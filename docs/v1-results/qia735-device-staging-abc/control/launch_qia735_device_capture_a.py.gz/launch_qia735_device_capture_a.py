from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-a'
assert not (b/'qia735-device-capture-a').exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',
 CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
 JAX_ENABLE_X64='true',JAX_PLATFORMS='cuda',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
with (b/'qia735-device-capture-a.log').open('x') as log:
 p=subprocess.Popen([sys.executable,'-u',str(b/'capture_qia735_device_a.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,scope='Original735 failed raw regression observer only,no physics/gate or accepted trajectory changes.')
(b/'qia735-device-capture-launch-a.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

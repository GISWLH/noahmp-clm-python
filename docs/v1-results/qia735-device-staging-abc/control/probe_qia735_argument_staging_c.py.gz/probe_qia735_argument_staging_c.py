from pathlib import Path
import hashlib
import json
import os
import sys
import time

import numpy as np

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-a'
r=b/'qia735-argument-staging-c';r.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items())
old=b/'qia735-device-capture-b';binding=json.loads((old/'receipt.json').read_text())
assert sha(old/'input-and-raw.npz')==binding['payload_sha256']=='90a4858239e9593d73a80d6c815b5b783f305b97c52d8bb28498444d8a911275'
with np.load(old/'input-and-raw.npz',allow_pickle=False) as z:packet=dict(z)
sys.path[:0]=[str(s),str(s/'src'),str(s/'tests')]
import jax
import jax.numpy as j
from jax import lax
from noahmp_clm.gpu.canopy_phase_energy import phase_energy_kernel_jax
from noahmp_clm.gpu.canopy_energy import _sum
from noahmp_clm.gpu.canopy_snow_radiation import canopy_snow_kernel_jax
from noahmp_clm.gpu.snicar import _jax_tables
from test_gpu_canopy_phase_energy import oldwet_jax_kernel

arrays=tuple(j.asarray(packet['a'+str(k)]) for k in range(9))
p=j.asarray(packet['parameters']);ext=j.asarray(packet['extension']);rad=j.asarray(packet['cuda_radiation'][0]);ice,impurity=_jax_tables('float32')
start=time.monotonic()
baseline=np.asarray(oldwet_jax_kernel('32')(*arrays))[None,:]
assert baseline.tobytes()==packet['jax_raw'].tobytes()
outputs=dict(cuda_original_raw=packet['cuda_raw'],jax_original_raw=baseline,cuda_original_radiation=packet['cuda_radiation'])
def radiation(leaf,stem,snow,count,u):
    area=lax.optimization_barrier(leaf+stem);fv=j.where(_sum(area)>0.,u[13],0.)
    return canopy_snow_kernel_jax(area,snow,count,j.stack((u[11],fv,u[21],u[22],u[19],u[20])),ice,impurity,track_absorption=True)
outputs['jax_tracked_radiation']=np.asarray(jax.jit(radiation)(arrays[0],arrays[4],arrays[7],arrays[8],arrays[1]))[None,:]
functions={
 'default_dynamic_parameters':(jax.jit(lambda *a:phase_energy_kernel_jax(*a[:9],a[9],ice,impurity,exchange_extension=a[10],max_iterations=100,tolerance=.005)),(*arrays,p,ext)),
 'explicit_radiation_constant_parameters':(jax.jit(lambda *a:phase_energy_kernel_jax(*a[:9],p,ice,impurity,exchange_extension=ext,radiation=a[9],max_iterations=100,tolerance=.005)),(*arrays,rad)),
 'explicit_radiation_dynamic_parameters':(jax.jit(lambda *a:phase_energy_kernel_jax(*a[:9],a[9],ice,impurity,exchange_extension=a[10],radiation=a[11],max_iterations=100,tolerance=.005)),(*arrays,p,ext,rad)),
}
for label,(fn,args) in functions.items():
    outputs[label]=np.asarray(fn(*args))[None,:]
np.savez_compressed(r/'variants.npz',**outputs)
jax.effects_barrier();assert all(sha(s/n)==h for n,h in m.items())
record=dict(scope='GPU-only read-only JAX argument/radiation staging diagnosis for exact rejected735. Original default-constant path reproduced byte-exact before explicit dynamicparameter and/or sameCUDA-radiation variants. Same private production physics/kernel/oldstores/100/.005;no source/gate/field/precision changes or acceptedtrajectory. Every300raw variant and584trackedradiation exported for EHPC analysis. Earlier captureA shape failure and B untracked extra-radiation calculation retained;C explicitly uses actual track_absorption=True.',
 source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,original_constant_path_byte_exact=True,device_barrier_complete=True,
 original_payload_sha256=sha(old/'input-and-raw.npz'),variants_sha256=sha(r/'variants.npz'),seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
os._exit(0)

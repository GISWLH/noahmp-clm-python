from pathlib import Path
import hashlib
import inspect
import json
import os
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1'); s = b / 'p6-all-phase-final-a'
r = b / 'qia735-device-capture-a'; r.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text()); assert all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'tests')]
import test_gpu_canopy_phase_energy as test
import cupy as cp
import jax
import jax.numpy as j
from noahmp_clm.gpu.canopy_snow_radiation import canopy_snow_kernel_jax
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
from noahmp_clm.gpu.snicar import _jax_tables

captured = {}
def capture(local):
    captured.update(local)

source = inspect.getsource(test.test_saved_existing_water_phase_cuda_all_raw_same_precision)
marker = '    np.testing.assert_allclose(actual,expected,rtol=1e-6,atol=1e-6)'
assert source.count(marker) == 1
instrumented = source.replace(marker, '    capture(locals())\n' + marker)
namespace = dict(test.__dict__, capture=capture)
exec(compile(instrumented, '<read-only capture of original735 failed device regression>', 'exec'), namespace)
start, failure = time.monotonic(), None
try:
    namespace['test_saved_existing_water_phase_cuda_all_raw_same_precision']()
except AssertionError as e:
    failure = type(e).__name__ + ': ' + str(e); (r / 'original-assertion.txt').write_text(traceback.format_exc())
assert captured and failure
case = captured['case']; arrays = case['arrays']
payload = dict(cuda_raw=captured['actual'], jax_raw=captured['expected'], cuda_radiation=cp.asnumpy(captured['radiation']))
for k, value in enumerate(captured['arrays']):
    actual = cp.asnumpy(value)[0]; expected = np.asarray(arrays[k])
    assert np.array_equal(actual, expected) and actual.dtype == expected.dtype, k
    payload['a' + str(k)] = actual
leaf, u, f, soil, stem, c, boundary, snow, count = map(j.asarray, arrays)
ice, impurity = _jax_tables('float32')
radfn = jax.jit(lambda a, st, ss, n, ex: canopy_snow_kernel_jax(a+st, ss, n, radiation_inputs(a+st, ex, j), ice, impurity))
payload['separately_recomputed_jax_radiation'] = np.asarray(radfn(leaf,stem,snow,count,u))[None,:]
payload['extension'] = case['extension']; payload['parameters'] = case['parameters']
np.savez_compressed(r / 'input-and-raw.npz', **payload)
jax.effects_barrier(); cp.cuda.runtime.deviceSynchronize()
assert all(sha(s / n) == h for n, h in m.items())
record = dict(scope='Read-only observer inserted immediately before original allraw1e-6 assertion in source511735 regression. Same original CUDA/JAX raw outputs/inputs captured and original rejection preserved. Additional JAX radiation recomputed separately is diagnostic only;no claim this injection reproduces full original raw path. No source/solver/gate or accepted-year changes.',
              failure=failure, input_arrays_exact=True, source_unchanged=True, device_barriers_complete=True,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), payload_sha256=sha(r / 'input-and-raw.npz'), seconds=time.monotonic()-start)
(r / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n'); print(json.dumps(record), flush=True)
os._exit(0)

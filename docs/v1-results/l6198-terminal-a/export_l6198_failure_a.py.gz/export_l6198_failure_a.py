from pathlib import Path
from dataclasses import astuple
import hashlib,json,sys,tarfile
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-joint-chord-a';original=b/'fluxnet-first-climate-cycle-20261018-l';r=b/'l6198-failure-a';r.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==489 and all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as driver
report,state,prior=driver.read_generation(original/'cuda-day');assert report['status']=='failed' and report['steps_completed']==6198 and report['steps_requested']==17520
cases=driver.load_batch(original/'batch.json');index=report['steps_completed'];forcing=np.asarray([c['data']['forcing'][index] for c in cases],np.float32);environment=np.asarray([c['data']['environment'][index] for c in cases],np.float32)
calendar_values,calendar_flags=driver.pack_bgc_environment([driver.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=np.float32)
schedules=[driver.DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([v.nitrogen_rate for v in schedules],np.float32)*forcing[:,0];deposition=np.asarray([d.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,d) in enumerate(zip(cases,schedules))],np.float32)
geometry=np.asarray([astuple(driver.MOSTGeometry(**c['config']['most_geometry'])) for c in cases],np.float32)
payload={f'a{k}':state[f'a{k}'] for k in range(16)};payload.update(forcing=forcing,environment=environment,calendar_values=calendar_values,calendar_flags=calendar_flags,nitrogen=nitrogen,deposition=deposition,geometry=geometry)
np.savez_compressed(r/'input.npz',**payload)
differences=[];assert not report['identity']['compare_jax32']
record=dict(scope='Original failed L6198 committed primary16 arrays, no shadow plus exact next forcing/environment/deposition/calendar/geometry. Packing only, no original failed step accepted/advanced or model restarted. Original50 MOST iterations and all convergence/MHCN bounds remain unchanged.',index=index,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(r/'input.npz'),primary_shadow_before_maximum_absolute=differences,leaf_parameters=cases[0]['config']['leaf_parameters'],cases=[dict(case=c['case'],time_start=str(c['data']['time_start'][index])) for c in cases],original_failure=report['failure'])
(r/'binding.json').write_text(json.dumps(record,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
a=b/'l6198-terminal-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [original/'cuda-day/batch.json',original/'cuda-day'/report['checkpoint_file'],original/'annual.log',original/'annual-exit.json',original/'annual-launch.json',original/'batch.json',original/'input-import.json']:
  if p.exists():t.add(p,arcname=p.relative_to(original),recursive=False)
 for case,desc in report['case_reports'].items():
  p=original/'cuda-day'/case/desc['file'];d=json.loads(p.read_text());t.add(p,arcname=p.relative_to(original),recursive=False);p=original/'cuda-day'/case/d['model_npz'];t.add(p,arcname=p.relative_to(original),recursive=False)
 for p in sorted(r.iterdir()):t.add(p,arcname='diagnostic-input/'+p.name,recursive=False)
 t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
assert all(sha(s/n)==v for n,v in m.items());print(json.dumps(dict(archive_sha256=sha(a),bytes=a.stat().st_size,before_maximum_absolute=differences,input_sha256=sha(r/'input.npz'))))

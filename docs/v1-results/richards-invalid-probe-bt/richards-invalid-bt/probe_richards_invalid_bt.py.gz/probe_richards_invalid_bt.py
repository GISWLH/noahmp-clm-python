"""Reproduce one failed tendency on copied state; do not resume either year."""
from pathlib import Path
from dataclasses import astuple
import hashlib,json,os,sys,time,traceback
import numpy as np
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-numerical-recovery-c';r=b/'richards-invalid-bt'/label;r.mkdir();old=b/('qia-richards-'+label+'-cuda-year-c');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());terminal=json.loads((old/'year-exit.json').read_text());year=json.loads((old/'year-receipt.json').read_text());assert terminal['returncode']==1 and not terminal['passed'] and year['failure']=='ValueError: Invalid Richards water, pores or hydraulic coefficients' and year['source_unchanged']
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as cpu
import noahmp_clm.clm_enthalpy_driver as model
import noahmp_clm.gpu.richards_enthalpy as heat
import noahmp_clm.gpu.cuda.richards as flow
import noahmp_clm.gpu.cuda.richards_enthalpy as cuda_heat
import cupy as cp
report,saved,prior=native.read_generation(old/'trajectory');index=report['steps_completed'];assert report['status']=='failed' and index==(6501 if label=='capacity' else 6499) and report['steps_requested']==17520
cases=native.load_batch(old/'inputs'/label/'batch.json');dtype=np.float32;a=native.checkpoint_arrays(saved,report['identity']);assert len(a)==23 and len(cases)==1
forcing=np.asarray([c['data']['forcing'][index] for c in cases],dtype);environment=np.asarray([c['data']['environment'][index] for c in cases],dtype);calendar,flags=native.pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype);schedules=[native.DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([q.nitrogen_rate for q in schedules],dtype)*forcing[:,0];deposition=np.asarray([q.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,q) in enumerate(zip(cases,schedules))],dtype);geometry=np.asarray([astuple(native.MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype);leaf=np.asarray([astuple(native.LeafParameters(**c['config']['leaf_parameters'])) for c in cases],dtype);capacity_environment=native.pack_capacity_environment([native.capacity_environment(c['stamps'][index],c['metadata'],True) for c in cases],dtype=dtype)
kwargs=dict(environment=calendar,calendar=flags,nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,most_geometry=geometry,leaf_parameters=leaf,return_surface=True,soil_hydrology=native.batch_hydrology(cases),capacity_environment=capacity_environment)
if cases[0]['config'].get('canopy_optics') is not None:
    from noahmp_clm.physics.canopy_optics import CanopyOptics
    from noahmp_clm.gpu.canopy_optics import pack_canopy_optics
    kwargs['canopy_optics']=np.stack([pack_canopy_optics(CanopyOptics(**c['config']['canopy_optics']),dtype) for c in cases])
engine=native.Backend('cuda32');device=tuple(cp.asarray(v) for v in a);device=engine.update_forcing(device,environment);before=tuple(engine.host(v) for v in device);original_profile=heat._profile;original_flow=flow.run_richards_cuda;latest={};calls=0;captured=False
def wrapped_profile(c,p,liquid,xp,exponent):
    result=original_profile(c,p,liquid,xp,exponent);latest.clear();latest.update(heat_cells=cp.asnumpy(c),heat_properties=cp.asnumpy(p),phase_liquid=cp.asnumpy(liquid),profile=cp.asnumpy(result),ice_exponent=np.asarray(exponent));return result
def wrapped_flow(w,p,dt,**controls):
    global calls,captured
    calls+=1
    try:return original_flow(w,p,dt,**controls)
    except ValueError as err:
        if str(err)=='Invalid Richards water, pores or hydraulic coefficients':
            packet=dict(latest,water=cp.asnumpy(w),hydraulics=cp.asnumpy(p),dt=cp.asnumpy(dt));np.savez_compressed(r/'invalid-richards-input.npz',**packet);(r/'invalid-controls.json').write_text(json.dumps(controls,indent=2)+'\n');captured=True
        raise
def blocked(*args,**kwargs):raise AssertionError('Probe cannot use NumPy model forward physics')
failure=None;start=time.monotonic();output_produced=False
try:
    heat._profile=wrapped_profile;flow.run_richards_cuda=wrapped_flow;cpu.step_clm_enthalpy_column=blocked;model.step_clm_enthalpy_column=blocked
    engine.step(*device,forcing,**kwargs);output_produced=True
except Exception as err:failure=type(err).__name__+': '+str(err);(r/'traceback.txt').write_text(traceback.format_exc())
finally:heat._profile=original_profile;flow.run_richards_cuda=original_flow
cp.cuda.runtime.deviceSynchronize();inputs=dict(forcing=forcing,environment=environment,calendar=calendar,calendar_flags=flags,nitrogen=nitrogen,deposition=deposition,geometry=geometry,leaf_parameters=leaf,capacity_environment=capacity_environment)
if 'canopy_optics' in kwargs:inputs['canopy_optics']=kwargs['canopy_optics']
inputs.update({'before'+str(k):v for k,v in enumerate(before)});inputs.update({'saved_'+k:v for k,v in saved.items() if k in ['initial','net','bounds','maximum','stepmax','tracermax','index']});np.savez_compressed(r/'tendency-inputs-and-ledger.npz',**inputs);(r/'failed-batch-report.json').write_bytes((old/'trajectory/batch.json').read_bytes());(r/'configuration.json').write_text(json.dumps(cases[0]['config'],indent=2)+'\n');(r/'year-receipt.json').write_bytes((old/'year-receipt.json').read_bytes());d=dict(case=label,expected_failure_reproduced=failure==year['failure'],failure=failure,output_produced=output_produced,invalid_input_captured=captured,flow_calls=calls,completed_before_failed_step=index,original_requested_steps=17520,seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_year_report_unchanged=sha(old/'trajectory/batch.json')==year['report_sha256'],original_year_parent_exit=terminal['returncode'],device_barrier_complete=True,scope='One privateCUDA tendency on copiedactualfailed6501/6499 state, originaloldC inputs/config/forcing/controls and I/O wrappers only. Rawinvalidprofile exported for independentEHPC analysis; no CPUforwardphysics, no originalyear resumed/overwritten. Diagnosticdelivery0 is reproduction, not physicsorconservationpass/yearcompletion.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if d['expected_failure_reproduced'] and captured and d['source_unchanged'] and d['original_year_report_unchanged'] else 1)

from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();mode=sys.argv[1];items=[]
if mode=='years':
    snapshots=[]
    for label,n in [('capacity',6501),('capacity_optics',6499)]:
        root=b/('qia-richards-'+label+'-cuda-year-c');year=json.loads((root/'year-receipt.json').read_text());exit=json.loads((root/'year-exit.json').read_text());report=json.loads((root/'trajectory/batch.json').read_text());assert exit['returncode']==1 and not exit['passed'] and year['failure']=='ValueError: Invalid Richards water, pores or hydraulic coefficients' and year['source_unchanged'] and sha(root/'trajectory/batch.json')==year['report_sha256'] and report['status']=='failed' and report['steps_completed']==n and report['steps_requested']==17520
        for p in sorted(root.iterdir()):
            if p.is_file():items.append((p,label+'/'+p.name))
        for p in sorted((root/'inputs').rglob('*.json')):items.append((p,label+'/inputs/'+p.relative_to(root/'inputs').as_posix()))
        items.append((root/'trajectory/batch.json',label+'/trajectory/batch.json'));p=root/'trajectory'/report['checkpoint_file'];assert sha(p)==report['checkpoint_sha256'];items.append((p,label+'/trajectory/'+p.name))
        for case,descriptor in report['case_reports'].items():
            folder=root/'trajectory'/case;p=folder/descriptor['file'];assert sha(p)==descriptor['sha256'];c=json.loads(p.read_text());items.append((p,label+'/trajectory/'+case+'/'+p.name));p=folder/c['model_npz'];assert sha(p)==c['model_npz_sha256'];items.append((p,label+'/trajectory/'+case+'/'+p.name))
        snapshots.append(dict(case=label,completed_steps=n,status=report['status'],failure=year['failure'],original_parent_exit=exit['returncode'],batch_report_sha256=year['report_sha256'],checkpoint_sha256=report['checkpoint_sha256']))
    controls=['clm-numerical-recovery-c-source.tar.gz','qia-recovery-c-inputs-u.tar.gz','run_qia_cuda_year_w.py','control_qia_cuda_year_w.py','launch_qia_cuda_year_w.py'];name='qia-cuda-year-failures-bu'
    meta=b/(name+'-record.json');assert not meta.exists();meta.write_text(json.dumps(dict(snapshots=snapshots,scope='Actualold563C cap1 CUDAyears terminalfailed6501/6499 of17520, originalMHCN checkpoints/fullpartialtrace/forcing/config/controls retained. Onlyterminalgeneration copied; alloriginaldailygenerations remainserver. No failedprefix resumed or partialyearcompletion/sciencepass.'),indent=2)+'\n');items.append((meta,'record.json'))
elif mode=='probe-bt':
    roots=[b/'richards-invalid-bs',b/'richards-invalid-bt'];d=json.loads((roots[1]/'exit.json').read_text());assert d['diagnostic_delivered'] and d['returncode']==0 and all(q['actual_child_returncode']==0 for q in d['records']);assert json.loads((roots[0]/'exit.json').read_text())['returncode']==1
    for root in roots:
        for p in sorted(root.rglob('*')):
            if p.is_file():items.append((p,root.name+'/'+p.relative_to(root).as_posix()))
    controls=['clm-numerical-recovery-c-source.tar.gz','launch_richards_invalid_bs.py','launch_richards_invalid_bt.py','prepare_richards_invalid_bt.py'];name='richards-invalid-probe-bt'
else:raise ValueError(mode)
items.extend((b/n,'control/'+n) for n in [*controls,Path(__file__).name]);a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

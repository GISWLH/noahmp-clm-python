from pathlib import Path
import ast
o=Path(__file__).parent
for name in ['probe_richards_invalid_bs.py','control_richards_invalid_bs.py','launch_richards_invalid_bs.py']:
    text=(o/name).read_text(encoding='utf-8').replace('richards-invalid-bs','richards-invalid-bt').replace('_bs.py','_bt.py')
    text=text.replace(';original_alias=cuda_heat.run_richards_cuda','').replace(';cuda_heat.run_richards_cuda=wrapped_flow','').replace(';cuda_heat.run_richards_cuda=original_alias','')
    ast.parse(text);p=o/name.replace('_bs.py','_bt.py');assert not p.exists();p.write_bytes(text.encode())
print('BT fixes diagnosticalias assumption only: CUDAheat importsflow insidefunction; originalBS prefailure retained. No model edit.')

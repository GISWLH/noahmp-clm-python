from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'richards-invalid-bs';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for label in ['capacity','capacity_optics']:
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:break
        (r/'waiting.json').write_text(json.dumps(dict(gpu_free_mib=free,host_available_kib=mem))+'\n');time.sleep(20.)
    with (r/(label+'.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'probe_richards_invalid_bs.py'),label],stdout=log,stderr=subprocess.STDOUT)
    (r/'progress.json').write_text(json.dumps(dict(case=label,pid=p.pid,records=records),indent=2)+'\n');code=p.wait();path=r/label/'receipt.json';d=json.loads(path.read_text()) if path.exists() else {};row=dict(case=label,actual_child_returncode=code,diagnostic_delivered=code==0 and d.get('expected_failure_reproduced') and d.get('invalid_input_captured'),receipt_sha256=sha(path) if path.exists() else None);records.append(row);print(json.dumps(row),flush=True)
    if not row['diagnostic_delivered']:break
good=len(records)==2 and all(q['diagnostic_delivered'] for q in records);(r/'exit.json').write_text(json.dumps(dict(returncode=0 if good else 1,diagnostic_delivered=good,records=records,scope='Actualprivateprobe parentwait status only; originalyearsbothremainfailed and notresumed.'),indent=2)+'\n');raise SystemExit(0 if good else 1)

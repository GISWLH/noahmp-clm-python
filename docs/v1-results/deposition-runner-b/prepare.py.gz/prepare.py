"""Four existing site initializations; change only explicit deposition input."""
from pathlib import Path
import hashlib,json,os,subprocess
import numpy as np
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-deposition-runner-b'
inputs=root/'inputs';inputs.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=base/'p6-molten-snow-gpu-a/inputs'
cfgs={site:original/'configs'/(case+'.json') for site,case in [
    ('CN-Cng','CN-Cng-tq6-w2'),('CN-Qia','CN-Qia-tq39.6-w39.6'),('CN-Cha','CN-Cha-tq61.8-w61.8')]}
cfgs['CN-HaM']=original/'fluxnet-ham-initial-config-b.json'
batch=[];protocol=[]
for site,cf in cfgs.items():
    config=json.loads(cf.read_text());dep=root/'deposition-inputs'/(site+'.json');clim=json.loads(dep.read_text())
    stem='fluxnet-ham-2002-prepared' if site=='CN-HaM' else site
    inp=original/(stem+'.npz');mp=original/(stem+'.json');meta=json.loads(mp.read_text())
    assert all(config[k]==clim[k]==meta[k] for k in ('latitude','longitude'))
    with np.load(inp,allow_pickle=False) as z:data=dict(z)
    assert sha(inp)==meta['prepared_npz_sha256'];n=len(data['time_start']);values={k:v[:48] if v.ndim>0 and len(v)==n else v for k,v in data.items()}
    p=inputs/(site+'.npz');np.savez_compressed(p,**values)
    meta.update(scope='First day deposition integration check; not observation acceptance',
        parent_prepared_npz_sha256=sha(inp),parent_manifest_sha256=sha(mp),prepared_npz_sha256=sha(p),
        steps=48,start=str(values['time_start'][0]),end_exclusive=str(values['time_end'][-1]))
    (inputs/(site+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
    assert config.pop('aerosol_deposition_kg_m2_s')==[0.]*5
    config.update(case=site+'-monthly-deposition',scope='One-day real-forcing deposition integration check; existing cold initialization, not spinup or observational acceptance',
        aerosol_deposition_monthly_kg_m2_s=clim['aerosol_deposition_monthly_kg_m2_s'],
        nitrogen_deposition_gn_m2_s=clim['nitrogen_deposition_gn_m2_s'],deposition_provenance=clim,
        parent_configuration_sha256=sha(cf))
    if 'assumptions' in config:
        config['assumptions']=[x for x in config['assumptions'] if not x.startswith('Aerosol and N deposition zero')]
    cp=inputs/(site+'-config.json');cp.write_text(json.dumps(config,indent=2)+'\n')
    batch.append(dict(case=config['case'],input=str(p),input_manifest=str(inputs/(site+'.json')),configuration=str(cp)))
    protocol.append(dict(site=site,previous_configuration_sha256=sha(cf),configuration_sha256=sha(cp),deposition_mapping_sha256=sha(dep),first_interval=str(values['time_start'][0]),steps=48))
(root/'batch.json').write_text(json.dumps({'cases':batch},indent=2)+'\n')
(root/'protocol.json').write_text(json.dumps(dict(scope='No soil, leaf, height or initial-state retuning; only deposition input differs from the previous execution configurations',cases=protocol),indent=2)+'\n')
e=os.environ.copy();e.pop('LD_LIBRARY_PATH',None);e.update(PYTHONPATH='src:tests:benchmarks',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin')
exe='/home/lhwang/venvs/noahmp-phase3b/bin/python';jobs=[]
with (root/'cuda.log').open('w') as log:
    p=subprocess.Popen([exe,'-u','benchmarks/run_fluxnet_native.py','--batch','batch.json','--output','cuda-day'],cwd=root,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
jobs.append(dict(backend='cuda32',pid=p.pid))
for c in batch:
    with (root/(c['case']+'.log')).open('w') as log:
        p=subprocess.Popen([exe,'-u','benchmarks/run_fluxnet_column.py','--input',c['input'],'--input-manifest',c['input_manifest'],'--config',c['configuration'],'--output',str(root/'numpy-day'/c['case'])],cwd=root,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    jobs.append(dict(backend='numpy64',case=c['case'],pid=p.pid))
(root/'launch.json').write_text(json.dumps(jobs,indent=2)+'\n');print(json.dumps(jobs))

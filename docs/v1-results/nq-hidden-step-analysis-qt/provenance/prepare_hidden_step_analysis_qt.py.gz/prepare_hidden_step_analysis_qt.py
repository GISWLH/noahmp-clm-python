"""Freeze sealed QS local/time posthoc for root review; no numerical work."""
import ast
import difflib
import gzip
import io
import json
from pathlib import Path
import tarfile

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
PREP=BASE/'nq-hidden-step-analysis-qt-preparation'
NEW=BASE/'nq-hidden-step-analysis-qt-execution'
OLD=BASE/'nq-transport-analysis-qo-execution'


def main():
    evidence=(BASE/'nq-hidden-step-trace-qs-evidence.tar.gz').read_bytes();assert sha(evidence)=='797cc15dbc1ae68e7a2c057c4c19a432db126006a3d0505f1d8c16a56c9a0bbf'
    actual=files(evidence);stage=files(actual['executed-stage.tar.gz']);source=files(stage['source.tar.gz']);nq=files(stage['nq-evidence.tar.gz']);qs_binding=json.loads(stage['preparation/BINDINGS.json']);path=qs_binding['actual_aggregate0_packet_path']
    binding=dict(QS_evidence_archive_sha256=sha(evidence),QS_executed_stage_sha256=sha(actual['executed-stage.tar.gz']),QS_raw_GPU_archive_sha256=sha(actual['raw-gpu-result.tar.gz']),source_archive_sha256=sha(stage['source.tar.gz']),source_manifest_sha256=sha(source['SOURCE_SHA256.json']),source_files=584,original_test_sha256=sha(source['tests/test_gpu_clm_richards_column.py']),original_NQ_packet_path=path,original_NQ_packet_sha256=sha(nq[path]),original_fixture_sha256=sha(source['tests/fixtures/clm_richards_reference.npz']),control_code_source_path=qs_binding['control_code_source_path'],control_code_source_sha256=qs_binding['control_code_source_sha256'],selected_source_lines=qs_binding['selected_source_lines'],per_backend_original_events=dict(adapter=1,phase=4,profile=3,redistribute=3),per_backend_original_control_events=34,original_fields=126,physical_forward_calls=0,phase_or_reference_replays=0,GPU_calls=0,original_audit_calls=2,same_precision=dict(rtol=1e-6,atol=1e-6,integer_exact=True),resources='EHPC PBS compute002/1CPU/2GiB/5min',root_pre_execution_review_pending=True)
    assert binding['QS_executed_stage_sha256']=='ecbc522b5c40d15ec857df06c0f9cbcd565c0ec6350d1ad50f34e75c7af19e22' and binding['QS_raw_GPU_archive_sha256']=='3919278110fe5764b9143d26abe20f4b6f0d0a1f6ca98371703b5dc95f56f20e'
    PREP.mkdir(exist_ok=False);NEW.mkdir(exist_ok=False)
    for name in ('analyze_hidden_step_trace_qt.py','control_analysis_qt.py'):
        raw=(BASE/name).read_bytes();ast.parse(raw);assert b'\r' not in raw;(PREP/name).write_bytes(raw)
    (PREP/'BINDINGS.json').write_bytes(encode(binding));(PREP/'CONTROL_SOURCE_LINES.json').write_bytes(stage['preparation/CONTROL_SOURCE_LINES.json']);(PREP/'QS_CAPTURE_READOUT.json').write_bytes(actual['readout.json']);(PREP/'QO_TO_QT_WORKER.diff').write_bytes((BASE/'nq-hidden-step-analysis-qt-QO_TO_QT_WORKER.diff').read_bytes())
    (PREP/'README.md').write_text('''# QT sealed QS controls/time posthoc — review only

One compute0021CPU/2GiB/5min PBS job reads only sealed actualQS797cc… evidence/raw391927…/stageecbc… and unchanged originalNM584/NQ aggregate0. No model/evaluate/phase/flow/reference/GPU solve or new physical trial is called. Actual transparent126outputs/11native schedule/34code-object events per backend are revalidated from raw hashes; all data/source/control bytes remain exact. Original QO126field/int1e-6/native-prefix analysis and two original aggregate M/H/impurity audit calls are retained unchanged. Aggregate has no C/N pools. Original1J failure remains actualworker/PBS1 even when diagnostic_conclusive is true.

Validate every original typed packet and align native events and control events only while their exact metadata schedule has a common prefix. Every control snapshot retains original source line/text, event/line occurrence/native sequence and explicit present/absent local list. The helper tracks original call args and assignments completed before selected source points, separates earlier-loop values and conditional line77 growth that was not separately traced. Presence does not establish a fresh value. Return water/enthalpy/z ages are identified from unconditional original78/82/83 assignments and normal original return, not invented from numerical agreement. Report complete actual arrays, scalarhex and first differing snapshot/newly assigned local; identical operands localize an original expression only, not its generated division/multiply instruction.

Time bookkeeping is separate from physical equality. Bind each original pre-call line44 host step/elapsed to the immediately following original flow event and its actual<f4 dt argument. Classify acceptance from the actual line74 event after original elapsed update; rejection from52/68 is retained and not counted as committed time. Preserve raw Pythonfloat hex/value and dtype32 dt; compute only saved-value differences and exact dyadic sums, with original host-addition checks, accepted-flow cumulative durations, host elapsed minus that sum and endpoint sum minus original requested duration. Inner flow substep elapsed was not observed; this is an audit of actual arguments passed to accepted outer flow calls. No new root, derivative, divider, flag or alternate trajectory is generated.

The worker imports only the same original pure audit and blocks NumPy physical forward definitions. All126fields, exact integer rules and all original hard ledger bounds stay unchanged; no near-zero relative gate is added. Full existing numerical raw payloads remain sealed; nonfinite values keep explicit hex, never replace0. All source/control/evidence identities are rechecked. Actual F/Stageout must be collected. A time-bookkeeping candidate remains a separate proposal pending these actual causal data; no production/source/fixture/test is changed, and no original scientific/year/global failure is erased.

This directory is prepared only. Root must read worker/helper/diff/binding and authorize the unique actual job; no submission or numerical computation occurs during preparation.
''',encoding='utf-8',newline='\n')
    controls={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir())};(PREP/'CONTROLS_SHA256.json').write_bytes(encode(controls))
    differences=[]
    for old,new in [('check_stage_qo.py','check_stage_qt.py'),('dispatch_transport_analysis_qo.py','dispatch_hidden_step_analysis_qt.py'),('analysis_qo.pbs','analysis_qt.pbs')]:
        before=(OLD/old).read_text();after=before.replace('transport-analysis-qo','hidden-step-analysis-qt').replace('check_stage_qo','check_stage_qt').replace('dispatch_transport_analysis_qo','dispatch_hidden_step_analysis_qt').replace('analysis_qo.pbs','analysis_qt.pbs').replace('qo-result','qt-result')
        if old.endswith('.pbs'):
            command='"$py" -B "$stage/preparation/analyze_transport_trace_qo.py" --evidence "$stage/qj-evidence.tar.gz" --output "$root/analysis"';assert command in after
            after=after.replace(command,'"$py" -B "$stage/preparation/analyze_hidden_step_trace_qt.py" --evidence "$stage/qs-evidence.tar.gz" --output "$root/analysis"');assert after.startswith('#!/bin/bash\n') and '\r' not in after
        else:ast.parse(after)
        (NEW/new).write_text(after,encoding='utf-8',newline='\n');differences.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='QO/'+old,tofile='QT/'+new))
    (NEW/'QO_TO_QT_LIFECYCLE.diff').write_text(''.join(differences),encoding='utf-8',newline='\n');(NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),QS_evidence_archive_sha256=sha(evidence),resources='1CPU/2GiB/5min/compute002',original_audit_calls=2,physical_forward_calls=0,GPU_calls=0,root_authorization_pending=True,single_submission=True,automatic_retry=False)));(NEW/'README.md').write_text('Original QO/QI/PW immutable manager/compute002 PBS/hash lifecycle, freshQT paths,1CPU/2GiB/5min.0forward/GPU,2original pure ledger calls. Native1J gate remains actualPBS1 if reproduced; diagnostic completion is independent. Root review/authorization pending; no submit.\n',encoding='utf-8',newline='\n')
    execution={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir())};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(execution))
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()});items['qs-evidence.tar.gz']=evidence;items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/'nq-hidden-step-analysis-qt-stage.tar.gz';assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(passed=True,stage_sha256=sha(target.read_bytes()),stage_files=len(items),preparation_controls=len(controls),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(execution),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),source584_and_actual_QS_bound=True,control_assignment_age_explicit=True,saved_host_and_actual_f32_flow_time_separate=True,physical_forward_calls=0,GPU_calls=0,original_audit_calls=2,root_review_pending=True,submitted=False,numerical_executed=False)
    (BASE/'nq-hidden-step-analysis-qt-stage-package.json').write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

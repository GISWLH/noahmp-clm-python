"""EHPC-only interpretation of sealed QS snapshots with explicit assignment age."""
import json
import hashlib
import os
import socket
from fractions import Fraction

FRESH_AFTER_SOURCE={
    39:('current','phase','accepted','rejected','hydraulic_steps','hydraulic_rejections','elapsed','step'),
    43:('step','liquid','offset'),
    44:('profile',),
    50:('flow','f','r','net','z','outward','incoming','available','ratio','fraction'),
    52:('rejected','step'),
    60:('specific','carried','water','enthalpy','candidate'),
    65:('next_phase',),
    66:('change',),
    68:('rejected','step'),
    74:('current','phase','elapsed','accepted'),
    77:('hydraulic_steps','hydraulic_rejections','max_hydraulic','max_temperature','max_fraction'),
}


def guard():
    assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES')==''


def host_state(tree):
    items=tree['items'];items=items['locals']['items'] if 'locals' in items else items
    result={}
    for name in ('duration','elapsed','step','fraction_limit','temperature_limit','budget','accepted','rejected','hydraulic_steps','hydraulic_rejections'):
        if name not in items:continue
        value=items[name]
        if value['kind']=='float':result[name]=dict(kind='float',hex=value['hex'],value=float.fromhex(value['hex']))
        elif value['kind'] in ('int','bool'):result[name]=dict(kind=value['kind'],value=value['value'])
        else:result[name]=dict(kind=value['kind'],descriptor=value)
    return result


def load_controls(evidence,prefix,tape,source_files,binding,packet):
    guard();receipt=json.loads(evidence[prefix+'control-trace-receipt.json']);capture=json.loads(evidence[prefix+'capture-receipt.json'])
    assert receipt==capture['control_trace'] and receipt['original_one_calls']==receipt['original_one_returns']==1 and not receipt['original_abnormal_exits'] and not receipt['original_exception_events'] and not receipt['observer_errors'] and receipt['tracer_started'] and receipt['tracer_stopped'] and receipt['was_current_when_stopped'] and receipt['prior_tracer_was_none']
    assert receipt['original_code_name']=='_one' and receipt['original_code_first_line']==34
    assert hashlib.sha256(evidence[prefix+'control-events.jsonl']).hexdigest()==capture['control_events_jsonl_sha256']
    assert hashlib.sha256(source_files[binding['control_code_source_path']]).hexdigest()==binding['control_code_source_sha256']
    rows=[json.loads(s) for s in evidence[prefix+'control-events.jsonl'].decode().splitlines()]
    assert len(rows)==receipt['events']==34 and [r['sequence'] for r in rows]==list(range(1,35))
    lines=source_files[binding['control_code_source_path']].decode().splitlines();allowlist=receipt['named_local_allowlist']
    assert receipt['selected_lines']==binding['selected_source_lines']
    attempt=0;ages={};records=[]
    for row in rows:
        assert row['frame_ordinal']==1 and row['source_text']==lines[row['source_line']-1]
        assert row['event'] in ('call','line','return') and (row['event']!='line' or row['source_line'] in receipt['selected_lines'])
        assert len(set(row['present_local_names'])|set(row['absent_local_names']))==len(allowlist) and set(row['present_local_names']).isdisjoint(row['absent_local_names'])
        assert set(row['present_local_names'])|set(row['absent_local_names'])==set(allowlist)
        pair=packet(tape,'control/'+str(row['sequence']).zfill(6));tree=pair[0];items=tree['items']
        locals_items=items['locals']['items'] if row['event']=='return' else items
        assert set(locals_items)==set(row['present_local_names'])
        if row['event']=='call':
            for name in locals_items:ages[name]=dict(origin='original_call_argument',attempt=0,control_event=row['sequence'],source_line=row['source_line'])
        if row['event']=='line' and row['source_line']==42:attempt+=1
        fresh=list(FRESH_AFTER_SOURCE.get(row['source_line'],())) if row['event']=='line' else []
        if row['event']=='line' and row['source_line']==40 and attempt==0:fresh+=['max_temperature','max_fraction','max_hydraulic']
        for name in fresh:
            if name in locals_items:ages[name]=dict(origin='assignment_completed_before_this_source_line',attempt=attempt,control_event=row['sequence'],observed_at_source_line=row['source_line'])
        if row['event']=='return':
            assert row['normal_original_return'] and items['original_return']['kind']=='dict'
            for name,line in [('z',78),('water',82),('enthalpy',83)]:
                if name in locals_items:
                    ages[name]=dict(origin='original_unconditional_assignment_after_last_line_event_before_normal_return',attempt=attempt,source_line=line,observed_at_control_event=row['sequence']);fresh.append(name)
        named_ages={name:dict(ages.get(name,dict(origin='present_but_assignment_age_not_observed'))) for name in locals_items}
        key={n:row[n] for n in ('event','frame_ordinal','source_line','line_occurrence','native_event_sequence','present_local_names','absent_local_names')}
        records.append(dict(row=row,alignment_key=key,packet=pair,attempt=attempt,freshly_assigned_local_names=[n for n in fresh if n in locals_items],assignment_age=named_ages,actual_host_state=host_state(tree)))
        if row['event']=='line' and row['source_line']==77 and 'step' in locals_items:
            # The conditional and its body share line77. The next recorded step
            # may have changed there; do not infer branch truth from presence.
            ages['step']=dict(origin='may_have_been_updated_by_unobserved_line77_conditional_body',attempt=attempt,after_control_event=row['sequence'],source_line=77)
    return dict(receipt=receipt,records=records,observed_attempts=attempt)


def changed_local_names(comparison):
    names=set()
    for path in comparison['differing_array_paths']:
        parts=path.split('/')[1:]
        if parts and parts[0]=='locals':parts=parts[1:]
        if parts:names.add(parts[0])
    for change in comparison['nonarray_typed_differences']:
        parts=[s for s in change['path'].split('/')[1:] if s not in ('items','fields')]
        if parts and parts[0]=='locals':parts=parts[1:]
        if parts:names.add(parts[0])
    return sorted(names)


def compare_controls(left,right,compare_packets):
    guard();a=left['records'];b=right['records'];comparisons=[];first=None;first_fresh=None;divergence=None
    for index in range(max(len(a),len(b))):
        x=a[index] if index<len(a) else None;y=b[index] if index<len(b) else None
        if x is None or y is None or x['alignment_key']!=y['alignment_key']:
            divergence=dict(index=index,cuda=x['alignment_key'] if x else None,jax=y['alignment_key'] if y else None);break
        values=compare_packets(x['packet'],y['packet'],'original_one_locals');names=changed_local_names(values)
        host_diffs={}
        for name,l in x['actual_host_state'].items():
            r=y['actual_host_state'].get(name)
            if r is not None and l!=r:
                host_diffs[name]=dict(cuda=l,jax=r,absolute_difference=abs(l['value']-r['value']) if l['kind']==r['kind']=='float' else None)
        newly_changed=sorted(set(names)&set(x['freshly_assigned_local_names'])&set(y['freshly_assigned_local_names']))
        summary=dict(index=index,sequence=x['row']['sequence'],event=x['row']['event'],source_line=x['row']['source_line'],source_text=x['row']['source_text'],native_event_sequence=x['row']['native_event_sequence'],cuda_attempt=x['attempt'],jax_attempt=y['attempt'],differing_local_names=names,newly_assigned_differing_names=newly_changed,cuda_assignment_age=x['assignment_age'],jax_assignment_age=y['assignment_age'],cuda_host_state=x['actual_host_state'],jax_host_state=y['actual_host_state'],host_float_differences=host_diffs,complete_values=values)
        comparisons.append(summary)
        marker={n:summary[n] for n in ('index','sequence','event','source_line','source_text','native_event_sequence','cuda_attempt','jax_attempt','differing_local_names','newly_assigned_differing_names')}
        if first is None and not values['physical_typed_inputs_or_outputs_byte_exact']:first=marker
        if first_fresh is None and newly_changed:first_fresh=marker
    return dict(common_prefix_events=len(comparisons),first_control_schedule_divergence=divergence,first_differing_control_snapshot=first,first_differing_newly_assigned_locals=first_fresh,observed_attempts=dict(cuda=left['observed_attempts'],jax=right['observed_attempts']),source_assignment_age_rules={str(k):list(v) for k,v in FRESH_AFTER_SOURCE.items()},complete_common_prefix_comparisons=comparisons,
                interpretation='Snapshots copy existing variables. Assignment age follows pinned original source lines; line77 step growth is explicitly uncertain until a later recorded assignment. A newly different ratio after source49 with identical saved operands localizes that source expression, not a specific generated reciprocal/multiply instruction. Only saved-value algebra is performed; no model/branch-selection/phase/flow/reference trajectory is replayed.')


def audit_time_bookkeeping(control,native):
    """Compare saved host time to actual flow-argument time; no new solve."""
    guard();records=control['records'];flow_rows=[r for r in native['schedule'] if r['kind']=='redistribute']
    assert len(flow_rows)==control['observed_attempts']
    def exact_number(value):
        q=Fraction.from_float(float(value));return dict(value=float(value),hex=float(value).hex(),exact_numerator=q.numerator,exact_denominator=q.denominator)
    def fraction_number(value):return dict(value=float(value),exact_numerator=value.numerator,exact_denominator=value.denominator)
    committed=Fraction(0);host_sequential=0.;ledger=[]
    for attempt,flow in enumerate(flow_rows,1):
        pre=[r for r in records if r['attempt']==attempt and r['row']['event']=='line' and r['row']['source_line']==44]
        accepted=[r for r in records if r['attempt']==attempt and r['row']['event']=='line' and r['row']['source_line']==74]
        rejected=[r for r in records if r['attempt']==attempt and r['row']['event']=='line' and r['row']['source_line'] in (52,68)]
        assert len(pre)==1 and len(accepted)+len(rejected)==1
        pre=pre[0];assert flow['sequence']==pre['row']['native_event_sequence']+1 and flow['ordinal']==attempt
        tree,arrays=native['events'][flow['sequence']]['input'];node=tree['items']['dt'];dt=arrays[node['key']]
        assert dt.dtype.str=='<f4' and list(dt.shape)==[1]
        actual_dt=float(dt[0]);state=pre['actual_host_state'];step=state['step']['value'];elapsed=state['elapsed']['value'];duration=state['duration']['value']
        kernel_q=Fraction.from_float(actual_dt);host_step_q=Fraction.from_float(step)
        row=dict(attempt=attempt,native_flow_sequence=flow['sequence'],native_flow_ordinal=flow['ordinal'],pre_call_control_sequence=pre['row']['sequence'],actual_flow_dt_dtype=dt.dtype.str,actual_flow_dt_shape=list(dt.shape),actual_flow_dt=exact_number(actual_dt),saved_pre_call_host_step=exact_number(step),saved_pre_call_host_elapsed=exact_number(elapsed),saved_host_duration=exact_number(duration),host_step_minus_actual_flow_dt_exact=fraction_number(host_step_q-kernel_q),host_step_exactly_equals_actual_flow_dt=host_step_q==kernel_q,accepted=bool(accepted),rejected=bool(rejected))
        terminal=(accepted or rejected)[0];after=terminal['actual_host_state'];row['terminal_control_sequence']=terminal['row']['sequence'];row['terminal_source_line']=terminal['row']['source_line'];row['saved_terminal_host_step']=exact_number(after['step']['value']);row['saved_terminal_host_elapsed']=exact_number(after['elapsed']['value'])
        if accepted:
            assert after['step']['hex']==state['step']['hex'] and after['accepted']['value']==state['accepted']['value']+1 and after['rejected']['value']==state['rejected']['value']
            committed+=kernel_q;host_sequential+=step
            row.update(saved_host_elapsed_matches_original_float64_addition=after['elapsed']['hex']==(elapsed+step).hex(),saved_host_elapsed_increment_exact=fraction_number(Fraction.from_float(after['elapsed']['value'])-Fraction.from_float(elapsed)),committed_flow_dt_sum_exact=fraction_number(committed),saved_host_elapsed_minus_committed_flow_dt_sum_exact=fraction_number(Fraction.from_float(after['elapsed']['value'])-committed))
        else:
            assert after['elapsed']['hex']==state['elapsed']['hex'] and after['rejected']['value']==state['rejected']['value']+1 and after['accepted']['value']==state['accepted']['value']
            row.update(committed_flow_dt_sum_exact=fraction_number(committed),rejected_trial_dt_not_added_to_committed_elapsed=True)
        row['sequential_saved_host_step_sum_of_accepted_trials']=exact_number(host_sequential);ledger.append(row)
    returned=[r for r in records if r['row']['event']=='return'];assert len(returned)==1
    final=returned[0]['actual_host_state'];duration=final['duration']['value'];elapsed=final['elapsed']['value']
    return dict(trials=ledger,accepted_trials=sum(r['accepted'] for r in ledger),rejected_trials=sum(r['rejected'] for r in ledger),final_saved_host_elapsed=exact_number(elapsed),original_host_duration=exact_number(duration),sum_committed_actual_flow_input_durations_exact=fraction_number(committed),final_saved_host_elapsed_minus_committed_flow_input_duration_exact=fraction_number(Fraction.from_float(elapsed)-committed),committed_flow_input_duration_minus_requested_duration_exact=fraction_number(committed-Fraction.from_float(duration)),saved_host_elapsed_equals_requested_duration=final['elapsed']['hex']==final['duration']['hex'],all_accepted_host_additions_match_original_float64_arithmetic=all(r.get('saved_host_elapsed_matches_original_float64_addition',True) for r in ledger),scope='Exact dyadic addition/difference on saved Python float and actual f32 flow-argument snapshots only. Rejected trial durations are excluded. Inner flow solver substep time is not observed; these are actual arguments passed to accepted outer flow calls. No model/evaluate/phase/flow/reference call or new trial/trajectory is performed.')

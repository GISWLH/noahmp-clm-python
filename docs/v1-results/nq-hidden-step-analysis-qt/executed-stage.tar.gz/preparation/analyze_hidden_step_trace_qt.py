"""EHPC posthoc only: sealed actual QS trace, no forward/replay/fixture edits."""
import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path
import socket
import sys
import tarfile
import time
import traceback

from control_analysis_qt import load_controls,compare_controls,audit_time_bookkeeping

HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,d):
    def clean(v):
        if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)):return [clean(x) for x in v]
        if isinstance(v,float) and not math.isfinite(v):return dict(nonfinite_hex=v.hex())
        return v
    Path(p).write_text(json.dumps(clean(d),indent=2,allow_nan=False)+'\n')
def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=t.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        assert len({m.name for m in members})==len(members)
        return {m.name:t.extractfile(m).read() for m in members}
def inventory(files,name='artifact-inventory.json'):
    index=json.loads(files[name]);assert set(index)==set(files)-{name}
    for n,v in index.items():
        assert sha(files[n])==(v['sha256'] if isinstance(v,dict) else v)
        if isinstance(v,dict):assert len(files[n])==v['bytes']


def main():
    parser=argparse.ArgumentParser()
    for n in ('evidence','output'):parser.add_argument('--'+n,type=Path,required=True)
    a=parser.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists();a.output.mkdir()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());controls_raw=(HERE/'CONTROLS_SHA256.json').read_bytes();controls=json.loads(controls_raw)
    assert all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
    raw=a.evidence.read_bytes();assert sha(raw)==binding['QS_evidence_archive_sha256'];evidence=unpack(raw);inventory(evidence)
    stage=unpack(evidence['executed-stage.tar.gz']);assert sha(evidence['executed-stage.tar.gz'])==binding['QS_executed_stage_sha256'];inventory(stage,'stage-inventory.json')
    source_files=unpack(stage['source.tar.gz']);manifest_raw=source_files['SOURCE_SHA256.json'];manifest=json.loads(manifest_raw)
    assert sha(manifest_raw)==binding['source_manifest_sha256'] and len(manifest)==584 and set(source_files)==set(manifest)|{'SOURCE_SHA256.json'}
    assert all(sha(source_files[n])==h for n,h in manifest.items())
    source=a.output/'source'
    for n,b in source_files.items():
        p=source/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    nq=unpack(stage['nq-evidence.tar.gz']);inventory(nq)
    original_packet=nq[binding['original_NQ_packet_path']];assert sha(original_packet)==binding['original_NQ_packet_sha256']
    assert sha(evidence['raw-gpu-result.tar.gz'])==binding['QS_raw_GPU_archive_sha256']
    gpu_files=unpack(evidence['raw-gpu-result.tar.gz'])
    assert {n[len('actual-gpu/'):]:b for n,b in evidence.items() if n.startswith('actual-gpu/')}==gpu_files
    sys.path[:0]=[str(source/'src'),str(source/'tests'),str(source/'benchmarks')]
    import numpy as np
    import test_gpu_clm_richards_column as original
    from noahmp_clm import clm_enthalpy_driver as cpu_driver
    from noahmp_clm.physics import richards as cpu_richards
    forbidden=[]
    def no_forward(*args,**kwargs):forbidden.append('Actual NumPy physical forward attempted');raise AssertionError(forbidden[-1])
    cpu_driver.step_clm_enthalpy_column=no_forward;cpu_richards.redistribute_soil_enthalpy=no_forward
    assert Path(original.audit.__code__.co_filename).resolve()==source/'tests/test_gpu_clm_richards_column.py'
    assert sha((source/'tests/test_gpu_clm_richards_column.py').read_bytes())==binding['original_test_sha256']
    started=time.monotonic();original_audit_calls=[];result={};error=None
    def finite(value):
        value=float(value)
        return value if np.isfinite(value) else dict(nonfinite_hex=value.hex())
    def load_npz(raw):
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:return {n:z[n].copy() for n in z.files}
    def packet(files,stem):
        meta=json.loads(files[stem+'.json']);raw=files[stem+'.npz'];assert sha(raw)==meta['npz_sha256'];arrays=load_npz(raw)
        used=[]
        def check(v):
            if v['kind']=='array':
                q=arrays[v['key']];used.append(v['key']);assert q.dtype.str==v['dtype'] and list(q.shape)==v['shape'] and sha(q.tobytes(order='C'))==v['c_order_sha256']
            elif v['kind'] in ('dict','dataclass'):
                for x in v['items' if v['kind']=='dict' else 'fields'].values():check(x)
            elif v['kind'] in ('list','tuple'):
                for x in v['items']:check(x)
            elif v['kind']=='enum':check(v['value'])
        check(meta['tree']);assert len(used)==len(set(used))==len(arrays)==meta['array_count'] and set(used)==set(arrays)
        return meta['tree'],arrays
    def decode(v,arrays):
        kind=v['kind']
        if kind=='array':return arrays[v['key']]
        if kind=='dict':return {n:decode(x,arrays) for n,x in v['items'].items()}
        if kind in ('tuple','list'):
            values=[decode(x,arrays) for x in v['items']];return tuple(values) if kind=='tuple' else values
        if kind=='float':return float.fromhex(v['hex'])
        if kind in ('NoneType','str','int','bool'):return v['value']
        raise AssertionError('Only aggregate original basic data may be decoded: '+kind)
    def canonical(v,kind,path='value',excluded=None):
        tag=v['kind']
        if tag in ('module-context','callable-context') or (kind=='adapter' and path=='value/backend'):
            excluded.append(dict(path=path,actual=v));return dict(kind='backend-context-excluded')
        if tag=='dict':return dict(kind=tag,items={n:canonical(x,kind,path+'/'+n,excluded) for n,x in v['items'].items()})
        if tag=='dataclass':return dict(kind=tag,module=v['module'],name=v['name'],fields={n:canonical(x,kind,path+'/'+n,excluded) for n,x in v['fields'].items()})
        if tag in ('tuple','list'):return dict(kind=tag,items=[canonical(x,kind,path+'/'+str(i),excluded) for i,x in enumerate(v['items'])])
        if tag=='enum':return dict(kind=tag,module=v['module'],name=v['name'],value=canonical(v['value'],kind,path+'/value',excluded))
        return v
    def array_diff(x,y):
        row=dict(dtype_left=x.dtype.str,dtype_right=y.dtype.str,shape_left=list(x.shape),shape_right=list(y.shape))
        row['dtype_shape_exact']=x.dtype==y.dtype and x.shape==y.shape
        row['opaque_C_bytes_exact']=row['dtype_shape_exact'] and x.tobytes(order='C')==y.tobytes(order='C')
        if not row['dtype_shape_exact']:row['original_same_precision_pass']=False;return row
        if x.dtype.kind in 'biu':row['original_same_precision_pass']=bool(np.array_equal(x,y))
        elif x.dtype.kind in 'fc':row['original_same_precision_pass']=bool(np.allclose(x,y,rtol=1e-6,atol=1e-6))
        else:row['original_same_precision_pass']=row['opaque_C_bytes_exact']
        if x.dtype.kind in 'biufc' and x.size:
            u=x.astype(np.complex128 if x.dtype.kind=='c' else np.float64);v=y.astype(u.dtype);diff=abs(u-v)
            row.update(maximum_absolute_difference=finite(np.max(diff)),maximum_original_tolerance_excess=finite(np.max(diff-(1e-6+1e-6*abs(v)))),left_values=x.tolist(),right_values=y.tolist())
            # Do not replace nonfinite raw values; JSON uses explicit hex representations.
            def safe_values(q):
                if isinstance(q,list):return [safe_values(s) for s in q]
                if isinstance(q,float):return finite(q)
                if isinstance(q,complex):return dict(real=finite(q.real),imag=finite(q.imag))
                return q
            row['left_values']=safe_values(row['left_values']);row['right_values']=safe_values(row['right_values'])
        return row
    def compare_packets(left,right,kind):
        lt,la=left;rt,ra=right;le=[];re=[]
        lc=canonical(lt,kind,excluded=le);rc=canonical(rt,kind,excluded=re)
        scalar_changes=[]
        def nonarray_changes(l,r,path):
            if isinstance(l,dict) and isinstance(r,dict):
                if l.get('kind')==r.get('kind')=='array':return
                for key in sorted(set(l)|set(r)):
                    if key not in l or key not in r:scalar_changes.append(dict(path=path+'/'+key,left_present=key in l,right_present=key in r,left=l.get(key),right=r.get(key)))
                    else:nonarray_changes(l[key],r[key],path+'/'+key)
            elif isinstance(l,list) and isinstance(r,list):
                if len(l)!=len(r):scalar_changes.append(dict(path=path,left=l,right=r))
                else:
                    for i,(x,y) in enumerate(zip(l,r)):nonarray_changes(x,y,path+'/'+str(i))
            elif type(l)is not type(r) or l!=r:scalar_changes.append(dict(path=path,left=l,right=r))
        nonarray_changes(lc,rc,'value')
        fields={n:array_diff(la[n],ra[n]) for n in sorted(set(la)&set(ra))}
        return dict(physical_typed_inputs_or_outputs_byte_exact=lc==rc,excluded_backend_context_left=le,excluded_backend_context_right=re,
                    nonarray_typed_differences=scalar_changes,
                    left_only_array_paths=sorted(set(la)-set(ra)),right_only_array_paths=sorted(set(ra)-set(la)),arrays=fields,
                    differing_array_paths=[n for n,v in fields.items() if not v['opaque_C_bytes_exact']],
                    original_same_precision_failed_array_paths=[n for n,v in fields.items() if not v['original_same_precision_pass']])
    def nested(flat):
        root={}
        for name,value in flat.items():
            parts=name.split('/');parent=root
            for key in parts[:-1]:parent=parent.setdefault(key,{})
            assert parts[-1] not in parent;parent[parts[-1]]=value
        return root
    def ledgers(arrays,r,forcing,deposition,c):
        dtype=arrays[0].dtype;eps=np.finfo(dtype).eps;d=r['diagnostics'];sf=r['surface']
        snow=r['snow_cells'].astype(float);soil=r['soil_cells'].astype(float);oldcan=arrays[5][:,:2].astype(float);newcan=r['storage'].astype(float)[:,:2]
        oldm=arrays[0][:,:,0].astype(float).sum(1)+arrays[1][:,:,0].astype(float).sum(1)+oldcan[:,0];newm=snow[:,:,0].sum(1)+soil[:,:,0].sum(1)+newcan[:,0]
        oldh=arrays[0][:,:,1].astype(float).sum(1)+arrays[1][:,:,1].astype(float).sum(1)+oldcan[:,1];newh=snow[:,:,1].sum(1)+soil[:,:,1].sum(1)+newcan[:,1]
        dt=forcing[:,0].astype(float);precip=c['expected/0/diagnostics/prcp_mm'];ph=c['expected/0/diagnostics/precipitation_enthalpy_jm2']
        atmo=(forcing[:,5].astype(float)+forcing[:,6]-sf['outgoing_shortwave'].astype(float)-sf['outgoing_longwave'].astype(float)-d['h'].astype(float)-d['le'].astype(float))*dt
        et=d['et_mm'].astype(float);runoff=d['runoff_mm'].astype(float);adv=d['advected_enthalpy_jm2'].astype(float);rh=d['runoff_enthalpy_jm2'].astype(float)
        water=newm-oldm-precip+et+runoff;heat=newh-oldh-ph-atmo+adv+rh
        mb=32.*eps*np.maximum(abs(oldm)+abs(newm)+abs(precip)+abs(et)+abs(runoff),1.)
        scale=abs(arrays[0][:,:,1].astype(float)).sum(1)+abs(arrays[1][:,:,1].astype(float)).sum(1)+abs(oldcan[:,1])+abs(snow[:,:,1]).sum(1)+abs(soil[:,:,1]).sum(1)+abs(newcan[:,1])
        hb=sf['thermal_layer_tolerance'].astype(float).sum(1)+dt*abs(sf['layer_residual'].astype(float)).sum(1)+32.*eps*np.maximum(scale+abs(ph)+abs(atmo)+abs(adv)+abs(rh),1.)+1e-5
        tracer=snow[:,:,4:].sum(1)-arrays[0][:,:,4:].astype(float).sum(1)-deposition.astype(float)*dt[:,None]+r['impurity_output_kgm2'].astype(float)
        tb=64.*eps*np.maximum(arrays[0][:,:,4:].astype(float).sum(1)+deposition.astype(float)*dt[:,None],1e-20)
        return dict(water_residual=water.tolist(),water_bound=mb.tolist(),heat_residual=heat.tolist(),heat_bound=hb.tolist(),impurity_residual=tracer.tolist(),impurity_bound=tb.tolist(),CN='not applicable to original aggregate case')
    try:
        with np.load(io.BytesIO(source_files['tests/fixtures/clm_richards_reference.npz']),allow_pickle=False) as z:c={n[len('32/1/'):]:z[n].copy() for n in z.files if n.startswith('32/1/')}
        gold=load_npz(original_packet);backends={};audits={};transparency={}
        for backend in ('cuda','jax'):
            prefix='actual-gpu/'+backend+'/device/';receipt=json.loads(evidence[prefix+'capture-receipt.json'])
            assert receipt['source584_exact'] and receipt['controls_exact'] and receipt['inputs_unchanged'] and receipt['all126_same_backend_byte_exact']
            assert receipt['actual_aggregate_calls']==dict(started=1,returned=1) and not receipt['observation_limit_reached'] and not receipt['logging_errors'] and not receipt['original_observed_exceptions'] and not receipt['forbidden_attempts']
            assert receipt['NumPy_physical_forward_calls']==receipt['extra_phase_or_reference_replays']==0
            assert sha(evidence[prefix+'events.tar'])==receipt['events_tar_sha256'] and sha(evidence[prefix+'events.jsonl'])==receipt['events_jsonl_sha256']
            expected_counts=dict(adapter=1,phase=4,profile=3,redistribute=3)
            assert set(receipt['observed_original_call_counts'])==set(expected_counts)
            assert all(receipt['observed_original_call_counts'][kind]==dict(entered=count,actual_original_started=count,actual_original_returned=count,actual_original_raised=0) for kind,count in expected_counts.items())
            tape=unpack(evidence[prefix+'events.tar']);rows=[json.loads(s) for s in evidence[prefix+'events.jsonl'].decode().splitlines()];stack=[];schedule=[];ordinals={};entries={}
            for row in rows:
                assert row['stage'] in ('enter','return') and row['backend']==backend
                if row['stage']=='enter':
                    ordinals[row['kind']]=ordinals.get(row['kind'],0)+1;assert row['ordinal']==ordinals[row['kind']]
                    assert row['sequence']==len(schedule)+1 and row['parent']==(stack[-1] if stack else None);stack.append(row['sequence']);entry={n:row[n] for n in ('sequence','parent','kind','ordinal')};schedule.append(entry);entries[row['sequence']]=entry
                else:
                    assert stack.pop()==row['sequence'] and {n:row[n] for n in ('sequence','parent','kind','ordinal')}==entries[row['sequence']]
            assert not stack and len(schedule)==receipt['events'] and len(rows)==2*len(schedule)
            events={r['sequence']:dict(input=packet(tape,'events/'+str(r['sequence']).zfill(6)+'-input'),output=packet(tape,'events/'+str(r['sequence']).zfill(6)+'-output')) for r in schedule}
            control_data=load_controls(evidence,prefix,tape,source_files,binding,packet)
            actual=packet(tape,'original-aggregate-call');call=decode(*actual)
            assert call['kind']=='aggregate' and call['backend']==backend+'32'
            arrays=call['arrays'];forcing=call['forcing'];deposition=call['deposition']
            for i,x in enumerate(arrays):assert x.dtype==c['initial/'+str(i)].dtype and x.shape==c['initial/'+str(i)].shape and x.tobytes()==c['initial/'+str(i)].tobytes()
            for n,x in [('forcing',forcing),('deposition',deposition)]:assert x.dtype==c[n][0].dtype and x.shape==c[n][0].shape and x.tobytes()==c[n][0].tobytes()
            if call['geometry'] is not None:assert call['geometry'].dtype==c['geometry'].dtype and call['geometry'].shape==c['geometry'].shape and call['geometry'].tobytes()==c['geometry'].tobytes()
            final=load_npz(evidence[prefix+'complete-final126.npz']);meta=json.loads(evidence[prefix+'complete-final126.json']);assert sha(evidence[prefix+'complete-final126.npz'])==meta['npz_sha256'] and len(final)==126
            old={n[len(backend)+1:]:q for n,q in gold.items() if n.startswith(backend+'/')};assert set(final)==set(old)
            transparency[backend]={n:bool(final[n].dtype==old[n].dtype and final[n].shape==old[n].shape and final[n].tobytes()==old[n].tobytes()) for n in final};assert all(transparency[backend].values())
            r=nested(final);audit=dict(complete_original_ledger_values=ledgers(arrays,r,forcing,deposition,c),original_hard_audit_pass=False)
            try:
                original_audit_calls.append(backend);audit['original_audit_return']=original.audit(arrays,r,forcing,deposition,c,'expected/0/','aggregate');audit['original_hard_audit_pass']=True
            except AssertionError:audit['original_audit_failure']=traceback.format_exc()
            audits[backend]=audit;backends[backend]=dict(schedule=schedule,events=events,final=final,control=control_data)
        left,right=backends['cuda'],backends['jax']
        control_comparison=compare_controls(left['control'],right['control'],compare_packets)
        time_bookkeeping={backend:audit_time_bookkeeping(value['control'],value) for backend,value in backends.items()}
        common=[];schedule_divergence=None
        for i in range(max(len(left['schedule']),len(right['schedule']))):
            l=left['schedule'][i] if i<len(left['schedule']) else None;r=right['schedule'][i] if i<len(right['schedule']) else None
            if l!=r:schedule_divergence=dict(index=i,cuda=l,jax=r);break
            common.append(l)
        comparisons=[];first_entry=None;first_operator=None
        for row in common:
            seq=row['sequence'];x=left['events'][seq];y=right['events'][seq]
            entry=compare_packets(x['input'],y['input'],row['kind']);returned=compare_packets(x['output'],y['output'],row['kind']);record=dict(**row,input=entry,output=returned);comparisons.append(record)
            if first_entry is None and not entry['physical_typed_inputs_or_outputs_byte_exact']:first_entry={n:row[n] for n in row}
            if first_operator is None and entry['physical_typed_inputs_or_outputs_byte_exact'] and not returned['physical_typed_inputs_or_outputs_byte_exact']:first_operator={n:row[n] for n in row}
        final_comparison={n:array_diff(left['final'][n],right['final'][n]) for n in sorted(left['final'])};failed=[n for n,v in final_comparison.items() if not v['original_same_precision_pass']]
        assert len(original_audit_calls)==2 and not forbidden
        result=dict(scope='Sealed original QS captures only; zero model/phase/reference replay',source_manifest_sha256=sha(manifest_raw),QS_raw_GPU_archive_sha256=binding['QS_raw_GPU_archive_sha256'],
                    original_test_and_all584_source_exact=True,original_audit_calls=original_audit_calls,original_independent_hard_audits=audits,all126_same_backend_byte_transparency=transparency,
                    complete_original_event_schedules={b:v['schedule'] for b,v in backends.items()},schedule_common_prefix_events=len(common),first_schedule_divergence=schedule_divergence,
                    first_differing_physical_entry=first_entry,first_identical_physical_input_different_output=first_operator,common_prefix_event_comparisons=comparisons,
                    original_same_precision=dict(rtol=1e-6,atol=1e-6,integer_exact=True,fields=final_comparison,failed_fields=failed,passed=not failed),
                    control_assignment_age_and_values=control_comparison,saved_host_vs_actual_f32_flow_time=time_bookkeeping,control_capture_analysis_completed=True,original_NQ399_of408_and9failed_records_retained=True,diagnostic_conclusive=schedule_divergence is None and len(common)==11 and all(v['original_hard_audit_pass'] for v in audits.values()),
                    interpretation='First hidden difference is reported from sealed actual locals with explicit assignment age and native-call binding. Host step/elapsed and actual f32 flow dt are separate, including exact accepted-duration sums; rejected trials are excluded. Native array/control comparisons alone do not identify a generated divider or prove a repair. Context exclusions are explicit backend selector/module/callback only. No original tolerance, diagnostic or result field is altered.')
        save(a.output/'analysis.json',result)
    except BaseException:error=traceback.format_exc();(a.output/'failure.txt').write_text(error)
    finally:
        source_exact=all(sha((source/n).read_bytes())==h for n,h in manifest.items());controls_exact=all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
        save(a.output/'receipt.json',dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),source584_exact=source_exact,controls_exact=controls_exact,controls_manifest_sha256=sha(controls_raw),evidence_exact=sha(a.evidence.read_bytes())==binding['QS_evidence_archive_sha256'],NumPy_physical_forward_calls=0,GPU_calls=0,extra_phase_or_reference_replays=0,forbidden_attempts=forbidden,actual_original_audit_calls=original_audit_calls,error=error,seconds=time.monotonic()-started,
                                         diagnostic_conclusive=result.get('diagnostic_conclusive',False),original_same_precision_pass=result.get('original_same_precision',{}).get('passed',False),control_capture_analysis_completed=result.get('control_capture_analysis_completed',False),time_bookkeeping_analysis_completed='saved_host_vs_actual_f32_flow_time' in result))
        assert source_exact and controls_exact and not forbidden
    # The diagnostic may be complete while the original1e-6 gate is still red.
    # Preserve that actual original failure as worker/PBS1, never normalize it.
    return 0 if not error and result.get('diagnostic_conclusive') and result['original_same_precision']['passed'] else 1


if __name__=='__main__':raise SystemExit(main())

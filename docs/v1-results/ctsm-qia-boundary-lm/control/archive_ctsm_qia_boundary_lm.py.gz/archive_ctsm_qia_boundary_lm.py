from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
archive = b / 'ctsm-qia-boundary-lm-evidence.tar.gz'
assert not archive.exists()
cases, audits = [], []
with tarfile.open(archive, 'w:gz') as t:
    for letter in ['l', 'm']:
        r = b / ('ctsm-qia-run-' + letter)
        d = json.loads((r / 'configuration.json').read_text())
        assert (r / 'pbs-exit.txt').read_text().strip() == '0' and d['official_model_returncode'] == 0
        assert all(s['returncode'] == 0 for s in d['stages']) and d['upstream_original_bytes_unchanged']
        for p in sorted(r.iterdir()):
            if p.is_file() and p.name != 'case-configuration-private.tar.gz':
                t.add(p, arcname=r.name + '/' + p.name, recursive=False)
        samples, indices = 0, []
        private = r / 'case-configuration-private.tar.gz'
        with tarfile.open(private) as original:
            for m in original:
                if m.isfile() and (m.name.endswith(('.stdout.txt', '.stderr.txt', '-adaptation.json', '.stream')) or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in', 'drv_in', 'lnd_in'])) or m.name.startswith('case/user_nl_')):
                    data = original.extractfile(m).read()
                    info = tarfile.TarInfo(r.name + '/workspace/' + m.name)
                    info.size = len(data)
                    t.addfile(info, io.BytesIO(data))
                    if 'lnd.log.' in m.name:
                        text = data.decode(errors='replace')
                        samples += text.count('Writing current time sample')
                        indices.extend(map(int, re.findall(r'clm: completed timestep\s+(\d+)', text)))
        assert samples == 49 and max(indices) == 48
        cases.append(dict(case=r.name, pbs_job=d['pbs_job'], node=d['node'], seconds=d['seconds'], model_and_pbs_returncode=0,
                          upstream_original_bytes_unchanged=True, written_history_samples=samples, last_nstep=max(indices),
                          configuration_sha256=sha(r / 'configuration.json'), private_workspace_sha256=sha(private)))
    for name in ['ctsm-qia-phase-probe-a', 'ctsm-qia-boundary-l', 'ctsm-qia-boundary-l-c', 'ctsm-qia-boundary-m-c', 'ctsm-qia-forcing-phase-a', 'ctsm-qia-forcing-phase-b', 'ctsm-land-radiation-contract-c']:
        r = b / name
        if (r / 'receipt.json').exists():
            receipt = json.loads((r / 'receipt.json').read_text())
            assert (r / 'pbs-exit.txt').read_text().strip() == '0' and all(s['returncode'] == 0 for s in receipt['stages'])
            assert sha(r / 'boundary.json') == receipt['boundary_sha256']
            raw = r / ('raw-selected-fields.npz')
            assert sha(raw) == receipt['raw_fields_sha256']
            assert sha(r / 'official-first48.npz') == receipt['positive48_sha256']
            audits.append(dict(root=name, receipt=receipt, boundary=json.loads((r / 'boundary.json').read_text())))
        if name == 'ctsm-qia-phase-probe-a':
            assert (r / 'pbs-exit.txt').read_text().strip() == '0'
            phase = json.loads((r / 'probe.json').read_text())
            assert all(phase['fields'][n]['reference_index_shift_diagnostics']['-1']['exact_at_history_dtype'] for n in ['TBOT', 'QBOT', 'WIND', 'FSDS', 'FLDS', 'PBOT'])
        for p in sorted(r.iterdir()):
            if p.is_file():
                t.add(p, arcname=name + '/' + p.name, recursive=False)
    for name in ['inspect_ctsm_qia_forcing_phase_a.py', 'inspect_ctsm_qia_forcing_phase_b.py', 'inspect_ctsm_land_radiation_contract_c.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
    summary = dict(scope='Actual pinned official K phase diagnosis, L upper-only meteorology experiment and M common original-Erbs direct/diffuse experiment. Source2930 bytes and original native/meteorology data unchanged. Land positive48 bins, scalar inputs/PCO2/four solar bands verified from actual output; ha2x solar history has a distinct driver recording phase and is never substituted for land forcing. Raw differences/history-dtype checks retained, not soil/cold-state/SP-CN/scientific acceptance.', cases=cases, audits=audits,
                   history_scope='B inspector retained as original diagnostic; C adds actual registered land-band fields and uses float64 means. No original result edited.',
                   fpsn_source_scope='Pinned PhotosynthesisMod psn_z=ag, an=ag-lmr, canopy psnsun*laisun+psnsha*laisha shows FPSN is gross assimilation, not An or NEE. Read-only contract; no Fortran copied into Python physical code.')
    data = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(data)
    t.addfile(info, io.BytesIO(data))
print(json.dumps(dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size, cases=cases)))

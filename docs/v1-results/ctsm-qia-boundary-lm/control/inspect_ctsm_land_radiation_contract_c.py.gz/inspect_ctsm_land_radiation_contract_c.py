from pathlib import Path
import hashlib
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-land-radiation-contract-c'
r.mkdir(exist_ok=False)
archive = b / 'ctsm-reference-source-bundle-a.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
rows = []
with tarfile.open(archive) as t:
    for m in t:
        if not m.isfile() or not m.name.endswith('.F90'):
            continue
        raw = t.extractfile(m).read()
        lines = raw.decode(errors='replace').splitlines()
        hits = []
        for i, line in enumerate(lines):
            if re.search(r"fname\s*=\s*['\"](?:FSDS|FSD[0-9]|FSR)", line, re.I) or ('atm2lndMod.F90' in m.name and any(s in line.lower() for s in ['forc_solad', 'forc_solai'])):
                lo, hi = max(0, i-3), min(len(lines), i+7)
                hits.append(dict(first=lo+1, last=hi, lines=[str(j+1)+':'+lines[j] for j in range(lo, hi)]))
        if hits:
            rows.append(dict(source=m.name, source_sha256=hashlib.sha256(raw).hexdigest(), hits=hits))
d = dict(scope='Read-only pinned source solar history registration and land import contract. No upstream/physics mutation or acceptance.', records=rows)
(r / 'contract.json').write_text(json.dumps(d, indent=2) + '\n')
print(json.dumps(d))

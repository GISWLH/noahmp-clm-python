from pathlib import Path
import hashlib,json,re,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-forcing-phase-a';r.mkdir(exist_ok=False);archive=b/'ctsm-reference-source-bundle-a.tar.gz';sha=lambda data:hashlib.sha256(data).hexdigest();assert sha(archive.read_bytes())=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6';rows=[];index=[]
with tarfile.open(archive) as t:
 for m in t:
  if not m.isfile() or not m.name.endswith('.F90'):continue
  if any(v in m.name.lower() for v in ['atm2lnd','clm_comp','clm_driver','datm_comp','shr_dmodel','shr_stream']):index.append(m.name)
  raw=t.extractfile(m).read();text=raw.decode(errors='replace');lines=text.splitlines();hits=[]
  for i,line in enumerate(lines):
   kinds=[]
   if m.name.startswith('CTSM/src/') and re.search(r"fname\s*=\s*['\"](?:TBOT|FSDS|PCO2)['\"]",line,re.I):kinds.append('history-registration')
   if m.name.startswith('CTSM/src/') and any(x in line.lower() for x in ['call hist_update_hbuf','call hist_htapes_wrapup','call clm_drv','call clm_import']):kinds.append('land-call-order')
   if m.name.endswith('shr_stream_mod.F90') and 'strm%offset' in line.lower():kinds.append('stream-offset')
   if m.name.endswith('shr_dmodel_mod.F90') and any(x in line for x in ['strm_swdndr','strm_swdndf','iradsw','swdndr','swdndf']):kinds.append('datm-shortwave')
   if m.name.endswith('datm_comp_mod.F90') and 'call shr_strdata_advance' in line.lower():kinds.append('datm-advance')
   if m.name.endswith('PhotosynthesisMod.F90') and re.search(r'fpsn\s*\(p\)\s*=',line,re.I):kinds.append('photosynthesis-output')
   if kinds:hits.append(dict(line=i+1,kinds=kinds,context=[str(k+1)+':'+lines[k] for k in range(max(0,i-5),min(len(lines),i+9))]))
  if hits:rows.append(dict(source=m.name,source_sha256=sha(raw),hits=hits))
d=dict(scope='Read-only pinned upstream forcing/history/offset/shortwave contract after observed official input mismatch; no source or physics mutation and no scientific acceptance.',source_bundle_sha256=sha(archive.read_bytes()),candidate_files=index,records=rows);(r/'contract.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate_files=index,records=[dict(source=x['source'],hits=[dict(line=h['line'],kinds=h['kinds']) for h in x['hits']]) for x in rows])))

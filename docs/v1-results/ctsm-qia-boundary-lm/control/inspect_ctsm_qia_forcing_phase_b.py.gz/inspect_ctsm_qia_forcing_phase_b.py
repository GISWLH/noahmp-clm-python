from pathlib import Path
import hashlib,json,re,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-forcing-phase-b';r.mkdir(exist_ok=False);rows=[]
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 for m in t:
  if not m.isfile() or not m.name.endswith('.F90'):continue
  raw=t.extractfile(m).read();lines=raw.decode(errors='replace').splitlines();ranges=[]
  if m.name=='CTSM/src/cpl/lnd_comp_mct.F90':ranges.append((370,465,'land-import-run-order'))
  for i,line in enumerate(lines):
   text=line.lower();kind=None
   if 'datm' in m.name and any(k in text for k in ['strm_swdndr','strm_swdndf','if (iradsw','if(iradsw','case (iradsw','shr_dmodel']) and not m.name.endswith('datm_comp_mod.F90'):kind='shortwave'
   if m.name.endswith('datm_comp_mod.F90') and (any(k in text for k in ['strm_swdndr','strm_swdndf','if (iradsw','if(iradsw','call shr_dmodel']) or 'case (iradsw' in text):kind='shortwave'
   if m.name.endswith('atm2lndMod.F90') and 'forc_solar' in text:kind='land-solar-assignment'
   if m.name.endswith('PhotosynthesisMod.F90') and (re.search(r'\ban\s*=.*psn',text) or re.search(r'\bpsn\s*\(.*\)\s*=',text) or 'psnsun(p) = ' in text):kind='gross-net-photosynthesis'
   if m.name.endswith('shr_strdata_mod.F90') and any(k in text for k in ['case ("nearest")',"case ('nearest')",'case ("coszen")',"case ('coszen')"]):kind='interpolation-policy'
   if kind:ranges.append((max(1,i-7),min(len(lines),i+16),kind))
  if ranges:rows.append(dict(source=m.name,source_sha256=hashlib.sha256(raw).hexdigest(),ranges=[dict(first=a,last=z,kind=k,lines=[str(i+1)+':'+lines[i] for i in range(a-1,z)]) for a,z,k in ranges]))
d=dict(scope='Read-only pinned source field/driver-phase/shortwave/assimilation contract,not copied implementation or a modified model.',records=rows);(r/'contract.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps([dict(source=x['source'],ranges=[dict(first=v['first'],last=v['last'],kind=v['kind']) for v in x['ranges']]) for x in rows]))

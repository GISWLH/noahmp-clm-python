from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time

assert os.environ.get('PBS_JOBID')
letter = sys.argv[1]
assert letter in ['l', 'm']
b = Path('/home/zhangyq/noahmp-v1')
r = b / ('ctsm-qia-boundary-' + letter + '-c')
case = b / ('ctsm-qia-run-' + letter)
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
prefix, workspace = scratch / 'toolchain', scratch / 'workspace'
prefix.mkdir()
workspace.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start = time.monotonic()
config = json.loads((case / 'configuration.json').read_text())
assert config['official_model_returncode'] == 0 and config['upstream_original_bytes_unchanged']
assert all(s['returncode'] == 0 for s in config['stages']) and (case / 'pbs-exit.txt').read_text().strip() == '0'
a = b / 'ctsm-portable-env-b.tar.gz'
assert sha(a) == '6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(a) as t:
    t.extractall(prefix, filter='data')
private = case / 'case-configuration-private.tar.gz'
private_sha = sha(private)
with tarfile.open(private) as t:
    members = [m for m in t if m.isfile() and (m.name.startswith('output/case/run/') and m.name.endswith('.nc') or m.name == 'inputdata/CN-Qia.datm.2003.nc')]
    t.extractall(workspace, members=members, filter='data')
for name, metadata in config['model_outputs'].items():
    if name.endswith('.nc'):
        assert sha(workspace / 'output/case/run' / name) == metadata['sha256']
if letter == 'l':
    point = json.loads((b / 'ctsm-qia-point-inputs-b/derivation.json').read_text())
    assert sha(workspace / 'inputdata/CN-Qia.datm.2003.nc') == point['files']['CN-Qia.datm.2003.nc']['sha256']
else:
    assert sha(workspace / 'inputdata/CN-Qia.datm.2003.nc') == config['common_radiation_derivation']['derived_met_sha256']
env = os.environ.copy()
env.pop('PYTHONPATH', None)
env.update(PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
stages = []
for name, cmd in [('relocate', [str(prefix / 'bin/python'), str(prefix / 'bin/conda-unpack')]), ('inspect', [str(prefix / 'bin/python'), str(r / 'inspect_ctsm_qia_runtime_boundary_c.py'), str(workspace), str(r), letter])]:
    p = subprocess.run(cmd, cwd=scratch, env=env, capture_output=True, text=True, timeout=180)
    (r / (name + '.stdout.txt')).write_text(p.stdout)
    (r / (name + '.stderr.txt')).write_text(p.stderr)
    stages.append(dict(stage=name, returncode=p.returncode))
    assert p.returncode == 0, p.stderr
receipt = dict(scope='Actual official model/PBS0 and output NC hashes verified, then boundary diagnostic only on EHPC compute node. No scientific acceptance.',
               pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, seconds=time.monotonic() - start,
               official_case=case.name, official_configuration_sha256=sha(case / 'configuration.json'),
               official_private_sha256=private_sha, upstream_original_bytes_unchanged=True, stages=stages,
               boundary_sha256=sha(r / 'boundary.json'), raw_fields_sha256=sha(r / 'raw-selected-fields.npz'), positive48_sha256=sha(r / 'official-first48.npz'))
(r / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)

from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'inspect_ctsm_qia_runtime_boundary_b.py').read_text()
p = p.replace("'SWDNDIR_COMMON', 'SWDNDF_COMMON'}", "'SWDNDIR_COMMON', 'SWDNDF_COMMON', 'FSDSND', 'FSDSNI', 'FSDSVD', 'FSDSVI'}")
p = p.replace('actual_mean=float(a.mean())', 'actual_mean=float(a.astype(float).mean())')
marker = "np.savez_compressed(root / 'raw-selected-fields.npz', **arrays)"
assert p.count(marker) == 1
addition = '''land_bands = {n: fields[n].reshape(48).astype(float) for n in ['FSDSND', 'FSDSNI', 'FSDSVD', 'FSDSVI']}
land_total = sum(land_bands.values())
compare('land_four_band_total_Wm2', land_total, forcing[:, 5])
for name, fraction_expected in [('FSDSND', .5 * (1 - environment[:, 2])), ('FSDSVD', .5 * (1 - environment[:, 2])), ('FSDSNI', .5 * environment[:, 2]), ('FSDSVI', .5 * environment[:, 2])]:
    compare(name + '_common_reference_Wm2', fields[name], forcing[:, 5] * fraction_expected)
land_fraction = np.divide(land_bands['FSDSNI'] + land_bands['FSDSVI'], land_total, out=np.zeros(48), where=land_total > 0)
land_radiation = dict(daylight_intervals=int(day.sum()), native_diffuse_fraction_mean=float(environment[day, 2].mean()),
                      official_land_diffuse_fraction_mean=float(land_fraction[day].mean()),
                      maximum_daylight_fraction_difference=float(abs(land_fraction[day] - environment[day, 2]).max()),
                      maximum_total_SW_difference_Wm2=float(abs(land_total - forcing[:, 5]).max()),
                      scope='Land FSDSND/NI/VD/VI actual positive48 physical bins; driver ha2x is a separate recording phase and its same-bin comparison is diagnostic only, never the forcing acceptance basis.')
'''
p = p.replace(marker, addition + marker)
p = p.replace('input_field_differences=metrics, radiation_split=radiation,', 'input_field_differences=metrics, radiation_split=radiation, land_radiation_split=land_radiation,')
ast.parse(p)
(r / 'inspect_ctsm_qia_runtime_boundary_c.py').write_bytes(p.encode())
p = (r / 'run_ctsm_qia_boundary_b.py').read_text().replace("r = b / ('ctsm-qia-boundary-' + letter)", "r = b / ('ctsm-qia-boundary-' + letter + '-c')").replace('inspect_ctsm_qia_runtime_boundary_b.py', 'inspect_ctsm_qia_runtime_boundary_c.py')
ast.parse(p)
(r / 'run_ctsm_qia_boundary_c.py').write_bytes(p.encode())
for letter in ['l', 'm']:
    p = (r / f'ctsm_qia_boundary_{letter}.pbs').read_text().replace('ctsm-qia-boundary-' + letter, 'ctsm-qia-boundary-' + letter + '-c').replace('clm-qia-boundary-' + letter, 'clm-qia-boundary-' + letter + '-c').replace('run_ctsm_qia_boundary_b.py', 'run_ctsm_qia_boundary_c.py')
    (r / f'ctsm_qia_boundary_{letter}_c.pbs').write_bytes(p.encode())

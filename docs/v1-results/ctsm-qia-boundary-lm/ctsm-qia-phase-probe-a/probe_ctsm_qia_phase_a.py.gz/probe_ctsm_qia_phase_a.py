from pathlib import Path
import hashlib,json,os
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-phase-probe-a';base=b/'ctsm-qia-output-inspection-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();schema=json.loads((base/'schema.json').read_text());receipt=json.loads((base/'receipt.json').read_text());assert sha(base/'schema.json')==receipt['schema_sha256'] and sha(base/'extracted-reference-fields.npz')==receipt['extracted_fields_sha256']
with np.load(base/'extracted-reference-fields.npz',allow_pickle=False) as z:data=dict(z)
files=schema['files'];hist=[f for f in files if '.clm2.h0.' in f['file']]
with np.load(b/'qia-stem-inputs-a/inputs/CN-Qia.npz',allow_pickle=False) as z:forcing=np.asarray(z['forcing'][:49],float)
rows={}
for name in ['TBOT','QBOT','WIND','ZBOT','FSDS','FLDS','PBOT']:
 whole=np.concatenate([data[f['array_keys'][name]].reshape(-1) for f in hist]);assert whole.shape==(49,);actual=whole[1:];reference=forcing[:,4] if name=='PBOT' else data[files[0]['array_keys'][name]].reshape(-1);assert reference.shape==(49,)
 result={}
 for shift in [-2,-1,0,1]:
  selected=reference[np.clip(np.arange(48)+shift,0,48)];difference=actual-selected;result[str(shift)]=dict(max_absolute=float(abs(difference).max()),mean_difference=float(difference.mean()),rms_difference=float(np.sqrt(np.mean(difference**2))),exact_at_history_dtype=bool(np.array_equal(actual,selected.astype(actual.dtype))),history_dtype=str(actual.dtype))
 rows[name]=dict(first8_history_positive_bins=actual[:8].tolist(),first9_input=reference[:9].tolist(),last3_history_positive_bins=actual[-3:].tolist(),last4_input=reference[-4:].tolist(),reference_index_shift_diagnostics=result,startup_record=float(whole[0]))
d=dict(scope='Read-only official K forcing-phase counterfactual diagnostics on EHPC compute node. Report fixed input-index offsets[-2,-1,0,+1] with endpoint holding for diagnosis only; no time axis/source/field changed or offset selected as a physical validation. Raw and quantization-aware numerical differences both retained.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,original_schema_sha256=sha(base/'schema.json'),original_fields_sha256=sha(base/'extracted-reference-fields.npz'),fields=rows)
(r/'probe.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

"""Read actual official output on a PBS node; never shift physical bins."""
from pathlib import Path
import hashlib
import json
import os
import sys

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
workspace, root, letter = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
base = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
run = workspace / 'output/case/run'
input_root = base / 'qia-stem-inputs-a/inputs'
protocol = json.loads((input_root.parent / 'protocol.json').read_text())
assert all(sha(input_root / n) == v for n, v in protocol['inputs_sha256'].items())
with np.load(input_root / 'CN-Qia.npz', allow_pickle=False) as z:
    forcing = np.asarray(z['forcing'][:48], float)
    environment = np.asarray(z['environment'][:48], float)

arrays, files = {}, []
wanted = {'time', 'time_bounds', 'time_bnds', 'TBOT', 'QBOT', 'WIND', 'ZBOT', 'PBOT', 'PSRF', 'PCO2', 'CO2_PPM_AUXILIARY', 'PRECTmms', 'FSDS', 'FLDS', 'RAIN', 'SNOW', 'H2OSNO', 'TSOI', 'H2OSOI', 'FPSN', 'FSH', 'EFLX_LH_TOT', 'FCEV', 'FCTR', 'FGEV', 'QOVER', 'QDRAI', 'TLAI', 'TSAI', 'ELAI', 'FGR', 'FSA', 'FIRA', 'TG', 'levgrnd', 'levsoi', 'DZSOI', 'ZSOI', 'SWDNDIR_COMMON', 'SWDNDF_COMMON'}
for index, path in enumerate([workspace / 'inputdata/CN-Qia.datm.2003.nc', *sorted(run.glob('*.nc'))]):
    with Dataset(path) as d:
        row = dict(file=path.relative_to(workspace).as_posix(), sha256=sha(path), bytes=path.stat().st_size,
                   dimensions={n: len(v) for n, v in d.dimensions.items()},
                   variables={n: dict(dimensions=v.dimensions, units=getattr(v, 'units', None), long_name=getattr(v, 'long_name', None)) for n, v in d.variables.items()}, array_keys={})
        if 'time' in d.variables:
            row['time_units'] = getattr(d['time'], 'units', None)
            row['time_calendar'] = getattr(d['time'], 'calendar', 'standard')
        for name, v in d.variables.items():
            if name in wanted or name.startswith('a2x_Faxa_sw') or name == 'a2x_ax_Sa_co2diag':
                value = np.ma.asarray(v[:])
                assert not np.any(np.ma.getmaskarray(value)), (path.name, name)
                value = np.asarray(value)
                if index == 0 and v.dimensions and v.dimensions[0] == 'time':
                    value = value[:49]
                key = f'f{index}_{name}'
                arrays[key] = value
                row['array_keys'][name] = key
        files.append(row)

def array(file, name):
    return arrays[file['array_keys'][name]]

epoch = files[0]['time_units'].split(' since ', 1)[1]

def seconds(file, values):
    unit, origin = file['time_units'].split(' since ', 1)
    assert origin == epoch and unit in ['hours', 'days']
    return np.asarray(values, float) * (3600. if unit == 'hours' else 86400.)

expected = np.arange(48)[:, None] * 1800 + np.array([[0, 1800]])
assert np.array_equal(seconds(files[0], array(files[0], 'time_bounds')[:48]), expected)
bounds, parts, time_errors = [], {}, []
for file in [f for f in files if '.clm2.h0.' in f['file']]:
    raw = seconds(file, array(file, 'time_bounds'))
    time_errors.append(float(np.max(abs(raw - np.rint(raw)))))
    assert time_errors[-1] <= .01
    bounds.append(np.rint(raw).astype(np.int64))
    for name in file['array_keys']:
        if name not in ['time', 'time_bounds'] and file['variables'][name]['dimensions'][0] == 'time':
            parts.setdefault(name, []).append(array(file, name).reshape(len(raw), -1))
allbounds = np.concatenate(bounds)
order = np.argsort(allbounds[:, 0], kind='stable')
allbounds = allbounds[order]
valid = (allbounds[:, 0] >= 0) & (allbounds[:, 1] <= 86400)
assert len(allbounds) == 49 and valid.sum() == 48
assert np.array_equal(allbounds[valid], expected)
assert np.array_equal(allbounds[~valid], [[-1800, 0]])
fields = {n: np.concatenate(p)[order][valid] for n, p in parts.items()}
metrics = {}

def compare(name, actual, reference):
    a, v = np.asarray(actual).reshape(48), np.asarray(reference, float).reshape(48)
    assert np.all(np.isfinite(a)) and np.all(np.isfinite(v))
    delta = a.astype(float) - v
    metrics[name] = dict(max_absolute=float(abs(delta).max()), mean_bias=float(delta.mean()),
                         actual_mean=float(a.mean()), original_mean=float(v.mean()),
                         history_dtype=str(a.dtype), exact_at_history_dtype=bool(np.array_equal(a, v.astype(a.dtype))))

for name, column in [('TBOT', 1), ('QBOT', 2), ('WIND', 3), ('PBOT', 4), ('FSDS', 5), ('FLDS', 6)]:
    compare(name, fields[name], forcing[:, column])
compare('ZBOT', fields['ZBOT'], array(files[0], 'ZBOT')[:48])
compare('RAIN_plus_SNOW_mm_s', fields['RAIN'] + fields['SNOW'], forcing[:, 7] * 1000.)
compare('PCO2_Pa', fields['PCO2'], forcing[:, 4] * environment[:, 0] * 1.e-6)
co2_ppm = fields['PCO2'].reshape(48).astype(float) / fields['PBOT'].reshape(48).astype(float) * 1.e6
compare('CO2_derived_ppm', co2_ppm, environment[:, 0])
coupler = next(f for f in files if '.cpl.ha2x.' in f['file'])
cb = seconds(coupler, array(coupler, 'time_bnds'))
assert np.max(abs(cb - np.rint(cb))) <= .01 and np.array_equal(np.rint(cb).astype(np.int64), expected)
shortwave = {n: array(coupler, n).reshape(48) for n in coupler['array_keys'] if n.startswith('a2x_Faxa_sw')}
assert len(shortwave) == 4
total = sum(shortwave.values())
compare('coupler_total_SW_Wm2', total, forcing[:, 5])
diffuse = shortwave['a2x_Faxa_swndf'] + shortwave['a2x_Faxa_swvdf']
fraction = np.divide(diffuse, total, out=np.zeros(48), where=total > 0)
day = forcing[:, 5] > 1
radiation = dict(daylight_intervals=int(day.sum()), native_diffuse_fraction_mean=float(environment[day, 2].mean()),
                 official_diffuse_fraction_mean=float(fraction[day].mean()),
                 maximum_daylight_fraction_difference=float(abs(fraction[day] - environment[day, 2]).max()))
for name, fraction_expected in [('a2x_Faxa_swndr', .5 * (1 - environment[:, 2])), ('a2x_Faxa_swvdr', .5 * (1 - environment[:, 2])), ('a2x_Faxa_swndf', .5 * environment[:, 2]), ('a2x_Faxa_swvdf', .5 * environment[:, 2])]:
    compare(name + '_common_reference_Wm2', shortwave[name], forcing[:, 5] * fraction_expected)
np.savez_compressed(root / 'raw-selected-fields.npz', **arrays)
np.savez_compressed(root / 'official-first48.npz', **fields, **shortwave, time_bounds_seconds=expected, co2_derived_ppm=co2_ppm, official_diffuse_fraction=fraction)
record = dict(scope='Read-only actual official input-boundary diagnostic on EHPC PBS compute node. Keep original48 CF bins; exclude only startup[-1800,0]. Raw differences and original-history-dtype checks reported separately. No model-output retagging, flux-score selection, soil/cold-state/SP-CN or scientific acceptance.',
              source_case=f'ctsm-qia-run-{letter}', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              input_protocol_sha256=sha(input_root.parent / 'protocol.json'), epoch=epoch,
              source_input_met_sha256=sha(workspace / 'inputdata/CN-Qia.datm.2003.nc'),
              selected_intervals=48, original_history_samples=49, maximum_time_quantization_seconds=max(time_errors),
              input_field_differences=metrics, radiation_split=radiation,
              all_direct_met_fields_exact_at_history_dtype=all(metrics[n]['exact_at_history_dtype'] for n in ['TBOT', 'QBOT', 'WIND', 'PBOT', 'FSDS', 'FLDS', 'ZBOT']),
              files=files, raw_fields_sha256=sha(root / 'raw-selected-fields.npz'), positive48_sha256=sha(root / 'official-first48.npz'))
(root / 'boundary.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'files'}), flush=True)

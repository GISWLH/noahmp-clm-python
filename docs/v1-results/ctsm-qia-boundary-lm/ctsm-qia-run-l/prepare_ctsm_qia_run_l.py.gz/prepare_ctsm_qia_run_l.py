from pathlib import Path
import ast
import hashlib
import json

r = Path(__file__).resolve().parent
original = r / 'run_ctsm_qia_k.py'
p = original.read_text().replace('ctsm-qia-run-k', 'ctsm-qia-run-l')
old = "tintalgo='nearest','linear','lower'"
new = "tintalgo='upper','linear','lower'"
assert p.count(old) == 1
p = p.replace(old, new)
p = p.replace(
    'Original UTC interval midpoints, nearest; actual per-step feed-through not yet verified.',
    'Original unchanged UTC interval midpoints, upper met interpolation; explicit pinned-source hypothesis test for nearest midpoint ties plus driver ordering. Actual positive-bin feed-through requires independent audit; no output retagging or physics/source changes.'
)
ast.parse(p)
(r / 'run_ctsm_qia_l.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_k.pbs').read_text().replace('ctsm-qia-run-k', 'ctsm-qia-run-l').replace('run_ctsm_qia_k.py', 'run_ctsm_qia_l.py').replace('clm-qia-official-k', 'clm-qia-official-l')
(r / 'ctsm_qia_run_l.pbs').write_bytes(p.encode())
record = dict(
    scope='Controller-only K to L: owned case/root labels and met tintalgo nearest to upper; no upstream physics or generated field/data/time changes.',
    original_controller_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    changed_controller_sha256=hashlib.sha256((r / 'run_ctsm_qia_l.py').read_bytes()).hexdigest(),
    source_basis=['CTSM/cime/src/share/streams/shr_tInterp_mod.F90:152-179', 'CTSM/cime/src/components/data_comps/datm/datm_comp_mod.F90:608-664'],
    acceptance='Positive48 exact original CF bins and all meteorology checked after actual official execution; never accept by choosing an output time shift.'
)
(r / 'ctsm-qia-run-l-control.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

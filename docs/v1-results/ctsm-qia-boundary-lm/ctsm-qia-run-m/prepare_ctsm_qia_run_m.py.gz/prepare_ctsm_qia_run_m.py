from pathlib import Path
import ast
import hashlib
import json

r = Path(__file__).resolve().parent
original = r / 'run_ctsm_qia_l.py'
p = original.read_text().replace('ctsm-qia-run-l', 'ctsm-qia-run-m')
marker = "    assert run('machine-query',[py,str(source/'cime/scripts/query_config'),'--machines','centos7-linux','--long'])==0"
assert p.count(marker) == 1
addition = "    assert run('common-radiation-input',[py,str(root/'derive_ctsm_qia_common_radiation_a.py'),str(inputs/'CN-Qia.datm.2003.nc'),str(base/'qia-stem-inputs-a/inputs')])==0\n    value['common_radiation_derivation']=json.loads((scratch/'common-radiation-input.stdout.txt').read_text())\n"
p = p.replace(marker, addition + marker)
old = "('FSDS','swdn'),('FLDS','lwdn')"
assert p.count(old) == 1
p = p.replace(old, "('FSDS','swdn'),('SWDNDIR_COMMON','swdndr'),('SWDNDF_COMMON','swdndf'),('FLDS','lwdn')")
p = p.replace('Original unchanged UTC interval midpoints, upper met interpolation;', 'Original unchanged UTC interval midpoints, upper met interpolation; fixed original Erbs direct/diffuse and common0.5 VIS/NIR inputs;')
ast.parse(p)
(r / 'run_ctsm_qia_m.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_l.pbs').read_text().replace('ctsm-qia-run-l', 'ctsm-qia-run-m').replace('run_ctsm_qia_l.py', 'run_ctsm_qia_m.py').replace('clm-qia-official-l', 'clm-qia-official-m')
(r / 'ctsm_qia_run_m.pbs').write_bytes(p.encode())
p = (r / 'ctsm_qia_boundary_l.pbs').read_text().replace('ctsm-qia-boundary-l', 'ctsm-qia-boundary-m').replace('clm-qia-boundary-l', 'clm-qia-boundary-m').replace('run_ctsm_qia_boundary_b.py l', 'run_ctsm_qia_boundary_b.py m')
(r / 'ctsm_qia_boundary_m.pbs').write_bytes(p.encode())
record = dict(scope='L to M adds only standard DATM direct/diffuse shortwave inputs derived from unchanged native input, with common50/50 VIS/NIR. Original input fields and source bytes untouched; time interpolation same as L. Postrun actual four-band/land inputs require independent audit.',
              original_controller_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
              changed_controller_sha256=hashlib.sha256((r / 'run_ctsm_qia_m.py').read_bytes()).hexdigest(),
              source_basis=['CTSM/cime/src/components/data_comps/datm/datm_comp_mod.F90:963-977', 'src/noahmp_clm/physics/canopy_radiation.py:98-115'])
(r / 'ctsm-qia-run-m-control.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

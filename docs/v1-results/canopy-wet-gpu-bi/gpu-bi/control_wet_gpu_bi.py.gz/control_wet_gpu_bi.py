from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-canopy-wet-key-bi';r=s/'gpu-bi';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());start=time.monotonic();records=[]
def ready():
    free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
    return free>8192 and mem>32*1024*1024,dict(gpu_free_mib=free,host_available_kib=mem)
while True:
    good,state=ready();(r/'waiting.json').write_text(json.dumps(dict(ready=good,state=state,seconds=time.monotonic()-start),indent=2)+'\n')
    if good:break
    time.sleep(20.)
with (r/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(r/'collect_wet_gpu_bi.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
collection=json.loads((r/'collection.json').read_text());assert code==0 and collection['passed'] and collection['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
for name,count in [('test_gpu_canopy_interception.py',4),('test_gpu_canopy_phase_energy.py',14)]:
    assert all(sha(s/n)==h for n,h in m.items());nodes=[Path(n.split('::')[0]).name+'::'+n.split('::',1)[1] for n in collection['nodes'] if Path(n.split('::')[0]).name==name];assert len(nodes)==count
    stem=Path(name).stem;expected=r/(stem+'-expected.json');expected.write_text(json.dumps(nodes,indent=2)+'\n');receipt=r/(stem+'-receipt.json');xml=r/(stem+'.xml')
    command=[sys.executable,'-u',str(r/'wet_oracle_worker_bi.py'),'--source',str(s),'--test-file',str(s/'tests'/name),'--expected',str(expected),'--receipt',str(receipt),'--xml',str(xml)];begun=time.monotonic()
    with (r/(stem+'.log')).open('x') as log:p=subprocess.Popen(command,cwd=s,stdout=log,stderr=subprocess.STDOUT)
    (r/'progress.json').write_text(json.dumps(dict(active_file=name,pid=p.pid,records=records),indent=2)+'\n');code=p.wait();d=json.loads(receipt.read_text()) if receipt.exists() else {}
    passed=bool(code==d.get('worker_exitcode')==d.get('pytest_returncode')==0 and d.get('passed') and d.get('source_unchanged') and d.get('node_coverage_exact') and d.get('all_setup_call_teardown_phases_passed') and d.get('counts')==dict(tests=count,failures=0,errors=0,skipped=0) and d.get('xml_sha256')==sha(xml) and d.get('source_manifest_sha256')==sha(s/'SOURCE_SHA256.json'))
    row=dict(file=name,pid=p.pid,passed=passed,actual_parent_returncode=code,seconds=time.monotonic()-begun,receipt_sha256=sha(receipt) if receipt.exists() else None);records.append(row);(r/(stem+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
    if not passed:break
passed=len(records)==2 and all(v['passed'] for v in records) and all(sha(s/n)==h for n,h in m.items());d=dict(passed=passed,returncode=0 if passed else 1,records=records,seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),scope='Finalwetarea.05 actualxuanze module4+14 original nodes. NumPyforward references computedEHPC384 correcteddefaultsignature190 and keycheckedcachedread only onGPUhost; originalinput/science10%/nearzeroabsolute/allraw1e-6/int/MH assertions unchanged. Stableworker validates allphases/XML/devicebarriers, actualparentexit required. No full390GPU/1483/year/science acceptance.')
(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');raise SystemExit(d['returncode'])

from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[2]
base = root / 'docs/v1-results'
prior = json.loads((base / 'qia-physiology-3798-static-a.json').read_text())
groups = list(prior['groups']) + ['ctsm-qia-daylength-uv-a']
docs = ['README.md', 'ROADMAP.md', 'docs/CLM_CTSM_COLD_INITIALIZATION.md', 'docs/CLM_CTSM_PHYSIOLOGY_INPUTS.md',
        'docs/CLM_K78_PRECISION.md', 'docs/CLM_QIA3798_PHASE.md', 'docs/FLUXNET_PLAN.md', 'docs/GPU_BLOCKERS.md', 'docs/KNOWN_LIMITATIONS.md', 'docs/V1_PROGRESS.md']
metadata = ['qia-physiology-3798-static-a.json', 'qia-physiology-3798-static-a.py.gz', 'qia-daylength-closeout-static-b.json', 'qia-daylength-closeout-static-b.py.gz',
            'v1-live-20261019-1345-ehpc.json', 'xuanze-ssh-metadata-a.json.gz', 'xuanze-ssh-metadata-a.py.gz']
paths = docs + ['docs/v1-results/' + n for n in metadata] + ['docs/v1-results/' + n for n in groups]
git = ['git', '-c', 'windows.appendAtomically=false', '-c', 'maintenance.auto=false', '-c', 'gc.auto=false',
       '-c', 'core.compression=0', '-c', 'core.looseCompression=0', '-c', 'pack.compression=0', '-c', 'core.safecrlf=false']
subprocess.run(git + ['add', '-f', '--', *paths], cwd=root, check=True)
subprocess.run(git + ['diff', '--cached', '--check'], cwd=root, check=True)
checks = 0
for group in groups:
    m = json.loads((base / group / 'manifest.json').read_text())
    for item in m['artifacts']:
        name = 'docs/v1-results/' + group + '/' + item['path']
        raw = subprocess.check_output(['git', 'cat-file', 'blob', ':' + name], cwd=root)
        assert hashlib.sha256(raw).hexdigest() == item['stored_sha256'], name
        checks += 1
result = dict(scope='Local Git index-byte/hash and whitespace checks only,no scientific computation. Per-command compression0 avoids prior loose-object compression fault without changing raw artifacts/history/global configuration.',
              groups=len(groups), every_artifact_index_bytes_verified=checks, expected=527)
assert checks == 527
(root / 'outputs/v1/qia-index-audit-a.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))

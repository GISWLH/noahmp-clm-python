import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tests'))
import numpy as np
from test_gpu_canopy_boundary import cases,numpy_reference,reference_arguments
from noahmp_clm.gpu.canopy_boundary import run_canopy_boundary_jax,radiation_inputs
from noahmp_clm.gpu.canopy_snow_radiation import run_canopy_snow_jax
from noahmp_clm.physics.canopy_snow_radiation import canopy_snow_shortwave
arrays=tuple(v[320:321] for v in cases(np.float32,400))
a,s,l,e,kw=reference_arguments(tuple(v[0] for v in arrays))
ref=numpy_reference(arrays)[0]
for tol in (.005,.001,.0005):
 r=run_canopy_boundary_jax(*arrays,tolerance=tol,raise_on_failure=False)
 print('energy',tol,{k:np.asarray(r[k]).tolist() for k in ('leaf_temperature','layer_residual','iterations','converged')},flush=True)
g=run_canopy_snow_jax(arrays[0],arrays[6],arrays[7],radiation_inputs(arrays[0],arrays[1],np))
r=canopy_snow_shortwave(a,kw['snowpack'],s,vegetated_fraction=kw['vegetated_fraction'],ground_albedo=kw['ground_albedo'],diffuse_fraction=kw['diffuse_fraction'],cosine_zenith=kw['cosine_zenith'])
for k in ('canopy_absorbed','absorbed_par'):
 expected=r[k] if k=='canopy_absorbed' else r['canopy'][k]
 print('radiation',k,np.asarray(g[k])[0].tolist(),expected.tolist(),flush=True)
print('reference_temperature',ref['leaf_temperature'].tolist(),flush=True)

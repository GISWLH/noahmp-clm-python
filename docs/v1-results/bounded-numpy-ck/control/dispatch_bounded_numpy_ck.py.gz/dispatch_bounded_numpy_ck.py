from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-numpy-ck';assert not r.exists();r.mkdir();controls={}
for name in ['run_bounded_numpy_ck.py','bounded_numpy_ck.pbs','clm-bounded-numpy-ck-package.json']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/('package.json' if name.endswith('package.json') else name)).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'bounded_numpy_ck.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=b/'bounded-numpy-ck';assert (r/'pbs-exit.txt').read_text().strip()=='0'
for label,count in [('target',81),('full',1119)]:
    d=json.loads((r/(label+'-receipt.json')).read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=count,failures=0,errors=0,skipped=0) and sha(r/(label+'.xml'))==d['xml_sha256']
items=[(p,'bounded-numpy-ck/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['clm-bounded-numpy-ck-source.tar.gz','clm-bounded-numpy-ck-package.json','dispatch_bounded_numpy_ck.py',Path(__file__).name]);a=b/'bounded-numpy-ck-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

"""Read-only live metadata/control snapshot; no numerical-pass inference."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'current-jn-runtime-kb';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();snapshots=[]
for folder in ['ballberry-jo-full-gpu','k78-corrected-js','ballberry-climatology-cuda-jt']:
    q=b/folder;saved=r/folder;saved.mkdir();launch=json.loads((q/'launch.json').read_text());pid=launch['pid'];proc=Path('/proc')/str(pid);assert proc.exists();command=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode();environment=dict(x.split('=',1) for x in (proc/'environ').read_bytes().decode().split('\0') if '=' in x);selected={n:environment.get(n) for n in ['CUDA_VISIBLE_DEVICES','JAX_PLATFORMS','JAX_ENABLE_X64','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']};assert selected['CUDA_VISIBLE_DEVICES']=='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
    for n,h in launch['controls_sha256'].items():
        p=q/n if (q/n).exists() else b/n;assert sha(p)==h;(saved/n).write_bytes(p.read_bytes())
    candidates=['launch.json','SOURCE_SHA256.json','package.json','source-location.json','collection.json','collection-exit.json','inheritance-proof.json','inheritance-prevalidation-proof.json','execution-plan.json','progress.json','worker.json','cold-audit.json','cuda32-worker.json','cuda32-exit.json','jax32-worker.json','waiting-validation.json']
    for name in candidates:
        if (q/name).is_file():(saved/name).write_bytes((q/name).read_bytes())
    row=dict(folder=folder,pid=pid,controller_observed_live=True,command=command,selected_nonsecret_environment=selected,source_manifest_sha256=launch['source_manifest_sha256'],has_terminal_at_snapshot=(q/'exit.json').exists(),scope='Livecontrol/metadata only, no complete/model/1e-6/year/scienceacceptance inferred. Atomicreport snapshots may lag active worker.');snapshots.append(row)
(r/'snapshot.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),physical_gpu1=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=uuid,memory.used,memory.free','--format=csv,noheader'],text=True).strip(),controllers=snapshots,scope='OwnJN581 CPU1156actual0 + originalIV37allactual0 withverifiedCPUtest-onlyinheritance; newCUDA12x48cold/fullGPUremaining370/K78exports actuallydispatched onphysical1. No full407/canonical1563/currentyear/spinup/observational/releasepass fromthis snapshot.'),indent=2)+'\n');(r/Path(__file__).name).write_bytes(Path(__file__).read_bytes());archive=b/'current-jn-runtime-kb-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():n=p.relative_to(r).as_posix();inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as tf:
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
d=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),scope='ActualJN CUDA1 liveJO/JS/JT control/source/collection/inheritance/coldinitial audit snapshot only. 1563=1156CPU+407GPU collected,37originalIV passedfiles inherited withallruntime/testfixture bytesexact; no full407/year/spinup/sciencepass. Onlyallowlisted nonsecretprocessenvironment fields copied.');(b/'current-jn-runtime-kb-package.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

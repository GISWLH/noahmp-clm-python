from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
s, old, r = Path('/tmp/noahmp-k78-corrected-js/source'), b / 'k78-current-ey', b / 'k78-corrected-js'
assert not r.exists() and not s.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
archive=b/'clm-ballberry-jn-source.tar.gz'
assert sha(archive)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
s.mkdir(parents=True)
with tarfile.open(archive) as package:
    for member in package.getmembers():
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
    package.extractall(s,filter='data')
assert sha(s / 'SOURCE_SHA256.json') == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m)==581 and all(sha(s / n) == v for n, v in m.items())
assert sha(old / 'input.npz') == '957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
free = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip()
memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
assert int(free)>8192 and memory>32*1024*1024, 'Original8GiBGPU/32GiBhost guard; no resets/kills'
cache=Path('/tmp/noahmp-k78-corrected-js-cache');assert not cache.exists();cache.mkdir()
r.mkdir()
for name in ['input.npz', 'binding.json']:
    shutil.copyfile(old / name, r / name)
    assert sha(old / name) == sha(r / name)
shutil.copyfile(s / 'SOURCE_SHA256.json', r / 'SOURCE_SHA256.json')
controls = {name: sha(b / name) for name in ['replay_k78_backend_js.py', 'control_k78_js.py', 'launch_k78_js.py']}
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1',
           CUDA_VISIBLE_DEVICES='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
           XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_COMPILATION_CACHE_DIR=str(cache/'jax-cache'), CUPY_CACHE_DIR=str(cache/'cupy-cache'))
with (r / 'controller.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'control_k78_js.py')], cwd=s, env=env, stdin=subprocess.DEVNULL,
                         stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
launch = dict(scope='CurrentJN581 changedphysics regression, queued after ownCPU1156+GPU37 actual0; original K78 isolated16-array whole-step device replay on frozen IV581. Exact historical K78 primary/shadow inputs and binding retained, current source independently verified,unchanged1e-6/no source or failed-year advancement. Actual CPU independent acceptance on EHPC follows exports. Physical1 isolatedsingle-step with currentyear alive, original8GiB/32GiB resourceguards/privatecache; no worker/source/cache intervention.',
              utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=p.pid, device=1,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), input_sha256=sha(r / 'input.npz'), controls_sha256=controls,
              independent_acceptance='pending EHPC PBS', free_gpu1_memory_mib=int(free))
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps(launch))

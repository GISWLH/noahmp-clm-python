import subprocess,json,hashlib,time
results={}
for job in ('1831.manager','1813.manager'):
 r=subprocess.run(['qstat','-fx',job],capture_output=True,timeout=20)
 results[job]=dict(actual_exit=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest())
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),jobs=results,PBS_available=all(r['actual_exit']==0 for r in results.values())),indent=2))

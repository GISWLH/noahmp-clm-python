import subprocess,json,time
commands=[['systemctl','show','pbs','-p','ActiveState','-p','SubState','-p','Result','-p','ExecMainStatus'],['systemctl','status','pbs','--no-pager','-n','8'],['pgrep','-a','pbs_server'],['pgrep','-a','pbs_sched'],['ss','-ltn','sport = :15001']]
results=[]
for command in commands:
 try:
  r=subprocess.run(command,capture_output=True,timeout=12)
  results.append(dict(command=command,actual_exit=r.returncode,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace')))
 except Exception as e:results.append(dict(command=command,exception=type(e).__name__+': '+str(e)))
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),read_only=True,service_or_system_changes=0,observations=results),indent=2))

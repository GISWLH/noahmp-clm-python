"""One read-only PBS daemon/port observation; no service administration."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'pj-pbs-service-readonly-diagnosis-qd-b'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    code="""import subprocess,json,time
commands=[['systemctl','show','pbs','-p','ActiveState','-p','SubState','-p','Result','-p','ExecMainStatus'],['systemctl','status','pbs','--no-pager','-n','8'],['pgrep','-a','pbs_server'],['pgrep','-a','pbs_sched'],['ss','-ltn','sport = :15001']]
results=[]
for command in commands:
 try:
  r=subprocess.run(command,capture_output=True,timeout=12)
  results.append(dict(command=command,actual_exit=r.returncode,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace')))
 except Exception as e:results.append(dict(command=command,exception=type(e).__name__+': '+str(e)))
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),read_only=True,service_or_system_changes=0,observations=results),indent=2))
"""
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc',shlex.join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B','-'])]
    start=time.monotonic();result=subprocess.run(command,input=code.encode(),capture_output=True,timeout=80)
    (OUT/'remote-reader.py').write_bytes(code.encode());(OUT/'snapshot.json').write_bytes(result.stdout);(OUT/'stderr').write_bytes(result.stderr)
    receipt=dict(actual_ssh_exit=result.returncode,seconds=time.monotonic()-start,command=command,
        code_sha256=sha(code.encode()),stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
    (OUT/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n');assert result.returncode==0
    print(json.dumps(receipt));snapshot=json.loads(result.stdout)
    for row in snapshot['observations']:print(json.dumps(row))


if __name__=='__main__':main()

"""Six read-only samples45s apart; no service/job restart or submission."""
from pathlib import Path
import json
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent


def main():
    prefix=sys.argv[1]
    for k in range(6):
        label=prefix+'-'+str(k)
        result=subprocess.run([sys.executable,'-X','utf8',str(BASE/'poll_pj_pbs_service_qd_b.py'),label],capture_output=True,text=True,timeout=65)
        print(result.stdout,flush=True)
        if result.stderr:print(result.stderr,file=sys.stderr,flush=True)
        assert result.returncode==0
        report=json.loads((BASE/'pj-pbs-service-qd-b'/label/'snapshot.json').read_bytes())
        if report['PBS_available']:
            print(json.dumps(dict(event='PBS_recovered',sample=label,read_only=True,controller_or_job_submitted=False)),flush=True)
            return
        if k<5:time.sleep(45)
    print(json.dumps(dict(event='bounded_six_samples_finished',PBS_available=False,read_only=True)),flush=True)


if __name__=='__main__':main()

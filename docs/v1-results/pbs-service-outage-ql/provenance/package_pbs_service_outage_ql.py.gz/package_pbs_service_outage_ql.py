"""Seal only new small PBS-outage evidence; existing physics archives referenced."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='pbs-service-outage-ql'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()


def main():
    blocker=json.loads((BASE/'pbs-service-blocker-qf-qd-b.json').read_bytes())
    assert blocker['thirty_minute_threshold_satisfied'] and blocker['elapsed_seconds_between_verified_refusals']>=1800
    assert blocker['new_qsub_attempts']==blocker['service_or_system_changes']==0
    sudo=json.loads((BASE/'pbs-sudo-readonly-ql-exit.json').read_bytes())
    assert sudo['actual_ssh_command_exit']==1 and not sudo['privilege_change'] and not sudo['service_change']
    assert sha((BASE/'pbs-sudo-readonly-ql.stdout').read_bytes())==sudo['stdout_sha256']
    assert sha((BASE/'pbs-sudo-readonly-ql.stderr').read_bytes())==sudo['stderr_sha256']
    assert (BASE/'pbs-sudo-readonly-ql.stderr').read_bytes().strip()==b'sudo: a password is required'
    stage=json.loads((BASE/'surface-lm-transparent-trace-qf-stage-package.json').read_bytes())
    assert stage['stage_sha256']=='0f28c81c34d6909cb2b2812136395d2c5215004950d469dcc0c0879adafe2d04'
    assert not stage['submission_performed'] and stage['PBS_LF_shebang_verified']
    references={}
    for label in ('surface-dry-lm-py-c','surface-dry-lm-bound-qe','pj-dependency-repair-qd-b','pbs-cache-diagnosis-qk'):
        references[label]=json.loads((BASE/(label+'-package.json')).read_bytes())
    logs=json.loads((BASE/'pbs-logs-qk.json').read_bytes())
    inode=logs['commands']['df-inodes'];assert inode['actual_exit']==0 and '50176 50176     0  100% /opt' in inode['stdout']
    review=json.loads((BASE/'qf-wrapper-independent-review-qc.json').read_bytes())
    assert review['blocking_findings']==[] and not review['actual_QF_submission']
    readout=dict(blocker=blocker,continuous_monitoring_stopped=True,monitoring_scope='All three bounded6-sample readers finished actual0; no live poll process remains and no new loop is launched.',
        next_check_policy='Only one fresh read after a user management-entry update or a new PBS-recovery signal; no unchanged busy polling.',
        prepared_QF=stage,prepared_QD_b_wrapper_sha256='62694b3eae242b33f1ac097b4e6705e57974579c8a2dcca749fd6f6b707e0d53',
        source_or_physical_state_changes=0,new_physical_calls=0,new_qsub_attempts=0,
        sudo_observation=dict(observed_UTC='2026-10-26 16:36 UTC',time_source='Root reported this newly captured observation; it is not the first historical sudo attempt.',
            actual_ssh_command_exit=1,stderr='sudo: a password is required',privilege_change=False,service_change=False,
            stdout_sha256=sudo['stdout_sha256'],stderr_sha256=sudo['stderr_sha256']),
        opt_inode_observation=dict(existing_evidence_label='pbs-cache-diagnosis-qk',original_file='pbs-logs-qk.json',
            original_file_sha256=sha((BASE/'pbs-logs-qk.json').read_bytes()),command=inode['command'],actual_exit=inode['actual_exit'],stdout=inode['stdout'],
            scope='Observation only; no established causal connection to the PBS outage.'),
        causality_limit='No proved reason for pbs_server exit. Inaccessible datastore logs, historical Sept24 systemd state, current inode0 and denied noninteractive sudo do not establish the cause. No root/service action was performed.',
        independent_QF_review=review,existing_evidence_references=references,
        bypass='Retain all frozen CPU work and original failures; root continues independent CUDA1 RN diagnosis. No full-goal pause/blocked/complete status is asserted by this package.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={'readout.json':encode(readout),'existing-evidence-references.json':encode(references),
        'pbs-service-blocker-qf-qd-b.json':(BASE/'pbs-service-blocker-qf-qd-b.json').read_bytes(),
        'SCOPE.md':b'New small PBS outage evidence only: first saved refusal16:02:28.499581UTC and same-handle16:32:43UTC refusal are1814.500419s apart; zero new qsub/service/model actions. Original raw latest/first observations, readonly daemon diagnosis and newly captured16:36UTC sudo password-required response are retained. /opt inode0 is a hash reference to existing QK evidence, not a proved cause. QF static wrapper review and prepared-only metadata/controls are included without any existing model/source/result archive. All continuous monitoring stopped after bounded readers finished. Pending CPU jobs remain frozen; root bypasses to independent CUDA1 work.\n'}
    first=BASE/'pj-seed48-restore-qd-b-deployment/manager-pbs-recheck'
    for name in ('qstat.stdout','qstat.stderr','exit.json'):items['first-saved-refusal/'+name]=(first/name).read_bytes()
    assert sha(items['first-saved-refusal/qstat.stderr'])==blocker['earliest_saved_stderr_sha256']
    for suffix in ('4','5'):
        folder=BASE/('pj-pbs-service-qd-b/qf-thirty-minute-boundary-'+suffix)
        for p in folder.iterdir():
            if p.is_file():items['last-bounded-samples/'+folder.name+'/'+p.name]=p.read_bytes()
    assert sha(items['last-bounded-samples/qf-thirty-minute-boundary-4/snapshot.json'])==blocker['latest_sample_sha256']
    folder=BASE/'pj-pbs-service-readonly-diagnosis-qd-b'
    for p in folder.iterdir():
        if p.is_file():items['readonly-service-diagnosis/'+p.name]=p.read_bytes()
    for name in ('pbs-sudo-readonly-ql.stdout','pbs-sudo-readonly-ql.stderr','pbs-sudo-readonly-ql-exit.json',
        'qf-wrapper-independent-review-qc.txt','qf-wrapper-independent-review-qc.json','surface-lm-transparent-trace-qf-stage-package.json'):
        items[name]=(BASE/name).read_bytes()
    for foldername in ('surface-lm-transparent-trace-qf-preparation','surface-lm-transparent-trace-qf-execution'):
        folder=BASE/foldername
        for p in folder.iterdir():
            if p.is_file():items['prepared-only/'+foldername+'/'+p.name]=p.read_bytes()
    for name in ('poll_pj_pbs_service_qd_b.py','bounded_poll_pj_pbs_service_qd_b.py','diagnose_pbs_service_readonly_qd_b.py',
        'prepare_surface_lm_trace_qf_execution.py','add_qf_identity_hash_capture.py','deploy_surface_lm_trace_qf.py',Path(__file__).name):
        items['provenance/'+name]=(BASE/name).read_bytes()
    assert all(not name.endswith(('.tar.gz','.tar','.npz','.pkl')) for name in items)
    items['artifact-inventory.json']=encode({n:dict(bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='New small read-only PBS outage evidence across1814.500419s, original first/latest samples and daemon/sudo observations, prepared-only QF wrapper independent review. Existing source/physics archives only hash-referenced; no causal ENOSPC claim, new qsub, service/model changes, continuous polling or full-goal status change.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

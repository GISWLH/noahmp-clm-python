"""Add only the explicitly authorized before/after identity evidence to QF."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

BASE=Path(__file__).resolve().parent
PREP=BASE/'surface-lm-transparent-trace-qf-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    target=PREP/'trace_original_qia_lm_qf.py';before=target.read_bytes()
    assert sha(before)=='f1b0ee49780a88d8affc66263748afb4975fb655103810570a50b535b8ffc423'
    provenance=BASE/'surface-lm-transparent-trace-qf-provenance';assert not provenance.exists();provenance.mkdir()
    (provenance/'root-reviewed-worker.py').write_bytes(before)
    old=b'    helper_code=phase._dry_lm_rescue.__code__'
    new=b"    helper.dump_return(root/'kwargs-before',kwargs)\n    source_before={n:sha((source/n).read_bytes()) for n in index}\n    (root/'source-before.json').write_text(json.dumps(source_before,indent=2)+'\\n')\n    assert source_before==index\n"+old
    assert before.count(old)==1;after=before.replace(old,new)
    old2=b'    packet=dict(phase_calls=calls,helper_state=state,events=trace_events,helper_returns=helper_returns,'
    new2=b"    helper.dump_return(root/'kwargs-after',kwargs)\n    source_after={n:sha((source/n).read_bytes()) for n in index}\n    (root/'source-after.json').write_text(json.dumps(source_after,indent=2)+'\\n')\n"+old2
    assert after.count(old2)==1;after=after.replace(old2,new2)
    old3=b'        source_unchanged=False,inputs_unchanged=False,original_rescue_record_exact=False)'
    new3=b"        source_unchanged=False,inputs_unchanged=False,original_rescue_record_exact=False,\n        source_before_sha256=sha((root/'source-before.json').read_bytes()),\n        source_after_sha256=sha((root/'source-after.json').read_bytes()),\n        kwargs_before_pickle_sha256=sha((root/'kwargs-before.pkl').read_bytes()),\n        kwargs_after_pickle_sha256=sha((root/'kwargs-after.pkl').read_bytes()))"
    assert after.count(old3)==1;after=after.replace(old3,new3)
    assert after.replace(new3,old3).replace(new2,old2).replace(new,old)==before
    ast.parse(after);target.write_bytes(after)
    (PREP/'identity-evidence.diff').write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='root-reviewed-QF',tofile='authorized-identity-evidence-QF')).encode())
    binding=json.loads((PREP/'BINDINGS.json').read_bytes())
    binding.update(execution_authorized=True,root_reviewed_worker_sha256=sha(before),identity_evidence_worker_sha256=sha(after),
        execution_condition='Only one unique1CPU2GiB10min job after actual PBS recovery; original exception rethrown and original model exit1 retained.')
    (PREP/'BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n')
    (PREP/'IDENTITY_DIFF_PROOF.json').write_text(json.dumps(dict(root_reviewed_worker_sha256=sha(before),
        new_worker_sha256=sha(after),reverse_three_identity_evidence_insertions_byte_exact=True,
        phase_helper_or_evaluate_algorithm_changes=0,extra_evaluate_calls=0,extra_Jacobian_computations=0),indent=2)+'\n')
    static=json.loads((PREP/'STATIC_CHECKS.json').read_bytes());static['worker_sha256']=sha(after)
    static['identity_capture_only_metadata_augment']=True
    (PREP/'STATIC_CHECKS.json').write_text(json.dumps(static,indent=2)+'\n')
    manifest={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'}
    (PREP/'CONTROLS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(dict(worker_sha256=sha(after),preparation_files=len(manifest)+1,manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()))))


if __name__=='__main__':main()

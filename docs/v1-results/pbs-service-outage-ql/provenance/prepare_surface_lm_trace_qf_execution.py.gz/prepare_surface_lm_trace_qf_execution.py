"""Freeze the authorized single original-phase replay with LF PBS controls."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-transparent-trace-qf'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution')
    assert execution.exists() and {p.name for p in execution.iterdir()}=={'run_trace_qf.py'}
    old=BASE/'surface-dry-lm-bound-qe-c-execution';patches=[]
    before=(old/'check_stage_py.py').read_bytes()
    after=before.replace(b'/tmp/noahmp-surface-dry-lm-bound-qe-c',b'/tmp/noahmp-surface-lm-transparent-trace-qf')
    (execution/'check_stage_qf.py').write_bytes(after)
    patches.append(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='QE-c/check_stage_py.py',tofile='QF/check_stage_qf.py')))
    before=(old/'dispatch_surface_py.py').read_bytes()
    after=before.replace(b'noahmp-surface-dry-lm-bound-qe-c',b'noahmp-surface-lm-transparent-trace-qf')
    after=after.replace(b'dispatch_surface_bound_qe_c.py',b'dispatch_surface_trace_qf.py').replace(b'dispatch_surface_py.py',b'dispatch_trace_qf.py').replace(b'bounds_qe.pbs',b'trace_qf.pbs')
    oldfields=b"resources='1CPU/2GiB/2min/compute002', offline_saved_array_analysis=True, physical_evaluate_calls=0, LM_replays=0, GPU_calls=0,"
    newfields=b"resources='1CPU/2GiB/10min/compute002', planned_original_phase_calls=1, original_physical_exception_expected=True, extra_evaluate_calls=0, GPU_calls=0,"
    assert after.count(oldfields)==1;after=after.replace(oldfields,newfields)
    (execution/'dispatch_trace_qf.py').write_bytes(after)
    patches.append(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='QE-c/dispatch_surface_py.py',tofile='QF/dispatch_trace_qf.py')))
    pbs='''#!/bin/bash
#PBS -N surface-lm-trace-qf
#PBS -l select=1:ncpus=1:mem=2gb:host=compute002_00260924
#PBS -l walltime=00:10:00
#PBS -j oe
set -u
stage=/tmp/noahmp-surface-lm-transparent-trace-qf
root="$TMPDIR/qf-result"
py=/home/zhangyq/venvs/noahmp-closeout/bin/python
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/home/zhangyq/noahmp-v1/test-deps
export CUDA_VISIBLE_DEVICES=''
unset PYTHONHOME
test ! -e "$root" || exit 91
test ! -e "$stage/result.tar.gz" || exit 92
mkdir "$root" || exit 93
cp -r "$stage/execution" "$root/execution-controls" || exit 94
cp "$stage/stage-inventory.json" "$root/stage-inventory.json" || exit 95
"$py" -B "$stage/execution/check_stage_qf.py" --output "$root/stage-before.json" > "$root/stage-before.log" 2>&1
setup_status=$?
echo "$setup_status" > "$root/setup-exit.txt"
status=$setup_status
if test "$setup_status" -eq 0; then
    "$py" -B "$stage/execution/run_trace_qf.py" "$root/probe" > "$root/wrapper.stdout" 2> "$root/wrapper.stderr"
    worker_status=$?
    echo "$worker_status" > "$root/worker-exit.txt"
    "$py" -B "$stage/execution/check_stage_qf.py" --output "$root/stage-after.json" > "$root/stage-after.log" 2>&1
    after_status=$?
    echo "$after_status" > "$root/stage-after-exit.txt"
    status=$worker_status
    if test "$after_status" -ne 0; then status=$after_status; fi
fi
echo "$status" > "$root/pbs-command-exit.txt"
tar -czf "$stage/result.tar.gz" --exclude='./probe/trace/source' -C "$root" . || exit 96
echo "$status" > "$stage/pbs-exit.txt"
exit "$status"
'''.encode()
    assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs
    (execution/'trace_qf.pbs').write_bytes(pbs)
    patches.append(''.join(difflib.unified_diff((old/'bounds_qe.pbs').read_text().splitlines(True),pbs.decode().splitlines(True),fromfile='QE-c/bounds_qe.pbs',tofile='QF/trace_qf.pbs')))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'README.md').write_bytes(b'One authorized1CPU2GiB10min compute002 original phase replay, no source changes or extra evaluate/J computations. Private manager/compute transfer and unique qsub mechanically reuse QE-c/PY. LF PBS; all inputs/controls/stage hashed before/after. Wrapper records actual original worker exit1 and preserves that exit even if replay-identity conclusive=true. Raw pickle precedes typed JSON/NPZ; any nonfinite metadata float is explicit hex. No physical repair, whole-column timestep, annual or scientific credit. Deployment waits for actual PBS recovery; no repeated submission attempt while unavailable.\n')
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={}
    for folder,directory in [('preparation',prep),('execution',execution)]:
        items.update({folder+'/'+p.relative_to(directory).as_posix():p.read_bytes() for p in directory.rglob('*') if p.is_file()})
    binding=json.loads((prep/'BINDINGS.json').read_bytes())
    for name,filename,key in [('source.tar.gz','surface-dry-lm-py-source.tar.gz','source_archive_sha256'),
        ('py-c-result.tar.gz','surface-dry-lm-py-c-result.tar.gz','PY_c_result_sha256'),
        ('qe-c-result.tar.gz','surface-dry-lm-bound-qe-c-result.tar.gz','QE_c_result_sha256')]:
        items[name]=(BASE/filename).read_bytes();assert sha(items[name])==binding[key]
    items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    result=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),
        worker_sha256=sha((prep/'trace_original_qia_lm_qf.py').read_bytes()),PBS_LF_shebang_verified=True,
        planned_phase_calls=1,original_physical_exception_expected=True,extra_evaluate_calls=0,extra_Jacobian_computations=0,submission_performed=False)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(result));print(json.dumps(result))


if __name__=='__main__':main()

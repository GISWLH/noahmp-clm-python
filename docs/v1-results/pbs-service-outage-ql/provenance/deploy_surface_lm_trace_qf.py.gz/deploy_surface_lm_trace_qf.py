"""Unique QF deployment, gated on actual PBS recovery before stage upload."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
LOG=BASE/'surface-lm-transparent-trace-qf-deployment'
STAGE=BASE/'surface-lm-transparent-trace-qf-stage.tar.gz'
DISPATCH=BASE/'surface-lm-transparent-trace-qf-execution/dispatch_trace_qf.py'
EXPECTED='0f28c81c34d6909cb2b2812136395d2c5215004950d469dcc0c0879adafe2d04'
sha=lambda b:hashlib.sha256(b).hexdigest()


def run(label,command):
    start=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=120)
    (LOG/(label+'.stdout')).write_bytes(result.stdout);(LOG/(label+'.stderr')).write_bytes(result.stderr)
    (LOG/(label+'.json')).write_text(json.dumps(dict(command=command,actual_exit=result.returncode,
        seconds=time.monotonic()-start,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)),indent=2)+'\n')
    assert result.returncode==0,(label,result.stderr.decode(errors='replace'))
    return result.stdout


def main():
    assert sha(STAGE.read_bytes())==EXPECTED and not LOG.exists();LOG.mkdir()
    ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc']
    scp=['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12']
    live=run('PBS-live',ssh+['qstat -fx 1831.manager'])
    assert all(v in live for v in (b'job_state = F',b'Exit_status = 1',b'Stageout_status = 0'))
    parent=run('PBS-parent-live',ssh+['qstat -fx 1813.manager'])
    assert all(v in parent for v in (b'job_state = F',b'Exit_status = 0',b'Stageout_status = 0'))
    remote='/tmp/noahmp-surface-lm-transparent-trace-qf'
    dispatcher='/tmp/dispatch_surface_trace_qf.py'
    for label,path in [('root',remote),('stage',remote+'-stage.tar.gz'),('dispatch',dispatcher)]:
        run('preflight-'+label,ssh+['test ! -e '+path])
    run('upload-stage',scp+[str(STAGE),'ehpc:'+remote+'-stage.tar.gz'])
    run('upload-dispatch',scp+[str(DISPATCH),'ehpc:'+dispatcher])
    uploaded=run('uploaded-hashes',ssh+['sha256sum '+remote+'-stage.tar.gz '+dispatcher])
    assert {line.split()[1]:line.split()[0] for line in uploaded.decode().splitlines()}=={
        remote+'-stage.tar.gz':EXPECTED,dispatcher:sha(DISPATCH.read_bytes())}
    output=run('dispatch',ssh+['/home/zhangyq/venvs/noahmp-closeout/bin/python -B '+dispatcher+
        ' --archive '+remote+'-stage.tar.gz --sha256 '+EXPECTED])
    record=json.loads(output);assert record['stage_sha256']==EXPECTED
    print(json.dumps(dict(pbs_job=record['pbs_job'],stage_sha256=EXPECTED,actual_dispatch_exit=0)))


if __name__=='__main__':main()

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-native-column-a';r=s/'cuda-prefix-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and len(d['completed'])==7 and sha(r/'outputs.npz')==d['outputs_sha256'];m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());rows=[]
for line in (s/'cuda-prefix-a.log').read_text().splitlines():
 if line.startswith('native structure whole '):rows.append(json.loads(line[line.index('{'):]))
assert len(rows)==14
maximum={key:max(row['maximum_absolute'][key] for row in rows) for key in ['h','le','sai']};budgets={key:max(row['independent_budgets'].get(key,0.) for row in rows) for key in ['water_kgm2','heat_jm2','carbon','nitrogen']};record=dict(scope='Completed CUDA32-only28 column-steps, independent NumPy reference10% and original MHCN bounds inside each audit. Receipt/device barrier verified; detached launch does not independently record interpreter process exit status. JAX parity/canonical19/full regression/year still pending.',maximum_absolute=maximum,maximum_independent_residuals=budgets,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'))
(r/'comparison-summary.json').write_text(json.dumps(record,indent=2)+'\n');a=b/'stem-native-cuda-prefix-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):t.add(p,arcname='cuda-prefix-a/'+p.name,recursive=False)
 for p in [s/'cuda-prefix-a.log',s/'cuda-prefix-launch-a.json',s/'SOURCE_SHA256.json']:t.add(p,arcname=p.name,recursive=False)
 for n in ['run_stem_native_cuda_prefix_a.py','launch_stem_native_cuda_prefix_a.py','archive_stem_native_cuda_prefix_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,summary=record)))

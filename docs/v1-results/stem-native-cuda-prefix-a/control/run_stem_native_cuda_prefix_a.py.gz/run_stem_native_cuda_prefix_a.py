from pathlib import Path
import hashlib,json,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-native-column-a';r=s/'cuda-prefix-a';r.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s/'src'),str(s/'tests'),str(s/'benchmarks')];import cupy as cp
from test_gpu_clm_structure_column import run_cases
from noahmp_clm.gpu.clm_structure_column import step_clm_structure_columns_cuda
begun=time.monotonic();failure=None;flat={};rows=[]
try:
 for most in (False,True):
  for kind,got in run_cases(step_clm_structure_columns_cuda,np.float32,most,convert=lambda x:cp.asnumpy(x) if isinstance(x,cp.ndarray) else np.asarray(x)):
   prefix=('most' if most else 'neutral')+'/'+kind+'/'
   def flatten(d,path):
    for key,value in d.items():
     if isinstance(value,dict):flatten(value,path+key+'/')
     else:flat[path+key]=np.asarray(value)
   flatten(got,prefix);rows.append(dict(most=most,kind=kind,steps=2,columns=2));print(json.dumps(rows[-1]),flush=True)
 cp.cuda.runtime.deviceSynchronize()
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
np.savez_compressed(r/'outputs.npz',**flat);unchanged=all(sha(s/n)==v for n,v in m.items());d=dict(scope='Original new502 CUDA32-only two-step structured whole-column prefix on GPU0, independent NumPy10% and original independent MHCN audits inside each case. Not JAX parity, all19 completion, annual or scientific validation.',failure=failure,completed=rows,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),outputs_sha256=sha(r/'outputs.npz'),seconds=time.monotonic()-begun);(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);raise SystemExit(0 if failure is None and unchanged and len(rows)==7 else 1)

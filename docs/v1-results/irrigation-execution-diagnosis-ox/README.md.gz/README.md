# Irrigation execution diagnosis OX

Read-only sample ended 2026-10-25 09:58:59 UTC on xuanze physical CUDA1.
PID3799882 had run3200.5s and used501CPU ticks over5.019419s; RSS21.9579GiB, VmSwap0, host available82.0372GiB. No new model, benchmark, worker, profiler attachment, signal, cache/source/task change or numerical recomputation was performed.

The module has13nodes. Five reference-node outputs are visible, but no terminal file-level credit is added: NQ remains95fresh+32inherited=127/408 at this sample. The old source JO13-node parent0/receipt/XML/expected/cache records retain their original identity and supply timing only. Current and historical test bytes are identical; model sources differ.

GD checks16GiB peak after only native.Backend.step, Richards.advance and Capacity.run. The irrigation test directly calls step_clm_irrigated_columns_jax/cuda and therefore does not have a continuously enforced16GiB cap. Startup GPU>8GiB/host>32GiB resource checks remain.

Current first-five logged time2576.54s is comparable with historical2665s; old whole-file parent time4060.7668s. This supports continuing the current queue, not assigning an internal tracing/compilation/compute/GC substage or a new deadline. The prior23.21-45.67h scenario remains conditional; active elapsed is not subtracted.

The sample was captured by an inline SSH standard-library script; no pre-existing standalone sampler file is represented as archived. Package controls are exact existing read-only source copies, not new instrumentation.

from pathlib import Path
import hashlib,json,os,re,subprocess
base=Path('/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016')
old=base/'bondville-smoke-b'; run=base/'bondville-fixed-lai-c';run.mkdir(exist_ok=False);(run/'output').mkdir()
for source in old.iterdir():
 if source.is_symlink(): (run/source.name).symlink_to(source.resolve())
(run/'forcing').symlink_to(old/'forcing',target_is_directory=True)
nml=(old/'namelist.hrldas').read_text().replace(str(old/'output'),str(run/'output'))
changes={'DYNAMIC_VEG_OPTION':9,'TBOT_OPTION':1}
for key,value in changes.items():
 nml,count=re.subn(r'(?m)^( '+key+r'\s*=)\s*\d+',r'\g<1> '+str(value),nml);assert count==1
(run/'namelist.hrldas').write_text(nml)
manifest={'scope':'Official one-day same-meteorology fixed-input-LAI comparison profile, no spinup/calibration','parent':'bondville-smoke-b','changes':changes,'unchanged_forcing':str(old/'forcing'),'namelist_sha256':hashlib.sha256(nml.encode()).hexdigest(),'binary_sha256':hashlib.sha256((run/'hrldas.exe').read_bytes()).hexdigest(),'note':'Upstream opt4 uses monthly table LAI; opt9 uses input LAI and maximum vegetation cover. Official snow albedo BATS remains; Python uses SNICAR.'}
(run/'setup-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=dict(os.environ);env.pop('LD_LIBRARY_PATH',None)
with (run/'hrldas.log').open('wb') as f:r=subprocess.run([str(run/'hrldas.exe')],cwd=run,env=env,stdout=f,stderr=subprocess.STDOUT)
print(json.dumps({'returncode':r.returncode,'output_count':len(list((run/'output').glob('*.LDASOUT_DOMAIN1')))}),flush=True)
raise SystemExit(r.returncode)

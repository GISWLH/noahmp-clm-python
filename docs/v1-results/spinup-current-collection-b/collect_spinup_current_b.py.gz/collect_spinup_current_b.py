from pathlib import Path
import hashlib,json,os,subprocess,sys
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-spinup-assessment-b';old=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=root/'current-collection-receipt.json';assert not receipt.exists()
m=json.loads((root/'SOURCE_SHA256.json').read_text());previous=json.loads((old/'SOURCE_SHA256.json').read_text())
assert all(sha(root/n)==v for n,v in m.items())
names=[n for n in previous if n.startswith(('src/','tests/','benchmarks/','examples/'))];assert all(previous[n]==m[n] for n in names)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(root/'src')+':'+str(root/'tests')+':'+str(root/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'))
r=subprocess.run(['/home/lhwang/venvs/noahmp-phase3b/bin/python','-m','pytest','--collect-only','-q'],cwd=root,env=env,capture_output=True,text=True)
(root/'current-collection.log').write_text(r.stdout+r.stderr);assert r.returncode==0
nodes=[v.strip() for v in r.stdout.splitlines() if v.startswith('tests/') and '::' in v];assert len(nodes)==len(set(nodes))==1128
gpu=lambda n:Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))
gpu_nodes={n for n in nodes if gpu(n)};prior=json.loads((old/'full-by-file-a/selection.json').read_text());old_gpu={n for n in prior['all_nodes'] if gpu(n)}
assert len(gpu_nodes)==325 and gpu_nodes==old_gpu and all(sha(root/n)==v for n,v in m.items())
value=dict(scope='Collection and raw source/node identity only, no test execution. Current1128=803 CPU+325 GPU; every GPU node and existing483 code/test/benchmark files are identical to the actively executing frozen MOST suite. Added assessment tool/test only, no model source edit.',
    collected_nodes=1128,cpu_nodes=803,gpu_nodes=325,gpu_node_identity_exact=True,source_files=len(m),source_unchanged=True,existing_code_test_benchmark_files_identical=len(names),nodes=nodes,scientific_acceptance_claim=False)
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k!='nodes'}))

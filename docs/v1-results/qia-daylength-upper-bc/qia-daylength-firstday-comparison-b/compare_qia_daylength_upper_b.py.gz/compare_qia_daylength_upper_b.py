from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-daylength-firstday-comparison-b';scratch=Path(os.environ['TMPDIR']);s=scratch/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'p6-all-phase-final-b-source.tar.gz';assert sha(a)=='1456f86a97f1a744da13d0a1805d3dfa815ef810d4c386799f47ac233b6ffef4'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src')]
from noahmp_clm.validation import compare_series
official=b/'ctsm-qia-run-r';audit=json.loads((official/'year-boundary.json').read_text());assert (official/'pbs-exit.txt').read_text().strip()=='0' and sha(official/'official-year-fields.npz')==audit['fields_sha256']
with np.load(official/'official-year-fields.npz',allow_pickle=False) as z:ref=dict(z)
assert np.array_equal(ref['time_bounds_seconds'][:48],np.arange(48)[:,None]*1800+[[0,1800]])
config=json.loads((b/'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json').read_text());dz=np.asarray(config['column']['dz'],float);te=np.r_[0.,np.cumsum(dz)];se=np.r_[0.,np.cumsum(np.asarray(ref['DZSOI'],float).reshape(15))];overlap=np.maximum(0.,np.minimum(te[1:,None],se[None,1:])-np.maximum(te[:-1,None],se[None,:-1]))/dz[:,None];assert np.max(abs(overlap.sum(1)-1.))<1e-14 and np.all(overlap[:,10:]==0.)
a=b/'qia-all-phase-numpy-year-launch-c-evidence.tar.gz';assert sha(a)=='7f68019a364ad7c6d0ea88902f0d49f869f15f6b9fb40483f55caddf3c4391af';baseline=scratch/'current-baseline';baseline.mkdir()
with tarfile.open(a) as t:t.extractall(baseline,filter='data')
archived_m=json.loads((baseline/'controller/SOURCE_SHA256.json').read_text());assert all(archived_m[n]==h for n,h in m.items() if n.startswith(('src/','benchmarks/')))
new=b/'qia-trait-daylength-upper-b';receipt=json.loads((new/'receipt.json').read_text());assert (new/'pbs-exit.txt').read_text().strip()=='0' and receipt['returncode']==0 and receipt['source_unchanged'] and receipt['steps_completed']==48
cases={};traces={}
for label,folder,cfg in [('current-generic-B',baseline/'trajectory',config),('PFT-NOAA-daylight-upper-B',new/'trajectory',json.loads((new/'config.json').read_text()))]:
    report=json.loads((folder/'report.json').read_text());assert report['source_unchanged'] and report['status']=='running' and report['steps_completed']>=48 and report['forcing_npz_sha256']=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
    p=folder/report['model_npz'];assert sha(p)==report['model_npz_sha256']
    with np.load(p,allow_pickle=False) as z:model={n:np.asarray(v)[:48] for n,v in z.items()}
    assert str(model['time_start'][0])=='200301010000' and str(model['time_end'][-1])=='200301020000'
    metrics={}
    for name,source,factor,unit in [('h_wm2','FSH',1.,'h_wm2'),('le_wm2','EFLX_LH_TOT',1.,'le_wm2'),('et_mm','QFLX_EVAP_TOT',86400.,'et_mm_day'),('runoff_mm','QRUNOFF',86400.,'runoff_mm_day'),('gpp_gc_m2','FPSN',12.0107e-6*86400.,'gpp_gc_day'),('swe_m','H2OSNO',.001,'swe_m')]:
        actual=np.asarray(model[name],float).reshape(48)*(48. if name in ['et_mm','runoff_mm','gpp_gc_m2'] else 1.);expected=np.asarray(ref[source][:48],float).reshape(48)*factor;metrics[name]=compare_series(actual,expected,unit,weights=np.full(48,1800.))
    soil_t=np.asarray(ref['TSOI'][:48],float).reshape(48,15)@overlap.T;soil_w=np.asarray(ref['H2OSOI'][:48],float).reshape(48,10)@overlap[:,:10].T
    for name,expected,unit,offset in [('tsoil_k',soil_t,'tsoil_c',273.15),('smc_m3m3',soil_w,'smc',0.)]:
        for layer in range(4):metrics[name+'/'+str(layer)]=compare_series(model[name][:,layer]-offset,expected[:,layer]-offset,unit,weights=np.full(48,1800.))
    cases[label]=dict(status='first48 unspunup input diagnostic only',metrics=metrics,leaf_parameters=cfg['leaf_parameters'],trace_sha256=sha(p),report_sha256=sha(folder/'report.json'),configuration_sha256=report['configuration_sha256']);traces[label]=model
old=json.loads((b/'qia-trait-firstday-comparison-b/diagnosis.json').read_text());oldcases=old['cases'];assert len(oldcases)==3
baseline_differences={name:{key:dict(current=value,prior=oldcases['original-generic']['metrics'][name][key]) for key,value in row.items() if value!=oldcases['original-generic']['metrics'][name][key]} for name,row in cases['current-generic-B']['metrics'].items()}
oldcfg=json.loads((new/'config.json').read_text());assert all(oldcfg[k]==v for k,v in config.items() if k not in ['scope','leaf_parameters'])
record=dict(scope='EHPC actual all48 currentB511 generic and prospectivelydeclared PFT1/11C/approximateNOAAdaylightupper counterfactual versus sameoriginalR. Threeolder510baseline/BBonly/PFTupper results retained with source distinction. Every H/LE/ET/GPP/runoff/SWE/soil variable preserved,originalnearzero/10percent/r>.85 rules andfloat64metric arithmetic. No measured officialDAYL/actualcapacity claim,default selection,calibration,spinup/multiyear/science acceptance or production change.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cases=cases,older_source_cases=oldcases,current_vs_older_generic_metric_differences=baseline_differences,prospective_protocol_sha256=sha(new/'protocol.json'),original_reference_audit_sha256=sha(official/'year-boundary.json'))
(r/'diagnosis.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pbs_job=record['pbs_job'],source_unchanged=record['source_unchanged'],case_names=list(cases),prior_case_names=list(oldcases))),flush=True)

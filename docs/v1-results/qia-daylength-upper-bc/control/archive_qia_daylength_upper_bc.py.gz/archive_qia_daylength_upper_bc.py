from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=[b/'qia-trait-daylength-upper-b',b/'qia-daylength-firstday-comparison-b',b/'qia-daylength-firstday-comparison-c'];model,failed,analysis=roots
assert (model/'pbs-exit.txt').read_text().strip()=='0' and (failed/'pbs-exit.txt').read_text().strip()=='1' and (analysis/'pbs-exit.txt').read_text().strip()=='0'
rec=json.loads((model/'receipt.json').read_text());assert rec['source_unchanged'] and rec['returncode']==0 and rec['steps_completed']==48
protocol=json.loads((model/'protocol.json').read_text())
for n,h in protocol['controls_sha256'].items():assert sha(model/n)==h
report=json.loads((model/'trajectory/report.json').read_text());assert report['status']=='running' and report['steps_completed']==48 and sha(model/'trajectory/report.json')==rec['report_sha256']
assert sha(model/'trajectory'/report['model_npz'])==report['model_npz_sha256'] and sha(model/'trajectory'/report['checkpoint_file'])==report['checkpoint_sha256']
d=json.loads((analysis/'diagnosis.json').read_text());assert d['source_unchanged'] and len(d['cases'])==2 and len(d['older_source_cases'])==3 and d['prospective_protocol_sha256']==sha(model/'protocol.json')
summary=dict(scope='Prospective267 originalcold finalB511 counterfactual48 actual0/490.612s and originalhardguards/source unchanged. Original268 FileNotFoundError for prior comparisonfilename retained,269 correctedpath analysisactual0 without modelrerun/input/window change. Currentgeneric plusPFT1/11C/approximateNOAAdaylight-upper21.5604 capacity retained along with all3older510cases,all14metrics each. H-14.2811percent andGPP+59.7611percent/r.990215,LEabs.291613W,ETabs.00597175mmday;runoffabs.684363/r.771414 stillfails. Not production/default selection,actualDAYL/CO2capacity measurement,spinup/scientific validation. 269 dispatch inherited dependency label afterok267 but actual qsub has no dependency because267 had alreadyactuallycompleted0;control code shows exactsubmission.',model_receipt=rec,analysis_pbs=d['pbs_job'],source_manifest_sha256=d['source_manifest_sha256'])
a=b/'qia-daylength-upper-bc-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for r in roots:
        for p in sorted(r.rglob('*')):
            if p.is_file():t.add(p,arcname=r.name+'/'+p.relative_to(r).as_posix(),recursive=False)
    raw=(json.dumps(summary,indent=2)+'\n').encode();i=tarfile.TarInfo('summary.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw));t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

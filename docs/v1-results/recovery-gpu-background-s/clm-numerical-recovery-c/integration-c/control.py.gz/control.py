from pathlib import Path
import hashlib,json,os,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-numerical-recovery-c';r=s/'integration-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());manifest=sha(s/'SOURCE_SHA256.json');last=-100.
def ready():
    path=b/'numerical-recovery-cpu-c-receipt.json'
    if not path.exists():return False,'waiting actual EHPC354 full1071 receipt transfer'
    d=json.loads(path.read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1071,failures=0,errors=0,skipped=0) and d['source_manifest_sha256']==manifest
    path=b/'richards-column-native-a/target-a/exit.json'
    if not path.exists():return False,'waiting original552 whole5 actual parent terminal, no old pass credit'
    free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
    return free>8192 and mem>32*1024*1024,dict(previous552_actual_exit=json.loads(path.read_text()),gpu_free_mib=free,host_available_kib=mem)
while True:
    good,state=ready()
    if time.monotonic()-last>=60.:
        record=dict(elapsed_seconds=time.monotonic()-start,ready=good,state=state,scope='Light queue only, no integration test credit');(r/'waiting.json').write_text(json.dumps(record,indent=2)+'\n')
        with (r/'waiting-events.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
        last=time.monotonic()
    if good:break
    time.sleep(20.)
collection=json.loads((s/'target-a/collection.json').read_text());assert collection['source_unchanged'] and collection['source_manifest_sha256']==manifest;gpu=[n.split('/',1)[1] for n in collection['nodes'] if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];assert len(gpu)==390
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';records=[]
for label,filename,expected,variable in [('whole','test_gpu_clm_richards_column.py',5,'NOAHMP_RICHARDS_COLUMN_DIAGNOSTICS'),('station','test_gpu_fluxnet_richards_runner.py',3,'NOAHMP_RICHARDS_STATION_DIAGNOSTICS')]:
    while not ready()[0]:time.sleep(20.)
    assert all(sha(s/n)==h for n,h in m.items());q=r/label;q.mkdir();nodes=[n for n in gpu if n.split('::')[0]==filename];assert len(nodes)==expected;(q/'expected.json').write_text(json.dumps(nodes,indent=2)+'\n');env=os.environ.copy();env[variable]=str(q/'diagnostics')
    command=[sys.executable,'-u',str(worker),'--source',str(s),'--test-file',str(s/'tests'/filename),'--expected',str(q/'expected.json'),'--receipt',str(q/'receipt.json'),'--xml',str(q/'tests.xml')]
    with (q/'tests.log').open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
    (q/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2)+'\n');code=p.wait();d=json.loads((q/'receipt.json').read_text()) if (q/'receipt.json').exists() else {}
    passed=bool(code==d.get('worker_exitcode')==d.get('pytest_returncode')==0 and d.get('passed') and d.get('source_unchanged') and d.get('all_setup_call_teardown_phases_passed') and d.get('node_coverage_exact') and d.get('counts')==dict(tests=expected,failures=0,errors=0,skipped=0) and d.get('xml_sha256')==sha(q/'tests.xml') and d.get('source_manifest_sha256')==manifest and all(sha(s/n)==h for n,h in m.items()))
    row=dict(label=label,passed=passed,returncode=code if code else (0 if passed else 1),receipt_sha256=sha(q/'receipt.json') if d else None);(q/'exit.json').write_text(json.dumps(row,indent=2)+'\n');records.append(row)
    if not passed:break
passed=len(records)==2 and all(v['passed'] for v in records);record=dict(scope='563-recovery-C fresh integration whole5 then station3. Actual full1071/currentcomponent8 prerequisites and predecessor terminal/resources required; no old-source pass credit or NumPy forward onGPUhost. Original allraw1e-6/int/science/MHCN/impurity/restart gates unchanged; not full1461/year/science acceptance.',passed=passed,returncode=0 if passed else 1,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=manifest,seconds=time.monotonic()-start,records=records)
(r/'exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['returncode'])

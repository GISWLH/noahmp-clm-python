from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-joint-chord-a';root=base/'profile_output/chord-k-wait-l-start-a';root.mkdir(parents=True,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
def process(pid):
    p=Path('/proc')/str(pid);assert p.exists() and p.stat().st_uid==os.getuid();v=(p/'stat').read_text().rsplit(')',1)[1].split();hz=os.sysconf('SC_CLK_TCK');elapsed=float(Path('/proc/uptime').read_text().split()[0])-int(v[19])/hz
    return dict(pid=pid,state=v[0],command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),elapsed_seconds=elapsed,cpu_seconds=(int(v[11])+int(v[12]))/hz,rss_pages=int(v[21]),wait_channel=(p/'wchan').read_text().strip())
k=base/'fluxnet-first-climate-cycle-20261017-k';l=base/'fluxnet-first-climate-cycle-20261018-l';worker=json.loads((k/'annual-worker.json').read_text());kp=process(worker['pid']);assert 'run_fluxnet_native.py' in kp['command'] and '--compare-jax32' in kp['command'];lp=process(json.loads((l/'launch.json').read_text())['pid']);progress={}
for label,folder in [('k',k),('l',l)]:
    p=folder/'cuda-day/batch.json'
    if p.exists():r=json.loads(p.read_text());progress[label]={name:r.get(name) for name in ['status','steps_completed','steps_requested','seconds','source_unchanged','same_precision_max_absolute']};progress[label]['batch_sha256']=sha(p)
    else:progress[label]=dict(status='not-yet-published')
gpu=subprocess.run(['nvidia-smi','--query-gpu=index,utilization.gpu,memory.used','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Single read-only live K/L process/progress/GPU utilization snapshot. Does not attribute the whole elapsed interval to compilation, compute or I/O. Original K remains unchanged; fresh CUDA-only L advances independent science only after original NumPy and exact K primary prefix checks. No restart, source edits, other-user signals or GPU reset.',k_process=kp,l_controller=lp,progress=progress,gpu_snapshot=gpu,source_unchanged=True,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'));(root/'observation.json').write_text(json.dumps(value,indent=2)+'\n');(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
for name in ['launch.json','input-import.json','run_gpu_chord_l_campaign_a.py']:(root/('l-'+name)).write_bytes((l/name).read_bytes())
archive=base/'chord-k-wait-l-start-a-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(root.iterdir()):t.add(p,arcname=p.name,recursive=False)
print(json.dumps(dict(name='chord-k-wait-l-start-a',sha256=sha(archive),files=5,observation=value)))

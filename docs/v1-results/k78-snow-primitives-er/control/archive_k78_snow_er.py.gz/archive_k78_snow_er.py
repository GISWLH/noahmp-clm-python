from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-snow-primitives-er';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text());assert e['actual_parent_returncode']==0 and e['delivered'] and e['controller_failure'] is None and e['receipt_sha256']==sha(r/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barriers_complete'] and d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
assert all(sha(r/n)==h for n,h in d['output_sha256'].items());items=[(p,'probe/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()]
for name in ['input.npz','binding.json','cuda32/receipt.json','cuda32/output.npz','jax32/receipt.json','jax32/output.npz']:items.append((b/'k78-current-b'/name,'original-input/'+name))
items.append((b/Path(__file__).name,'control/'+Path(__file__).name));a=b/'k78-snow-primitives-er-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

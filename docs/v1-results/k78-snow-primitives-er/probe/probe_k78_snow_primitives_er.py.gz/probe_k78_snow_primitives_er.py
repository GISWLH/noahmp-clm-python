"""Isolated original-input fresh snow/transfer calls; no climate step or source edit."""
from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-snow-primitives-er';s=Path('/tmp/noahmp-phase-descent-ec/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
old=b/'k78-current-b';input=old/'input.npz';assert sha(input)=='957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
with np.load(input,allow_pickle=False) as z:forcing=z['forcing'].copy()
exports={}
for backend in ['cuda32','jax32']:
    p=old/backend/'output.npz';d=json.loads((old/backend/'receipt.json').read_text());assert d['failure'] is None and sha(p)==d['result']['output_sha256']
    with np.load(p,allow_pickle=False) as z:exports[backend]={k:z[k].copy() for k in ['canopy_interception/ledger/ground_ice_kgm2','canopy_interception/ledger/ground_ice_enthalpy_jm2']}
for name in exports['cuda32']:assert exports['cuda32'][name].tobytes()==exports['jax32'][name].tobytes()
mass=exports['cuda32']['canopy_interception/ledger/ground_ice_kgm2'];heat=exports['cuda32']['canopy_interception/ledger/ground_ice_enthalpy_jm2'];n=len(forcing);cells=np.zeros((n,5,9),np.float32);cells[:,:,3]=54.5;options=np.zeros((n,5),np.int32);u=np.zeros((n,23),np.float32);u[:,21]=forcing[:,1]-np.float32(273.15);u[:,22]=forcing[:,3];np.savez_compressed(r/'probe-input.npz',forcing=forcing,cells=cells,options=options,evolution_inputs=u,ground_ice=mass,ground_ice_enthalpy=heat)
import cupy as cp
import jax
import jax.numpy as j
from noahmp_clm.gpu.cuda.snow_evolution import run_snow_evolution_cuda
from noahmp_clm.gpu.snow_evolution import run_snow_evolution_jax
from noahmp_clm.gpu.cuda.snow_mass import run_snow_transfer_cuda
from noahmp_clm.gpu.snow_mass import run_snow_transfer_jax
start=time.monotonic();failure=None;rows=[]
def save(label,result):
    fields={k:cp.asnumpy(v) if isinstance(v,cp.ndarray) else np.asarray(v) for k,v in result.items()};np.savez_compressed(r/(label+'.npz'),**fields);return fields
try:
    density={}
    for name,function in [('cuda32',run_snow_evolution_cuda),('jax32',run_snow_evolution_jax)]:density[name]=save('fresh-'+name,function(cells,options,u))
    for choice in ['own','common-cuda-density']:
        for name,function,xp in [('cuda32',run_snow_transfer_cuda,cp),('jax32',run_snow_transfer_jax,j)]:
            inputs=xp.zeros((n,16),xp.float32);ground=xp.asarray(mass);enthalpy=xp.asarray(heat);offset=xp.where(ground>0.,enthalpy/xp.maximum(ground*xp.float32(2100.),xp.float32(1e-30)),xp.float32(0.))
            values=[ground,offset,xp.asarray(density['cuda32' if choice=='common-cuda-density' else name]['fresh_density']),xp.asarray(density[name]['fresh_radius'])]
            if name=='cuda32':
                for k,v in enumerate(values):inputs[:,k]=v
                inputs[:,4:11]=xp.asarray([.033,.05,.2,.02,.02,.01,.01],xp.float32)
            else:
                for k,v in enumerate(values):inputs=inputs.at[:,k].set(v)
                inputs=inputs.at[:,4:11].set(xp.asarray([.033,.05,.2,.02,.02,.01,.01],xp.float32))
            host=cp.asnumpy(inputs) if name=='cuda32' else np.asarray(inputs);np.savez_compressed(r/('transfer-input-'+choice+'-'+name+'.npz'),inputs=host)
            got=save('transfer-'+choice+'-'+name,function(cells,np.zeros(n,np.int32),np.ones(n,np.int32),inputs));rows.append(dict(backend=name,density_choice=choice,fresh_density=density[name]['fresh_density'].tolist(),snow_thickness=got['cells'][:,:,2].tolist()))
    cp.cuda.runtime.deviceSynchronize();jax.effects_barrier()
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
d=dict(failure=failure,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=manifest,original_input_sha256=sha(input),rows=rows,seconds=time.monotonic()-start,device_barriers_complete=failure is None,output_sha256={p.name:sha(p) for p in sorted(r.glob('*.npz'))},scope='CurrentEC isolatedproductionfreshsnow and extensive-transfer operators only, originalK78forcing and originalexactcommonpreinterceptiongroundice/heat. Ownvscommondensity swap isolates potentialgeometry source; no failedyear resume/wholecolumn/NumPyforward, no originalgates relaxed, no rootcause/acceptance claim before independentEHPC analysis.')
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0 if failure is None and d['source_unchanged'] else 1)

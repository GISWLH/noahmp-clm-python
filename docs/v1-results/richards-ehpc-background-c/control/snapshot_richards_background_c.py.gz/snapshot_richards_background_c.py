from pathlib import Path
import datetime,hashlib,io,json,subprocess,sys,tarfile
mode=sys.argv[1];assert mode in ('cpu','gpu');data={}
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only live pending/actual-exit/source controls. Richards538R-B actualCPU21 is a separate newprototype, noRichardsnative/column/year claim. Queuedcapacity535C andcore532F remain distinct from year519H and older511/518/519 full suites. Snapshot is not test/year/spinup/science acceptance; no worker stopped or restarted.')
def add(path,name):
    if path.exists():data[name]=path.read_bytes()
if mode=='cpu':
    b=Path('/home/zhangyq/noahmp-v1');name='richards-ehpc-background-c'
    record['qstat']=subprocess.run(['qstat','-u','zhangyq'],capture_output=True,text=True).stdout
    for folder in ['capacity-station-cpu-c','qia-capacity-firstday-d','qia-capacity_optics-firstday-d','qia-kink-numpy-year-h','qia-runoff-partition-a','ctsm-runoff-partition-b','richards-numpy-b']:
        r=b/folder
        for filename in ['dispatch.json','package.json','SOURCE_SHA256.json','node.txt','controller.log','model.log','cpu-full.log','receipt.json','pbs-exit.txt','launch.json','config.json','trajectory/report.json']:
            add(r/filename,folder+'/'+filename)
    controls=['dispatch_capacity_station_cpu_c.py','run_capacity_station_cpu_c.py','capacity_station_cpu_c.pbs',
        'dispatch_qia_capacity_firstday_d.py','run_qia_capacity_firstday_d.py','qia_capacity_firstday_d.pbs']
else:
    b=Path('/home/lhwang/work/noahmp-v1');name='richards-xuanze-background-c'
    for folder in ['clm-capacity-final-f/full-bgc-f','clm-capacity-final-f/full-controller-f','capacity-station-final-c/target-c',
                   'qia1110-final-h/full-controller-h','p6-all-phase-final-b/full-controller-a','pft-optics-final-d/full-controller-e','qia-kink-cuda-year-h']:
        for filename in ['launch.json','worker.json','controller-worker.json','active-worker.json','controller.log','targets.log','wait.log','expected.json','receipt.json','exit.json','parent-exit.json','cpu-ready.json','model.log','trajectory/batch.json']:
            add(b/folder/filename,folder+'/'+filename)
    for folder in ['p6-all-phase-final-b/full-by-file-a','pft-optics-final-d/full-by-file-d','qia1110-final-h/full-by-file-h','clm-capacity-final-f/full-by-file-f']:
        for filename in ['progress.json','summary.json','selection.json']:add(b/folder/filename,folder+'/'+filename)
    record['ps']=subprocess.run(['ps','-p','3802989,3802990,3850155,3864455,3547743,3622193,3662728,3695324,3695325','-o','pid,stat,etime,pcpu,rss,args'],capture_output=True,text=True).stdout
    record['devices']=subprocess.run(['nvidia-smi','--query-gpu=index,memory.used,memory.free,utilization.gpu','--format=csv,noheader'],capture_output=True,text=True).stdout
    controls=['launch_capacity_canonical_f.py','wait_capacity_canonical_f.py','run_capacity_canonical_f.py','collect_capacity_canonical_f.py',
        'launch_capacity_station_target_c.py','wait_capacity_station_target_c.py','control_capacity_station_target_c.py','collect_capacity_station_target_c.py',
        'gpu-worker-lifecycle-a/run_pytest_worker_a.py']
    add(b/'capacity-station-final-c-source.tar.gz','source/capacity-station-final-c-source.tar.gz')
    add(b/'capacity-station-final-c-package.json','source/capacity-station-final-c-package.json')
for control in controls:add(b/control,'control/'+control)
add(Path(__file__),'control/'+Path(__file__).name)
data['snapshot.json']=(json.dumps(record,indent=2)+'\n').encode()
archive=b/(name+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for filename,raw in data.items():
        info=tarfile.TarInfo(filename);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,utc=record['utc'],scope=record['scope'])))

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'pft-optics-cpu-final-d';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());a=b/'pft-optics-final-d-source.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==518 and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')));xml=r/'cpu-full.xml';start=time.monotonic()
with (r/'cpu-full.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
tree=ET.parse(xml).getroot();counts={k:sum(int(x.attrib[k]) for x in tree.iter('testsuite')) for k in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==h for n,h in m.items())
d=dict(scope='Final518 PFToptics fullCPU exactoriginalpytest/solver/physicalhardgates;independentNumPy103 prerequisite. GPU351/fullcanonical1291/year/science not inferred.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,counts=counts,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,xml_sha256=sha(xml))
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert code==0 and unchanged and counts==dict(tests=940,failures=0,errors=0,skipped=0)

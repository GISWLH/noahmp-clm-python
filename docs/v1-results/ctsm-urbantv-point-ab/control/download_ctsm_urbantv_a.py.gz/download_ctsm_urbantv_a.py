from pathlib import Path
import datetime,hashlib,json,time,urllib.request

r=Path('/home/lhwang/work/noahmp-v1/ctsm-urbantv-input-a');r.mkdir(exist_ok=False)
name='CLM50_tbuildmax_Oleson_2016_0.9x1.25_simyr1849-2106_c160923.nc'
url='https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/lnd/clm2/urbandata/'+name
expected_etag='"16498//trunk/inputdata/lnd/clm2/urbandata/'+name+'"';expected_size=343955156
start=time.monotonic();failure=None;result=None;part=r/(name+'.part')
try:
 with urllib.request.urlopen(url,timeout=60) as response,part.open('xb') as target:
  assert response.status==200 and int(response.headers['Content-Length'])==expected_size
  assert response.headers['ETag']==expected_etag,response.headers['ETag']
  count=0;digest=hashlib.sha256();headers=dict(response.headers)
  while True:
   data=response.read(1024*1024)
   if not data:break
   target.write(data);digest.update(data);count+=len(data)
   assert count<=expected_size and time.monotonic()-start<600
 assert count==expected_size
 with part.open('rb') as f:signature=f.read(8)
 assert signature[:3]==b'CDF' or signature==b'\x89HDF\r\n\x1a\n'
 p=r/name;part.rename(p);result=dict(file=name,url=url,bytes=count,sha256=digest.hexdigest(),etag=expected_etag,headers=headers,signature_hex=signature.hex())
except Exception as e:failure=type(e).__name__+': '+str(e)
record=dict(scope='Original pinned public CTSM auxiliary runtime input required by unconditional UrbanTimeVar initialization even with forest-only PCT_URBAN=0. Dependency staging only,not urban model development or science pass. NetCDF content/runtime matching still needs EHPC compute-node inspection.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,failure=failure,result=result)
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if failure is None else 1)

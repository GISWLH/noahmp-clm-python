from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=b/'ctsm-urbantv-input-a';a=b/'ctsm-urbantv-point-ab-evidence.tar.gz';assert not a.exists();download=json.loads((old/'receipt.json').read_text());failed=json.loads((b/'ctsm-urbantv-point-a/selection.json').read_text());passed=json.loads((b/'ctsm-urbantv-point-b/selection.json').read_text());assert download['failure'] is not None and failed['failure'] is not None and passed['failure'] is None and sha(b/'ctsm-urbantv-point-b/selection.json')=='2f06147f8a9b6b07e0f3e261bf7170adea3c738cfa33c880c3b1fcf69bf50641';partial=next(old.glob('*.nc.part'));pids=b/'ctsm-urbantv-input-a-launch.json';pid=json.loads(pids.read_text())['pid'];assert not Path('/proc',str(pid)).exists()
with tarfile.open(a,'w:gz') as t:
 for r in [old,b/'ctsm-urbantv-point-a',b/'ctsm-urbantv-point-b']:
  for p in sorted(r.iterdir()):
   if p.is_file() and not p.name.endswith('.part'):t.add(p,arcname=r.name+'/'+p.name,recursive=False)
 for name in ['download_ctsm_urbantv_a.py','launch_ctsm_urbantv_a.py','select_ctsm_urbantv_point_a.py','select_ctsm_urbantv_point_b.py','inspect_ctsm_urbantv_header_a.py']:t.add(b/name,arcname='control/'+name,recursive=False)
 t.add(pids,arcname='control/'+pids.name,recursive=False);t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 summary=dict(scope='Original NCAR full download bounded614.658s failure and original Range request200/ignored retained. Public Sigma2 mirror supports validated206 ranges; header and selectedstatic bytes exactly equal actual NCAR prefix,not a full original-file SHA proof. Actual17 range responses and original selected values1999-2001 retained for forest-only zero-urban auxiliary dependency; no model/science acceptance.',original_partial_bytes=partial.stat().st_size,original_partial_sha256=sha(partial),successful_point_selection_sha256=sha(b/'ctsm-urbantv-point-b/selection.json'),selected_years=passed['result']['years'],source_url=passed['result']['source_url'],http_range_count=len(passed['result']['ranges']))
 data=(json.dumps(summary,indent=2)+'\n').encode();info=tarfile.TarInfo('summary.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,ranges=summary['http_range_count'])))

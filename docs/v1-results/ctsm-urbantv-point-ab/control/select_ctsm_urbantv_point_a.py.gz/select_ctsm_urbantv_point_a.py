from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime,hashlib,json,time,urllib.request
import numpy as np

b=Path('/home/lhwang/work/noahmp-v1');r=b/'ctsm-urbantv-point-a';r.mkdir(exist_ok=False);start=time.monotonic()
old=b/'ctsm-urbantv-input-a';h=json.loads((old/'header-inspection.json').read_text());variables={v['name']:v for v in h['variables']};part=next(old.glob('*.nc.part'))
config=json.loads((b/'qia-stem-device-day-a/inputs/CN-Qia-stem-config.json').read_text());lat,lon=config['latitude'],config['longitude'];ys=np.asarray(variables['lat']['values']);xs=np.asarray(variables['lon']['values']);distance=np.sin(np.deg2rad((ys[:,None]-lat)/2))**2+np.cos(np.deg2rad(ys[:,None]))*np.cos(np.deg2rad(lat))*np.sin(np.deg2rad((xs[None,:]-lon)/2))**2;iy,ix=map(int,np.unravel_index(distance.argmin(),distance.shape));flat=iy*len(xs)+ix
name='CLM50_tbuildmax_Oleson_2016_0.9x1.25_simyr1849-2106_c160923.nc';url='https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/lnd/clm2/urbandata/'+name;etag='"16498//trunk/inputdata/lnd/clm2/urbandata/'+name+'"';size=343955156;record_variables=[v for v in h['variables'] if v['shape'][0] is None];stride=sum(v['padded_bytes'] for v in record_variables);assert stride==1327132 and variables['time']['offset']+258*stride==size
records=[]
def fetch(item):
 label,offset,count=item;request=urllib.request.Request(url,headers={'Range':f'bytes={offset}-{offset+count-1}','If-Match':etag})
 with urllib.request.urlopen(request,timeout=30) as response:
  assert response.status==206 and response.headers['Content-Range']==f'bytes {offset}-{offset+count-1}/{size}',dict(response.headers)
  assert response.headers['ETag']==etag
  data=response.read(count+1);assert len(data)==count
 record=dict(label=label,offset=offset,bytes=count,sha256=hashlib.sha256(data).hexdigest(),headers=dict(response.headers))
 return label,data,record
failure=None;result=None
try:
 label,data,record=fetch(('header',0,65536));assert hashlib.sha256(data).hexdigest()==h['header_first64k_sha256'];records.append(record);(r/'header.bin').write_bytes(data)
 jobs=[]
 for year in [1999,2000,2001]:
  k=year-1849;jobs.append((f'{year}/clock',variables['time']['offset']+k*stride,28))
  for field in ['tbuildmax_TBD','tbuildmax_HD','tbuildmax_MD']:jobs.append((f'{year}/{field}',variables[field]['offset']+k*stride+flat*8,8))
 values={}
 with ThreadPoolExecutor(max_workers=4) as pool:
  for label,data,record in pool.map(fetch,jobs):
   records.append(record);target=r/(label.replace('/','-')+'.bin');target.write_bytes(data)
   year,key=label.split('/');v=values.setdefault(year,{})
   if key=='clock':
    v.update(time=float(np.frombuffer(data[:8],dtype='>f8')[0]),year=int(np.frombuffer(data[8:12],dtype='>i4')[0]),time_bnds=np.frombuffer(data[12:],dtype='>f8').tolist());assert v['year']==int(year)
   else:v[key]=float(np.frombuffer(data,dtype='>f8')[0]);assert np.isfinite(v[key])
 static={}
 for field in ['LATIXY','LONGXY','LANDMASK','area']:
  v=variables[field];offset=v['offset']+flat*v['item_bytes'];assert offset+v['item_bytes']<=part.stat().st_size
  with part.open('rb') as f:f.seek(offset);data=f.read(v['item_bytes'])
  static[field]=np.frombuffer(data,dtype=v['dtype'])[0].item();(r/(field+'.bin')).write_bytes(data)
 assert static['LATIXY']==ys[iy] and static['LONGXY']==xs[ix] and static['LANDMASK']==1 and static['area']>0
 result=dict(source_url=url,source_etag=etag,original_full_bytes=size,header_sha256=h['header_first64k_sha256'],record_stride_bytes=stride,site_latitude=lat,site_longitude=lon,nearest_indices=[iy,ix],latitude=float(ys[iy]),longitude=float(xs[ix]),static=static,years=values,variables={k:dict(attributes=v['attributes'],dtype=v['dtype']) for k,v in variables.items()},ranges=records)
except Exception as e:failure=type(e).__name__+': '+str(e)
v=dict(scope='Original official auxiliary stream nearest-point/year1999-2001 byte selection for forest-only Qia initialization; every HTTP Range must206 with exact Content-Range/ETag and header hash. No urban physics,met/soil/state change or science pass. Raw original whole-download attempt retained separately; selected NetCDF build/read still requires EHPC compute node.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,failure=failure,result=result,completed_ranges=records)
(r/'selection.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v[k] for k in ['scope','utc','seconds','failure']}),flush=True)
raise SystemExit(0 if failure is None else 1)

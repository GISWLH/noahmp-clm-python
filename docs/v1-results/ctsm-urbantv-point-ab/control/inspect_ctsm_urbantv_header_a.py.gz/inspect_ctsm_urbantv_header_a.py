from pathlib import Path
import hashlib,json
import numpy as np
from scipy.io import netcdf_file

p=Path('/home/lhwang/work/noahmp-v1/ctsm-urbantv-input-a/CLM50_tbuildmax_Oleson_2016_0.9x1.25_simyr1849-2106_c160923.nc.part')
class Header(netcdf_file):
 def _read_var_array(self):
  assert self.fp.read(4) in [b'\0'*4,b'\0\0\0\x0b']
  self.__dict__['header_variables']=[self._read_var() for _ in range(self._unpack_int())]
def serial(v):
 if isinstance(v,bytes):return v.decode('latin1')
 if isinstance(v,np.ndarray):return v.tolist()
 if isinstance(v,np.generic):return v.item()
 raise TypeError(type(v).__name__)
with Header(p,mmap=False) as d:
 rows=[]
 for v in d.header_variables:
  name,dims,shape,attrs,typecode,size,dtype,begin,vsize=v
  row=dict(name=name,dimensions=dims,shape=shape,attributes=attrs,typecode=typecode,item_bytes=size,dtype=dtype,offset=begin,padded_bytes=vsize)
  if name in ['lat','lon','time'] and None not in shape and begin+int(np.prod(shape))*size<=p.stat().st_size:
   with p.open('rb') as f:f.seek(begin);row['values']=np.frombuffer(f.read(int(np.prod(shape))*size),dtype=dtype).tolist()
  rows.append(row)
 record=dict(scope='Read original fixed NetCDF3 header and already downloaded coordinate bytes only; incomplete download is not a complete input or science result.',partial_bytes=p.stat().st_size,header_first64k_sha256=hashlib.sha256(p.read_bytes()[:65536]).hexdigest(),version=int(d.version_byte),dimensions=d.dimensions,record_count=d._recs,variables=rows)
out=p.parent/'header-inspection.json';assert not out.exists();out.write_text(json.dumps(record,indent=2,default=serial)+'\n');print(json.dumps(record,default=serial))

from pathlib import Path
import datetime,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');log=b/'ctsm-urbantv-input-a-download.log';assert not log.exists() and not (b/'ctsm-urbantv-input-a').exists()
with log.open('x') as f:p=subprocess.Popen([sys.executable,'-u',str(b/'download_ctsm_urbantv_a.py')],cwd=b,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Own detached bounded official auxiliary-input download,not a physics/GPU test. Forest reference urban area remains0.');(b/'ctsm-urbantv-input-a-launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

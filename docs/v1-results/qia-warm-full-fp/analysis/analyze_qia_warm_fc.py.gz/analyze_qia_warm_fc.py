"""Analyse a prospectively fixed first48 or complete336, never rerun physics."""
from pathlib import Path
import gzip,hashlib,json,os,pickle,sys,tarfile,time
import numpy as np

assert os.environ.get('PBS_JOBID')
stage=sys.argv[1];assert stage in ('first48','all336')
b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-warm-analysis-fc' if stage=='first48' else 'qia-warm-analysis-fd');source=b/'qia-warm-diagnostic-fb'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=Path(os.environ['TMPDIR'])/'source';s.mkdir();archive=b/'clm-phase-descent-ec-source.tar.gz'
assert sha(archive)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json')
assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
protocol=json.loads((source/'protocol.json').read_text());assert protocol['source_manifest_sha256']==manifest and protocol['configuration_sha256']=='e203ec68860933d0c57b92dd5fd4f719313c1237905d40cefd0e9393cd0b174c'
files=[source/'captured-first48'/('call-'+str(k).zfill(5)+'.pkl.gz') for k in range(48)]
assert all(p.is_file() for p in files),'No partial-day or selected timestamps'
rows=[];soil_rows=[];inventory=[];ground_resistance=[];air_resistance=[];gs=[];leaf_t=[];initial=None
for k,p in enumerate(files):
    raw=p.read_bytes();inventory.append(dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest()))
    packet=pickle.loads(gzip.decompress(raw));d=packet['diagnostics'];before=packet['before'];f=packet['forcing'];sf=packet['surface_input'];ground=sf['args'][1];boundary=sf['args'][6];dt=f.dt
    assert dt==1800. and not len(sf['args'][0].mass)
    if initial is None:
        initial=dict(liquid_theta=(before.ground.liquid/(1000.*before.ground.dz)).tolist(),soil_temperature_k=before.ground.temperature.tolist(),root_fractions=before.root_frac.tolist(),soil_parameters=vars(before.ground.params),options=vars(before.options),forcing=vars(f))
    wet=float(np.asarray(d['vapor_parcels']['latent_energy_jm2']).sum()/dt);trans=float(2.5e6*np.asarray(d['transpiration']).sum());bare=float(d['ground_latent_energy_jm2']/dt)
    wm=float(np.asarray(d['wet_evaporation']).sum()*dt);tm=float(np.asarray(d['transpiration']).sum()*dt);gm=float(d['ground_evaporation']*dt)
    beta=np.clip((ground.liquid/(1000.*ground.dz)-ground.params.smcwlt)/(ground.params.smcref-ground.params.smcwlt),0.,1.)
    root_beta=float(beta@before.root_frac);assert abs(root_beta-float(sf['kwargs']['water_stress']))<1e-12
    soil_rows.append(np.r_[ground.liquid/(1000.*ground.dz),ground.temperature,beta])
    rows.append([float(d['le']),wet,trans,bare,float(d['et_kgm2']),wm,tm,gm,float(sf['kwargs']['water_stress']),float(d['biogeochemistry']['nitrogen_factor_used']),float(d['biogeochemistry']['lai_used']),float(d['gpp_gc_m2']),float(d['nee_gc_m2']),float(d['h']),wet+trans+bare-float(d['le']),wm+tm+gm-float(d['et_kgm2']),f.swdown,f.prcp])
    ground_resistance.append(boundary.ground_resistance);air_resistance.append(1./boundary.water_velocity);gs.append(np.asarray(d['gas_exchange']['gs_mol']));leaf_t.append(np.asarray(d['leaf_temperature']))
columns=['total_LE_Wm2','wet_LE_Wm2_DIRECT','transpiration_LE_Wm2_DIRECT','ground_LE_Wm2_DIRECT','et_mm','wet_mass_mm','transpiration_mass_mm','ground_mass_mm','actual_water_stress','actual_leaf_N_factor','actual_LAI_used','gpp_gc_m2_interval','nee_gc_m2_interval','H_Wm2','component_LE_join_Wm2','component_ET_join_mm','incoming_shortwave_Wm2','precipitation_ms']
values=np.asarray(rows);soil_rows=np.asarray(soil_rows)
assert np.max(abs(values[:,14]))<1e-9 and np.max(abs(values[:,15]))<1e-12
def summarize(a,names):
    return {name:dict(minimum=float(a[:,k].min()),maximum=float(a[:,k].max()),mean=float(a[:,k].mean()),sum=float(a[:,k].sum())) for k,name in enumerate(names)}
first48=summarize(values,columns);np.savez_compressed(r/'first48-components.npz',values=values,soil_liquid_theta_temperature_and_layer_beta=soil_rows,stomatal_conductance_mol_m2s=np.asarray(gs),leaf_temperature_k=np.asarray(leaf_t),ground_resistance_sm=np.asarray(ground_resistance),atmospheric_water_resistance_sm=np.asarray(air_resistance))
whole=None;parents={}
if stage=='all336':
    receipt=json.loads((source/'receipt.json').read_text());report=json.loads((source/'trajectory/report.json').read_text());parents=dict(receipt_sha256=sha(source/'receipt.json'),report_sha256=sha(source/'trajectory/report.json'),pbs_exit=(source/'pbs-exit.txt').read_text().strip())
    assert parents['pbs_exit']=='0' and receipt['failure'] is None and receipt['source_unchanged'] and receipt['calls']==336 and receipt['first48_capture_files']==48 and report['steps_completed']==report['steps_requested']==336 and report['status']=='complete'
    assert receipt['component_columns']==columns[:16]
    with np.load(source/'components.npz',allow_pickle=False) as z:allvalues=z['values'].copy();stamps=z['time_start'].copy();ends=z['time_end'].copy()
    assert allvalues.shape==(336,16) and np.array_equal(allvalues[:48],values[:,:16])
    assert np.max(abs(allvalues[:,14]))<1e-9 and np.max(abs(allvalues[:,15]))<1e-12
    whole=dict(time_start=str(stamps[0]),time_end=str(ends[-1]),all336=summarize(allvalues,columns[:16]),days_fixed_since_original_start=[])
    for day in range(7):whole['days_fixed_since_original_start'].append(dict(index=day,time_start=str(stamps[day*48]),time_end=str(ends[(day+1)*48-1]),stats=summarize(allvalues[day*48:(day+1)*48],columns[:16])))
    assert sha(source/'trajectory'/report['model_npz'])==report['model_npz_sha256']
    whole['all_originalBO_trace_fields']=receipt['all_originalBO_trace_fields'];whole['observations_sha256']=sha(source/'observations.json')
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stage=stage,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_protocol_sha256=sha(source/'protocol.json'),initial=initial,first48=first48,whole=whole,parents=parents,packet_inventory=inventory,first48_ground_resistance_sm=dict(minimum=min(ground_resistance),maximum=max(ground_resistance)),scope='Directactual LE/ET partition and actualroot/N stress of prospectivelyfixed originalQia warmbaseline. Allfirst48 full24h, or all336 originalseven-day run includingeveryday, no dates/heights/parameters fit orcounterfactualphysics, no source/gatechanges. Completeanalysis exit0 is not scientificacceptance or spinup/year/multisite proof.')
(r/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
assert result['source_unchanged']
print(json.dumps(dict(pbs_job=result['pbs_job'],stage=stage,first48=first48,whole=None if whole is None else {k:v for k,v in whole.items() if k not in ('days_fixed_since_original_start','all_originalBO_trace_fields')})),flush=True)

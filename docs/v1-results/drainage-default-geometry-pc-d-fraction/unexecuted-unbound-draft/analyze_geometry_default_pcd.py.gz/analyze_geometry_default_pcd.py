"""EHPC-only exact Fraction/RNE audit of one closed PC-d candidate packet."""
import argparse
from fractions import Fraction
import io
import json
import math
import os
from pathlib import Path
import pickle
import socket
import struct
import tarfile

import numpy as np
from exact_geometry_core import operation,round_binary32,sha,verify_rounding

HERE=Path(__file__).resolve().parent

def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        result={}
        for member in archive:
            if member.isdir():continue
            name=member.name.removeprefix('./')
            assert member.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts and name not in result
            result[name]=archive.extractfile(member).read()
        return result

def safe(value):
    if isinstance(value,float) and not math.isfinite(value):
        return dict(nonfinite='NaN' if math.isnan(value) else ('+Inf' if value>0 else '-Inf'))
    if isinstance(value,dict):return {key:safe(v) for key,v in value.items()}
    if isinstance(value,(tuple,list)):return [safe(v) for v in value]
    return value

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,required=True);p.add_argument('--input-sha256',required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes())
    # Deliberately not launchable until the actual closed GPU archive is bound.
    assert isinstance(binding['actual_GPU_result_sha256'],str) and len(binding['actual_GPU_result_sha256'])==64
    assert a.input_sha256==binding['actual_GPU_result_sha256']
    controls=json.loads((HERE/'CONTROLS_SHA256.json').read_bytes())
    assert all(sha((HERE/name).read_bytes())==value for name,value in controls.items())
    raw=a.input.read_bytes();assert sha(raw)==a.input_sha256;data=unpack(raw)
    meta=json.loads(data['cuda/device/result.json']);capture=json.loads(data['cuda/device/capture-receipt.json'])
    packet=data['cuda/device/result.npz'];assert sha(packet)==meta['npz_sha256']
    with np.load(io.BytesIO(packet),allow_pickle=False) as store:values={name:store[name].copy() for name in store.files}
    assert set(values)==set(meta['arrays'])
    for name,value in values.items():
        desc=meta['arrays'][name]
        assert (value.dtype.str,list(value.shape),sha(value.tobytes()))==(desc['dtype'],desc['shape'],desc['c_order_sha256'])
    cells=values['input.phase_cells'];parameters=values['input.parameters'];candidate=values['candidate.components']
    previous=values['context.components'];count=len(binding['groups'])
    assert count==10 and cells.shape==(count,4,6) and parameters.shape==(count,12) and candidate.shape==previous.shape==(count,4,9)
    assert all(v.dtype==np.float32 for v in (cells,parameters,candidate,previous))
    assert capture['source_manifest_sha256']==binding['source_manifest_sha256'] and capture['controls_manifest_sha256']==binding['device_preparation_manifest_sha256']
    assert capture['source_controls_prior_unchanged'] and capture['gpu_uuid']==binding['gpu_uuid']
    assert meta['own_process_GPU_UUIDs'] and set(meta['own_process_GPU_UUIDs'])=={binding['gpu_uuid']}
    assert meta['compiled']['candidate']['source_sha256']==binding['candidate_code_sha256']
    assert meta['compiled']['RN']['source_sha256']==binding['RN_code_sha256']
    for kind in ('candidate','RN'):
        assert sha(data['cuda/device/compiler/'+kind+'-ACTUAL-LOADED.cubin'])==meta['compiled'][kind]['actual_loaded_cubin_sha256']
    assert tuple(meta['actual_compile_options'])==tuple(capture['actual_compile_options']) and '--ftz=false' in meta['actual_compile_options']
    assert capture['candidate_kernel_attempted']==capture['candidate_kernel_returned']==capture['RN_kernel_attempted']==capture['RN_kernel_returned']==1
    assert capture['CPU_physical_reference_calls']==capture['model_calls']==capture['phase_calls']==0
    assert not capture['JAX_imported'] and not capture['default_JAX_flags_changed'] and not capture['production_source_patch_applied']
    original_inputs_exact=[]
    for group,original in enumerate(binding['original_payloads']):
        for key in ('input.phase_cells','input.parameters','context.components'):
            actual=values[key][group:group+1];desc=original['arrays'][key]
            assert actual.dtype.str==desc['dtype'] and list(actual.shape)==desc['shape'] and sha(actual.tobytes())==desc['c_order_sha256']
        original_inputs_exact.append(True)
    cwords=cells.view(np.uint32);pwords=parameters.view(np.uint32);observed=candidate.view(np.uint32)
    for group,case in enumerate(binding['boundary_cases'],4):
        declared=[int(word,16) for word in case['primitive_words']]
        assert all(list(map(int,cwords[group,layer,:3]))==declared[:3] for layer in range(4)) and int(pwords[group,0])==declared[3]
    assert np.array_equal(values['candidate.candidate_bits'],observed) and np.array_equal(values['RN.observed_bits'],observed)
    assert np.array_equal(values['candidate.previous_equal'][:4],(observed[:4]==previous[:4].view(np.uint32)).astype(np.uint32))
    assert np.all(values['candidate.previous_equal'][4:]==2)
    checks=verify_rounding();thousand=round_binary32(Fraction(1000));density=round_binary32(Fraction(917));rows=[]
    all_reference_bits_consistent=True;all_exact_references_eligible=True
    for group,spec in enumerate(binding['groups']):
        layers=[]
        for layer in range(4):
            liquid,ice,dz=map(int,cwords[group,layer,:3]);porosity=int(pwords[group,0]);history=[];operations=[]
            actual=list(map(int,observed[group,layer]))
            def operands(index,h):
                future=h+[None]*(9-len(h))
                return (('div',liquid,thousand),('div',ice,density),('add',future[0],future[1]),
                    ('mul',dz,porosity),('div',future[2],future[3]),('mul',density,dz),
                    ('mul',future[5],porosity),('div',ice,future[6]),('min1',future[7],0x3f800000))[index]
            def exact(index,h):
                op,left,right=operands(index,h)
                if left is None or right is None:return dict(eligible=False,reason='Earlier exact reference was ineligible',bits=None)
                try:
                    bits,real=operation(op,left,right)
                    return dict(eligible=True,bits=bits,exact_operation=real,operand_bits=[f'0x{left:08x}',f'0x{right:08x}'])
                except (ValueError,OverflowError) as error:
                    return dict(eligible=False,reason=str(error),bits=None,operand_bits=[f'0x{left:08x}',f'0x{right:08x}'])
            for index,field in enumerate(binding['component_fields']):
                strict=exact(index,history);own=exact(index,actual);history.append(strict['bits'])
                refs={};eligible=strict['eligible'] and own['eligible'];all_exact_references_eligible=all_exact_references_eligible and eligible
                for label,result,key,flagkey in (('strict',strict,'RN.strict_rn_bits','RN.strict_equal'),('own_operands',own,'RN.actual_operand_rn_bits','RN.actual_operand_equal')):
                    gpu_bits=int(values[key][group,layer,index]);gpu_flag=int(values[flagkey][group,layer,index])
                    if result['eligible']:
                        bit_match=gpu_bits==result['bits'];flag_match=gpu_flag==int(actual[index]==result['bits'])
                        all_reference_bits_consistent=all_reference_bits_consistent and bit_match and flag_match
                    else:bit_match=flag_match=None
                    refs[label]=dict(**result,GPU_reference_bits=f'0x{gpu_bits:08x}',GPU_equal_flag=gpu_flag,
                        hardware_reference_matches_exact=bit_match,hardware_flag_matches_exact=flag_match,
                        candidate_matches_RN=(actual[index]==result['bits']) if result['eligible'] else None)
                operations.append(dict(field=field,actual_bits=f'0x{actual[index]:08x}',actual_value=struct.unpack('<f',struct.pack('<I',actual[index]))[0],references=refs))
            layers.append(dict(layer=layer,operations=operations))
        rows.append(dict(group=spec,layers=layers))
    context=bool(np.all(observed[:4]==previous[:4].view(np.uint32))) and meta['original_context_reproduced']
    valid=bool(meta['all_primitive_inputs_valid'] and meta['all_constants_RN_checked'] and meta['all_candidate_outputs_finite'] and meta['all_RN_recorded_domains_valid'])
    passed=bool(capture['capture_completed'] and context and valid and all_reference_bits_consistent and all_exact_references_eligible)
    report=dict(completed=True,passed=passed,pbs_job=os.environ['PBS_JOBID'],actual_GPU_result_sha256=sha(raw),
        source_manifest_sha256=binding['source_manifest_sha256'],original_inputs_exact=original_inputs_exact,
        original_context_reproduction_passed=context,all_GPU_delivery_domains_valid=valid,original_GPU_capture_completed=capture['capture_completed'],
        Fraction_reference_selftests=checks,all_eligible_hardware_RN_bits_flags_consistent=all_reference_bits_consistent,
        all_exact_references_eligible=all_exact_references_eligible,candidate_RN_equality_required=False,
        physical_forward_calls=0,GPU_calls=0,rows=rows,
        scope='Existing closed candidate bits only. Exact Fraction/integer real operations plus explicit binary32 RNE validate hardware references, not demand candidate RN equality. Full module1e-6/integer/P0/hard-ledger/NumPy64/32 acceptance remains separate and unchanged. Nonfinite diagnostic values are preserved/tagged; no new divider or fallback.')
    with a.output.with_suffix('.pickle').open('xb') as out:pickle.dump(dict(report=report,original_arrays=values,metadata=meta,capture=capture),out,protocol=5)
    a.output.write_text(json.dumps(safe(report),indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(completed=True,passed=passed,original_context_reproduction_passed=context,all_exact_references_eligible=all_exact_references_eligible,
        all_eligible_hardware_RN_bits_flags_consistent=all_reference_bits_consistent,candidate_RN_equality_required=False,physical_forward_calls=0,GPU_calls=0)))
    return 0 if passed else 1

if __name__=='__main__':raise SystemExit(main())

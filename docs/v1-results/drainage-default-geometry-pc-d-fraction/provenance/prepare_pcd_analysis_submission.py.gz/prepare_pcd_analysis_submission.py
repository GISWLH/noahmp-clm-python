"""Mechanical approved analysis uploader binding; no command execution here."""
from pathlib import Path

base=Path(__file__).resolve().parent
old=(base/'deploy_drainage_geometry_pbv_analysis.py').read_text()
new=old.replace('drainage-geometry-pb-v-analysis','drainage-default-geometry-pc-d-analysis')
new=new.replace('dispatch_geometry_pbv_analysis.py','dispatch_geometry_pcd_analysis.py')
new=new.replace('86c9b8a2a1884ba4e4b6f571f0d2ba0ec1f1386cc0887efb779fc31b5c4928ed','931a8a2841d055bb8ead45fb06e8edb1c30625de491a65bf5ebd5186e655a114')
target=base/'deploy_geometry_default_pcd_analysis.py';assert not target.exists()
target.write_text(new,encoding='utf-8',newline='\n')

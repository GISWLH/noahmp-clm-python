"""One authorized comparison PBS submission; raw command exits preserved."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'drainage-default-geometry-pc-d-analysis-stage.tar.gz'
expected='931a8a2841d055bb8ead45fb06e8edb1c30625de491a65bf5ebd5186e655a114'
assert sha(stage.read_bytes())==expected
target=BASE/'drainage-default-geometry-pc-d-analysis-deployment.json'
assert not target.exists()
dispatcher=BASE/'drainage-default-geometry-pc-d-analysis-execution/dispatch_compare_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',
    'test ! -e /tmp/noahmp-drainage-default-geometry-pc-d-analysis && test ! -e /tmp/noahmp-drainage-default-geometry-pc-d-analysis-stage.tar.gz && test ! -e /tmp/dispatch_geometry_pcd_analysis.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'ehpc:/tmp/noahmp-drainage-default-geometry-pc-d-analysis-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(dispatcher),'ehpc:/tmp/dispatch_geometry_pcd_analysis.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',
     '/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_geometry_pcd_analysis.py --archive /tmp/noahmp-drainage-default-geometry-pc-d-analysis-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_submit=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('drainage-default-geometry-pc-d-analysis-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('drainage-default-geometry-pc-d-analysis-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['dispatch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['dispatch']))

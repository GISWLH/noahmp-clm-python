"""Freeze actual-result-bound Fraction audit stage for root review, no submission."""
from pathlib import Path
import ast
import difflib
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
OLD=BASE/'drainage-default-geometry-pc-d-analysis-preparation'
PREP=BASE/'drainage-default-geometry-pc-d-analysis-preparation-b'
EXEC=BASE/'drainage-default-geometry-pc-d-analysis-execution'
LABEL='drainage-default-geometry-pc-d-analysis'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def main():
    assert not PREP.exists() and not EXEC.exists();PREP.mkdir();EXEC.mkdir()
    assert sha((OLD/'CONTROLS_SHA256.json').read_bytes())=='555cc8086c4eb257ffbdd66ef83a12d26c0d0a7ba7a96918bd76492657d61c5f'
    gpu=(BASE/'drainage-default-geometry-pc-d-gpu-closed/gpu-result.tar.gz').read_bytes()
    actual='8cb523d79eeb201096f5256b977e35ebfb7d51cc6c4686a728831400a7f30efc';assert sha(gpu)==actual
    binding=json.loads((OLD/'BINDINGS.json').read_bytes());binding.update(actual_GPU_result_sha256=actual,launchable=True,
        freeze_state='Actual closed GPU archive bound; root execution authorization pending',prepared_only=True,execution_authorization_pending=True)
    (PREP/'BINDINGS.json').write_bytes(encode(binding));(PREP/'exact_geometry_core.py').write_bytes((OLD/'exact_geometry_core.py').read_bytes())
    before=(OLD/'analyze_geometry_default_pcd.py').read_text();after=before
    after=after.replace("meta=json.loads(data['cuda/device/result.json']);capture=json.loads(data['cuda/device/capture-receipt.json'])", "meta=json.loads(data['cuda/device/result.json']);capture=json.loads(data['cuda/device/capture-receipt.json'])\n    assert meta['groups']==binding['groups']")
    after=after.replace("checks=verify_rounding();thousand=round_binary32(Fraction(1000));density=round_binary32(Fraction(917));rows=[]", "checks=verify_rounding();thousand=round_binary32(Fraction(1000));density=round_binary32(Fraction(917));rows=[]\n    inverse1000,_=operation('div',0x3f800000,thousand);inverse917,_=operation('div',0x3f800000,density)\n    expected_constants=np.asarray([inverse1000,inverse1000,inverse917,inverse917],np.uint32)\n    constants_exactly_verified=bool(np.all(values['candidate.constant_bits']==expected_constants) and np.all(values['candidate.constant_equal']==1))")
    after=after.replace("passed=bool(capture['capture_completed'] and context and valid and all_reference_bits_consistent and all_exact_references_eligible)", "controls_after_exact=all(sha((HERE/name).read_bytes())==value for name,value in controls.items())\n    input_after_exact=sha(a.input.read_bytes())==a.input_sha256\n    passed=bool(capture['capture_completed'] and context and valid and constants_exactly_verified and controls_after_exact and input_after_exact and all_reference_bits_consistent and all_exact_references_eligible)")
    after=after.replace("Fraction_reference_selftests=checks,all_eligible_hardware_RN_bits_flags_consistent=all_reference_bits_consistent,", "Fraction_reference_selftests=checks,constants_exactly_verified=constants_exactly_verified,\n        controls_after_exact=controls_after_exact,input_after_exact=input_after_exact,\n        all_eligible_hardware_RN_bits_flags_consistent=all_reference_bits_consistent,")
    ast.parse(after);(PREP/'analyze_geometry_default_pcd.py').write_text(after,encoding='utf-8',newline='\n')
    (PREP/'UNBOUND_TO_BOUND.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='unbound/analyze_geometry_default_pcd.py',tofile='bound/analyze_geometry_default_pcd.py')),encoding='utf-8',newline='\n')
    (PREP/'README.md').write_text('''# PC-d exact Fraction analysis — actual hash bound, prepared only

Exactly one planned EHPC PBS compute0021CPU/2GiB/5min audit,0model/GPU/replay. Closed PC-d raw GPU-result SHA8cb523d7…f30efc is now frozen. Parent/worker0 and all3PIDgone evidence remain separate original GPU evidence; no device rerun is part of this stage. Root must read/authorize before unique submission.

The previous unbound555cc…preparation is preserved unexecuted. This bound version keeps the executed1845 Fraction/integer-RNE core byte-identical, binds the actual GPU packet, checks its groups and independently verifies both actual HLO reciprocal-literal bits and hardware RN reciprocal bits against exact Fraction1/rho. It also checks controls/input bytes again after analysis; UNBOUND_TO_BOUND.diff makes these additions explicit.

All original4 input contexts/6boundary words/source/UUID/actualCUBIN/typedNPZ payloads are checked. Every strict-chain and own-operand exact reference is compared with existing GPU hardware-RN bits/flags. Candidate non-RN values remain descriptive: RN equality is not required, while invalid context/domain or reference inconsistency returns1 with all raw evidence retained. Complete original arrays/report are saved in pickle before strict JSON; no pickle is loaded, no nonfinite is replaced with zero. Original physical1e-6/integer/P0/hard-ledger and independent NumPy64/32 gates remain unchanged; this diagnostic gives no full-module/production pass.
''',encoding='utf-8',newline='\n')
    (PREP/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file()}))
    oldexec=BASE/'drainage-geometry-pb-v-analysis-execution';diff=[]
    for name in ('check_stage_pbs.py','compare_pbs.pbs','dispatch_compare_pbs.py'):
        initial=(oldexec/name).read_text();updated=initial.replace('noahmp-drainage-geometry-pb-v-analysis','noahmp-drainage-default-geometry-pc-d-analysis')
        updated=updated.replace('dispatch_geometry_pbv_analysis.py','dispatch_geometry_pcd_analysis.py')
        updated=updated.replace('drainage-geom-pbv-ref','drainage-geompccd-ref').replace('geometry-analysis-result','geometry-default-analysis-result')
        updated=updated.replace('analyze_geometry_exact_pbv_b.py','analyze_geometry_default_pcd.py')
        updated=updated.replace('f5221539e4ab7371171b1b67e4b488317e5157d62ddec002dd3d6792e0b6c9b9',actual)
        if name.endswith('.py'):ast.parse(updated)
        (EXEC/name).write_text(updated,encoding='utf-8',newline='\n')
        diff.extend(difflib.unified_diff(initial.splitlines(True),updated.splitlines(True),fromfile='PB-v/'+name,tofile='PC-d/'+name))
    (EXEC/'PBV_TO_PCD.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
    (EXEC/'README.md').write_text('Prepared-only unique existing-output analysis; original1CPU2GiB5mincompute002 transfer/hash/PBSbefore-after checks. Actual input8cb5… is bound. No submission until root reads code and frozen stage. No GPU/model/reference replay.\n',encoding='utf-8',newline='\n')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}))
    items={prefix+'/'+p.name:p.read_bytes() for root,prefix in ((PREP,'preparation'),(EXEC,'execution')) for p in root.iterdir() if p.is_file()}
    items['gpu-result.tar.gz']=gpu;items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,raw in sorted(items.items()):
                m=tarfile.TarInfo(name);m.size=len(raw);m.mode=0o644;tar.addfile(m,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    report=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),bytes=target.stat().st_size,stage_files=len(items),
        preparation_manifest_sha256=sha(items['preparation/CONTROLS_SHA256.json']),execution_manifest_sha256=sha(items['execution/CONTROLS_SHA256.json']),
        actual_GPU_result_sha256=actual,prepared_only=True,submitted=False,numerical_executed=False,resources='1CPU/2GiB/5min/compute002',physical_forward_calls=0,GPU_calls=0)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(report));print(json.dumps(report))

if __name__=='__main__':main()

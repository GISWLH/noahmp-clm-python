"""Readonly PBS server/node capability check; scheduler owns allocation."""
from pathlib import Path
import hashlib
import json
import subprocess

base=Path(__file__).resolve().parent/'drainage-default-geometry-pc-d-analysis-preflight'
assert not base.exists();base.mkdir()
data={}
for label,query in (('server','qstat -Bf'),('nodes','pbsnodes -av')):
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',query]
    r=subprocess.run(command,capture_output=True,timeout=35)
    (base/(label+'.stdout')).write_bytes(r.stdout);(base/(label+'.stderr')).write_bytes(r.stderr)
    (base/(label+'-exit.json')).write_text(json.dumps(dict(command=command,actual_exit=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()),indent=2)+'\n')
    assert r.returncode==0,r.stderr.decode(errors='replace');data[label]=r.stdout.decode()
assert 'server_state = Active' in data['server'] and 'scheduling = True' in data['server']
sections=[s for s in data['nodes'].split('\n\n') if s.startswith('compute002\n')]
assert len(sections)==1 and 'resources_available.ncpus = ' in sections[0]
assert 'state = down' not in sections[0] and 'state = offline' not in sections[0]
report=dict(actual_exits=[0,0],server_Active=True,scheduling=True,target_compute002_registered=True,not_down_or_offline=True,
    requested_resources='1CPU/2GiB/5min',allocation_enforced_by_PBS=True,numerical_calls=0)
(base/'readout.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

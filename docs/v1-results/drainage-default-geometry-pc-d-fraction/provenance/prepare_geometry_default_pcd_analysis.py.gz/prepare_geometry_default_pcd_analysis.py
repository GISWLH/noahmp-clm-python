"""Prepare review-only analysis code; actual GPU hash remains mandatory/unset."""
from pathlib import Path
import ast
import json
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
DEST=BASE/'drainage-default-geometry-pc-d-analysis-preparation'
assert not DEST.exists();DEST.mkdir()
device=BASE/'drainage-default-geometry-pc-d-preparation'
binding=json.loads((device/'BINDINGS.json').read_bytes())
prior=files((BASE/'drainage-geometry-pb-v-gpu-closed/gpu-result.tar.gz').read_bytes())
original=[json.loads(prior['jax/device/'+case+'/result.json']) for case in binding['original_cases']]
core=(BASE/'drainage-geometry-pb-v-analysis-preparation/analyze_geometry_exact_pbv_b.py').read_bytes()
assert sha(core)=='180f1b0a35c4daee300ec32c16fc51ba0d44547685f66888cf5cfab056b7f209'
worker=(BASE/'analyze_geometry_default_pcd.py').read_bytes();ast.parse(worker)
(DEST/'exact_geometry_core.py').write_bytes(core);(DEST/'analyze_geometry_default_pcd.py').write_bytes(worker)
plan=dict(actual_GPU_result_sha256=None,launchable=False,freeze_state='Waiting actual closed GPU archive, unique result SHA and root-reviewed execution stage',
    device_stage_sha256='82f9e26f5868780319c608701a9fee2d5ced96288b9a184777e1f47c9257c7d8',
    device_preparation_manifest_sha256=sha((device/'CONTROLS_SHA256.json').read_bytes()),source_manifest_sha256=binding['source_manifest_sha256'],
    gpu_uuid='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',original_payloads=original,
    boundary_cases=binding['boundary_cases'],groups=[dict(kind='original-default-JAX',case=case) for case in binding['original_cases']]+[dict(kind='primitive-boundary',**case) for case in binding['boundary_cases']],
    component_fields=binding['component_fields'],RN_code_sha256=binding['original_RN_kernel_sha256'],
    candidate_code_sha256=sha((device/'geometry_default_pcd.cuh').read_bytes()+b'\n'+(device/'geometry_default_pcd_probe.cu').read_bytes()),
    original_1845_exact_core_sha256=sha(core),planned_resources='EHPC PBS compute002 1CPU/2GiB/5min',model_calls=0,GPU_calls=0)
(DEST/'BINDINGS.json').write_text(json.dumps(plan,indent=2,allow_nan=False)+'\n')
(DEST/'README.md').write_text('''# PC-d candidate Fraction analysis — review-only, not launchable

Existing raw PC-d GPU outputs only; no replay, model, GPU or production change. Planned unique EHPC PBS compute0021CPU/2GiB/5min. The actual closed GPU-result SHA is deliberately null, and the worker refuses to run until it is bound into a new reviewed frozen execution stage. Current SSH preflights have failed before deployment; this preparation does not invent an input/result hash or launch a job.

The exact Fraction/integer IEEE binary32 nearest-even core is copied byte-for-byte from the original executed1845 analysis. Its halfway/subnormal/signed-zero/overflow checks run only inside the future PBS compute job. Inputs/outputs and all original GPU uint32 bits/flags are SHA/schema/source/UUID/actual-CUBIN bound; four original typed input contexts must match their prior payloads, six boundary bit encodings are checked. No pickle is loaded; an opaque complete raw pickle is saved for independent retention before strict allow_nan=False JSON.

Each9-step strict chain and actual-candidate-operand reference is computed exactly. The analyzer independently checks existing GPU hardware-RN reference bits and equality flags, while candidate non-RN results remain descriptive and are never turned into a new RN requirement. Nonfinite or zero-denominator/ineligible operands remain explicit records, never substituted with zero or accepted by widened tolerances. GPU capture failure, invalid context/domain, incomplete reference eligibility or inconsistency yields actual exit1 while retaining the analysis. Original module1e-6/integer/P0/hard-ledger gates and NumPy64/32 independent references are unchanged; no full-module pass follows from this diagnostic.
''',encoding='utf-8',newline='\n')
(DEST/'CONTROLS_SHA256.json').write_text(json.dumps({p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()},indent=2)+'\n')
print(json.dumps(dict(preparation=str(DEST),manifest_sha256=sha((DEST/'CONTROLS_SHA256.json').read_bytes()),launchable=False,actual_GPU_hash_unset=True,numerical_executed=False)))

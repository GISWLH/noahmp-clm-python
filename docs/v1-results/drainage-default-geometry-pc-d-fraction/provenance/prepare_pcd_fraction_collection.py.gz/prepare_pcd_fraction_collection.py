"""Mechanical original compute-result collector binding; no model execution."""
from pathlib import Path

base=Path(__file__).resolve().parent
text=(base/'collect_pbv_fraction_result.py').read_text()
text=text.replace('drainage-geometry-pb-v-analysis','drainage-default-geometry-pc-d-analysis').replace('1845','1867')
target=base/'collect_geometry_default_pcd_fraction_result.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')

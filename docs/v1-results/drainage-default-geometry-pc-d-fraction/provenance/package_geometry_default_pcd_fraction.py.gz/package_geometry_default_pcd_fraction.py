"""Close actual1867 Fraction audit without local array/pickle numeric decode."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent;LABEL='drainage-default-geometry-pc-d-fraction'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def main():
    stage_raw=(BASE/'drainage-default-geometry-pc-d-analysis-stage.tar.gz').read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='931a8a2841d055bb8ead45fb06e8edb1c30625de491a65bf5ebd5186e655a114'
    index=json.loads(stage['stage-inventory.json']);assert len(stage)==14 and all(sha(stage[n])==h for n,h in index.items())
    closed=BASE/'drainage-default-geometry-pc-d-analysis-result'
    raw=(closed/'result.tar.gz').read_bytes();result=files(raw)
    assert sha(raw)=='912080e2f780b2208a28a1945ddb5214c8733ea518345ff4c06d60bf3c279932'
    qstat=(closed/'qstat.stdout').read_text()
    assert all(token in qstat for token in ('Job Id: 1867.manager','job_state = F','Exit_status = 0','Stageout_status = 0','run_count = 1'))
    assert (closed/'pbs-exit.txt').read_bytes().strip()==b'0'
    assert all(result[name].strip()==b'0' for name in ('setup-exit.txt','worker-exit.txt','pbs-command-exit.txt','stage-after-exit.txt'))
    assert result['worker.stderr']==b''
    for name in ('stage-before.json','stage-after.json'):
        row=json.loads(result[name]);assert row['passed'] and row['expected']==row['actual']==index
    for prefix,stored in (('preparation','preparation-controls'),('execution','execution-controls')):
        controls=json.loads(stage[prefix+'/CONTROLS_SHA256.json'])
        assert all(result[stored+'/'+name]==stage[prefix+'/'+name] for name in [*controls,'CONTROLS_SHA256.json'])
    report=json.loads(result['diagnosis.json']);assert report['completed'] and report['passed'] and report['pbs_job']=='1867.manager'
    assert len(report['rows'])==10 and report['original_inputs_exact']==[True]*4
    assert all(report[name] for name in ('original_context_reproduction_passed','all_GPU_delivery_domains_valid','original_GPU_capture_completed','constants_exactly_verified','controls_after_exact','input_after_exact','all_eligible_hardware_RN_bits_flags_consistent','all_exact_references_eligible'))
    assert all(report['Fraction_reference_selftests'].values()) and report['candidate_RN_equality_required'] is False
    assert report['physical_forward_calls']==report['GPU_calls']==0
    assert report['actual_GPU_result_sha256']=='8cb523d79eeb201096f5256b977e35ebfb7d51cc6c4686a728831400a7f30efc'
    assert len(result['diagnosis.pickle'])==137423 and sha(result['diagnosis.pickle'])=='ae7a3d9f36de3b4f02c8708f010a52105df72245b9a6a2b0e4e2826678146c88'
    groups=[dict(group=row['group'],layers=[dict(layer=layer['layer'],
        own_operand_non_RN_operations=[op for op in layer['operations'] if op['references']['own_operands']['candidate_matches_RN'] is False],
        strict_chain_non_RN_fields=[op['field'] for op in layer['operations'] if op['references']['strict']['candidate_matches_RN'] is False]) for layer in row['layers']]) for row in report['rows']]
    readout=dict(actual_job='1867.manager',actual_state='F',actual_exit=0,Stageout_status=0,run_count=1,
        resources='1CPU/2GiB/5min/compute002',all4_original_inputs_exact=True,all10_geometry_domains_valid=True,
        original_context_reproduction_passed=True,constants_exactly_verified=True,Fraction_reference_selftests=report['Fraction_reference_selftests'],
        all_eligible_hardware_RN_bits_and_flags_match_exact_Fraction=True,all_exact_references_eligible=True,
        candidate_RN_equality_required=False,controls_and_input_after_exact=True,groups=groups,
        raw_pickle_bytes=len(result['diagnosis.pickle']),raw_pickle_sha256=sha(result['diagnosis.pickle']),local_pickle_or_array_numeric_decode=False,
        physical_forward_calls=0,GPU_calls=0,model_replays=0,actual_GPU_result_sha256=report['actual_GPU_result_sha256'],
        scientific_acceptance=False,
        scope='Existing isolated PC-d candidate only. Exact Fraction/integer/RNE checks validate both literal reciprocal constants and all eligible GPU reference bits/flags. Candidate non-RN differences remain descriptive. No complete module/production/NumPy64/32/1e-6/integer/P0/hard-ledger acceptance credit.')
    items={'executed-stage.tar.gz':stage_raw,'original-result.tar.gz':raw,'readout.json':encode(readout),
        'original-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(result.items())})}
    for name,payload in stage.items():
        if name.startswith(('preparation/','execution/')):items[name]=payload
    for p in closed.iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for p in (BASE/'drainage-default-geometry-pc-d-analysis-preflight').iterdir():
        if p.is_file():items['PBS-preflight/'+p.name]=p.read_bytes()
    for p in (BASE/'drainage-default-geometry-pc-d-analysis-preparation').iterdir():
        if p.is_file():items['unexecuted-unbound-draft/'+p.name]=p.read_bytes()
    for name in ('drainage-default-geometry-pc-d-analysis-stage-package.json','drainage-default-geometry-pc-d-analysis-deployment.json',
        'prepare_geometry_default_pcd_analysis.py','freeze_geometry_default_pcd_analysis.py','prepare_pcd_analysis_submission.py',
        'preflight_pcd_fraction_pbs.py','deploy_geometry_default_pcd_analysis.py','prepare_pcd_fraction_collection.py','collect_geometry_default_pcd_fraction_result.py',Path(__file__).name):items['provenance/'+name]=(BASE/name).read_bytes()
    for p in BASE.glob('drainage-default-geometry-pc-d-analysis-deploy-*'):
        if p.is_file():items['deployment/'+p.name]=p.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name,payload in sorted(items.items()):
                member=tarfile.TarInfo(name);member.size=len(payload);member.mode=0o644;archive.addfile(member,io.BytesIO(payload))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='EHPC1867 F0/Stageout0 independent exact Fraction/RNE audit of actual PC-d10groups,0model/GPU/replay; candidate RN differences descriptive, no complete-module/science pass.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

"""Collect existing1867 compute result; PBS delivery finality stays separate."""
from pathlib import Path
import hashlib
import json
import subprocess

base=Path(__file__).resolve().parent
dest=base/'drainage-default-geometry-pc-d-analysis-result'
assert not dest.exists();dest.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
root='/tmp/noahmp-drainage-default-geometry-pc-d-analysis'
commands=[('qstat',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc','qstat -xf 1867.manager']),
    ('compute-before',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc-c2','sha256sum '+root+'/result.tar.gz '+root+'/stage-inventory.json']),
    ('scp',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc-c2:'+root+'/result.tar.gz','ehpc-c2:'+root+'/pbs-exit.txt',str(dest.resolve())]),
    ('compute-after',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc-c2','sha256sum '+root+'/result.tar.gz '+root+'/stage-inventory.json'])]
for label,command in commands:
    r=subprocess.run(command,capture_output=True,timeout=120)
    (dest/(label+'.stdout')).write_bytes(r.stdout);(dest/(label+'.stderr')).write_bytes(r.stderr)
    (dest/(label+'-exit.json')).write_text(json.dumps(dict(command=command,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)),indent=2)+'\n')
    assert r.returncode==0,r.stderr.decode(errors='replace')
assert (dest/'compute-before.stdout').read_bytes()==(dest/'compute-after.stdout').read_bytes()
expected=(dest/'compute-before.stdout').read_text().split()[0]
assert sha((dest/'result.tar.gz').read_bytes())==expected
qstat=(dest/'qstat.stdout').read_text()
print(json.dumps(dict(actual_job='1867.manager',compute_pbs_command_exit=(dest/'pbs-exit.txt').read_text().strip(),original_result_sha256=expected,
    actual_qstat_F='job_state = F' in qstat,Stageout0='Stageout_status = 0' in qstat,read_exits=[0,0,0,0])))

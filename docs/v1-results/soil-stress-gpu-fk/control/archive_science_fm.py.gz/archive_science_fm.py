"""Archive only actual-terminal diagnostics/references; no numerical evaluation."""
from pathlib import Path
import hashlib,io,json,sys,tarfile
mode=sys.argv[1];assert mode in ('cpu','gpu');b=Path('/home/zhangyq/noahmp-v1' if mode=='cpu' else '/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def archive(name,roots,extra=()):
    a=b/(name+'-evidence.tar.gz');assert not a.exists();count=0
    with tarfile.open(a,'w:gz') as tf:
        for prefix,root in roots:
            for p in sorted(root.rglob('*')):
                if p.is_file():tf.add(p,arcname=prefix+'/'+p.relative_to(root).as_posix(),recursive=False);count+=1
        for name_in,p in extra:tf.add(p,arcname=name_in,recursive=False);count+=1
        raw=Path(__file__).read_bytes();q=tarfile.TarInfo('control/'+Path(__file__).name);q.size=len(raw);tf.addfile(q,io.BytesIO(raw));count+=1
    print(json.dumps(dict(group=name,archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=count)),flush=True)
if mode=='cpu':
    fc=b/'qia-warm-analysis-fc';fa=b/'qia-warm-diagnostic-fa';fb=b/'qia-warm-diagnostic-fb';assert (fc/'pbs-exit.txt').read_text().strip()=='0' and (fa/'pbs-exit.txt').read_text().strip()=='1';result=json.loads((fc/'analysis.json').read_text());assert result['stage']=='first48' and result['source_unchanged'] and len(result['packet_inventory'])==48
    extra=[('first48-original/'+Path(q['path']).name,Path(q['path'])) for q in result['packet_inventory']]
    assert all(sha(Path(q['path']))==q['sha256'] for q in result['packet_inventory'])
    extra += [('original-physical-inputs/'+n,fb/n) for n in ['protocol.json','config.json','SOURCE_SHA256.json','dispatch.json','run_qia_warm_diagnostic_fb.py','qia_warm_diagnostic_fb.pbs']]
    archive('qia-warm-firstday-fc',[('analysis',fc),('observer-failed-fa',fa)],extra)
    roots=[]
    for name in ['soil-stress-reference-fg','soil-stress-numpy-fh','soil-stress-gpu-reference-fj']:
        root=b/name;assert (root/'pbs-exit.txt').read_text().strip()=='0';roots.append((name,root))
    assert json.loads((b/'soil-stress-numpy-fh/reference.json').read_text())['unit']['counts']==dict(tests=26,failures=0,errors=0,skipped=0)
    archive('soil-stress-reference-fg',roots)
    fe=b/'k78-current-fe';assert (fe/'pbs-exit.txt').read_text().strip()=='1';audit=json.loads((fe/'audit.json').read_text());assert audit['source_unchanged'] and not audit['passed'] and audit['raw_model_and_next_fields']==329 and len(audit['failed'])==1 and all(q['passed'] for q in audit['budgets'].values())
    archive('k78-current-fe',[('current-ec-audit',fe)])
else:
    root=b/'soil-stress-gpu-fk';done=json.loads((root/'exit.json').read_text());assert done['passed'] and done['actual_parent_returncode']==0 and done['source_unchanged'];s=Path(json.loads((root/'source-location.json').read_text())['source']);package=json.loads((root/'package.json').read_text());extra=[('validated-added-source/'+n,s/n) for n in package['added']];archive('soil-stress-gpu-fk',[('device',root)],extra)

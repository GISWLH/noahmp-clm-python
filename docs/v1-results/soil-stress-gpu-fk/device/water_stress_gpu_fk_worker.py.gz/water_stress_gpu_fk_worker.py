from pathlib import Path
import hashlib,json,runpy
b=Path('/home/lhwang/work/noahmp-v1');r=b/'soil-stress-gpu-fk';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());assert sha(s/'SOURCE_SHA256.json')==meta['manifest_sha256'];assert sha(s/'tests/fixtures/clm_water_stress_gpu_reference.npz')==meta['numpy_reference_sha256']
def blocked(*args,**kwargs):raise AssertionError('NumPy forward reference is frozen from EHPC440/441; no CPU physics on GPUhost')
import noahmp_clm.physics.clm_water_stress as physics
physics.soil_water_stress=blocked
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';runpy.run_path(str(worker),run_name='__main__')

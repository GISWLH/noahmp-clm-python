"""Mechanical stdlib-only stage for the one authorized PB-q diagnostic."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

OUT = Path(__file__).resolve().parent
LABEL = 'clm-drainage-nonuniform-pb-q'
PREP = OUT / (LABEL + '-preparation')
EXEC = OUT / (LABEL + '-execution')
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda v: (json.dumps(v, indent=2, allow_nan=False)+'\n').encode()
assert sha((PREP/'CONTROLS_SHA256.json').read_bytes()) == '5396017931adebc1226aab09a5f7438ad3427cf01343ce13dcd706755ce76e71'
prep = json.loads((PREP/'CONTROLS_SHA256.json').read_bytes())
assert len(prep) == 3 and all(sha((PREP/n).read_bytes()) == h for n, h in prep.items())
binding = json.loads((PREP/'BINDINGS.json').read_bytes())
original = OUT / binding['original1695_raw_result_archive']
assert sha(original.read_bytes()) == binding['original1695_raw_result_sha256']
with tarfile.open(original) as t:
    raw = {m.name.removeprefix('./'): t.extractfile(m).read() for m in t if m.isfile()}
assert len(raw) == 1103
assert sha(raw['source/SOURCE_SHA256.json']) == binding['source_manifest_sha256']
source = json.loads(raw['source/SOURCE_SHA256.json'])
assert len(source) == 596 and all(sha(raw['source/'+n]) == h for n, h in source.items())
assert sha(raw['preparation/test_adapter_pbp.py']) == binding['original_test_sha256']
assert sha(raw['execution/observe_pbp.py']) == binding['original_observer_sha256']
EXEC.mkdir(exist_ok=True)
patch = []
for name in ('dispatch_component_pb.py', 'component_pb.pbs'):
    old = raw['execution/'+name].decode()
    new = old.replace('clm-drainage-adapter-pb-p-b', LABEL).replace('drainage-adapter-pbp-b', 'drainage-nonuniform-pbq')
    new = new.replace('dispatch_drainage_adapter_pbp_b.py', 'dispatch_drainage_nonuniform_pbq.py')
    if name.endswith('.pbs'):
        new = new.replace('walltime=00:10:00', 'walltime=00:05:00')
        new = new.replace('export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1',
            "export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1\nexport CUDA_VISIBLE_DEVICES='' JAX_PLATFORMS=cpu")
        new = new.replace('unset PYTHONPATH PYTHONHOME', 'unset PYTHONHOME\nexport PYTHONPATH=/home/zhangyq/noahmp-v1/test-deps')
        new = new.replace('"$stage/execution/run_component_pb.py" "$TMPDIR/result"',
            '"$stage/preparation/capture_nonuniform_pbq.py" "$TMPDIR/result" "$stage/original1695-result.tar.gz"')
    else:
        new = new.replace('1CPU/2GB/10min/compute002', '1CPU/2GB/5min/compute002')
        new = new.replace('PB-p isolated CPU diagnosis/adapter versus original physics and20gold diagnosis/trial, source596. Expected24nodes await actual collect. NoGPU/full-column/site/annual execution.',
            'PB-q one unchanged failed1695 nonuniform_dz-float64 direct test plus post-exception predicate capture. Original ValueError/parent1/PBS1 preserved; no algorithm/input/gate changes, GPU or column run.')
    (EXEC/name).write_text(new, encoding='utf-8', newline='\n')
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile='original1695/'+name, tofile='PB-q/'+name))
(EXEC/'wrapper.patch').write_text(''.join(patch), encoding='utf-8', newline='\n')
(EXEC/'README.md').write_text('''# PB-q single diagnostic execution

Mechanical1695 PBS/dispatch reuse. Only private paths, 5min time, required CPU/no-device environment and unique capture CLI change; manifest/hash/probe/one-qsub and result-pack/exit propagation remain. Original1695 raw archive is the immutable source/test/observer input. This stage does not modify it or any source/phase/guard.

One direct original nonuniform_dz-float64 test invocation is expected to raise its original ValueError. Child1/PBS1 are retained; successful diagnostic capture is not a passed physical testcase. No test collection or other24-case rerun. Capture exact call counts, complete exception arrays and separate predicate/ULP readout; real F/Exit/Stageout and immutable hashes required at closeout. Source files may be omitted from the publication wrapper only with the original raw archive retained and every original member hash mapped.

Authorized1CPU/2GiB/5min compute002, existing closeout Python/test-deps, manager/compute private/tmp and PBS TMPDIR. No CUDA/JAX/kernel/production/annual action. No automatic retry after actual failure.
''', encoding='utf-8', newline='\n')
for p in (PREP/'capture_nonuniform_pbq.py', EXEC/'dispatch_component_pb.py'): ast.parse(p.read_bytes())
exec_index = {p.name: sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
assert len(exec_index) == 4
(EXEC/'CONTROLS_SHA256.json').write_bytes(encode(exec_index))
data = {'original1695-result.tar.gz': original.read_bytes()}
for folder, label in ((PREP, 'preparation'), (EXEC, 'execution')):
    data.update({label+'/'+p.name: p.read_bytes() for p in sorted(folder.iterdir()) if p.is_file()})
data['stage-inventory.json'] = encode({n: sha(b) for n, b in data.items()})
archive = OUT/(LABEL+'-stage.tar.gz')
assert not archive.exists()
with archive.open('wb') as f, gzip.GzipFile(filename='', fileobj=f, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as t:
    for n, b in sorted(data.items()):
        m = tarfile.TarInfo(n); m.size=len(b); t.addfile(m, io.BytesIO(b))
with tarfile.open(archive) as t: assert {m.name:t.extractfile(m).read() for m in t} == data
report = dict(actual_stdlib_exit=0, stage_sha256=sha(archive.read_bytes()), stage_members=len(data),
    original1695_raw_result_sha256=sha(original.read_bytes()), preparation_controls=3,
    preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()), execution_controls=4,
    execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()), source_files=596,
    source_manifest_sha256=binding['source_manifest_sha256'], only_one_original_case=True,
    numerical_executed=False, PBS_submitted=False)
(OUT/(LABEL+'-stage-preparation.json')).write_bytes(encode(report))
print(json.dumps(report), flush=True)

"""Stdlib-only control delta and exception-preservation checks; no NumPy import."""
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace
import ast
import difflib
import hashlib
import io
import json
import tarfile

OUT = Path(__file__).resolve().parent
HERE = OUT / 'clm-drainage-nonuniform-pb-q-preparation'
sha = lambda b: hashlib.sha256(b).hexdigest()
old_archive = OUT / 'clm-drainage-nonuniform-pb-q-before-io-guard.tar.gz'
with tarfile.open(old_archive) as t:
    old = {m.name: t.extractfile(m).read() for m in t}
assert len(old) == 4 and sha(old['CONTROLS_SHA256.json']) == '8befa167db1e873c6d21dd289e20f9ca7df5594b2a4f25ff343f6c400d0dc985'
assert all(sha(old[n]) == h for n, h in json.loads(old['CONTROLS_SHA256.json']).items())
assert old['BINDINGS.json'] == (HERE / 'BINDINGS.json').read_bytes()
name = 'capture_nonuniform_pbq.py'
before = ast.parse(old[name]); after = ast.parse((HERE / name).read_bytes())
dump = lambda n: ast.dump(n, include_attributes=False)
subtree = lambda tree, pred: [dump(n) for n in ast.walk(tree) if pred(n)]
is_analysis = lambda n: isinstance(n, ast.If) and ast.unparse(n.test) == 'validate_locals is not None'
assert subtree(before, is_analysis) == subtree(after, is_analysis)
assert subtree(before, lambda n: isinstance(n, ast.While)) == subtree(after, lambda n: isinstance(n, ast.While))
is_np_call = lambda n: isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == 'np'
assert sorted(subtree(before, is_np_call)) == sorted(subtree(after, is_np_call))
is_test_call = lambda n: isinstance(n, ast.Call) and ast.unparse(n.func) == 'test.test_adapter_independent_physics_reference'
assert subtree(before, is_test_call) == subtree(after, is_test_call)
helper = next(n for n in after.body if isinstance(n, ast.FunctionDef) and n.name == 'preserve_original_error')
namespace = dict(contextmanager=contextmanager, json=json, sys=SimpleNamespace(stderr=io.StringIO()))
exec(compile(ast.Module(body=[helper], type_ignores=[]), '<stdlib-control-helper-only>', 'exec'), namespace)
guard = namespace['preserve_original_error']
checks = []
for broken_stderr in (False, True):
    class BrokenStream:
        def write(self, _): raise OSError('stderr deliberately unavailable')
        def flush(self): raise OSError('stderr deliberately unavailable')
    namespace['sys'].stderr = BrokenStream() if broken_stderr else io.StringIO()
    original = ValueError('original guard error'); errors = []; propagated = None
    try:
        try:
            raise original
        except BaseException as error:
            with guard('capture-save', errors, error): raise OSError('capture save failed')
            with guard('analysis-encoding', errors, error): raise TypeError('diagnostic encoding failed')
            raise
        finally:
            with guard('final-save', errors, original): raise OSError('final save failed')
    except BaseException as error:
        propagated = error
    assert propagated is original and [v['operation'] for v in errors] == ['capture-save', 'analysis-encoding', 'final-save']
    checks.append(dict(broken_stderr=broken_stderr, original_exception_identity_retained=True, independent_failures_recorded=3))
secondary = OSError('no original exception'); propagated = None
try:
    with guard('normal-finalization', [], None): raise secondary
except BaseException as error:
    propagated = error
assert propagated is secondary
assert any(isinstance(n, ast.Assert) and ast.unparse(n.test) == 'sys.dont_write_bytecode' for n in ast.walk(after))
manifest = {p.name: sha(p.read_bytes()) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
assert len(manifest) == 3
(HERE / 'CONTROLS_SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8', newline='\n')
changed = [n for n in old if old[n] != (HERE / n).read_bytes()]
assert set(changed) == {name, 'README.md', 'CONTROLS_SHA256.json'}
patch = ''.join(''.join(difflib.unified_diff(old[n].decode().splitlines(keepends=True),
    (HERE/n).read_text().splitlines(keepends=True), fromfile='before/'+n, tofile='after/'+n)) for n in changed)
(OUT / 'clm-drainage-nonuniform-pb-q-io-only.patch').write_text(patch, encoding='utf-8', newline='\n')
review = dict(actual_stdlib_exit=0, old_unexecuted_archive_sha256=sha(old_archive.read_bytes()),
    old_manifest_sha256=sha(old['CONTROLS_SHA256.json']), new_manifest_sha256=sha((HERE/'CONTROLS_SHA256.json').read_bytes()),
    controls=3, changed_files=changed, original_BINDINGS_exact=True,
    all_original_np_calls_AST_exact=True, original_frame_capture_while_AST_exact=True,
    complete_original_predicate_analysis_AST_exact=True, original_test_call_AST_exact=True,
    control_checks=checks, no_original_exception_secondary_error_propagates=True,
    source_test_observer_inputs_unchanged=True, numerical_imported=False, model_executed=False, PBS_submitted=False,
    scope='Control-only IO exception protection and pre-numerical environment assertions; actual tests above execute only the extracted stdlib contextmanager helper.')
(OUT / 'clm-drainage-nonuniform-pb-q-io-review.json').write_text(json.dumps(review, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(review), flush=True)

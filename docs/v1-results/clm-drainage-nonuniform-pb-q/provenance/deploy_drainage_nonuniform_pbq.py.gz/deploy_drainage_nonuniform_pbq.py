"""Authorized one-shot deployment, no model execution on the local host."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
stage = ROOT/'clm-drainage-nonuniform-pb-q-stage.tar.gz'
digest = 'ca6aeec20fce1fb239b596f365d5b5a0a9730357e5691e6e651f3837adf6bdc3'
assert hashlib.sha256(stage.read_bytes()).hexdigest() == digest
record_path = ROOT/'clm-drainage-nonuniform-pb-q-deployment.json'
assert not record_path.exists(), 'Do not retry this deployment automatically'
record = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              stage_sha256=digest, actual_exit=None, commands=[], single_submit_authorized=True)


def save(): record_path.write_text(json.dumps(record, indent=2)+'\n', encoding='utf8')


save()
commands = [
    ['scp', '-O', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', str(stage),
     'ehpc:/tmp/noahmp-clm-drainage-nonuniform-pb-q-stage.tar.gz'],
    ['scp', '-O', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20',
     str(ROOT/'clm-drainage-nonuniform-pb-q-execution/dispatch_component_pb.py'),
     'ehpc:/tmp/dispatch_drainage_nonuniform_pbq.py'],
    ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'ehpc',
     '/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_drainage_nonuniform_pbq.py '
     '--archive /tmp/noahmp-clm-drainage-nonuniform-pb-q-stage.tar.gz --sha256 '+digest]]
for i, command in enumerate(commands):
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    (ROOT/f'clm-drainage-nonuniform-pb-q-deploy-{i}.stdout.txt').write_text(result.stdout, encoding='utf8')
    (ROOT/f'clm-drainage-nonuniform-pb-q-deploy-{i}.stderr.txt').write_text(result.stderr, encoding='utf8')
    record['commands'].append(dict(command=command, returncode=result.returncode))
    save()
    if result.returncode:
        record['actual_exit'] = result.returncode; save(); raise SystemExit(result.returncode)
    if i == 2:
        record['dispatch'] = json.loads(result.stdout)
record.update(actual_exit=0, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
print(json.dumps(dict(actual_exit=0, stage_sha256=digest, pbs_job=record['dispatch']['pbs_job'])))
sys.exit(0)

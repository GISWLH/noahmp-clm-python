"""Close actual PB-q single-case diagnostic, raw bytes/stdlibrary only."""
from pathlib import Path
import hashlib
import io
import json
import re
import shlex
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
LABEL = 'clm-drainage-nonuniform-pb-q'
ROOT = '/tmp/noahmp-' + LABEL
JOB = '1702.manager'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda v: (json.dumps(v, indent=2, allow_nan=False)+'\n').encode()
data = {}


def command(argv, label):
    result = subprocess.run(argv, capture_output=True, timeout=50)
    data['closure/'+label+'.stdout.txt'] = result.stdout
    data['closure/'+label+'.stderr.txt'] = result.stderr
    assert result.returncode == 0, (label, result.stderr)
    return result.stdout


def remote(cmd, label):
    return command(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'ehpc', cmd], label)


def read_tar(blob):
    with tarfile.open(fileobj=io.BytesIO(blob)) as t:
        members = [m for m in t if m.isfile()]
        assert len({m.name.removeprefix('./') for m in members}) == len(members)
        assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        return {m.name.removeprefix('./'): t.extractfile(m).read() for m in members}


status = remote('qstat -xf '+JOB, 'actual-qstat').decode()
assert re.search(r'^\s*job_state = F\s*$', status, re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$', status, re.M)
exit_status = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', status, re.M).group(1))
assert exit_status == 1
compute_hash = remote('ssh compute002 '+shlex.quote('sha256sum '+ROOT+'/result.tar.gz'), 'compute-result-hash').decode().split()[0]
assert int(remote('ssh compute002 '+shlex.quote('cat '+ROOT+'/pbs-exit.txt'), 'compute-pbs-exit')) == exit_status
remote('if test ! -e '+ROOT+'/result.tar.gz; then scp compute002:'+ROOT+'/result.tar.gz '+ROOT+'/result.tar.gz; fi', 'copy-result-manager')
assert remote('sha256sum '+ROOT+'/result.tar.gz', 'manager-result-hash').decode().split()[0] == compute_hash
local = OUT/(LABEL+'-1702-original-result.tar.gz')
if not local.exists():
    command(['scp', '-O', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'ehpc:'+ROOT+'/result.tar.gz', str(local)], 'download-result')
assert sha(local.read_bytes()) == compute_hash
raw = read_tar(local.read_bytes())
receipt = json.loads(raw['receipt.json']); analysis = json.loads(raw['independent-predicate-analysis.json'])
assert receipt['pbs_job'] == JOB and receipt['node'] == 'compute002'
assert int(raw['worker-exit.txt']) == 1
assert receipt['original_test_attempts'] == 1 and receipt['original_test_returned'] == 0
assert receipt['exception_type'] == 'ValueError'
assert receipt['exception_message'] == 'Invalid stock, phase partition, geometry, rate or trial limits'
assert receipt['diagnostic_errors'] == [] and receipt['independent_analysis_completed']
assert receipt['original_validate_frame_found'] and receipt['original_reference_returned']
assert receipt['controls_unchanged'] and receipt['immutable_unchanged']
assert not receipt['numerical_success_claimed'] and not receipt['cupy_imported'] and not receipt['jax_imported']
before = json.loads(raw['immutable-before.json']); after = json.loads(raw['immutable-after.json'])
assert before == after and len(before) == 630
assert all(sha(raw[n]) == h for n, h in before.items())
source = json.loads(raw['source/SOURCE_SHA256.json'])
assert len(source) == 596 and all(sha(raw['source/'+n]) == h for n, h in source.items())
bindings = json.loads((OUT/(LABEL+'-preparation/BINDINGS.json')).read_bytes())
original_blob = (OUT/bindings['original1695_raw_result_archive']).read_bytes()
assert sha(original_blob) == bindings['original1695_raw_result_sha256']
original = read_tar(original_blob)
assert all(raw[n] == original[n] for n in before)
assert sha(raw['source/SOURCE_SHA256.json']) == bindings['source_manifest_sha256']
assert sha(raw['preparation/test_adapter_pbp.py']) == bindings['original_test_sha256']
assert sha(raw['execution/observe_pbp.py']) == bindings['original_observer_sha256']
assert analysis['failing_predicates'] == ['ice_negative'] and analysis['predicate_union_matches_original']
assert analysis['original_bad'] == analysis['reconstructed_bad'] == [True]
assert analysis['phase']['all_warm'] and analysis['phase']['liquid_equals_roundtrip_exact']
assert analysis['phase']['liquid_minus_water_in_ulp'] == [[0.0, 1.0, 0.0, 0.0]]
assert analysis['predicates']['ice_negative'] == [[False, True, False, False]]
assert b'ValueError: Invalid stock, phase partition, geometry, rate or trial limits' in raw['controller.log']
calls = receipt['actual_calls']
assert (calls['reference_drainage']['attempted'], calls['reference_drainage']['returned']) == (1, 1)
assert (calls['adapter']['attempted'], calls['adapter']['returned'], calls['adapter']['raised']) == (1, 0, 1)
for name in ('dispatch.json', 'stage-inventory.json', 'qsub.stdout.txt', 'qsub.stderr.txt',
             'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt'):
    data['scheduler/'+name] = remote('cat '+shlex.quote(ROOT+'/'+name), 'read-'+name)
data['scheduler/optional-pbs-output.txt'] = remote('if test -f '+ROOT+'/pbs-output.log; then cat '+ROOT+'/pbs-output.log; else printf "Optional manager PBS log absent; original controller.log retained.\\n"; fi', 'optional-pbs-output')
stage = read_tar((OUT/(LABEL+'-stage.tar.gz')).read_bytes())
assert sha((OUT/(LABEL+'-stage.tar.gz')).read_bytes()) == 'ca6aeec20fce1fb239b596f365d5b5a0a9730357e5691e6e651f3837adf6bdc3'
stage_index = json.loads(stage['stage-inventory.json'])
assert all(sha(stage[n]) == h for n, h in stage_index.items())
assert json.loads(data['scheduler/dispatch.json'])['stage_archive_sha256'] == sha((OUT/(LABEL+'-stage.tar.gz')).read_bytes())
for n, b in stage.items():
    if n != 'original1695-result.tar.gz': data['executed-stage/'+n] = b
data['original1695-result.tar.gz'] = original_blob
for n, b in raw.items():
    if n not in before: data['actual/'+n] = b
data['source-manifest.json'] = raw['source/SOURCE_SHA256.json']
data['original1702-result-inventory.json'] = encode({n: dict(sha256=sha(b), bytes=len(b),
    location=('original1695-result.tar.gz:'+n) if n in before else 'actual/'+n) for n, b in raw.items()})
scope = ('Single unchanged1695 nonuniform_dz-float64 test reproduced original ValueError: actual1702 F1/Stageout0. '
    'Transparent traceback/predicate diagnostic completed; only second-layer ice_negative from one-ULP warm liquid volume/mass roundtrip. '
    'No successful endpoint/budget comparison, source/input/guard changes, retry, GPU, coupled column or annual acceptance.')
readout = dict(actual_job=JOB, actual_job_state='F', actual_exit=exit_status, Stageout_status=0,
    diagnostic_capture_completed=True, scientific_test_passed=False, receipt=receipt, predicate_analysis=analysis,
    raw_result_sha256=compute_hash, raw_result_members=len(raw), original1695_raw_result_sha256=sha(original_blob),
    unchanged_original_files=630, source_files=596, model_guard_changed=False, phase_changed=False, scope=scope,
    minimum_followup='Root review only: consider warm-liquid canonicalization to exact extensive W in the NumPy64 phase adapter, matching existing32/device warm branch; keep original domain guard and M/H budgets. No revision or follow-up run is performed here.')
data['run-readout.json'] = encode(readout)
data['closed-run.json'] = encode(dict(job=JOB, actual_job_state='F', actual_exit=1, Stageout_status=0,
    diagnostic_capture_completed=True, scientific_test_passed=False, raw_result_sha256=compute_hash,
    original1695_raw_result_sha256=sha(original_blob), run_count=1))
for name in ('stage_drainage_nonuniform_pbq.py', 'deploy_drainage_nonuniform_pbq.py', LABEL+'-deployment.json',
             LABEL+'-stage-preparation.json', LABEL+'-io-only.patch', LABEL+'-io-review.json',
             'review_drainage_nonuniform_pbq_io.py', LABEL+'-before-io-guard.tar.gz'):
    data['provenance/'+name] = (OUT/name).read_bytes()
data['archive_drainage_nonuniform_pbq.py'] = Path(__file__).read_bytes()
data['artifact-inventory.json'] = encode({n: dict(sha256=sha(b), bytes=len(b)) for n, b in data.items()})
target = OUT/(LABEL+'-evidence.tar.gz'); assert not target.exists()
with tarfile.open(target, 'w:gz') as t:
    for n, b in sorted(data.items()):
        m = tarfile.TarInfo(n); m.size=len(b); t.addfile(m, io.BytesIO(b))
assert read_tar(target.read_bytes()) == data
package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size, artifacts=len(data),
    actual_job=JOB, actual_job_state='F', actual_exit=1, Stageout_status=0, diagnostic_capture_completed=True,
    scientific_test_passed=False, scope=scope)
(OUT/(LABEL+'-package.json')).write_bytes(encode(package))
(OUT/(LABEL+'-readout.json')).write_bytes(encode(readout))
print(json.dumps(package), flush=True)

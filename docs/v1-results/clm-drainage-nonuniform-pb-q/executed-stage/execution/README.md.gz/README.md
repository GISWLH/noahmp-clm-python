# PB-q single diagnostic execution

Mechanical1695 PBS/dispatch reuse. Only private paths, 5min time, required CPU/no-device environment and unique capture CLI change; manifest/hash/probe/one-qsub and result-pack/exit propagation remain. Original1695 raw archive is the immutable source/test/observer input. This stage does not modify it or any source/phase/guard.

One direct original nonuniform_dz-float64 test invocation is expected to raise its original ValueError. Child1/PBS1 are retained; successful diagnostic capture is not a passed physical testcase. No test collection or other24-case rerun. Capture exact call counts, complete exception arrays and separate predicate/ULP readout; real F/Exit/Stageout and immutable hashes required at closeout. Source files may be omitted from the publication wrapper only with the original raw archive retained and every original member hash mapped.

Authorized1CPU/2GiB/5min compute002, existing closeout Python/test-deps, manager/compute private/tmp and PBS TMPDIR. No CUDA/JAX/kernel/production/annual action. No automatic retry after actual failure.

"""Prepared single unchanged1695 case; capture original exception then re-raise."""
from pathlib import Path
from contextlib import contextmanager
import hashlib
import importlib
import json
import os
import socket
import sys
import tarfile
import time
import traceback

sha = lambda b: hashlib.sha256(b).hexdigest()
HERE = Path(__file__).resolve().parent


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


@contextmanager
def preserve_original_error(label, diagnostic_errors, original_error):
    """A diagnostic failure must never replace an already active model error."""
    try:
        yield
    except BaseException as secondary:
        if original_error is None:
            raise
        # Both metadata and stderr are best effort under an original exception.
        # In particular a broken stderr stream must not replace that exception.
        record = dict(operation=label, exception_type=type(secondary).__name__)
        try:
            record['message'] = str(secondary)
        except BaseException:
            record['message'] = '<exception text unavailable>'
        try:
            diagnostic_errors.append(record)
        except BaseException:
            pass
        try:
            print('PB_Q_DIAGNOSTIC_IO_FAILURE ' + json.dumps(record), file=sys.stderr, flush=True)
        except BaseException:
            pass


def main():
    assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode, 'Run with -B before any numerical import'
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    assert all(os.environ.get(name) == '1' for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'))
    root = Path(sys.argv[1]).resolve(); archive = Path(sys.argv[2]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    controls = json.loads((HERE / 'CONTROLS_SHA256.json').read_bytes())
    assert all(sha((HERE / n).read_bytes()) == h for n, h in controls.items())
    binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
    assert sha(archive.read_bytes()) == binding['original1695_raw_result_sha256']
    root.mkdir(); immutable = {}; started = time.monotonic()
    with tarfile.open(archive) as t:
        members = [m for m in t if m.isfile()]
        assert len({m.name.removeprefix('./') for m in members}) == len(members) == 1103
        for member in members:
            name = member.name.removeprefix('./')
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            if name.startswith(('source/', 'preparation/', 'execution/', 'reference/')):
                target = root / name; target.parent.mkdir(parents=True, exist_ok=True)
                raw = t.extractfile(member).read(); target.write_bytes(raw); immutable[name] = sha(raw)
    source = json.loads((root / 'source/SOURCE_SHA256.json').read_bytes())
    assert len(source) == 596 and sha((root / 'source/SOURCE_SHA256.json').read_bytes()) == binding['source_manifest_sha256']
    assert all(immutable['source/' + n] == h for n, h in source.items())
    for folder, count in (('preparation', 19), ('execution', 7), ('reference', 4)):
        index = json.loads((root / folder / 'CONTROLS_SHA256.json').read_bytes())
        assert len(index) == count and all(immutable[folder + '/' + n] == h for n, h in index.items())
    assert immutable['preparation/test_adapter_pbp.py'] == binding['original_test_sha256']
    assert immutable['execution/observe_pbp.py'] == binding['original_observer_sha256']
    save(root / 'immutable-before.json', immutable)
    os.environ.update(PBP_RUN_ROOT=str(root), PBP_RESULTS=str(root / 'unused-original-results'), PBP_OBSERVER_MODE='single-case')
    sys.path[:0] = [str(root / 'source/src'), str(root / 'execution'), str(root / 'preparation')]
    observer = importlib.import_module('observe_pbp')
    observer.pytest_configure(None)  # Exact1695 observer has no config dependency.
    test = importlib.import_module('test_adapter_pbp')
    import numpy as np
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
        source_manifest_sha256=binding['source_manifest_sha256'], original_test_sha256=binding['original_test_sha256'],
        case='nonuniform_dz-float64', original_test_attempts=0, original_test_returned=0,
        expected_reproduction_is_not_success=True, numerical_scope='One unchanged original test plus independent post-exception predicate readout; no modified source or inputs.')
    original_error = None; diagnostic_errors = []
    receipt['diagnostic_errors'] = diagnostic_errors
    try:
        receipt['original_test_attempts'] = 1
        test.test_adapter_independent_physics_reference(np.float64, 'nonuniform_dz')
        receipt['original_test_returned'] = 1
        raise RuntimeError('Original1695 failure unexpectedly did not reproduce; no success reclassification')
    except BaseException as error:
        original_error = error
        with preserve_original_error('exception-identity', diagnostic_errors, original_error):
            receipt['exception_type'] = type(error).__name__
            receipt['exception_message'] = str(error)
        with preserve_original_error('original-exception.txt', diagnostic_errors, original_error):
            (root / 'original-exception.txt').write_text(traceback.format_exc())
        arrays = {}; frames = []; validate_locals = None; reference_ledger = None
        with preserve_original_error('traceback-frame-capture', diagnostic_errors, original_error):
            tb = error.__traceback__
            while tb:
                frame = tb.tb_frame; path = Path(frame.f_code.co_filename).resolve()
                if path.is_relative_to(root):
                    number = len(frames); scalars = {}; saved = {}
                    for key, value in frame.f_locals.items():
                        if isinstance(value, np.ndarray) and value.dtype.kind in 'biuf':
                            name = 'frame' + str(number) + '.' + key
                            arrays[name] = value.copy(); saved[key] = name
                        elif type(value) in (bool, int, float, str, type(None)):
                            scalars[key] = value
                    frames.append(dict(source=path.relative_to(root).as_posix(), function=frame.f_code.co_name,
                        line=tb.tb_lineno, scalars=scalars, arrays=saved))
                    if path.name == 'clm_drainage_primitives.py' and frame.f_code.co_name == 'validate':
                        validate_locals = frame.f_locals
                    if path.name == 'test_adapter_pbp.py' and frame.f_code.co_name == 'checked_reference':
                        reference_ledger = frame.f_locals.get('ledger')
                        expected = frame.f_locals.get('expected')
                        if expected is not None:
                            # Raw stored fields only; no property invokes another inverse.
                            for name in ('water', 'enthalpy', 'dz'):
                                arrays['original_reference.' + name] = getattr(expected, name).copy()
                tb = tb.tb_next
        with preserve_original_error('exception-arrays.npz', diagnostic_errors, original_error):
            np.savez(root / 'exception-arrays.npz', **arrays)
        with preserve_original_error('exception-array-manifest.json', diagnostic_errors, original_error):
            save(root / 'exception-array-manifest.json', {k: dict(dtype=v.dtype.str, shape=list(v.shape),
                 c_order_sha256=sha(v.tobytes()), bytes=v.nbytes) for k, v in arrays.items()})
        with preserve_original_error('exception-frames.json', diagnostic_errors, original_error):
            save(root / 'exception-frames.json', frames)
        with preserve_original_error('original-reference-ledger.json', diagnostic_errors, original_error):
            if reference_ledger is not None:
                save(root / 'original-reference-ledger.json', test.json_value(reference_ledger))
        receipt['original_reference_returned'] = reference_ledger is not None
        receipt['original_validate_frame_found'] = validate_locals is not None
        # This independent analysis is after the original exception. It never
        # substitutes a predicate, repairs a phase or changes original arguments.
        with preserve_original_error('independent-predicate-analysis', diagnostic_errors, original_error):
            if validate_locals is not None:
                c = validate_locals['cells'].copy(); p = validate_locals['pars'].copy(); u = validate_locals['interval'].copy()
                eps = np.finfo(c.dtype).eps; edges = np.cumsum(c[:, :, 2], axis=1)
                matches = np.sum(abs(edges-p[:, 4, None]) <= 16*eps*np.maximum(edges[:, -1, None], 1), axis=1)
                masks = {
                    'liquid_negative': c[:, :, 0] < 0, 'ice_negative': c[:, :, 1] < 0,
                    'dz_nonpositive': c[:, :, 2] <= 0, 'temperature_below150': c[:, :, 3] < 150,
                    'temperature_above400': c[:, :, 3] > 400, 'water_negative': c[:, :, 4] < 0,
                    'water_above_pore_capacity': c[:, :, 4] > 1000*c[:, :, 2]*p[:, 0, None],
                    'phase_partition_mismatch': abs(c[:, :, 0]+c[:, :, 1]-c[:, :, 4]) > 16*eps*np.maximum(c[:, :, 4], 1),
                    'porosity_nonpositive': p[:, 0] <= 0, 'porosity_atleast1': p[:, 0] >= 1,
                    'suction_nonpositive': p[:, 1] <= 0, 'bexp_nonpositive': p[:, 2] <= 0,
                    'ks_negative': p[:, 3] < 0, 'bedrock_nonpositive': p[:, 4] <= 0,
                    'bedrock_interface_not_unique': matches != 1, 'slope_negative': p[:, 5] < 0,
                    'slope_atleast_pi_over2': p[:, 5] >= np.pi/2, 'baseflow_negative': p[:, 6] < 0,
                    'perched_scale_negative': p[:, 7] < 0, 'saturation_nonpositive': p[:, 8] <= 0,
                    'saturation_above1': p[:, 8] > 1, 'sy_nonpositive': p[:, 9] <= 0,
                    'sy_atleast_porosity': p[:, 9] >= p[:, 0], 'retained_liquid_negative': p[:, 10] < 0,
                    'ice_exponent_negative': p[:, 11] < 0, 'dt_nonpositive': u[:, 0] <= 0,
                    'front_negative': u[:, 1] < 0, 'bottom_less_than_front': u[:, 2] < u[:, 1],
                    'bottom_below_bedrock': u[:, 2] > p[:, 4]}
                diagnosed_bad = np.zeros(len(c), bool)
                for mask in masks.values(): diagnosed_bad |= np.any(mask, axis=1) if mask.ndim == 2 else mask
                original_bad = validate_locals['bad'].copy()
                roundtrip = (c[:, :, 4]/(1000*c[:, :, 2]))*1000*c[:, :, 2]
                independent = dict(scope='Post-exception arithmetic only, not a new physical trajectory or altered guard.',
                    predicates={k: v.tolist() for k, v in masks.items()}, failing_predicates=[k for k, v in masks.items() if np.any(v)],
                    original_bad=original_bad.tolist(), reconstructed_bad=diagnosed_bad.tolist(),
                    predicate_union_matches_original=bool(np.array_equal(diagnosed_bad, original_bad)),
                    phase=dict(water=c[:, :, 4].tolist(), liquid=c[:, :, 0].tolist(), ice=c[:, :, 1].tolist(),
                        temperature_k=c[:, :, 3].tolist(), dz=c[:, :, 2].tolist(),
                        liquid_minus_water=(c[:, :, 0]-c[:, :, 4]).tolist(),
                        water_ulp=np.spacing(c[:, :, 4]).tolist(),
                        liquid_minus_water_in_ulp=((c[:, :, 0]-c[:, :, 4])/np.spacing(c[:, :, 4])).tolist(),
                        original_volume_mass_roundtrip=roundtrip.tolist(),
                        liquid_equals_roundtrip_exact=bool(np.array_equal(c[:, :, 0], roundtrip)),
                        all_warm=bool(np.all(c[:, :, 3] >= 273.15))))
                save(root / 'independent-predicate-analysis.json', independent)
                receipt['independent_analysis_completed'] = True
        raise  # Preserve the actual original exception and parent nonzero exit.
    finally:
        with preserve_original_error('observer.persist', diagnostic_errors, original_error):
            observer.persist()
        after = None
        with preserve_original_error('immutable-after-hashes', diagnostic_errors, original_error):
            after = {n: sha((root / n).read_bytes()) for n in immutable}
        if after is not None:
            with preserve_original_error('immutable-after.json', diagnostic_errors, original_error):
                save(root / 'immutable-after.json', after)
        with preserve_original_error('receipt-metadata', diagnostic_errors, original_error):
            receipt.update(immutable_files=len(immutable), immutable_unchanged=None if after is None else after == immutable,
                seconds=time.monotonic()-started, cupy_imported='cupy' in sys.modules, jax_imported='jax' in sys.modules,
                actual_calls=observer.COUNTS, module_paths=observer.MODULES, numerical_success_claimed=False)
        with preserve_original_error('control-after-hashes', diagnostic_errors, original_error):
            receipt['controls_unchanged'] = all(sha((HERE / n).read_bytes()) == h for n, h in controls.items())
        with preserve_original_error('receipt.json', diagnostic_errors, original_error):
            save(root / 'receipt.json', receipt)


if __name__ == '__main__': main()

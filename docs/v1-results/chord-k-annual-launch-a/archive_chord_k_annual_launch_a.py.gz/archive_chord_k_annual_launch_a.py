from pathlib import Path
import datetime,hashlib,io,json,os,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-k';source=base/'p6-joint-chord-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((root/'annual-launch.json').read_text());worker=json.loads((root/'annual-worker.json').read_text());p=Path('/proc')/str(worker['pid']);assert p.exists() and str(source/'benchmarks/run_fluxnet_native.py') in (p/'cmdline').read_bytes().replace(b'\0',b' ').decode();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
observation=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),worker_pid=worker['pid'],worker_command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),worker_live=True,source_unchanged=True,scope='Actual own K48 annual continuation launch and live worker observation only, not full annual/spinup/science. Original prefix archive retains immutable primary/shadow arrays and cumulative ledgers.')
archive=base/'chord-k-annual-launch-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for name in ['annual-launch.json','annual-worker.json','run_chord_k_annual_a.py']:t.add(root/name,arcname=name,recursive=False)
    for name,raw in [('live-observation.json',(json.dumps(observation,indent=2)+'\n').encode()),('batch-observed.json',(root/'cuda-day/batch.json').read_bytes())]:x=tarfile.TarInfo(name);x.size=len(raw);t.addfile(x,io.BytesIO(raw))
    t.add(source/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False);t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
print(json.dumps(dict(name='chord-k-annual-launch-a',sha256=sha(archive),files=7)))

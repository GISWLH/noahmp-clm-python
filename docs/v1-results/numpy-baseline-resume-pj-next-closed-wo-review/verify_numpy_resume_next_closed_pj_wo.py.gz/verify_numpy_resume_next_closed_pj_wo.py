"""Stdlib-only reconstruction and terminal review; no array/pickle decoding."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import tarfile

BASE = Path(__file__).resolve().parent
LABEL = 'numpy-baseline-resume-pj-next-closed-wo'
sha = lambda b: hashlib.sha256(b).hexdigest()


def unpack(path, expected):
    body = path.read_bytes()
    assert sha(body) == expected
    with tarfile.open(fileobj=io.BytesIO(body)) as t:
        members = t.getmembers()
        assert all(m.isfile() for m in members)
        raw = {m.name: t.extractfile(m).read() for m in members}
        assert len(raw) == len(members)
    index = json.loads(raw['INTEGRITY.json'])
    assert set(raw) == set(index) | {'INTEGRITY.json'}
    assert all(sha(raw[n]) == h for n, h in index.items())
    return raw


def main():
    package = json.loads((BASE / (LABEL + '-package.json')).read_bytes())
    assert package['sha256'] == '1a8bcae59182f65fe0d72073c1f519bac0d93bb795e11c27160f3be7000fadff'
    raw = unpack(BASE / package['archive'], package['sha256'])
    parent = unpack(BASE / package['parent_public_archive'], package['parent_public_sha256'])
    assert len(raw) == package['artifacts'] == 520 and len(parent) == 385
    controls = json.loads(raw['controls/CONTROLS_SHA256.json'])
    assert len(controls) == 9
    assert sha(raw['controls/CONTROLS_SHA256.json']) == package['controls_manifest_sha256']
    for name, digest in controls.items():
        assert sha(raw['controls/' + name]) == digest
        assert raw['controls/' + name] == (BASE / 'numpy-baseline-resume-pj-preparation' / name).read_bytes()
    summary = json.loads(raw['SUMMARY.json'])
    assert all(summary[k] == package[k] for k in summary)
    parent_summary = json.loads(parent['SUMMARY.json'])
    rows = []
    for i in range(4):
        prefix = 'cases/' + str(i) + '/'
        current = {n[len(prefix):]: b for n, b in parent.items() if n.startswith(prefix)}
        parent_sha = parent_summary['rows'][i]['original_closed_archive_sha256']
        cold = current['own-cold-seed/own-cold-state.pkl']
        probe = {n: b for n, b in current.items() if n.startswith('first-resume-input-probe/')}
        for stop in [1008, 1488]:
            prefix = 'deltas/case-' + str(i) + '/stop-' + str(stop).zfill(7) + '/'
            delta = json.loads(raw[prefix + 'DELTA.json'])
            assert delta['parent_archive_sha256'] == parent_sha
            assert {n: sha(b) for n, b in current.items()} == delta['parent_members_sha256']
            previous = current
            current = {n: b for n, b in previous.items() if n not in delta['removed']}
            changed = delta['added'] + delta['replaced']
            assert len(changed) == len(set(changed))
            current.update({n: raw[prefix + 'files/' + n] for n in changed})
            assert set(raw_name[len(prefix+'files/'): ] for raw_name in raw if raw_name.startswith(prefix+'files/')) == set(changed)
            assert {n: sha(b) for n, b in current.items()} == delta['new_members_sha256']
            assert sorted(set(current) - set(previous)) == delta['added']
            assert sorted(set(previous) - set(current)) == delta['removed']
            assert sorted(n for n in current.keys() & previous.keys() if current[n] != previous[n]) == delta['replaced']
            assert sorted(n for n in current.keys() & previous.keys() if current[n] == previous[n]) == delta['unchanged']
            index = json.loads(current['ARTIFACT_SHA256.json'])
            assert set(current) == set(index) | {'ARTIFACT_SHA256.json'}
            assert all(sha(current[n]) == h for n, h in index.items())
            assert current['own-cold-seed/own-cold-state.pkl'] == cold
            assert all(current[n] == b for n, b in probe.items())
            assert sha(current['SOURCE_SHA256.json']) == package['source_manifest_sha256']
            assert len(json.loads(current['SOURCE_SHA256.json'])) == 584
            receipt = json.loads(current['receipt.json'])
            audit = json.loads(current['window-audit.json'])
            job = receipt['pbs_job']
            assert receipt['passed'] and receipt['error'] is None and receipt['source_unchanged']
            assert receipt['node'] == 'compute002' and receipt['original_steps_completed'] == receipt['original_steps_started'] == 480
            assert receipt['start'] == stop - 480 and receipt['stop'] == stop
            assert receipt['identity'] == audit['identity'] == delta['identity']
            assert receipt['parent_archive_sha256'] == parent_sha
            assert receipt['source_manifest_sha256'] == package['source_manifest_sha256']
            assert receipt['controls_manifest_sha256'] == package['controls_manifest_sha256']
            assert receipt['window_audit_sha256'] == sha(current['window-audit.json'])
            assert receipt['run_receipt_sha256'] == sha(current['run/receipt.json'])
            terms = json.loads(current['terminals.json'])
            assert job in terms
            for terminal_job, files in terms.items():
                q = current[files['qstat']]
                assert re.search(rb'^Job Id: ' + re.escape(terminal_job.encode()) + rb'\s*$', q, re.M)
                for key, value in [('job_state', 'F'), ('Exit_status', '0'), ('Stageout_status', '0')]:
                    assert re.search(rb'^\s*' + key.encode() + rb' = ' + value.encode() + rb'\s*$', q, re.M)
                assert current[files['parent_exit']].strip() == current[files['worker_exit']].strip() == b'0'
            closure = json.loads(current['closure-records/stop-' + str(stop).zfill(7) + '.json'])
            original = {n: current[n] for n in closure['original_result_members']}
            original['terminals.json'] = raw[prefix + 'result-originals/terminals.json']
            assert {n: sha(b) for n, b in original.items()} == closure['original_result_members']
            assert closure['original_result_archive_sha256'] == delta['original_result_archive_sha256']
            assert closure['parent_archive_sha256'] == parent_sha
            assert closure['controller_source_sha256'] == controls['controller_pj.py']
            assert audit['full_seven_tuple_at_original_resume_exact']['arrays'] == 20
            assert audit['full_seven_tuple_at_original_resume_exact']['scalars'] == 116
            assert audit['full_seven_tuple_at_original_resume_exact']['max_abs_difference'] == 0
            assert len(audit['original_trace_prefix_exact']) == 18
            assert all(v['max_abs_difference'] == 0 for v in audit['original_trace_prefix_exact'].values())
            assert all(v['max_abs_difference'] == 0 for v in audit['first_original_input_exact'].values())
            assert audit['full_BGC_chain']['records'] == stop
            assert audit['full_BGC_chain']['final_BGC_exact']['max_abs_difference'] == 0
            budget = audit['original_trace_budget']
            assert budget['intervals'] == stop and budget['original_bounds_preserved']
            assert budget['final_global_bounds_m_h_c_n'] == audit['bounds_m_h_c_n']
            assert all(abs(v) <= bound for v, bound in zip(audit['residual_m_h_c_n'], audit['bounds_m_h_c_n']))
            streams = json.loads(current['BGC_STREAMS.json'])
            assert streams['identity'] == receipt['identity']
            assert [(s['first_index'],s['stop_index']) for s in streams['streams']] == [(0,48)] + [(k,k+480) for k in range(48,stop,480)]
            for stream in streams['streams']:
                d = stream['directory'] + '/'
                assert sha(current[d+'BGC_STREAM.json']) == stream['header_sha256']
                header = json.loads(current[d+'BGC_STREAM.json'])
                assert header['successful_original_tendencies_recorded'] == stream['stop_index']-stream['first_index']
                assert header['original_call_completed_without_exception']
                assert sum(b['count'] for b in header['blocks']) == header['successful_original_tendencies_recorded']
                assert all(sha(current[d+b['file']]) == b['sha256'] for b in header['blocks'])
            assert audit['calendar_intervals'] == 17520 and not audit['complete_original_year']
            assert not audit['accepted_spinup'] and not audit['score_eligible'] and not audit['auto_cycle2']
            row = next(r for r in summary['rows'] if r['case_index']==i and r['stop']==stop)
            assert row['pbs_job']==job and row['residual_m_h_c_n']==audit['residual_m_h_c_n']
            assert row['bounds_m_h_c_n']==audit['bounds_m_h_c_n'] and row['original_trace_budget']==budget
            rows.append(dict(case_index=i,pbs_job=job,start=stop-480,stop=stop,new_steps=480,
                new_closed_members=len(current),original_worker_members=len(original),
                raw_zip_npz_replacements=[n for n in delta['replaced'] if n.endswith(('.zip','.npz'))],
                raw_BGC_zip_changes=[n for n in delta['replaced'] if n.startswith('bgc-') and n.endswith('.zip')],
                added=len(delta['added']),replaced=len(delta['replaced']),removed=len(delta['removed']),
                all_original_file_hashes_reconstructed=True,original_tar_container_bytes_reconstructed=False,
                original_worker_members_reconstructed=True,actual_F0=True,actual_Stageout0=True,
                residual_m_h_c_n=audit['residual_m_h_c_n'],bounds_m_h_c_n=audit['bounds_m_h_c_n']))
            parent_sha = delta['new_archive_sha256']
    result = dict(review_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),passed=True,
        blocking_findings=[],archive_sha256=package['sha256'],artifacts=520,inventory_files=519,
        parent_public_archive_sha256=package['parent_public_sha256'],source_files=584,
        controls=9,controls_manifest_sha256=package['controls_manifest_sha256'],
        reconstructed_closed_file_versions=sum(r['new_closed_members'] for r in rows),
        actual_new_steps=3840,new_complete_years=0,accepted_spinup=False,score_executed=False,
        arrays_or_pickle_decoded_locally=0,physics_executed_by_this_review=0,
        scope='Local stdlib hash/JSON/terminal and exact original-file reconstruction. Numerical seven-tuple/prefix/first-input/BGC and hard M/H/C/N checks were executed by original EHPC workers, not recomputed here. No original compressed tar.gz byte reconstruction claimed; full remote archives retained.',
        rows=rows)
    target=BASE/(LABEL+'-reconstruction-review.json')
    target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed=True,review=str(target),sha256=sha(target.read_bytes()),
        reconstructed_file_versions=result['reconstructed_closed_file_versions'],actual_new_steps=3840)))


if __name__ == '__main__':
    main()

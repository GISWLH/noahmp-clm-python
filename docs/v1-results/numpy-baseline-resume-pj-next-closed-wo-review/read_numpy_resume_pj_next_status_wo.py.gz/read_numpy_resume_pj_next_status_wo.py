"""Read-only PJ manager/process/scheduler snapshot; no model imports or control."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import socket
import subprocess

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')
assert socket.gethostname() == 'manager'
sha = lambda b: hashlib.sha256(b).hexdigest()
progress_raw = (ROOT / 'PROGRESS.json').read_bytes()
progress = json.loads(progress_raw)
pid = 48727
folder = Path('/proc') / str(pid)
parts = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
cmdline = (folder / 'cmdline').read_bytes().replace(b'\0', b' ').decode().strip()
assert int(parts[19]) == 269100908 and str(ROOT / 'preparation/controller_pj.py') in cmdline
state = dict(pid=pid, start_ticks=int(parts[19]), state=parts[0], cmdline=cmdline)
jobs = {}
for case in progress['cases']:
    for job in {case.get('job')} | {h['job'] for h in case['history'] if h['start'] >= 528}:
        if job is None or job in jobs:
            continue
        p = subprocess.run(['qstat', '-xf', job], capture_output=True, text=True)
        jobs[job] = dict(exit=p.returncode, stdout=p.stdout, stderr=p.stderr)
controls = json.loads((ROOT / 'preparation/CONTROLS_SHA256.json').read_bytes())
assert all(sha((ROOT / 'preparation' / n).read_bytes()) == h for n, h in controls.items())
print(json.dumps(dict(sample_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    manager_process=state, controls_manifest_sha256=sha((ROOT / 'preparation/CONTROLS_SHA256.json').read_bytes()),
    PROGRESS_sha256=sha(progress_raw), progress=progress, scheduler=jobs,
    scope='Read-only existing controller and actual PBS state; no new submit, restart, physics or numerical data decoding.'), indent=2))

from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'phase-final-check-cpu-a'
scratch = Path(os.environ['TMPDIR'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
roots = {}
for label, name, digest in [('baseline', 'p6-stem-assessment-b-source.tar.gz', '8a378a471cd163958ca01cb9184343e79624af5f05e427b9397eaffd17cb2ca0'), ('candidate', 'p6-phase-final-check-a-source.tar.gz', '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87')]:
    a = b / name
    assert sha(a) == digest
    s = scratch / label
    s.mkdir()
    with tarfile.open(a) as t:
        t.extractall(s, filter='data')
    manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
    assert len(manifest) == 506 and all(sha(s / n) == v for n, v in manifest.items())
    roots[label] = (s, manifest)
new, m = roots['candidate']
old, om = roots['baseline']
assert sorted(n for n in m if m[n] != om[n]) == ['src/noahmp_clm/physics/canopy_phase_energy.py', 'tests/test_canopy_phase_energy.py']
(old / 'tests/test_canopy_phase_energy.py').write_bytes((new / 'tests/test_canopy_phase_energy.py').read_bytes())
om = {n: sha(old / n) for n in om}
(r / 'baseline-observed-manifest.json').write_text(json.dumps(om, indent=2) + '\n')
(r / 'SOURCE_SHA256.json').write_bytes((new / 'SOURCE_SHA256.json').read_bytes())
targets = ['tests/test_canopy_phase_energy.py::test_phase_root_reached_by_last_permitted_update_is_accepted', 'tests/test_canopy_phase_energy.py::test_exhausted_phase_updates_still_reject_an_unconverged_final_state']

def run(label, s, manifest, files, expected, expected_failure=False):
    env = os.environ.copy()
    env.update(PYTHONPATH=':'.join(map(str, [b / 'test-deps', s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    env.pop('NOAHMP_REQUIRE_GPU', None)
    start = time.monotonic()
    xml = r / (label + '.xml')
    with (r / (label + '.log')).open('x') as log:
        code = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-s', *files, '--junitxml=' + str(xml)], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    tree = ET.parse(xml).getroot()
    counts = {k: sum(int(v.attrib[k]) for v in tree.iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
    failures = [v.attrib['name'] for v in tree.iter('testcase') if v.find('failure') is not None]
    unchanged = all(sha(s / n) == v for n, v in manifest.items())
    record = dict(scope='Real nonlinear phase-solver final-update regression and full CPU suite on EHPC PBS only. Baseline failure intentionally demonstrates missing final-state check; never counted as pass. Original tolerances/update limits/equations/MHCN unchanged. No climate/scientific/GPU acceptance.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, label=label, returncode=code, expected_failure=expected_failure, counts=counts, failures=failures, source_unchanged=unchanged, source_files=506, seconds=time.monotonic() - start, xml_sha256=sha(xml))
    (r / (label + '-receipt.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if expected_failure:
        return code == 1 and unchanged and counts == dict(tests=2, failures=1, errors=0, skipped=0) and failures == ['test_phase_root_reached_by_last_permitted_update_is_accepted']
    return code == 0 and unchanged and counts == dict(tests=expected, failures=0, errors=0, skipped=0)

assert run('original-regression', old, om, targets, 2, True)
assert run('fixed-regression', new, m, targets, 2)
files = sorted(p.relative_to(new).as_posix() for p in (new / 'tests').glob('test_*.py') if not p.name.startswith(('test_gpu', 'test_jax', 'test_cuda')))
assert run('cpu-full', new, m, files, 901)

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-phase-final-check-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((s/'full-by-file-a/summary.json').read_text());assert d['status']=='complete' and d['collected_nodes']==d['covered_nodes']==1241 and d['all_node_coverage_exact'] and json.loads((s/'full-controller-a/exit.json').read_text())['returncode']==0
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==h for n,h in m.items());a=b/'phase-final-check-full-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    for name in ['full-by-file-a','full-controller-a']:
        for p in sorted((s/name).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
    for label,digest in [('phase-final-check-cpu-a','a72ad75742c43827353d22e7cccd78edc6018886ec42c24591fffef5d8ccf698'),('phase-final-check-gpu-a','207a105f9c36ee4111bd13c2a60c2cae77fda6ae457849fdc3055eba269e8ebd')]:
        p=b/(label+'-evidence.tar.gz');assert sha(p)==digest;t.add(p,arcname='prerequisites/'+p.name,recursive=False)
    for n in ['run_phase_full_gpu_a.py','collect_phase_full_gpu_a.py','wait_phase_full_gpu_a.py','launch_phase_full_gpu_a.py','archive_legacy506_full_h.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Original frozen506 canonical1241 actualcomplete with exactnodecoverage/actualparent0. Originalallreceipts/XML/setup-call-teardown/barriers/source andoriginal prerequisites retained. Oldsource only, no current519H1297/science/year credit.')))

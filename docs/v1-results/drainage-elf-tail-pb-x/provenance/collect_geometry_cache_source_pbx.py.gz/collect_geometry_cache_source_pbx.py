"""Read actual CuPy compiler/cache-writer sources and preserve transfer identities."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
OUT=BASE/'drainage-elf-tail-pb-x'
REMOTE='/home/lhwang/venvs/noahmp-phase3b/lib/python3.12/site-packages/cupy/cuda/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main():
    result=OUT/'SOURCE_COLLECTION.json';assert not result.exists()
    paths=[REMOTE+n for n in ('compiler.py','_compiler_cache.py')]
    command='sha256sum '+' '.join(paths)
    commands=[('before',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang',command]),
        ('scp',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12',*['xuanze-neiwang:'+p for p in paths],str(OUT)]),
        ('after',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang',command])]
    rows=[]
    for label,args in commands:
        r=subprocess.run(args,capture_output=True,timeout=120)
        (OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr)
        rows.append(dict(label=label,command=args,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)))
        assert r.returncode==0,r.stderr.decode(errors='replace')
    assert (OUT/'before.stdout').read_bytes()==(OUT/'after.stdout').read_bytes()
    expected={Path(line.split()[1]).name:line.split()[0] for line in (OUT/'before.stdout').read_text().splitlines()}
    assert all(sha((OUT/n).read_bytes())==h for n,h in expected.items())
    assert expected['compiler.py']=='09226d26ab41bf6e7b5b6e57b59187b4c3a5637690747af9a83d288a87d0fb6e'
    report=dict(actual_commands=rows,source_hashes=expected,source_unchanged_during_read=True,
        compiler_source_matches_successful_PBv_worker_hash=True,static_read_only=True,GPU_calls=0,NumPy_imports=0)
    result.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()

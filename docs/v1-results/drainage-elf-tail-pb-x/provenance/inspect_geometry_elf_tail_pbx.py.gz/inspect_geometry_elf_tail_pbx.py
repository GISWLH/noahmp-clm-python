"""Read-only ELF64 structure bounds on exact archived CUDA module bytes."""
from pathlib import Path
import hashlib
import json
import struct

BASE=Path(__file__).resolve().parent
INPUT=BASE/'drainage-geometry-pb-v-loaded-cuda-disassembly'
OUT=BASE/'drainage-elf-tail-pb-x'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
HEADER_KEYS=('e_ident','e_type','e_machine','e_version','e_entry','e_phoff','e_shoff','e_flags',
    'e_ehsize','e_phentsize','e_phnum','e_shentsize','e_shnum','e_shstrndx')
SECTION_KEYS=('sh_name','sh_type','sh_flags','sh_addr','sh_offset','sh_size','sh_link','sh_info','sh_addralign','sh_entsize')
PROGRAM_KEYS=('p_type','p_flags','p_offset','p_vaddr','p_paddr','p_filesz','p_memsz')

def inspect(path):
    raw=path.read_bytes();assert raw[:6]==b'\x7fELF\x02\x01' and len(raw)>=64
    header=dict(zip(HEADER_KEYS,struct.unpack_from('<16sHHIQQQIHHHHHH',raw)))
    header['e_ident']=header['e_ident'].hex()
    assert header['e_ehsize']==64 and header['e_shentsize']==64 and header['e_phentsize']==56
    assert header['e_shnum']>0 and header['e_shstrndx']<header['e_shnum']
    sections=[]
    for k in range(header['e_shnum']):
        offset=header['e_shoff']+k*64
        row=dict(index=k,table_entry_offset=offset,table_entry_expected_end=offset+64,
            table_entry_available_bytes=max(0,min(64,len(raw)-offset)))
        if row['table_entry_available_bytes']==64:
            row.update(zip(SECTION_KEYS,struct.unpack_from('<IIQQQQIIQQ',raw,offset)))
            end=row['sh_offset']+row['sh_size']
            row.update(declared_offset_plus_size=end,NOBITS_no_file_payload=row['sh_type']==8,
                declared_file_payload_end=(row['sh_offset'] if row['sh_type']==8 else end),
                missing_declared_file_payload_bytes=(0 if row['sh_type']==8 else max(0,end-len(raw))))
        sections.append(row)
    strings=sections[header['e_shstrndx']]
    assert strings['table_entry_available_bytes']==64 and strings['missing_declared_file_payload_bytes']==0
    names=raw[strings['sh_offset']:strings['sh_offset']+strings['sh_size']]
    for row in sections:
        if 'sh_name' in row:
            start=row['sh_name'];end=names.find(b'\0',start)
            row['name']=names[start:end].decode() if end>=0 else None
    programs=[]
    for k in range(header['e_phnum']):
        offset=header['e_phoff']+k*56;available=max(0,min(56,len(raw)-offset))
        row=dict(index=k,table_entry_offset=offset,table_entry_expected_end=offset+56,table_entry_available_bytes=available)
        if available>=48:
            row.update(zip(PROGRAM_KEYS,struct.unpack_from('<IIQQQQQ',raw,offset)))
            end=row['p_offset']+row['p_filesz']
            row.update(declared_file_payload_end=end,missing_declared_file_payload_bytes=max(0,end-len(raw)))
            align=raw[offset+48:min(offset+56,len(raw))]
            row['p_align_field']=dict(offset=offset+48,expected_bytes=8,available_bytes=len(align),available_bytes_hex=align.hex(),
                value=(struct.unpack('<Q',align)[0] if len(align)==8 else None))
        programs.append(row)
    sh_end=header['e_shoff']+header['e_shentsize']*header['e_shnum']
    ph_end=header['e_phoff']+header['e_phentsize']*header['e_phnum']
    return dict(file=path.name,file_sha256=sha(raw),actual_file_bytes=len(raw),header=header,
        section_table_declared_end=sh_end,section_table_missing_bytes=max(0,sh_end-len(raw)),sections=sections,
        program_table_declared_end=ph_end,program_table_missing_bytes=max(0,ph_end-len(raw)),programs=programs,
        final32_actual_bytes_hex=raw[-32:].hex(),file_modified=False,bytes_appended=0)

def main():
    assert not OUT.exists();OUT.mkdir()
    proof=json.loads((INPUT/'EXTRACTION_PROOF.json').read_bytes());rows=[]
    for label,record in proof['extracted'].items():
        path=INPUT/record['extracted_file'];assert sha(path.read_bytes())==record['extracted_ELF_sha256']
        row=inspect(path);rows.append(row)
        assert row['section_table_missing_bytes']==0 and all(r.get('missing_declared_file_payload_bytes',0)==0 for r in row['sections'])
        assert row['program_table_missing_bytes']==1
        assert row['programs'][-1]['p_align_field']['available_bytes']==7
    report=dict(completed=True,pure_static_binary_metadata=True,GPU_calls=0,NumPy_imports=0,bytes_modified_or_appended=0,
        original_GPU_result_sha256=proof['original_GPU_result_sha256'],ELF=rows,
        conclusion='Both exact cache-extracted ELF files contain all declared section table entries and file-backed section payloads. Each file ends one byte before its declared four-entry program-header table end, specifically the last byte of program header3 p_align. This identifies a concrete structural shortfall explaining why a parser can report truncated, without supplying or modifying the absent byte or proving where it was removed.')
    (OUT/'ELF_STRUCTURE.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(completed=True,files=[dict(file=r['file'],bytes=r['actual_file_bytes'],
        e_shoff=r['header']['e_shoff'],e_shentsize=r['header']['e_shentsize'],e_shnum=r['header']['e_shnum'],
        section_table_end=r['section_table_declared_end'],program_table_end=r['program_table_declared_end'],
        missing_program_table_bytes=r['program_table_missing_bytes'],last_field=r['programs'][-1]['p_align_field']) for r in rows])))

if __name__=='__main__':main()

"""Bounded ELF-tail/cache-writer inspection evidence; no numeric/GPU work."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
ROOT=BASE/'drainage-elf-tail-pb-x'
PRIOR=BASE/'drainage-geometry-pb-v-loaded-cuda-disassembly'
LABEL='drainage-elf-tail-pb-x'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    structure=json.loads((ROOT/'ELF_STRUCTURE.json').read_bytes());collection=json.loads((ROOT/'SOURCE_COLLECTION.json').read_bytes())
    assert structure['completed'] and structure['bytes_modified_or_appended']==0
    assert all(x['actual_exit']==0 for x in collection['actual_commands']) and collection['source_unchanged_during_read']
    assert collection['compiler_source_matches_successful_PBv_worker_hash']
    for n,h in collection['source_hashes'].items():assert sha((ROOT/n).read_bytes())==h
    compiler=(ROOT/'compiler.py').read_text().splitlines();cache=(ROOT/'_compiler_cache.py').read_text().splitlines()
    compiler_lines=(584,585,759,781,870);cache_lines=(109,142,145,176)
    assert 'parts.append(cubin)' in compiler[583] and 'nvrtc.getCUBIN' in compiler[869]
    assert "+ cubin" in cache[108] and 'tf.write(data)' in cache[141]
    writer=dict(actual_source_hashes=collection['source_hashes'],source_snapshot_read_exits=[0,0,0],
        compiler_statements=[dict(line=k,text=compiler[k-1]) for k in compiler_lines],
        cache_backend_statements=[dict(line=k,text=cache[k-1]) for k in cache_lines],
        conclusion='The actual captured-version Python compiler route forwards getCUBIN bytes, appends those bytes to the named-module header, then stores SHA1+payload through verbatim tf.write and atomic replace. No trailing-NUL removal occurs in these observed format/write statements. The lower-level NVRTC return/binding behavior was not inspected, so this does not identify where the last byte became absent.')
    readout=dict(static_inspection_completed=True,ELF_structure=[dict(file=x['file'],actual_file_bytes=x['actual_file_bytes'],
        e_shoff=x['header']['e_shoff'],e_shentsize=x['header']['e_shentsize'],e_shnum=x['header']['e_shnum'],
        section_table_declared_end=x['section_table_declared_end'],section_table_missing_bytes=x['section_table_missing_bytes'],
        every_file_backed_section_payload_present=all(r.get('missing_declared_file_payload_bytes',0)==0 for r in x['sections']),
        program_table_declared_end=x['program_table_declared_end'],program_table_missing_bytes=x['program_table_missing_bytes'],
        last_program_header_p_align=x['programs'][-1]['p_align_field']) for x in structure['ELF']],
        cache_writer=writer,GPU_calls=0,NumPy_imports=0,ELF_modified=False,bytes_appended=0,
        scope='Concrete ELF program-header last-byte shortfall identified in exact original cache bytes. Existing sections are complete. Actual Python cache format/writer forwards bytes without a trim at the checked statements; removal origin remains unproved. No repair, padding, recompilation, disassembly success or numerical cause is asserted.')
    items={'readout.json':encode(readout),'cache-writer-readout.json':encode(writer)}
    for p in ROOT.iterdir():
        if p.is_file():items['raw-static-inspection/'+p.name]=p.read_bytes()
    for n in ('EXTRACTION_PROOF.json','original-diagnosis-original-cache.bin','geometry-probe-original-cache.bin','original-diagnosis.cubin','geometry-probe.cubin'):
        items['original-cache-ELF/'+n]=(PRIOR/n).read_bytes()
    for n in ('inspect_geometry_elf_tail_pbx.py','collect_geometry_cache_source_pbx.py',Path(__file__).name):items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;archive.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Read-only exact ELF/header/section/program-table bounds and actual CuPy Python cache source. Both saved ELF files lack program-header table final1 byte, all file-backed sections intact; no bytes altered/padded, no GPU/NumPy/compile/numerical cause credit.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package))
    print(json.dumps(package))

if __name__=='__main__':main()

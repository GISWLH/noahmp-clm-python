from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');out=base/'ctsm-forcing-contract-a';out.mkdir(exist_ok=False);sha=lambda b:hashlib.sha256(b).hexdigest();archive=base/'ctsm-reference-source-bundle-a.tar.gz';assert sha(archive.read_bytes())=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
files={}
with tarfile.open(archive) as t:
    for m in t:
        if not m.isfile():continue
        p=Path(m.name);n=m.name.lower()
        if ('datm' in n and any(x in n for x in ['buildnml','streams','namelist_definition','namelist_defaults','config_component'])) or ('userdat' in n and p.suffix in ['.xml','.md','.rst','.txt']):
            raw=t.extractfile(m).read();target=out/'selected-upstream'/m.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);files[m.name]=dict(sha256=sha(raw),bytes=len(raw))
generated={}
with tarfile.open(base/'ctsm-case-build-h/case-configuration-private.tar.gz') as t:
    for m in t:
        if m.isfile() and any(v in m.name for v in ['datm.streams','datm_in','datm.input_data_list','lnd_in','user_nl_datm','env_run.xml']):
            raw=t.extractfile(m).read();target=out/'generated-build-h'/m.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);generated[m.name]=dict(sha256=sha(raw),bytes=len(raw))
record=dict(scope='Read-only pinned upstream/generated configuration contract inventory. No source edits, forcing generation, model execution or scientific comparison.',upstream_source_bundle_sha256=sha(archive.read_bytes()),selected_upstream=files,generated_build_h=generated);(out/'inventory.json').write_text(json.dumps(record,indent=2)+'\n');(out/Path(__file__).name).write_bytes(Path(__file__).read_bytes());print(json.dumps(dict(upstream_files=len(files),generated_files=len(generated),paths=list(files),generated_paths=list(generated))))

from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-j';folder=root/'cuda-day';source=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in m.items())
checkpoints=list(folder.glob('state-0004176-*.npz'));assert len(checkpoints)==1;checkpoint=checkpoints[0];checkpoint_sha=sha(checkpoint)
pairs=[(checkpoint,checkpoint.name),(root/'batch.json','input-batch.json'),(root/'protocol.json','input-protocol.json'),(source/'SOURCE_SHA256.json','gpu-SOURCE_SHA256.json')];rows=[]
for site in ['CN-Cng','CN-Qia','CN-Cha','CN-HaM']:
    case=site+'-suction-climate-cycle';directory=folder/case;reports=list(directory.glob('report-0004176-*.json'));assert len(reports)==1
    p=reports[0];r=json.loads(p.read_text());trace=directory/r['model_npz']
    assert r['status']=='running' and r['steps_completed']==4176 and r['steps_requested']==17520 and r['source_unchanged']
    assert r['batch_checkpoint_sha256']==checkpoint_sha and sha(trace)==r['model_npz_sha256']
    pairs += [(p,case+'/'+p.name),(trace,case+'/'+trace.name)]
    rows.append(dict(case=case,report=p.name,report_sha256=sha(p),trace=trace.name,trace_sha256=sha(trace),configuration_sha256=r['configuration_sha256']))
identity=root/'immutable-4176-export.json';assert not identity.exists()
identity.write_text(json.dumps(dict(scope='Derived export index of original immutable4176 per-case reports/traces and matching original checkpoint. Original year remains17520requested; no replacement complete global report is constructed.',utc=datetime.now(timezone.utc).isoformat(),source_files=len(m),source_unchanged=True,checkpoint_file=checkpoint.name,checkpoint_sha256=checkpoint_sha,cases=rows),indent=2)+'\n')
pairs.append((identity,identity.name));pairs.append((Path(__file__),Path(__file__).name));archive=base/'most-j4176-prefix-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(path=str(archive),sha256=sha(archive),files=len(pairs))))

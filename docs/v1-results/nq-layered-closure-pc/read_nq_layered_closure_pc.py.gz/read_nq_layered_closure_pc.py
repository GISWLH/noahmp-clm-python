from pathlib import Path
import base64,hashlib,json
root=Path('/home/lhwang/work/noahmp-v1/candidate-full-gpu-nq')
stem='test_gpu_clm_layered_column'
names=[stem+s for s in ['-exit.json','-receipt.json','-expected.json','.log','.xml']]+['3860986-cache-events.jsonl','SOURCE_SHA256.json','plan.json']
files={name:(root/name).read_bytes() for name in names}
parent=json.loads(files[stem+'-exit.json'])
assert parent['actual_parent_returncode']==0 and parent['expected_tests']==5
assert hashlib.sha256(files[stem+'-receipt.json']).hexdigest()==parent['receipt_sha256']
print(json.dumps({'files':{n:base64.b64encode(b).decode() for n,b in files.items()}}))

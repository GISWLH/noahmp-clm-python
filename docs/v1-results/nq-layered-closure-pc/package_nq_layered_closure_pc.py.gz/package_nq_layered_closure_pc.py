"""Preserve closed CUDA1 output and refresh ETA using original timing rules."""
from pathlib import Path
import ast
import base64
import gzip
import hashlib
import io
import json
import math
import re
import tarfile
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
LABEL = 'nq-layered-closure-pc'
STEM = 'test_gpu_clm_layered_column'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
files = {name: base64.b64decode(value) for name, value in
         json.loads((OUT / (LABEL + '-raw.json')).read_bytes())['files'].items()}
parent = json.loads(files[STEM + '-exit.json'])
receipt = json.loads(files[STEM + '-receipt.json'])
expected = json.loads(files[STEM + '-expected.json'])
manifest = json.loads(files['SOURCE_SHA256.json'])
assert parent['actual_parent_returncode'] == 0 and parent['passed'] and parent['expected_tests'] == 5
assert sha(files[STEM + '-receipt.json']) == parent['receipt_sha256']
assert receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0 and receipt['passed']
assert receipt['counts'] == dict(tests=5, failures=0, errors=0, skipped=0)
assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed'] and receipt['source_unchanged']
assert receipt['nodes'] == expected and len(expected) == len(set(expected)) == 5
assert sha(files[STEM + '-expected.json']) == receipt['expected_nodes_sha256']
assert sha(files[STEM + '.xml']) == receipt['xml_sha256']
assert sha(files['SOURCE_SHA256.json']) == receipt['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert receipt['source_files'] == len(manifest) == 584
assert {r['backend']: r['status'] for r in receipt['device_barriers']} == {'jax': 'complete', 'cupy': 'complete'}
cases = list(ET.fromstring(files[STEM + '.xml']).iter('testcase'))
assert len(cases) == 5 and all(c.find(tag) is None for c in cases for tag in ['failure', 'error', 'skipped'])
reference = {'float32': {}, 'float64': {}}
budgets, same, cuda_budgets = [], [], []
for line in files[STEM + '.log'].decode().splitlines():
    match = re.fullmatch(r"\.*layered full column <class 'numpy\.(float32|float64)'> (\d+) (\{.*\})", line)
    if match:
        dtype, index, payload = match.groups()
        assert index not in reference[dtype]
        reference[dtype][index] = ast.literal_eval(payload)
    match = re.fullmatch(r'\.*layered full budgets (\{.*\})', line)
    if match:
        budgets.append(ast.literal_eval(match[1]))
    match = re.fullmatch(r'\.*layered full same precision ([0-9.eE+\-]+)', line)
    if match:
        same.append(float(match[1]))
    match = re.fullmatch(r'\.*layered full CUDA budgets (\{.*\})', line)
    if match:
        cuda_budgets.append(ast.literal_eval(match[1]))
assert all(set(rows) == {str(i) for i in range(16)} for rows in reference.values())
assert len(budgets) == 2 and same == [0.] and len(cuda_budgets) == 1
scalar_max = {dtype: {key: max(row[key] for row in rows.values())
                     for key, value in next(iter(rows.values())).items() if isinstance(value, (int, float))}
              for dtype, rows in reference.items()}
quantified = dict(tests=5, actual_parent_exit=0, actual_worker_exit=0, parent_seconds=parent['seconds'],
                 worker_seconds=receipt['seconds'], pytest_main_seconds=receipt['pytest_seconds'],
                 scalar_absolute_reference_maxima=scalar_max, original_16_rows_per_dtype=reference,
                 original_budget_logs_in_dtype_order=budgets, original_cuda_budget=cuda_budgets[0],
                 same_precision_full_return_max_absolute_difference=same[0],
                 limitations=['Absolute differences only; no relative error inferred without reference magnitudes.',
                              'Budget maxima are not paired with maximum bounds; original per-column assertions passed.',
                              'Original worker bypasses atexit after device/node/source closure; interpreter shutdown is not validated.',
                              'This one module contributes five completed tests, not annual or full-suite acceptance.'])

snapshot_raw = (OUT / 'candidate-progress-pc.json').read_bytes()
snapshot = json.loads(snapshot_raw)
timing_raw = (OUT / 'GPU_ETA_NQ.json').read_bytes()
timing = json.loads(timing_raw)
modules = {row['file']: row for row in timing['modules_in_execution_order']}
closed = {row['file']: row for row in snapshot['closed']}
assert closed[STEM + '.py'] == parent
assert all(r['passed'] and r['actual_parent_returncode'] == 0 and r['expected_tests'] == modules[n]['tests'] for n, r in closed.items())
fresh = sum(row['expected_tests'] for row in closed.values())
reused = sum(row['tests'] for row in snapshot['progress']['reused'])
assert (fresh, reused) == (113, 32)
remaining = [row for name, row in modules.items() if name not in closed]
recent = [row for row in remaining if row['timing_group'] in ('JO_recent', 'IV_recent')]
older = [row for row in remaining if row not in recent]
assert len(older) == 49 and sum(row['tests'] for row in remaining) + fresh + reused == 408
recent_seconds = math.fsum(row['baseline_min_seconds'] for row in recent)
hours = [(recent_seconds + factor * math.fsum(row['baseline_' + bound + '_seconds'] for row in older))/3600.
         for factor, bound in [(1.3, 'min'), (2.6, 'max')]]
uuid = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
assert all(row['environment']['CUDA_VISIBLE_DEVICES'] == uuid for row in snapshot['second']['processes'])
years = {}
for name, run in snapshot['years'].items():
    rows = [json.loads(line) for line in run['log_tail']]
    first, last = rows[0], rows[-1]
    assert last['steps'] == run['steps_completed'] and last['steps'] > first['steps']
    seconds_per_step = (last['seconds'] - first['seconds'])/(last['steps'] - first['steps'])
    years[name] = dict(steps_completed=run['steps_completed'], steps_requested=run['steps_requested'],
                      window_start=first, window_stop=last, seconds_per_batch_step=seconds_per_step,
                      remaining_hours=(run['steps_requested']-run['steps_completed'])*seconds_per_step/3600.)
estimate = dict(utc=snapshot['second']['utc'], gpu_uuid=uuid, all_observed_processes_bound=True,
                completed_tests=fresh+reused, fresh=fresh, reused=reused, requested_tests=408,
                active_module=snapshot['progress']['file'], queue_remaining_hours=hours,
                current_module_elapsed_credit_seconds=0, formula=timing['estimate']['formula'], years=years,
                input_sha256={'candidate-progress-pc.json': sha(snapshot_raw), 'GPU_ETA_NQ.json': sha(timing_raw)},
                scope='Conditional winter-prefix estimates under concurrency. Parallel durations are not added. Excludes later spinup/calibration/release; no throughput guarantee.')
items = {'original/' + name: raw for name, raw in files.items()}
with tarfile.open(OUT / 'climatology-final-candidate-nm-source.tar.gz') as source:
    for name in ['tests/test_gpu_clm_layered_column.py', 'tests/test_gpu_clm_enthalpy_column.py']:
        raw = source.extractfile(name).read()
        assert sha(raw) == manifest[name]
        items['original-source/' + name] = raw
assert sha(items['original-source/tests/test_gpu_clm_layered_column.py']) == receipt['test_sha256']
items.update({'quantified.json': encode(quantified), 'candidate-estimate-pc.json': encode(estimate),
              'candidate-progress-pc.json': snapshot_raw, 'GPU_ETA_NQ.json': timing_raw,
              'package_nq_layered_closure_pc.py': Path(__file__).read_bytes(),
              'read_nq_layered_closure_pc.py': (OUT / 'read_nq_layered_closure_pc.py').read_bytes()})
items['inventory.json'] = encode({n: dict(sha256=sha(b), bytes=len(b)) for n, b in sorted(items.items())})
target = OUT / (LABEL + '-evidence.tar.gz')
with target.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name, raw in sorted(items.items()):
            member = tarfile.TarInfo(name); member.size = len(raw); member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as archive:
    assert {m.name: archive.extractfile(m).read() for m in archive} == items
package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
               artifacts=len(items), actual_parent_exit=0, tests=5, completed_gpu_tests=145,
               scope='Original NQ layered-column five-node closure, original log numbers and actual CUDA1 status/conditional ETA; no new model or test execution.')
(OUT / (LABEL + '-package.json')).write_bytes(encode(package))
(OUT / (LABEL + '-quantified.json')).write_bytes(encode(quantified))
(OUT / 'candidate-estimate-pc.json').write_bytes(encode(estimate))
print(json.dumps(dict(package=package, reference_maxima=scalar_max, same_precision=same[0], queue_hours=hours,
                     years={n: {k: v for k, v in row.items() if not k.startswith('window')} for n, row in years.items()})))

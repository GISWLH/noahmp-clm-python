from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-heat-reference-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for folder,count in [('richards-numpy-c',28),('richards-cpu-full-c',1037)]:
    d=json.loads((b/folder/'receipt.json').read_text());assert (b/folder/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=count,failures=0,errors=0,skipped=0)
a=b/'richards-numpy-c-source.tar.gz';assert sha(a)=='ae2cbfb94669326fcb0efa0d5ea9ce30a128214813112fafd59f8741a6f08a9b'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==538 and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s/'src'),str(s/'tests')]
from noahmp_clm.physics.richards import redistribute_soil_enthalpy
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.column import SoilParams
from test_richards import initial_soil,profile
cases=[];start=time.monotonic()
for kind,option in [('warm',1),('warm_day',1),('ten_layers',1),('frozen',1),('frozen',2),('dry_warm',1),('all_dry',1)]:
    dz=profile().dz_m;theta=np.array([.35,.24,.28,.25]);temperature=np.array([285.,294.,281.,300.]);duration=1800.
    if kind=='warm_day':duration=86400.
    if kind=='ten_layers':dz=profile(10).dz_m;theta=np.full(10,.28);temperature=285.+5.*np.sin(np.arange(10));duration=21600.
    if kind=='frozen':theta=np.array([.3,.31,.29,.35]);temperature=np.array([271.,274.,272.,276.]);duration=21600.
    if kind=='dry_warm':theta=np.array([.3,0.,.25,.28])
    if kind=='all_dry':theta=np.zeros(4);duration=86400.
    cases.append((kind,initial_soil(theta,temperature,dz,option),duration))
data={};records=[]
for precision,dtype in [('32',np.float32),('64',np.float64)]:
    for index,(label,state,duration) in enumerate(cases):
        params=np.array([state.params.smcmax,state.params.bexp,state.params.satdk,state.params.saturated_suction_m],dtype)
        cells=np.column_stack((state.water,state.enthalpy,state.dz)).astype(dtype)
        p=SoilParams(smcmax=float(params[0]),bexp=float(params[1]),satdk=float(params[2]),saturated_suction_m=float(params[3]))
        initial=SoilEnthalpyState(cells[:,0].astype(float),cells[:,1].astype(float),cells[:,2].astype(float),p,state.freezing_option)
        final,ledger=redistribute_soil_enthalpy(initial,duration)
        prefix=precision+'/'+str(index)+'/'
        data.update({prefix+'cells':cells[None,:,:],prefix+'properties':params[None,:],prefix+'options':np.array([state.freezing_option],np.int32),prefix+'dt':np.array([duration],dtype)})
        expected=dict(cells=np.column_stack((final.water,final.enthalpy,final.dz)),temperature_k=final.temperature,
            liquid_kg_m2=final.liquid,ice_kg_m2=final.water-final.liquid,**ledger)
        data.update({prefix+'expected/'+k:np.asarray(v)[None,...] for k,v in expected.items()})
        records.append(dict(precision=precision,index=index,label=label,option=state.freezing_option,layers=len(final.water),
            mass_heat_residual=ledger['residual_mass_heat'].tolist(),original_bounds=ledger['bound_mass_heat'].tolist()))
assert len(records)==14
np.savez_compressed(r/'richards_heat_reference.npz',**data)
d=dict(scope='EHPC compute-only original538C NumPy water/enthalpy reference after actual independentODE28 and full1037. Seven warm/frozen1&2/dry/4&10layer inputs at each quantized32/64, full M/H and authoritative states retained. No GPU/column/year/science acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,
    source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),reference_sha256=sha(r/'richards_heat_reference.npz'),cases=records,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

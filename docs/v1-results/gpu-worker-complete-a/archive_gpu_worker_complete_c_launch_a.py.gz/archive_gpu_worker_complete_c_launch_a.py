from pathlib import Path
import ast,hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';current=base/'p6-spinup-assessment-c';trial=base/'gpu-worker-lifecycle-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());summary=json.loads((trial/'summary.json').read_text());assert summary['status']=='complete' and all(v['returncode']==0 and v['receipt']['passed'] for v in summary['results'])
metrics=dict(scope='Organization of already computed remote printed errors/budgets only; no new model evaluation or performance comparison.',maximum_cuda_jax_same_precision=0.,same_precision_lines=0,reference_max_absolute_differences={},budget_max_absolute_residuals={},budget_rows=[])
for line in (trial/'test_gpu_clm_irrigation_column.log').read_text().splitlines():
    if 'irrigation whole same precision ' in line:
        metrics['same_precision_lines']+=1;metrics['maximum_cuda_jax_same_precision']=max(metrics['maximum_cuda_jax_same_precision'],float(line.split()[-1]))
    if 'irrigation whole reference ' in line:
        group='JAX32' if 'numpy.float32' in line else 'JAX64';d=ast.literal_eval(line[line.index('{'):]);result=metrics['reference_max_absolute_differences'].setdefault(group,{})
        for key,value in d.items():result[key]=max(result.get(key,0.),float(value))
    if 'irrigation whole budgets ' in line or 'irrigation whole CUDA budgets ' in line:
        group='CUDA32' if 'CUDA budgets' in line else ('JAX32' if 'numpy.float32' in line else 'JAX64');d=ast.literal_eval(line[line.index('{'):]);metrics['budget_rows'].append(dict(group=group,context=line[:line.index('{')],values=d))
        result=metrics['budget_max_absolute_residuals'].setdefault(group,{})
        for key in ['water_kgm2','heat_jm2','carbon','nitrogen','request_kgm2']:
            if key in d:result[key]=max(result.get(key,0.),abs(float(d[key])))
assert metrics['same_precision_lines']==8 and metrics['maximum_cuda_jax_same_precision']==0.
(trial/'irrigation-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
def archive(name,pairs,scope):
    dest=base/(name+'-evidence.tar.gz');assert not dest.exists()
    with tarfile.open(dest,'w:gz') as t:
        for path,label in pairs:t.add(path,arcname=label,recursive=False)
    print(json.dumps(dict(name=name,files=len(pairs),sha256=sha(dest),scope=scope)))
names=['run_pytest_worker_a.py','launch_gpu_worker_lifecycle_a.py','launch.json','summary.json','controller.log','irrigation-metrics.json']
for stem in ['test_gpu_photosynthesis','test_gpu_clm_irrigation_column']:names += [stem+'-expected.json',stem+'-receipt.json',stem+'.xml',stem+'.log']
pairs=[(trial/n,n) for n in names]+[(source/'full-by-file-a/test_gpu_clm_irrigation_column.log','original-normal-cli/test_gpu_clm_irrigation_column.log'),(source/'full-by-file-a/test_gpu_clm_irrigation_column.xml','original-normal-cli/test_gpu_clm_irrigation_column.xml'),(source/'SOURCE_SHA256.json','SOURCE_SHA256.json'),(Path(__file__),'archive_gpu_worker_complete_c_launch_a.py')]
archive('gpu-worker-complete-a',pairs,'Original leaf6+irrigation13 complete with real worker return0, full phases/barriers/exact nodes/source. Original normal CLI irrigation body output retained but its cleanup process has no terminal return0 claim. No full-suite/annual/scientific acceptance.')
selection=json.loads((source/'full-by-file-c/selection.json').read_text());pre=json.loads((source/'full-worker-preflight-c/selection.json').read_text());assert selection==pre
assert selection['verified_gpu_prefix_nodes']==104 and selection['remaining_gpu_nodes']==221 and len(selection['remaining_gpu_files'])==43
progress=(source/'full-by-file-c/progress.json').read_bytes();json.loads(progress);snapshot=source/'full-c-progress-after-launch-a.json';assert not snapshot.exists();snapshot.write_bytes(progress)
names=['run_most_full_gpu_c.py','launch_most_full_gpu_c.py','supersede_full_controller_c.py','full-worker-c-launch.json','full-controller-superseded-c.json','full-before-controller-supersession-c.json','full-c-progress-after-launch-a.json','full-by-file-c/selection.json','full-by-file-c/run_pytest_worker_a.py','SOURCE_SHA256.json']
pairs=[(source/n,n) for n in names]+[(current/'SOURCE_SHA256.json','current-SOURCE_SHA256.json'),(current/'current-collection-receipt.json','current-collection-receipt.json'),(Path(__file__),'archive_gpu_worker_complete_c_launch_a.py')]
for row in json.loads((source/'full-before-controller-supersession-c.json').read_text())['results']:
    stem=Path(row['file']).stem
    for suffix in ['.xml','.log']:pairs.append((source/'full-by-file-a'/(stem+suffix),'original-prefix/'+stem+suffix))
archive('full-worker-c-launch-a',pairs,'Current1129 exact distributed-node continuation:804 CPU proved,104 GPU genuinely complete, remaining221/43files launched. Original17-file normal prefix retained. Original cleanup child still reported honestly; no full/annual/scientific completion claim.')
print(json.dumps({k:v for k,v in metrics.items() if k!='budget_rows'}))

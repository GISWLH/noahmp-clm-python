"""Freeze read-only PBS/cache observations and an unexecuted reversible proposal."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='pbs-cache-diagnosis-qk'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
def main():
    cache=json.loads((BASE/'pbs-cache-qk.json').read_bytes());logs=json.loads((BASE/'pbs-logs-qk.json').read_bytes())
    assert cache['read_only'] and cache['deleted_or_renamed']==cache['remote_files_written']==0 and cache['previous_job41_cache_absent']
    assert logs['read_only'] and not logs['privilege_attempted']
    assert all(json.loads((BASE/n).read_bytes())['actual_exit']==0 for n in ('pbs-cache-qk-exit.json','pbs-logs-qk-exit.json'))
    names={'/home/zhangyq/noahmp-v1/p6-phase-jacobian-numpy-b/.pytest_cache','/home/zhangyq/noahmp-v1/p6-suction-numpy-coupled-a/.pytest_cache'}
    selected=[c for c in cache['caches'] if c['path'] in names];assert len(selected)==2
    assert all(c['all_known_manifests_exclude_cache'] and not c['source_process_references'] and not c['cache_process_references'] and any(e['raw_text'].strip()=='0' for e in c['original_exit_files']) for c in selected)
    proposal=dict(proposed_only=True,approved_for_cleanup=False,backup_not_yet_created=True,deleted_or_renamed=0,base=cache['base'],selected=selected,regular_files=9,directories=6,bytes=73165,expected_maximum_entries_reclaimable=15,limits='Point-in-time readable same-UID process inventory only; two processes inaccessible/transient and other UIDs not claimed visible. Known SOURCE manifests exclude cache; no STAGE/ARTIFACT manifest was found for these old roots. No guarantee of immediate df change or PBS recovery.')
    (BASE/(LABEL+'-backup-proposal.json')).write_bytes(encode(proposal))
    plan='''# QK old-cache reversible backup proposal — not executed or approved

Only two exact old project caches are proposed: p6-phase-jacobian-numpy-b/.pytest_cache (4files/3directories,3715B, original exit.txt0) and p6-suction-numpy-coupled-a/.pytest_cache (5files/3directories,69450B, original pbs-exit.txt0), both below /home/zhangyq/noahmp-v1. Original SOURCE manifests contain no cache reference. No STAGE/ARTIFACT manifest was found for those old roots, so their absence is not claimed as proven exclusion. Current readable same-UID cwd/fd snapshot found no source/cache reference; two processes were transient/inaccessible, and other UIDs were not claimed visible. Source/scientific artifacts and previously reclaimed job41 cache are outside this proposal.

If root later approves: first repeat only these two exact source/cache/proc checks and require every member's type/inode/hash/mode/mtime/ownership and exit/SOURCE manifest identity still match the proposal. Unknown types/symlinks/hardlinks or relevant live source/cwd/fd references stop the action. Record any readable extended attributes and include them in backup; do not assume their absence.

Stream a binary PAX tar through SSH stdout directly into a fresh local outputs/v1 file, creating no remote inode. Include exactly9 regular files plus6 directories under project-relative validated names, original contents, modes, uid/gid and nanosecond mtimes, and any extended-attribute metadata. Keep reader stderr and command exit separate. Verify archive whole SHA, unique/safe names and all9 file SHA/size plus directory/file metadata locally; fsync and rename only after complete verification. This backup has not yet been created.

Deletion is a later separately authorized step, only after backup verification and a fresh immutable/source/process guard. Unlink only the exact9 cached files and remove exactly6 empty directories bottom-up, never a recursive source deletion; leave every other original file unchanged. Record before/after directory lists/statvfs, actual exceptions/exits and unchanged source/exit manifests. If state differs, stop and preserve the verified backup. The intended maximum reclaimed entries is15, but immediate df change and PBS recovery are not guaranteed; inode0 is not proved to be the service-stop cause.

To restore when inodes are available: require each destination absent, validate every resolved target beneath the same project BASE, recreate directory/file contents exclusively, apply recorded mode and nanosecond mtime (directories last), ownership only as permitted for the same original user/group, and preserved attributes. Verify all original hashes and metadata against the backup/proposal. No scientific source/model/state data needs reconstruction.
'''
    (BASE/(LABEL+'-BACKUP_PROPOSAL.md')).write_text(plan,encoding='utf-8',newline='\n')
    readout=dict(read_only_complete=True,active_scan_processes_or_sessions=None,cache_count=cache['cache_count'],regular_files=cache['files'],directories=cache['directories'],bytes=cache['bytes'],known_SOURCE_manifest_exclusion=sum(c['all_known_manifests_exclude_cache'] for c in cache['caches']),unknown_manifest_scope=sum(not c['manifest_checks'] for c in cache['caches']),process_visibility=cache['process_scope'],original_job41_cache_absent=True,filesystem=cache['filesystem'],proposed_small_backup=proposal,last_server_log='/opt/pbshome/server_logs/20261026',last_server_entry='10/27/2026 00:00:00;0002;Server@manager_00260924;Svr;Log;Log closed',last_server_entry_UTC='2026-10-26 16:00:00 UTC',current_day_log_missing=True,datastore_logs_read_permission='errno13; not accessed',explicit_inode_ENOSPC_service_stop_error_found=False,pbs_server_process_query=logs['commands']['pbs-server-process'],pbs_service_journal=logs['commands']['pbs-journal'],scientific_job_state_reclassified=False,limit='Accessible server/scheduler/comm logs do not establish why pbs_server stopped. Repeated post-job file processing errors coexist with original actual F0/Stageout0 and direct raw results; no original status or result is changed.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={n:(BASE/n).read_bytes() for n in ('read_project_pytest_caches_qk.py','read_pbs_home_logs_qk.py','pbs-cache-qk.json','pbs-cache-qk.stderr','pbs-cache-qk-exit.json','pbs-logs-qk.json','pbs-logs-qk.stderr','pbs-logs-qk-exit.json',LABEL+'-readout.json',LABEL+'-backup-proposal.json',LABEL+'-BACKUP_PROPOSAL.md','package_pbs_cache_diagnosis_qk.py')}
    items['artifact-inventory.json']=encode({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Read-only PBS_HOME latest accessible log/permission and project-only pytest-cache/process/manifest inventory. No direct ENOSPC stop cause established; no privileged action, deletion, source/scientific-state modification, new physical call or original F0/Stageout0 reclassification. Two-cache reversible backup proposal is unexecuted and unapproved.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

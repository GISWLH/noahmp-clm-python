"""Read only accessible PBS logs and metadata; never privileged/system changes."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT=Path('/opt/pbshome')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def main():
    result=dict(root=str(ROOT),observed_unix=time.time(),read_only=True,privilege_attempted=False,paths={},logs={},commands={})
    for rel in ('server_logs','sched_logs','comm_logs','datastore','datastore/pg_log','datastore/log','datastore/logfile'):
        p=ROOT/rel
        try:
            s=p.stat();d=dict(mode=oct(s.st_mode&0o7777),uid=s.st_uid,gid=s.st_gid,size=s.st_size,mtime_ns=s.st_mtime_ns)
            if p.is_dir():d['readable_entries']=[dict(name=x.name,bytes=x.stat().st_size,mtime_ns=x.stat().st_mtime_ns) for x in sorted(p.iterdir())][-5:]
            result['paths'][rel]=d
        except OSError as exc:result['paths'][rel]=dict(error=repr(exc),errno=exc.errno)
    pattern=re.compile(r'no space|enospc|inode|disk full|database|datastore|postgres|fatal|panic|log open|log closed|error',re.I)
    for dirname in ('server_logs','sched_logs','comm_logs'):
        root=ROOT/dirname
        for p in sorted(root.iterdir())[-2:]:
            raw=p.read_bytes();lines=raw.decode(errors='replace').splitlines();matches=[dict(line=i+1,text=v) for i,v in enumerate(lines) if pattern.search(v)]
            result['logs'][str(p)]=dict(bytes=len(raw),sha256=sha(raw),last_lines=lines[-35:],matching_error_or_lifecycle_lines=matches[-80:],full_match_count=len(matches))
    for label,command in [('df-inodes',['df','-i','/opt/pbshome','/home/zhangyq/noahmp-v1']),('df-bytes',['df','-B1','/opt/pbshome','/home/zhangyq/noahmp-v1']),('pbs-server-process',['pgrep','-x','pbs_server']),('pbs-journal',['journalctl','--no-pager','-u','pbs','--since','2026-10-26 23:40:00','-n','80'])]:
        try:
            r=subprocess.run(command,capture_output=True,text=True,timeout=20);result['commands'][label]=dict(command=command,actual_exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
        except Exception as exc:result['commands'][label]=dict(command=command,error=repr(exc))
    result['causal_limit']='Missing current-day log and inode0 are observations. Unless an explicit error is found, these do not prove why pbs_server stopped. Inaccessible datastore logs remain unknown; no root access or restart attempted.'
    print(json.dumps(result))

if __name__=='__main__':main()

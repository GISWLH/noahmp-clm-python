"""Read-only project cache/manifest/process inventory; no removal or remote write."""
import hashlib
import json
import os
from pathlib import Path
import stat
import time

BASE=Path('/home/zhangyq/noahmp-v1').resolve()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
SKIP={'test-deps','.git','.venv','venv','node_modules','.ssh','credentials','.credentials'}

def main():
    assert str(BASE)=='/home/zhangyq/noahmp-v1' and BASE.is_dir()
    caches=[];errors=[];manifests=[];started=time.monotonic()
    for root,dirs,files in os.walk(str(BASE),followlinks=False):
        parent=Path(root)
        dirs[:]=[n for n in dirs if n not in SKIP and not (parent/n).is_symlink()]
        if '.pytest_cache' in dirs:
            path=parent/'.pytest_cache';dirs.remove('.pytest_cache')
            members=[]
            for r,ds,fs in os.walk(str(path),followlinks=False):
                ds[:]=[n for n in ds if not (Path(r)/n).is_symlink()]
                for n in [None,*fs]:
                    p=Path(r) if n is None else Path(r)/n
                    st=p.lstat();entry=dict(path=str(p.relative_to(BASE)),kind='directory' if stat.S_ISDIR(st.st_mode) else ('file' if stat.S_ISREG(st.st_mode) else 'other'),bytes=st.st_size if stat.S_ISREG(st.st_mode) else 0,mode=stat.S_IMODE(st.st_mode),mtime_ns=st.st_mtime_ns,uid=st.st_uid,gid=st.st_gid,inode=st.st_ino,nlink=st.st_nlink)
                    if stat.S_ISREG(st.st_mode):entry['sha256']=sha(p.read_bytes())
                    members.append(entry)
            caches.append(dict(path=str(path),source_root=str(parent),files=sum(m['kind']=='file' for m in members),directories=sum(m['kind']=='directory' for m in members),bytes=sum(m['bytes'] for m in members),members=members,manifest_checks=[],source_process_references=[],cache_process_references=[]))
        for n in files:
            lower=n.lower()
            if lower.endswith('.json') and any(s in lower for s in ('source','stage','artifact')) and any(s in lower for s in ('sha256','manifest','inventory')):
                manifests.append(parent/n)
    # Restrict manifest contents to each cache's own source root/ancestors,
    # never read third-party runtime/credentials or unrelated HOME directories.
    for cache in caches:
        source=Path(cache['source_root'])
        candidates=[p for p in manifests if source==p.parent or source in p.parents or p.parent in source.parents and p.parent!=BASE]
        for p in candidates:
            try:
                raw=p.read_bytes();doc=json.loads(raw);hits=[]
                def walk(v):
                    if isinstance(v,str) and '.pytest_cache' in v:hits.append(v)
                    elif isinstance(v,dict):
                        for k,x in v.items():walk(k);walk(x)
                    elif isinstance(v,list):
                        for x in v:walk(x)
                walk(doc)
                cache['manifest_checks'].append(dict(path=str(p),sha256=sha(raw),contains_pytest_cache_reference=bool(hits),references=hits[:30]))
            except (OSError,ValueError) as exc:cache['manifest_checks'].append(dict(path=str(p),error=repr(exc)))
        cache['all_known_manifests_exclude_cache']=bool(cache['manifest_checks']) and all(m.get('contains_pytest_cache_reference') is False for m in cache['manifest_checks'])
        exit_files=[]
        for n in ('pbs-exit.txt','pbs-exit','pytest-exit.txt','exit.txt'):
            p=source/n
            if p.is_file():exit_files.append(dict(path=str(p),raw_text=p.read_text(errors='replace')[:200],sha256=sha(p.read_bytes())))
        cache['original_exit_files']=exit_files
    own_uid=os.getuid();scanned=0;denied=0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:
            if proc.stat().st_uid!=own_uid:continue
            comm=(proc/'comm').read_text().strip();targets=[];scanned+=1
            for label,p in [('cwd',proc/'cwd'),*[(str(f.relative_to(proc)),f) for f in (proc/'fd').iterdir()]]:
                try:target=Path(os.readlink(str(p)).removesuffix(' (deleted)'))
                except (OSError,ValueError):continue
                if not target.is_absolute() or not target.is_relative_to(BASE):continue
                targets.append((label,target))
            for cache in caches:
                path=Path(cache['path']);source=Path(cache['source_root'])
                for label,target in targets:
                    row=dict(pid=int(proc.name),process=comm,handle=label,path=str(target))
                    if target==source or source in target.parents:cache['source_process_references'].append(row)
                    if target==path or path in target.parents:cache['cache_process_references'].append(row)
        except (OSError,PermissionError):denied+=1
    before=os.statvfs(str(BASE))
    result=dict(base=str(BASE),read_only=True,remote_files_written=0,deleted_or_renamed=0,cache_count=len(caches),files=sum(c['files'] for c in caches),directories=sum(c['directories'] for c in caches),bytes=sum(c['bytes'] for c in caches),caches=sorted(caches,key=lambda c:c['path']),process_scope=dict(uid=own_uid,own_processes_scanned=scanned,inaccessible_own_processes=denied,other_UID_processes_not_claimed_visible=True,arguments_or_sensitive_paths_not_returned=True),filesystem=dict(files=before.f_files,free_inodes=before.f_ffree,available_inodes=before.f_favail),errors=errors,seconds=time.monotonic()-started,previous_job41_cache_absent=not (BASE/'p6-soil-freezing-numpy-a/.pytest_cache').exists(),limits='No deletion approval implied. Manifest absence is reported as unknown, not exclusion. Process references are a point-in-time readable same-UID /proc snapshot, not a future safety guarantee. Third-party runtime and credential directories excluded.')
    print(json.dumps(result))

if __name__=='__main__':main()

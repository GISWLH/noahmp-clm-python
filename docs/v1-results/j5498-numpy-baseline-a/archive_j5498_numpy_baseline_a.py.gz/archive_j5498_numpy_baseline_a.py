from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'j5498-numpy-baseline-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((root/'baseline.json').read_text());assert r['pbs_job']=='124.manager' and r['source_unchanged'] and (root/'pbs-exit.txt').read_text().strip()=='0' and all(row['status']=='complete' for row in r['rows'])
names=['probe_j5498_numpy_baseline_a.py','j5498_numpy_baseline_a.pbs','baseline.json','baseline.log','node.txt','pbs-exit.txt','whole-inputs.npz'];pairs=[(root/n,n) for n in names]+[(base/'p6-spinup-assessment-c/SOURCE_SHA256.json','SOURCE_SHA256.json'),(Path(__file__),Path(__file__).name)];dest=base/'j5498-numpy-baseline-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for p,n in pairs:t.add(p,arcname=n,recursive=False)
print(json.dumps(dict(path=str(dest),sha256=sha(dest),files=len(pairs),seconds=r['seconds'],cases=[dict(site=row['site'],status=row['status'],h=row.get('h'),le=row.get('le'),energy_residual_jm2=row.get('energy_residual_jm2'),seconds=row['seconds']) for row in r['rows']])))

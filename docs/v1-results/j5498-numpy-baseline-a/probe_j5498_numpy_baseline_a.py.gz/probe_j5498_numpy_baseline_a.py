from pathlib import Path
import hashlib,json,os,time,traceback
import numpy as np
from test_gpu_clm_bgc_column import reference
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
root=Path.cwd();source=Path('/home/zhangyq/noahmp-v1/p6-spinup-assessment-c');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in m.items())
path=root/'whole-inputs.npz';assert sha(path)=='fc8869bccf3ff62ccceb27d06c654501180c6277927503d9e571ce8a3a650848'
with np.load(path,allow_pickle=False) as z:v=dict(z)
leaf=json.loads((root.parent/'fluxnet-first-climate-cycle-20261017-h/inputs/CN-Qia-config.json').read_text())['leaf_parameters'];assert leaf==vars(LeafParameters())
a=[v[f'a{k}'].copy() for k in range(16)];a[4][:,7:10]=v['forcing_environment'];rows=[];begin=time.monotonic()
for k,site in enumerate(['CN-Cng','CN-Qia','CN-Cha','CN-HaM']):
    started=time.monotonic();row=dict(site=site)
    try:
        out=reference(tuple(x[k] for x in a),v['forcing'][k],v['deposition'][k],v['environment'][k],v['calendar'][k],v['nitrogen'][k],1.,most_geometry=MOSTGeometry(*map(float,v['geometry'][k])))
        d=out['diagnostics'];row.update(status='complete',h=d['h'],le=d['le'],most=d['most'],energy_residual_jm2=d.get('energy_residual_jm2'),thermal=d.get('thermal',{}).get('converged'))
    except Exception:row.update(status='failed',failure=traceback.format_exc())
    row['seconds']=time.monotonic()-started;rows.append(row);print(json.dumps(row),flush=True)
assert all(sha(source/k)==v for k,v in m.items())
(root/'baseline.json').write_text(json.dumps(dict(scope='Independent NumPy interpretation of original quantized J5498 whole inputs, source unchanged; no fix/parameter edits.',node=os.uname().nodename,pbs_job=os.environ['PBS_JOBID'],source_unchanged=True,seconds=time.monotonic()-begin,rows=rows),indent=2)+'\n')

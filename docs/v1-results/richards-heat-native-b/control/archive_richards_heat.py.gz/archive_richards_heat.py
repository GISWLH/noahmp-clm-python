from pathlib import Path
import hashlib,json,sys,tarfile
mode=sys.argv[1];label=sys.argv[2];assert label in ('a','b','c','d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='reference':
    b=Path('/home/zhangyq/noahmp-v1');name='richards-heat-reference-'+label;r=b/name;d=json.loads((r/'receipt.json').read_text())
    assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged'] and len(d['cases'])==14 and sha(r/'richards_heat_reference.npz')==d['reference_sha256']
    controls=['run_richards_heat_reference_'+label+'.py','richards_heat_reference_'+label+'.pbs','dispatch_richards_heat_reference_'+label+'.py'];source=b/'richards-numpy-c-source.tar.gz'
else:
    assert mode=='native';b=Path('/home/lhwang/work/noahmp-v1');name='richards-heat-native-'+label;s=b/name;r=s/('target-'+label)
    d=json.loads((r/'receipt.json').read_text());e=json.loads((r/'exit.json').read_text())
    assert e['source_unchanged'] and d['source_unchanged'] and e['receipt_sha256']==sha(r/'receipt.json') and d['xml_sha256']==sha(r/'tests.xml') and d['counts']['tests']==4
    assert e['returncode']==d['worker_exitcode']==d['pytest_returncode'] and d['node_coverage_exact']
    controls=['collect_richards_heat_'+label+'.py','control_richards_heat_'+label+'.py','launch_richards_heat_'+label+'.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py'];source=b/(name+'-source.tar.gz')
    assert sha(source)==json.loads((b/(name+'-package.json')).read_text())['archive_sha256']
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(source,arcname='source/'+source.name,recursive=False)
    if mode=='native':tf.add(b/(name+'-package.json'),arcname='source/'+name+'-package.json',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

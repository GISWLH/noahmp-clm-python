"""Replay existing official C data on an EHPC PBS CPU node."""
from pathlib import Path
import hashlib,json,os,subprocess,time
import numpy as np
from audit_hrldas_point_output import audit
from datetime import datetime
root=Path('/home/zhangyq/noahmp-v1/hrldas-portable-a');run=root/'bondville'
manifest=json.loads((root/'MANIFEST.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(root/k)==v for k,v in manifest['files'].items())
assert not list((run/'output').iterdir())
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
command=[str(root/'lib/ld-linux-x86-64.so.2'),'--library-path',str(root/'lib'),str(root/'bin/hrldas.exe')]
started=time.monotonic()
with (root/'hrldas-replay.log').open('wb') as log:
    code=subprocess.run(command,cwd=run,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
receipt=dict(scope='Existing official Bondville C binary/data replay on EHPC CPU, not a new station or3-5-site acceptance.',
    returncode=code,command=command,seconds=time.monotonic()-started,node=os.uname().nodename,pbs_job=os.environ.get('PBS_JOBID'),
    official_binary_sha256=sha(root/'bin/hrldas.exe'),frozen_input_and_runtime_unchanged=all(sha(root/k)==v for k,v in manifest['files'].items()))
(root/'run-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');assert code==0 and receipt['frozen_input_and_runtime_unchanged']
result=audit(run/'output',initial_time=datetime(1998,1,2),timestep_seconds=1800)
result['instrument_sha256']=sha(Path(__file__).with_name('audit_hrldas_point_output.py'))
(root/'audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
old=json.loads((root/'original-xuanze-audit.json').read_text());maximum={};mismatches=[]
def compare(a,b,path):
    if isinstance(a,dict):
        assert set(a)==set(b),(path,set(a)^set(b))
        for key in a:compare(a[key],b[key],path+'/'+key)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for x,y in zip(a,b):compare(x,y,path+'[]')
    elif isinstance(a,(int,float)):
        error=abs(float(a)-float(b));key=path.split('/')[-1];maximum[key]=max(maximum.get(key,0.),error)
    elif a!=b:mismatches.append(dict(path=path,old=a,new=b))
for key in ['file_count','physical_intervals','timestep_seconds','initial_time','raw_units','initial_state','daily','intervals']:
    compare(old[key],result[key],key)
files=sorted((run/'output').glob('*.LDASOUT_DOMAIN1'))
byte_differences=[p.name for p in files if sha(p)!=sha(root/'original-output'/p.name)]
comparison=dict(scope='All audited variables and original49 LDASOUT files, original xuanze C versus EHPC replay. Reproducibility result only, not CLM-versus-HRLDAS scientific acceptance.',
    audited_numerical_max_abs_by_field=maximum,non_numerical_differences=mismatches,audited_values_equal=not mismatches and all(v==0. for v in maximum.values()),
    ldasout_files=len(files),ldasout_files_byte_equal=len(files)-len(byte_differences),byte_differences=byte_differences)
(root/'replay-comparison.json').write_text(json.dumps(comparison,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(**receipt,audited_values_equal=comparison['audited_values_equal'],ldasout_files_byte_equal=comparison['ldasout_files_byte_equal'],physical_intervals=result['physical_intervals'])),flush=True)

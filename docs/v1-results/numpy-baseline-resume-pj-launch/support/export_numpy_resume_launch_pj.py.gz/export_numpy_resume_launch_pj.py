"""Read-only, standard-library snapshot of the already launched PJ windows."""
from pathlib import Path
import hashlib
import io
import json
import os
import socket
import subprocess
import tarfile
import time

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')
JOBS = [str(n) + '.manager' for n in range(1633, 1641)]


def sha(value):
    return hashlib.sha256(value).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def process(pid):
    base = Path('/proc') / str(pid)
    stat = (base / 'stat').read_text()
    tail = stat[stat.rfind(')')+2:].split()
    return dict(pid=pid, start_ticks=int(tail[19]), state=tail[0], parent=int(tail[1]),
        cpu_ticks=int(tail[11])+int(tail[12]), rss_pages=int(tail[21]),
        cmdline=(base/'cmdline').read_bytes().replace(b'\0',b' ').decode(),
        cwd=str((base/'cwd').resolve()), status=(base/'status').read_text())


def main():
    node = socket.gethostname()
    assert node in ('manager', 'compute002')
    target = Path('/tmp') / ('numpy-resume-pj-launch-' + node + '.tar.gz')
    assert not target.exists()
    files, immutable, observations = {}, {}, []

    def read(path, name, fixed=False):
        body = path.read_bytes()
        files[name] = body
        if fixed:
            immutable[str(path)] = sha(body)
        return body

    stage = json.loads(read(ROOT/'STAGE_SHA256.json', 'STAGE_SHA256.json', True))
    assert all(sha((ROOT/name).read_bytes()) == digest for name,digest in stage.items())
    controls = json.loads(read(ROOT/'preparation/CONTROLS_SHA256.json', 'CONTROLS_SHA256.json', True))
    assert sha(files['CONTROLS_SHA256.json']) == '0f044fd60a1c870396075f63e1f87ff724ada6362072fe882fcd43fe1e7c3770'
    assert len(controls) == 9
    for name,digest in controls.items():
        assert sha(read(ROOT/'preparation'/name, 'preparation/'+name, True)) == digest
    if node == 'manager':
        launch = json.loads(read(ROOT/'LAUNCH.json', 'LAUNCH.json', True))
        read(ROOT/'CONTROLLER_STARTED.json', 'CONTROLLER_STARTED.json', True)
        read(ROOT/'PROGRESS.json', 'snapshot/PROGRESS.json')
        read(ROOT/'controller.log', 'snapshot/controller.log')
        proc = process(launch['controller_pid'])
        assert proc['start_ticks'] == launch['controller_start_ticks']
        assert proc['cwd'] == str(ROOT)
        files['snapshot/controller-process.json'] = js(proc)
        for i,job in enumerate(JOBS):
            q = subprocess.run(['qstat','-xf',job],capture_output=True)
            files['qstat/'+job+'.stdout'] = q.stdout
            files['qstat/'+job+'.stderr'] = q.stderr
            files['qstat/'+job+'.exit'] = str(q.returncode).encode()
            assert q.returncode == 0
            folder = ROOT/'actual'/('case-'+str(i))/'start-0000048'
            for name in ['qsub.stdout','qsub.stderr','qsub-exit.txt']:
                read(folder/name, 'submitted/'+str(i)+'/'+name, True)
    else:
        for i,job in enumerate(JOBS):
            jobroot = Path('/var/tmp')/('pbs.'+job)
            result = jobroot/'result'
            prefix = 'cases/'+str(i)+'/'
            raw = read(result/'first-resume-input-probe/PROBE_ONLY.json', prefix+'probe/PROBE_ONLY.json', True)
            probe = json.loads(raw)
            assert probe['expected_controlled_stop'] and probe['actual_original_tendencies'] == 0
            assert probe['original_report_status'] == 'failed' and probe['allowed_as_parent'] is False
            assert probe['actual_index'] == 48 and probe['exact_full_seven_tuple']['max_abs_difference'] == 0.
            assert all(x['max_abs_difference'] == 0. for x in probe['actual_first_input'].values())
            for name in ['actual-first-input.pkl','report.json','state-0000048.pkl','trace-0000048.npz']:
                read(result/'first-resume-input-probe'/name,prefix+'probe/'+name,True)
            segment = result/'run/segment-0000048'
            for name in ['first-call-input.pkl','first-call.pkl']:
                read(segment/name,prefix+'formal/'+name,True)
            start = json.loads(read(segment/'start-originals/report.json',prefix+'formal/start-originals/report.json',True))
            assert start['status'] == 'running' and start['steps_completed'] == 48
            for name in [start['checkpoint_file'],start['model_npz']]:
                read(segment/'start-originals'/name,prefix+'formal/start-originals/'+name,True)
            current = json.loads(read(result/'run/trajectory/report.json',prefix+'snapshot/report.json'))
            assert current['status'] == 'running' and 48 <= current['steps_completed'] < 528
            assert not (result/'PJ-traceback.txt').exists()
            source = jobroot/'source-nm584'
            srcraw = read(source/'SOURCE_SHA256.json',prefix+'SOURCE_SHA256.json',True)
            assert sha(srcraw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
            index = json.loads(srcraw)
            assert len(index) == 584
            assert all(sha((source/n).read_bytes()) == h for n,h in index.items())
            matching = []
            for p in Path('/proc').iterdir():
                if not p.name.isdigit():
                    continue
                try:
                    cmd = (p/'cmdline').read_bytes()
                    if b'run_window_job_pj.py' not in cmd:
                        continue
                    item = process(int(p.name))
                    if item['cwd'] == str(jobroot):
                        matching.append(item)
                except (FileNotFoundError,ProcessLookupError,PermissionError):
                    continue
            assert len(matching) == 1
            files[prefix+'snapshot/worker-process.json'] = js(matching[0])
            observations.append(dict(case_index=i,pbs_job=job,worker_pid=matching[0]['pid'],
                report_saved_intervals=current['steps_completed'],original_report_status=current['status'],
                probe_original_tendencies=0,probe_seven_tuple_max_abs_difference=0.,
                actual_formal_first_tendency_saved=True,source_files=584,source_all_hash_exact=True))
            assert all(sha((source/n).read_bytes()) == h for n,h in index.items())
    assert all(sha(Path(n).read_bytes()) == h for n,h in immutable.items())
    assert all(sha((ROOT/name).read_bytes()) == digest for name,digest in stage.items())
    stat = os.statvfs('/tmp')
    files['SNAPSHOT.json'] = js(dict(node=node,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        scope='Launch/current progress only; no new complete-window/year credit',
        immutable_before_after_sha256=immutable,stage_all_files_exact=True,observations=observations,
        available_bytes=stat.f_bavail*stat.f_frsize,available_inodes=stat.f_favail,
        forward_steps_executed_by_exporter=0,mutable_files_claimed_unchanged=False))
    files['ARTIFACT_SHA256.json'] = js({n:sha(b) for n,b in sorted(files.items())})
    with tarfile.open(target,'w:gz') as archive:
        for name,body in sorted(files.items()):
            member=tarfile.TarInfo(name);member.size=len(body)
            archive.addfile(member,io.BytesIO(body))
    print(json.dumps(dict(path=str(target),sha256=sha(target.read_bytes()),members=len(files),observations=observations)))


if __name__ == '__main__':
    main()

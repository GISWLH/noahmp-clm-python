"""Frozen PJ full-calendar identities and exact PH48 parent packets; stdlib only."""
from pathlib import Path
import ast
import copy
import hashlib
import io
import json
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
OUT=BASE/'numpy-baseline-resume-pj-preparation'
PF=BASE/'numpy-own-spinup-pf-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def tar_bytes(files):
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
        for name,raw in sorted(files.items()):
            item=tarfile.TarInfo(name);item.size=len(raw)
            archive.addfile(item,io.BytesIO(raw))
    return buffer.getvalue()


def main():
    pfraw=(PF/'CONTROLS_SHA256.json').read_bytes()
    assert sha(pfraw)=='32ca64c70a5705f2bd4ae9c78c9c549cc5f553d1a6da153b8a20b041baedf08b'
    pfi=json.loads(pfraw)
    assert all(sha((PF/n).read_bytes())==h for n,h in pfi.items())
    original_raw=(PF/'pb/numpy_chain_pb.py').read_bytes()
    original=next(n for n in ast.parse(original_raw).body if isinstance(n,ast.FunctionDef) and n.name=='_run_segment')
    adapted=copy.deepcopy(original)
    adapted.name='run_window'
    adapted.body[0]=ast.Expr(value=ast.Constant(value='Same-year original baseline resume: <=480 steps, never reset/cycle/train.'))
    adapted.body[2]=ast.parse("""require(identity == request(identity['candidate'], identity['case'], 'spinup', 1)
        and identity['candidate'] == 'om-baseline' and identity['steps'] == 17520
        and identity['test_only'] is False and resume is True
        and 48 <= read_json(Path(output)/'trajectory/report.json')['steps_completed'] < 17520
        and (read_json(Path(output)/'trajectory/report.json')['steps_completed'] - 48) % 480 == 0
        and stop_after == min(480, 17520-read_json(Path(output)/'trajectory/report.json')['steps_completed']),
        'PJ only resumes the original baseline partial first year in fixed bounded windows')""").body[0]
    restored=copy.deepcopy(adapted)
    restored.name,restored.body[0],restored.body[2]=original.name,original.body[0],original.body[2]
    assert ast.dump(restored,include_attributes=False)==ast.dump(original,include_attributes=False)
    header=(BASE/'numpy-baseline-cold48-ph-preparation/run_window_ph.py').read_text().split('def run_window(',1)[0]
    (OUT/'run_window_pj.py').write_text(header+ast.unparse(ast.fix_missing_locations(adapted))+'\n')
    ph=BASE/'numpy-baseline-cold48-ph-evidence.tar.gz'
    assert sha(ph.read_bytes())=='c378f53895c0ca618abef26eda431643ca5778dafbae22b2dc58a29cea459171'
    with tarfile.open(ph) as archive:
        raw={m.name:archive.extractfile(m).read() for m in archive}
    integrity=json.loads(raw['INTEGRITY.json'])
    assert set(raw)==set(integrity)|{'INTEGRITY.json'} and all(sha(raw[n])==h for n,h in integrity.items())
    initial,identities,closed={},{},{}
    dispatch=json.loads(raw['actual/manager/dispatch.json'])
    for row in dispatch['jobs']:
        i,job=row['index'],row['pbs_job']
        prefix='cases/'+str(i)+'/'
        contents={n.removeprefix(prefix):b for n,b in raw.items() if n.startswith(prefix)}
        receipt=json.loads(contents['receipt.json'])
        assert receipt['passed'] and receipt['saved_intervals']==48 and receipt['actual_original_tendencies']==48
        assert receipt['identity']==row['identity'] and receipt['pbs_job']==job
        qstat=raw['actual/manager/'+job+'-qstat.stdout']
        assert b'job_state = F' in qstat and b'Exit_status = 0' in qstat and b'Stageout_status = 0' in qstat
        term='terminals/'+job
        contents[term+'/qstat.stdout']=qstat
        contents[term+'/parent-exit.txt']=raw['actual/compute002/case-'+str(i)+'-pbs-exit.txt']
        contents[term+'/worker-exit.txt']=contents['worker-exit.txt']
        contents['terminals.json']=js({job:dict(qstat=term+'/qstat.stdout',parent_exit=term+'/parent-exit.txt',worker_exit=term+'/worker-exit.txt')})
        contents['BGC_STREAMS.json']=js(dict(identity=row['identity'],streams=[dict(directory='bgc-stream',
            header_sha256=sha(contents['bgc-stream/BGC_STREAM.json']),first_index=0,stop_index=48)]))
        contents['PH_ORIGINAL_MEMBERS.json']=js(dict(PH_archive_sha256=sha(ph.read_bytes()),
            case_index=i,member_sha256={n.removeprefix(prefix):sha(b) for n,b in raw.items() if n.startswith(prefix)}))
        contents['ARTIFACT_SHA256.json']=js({n:sha(b) for n,b in sorted(contents.items())})
        body=tar_bytes(contents)
        name='closed/case-'+str(i)+'/stop-0000048.tar.gz'
        closed[name]=body
        initial[str(i)]=dict(path=name,sha256=sha(body),bytes=len(body),inventory_sha256=sha(contents['ARTIFACT_SHA256.json']),
                            actual_PBS_job=job,source_PH_archive_sha256=sha(ph.read_bytes()))
        identities[i]=row['identity']
    fixed=json.loads((PF/'BINDINGS_PF.json').read_bytes())
    bindings=dict(identities=[identities[i] for i in range(8)],initial_archives=initial,
        source_archive_sha256=fixed['source_archive_sha256'],source_manifest_sha256=fixed['source_manifest_sha256'],
        PF_manifest_sha256=sha(pfraw),PH_archive_sha256=sha(ph.read_bytes()),windows_per_case=37,
        first_start=48,maximum_window_steps=480,last_window_steps=192,final_stop=17520,
        continuation_steps_per_case=17472,total_continuation_step_cap=139776,
        maximum_concurrent_jobs=8,cpus_per_job=1,memory_gib_per_job=2,wall_seconds_per_job=21600,
        minimum_disk_free_bytes=12*1024**3,minimum_free_inodes=20000,no_automatic_retry=True,
        no_cycle2=True,no_train1=True,no_scoring=True,
        original_PB_module_sha256=sha(original_raw),original_function_AST_restore_exact=True)
    (OUT/'PJ_BINDINGS.json').write_bytes(js(bindings))
    (OUT/'ADAPTATION.json').write_bytes(js(dict(original='_run_segment',adapted='run_window',
        original_module_sha256=sha(original_raw),changed=['function name','docstring','execution entry gate'],
        all_remaining_function_AST_exact=True,original_physical_source_modified=False,
        first_input_probe='Separate original PH trajectory copy, expected zero-step exception, never a parent; formal run uses separate unchanged copy.')))
    index={p.name:sha(p.read_bytes()) for p in OUT.iterdir() if p.is_file() and p.name!='CONTROLS_SHA256.json'}
    for name in index:
        if name.endswith('.py'):ast.parse((OUT/name).read_bytes())
    (OUT/'CONTROLS_SHA256.json').write_bytes(js(index))
    check=subprocess.run(['E:/miniconda3/Scripts/ruff.exe','check','--select','F821',str(OUT),str(Path(__file__))],capture_output=True,text=True)
    assert check.returncode==0,check.stdout+check.stderr
    files={'preparation/'+n:(OUT/n).read_bytes() for n in [*index,'CONTROLS_SHA256.json']}
    files.update({'pf/'+n:(PF/n).read_bytes() for n in [*pfi,'CONTROLS_SHA256.json']})
    source=(BASE/'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    assert sha(source)==fixed['source_archive_sha256']
    files['inputs/climatology-final-candidate-nm-source.tar.gz']=source
    files.update(closed)
    files['STAGE_SHA256.json']=js({n:sha(b) for n,b in files.items()})
    target=BASE/'numpy-baseline-resume-pj-stage-b.tar.gz'
    assert not target.exists(),'Preserve immutable deployed attempts'
    target.write_bytes(tar_bytes(files))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==files
    result=dict(stage=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,members=len(files),
        controls=len(index),controls_manifest_sha256=sha((OUT/'CONTROLS_SHA256.json').read_bytes()),
        original_function_AST_restore_exact=True,ruff_exit=check.returncode,local_numeric_execution=False,submitted=False)
    (BASE/'numpy-baseline-resume-pj-preparation.json').write_bytes(js(result))
    print(json.dumps(result))


if __name__=='__main__':main()

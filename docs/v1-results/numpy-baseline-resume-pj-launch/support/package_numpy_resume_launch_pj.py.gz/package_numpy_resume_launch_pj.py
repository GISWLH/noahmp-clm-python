"""Package actual PJ launch evidence; no NumPy imports or model execution."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def load(path, expected, inventory):
    assert sha(path.read_bytes()) == expected
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len(members) == len({m.name for m in members})
        data = {m.name: archive.extractfile(m).read() for m in members}
    index = json.loads(data[inventory])
    assert set(index) == set(data) - {inventory}
    assert all(sha(data[n]) == h for n,h in index.items())
    return data


def main():
    data, references = {}, {}
    snapshots = {}
    expected = dict(manager='73e4eb019c37b99753ec1d664ce1b273393b145ff28b492ac3a70fcca39079e2',
                    compute002='fe1788f98199f2dea53ed04a44ab8969a5656f52b07dd67a9ceb869103e8d32c')
    for node,digest in expected.items():
        path = BASE / ('numpy-baseline-resume-pj-launch-' + node + '.tar.gz')
        raw = load(path,digest,'ARTIFACT_SHA256.json')
        data.update({'actual/'+node+'/'+n:b for n,b in raw.items()})
        references[node] = dict(archive=path.name,sha256=digest,members={n:sha(b) for n,b in raw.items()})
        snapshots[node] = json.loads(raw['SNAPSHOT.json'])
    manager = 'actual/manager/'
    launch = json.loads(data[manager+'LAUNCH.json'])
    assert launch['controller_pid'] == 48727 and launch['controller_start_ticks'] == 269100908
    assert launch['maximum_continuation_tendencies'] == 139776
    stage = BASE/'numpy-baseline-resume-pj-stage-b.tar.gz'
    stageraw = load(stage,'9b5af7ba849d9101c1f7455e27342db945066ed022a4f58e1e2cb2329d7441bb','STAGE_SHA256.json')
    assert launch['stage_sha256'] == sha(stage.read_bytes())
    manifest = stageraw['preparation/CONTROLS_SHA256.json']
    assert sha(manifest) == '0f044fd60a1c870396075f63e1f87ff724ada6362072fe882fcd43fe1e7c3770'
    assert len(json.loads(manifest)) == 9
    for n,h in json.loads(manifest).items():
        assert sha(stageraw['preparation/'+n]) == h
        assert data[manager+'preparation/'+n] == data['actual/compute002/preparation/'+n] == stageraw['preparation/'+n]
    data['original-stage-b.tar.gz'] = stage.read_bytes()
    fixed = json.loads(stageraw['preparation/PJ_BINDINGS.json'])
    rows = snapshots['compute002']['observations']
    assert len(rows) == 8
    for row in rows:
        i,job = row['case_index'],row['pbs_job']
        assert job == str(1633+i)+'.manager'
        qstat = data[manager+'qstat/'+job+'.stdout']
        assert re.search(rb'^Job Id: '+re.escape(job.encode())+rb'\s*$',qstat,re.M)
        assert re.search(rb'^\s*job_state = R\s*$',qstat,re.M)
        assert data[manager+'qstat/'+job+'.exit'].strip() == b'0'
        assert row['source_files'] == 584 and row['source_all_hash_exact']
        prefix = 'actual/compute002/cases/'+str(i)+'/'
        probe = json.loads(data[prefix+'probe/PROBE_ONLY.json'])
        assert probe['actual_original_tendencies'] == 0 and probe['allowed_as_parent'] is False
        assert probe['exact_full_seven_tuple']['max_abs_difference'] == 0.
        assert all(v['max_abs_difference'] == 0. for v in probe['actual_first_input'].values())
        start = json.loads(data[prefix+'formal/start-originals/report.json'])
        assert start['steps_completed'] == 48 and start['status'] == 'running'
        # Decode only JSON and archive metadata on Windows, never state pickle or NPZ.
        with tarfile.open(fileobj=io.BytesIO(stageraw[fixed['initial_archives'][str(i)]['path']])) as archive:
            before = {m.name:archive.extractfile(m).read() for m in archive}
        original = json.loads(before['run/trajectory/report.json'])
        assert start['configuration'] == original['configuration']
        containers = {}
        for field in ['checkpoint_file','model_npz']:
            formal = data[prefix+'formal/start-originals/'+start[field]]
            parent = before['run/trajectory/'+original[field]]
            containers[field] = dict(formal_sha256=sha(formal),parent_PH_sha256=sha(parent),
                                    container_raw_bytes_equal=formal==parent)
        row['original_container_hashes'] = containers
        row['formal_seven_tuple_and_full_trace_comparison_at_window_close'] = True
        row['case'] = fixed['identities'][i]['case']
    for name in ['prepare_numpy_baseline_resume_pj.py','export_numpy_resume_launch_pj.py',
                 'package_numpy_resume_launch_pj.py','numpy-baseline-resume-pj-preparation.json',
                 'numpy-baseline-resume-pj-deploy.stdout','numpy-baseline-resume-pj-deploy.stderr',
                 'numpy-baseline-resume-pj-deploy-exit.txt']:
        data['support/'+name] = (BASE/name).read_bytes()
    summary = dict(scope='Actual launch and exact first-input evidence; all eight first windows still R at snapshot',
        passed_launch_and_input_checks=True,controller_pid=launch['controller_pid'],
        pbs_jobs=[row['pbs_job'] for row in rows],current_saved_intervals=[row['report_saved_intervals'] for row in rows],
        new_closed_480_windows=0,new_complete_years=0,accepted_spinup=False,scored=False,GPU_steps=0,
        isolated_zero_step_probe_count=8,probe_physical_steps=0,formal_first_tendency_originals=8,
        probe_max_abs_difference=0.,raw_pickle_npz_canonical_equality_claimed=False,
        source_files_per_case=584,source_manifest_sha256=fixed['source_manifest_sha256'],
        controls_manifest_sha256=sha(manifest),stage_sha256=sha(stage.read_bytes()),
        maximum_windows_per_case=37,maximum_continuation_tendencies=139776,stop_at=17520,
        no_auto_cycle2=True,no_automatic_retry=True,wall_seconds_per_window=21600,
        manager_snapshot_utc=snapshots['manager']['utc'],compute_snapshot_utc=snapshots['compute002']['utc'],rows=rows)
    data['LAUNCH_SUMMARY.json'] = js(summary)
    data['ORIGINAL_EXPORTS.json'] = js(references)
    data['SCOPE.md'] = ('# PJ 同年续跑实际启动\n\n'
        'EHPC compute002 的 1633–1640.manager 已实际运行，8 根各 1 CPU、2 GiB、6 小时墙钟，从原第 48 步续到第 528 步。'
        'manager 控制器 PID 48727。包内时点均为 R；当前没有新的完整 480 窗、完整年或已接受 spinup。\n\n'
        '8 个隔离零步探针实际在原 index 48 处故意终止，原报告 failed 保留，物理调用为 0；这些探针不能作父状态。'
        '其七元组 20 数组、116 标量和真实首步 state/forcing/kwargs 最大差均为 0。正式窗口使用不同的原 PH 克隆；'
        '8 个正式首个原 tendency 输入与返回原件均保存。原 runner 重写零步容器后，pickle/NPZ 的容器字节不保证 canonical；'
        '逐件保留两侧原 SHA，不宣称容器字节相等。正式零步完整七元组与 18 字段原 trace 前缀的严格内容核验在窗口闭合执行。\n\n'
        '每根只在真实 F0、Stageout0、worker0、原源/输入/七元状态/逐步累计账/完整 BGC 链闭合后接下一窗；'
        '36×480+192 共 37 窗，到 17520 停止。无自动 retry/cycle2/train1/评分。异常停止对应根并保留失败；'
        '控制器任何根未完整闭合时最终 exit1。6 小时是有限资源上限，不是未测全年速度保证。\n\n'
        '原始冻结 stage-b 内含 9 控件、PF 依赖、NM584 与 8 个已闭合 PH 初始输入包。实际目录仅只读导出；'
        '只对 immutable 源、控件和首步文件做前后 SHA，运行中的报告及进程明确为快照。'
        '每次提交前检查两端 /tmp 至少 12 GiB、20,000 inode；没有删除或覆盖活数据，剩余容量仍需按实际增长监测。\n').encode()
    data['INTEGRITY.json'] = js({n:sha(b) for n,b in sorted(data.items())})
    target = BASE/'numpy-baseline-resume-pj-launch-evidence.tar.gz'
    assert not target.exists()
    with tarfile.open(target,'w:gz') as archive:
        for n,b in sorted(data.items()):
            m=tarfile.TarInfo(n);m.size=len(b);archive.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as archive:
        assert {m.name:archive.extractfile(m).read() for m in archive} == data
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,
        artifacts=len(data),inventory_files=len(data)-1,**summary)
    (BASE/'numpy-baseline-resume-pj-launch-package.json').write_bytes(js(package))
    print(json.dumps({k:v for k,v in package.items() if k!='rows'}))


if __name__ == '__main__':
    main()

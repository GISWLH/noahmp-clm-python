"""Compare the analytic night branch against the immutable pre-change module."""
from pathlib import Path
import hashlib,json,subprocess,sys,types,time,statistics
import numpy as np
import noahmp_clm.physics.photosynthesis as candidate
old_source=subprocess.check_output(['git','show','25e8b52:src/noahmp_clm/physics/photosynthesis.py'])
old=types.ModuleType('dark_leaf_original');sys.modules[old.__name__]=old
exec(compile(old_source,'25e8b52/photosynthesis.py','exec'),old.__dict__)
rng=np.random.default_rng(1710);n=4096
values=dict(co2_ppm=rng.uniform(100,1200,n),relative_humidity=rng.uniform(0,1.5,n),
 boundary_conductance=np.exp(rng.uniform(np.log(.001),np.log(10),n)),
 nitrogen_factor=rng.uniform(0,1,n),water_stress=rng.uniform(0,1,n))
temperature=rng.uniform(200,350,n);cases={}
for minimum in (.001,.01,.2):
 po=old.LeafParameters(minimum_conductance=minimum);pn=candidate.LeafParameters(minimum_conductance=minimum)
 a=old.leaf_gas_exchange(np.zeros(n),temperature,parameters=po,**values)
 b=candidate.leaf_gas_exchange(np.zeros(n),temperature,parameters=pn,**values)
 cases[str(minimum)]={k:float(np.max(abs(a[k]-b[k]))) for k in a}
 for k in a:np.testing.assert_allclose(a[k],b[k],rtol=1e-11,atol=1e-10,err_msg=k)
 for key in ('gross','net','gs_mol','surface_relative_humidity'):np.testing.assert_array_equal(a[key],b[key])
timing={}
for label,module in [('original',old),('analytic',candidate)]:
 duration=[]
 for rep in range(5):
  start=time.perf_counter()
  for _ in range(100):module.leaf_gas_exchange(np.zeros(10),np.linspace(260,290,10),parameters=module.LeafParameters(minimum_conductance=.002))
  duration.append(time.perf_counter()-start)
 timing[label]={'100_calls_seconds':duration,'median_seconds':statistics.median(duration)}
result={'scope':'Original versus analytic zero-light gas exchange; all-dark 4096 inputs per conductance, 12288 total',
 'old_commit':'25e8b52','old_source_sha256':hashlib.sha256(old_source).hexdigest(),
 'candidate_source_sha256':hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest(),
 'instrument_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'all_outputs_max_absolute':cases,'gross_net_conductance_surface_humidity_bitwise_equal':True,
 'timing':timing,'median_speed_ratio':timing['original']['median_seconds']/timing['analytic']['median_seconds']}
Path('outputs/v1/profile_output/dark-leaf-comparison.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))

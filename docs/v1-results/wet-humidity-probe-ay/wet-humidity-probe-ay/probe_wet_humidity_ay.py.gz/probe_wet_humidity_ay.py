from pathlib import Path
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'wet-humidity-probe-ay';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-canopy-wet-final-aq-source.tar.gz';assert sha(a)=='87d34428812ee484a75dce6c299cea95c3b24a828a0059506ed9d55103d408c7'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
import test_gpu_canopy_phase_energy as phase
records=[];start=time.monotonic()
for name in ['canopy_phase_humidity_bound.json','canopy_phase_humidity_slow.json']:
    saved=json.loads((s/'tests/fixtures'/name).read_text());arrays=tuple(np.asarray(v,np.int32 if k==8 else np.float64) for k,v in enumerate(saved['arrays']));default=phase.reference(arrays,tolerance=1e-7)
    row=dict(fixture=name,default=dict(iterations=default['iterations'],restarts=default['restarts'],canopy_humidity=float(default['canopy_humidity']),maximum_layer_residual_wm2=float(abs(default['layer_residual']).max()),maximum_solver_residual_wm2=float(abs(default['solver_residual']).max()),water_residual_kgm2=float(default['canopy_water_residual'])),probes=[])
    # Prescribed numerical starts, not fitted physics. Keep all original
    # forcing/stores/traits/bounds and80 iterations/1e-7 unchanged.
    for coordinate in [-20.,0.,40.,80.,120.]:
        for humidity_gkg in [0.,190.]:
            guess=[coordinate]*len(arrays[0])+[float(arrays[6][1]),humidity_gkg];v=dict(initial_guess=guess)
            try:
                q=phase.reference(arrays,tolerance=1e-7,initial_guess=guess);v.update(failure=None,iterations=q['iterations'],restarts=q['restarts'],canopy_humidity=float(q['canopy_humidity']),maximum_solver_residual_wm2=float(abs(q['solver_residual']).max()),maximum_layer_residual_wm2=float(abs(q['layer_residual']).max()),water_residual_kgm2=float(q['canopy_water_residual']),maximum_temperature_difference_to_default_k=float(abs(q['leaf_temperature']-default['leaf_temperature']).max()),maximum_mass_difference_to_default_kgm2=float(abs(q['condensate'].mass-default['condensate'].mass).max()))
            except Exception as err:v.update(failure=type(err).__name__+': '+str(err),traceback=traceback.format_exc())
            row['probes'].append(v)
    records.append(row)
d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),seconds=time.monotonic()-start,records=records,scope='Diagnose oldhumidity assertion only: alloriginalinputs retained under productionwetarea.05. Prescribed numericalinitialguess grid probes recovery coverage; no sourcephysics/tolerance/budget modifications or scientificparameterselection. All successes/failures retained; no productionbug conclusion from restartcounter alone.')
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(seconds=d['seconds'],default=[v['default'] for v in records])),flush=True);assert d['source_unchanged']

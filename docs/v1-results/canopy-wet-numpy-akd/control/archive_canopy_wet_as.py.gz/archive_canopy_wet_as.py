from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[]
if mode=='references':
    root=b/'canopy-wet-references-ap';d=json.loads((root/'receipt.json').read_text())
    assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['failure'] is None and d['source_unchanged'] and d['keys']==188 and sha(root/'references.pkl')==d['reference_pickle_sha256']
    roots=[root];controls=['generate_wet_references_ap.py','wet_reference_key_ap.py','dispatch_canopy_wet_references_ap.py','clm-canopy-wet-native-am-source.tar.gz','clm-canopy-wet-native-am-package.json'];name='canopy-wet-references-ap'
elif mode=='numpy':
    root=b/'canopy-wet-numpy-akd';d=json.loads((root/'full-receipt.json').read_text());t=json.loads((root/'target-receipt.json').read_text())
    assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1091,failures=0,errors=0,skipped=0) and t['counts']==dict(tests=72,failures=0,errors=0,skipped=0)
    roots=[b/n for n in ['canopy-wet-numpy-ak','canopy-wet-numpy-akb','canopy-wet-numpy-akc','canopy-wet-numpy-akd']]
    assert all((p/'pbs-exit.txt').read_text().strip()=='1' for p in roots[:-1]);controls=['clm-canopy-wet-numpy-ak-source.tar.gz','clm-canopy-wet-numpy-akb-source.tar.gz','clm-canopy-wet-numpy-akc-source.tar.gz','clm-canopy-wet-numpy-akd-source.tar.gz'];name='canopy-wet-numpy-akd'
elif mode=='comparison':
    roots=[b/n for n in ['qia-wet005-capacity-numpy-aj','qia-wet005-capacity_optics-numpy-aj','qia-wet005-capacity-numpy-ajb','qia-wet005-capacity_optics-numpy-ajb','qia-wet005-comparison-an']]
    assert all((p/'pbs-exit.txt').read_text().strip()=='1' for p in roots[:2])
    assert all((p/'pbs-exit.txt').read_text().strip()=='0' for p in roots[2:])
    d=json.loads((roots[-1]/'comparison.json').read_text());assert d['diagnosis_complete'] and all(v['all96state_chains_and_original_guards_exact'] for v in d['cases'].values())
    controls=['probe_qia_wet_limit_aj.py','probe_qia_wet_limit_ajb.py','compare_qia_wet_limit_an.py','clm-numerical-recovery-c-source.tar.gz','qia-recovery-c-inputs-u.tar.gz'];name='qia-wet005-comparison-an'
else:raise ValueError(mode)
for root in roots:
    for p in sorted(root.rglob('*')):
        if p.is_file():items.append((p,root.name+'/'+p.relative_to(root).as_posix()))
items += [(b/n,'control/'+n) for n in [*controls,Path(__file__).name]]
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia1110-numpy-tests-g';scratch=Path(os.environ['TMPDIR']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'qia1110-numpy-tests-g-source.tar.gz';package=json.loads((r/'package.json').read_text());assert sha(a)==package['archive_sha256'];results=[]
with tarfile.open(b/'pft-optics-final-d-source.tar.gz') as t:old=t.extractfile('src/noahmp_clm/physics/canopy_phase_energy.py').read()
for label in ['baseline','candidate']:
    s=scratch/label;s.mkdir()
    with tarfile.open(a) as t:t.extractall(s,filter='data')
    m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and all(sha(s/n)==h for n,h in m.items())
    if label=='baseline':
        (s/'src/noahmp_clm/physics/canopy_phase_energy.py').write_bytes(old);m['src/noahmp_clm/physics/canopy_phase_energy.py']=hashlib.sha256(old).hexdigest()
    folder=r/label;folder.mkdir();(folder/'SOURCE_SHA256.json').write_text(json.dumps(m,indent=2)+'\n');xml=folder/'targets.xml'
    env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
    cmd=[sys.executable,'-m','pytest','-q','-s','tests/test_canopy_phase_energy.py','--junitxml='+str(xml)]
    if label=='baseline':cmd+=['-k','exact_phase_kink_recovery']
    begun=time.monotonic()
    with (folder/'targets.log').open('x') as f:code=subprocess.run(cmd,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    tree=ET.parse(xml).getroot();counts={k:sum(int(v.attrib[k]) for v in tree.iter('testsuite')) for k in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==h for n,h in m.items());row=dict(label=label,returncode=code,counts=counts,source_unchanged=unchanged,seconds=time.monotonic()-begun,xml_sha256=sha(xml));results.append(row);(folder/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert unchanged
    if label=='baseline':assert code==1 and counts['tests']==3 and counts['failures']>=1 and counts['errors']==counts['skipped']==0
    if label=='baseline':assert all('Canopy phase Newton stalled' in (failure.text or '') for failure in tree.iter('failure'))
    else:assert code==0 and counts==dict(tests=29,failures=0,errors=0,skipped=0)
d=dict(scope='Actual EHPC PBS originalD expectedregressionfailure then all29 newNP phase tests with3 originalkink guesses/independentnetwork/store/energy invariants; beforeGPUport, no source/gate/precision/oldstores changes or fullscience acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,results=results,source_archive_sha256=sha(a),source_manifest_sha256=package['manifest_sha256']);(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')

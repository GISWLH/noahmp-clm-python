from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile
import time
import traceback

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia1110-reference-g'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'qia1110-numpy-d-source.tar.gz'
assert sha(a) == '300e6052489ccffeeba7710309686659f94e3d69f191f0181b253e830d7bdb45'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'tests'), str(s / 'benchmarks')]
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack, TF, LF, CW
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.gpu.canopy_phase_energy import unpack_phase

device = r / 'device'
binding = json.loads((device / 'binding.json').read_text())
cap = json.loads((device / 'surface-capture-a/receipt.json').read_text())
path = device / 'surface-capture-a/failed-surface.npz'
assert sha(path) == cap['failed_surface_sha256']
with np.load(path, allow_pickle=False) as z:
    packet = dict(z)
c, g, p, o, leaf, u, factors, v, cond = [np.asarray(packet['surface_a' + str(k)][0], float) for k in range(9)]
n = int(o[0]); dt = v[0]
snow = Snowpack(c[:n, 0], c[:n, 1], c[:n, 2], c[:n, 3], c[:n, 4:])
props = SoilParams(smcmax=p[0], bexp=p[1], smcref=p[2], satdk=p[3], quartz=p[4], smcwlt=p[5], saturated_suction_m=p[6])
soil = SoilEnthalpyState(g[:, 0], g[:, 1], g[:, 2], props, int(o[1]))
water = CanopyCondensate(cond[:, 0], cond[:, 1])
extra = packet['exchange_extension'][0]
exchange = CanopyExchange(*u[:11], atmosphere_water_velocity=extra[0], potential_temperature=extra[1])
parameters = LeafParameters(**json.loads((device / 'surface-capture-a/leaf-parameters.json').read_text()))
kwargs = dict(stem_area=packet['stem_area'][0], vegetated_fraction=u[13], transpiration_limit=u[16],
              ground_emissivity=u[18], ground_albedo=u[19:21], diffuse_fraction=u[21], cosine_zenith=u[22],
              nitrogen_factor=factors[:, 0], water_stress=factors[:, 1], leaf_parameters=parameters)
raw = packet['raw']; got = unpack_phase(raw[:, 441:741])
supply = SoilWaterSupply(np.maximum(soil.liquid - props.smcwlt * 1000. * soil.dz, 0.) / dt, v[3:], soil.liquid[0] / dt)
fixed = float(raw[0, 360])
from dataclasses import asdict,is_dataclass,replace
from test_canopy_phase_energy import independent_reference
from test_gpu_canopy_phase_energy import reference as quantized_reference
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters

def encode(x):
    if isinstance(x,np.ndarray):return dict(__array__=encode(x.tolist()),dtype=str(x.dtype),shape=list(x.shape))
    if is_dataclass(x):return dict(__type__=type(x).__name__,data={k:encode(v) for k,v in vars(x).items()})
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [encode(v) for v in x]
    if isinstance(x,np.generic):x=x.item()
    if isinstance(x,float) and not np.isfinite(x):return dict(__float__=str(x))
    return x

args=(leaf,float(u[11]),float(u[12]),exchange,water,float(dt))
kw={**kwargs,'soil_supply':supply,'root_enthalpy':LF+CW*(soil.temperature-TF),
    'ground_evaporation_limit':snow.mass[0]/dt if n else np.inf,'fixed_ground_temperature':fixed,
    'ground_is_ice':bool(fixed<TF),'ground_shares_soil':not n,'snowpack':snow,'tolerance':1e-7,'max_iterations':80}
got=solve_canopy_phase_energy(*args,**kw);independent=independent_reference(*args,**kw)
temperature=float(np.max(abs(np.r_[got['leaf_temperature'],got['ground_temperature']]-independent['temperature'])))
differences={key:float(abs(got[key]-independent[key])) for key in ['h','le','gpp']}
assert temperature<=.05 and np.max(abs(got['solver_residual']))<=1e-7 and np.max(abs(got['layer_residual']))<=1.01e-7
for key,delta in differences.items():
    absolute,near=(.01,.1) if key=='gpp' else (1.,10.)
    assert delta<=(absolute if abs(independent[key])<=near else .1*abs(independent[key]))
np.testing.assert_allclose(got['condensate'].mass+dt*got['wet_evaporation'],water.mass,rtol=0.,atol=1e-14)
quantized={}
assert vars(parameters)==vars(LeafParameters())
pack_kw={k:v for k,v in kw.items() if k not in ['tolerance','max_iterations','leaf_parameters']}
for precision,dtype in [('32',np.float32),('64',np.float64)]:
    base=replace(exchange,atmosphere_water_velocity=None,potential_temperature=None)
    arrays=pack_canopy_phase(*args[:3],base,*args[4:],**pack_kw,dtype=dtype)
    extension=np.asarray([exchange.water_velocity,exchange.heat_temperature],dtype)
    target=quantized_reference(arrays,exchange_extension=extension,tolerance=1e-7,max_iterations=80)
    quantized[precision]=dict(arrays=encode(arrays),extension=encode(extension),parameters=encode(pack_leaf_parameters(parameters,dtype)),
        reference={k:encode(target[k]) for k in ['leaf_temperature','ground_temperature','canopy_temperature','h','le','gpp','ground_heat']},
        reference_mass=encode(target['condensate'].mass),reference_enthalpy=encode(target['condensate'].enthalpy))
record=dict(scope='Corrected array shape metadata after289 fixturedecode failed for empty(0,5) snowimpurities; prior287 infinityserialization and289 invalidfixture results retained. No model/equation/input/control/reference changes. ExactoriginalCUDA1110 thirdMOST rejected boundary: currentNP-onlyproductionrecovery, oldstores/1e-7/80/strictdescent; independently assembled mass/phase/air/heat network with no production iterates, all outcomes retained. Quantized32/64 references computed onEHPC beforedeviceport. Not annual resume or scientificsite acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_surface_sha256=sha(path),call=encode(dict(args=args,kwargs=kw,initial_guess=None)),quantized=quantized,
    actual_reference_iterations=got['iterations'],actual_reference_max_residual=float(np.max(abs(got['solver_residual']))),independent_temperature_difference_K=temperature,independent_flux_absolute_differences=differences,
    independent_reference={k:encode(independent[k]) for k in ['temperature','h','le','gpp','residual']})
dest=r/'qia_1110_phase_kink.json';dest.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')

# Reconstruct the original native19 input with the established independent
# NumPy reference, retaining the explicit structure and MOST extension.
import test_gpu_clm_bgc_column as bgc
from noahmp_clm.physics.canopy_most import MOSTGeometry
from run_fluxnet_column import audit_step
with np.load(device/'input.npz',allow_pickle=False) as z:data=dict(z)
arrays=[data['a'+str(k)].copy() for k in range(19)];arrays[4][:,7:10]=data['environment']
original_step=bgc.step_clm_enthalpy_column;captured={}
def observe(state,forcing,**controls):
    after,diagnostics=original_step(state,forcing,**controls)
    _,residual,bound=audit_step(state,after,forcing,diagnostics,float(data['nitrogen'][0]))
    captured.update(before=state,after=after,forcing=forcing,diagnostics=diagnostics,residual=residual,bound=bound)
    return after,diagnostics
bgc.step_clm_enthalpy_column=observe
try:
    full=bgc.reference(tuple(v[0] for v in arrays[:16]),data['forcing'][0],data['deposition'][0],data['calendar_values'][0],data['calendar_flags'][0],float(data['nitrogen'][0]),1.,
        canopy_structure=tuple(v[0] for v in arrays[16:]),most_geometry=MOSTGeometry(*data['geometry'][0].astype(float)))
finally:bgc.step_clm_enthalpy_column=original_step
assert np.all(abs(captured['residual'])<=captured['bound'])
np.savez_compressed(r/'full-reference.npz',**{k:np.asarray(full['diagnostics'][k]) for k in ['h','le','gpp_gc_m2','nee_gc_m2']},tsoil_k=full['soil_temperature'],smc_m3m3=full['soil_cells'][:,0]/(1000.*full['soil_cells'][:,2]))
import pickle
(r/'full-reference-state.pkl').write_bytes(pickle.dumps(captured))
assert all(sha(s/k)==h for k,h in m.items())
receipt=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),fixture_sha256=sha(dest),fixture_bytes=dest.stat().st_size,
    reference_iterations=got['iterations'],independent_temperature_difference_K=temperature,independent_flux_absolute_differences=differences,
    full_original_MHCN_residual=captured['residual'].tolist(),full_original_MHCN_bound=captured['bound'].tolist(),full_reference_sha256=sha(r/'full-reference.npz'),
    reference_note='Nativequantizedinputs reconstructed infloat64; existingNumPy dataclass normalization of quantizedrootweights disclosed, no GPU/host surrogate tendency. This is a reference step, not original failed-year continuation.')
(r/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n');print(json.dumps(receipt,allow_nan=False),flush=True)

from pathlib import Path
import hashlib,json,subprocess,shutil
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia1110-reference-g';assert not r.exists();r.mkdir();shutil.copytree(b/'qia1110-numpy-a/device',r/'device')
controls={}
for n in ['generate_qia1110_reference_g.py','qia1110_reference_g.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia1110_reference_g.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,controls_sha256=controls,scope='NP-onlyproductioncandidate reference, originalfixedboundary/wholeBGC hardgates and independentnetwork; noGPUforwardphysics.'),indent=2)+'\n');print(job)

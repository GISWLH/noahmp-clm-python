from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia1110-numpy-tests-g';assert not r.exists();r.mkdir();controls={}
assert (b/'qia1110-reference-g/pbs-exit.txt').read_text().strip()=='0'
for n in ['run_qia1110_numpy_tests_g.py','qia1110_numpy_tests_g.pbs','qia1110-numpy-tests-g-package.json']:
    raw=(b/n).read_bytes()
    if n.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if n.endswith('package.json') else n)).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia1110_numpy_tests_g.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,controls_sha256=controls),indent=2)+'\n');print(job)

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia1110-numpy-native-h';assert not r.exists();r.mkdir();controls={};old=b/'qia-all-phase-numpy-year-c';assert (old/'pbs-exit.txt').read_text().strip()=='1' and json.loads((old/'receipt.json').read_text())['steps_completed']==1110
for n in ['probe_qia1110_numpy_native_h.py','qia1110_numpy_native_h.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia1110_numpy_native_h.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,controls_sha256=controls,scope='OriginalNumPyC failed1110 immutable; one diagnosticstep underH, originalsingle/cumulativeMHCN audit.'),indent=2)+'\n');print(job)

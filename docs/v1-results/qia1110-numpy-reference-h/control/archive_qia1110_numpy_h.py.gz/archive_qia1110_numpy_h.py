from pathlib import Path
import datetime,hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');roots=['qia1110-reference-d','qia1110-reference-e','qia1110-reference-g','qia1110-numpy-tests-f','qia1110-numpy-tests-g','qia1110-numpy-native-h','qia1110-cuda-audit-h'];a=b/'qia1110-numpy-reference-h-evidence.tar.gz';assert not a.exists()
assert (b/roots[0]/'pbs-exit.txt').read_text().strip()=='1' and (b/'qia1110-numpy-tests-f/pbs-exit.txt').read_text().strip()=='1'
for n in roots[1:]:
    if n!='qia1110-numpy-tests-f':assert (b/n/'pbs-exit.txt').read_text().strip()=='0'
with tarfile.open(a,'w:gz') as t:
    for n in roots:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(b).as_posix(),recursive=False)
    for n in ['qia1110-numpy-d-source.tar.gz','qia1110-numpy-tests-f-source.tar.gz','qia1110-numpy-tests-g-source.tar.gz','qia1110-final-h-source.tar.gz']:
        t.add(b/n,arcname='source/'+n,recursive=False)
    for n in ['dispatch_qia1110_reference_d.py','dispatch_qia1110_reference_e.py','dispatch_qia1110_reference_g.py','dispatch_qia1110_numpy_tests_f.py','dispatch_qia1110_numpy_tests_g.py','dispatch_qia1110_numpy_native_h.py','dispatch_qia1110_cuda_audit_h.py','archive_qia1110_numpy_h.py']:
        t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,scope='Original287 JSONinf serialization1,289 invalidemptyshape regressions1 are retained and not physicalregression credit. 288/290 independentreference same physicaloutputs; corrected291 trueold3Newtonfail/new29pass. 293 originalNumPyfailed1110 originalhard single/cumulative MHCN and294 CUDA361/19 originalhardbudgets retained; no failedyearresume/currentfull sciencepass.')))

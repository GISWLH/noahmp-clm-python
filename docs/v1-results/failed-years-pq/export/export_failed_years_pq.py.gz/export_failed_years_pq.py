"""Freeze original closed NS/NZ failure evidence without model imports or replay."""
import ast
import datetime
import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile
import zipfile

BASE = Path('/home/lhwang/work/noahmp-v1')
DEST = Path('/tmp/noahmp-failed-years-pq-export')
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
SOURCE_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
SPECS = {'NS': ('climatology-cold48-np', 'climatology-year-ns', 12),
         'NZ': ('hrldas-candidate-cold48-ny', 'hrldas-year-nz', 3)}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_text())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def npz_headers(path):
    result = {}
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            assert name.endswith('.npy')
            data = archive.read(name)
            assert data[:6] == b'\x93NUMPY'
            version = tuple(data[6:8])
            width = 2 if version == (1, 0) else 4
            assert version in ((1, 0), (2, 0), (3, 0))
            length = int.from_bytes(data[8:8 + width], 'little')
            header = ast.literal_eval(data[8 + width:8 + width + length].decode('utf-8' if version == (3, 0) else 'latin1'))
            payload = data[8 + width + length:]
            assert isinstance(header['descr'], str) and 'O' not in header['descr']
            result[name[:-4]] = dict(dtype=header['descr'], shape=list(header['shape']),
                fortran_order=header['fortran_order'], payload_bytes=len(payload),
                payload_sha256=hashlib.sha256(payload).hexdigest())
            if name == 'index.npy':
                assert header['shape'] == () and header['descr'] in ('<i8', '<i4')
                result['index']['scalar_value'] = struct.unpack('<q' if header['descr'] == '<i8' else '<i', payload)[0]
    return result


def main():
    assert not DEST.exists(), 'Use one fresh export directory; never overwrite original evidence.'
    selected = {}
    records = {}
    original_checks = {}
    source_checks = {}

    def add(name, path):
        path = Path(path)
        assert path.is_file() and not path.is_symlink(), path
        assert name not in selected, name
        selected[name] = path

    def tree(prefix, folder):
        for path in sorted(folder.rglob('*')):
            if path.is_file():
                add(prefix + '/' + path.relative_to(folder).as_posix(), path)

    source_archive = None
    for label, (original, control_name, columns) in SPECS.items():
        root, control = BASE / original, BASE / control_name
        current = root / 'cold48'
        trajectory = current / 'trajectory'
        plan = load(control / 'plan.json')
        source = Path(plan['source'])
        manifest = load(source / 'SOURCE_SHA256.json')
        assert sha(source / 'SOURCE_SHA256.json') == TARGET and len(manifest) == 584
        assert all(sha(source / n) == h for n, h in manifest.items())
        source_checks[label] = (source, manifest)
        assert all(sha(control / n) == h for n, h in plan['controls_sha256'].items())
        original_checks[label] = (control, plan['controls_sha256'])
        for name in ('year-launch.json', 'year-worker.json'):
            pid = load(current / name)['pid']
            assert not (Path('/proc') / str(pid)).exists(), (label, pid, 'still exists')
        end, receipt, report = [load(p) for p in (current / 'year-exit.json', current / 'year-receipt.json', trajectory / 'batch.json')]
        assert end['actual_parent_returncode'] == 1 and end['passed'] is False
        assert end['receipt_sha256'] == sha(current / 'year-receipt.json')
        assert receipt['report_sha256'] == sha(trajectory / 'batch.json')
        assert receipt['status'] == report['status'] == 'failed'
        assert receipt['source_unchanged'] and receipt['device_barrier_complete']
        assert report['columns'] == columns and report['steps_completed'] == report['ledger_steps'] == report['failed_step'] == 7275
        assert report['steps_requested'] == 17520 and report['ledger_segments'] == 1
        checkpoint = trajectory / report['checkpoint_file']
        assert sha(checkpoint) == report['checkpoint_sha256']
        descriptor = npz_headers(checkpoint)
        expected = {f'a{i}' for i in range(16)} | {'index', 'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax'}
        assert set(descriptor) == expected and descriptor['index']['scalar_value'] == 7275
        for i in range(16):
            assert descriptor[f'a{i}']['shape'][0] == columns
            assert descriptor[f'a{i}']['dtype'] == ('<i4' if i in (3, 9) else '<f4')
        for name in ('initial', 'net', 'bounds', 'maximum', 'stepmax'):
            assert descriptor[name]['shape'] == [columns, 4]
        assert descriptor['tracermax']['shape'] == [columns, 5]
        add(label + '/source/SOURCE_SHA256.json', source / 'SOURCE_SHA256.json')
        for name in ('benchmarks/run_fluxnet_native.py', 'src/noahmp_clm/gpu/clm_bgc_column.py',
                     'src/noahmp_clm/gpu/cuda/clm_layered_column.py', 'src/noahmp_clm/gpu/canopy_most_surface.py',
                     'src/noahmp_clm/gpu/cuda/canopy_phase_surface.py'):
            add(label + '/source/' + name, source / name)
        tree(label + '/year-controller', control)
        for path in sorted(root.iterdir()):
            if path.is_file() and not path.name.endswith('.tar.gz'):
                add(label + '/original-root/' + path.name, path)
        for path in sorted(current.iterdir()):
            if path.is_file():
                add(label + '/current/' + path.name, path)
        for folder in ('inputs', 'steps', 'year-bgc-diagnostics'):
            assert (current / folder).is_dir(), (label, folder)
            tree(label + '/current/' + folder, current / folder)
        add(label + '/current/trajectory/batch.json', trajectory / 'batch.json')
        add(label + '/current/trajectory/' + checkpoint.name, checkpoint)
        for case, item in report['case_reports'].items():
            case_report = trajectory / case / item['file']
            assert sha(case_report) == item['sha256']
            value = load(case_report)
            model = case_report.parent / value['model_npz']
            assert sha(model) == value['model_npz_sha256']
            assert value['steps_completed'] == value['ledger_steps'] == 7275
            assert value['batch_checkpoint_sha256'] == sha(checkpoint)
            assert (case_report.parent / value['batch_checkpoint_file']).resolve() == checkpoint.resolve()
            for path in (case_report, model, case_report.parent / 'report.json'):
                add(label + '/current/trajectory/' + path.relative_to(trajectory).as_posix(), path)
        # Retain the immediately previous durable generation for the BGC7248 endpoint.
        prior = [p for p in trajectory.rglob('*0007248-*') if p.is_file()]
        assert len(prior) == 1 + columns * 2
        for path in prior:
            add(label + '/current/trajectory/' + path.relative_to(trajectory).as_posix(), path)
        chunks = receipt['bgc_diagnostic_chunks']
        assert len(chunks) == 150 and receipt['bgc_diagnostic_steps'] == 7227
        for i, item in enumerate(chunks):
            assert item['first'] == 48 + i * 48 and item['end'] == 96 + i * 48
            file = current / 'year-bgc-diagnostics' / f"steps-{item['first']:07d}-{item['end']:07d}.npz"
            assert sha(file) == item['sha256']
        original_source = root / 'candidate-source.tar.gz'
        assert sha(original_source) == SOURCE_ARCHIVE
        if source_archive is None:
            source_archive = original_source
            add('source/candidate-source.tar.gz', source_archive)
        records[label] = dict(original_root=str(root), source=str(source), controller_root=str(control),
            original_processes=[dict(pid=load(current / n)['pid'], exists=False) for n in ('year-launch.json', 'year-worker.json')],
            actual_worker_returncode=end['actual_parent_returncode'], parent_record_passed=end['passed'],
            parent_record_failure=end['failure'], worker_failure=receipt['failure'],
            controller_os_exit_code=None,
            controller_exit_evidence='Original controller log and year-exit record retained; controller code ends SystemExit(1) when passed is false, but detached launch has no separate OS wait receipt.',
            status=report['status'], completed=7275, requested=17520, failed_step_zero_based=report['failed_step'],
            columns=columns, checkpoint_file=checkpoint.name, checkpoint_sha256=sha(checkpoint), checkpoint_fields=descriptor,
            source_manifest_sha256=TARGET, source_files_verified=584, source_before_after_verified=False,
            control_files_verified=len(plan['controls_sha256']), control_before_after_verified=False,
            declared_and_byte_verified_bgc_chunks=150, persisted_bgc_range=[48, 7248],
            successful_diagnostic_counter=7227, successful_bgc_steps_without_persisted_chunk=27,
            failed_call_before_packet_saved=False,
            failed_call_capture_evidence='Original native493 invokes step before audit496; except545-547 saves last committed a/global ledger at index7275. Year wrapper check_start runs only for first continuation and captures first successful result after audit; no per-step before dump or failure buffer flush.',
            replay_scope='Full original committed state at7275 plus unchanged input/source/configuration are retained. This supports a separately constructed replay request without replaying preceding48 steps; no actual failed before_device/kwargs/surface trial packet exists or is claimed byte-identical.',
            original_cold_archive=dict(path=str(root / 'cold48-evidence.tar.gz'), sha256=sha(root / 'cold48-evidence.tar.gz'), included=False),
            directory_listing=[dict(path=p.relative_to(current).as_posix(), bytes=p.stat().st_size)
                for p in sorted(current.rglob('*')) if p.is_file()],
            omitted_prior_generations='Original directories retained unchanged. Archive includes final7275 and preceding7248 immutable generations, all raw cold48 steps and validated prefix, all persisted BGC, full final traces, all frozen inputs and controls; older intermediate trajectory generations are listed only.')
    add('export/export_failed_years_pq.py', Path(__file__))
    before = {name: dict(sha256=sha(path), bytes=path.stat().st_size, original_path=str(path)) for name, path in selected.items()}
    DEST.mkdir()
    archive_path = DEST / 'failed-years-pq-evidence.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name, path in selected.items():
            archive.add(path, arcname=name, recursive=False)
        for label, (source, manifest) in source_checks.items():
            assert all(sha(source / n) == h for n, h in manifest.items())
            records[label]['source_before_after_verified'] = True
        for label, (control, hashes) in original_checks.items():
            assert all(sha(control / n) == h for n, h in hashes.items())
            records[label]['control_before_after_verified'] = True
        assert all(sha(path) == before[name]['sha256'] for name, path in selected.items())
        summary = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), years=records,
            immutable_selected_files=len(selected), all_selected_before_after_exact=True,
            source_archive_sha256=SOURCE_ARCHIVE, numerical_execution=False, gpu_calls=0,
            scope='Original terminal failure evidence; no reexecution, restart, source mutation, successful-year credit or failed-input reconstruction.')
        extra = {'SUMMARY.json': encoded(summary)}
        inventory = dict(before)
        inventory['SUMMARY.json'] = dict(sha256=hashlib.sha256(extra['SUMMARY.json']).hexdigest(), bytes=len(extra['SUMMARY.json']))
        extra['INVENTORY.json'] = encoded(inventory)
        for name, data in extra.items():
            item = tarfile.TarInfo(name)
            item.size = len(data)
            archive.addfile(item, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert len(archive.getmembers()) == len(inventory) + 1
        for name, item in inventory.items():
            stream = archive.extractfile(name)
            h = hashlib.sha256()
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
            assert h.hexdigest() == item['sha256'], name
    (DEST / 'SUMMARY.json').write_bytes(encoded(summary))
    package = dict(archive=archive_path.name, sha256=sha(archive_path), bytes=archive_path.stat().st_size,
        artifacts=len(inventory) + 1, inventory_files=len(inventory),
        scope=summary['scope'], source_archive_sha256=SOURCE_ARCHIVE, source_manifest_sha256=TARGET,
        actual_worker_returncodes={'NS': 1, 'NZ': 1}, status={'NS': 'failed', 'NZ': 'failed'},
        completed_each=7275, requested_each=17520, gpu_calls=0)
    (DEST / 'failed-years-pq-package.json').write_bytes(encoded(package))
    print(json.dumps(package))


if __name__ == '__main__':
    main()

"""PBS-only audit of current JN NumPy first-week paired HRLDAS outputs."""
from pathlib import Path
from dataclasses import fields, is_dataclass
import gzip, hashlib, json, os, pickle, re, struct, subprocess, sys, tarfile, time
import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r, model = b/'hrldas-current-kh', b/'hrldas-current-kg'
s = Path(os.environ['TMPDIR'])/'source'
s.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan = json.loads((model/'package.json').read_text())
assert sha(b/plan['archive']) == plan['archive_sha256']
with tarfile.open(b/plan['archive']) as archive:
    archive.extractall(s, filter='data')
m = json.loads((s/'SOURCE_SHA256.json').read_text())
manifest = sha(s/'SOURCE_SHA256.json')
assert len(m) == 581 and manifest == plan['source_manifest_sha256'] == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert all(sha(s/n) == h for n,h in m.items())
sys.path[:0] = [str(b/'test-deps'), str(s), str(s/'src'), str(s/'benchmarks')]
import run_fluxnet_column as runner
from compare_hrldas_suction_prefix import bind_suction_configurations, PROTOCOL_SHA, ARCHIVE_SHA, GENERATOR_SHA, SITES
from compare_hrldas_climate_prefix import _compare_aligned_prefix

start = time.monotonic()
dispatch = json.loads((model/'dispatch.json').read_text())
status = subprocess.check_output(['qstat','-xf',dispatch['pbs_job']], text=True)
assert re.search(r'^\s*job_state = F\s*$',status,re.M)
assert re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
assert (model/'pbs-exit.txt').read_text().strip() == '0'
(r/'model-actual-pbs-qstat.txt').write_text(status)
assert all(sha(model/n) == h for n,h in dispatch['controls_sha256'].items())
receipt = json.loads((model/'receipt.json').read_text())
protocol = json.loads((model/'inputs/protocol.json').read_text())
assert receipt['passed'] and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == manifest
assert receipt['input_protocol_sha256'] == sha(model/'inputs/protocol.json')
assert protocol['source_manifest_sha256'] == manifest and protocol['case_count'] == 3
assert protocol['diagnostic_steps'] == 336 and protocol['requested_steps'] == 17520
assert all(sha(model/'inputs'/n) == h for n,h in protocol['original_I_inputs_sha256'].items())
official = b/'hrldas-three-climate-b'
assert sha(official/'protocol.json') == PROTOCOL_SHA and sha(b/'hrldas-three-climate-b-evidence.tar.gz') == ARCHIVE_SHA
assert json.loads((official/'protocol.json').read_text())['instrument_sha256'] == GENERATOR_SHA

def identical(a,b,path='state'):
    assert type(a) is type(b), (path,type(a),type(b))
    if isinstance(a,np.ndarray):
        assert a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes(),path
    elif is_dataclass(a):
        for field in fields(a): identical(getattr(a,field.name),getattr(b,field.name),path+'.'+field.name)
    elif isinstance(a,dict):
        assert a.keys() == b.keys(),path
        for key in a: identical(a[key],b[key],path+'.'+str(key))
    elif isinstance(a,(list,tuple)):
        assert len(a) == len(b),path
        for i,(x,y) in enumerate(zip(a,b)): identical(x,y,path+'.'+str(i))
    elif isinstance(a,float):
        assert struct.pack('d',a) == struct.pack('d',b),path
    elif isinstance(a,np.generic):
        assert a.dtype == b.dtype and a.tobytes() == b.tobytes(),path
    else: assert a == b,path

results, audits, identities = {}, {}, {}
with tarfile.open(b/'hrldas-three-climate-b-evidence.tar.gz') as original:
    for name in ['protocol.json']+[site+'/'+n for site in SITES for n in ['prepared-manifest.json','audit.json','run-receipt.json']]:
        assert original.extractfile(name).read() == (official/name).read_bytes(),name
    for row in receipt['cases']:
        site,case = row['site'],row['case']
        assert site in SITES and case == site+'-suction-climate-cycle' and site not in results
        folder = model/'runs'/case
        assert (folder/'receipt.json').read_bytes() == (json.dumps(row,indent=2)+'\n').encode()
        assert row['failure'] is None and row['source_unchanged'] and row['source_manifest_sha256'] == manifest
        assert row['captured_steps'] == row['steps_completed'] == 336 and row['steps_requested'] == 17520
        assert row['preflight']['passed'] and row['preflight']['steps_completed'] == 48
        report_path = folder/'trajectory/report.json'
        report = json.loads(report_path.read_text())
        assert sha(report_path) == row['report_sha256']
        assert report['source_unchanged'] and report['source_sha256'] == runner.source_hashes()
        assert all(m[n] == h for n,h in report['source_sha256'].items())
        config_path = model/'inputs'/(site+'-config.json')
        config = json.loads(config_path.read_text())
        assert report['configuration'] == config and config['case'] == case
        assert sha(config_path) == row['configuration_sha256'] == report['configuration_sha256']
        prepared = json.loads((official/site/'prepared-manifest.json').read_text())
        reference = json.loads((official/site/'audit.json').read_text())
        assert reference['source_protocol_sha256'] == PROTOCOL_SHA
        paths = prepared['inputs_sha256']
        assert all(sha(name) == h for name,h in paths.items())
        old_config = next(Path(name) for name in paths if name.endswith('-config.json'))
        binding = bind_suction_configurations(old_config.read_bytes(),config_path.read_bytes(),prepared,site)
        for suffix,key in [('.npz','forcing_npz_sha256'),('.json','forcing_manifest_sha256')]:
            old = next(Path(name) for name in paths if name.endswith(suffix) and not name.endswith('-config.json'))
            assert sha(old) == sha(model/'inputs'/(site+suffix)) == report[key]
        trace_path = folder/'trajectory'/report['model_npz']
        checkpoint = folder/'trajectory'/report['checkpoint_file']
        assert sha(trace_path) == report['model_npz_sha256'] and sha(checkpoint) == report['checkpoint_sha256']
        with np.load(trace_path,allow_pickle=False) as z: trace = dict(z)
        saved,initial,net,bounds,maximum,stepmax,index = pickle.loads(checkpoint.read_bytes())
        assert index == 336 and sha(folder/'steps.tar.gz') == row['packets_sha256']
        state = runner.build_state(config)
        identical(initial,runner.totals(state),'initial_totals')
        current_initial = runner.totals(state)
        current_net, current_bounds, current_maximum, current_stepmax = [np.zeros(4) for _ in range(4)]
        metadata = json.loads((model/'inputs'/(site+'.json')).read_text())
        with np.load(model/'inputs'/(site+'.npz'),allow_pickle=False) as z: data = dict(z)
        stamps = runner.validate_input(data,metadata,model/'inputs'/(site+'.npz'))
        deposition = runner.DepositionSchedule(config)
        capacity = runner.capacity_configuration(config)
        with tarfile.open(folder/'steps.tar.gz') as packets:
            assert packets.getnames() == ['call-'+str(k).zfill(5)+'.pkl.gz' for k in range(336)]
            for k in range(336):
                packet = pickle.loads(gzip.decompress(packets.extractfile('call-'+str(k).zfill(5)+'.pkl.gz').read()))
                before,after,diagnostic = packet['before'],packet['after'],packet['diagnostics']
                identical(before,state,'step'+str(k)+'.before_chain')
                forcing = runner.Forcing(*data['forcing'][k])
                identical(packet['forcing'],forcing,'forcing')
                co2,mu,diffuse = data['environment'][k]
                expected = dict(co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),
                    leaf_dimension=config['leaf_dimension_m'],leaf_parameters=runner.LeafParameters(**config['leaf_parameters']),
                    most_geometry=runner.MOSTGeometry(**config['most_geometry']),
                    phenology_environment=runner.calendar(stamps[k],metadata,config['phenology'] is not None),
                    deposition_rates=deposition.aerosol(stamps[k],forcing.dt),nitrogen_deposition_gn_m2=deposition.nitrogen_rate*forcing.dt,
                    capacity_environment=runner.capacity_environment(stamps[k],metadata,capacity is not None))
                if config.get('canopy_optics') is not None: expected['canopy_optics'] = runner.CanopyOptics(**config['canopy_optics'])
                hydrology = runner.hydrology_configuration(config)
                if hydrology is not None: expected['soil_hydrology'] = hydrology
                identical(packet['kwargs'],expected,'kwargs')
                incoming,residual,bound = runner.audit_step(before,after,forcing,diagnostic,expected['nitrogen_deposition_gn_m2'])
                current_net += incoming
                current_bounds += bound
                cumulative = runner.totals(after)-current_initial-current_net
                assert np.all(abs(cumulative) <= current_bounds),(site,k,'original cumulative MHCN bound')
                for key,value in [('step_residual_m_h_c_n',residual),('step_bound_m_h_c_n',bound),('cumulative_residual_m_h_c_n',cumulative)]:
                    identical(trace[key][k],value,site+'.'+key+'.'+str(k))
                for key,field in runner.TRACE.items():
                    assert np.asarray(trace[key][k]).tobytes() == np.asarray(float(diagnostic[field])).tobytes(),(site,k,key)
                for key,value in [('tsoil_k',after.tsoil),('smc_m3m3',after.smc)]: identical(trace[key][k],value,site+'.'+key)
                assert trace['swe_m'][k] == after.swe and trace['lai'][k] == after.lai
                current_maximum = np.maximum(current_maximum,abs(cumulative))
                current_stepmax = np.maximum(current_stepmax,abs(residual))
                state = after
        for x,y,name in [(state,saved,'final_state'),(current_net,net,'net'),(current_bounds,bounds,'bounds'),(current_maximum,maximum,'maximum'),(current_stepmax,stepmax,'stepmax')]:
            identical(x,y,site+'.'+name)
        result = _compare_aligned_prefix(trace,report,reference,prepared)
        result['configuration_binding'] = binding
        results[site] = result
        audits[site] = dict(steps=336,cold_and_all335_between_steps_and_final_checkpoint_exact=True,
            actual_weather_calendar_leaf_height_deposition_kwargs_exact=True,all_original_step_and_cumulative_m_h_c_n_gates_passed=True,
            maximum_step_absolute_m_h_c_n=stepmax.tolist(),maximum_cumulative_absolute_m_h_c_n=maximum.tolist(),
            final_cumulative_bounds_m_h_c_n=bounds.tolist(),original_model_status=report['status'],original_model_requested=report['steps_requested'])
        identities[site] = {str(p):sha(p) for p in [report_path,trace_path,checkpoint,folder/'steps.tar.gz',config_path,old_config,
            official/site/'prepared-manifest.json',official/site/'audit.json',folder/'receipt.json']}
assert set(results) == set(SITES)
summary = dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,
    source_manifest_sha256=manifest,source_unchanged=all(sha(s/n) == h for n,h in m.items()),
    actual_model_parent_zero_job=dispatch['pbs_job'],input_protocol_sha256=sha(model/'inputs/protocol.json'),
    official_archive_sha256=ARCHIVE_SHA,official_protocol_sha256=PROTOCOL_SHA,results=results,independent_audits=audits,source_sha256=identities,
    scope='CurrentJN originalthree HRLDAS paired configurations, actualNumPy336 from freshcold, original17,520year request remainsrunning. Independentactual1008packet statechain/weather/kwargs/MHCN/trace/checkpoint audits and originalunchanged officialmetadata/time/7day/allvariables comparator. No report rewritten, source/calibration/selection/height/forcing changes. This is coldfirstweek diagnosis, not annual/spinup/observational/GPU/sameprecision/release acceptance. Scientificfailures are preserved independently of auditexecution status.')
assert summary['source_unchanged']
runner.atomic_json(r/'comparison.json',summary)
print(json.dumps({site:dict(h_bias=x['whole_prefix_means']['h_wm2']['relative_bias'],h_r=x['instantaneous_fluxes']['h_wm2']['r'],le_r=x['instantaneous_fluxes']['le_wm2']['r'],all_daily_bias=x['diagnostic_all_daily_bias_criteria_met']) for site,x in results.items()}),flush=True)

"""NY metadata contract; NP candidate safety prerequisites, exact KG input and LE reference."""
import json
import re
import tarfile
import hashlib
from pathlib import Path
from climatology_contract_np import (GPU, PARENT, TARGET, SOURCE_ARCHIVE,
    load, sha, source_archive, verify_source, prerequisites as np_prerequisites)

INPUT = '044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e'
REFERENCE = 'bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416'
PROTOCOL = 'cdbcdede1c9415a1a44c2c5de0849dcfcf93b9cb8e8eeaf18cb25c02c6014677'
NR = '6c77ee006ab9a815569039f491a7b1bd69fd118c1886ab178f72cbe0bd58466a'
NR_NAME = 'climatology-final-cpu-nr-evidence.tar.gz'
SITES = ['CN-Qia', 'CN-Cha', 'CN-HaM']


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def unpack(path, expected):
    assert sha(path) == expected
    with tarfile.open(path) as tf:
        files = [m for m in tf if m.isfile()]
        assert len({m.name for m in files}) == len(files)
        assert all(not m.issym() and not m.islnk() for m in files)
        data = {m.name: tf.extractfile(m).read() for m in files}
    if 'artifact-inventory.json' in data:
        inventory = json.loads(data['artifact-inventory.json'])
        assert set(inventory) == set(data) - {'artifact-inventory.json'}
        assert all(digest(data[n]) == v['sha256'] and len(data[n]) == v['bytes'] for n, v in inventory.items())
    return data


def actual_f0(data, job):
    text = data['actual-qstat.txt'].decode()
    assert re.search(r'^Job Id: ' + re.escape(job) + r'\s*$', text, re.M)
    assert re.search(r'^\s*job_state = F\s*$', text, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', text, re.M)
    assert data['pbs-exit.txt'].strip() == b'0'


def verify_nr(here):
    data = unpack(here / NR_NAME, NR)
    actual_f0(data, '1585.manager')
    value = json.loads(data['receipt.json'])
    proof = json.loads(data['collection-proof.json'])
    plan = json.loads(data['control/climatology-final-cpu-nr-plan.json'])
    nodes = json.loads(data['nodes.json'])
    assert value['pbs_job'] == '1585.manager' and value['node'] == 'compute002'
    assert value['passed'] and value['failure'] is None and value['source_unchanged']
    assert value['source_manifest_sha256'] == TARGET and value['source_archive_sha256'] == SOURCE_ARCHIVE
    assert value['source_files'] == 584 and value['pytest_returncode'] == 0
    assert value['counts'] == dict(tests=1168, failures=0, errors=0, skipped=0)
    assert value['exact_executed_node_coverage'] and value['xml_sha256'] == digest(data['junit.xml'])
    assert proof['original1156_retained'] and proof['added12_only_soc_boundary']
    assert proof['collection_actual_parent_returncode'] == 0
    assert len(nodes) == len(set(nodes)) == 1168
    assert set(nodes) == set(plan['original_cpu_nodes']) | set(plan['expected_added_boundary_nodes'])
    return {str(here / NR_NAME): NR}


def verify_inputs(folder, proof):
    folder = Path(folder)
    assert proof['reference_reusable'] and proof['reference_archive_sha256'] == REFERENCE
    assert proof['reference_source_manifest_sha256'] == PARENT and proof['input_archive_sha256'] == INPUT
    assert proof['candidate_source_manifest_sha256'] == TARGET and proof['candidate_source_archive_sha256'] == SOURCE_ARCHIVE
    assert proof['raw_packet_count'] == 1008 and proof['selected_packet_count'] == 144
    expected = proof['every_input_file_sha256']
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    assert actual == set(expected) and all(sha(folder/n) == h for n,h in expected.items())
    assert sha(folder/'protocol.json') == PROTOCOL
    value = load(folder/'protocol.json')
    assert value['pbs_job'] == '1188.manager' and value['source_manifest_sha256'] == PARENT and value['source_unchanged']
    assert value['case_count'] == 3 and value['cold_fields'] == 23 and value['primary_arrays'] == 16
    assert value['requested_steps'] == 17520 and value['preflight_steps'] == 48 and value['diagnostic_steps'] == 336
    assert [v['site'] for v in value['cases']] == SITES
    assert [v['case'] for v in value['cases']] == [site+'-suction-climate-cycle' for site in SITES]
    assert sha(folder/'cold-reference.npz') == value['cold_reference_sha256']
    assert all(sha(folder/n) == h for n,h in value['original_I_inputs_sha256'].items())
    assert load(folder/'batch.json')['cases'] == [{k:v for k,v in row.items() if k != 'site'} for row in value['cases']]
    return value


def verify_reference(path):
    assert sha(path) == REFERENCE
    with tarfile.open(path) as archive:
        names = archive.getnames()
        assert len(names) == len(set(names))
        value = json.loads(archive.extractfile('hrldas-current-kg/receipt.json').read())
        assert value['pbs_job'] == '1188.manager' and value['node'] == 'compute002'
        assert value['passed'] and value['source_unchanged'] and value['source_manifest_sha256'] == PARENT
        assert value['input_protocol_sha256'] == PROTOCOL and len(value['cases']) == 3
        for name,job in [('hrldas-current-kg','1188.manager'),('hrldas-current-kh','1189.manager')]:
            raw = archive.extractfile(name+'/actual-pbs-qstat.txt').read().decode()
            assert re.search(r'^Job Id: '+re.escape(job)+r'\s*$',raw,re.M)
            assert re.search(r'^\s*job_state = F\s*$',raw,re.M)
            assert re.search(r'^\s*Exit_status = 0\s*$',raw,re.M)
            assert archive.extractfile(name+'/pbs-exit.txt').read().strip() == b'0'
        assert digest(archive.extractfile('hrldas-current-kg/SOURCE_SHA256.json').read()) == PARENT
        for row in value['cases']:
            assert row['failure'] is None and row['source_unchanged'] and row['source_manifest_sha256'] == PARENT
            assert row['captured_steps'] == row['steps_completed'] == 336 and row['steps_requested'] == 17520
            assert row['preflight']['passed'] and row['preflight']['steps_completed'] == 48
            packet = archive.extractfile('hrldas-current-kg/runs/'+row['case']+'/steps.tar.gz').read()
            assert digest(packet) == row['packets_sha256']
    return value


def prerequisites(base):
    result = np_prerequisites(base)
    result.update(verify_nr(Path(__file__).resolve().parent))
    mx = Path(base) / 'surface-root-regression-mx'
    nodes = load(mx/'plan.json')['nodes']
    closed = [name for name in nodes if (mx/(Path(name).stem+'-exit.json')).exists()]
    assert len(closed) >= 6 and sum(len(nodes[name]) for name in closed) >= 23
    # The inherited NP gate has already verified every present receipt/exit/log.
    nf = Path(base)/'surface-root-permanent-nf/positive/audit.json'
    differences = load(nf)['same_precision_maximum_absolute_difference']
    assert len(differences) == 345 and all(value == 0 for value in differences.values())
    return result

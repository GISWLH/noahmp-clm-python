"""Fail-closed metadata gates for the future NM experiment. No model imports."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

PARENT = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
NF_TARGET = '097a98ce878e33eae26de0dd48fbb7b8a5b5b655661b84d4a64d296b21754f98'
ML = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
SOURCE_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
INPUT = 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
REFERENCE = 'b398835db56aa07f66641e81817bf9f3b8fb40bfe06eb9cf1b0f0b44d8409832'
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def verify_source(source):
    source = Path(source)
    manifest = load(source / 'SOURCE_SHA256.json')
    assert sha(source / 'SOURCE_SHA256.json') == TARGET and len(manifest) == 584
    assert all(sha(source / n) == h for n, h in manifest.items())
    actual = {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()}
    assert actual == set(manifest) | {'SOURCE_SHA256.json'}, 'Unmanifested source files are forbidden'
    return manifest


def source_archive(path):
    assert sha(path) == SOURCE_ARCHIVE
    with tarfile.open(path) as tf:
        members = tf.getmembers()
        assert all(m.isfile() for m in members)
        assert len({m.name for m in members}) == len(members)
        raw = {m.name: tf.extractfile(m).read() for m in members}
    assert hashlib.sha256(raw['SOURCE_SHA256.json']).hexdigest() == TARGET
    manifest = json.loads(raw['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and set(raw) == set(manifest) | {'SOURCE_SHA256.json'}
    assert all(hashlib.sha256(raw[n]).hexdigest() == h for n, h in manifest.items())
    return manifest


def verify_inputs(folder, proof):
    folder = Path(folder)
    expected = proof['every_input_file_sha256']
    assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()} == set(expected)
    assert all(sha(folder / n) == h for n, h in expected.items())
    protocol = load(folder / 'protocol.json')
    assert protocol['source_manifest_sha256'] == PARENT and protocol['case_count'] == 12
    assert protocol['cold_fields'] == 23 and protocol['native_state_arrays'] == 16
    return protocol




def verify_partial_mx(base, expected_source):
    """Require the actual first five; reject every currently recorded failure."""
    mx = base / 'surface-root-regression-mx'
    assert sha(mx / 'SOURCE_SHA256.json') == ML
    manifest = load(mx / 'SOURCE_SHA256.json')
    plan = load(mx / 'plan.json')
    assert plan['derived_manifest_sha256'] == ML and plan['total_original_nodes'] == 31
    assert len(plan['nodes']) == 8 and len(plan['nodes']['test_gpu_canopy_surface.py']) == 5
    evidence = {str(mx / 'plan.json'): sha(mx / 'plan.json')}
    completed = []
    for name, nodes in plan['nodes'].items():
        stem = Path(name).stem
        receipt_path = mx / (stem + '-receipt.json')
        exit_path = mx / (stem + '-exit.json')
        if receipt_path.exists():
            receipt = load(receipt_path)
            assert receipt['passed'] and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == ML
            assert receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0
            assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed']
            assert receipt['counts'] == dict(tests=len(nodes), failures=0, errors=0, skipped=0)
            assert set(receipt['nodes']) == set(nodes) and len(receipt['nodes']) == len(nodes)
            assert receipt['expected_nodes_sha256'] == sha(mx / (stem + '-expected.json'))
            assert receipt['xml_sha256'] == sha(mx / (stem + '.xml'))
            assert receipt['test_sha256'] == manifest['tests/' + name] == expected_source['tests/' + name]
            assert receipt['device_barriers'] and all(v['status'] == 'complete' for v in receipt['device_barriers'])
            evidence[str(receipt_path)] = sha(receipt_path)
        if exit_path.exists():
            row = load(exit_path)
            assert row['passed'] and row['actual_parent_returncode'] == 0
            assert row['receipt_sha256'] == sha(receipt_path)
            completed.append(name)
            evidence[str(exit_path)] = sha(exit_path)
        log = mx / (stem + '.log')
        if log.exists():
            raw = log.read_text(errors='replace')
            assert not re.search(r'^(?:FAILED\b|ERROR\b|=+ (?:FAILURES|ERRORS) =+)', raw, re.MULTILINE), name
            for line in raw.splitlines():
                match = re.fullmatch(r'([.FE]+)(?:\s+\[\s*\d+%\])?\s*', line)
                assert not match or not ({'F', 'E'} & set(match.group(1))), name
    assert 'test_gpu_canopy_surface.py' in completed
    progress = load(mx / 'progress.json')
    assert all(v['passed'] and v['actual_parent_returncode'] == 0 for v in progress['records'])
    if (mx / 'exit.json').exists():
        terminal = load(mx / 'exit.json')
        assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
        evidence[str(mx / 'exit.json')] = sha(mx / 'exit.json')
    assert not (mx / 'traceback.txt').exists()
    for name in ['src/noahmp_clm/gpu/snow_evolution.py', 'src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu',
                 'src/noahmp_clm/gpu/canopy_surface.py', 'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu']:
        assert expected_source[name] == manifest[name]
    return evidence


def verify_ni(expected_source):
    archive = Path(__file__).resolve().parent / 'surface-root-cpu-ni-evidence.tar.gz'
    assert sha(archive) == 'cc4ebaf52796ca40de9ee11df4ddb7269702ba458a10672d3668dcc924b78adc'
    with tarfile.open(archive) as tf:
        receipt = json.loads(tf.extractfile('receipt.json').read())
        plan = json.loads(tf.extractfile('control/surface-root-cpu-ni-plan.json').read())
        nodes = json.loads(tf.extractfile('nodes.json').read())
        source = json.loads(tf.extractfile('SOURCE_SHA256.json').read())
        qstat = tf.extractfile('actual-qstat.txt').read().decode()
        assert tf.extractfile('pbs-exit.txt').read().strip() == b'0'
        assert hashlib.sha256(tf.extractfile('SOURCE_SHA256.json').read()).hexdigest() == NF_TARGET
        assert hashlib.sha256(tf.extractfile('junit.xml').read()).hexdigest() == receipt['xml_sha256']
    assert receipt['passed'] and receipt['failure'] is None and receipt['pbs_job'] == '1578.manager'
    assert receipt['pytest_returncode'] == receipt['collection_actual_parent_returncode'] == 0
    assert receipt['counts'] == dict(tests=1156, failures=0, errors=0, skipped=0)
    assert receipt['source_unchanged'] and receipt['source_manifest_sha256'] == NF_TARGET and receipt['source_files'] == 584
    assert receipt['exact_original_cpu_nodes'] and len(nodes) == len(set(nodes)) == 1156
    assert nodes == plan['original_cpu_nodes']
    assert re.search(r'^Job Id: 1578\.manager\s*$', qstat, re.MULTILINE)
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.MULTILINE)
    assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.MULTILINE)
    assert set(source) == set(expected_source)
    assert {n for n in source if source[n] != expected_source[n]} == {'benchmarks/assess_clm_spinup.py', 'tests/test_clm_spinup.py'}
    return {str(archive): sha(archive)}


def prerequisites(base):
    from surface_regression_contract_mx import verify_preflight
    base = Path(base)
    expected_path=Path(__file__).resolve().parent/'EXPECTED_SOURCE_SHA256.json'
    assert sha(expected_path)==TARGET
    expected_source=load(expected_path)
    retained=verify_partial_mx(base,expected_source)
    retained.update(verify_ni(expected_source))
    preflight=base/'surface-root-regression-mx/preflight'
    verify_preflight(preflight)
    for name in ['ack.json','point_pair-audit.json','point_pair-actual-qstat.txt','k78-audit.json','k78-actual-qstat.txt']:
        retained[str(preflight/name)]=sha(preflight/name)
    nf = base / 'surface-root-permanent-nf'
    terminal = load(nf / 'exit.json')
    plan = load(nf / 'plan.json')
    assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
    assert plan['parent_manifest_sha256'] == PARENT and plan['ml_manifest_sha256'] == ML
    assert plan['variants']['positive']['source_manifest_sha256'] == NF_TARGET
    assert len(terminal['records']) == 2
    assert all(expected_source[n] == h for n, h in plan['additions_sha256'].items())
    for variant, code in [('negative', 1), ('positive', 0)]:
        folder = nf / variant
        receipt = load(folder / 'receipt.json')
        actual = load(folder / 'worker-actual-exit.json')
        audit = load(folder / 'audit.json')
        phases = load(folder / 'phases.json')
        collection = load(folder / 'collection.json')
        collect_actual = load(folder / 'collect-actual-exit.json')
        assert actual['actual_parent_returncode'] == receipt['worker_exitcode'] == receipt['pytest_returncode'] == code
        assert audit in terminal['records'] and audit['receipt_sha256'] == sha(folder / 'receipt.json')
        assert audit['phases_sha256'] == sha(folder / 'phases.json')
        assert receipt['source_unchanged'] and receipt['source_manifest_sha256'] == plan['variants'][variant]['source_manifest_sha256']
        assert receipt['counts'] == dict(tests=1, failures=code, errors=0, skipped=0)
        assert receipt['node_coverage_exact'] and receipt['xml_sha256'] == sha(folder / 'junit.xml')
        assert receipt['expected_nodes_sha256'] == sha(folder / 'expected.json')
        assert receipt['nodes'] == load(folder / 'expected.json')
        assert receipt['source_files'] == 584
        assert receipt['test_sha256'] == plan['additions_sha256']['tests/test_gpu_surface_root_contraction.py']
        assert {v['backend']: v['status'] for v in receipt['device_barriers']} == dict(jax='complete', cupy='complete')
        assert phases['pytest_exitstatus'] == code
        assert [v['outcome'] for v in phases['reports']] == ['passed', 'failed' if code else 'passed', 'passed']
        assert [v['when'] for v in phases['reports']] == ['setup', 'call', 'teardown']
        assert all(v['node'] == receipt['nodes'][0] for v in phases['reports'])
        assert collection['passed'] and collection['source_unchanged'] and collection['original_nodes_retained_exact']
        assert collect_actual['actual_parent_returncode'] == collection['returncode'] == 0
        assert collection['source_manifest_sha256'] == plan['variants'][variant]['source_manifest_sha256']
        assert collection['total_count'] == 1564 and collection['gpu_count'] == 408
        if code:
            assert audit['expected_original_physical_failure_observed'] and not receipt['passed']
        else:
            assert receipt['passed'] and receipt['all_setup_call_teardown_phases_passed']
            assert len(audit['same_precision_maximum_absolute_difference']) == 345
        for name in ['receipt.json', 'worker-actual-exit.json', 'audit.json', 'phases.json',
                     'collection.json', 'collect-actual-exit.json', 'expected.json', 'junit.xml']:
            retained[str(folder / name)] = sha(folder / name)
    for name in ['exit.json', 'plan.json']:
        retained[str(nf / name)] = sha(nf / name)
    nk = Path(__file__).resolve().parent / 'soc-strict-boundary-nk-evidence.tar.gz'
    assert sha(nk) == '0ee0356df093b5163f8b9c8e3b366a4919ac0fa6c521157973b0328968d7eb19'
    with tarfile.open(nk) as tf:
        nk_receipt = json.loads(tf.extractfile('receipt.json').read())
        nk_positive = json.loads(tf.extractfile('positive/actual.json').read())
        nk_qstat = tf.extractfile('actual-qstat.txt').read().decode()
        assert tf.extractfile('pbs-exit.txt').read().strip() == b'0'
    assert nk_receipt['passed'] and nk_receipt['pbs_job'] == '1583.manager'
    assert nk_positive['actual_pytest_parent_returncode'] == 0
    assert nk_positive['counts'] == dict(tests=46,failures=0,errors=0,skipped=0)
    assert re.search(r'^\s*job_state = F\s*$',nk_qstat,re.MULTILINE)
    assert re.search(r'^\s*Exit_status = 0\s*$',nk_qstat,re.MULTILINE)
    retained[str(nk)] = sha(nk)
    return retained


"""Close actual terminal F of the independent NY CPU audit, preserving any failure."""
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/tmp/noahmp-hrldas-cold48-ny-audit')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    assert os.name == 'posix' and os.uname().nodename == 'manager'
    launch = json.loads((ROOT / 'manager/dispatch.json').read_text())
    job_id = launch['pbs_job']
    qstat = subprocess.check_output(['qstat', '-xf', job_id], text=True)
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M), 'Must be actual F, not E'
    actual_exit = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
    raw_archive = ROOT / ('paired-audit-' + job_id + '.tar.gz')
    assert not raw_archive.exists()
    subprocess.run(['scp', 'compute002:' + str(raw_archive), str(raw_archive)], check=True)
    with tarfile.open(raw_archive) as tf:
        payload = {m.name.removeprefix('./'): tf.extractfile(m).read() for m in tf if m.isfile()}
    assert int(payload['pbs-exit.txt']) == actual_exit
    receipt = json.loads(payload['receipt.json']) if 'receipt.json' in payload else None
    passed = actual_exit == 0 and receipt is not None and receipt.get('passed') is True
    if passed:
        assert receipt['pbs_job'] == job_id and receipt['source_unchanged']
        assert receipt['source_manifest_sha256'] == launch['source_manifest_sha256']
        assert receipt['device_archive_sha256'] == launch['device_archive_sha256']
        assert receipt['reference_archive_sha256'] == launch['reference_archive_sha256']
        assert receipt['physical_step_pairs'] == 144 and receipt['cold_fields_exact'] == 23
        assert receipt['returned_fields_per_batched_step'] == 313
        assert receipt['all16state_chains_and_final_checkpoint_exact']
        assert len(receipt['cases']) == 3 and all(row['passed'] for row in receipt['cases'])
        assert all(row['original_numpy_first48_audit']['passed'] and row['original_numpy_first48_audit']['steps'] == 48 and row['original_numpy_first48_audit']['model_forward_calls'] == 0 for row in receipt['cases'])
        execution = json.loads(payload['executed-controls.json'])
        assert execution['actual_pbs_job'] == job_id and execution['actual_node'] == 'compute002'
        assert execution['audit_controls_manifest_sha256'] == launch['audit_controls_manifest_sha256']
    payload['actual-qstat.txt'] = qstat.encode()
    controls = ['manager/dispatch.json', 'manager/qsub-stdout.txt', 'manager/qsub-stderr.txt',
                'audit-input-manifest.json', 'dispatch_cold48_ny_audit.py', 'archive_cold48_ny_audit.py',
                'cold48-package.json']
    controls += ['controls/'+p.name for p in sorted((ROOT/'controls').iterdir()) if p.is_file()]
    for name in controls:
        payload['control/' + name] = (ROOT / name).read_bytes()
    assert sha(payload['control/audit-input-manifest.json']) == launch['manifest_sha256']
    assert sha(payload['control/controls/audit_cold48_ny.pbs']) == launch['pbs_sha256']
    assert sha(payload['control/controls/AUDIT_CONTROLS_SHA256.json']) == launch['audit_controls_manifest_sha256']
    if 'audit-input-manifest.json' in payload:
        assert payload['audit-input-manifest.json'] == payload['control/audit-input-manifest.json']
    if passed:
        assert execution['audit_controls_sha256'] == json.loads(payload['control/controls/AUDIT_CONTROLS_SHA256.json'])
        assert execution['gpu_controls_sha256'] == json.loads(payload['control/controls/EXPECTED_GPU_CONTROLS_SHA256.json'])
    manifest = json.loads(payload['control/audit-input-manifest.json'])
    for name in controls:
        if name in manifest['inputs']:
            assert sha(payload['control/' + name]) == manifest['inputs'][name]['sha256']
    output = ROOT / 'pbs-output.log'
    if output.exists():
        payload['control/pbs-output.log'] = output.read_bytes()
    payload['control/pbs-output-status.json'] = (json.dumps(dict(present=output.exists(),
        expected_path=str(output), note='Full worker stdout/stderr is preserved in worker.log; no absent scheduler output invented.'), indent=2) + '\n').encode()
    inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in payload.items()}
    payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
    target = ROOT / 'hrldas-cold48-ny-pair-evidence.tar.gz'
    assert not target.exists()
    with tarfile.open(target, 'w:gz') as tf:
        for name, raw in sorted(payload.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            tf.addfile(info, io.BytesIO(raw))
    with tarfile.open(target) as tf:
        assert {m.name: tf.extractfile(m).read() for m in tf} == payload
    package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
                   artifacts=len(payload), pbs_job=job_id, actual_job_state='F', actual_pbs_exit=actual_exit,
                   passed=passed, physical_step_pairs=receipt.get('physical_step_pairs') if receipt else None,
                   seconds=receipt.get('seconds') if receipt else None,
                   source_manifest_sha256=launch['source_manifest_sha256'],
                   device_archive_sha256=launch['device_archive_sha256'],
                   candidate_only=True, continuation_allowed=False,
                   scope='Independent3x48paired candidate readback only; no annual/multiyear/full-regression/observational pass.')
    (ROOT / 'hrldas-cold48-ny-pair-package.json').write_text(json.dumps(package, indent=2) + '\n')
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()

"""Run synthetic assessment tests only on the EHPC compute node."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/tmp/noahmp-soc-strict-boundary-nk')
out = root / 'manager'
assert not out.exists()
out.mkdir()
names = ['run_soc_strict_boundary_nk.py', 'soc-strict-boundary-nk-plan.json', 'soc-strict-boundary-nk-patch.tar.gz']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((root / names[1]).read_text())
assert sha(root / names[2]) == plan['patch_sha256']
assert b'\r\n' not in (root / names[0]).read_bytes()
subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'compute002',
                'test ! -e /tmp/noahmp-soc-strict-boundary-nk && mkdir -p /tmp/noahmp-soc-strict-boundary-nk/result'], check=True)
subprocess.run(['scp', *[str(root / n) for n in names], 'compute002:' + str(root) + '/'], check=True)
script = '''#!/bin/bash
#PBS -N clm-soc-limit-nk
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=4gb:host=compute002_00260924
#PBS -l walltime=00:10:00
#PBS -j oe
#PBS -o /tmp/noahmp-soc-strict-boundary-nk/pbs-output.log
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /tmp/noahmp-soc-strict-boundary-nk/result
/home/zhangyq/venvs/noahmp-closeout/bin/python -u /tmp/noahmp-soc-strict-boundary-nk/run_soc_strict_boundary_nk.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(out / 'job.pbs').write_text(script)
job = subprocess.run(['qsub', str(out / 'job.pbs')], cwd=out, capture_output=True, text=True)
assert job.returncode == 0, job.stderr
result = dict(pbs_job=job.stdout.strip(), controls_sha256={n: sha(root / n) for n in names},
              job_sha256=sha(out / 'job.pbs'), scope=plan['scope'])
(out / 'dispatch.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)

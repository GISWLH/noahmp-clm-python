"""Collect terminal NI or NK PBS evidence from node /tmp without touching HOME."""
from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

mode = sys.argv[1]
assert mode in ['ni', 'nk']
label = 'surface-root-cpu-ni' if mode == 'ni' else 'soc-strict-boundary-nk'
root = Path('/tmp/noahmp-' + label)
launch = json.loads((root / 'manager/dispatch.json').read_text())
qstat = subprocess.check_output(['qstat', '-xf', launch['pbs_job']], text=True)
assert re.search(r'^\s*job_state = F\s*$', qstat, re.M), 'Wait for actual terminal PBS state'
actual = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dest = root / 'compute-result'
assert not dest.exists()
subprocess.run(['scp', '-r', 'compute002:' + str(root / 'result'), str(dest)], check=True)
assert int((dest / 'pbs-exit.txt').read_text()) == actual
d = json.loads((dest / 'receipt.json').read_text())
assert d['pbs_job'] == launch['pbs_job'] and d['node'] == 'compute002'
assert d['passed'] and d['failure'] is None and actual == 0
if mode == 'ni':
    assert d['source_manifest_sha256'] == launch['source_manifest_sha256'] == '097a98ce878e33eae26de0dd48fbb7b8a5b5b655661b84d4a64d296b21754f98'
    assert d['source_unchanged'] and d['source_files'] == 584 and d['pytest_returncode'] == 0
    assert d['counts'] == dict(tests=1156, failures=0, errors=0, skipped=0)
    assert sha((dest / 'junit.xml').read_bytes()) == d['xml_sha256']
    assert d['exact_original_cpu_nodes'] and d['collection_actual_parent_returncode'] == 0
    plan = json.loads((root / (label + '-plan.json')).read_text())
    assert set(json.loads((dest / 'nodes.json').read_text())) == set(plan['original_cpu_nodes'])
else:
    assert len(d['records']) == 2
    negative, positive = d['records']
    assert [v['variant'] for v in d['records']] == ['negative', 'positive']
    assert negative['actual_pytest_parent_returncode'] == 1 and negative['counts']['failures'] == 4
    assert positive['actual_pytest_parent_returncode'] == 0 and positive['counts']['failures'] == 0
    assert negative['nodes'] == positive['nodes'] and negative['test_sha256'] == positive['test_sha256']
    for row in d['records']:
        assert row['source_unchanged'] and row['counts']['errors'] == row['counts']['skipped'] == 0
        assert sha((dest / row['variant'] / 'junit.xml').read_bytes()) == row['xml_sha256']
        assert sha((dest / row['variant'] / 'SOURCE_SHA256.json').read_bytes()) == row['source_manifest_sha256']
payload = {}
for p in dest.rglob('*'):
    if p.is_file():
        assert not p.is_symlink()
        payload[p.relative_to(dest).as_posix()] = p.read_bytes()
payload['actual-qstat.txt'] = qstat.encode()
for name, digest in launch['controls_sha256'].items():
    raw = (root / name).read_bytes()
    assert sha(raw) == digest
    payload['control/' + name] = raw
assert sha((root / 'manager/job.pbs').read_bytes()) == launch['job_sha256']
for name in ['manager/dispatch.json', 'manager/job.pbs']:
    payload['control/' + name] = (root / name).read_bytes()
dispatcher = 'dispatch_surface_cpu_ni.py' if mode == 'ni' else 'dispatch_soc_strict_boundary_nk.py'
payload['control/' + dispatcher] = (root / dispatcher).read_bytes()
payload['control/' + Path(__file__).name] = Path(__file__).read_bytes()
if (root / 'pbs-output.log').exists():
    payload['control/pbs-output.log'] = (root / 'pbs-output.log').read_bytes()
inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = root / (label + '-evidence.tar.gz')
assert not target.exists()
with tarfile.open(target, 'w:gz') as tf:
    for name, raw in sorted(payload.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        tf.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers()) == len(payload)
    for member in tf:
        assert tf.extractfile(member).read() == payload[member.name]
value = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size, artifacts=len(payload),
             pbs_job=launch['pbs_job'], actual_pbs_exit=actual, seconds=d['seconds'], scope=d['scope'])
(root / (label + '-package.json')).write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)

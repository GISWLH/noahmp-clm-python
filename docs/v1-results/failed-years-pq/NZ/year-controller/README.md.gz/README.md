# NZ：原三站NY冷48之后的年度后继（仅准备）

本年度后继未启动GPU、PBS或模型；不替换／中止原EHPC CPU LQ年度。准备期间NY独立审计1590已实际F0，因此`closed-prefix.json`绑定真实48步device `674b2f3f…703ed4c`、checkpoint `6c6211c8…824df7f`及144对审计包 `6bb99c71…ffedbcc`，并封入完整原38项审计包。原占位`closed-prefix.template.json`仍false/null，`promotion.template.json`同样false/null；没有`promotion.json`。已绑定冷48事实不构成年度运行许可。

唯一未来入口为`launch_year_nz.py year`，直接调用原`native.run(...backend='cuda32', compare_jax32=False, resume=True)`，在原NY `cold48/trajectory` 上48→17520，不复制／裁剪／重置物理状态和全局账，不接2657失败年，不借12组气候配置。新控制根为`/home/lhwang/work/noahmp-v1/hrldas-year-nz`，独立私有缓存为`/tmp/noahmp-hrldas-year-nz`。模型源仍为原NY `/tmp/noahmp-hrldas-candidate-cold48-ny/source`，固定NM584，不重解包新源。

启动门全部在mkdir前，controller与worker第一步前再次检查：

1. 原NM完整MX8模块／31节点的真实parent0与原phase/source/node/barrier证据、NF原负控1／正控0、345同精度最大差全部0、NK实际F0。原NM合同逐字节保留，仅调用其完整前提函数；其旧12组参考入口不用于本试验。
2. 精确NR1585 F0，1168项全过、584源、原1156+新增12覆盖。包SHA `6c77ee006ab9a815569039f491a7b1bd69fd118c1886ab178f72cbe0bd58466a`。
3. 新NY CUDA实际父退出0（物理设备仍CUDA1），以及新EHPC **144对实际F0**的完整封包：313返回结构、23冷字段、16链／末checkpoint、原MHCN／杂质、13轨迹、6日门、每库C/N和原NumPy48读回全部成功。必须真实产生后由根绑定归档SHA、checkpointSHA与job，不能填旧NP1586／576对结果。
4. 原KG三站输入SHA `044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e`；原LE NumPy参考SHA `bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416`；CN-Qia／CN-Cha／CN-HaM与原配置／驱动／根／PFT／高度／C/N全不变。原15输入逐字节；原NY冻结18控件清单匹配，不把旧12case接口当新输入。
5. root实际完成并核验Git晋升，写独立promotion.json：真实40位commit、精确NM源和NY实际闭合哈希，显式`formal_git_promotion_verified_by_root=true`及`allow_ny48_to_year=true`。此文件是root的事实确认；xuanze归档目录不是Git checkout，合同检查绑定和格式，不能自行证明该commit已真实晋升。root仍须以实际Git／NT证据确认，不可根据模板填一个SHA即声称晋升。
6. 原封存NY包内**所有原文件**与仍停在48的live目录逐字节相同，严格native identity包含原batch、3配置／强迫、全部源字段、cuda32/shadow=false。23字段checkpoint、3站generation report/trace、ledger=48/1均与封包匹配。原NY controller/worker已退出。已经前进、失败、重置或改输入的live轨迹拒绝。
7. 物理CUDA1 UUID `GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452`、启动显存>8 GiB和主机可用>32 GiB；原运行峰值4 GiB门保留，私有缓存，无NumPy前向或JAX shadow。

`forbidden/check_start/retain_bgc/first_step`四观察函数AST与原NS/NM完全相同，原唯一native.run调用完全相同；10个原assert只改两处参考基数（12→3、576→144和原KG沉降核验字段名），其余门不变。原始23字段在第一步真正tendency前逐字节再核；原累计MHCN和16状态链继续，不另起账。每48步保存实际BGC诊断和首次接续的原完整返回包，年末要求17520/1及相同identity。year原文件前缀新增于liveNY目录，但原已封存冷48包和candidate_only/continuation_allowed=false原记录不改；新年度许可独立记录在NZ。

准备完成不代表远端当前48状态已核验、MX31已通过或Git已晋升。NY配对1590F0已经按原门独立完成，耗时4.645844592秒；其元数据、完整原包与SHA在本机仅用标准库核验，未重新执行模型或数组分析。缺少真实promotion仍不能launch；没有自动续年／下一周期入口，也不能将年度成功当官方科学、SOC准平衡或全GPU回归验收。

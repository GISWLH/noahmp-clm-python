"""Future single NZ year entry, strictly from held NY48; preparation never runs it."""
import argparse
import datetime
import json
import os
import subprocess
import sys
from pathlib import Path

from hrldas_contract_nz import (GPU, NY_ROOT, NY_SOURCE, NZ_ROOT, NZ_TMP,
    PAIR_NAME, TARGET, load, preflight, sha)

HERE = Path(__file__).resolve().parent


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['year'])
    parser.parse_args()
    assert os.name == 'posix' and Path('/proc/meminfo').exists(), 'xuanze only'
    assert not NZ_ROOT.exists() and not NZ_TMP.exists(), 'Single fresh NZ control attempt only'
    controls = load(HERE / 'CONTROLS_SHA256.json')
    assert all(sha(HERE / name) == value for name, value in controls.items())
    proof = preflight(HERE)  # No filesystem mutation before real closed proof and promotion.
    folder = NY_ROOT / 'cold48'
    additions = ['prefix-verification.json', 'prefix-verification-pbs-exit.txt',
                 'prefix-verification-actual-qstat.txt', 'year-prefix-binding.json',
                 'year-launch.json', 'year-controller.log', 'year-worker.json',
                 'year-model.log', 'year-receipt.json', 'year-exit.json', 'year-bgc-diagnostics',
                 'validated-prefix-state.npz', 'validated-prefix-report.json',
                 'year-start-audit.json', 'first-continued-step.npz']
    assert all(not (folder / name).exists() for name in additions), 'Never overwrite/restart a year attempt'
    for record in [NY_ROOT / 'launch.json', folder / 'worker.json']:
        value = load(record)
        process = Path('/proc') / str(value['pid']) / 'cmdline'
        if process.exists():
            command = process.read_bytes().replace(b'\0', b' ').decode(errors='replace')
            assert str(NY_ROOT) not in command, 'Original NY process must have terminated'
    gpu = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=uuid,memory.free',
                                   '--format=csv,noheader,nounits'], text=True).strip().split(',')
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:')))
    assert gpu[0].strip() == GPU and int(gpu[1]) > 8192 and available > 32 * 1024 * 1024
    NZ_ROOT.mkdir()
    NZ_TMP.mkdir()
    names = sorted(set(controls) | {'CONTROLS_SHA256.json', PAIR_NAME, 'promotion.json', 'closed-prefix.json'})
    for name in names:
        (NZ_ROOT / name).write_bytes((HERE / name).read_bytes())
    hashes = {n: sha(NZ_ROOT / n) for n in names}
    write(NZ_ROOT / 'plan.json', dict(source_manifest_sha256=TARGET, source=str(NY_SOURCE),
        original_ny_root=str(NY_ROOT), original_ny_plan_sha256=sha(NY_ROOT / 'plan.json'),
        controls_sha256=hashes, stage='year', prerequisite_evidence_sha256=proof['retained'],
        scope='Separate formal authorization for the same successful NY48 trajectory; '
              'NY original candidate records stay immutable. No cold restart, failed JN continuation, '
              'state/ledger reset, altered physics gates or automatic next cycle.'))
    for source, destination in [('receipt.json', 'prefix-verification.json'),
                                ('pbs-exit.txt', 'prefix-verification-pbs-exit.txt'),
                                ('actual-qstat.txt', 'prefix-verification-actual-qstat.txt')]:
        with (folder / destination).open('xb') as stream:
            stream.write(proof['pair'][source])
    write(folder / 'year-prefix-binding.json', dict(
        prefix_batch_report_sha256=sha(folder / 'trajectory/batch.json'),
        prefix_checkpoint_sha256=proof['report']['checkpoint_sha256'],
        source_manifest_sha256=TARGET, independent_audit_receipt_sha256=sha(folder / 'prefix-verification.json'),
        original_ny_plan_sha256=sha(NY_ROOT / 'plan.json'), nz_plan_sha256=sha(NZ_ROOT / 'plan.json'),
        prefix_ledger_steps=48, prefix_ledger_segments=1))
    env = os.environ.copy()
    for key in ['LD_LIBRARY_PATH', 'PYTEST_PLUGINS']:
        env.pop(key, None)
    env.update(NZ_ROOT=str(NZ_ROOT), NZ_SOURCE=str(NY_SOURCE), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU,
               PYTHONPATH=':'.join(map(str, [NZ_ROOT, NY_SOURCE, NY_SOURCE / 'src', NY_SOURCE / 'benchmarks'])),
               CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
               XLA_PYTHON_CLIENT_PREALLOCATE='false', CUPY_CACHE_DIR=str(NZ_TMP / 'cupy'),
               CUDA_CACHE_PATH=str(NZ_TMP / 'cuda'), JAX_COMPILATION_CACHE_DIR=str(NZ_TMP / 'jax'))
    with (folder / 'year-controller.log').open('x') as log:
        process = subprocess.Popen([sys.executable, '-u', str(NZ_ROOT / 'control_year_nz.py')],
            cwd=NY_SOURCE, env=env, stdin=subprocess.DEVNULL, stdout=log,
            stderr=subprocess.STDOUT, start_new_session=True)
    write(folder / 'year-launch.json', dict(stage='year', controller_root=str(NZ_ROOT), pid=process.pid,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_manifest_sha256=TARGET,
        physical_gpu_index=1, physical_gpu_uuid=GPU, private_cache=str(NZ_TMP),
        gpu_free_mib=int(gpu[1]), host_available_kib=available, nz_plan_sha256=sha(NZ_ROOT / 'plan.json'),
        prerequisite_evidence_sha256=proof['retained']))
    print(json.dumps(load(folder / 'year-launch.json')))


if __name__ == '__main__':
    main()

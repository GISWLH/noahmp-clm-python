"""NZ metadata-only gates for the unchanged, still-held successful NY48."""
import hashlib
import io
import json
import re
import tarfile
import zipfile
from pathlib import Path

from climatology_contract_nm import (GPU, PARENT, SOURCE_ARCHIVE,
    TARGET, load, prerequisites, sha, verify_source)
from hrldas_contract_ny import INPUT, REFERENCE, verify_inputs

BASE = Path('/home/lhwang/work/noahmp-v1')
NY_ROOT = BASE / 'hrldas-candidate-cold48-ny'
NY_SOURCE = Path('/tmp/noahmp-hrldas-candidate-cold48-ny/source')
NZ_ROOT = BASE / 'hrldas-year-nz'
NZ_TMP = Path('/tmp/noahmp-hrldas-year-nz')
NR = '6c77ee006ab9a815569039f491a7b1bd69fd118c1886ab178f72cbe0bd58466a'
PAIR_NAME = 'hrldas-cold48-ny-pair-evidence.tar.gz'
NR_NAME = 'climatology-final-cpu-nr-evidence.tar.gz'


def closed_prefix():
    """Only an actual independently closed NY48 may supply these future hashes."""
    value = load(Path(__file__).resolve().parent/'closed-prefix.json')
    assert value['ready'] is True
    assert value['source_manifest_sha256'] == TARGET
    assert value['source_archive_sha256'] == SOURCE_ARCHIVE
    assert value['input_archive_sha256'] == INPUT and value['reference_archive_sha256'] == REFERENCE
    assert value['gpu_actual_parent_returncode'] == 0
    assert value['pair_actual_state'] == 'F' and value['pair_actual_exit'] == 0
    assert value['physical_step_pairs'] == 144 and value['cases'] == 3
    assert re.fullmatch(r'\d+\.manager',value['pair_pbs_job'])
    for name in ['device_archive_sha256','checkpoint_sha256','pair_archive_sha256']:
        assert isinstance(value[name],str) and re.fullmatch(r'[0-9a-f]{64}',value[name])
    return value


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def unpack(path, expected):
    assert sha(path) == expected
    with tarfile.open(path) as tf:
        files = [m for m in tf if m.isfile()]
        assert len({m.name for m in files}) == len(files)
        assert all(not m.issym() and not m.islnk() for m in files)
        data = {m.name: tf.extractfile(m).read() for m in files}
    if 'artifact-inventory.json' in data:
        inventory = json.loads(data['artifact-inventory.json'])
        assert set(inventory) == set(data) - {'artifact-inventory.json'}
        assert all(digest(data[n]) == v['sha256'] and len(data[n]) == v['bytes'] for n, v in inventory.items())
    return data


def actual_f0(data, job):
    text = data['actual-qstat.txt'].decode()
    assert re.search(r'^Job Id: ' + re.escape(job) + r'\s*$', text, re.M)
    assert re.search(r'^\s*job_state = F\s*$', text, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', text, re.M)
    assert data['pbs-exit.txt'].strip() == b'0'


def verify_nr(here):
    data = unpack(here / NR_NAME, NR)
    actual_f0(data, '1585.manager')
    value = json.loads(data['receipt.json'])
    proof = json.loads(data['collection-proof.json'])
    plan = json.loads(data['control/climatology-final-cpu-nr-plan.json'])
    nodes = json.loads(data['nodes.json'])
    assert value['pbs_job'] == '1585.manager' and value['node'] == 'compute002'
    assert value['passed'] and value['failure'] is None and value['source_unchanged']
    assert value['source_manifest_sha256'] == TARGET and value['source_archive_sha256'] == SOURCE_ARCHIVE
    assert value['source_files'] == 584 and value['pytest_returncode'] == 0
    assert value['counts'] == dict(tests=1168, failures=0, errors=0, skipped=0)
    assert value['exact_executed_node_coverage'] and value['xml_sha256'] == digest(data['junit.xml'])
    assert proof['original1156_retained'] and proof['added12_only_soc_boundary']
    assert proof['collection_actual_parent_returncode'] == 0
    assert len(nodes) == len(set(nodes)) == 1168
    assert set(nodes) == set(plan['original_cpu_nodes']) | set(plan['expected_added_boundary_nodes'])
    return {str(here / NR_NAME): NR}


def verify_ny_static():
    """Never modify or relabel the candidate-only original NY records."""
    closure = closed_prefix()
    DEVICE, CHECKPOINT, PAIR = (closure[k] for k in ['device_archive_sha256','checkpoint_sha256','pair_archive_sha256'])
    verify_source(NY_SOURCE)
    assert sha(NY_ROOT / 'candidate-source.tar.gz') == SOURCE_ARCHIVE
    assert sha(NY_ROOT / 'cold48-evidence.tar.gz') == DEVICE
    package = load(NY_ROOT / 'cold48-package.json')
    assert package['device_archive_sha256'] == DEVICE and package['source_manifest_sha256'] == TARGET
    assert package['candidate_only'] and package['continuation_allowed'] is False
    plan = load(NY_ROOT / 'plan.json')
    assert load(Path(__file__).resolve().parent/'EXPECTED_GPU_CONTROLS_SHA256.json') == plan['controls_sha256']
    assert plan['source_manifest_sha256'] == TARGET and plan['source_archive_sha256'] == SOURCE_ARCHIVE
    assert plan['input_archive_sha256'] == INPUT and plan['reference_archive_sha256'] == REFERENCE
    assert plan['candidate_only'] and plan['continuation_allowed'] is False and plan['maximum_forward_steps'] == 48
    assert all(sha(NY_ROOT / n) == h for n, h in plan['controls_sha256'].items())
    verify_inputs(NY_ROOT / 'cold48/inputs', load(NY_ROOT / 'reference-reuse.json'))
    return plan


def verify_ny48():
    """Bind every archived original byte; no state reconstruction or trimming."""
    closure = closed_prefix()
    DEVICE, CHECKPOINT, PAIR = (closure[k] for k in ['device_archive_sha256','checkpoint_sha256','pair_archive_sha256'])
    verify_ny_static()
    data = unpack(NY_ROOT / 'cold48-evidence.tar.gz', DEVICE)
    for name, raw in data.items():
        if name.startswith('current/'):
            actual = NY_ROOT / 'cold48' / name.removeprefix('current/')
        elif name.startswith('control/'):
            actual = NY_ROOT / name.removeprefix('control/')
        else:
            raise AssertionError('Unexpected original NY archive member: ' + name)
        assert actual.is_file() and not actual.is_symlink() and actual.read_bytes() == raw, name
    end, receipt = (json.loads(data[n]) for n in ['current/exit.json', 'current/receipt.json'])
    assert end['passed'] and end['actual_parent_returncode'] == 0 and end['failure'] is None
    assert end['receipt_sha256'] == digest(data['current/receipt.json'])
    assert end['candidate_only'] and end['continuation_allowed'] is False
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['device_barrier_complete'] and receipt['cold_fields_exact'] == 23 and receipt['primary_state_arrays'] == 16
    assert receipt['cases'] == 3 and receipt['captured_step_calls'] == receipt['steps_completed'] == 48
    assert receipt['steps_requested'] == 17520 and receipt['status'] == 'running'
    raw = data['current/trajectory/batch.json']
    report = json.loads(raw)
    assert receipt['report_sha256'] == digest(raw)
    assert report['source_unchanged'] and report['status'] == 'running' and report['columns'] == 3
    assert report['steps_completed'] == report['ledger_steps'] == 48 and report['ledger_segments'] == 1
    assert report['steps_requested'] == 17520 and report['same_precision_max_absolute'] is None
    assert report['checkpoint_sha256'] == CHECKPOINT
    checkpoint = data['current/trajectory/' + report['checkpoint_file']]
    assert digest(checkpoint) == CHECKPOINT
    with zipfile.ZipFile(io.BytesIO(checkpoint)) as z:
        assert set(z.namelist()) == {f'a{i}.npy' for i in range(16)} | {
            'index.npy', 'initial.npy', 'net.npy', 'bounds.npy', 'maximum.npy', 'stepmax.npy', 'tracermax.npy'}
    manifest = load(NY_SOURCE / 'SOURCE_SHA256.json')
    source_names = {n for n in manifest if n.startswith('src/noahmp_clm/') and Path(n).suffix in ('.py', '.cu', '.npz')}
    source_names |= {'benchmarks/run_fluxnet_native.py', 'benchmarks/run_fluxnet_column.py',
                     'benchmarks/fluxnet_solar.py', 'benchmarks/fluxnet_deposition.py'}
    batch_raw = data['current/inputs/batch.json']
    batch = json.loads(batch_raw)
    identities = []
    for row in batch['cases']:
        identities.append(dict(case=row['case'], forcing_npz_sha256=digest(data['current/inputs/' + row['input']]),
            forcing_manifest_sha256=digest(data['current/inputs/' + row['input_manifest']]),
            configuration_sha256=digest(data['current/inputs/' + row['configuration']])))
    expected = dict(batch_sha256=digest(batch_raw), cases=identities,
                    source_sha256={n: manifest[n] for n in source_names}, backend='cuda32', compare_jax32=False)
    assert report['identity'] == expected, 'Original strict native resume identity must match exactly'
    assert len(report['case_reports']) == 3
    for case, descriptor in report['case_reports'].items():
        path = 'current/trajectory/' + case + '/'
        case_raw = data[path + descriptor['file']]
        assert digest(case_raw) == descriptor['sha256']
        record = json.loads(case_raw)
        assert record['steps_completed'] == record['ledger_steps'] == 48 and record['ledger_segments'] == 1
        assert record['batch_checkpoint_sha256'] == CHECKPOINT
        assert digest(data[path + record['model_npz']]) == record['model_npz_sha256']
    return report


def verify_pair(here, promotion):
    closure = closed_prefix()
    DEVICE, CHECKPOINT, PAIR = (closure[k] for k in ['device_archive_sha256','checkpoint_sha256','pair_archive_sha256'])
    expected = promotion['ny_pair_archive_sha256']
    assert expected == PAIR
    data = unpack(here / PAIR_NAME, expected)
    actual_f0(data, closure['pair_pbs_job'])
    receipt = json.loads(data['receipt.json'])
    assert receipt['pbs_job'] == closure['pair_pbs_job'] and receipt['node'] == 'compute002'
    assert receipt['passed'] and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['device_archive_sha256'] == DEVICE
    assert receipt['reference_source_manifest_sha256'] == PARENT and receipt['reference_archive_sha256'] == REFERENCE
    assert receipt['cold_fields_exact'] == 23 and receipt['physical_step_pairs'] == 144
    assert receipt['returned_fields_per_batched_step'] == 313
    execution = json.loads(data['executed-controls.json'])
    assert execution['gpu_controls_manifest_sha256'] == sha(Path(__file__).resolve().parent/'EXPECTED_GPU_CONTROLS_SHA256.json')
    assert receipt['all16state_chains_and_final_checkpoint_exact'] and len(receipt['cases']) == 3
    assert all(v['passed'] and not v['failed_fields'] and v['all48_actual_deposition_inputs_byteexact_to_original_configuration']
               for v in receipt['cases'])
    assert {v['case'] for v in receipt['cases']} == {s+'-suction-climate-cycle' for s in ['CN-Qia','CN-Cha','CN-HaM']}
    assert all(v['original_numpy_first48_audit']['passed'] and v['original_numpy_first48_audit']['steps'] == 48
               and v['original_numpy_first48_audit']['model_forward_calls'] == 0 for v in receipt['cases'])
    return data


def preflight(here):
    """Requires fresh explicit promotion plus original full MX/NF/NR/NY evidence."""
    closure = closed_prefix()
    DEVICE, CHECKPOINT, PAIR = (closure[k] for k in ['device_archive_sha256','checkpoint_sha256','pair_archive_sha256'])
    here = Path(here)
    promotion = load(here / 'promotion.json')
    assert promotion['allow_ny48_to_year'] is True
    assert promotion['formal_git_promotion_verified_by_root'] is True
    assert re.fullmatch(r'[0-9a-f]{40}', promotion['promotion_commit'])
    assert promotion['promoted_source_manifest_sha256'] == TARGET
    assert promotion['source_archive_sha256'] == SOURCE_ARCHIVE
    assert promotion['ny_device_archive_sha256'] == DEVICE and promotion['nr_archive_sha256'] == NR
    assert promotion['ny_pair_archive_sha256'] == PAIR and promotion['ny_checkpoint_sha256'] == CHECKPOINT
    assert promotion['closed_prefix_sha256'] == sha(here/'closed-prefix.json')
    assert promotion['trajectory'] == str(NY_ROOT / 'cold48/trajectory')
    retained = prerequisites(BASE)  # Exact, unchanged NM full MX31 + NF +/- + NK gates.
    positive = load(BASE / 'surface-root-permanent-nf/positive/audit.json')
    assert len(positive['same_precision_maximum_absolute_difference']) == 345
    assert all(v == 0 for v in positive['same_precision_maximum_absolute_difference'].values())
    retained.update(verify_nr(here))
    pair = verify_pair(here, promotion)
    report = verify_ny48()
    retained.update({str(here / 'promotion.json'): sha(here / 'promotion.json'),
                     str(here / 'closed-prefix.json'): sha(here / 'closed-prefix.json'),
                     str(here / PAIR_NAME): sha(here / PAIR_NAME),
                     str(NY_ROOT / 'cold48-evidence.tar.gz'): DEVICE,
                     str(NY_ROOT / 'cold48/trajectory/batch.json'): sha(NY_ROOT / 'cold48/trajectory/batch.json')})
    return dict(retained=retained, report=report, pair=pair)


def verify_year_binding(here, proof):
    """The separate authorization must copy the exact independently closed audit."""
    closure = closed_prefix()
    DEVICE, CHECKPOINT, PAIR = (closure[k] for k in ['device_archive_sha256','checkpoint_sha256','pair_archive_sha256'])
    here = Path(here)
    folder = NY_ROOT / 'cold48'
    for archived, current in [('receipt.json', 'prefix-verification.json'),
                              ('pbs-exit.txt', 'prefix-verification-pbs-exit.txt'),
                              ('actual-qstat.txt', 'prefix-verification-actual-qstat.txt')]:
        assert (folder / current).read_bytes() == proof['pair'][archived]
    binding = load(folder / 'year-prefix-binding.json')
    assert binding['prefix_batch_report_sha256'] == sha(folder / 'trajectory/batch.json')
    assert binding['prefix_checkpoint_sha256'] == proof['report']['checkpoint_sha256'] == CHECKPOINT
    assert binding['source_manifest_sha256'] == TARGET
    assert binding['independent_audit_receipt_sha256'] == sha(folder / 'prefix-verification.json')
    assert binding['original_ny_plan_sha256'] == sha(NY_ROOT / 'plan.json')
    assert binding['nz_plan_sha256'] == sha(here / 'plan.json')
    assert binding['prefix_ledger_steps'] == 48 and binding['prefix_ledger_segments'] == 1

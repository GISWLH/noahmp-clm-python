"""Fail-closed metadata gates for the future NM experiment. No model imports."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

PARENT = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
NF_TARGET = '097a98ce878e33eae26de0dd48fbb7b8a5b5b655661b84d4a64d296b21754f98'
ML = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
SOURCE_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
INPUT = 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
REFERENCE = 'b398835db56aa07f66641e81817bf9f3b8fb40bfe06eb9cf1b0f0b44d8409832'
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def verify_source(source):
    source = Path(source)
    manifest = load(source / 'SOURCE_SHA256.json')
    assert sha(source / 'SOURCE_SHA256.json') == TARGET and len(manifest) == 584
    assert all(sha(source / n) == h for n, h in manifest.items())
    actual = {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()}
    assert actual == set(manifest) | {'SOURCE_SHA256.json'}, 'Unmanifested source files are forbidden'
    return manifest


def source_archive(path):
    assert sha(path) == SOURCE_ARCHIVE
    with tarfile.open(path) as tf:
        members = tf.getmembers()
        assert all(m.isfile() for m in members)
        assert len({m.name for m in members}) == len(members)
        raw = {m.name: tf.extractfile(m).read() for m in members}
    assert hashlib.sha256(raw['SOURCE_SHA256.json']).hexdigest() == TARGET
    manifest = json.loads(raw['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and set(raw) == set(manifest) | {'SOURCE_SHA256.json'}
    assert all(hashlib.sha256(raw[n]).hexdigest() == h for n, h in manifest.items())
    return manifest


def verify_inputs(folder, proof):
    folder = Path(folder)
    expected = proof['every_input_file_sha256']
    assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()} == set(expected)
    assert all(sha(folder / n) == h for n, h in expected.items())
    protocol = load(folder / 'protocol.json')
    assert protocol['source_manifest_sha256'] == PARENT and protocol['case_count'] == 12
    assert protocol['cold_fields'] == 23 and protocol['native_state_arrays'] == 16
    return protocol


def prerequisites(base):
    """Recheck actual closed MX31 and NF worker evidence, never an ACK alone."""
    base = Path(base)
    mx = base / 'surface-root-regression-mx'
    terminal = load(mx / 'exit.json')
    assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
    assert terminal['source_manifest_sha256'] == ML and terminal['original_nodes_attempted'] == 31
    plan = load(mx / 'plan.json')
    assert plan['derived_manifest_sha256'] == ML and plan['total_original_nodes'] == 31
    assert sha(mx / 'SOURCE_SHA256.json') == ML
    mx_manifest = load(mx / 'SOURCE_SHA256.json')
    assert len(terminal['records']) == len(plan['nodes']) == 8
    expected_path = Path(__file__).resolve().parent / 'EXPECTED_SOURCE_SHA256.json'
    assert sha(expected_path) == TARGET
    expected_source = load(expected_path)
    for name in ['src/noahmp_clm/gpu/snow_evolution.py', 'src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu', 'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu', 'src/noahmp_clm/gpu/canopy_surface.py']:
        assert expected_source[name] == mx_manifest[name]
    retained = {str(mx / 'exit.json'): sha(mx / 'exit.json'), str(mx / 'plan.json'): sha(mx / 'plan.json')}
    for row in terminal['records']:
        stem = Path(row['file']).stem
        path = mx / (stem + '-receipt.json')
        receipt = load(path)
        expected = plan['nodes'][row['file']]
        assert row['passed'] and row['actual_parent_returncode'] == 0 and row['receipt_sha256'] == sha(path)
        assert receipt['passed'] and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == ML
        assert receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0
        assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed']
        assert receipt['counts'] == dict(tests=len(expected), failures=0, errors=0, skipped=0)
        assert set(receipt['nodes']) == set(expected) and len(receipt['nodes']) == len(expected)
        assert receipt['expected_nodes_sha256'] == sha(mx / (stem + '-expected.json'))
        assert receipt['test_sha256'] == mx_manifest['tests/' + row['file']]
        assert receipt['xml_sha256'] == sha(mx / (stem + '.xml'))
        assert receipt['device_barriers'] and all(v['status'] == 'complete' for v in receipt['device_barriers'])
        retained[str(path)] = sha(path)
    nf = base / 'surface-root-permanent-nf'
    terminal = load(nf / 'exit.json')
    plan = load(nf / 'plan.json')
    assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
    assert plan['parent_manifest_sha256'] == PARENT and plan['ml_manifest_sha256'] == ML
    assert plan['variants']['positive']['source_manifest_sha256'] == NF_TARGET
    assert len(terminal['records']) == 2
    assert all(expected_source[n] == h for n, h in plan['additions_sha256'].items())
    for variant, code in [('negative', 1), ('positive', 0)]:
        folder = nf / variant
        receipt = load(folder / 'receipt.json')
        actual = load(folder / 'worker-actual-exit.json')
        audit = load(folder / 'audit.json')
        phases = load(folder / 'phases.json')
        collection = load(folder / 'collection.json')
        collect_actual = load(folder / 'collect-actual-exit.json')
        assert actual['actual_parent_returncode'] == receipt['worker_exitcode'] == receipt['pytest_returncode'] == code
        assert audit in terminal['records'] and audit['receipt_sha256'] == sha(folder / 'receipt.json')
        assert audit['phases_sha256'] == sha(folder / 'phases.json')
        assert receipt['source_unchanged'] and receipt['source_manifest_sha256'] == plan['variants'][variant]['source_manifest_sha256']
        assert receipt['counts'] == dict(tests=1, failures=code, errors=0, skipped=0)
        assert receipt['node_coverage_exact'] and receipt['xml_sha256'] == sha(folder / 'junit.xml')
        assert receipt['expected_nodes_sha256'] == sha(folder / 'expected.json')
        assert receipt['nodes'] == load(folder / 'expected.json')
        assert receipt['source_files'] == 584
        assert receipt['test_sha256'] == plan['additions_sha256']['tests/test_gpu_surface_root_contraction.py']
        assert {v['backend']: v['status'] for v in receipt['device_barriers']} == dict(jax='complete', cupy='complete')
        assert phases['pytest_exitstatus'] == code
        assert [v['outcome'] for v in phases['reports']] == ['passed', 'failed' if code else 'passed', 'passed']
        assert [v['when'] for v in phases['reports']] == ['setup', 'call', 'teardown']
        assert all(v['node'] == receipt['nodes'][0] for v in phases['reports'])
        assert collection['passed'] and collection['source_unchanged'] and collection['original_nodes_retained_exact']
        assert collect_actual['actual_parent_returncode'] == collection['returncode'] == 0
        assert collection['source_manifest_sha256'] == plan['variants'][variant]['source_manifest_sha256']
        assert collection['total_count'] == 1564 and collection['gpu_count'] == 408
        if code:
            assert audit['expected_original_physical_failure_observed'] and not receipt['passed']
        else:
            assert receipt['passed'] and receipt['all_setup_call_teardown_phases_passed']
            assert len(audit['same_precision_maximum_absolute_difference']) == 345
        for name in ['receipt.json', 'worker-actual-exit.json', 'audit.json', 'phases.json',
                     'collection.json', 'collect-actual-exit.json', 'expected.json', 'junit.xml']:
            retained[str(folder / name)] = sha(folder / name)
    for name in ['exit.json', 'plan.json']:
        retained[str(nf / name)] = sha(nf / name)
    nk = Path(__file__).resolve().parent / 'soc-strict-boundary-nk-evidence.tar.gz'
    assert sha(nk) == '0ee0356df093b5163f8b9c8e3b366a4919ac0fa6c521157973b0328968d7eb19'
    with tarfile.open(nk) as tf:
        nk_receipt = json.loads(tf.extractfile('receipt.json').read())
        nk_positive = json.loads(tf.extractfile('positive/actual.json').read())
        nk_qstat = tf.extractfile('actual-qstat.txt').read().decode()
        assert tf.extractfile('pbs-exit.txt').read().strip() == b'0'
    assert nk_receipt['passed'] and nk_receipt['pbs_job'] == '1583.manager'
    assert nk_positive['actual_pytest_parent_returncode'] == 0
    assert nk_positive['counts'] == dict(tests=46,failures=0,errors=0,skipped=0)
    assert re.search(r'^\s*job_state = F\s*$',nk_qstat,re.MULTILINE)
    assert re.search(r'^\s*Exit_status = 0\s*$',nk_qstat,re.MULTILINE)
    retained[str(nk)] = sha(nk)
    return retained


def verify_prefix_audit(root):
    root = Path(root)
    evidence = root / 'paired-audit'
    receipt = load(evidence / 'receipt.json')
    assert (evidence / 'pbs-exit.txt').read_text().strip() == '0'
    qstat = (evidence / 'actual-qstat.txt').read_text()
    assert re.search(r'^Job Id: ' + re.escape(receipt['pbs_job']) + r'\s*$', qstat, re.M)
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M) and re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
    assert receipt['passed'] and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['reference_source_manifest_sha256'] == PARENT and receipt['reference_archive_sha256'] == REFERENCE
    assert receipt['cold_fields_exact'] == 23 and receipt['physical_step_pairs'] == 576
    assert receipt['all16state_chains_and_final_checkpoint_exact'] and len(receipt['cases']) == 12
    assert all(v['passed'] and v['all48_actual_deposition_inputs_byteexact_to_declared_climatology'] for v in receipt['cases'])
    assert receipt['device_archive_sha256'] == sha(root / 'cold48-evidence.tar.gz')
    # Bind the actual still-held48 report/checkpoint to the audited archive bytes.
    with tarfile.open(root / 'cold48-evidence.tar.gz') as tf:
        report_raw = tf.extractfile('current/trajectory/batch.json').read()
        report = json.loads(report_raw)
        assert report_raw == (root / 'cold48/trajectory/batch.json').read_bytes()
        checkpoint = tf.extractfile('current/trajectory/' + report['checkpoint_file']).read()
    assert hashlib.sha256(checkpoint).hexdigest() == report['checkpoint_sha256']
    assert checkpoint == (root / 'cold48/trajectory' / report['checkpoint_file']).read_bytes()
    return receipt


def verify_parent(folder, stage):
    folder = Path(folder)
    filename = 'year-receipt.json' if stage == 'year' else 'receipt.json'
    endname = 'year-exit.json' if stage == 'year' else 'exit.json'
    receipt = load(folder / filename)
    terminal = load(folder / endname)
    assert terminal['passed'] and terminal['actual_parent_returncode'] == 0 and terminal['receipt_sha256'] == sha(folder / filename)
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['device_barrier_complete'] and receipt['status'] == 'complete'
    assert receipt['steps_completed'] == receipt['steps_requested'] == 17520
    report = load(folder / 'trajectory/batch.json')
    assert receipt['report_sha256'] == sha(folder / 'trajectory/batch.json')
    assert report['status'] == 'complete' and report['steps_completed'] == report['steps_requested'] == 17520
    assert report['columns'] == 12 and report['source_unchanged'] and report['same_precision_max_absolute'] is None
    assert sha(folder / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
    return report

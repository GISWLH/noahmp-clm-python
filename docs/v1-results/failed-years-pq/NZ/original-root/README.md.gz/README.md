# NY：原 HRLDAS 三站的候选 CUDA1 冷48

本目录只准备私有候选实验，尚未启动 GPU、PBS 或续年。沿 NP 已完成的冷48控制：原 KG 的 CN-Qia、CN-Cha、CN-HaM 三个 batch/config/forcing、23 个冷字段和 16 个主状态数组全部保留；原完整请求仍为每站17,520步，唯一前向入口固定 `stop_after=48`，无 resume/year/cycle 命令，也不会修改正在运行的原 NumPy 年。

候选源固定 NM584，manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f`，source archive `39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d`。CPU依据为同源 NR1585.manager 实际 F0、1168/0/0/0；保留原 NP 候选安全前置条件，并收紧为 MX 原计划至少6个已闭合模块/23个原节点，全部实际 parent0、无任何当前记录失败；NF 实际负1/正0、345个同精度差值全部0。该冷48可早于剩余MX完成及Git晋升，但不能据此运行全年。

参考保留原 JN581 身份 `e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5`。原 KG1188/KH1189 实际 F0，LE 包 SHA `bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416`；原输入包 SHA `044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e`。`reference-reuse.json`、依赖图和源码清单证明15个输入文件逐字节相同、23个冷字段原NPY身份、1008个原捕获中的固定首48×3，以及NM/JN的61个NumPy文件和59个runner前向闭包文件逐字节相同。不会重跑NumPy参考，不把原JN参考改标为NM。

设备运行仅使用物理GPU1 UUID `GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452`；新根为 `/home/lhwang/work/noahmp-v1/hrldas-candidate-cold48-ny`，源码和三个缓存目录都位于全新 `/tmp/noahmp-hrldas-candidate-cold48-ny`。启动需主存可用大于32GiB、GPU空闲大于8GiB；原4GiB实测主存峰值门保持。每个前向步仍调用原 native 守恒审计，完整捕获16个前后状态、全部返回字段和原水热碳氮/杂质账；原 NumPy 前向函数被禁止，JAX shadow关闭。CuPy barrier、实际worker退出和回执哈希均需成功，不能以日志进度代替真实parent0。

根代理复核并上传三份精确归档后，未来唯一启动命令如下（此文档不会自动执行命令）：

```sh
/home/lhwang/venvs/noahmp-phase3b/bin/python -B /home/lhwang/work/noahmp-v1/hrldas-candidate-cold48-ny-preparation/launch_cold48_ny.py --source-archive /home/lhwang/work/noahmp-v1/climatology-final-candidate-nm-source.tar.gz --input-archive /home/lhwang/work/noahmp-v1/hrldas-current-kg-inputs.tar.gz --reference-archive /home/lhwang/work/noahmp-v1/hrldas-current-week-le-evidence.tar.gz
```

完成后可手动调用新运行根中的 `archive_cold48_ny.py`，只封存 `cold48-evidence.tar.gz` 和 `cold48-package.json`。归档中 `current/` 包含原输入、48个原捕获、完整冷/末checkpoint、三站trace、日志及实际回执；`control/` 保留plan、launch和全部控制字节。完整源在封存时再次验证不变。失败不会自动重试或续年。

独立EHPC审计由 `../hrldas-cold48-audit-ny-preparation/` 单独拥有和封包。它将固定读取LE完整336记录的前48段及原call47.after，绝不伪造48末checkpoint，保留原13物理轨迹、6个日门、各C/N池、近零绝对容差和非平坦关键通量r>0.85；同时重新核验两端原守恒账与全部状态链。必须实际144对审计通过后才可讨论后续；全年仍另需完整MX31及正式晋升。冷48、独立分析退出0或旧HRLDAS首周都不代表官方全年、SOC准平衡或v1验收通过。

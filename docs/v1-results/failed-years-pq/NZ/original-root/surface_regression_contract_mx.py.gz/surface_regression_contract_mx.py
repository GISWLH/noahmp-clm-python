"""Static ML lineage and actual EHPC preflight evidence; no device imports."""
from pathlib import Path
import hashlib
import json
import re

PARENT = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
DERIVED = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
ARCHIVE = '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
COLLECTION = '522be9c62aa9aa6cad64d4e614ac20f4d221f4cb90bea1deb9ecb63e9ad7b658'
WORKER = '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
GUARD = '4744d25ffde851c942816edf4e7078ce2179b48faa2fdb7c08d0b05100f4bd58'
GPU_UUID = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
FILES = {
    'test_gpu_canopy_surface.py': 5,
    'test_gpu_canopy_phase_surface.py': 4,
    'test_gpu_canopy_phase_weak_descent.py': 3,
    'test_gpu_snow_processes.py': 8,
    'test_gpu_surface_secant_rounding.py': 1,
    'test_gpu_surface_snow_branch.py': 2,
    'test_gpu_phase_coordinate_recovery.py': 4,
    'test_gpu_vanishing_snow_event.py': 4,
}
CHANGES = {
    'src/noahmp_clm/gpu/snow_evolution.py': 'f4724a3462d66caa8c4b93e20ca0022dabf6ed62cee9209de71c7ef4faeee297',
    'src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu': 'd8a7dcee2eb6a2243fd76fff26e65fe37b0509d0d011424918b1292a07705840',
    'src/noahmp_clm/gpu/canopy_surface.py': '4836ed4306c4d13c91e3c4860b738fc671a41293a70a1e6815459211cdf0f92a',
    'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu': 'a21741d4a4225cd7f4b132cb327da3f575e413d76e983970db000aa5aff06139',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def selected_nodes(path):
    assert sha(path) == COLLECTION
    record = json.loads(Path(path).read_text())
    assert record['passed'] and record['source_unchanged']
    assert record['source_manifest_sha256'] == PARENT
    assert record['total_count'] == 1563 and record['gpu_count'] == 407
    assert len(record['nodes']) == len(set(record['nodes'])) == 1563
    result = {}
    for name, count in FILES.items():
        result[name] = [Path(n.split('::')[0]).name + '::' + n.split('::', 1)[1]
                        for n in record['nodes'] if Path(n.split('::')[0]).name == name]
        assert len(result[name]) == count
    assert sum(map(len, result.values())) == 31
    return result


def verify_preflight(folder):
    """Reject absent/stale evidence before any experiment directory is made.

    Root exports the two closed audit.json files and actual qstat -xf snapshots
    from EHPC. The ACK binds their bytes; an ACK Boolean alone is insufficient.
    """
    folder = Path(folder)
    ack = json.loads((folder / 'ack.json').read_text())
    assert ack['passed'] is True and ack['derived_manifest_sha256'] == DERIVED
    assert set(ack['proofs']) == {'point_pair', 'k78'}
    result = {}
    for label in ['point_pair', 'k78']:
        proof = ack['proofs'][label]
        assert proof['actual_pbs_exit'] == 0
        job = proof['pbs_job']
        assert re.fullmatch(r'[0-9]+\.manager', job)
        audit_path = folder / (label + '-audit.json')
        qstat_path = folder / (label + '-actual-qstat.txt')
        assert sha(audit_path) == proof['audit_sha256']
        assert sha(qstat_path) == proof['qstat_sha256']
        qstat = qstat_path.read_text()
        assert re.search(r'^Job Id: ' + re.escape(job) + r'\s*$', qstat, re.M)
        assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
        assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
        audit = json.loads(audit_path.read_text())
        assert audit['pbs_job'] == job and audit['passed'] is True and not audit['errors']
        if label == 'point_pair':
            assert audit['stage'] == 'pair' and audit['derived_manifest_sha256'] == DERIVED
            assert audit['parent_manifest_sha256'] == PARENT
            assert audit['independent_reference_source_unchanged']
            assert set(audit['original_module_science']) == {'cuda32', 'jax32'}
            for backend in ['cuda32', 'jax32']:
                rows = audit['original_module_science'][backend]
                assert len(rows) == 12 and all(row['passed'] for row in rows)
                assert audit['original_hard_budgets'][backend]['passed']
            rows = audit['raw_same_precision_fields']
        else:
            assert audit['executed_gpu_derived_manifest_sha256'] == DERIVED
            assert audit['independent_reference_parent_manifest_sha256'] == PARENT
            assert audit['source_unchanged'] and not audit['failed']
            assert audit['raw_model_and_next_fields'] == 329 and audit['additional_before_arrays'] == 16
            assert set(audit['changed_gpu_source_files']) == set(CHANGES)
            assert set(audit['budgets']) == {'cuda32', 'jax32'}
            assert all(v['passed'] for v in audit['budgets'].values())
            rows = audit['fields']
        assert len(rows) == 345 and len({row['field'] for row in rows}) == 345
        assert all(row['passed'] for row in rows)
        result[label] = proof
    return result

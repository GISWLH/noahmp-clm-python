"""One-shot NR staging under /tmp; only PBS compute002 performs CPU tests."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/tmp/noahmp-climatology-final-cpu-nr')
out = root / 'manager'
assert not out.exists()
out.mkdir()
names = ['run_final_cpu_nr.py', 'climatology-final-cpu-nr-plan.json', 'climatology-final-candidate-nm-source.tar.gz']
plan = json.loads((root / names[1]).read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root / names[2]) == plan['archive_sha256'] == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
assert b'\r\n' not in (root / names[0]).read_bytes()
subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'compute002',
                'test ! -e /tmp/noahmp-climatology-final-cpu-nr && mkdir -p /tmp/noahmp-climatology-final-cpu-nr/result'], check=True)
subprocess.run(['scp', *[str(root / n) for n in names], 'compute002:' + str(root) + '/'], check=True)
script = '''#!/bin/bash
#PBS -N clm-final-cpu-nr
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=4gb:host=compute002_00260924
#PBS -l walltime=01:00:00
#PBS -j oe
#PBS -o /tmp/noahmp-climatology-final-cpu-nr/pbs-output.log
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /tmp/noahmp-climatology-final-cpu-nr/result
/home/zhangyq/venvs/noahmp-closeout/bin/python -u /tmp/noahmp-climatology-final-cpu-nr/run_final_cpu_nr.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(out / 'job.pbs').write_text(script)
job = subprocess.run(['qsub', str(out / 'job.pbs')], cwd=out, capture_output=True, text=True)
assert job.returncode == 0, job.stderr
result = dict(pbs_job=job.stdout.strip(), source_manifest_sha256=plan['source_manifest_sha256'],
              controls_sha256={n: sha(root / n) for n in names}, job_sha256=sha(out / 'job.pbs'), scope=plan['scope'])
(out / 'dispatch.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)

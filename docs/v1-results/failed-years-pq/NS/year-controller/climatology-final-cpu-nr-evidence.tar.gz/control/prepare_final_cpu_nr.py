"""Static NM binding and exact original1156 plus proven SOC-boundary12 plan."""
from pathlib import Path
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
archive = root / 'climatology-final-candidate-nm-source.tar.gz'
assert sha(archive.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(archive) as tf:
    raw = tf.extractfile('SOURCE_SHA256.json').read()
    manifest = json.loads(raw)
    assert sha(raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert len(manifest) == 584 and all(sha(tf.extractfile(n).read()) == h for n, h in manifest.items())
ni_package = json.loads((root / 'surface-root-cpu-ni-package.json').read_text())
ni_archive = root / ni_package['archive']
assert sha(ni_archive.read_bytes()) == ni_package['sha256'] == 'cc4ebaf52796ca40de9ee11df4ddb7269702ba458a10672d3668dcc924b78adc'
with tarfile.open(ni_archive) as tf:
    ni_manifest = json.load(tf.extractfile('SOURCE_SHA256.json'))
    original = json.load(tf.extractfile('nodes.json'))
    assert len(original) == len(set(original)) == 1156
    ni_receipt = json.load(tf.extractfile('receipt.json'))
    assert ni_receipt['passed'] and ni_receipt['pytest_returncode'] == 0
    assert ni_receipt['counts'] == dict(tests=1156, failures=0, errors=0, skipped=0)
assert set(ni_manifest) == set(manifest)
changes = {n: dict(before=ni_manifest[n], after=h) for n, h in manifest.items() if h != ni_manifest[n]}
nk_plan = json.loads((root / 'soc-strict-boundary-nk-plan.json').read_text())
assert set(changes) == {'benchmarks/assess_clm_spinup.py', 'tests/test_clm_spinup.py'}
assert all(q['before'] == nk_plan['before_sha256'][n] and q['after'] == nk_plan['after_sha256'][n] for n, q in changes.items())
nk_package = json.loads((root / 'soc-strict-boundary-nk-package.json').read_text())
nk_archive = root / nk_package['archive']
assert sha(nk_archive.read_bytes()) == nk_package['sha256']
with tarfile.open(nk_archive) as tf:
    proof = json.load(tf.extractfile('receipt.json'))
    assert proof['passed'] and proof['failure'] is None
    positive = next(r for r in proof['records'] if r['variant'] == 'positive')
    assert positive['actual_pytest_parent_returncode'] == 0
    added = sorted(set(positive['nodes']) - set(original))
prefix = 'tests/test_clm_spinup.py::test_carbon_convergence_is_strictly_below_five_percent['
assert len(added) == 12 and all(n.startswith(prefix) for n in added)
plan = dict(archive=archive.name, archive_sha256=sha(archive.read_bytes()),
            source_manifest_sha256=sha(raw), source_files=584, cpu_expected=1168,
            original_cpu_nodes=original, expected_added_boundary_nodes=added,
            exact_changes_from_NI=changes, baseline_NI_archive_sha256=ni_package['sha256'],
            boundary_NK_archive_sha256=nk_package['sha256'],
            scope='Exact frozen NM final candidate. EHPC full CPU original1156 plus12 strict SOC boundary cases; '
                  'actual collection, exact JUnit node coverage, source before/after and actual PBS terminal required. '
                  'No new reference generation, GPU workload, annual or scientific acceptance credit.')
target = root / 'climatology-final-cpu-nr-plan.json'
assert not target.exists()
target.write_text(json.dumps(plan, indent=2) + '\n', newline='\n')
print(json.dumps({k:v for k,v in plan.items() if k not in ['original_cpu_nodes','expected_added_boundary_nodes']}))

"""Future private candidate cold48 only. No resume/year/cycle CLI exists."""
import argparse
import datetime
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

from climatology_contract_np import (
    GPU,
    INPUT,
    PARENT,
    REFERENCE,
    TARGET,
    load,
    prerequisites,
    sha,
    source_archive,
    verify_inputs,
    verify_source,
)

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE / 'climatology-cold48-np'
TMP = Path('/tmp/noahmp-climatology-cold48-np')
HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-archive', type=Path, required=True)
    args = parser.parse_args()
    assert os.name == 'posix' and Path('/proc/meminfo').exists()
    assert not ROOT.exists() and not TMP.exists(), 'Fresh immutable candidate attempt only'
    proof = prerequisites(BASE)
    source_archive(args.source_archive)
    assert sha(BASE / 'multisite-climatology-jr-inputs.tar.gz') == INPUT
    assert sha(BASE / 'climatology-numpy-jr-evidence.tar.gz') == REFERENCE
    reuse = load(HERE / 'reference-reuse.json')
    assert reuse['reference_reusable'] and reuse['reference_archive_sha256'] == REFERENCE
    assert reuse['input_archive_sha256'] == INPUT and reuse['raw_packet_count'] == 576
    gpu = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=uuid,memory.free',
                                   '--format=csv,noheader,nounits'], text=True).strip().split(',')
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:')))
    assert gpu[0].strip() == GPU and int(gpu[1]) > 8192 and available > 32 * 1024 * 1024
    ROOT.mkdir()
    (TMP / 'source').mkdir(parents=True)
    (ROOT / 'cold48/inputs').mkdir(parents=True)
    with tarfile.open(args.source_archive) as tf:
        tf.extractall(TMP / 'source', filter='data')
    (ROOT / 'candidate-source.tar.gz').write_bytes(args.source_archive.read_bytes())
    with tarfile.open(BASE / 'multisite-climatology-jr-inputs.tar.gz') as tf:
        tf.extractall(ROOT / 'cold48/inputs', filter='data')
    verify_source(TMP / 'source')
    verify_inputs(ROOT / 'cold48/inputs', reuse)
    names = ['run_cold48_np.py', 'audit_cold48_np.py', 'control_cold48_np.py', 'launch_cold48_np.py',
             'archive_cold48_np.py', 'climatology_contract_np.py', 'surface_regression_contract_mx.py',
             'reference-reuse.json', 'source-dependencies.json', 'reference-dependency-graph.json',
             'EXPECTED_SOURCE_SHA256.json', 'surface-root-cpu-ni-evidence.tar.gz',
             'soc-strict-boundary-nk-evidence.tar.gz']
    for name in names:
        (ROOT / name).write_bytes((HERE / name).read_bytes())
    with tarfile.open(BASE / 'climatology-numpy-jr-evidence.tar.gz') as tf:
        (ROOT / 'cold48/ballberry-climatology-numpy-jr-receipt.json').write_bytes(tf.extractfile('numpy/receipt.json').read())
    plan = dict(source_manifest_sha256=TARGET, reference_source_manifest_sha256=PARENT,
                source_archive_sha256=sha(args.source_archive), reference_archive_sha256=REFERENCE,
                input_archive_sha256=INPUT, controls_sha256={n: sha(ROOT / n) for n in names},
                candidate_only=True, continuation_allowed=False, maximum_forward_steps=48,
                prerequisites=proof,
                scope='Private NM584 candidate cold48, original12cases/23fields/globalledgers unchanged. '
                      'NFpositive0+MPMVactualF0+NI1578F0+NK1583F0+MXfirst5actual0/no recorded failure; '
                      'does not wait for remainingMX26, does not promote production or permit continuation.')
    (ROOT / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    env = os.environ.copy()
    for key in ['LD_LIBRARY_PATH', 'PYTEST_PLUGINS']:
        env.pop(key, None)
    source = TMP / 'source'
    env.update(NP_ROOT=str(ROOT), NP_SOURCE=str(source), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU,
               PYTHONPATH=':'.join(map(str, [ROOT, source, source / 'src', source / 'benchmarks'])),
               CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
               XLA_PYTHON_CLIENT_PREALLOCATE='false', CUPY_CACHE_DIR=str(TMP / 'cupy-cache'),
               CUDA_CACHE_PATH=str(TMP / 'cuda-cache'), JAX_COMPILATION_CACHE_DIR=str(TMP / 'jax-cache'))
    with (ROOT / 'cold48/controller.log').open('x') as log:
        process = subprocess.Popen([sys.executable, '-u', str(ROOT / 'control_cold48_np.py')], cwd=source,
                                   env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
    record = dict(pid=process.pid, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  source_manifest_sha256=TARGET, physical_gpu_index=1, physical_gpu_uuid=GPU,
                  private_cache=str(TMP), candidate_only=True, continuation_allowed=False)
    (ROOT / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

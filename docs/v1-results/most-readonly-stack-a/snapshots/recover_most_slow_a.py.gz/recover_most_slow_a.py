from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
base=Path('/home/lhwang/work/noahmp-v1');model=base/'p6-most-oscillation-a';root=base/'profile_output/most-slow-a';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
dest=root/'summary.json';assert not dest.exists();m=json.loads((model/'SOURCE_SHA256.json').read_text());assert all(sha(model/n)==v for n,v in m.items())
rows=[]
for path in sorted(root.glob('*-*-*.json')):
    values=json.loads(path.read_text());assert isinstance(values,list)
    for thread in values:
        assert all(not f.get('locals') for f in thread['frames'])
        rows.append(dict(file=path.name,pid=thread['pid'],thread_name=thread['thread_name'],active=thread['active'],
            frames=[dict(name=f['name'],file=f['filename'],line=f['line']) for f in thread['frames']],captured_file_mtime_utc=datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat()))
assert len(rows)==3
spy=base/'profile-tools-pyspy-a/bin/py-spy';version=subprocess.run([str(spy),'--version'],capture_output=True,text=True,timeout=5);assert version.returncode==0
for name in ['probe_most_slow_a.py','recover_most_slow_a.py']:(root/name).write_bytes((base/name).read_bytes())
progress=json.loads((model/'gpu-target-progress.json').read_text());stable=[r for r in progress['results'] if r['file']=='tests/test_gpu_most_stagnation.py']
assert len(stable)==1 and stable[0]['returncode']==0 and stable[0]['counts']==dict(tests=3,failures=0,errors=0,skipped=0)
value=dict(scope='Recovery of three already-captured, no-locals/environment read-only stack samples; no additional target sampling, production instrumentation or model edits. Instantaneous stacks/GPU utilization are not a statistical profile or speedup measurement.',
    instrumentation_failure='The original probe completed its stack/GPU captures and source checks, then its metadata SHA helper called read_bytes on the __file__ string and raised AttributeError; no original summary/per-call duration survived. This recovery reads those original files only.',
    metadata_recovered_utc=datetime.now(timezone.utc).isoformat(),per_call_durations_available=False,profiler_version=version.stdout.strip(),profiler_sha256=sha(spy),
    model_source_files=len(m),source_unchanged_at_recovery=True,source_manifest_sha256=sha(model/'SOURCE_SHA256.json'),snapshots=rows,
    stable_target_observed_after_capture=stable[0],artifacts={p.name:sha(p) for p in root.iterdir() if p.is_file()})
dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k not in ('artifacts','snapshots')}));print(json.dumps([dict(file=r['file'],pid=r['pid'],top_frames=[f['name'] for f in r['frames'][:2]]) for r in rows]))

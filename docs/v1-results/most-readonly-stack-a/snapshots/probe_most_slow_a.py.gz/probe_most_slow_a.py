from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
base=Path('/home/lhwang/work/noahmp-v1');model=base/'p6-most-oscillation-a';year=base/'fluxnet-first-climate-cycle-20261017-j';root=base/'profile_output/most-slow-a';root.mkdir(parents=True,exist_ok=False)
spy=base/'profile-tools-pyspy-a/bin/py-spy';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((model/'SOURCE_SHA256.json').read_text());assert all(sha(model/n)==v for n,v in m.items())
results=[];begun=time.monotonic()
for label in ['target','annual','target']:
    if label=='target':
        record=json.loads((model/'gpu-target-progress.json').read_text());active=record.get('active')
        if record['status']!='running' or not active:results.append(dict(label=label,status='target already terminal'));continue
        pid=active['pid'];expected=active['file']
    else:pid=json.loads((year/'cuda-annual-launch.json').read_text())['pid'];expected=str(model/'benchmarks/run_fluxnet_native.py')
    proc=Path('/proc')/str(pid)
    if not proc.exists():results.append(dict(label=label,pid=pid,status='process absent'));continue
    assert proc.stat().st_uid==os.getuid() and proc.joinpath('cwd').resolve()==model
    args=proc.joinpath('cmdline').read_bytes().rstrip(b'\0').split(b'\0');assert expected.encode() in args
    commands=[[str(spy),'dump','--pid',str(pid),'--json','--full-filenames','--nonblocking']]
    for command in commands:
        start=time.monotonic()
        try:r=subprocess.run(command,capture_output=True,text=True,timeout=8);code=r.returncode;stdout=r.stdout;stderr=r.stderr
        except subprocess.TimeoutExpired:code=124;stdout='';stderr='Read-only py-spy snapshot timeout; target was not terminated.'
        name=f'{len(results):02d}-{label}-{pid}';status='captured' if code==0 else 'unavailable'
        if code==0:
            parsed=json.loads(stdout)
            def no_locals(v):
                if isinstance(v,dict):return all((k!='locals' or not x) and no_locals(x) for k,x in v.items())
                if isinstance(v,list):return all(no_locals(x) for x in v)
                return True
            assert no_locals(parsed);(root/(name+'.json')).write_text(stdout)
        (root/(name+'.stderr.txt')).write_text(stderr)
        results.append(dict(label=label,pid=pid,status=status,returncode=code,command=command,seconds=time.monotonic()-start))
        if code!=0 and command[0]!='sudo':commands.append(['sudo','-n',*command])
    time.sleep(.1)
gpu=subprocess.run(['nvidia-smi','--query-gpu=index,utilization.gpu,memory.used,memory.free','--format=csv,noheader'],capture_output=True,text=True,timeout=5)
(root/'gpu-snapshot.txt').write_text(gpu.stdout+gpu.stderr)
assert all(sha(model/n)==v for n,v in m.items())
value=dict(scope='Three bounded read-only Python stack snapshots, no locals/environment or inline instrumentation. Existing own-PID uid/cwd/argv verified. Shared GPU utilization is instantaneous, not attributed per process. No statistical profile or speedup claim.',
    captured_utc=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-begun,source_files=len(m),source_unchanged=True,source_manifest_sha256=sha(model/'SOURCE_SHA256.json'),probe_sha256=sha(__file__),profiler_sha256=sha(spy),
    results=results,artifacts={p.name:sha(p) for p in root.iterdir() if p.is_file()})
(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k!='artifacts'}))

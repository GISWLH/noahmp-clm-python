from pathlib import Path
import hashlib,json,time
import numpy as np
import cupy as cp
from noahmp_clm.physics.photosynthesis import LeafParameters
import noahmp_clm.gpu.cuda.canopy_phase_surface as surface
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
fixture=base/'failure-j-phase-a/failed-surface-inputs.npz';assert sha(fixture)=='3a3a3fe5aae3bf41fa19fc0c3a34720eb6ab5591980c5aa4ed63466abf00c4ad'
with np.load(fixture,allow_pickle=False) as z:inputs=dict(z)
arrays=tuple(inputs[f'a{k}'][3:4].copy() for k in range(9));extra={k:inputs[k][3:4].copy() for k in ['exchange_extension','vic'] if k in inputs};assert 'exchange_extension' in extra
original=base/'fluxnet-first-climate-cycle-20261017-j';batch=json.loads((original/'batch.json').read_text());config=Path(batch['cases'][0]['configuration']);config=config if config.is_absolute() else original/config;leaf=LeafParameters(**json.loads(config.read_text())['leaf_parameters'])
def host(v):return {k:host(x) for k,x in v.items()} if isinstance(v,dict) else cp.asnumpy(v)
begun=time.monotonic();baseline=host(surface.run_canopy_phase_surface_cuda(*arrays,parameters=leaf,raise_on_failure=False,**extra))
folder=source/'src/noahmp_clm/gpu/cuda';names=['leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu','enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu','snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu'];texts={n:(folder/n).read_text() for n in names};thermal=texts['column_heat_kernel.cu']
header='extern "C" { __device__ float diag_cells[45],diag_props[4],diag_bc[4],diag_out[77],diag_trace[81*32]; __device__ int diag_options[2]; }\n'
needle='    int ns=options[0],phase=options[1];float por=props[0],quartz=props[2];'
assert thermal.count(needle)==1;thermal=thermal.replace(needle,'    for(int i=0;i<45;++i)diag_cells[i]=cells[i];for(int i=0;i<4;++i){diag_props[i]=props[i];diag_bc[i]=bc[i];}for(int i=0;i<2;++i)diag_options[i]=options[i];\n'+needle)
helper='''__device__ void save_heat_diagnostic(int count,bool done,bool valid,int accepted,const float* h,const float* r,const float* d,const float* tolerance,const float* rounding,const float* conduct,const float* bc){
    int k=min(count,80)*32;diag_trace[k]=(float)count;diag_trace[k+1]=done?1.f:0.f;diag_trace[k+2]=valid?1.f:0.f;diag_trace[k+3]=heat_norm(r,h,tolerance,rounding,conduct,bc);
    for(int i=0;i<9;++i){diag_trace[k+4+i]=h[i];diag_trace[k+13+i]=r[i];diag_trace[k+22+i]=d[i];}diag_trace[k+31]=(float)accepted;
}
'''
thermal=thermal.replace('__device__ void joint_heat_device(',helper+'\n__device__ void joint_heat_device(',1)
needle='    bool done=heat_norm(residual,h,tolerance,rounding,conduct,bc)<=1.f;int count=0;'
assert thermal.count(needle)==1;thermal=thermal.replace(needle,needle+'\n    save_heat_diagnostic(count,done,valid,-1,h,residual,d,tolerance,rounding,conduct,bc);')
needle='done=heat_norm(residual,h,tolerance,rounding,conduct,bc)<=1.f;valid=good&&(accepted||done);count++;';assert thermal.count(needle)==1;thermal=thermal.replace(needle,needle+'\n        save_heat_diagnostic(count,done,valid,accepted?1:0,h,residual,d,tolerance,rounding,conduct,bc);')
needle='out[75]=done&&valid?1.f:0.f;out[76]=max_tolerance;';assert thermal.count(needle)==1;thermal=thermal.replace(needle,needle+'\n    for(int i=0;i<77;++i)diag_out[i]=out[i];')
(root/'instrumented-column-heat.cu').write_text(header+thermal);texts['column_heat_kernel.cu']=thermal;combined=header+'\n'.join(texts[n] for n in names);(root/'instrumented-surface.cu').write_text(combined)
kernel_name='run_canopy_phase_surface_vic' if 'vic' in extra else 'run_canopy_phase_surface_extended'
module=cp.RawModule(code=combined,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=(kernel_name,'run_soil_thermodynamics'))
kernel=module.get_function(kernel_name);get=lambda name,shape,dtype=cp.float32:cp.ndarray(shape,dtype,memptr=module.get_global(name));get('diag_trace',(81,32)).fill(cp.nan)
real=surface._kernel
try:
    surface._kernel=lambda extended=False,vic=False:kernel
    observed=host(surface.run_canopy_phase_surface_cuda(*arrays,parameters=leaf,raise_on_failure=False,**extra));cp.cuda.runtime.deviceSynchronize()
finally:surface._kernel=real
def exact(a,b):
    assert a.keys()==b.keys()
    return all(exact(a[k],b[k]) if isinstance(a[k],dict) else a[k].dtype==b[k].dtype and a[k].shape==b[k].shape and a[k].tobytes()==b[k].tobytes() for k in a)
assert exact(baseline,observed),'Instrumentation changed original returned fields'
cells=cp.asnumpy(get('diag_cells',(1,9,5)));props=cp.asnumpy(get('diag_props',(1,4)));options=cp.asnumpy(get('diag_options',(1,2),cp.int32));boundary=cp.asnumpy(get('diag_bc',(1,4)));out=cp.asnumpy(get('diag_out',(77,)));trace=cp.asnumpy(get('diag_trace',(81,32)));trace=trace[np.isfinite(trace[:,0])]
np.savez_compressed(root/'joint-inputs.npz',cells=cells,props=props,options=options,boundary=boundary)
np.savez_compressed(root/'joint-diagnostics.npz',out=out,trace=trace)
ns=int(options[0,0]);u=np.column_stack((cells[0,ns:ns+4,0],cells[0,ns:ns+4,1],cells[0,ns:ns+4,2],np.broadcast_to(props[0,[0,1,3]],(4,3)))).astype(np.float32);result=cp.empty((4,9),cp.float32)
module.get_function('run_soil_thermodynamics')((1,),(32,),(cp.asarray(u),cp.full(4,int(options[0,1]),cp.int32),result,np.int32(1),np.int32(4)));inverse=cp.asnumpy(result);np.savez_compressed(root/'initial-soil-inversion.npz',inputs=u,outputs=inverse)
assert all(sha(source/n)==v for n,v in manifest.items())
value=dict(scope='Selected physical diagnostic stores added only to a separate derived CUDA source/module; all original surface fields bitwise identical to uninstrumented original. No production/frozen source modification or invalid state advance.',source_unchanged=True,all_returned_fields_bitwise_equal=True,input_sha256=sha(fixture),joint_input_sha256=sha(root/'joint-inputs.npz'),joint_count=float(out[74]),joint_converged=bool(out[75]),joint_budget=float(out[72]),trace=trace.tolist(),initial_soil_inverse=inverse.tolist(),seconds=time.monotonic()-begun,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'))
(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

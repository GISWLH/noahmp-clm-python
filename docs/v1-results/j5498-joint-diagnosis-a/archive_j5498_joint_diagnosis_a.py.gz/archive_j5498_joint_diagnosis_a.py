from pathlib import Path
import datetime,hashlib,io,json,os,tarfile
base=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=['probe-j5498-surface-backends-a','capture-j5498-joint-a','capture-j5498-joint-b','audit-j5498-packing-a','probe-j5498-dominant-a','probe-j5498-chord-b']
source=base/'p6-most-oscillation-a';m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
archive=base/'j5498-joint-diagnosis-a-evidence.tar.gz';assert not archive.exists();entries=[]
for root in roots:
    folder=base/root;assert folder.is_dir()
    for p in sorted(folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            assert p.suffix in ['.py','.json','.npz','.log','.cu','.txt'] and p.stat().st_size<20000000
            entries.append((p.relative_to(base).as_posix(),p))
profile=base/'profile_output/j5498-joint-a';profile.mkdir(parents=True,exist_ok=True)
for name in ['joint-inputs.npz','joint-diagnostics.npz','summary.json']:
    p=base/'capture-j5498-joint-b'/name;target=profile/name
    if target.exists():assert target.read_bytes()==p.read_bytes()
    else:target.write_bytes(p.read_bytes())
    entries.append((target.relative_to(base).as_posix(),target))
note=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Selected physical arrays/derived instrumentation and failed A/successful B numerical probes. Original full-surface bitwise observer check retained. Auxiliary initial-soil-inversion B used wrong F-order raw ABI packing; corrected contiguous public-API audit is authoritative. Terminal/body summaries are not invented child return codes. No invalid original candidate advanced; no annual/science acceptance.',source_files=len(m),source_unchanged=True,files={n:sha(p) for n,p in entries})
with tarfile.open(archive,'w:gz') as t:
    for n,p in entries:t.add(p,arcname=n,recursive=False)
    t.add(source/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
    raw=(json.dumps(note,indent=2)+'\n').encode();x=tarfile.TarInfo('diagnosis-binding.json');x.size=len(raw);t.addfile(x,io.BytesIO(raw))
print(json.dumps(dict(sha256=sha(archive),files=len(entries)+3)))

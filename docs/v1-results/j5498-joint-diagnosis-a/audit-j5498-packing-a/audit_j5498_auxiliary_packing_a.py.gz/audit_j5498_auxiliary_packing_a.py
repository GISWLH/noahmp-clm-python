from pathlib import Path
import hashlib,json
import numpy as np
import cupy as cp
from noahmp_clm.gpu.cuda.enthalpy import run_soil_thermodynamics_cuda
base=Path('/home/lhwang/work/noahmp-v1');root=Path.cwd();source=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
with np.load(base/'capture-j5498-joint-b/initial-soil-inversion.npz',allow_pickle=False) as z:u=z['inputs'];old=z['outputs']
with np.load(base/'capture-j5498-joint-b/joint-inputs.npz',allow_pickle=False) as z:option=int(z['options'][0,1])
original_layout=dict(c_contiguous=u.flags.c_contiguous,f_contiguous=u.flags.f_contiguous);assert u.flags.f_contiguous and not u.flags.c_contiguous
correct=np.ascontiguousarray(u);result=run_soil_thermodynamics_cuda(correct,np.full(4,option,np.int32),inverse=True);out={k:cp.asnumpy(v).tolist() for k,v in result.items()};assert all(out['converged']) and all(sha(source/n)==v for n,v in m.items())
value=dict(scope='Auxiliary diagnostic packing correction only. B raw auxiliary launch incorrectly passed a Fortran-order matrix to row-major CUDA ABI; its auxiliary rows are invalid and are not model evidence. Original surface/81-row joint trace bitwise observation proof is unaffected. Public contiguous API returns all four valid.',original_layout=original_layout,source_unchanged=True,original_auxiliary_validity_column=old[:,-1].tolist(),corrected=out)
(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import hashlib,json,time
import numpy as np
import cupy as cp
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
path=base/'capture-j5498-joint-b/joint-inputs.npz';assert sha(path)=='992c7371ed87da40ae00bd8cbfa99fbba97c8afa83578420e433fbcc72a6d3b0'
with np.load(path,allow_pickle=False) as z:inputs=[z[k] for k in ['cells','props','options','boundary']]
device=[cp.ascontiguousarray(cp.asarray(v)) for v in inputs];folder=source/'src/noahmp_clm/gpu/cuda';enthalpy=(folder/'enthalpy_kernel.cu').read_text();old=(folder/'column_heat_kernel.cu').read_text();new=old
needle='        bool accepted=false;';assert new.count(needle)==1
new=new.replace(needle,'        int dominant=0;float peak_dominant=-1.f;for(int i=0;i<ns+4;++i){float ratio=fabsf(residual[i])/weights[i];if(ratio>peak_dominant){peak_dominant=ratio;dominant=i;}}\n'+needle)
needle='accepted=good&&(trial_merit<merit||(exact_event&&trial_merit==merit)||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);';assert new.count(needle)==2
new=new.replace(needle,'bool dominant_progress=candidate[dominant]!=h[dominant]||fabsf(trial_r[dominant])<fabsf(residual[dominant])||exact_event;\n            accepted=good&&(((trial_merit<merit||(exact_event&&trial_merit==merit))&&dominant_progress)||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);',1)
(root/'candidate-column-heat.cu').write_text(new);results={};begun=time.monotonic()
for label,text in [('original',old),('candidate',new)]:
    module=cp.RawModule(code=enthalpy+'\n'+text,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_joint_heat',));kernel=module.get_function('run_joint_heat');out=cp.empty((1,77),cp.float32);kernel((1,),(64,),(*device,out,np.int32(1)));data=cp.asnumpy(out);np.savez_compressed(root/(label+'-output.npz'),out=data)
    c,p,o,b=inputs;n=int(o[0,0])+4;res=data[0,45:54];tol=data[0,62:71];independent=float((data[0,:n].astype(float)-c[0,:n,1].astype(float)).sum()-float(b[0,0])*(float(data[0,73])+c[0,:n,4].astype(float).sum()))
    results[label]=dict(converged=bool(data[0,75]),iterations=float(data[0,74]),independent_heat_residual_jm2=independent,max_layer_ratio=float(np.max(abs(res)/tol)),layer_residual_jm2=res.tolist(),layer_tolerance_jm2=tol.tolist(),enthalpy_jm2=data[0,:n].tolist(),temperature_k=data[0,9:9+n].tolist())
assert all(sha(source/n)==v for n,v in manifest.items());value=dict(scope='Candidate numerical line-search safeguard only in an isolated CUDA module. Reject a coupled trial that does not move or improve the dominant equation, preserving exact snow phase events; unchanged equations/80 iterations/merit and final original bounds. Not adopted or full-step/scientific acceptance.',source_unchanged=True,input_sha256=sha(path),results=results,seconds=time.monotonic()-begun)
(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

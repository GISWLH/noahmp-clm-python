from pathlib import Path
import hashlib,json,time
import numpy as np
import cupy as cp
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
path=base/'capture-j5498-joint-b/joint-inputs.npz';assert sha(path)=='992c7371ed87da40ae00bd8cbfa99fbba97c8afa83578420e433fbcc72a6d3b0'
with np.load(path,allow_pickle=False) as z:inputs=[z[k] for k in ['cells','props','options','boundary']]
device=[cp.ascontiguousarray(cp.asarray(v)) for v in inputs];folder=source/'src/noahmp_clm/gpu/cuda';enthalpy=(folder/'enthalpy_kernel.cu').read_text();old=(folder/'column_heat_kernel.cu').read_text();new=old
needle='    bool done=heat_norm(residual,h,tolerance,rounding,conduct,bc)<=1.f;int count=0;'
assert new.count(needle)==1
new=new.replace(needle,needle+'\n    float previous_h[9],previous_r[9];for(int i=0;i<9;++i){previous_h[i]=h[i];previous_r[i]=residual[i];}')
needle='        for(int a=0;a<12;++a) {'
assert new.count(needle)==1
new=new.replace(needle,'''        int dominant=0;float peak_dominant=-1.f;for(int i=0;i<ns+4;++i){float ratio=fabsf(residual[i])/weights[i];if(ratio>peak_dominant){peak_dominant=ratio;dominant=i;}}
        bool stalled=count>0&&h[dominant]==previous_h[dominant]&&fabsf(residual[dominant])>=fabsf(previous_r[dominant]);
        for(int i=0;i<9;++i){previous_h[i]=h[i];previous_r[i]=residual[i];}
'''+needle)
needle='        heat_linear(d,residual,conduct,bc,delta);float step=1.f;'
assert new.count(needle)==1
new=new.replace(needle,'''        heat_linear(d,residual,conduct,bc,delta);
        if(stalled) for(int chord=0;chord<4;++chord){
            float trial[9],r2[9],t2[9],d2[9],l2[9],f2[8],top2,round2[9];
            for(int i=0;i<9;++i)trial[i]=h[i]+delta[i];
            bool good=heat_evaluate(trial,old,mass,z,solar,conduct,ns,props,bc,phase,r2,t2,d2,l2,f2,top2,round2);
            if(!good)break;
            for(int i=0;i<ns+4;++i){float change=trial[i]-h[i];if(change!=0.f){float slope=(t2[i]-t[i])/change;if(isfinite(slope)&&slope>=0.f)d[i]=slope;}}
            heat_linear(d,residual,conduct,bc,delta);
        }
        float step=1.f;''')
(root/'candidate-column-heat.cu').write_text(new);results={};begun=time.monotonic()
for label,text in [('original',old),('candidate',new)]:
    module=cp.RawModule(code=enthalpy+'\n'+text,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_joint_heat',));kernel=module.get_function('run_joint_heat');out=cp.empty((1,77),cp.float32);kernel((1,),(64,),(*device,out,np.int32(1)));data=cp.asnumpy(out);np.savez_compressed(root/(label+'-output.npz'),out=data)
    c,p,o,b=inputs;n=int(o[0,0])+4;res=data[0,45:54];tol=data[0,62:71];independent=float((data[0,:n].astype(float)-c[0,:n,1].astype(float)).sum()-float(b[0,0])*(float(data[0,73])+c[0,:n,4].astype(float).sum()))
    results[label]=dict(converged=bool(data[0,75]),iterations=float(data[0,74]),independent_heat_residual_jm2=independent,max_layer_ratio=float(np.max(abs(res)/tol)),layer_residual_jm2=res.tolist(),layer_tolerance_jm2=tol.tolist(),enthalpy_jm2=data[0,:n].tolist(),temperature_k=data[0,9:9+n].tolist())
assert all(sha(source/n)==v for n,v in manifest.items());value=dict(scope='Candidate numerical line-search safeguard only in an isolated CUDA module. On represented dominant-equation stagnation only, perform four chord relinearizations of the enthalpy Newton direction; unchanged equations/80 outer iterations/merit and final original bounds. Not adopted or full-step/scientific acceptance.',source_unchanged=True,input_sha256=sha(path),results=results,seconds=time.monotonic()-begun)
(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

from pathlib import Path
import hashlib,json,math,os,time
import numpy as np
import jax
import cupy as cp
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.gpu.canopy_phase_surface import run_canopy_phase_surface_jax
from noahmp_clm.gpu.cuda.canopy_phase_surface import run_canopy_phase_surface_cuda
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
path=base/'failure-j-phase-a/failed-surface-inputs.npz';assert sha(path)=='3a3a3fe5aae3bf41fa19fc0c3a34720eb6ab5591980c5aa4ed63466abf00c4ad'
assert jax.devices() and all(device.platform=='gpu' for device in jax.devices())
with np.load(path,allow_pickle=False) as z:values=dict(z)
arrays=tuple(values[f'a{k}'][3:4].copy() for k in range(9));extra={k:values[k][3:4].copy() for k in ['exchange_extension','vic'] if k in values}
original=base/'fluxnet-first-climate-cycle-20261017-j';batch=json.loads((original/'batch.json').read_text());config=Path(batch['cases'][0]['configuration']);config=config if config.is_absolute() else original/config;leaf=LeafParameters(**json.loads(config.read_text())['leaf_parameters'])
def host(value,convert):
    if isinstance(value,dict):return {k:host(v,convert) for k,v in value.items()}
    return np.asarray(convert(value))
begun=time.monotonic();start=time.monotonic();cuda=host(run_canopy_phase_surface_cuda(*arrays,parameters=leaf,raise_on_failure=False,**extra),cp.asnumpy);cp.cuda.runtime.deviceSynchronize();cuda_seconds=time.monotonic()-start
start=time.monotonic();device=run_canopy_phase_surface_jax(*arrays,parameters=leaf,raise_on_failure=False,**extra);jax.effects_barrier();other=host(device,np.asarray);jax_seconds=time.monotonic()-start
def encode(value):
    if isinstance(value,dict):return {k:encode(v) for k,v in value.items()}
    if isinstance(value,np.ndarray):return encode(value.tolist())
    if isinstance(value,(list,tuple)):return [encode(v) for v in value]
    if isinstance(value,float) and not math.isfinite(value):return repr(value)
    return value
def compare(a,b,prefix=''):
    out={};assert a.keys()==b.keys()
    for key,x in a.items():
        y=b[key];name=prefix+'/'+key
        if isinstance(x,dict):out.update(compare(x,y,name));continue
        assert x.shape==y.shape
        finite=np.isfinite(x)&np.isfinite(y);out[name]=dict(dtype_left=str(x.dtype),dtype_right=str(y.dtype),finite_pairs=int(finite.sum()),nonfinite_pairs=int((~finite).sum()),maximum_absolute=float(np.max(np.abs(x.astype(float)[finite]-y.astype(float)[finite]),initial=0.)),exact_equal=bool(np.array_equal(x,y,equal_nan=True)))
    return out
comparison=compare(cuda,other);assert all(sha(source/n)==v for n,v in manifest.items())
value=dict(scope='Diagnostic only: original failing HaM surface on CUDA32/JAX32 with raising disabled. No invalid result advances a state; similarity of failed candidates is not parity/scientific acceptance.',source_unchanged=True,input_sha256=sha(path),node=os.uname().nodename,backend_devices=[dict(platform=d.platform,kind=d.device_kind) for d in jax.devices()],cuda_seconds=cuda_seconds,jax_seconds=jax_seconds,seconds=time.monotonic()-begun,cuda=encode(cuda),jax=encode(other),comparison=comparison)
(root/'summary.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(scope=value['scope'],cuda_seconds=cuda_seconds,jax_seconds=jax_seconds,cuda_converged=cuda['converged'].tolist(),jax_converged=other['converged'].tolist(),cuda_heat_residual=cuda['energy_residual_jm2'].tolist(),jax_heat_residual=other['energy_residual_jm2'].tolist(),source_unchanged=True)),flush=True)

"""Bounded PBS wrapper; immutable candidate/preparation/gold before and after."""
from pathlib import Path
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback
from contract_pbn import sha, save

STAGE = Path('/tmp/noahmp-clm-drainage-guard-pb-o')


def unpack(path, target):
    target.mkdir()
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        for item in members:
            destination = target / item.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(archive.extractfile(item).read())
    return {p.relative_to(target).as_posix(): sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}


def main():
    assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    root = Path(sys.argv[1]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    started = time.monotonic()
    receipt = dict(passed=False, pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
        python=sys.version, python_executable=sys.executable, numerical_parent_returncode=None,
        coupled_column_runs=0, GPU_calls=0, JAX_calls=0, float64_component_calls=0)
    try:
        stage_index = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        immutable = {}
        for folder in ('preparation', 'execution'):
            shutil.copytree(STAGE / folder, root / folder)
            index = json.loads((root / folder / 'CONTROLS_SHA256.json').read_bytes())
            actual = {p.relative_to(root / folder).as_posix() for p in (root / folder).rglob('*') if p.is_file()}
            assert actual == set(index) | {'CONTROLS_SHA256.json'}
            assert all(sha((root / folder / n).read_bytes()) == h for n, h in index.items())
            immutable.update({folder + '/' + n: h for n, h in index.items()})
            immutable[folder + '/CONTROLS_SHA256.json'] = sha((root / folder / 'CONTROLS_SHA256.json').read_bytes())
        binding = json.loads((root / 'preparation/BINDINGS.json').read_bytes())
        shutil.copytree(STAGE / 'reference', root / 'reference')
        reference_index = json.loads((root / 'reference/CONTROLS_SHA256.json').read_bytes())
        assert all(sha((root / 'reference' / n).read_bytes()) == h for n, h in reference_index.items())
        immutable.update({'reference/' + n: h for n, h in reference_index.items()})
        immutable['reference/CONTROLS_SHA256.json'] = sha((root / 'reference/CONTROLS_SHA256.json').read_bytes())
        gold_binding = json.loads((root / 'reference/GOLD32_BINDINGS.json').read_bytes())
        assert sha((STAGE / 'source.tar.gz').read_bytes()) == binding['source_archive_sha256']
        assert sha((STAGE / 'gold.tar.gz').read_bytes()) == gold_binding['archive_sha256']
        source_members = unpack(STAGE / 'source.tar.gz', root / 'source')
        source_raw = (root / 'source/SOURCE_SHA256.json').read_bytes()
        source_index = json.loads(source_raw)
        assert len(source_index) == 594 and len(source_members) == 595
        assert sha(source_raw) == binding['source_manifest_sha256']
        assert {n: h for n, h in source_members.items() if n != 'SOURCE_SHA256.json'} == source_index
        base = json.loads((root / 'reference/BASE_PBL_SOURCE_SHA256.json').read_bytes())
        assert len(base) == 586 and all(source_index[n] == h for n, h in base.items())
        gold_members = unpack(STAGE / 'gold.tar.gz', root / 'sealed-gold')
        assert len(gold_members) == 345
        inventory = json.loads((root / 'sealed-gold/artifact-inventory.json').read_bytes())
        assert set(inventory) == set(gold_members) - {'artifact-inventory.json'}
        assert all(gold_members[n] == h for n, h in inventory.items())
        assert all(gold_members[n] == h for n, h in gold_binding['members'].items())
        immutable.update({'source/' + n: h for n, h in source_members.items()})
        immutable.update({'sealed-gold/' + n: h for n, h in gold_members.items()})
        save(root / 'immutable-before.json', immutable)
        env = os.environ.copy()
        env.pop('PYTHONHOME', None)
        env.update(PYTHONPATH=str(root / 'source/src') + ':' + str(root / 'execution') + ':/home/zhangyq/noahmp-v1/test-deps',
            PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='', JAX_PLATFORMS='cpu',
            OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        dependency = Path('/home/zhangyq/noahmp-v1/test-deps/numpy-2.2.6.dist-info/METADATA')
        save(root / 'dependencies.json', dict(numpy_metadata_path=str(dependency), numpy_metadata_sha256=sha(dependency.read_bytes())))
        guard_command = [sys.executable, '-B', '-m', 'pytest', '-q', '-s', '-p', 'no:cacheprovider',
            '--junitxml=' + str(root / 'guard-tests.xml'), str(root / 'preparation/test_guard_pbo.py')]
        save(root / 'guard-command.json', guard_command)
        guard_started = time.monotonic()
        with (root / 'guard.stdout.txt').open('wb') as out, (root / 'guard.stderr.txt').open('wb') as err:
            guard_result = subprocess.run(guard_command, cwd=root, env=env, stdout=out, stderr=err, timeout=100)
        receipt.update(guard_parent_returncode=guard_result.returncode, guard_seconds=time.monotonic() - guard_started)
        import xml.etree.ElementTree as ET
        testcases = list(ET.parse(root / 'guard-tests.xml').getroot().iter('testcase'))
        receipt.update(guard_tests=len(testcases), guard_failures=sum(c.find('failure') is not None for c in testcases),
            guard_errors=sum(c.find('error') is not None for c in testcases), guard_skipped=sum(c.find('skipped') is not None for c in testcases))
        assert guard_result.returncode == 0 and len(testcases) == 12
        assert receipt['guard_failures'] == receipt['guard_errors'] == receipt['guard_skipped'] == 0
        command = [sys.executable, '-B', str(root / 'execution/parity_pbn.py'), str(root)]
        save(root / 'command.json', command)
        with (root / 'numerical.stdout.txt').open('wb') as out, (root / 'numerical.stderr.txt').open('wb') as err:
            result = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=400)
        receipt['numerical_parent_returncode'] = result.returncode
        after = {n: sha((root / n).read_bytes()) for n in immutable}
        save(root / 'immutable-after.json', after)
        assert after == immutable
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        summary = json.loads((root / 'parity/summary.json').read_bytes())
        receipt.update(source_files=594, unchanged_PBl_files=586, sealed_gold_members=345,
            preparation_controls=17, source_archive_sha256=binding['source_archive_sha256'],
            source_manifest_sha256=binding['source_manifest_sha256'], gold_archive_sha256=gold_binding['archive_sha256'],
            preparation_manifest_sha256=immutable['preparation/CONTROLS_SHA256.json'],
            execution_manifest_sha256=immutable['execution/CONTROLS_SHA256.json'],
            immutable_files_verified=len(immutable), source_controls_gold_unchanged=True,
            actual_trial_calls=summary['actual_trial_calls'], actual_full_calls=summary['actual_full_calls'],
            actual_inverse_calls=summary['actual_inverse_calls'], numeric_fields_compared=summary['numeric_fields_compared'])
        assert result.returncode == 0 and summary['passed']
        receipt['passed'] = True
    except Exception:
        receipt['error'] = traceback.format_exc()
        (root / 'failure.txt').write_text(receipt['error'])
    receipt.update(seconds=time.monotonic() - started,
        scope='PB-o12 CPU guard tests plus unchanged1673 exact NumPy32 parity driver on frozen594 source and sealed1665 input32. Actual20trial17full expected; no64/JAX/CUDA/column/annual/production acceptance.')
    save(root / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

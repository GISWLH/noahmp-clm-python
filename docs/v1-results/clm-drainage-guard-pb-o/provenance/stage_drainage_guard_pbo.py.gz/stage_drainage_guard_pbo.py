"""Prepare PB-o12 CPU guard tests plus exact unchanged1673 NumPy32 parity."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
PREP = ROOT / 'clm-drainage-guard-pb-o-preparation'
EXEC = ROOT / 'clm-drainage-guard-pb-o-execution'
OLD = ROOT / 'clm-drainage-package-pb-n-execution'
sha = lambda b: hashlib.sha256(b).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n', encoding='utf8', newline='\n')


def main():
    assert sha((PREP / 'CONTROLS_SHA256.json').read_bytes()) == 'eaaec34067f643e5efa6dbe69686cf7cd34542bf3a38fdaac275ce21a76a939c'
    prep_index = json.loads((PREP / 'CONTROLS_SHA256.json').read_bytes())
    assert len(prep_index) == 17 and all(sha((PREP / n).read_bytes()) == h for n, h in prep_index.items())
    binding = json.loads((PREP / 'BINDINGS.json').read_bytes())
    source = ROOT / binding['source_archive']
    assert sha(source.read_bytes()) == binding['source_archive_sha256']
    parent_evidence = ROOT / 'clm-drainage-package-pb-n-evidence.tar.gz'
    assert sha(parent_evidence.read_bytes()) == 'bd5e179136af200b9f57906c8334dc1a7473f8377cf317464fcbfc4fef71e9a7'
    with tarfile.open(parent_evidence) as t:
        parent = {m.name: t.extractfile(m).read() for m in t}
    EXEC.mkdir(exist_ok=True)
    retained = ('arrays_pbn.py', 'contract_pbn.py', 'original_arrays_po.py', 'encoder.patch',
                'ENCODER_ADAPTATION.json', 'parity_pbn.py')
    for name in retained:
        original = parent['execution/' + name]
        assert original == (OLD / name).read_bytes()
        (EXEC / name).write_bytes(original)
    code = parent['execution/run_component_pb.py'].decode()
    changes = [
        ('clm-drainage-package-pb-n', 'clm-drainage-guard-pb-o'),
        ("gold_binding = json.loads((root / 'preparation/GOLD32_BINDINGS.json').read_bytes())",
         "shutil.copytree(STAGE / 'reference', root / 'reference')\n        reference_index = json.loads((root / 'reference/CONTROLS_SHA256.json').read_bytes())\n        assert all(sha((root / 'reference' / n).read_bytes()) == h for n, h in reference_index.items())\n        immutable.update({'reference/' + n: h for n, h in reference_index.items()})\n        immutable['reference/CONTROLS_SHA256.json'] = sha((root / 'reference/CONTROLS_SHA256.json').read_bytes())\n        gold_binding = json.loads((root / 'reference/GOLD32_BINDINGS.json').read_bytes())"),
        ("binding['archive_sha256']", "binding['source_archive_sha256']"),
        ("gold_binding['source_archive_sha256']", "gold_binding['archive_sha256']"),
        ('len(source_index) == 593 and len(source_members) == 594', 'len(source_index) == 594 and len(source_members) == 595'),
        ("root / 'preparation/BASE_PBL_SOURCE_SHA256.json'", "root / 'reference/BASE_PBL_SOURCE_SHA256.json'"),
        ("        command = [sys.executable, '-B', str(root / 'execution/parity_pbn.py'), str(root)]",
         """        guard_command = [sys.executable, '-B', '-m', 'pytest', '-q', '-s', '-p', 'no:cacheprovider',
            '--junitxml=' + str(root / 'guard-tests.xml'), str(root / 'preparation/test_guard_pbo.py')]
        save(root / 'guard-command.json', guard_command)
        guard_started = time.monotonic()
        with (root / 'guard.stdout.txt').open('wb') as out, (root / 'guard.stderr.txt').open('wb') as err:
            guard_result = subprocess.run(guard_command, cwd=root, env=env, stdout=out, stderr=err, timeout=100)
        receipt.update(guard_parent_returncode=guard_result.returncode, guard_seconds=time.monotonic() - guard_started)
        import xml.etree.ElementTree as ET
        testcases = list(ET.parse(root / 'guard-tests.xml').getroot().iter('testcase'))
        receipt.update(guard_tests=len(testcases), guard_failures=sum(c.find('failure') is not None for c in testcases),
            guard_errors=sum(c.find('error') is not None for c in testcases), guard_skipped=sum(c.find('skipped') is not None for c in testcases))
        assert guard_result.returncode == 0 and len(testcases) == 12
        assert receipt['guard_failures'] == receipt['guard_errors'] == receipt['guard_skipped'] == 0
        command = [sys.executable, '-B', str(root / 'execution/parity_pbn.py'), str(root)]"""),
        ('timeout=530', 'timeout=400'),
        ('receipt.update(source_files=593', 'receipt.update(source_files=594'),
        ('preparation_controls=23', 'preparation_controls=17'),
        ("scope='Only NumPy32 package-bound replay of sealed1665 inputs; 20direct trials/17full expected, actual counters from returned calls. No64/JAX/CUDA/column/annual/source promotion.'",
         "scope='PB-o12 CPU guard tests plus unchanged1673 exact NumPy32 parity driver on frozen594 source and sealed1665 input32. Actual20trial17full expected; no64/JAX/CUDA/column/annual/production acceptance.'")
    ]
    for old, new in changes:
        assert old in code, old
        code = code.replace(old, new)
    assert "gold_binding['source_archive_sha256']" not in code
    (EXEC / 'run_component_pb.py').write_text(code, encoding='utf8', newline='\n')
    diff = list(difflib.unified_diff(parent['execution/run_component_pb.py'].decode().splitlines(True), code.splitlines(True),
        fromfile='actual1673/execution/run_component_pb.py', tofile='preparedPB-o/execution/run_component_pb.py'))
    for name in ('component_pb.pbs', 'dispatch_component_pb.py'):
        original = parent['execution/' + name].decode()
        code = original.replace('clm-drainage-package-pb-n', 'clm-drainage-guard-pb-o')
        code = code.replace('drainage-package-pbn', 'drainage-guard-pbo').replace('dispatch_drainage_package_pbn.py', 'dispatch_drainage_guard_pbo.py')
        code = code.replace('PB-n exact NumPy32 package parity: sealed1665 input32,20trials17full,allnumeric byte equality. No64/JAX/CUDA/coupled/site/annual execution.',
            'PB-o12 CPU guard tests plus actual1673 exact32 parity controls, source594. No64/JAX/CUDA/coupled/site/annual execution.')
        (EXEC / name).write_text(code, encoding='utf8', newline='\n')
        diff.extend(difflib.unified_diff(original.splitlines(True), code.splitlines(True),
            fromfile='actual1673/execution/' + name, tofile='preparedPB-o/execution/' + name))
    (EXEC / 'wrapper.patch').write_text(''.join(diff), encoding='utf8', newline='\n')
    (EXEC / 'README.md').write_text('''# PB-o prepared execution, not submitted

One EHPC compute002 PBS1CPU/2GB/10min job, existing Python3.11.9 and test-deps NumPy2.2.6/pytest9.1.1. First run only the twelve frozen guard tests. Invalid CUDA/JAX paths use sentinels and must reject before backend import/conversion; they do not execute a GPU or establish device acceptance. The accepted public pack test only explicitly encodes a concrete64 state record to32.

Only if all twelve pass, execute the exact original1673 arrays_pbn.py/contract_pbn.py/parity_pbn.py and encoder provenance bytes. No case/math/gold/threshold change. The source is the new frozen PB-o594 candidate instead of PB-n593. It repeats the exact sealed1665 input32 twenty trials/seventeen full integrations and1106field dtype/shape/byte comparison, original64eps accounts and phase checks. Original six retained execution artifacts are SHA-bound to actual1673 evidence. No64 reference/JAX/CUDA/native column is run.

Original preparation17 and all source594/gold345/retained controls are byte-checked before/after. Actual calls accrue only after returned calls in the unchanged parity driver. Parent/execution exits, pytest XML/stdout/stderr, numerical outputs/partial counters and scheduler trueF/Stageout are retained. A failed setup/test does not proceed to parity and remains a failed job; do not silently rewrite its stage or relaunch. Current status is prepared-only, awaiting root control-plan review, with no qsub authorization claimed by this file.
''', encoding='utf8', newline='\n')
    save(EXEC / 'REUSE_BINDINGS.json', dict(parent_actual_job='1673.manager', parent_actual_F0=True,
        parent_evidence_sha256=sha(parent_evidence.read_bytes()),
        exact_retained_execution_members={n: sha(parent['execution/' + n]) for n in retained},
        candidate_source_sha256=binding['source_archive_sha256'], candidate_source_files=594,
        original_math_cases_gold_thresholds_unchanged=True, numerical_executed=False, PBS_submitted=False))
    for path in EXEC.glob('*.py'): ast.parse(path.read_bytes())
    exec_index = {p.name: sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    save(EXEC / 'CONTROLS_SHA256.json', exec_index)
    reference = {name: parent['preparation/' + name] for name in ('GOLD32_BINDINGS.json', 'BASE_PBL_SOURCE_SHA256.json')}
    reference['parent1673-closed-run.json'] = parent['closed-run.json']
    reference['CONTROLS_SHA256.json'] = (json.dumps({n: sha(b) for n, b in reference.items()}, indent=2) + '\n').encode()
    gold_binding = json.loads(reference['GOLD32_BINDINGS.json'])
    gold = ROOT / gold_binding['archive']
    assert sha(gold.read_bytes()) == gold_binding['archive_sha256']
    raw = {'source.tar.gz': source.read_bytes(), 'gold.tar.gz': gold.read_bytes()}
    raw.update({'reference/' + n: b for n, b in reference.items()})
    for folder, label in ((PREP, 'preparation'), (EXEC, 'execution')):
        raw.update({label + '/' + p.relative_to(folder).as_posix(): p.read_bytes() for p in sorted(folder.rglob('*')) if p.is_file()})
    raw['stage-inventory.json'] = (json.dumps({n: sha(b) for n, b in sorted(raw.items())}, indent=2) + '\n').encode()
    archive = ROOT / 'clm-drainage-guard-pb-o-stage.tar.gz'
    with tarfile.open(archive, 'w:gz') as t:
        for name, data in sorted(raw.items()):
            ti = tarfile.TarInfo(name); ti.size = len(data); t.addfile(ti, io.BytesIO(data))
    report = dict(actual_static_exit=0, stage_sha256=sha(archive.read_bytes()), stage_members=len(raw),
        preparation_controls=len(prep_index), preparation_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()),
        execution_controls=len(exec_index), execution_manifest_sha256=sha((EXEC / 'CONTROLS_SHA256.json').read_bytes()),
        candidate_source_sha256=binding['source_archive_sha256'], candidate_source_files=594,
        gold_archive_sha256=gold_binding['archive_sha256'], parent1673_evidence_sha256=sha(parent_evidence.read_bytes()),
        planned_guard_tests=12, planned_exact32_cases=20, planned_full32_calls=17, planned_numeric_fields=1106,
        exact_reused_execution_members=retained, source_or_preparation_modified=False,
        numerical_executed=False, PBS_submitted=False, awaiting_root_plan_review=True)
    save(ROOT / 'clm-drainage-guard-pb-o-stage-preparation.json', report)
    print(json.dumps(report))


if __name__ == '__main__': main()

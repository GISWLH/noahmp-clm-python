"""Prepared CPU-only guard tests; not executed on the authoring computer."""
import os
if os.name == 'nt':
    raise RuntimeError('PB-o tests require an authorized EHPC compute job')

import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
from noahmp_clm.gpu import _clm_drainage_input_guard as guard
from noahmp_clm.gpu import clm_drainage_primitives as main
from noahmp_clm.gpu import clm_perched_drainage_primitives as perched
from noahmp_clm.gpu import clm_drainage_adaptive as main_full
from noahmp_clm.gpu import clm_perched_drainage_adaptive as perched_full


def inputs(dtype=np.float32):
    return np.zeros((1, 4, 6), dtype), np.zeros((1, 12), dtype), np.zeros((1, 3), dtype)


class TestRawDrainageGuard(unittest.TestCase):
    def test_numpy_metadata_allows_explicit_32_and_64_without_change(self):
        for dtype in (np.float32, np.float64):
            values = inputs(dtype)
            before = [v.tobytes() for v in values]
            self.assertEqual(guard.require_trial_inputs(*values, 'numpy'), np.dtype(dtype).itemsize)
            self.assertEqual([v.tobytes() for v in values], before)

    def test_cuda64_trials_reject_before_backend_import(self):
        for call in (main.run_cuda, perched.run_cuda_perched):
            with patch.dict(sys.modules, {'cupy': None}):
                with self.assertRaisesRegex(ValueError, 'CUDA requires float32'):
                    call(*inputs(np.float64))

    def test_mixed_float_dtypes_reject_before_physics_all_trial_entries(self):
        values = inputs(); values = (values[0], values[1].astype(np.float64), values[2])
        for call in (main.run_numpy, main.run_jax, main.run_cuda,
                     perched.run_numpy_perched, perched.run_jax_perched, perched.run_cuda_perched):
            with patch.object(main, 'validate', side_effect=AssertionError('physical validator reached')):
                with self.assertRaisesRegex(ValueError, 'same explicit floating dtype'):
                    call(*values)

    def test_unsupported_array_dtypes_reject_before_numpy_physics(self):
        for dtype in (np.float16, np.int32, np.bool_, np.complex64, object, 'U2'):
            for call in (main.run_numpy, perched.run_numpy_perched):
                with patch.object(main, 'validate', side_effect=AssertionError('physical validator reached')):
                    with self.assertRaisesRegex(ValueError, 'float32/float64 array required'):
                        call(*inputs(dtype))

    def test_untyped_lists_and_non_native_endian_reject(self):
        c, p, u = inputs()
        for invalid in (c.tolist(), c.astype('>f4')):
            with self.assertRaises(ValueError): guard.require_trial_inputs(invalid, p, u, 'numpy')

    def test_wrong_shape_and_empty_batch_reject_without_values(self):
        for n, layers in ((0, 4), (1, 3), (1, 6)):
            with self.assertRaisesRegex(ValueError, 'shapes'):
                guard.require_trial_inputs(np.zeros((n, layers, 6), np.float32),
                    np.zeros((n, 12), np.float32), np.zeros((n, 3), np.float32), 'cuda')

    def test_adaptive_cuda64_rejects_before_backend_and_phase(self):
        c, p, _ = inputs(np.float64)
        for module, name in ((main_full, 'advance_main_band'), (perched_full, 'advance_perched_band')):
            with patch.object(module, '_backend', side_effect=AssertionError('backend reached')):
                with patch.object(module, '_phase', side_effect=AssertionError('phase reached')):
                    with self.assertRaisesRegex(ValueError, 'CUDA requires float32'):
                        getattr(module, name)(c[0], p[0], 1, 1800., .5, 2., backend='cuda')
                    for backend in ('numpy', 'jax', 'cuda'):
                        with self.assertRaisesRegex(ValueError, 'same explicit floating dtype'):
                            getattr(module, name)(c[0].astype(np.float32), p[0], 1, 1800., .5, 2., backend=backend)

    def test_adaptive_phase_option_is_exact_original_integer_before_dispatch(self):
        c, p, _ = inputs()
        for module, name in ((main_full, 'advance_main_band'), (perched_full, 'advance_perched_band')):
            with patch.object(module, '_backend', side_effect=AssertionError('backend reached')):
                for option in (True, 1., np.int32(1), 0, 3):
                    with self.assertRaisesRegex(ValueError, 'Original integer phase option'):
                        getattr(module, name)(c[0], p[0], option, 1800., .5, 2.)

    def test_typed_scalar_mismatch_and_invalid_time_reject(self):
        c, p, _ = inputs()
        for value in (np.float64(1800), True, float('nan'), 0., -1.):
            with self.assertRaises(ValueError):
                guard.require_adaptive_inputs(c[0], p[0], 1, value, .5, 2., 'numpy')
        self.assertEqual(guard.require_adaptive_inputs(c[0], p[0], 1, np.float32(1800), .5, 2., 'numpy'), 4)
        self.assertEqual(guard.require_adaptive_inputs(c[0], p[0], 2, 1800., .5, 2., 'numpy'), 4)

    def test_jax64_disabled_rejects_before_array_conversion(self):
        fake_jax = SimpleNamespace(config=SimpleNamespace(jax_enable_x64=False))
        with patch.dict(sys.modules, {'jax': fake_jax, 'jax.numpy': None}):
            for call in (main.run_jax, perched.run_jax_perched):
                with self.assertRaisesRegex(ValueError, 'x64 enabled before conversion'):
                    call(*inputs(np.float64))
        # A metadata/config guard test only, not execution of JAX or its kernels.

    def test_unknown_backend_rejects(self):
        with self.assertRaisesRegex(ValueError, 'Choose numpy, jax or cuda'):
            guard.require_trial_inputs(*inputs(), 'gpu')

    def test_public_explicit_pack_float32_is_valid_raw_cuda_encoding(self):
        from noahmp_clm.column import SoilParams
        from noahmp_clm.physics.clm_saturated_drainage import DrainageParameters
        # A concrete float64 state record exercises the unchanged public pack;
        # no thermodynamic integration or CUDA execution is needed for encoding.
        water = np.full(4, 200., np.float64)
        soil = SimpleNamespace(params=SoilParams(smcmax=.45), liquid=water.copy(), water=water,
            dz=np.full(4, .5), temperature=np.full(4, 290.), enthalpy=np.full(4, 7e7))
        before = soil.water.tobytes()
        c, p, u = main.pack(soil, DrainageParameters(bedrock_depth_m=2., slope_radians=.1),
                            1800., .5, 2., dtype=np.float32)
        self.assertEqual(guard.require_trial_inputs(c[None], p[None], u[None], 'cuda'), 4)
        self.assertEqual(soil.water.dtype, np.dtype('float64'))
        self.assertEqual(soil.water.tobytes(), before)


if __name__ == '__main__': unittest.main()

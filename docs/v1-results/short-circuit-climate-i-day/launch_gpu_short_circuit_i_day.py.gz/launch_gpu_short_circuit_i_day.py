from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-i';source=base/'p6-phase-short-circuit-gpu-a';receipt=root/'cuda-day-launch.json';assert not receipt.exists()
legacy=json.loads((base/'p6-short-circuit-legacy-replay-a/cuda-replay.json').read_text());assert legacy['status']=='complete' and legacy['pre_change_baseline_bitwise_equal']
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'benchmarks'),CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with (root/'cuda-controller.log').open('w') as log:p=subprocess.Popen(['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_gpu_short_circuit_i_day.py')],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,steps_requested=17520,stop_after=48)
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

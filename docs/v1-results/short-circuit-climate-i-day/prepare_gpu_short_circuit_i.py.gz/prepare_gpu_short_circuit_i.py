from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-i';assert not root.exists();root.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archives=[('first-climate-h-inputs.tar.gz','98c03d7771abb8390b989bebc66f19f8d4e399babd71def053a8f36998bb0143'),('suction-climate-h-numpy-day-evidence.tar.gz','38518829a5be5f7bf04f6ef8cda4f0bcb9d64f6b473184f5cbf4b60fac4b4eae')]
for name,expected in archives:
    p=base/name;assert sha(p)==expected
    with tarfile.open(p) as t:
        for m in t:
            key=PurePosixPath(m.name);assert m.isfile() and not key.is_absolute() and '..' not in key.parts
            target=root/m.name;data=t.extractfile(m).read();target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():assert target.read_bytes()==data
            else:target.write_bytes(data)
original=(root/'batch.json').read_bytes();(root/'ehpc-batch.json').write_bytes(original)
batch=json.loads(original)
for row in batch['cases']:
    for k in ['input','input_manifest','configuration']:row[k]=str(root/'inputs'/Path(row[k]).name)
(root/'batch.json').write_text(json.dumps(batch,indent=2)+'\n')
manifest=base/'h-numpy-source-manifest.json';assert sha(manifest)==json.loads((root/'protocol.json').read_text())['source_manifest_sha256']
(root/'numpy-source-manifest.json').write_bytes(manifest.read_bytes())
record=dict(scope='Fresh GPU cold seed from locked explicit-suction configurations. NumPy prefixes are independent immutable references; no checkpoint is reused.',archives=dict(archives),ehpc_batch_sha256=hashlib.sha256(original).hexdigest(),gpu_batch_sha256=sha(root/'batch.json'))
(root/'input-import.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

source=base/'p6-phase-short-circuit-gpu-a';previous=base/'p6-phase-jacobian-gpu-a'
new=json.loads((source/'SOURCE_SHA256.json').read_text());old=json.loads((previous/'SOURCE_SHA256.json').read_text())
diff={k for k in old if k.startswith('src/') and old[k]!=new[k]}
assert diff=={'src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu'}
(root/'early-exit-provenance.json').write_text(json.dumps(dict(scope='Fresh I trajectory from identical locked H physical configurations/forcing and explicit-suction NumPy seed policy; no H checkpoint reused. Only two device early-exit files differ.',source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),previous_manifest_sha256=sha(previous/'SOURCE_SHA256.json'),runtime_differences=sorted(diff)),indent=2)+'\n')

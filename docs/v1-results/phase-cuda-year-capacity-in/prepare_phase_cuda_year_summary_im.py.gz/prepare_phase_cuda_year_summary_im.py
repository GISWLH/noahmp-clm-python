from pathlib import Path
import hashlib,json,re,subprocess,sys
b=Path('/home/zhangyq/noahmp-v1');label=sys.argv[1];assert label in ['capacity','capacity_optics'];r=b/('qia-phase-'+label+'-cuda-year-summary-im');prior=b/('qia-phase-'+label+'-cuda-year-evaluation-ih')
parent=json.loads((prior/'dispatch.json').read_text())['pbs_job'];status=subprocess.check_output(['qstat','-xf',parent],text=True)
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and json.loads((prior/'receipt.json').read_text())['evaluation_delivered']
assert not r.exists();r.mkdir();controls={}
for name in ['summarize_phase_cuda_year_im.py','phase_cuda_year_summary_im.pbs']:
 raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
(r/'parent-actual-qstat.txt').write_text(status)
p=subprocess.run(['qsub','-v','CAPACITY_CASE='+label,str(r/'phase_cuda_year_summary_im.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),case=label,parent_actual_pbs=parent,parent_actual_exit=0,controls_sha256=controls)
(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');label=sys.argv[1];assert label in ['capacity','capacity_optics'];expected=sys.argv[2]
r=b/('qia-phase-'+label+'-cuda-year-evaluation-ih');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
packet=b/('qia-phase-'+label+'-cuda-year-ig-export.tar.gz');assert sha(packet)==expected and not r.exists()
with tarfile.open(packet) as tf:
 parent=json.load(tf.extractfile('year-exit.json'));raw=tf.extractfile('year-receipt.json').read();d=json.loads(raw)
 assert parent['returncode']==0 and parent['passed'] and hashlib.sha256(raw).hexdigest()==parent['receipt_sha256']
 assert d['failure'] is None and d['source_unchanged'] and d['status']=='complete' and d['steps_completed']==d['steps_requested']==17520 and d['device_barrier_complete']
 assert d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
r.mkdir();controls={}
for name in ['evaluate_phase_cuda_year_ih.py','phase_cuda_year_evaluation_ih.pbs']:
 raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
(r/'packet.json').write_text(json.dumps(dict(sha256=expected,archive=packet.name),indent=2)+'\n')
p=subprocess.run(['qsub','-v','CAPACITY_CASE='+label,str(r/'phase_cuda_year_evaluation_ih.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),case=label,controls_sha256=controls,packet_sha256=expected,
 scope='ActualEC17520CUDAyear parent0/barrier required before independentEHPC all365days12months/year original14CTSMfields +FLUXNET products/QC/soil operators and nativeall23finalstorage/originalledgers. No currentFL/fullsameprecision/spinup/observedsciencepass from completedmodel or queue.')
(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

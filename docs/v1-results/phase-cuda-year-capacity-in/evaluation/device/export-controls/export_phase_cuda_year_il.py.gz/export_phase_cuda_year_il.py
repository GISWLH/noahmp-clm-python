from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');label=sys.argv[1];assert label in ['capacity','capacity_optics'];r=b/('qia-phase-'+label+'-cuda-year-ej');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
exit=json.loads((r/'year-exit.json').read_text());receipt=json.loads((r/'year-receipt.json').read_text())
assert exit['returncode']==0 and exit['passed'] and exit['receipt_sha256']==sha(r/'year-receipt.json')
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['status']=='complete' and receipt['steps_completed']==receipt['steps_requested']==17520 and receipt['device_barrier_complete']
assert receipt['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
folder=r/'trajectory';report=json.loads((folder/'batch.json').read_text());assert report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520
assert report['source_unchanged'] and report['same_precision_max_absolute'] is None and report['identity']['backend']=='cuda32' and not report['identity']['compare_jax32']
assert sha(folder/report['checkpoint_file'])==report['checkpoint_sha256']
files=[r/name for name in ['year-exit.json','year-receipt.json','year-launch.json','year-start-audit.json','prefix-verification.json','prefix-exit.json','prefix-receipt.json','SOURCE_SHA256.json','first-continued-step.npz'] if (r/name).exists()]
source_root=Path('/tmp/noahmp-phase-descent-ec/source');source_manifest=source_root/'SOURCE_SHA256.json'
assert sha(source_manifest)==receipt['source_manifest_sha256']
m=json.loads(source_manifest.read_text());assert len(m)==571 and all(sha(source_root/n)==h for n,h in m.items())
assert receipt['first_continued_step_captured'] and receipt['continued_fields_exact']==30 and (r/'first-continued-step.npz').exists()
files.extend([folder/'batch.json',folder/report['checkpoint_file']])
cold=list(folder.glob('state-0000000-*.npz'));assert len(cold)==1;files.extend(cold)
for name,descriptor in report['case_reports'].items():
 case=folder/name;path=case/descriptor['file'];data=json.loads(path.read_text());assert sha(path)==descriptor['sha256']
 assert data['status']=='complete' and data['steps_completed']==data['steps_requested']==17520 and data['batch_checkpoint_sha256']==report['checkpoint_sha256']
 assert sha(case/data['model_npz'])==data['model_npz_sha256'];files.extend([path,case/data['model_npz']])
 alias=case/'report.json';assert alias.read_bytes()==path.read_bytes();files.append(alias)
 generation=cold[0].stem[len('state-'):]
 for stem in ['report-','trace-']:
  path=case/(stem+generation+('.json' if stem=='report-' else '.npz'));assert path.exists();files.append(path)
archive=b/('qia-phase-'+label+'-cuda-year-ig-export.tar.gz');assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
 for path in sorted(set(files)):
  assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(r.resolve());name=path.relative_to(r).as_posix();inventory[name]=sha(path);tf.add(path,arcname=name,recursive=False)
 tf.add(source_manifest,arcname='SOURCE_SHA256.json',recursive=False);inventory['SOURCE_SHA256.json']=sha(source_manifest)
 for control in [Path(__file__),b/'export_phase_cuda_year_ig.py']:
  tf.add(control,arcname='export-controls/'+control.name,recursive=False);inventory['export-controls/'+control.name]=sha(control)
 import io
 error=(json.dumps(dict(actual_static_export_exit=1,original_control='export_phase_cuda_year_ig.py',failure='FileNotFoundError: year root has no SOURCE_SHA256.json; immutable EC source manifest remains at original /tmp source. IL reads and verifies that original571-file source and records the manifest in the export. No originalyear/source/config/input/gate/receipt change or numerical rerun.'))+'\n').encode()
 name='export-controls/ig-observer-error.json';info=tarfile.TarInfo(name);info.size=len(error);tf.addfile(info,io.BytesIO(error));inventory[name]=hashlib.sha256(error).hexdigest()
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(inventory)
 for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(case=label,archive=archive.name,sha256=sha(archive),artifacts=len(inventory),bytes=archive.stat().st_size,source_manifest_sha256=receipt['source_manifest_sha256'],
 scope='ActualEC571 CUDA-only full17520year ownactualparent0/barrier, immutablecold/final23state+7ledger, fulltrace/source/config/hashlinks and firstcontinuedstep retained. No currentFL579/fullsameprecision/NumPy/fullsuite/spinup/sciencepass credit. Staticexportonly, independentfullperiod/reference/ledger audit onEHPCcompute follows.')
(b/('qia-phase-'+label+'-cuda-year-ig-export.json')).write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

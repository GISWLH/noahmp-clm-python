from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics']
r=b/('qia-phase-'+label+'-cuda-year-summary-im');prior=b/('qia-phase-'+label+'-cuda-year-evaluation-ih');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert (prior/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((prior/'receipt.json').read_text());assert d['evaluation_delivered'] and d['source_unchanged'] and d['model_complete_steps']==17520
assert all(sha(prior/n)==h for n,h in d['output_sha256'].items())
s=Path(os.environ['TMPDIR'])/'source';s.mkdir();archive=b/'clm-phase-descent-ec-source.tar.gz';assert sha(archive)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
manifest=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(manifest)==571 and sha(s/'SOURCE_SHA256.json')==d['source_manifest_sha256'] and all(sha(s/n)==h for n,h in manifest.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
start=time.monotonic();folder=prior/'device/trajectory';batch,saved,pairs=native.read_generation(folder);assert len(pairs)==1
report,trace=pairs[0];n=17520;assert report['status']=='complete' and report['steps_completed']==report['steps_requested']==n
cold_paths=list(folder.glob('state-0000000-*.npz'));assert len(cold_paths)==1
with np.load(cold_paths[0],allow_pickle=False) as z:cold=dict(z)
assert int(cold['index'])==0
cold_arrays=native.checkpoint_arrays(cold,batch['identity']);final_arrays=native.checkpoint_arrays(saved,batch['identity']);assert len(cold_arrays)==len(final_arrays)==23
assert np.array_equal(native.totals(cold_arrays),cold['initial']) and np.array_equal(cold['initial'],saved['initial'])
c0,c1=cold_arrays[13][0,:7].astype(float),final_arrays[13][0,:7].astype(float);n0,n1=cold_arrays[13][0,7:].astype(float),final_arrays[13][0,7:].astype(float)
soc0,soc1=float(c0[4:].sum()),float(c1[4:].sum())
swe=np.asarray(trace['swe_m'],float);old=np.r_[float(cold_arrays[0][0,:,0].astype(float).sum()/1000.),swe[:-1]]
energy=json.loads((prior/'official-comparison.json').read_text());obs=json.loads((prior/'fluxnet-observations.json').read_text());annual=energy['metrics']['year']['2003'];assert len(annual)==14 and len(energy['metrics']['daily'])==365 and len(energy['metrics']['monthly'])==12
fields={}
for name,metric in annual.items():
 fields[name]=dict(year=metric,complete_days=365,complete_months=12,
  daily_bias_pass=sum(v[name].get('bias_pass') is True for v in energy['metrics']['daily'].values()),
  monthly_bias_pass=sum(v[name].get('bias_pass') is True for v in energy['metrics']['monthly'].values()),
  daily_correlation_pass=sum(v[name].get('correlation_pass') is True for v in energy['metrics']['daily'].values()),
  monthly_correlation_pass=sum(v[name].get('correlation_pass') is True for v in energy['metrics']['monthly'].values()))
value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,case=label,passed=True,source_manifest_sha256=d['source_manifest_sha256'],source_unchanged=all(sha(s/k)==h for k,h in manifest.items()),
 parent_evaluation_receipt_sha256=sha(prior/'receipt.json'),native_backend='cuda32',model_complete_steps=n,
 independent_ledger_checks=energy['independent_ledger_checks'],independent_final_storage_checks=energy['independent_final_storage_checks'],
 official14fields=fields,official_period_integrals=energy['period_integrals']['year']['2003'],fluxnet_original_own_qc_instantaneous=obs['instantaneous'],
 soil_carbon=dict(cold_seven_pools_gc_m2=c0.tolist(),final_seven_pools_gc_m2=c1.tolist(),cold_soil_cn_nitrogen_gn_m2=n0.tolist(),final_soil_cn_nitrogen_gn_m2=n1.tolist(),
  cold_three_soc_gc_m2=soc0,final_three_soc_gc_m2=soc1,delta_soc_gc_m2=soc1-soc0,
  single_cold_year_annualized_soc_drift_percent_per_century=10000.*(soc1-soc0)/soc0 if soc0>0 else None,
  meaning='One actualcoldyear endpoint diagnostic, not stationaryspinup drift, a100year trajectory or SOCacceptance. Originalall7pools/8Nfields retained; no soilpoolpreconditioning.'),
 snow=dict(intervals_with_swe_positive=int(np.count_nonzero(swe>0)),maximum_swe_m=float(swe.max()),end_swe_m=float(swe[-1]),
  positive_to_zero_saved_endpoint_indices=np.flatnonzero((old>0)&(swe==0)).tolist(),
  meaning='Savedendpoint snowdisappearance includespotentialmelt/sublimation/drainage; not byitself proof of melt-onlyleftoverheat routing.'),
 seconds=time.monotonic()-start,
 scope='Allactual17520EC-CUDAyear/365days/12months and original14officialfields plus allFLUXNETproducts/ownQC, rawbudgets/final23state and cold/finalC-N. Allfailures and unmeasuredretained, no bestvariant/day/month/parameter selection, no currentFL/fullsameprecision/spinup/SOC/multisiteyear/holdout/calibration or release claim.')
(r/'summary.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
(r/'receipt.json').write_text(json.dumps(dict(pbs_job=value['pbs_job'],node=value['node'],passed=True,source_unchanged=value['source_unchanged'],summary_sha256=sha(r/'summary.json'),source_manifest_sha256=value['source_manifest_sha256'],source_steps=n),indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k not in ['official14fields','fluxnet_original_own_qc_instantaneous']}),flush=True)
for name,row in fields.items():print(json.dumps(dict(field=name,metrics=row)),flush=True)
assert value['source_unchanged']

from pathlib import Path
import hashlib,json,re,subprocess,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');label=sys.argv[1];assert label in ['capacity','capacity_optics'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
roots=[(b/('qia-phase-'+label+'-cuda-year-evaluation-ih'),'evaluation'),(b/('qia-phase-'+label+'-cuda-year-summary-im'),'summary')]
proof=[]
for r,prefix in roots:
 launch=json.loads((r/'dispatch.json').read_text());job=launch['pbs_job'];raw=subprocess.check_output(['qstat','-xf',job],text=True)
 assert re.search(r'^\s*job_state = F\s*$',raw,re.M) and re.search(r'^\s*Exit_status = 0\s*$',raw,re.M) and (r/'pbs-exit.txt').read_text().strip()=='0'
 (r/'actual-pbs-qstat.txt').write_text(raw);d=json.loads((r/'receipt.json').read_text());assert d.get('passed',d.get('evaluation_delivered')) and d['source_unchanged']
 assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items());proof.append(dict(job=job,actual_pbs_exit=0,receipt_sha256=sha(r/'receipt.json')))
r=roots[1][0];d=json.loads((r/'summary.json').read_text());assert d['model_complete_steps']==17520 and len(d['official14fields'])==14 and all(q['complete_days']==365 and q['complete_months']==12 for q in d['official14fields'].values())
assert d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
archive=b/('phase-cuda-year-'+label+'-in-evidence.tar.gz');assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
 for folder,prefix in roots:
  for p in sorted(folder.rglob('*')):
   if p.is_file():
    assert not p.is_symlink();name=prefix+'/'+p.relative_to(folder).as_posix();inventory[name]=sha(p);tf.add(p,arcname=name,recursive=False)
 for p,name in [(b/('qia-phase-'+label+'-cuda-year-ig-export.tar.gz'),'original-complete-native-year.tar.gz'),(b/'ctsm-qia-run-r/official-year-fields.npz','official-reference/official-year-fields.npz'),(b/'ctsm-qia-run-r/year-boundary.json','official-reference/year-boundary.json'),(b/'clm-phase-descent-ec-source.tar.gz','frozen-source/clm-phase-descent-ec-source.tar.gz')]:
  inventory[name]=sha(p);tf.add(p,arcname=name,recursive=False)
 for name in ['prepare_phase_cuda_year_ih.py','prepare_phase_cuda_year_summary_im.py',Path(__file__).name]:inventory[name]=sha(b/name);tf.add(b/name,arcname=name,recursive=False)
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(inventory)
 for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(archive=archive.name,sha256=sha(archive),artifacts=len(inventory),bytes=archive.stat().st_size,actual_completed_jobs=proof,source_manifest_sha256=d['source_manifest_sha256'],source_steps=17520,
 scope='ActualoriginalEC-CUDAyearparent0/barrier and independentEHPC1175/1176F0, all365days12months14CTSMfields+FLUXNET allproducts/ownQC and originalstep/cumulativeledgers/final23state. Entirecold/finalstate/fulltrace/referencefields/frozenECsource+realstaticIGfailure/ILfix retained. Scientificfailures/SOCcoldtransient kept, no currentFL/fullsameprecision/spinup/multisite/multiyear/holdout/calibration/release claim.')
(b/('phase-cuda-year-'+label+'-in-package.json')).write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

"""Use exact NumPy results from own-source PBS442; preserve original tests."""
from pathlib import Path
import copy,hashlib,json,pickle,runpy,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'soil-stress-coupled-fl-gpu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());ref=r/'reference-evidence';proof=json.loads((ref/'reference-receipt.json').read_text());full=json.loads((ref/'full-receipt.json').read_text());assert (ref/'pbs-exit.txt').read_text().strip()=='0' and proof['source_unchanged'] and proof['keys']==64 and proof['source_manifest_sha256']==full['source_manifest_sha256']==meta['manifest_sha256']==sha(s/'SOURCE_SHA256.json');assert full['returncode']==0 and full['counts']==dict(tests=1148,failures=0,errors=0,skipped=0);assert sha(ref/'references.pkl')==proof['reference_pickle_sha256'] and sha(r/'column_water_stress_key_fl.py')==proof['key_helper_sha256'];sys.path.insert(0,str(r))
from column_water_stress_key_fl import key
cache=pickle.loads((ref/'references.pkl').read_bytes());assert len(cache)==64;file=Path(sys.argv[sys.argv.index('--test-file')+1]).stem
def lookup(family,row,forcing,deposition):
    signature=key(family,row,forcing,deposition);assert signature in cache,(family,signature)
    with (r/(file+'-reference-requests.jsonl')).open('a') as f:f.write(json.dumps(dict(family=family,key=signature))+'\n')
    return copy.deepcopy(cache[signature])
def blocked(*args,**kwargs):raise AssertionError('NumPy forward physics is frozen from own-source EHPC442; no fallback on GPUhost')
if file=='test_gpu_clm_enthalpy_column':
    import test_gpu_clm_enthalpy_column as module
    module.reference=lambda row,f,dep:lookup('enthalpy',row,f,dep);module.step_clm_enthalpy_column=blocked
elif file=='test_gpu_clm_layered_column':
    import test_gpu_clm_layered_column as module
    module.reference=lambda row,f,dep:lookup('layered',row,f,dep);module.step_clm_enthalpy_column=blocked
else:assert file=='test_gpu_clm_water_stress'
import noahmp_clm.clm_enthalpy_driver as driver
import noahmp_clm.physics.clm_water_stress as physics
driver.step_clm_enthalpy_column=blocked;physics.soil_water_stress=blocked
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';runpy.run_path(str(worker),run_name='__main__')

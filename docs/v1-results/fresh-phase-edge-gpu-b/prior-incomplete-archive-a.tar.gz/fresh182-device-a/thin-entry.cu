
extern "C" __global__ void probe_qia182_phase(const float* leaf,const float* u,const float* f,const float* soil,const float* stem,const float* c,const float* b,const float* rad,const float* p,const float* extension,float* out) {
    if(blockIdx.x*blockDim.x+threadIdx.x==0){PhaseContext v;phase_prepare(leaf,u,f,soil,stem,c,b,p,rad,v);v.water_velocity=extension[0];v.heat_temperature=extension[1];phase_solve(v,out,100,.005f);}
}

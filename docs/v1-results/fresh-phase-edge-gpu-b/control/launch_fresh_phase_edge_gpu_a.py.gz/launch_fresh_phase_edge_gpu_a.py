from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-fresh-phase-edge-a'
assert not s.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(a) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
s.mkdir()
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 510 and all(sha(s / n) == v for n, v in m.items())
r = s / 'target-a'
r.mkdir()
prefix = 'test_gpu_canopy_phase_energy.py::'
nodes = [prefix + 'test_humidity_bound_restart_closes_original_coupled_equations[' + n + ']' for n in ['canopy_phase_humidity_bound.json', 'canopy_phase_humidity_slow.json']]
nodes += [prefix + 'test_phase_native_reference[' + n + ']' for n in ['float64', 'float32']]
nodes += [prefix + 'test_phase_input_contract', prefix + 'test_phase_cuda_same_precision']
nodes += [prefix + 'test_saved_float64_jacobian_closes_original_phase_equations[' + n + ']' for n in ['Qia479-supply', 'existing-phase-edge']]
(r / 'expected.json').write_text(json.dumps(nodes, indent=2) + '\n')
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='0', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_COMPILATION_CACHE_DIR=str(b / 'jax-surface-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NOAHMP_REQUIRE_GPU='1')
controller = b / 'control_fresh_phase_edge_gpu_a.py'
with (r / 'controller.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(controller)], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
record = dict(scope='Actual targeted phase component8 launch on xuanze GPU0; original strict real-day/annual/oldfull jobs retained. Does not certify test completion or fullGPU340.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=p.pid, device=0, source_files=510, source_archive_sha256=sha(a), source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), controller_sha256=sha(controller), expected_nodes=nodes)
(r / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

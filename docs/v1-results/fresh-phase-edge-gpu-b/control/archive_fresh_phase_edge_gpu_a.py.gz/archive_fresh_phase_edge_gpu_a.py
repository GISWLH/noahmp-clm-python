from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-fresh-phase-edge-a';a=b/'fresh-phase-edge-gpu-a-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((s/'target-a/exit.json').read_text())['passed'] and json.loads((s/'target-a/exit.json').read_text())['returncode']==0
assert json.loads((s/'fresh182-device-controller-a/exit.json').read_text())['actual_returncode']==0
d=json.loads((s/'fresh182-device-a/receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and d['device_barriers_complete'] and d['results']['same_precision']['maximum_absolute_difference']==0.
with tarfile.open(a,'w:gz') as t:
    for name in ['target-a','fresh182-device-a','fresh182-device-controller-a']:
        for p in sorted((s/name).rglob('*')):
            if p.is_file():t.add(p,arcname=name+'/'+p.relative_to(s/name).as_posix(),recursive=False)
    for n in ['SOURCE_SHA256.json','launch.json','fresh182-device-launch-a.json']:t.add(s/n,arcname=n,recursive=False)
    for n in ['launch_fresh_phase_edge_gpu_a.py','control_fresh_phase_edge_gpu_a.py','probe_fresh_phase_edge_device_a.py','launch_fresh_phase_edge_device_a.py','start_fresh_phase_edge_device_a.py','archive_fresh_phase_edge_gpu_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
    for p in sorted((b/'qia182-device-input-a').iterdir()):
        if p.is_file():t.add(p,arcname='reference-packet/'+p.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Actual510 source GPUphase8 stages/barriers/worker/controller0 plus exact182 extended boundary thin originalCUDA function/JAX32/64. All300raw32 maxdiff0,originalnativeGPU100/.005 and64tol1e-7,original parcel guards. NumPy reference onEHPC,no currentfullGPU340 or science/year credit. Atexit bypass explicit after barriers/receipts.')))

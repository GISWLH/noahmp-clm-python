"""Actual182 phase component on GPU; NumPy references computed on EHPC."""
from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-fresh-phase-edge-a';r=s/'fresh182-device-a';r.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==510 and all(sha(s/n)==v for n,v in m.items())
sys.path[:0]=[str(s),str(s/'src'),str(s/'tests')]
binding=json.loads((b/'qia182-device-input-a/receipt.json').read_text());input_file=b/'qia182-device-input-a/input.npz';assert sha(input_file)==binding['input_sha256'] and binding['source_unchanged'] and binding['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
with np.load(input_file,allow_pickle=False) as z:packet=dict(z)
import cupy as cp
import jax
import jax.numpy as j
from noahmp_clm.gpu.canopy_phase_energy import phase_energy_kernel_jax,unpack_phase,validate_phase
from noahmp_clm.gpu.snicar import _jax_tables
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as radiation_kernel
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.canopy_boundary import radiation_inputs

start=time.monotonic();results={};raws={};failure=None


def save(label,raw,precision):
    assert np.all(np.isfinite(raw));raws[label]=raw
    out=unpack_phase(raw);tol=.005 if precision=='32' else 1e-7
    assert np.all(out['converged']) and np.max(abs(out['layer_residual']))<=tol*1.05
    differences={}
    for key in ('leaf_temperature','ground_temperature','canopy_temperature','h','le','gpp','ground_heat'):
        actual=out[key][0];ref=packet['reference'+precision+'_'+key]
        differences[key]=float(np.max(abs(actual-ref)))
        if 'temperature' in key:np.testing.assert_allclose(actual,ref,rtol=0.,atol=.05)
        else:
            absolute=.01 if key=='gpp' else 1.;near=.1 if key=='gpp' else 10.
            assert np.all(abs(actual-ref)<=np.where(abs(ref)<=near,absolute,.1*abs(ref)))
    c=packet['a'+precision+'_5'];dt=packet['a'+precision+'_6'][4];dtype=np.float32 if precision=='32' else np.float64
    water=out['mass'][0]-c[:,0]+dt*out['wet_evaporation'][0]
    heat=out['enthalpy'][0]-c[:,1]+out['vapor_enthalpy'][0]-(out['thermal_enthalpy'][0]-c[:,1])
    magnitude=abs(out['enthalpy'][0])+abs(c[:,1])+abs(out['vapor_enthalpy'][0])+abs(out['thermal_enthalpy'][0])
    assert np.all(abs(water)<=64*np.finfo(dtype).eps*np.maximum(c[:,0],1.)+1e-12)
    assert np.all(abs(heat)<=64*np.finfo(dtype).eps*np.maximum(magnitude,1.)+1e-6)
    np.savez_compressed(r/(label+'-raw.npz'),raw=raw)
    results[label]=dict(iterations=out['iterations'].tolist(),max_solver_residual=out['max_solver_residual'].tolist(),science_maximum_absolute_differences=differences,maximum_water_residual_kgm2=float(np.max(abs(water))),maximum_parcel_heat_residual_jm2=float(np.max(abs(heat))))
    return out


try:
    arrays=tuple(cp.ascontiguousarray(cp.asarray(packet['a32_'+str(i)][None,...],dtype=cp.int32 if i==8 else cp.float32)) for i in range(9));validate_phase(arrays,cp)
    leaf,u,f,soil,stem,c,ground,snow,count=arrays
    area=cp.ascontiguousarray(leaf+stem);ru=cp.ascontiguousarray(radiation_inputs(area,u,cp));rad=cp.empty((1,584),cp.float32)
    radiation_kernel(True)((1,),(32,),(area,snow,count,ru,*_tables(),rad,np.int32(1)))
    files=['leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu']
    code='\n'.join((s/'src/noahmp_clm/gpu/cuda'/name).read_text() for name in files)
    thin='''\nextern "C" __global__ void probe_qia182_phase(const float* leaf,const float* u,const float* f,const float* soil,const float* stem,const float* c,const float* b,const float* rad,const float* p,const float* extension,float* out) {
    if(blockIdx.x*blockDim.x+threadIdx.x==0){PhaseContext v;phase_prepare(leaf,u,f,soil,stem,c,b,p,rad,v);v.water_velocity=extension[0];v.heat_temperature=extension[1];phase_solve(v,out,100,.005f);}
}\n'''
    module=cp.RawModule(code=code+thin,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('probe_qia182_phase',))
    p=cp.asarray(packet['parameters32']);ext=cp.asarray(packet['extension32']);out=cp.empty((1,300),cp.float32)
    module.get_function('probe_qia182_phase')((1,),(32,),(leaf,u,f,soil,stem,c,ground,rad,p,ext,out))
    cu=save('cuda32',cp.asnumpy(out),'32')
    for i,value in enumerate(arrays):np.testing.assert_array_equal(cp.asnumpy(value),packet['a32_'+str(i)][None,...])
    (r/'thin-entry.cu').write_text(thin)
    for precision,dtype,tolerance in [('32',j.float32,.005),('64',j.float64,1e-7)]:
        arrays_j=tuple(j.asarray(packet['a'+precision+'_'+str(i)],dtype=j.int32 if i==8 else dtype) for i in range(9))
        parameters=j.asarray(packet['parameters'+precision]);extension=j.asarray(packet['extension'+precision]);ice,impurity=_jax_tables('float'+precision)
        fn=jax.jit(lambda *a:phase_energy_kernel_jax(*a,parameters,ice,impurity,exchange_extension=extension,max_iterations=100,tolerance=tolerance))
        raw=np.asarray(fn(*arrays_j))[None,:];ja=save('jax'+precision,raw,precision)
        if precision=='32':
            np.testing.assert_allclose(raw,raws['cuda32'],rtol=1e-6,atol=1e-6)
            for key,value in cu.items():
                if not isinstance(value,dict) and np.asarray(value).dtype.kind in 'biu':np.testing.assert_array_equal(value,ja[key])
            results['same_precision']=dict(raw_fields=300,maximum_absolute_difference=float(np.max(abs(raw.astype(float)-raws['cuda32'].astype(float)))),rtol=1e-6,atol=1e-6,integer_fields_exact=True)
except Exception as e:
    failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
jax.effects_barrier();cp.cuda.runtime.deviceSynchronize()
unchanged=all(sha(s/n)==v for n,v in m.items());assert unchanged and sha(input_file)==binding['input_sha256']
record=dict(scope='Actual saved182 phase boundary and preserved MOST extension. CUDA thin entry invokes unchanged production phase_prepare/phase_solve;no physics copied/replaced. Native originalGPU100/.005 and JAX64 original1e-7 controls,all300raw1e-6 and original parcel guards. NumPy references computed on EHPC. Not a climate/year/canonical-node/science pass. Atexit bypass only after barriers and receipt.',source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(input_file),device_barriers_complete=True,failure=failure,results=results,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True);sys.stdout.flush();os._exit(0 if failure is None else 1)

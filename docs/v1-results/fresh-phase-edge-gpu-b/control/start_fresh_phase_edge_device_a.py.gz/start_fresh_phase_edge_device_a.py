from pathlib import Path
import datetime,json,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-fresh-phase-edge-a';record=s/'fresh182-device-launch-a.json';assert not record.exists()
with (s/'fresh182-device-controller-a.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'launch_fresh_phase_edge_device_a.py')],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Exact182 saved phase component on GPU0,NumPy references on EHPC;300raw1e-6/no solver budget changes,no current year mutation.');record.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import datetime,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-fresh-phase-edge-a';r=s/'fresh182-device-controller-a';r.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
with (r/'worker.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-u',str(b/'probe_fresh_phase_edge_device_a.py')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n');code=p.wait()
(r/'exit.json').write_text(json.dumps(dict(actual_returncode=code))+'\n');raise SystemExit(code)

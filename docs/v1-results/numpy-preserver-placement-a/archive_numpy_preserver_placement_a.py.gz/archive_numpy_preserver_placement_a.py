from pathlib import Path
import hashlib,io,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'fluxnet-numpy-current-first-year-a';names=[(root/'snapshot-preserver-placement-a.json','placement.json'),(base/'adjust_numpy_preserver_placement_a.py','adjust_numpy_preserver_placement_a.py'),(root/'snapshots/preserver-launch.json','actual-node-launch.json'),(Path(__file__),Path(__file__).name)];dest=base/'numpy-preserver-placement-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for p,n in names:t.add(p,arcname=n,recursive=False)
print(json.dumps(dict(files=len(names),path=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest())))

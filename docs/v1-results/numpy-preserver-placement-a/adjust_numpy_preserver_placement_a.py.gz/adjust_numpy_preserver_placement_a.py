from pathlib import Path
import datetime,json,subprocess
root=Path('/home/zhangyq/noahmp-v1/fluxnet-numpy-current-first-year-a')
command=['qalter','-l','select=1:vnode=compute002:ncpus=1:mem=512mb','123.manager'];p=subprocess.run(command,text=True,capture_output=True)
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Queued checkpoint preserver scheduler placement only. Original host=compute002 could never run because host resource uses generated name compute002_00260924; use observed original121 vnode=compute002. No source/physics job restarted.',command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
(root/'snapshot-preserver-placement-a.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(p.returncode)

"""Read only this task's scheduler/controller files, with actual absence recorded."""
from pathlib import Path
import base64
import hashlib
import json
import socket
import subprocess
from datetime import datetime, timezone

ROOTS = {'1604.manager': '/tmp/noahmp-numpy-training-chain-pb',
         '1607.manager': '/tmp/noahmp-numpy-training-chain-pb-b',
         '1611.manager': '/tmp/noahmp-numpy-training-chain-pb-closure',
         '1612.manager': '/tmp/noahmp-numpy-training-chain-pb-closure-b'}


def main():
    node = socket.gethostname()
    assert node in ('manager', 'compute002')
    rows = []
    for job, folder in ROOTS.items():
        names = ['dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'qsub-actual-exit.json',
                 'qsub-exit.txt', 'compute-extract.stdout.txt', 'compute-extract.stderr.txt',
                 'compute-file-hashes.txt', 'pbs-output.log'] if node == 'manager' else ['pbs-exit.txt']
        for name in names:
            path = Path(folder) / name
            row = dict(job=job, path=str(path), name=name, present=path.is_file())
            if path.is_file():
                raw = path.read_bytes()
                row.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                           base64=base64.b64encode(raw).decode())
            rows.append(row)
        if node == 'manager':
            proc = subprocess.run(['qstat', '-xf', job], capture_output=True)
            for kind, raw in [('stdout', proc.stdout), ('stderr', proc.stderr)]:
                rows.append(dict(job=job, name='qstat.' + kind + '.txt', present=True,
                     path='qstat -xf ' + job, actual_exit=proc.returncode, bytes=len(raw),
                     sha256=hashlib.sha256(raw).hexdigest(), base64=base64.b64encode(raw).decode()))
    print(json.dumps(dict(node=node, sampled_utc=datetime.now(timezone.utc).isoformat(), rows=rows)))


if __name__ == '__main__':
    main()

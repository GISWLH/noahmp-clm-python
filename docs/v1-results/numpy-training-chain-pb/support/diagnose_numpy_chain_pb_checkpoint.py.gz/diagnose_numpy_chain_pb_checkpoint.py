"""Read-only EHPC zero-step serialization diagnosis; no tendency calls."""
import dataclasses
from enum import Enum
import hashlib
import importlib.util
import json
from pathlib import Path
import pickle
import pickletools
import socket
import struct
import sys
import tarfile
import tempfile

BASE = Path('/tmp/noahmp-numpy-training-chain-pb')
assert socket.gethostname() == 'compute002'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
archive = BASE / 'result.tar.gz'
assert sha(archive.read_bytes()) == '6684a19e06c88d028db0e607ece899341fbc9a618ce4b6d3487e5ec67a5d0b9b'
with tarfile.open(archive, 'r:gz') as t:
    original = t.extractfile('./short-model-output/cold/segment-0000000/start-originals/state-0000000.pkl').read()
    config_raw = t.extractfile('./short-model-output/original-config.json').read()
    failed_receipt = json.loads(t.extractfile('./short-model-output/cold/segment-0000000/receipt.json').read())
assert failed_receipt['successful_tendency_calls'] == 0
assert sha(config_raw) == 'f563ee83604aa1af471260bf4bbd416603d5ed3abb4d4982b6b0022d408b0dbc'
source_archive = BASE / 'inputs/climatology-final-candidate-nm-source.tar.gz'
assert sha(source_archive.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tempfile.TemporaryDirectory(prefix='pb-zero-diagnosis-', dir='/tmp') as temp:
    source = Path(temp)
    with tarfile.open(source_archive, 'r:gz') as t:
        manifest_raw = t.extractfile('SOURCE_SHA256.json').read()
        assert sha(manifest_raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
        manifest = json.loads(manifest_raw)
        assert len(manifest) == 584
        for name, digest in manifest.items():
            raw = t.extractfile(name).read()
            assert sha(raw) == digest and '..' not in Path(name).parts
            target = source / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
    sys.path[:0] = [str(source / 'src'), str(source / 'benchmarks')]
    spec = importlib.util.spec_from_file_location('pb_zero_original', source / 'benchmarks/run_fluxnet_column.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    np = runner.np
    live = runner.build_state(json.loads(config_raw))
    saved = pickle.loads(original)[0]
    mismatches, arrays, scalar_paths, types = [], [], [], []
    alias = {'live_arrays': {}, 'loaded_arrays': {}, 'live_dtypes': {}, 'loaded_dtypes': {}}

    def walk(x, y, path):
        types.append((path, type(x).__module__ + '.' + type(x).__qualname__))
        if type(x) is not type(y):
            mismatches.append(dict(path=path, reason='type')); return
        if isinstance(x, np.ndarray):
            info = dict(path=path, dtype=x.dtype.str, shape=list(x.shape), strides=list(x.strides),
                        loaded_strides=list(y.strides), live_flags=str(x.flags), loaded_flags=str(y.flags),
                        bytes_sha256=sha(x.tobytes()), loaded_bytes_sha256=sha(y.tobytes()),
                        dtype_equal=x.dtype == y.dtype, descriptor_equal=x.dtype.descr == y.dtype.descr,
                        shape_equal=x.shape == y.shape, strides_equal=x.strides == y.strides,
                        flags_equal=str(x.flags) == str(y.flags), bytes_exact=x.tobytes() == y.tobytes())
            arrays.append(info)
            for label, obj in [('live_arrays', x), ('loaded_arrays', y), ('live_dtypes', x.dtype), ('loaded_dtypes', y.dtype)]:
                alias[label].setdefault(id(obj), []).append(path)
            if not all(info[k] for k in ('dtype_equal', 'descriptor_equal', 'shape_equal', 'strides_equal', 'flags_equal', 'bytes_exact')):
                mismatches.append(dict(path=path, reason='array_content_or_metadata'))
        elif dataclasses.is_dataclass(x):
            for field in dataclasses.fields(x):
                walk(getattr(x, field.name), getattr(y, field.name), path + '.' + field.name)
        elif isinstance(x, dict):
            if list(x) != list(y): mismatches.append(dict(path=path, reason='dictionary_keys'))
            for key in x:
                walk(x[key], y[key], path + '[' + repr(key) + ']')
        elif isinstance(x, (tuple, list)):
            if len(x) != len(y): mismatches.append(dict(path=path, reason='length'))
            for i, (xx, yy) in enumerate(zip(x, y)):
                walk(xx, yy, path + '[' + str(i) + ']')
        else:
            scalar_paths.append(path)
            if isinstance(x, float): equal = struct.pack('!d', x) == struct.pack('!d', y)
            elif isinstance(x, np.generic): equal = x.dtype == y.dtype and x.tobytes() == y.tobytes()
            elif isinstance(x, Enum): equal = x.name == y.name and x.value == y.value
            else: equal = x == y
            if not equal: mismatches.append(dict(path=path, reason='scalar'))

    walk(live, saved, 'state')
    a, b = pickle.dumps(live, protocol=5), pickle.dumps(saved, protocol=5)
    ops_a = [(op.name, repr(arg)[:120]) for op, arg, pos in pickletools.genops(a)]
    ops_b = [(op.name, repr(arg)[:120]) for op, arg, pos in pickletools.genops(b)]
    differences = [(i, x, y) for i, (x, y) in enumerate(zip(ops_a, ops_b)) if x != y]
    groups = {key: sorted(sorted(v) for v in values.values()) for key, values in alias.items()}
    assert all(sha((source / n).read_bytes()) == h for n, h in manifest.items())
    content_equal = all(all(v[k] for k in ('dtype_equal', 'descriptor_equal', 'shape_equal', 'bytes_exact')) for v in arrays)
    content_equal = content_equal and all(v['reason'] == 'array_content_or_metadata' for v in mismatches)
    print(json.dumps(dict(passed=content_equal, serialization_metadata_exact=not mismatches,
        source_manifest_sha256=sha(manifest_raw), source_files=584,
        original_zero_checkpoint_sha256=sha(original), config_sha256=sha(config_raw),
        original_failed_tendency_calls=0, diagnostic_tendency_calls=0, actual_years=0,
        reconstructed_live_protocol5_sha256=sha(a), loaded_protocol5_sha256=sha(b),
        pickle_lengths=[len(a), len(b)], pickle_protocol5_equal=a == b,
        array_count=len(arrays), scalar_count=len(scalar_paths), visited_type_count=len(types),
        arrays=arrays, serialization_metadata_mismatches=mismatches,
        max_array_abs_difference=0.0 if content_equal else None,
        array_alias_groups_equal=groups['live_arrays'] == groups['loaded_arrays'],
        dtype_alias_groups_equal=groups['live_dtypes'] == groups['loaded_dtypes'],
        alias_groups=groups, first_opcode_differences=differences[:8],
        scope='Read-only original failed zero-step checkpoint versus freshly reconstructed same fixed configuration. No tendency or candidate execution.'), indent=2))

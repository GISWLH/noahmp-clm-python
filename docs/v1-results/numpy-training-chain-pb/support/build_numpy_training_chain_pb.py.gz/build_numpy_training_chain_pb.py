"""Freeze PB metadata and perform stdlib AST/byte checks; never import numerics."""
import ast
from datetime import datetime
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/v1'
PREP = OUT / 'numpy-training-chain-pb-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def archive(name, digest):
    path = OUT / name
    assert sha(path.read_bytes()) == digest
    with tarfile.open(path, 'r:gz') as t:
        answer = {}
        for m in t.getmembers():
            assert m.isfile() and m.name not in answer and '..' not in Path(m.name).parts
            answer[m.name] = t.extractfile(m).read()
    return answer


om_hash = '1581110dab18462127cb4baf54eef327de9bfd15eb3da72d3dc01670512ba7ac'
ou_hash = 'e47b2fec32c435323b4ed3ab759085e470b18bb1f4f12bb902354a4697ac2a73'
nm_hash = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
manifest_hash = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
om = archive('fluxnet-calibration-om-evidence.tar.gz', om_hash)
ou = archive('fluxnet-training-years-ou-evidence.tar.gz', ou_hash)
nm = archive('climatology-final-candidate-nm-source.tar.gz', nm_hash)
assert sha(nm['SOURCE_SHA256.json']) == manifest_hash
source = json.loads(nm['SOURCE_SHA256.json'])
assert len(source) == 584 and set(nm) == set(source) | {'SOURCE_SHA256.json'}
assert all(sha(nm[n]) == h for n, h in source.items())
index = json.loads(om['result/applied-index.json'])
refs = json.loads(ou['current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json'])
years = json.loads(ou['current/prepared-inputs/YEAR_IDENTITIES.json'])
plan = json.loads(om['result/candidate-plan.json'])
configurations = []
for ref in refs['original_OM_applied_configurations']:
    row = next(r for r in index if (r['candidate'], r['case']) == (ref['candidate'], ref['case']))
    raw = om[ref['original_OM_member']]
    config = json.loads(raw)
    assert sha(raw) == row['output_sha256'] == ref['candidate_config_sha256']
    assert (config['case'], config['site']) == (ref['case'], ref['site'])
    configurations.append(dict(candidate=ref['candidate'], case=ref['case'], site=ref['site'],
                               configuration_sha256=sha(raw), first_year=ref['first_year'],
                               second_year=ref['second_year'], OM_member=ref['original_OM_member']))
assert len(configurations) == len({(r['candidate'], r['case']) for r in configurations}) == 184
yr = []
for row in years['rows']:
    n = row['year']
    assert row['complete_calendar'] and row['original_validate_input_succeeded']
    assert row['steps'] == (datetime(n + 1, 1, 1) - datetime(n, 1, 1)).total_seconds() // 1800
    for k, h in [('npz', 'npz_sha256'), ('metadata', 'metadata_sha256')]:
        assert sha(ou['current/prepared-inputs/' + row[k]]) == row[h]
    yr.append({**{k: row[k] for k in ('site', 'year', 'steps', 'npz', 'npz_sha256', 'metadata', 'metadata_sha256')},
               'first': f'{n}01010000', 'stop': f'{n+1}01010000'})
assert len(yr) == 4
identities = dict(candidate_order=[r['id'] for r in plan['first_batch'] + plan['second_batch']],
                  configurations=configurations, years=yr,
                  OM_archive_sha256=om_hash, OU_archive_sha256=ou_hash)
dump(PREP / 'IDENTITIES.json', identities)
original_runner = nm['benchmarks/run_fluxnet_column.py']
assert original_runner == (ROOT / 'benchmarks/run_fluxnet_column.py').read_bytes()
(PREP / 'original-run_fluxnet_column.py').write_bytes(original_runner)
fixed = dict(production_launch_allowed=False, initialization_and_spinup_contract_sealed=False,
             uniform_candidate_backend='numpy64', final_selected_validation_backend='CUDA1',
             candidates=23, independent_roots_per_candidate=8,
             identities_sha256=sha((PREP / 'IDENTITIES.json').read_bytes()),
             source=dict(archive='climatology-final-candidate-nm-source.tar.gz', archive_sha256=nm_hash,
                         manifest_sha256=manifest_hash, files=584,
                         runner_sha256=sha(original_runner)),
             original_HP_control_sha256=sha((OUT / 'run_climatology_numpy_cycle_hp.py').read_bytes()),
             OM_archive_sha256=om_hash, OU_archive_sha256=ou_hash,
             scope='Single CPU chain carry/capture preparation; no scheduler, seed certification or OO scoring adapter.')
dump(PREP / 'BINDINGS.json', fixed)
trees = {p.name: ast.parse(p.read_text(encoding='utf-8')) for p in PREP.glob('*.py')}
test_count = sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_')
                 for n in ast.walk(trees['test_numpy_chain_pb.py']))
unchanged = {}
for n in ast.walk(trees['original-run_fluxnet_column.py']):
    if isinstance(n, ast.FunctionDef) and n.name in ('run', 'audit_step', 'totals', 'build_state', 'validate_input'):
        unchanged[n.name] = sha(ast.dump(n, include_attributes=False).encode())
files = sorted(p for p in PREP.iterdir() if p.is_file() and p.name != 'CONTROLS_SHA256.json')
dump(PREP / 'CONTROLS_SHA256.json', {p.name: sha(p.read_bytes()) for p in files})
dump(OUT / 'numpy-training-chain-pb-static.json', dict(
    passed=True, controls=len(files), controls_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()),
    test_methods=test_count, source_files=584, source_verified_byteexact=True,
    original_runner_byteexact=True, unchanged_original_function_ast=unchanged,
    model_executed=False, numpy_imported=False, tests_executed=False,
    production_launch_allowed=False, numerical_validation_pending=True))
print(json.dumps(dict(passed=True, controls=len(files), test_methods=test_count,
                      manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()))))

"""Freeze PB execution stage using the final independent review; stdlib only."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'numpy-training-chain-pb-preparation'
EXEC = OUT / 'numpy-training-chain-pb-execution'
EXPECTED = '165913db4fd39f10c47d174b74c42f8f877216c347fe46535489c5ecc013e7be'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


prep_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
assert sha(prep_raw) == EXPECTED
prep = json.loads(prep_raw)
assert len(prep) == 7 and all(sha((PREP / n).read_bytes()) == h for n, h in prep.items())
review_raw = (OUT / 'numpy-training-chain-pb-comparator-independent-review-wo.json').read_bytes()
review = json.loads(review_raw)
assert review['passed'] is True and review['blocking_findings'] == [] and review['controls'] == 7
assert review['controls_manifest_sha256'] == EXPECTED
fixed = json.loads((PREP / 'BINDINGS.json').read_bytes())
dump(EXEC / 'RUN_BINDINGS.json', dict(authorized=True, expected_tests=19, expected_original_tendencies=10,
     preparation_manifest_sha256=EXPECTED, independent_review_sha256=sha(review_raw),
     source_manifest_sha256=fixed['source']['manifest_sha256'],
     source_archive_sha256=fixed['source']['archive_sha256'], production_launch_allowed=False,
     scope='Root authorized one EHPC1CPU/2GiB/10min short test job after static review; no annual/candidate run.'))
controls = {name: sha((EXEC / name).read_bytes()) for name in
            ['run_tests_pb.py', 'dispatch_tests_pb.py', 'tests_pb.pbs', 'RUN_BINDINGS.json']}
dump(EXEC / 'CONTROLS_SHA256.json', controls)
for name in controls:
    if name.endswith('.py'):
        ast.parse((EXEC / name).read_bytes())
lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(EXEC), str(Path(__file__))],
                      capture_output=True, text=True)
assert lint.returncode == 0, lint.stdout + lint.stderr
files = {'preparation/' + n: (PREP / n).read_bytes() for n in [*prep, 'CONTROLS_SHA256.json']}
files.update({'execution/' + n: (EXEC / n).read_bytes() for n in [*controls, 'CONTROLS_SHA256.json']})
files['independent-review.json'] = review_raw
for name, digest in [('climatology-final-candidate-nm-source.tar.gz', fixed['source']['archive_sha256']),
                     ('fluxnet-calibration-om-evidence.tar.gz', fixed['OM_archive_sha256']),
                     ('fluxnet-training-years-ou-evidence.tar.gz', fixed['OU_archive_sha256'])]:
    raw = (OUT / name).read_bytes()
    assert sha(raw) == digest
    files['inputs/' + name] = raw
index = {n: sha(raw) for n, raw in files.items()}
files['stage-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
target = OUT / 'numpy-training-chain-pb-stage-b.tar.gz'
assert not target.exists(), 'Never replace a frozen attempt'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(target, 'r:gz') as archive:
    restored = {m.name: archive.extractfile(m).read() for m in archive}
assert restored == files
record = dict(stage_archive=target.name, stage_archive_sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
              members=len(files), preparation_manifest_sha256=EXPECTED,
              execution_manifest_sha256=sha((EXEC / 'CONTROLS_SHA256.json').read_bytes()),
              independent_review_sha256=sha(review_raw), stage_inventory=index,
              resource_request='1CPU/2GiB/10min/compute002', AST_passed=True, actual_ruff_exit=lint.returncode,
              model_executed=False, tests_executed=False, submitted=False,
              scope='Prepared short-test stage, not execution evidence.',
              optional_pbs_log='Record actual presence of pbs-output.log; do not invent empty scheduler logs.')
dump(OUT / 'numpy-training-chain-pb-execution-preparation-b.json', record)
print(json.dumps({k: record[k] for k in ('stage_archive', 'stage_archive_sha256', 'bytes', 'members',
                                        'execution_manifest_sha256', 'independent_review_sha256')}))

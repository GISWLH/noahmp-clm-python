"""Stdlib-only flat PB evidence assembly; never deserialize numerical arrays."""
from pathlib import Path
import ast
import hashlib
import io
import json
import re
import tarfile

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    data, archives = {}, []

    def add(name, raw):
        assert name not in data and '..' not in Path(name).parts and not Path(name).is_absolute()
        data[name] = raw

    def unpack(filename, prefix, expected=None, skip_inputs=False):
        path = BASE / filename
        digest = sha(path.read_bytes())
        if expected:
            assert digest == expected
        member_index, excluded = {}, {}
        with tarfile.open(path) as archive:
            for member in archive.getmembers():
                if member.isdir():
                    continue
                assert member.isfile()
                name = member.name.removeprefix('./')
                assert name not in member_index and '..' not in Path(name).parts and not Path(name).is_absolute()
                raw = archive.extractfile(member).read()
                member_index[name] = sha(raw)
                if skip_inputs and name.startswith('inputs/'):
                    excluded[name] = dict(sha256=sha(raw), bytes=len(raw), reason='Unchanged published NM/OM/OU archive; exact hash reference only.')
                else:
                    add(prefix + '/' + name, raw)
        archives.append(dict(original_archive=filename, sha256=digest, bytes=path.stat().st_size,
                             flat_prefix=prefix, members=member_index, excluded_published_inputs=excluded))

    unpack('numpy-training-chain-pb-first-result.tar.gz', 'attempt-1604/result',
           '6684a19e06c88d028db0e607ece899341fbc9a618ce4b6d3487e5ec67a5d0b9b')
    unpack('numpy-training-chain-pb-b-result.tar.gz', 'attempt-1607/result',
           '145732b78e67daad84bc120e197373b28edfd4e182fa6e4836f2b5cfc3e44760')
    unpack('numpy-training-chain-pb-stage.tar.gz', 'attempt-1604/stage',
           '1e661d8a125bd7cba08b6f39b351a275a01e96857b719f5949e0bf1c61d6a6b7', True)
    unpack('numpy-training-chain-pb-stage-b.tar.gz', 'attempt-1607/stage',
           'c619f1871b275b5e3784dcc0e7728706108b9131dbf91afd0ce36bd9dc5a340d', True)
    unpack('numpy-training-chain-pb-closure-first-result.tar.gz', 'readonly-1611/result')
    unpack('numpy-training-chain-pb-closure-b-result.tar.gz', 'readonly-1612/result',
           'c20b773bca493a2437554f54f5fa1ea0833e717a4fac1528695b87fa43ee3961')
    unpack('numpy-training-chain-pb-closure-stage.tar.gz', 'readonly-1611/controls',
           'a53da09a7727ff3e9d1c3fa025437da49d6dee8e392e9979fb2cc96fb98c97f4')
    unpack('numpy-training-chain-pb-closure-b-stage.tar.gz', 'readonly-1612/controls',
           '0ea7f4e23d581d35edc13cc0792e8f1102a9ce4b8908fb62690a22ab6f23b76e')
    with tarfile.open(BASE / 'numpy-training-chain-pb-first-preparation.tar.gz') as t:
        add('attempt-1604/initial-static.json', t.extractfile('static.json').read())
    for path in sorted((BASE / 'numpy-training-chain-pb-actual-all').rglob('*')):
        if path.is_file():
            add('actual/' + path.relative_to(BASE / 'numpy-training-chain-pb-actual-all').as_posix(), path.read_bytes())
    for job, exitcode in [('1604', 1), ('1607', 1), ('1611', 1), ('1612', 0)]:
        qstat = data['actual/manager/' + job + '.manager/qstat.stdout.txt'].decode()
        assert re.search(r'^Job Id: ' + job + r'\.manager$', qstat, re.M)
        for field, value in [('job_state', 'F'), ('Exit_status', str(exitcode)), ('Stageout_status', '0')]:
            assert re.search(r'^\s*' + field + r' = ' + value + '$', qstat, re.M), (job, field)
        assert data['actual/compute002/' + job + '.manager/pbs-exit.txt'].strip() == str(exitcode).encode()
    local_names = [
        'build_numpy_training_chain_pb.py', 'prepare_numpy_training_chain_pb_execution.py',
        'numpy-training-chain-pb-static.json', 'numpy-training-chain-pb-independent-review-wo.json',
        'numpy-training-chain-pb-comparator-independent-review-wo.json',
        'numpy-training-chain-pb-execution-preparation.json', 'numpy-training-chain-pb-execution-preparation-b.json',
        'diagnose_numpy_chain_pb_checkpoint_first.py', 'diagnose_numpy_chain_pb_checkpoint.py',
        'numpy-training-chain-pb-zero-diagnosis.json', 'numpy-training-chain-pb-zero-diagnosis.stderr.txt',
        'numpy-training-chain-pb-zero-diagnosis.exit.txt', 'numpy-training-chain-pb-zero-detail.json',
        'numpy-training-chain-pb-zero-detail.stderr.txt', 'numpy-training-chain-pb-zero-detail.exit.txt',
        'numpy-training-chain-pb-first-upload.json', 'collect_numpy_training_chain_pb_metadata.py',
        'package_numpy_training_chain_pb.py']
    for suffix in ['upload-retry', 'dispatch', 'upload-b', 'dispatch-b', 'closure-upload', 'closure-dispatch',
                   'closure-b-upload', 'closure-b-dispatch']:
        for stream in ('stdout', 'stderr', 'exit'):
            local_names.append('numpy-training-chain-pb-' + suffix + '.' + stream + '.txt')
    for name in local_names:
        raw = (BASE / name).read_bytes()
        if name.endswith('.py'):
            ast.parse(raw)
        add('support/' + name, raw)
    receipt = json.loads(data['readonly-1612/result/receipt.json'])
    assert receipt['passed'] and receipt['test_count'] == 19 and receipt['skipped'] == 0
    assert receipt['actual_original_physical_tendencies'] == 10 and receipt['readonly_closure_tendency_calls'] == 0
    assert receipt['original_pbs_exit'] == receipt['original_wrapper_exit'] == 1
    original_index = json.loads(data['readonly-1612/result/original-result-file-sha256.json'])
    assert len(original_index) == 250 and all(sha(data['attempt-1607/result/' + n]) == h for n, h in original_index.items())
    diagnostics = json.loads(data['readonly-1612/result/quantified-closure.json'])
    assert len(diagnostics['trace_fields']) == 18 and len(diagnostics['three_six_object_carries']) == 3
    source_refs = dict(flat_archive_records=archives,
        source_archive=dict(name='climatology-final-candidate-nm-source.tar.gz',
            sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',
            manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f', files=584),
        OM_published_archive=dict(name='fluxnet-calibration-om-evidence.tar.gz',
            sha256='1581110dab18462127cb4baf54eef327de9bfd15eb3da72d3dc01670512ba7ac'),
        OU_published_archive=dict(name='fluxnet-training-years-ou-evidence.tar.gz',
            sha256='e47b2fec32c435323b4ed3ab759085e470b18bb1f4f12bb902354a4697ac2a73'),
        scope='Every original result member is flat and byteexact; unchanged 584-file source and large OM/OU input archives are referenced by full SHA256, not copied again.')
    add('SOURCE_REFERENCES.json', js(source_refs))
    lines = [
        '# PB NumPy 短接续实际结果', '',
        '数值测试通过，执行包装解析失败，经只读复核闭合。1607 保持真实 F1/Stageout0；其 unittest 子进程实际 0，19 项全部 ok、零 skip，24.514 s。实际原物理调用 10 次：适配器五段共 8 次，加未经修改的原 runner 连续参考 2 次。', '',
        '1612 只读闭合实际 F0/Stageout0，耗时 1.223530804 s；没有重跑 tests 或物理。1604 的原零步序列化比较失败 F1，以及 1611 因 PBS 已清理 1607 TMP 源目录而失败 F1，均完整保留。', '',
        '1604 的 EHPC 诊断表明原 15 数组 dtype/shape/值 bytes、115 标量、alias 图相同；差异仅 pickle roundtrip 后 readonly flags 与五个空数组 strides。仅比较器改为严格类型/字段/dtype/shape/值位与 alias 图检查，原 runner 与物理未改。新增 ULP、正负零、dtype、shape、alias 篡改负例均实际通过。', '',
        '1607 的冷态分段与原连续参考：整个七元组 20 数组和 116 标量逐项相同；18 个轨迹字段（16 数值、2 时间戳）dtype/shape/bytes 全相同，数值最大绝对差 0。三次六对象 carry 各 20 数组、115 标量完全相同，最大绝对差均 0。10 份保存 generation、每段原 zero/start 报告和 checkpoint、首调用 before/forcing/kwargs/after/diagnostics 原件均保留。', '',
        '以下各格为原端点 residual / 原累计数值 bound，顺序是水 M (kg m-2)、热 H (J m-2)、碳 C (gC m-2)、氮 N (gN m-2)。没有使用 10% 容差替代守恒。', '',
        '| 短路径 / 全局步数 | M | H | C | N |',
        '|---|---:|---:|---:|---:|']
    for row in diagnostics['rows']:
        cells = [format(v, '.17g') + ' / ' + format(b, '.17g') for v, b in zip(row['residual_m_h_c_n'], row['bounds_m_h_c_n'])]
        lines.append('| ' + row['trajectory'] + ' / ' + str(row['ledger_steps']) + ' | ' + ' | '.join(cells) + ' |')
    lines += ['', '仅 Cng2007 原 baseline 的两个 2×1800s 窗口用于物理短测；train1/train2 名称在此表示接续逻辑测试，后者是同年紧接两时段，未执行真实跨年。完整常年/闰年及23×8配置身份是元数据测试。未启动正式年度候选或被接受的 spinup，未执行 GPU、OO 评分或留出预测；production_launch_allowed=false。新的排水物理若采用，必须重新绑定源与配置。', '',
              '原独立审阅分别绑定 e03eaf… 初版与 165913… 比较器修订版。原物理执行 receipt 保持失败值，闭合结果不替换它。当前封包一次平铺；完整 NM584 SHA 清单在原结果中，大源包与 OM/OU 原输入压包仅列完整 SHA 引用。PBS 空日志按 actual/manager-metadata.json 记录真实存在或不存在。', '']
    add('RESULTS.md', '\n'.join(lines).encode())
    add('INTEGRITY.json', js({n: sha(b) for n, b in sorted(data.items())}))
    destination = BASE / 'numpy-training-chain-pb-evidence.tar.gz'
    with tarfile.open(destination, 'w:gz') as archive:
        for name, raw in sorted(data.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mtime = 0
            archive.addfile(member, io.BytesIO(raw))
    with tarfile.open(destination) as archive:
        assert len(archive.getnames()) == len(data) and set(archive.getnames()) == set(data)
        assert all(archive.extractfile(n).read() == b for n, b in data.items())
    package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
                   artifacts=len(data), inventory_files=len(data) - 1, passed=True,
                   scientific_short_tests_passed=True, original_test_job='1607.manager',
                   original_test_pbs_state='F', original_test_pbs_exit=1, original_test_worker_exit=1,
                   original_test_child_exit=0, original_test_stageout=0, closure_job='1612.manager',
                   closure_pbs_state='F', closure_pbs_exit=0, closure_worker_exit=0, closure_stageout=0,
                   actual_test_count=19, actual_skipped=0, actual_test_seconds=24.514,
                   original_cpu_tendencies=10, adapter_tendencies=8, untouched_reference_tendencies=2,
                   readonly_closure_tendencies=0, exact_trace_fields=18, exact_six_object_carries=3,
                   max_abs_state_and_numeric_trace_difference=0.0, actual_field_years=0,
                   actual_accepted_spinup=False, GPU_steps=0, production_launch_allowed=False,
                   preparation_manifest_sha256=receipt['preparation_manifest_sha256'],
                   scope='Numerical tests passed; wrapper parsing failed; read-only closure passed. All original failures retained; no formal candidate year/spinup or GPU launch.')
    (BASE / 'numpy-training-chain-pb-package.json').write_bytes(js(package))
    print(json.dumps(package))


if __name__ == '__main__':
    main()

"""One EHPC CPU PBS job: 19 PB tests, bounded original tendencies only."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import os
import re
import resource
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-numpy-training-chain-pb-b')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def process_identity(pid):
    root = Path('/proc') / str(pid)
    raw = (root / 'stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    return dict(pid=pid, start_ticks=int(fields[19]), ppid=int(fields[1]),
                cmdline=(root / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace'))


def main():
    assert sys.version_info >= (3, 10)
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    result = Path(sys.argv[1]).resolve()
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not result.exists()
    result.mkdir()
    began = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
                   executable=sys.executable, numpy_version=importlib.metadata.version('numpy'),
                   actual_worker=process_identity(os.getpid()), passed=False, error=None,
                   test_parent_returncode=None, test_timed_out=False, production_launch_allowed=False,
                   actual_field_years=0, actual_spinup=False, GPU_steps=0,
                   expected_original_cpu_tendencies=10, actual_original_cpu_tendencies=None)
    try:
        stage_inventory = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_inventory.items())
        run = json.loads((STAGE / 'execution/RUN_BINDINGS.json').read_bytes())
        prep_raw = (STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()
        prep = json.loads(prep_raw)
        assert sha(prep_raw) == run['preparation_manifest_sha256'] and len(prep) == 7
        assert all(sha((STAGE / 'preparation' / n).read_bytes()) == h for n, h in prep.items())
        review_raw = (STAGE / 'independent-review.json').read_bytes()
        review = json.loads(review_raw)
        assert sha(review_raw) == run['independent_review_sha256'] and review['passed'] is True
        assert review['blocking_findings'] == [] and review['controls'] == 7
        assert review['controls_manifest_sha256'] == run['preparation_manifest_sha256']
        assert run['authorized'] is True and run['expected_tests'] == 19 and run['expected_original_tendencies'] == 10
        fixed = json.loads((STAGE / 'preparation/BINDINGS.json').read_bytes())
        assert fixed['production_launch_allowed'] is False
        source_path = STAGE / 'inputs' / fixed['source']['archive']
        assert sha(source_path.read_bytes()) == fixed['source']['archive_sha256']
        with tarfile.open(source_path, 'r:gz') as archive:
            members = archive.getmembers()
            assert all(m.isfile() for m in members) and len({m.name for m in members}) == 585
            source_raw = archive.extractfile('SOURCE_SHA256.json').read()
            assert sha(source_raw) == fixed['source']['manifest_sha256']
            source = json.loads(source_raw)
            assert len(source) == 584 and {m.name for m in members} == set(source) | {'SOURCE_SHA256.json'}
            assert all(sha(archive.extractfile(n).read()) == h for n, h in source.items())
            source_root = result.parent / 'source-nm584'
            source_root.mkdir()
            for name in [*source, 'SOURCE_SHA256.json']:
                assert not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name
                path = source_root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.extractfile(name).read())
        execution_raw = (STAGE / 'execution/CONTROLS_SHA256.json').read_bytes()
        execution = json.loads(execution_raw)
        assert all(sha((STAGE / 'execution' / n).read_bytes()) == h for n, h in execution.items())
        for folder, index in [('preparation', prep), ('execution', execution)]:
            target = result / folder
            target.mkdir()
            for name in [*index, 'CONTROLS_SHA256.json']:
                shutil.copyfile(STAGE / folder / name, target / name)
        (result / 'SOURCE_SHA256.json').write_bytes(source_raw)
        (result / 'independent-review.json').write_bytes(review_raw)
        work = result / 'preparation'
        tree = ast.parse((work / 'test_numpy_chain_pb.py').read_bytes())
        tests = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
        assert len(tests) == len(set(tests)) == 19
        env = os.environ.copy()
        env.pop('PYTHONPATH', None)
        env.pop('PYTHONHOME', None)
        env.update(PB_SOURCE=str(source_root), PB_TEST_OUTPUT=str(result / 'short-model-output'),
                   PB_OM_ARCHIVE=str(STAGE / 'inputs/fluxnet-calibration-om-evidence.tar.gz'),
                   PB_OU_ARCHIVE=str(STAGE / 'inputs/fluxnet-training-years-ou-evidence.tar.gz'),
                   PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
        assert sha(Path(env['PB_OM_ARCHIVE']).read_bytes()) == fixed['OM_archive_sha256']
        assert sha(Path(env['PB_OU_ARCHIVE']).read_bytes()) == fixed['OU_archive_sha256']
        command = [sys.executable, '-B', '-m', 'unittest', '-v', 'test_numpy_chain_pb']
        save(result / 'test-command.json', dict(argv=command, cwd=str(work), tests=tests))
        with (result / 'unittest.stdout.txt').open('w') as out, (result / 'unittest.stderr.txt').open('w') as err:
            child = subprocess.Popen(command, cwd=work, env=env, stdout=out, stderr=err)
            receipt['actual_test_process'] = process_identity(child.pid)
            save(result / 'actual-test-process.json', receipt['actual_test_process'])
            try:
                code = child.wait(timeout=480)
            except subprocess.TimeoutExpired:
                receipt['test_timed_out'] = True
                child.kill()  # Only this job's own bounded test subprocess.
                code = child.wait()
        receipt['test_parent_returncode'] = code
        (result / 'unittest-parent-exit.txt').write_text(str(code) + '\n')
        stderr = (result / 'unittest.stderr.txt').read_text()
        count = re.search(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
        assert code == 0 and not receipt['test_timed_out'], stderr
        assert count and int(count.group(1)) == 19 and re.search(r'^OK$', stderr, re.M)
        assert not re.search(r'skipped|expected failure|unexpected success', stderr, re.I)
        assert all(re.search(r'^' + re.escape(name) + r' \(.*\) \.\.\. ok$', stderr, re.M) for name in tests)
        prefix = 'PB_DIAGNOSTIC '
        diagnostics = [json.loads(line[len(prefix):]) for line in (result / 'unittest.stdout.txt').read_text().splitlines()
                       if line.startswith(prefix)]
        assert {r['test'] for r in diagnostics} == {'cold_split_vs_original', 'bounded_chain'}
        exact = next(r for r in diagnostics if r['test'] == 'cold_split_vs_original')
        assert exact['seven_tuple_exact'] and exact['all_trace_fields_exact'] and exact['max_abs_difference'] == 0.
        short = result / 'short-model-output'
        segments = []
        for name in ('cold', 'spinup-cycle', 'train1-cycle', 'train2-continue'):
            for path in sorted((short / name).glob('segment-*/receipt.json')):
                record = json.loads(path.read_bytes())
                assert record['worker_completed'] is True and record['failure'] is None and record['source_unchanged'] is True
                assert record['first_start_exact'] is True and record['identity']['test_only'] is True
                segments.append(dict(path=path.relative_to(result).as_posix(), sha256=sha(path.read_bytes()),
                                     successful_tendency_calls=record['successful_tendency_calls']))
        reference = json.loads((short / 'unmodified-runner-reference/report.json').read_bytes())
        assert reference['status'] == 'complete' and 'failure' not in reference
        assert reference['steps_completed'] == reference['steps_requested'] == 2 and reference['source_unchanged'] is True
        assert sum(r['successful_tendency_calls'] for r in segments) == 8 and len(segments) == 5
        assert all(sha((source_root / n).read_bytes()) == h for n, h in source.items())
        assert all(sha((work / n).read_bytes()) == h for n, h in prep.items())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_inventory.items())
        save(result / 'quantified-short-diagnostics.json', dict(diagnostics=diagnostics, segment_receipts=segments,
              adapter_original_tendencies=8, untouched_reference_tendencies=2, actual_original_cpu_tendencies=10,
              actual_field_years=0, actual_spinup=False, production_launch_allowed=False))
        receipt.update(passed=True, actual_test_count=19, actual_test_seconds=float(count.group(2)),
                       actual_original_cpu_tendencies=10, adapter_tendencies=8, untouched_reference_tendencies=2,
                       source_before_after_584_exact=True, preparation_inputs_unchanged=True,
                       preparation_manifest_sha256=sha(prep_raw), execution_manifest_sha256=sha(execution_raw),
                       source_manifest_sha256=sha(source_raw), independent_review_sha256=sha(review_raw),
                       test_names=tests, quantified_diagnostics_sha256=sha((result / 'quantified-short-diagnostics.json').read_bytes()))
    except Exception as exc:
        receipt['error'] = type(exc).__name__ + ': ' + str(exc)
        (result / 'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic() - began
    receipt['maximum_controller_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    receipt['maximum_child_rss_kib'] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    save(result / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

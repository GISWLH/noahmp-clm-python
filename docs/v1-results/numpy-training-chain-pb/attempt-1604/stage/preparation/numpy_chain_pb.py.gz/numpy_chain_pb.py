"""Minimal NM NumPy carry/capture adapter. Production launch remains disabled.

The original runner, its tendency, audit_step and cumulative arithmetic are not
copied or edited. A report derived for a new forcing window is explicitly kept
apart from the first report actually emitted by the original runner.
"""
from __future__ import annotations

import contextlib
from copy import deepcopy
from dataclasses import asdict
import importlib.util
import os
from pathlib import Path
import pickle
import socket
import sys
import time
import traceback
import zipfile

from chain_contract_pb import (bindings, calendar_summary, json_bytes, read_json,
                               request, require, sha, terminal, transition,
                               validate_configuration)


def verify_source(source):
    source = Path(source).resolve()
    raw = (source / 'SOURCE_SHA256.json').read_bytes()
    fixed = bindings()['source']
    require(sha(raw) == fixed['manifest_sha256'], 'NM source manifest mismatch')
    manifest = __import__('json').loads(raw)
    require(len(manifest) == fixed['files'], 'NM source count mismatch')
    for name, expected in manifest.items():
        path = source / name
        require(path.resolve().is_relative_to(source) and path.is_file()
                and sha(path.read_bytes()) == expected, 'NM source byte mismatch: ' + name)
    return manifest


def load_runtime(source):
    require(os.name == 'posix' and os.environ.get('PBS_JOBID')
            and socket.gethostname().split('.')[0] in ('compute000', 'compute001', 'compute002'),
            'Numerical adapter is restricted to an EHPC compute PBS job')
    source = Path(source).resolve()
    verify_source(source)
    for name, module in list(sys.modules.items()):
        if name == 'noahmp_clm' or name.startswith('noahmp_clm.') or name in ('fluxnet_solar', 'fluxnet_deposition'):
            require(Path(module.__file__).resolve().is_relative_to(source), 'Different model already imported')
    sys.path[:0] = [str(source / 'src'), str(source / 'benchmarks')]
    spec = importlib.util.spec_from_file_location('pb_original_numpy_runner', source / 'benchmarks/run_fluxnet_column.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    return runner


def _write(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def _member(folder, name):
    require(type(name) is str and Path(name).name == name, 'Generation path must be a basename')
    return Path(folder) / name


def validate_inputs(runner, paths, identity):
    np = runner.np
    verify_source(runner.ROOT)
    if not identity['test_only']:
        require(identity == request(identity['candidate'], identity['case'], identity['phase'], identity['cycle']),
                'Full-year identity is not the fixed OM/OU request')
    ip, mp, cp = (Path(paths[k]) for k in ('input', 'input_manifest', 'configuration'))
    for path, key in ((ip, 'forcing_npz_sha256'), (mp, 'forcing_manifest_sha256'),
                      (cp, 'configuration_sha256')):
        require(sha(path.read_bytes()) == identity[key], 'Input identity mismatch: ' + key)
    config = validate_configuration(cp.read_bytes(), identity)
    metadata = read_json(mp)
    with np.load(ip, allow_pickle=False) as z:
        data = dict(z)
    runner.validate_input(data, metadata, ip)
    info = calendar_summary(data['time_start'], data['time_end'], float(data['forcing'][0, 0]),
                            full_year=not identity['test_only'])
    require(all(info[k] == identity[k] for k in info), 'Declared calendar differs from original input')
    for key in ('latitude', 'longitude', 'utc_offset_hours'):
        require(config[key] == metadata[key], 'Configuration/forcing geometry mismatch')
    if identity['test_only']:
        require(identity.get('test_scope') == 'PB bounded adapter test' and info['steps'] <= 2,
                'Test-only windows must be explicit and at most two intervals')
    return data, config


def _generation(runner, trajectory, report, *, complete):
    np = runner.np
    require('failure' not in report and report['source_unchanged'] is True, 'Failed/changed source parent')
    require(report['source_sha256'] == runner.source_hashes(), 'Original runner source footprint differs')
    if complete:
        require(report['status'] == 'complete'
                and report['steps_completed'] == report['steps_requested'], 'Complete parent year/window required')
    for field, digest in (('checkpoint_file', 'checkpoint_sha256'), ('model_npz', 'model_npz_sha256')):
        require(sha(_member(trajectory, report[field]).read_bytes()) == report[digest], 'Generation hash mismatch')
    raw = _member(trajectory, report['checkpoint_file']).read_bytes()
    saved = pickle.loads(raw)  # only internally produced hash-bound checkpoints
    require(type(saved) is tuple and len(saved) == 7 and type(saved[-1]) is int
            and saved[-1] == report['steps_completed'], 'Seven-tuple/index mismatch')
    for value in saved[1:6]:
        require(type(value) is np.ndarray and value.shape == (4,) and np.all(np.isfinite(value)),
                'Cumulative ledger array is invalid')
    require(np.all(saved[3] >= 0) and np.all(saved[4] >= 0) and np.all(saved[5] >= 0),
            'Negative bound or maximum')
    residual = runner.totals(saved[0]) - saved[1] - saved[2]
    require(np.all(np.isfinite(residual)) and np.all(abs(residual) <= saved[3]), 'Endpoint M/H/C/N ledger failed')
    for key, value in (('cumulative_numerical_bounds_m_h_c_n', saved[3]),
                       ('maximum_cumulative_residual_m_h_c_n', saved[4]),
                       ('maximum_step_residual_m_h_c_n', saved[5])):
        require(np.array_equal(np.asarray(report[key]), value), 'Report/checkpoint ledger mismatch: ' + key)
    with np.load(_member(trajectory, report['model_npz']), allow_pickle=False) as z:
        trace = dict(z)
    expected = set((*runner.TRACE, *runner.structure_trace_keys(report['configuration']),
                    *runner.capacity_trace_keys(report['configuration']), 'swe_m', 'lai', 'tsoil_k',
                    'smc_m3m3', 'liquid_m3m3', 'step_residual_m_h_c_n', 'step_bound_m_h_c_n',
                    'cumulative_residual_m_h_c_n', 'time_start', 'time_end'))
    require(set(trace) == expected and all(len(v) == saved[-1] for v in trace.values()),
            'Complete original trace schema/count required')
    require(all(np.all(np.isfinite(v)) for k, v in trace.items() if k not in ('time_start', 'time_end')),
            'Nonfinite model trace')
    require(np.all(abs(trace['step_residual_m_h_c_n']) <= trace['step_bound_m_h_c_n']),
            'Stored step budget failed')
    return raw, saved, trace


def verify_parent(runner, parent, expected_identity, parent_terminal):
    """Inspect a closed original generation; never interpret a running receipt as F0."""
    parent = Path(parent)
    receipt_raw = (parent / 'receipt.json').read_bytes()
    receipt = read_json(parent / 'receipt.json')
    chain_raw = (parent / 'chain-state.json').read_bytes()
    chain = read_json(parent / 'chain-state.json')
    report_raw = (parent / 'trajectory/report.json').read_bytes()
    report = read_json(parent / 'trajectory/report.json')
    require(receipt['failure'] is None and receipt['worker_completed'] is True and receipt['source_unchanged'] is True,
            'Parent worker did not succeed')
    require(receipt['first_start_exact'] is True, 'Parent first physical state was not verified')
    require(receipt['identity'] == chain['identity'] == expected_identity, 'Parent chain identity mismatch')
    context_raw = (parent / 'start-context.json').read_bytes()
    context = read_json(parent / 'start-context.json')
    require(all(chain[k] == v for k, v in context.items())
            and chain['start_context_sha256'] == sha(context_raw), 'Parent start context changed')
    require(receipt['chain_sha256'] == sha(chain_raw) and receipt['report_sha256'] == sha(report_raw)
            and chain['report_sha256'] == sha(report_raw), 'Parent receipt/report/ledger binding differs')
    capture_root = parent / 'segment-0000000'
    capture_raw = (capture_root / 'capture-SHA256.json').read_bytes()
    require(sha(capture_raw) == receipt['chain_start_capture_sha256'], 'Original start-capture binding changed')
    for name, digest in read_json(capture_root / 'capture-SHA256.json').items():
        path = capture_root / name
        require(path.resolve().is_relative_to(capture_root.resolve()) and sha(path.read_bytes()) == digest,
                'Original start/first-call bytes changed')
    require(chain['ledger_steps'] == chain['previous_ledger_steps'] + report['steps_completed']
            and chain['ledger_segments'] >= 1, 'Parent cumulative step/segment count mismatch')
    require(report['steps_requested'] == report['steps_completed'] == expected_identity['steps'],
            'Full parent year required')
    for key in ('configuration_sha256', 'forcing_npz_sha256', 'forcing_manifest_sha256'):
        require(report[key] == expected_identity[key], 'Parent original input identity mismatch: ' + key)
    job = parent_terminal['job']
    if not expected_identity['test_only']:
        require(job == receipt['pbs_job'], 'Terminal is not the actual worker PBS job')
    proof = terminal(parent_terminal['qstat'], parent_terminal['parent_exit'], parent_terminal['worker_exit'],
                     job, synthetic=expected_identity['test_only'])
    raw, saved, trace = _generation(runner, parent / 'trajectory', report, complete=True)
    info = calendar_summary(trace['time_start'], trace['time_end'], expected_identity['dt_seconds'],
                            full_year=not expected_identity['test_only'])
    require(all(info[k] == expected_identity[k] for k in info), 'Parent trace/calendar mismatch')
    first = parent / 'segment-0000000/start-originals'
    inventory = read_json(first / 'SHA256.json')
    require(all(sha((first / n).read_bytes()) == h for n, h in inventory.items()), 'Original zero-step packet changed')
    first_report = read_json(first / 'report.json')
    require(first_report['steps_completed'] == 0 and first_report['status'] == 'running',
            'Original zero-step report required')
    zero_state = pickle.loads(_member(first, first_report['checkpoint_file']).read_bytes())
    require(type(zero_state) is tuple and len(zero_state) == 7 and zero_state[-1] == 0,
            'Original zero-step seven-tuple required')
    first_input = pickle.loads((parent / 'segment-0000000/first-call-input.pkl').read_bytes())
    require(pickle.dumps(first_input['before'], protocol=5) == pickle.dumps(zero_state[0], protocol=5),
            'Original first-call input differs from zero-step state')
    if context['mode'] == 'cold':
        require(expected_identity['phase'] == 'spinup' and expected_identity['cycle'] == 1,
                'Only own spinup cycle1 can claim cold provenance')
        require(context['previous_ledger_steps'] == 0 and context['ledger_segments'] == 1,
                'Cold ledger cannot inherit prior credit')
        require(pickle.dumps(zero_state[0], protocol=5)
                == pickle.dumps(runner.build_state(report['configuration']), protocol=5),
                'Cold start is not the candidate original explicit configuration')
        require(runner.np.array_equal(zero_state[1], runner.totals(zero_state[0]))
                and all(runner.np.array_equal(x, runner.np.zeros(4)) for x in zero_state[2:6]),
                'Cold global ledger initialization mismatch')
    else:
        retained = parent / 'parent-originals'
        for name, key in (('parent-report.json', 'parent_report_sha256'),
                          ('parent-chain-state.json', 'parent_chain_sha256'),
                          ('parent-receipt.json', 'parent_receipt_sha256')):
            require(sha((retained / name).read_bytes()) == context[key], 'Retained parent metadata changed')
        old_chain = read_json(retained / 'parent-chain-state.json')
        require(transition(old_chain['identity'], expected_identity) == context['mode'],
                'Retained parent phase differs')
        require(context['previous_ledger_steps'] == old_chain['ledger_steps']
                and context['ledger_segments'] == old_chain['ledger_segments'] + 1,
                'Global ledger steps/segments reset or jump')
        parent_raw = (parent / 'parent-originals/parent-state.pkl').read_bytes()
        require(sha(parent_raw) == context['parent_checkpoint_sha256'], 'Retained parent state changed')
        require(pickle.dumps(zero_state[:6], protocol=5)
                == pickle.dumps(pickle.loads(parent_raw)[:6], protocol=5), 'Six carried objects changed')
    return dict(report=report, report_raw=report_raw, state_raw=raw, saved=saved, trace=trace,
                chain=chain, chain_raw=chain_raw, receipt_raw=receipt_raw, terminal=proof)


def derive_start(runner, parent, parent_identity, child_identity, paths, output, parent_terminal):
    """Create one explicitly derived zero-step start; no tendency is evaluated."""
    mode = transition(parent_identity, child_identity)
    validate_inputs(runner, paths, child_identity)
    p = verify_parent(runner, parent, parent_identity, parent_terminal)
    output = Path(output)
    require(not output.exists(), 'Fresh child directory required')
    seed = p['saved'][:-1] + (0,)
    require(pickle.dumps(seed[:6], protocol=5) == pickle.dumps(p['saved'][:6], protocol=5),
            'Six state/global ledger objects changed')
    trajectory = output / 'trajectory'
    trajectory.mkdir(parents=True)
    _write(trajectory / 'state-0000000.pkl', pickle.dumps(seed))
    with (trajectory / 'trace-0000000.npz').open('xb') as stream:
        runner.np.savez_compressed(stream, **{k: v[:0].copy() for k, v in p['trace'].items()})
    derived = deepcopy(p['report'])
    for key in ('final_state', 'failure', 'failed_index'):
        derived.pop(key, None)
    derived.update(status='running', steps_completed=0, steps_requested=child_identity['steps'], seconds=0.,
                   initial_state=asdict(seed[0]), checkpoint_file='state-0000000.pkl',
                   checkpoint_sha256=sha((trajectory / 'state-0000000.pkl').read_bytes()),
                   model_npz='trace-0000000.npz',
                   model_npz_sha256=sha((trajectory / 'trace-0000000.npz').read_bytes()))
    for key in ('configuration_sha256', 'forcing_npz_sha256', 'forcing_manifest_sha256'):
        derived[key] = child_identity[key]
    runner.atomic_json(trajectory / 'report.json', derived)
    _write(output / 'derived-start-report.json', (trajectory / 'report.json').read_bytes())
    for name, raw in (('parent-report.json', p['report_raw']), ('parent-state.pkl', p['state_raw']),
                      ('parent-chain-state.json', p['chain_raw']), ('parent-receipt.json', p['receipt_raw']),
                      ('parent-qstat.txt', parent_terminal['qstat']),
                      ('parent-exit.txt', parent_terminal['parent_exit']),
                      ('parent-worker-exit.txt', parent_terminal['worker_exit'])):
        _write(output / 'parent-originals' / name, raw)
    context = dict(identity=child_identity, mode=mode, previous_ledger_steps=p['chain']['ledger_steps'],
                   ledger_segments=p['chain']['ledger_segments'] + 1,
                   parent_report_sha256=sha(p['report_raw']), parent_checkpoint_sha256=sha(p['state_raw']),
                   parent_chain_sha256=sha(p['chain_raw']), parent_receipt_sha256=sha(p['receipt_raw']),
                   parent_terminal=p['terminal'], six_objects_protocol5_exact=True,
                   spinup_accepted=False, score_eligible=False)
    _write(output / 'start-context.json', json_bytes(context))
    return context


def _snapshot(trajectory, report_path, target):
    report = read_json(report_path)
    files = {'report.json': Path(report_path).read_bytes()}
    for field in ('checkpoint_file', 'model_npz'):
        files[report[field]] = _member(trajectory, report[field]).read_bytes()
    for name, raw in files.items():
        _write(Path(target) / name, raw)
    _write(Path(target) / 'SHA256.json', json_bytes({n: sha(v) for n, v in files.items()}))
    return report


def _run_segment(runner, source, paths, identity, output, *, stop_after, resume=False):
    """Private execution core for reviewed EHPC tests; not a production entrypoint."""
    require(type(stop_after) is int and stop_after > 0, 'Positive integer segment length required')
    require(identity.get('test_only') is True,
            'PB production execution disabled; only reviewed bounded test windows may run')
    source = Path(source)
    verify_source(source)
    validate_inputs(runner, paths, identity)
    output = Path(output)
    trajectory = output / 'trajectory'
    if not resume:
        require(identity['phase'] == 'spinup' and identity['cycle'] == 1, 'Only own spinup cycle1 may start cold')
        require(not output.exists(), 'Cold run must use a fresh directory')
        output.mkdir(parents=True)
        context = dict(identity=identity, mode='cold', previous_ledger_steps=0, ledger_segments=1,
                       parent_report_sha256=None, parent_checkpoint_sha256=None,
                       spinup_accepted=False, score_eligible=False)
        _write(output / 'start-context.json', json_bytes(context))
        start = 0
    else:
        context = read_json(output / 'start-context.json')
        require(context['identity'] == identity, 'Resume identity differs from frozen start')
        report = read_json(trajectory / 'report.json')
        _, saved, _ = _generation(runner, trajectory, report, complete=False)
        start = saved[-1]
        require(report['status'] == 'running' and start < identity['steps'], 'No failed/complete resume')
    require(start + stop_after <= identity['steps'], 'Segment exceeds fixed window')
    segment = output / ('segment-' + str(start).zfill(7))
    require(not segment.exists(), 'Segment attempt already exists; retain failures')
    segment.mkdir()
    original_json, original_step = runner.atomic_json, runner.step_clm_enthalpy_column
    captured = False
    first_state_exact = False
    calls = 0
    expected_state = None
    failure = None
    source_unchanged = False
    began = time.monotonic()

    def observe(path, value):
        nonlocal captured, expected_state
        original_json(path, value)
        if Path(path).resolve() != (trajectory / 'report.json').resolve():
            return
        raw = Path(path).read_bytes()
        chain = dict(context, report_sha256=sha(raw),
                     start_context_sha256=sha((output / 'start-context.json').read_bytes()),
                     ledger_steps=context['previous_ledger_steps'] + value['steps_completed'])
        original_json(output / 'chain-state.json', chain)
        # Lossless bounded-inode report/checkpoint/trace history; no source mutation.
        with zipfile.ZipFile(output / 'generations.zip', 'a', zipfile.ZIP_DEFLATED) as z:
            prefix = f'{start:07d}-{len(z.namelist()):07d}/'
            for name in ('report.json', value['checkpoint_file'], value['model_npz']):
                z.writestr(prefix + name, (trajectory / name).read_bytes())
        if not captured:
            require(value['steps_completed'] == start, 'First saved generation is not original segment start')
            _snapshot(trajectory, path, segment / 'start-originals')
            expected_state = pickle.dumps(pickle.loads(_member(trajectory, value['checkpoint_file']).read_bytes())[0],
                                          protocol=5)
            captured = True

    def first(state, forcing, **kwargs):
        nonlocal calls, first_state_exact
        if calls == 0:
            require(captured and pickle.dumps(state, protocol=5) == expected_state,
                    'First physical state differs from original saved start')
            first_state_exact = True
            _write(segment / 'first-call-input.pkl', pickle.dumps(dict(before=state, forcing=forcing, kwargs=kwargs),
                                                                  protocol=5))
        after, diagnostics = original_step(state, forcing, **kwargs)
        if calls == 0:
            _write(segment / 'first-call.pkl', pickle.dumps(dict(before=state, forcing=forcing, kwargs=kwargs,
                                                                after=after, diagnostics=diagnostics), protocol=5))
        calls += 1
        return after, diagnostics

    with (segment / 'model.log').open('x') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        try:
            runner.atomic_json, runner.step_clm_enthalpy_column = observe, first
            report = runner.run(*(paths[k] for k in ('input', 'input_manifest', 'configuration')),
                                trajectory, resume=resume, stop_after=stop_after)
            require(captured and calls == stop_after and report['steps_completed'] == start + stop_after,
                    'Original runner did not complete the requested segment')
            _generation(runner, trajectory, report, complete=report['status'] == 'complete')
        except Exception as exc:
            failure = type(exc).__name__ + ': ' + str(exc)
            traceback.print_exc()
        finally:
            runner.atomic_json, runner.step_clm_enthalpy_column = original_json, original_step
    try:
        verify_source(source)
        source_unchanged = True
        # Recheck immutable inputs even on an original model failure.
        validate_inputs(runner, paths, identity)
    except Exception as exc:
        failure = (failure + '; ' if failure else '') + type(exc).__name__ + ': ' + str(exc)
    capture_files = {p.relative_to(segment).as_posix(): sha(p.read_bytes())
                     for p in sorted(segment.rglob('*')) if p.is_file()}
    _write(segment / 'capture-SHA256.json', json_bytes(capture_files))
    chain_start_capture = output / 'segment-0000000/capture-SHA256.json'
    report_raw = (trajectory / 'report.json').read_bytes() if (trajectory / 'report.json').exists() else b''
    chain_raw = (output / 'chain-state.json').read_bytes() if (output / 'chain-state.json').exists() else b''
    receipt = dict(identity=identity, pbs_job=os.environ.get('PBS_JOBID'), node=socket.gethostname(),
                   start_index=start, stop_index=start + calls, successful_tendency_calls=calls,
                   worker_completed=failure is None, failure=failure, source_unchanged=source_unchanged,
                   report_sha256=sha(report_raw), chain_sha256=sha(chain_raw),
                   chain_start_capture_sha256=sha(chain_start_capture.read_bytes()),
                   seconds=time.monotonic() - began, first_start_exact=first_state_exact,
                   actual_pbs_terminal_claimed=False, spinup_accepted=False, score_eligible=False)
    original_json(segment / 'receipt.json', receipt)
    original_json(output / 'receipt.json', receipt)
    if failure is not None:
        raise RuntimeError(failure)
    return receipt

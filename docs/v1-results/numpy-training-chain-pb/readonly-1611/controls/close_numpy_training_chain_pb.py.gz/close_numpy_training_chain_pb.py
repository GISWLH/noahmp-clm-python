"""One read-only EHPC closure of completed PB results; no tendency is allowed."""
from pathlib import Path
import ast
import hashlib
import json
import os
import pickle
import re
import socket
import sys
import tarfile
import time
import traceback
import zipfile

STAGE = Path('/tmp/noahmp-numpy-training-chain-pb-b')
CLOSURE = Path('/tmp/noahmp-numpy-training-chain-pb-closure')
SOURCE = Path('/var/tmp/pbs.1607.manager/source-nm584')
RESULT_SHA = '145732b78e67daad84bc120e197373b28edfd4e182fa6e4836f2b5cfc3e44760'
PREP_SHA = '165913db4fd39f10c47d174b74c42f8f877216c347fe46535489c5ecc013e7be'
EXEC_SHA = 'dacc90372adcb1327b27f9f01fc0fa5d53ee5da399ecc8ddc567073c958dc99b'
STAGE_SHA = 'c619f1871b275b5e3784dcc0e7728706108b9131dbf91afd0ce36bd9dc5a340d'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def inventory(folder):
    return {p.relative_to(folder).as_posix(): sha(p.read_bytes())
            for p in sorted(folder.rglob('*')) if p.is_file()}


def unpack(path, target):
    target.mkdir()
    with tarfile.open(path, 'r:gz') as archive:
        seen = set()
        for member in archive.getmembers():
            if member.isdir():
                continue
            name = member.name.removeprefix('./')
            assert member.isfile() and name not in seen and not Path(name).is_absolute()
            assert '..' not in Path(name).parts and '\\' not in name
            seen.add(name)
            dest = target / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(archive.extractfile(member).read())


def inspect(out):
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    index = read(CLOSURE / 'controls.json')
    assert all(sha((CLOSURE / n).read_bytes()) == h for n, h in index.items())
    assert sha(Path(__file__).read_bytes()) == index['close_numpy_training_chain_pb.py']
    original = STAGE / 'result.tar.gz'
    assert sha(original.read_bytes()) == RESULT_SHA
    stage_archive = Path('/tmp/noahmp-numpy-training-chain-pb-b-stage.tar.gz')
    assert sha(stage_archive.read_bytes()) == STAGE_SHA
    frozen = read(STAGE / 'stage-inventory.json')
    with tarfile.open(stage_archive) as archive:
        assert set(archive.getnames()) == set(frozen) | {'stage-inventory.json'}
        assert all(archive.extractfile(n).read() == (STAGE / n).read_bytes() for n in archive.getnames())
    assert all(sha((STAGE / n).read_bytes()) == h for n, h in frozen.items())
    qstat = (CLOSURE / 'original-1607-qstat.txt').read_text()
    assert re.search(r'^Job Id: 1607\.manager$', qstat, re.M)
    for field, expected in [('job_state', 'F'), ('Exit_status', '1'), ('Stageout_status', '0')]:
        assert re.search(r'^\s*' + field + r' = ' + expected + r'$', qstat, re.M)
    assert (STAGE / 'pbs-exit.txt').read_text().strip() == '1'
    raw = out.parent / 'original-result'
    unpack(original, raw)
    before = inventory(raw)
    save(out / 'original-result-file-sha256.json', before)
    original_receipt = read(raw / 'receipt.json')
    assert original_receipt['pbs_job'] == '1607.manager'
    assert original_receipt['passed'] is False and original_receipt['error'] == 'AssertionError: '
    assert original_receipt['test_parent_returncode'] == 0 and original_receipt['test_timed_out'] is False
    assert (raw / 'worker-exit.txt').read_text().strip() == '1'
    assert (raw / 'unittest-parent-exit.txt').read_text().strip() == '0'
    assert "assert not re.search(r'skipped|expected failure|unexpected success'" in (raw / 'traceback.txt').read_text()
    prep = raw / 'preparation'
    assert sha((prep / 'CONTROLS_SHA256.json').read_bytes()) == PREP_SHA
    assert sha((raw / 'execution/CONTROLS_SHA256.json').read_bytes()) == EXEC_SHA
    for folder in (prep, raw / 'execution'):
        assert all(sha((folder / n).read_bytes()) == h for n, h in read(folder / 'CONTROLS_SHA256.json').items())
    assert sha((raw / 'independent-review.json').read_bytes()) == '9fb0791579849df70b5f97b941a8ad050c449c0361d8afffd5f223f5abee10fa'
    tree = ast.parse((prep / 'test_numpy_chain_pb.py').read_bytes())
    expected_tests = {n.name + ' (test_numpy_chain_pb.' + cls.name + '.' + n.name + ')'
                      for cls in tree.body if isinstance(cls, ast.ClassDef)
                      for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
    stderr = (raw / 'unittest.stderr.txt').read_text()
    statuses = re.findall(r'^(test_\w+ \(test_numpy_chain_pb\.\w+\.test_\w+\)) \.\.\. (.+)$', stderr, re.M)
    assert len(expected_tests) == len(statuses) == 19 and {n for n, _ in statuses} == expected_tests
    assert all(status == 'ok' for _, status in statuses)
    summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
    assert len(summary) == 1 and summary[0][0] == '19' and re.findall(r'^OK.*$', stderr, re.M) == ['OK']
    assert not re.search(r'^(?:FAIL|ERROR|UNEXPECTED SUCCESS):|^FAILED\b', stderr, re.M)
    assert 'test_cycle_must_reuse_exact_forcing_and_no_skipped_phase' in stderr
    save(out / 'actual-test-statuses.json', dict(tests=statuses, count=19, skipped=0,
         seconds=float(summary[0][1]), child_exit=0, original_wrapper_exit=1,
         parser_failure='Unanchored skipped substring matched a successful test method name.'))
    sys.path.insert(0, str(prep))
    import numpy_chain_pb as adapter
    source_before = adapter.verify_source(SOURCE)
    runner = adapter.load_runtime(SOURCE)
    prohibited_calls = []

    def prohibit(*args, **kwargs):
        prohibited_calls.append(True)
        raise AssertionError('Read-only closure must not call a physical tendency or runner')

    runner.step_clm_enthalpy_column = prohibit
    runner.run = prohibit
    np = runner.np
    fixed = read(prep / 'BINDINGS.json')
    assert fixed['production_launch_allowed'] is False
    assert sha((SOURCE / 'SOURCE_SHA256.json').read_bytes()) == fixed['source']['manifest_sha256']
    assert (raw / 'SOURCE_SHA256.json').read_bytes() == (SOURCE / 'SOURCE_SHA256.json').read_bytes()
    short = raw / 'short-model-output'
    with tarfile.open(STAGE / 'inputs/fluxnet-calibration-om-evidence.tar.gz') as archive:
        config = archive.extractfile('result/applied/om-baseline/CN-Cng-2007-wilting-hydraulic-clim.json').read()
    assert config == (short / 'original-config.json').read_bytes()
    with tarfile.open(STAGE / 'inputs/fluxnet-training-years-ou-evidence.tar.gz') as archive:
        full_npz = archive.extractfile('current/prepared-inputs/year-inputs/CN-Cng-2007.npz').read()
        full_meta = json.loads(archive.extractfile('current/prepared-inputs/year-inputs/CN-Cng-2007.json').read())
    assert full_npz == (short / 'original-full-input.npz').read_bytes()
    input_fields = {}
    with np.load(short / 'original-full-input.npz', allow_pickle=False) as original_data:
        for start in (0, 2):
            meta = read(short / ('bounded-' + str(start) + '.json'))
            expected_meta = dict(full_meta, prepared_npz_sha256=sha((short / ('bounded-' + str(start) + '.npz')).read_bytes()),
                                 PB_test_only=True, PB_original_annual_sha256=sha(full_npz), PB_slice=[start, start + 2])
            assert meta == expected_meta
            with np.load(short / ('bounded-' + str(start) + '.npz'), allow_pickle=False) as bounded:
                assert set(bounded.files) == set(original_data.files)
                input_fields[str(start)] = {key: adapter.assert_content_exact(original_data[key][start:start + 2], bounded[key], np)
                                           for key in bounded.files}
    names = ('cold', 'spinup-cycle', 'train1-cycle', 'train2-continue')
    terminal_dir = short / 'spinup-cycle/parent-originals'
    terminal = dict(job='pb-test-closed', qstat=(terminal_dir / 'parent-qstat.txt').read_bytes(),
                    parent_exit=(terminal_dir / 'parent-exit.txt').read_bytes(),
                    worker_exit=(terminal_dir / 'parent-worker-exit.txt').read_bytes())
    rows, carry, segment_rows, generations = [], [], [], []
    previous = None
    for i, name in enumerate(names):
        folder = short / name
        identity = read(folder / 'receipt.json')['identity']
        result = adapter.verify_parent(runner, folder, identity, terminal)
        assert result['chain']['ledger_steps'] == 2 * (i + 1) and result['chain']['ledger_segments'] == i + 1
        residual = runner.totals(result['saved'][0]) - result['saved'][1] - result['saved'][2]
        rows.append(dict(trajectory=name, phase=identity['phase'], cycle=identity['cycle'],
                         ledger_steps=result['chain']['ledger_steps'], residual_m_h_c_n=residual.tolist(),
                         bounds_m_h_c_n=result['saved'][3].tolist()))
        if previous is not None:
            retained = folder / 'parent-originals/parent-state.pkl'
            assert retained.read_bytes() == previous['state_raw']
            zero = folder / 'segment-0000000/start-originals'
            seed = pickle.loads((zero / read(zero / 'report.json')['checkpoint_file']).read_bytes())
            assert seed[-1] == 0
            carry.append(dict(trajectory=name, comparison=adapter.assert_content_exact(seed[:6], previous['saved'][:6], np)))
        previous = result
        for segment in sorted(folder.glob('segment-*')):
            for member, digest in read(segment / 'capture-SHA256.json').items():
                assert sha((segment / member).read_bytes()) == digest
            rec = read(segment / 'receipt.json')
            assert rec['worker_completed'] and rec['source_unchanged'] and rec['first_start_exact'] and rec['failure'] is None
            assert rec['pbs_job'] == '1607.manager' and rec['identity'] == identity
            packet = pickle.loads((segment / 'first-call.pkl').read_bytes())
            first = pickle.loads((segment / 'first-call-input.pkl').read_bytes())
            assert set(packet) == {'before', 'forcing', 'kwargs', 'after', 'diagnostics'}
            first_comparison = adapter.assert_content_exact(first, {k: packet[k] for k in first}, np)
            original_start = segment / 'start-originals'
            start_report = read(original_start / 'report.json')
            saved_start = pickle.loads((original_start / start_report['checkpoint_file']).read_bytes())
            start_comparison = adapter.assert_content_exact(first['before'], saved_start[0], np)
            segment_rows.append(dict(trajectory=name, segment=segment.name, calls=rec['successful_tendency_calls'],
                                     first_input_and_packet=first_comparison, original_start=start_comparison))
        with zipfile.ZipFile(folder / 'generations.zip') as history:
            assert len(history.namelist()) == len(set(history.namelist()))
            for report_name in sorted(n for n in history.namelist() if n.endswith('/report.json')):
                report = json.loads(history.read(report_name))
                gen = out.parent / 'generation-read-copies' / name / Path(report_name).parent
                gen.mkdir(parents=True)
                for member in ('report.json', report['checkpoint_file'], report['model_npz']):
                    (gen / member).write_bytes(history.read(str(Path(report_name).parent / member)))
                adapter._generation(runner, gen, report, complete=report['status'] == 'complete')
                generations.append(dict(trajectory=name, report=report_name, steps=report['steps_completed'],
                                        report_sha256=sha(history.read(report_name))))
    assert len(segment_rows) == 5 and sum(r['calls'] for r in segment_rows) == 8 and len(carry) == 3
    cold_report = read(short / 'cold/trajectory/report.json')
    reference_report = read(short / 'unmodified-runner-reference/report.json')
    cold = adapter._generation(runner, short / 'cold/trajectory', cold_report, complete=True)
    reference = adapter._generation(runner, short / 'unmodified-runner-reference', reference_report, complete=True)
    assert reference_report['steps_completed'] == reference_report['steps_requested'] == 2
    state_exact = adapter.assert_content_exact(cold[1], reference[1], np)
    assert set(cold[2]) == set(reference[2]) and len(cold[2]) == 18
    trace_exact = {key: adapter.assert_content_exact(cold[2][key], reference[2][key], np) for key in cold[2]}
    diagnostic = [json.loads(line.removeprefix('PB_DIAGNOSTIC ')) for line in (raw / 'unittest.stdout.txt').read_text().splitlines()
                  if line.startswith('PB_DIAGNOSTIC ')]
    logged = next(d for d in diagnostic if d['test'] == 'bounded_chain')
    assert logged['original_tendency_calls'] == 10 and logged['adapter_calls'] == 8 and logged['untouched_reference_calls'] == 2
    for row, old in zip(rows, logged['rows'], strict=True):
        assert all(row[k] == value for k, value in old.items())
    assert adapter.verify_source(SOURCE) == source_before
    assert before == inventory(raw) and not prohibited_calls
    assert all(sha((STAGE / n).read_bytes()) == h for n, h in frozen.items())
    assert all(sha((CLOSURE / n).read_bytes()) == h for n, h in index.items())
    assert sha(original.read_bytes()) == RESULT_SHA
    save(out / 'quantified-closure.json', dict(rows=rows, three_six_object_carries=carry,
         seven_tuple_comparison=state_exact, trace_fields=trace_exact, segments=segment_rows,
         generation_history_checks=generations, two_input_slice_fields=input_fields,
         original_test_stdout_diagnostics=diagnostic))
    return dict(passed=True, original_pbs_job='1607.manager', original_pbs_state='F', original_pbs_exit=1,
                original_stageout=0, original_wrapper_exit=1, original_test_child_exit=0,
                test_count=19, skipped=0, test_seconds=float(summary[0][1]),
                actual_original_physical_tendencies=10, adapter_tendencies=8, original_reference_tendencies=2,
                readonly_closure_tendency_calls=0, original_source_584_before_after_exact=True,
                original_result_files=len(before), original_inputs_controls_before_after_exact=True,
                original_result_archive_sha256=RESULT_SHA, preparation_manifest_sha256=PREP_SHA,
                original_execution_manifest_sha256=EXEC_SHA, original_stage_archive_sha256=STAGE_SHA,
                source_manifest_sha256=sha((SOURCE / 'SOURCE_SHA256.json').read_bytes()),
                production_launch_allowed=False, actual_field_years=0, actual_accepted_spinup=False, GPU_steps=0,
                conclusion='Numerical tests passed; execution wrapper parsing failed; closed by read-only inspection.')


def main():
    out = Path(sys.argv[1]).resolve()
    assert out.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not out.exists()
    out.mkdir()
    began = time.monotonic()
    receipt = dict(passed=False)
    try:
        receipt = inspect(out)
    except Exception as exc:
        receipt.update(error=type(exc).__name__ + ': ' + str(exc))
        (out / 'traceback.txt').write_text(traceback.format_exc())
    receipt.update(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), pid=os.getpid(),
                   python=sys.version, seconds=time.monotonic() - began)
    save(out / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

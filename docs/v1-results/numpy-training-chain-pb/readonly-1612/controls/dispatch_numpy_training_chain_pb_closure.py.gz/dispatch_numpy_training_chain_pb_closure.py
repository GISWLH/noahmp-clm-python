"""Stage the single authorized PB read-only closure; never launch model tests."""
from pathlib import Path
import hashlib
import json
import shlex
import socket
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/noahmp-numpy-training-chain-pb-closure-b')


def main():
    assert socket.gethostname() == 'manager' and not ROOT.exists()
    archive_path, digest = Path(sys.argv[1]), sys.argv[2]
    assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == digest
    with tarfile.open(archive_path) as archive:
        names = archive.getnames()
        assert len(names) == len(set(names)) == 5 and all(Path(n).name == n for n in names)
        raw = {n: archive.extractfile(n).read() for n in names}
    index = json.loads(raw['controls.json'])
    assert set(index) == set(raw) - {'controls.json'}
    assert all(hashlib.sha256(raw[n]).hexdigest() == h for n, h in index.items())
    assert raw['dispatch_numpy_training_chain_pb_closure.py'] == Path(__file__).read_bytes()
    ROOT.mkdir()
    for n, value in raw.items():
        (ROOT / n).write_bytes(value)
    subprocess.run(['ssh', 'compute002', shlex.join(['mkdir', str(ROOT)])], check=True)
    subprocess.run(['scp', *[str(ROOT / n) for n in names], 'compute002:' + str(ROOT) + '/'], check=True)
    checked = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', *[str(ROOT / n) for n in names]])],
                             capture_output=True, text=True)
    (ROOT / 'compute-file-hashes.txt').write_text(checked.stdout)
    assert checked.returncode == 0, checked.stderr
    assert {line.split()[1]: line.split()[0] for line in checked.stdout.splitlines()} == {
        str(ROOT / n): hashlib.sha256(raw[n]).hexdigest() for n in names}
    result = subprocess.run(['qsub', '-o', str(ROOT / 'pbs-output.log'), str(ROOT / 'close_numpy_training_chain_pb.pbs')],
                            capture_output=True, text=True)
    (ROOT / 'qsub.stdout.txt').write_text(result.stdout)
    (ROOT / 'qsub.stderr.txt').write_text(result.stderr)
    (ROOT / 'qsub-exit.txt').write_text(str(result.returncode) + '\n')
    assert result.returncode == 0, result.stderr
    record = dict(pbs_job=result.stdout.strip(), controls_archive_sha256=digest,
                  controls_manifest_sha256=hashlib.sha256(raw['controls.json']).hexdigest(),
                  scope='Read-only original1607 result closure; no tests or physical tendency rerun.',
                  original_job='1607.manager', original_job_exit=1,
                  resources='1CPU/2GiB/10min/compute002')
    (ROOT / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

"""Read only the two actually closed NQ modules; leave active trees untouched."""
from pathlib import Path
import base64
import datetime
import hashlib
import json

ROOT = Path('/home/lhwang/work/noahmp-v1/candidate-full-gpu-nq')
STEMS = {'test_gpu_clm_optics_column': 3, 'test_gpu_clm_phenology_column': 4}
sha = lambda value: hashlib.sha256(value).hexdigest()
plan = json.loads((ROOT / 'plan.json').read_bytes())
source = Path(plan['source'])
raw_manifest = (source / 'SOURCE_SHA256.json').read_bytes()
assert sha(raw_manifest) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
manifest = json.loads(raw_manifest)
assert len(manifest) == 584
before = {name: sha((source / name).read_bytes()) for name in manifest}
assert before == manifest
names = {'SOURCE_SHA256.json', 'plan.json', 'launch.json', 'candidate-full-gpu-nq-spec.json',
         'collection.json', 'collection-actual-exit.json'} | set(plan['controls_sha256'])
optional = {}
for stem, count in STEMS.items():
    parent = json.loads((ROOT / (stem + '-exit.json')).read_bytes())
    assert parent['actual_parent_returncode'] == 0 and parent['passed'] and parent['expected_tests'] == count
    assert sha((ROOT / (stem + '-receipt.json')).read_bytes()) == parent['receipt_sha256']
    names.update(stem + suffix for suffix in ('-exit.json', '-receipt.json', '-expected.json', '.log', '.xml'))
    cache = str(parent['pid']) + '-cache-events.jsonl'
    optional[cache] = (ROOT / cache).is_file()
    if optional[cache]:
        names.add(cache)
    folder = ROOT / (stem + '-diagnostics')
    if folder.is_dir():
        names.update(str(path.relative_to(ROOT)) for path in folder.rglob('*') if path.is_file())
files = {name: (ROOT / name).read_bytes() for name in sorted(names)}
assert files['SOURCE_SHA256.json'] == raw_manifest
assert sha(files['candidate-full-gpu-nq-spec.json']) == plan['spec_sha256']
assert all(sha(files[name]) == expected for name, expected in plan['controls_sha256'].items())
assert {name: sha((ROOT / name).read_bytes()) for name in names} == {name: sha(raw) for name, raw in files.items()}
after = {name: sha((source / name).read_bytes()) for name in manifest}
assert after == before
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), root=str(ROOT),
    source=str(source), source_files=584, source_sha256_before=before, source_sha256_after=after,
    all_selected_closed_files_unchanged=True, optional_presence=optional,
    files={name: base64.b64encode(raw).decode() for name, raw in files.items()}), indent=2))

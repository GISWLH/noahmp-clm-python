"""NQ frozen source and evidence contracts; no numerical imports or mutations."""
from pathlib import Path
import hashlib
import json
import os
import re

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE / 'candidate-full-gpu-nq'
TMP = Path('/tmp/noahmp-candidate-full-gpu-nq')
ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
SOURCE = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
ML = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
NF = '097a98ce878e33eae26de0dd48fbb7b8a5b5b655661b84d4a64d296b21754f98'
JN = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
WORKER = '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
GUARD = '4744d25ffde851c942816edf4e7078ce2179b48faa2fdb7c08d0b05100f4bd58'
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
NK = {'benchmarks/assess_clm_spinup.py', 'tests/test_clm_spinup.py'}
NF_ADDITIONS = {'tests/test_gpu_surface_root_contraction.py',
                'tests/fixtures/cng_surface_root_contraction.npz',
                'tests/fixtures/cng_surface_root_contraction.json'}
MX_FILES = {'test_gpu_canopy_surface.py': 5, 'test_gpu_canopy_phase_surface.py': 4,
            'test_gpu_canopy_phase_weak_descent.py': 3, 'test_gpu_snow_processes.py': 8,
            'test_gpu_surface_secant_rounding.py': 1, 'test_gpu_surface_snow_branch.py': 2,
            'test_gpu_phase_coordinate_recovery.py': 4, 'test_gpu_vanishing_snow_event.py': 4}
NF_TEST = 'test_gpu_surface_root_contraction.py'


def validate_spec(spec):
    assert spec['source_manifest_sha256'] == SOURCE and spec['archive_sha256'] == ARCHIVE
    by_file = spec['gpu_nodes_by_file']
    flat = [n for nodes in by_file.values() for n in nodes]
    assert len(flat) == len(set(flat)) == spec['gpu_nodes'] == 408
    assert all(all(n.startswith(name + '::') for n in nodes) for name, nodes in by_file.items())
    assert all(len(by_file[name]) == count for name, count in MX_FILES.items()) and len(by_file[NF_TEST]) == 1
    new = spec['new_files_in_order']
    assert len(new) == len(set(new)) == 72
    assert set(new) == set(by_file) - set(MX_FILES) - {NF_TEST}
    assert sum(len(by_file[n]) for n in new) == spec['new_nodes'] == 376 and spec['reused_nodes'] == 32
    assert spec['dependency_proof']['nk_reachable'] == []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def verify_source(source, digest, count):
    source = Path(source)
    path = source / 'SOURCE_SHA256.json'
    manifest = read(path)
    assert sha(path) == digest and len(manifest) == count
    assert all(sha(source / n) == h for n, h in manifest.items())
    return manifest


def receipt_check(folder, stem, row, nodes, source, digest):
    """Require original actual parent0, full phases/barriers/XML/node/source proof."""
    folder, source = Path(folder), Path(source)
    receipt = folder / (stem + '-receipt.json')
    expected = folder / (stem + '-expected.json')
    xml = folder / (stem + '.xml')
    value = read(receipt)
    assert row['actual_parent_returncode'] == value['worker_exitcode'] == value['pytest_returncode'] == 0
    assert row['passed'] and value['passed'] and value['source_unchanged']
    assert value['source_manifest_sha256'] == digest and value['worker_sha256'] == WORKER
    assert value['node_coverage_exact'] and value['all_setup_call_teardown_phases_passed']
    assert len(value['nodes']) == len(nodes) and set(value['nodes']) == set(nodes)
    assert read(expected) == nodes and value['expected_nodes_sha256'] == sha(expected)
    assert value['counts'] == dict(tests=len(nodes), failures=0, errors=0, skipped=0)
    assert value['test_sha256'] == sha(source / 'tests' / (stem + '.py'))
    assert value['xml_sha256'] == sha(xml) and row['receipt_sha256'] == sha(receipt)
    assert value['errors'] == [] and value['device_barriers']
    assert all(b['status'] == 'complete' for b in value['device_barriers'])
    return value


def source_inheritance(candidate, previous, digest, label):
    current = verify_source(candidate, SOURCE, 584)
    old = verify_source(previous, digest, 581 if label == 'MX' else 584)
    assert set(old) <= set(current)
    assert {n for n in old if current[n] != old[n]} == NK
    assert set(current) - set(old) == (NF_ADDITIONS if label == 'MX' else set())
    return dict(origin=label, origin_manifest_sha256=digest, candidate_manifest_sha256=SOURCE,
                compared_original_files=len(old), changed_existing_files=sorted(NK),
                candidate_added_files=sorted(set(current)-set(old)),
                scope='All original GPU tests, fixtures, runtime and runners byte-exact. '
                      'Only NK offline assessor/CPU test differ; static dependency proof excludes both from GPU closure. '
                      'Original receipts retain their source identity.')


def closed_reuse(candidate, spec):
    mx = BASE / 'surface-root-regression-mx'
    nf = BASE / 'surface-root-permanent-nf'
    mx_plan, mx_exit = read(mx / 'plan.json'), read(mx / 'exit.json')
    mx_source = Path(mx_plan['source'])
    assert mx_exit['passed'] and mx_exit['failure'] is None and mx_exit['source_unchanged']
    assert mx_exit['source_manifest_sha256'] == ML
    assert mx_exit['original_nodes_attempted'] == mx_exit['total_original_nodes'] == 31
    assert len(mx_exit['records']) == len(MX_FILES)
    assert all(sha(mx / n) == h for n, h in mx_plan['controls_sha256'].items())
    proofs = {'MX': source_inheritance(candidate, mx_source, ML, 'MX')}
    reused = []
    rows = {v['file']: v for v in mx_exit['records']}
    assert set(rows) == set(MX_FILES)
    for name, count in MX_FILES.items():
        nodes = spec['gpu_nodes_by_file'][name]
        assert len(nodes) == count
        receipt_check(mx, Path(name).stem, rows[name], nodes, mx_source, ML)
        reused.append(dict(file=name, tests=count, original_source_manifest_sha256=ML,
                           original_root=str(mx), stem=Path(name).stem, actual_parent_returncode=0,
                           receipt_sha256=rows[name]['receipt_sha256']))
    nf_plan, nf_exit = read(nf / 'plan.json'), read(nf / 'exit.json')
    assert nf_exit['passed'] and nf_exit['failure'] is None and nf_exit['source_unchanged']
    assert all(sha(nf / n) == h for n, h in nf_plan['controls_sha256'].items())
    assert [v['actual_parent_returncode'] for v in nf_exit['records']] == [1, 0]
    nf_source = Path(nf_plan['variants']['positive']['source'])
    proofs['NF'] = source_inheritance(candidate, nf_source, NF, 'NF')
    out = nf / 'positive'
    value, audit = read(out / 'receipt.json'), read(out / 'audit.json')
    actual = read(out / 'worker-actual-exit.json')
    assert actual['actual_parent_returncode'] == value['worker_exitcode'] == value['pytest_returncode'] == 0
    assert value['passed'] and value['source_unchanged'] and value['source_manifest_sha256'] == NF
    assert value['node_coverage_exact'] and value['all_setup_call_teardown_phases_passed']
    assert value['nodes'] == read(out / 'expected.json') == spec['gpu_nodes_by_file'][NF_TEST]
    assert value['counts'] == dict(tests=1, failures=0, errors=0, skipped=0)
    assert value['test_sha256'] == sha(nf_source / 'tests' / NF_TEST)
    assert value['worker_sha256'] == WORKER and value['xml_sha256'] == sha(out / 'junit.xml')
    assert value['expected_nodes_sha256'] == sha(out / 'expected.json') and audit['receipt_sha256'] == sha(out / 'receipt.json')
    assert audit['phases_sha256'] == sha(out / 'phases.json')
    phases = read(out / 'phases.json')
    assert phases['pytest_exitstatus'] == 0
    assert [(v['when'], v['outcome']) for v in phases['reports']] == [('setup', 'passed'), ('call', 'passed'), ('teardown', 'passed')]
    assert value['errors'] == [] and {v['backend']: v['status'] for v in value['device_barriers']} == dict(jax='complete', cupy='complete')
    assert len(audit['same_precision_maximum_absolute_difference']) == 345
    assert max(audit['same_precision_maximum_absolute_difference'].values()) == 0
    reused.append(dict(file=NF_TEST, tests=1, original_source_manifest_sha256=NF,
                       original_root=str(out), stem=None, actual_parent_returncode=0,
                       receipt_sha256=sha(out / 'receipt.json')))
    assert sum(v['tests'] for v in reused) == 32
    return proofs, reused


def process_identity(pid):
    path = Path('/proc') / str(pid)
    try:
        values = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        try:
            cwd = str((path / 'cwd').resolve())
        except PermissionError:
            cwd = '<unreadable:PermissionError>'
        return dict(pid=pid, state=values[0], ppid=int(values[1]), pgid=int(values[2]),
                    sid=int(values[3]), start_ticks=int(values[19]),
                    cmdline=(path / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace').strip(),
                    cwd=cwd)
    except (FileNotFoundError, ProcessLookupError):
        return None


def promotion_check(folder):
    """Root creates these three proof records only after explicit queue replacement."""
    folder = Path(folder)
    promotion = read(folder / 'promotion.json')
    snapshot_path, stop_path = folder / 'old-jo-snapshot.json', folder / 'old-jo-stop.json'
    assert promotion['allow_new_gpu_queue'] is True and promotion['promoted_source_manifest_sha256'] == SOURCE
    assert promotion['source_archive_sha256'] == ARCHIVE
    assert re.fullmatch(r'[0-9a-f]{40}', promotion['promotion_commit'])
    assert promotion['old_jo_snapshot_sha256'] == sha(snapshot_path)
    assert promotion['old_jo_stop_sha256'] == sha(stop_path)
    snapshot, stopped = read(snapshot_path), read(stop_path)
    assert snapshot['root'] == str(BASE / 'ballberry-jo-full-gpu') and snapshot['source_manifest_sha256'] == JN
    assert stopped['snapshot_sha256'] == sha(snapshot_path)
    assert stopped['queue_cancelled_without_crediting_incomplete_module'] is True
    assert stopped['archive_sha256'] == sha(BASE / 'old-jo-seal-nq/old-jo-sealed.tar.gz')
    assert stopped['identities'] and snapshot['controller']['pid'] in {v['pid'] for v in stopped['identities']}
    assert {(v['pid'], v['start_ticks']) for v in snapshot['processes']} <= {(v['pid'], v['start_ticks']) for v in stopped['identities']}
    for old in stopped['identities']:
        current = process_identity(old['pid'])
        assert current is None or current['start_ticks'] != old['start_ticks'] or current['state'] == 'Z'
    old_root, old_source = snapshot['root'], snapshot['source']
    assert old_source == '/tmp/noahmp-ballberry-jo-full/source'
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            if path.stat().st_uid != os.getuid():
                continue
            current = process_identity(int(path.name))
            if current and current['state'] != 'Z':
                assert old_root not in current['cmdline'] and old_source not in current['cmdline']
                assert not current['cwd'].startswith(old_source)
        except (FileNotFoundError, ProcessLookupError):
            continue
    return promotion

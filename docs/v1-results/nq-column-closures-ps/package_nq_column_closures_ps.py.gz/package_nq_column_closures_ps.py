"""Stdlib verification and flat preservation of two closed original NQ modules."""
import ast
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
LABEL = 'nq-column-closures-ps'
STEMS = {'test_gpu_clm_optics_column': 3, 'test_gpu_clm_phenology_column': 4}
sha = lambda value: hashlib.sha256(value).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    raw = json.loads((OUT / (LABEL + '-raw.json')).read_bytes())
    files = {name: base64.b64decode(value) for name, value in raw['files'].items()}
    manifest = json.loads(files['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and raw['source_sha256_before'] == raw['source_sha256_after'] == manifest
    assert raw['all_selected_closed_files_unchanged']
    plan = json.loads(files['plan.json'])
    assert all(sha(files[name]) == expected for name, expected in plan['controls_sha256'].items())
    assert sha(files['candidate-full-gpu-nq-spec.json']) == plan['spec_sha256']
    spec = json.loads(files['candidate-full-gpu-nq-spec.json'])
    snapshot = json.loads((OUT / 'candidate-progress-ps.json').read_bytes())
    closed = {row['file']: row for row in snapshot['closed']}
    checks = {}
    for stem, count in STEMS.items():
        parent = json.loads(files[stem + '-exit.json'])
        receipt = json.loads(files[stem + '-receipt.json'])
        expected = json.loads(files[stem + '-expected.json'])
        assert parent == closed[stem + '.py']
        assert parent['actual_parent_returncode'] == 0 and parent['passed'] and parent['expected_tests'] == count
        assert sha(files[stem + '-receipt.json']) == parent['receipt_sha256']
        assert receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0 and receipt['passed']
        assert receipt['counts'] == dict(tests=count, failures=0, errors=0, skipped=0)
        assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed'] and receipt['source_unchanged']
        assert not receipt['errors']
        assert receipt['nodes'] == expected == spec['gpu_nodes_by_file'][stem + '.py']
        assert len(expected) == len(set(expected)) == count
        assert sha(files[stem + '-expected.json']) == receipt['expected_nodes_sha256']
        assert sha(files[stem + '.xml']) == receipt['xml_sha256']
        assert sha(files['SOURCE_SHA256.json']) == receipt['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
        assert receipt['source_files'] == 584
        assert receipt['test_sha256'] == manifest['tests/' + stem + '.py']
        assert receipt['worker_sha256'] == sha(files['run_pytest_worker_a.py'])
        assert {r['backend']: r['status'] for r in receipt['device_barriers']} == {'jax': 'complete', 'cupy': 'complete'}
        cases = list(ET.fromstring(files[stem + '.xml']).iter('testcase'))
        assert len(cases) == count and all(c.find(tag) is None for c in cases for tag in ('failure', 'error', 'skipped'))
        log = files[stem + '.log'].decode()
        summary = re.findall(r'(?m)^([0-9]+) passed in ([0-9.]+)s(?: .*)?$', log)
        assert len(summary) == 1 and int(summary[0][0]) == count
        records = [json.loads(line[len('ISOLATED_PYTEST_WORKER '):]) for line in log.splitlines() if line.startswith('ISOLATED_PYTEST_WORKER ')]
        assert len(records) == 1 and records[0] == {k: v for k, v in receipt.items() if k != 'nodes'}
        checks[stem] = dict(parent_returncode=0, worker_returncode=0, tests=count, skipped=0,
                           parent_seconds=parent['seconds'], receipt_sha256=parent['receipt_sha256'],
                           device_barriers=receipt['device_barriers'], original_source_unchanged=True)

    optics, optics_same, optics_budgets = [], [], []
    for line in files['test_gpu_clm_optics_column.log'].decode().splitlines():
        match = re.fullmatch(r"\.*PFT optics full BGC science (32|64) (False|True) (\{.*\})", line)
        if match:
            optics.append(dict(dtype='float' + match[1], structure=match[2] == 'True', values=ast.literal_eval(match[3])))
        match = re.fullmatch(r'\.*PFT optics complete raw sameprecision (\{.*\})', line)
        if match:
            optics_same.append(ast.literal_eval(match[1]))
        match = re.fullmatch(r'\.*PFT optics carried BGC budgets (False|True) ([01]) (\{.*\})', line)
        if match:
            optics_budgets.append(dict(structure=match[1] == 'True', interval=int(match[2]), values=ast.literal_eval(match[3])))
    assert len(optics) == 4 and {(r['dtype'], r['structure']) for r in optics} == {(d, s) for d in ('float32', 'float64') for s in (False, True)}
    assert len(optics_same) == len(optics_budgets) == 4
    assert all(not r['failed_fields'] and max(r['maximum_absolute'].values()) == 0 for r in optics_same)
    phen, phen_budgets, phen_same = [], [], []
    for line in files['test_gpu_clm_phenology_column.log'].decode().splitlines():
        match = re.fullmatch(r"\.*Phenology full native <class 'numpy\.(float32|float64)'> ([0-7]) (\{.*\})", line)
        if match:
            phen.append(dict(dtype=match[1], row=int(match[2]), values=ast.literal_eval(match[3])))
        match = re.fullmatch(r"\.*Phenology full budgets <class 'numpy\.(float32|float64)'> ([01]) (\{.*\})", line)
        if match:
            phen_budgets.append(dict(dtype=match[1], interval=int(match[2]), values=ast.literal_eval(match[3])))
        match = re.fullmatch(r'\.*Phenology full same precision ([01]) ([0-9.eE+\-]+)', line)
        if match:
            phen_same.append(dict(interval=int(match[1]), maximum_absolute=float(match[2])))
        match = re.fullmatch(r'\.*Phenology full CUDA budgets ([01]) (\{.*\})', line)
        if match:
            phen_budgets.append(dict(dtype='cuda32', interval=int(match[1]), values=ast.literal_eval(match[2])))
    assert len(phen) == 32 and all(sum(r['dtype'] == d and r['row'] == k for r in phen) == 2 for d in ('float32', 'float64') for k in range(8))
    assert len(phen_budgets) == 6 and phen_same == [dict(interval=0, maximum_absolute=0.), dict(interval=1, maximum_absolute=0.)]
    maxima = {d: {k: max(r['values'][k] for r in phen if r['dtype'] == d)
                 for k in ('h', 'le', 'g', 'soil_temperature', 'gpp_umol_m2s', 'lai')} for d in ('float32', 'float64')}
    quantified = dict(optics_reference=optics, optics_sameprecision=optics_same, optics_carried_budgets=optics_budgets,
                      phenology_reference=phen, phenology_reference_maxima=maxima, phenology_budgets=phen_budgets,
                      phenology_sameprecision=phen_same,
                      limits=['All quoted differences are original log numbers; no NumPy or physical calculation was performed.',
                              'Absolute maxima alone do not establish relative bias; original per-case scientific assertions remain in the logs/tests.',
                              'Independent maxima of residual and bound must not be treated as a paired per-column assertion.',
                              'These seven nodes are module credit, not annual success or completion of the 408-node suite.'])
    estimate = json.loads((OUT / 'GPU_ETA_NQ_PS_REFRESH.json').read_bytes())
    assert estimate['regression']['completed'] == 155 and estimate['regression']['fresh'] == 123
    assert estimate['regression']['reused'] == 32 and estimate['regression']['remaining_nodes'] == 253
    assert all(row['status'] == 'failed' and row['conditional_remaining_hours'] is None for row in estimate['years'].values())
    for name in ('candidate-progress-ps-exit.json', LABEL + '-exit.json'):
        assert json.loads((OUT / name).read_bytes())['actual_ssh_exit'] == 0
    verification = dict(passed=True, source_files=584, source_before_after_exact=True,
                        original_module_results=checks, original_all_nodes_and_phases_closed=True,
                        snapshot_completed_nodes=155, active_structure_nodes_credited=0,
                        gpu_app_pids_outside_sampled_task_family=estimate['gpu_app_pids_outside_sampled_task_family'],
                        numerical_execution=False, scope='Independent stdlib raw-log/XML/receipt/source verification, not numerical reexecution.')
    items = {'original/' + n: b for n, b in files.items()}
    with tarfile.open(OUT / 'climatology-final-candidate-nm-source.tar.gz') as source_archive:
        for stem in STEMS:
            name = 'tests/' + stem + '.py'
            content = source_archive.extractfile(name).read()
            assert sha(content) == manifest[name]
            items['original-source/' + name] = content
    proof = {key: value for key, value in raw.items() if key != 'files'}
    items.update({'source-and-closed-files-proof.json': encode(proof), 'quantified.json': encode(quantified), 'verification.json': encode(verification)})
    for name in ('candidate-progress-ps.json', 'candidate-progress-ps.stderr', 'candidate-progress-ps-exit.json',
                 LABEL + '.stderr', LABEL + '-exit.json', 'review_candidate_concurrency_nt.py',
                 'read_nq_column_closures_ps.py', 'package_nq_column_closures_ps.py',
                 'refresh_gpu_eta_ps.py', 'GPU_ETA_NQ_PS_REFRESH.json', 'GPU_ETA_NQ.json'):
        items[name] = (OUT / name).read_bytes()
    items['inventory.json'] = encode({n: dict(bytes=len(b), sha256=sha(b)) for n, b in sorted(items.items())})
    target = OUT / (LABEL + '-evidence.tar.gz')
    with target.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for name, content in sorted(items.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode = len(content), 0o644
                archive.addfile(member, io.BytesIO(content))
    with tarfile.open(target) as archive:
        assert {member.name: archive.extractfile(member).read() for member in archive} == items
    package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
                   artifacts=len(items), actual_new_tests=7, actual_closed_gpu_nodes=155,
                   scope='Original NQ optics3 and phenology4 actual0 closures; full raw logs/XML/receipts/diagnostics/source/control proof and one CUDA1 PS snapshot. Conditional regression ETA only; NS/NZ remain failed7275, no running-year ETA or new model execution.')
    (OUT / (LABEL + '-package.json')).write_bytes(encode(package))
    (OUT / (LABEL + '-verification.json')).write_bytes(encode(verification))
    (OUT / (LABEL + '-quantified.json')).write_bytes(encode(quantified))
    print(json.dumps(dict(package=package, phenology_maxima=maxima, optics_sameprecision_fields=[len(r['maximum_absolute']) for r in optics_same],
                          eta=estimate['regression']['remaining_hours']), indent=2))


if __name__ == '__main__':
    main()

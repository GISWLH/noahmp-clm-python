"""One bounded same-year continuation, preserving every original global ledger."""
from pathlib import Path
import hashlib
import json
import os
import pickle
import resource
import shutil
import socket
import sys
import tarfile
import time
import traceback

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def expand(path, target):
    target.mkdir()
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len({m.name for m in members}) == len(members)
        for member in members:
            out = target / member.name
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(archive.extractfile(member).read())


def main():
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    case_index, start = int(os.environ['PJ_CASE_INDEX']), int(os.environ['PJ_START'])
    assert 0 <= case_index < 8 and 48 <= start < 17520 and (start - 48) % 480 == 0
    stop = min(start + 480, 17520)
    parent = ROOT / 'closed' / ('case-' + str(case_index)) / ('stop-' + str(start).zfill(7) + '.tar.gz')
    assert sha(parent.read_bytes()) == os.environ['PJ_PARENT_SHA']
    result = Path(os.environ['TMPDIR']) / 'result'
    began, guard = time.monotonic(), None
    summary = dict(pbs_job=os.environ['PBS_JOBID'], case_index=case_index, start=start, stop=stop,
        requested_original_steps=stop-start, original_steps_started=0, original_steps_completed=0,
        node=socket.gethostname(), pid=os.getpid(), passed=False, error=None, source_unchanged=False,
        parent_archive_sha256=os.environ['PJ_PARENT_SHA'], GPU_steps=0, score_eligible=False, spinup_accepted=False)
    try:
        stage_index = json.loads((ROOT / 'STAGE_SHA256.json').read_bytes())
        assert all(sha((ROOT / n).read_bytes()) == h for n, h in stage_index.items())
        fixed = json.loads((ROOT / 'preparation/PJ_BINDINGS.json').read_bytes())
        expand(parent, result)
        sys.path.insert(0, str(ROOT / 'pf'))
        import own_spinup_pf as pf
        from capture_bgc_pf import BGCRecorder, records
        from cpu_trace_budget import audit_cpu_trace
        sys.path.insert(0, str(ROOT / 'preparation'))
        from resume_pj import verify_partial, verify_bgc, expected_first, FirstInputGuard, probe_original_resume_input
        from run_window_pj import run_window
        descriptor = dict(directory=str(result), inventory_sha256=sha((result / 'ARTIFACT_SHA256.json').read_bytes()),
                          run='run', terminals='terminals.json')
        _, run, _, terminals = pf.closed_packet(descriptor)
        identity = fixed['identities'][case_index]
        assert identity == pf.contract.request('om-baseline', identity['case'], 'spinup', 1)
        source = result.parent / 'source-nm584'
        expand(ROOT / 'inputs/climatology-final-candidate-nm-source.tar.gz', source)
        runner, _, _ = pf.runtime(source)
        before = verify_partial(runner, result, identity, start, terminals)
        paths = dict(configuration=result / 'inputs/configuration.json', input=result / 'inputs/forcing.npz',
                     input_manifest=result / 'inputs/forcing.json')
        data, config = pf.adapter.validate_inputs(runner, paths, identity)
        assert config == before['report']['configuration']
        # Preserve replaced top-level envelope bytes; all original physical data stay in place.
        history = result / 'window-history' / ('stop-' + str(start).zfill(7))
        history.mkdir(parents=True)
        for name in ['receipt.json', 'window-audit.json', 'controller.log', 'worker-exit.txt',
                     'ARTIFACT_SHA256.json', 'BGC_STREAMS.json']:
            if (result / name).exists():
                shutil.copyfile(result / name, history / name)
        # Inventory is regenerated only by the post-F0 closure process.
        (result / 'ARTIFACT_SHA256.json').unlink()
        metadata = pf.contract.read_json(paths['input_manifest'])
        forcing, kwargs = expected_first(runner, data, metadata, config, start, paths['input'])
        if start == 48:
            probe = probe_original_resume_input(runner, run, paths, before['saved'], forcing, kwargs,
                                               result / 'first-resume-input-probe')
            assert probe['actual_original_tendencies'] == 0 and probe['allowed_as_parent'] is False
        stream_path = result / 'bgc-windows' / ('start-' + str(start).zfill(7))
        stream_path.parent.mkdir(exist_ok=True)
        guard = FirstInputGuard(runner, before['saved'], forcing, kwargs)
        with guard:
            with BGCRecorder(runner, identity, data['time_start'], data['time_end'], stream_path, start_index=start):
                receipt = run_window(runner, source, paths, identity, run, stop_after=stop-start, resume=True)
        assert guard.started == guard.completed == receipt['successful_tendency_calls'] == stop-start
        segment = run / ('segment-' + str(start).zfill(7))
        start_original = segment / 'start-originals'
        original_start_report = pf.contract.read_json(start_original / 'report.json')
        saved_start = pickle.loads((start_original / original_start_report['checkpoint_file']).read_bytes())
        carry = pf.adapter.assert_content_exact(saved_start, before['saved'], runner.np)
        report = pf.contract.read_json(run / 'trajectory/report.json')
        _, saved, trace = pf.adapter._generation(runner, run / 'trajectory', report, complete=stop == 17520)
        assert report['status'] == ('complete' if stop == 17520 else 'running')
        assert report['steps_completed'] == saved[-1] == stop and report['steps_requested'] == 17520
        prefix = {key: pf.adapter.assert_content_exact(trace[key][:start], before['trace'][key], runner.np)
                  for key in trace}
        for key in ('time_start', 'time_end'):
            pf.adapter.assert_content_exact(trace[key], data[key][:stop], runner.np)
        budget = audit_cpu_trace(runner, dict(saved=saved, trace=trace), run)
        index = pf.contract.read_json(result / 'BGC_STREAMS.json')
        index['streams'].append(dict(directory=stream_path.relative_to(result).as_posix(),
            header_sha256=sha((stream_path / 'BGC_STREAM.json').read_bytes()), first_index=start, stop_index=stop))
        write(result / 'BGC_STREAMS.json', index)
        cold = pickle.loads((result / 'own-cold-seed/own-cold-state.pkl').read_bytes())
        bgc = verify_bgc(runner, result, identity, stop, saved[0], cold[0].bgc_state)
        # Validate every new record timestamp against the unchanged full-year forcing.
        for row in records(stream_path):
            assert row['time_start'] == str(data['time_start'][row['index']])
            assert row['time_end'] == str(data['time_end'][row['index']])
        residual = runner.totals(saved[0]) - saved[1] - saved[2]
        audit = dict(identity=identity, start=start, stop=stop, same_year_resume=True,
            full_seven_tuple_at_original_resume_exact=carry, original_trace_prefix_exact=prefix,
            first_original_input_exact=guard.proof, original_trace_budget=budget, full_BGC_chain=bgc,
            residual_m_h_c_n=residual.tolist(), bounds_m_h_c_n=saved[3].tolist(),
            original_steps_started=guard.started, original_steps_completed=guard.completed,
            original_status=report['status'], calendar_intervals=17520, complete_original_year=stop == 17520,
            accepted_spinup=False, score_eligible=False, auto_cycle2=False)
        write(result / 'window-audit.json', audit)
        assert all(sha((ROOT / n).read_bytes()) == h for n, h in stage_index.items())
        pf.adapter.verify_source(source)
        summary.update(passed=True, identity=identity, source_unchanged=True, source_files=584,
            original_steps_started=guard.started, original_steps_completed=guard.completed,
            original_report_status=report['status'], saved_intervals=stop, full_BGC_records=stop,
            first_resume_seven_tuple_max_abs_difference=carry['max_abs_difference'], trace_prefix_fields=len(prefix),
            window_audit_sha256=sha((result / 'window-audit.json').read_bytes()),
            run_receipt_sha256=sha((run / 'receipt.json').read_bytes()),
            source_manifest_sha256=identity['source_manifest_sha256'],
            controls_manifest_sha256=sha((ROOT / 'preparation/CONTROLS_SHA256.json').read_bytes()))
    except Exception as exc:
        result.mkdir(exist_ok=True)
        summary['error'] = type(exc).__name__ + ': ' + str(exc)
        (result / 'PJ-traceback.txt').write_text(traceback.format_exc())
    if guard is not None:
        summary['original_steps_started'], summary['original_steps_completed'] = guard.started, guard.completed
    summary.update(seconds=time.monotonic()-began, maximum_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    write(result / 'receipt.json', summary)
    print(json.dumps(summary), flush=True)
    raise SystemExit(0 if summary['passed'] else 1)


if __name__ == '__main__':
    main()

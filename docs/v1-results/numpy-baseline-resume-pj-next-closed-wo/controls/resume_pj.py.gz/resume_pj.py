"""Exact same-year partial-window validation and first original input guard."""
from pathlib import Path
import json
import pickle
import shutil

import own_spinup_pf as pf
from capture_bgc_pf import records
from cpu_trace_budget import audit_cpu_trace


def expected_first(runner, data, metadata, config, index, input_path):
    """Only original runner constructors/calendar/deposition; no tendency."""
    stamps = runner.validate_input(data, metadata, Path(input_path))
    f = runner.Forcing(*data['forcing'][index])
    co2, mu, diffuse = data['environment'][index]
    deposition = runner.DepositionSchedule(config)
    hydrology = runner.hydrology_configuration(config)
    capacity = runner.capacity_configuration(config)
    optics = None if config.get('canopy_optics') is None else runner.CanopyOptics(**config['canopy_optics'])
    kwargs = dict(co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse),
        leaf_dimension=config['leaf_dimension_m'], leaf_parameters=runner.LeafParameters(**config['leaf_parameters']),
        most_geometry=runner.MOSTGeometry(**config['most_geometry']),
        phenology_environment=runner.calendar(stamps[index], metadata, config['phenology'] is not None),
        deposition_rates=deposition.aerosol(stamps[index], f.dt), nitrogen_deposition_gn_m2=deposition.nitrogen_rate*f.dt,
        capacity_environment=runner.capacity_environment(stamps[index], metadata, capacity is not None),
        **({} if optics is None else dict(canopy_optics=optics)),
        **({} if hydrology is None else dict(soil_hydrology=hydrology)))
    return f, kwargs


def verify_bgc(runner, root, identity, expected_stop, final_state, initial_bgc):
    raw = (root / 'BGC_STREAMS.json').read_bytes()
    index = json.loads(raw)
    pf.require(index['identity'] == identity and bool(index['streams']), 'BGC stream identity/list')
    count, previous, hashes = 0, initial_bgc, []
    for stream in index['streams']:
        path = root / stream['directory']
        pf.require(path.resolve().is_relative_to(root.resolve()), 'Unsafe stream path')
        header_raw = (path / 'BGC_STREAM.json').read_bytes()
        pf.require(pf.sha(header_raw) == stream['header_sha256'], 'Original BGC header changed')
        header = json.loads(header_raw)
        pf.require(header['identity'] == identity and header['first_index'] == count
            and header['stop_index'] == stream['stop_index'] and stream['first_index'] == count
            and header['original_call_completed_without_exception'] is True, 'BGC original window continuity')
        for row in records(path):
            pf.require(row['index'] == count, 'BGC interval gap/overlap')
            pf.adapter.assert_content_exact(row['before_bgc'], previous, runner.np)
            previous = row['after_bgc']
            count += 1
        pf.require(count == header['stop_index'], 'BGC window record count differs')
        hashes.append(dict(directory=stream['directory'], header_sha256=stream['header_sha256'],
                           first_index=stream['first_index'], stop_index=count))
    pf.require(count == expected_stop, 'BGC/current endpoint step count differs')
    exact = pf.adapter.assert_content_exact(previous, final_state.bgc_state, runner.np)
    return dict(records=count, streams=hashes, final_BGC_exact=exact, stream_index_sha256=pf.sha(raw))


def verify_partial(runner, root, identity, expected_start, terminals):
    """Never call the complete-parent validator for a same-year partial."""
    run = root / 'run'
    report = pf.contract.read_json(run / 'trajectory/report.json')
    pf.require(report['status'] == 'running' and report['steps_completed'] == expected_start
               and report['steps_requested'] == 17520 and expected_start < 17520, 'Actual same-year partial required')
    raw, saved, trace = pf.adapter._generation(runner, run / 'trajectory', report, complete=False)
    context = pf.contract.read_json(run / 'start-context.json')
    chain = pf.contract.read_json(run / 'chain-state.json')
    pf.require(context['identity'] == chain['identity'] == identity and context['mode'] == 'cold'
        and context['previous_ledger_steps'] == 0 and context['ledger_segments'] == 1
        and chain['ledger_steps'] == expected_start and chain['ledger_segments'] == 1,
        'Original cold/global ledger or same-year identity changed')
    pf.require(chain['report_sha256'] == pf.sha((run / 'trajectory/report.json').read_bytes())
        and chain['start_context_sha256'] == pf.sha((run / 'start-context.json').read_bytes()), 'Original chain report binding')
    calls, used = 0, set()
    for segment in sorted(run.glob('segment-*')):
        receipt = pf.contract.read_json(segment / 'receipt.json')
        pf.require(receipt['identity'] == identity and receipt['worker_completed'] is True
            and receipt['failure'] is None and receipt['source_unchanged'] is True
            and receipt['first_start_exact'] is True and receipt['pbs_job'] in terminals,
            'Every prior physical segment requires its own real F0 closure')
        pf.require(receipt['start_index'] == calls and receipt['stop_index'] == calls + receipt['successful_tendency_calls'],
                   'Prior segment call/index chain differs')
        calls = receipt['stop_index']
        used.add(receipt['pbs_job'])
        for name, digest in pf.contract.read_json(segment / 'capture-SHA256.json').items():
            path = segment / name
            pf.require(path.resolve().is_relative_to(segment.resolve()) and pf.sha(path.read_bytes()) == digest,
                       'Prior original capture changed')
    pf.require(calls == expected_start and used == set(terminals), 'Incomplete physical/terminal history')
    receipt = pf.contract.read_json(run / 'receipt.json')
    pf.require(receipt['report_sha256'] == pf.sha((run / 'trajectory/report.json').read_bytes())
        and receipt['chain_sha256'] == pf.sha((run / 'chain-state.json').read_bytes()), 'Last segment endpoint binding differs')
    budget = audit_cpu_trace(runner, dict(saved=saved, trace=trace), run)
    seed = pickle.loads((root / 'own-cold-seed/own-cold-state.pkl').read_bytes())
    bgc = verify_bgc(runner, root, identity, expected_start, saved[0], seed[0].bgc_state)
    return dict(report=report, saved=saved, state_raw=raw, trace=trace, budget=budget, bgc=bgc)


class FirstInputGuard:
    def __init__(self, runner, saved, forcing, kwargs):
        self.runner, self.saved, self.forcing, self.kwargs = runner, saved, forcing, kwargs
        self.started = self.completed = 0
        self.proof = None

    def __enter__(self):
        self.original = self.runner.step_clm_enthalpy_column
        self.runner.step_clm_enthalpy_column = self.call
        return self

    def call(self, before, forcing, **kwargs):
        if self.started == 0:
            self.proof = dict(before_state=pf.adapter.assert_content_exact(before, self.saved[0], self.runner.np),
                forcing=pf.adapter.assert_content_exact(forcing, self.forcing, self.runner.np),
                kwargs=pf.adapter.assert_content_exact(kwargs, self.kwargs, self.runner.np))
        self.started += 1
        after, diagnostics = self.original(before, forcing, **kwargs)
        self.completed += 1
        return after, diagnostics

    def __exit__(self, *error):
        self.runner.step_clm_enthalpy_column = self.original
        return False


def probe_original_resume_input(runner, parent, paths, saved, forcing, kwargs, output):
    """First-window-only zero-forward probe on a separate copy, never a parent."""
    output.mkdir()
    report = pf.contract.read_json(parent / 'trajectory/report.json')
    for name in ['report.json', report['checkpoint_file'], report['model_npz']]:
        shutil.copyfile(parent / 'trajectory' / name, output / name)
    proof = {}

    class StopBeforePhysicalStep(RuntimeError):
        pass

    def capture(before, actual_forcing, **actual_kwargs):
        proof.update(state=pf.adapter.assert_content_exact(before, saved[0], runner.np),
            forcing=pf.adapter.assert_content_exact(actual_forcing, forcing, runner.np),
            kwargs=pf.adapter.assert_content_exact(actual_kwargs, kwargs, runner.np))
        (output / 'actual-first-input.pkl').write_bytes(pickle.dumps(dict(before=before, forcing=actual_forcing,
            kwargs=actual_kwargs), protocol=5))
        raise StopBeforePhysicalStep('PJ deliberate first-input read; no original tendency called')

    original = runner.step_clm_enthalpy_column
    try:
        runner.step_clm_enthalpy_column = capture
        try:
            runner.run(*(paths[k] for k in ('input', 'input_manifest', 'configuration')), output,
                       resume=True, stop_after=1)
        except StopBeforePhysicalStep:
            pass
        else:
            raise ValueError('Original first-input probe did not stop before tendency')
    finally:
        runner.step_clm_enthalpy_column = original
    after = pf.contract.read_json(output / 'report.json')
    pf.require(after['status'] == 'failed' and after['failed_index'] == saved[-1]
        and after['steps_completed'] == saved[-1] and len(proof) == 3,
        'Probe must retain its intentional failed status and zero physical advancement')
    exact = pf.adapter.assert_content_exact(pickle.loads((output / after['checkpoint_file']).read_bytes()), saved, runner.np)
    result = dict(expected_controlled_stop=True, actual_original_tendencies=0,
        original_report_status='failed', actual_index=saved[-1], allowed_as_parent=False,
        exact_full_seven_tuple=exact, actual_first_input=proof)
    (output / 'PROBE_ONLY.json').write_bytes(pf.contract.json_bytes(result))
    return result

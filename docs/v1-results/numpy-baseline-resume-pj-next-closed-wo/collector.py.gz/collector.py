"""Read-only collection of eight fixed PJ windows; byte-level file deltas only."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import io
import json
import re
import socket
import tarfile

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')
LABEL = 'numpy-baseline-resume-pj-next-closed-wo'
CONTROL_SHA = '0f044fd60a1c870396075f63e1f87ff724ada6362072fe882fcd43fe1e7c3770'
SOURCE_SHA = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
PARENT_PUBLIC_SHA = '63752d66bfd757cd83e0dbcaa5e8ba260b90e77c46024197d2e51f07342c157c'
PARENT_SHAS = [
    '21b1eb0fa42d1ef8140a0020aed0246281c708039d8ad4f0345795318d4dc6e9',
    '3358df637e9d843d33c0095f7590e5f13dc3dfddf9990826d9047261de0f3721',
    '2ba3873c85879f1b8b9bc2bfb5f56875e2b5b9de00008b2c2b187cde817cea65',
    '7c2ec9c7b2f039dff4038ce053cfe3948e826490b50f60741ad66da45c51c535',
]
JOBS = {0: ['1643.manager', '1648.manager'], 1: ['1646.manager', '1652.manager'],
        2: ['1644.manager', '1650.manager'], 3: ['1645.manager', '1651.manager']}
sha = lambda b: hashlib.sha256(b).hexdigest()
js = lambda x: (json.dumps(x, indent=2, allow_nan=False) + '\n').encode()


def read_tar(body):
    with tarfile.open(fileobj=io.BytesIO(body)) as archive:
        entries = archive.getmembers()
        assert all((m.isfile() or m.isdir()) and not PurePosixPath(m.name).is_absolute()
                   and '..' not in PurePosixPath(m.name).parts for m in entries)
        members = [m for m in entries if m.isfile()]
        raw = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in members}
        assert len(raw) == len(members)
    return raw


def verify_inventory(raw):
    index = json.loads(raw['ARTIFACT_SHA256.json'])
    assert set(raw) == set(index) | {'ARTIFACT_SHA256.json'}
    assert all(sha(raw[n]) == h for n, h in index.items())
    return {n: sha(b) for n, b in sorted(raw.items())}


def verify_terminal(raw, job, paths):
    qstat = raw[paths['qstat']]
    assert re.search(rb'^Job Id: ' + re.escape(job.encode()) + rb'\s*$', qstat, re.M)
    for key, value in [('job_state', 'F'), ('Exit_status', '0'), ('Stageout_status', '0')]:
        assert re.search(rb'^\s*' + key.encode() + rb' = ' + value.encode() + rb'\s*$', qstat, re.M)
    assert raw[paths['parent_exit']].strip() == raw[paths['worker_exit']].strip() == b'0'


def verify_window(raw, identity, job, start, stop, parent_sha):
    receipt = json.loads(raw['receipt.json'])
    audit = json.loads(raw['window-audit.json'])
    assert receipt['passed'] is True and receipt['error'] is None
    assert receipt['pbs_job'] == job and receipt['node'] == 'compute002'
    assert receipt['identity'] == audit['identity'] == identity
    assert receipt['parent_archive_sha256'] == parent_sha
    assert receipt['source_unchanged'] is True and receipt['source_files'] == 584
    assert receipt['source_manifest_sha256'] == SOURCE_SHA
    assert receipt['controls_manifest_sha256'] == CONTROL_SHA
    assert receipt['start'] == audit['start'] == start and receipt['stop'] == audit['stop'] == stop
    assert receipt['original_steps_started'] == receipt['original_steps_completed'] == 480
    assert receipt['saved_intervals'] == receipt['full_BGC_records'] == stop
    assert receipt['GPU_steps'] == 0 and receipt['score_eligible'] is False
    assert receipt['spinup_accepted'] is False and receipt['original_report_status'] == 'running'
    assert sha(raw['window-audit.json']) == receipt['window_audit_sha256']
    assert sha(raw['run/receipt.json']) == receipt['run_receipt_sha256']
    proof = audit['full_seven_tuple_at_original_resume_exact']
    assert proof['max_abs_difference'] == 0 and proof['arrays'] == 20 and proof['scalars'] == 116
    assert all(p['bytes_exact'] for p in proof['array_fields'].values())
    assert all(p['exact'] for p in proof['scalar_fields'].values())
    assert len(audit['original_trace_prefix_exact']) == 18
    assert all(p['max_abs_difference'] == 0 for p in audit['original_trace_prefix_exact'].values())
    assert all(p['max_abs_difference'] == 0 for p in audit['first_original_input_exact'].values())
    assert audit['same_year_resume'] and audit['calendar_intervals'] == 17520
    assert audit['complete_original_year'] is False and audit['accepted_spinup'] is False
    assert audit['score_eligible'] is False and audit['auto_cycle2'] is False
    assert audit['original_trace_budget']['intervals'] == stop
    assert audit['original_trace_budget']['original_bounds_preserved'] is True
    assert audit['original_trace_budget']['original_nee_carbon_exchange_exact'] is True
    assert len(audit['residual_m_h_c_n']) == len(audit['bounds_m_h_c_n']) == 4
    assert all(abs(v) <= b for v, b in zip(audit['residual_m_h_c_n'], audit['bounds_m_h_c_n']))
    assert audit['full_BGC_chain']['records'] == stop
    assert audit['full_BGC_chain']['final_BGC_exact']['max_abs_difference'] == 0
    terms = json.loads(raw['terminals.json'])
    assert job in terms
    for j, paths in terms.items():
        verify_terminal(raw, j, paths)
    streams = json.loads(raw['BGC_STREAMS.json'])
    assert streams['identity'] == identity
    expected = [(0, 48)] + [(k, min(k + 480, stop)) for k in range(48, stop, 480)]
    assert [(s['first_index'], s['stop_index']) for s in streams['streams']] == expected
    for stream in streams['streams']:
        prefix = stream['directory'] + '/'
        header_raw = raw[prefix + 'BGC_STREAM.json']
        assert sha(header_raw) == stream['header_sha256']
        header = json.loads(header_raw)
        count = stream['stop_index'] - stream['first_index']
        assert header['successful_original_tendencies_recorded'] == count
        assert header['original_call_completed_without_exception'] is True
        assert sum(b['count'] for b in header['blocks']) == count
        assert all(sha(raw[prefix + b['file']]) == b['sha256'] for b in header['blocks'])
    return dict(pbs_job=job, start=start, stop=stop, actual_F0=True, actual_Stageout0=True,
        new_steps=480, BGC_records=stop, seconds=receipt['seconds'],
        seven_tuple_arrays=20, seven_tuple_scalars=116, seven_tuple_max_difference=0,
        prefix_fields=18, prefix_max_difference=0, first_input_max_difference=0,
        BGC_endpoint_max_difference=0, residual_m_h_c_n=audit['residual_m_h_c_n'],
        bounds_m_h_c_n=audit['bounds_m_h_c_n'], original_trace_budget=audit['original_trace_budget'],
        numerical_audits_executed_by='Original EHPC compute002 worker; collector reads hash-bound JSON only.')


def main():
    assert socket.gethostname() == 'manager'
    target = Path('/tmp') / (LABEL + '-evidence.tar.gz')
    assert not target.exists()
    raw_progress = (ROOT / 'PROGRESS.json').read_bytes()
    progress = json.loads(raw_progress)
    data = {'snapshot/PROGRESS.json': raw_progress, 'collector.py': Path(__file__).read_bytes()}
    controls_raw = (ROOT / 'preparation/CONTROLS_SHA256.json').read_bytes()
    assert sha(controls_raw) == CONTROL_SHA
    controls = json.loads(controls_raw)
    data['controls/CONTROLS_SHA256.json'] = controls_raw
    for n, h in controls.items():
        b = (ROOT / 'preparation' / n).read_bytes()
        assert sha(b) == h
        data['controls/' + n] = b
    for n in ['LAUNCH.json', 'CONTROLLER_STARTED.json']:
        data['launch/' + n] = (ROOT / n).read_bytes()
    rows = []
    for i in range(4):
        case = progress['cases'][i]
        assert case['case_index'] == i and case['identity']['site'] == 'CN-Cng'
        parent_path = ROOT / 'closed' / ('case-' + str(i)) / 'stop-0000528.tar.gz'
        parent_sha = PARENT_SHAS[i]
        parent_body = parent_path.read_bytes()
        assert sha(parent_body) == parent_sha
        parent = read_tar(parent_body)
        verify_inventory(parent)
        for sequence, stop in enumerate([1008, 1488]):
            start = stop - 480
            history = next(h for h in case['history'] if h['stop'] == stop)
            assert history['start'] == start and history['job'] == JOBS[i][sequence]
            path = ROOT / 'closed' / ('case-' + str(i)) / ('stop-' + str(stop).zfill(7) + '.tar.gz')
            body = path.read_bytes()
            assert sha(body) == history['closed_archive_sha256'] and len(body) == history['closed_archive_bytes']
            raw = read_tar(body)
            member_hashes = verify_inventory(raw)
            row = verify_window(raw, case['identity'], history['job'], start, stop, parent_sha)
            closure = json.loads(raw['closure-records/stop-' + str(stop).zfill(7) + '.json'])
            assert closure['parent_archive_sha256'] == parent_sha
            assert closure['controller_source_sha256'] == controls['controller_pj.py']
            assert closure['actual_F0'] is True and closure['actual_stageout0'] is True
            original_path = ROOT / 'actual' / ('case-' + str(i)) / ('start-' + str(start).zfill(7)) / 'result.tar.gz'
            original_body = original_path.read_bytes()
            original_sha = sha(original_body)
            assert original_sha == history['original_result_archive_sha256'] == closure['original_result_archive_sha256']
            original = read_tar(original_body)
            # The worker raw tar precedes controller closure/inventory creation.
            assert 'ARTIFACT_SHA256.json' not in original
            assert {n: sha(b) for n, b in original.items()} == closure['original_result_members']
            assert set(original) <= set(raw)
            assert {n for n in original if original[n] != raw[n]} == {'terminals.json'}
            added = sorted(set(raw) - set(parent))
            removed = sorted(set(parent) - set(raw))
            replaced = sorted(n for n in raw.keys() & parent.keys() if raw[n] != parent[n])
            unchanged = sorted(n for n in raw.keys() & parent.keys() if raw[n] == parent[n])
            prefix = 'deltas/case-' + str(i) + '/stop-' + str(stop).zfill(7) + '/'
            delta = dict(case_index=i, identity=case['identity'], parent_stop=start, stop=stop,
                parent_archive_path=str(parent_path), parent_archive_sha256=parent_sha,
                new_archive_path=str(path), new_archive_sha256=sha(body), new_archive_bytes=len(body),
                original_result_archive_path=str(original_path), original_result_archive_sha256=original_sha,
                new_members_sha256=member_hashes, parent_members_sha256={n: sha(b) for n, b in sorted(parent.items())},
                added=added, replaced=replaced, removed=removed, unchanged=unchanged,
                reconstruction='Exact original member bytes, including whole ZIP/NPZ files. Not original tar.gz container bytes.',
                original_compressed_archives_retained=True)
            for n in added + replaced:
                data[prefix + 'files/' + n] = raw[n]
            for n in ['terminals.json']:
                data[prefix + 'result-originals/' + n] = original[n]
            reconstructed = {n: b for n, b in parent.items() if n not in removed}
            reconstructed.update({n: data[prefix + 'files/' + n] for n in added + replaced})
            assert reconstructed == raw
            data[prefix + 'DELTA.json'] = js(delta)
            row.update(case_index=i, case=case['identity']['case'], delta_path=prefix+'DELTA.json',
                parent_archive_sha256=parent_sha, new_archive_sha256=sha(body),
                original_result_archive_sha256=original_sha, original_member_count=len(raw),
                added_files=len(added), replaced_files=len(replaced), removed_files=len(removed), unchanged_files=len(unchanged))
            rows.append(row)
            assert sha(path.read_bytes()) == history['closed_archive_sha256']
            assert sha(original_path.read_bytes()) == original_sha and sha(parent_path.read_bytes()) == parent_sha
            parent, parent_sha, parent_path = raw, sha(body), path
    summary = dict(collected_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        snapshot_utc=progress['snapshot_utc'], parent_public_archive='numpy-baseline-resume-pj-first-closed-evidence.tar.gz',
        parent_public_sha256=PARENT_PUBLIC_SHA, controls_manifest_sha256=CONTROL_SHA,
        source_manifest_sha256=SOURCE_SHA, source_files=584, actual_closed_windows=8,
        actual_new_steps=3840, selected_endpoints=[1488]*4, new_complete_years=0,
        accepted_spinup=False, scored=False, GPU_steps=0, collection_physics_steps=0,
        Qia_or_live_window_completion_credit=0, rows=rows,
        scope='Eight actual closed Cng windows 528 to 1008 to 1488; raw per-file deltas against published first528 packet. Original compressed archives retained on EHPC. No model or array decoding during collection. Original worker numerical audits only.')
    assert len(rows) == 8
    data['SUMMARY.json'] = js(summary)
    data['INTEGRITY.json'] = js({n: sha(b) for n, b in sorted(data.items())})
    with tarfile.open(target, 'w:gz') as archive:
        for n, b in sorted(data.items()):
            item = tarfile.TarInfo(n)
            item.size = len(b)
            archive.addfile(item, io.BytesIO(b))
    assert read_tar(target.read_bytes()) == data
    package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
        artifacts=len(data), inventory_files=len(data)-1, **summary)
    (target.parent / (LABEL + '-package.json')).write_bytes(js(package))
    print(json.dumps({k: v for k, v in package.items() if k != 'rows'}))


if __name__ == '__main__':
    main()

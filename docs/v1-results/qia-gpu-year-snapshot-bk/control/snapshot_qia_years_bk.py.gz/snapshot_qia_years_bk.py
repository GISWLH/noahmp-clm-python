from pathlib import Path
import datetime,hashlib,io,json,subprocess,sys,tarfile
mode=sys.argv[1];assert mode in ['cpu','gpu'];b=Path('/home/zhangyq/noahmp-v1') if mode=='cpu' else Path('/home/lhwang/work/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();data={}
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only hash-bound live annual generation snapshot. Original17520 request, oldcurrentCUDA563C/CPU558 cap1 and newproductionAZ wetarea.05 CPU BE from ownactualAX96 kept distinct; oldC/558 share172NPphysics/runner, new.05 differs explicitly. No completedyear, JAXraw, spinup, multiyear/observational or wholecanonical pass inferred.',roots={})
def add(path,name,expected=None):
    raw=path.read_bytes()
    if expected is not None:assert sha(raw)==expected
    data[name]=raw;return raw
folders=['qia-richards-'+label+('-numpy-year-a' if mode=='cpu' else '-cuda-year-c') for label in ['capacity','capacity_optics']]
if mode=='cpu':folders += ['qia-wet-'+label+'-numpy-year-be' for label in ['capacity','capacity_optics']]
for folder in folders:
    r=b/folder;row={};report_name='report.json' if mode=='cpu' else 'batch.json';rp=r/'trajectory'/report_name;raw=add(rp,folder+'/trajectory/'+report_name);report=json.loads(raw)
    assert report['steps_requested']==17520 and report['source_unchanged']
    row.update({k:report[k] for k in ['status','steps_completed','steps_requested','seconds','maximum_cumulative_residual_m_h_c_n','cumulative_numerical_bounds_m_h_c_n']})
    cp=r/'trajectory'/report['checkpoint_file'];assert cp.parent==r/'trajectory';add(cp,folder+'/trajectory/'+cp.name,report['checkpoint_sha256'])
    if mode=='cpu':
        p=r/'trajectory'/report['model_npz'];assert p.parent==r/'trajectory';add(p,folder+'/trajectory/'+p.name,report['model_npz_sha256'])
    else:
        assert report['same_precision_max_absolute'] is None and report['identity']['native_state_arrays']==23
        for case,descriptor in report['case_reports'].items():
            p=r/'trajectory'/case/descriptor['file'];assert p.parent==r/'trajectory'/case;c=json.loads(add(p,folder+'/trajectory/'+case+'/'+p.name,descriptor['sha256']))
            assert c['steps_completed']==report['steps_completed'] and c['batch_checkpoint_sha256']==report['checkpoint_sha256']
            p=r/'trajectory'/case/c['model_npz'];assert p.parent==r/'trajectory'/case;add(p,folder+'/trajectory/'+case+'/'+p.name,c['model_npz_sha256'])
    names=(['launch.json','dispatch.json','receipt.json','pbs-exit.txt','SOURCE_SHA256.json','year-launch.json','lineage.json','segment-96-receipt.json','segment-96-pbs-exit.txt'] if mode=='cpu' else ['year-launch.json','year-worker.json','year-exit.json','year-receipt.json','year-start-audit.json','prefix-verification.json'])
    for name in names:
        if (r/name).is_file():add(r/name,folder+'/'+name)
    record['roots'][folder]=row
if mode=='cpu':
    p=subprocess.run(['qstat','343.manager','344.manager','385.manager','386.manager','383.manager'],capture_output=True,text=True,timeout=20);record['actual_qstat']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
else:
    p=subprocess.run(['ps','-p','182573,182574,182577,182578,4095434,4095585,3802989,3802990,108025,4122841,3850155,3864455,3547743,3622193,3662728,93734,95415','-o','pid,ppid,stat,etime,time,wchan:24,comm'],capture_output=True,text=True,timeout=20);record['actual_ps']=dict(returncode=p.returncode,stdout=p.stdout)
    for folder in ['clm-canopy-wet-key-bi/gpu-bi','clm-canopy-wet-final-az/gpu-bc','clm-numerical-recovery-c/integration-c','richards-column-native-a/target-a','richards-station-native-a/target-a','clm-capacity-final-f/full-bgc-f','p6-all-phase-final-b/full-by-file-a','pft-optics-final-d/full-by-file-d','qia1110-final-h/full-by-file-h']:
        for name in ['waiting.json','exit.json','receipt.json','target-receipt.json','progress.json','summary.json','selection.json']:
            if (b/folder/name).is_file():add(b/folder/name,'background/'+folder+'/'+name)
data['snapshot.json']=(json.dumps(record,indent=2)+'\n').encode();data['control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/('qia-'+mode+'-year-snapshot-bk-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in data.items():info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,roots=record['roots'])))

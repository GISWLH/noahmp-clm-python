"""NPZ packaging of already-completed PBS396 outputs; no forward physics."""
from pathlib import Path
import hashlib,io,json,tarfile
import numpy as np
b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-heat-reference-cm';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (r/'pbs-exit.txt').read_text().strip()=='0';receipt=json.loads((r/'receipt.json').read_text());assert all(q.get('actual_returncode',0)==0 for q in receipt['records']);data={};items=[];archive=b/'richards-producer-bw-evidence.tar.gz';assert sha(archive)=='6d79dafb621e4bbefdd712f653cf2bc21b07d6111f11bda543cdef0c9171386d'
with tarfile.open(archive) as tf:
    for i,label in enumerate(['capacity','capacity_optics']):
        def load(name):
            with np.load(io.BytesIO(tf.extractfile(label+'/'+name).read()),allow_pickle=False) as z:return dict(z)
        raw=load('producer-flow-000.npz');before=load('producer-before.npz');after=load('producer-output.npz');p=str(i)+'/';data.update({p+'cells':raw['heat_cells'][None,:],p+'properties':raw['properties'][None,:],p+'dt':raw['dt'],p+'options':before['before3'][:,1].astype(np.int32),p+'invalid_cells':after['after1']})
        proof=json.loads((r/(label+'-ck.json')).read_text());path=r/(label+'-ck.npz');assert sha(path)==proof['output_sha256'] and proof['source_unchanged'] and proof['stored_water_in_domain']
        with np.load(path,allow_pickle=False) as z:
            for name in z.files:data[p+'expected/'+name]=z[name][None,...]
        items.append(dict(case=label,reference_output_sha256=sha(path),source_manifest_sha256=proof['source_manifest_sha256'],input_arrays='exactBW raw producerarrays; options copiedexactinteger phase flag',expected='actualCK NumPy full1800s heat, comparedisolatedprechangeBO onEHPC396, no GPUforward'))
p=b/'richards_saturation_reference.npz';assert not p.exists();np.savez_compressed(p,**data);d=dict(fixture_sha256=sha(p),records=items,scope='I/O packaging only of actual396 NumPy reference and byteexactBW rawinput/oldinvalidendpoint. No alteredmaterial/water/forcing. Originalinvalidinput retained forrejection test; not GPU/sciencepass.');p=b/'richards-saturation-reference-cn.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

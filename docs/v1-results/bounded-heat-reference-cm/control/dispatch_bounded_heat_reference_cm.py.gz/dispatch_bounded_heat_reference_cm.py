from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-heat-reference-cm';proof=json.loads((b/'bounded-numpy-ck/target-receipt.json').read_text());assert proof['returncode']==0 and proof['source_unchanged'] and all(proof['counts'][k]==0 for k in ['failures','errors','skipped']);assert not r.exists();r.mkdir();controls={}
for name in ['run_bounded_heat_reference_cm.py','bounded_heat_child_cm.py','bounded_heat_reference_cm.pbs']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'bounded_heat_reference_cm.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

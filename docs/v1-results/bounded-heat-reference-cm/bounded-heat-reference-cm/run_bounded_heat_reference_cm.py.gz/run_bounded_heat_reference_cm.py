from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-heat-reference-cm';tmp=Path(os.environ['TMPDIR']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proof=json.loads((b/'bounded-numpy-ck/target-receipt.json').read_text());assert proof['returncode']==0 and proof['source_unchanged'] and proof['counts']['failures']==proof['counts']['errors']==proof['counts']['skipped']==0;packet=tmp/'packet';packet.mkdir();a=b/'richards-producer-bw-evidence.tar.gz';assert sha(a)=='6d79dafb621e4bbefdd712f653cf2bc21b07d6111f11bda543cdef0c9171386d'
with tarfile.open(a) as tf:tf.extractall(packet,filter='data')
sources={}
for name,digest in [('clm-wet-coupled-final-bo-source.tar.gz','b0746122376b0c9383162b282f9428dad8777984894fa3c5f9e6805a5719b2ce'),('clm-bounded-numpy-ck-source.tar.gz','d9a337d166b3ebca8dcb5d19dc820592e075ffa7eeb45c6ded357a9b684df786')]:
    a=b/name;assert sha(a)==digest;s=tmp/name.split('-source')[0];s.mkdir()
    with tarfile.open(a) as tf:tf.extractall(s,filter='data')
    sources['bo' if '-bo-' in name else 'ck']=s
start=time.monotonic();rows=[]
for label in ['capacity','capacity_optics']:
    for variant,s in sources.items():
        env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');output=r/(label+'-'+variant+'.npz')
        with (r/(label+'-'+variant+'.log')).open('x') as log:code=subprocess.run([sys.executable,'-u',str(r/'bounded_heat_child_cm.py'),str(s),str(packet),str(output),label],env=env,cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
        row=dict(case=label,variant=variant,actual_returncode=code);rows.append(row);(r/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');assert code==0,row
    with np.load(r/(label+'-bo.npz'),allow_pickle=False) as z:old=dict(z)
    with np.load(r/(label+'-ck.npz'),allow_pickle=False) as z:new=dict(z)
    assert old.keys()==new.keys();theta=float(np.max(abs(new['water']-old['water'])/(1000.*new['dz'])));temperature=float(np.max(abs(new['temperature']-old['temperature'])));assert theta<=.002 and temperature<=.05;assert np.all((new['water']>=0)&(new['water']<=new['capacity']));rows.append(dict(case=label,maximum_theta_difference=theta,maximum_temperature_difference_k=temperature,maximum_enthalpy_difference_jm2=float(np.max(abs(new['enthalpy']-old['enthalpy']))),all_new_stored_water_in_domain=True))
d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,records=rows,scope='NumPy integratedCK full1800s Richardswater/enthalpy using actualBW producerheatinput/phase/material, independentisolatedprechangeBO NumPyreference fromsamevalidquantizedinputs, originalM/Hbounds retained and newstrictporedomain. RaworiginalCUDA invalidstate is not usedasacceptedreference. Not fullsurfacecolumn/CN/GPU/year/sciencepass.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

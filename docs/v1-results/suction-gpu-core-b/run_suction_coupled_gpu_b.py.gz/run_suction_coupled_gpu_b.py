from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in manifest.items())
files=['tests/test_gpu_clm_freezing.py','tests/test_gpu_enthalpy.py','tests/test_gpu_soil_transport.py','tests/test_gpu_column_heat.py','tests/test_gpu_vic.py']
begun=time.monotonic()
code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml=gpu-core.xml']).returncode
assert all(sha(root/n)==v for n,v in manifest.items())
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'gpu-core.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
(root/'gpu-core-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun,counts=counts,source_files=len(manifest),source_unchanged=True,node=os.uname().nodename,files=files),indent=2)+'\n')
assert code==0 and all(counts[k]==0 for k in ['failures','errors','skipped'])

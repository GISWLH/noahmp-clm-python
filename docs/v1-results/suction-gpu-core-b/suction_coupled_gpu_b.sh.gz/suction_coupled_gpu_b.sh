#!/bin/bash
set -u
cd /home/lhwang/work/noahmp-v1/p6-suction-coupled-b
env -u LD_LIBRARY_PATH PYTHONPATH=src:tests:benchmarks PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 NOAHMP_REQUIRE_GPU=1 CUDA_VISIBLE_DEVICES=0 JAX_PLATFORMS=cuda JAX_ENABLE_X64=true XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/home/lhwang/work/noahmp-v1/jax-surface-cache CUDA_PATH=/usr/local/cuda-12.4 PATH=/usr/local/cuda-12.4/bin:/usr/bin:/bin OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 /home/lhwang/venvs/noahmp-phase3b/bin/python -u run_suction_coupled_gpu_b.py >gpu-core.log 2>&1
code=$?
printf '%s\n' "$code" >gpu-core-exit.txt
exit "$code"

from pathlib import Path
import ast,hashlib,json,tarfile,xml.etree.ElementTree as ET
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';folder=source/'full-by-file-c';name='test_gpu_clm_most_column';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
progress=json.loads((folder/'progress.json').read_text());row=next(v for v in progress['results'] if v['file']=='tests/'+name+'.py');r=json.loads((folder/(name+'-receipt.json')).read_text())
assert row['returncode']==r['pytest_returncode']==r['worker_exitcode']==0 and row['passed'] and r['passed'] and r['source_unchanged'] and r['node_coverage_exact'] and r['all_setup_call_teardown_phases_passed'] and not r['errors'] and all(v['status']=='complete' for v in r['device_barriers'])
xml=ET.parse(folder/(name+'.xml'));cases=list(xml.iter('testcase'));assert len(cases)==r['counts']['tests']==len(r['nodes']) and all(all(case.find(tag) is None for tag in ['error','failure','skipped']) for case in cases)
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
root=base/'full-c-most-complete-a';root.mkdir(exist_ok=False);values=[]
for line in (folder/(name+'.log')).read_text().splitlines():
    if '{' in line:
        try:value=ast.literal_eval(line[line.index('{'):]);values.append(dict(label=line[:line.index('{')].strip(),metrics=value))
        except (ValueError,SyntaxError):pass
(root/'printed-metrics.json').write_text(json.dumps(values,indent=2)+'\n');(root/'terminal-row.json').write_text(json.dumps(row,indent=2)+'\n')
pairs=[(folder/(name+suffix),name+suffix) for suffix in ['.log','.xml','-receipt.json','-expected.json']]+[(folder/'run_pytest_worker_a.py','run_pytest_worker_a.py'),(source/'SOURCE_SHA256.json','SOURCE_SHA256.json'),(root/'terminal-row.json','terminal-row.json'),(root/'printed-metrics.json','printed-metrics.json'),(Path(__file__),Path(__file__).name)]
archive=base/'full-c-most-complete-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,n in pairs:t.add(p,arcname=n,recursive=False)
print(json.dumps(dict(files=len(pairs),path=str(archive),sha256=sha(archive),tests=r['counts']['tests'],seconds=row['seconds'],pytest_seconds=r['pytest_seconds'],verified_gpu_prefix_nodes=progress['covered_nodes']-804,remaining_gpu_nodes=1129-progress['covered_nodes'])))

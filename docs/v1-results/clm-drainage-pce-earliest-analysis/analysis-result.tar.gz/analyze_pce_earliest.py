"""EHPC-only comparison of already captured PC-e vs PB-t arrays.

No model/forward/GPU calls: this reads the two closed GPU archives and reports
the earliest stored divergence for the three failing cases.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import socket
import tarfile

import numpy as np

PC_E='48c18366b82b011702bad1ca2649fe5cd327088b16cd41a82b45387f6534fb31'
PB_T='69daf37ba4bdef8990de4325ba7bd3d8b38690adc4751fc0ae5f254cef669eea'
CASES=('perched_stress-float32','option2-float32','two_bands-float32')
MILESTONES=('input.cells','input.properties','input.options','input.dt',
            'actual.phase_cells_before','actual.diagnosis_before',
            'actual.phase_cells_after_perched','actual.diagnosis_after_perched',
            'actual.phase_cells_final','actual.diagnosis_after',
            'actual.layer_mass_kg_m2','actual.layer_enthalpy_j_m2',
            'actual.drained_kg_m2','actual.drained_enthalpy_j_m2',
            'actual.water_residual_kg_m2','actual.energy_residual_j_m2',
            'actual.perched.layer_mass_kg_m2','actual.perched.layer_enthalpy_j_m2',
            'actual.perched.drained_kg_m2','actual.perched.drained_enthalpy_j_m2',
            'actual.perched.water_residual_kg_m2','actual.perched.energy_residual_j_m2',
            'actual.perched.migrated_front_m','actual.perched.potential_requested_kg_m2',
            'actual.perched.elapsed_seconds','actual.perched.maximum_accepted_error_ratio',
            'actual.perched.quantized_requested_duration_seconds','actual.perched.clock_residual_seconds',
            'actual.perched.accepted_substeps','actual.perched.rejected_substeps')
DIAG=(
    'main_theta_m','frost_m_or_zero','perched_m_or_zero','has_frost','has_perched',
    'transition_count','active_layers','main_rate_kg_m2_s','perched_rate_kg_m2_s',
    'main_ice_factor','perched_ice_factor','main_specific_yield','first_perched_donor_or_minus_one',
    'main_weight_0','main_weight_1','main_weight_2','main_weight_3',
    'perched_weight_0','perched_weight_1','perched_weight_2','perched_weight_3',
    'ice_0','ice_1','ice_2','ice_3','sat_0','sat_1','sat_2','sat_3')
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def unpack(raw):
    out={}
    with tarfile.open(fileobj=io.BytesIO(raw)) as ar:
        for m in ar:
            n=m.name.removeprefix('./');p=PurePosixPath(n)
            if m.isdir():continue
            assert m.isfile() and not p.is_absolute() and '..' not in p.parts and n not in out
            out[n]=ar.extractfile(m).read()
    return out

def load_case(data, backend, case):
    prefix=f'{backend}/device/{case}/'
    meta=json.loads(data[prefix+'result.json'])
    with np.load(io.BytesIO(data[prefix+'result.npz']),allow_pickle=False) as z:
        values={n:z[n].copy() for n in z.files}
    assert sha(data[prefix+'result.npz'])==meta['npz_sha256']
    return meta,values

def metric(a,b):
    assert a.dtype==b.dtype and a.shape==b.shape
    if a.dtype.kind in 'biu':
        neq=a!=b; d=np.abs(a.astype(np.float64)-b.astype(np.float64))
        return dict(dtype=a.dtype.str,shape=list(a.shape),exact_elements=int(np.size(a)-np.count_nonzero(neq)),different_elements=int(np.count_nonzero(neq)),maximum_absolute_difference=float(d.max(initial=0)),maximum_scaled_difference=float(d.max(initial=0)),all_exact=not bool(np.any(neq)))
    finite=bool(np.all(np.isfinite(a)) and np.all(np.isfinite(b)))
    d=np.abs(a.astype(np.float64)-b.astype(np.float64)); scale=d/(1e-6+1e-6*np.abs(b.astype(np.float64)))
    return dict(dtype=a.dtype.str,shape=list(a.shape),finite=finite,exact_elements=int(np.size(a)-np.count_nonzero(a.view(np.uint8).reshape(-1,a.itemsize)!=b.view(np.uint8).reshape(-1,b.itemsize))),different_elements=int(np.count_nonzero(a!=b)),maximum_absolute_difference=float(d.max(initial=0)),maximum_scaled_difference=float(scale.max(initial=0)),all_exact=not bool(np.any(a.view(np.uint8)!=b.view(np.uint8))))

def main():
    p=argparse.ArgumentParser();p.add_argument('--pc-e',type=Path,required=True);p.add_argument('--pc-e-sha',required=True);p.add_argument('--pb-t',type=Path,required=True);p.add_argument('--pb-t-sha',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists()
    pce_raw=a.pc_e.read_bytes();pbt_raw=a.pb_t.read_bytes();assert sha(pce_raw)==a.pc_e_sha==PC_E and sha(pbt_raw)==a.pb_t_sha==PB_T
    pce=unpack(pce_raw);pbt=unpack(pbt_raw);rows=[]
    for case in CASES:
        backends={}
        for backend in ('cuda','jax'):
            pce_meta,pce_v=load_case(pce,backend,case);pbt_meta,pbt_v=load_case(pbt,backend,case)
            assert pce_meta['arrays'].keys()==pbt_meta['arrays'].keys()
            diffs={n:metric(pce_v[n],pbt_v[n]) for n in pce_meta['arrays']}
            earliest=next((n for n in MILESTONES if n in diffs and not diffs[n]['all_exact']),None)
            diagnosis={}
            for n in ('actual.diagnosis_before','actual.diagnosis_after_perched','actual.diagnosis_after'):
                if n in pce_v:
                    diagnosis[n]={DIAG[i]:dict(index=i,**metric(pce_v[n][...,i],pbt_v[n][...,i])) for i in range(min(29,pce_v[n].shape[-1])) if not metric(pce_v[n][...,i],pbt_v[n][...,i])['all_exact']}
            backends[backend]=dict(earliest_stored_divergence=earliest,earliest_index=(MILESTONES.index(earliest) if earliest in MILESTONES else None),
                milestone_metrics={n:diffs[n] for n in MILESTONES if n in diffs},diagnosis_field_metrics=diagnosis,
                all_array_metrics=diffs,metadata=dict(pce_npz=pce_meta['npz_sha256'],pbt_npz=pbt_meta['npz_sha256'],pce_calls=pce_meta.get('calls'),pbt_calls=pbt_meta.get('calls')))
        rows.append(dict(case=case,backends=backends))
    report=dict(completed=True,pbs_job=os.environ['PBS_JOBID'],pc_e_gpu_sha256=sha(pce_raw),pb_t_gpu_sha256=sha(pbt_raw),
        source_bound=True,model_forward_calls=0,GPU_calls=0,new_JAX_calls=0,stored_cases=list(CASES),rows=rows,
        interpretation='Earliest divergence means first non-bit-identical stored output in the fixed milestone order. Inputs, initial phase and initial diagnosis are compared directly against the closed PB-t capture. Missing internal solver values, per-operation pow/heads/rates and hidden trial trajectories are not reconstructed; only stored arrays are reported. This does not alter sameprecision/int/P0/hard ledgers or the original F1.')
    a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(completed=True,rows=len(rows),model_forward_calls=0,GPU_calls=0,new_JAX_calls=0)))

if __name__=='__main__':raise SystemExit(main())

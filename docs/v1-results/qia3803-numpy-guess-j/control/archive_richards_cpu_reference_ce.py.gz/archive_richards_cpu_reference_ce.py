from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='cpu':
    name='richards-cpu-full-c';r=b/name;d=json.loads((r/'receipt.json').read_text())
    assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1037,failures=0,errors=0,skipped=0) and d['xml_sha256']==sha(r/'cpu-full.xml')
    folders=[name];controls=['run_richards_cpu_full_c.py','richards_cpu_full_c.pbs','dispatch_richards_cpu_full_c.py'];source=b/'richards-numpy-c-source.tar.gz'
elif mode=='reference':
    name='richards-reference-de';r=b/'richards-reference-e';d=json.loads((r/'receipt.json').read_text())
    assert d['source_unchanged'] and len(d['cases'])==34 and sha(r/'richards_reference.npz')==d['reference_sha256']
    assert (b/'richards-reference-d/pbs-exit.txt').read_text().strip()=='1' and (r/'pbs-exit.txt').read_text().strip()=='0'
    folders=['richards-reference-d','richards-reference-e'];controls=[n for suffix in ['d','e'] for n in ['run_richards_reference_'+suffix+'.py','richards_reference_'+suffix+'.pbs','dispatch_richards_reference_'+suffix+'.py']];source=b/'richards-numpy-c-source.tar.gz'
else:
    assert mode in ('phase','guess');name='qia3803-numpy-a' if mode=='phase' else 'qia3803-numpy-guess-j';r=b/name;d=json.loads((r/'diagnosis.json').read_text())
    assert d['source_unchanged'] and d['binding']['index']==3803 and all(v['failure'] is None for v in d['records']) and (r/'pbs-exit.txt').read_text().strip()=='0'
    suffix='numpy_a' if mode=='phase' else 'guess_j'
    folders=[name];controls=['probe_qia3803_'+suffix+'.py','qia3803_'+suffix+'.pbs','dispatch_qia3803_'+suffix+'.py'];source=b/'qia1110-final-h-source.tar.gz'
assert sha(source)==('ffa30e87bc515d0694c9135c8b77d14286112e6da2cf7f4ef6467417319132a0' if mode in ('phase','guess') else 'ae2cbfb94669326fcb0efa0d5ea9ce30a128214813112fafd59f8741a6f08a9b')
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for folder in folders:
        for p in sorted((b/folder).rglob('*')):
            if p.is_file():tf.add(p,arcname=folder+'/'+p.relative_to(b/folder).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

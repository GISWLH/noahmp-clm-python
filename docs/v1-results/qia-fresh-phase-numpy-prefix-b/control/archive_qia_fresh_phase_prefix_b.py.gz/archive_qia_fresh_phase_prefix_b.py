from pathlib import Path
import datetime
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-fresh-phase-numpy-week-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
raw = (r / 'trajectory/report.json').read_bytes()
d = json.loads(raw)
assert d['status'] == 'running' and 192 <= d['steps_completed'] <= 336 and d['steps_requested'] == 17520 and d['source_unchanged']
assert sha(r / 'SOURCE_SHA256.json') == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
m = json.loads((r / 'SOURCE_SHA256.json').read_text())
assert all(m[n] == v for n, v in d['source_sha256'].items())
files = []
for key, digest in [('model_npz', 'model_npz_sha256'), ('checkpoint_file', 'checkpoint_sha256')]:
    p = r / 'trajectory' / d[key]
    assert sha(p) == d[digest]
    files.append(p)
a = b / 'qia-fresh-phase-numpy-prefix-b-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for name in ['launch.json', 'controller.log', 'run_qia_fresh_phase_numpy_week_a.py', 'qia_fresh_phase_numpy_week_a.pbs', 'SOURCE_SHA256.json']:
        t.add(r / name, arcname=name, recursive=False)
    info = tarfile.TarInfo('report-snapshot.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    for p in files:
        t.add(p, arcname='trajectory/' + p.name, recursive=False)
    summary = dict(scope='Actual source510 original-cold EHPC PBS225 valid running prefix beyond original182; original failed509C year not resumed. Preserved exact published generation/source/hash and original MHCN statistics. Original17520 request and336 observation stop retained. Not complete week/year/spinup or scientific acceptance; no new numerical analysis in archive writer.',
                   archive_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pbs_job='225.manager', steps_completed=d['steps_completed'], steps_requested=17520,
                   source_manifest_sha256=sha(r / 'SOURCE_SHA256.json'), report_sha256=hashlib.sha256(raw).hexdigest(),
                   maximum_cumulative_residual_m_h_c_n=d['maximum_cumulative_residual_m_h_c_n'])
    data = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(data)
    t.addfile(info, io.BytesIO(data))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, steps_completed=d['steps_completed'], source_unchanged=True)))

from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

b = Path('/home/lhwang/work/noahmp-v1')
s, r = b / 'p6-all-phase-final-b', b / 'qia-cuda-1110-a'
assert not (r / 'capture-launch.json').exists()
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1',
           CUDA_VISIBLE_DEVICES='0', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', XLA_PYTHON_CLIENT_PREALLOCATE='false')
free = subprocess.check_output(['nvidia-smi', '--id=0', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip()
assert int(free) > 8192
mem = int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
assert mem > 8*1024*1024
with (r / 'capture.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'capture_qia_cuda_1110_a.py')], cwd=s, env=env,
                         stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=p.pid, gpu=0,
              free_memory_mib=int(free), control_sha256={n: hashlib.sha256((b / n).read_bytes()).hexdigest() for n in ['capture_qia_cuda_1110_a.py', 'launch_qia1110_capture_a.py']})
(r / 'capture-launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

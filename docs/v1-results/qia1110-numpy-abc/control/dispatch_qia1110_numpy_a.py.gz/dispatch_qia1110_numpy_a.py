from pathlib import Path
import hashlib,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia1110-numpy-a';assert not r.exists();r.mkdir();a=b/'qia-cuda-1110-capture-a-evidence.tar.gz';assert a.exists()
with tarfile.open(a) as t:t.extractall(r/'device',filter='data')
cap=json.loads((r/'device/surface-capture-a/receipt.json').read_text());assert cap['source_unchanged'] and cap['input_unchanged'] and cap['device_barrier_complete']
controls={}
for n in ['probe_qia1110_numpy_a.py','qia1110_numpy_a.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia1110_numpy_a.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,capture_archive_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),controls_sha256=controls),indent=2)+'\n');print(job)

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');roots=['qia1110-numpy-a','qia1110-numpy-trace-b','qia1110-one-sided-c'];a=b/'qia1110-numpy-abc-evidence.tar.gz';assert not a.exists()
for n in roots:assert (b/n/'pbs-exit.txt').read_text().strip()=='0' and json.loads((b/n/'diagnosis.json').read_text())['source_unchanged']
with tarfile.open(a,'w:gz') as t:
    for n in roots:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(b).as_posix(),recursive=False)
    for n in ['dispatch_qia1110_numpy_a.py','dispatch_qia1110_trace_b.py','dispatch_qia1110_one_sided_c.py','archive_qia1110_numpy_abc.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

"""Retain all four exploratory soil/profile interventions, without selection."""
from pathlib import Path
import hashlib,json,subprocess,os
import numpy as np
base=Path('/home/lhwang/work/noahmp-v1')
root=base/'qia-soil-diagnostic-20261017-b';native=base/'p6-most-stagnation-a';original_native=base/'p6-native-fluxnet-b'
evaluation=base/'p6-fluxnet-evaluation-c';old=base/'p6-molten-snow-gpu-a'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for snapshot in [native,evaluation,original_native]:
    source=json.loads((snapshot/'SOURCE_SHA256.json').read_text())
    assert all(sha(snapshot/p)==h for p,h in source.items())
batch=json.loads((root/'native-run/batch.json').read_text())
assert batch['status']=='complete' and batch['steps_completed']==336
out=root/'results';out.mkdir(exist_ok=False)
exe='/home/lhwang/venvs/noahmp-phase3b/bin/python'
env=os.environ.copy();env.update(PYTHONPATH='src:tests:benchmarks',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
rows=[];alltraces={}
with np.load(root/'native-run'/batch['checkpoint_file'],allow_pickle=False) as z: state=dict(z)
for k,row in enumerate(json.loads((root/'batch.json').read_text())['cases']):
    case=row['case'];model=root/'native-run'/case;r=json.loads((model/'report.json').read_text())
    command=[exe,'benchmarks/evaluate_fluxnet_series.py','--model',str(model/r['model_npz']),
        '--model-manifest',str(model/'report.json'),'--observations',str(old/'inputs/CN-Qia.npz'),
        '--observation-manifest',str(old/'inputs/CN-Qia.json'),
        '--soil-operator',str(original_native/'soil-operators/CN-Qia.json'),'--output',str(out/(case+'-observations.json'))]
    subprocess.run(command,cwd=evaluation,env=env,check=True)
    e=json.loads((out/(case+'-observations.json')).read_text());metrics={}
    for field,instant in e['instantaneous'].items():
        days=[v[field]['metrics'] for v in e['daily'].values()];measured=[v for v in days if v['status']=='measured']
        rel=[v['relative_bias']*100 for v in measured if v['relative_bias'] is not None]
        near=[v['absolute_bias'] for v in measured if v['near_zero']]
        metrics[field]=dict(r=instant['metrics'].get('r'),samples=instant['metrics']['n'],
            daily_measured=len(measured),daily_bias_pass=sum(v['bias_pass'] for v in measured),
            daily_relative_bias_percent_range=None if not rel else [min(rel),max(rel)],
            near_zero_max_absolute_daily_bias=None if not near else max(near))
    with np.load(model/r['model_npz'],allow_pickle=False) as z: trace=dict(z)
    alltraces[case]=trace
    config=json.loads(Path(row['configuration']).read_text());s=config['column']['soil']
    roots=np.array(config['column']['root_frac']);roots/=roots.sum()
    beta=(np.clip((trace['liquid_m3m3']-s['smcwlt'])/(s['smcref']-s['smcwlt']),0,1)*roots).sum(1)
    daily={field:trace[field].reshape(7,48).sum(1).tolist() for field in ['et_mm','gpp_gc_m2','nee_gc_m2','runoff_mm']}
    daily.update({field:trace[field].reshape(7,48).mean(1).tolist() for field in ['h_wm2','le_wm2','lai']})
    daily['poststep_root_water_stress']=beta.reshape(7,48).mean(1).tolist()
    rows.append(dict(case=case,configuration_sha256=sha(Path(row['configuration'])),metrics=metrics,daily=daily,
        root_water_stress_poststep_range=[float(beta.min()),float(beta.max())],
        final_soil_water=trace['smc_m3m3'][-1].tolist(),final_plant_carbon=state['a11'][k,:3].tolist(),
        final_reserve_carbon=float(state['a11'][k,6]),final_leaf_nitrogen_factor=float(state['a4'][k,11]),
        initial_lai=config['column']['lai'],final_lai=float(trace['lai'][-1])))
original_folder=original_native/'height-cuda-a/CN-Qia-tq39.6-w39.6'
original_report=json.loads((original_folder/'report.json').read_text())
with np.load(original_folder/original_report['model_npz'],allow_pickle=False) as z: original=dict(z)
control=alltraces['qia-nominal-uniform']
for field,value in original.items(): np.testing.assert_array_equal(value,control[field],err_msg=field)
result=dict(scope='Exploratory after-score 2x2 soil/profile diagnostic; all cases retained, not blind validation or calibration/spinup',
    protocol_sha256=sha(root/'protocol.json'),model_source_manifest_sha256=sha(native/'SOURCE_SHA256.json'),
    evaluation_source_manifest_sha256=sha(evaluation/'SOURCE_SHA256.json'),instrument_sha256=sha(Path(__file__)),
    unchanged_original_control_all_trace_fields_bitwise_identical=True,
    steps_each=336,column_steps=1344,seconds=batch['seconds'],cases=rows,
    maximum_cumulative_m_h_c_n=np.asarray(batch['maximum_cumulative_residual_m_h_c_n']).max(0).tolist(),
    minimum_cumulative_bounds_m_h_c_n=np.asarray(batch['cumulative_numerical_bounds_m_h_c_n']).min(0).tolist())
(out/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2),flush=True)

"""Keep complete published closed evidence in its archive; free duplicate inodes."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1').resolve();tmp=Path('/tmp/noahmp-closed-recent-my');assert not tmp.exists();tmp.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for label,job,digest in [('climatology-reported-prefix-mq','1541.manager','7d0b21a36215903acd305e652985852df923c48c73ba3e09ba84e0d33fc0a89b'),('climatology-january-states-mt','1542.manager','0458191c691531c7baaede0889aca23dc4348531ea839e516db1c5d2304538e7')]:
    r=(b/label).resolve();assert r.parent==b and r.is_dir() and not r.is_symlink();q=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);a=b/(label+'-evidence.tar.gz');assert sha(a)==digest;destination=tmp/label;destination.mkdir()
    with tarfile.open(a) as t:t.extractall(destination,filter='data')
    files=[p for p in r.rglob('*') if p.is_file()];assert files and all(not p.is_symlink() and r in p.resolve().parents for p in files)
    entries=[]
    for p in files:
        relative=p.relative_to(r);restored=destination/relative;assert restored.is_file() and p.read_bytes()==restored.read_bytes();entries.append(dict(path=relative.as_posix(),sha256=sha(p),bytes=p.stat().st_size))
    # Every file has a complete tested restore before any unlink in this root.
    for p in files:assert sha(p)==next(x['sha256'] for x in entries if x['path']==p.relative_to(r).as_posix());p.unlink()
    for p in sorted([p for p in r.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):assert r in p.resolve().parents and not p.is_symlink();p.rmdir()
    record=dict(label=label,actual_pbs_job=job,actual_pbs_exit=0,archive=str(a),archive_sha256=digest,files_removed_after_full_restore=len(entries),entries=entries,scope='Closed published evidence only; complete existing archive and full TMP restore byteexact before removing duplicate scattered files. No latest live model states/source/inputs/journals touched. Read-only future analysis must restore this archive into its own TMPDIR.');(r/'ARCHIVE_LOCATION.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,actual_df_inode_snapshot=subprocess.check_output(['df','-i',str(b)],text=True));(tmp/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='records'}),flush=True);print('closed_duplicate_files_removed',sum(x['files_removed_after_full_restore'] for x in records),flush=True)

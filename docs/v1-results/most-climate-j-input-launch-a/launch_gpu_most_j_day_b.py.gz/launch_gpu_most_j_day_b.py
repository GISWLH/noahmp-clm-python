from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-j';source=base/'p6-most-oscillation-a'
receipt=root/'cuda-day-launch.json';assert not receipt.exists()
cpu=json.loads((source/'cpu-full-receipt.json').read_text());assert cpu['returncode']==0 and cpu['source_unchanged'] and cpu['counts']==dict(tests=780,failures=0,errors=0,skipped=0)
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==v for n,v in m.items())
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_gpu_most_j_day.py')]
with (root/'cuda-controller.log').open('w') as log:proc=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
value=dict(pid=proc.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,command=command,steps_requested=17520,stop_after=48,source_manifest_sha256=hashlib.sha256((source/'SOURCE_SHA256.json').read_bytes()).hexdigest(),scope='Additional CUDA validation: fresh J cold first48 from locked configurations and forcing, parallel to independent device target. Original failed I separate; all current device targets and independent first48 reference/budget comparisons required before any own annual resume.')
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');out=b/'profile_output/material-live-a';out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
def copy(p,target):
 target=out/target;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());return sha(target)
for label,name in [('K','fluxnet-first-climate-cycle-20261017-k'),('L','fluxnet-first-climate-cycle-20261018-l')]:
 root=b/name;folder=root/'cuda-day';raw=(folder/'batch.json').read_bytes();d=json.loads(raw)
 target=out/label/'cuda-day/batch.json';target.parent.mkdir(parents=True);target.write_bytes(raw)
 p=folder/d['checkpoint_file'];assert p.parent==folder and sha(p)==d['checkpoint_sha256'];copy(p,Path(label)/'cuda-day'/p.name)
 for case,desc in d['case_reports'].items():
  p=folder/case/desc['file'];assert p.parent==folder/case and sha(p)==desc['sha256'];r=json.loads(p.read_text());copy(p,Path(label)/'cuda-day'/case/p.name)
  p=folder/case/r['model_npz'];assert p.parent==folder/case and sha(p)==r['model_npz_sha256'] and r['batch_checkpoint_sha256']==d['checkpoint_sha256'];copy(p,Path(label)/'cuda-day'/case/p.name)
 for filename in ['launch.json','annual-launch.json','annual-worker.json','annual-exit.json','prefix-export.json']:
  p=root/filename
  if p.exists():copy(p,Path(label)/filename)
 rows.append(dict(campaign=label,folder=name,status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],compare_jax32=d['identity']['compare_jax32'],source_unchanged=d['source_unchanged']))
source=b/'p6-material-event-b';m=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(m)==493 and all(sha(source/n)==v for n,v in m.items());copy(source/'SOURCE_SHA256.json',Path('B-SOURCE_SHA256.json'))
for filename in ['launch.json','collection.json','progress.json','summary.json']:
 p=source/'target-a'/filename
 if p.exists():copy(p,Path('B-target')/filename)
value=dict(scope='One read-only live snapshot, immutable generation hashes verified and original reports/state/trajectory preserved. K/L still running, no full climate/spinup/scientific acceptance or whole-wait attribution. B-target collection/progress only, not uncompleted tests passed.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),campaigns=rows,source_b_unchanged=True)
(out/'snapshot.json').write_text(json.dumps(value,indent=2)+'\n');(out/'export_material_live_a.py').write_bytes(Path(__file__).read_bytes())
(out/'CHANGES.md').write_text('Created only this selected read-only snapshot and its compressed export. No model source, environment, process, checkpoint or device settings changed. No profiling instrumentation inserted; timing cause not attributed.\n')
a=b/'material-live-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=p.relative_to(out),recursive=False)
print(json.dumps(dict(**value,archive_bytes=a.stat().st_size,archive_sha256=sha(a))))

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'canopy-wet-final-ar';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());a=b/'clm-canopy-wet-final-aq-source.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
prereq=json.loads((b/'canopy-wet-numpy-akd/full-receipt.json').read_text());assert prereq['returncode']==0 and prereq['source_unchanged'] and prereq['counts']==dict(tests=1091,failures=0,errors=0,skipped=0)
files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
start=time.monotonic()
for label,selected,expected in [('cpu',files,1091)]:
    collect=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q',*selected],cwd=s,env=env,capture_output=True,text=True);(r/(label+'-collection.stdout.txt')).write_text(collect.stdout);(r/(label+'-collection.stderr.txt')).write_text(collect.stderr);assert collect.returncode==0,collect.stderr
    nodes=[line.strip() for line in collect.stdout.splitlines() if line.startswith('tests/') and '::' in line];assert len(nodes)==len(set(nodes))==expected;(r/(label+'-expected.json')).write_text(json.dumps(nodes,indent=2)+'\n')
xml=r/'full.xml'
with (r/'full.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
counts={k:sum(int(q.attrib[k]) for q in ET.parse(xml).getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(returncode=code,counts=counts,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,xml_sha256=sha(xml),scope='Finalwetarea.05 synchronizedsource full1091CPU actualpytest; canonical1481 still requires xuanze collection/execution, CPU host lacks GPU importdependencies. OriginalMHCN/raw/science gates unchanged. Not fullcanonical/year/science acceptance.')
(r/'full-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert code==0 and unchanged and counts==dict(tests=1091,failures=0,errors=0,skipped=0)

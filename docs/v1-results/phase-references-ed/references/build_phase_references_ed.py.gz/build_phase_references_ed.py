from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-references-ed';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());a=b/'clm-phase-descent-ec-source.tar.gz';assert sha(a)==meta['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==571 and sha(s/'SOURCE_SHA256.json')==meta['manifest_sha256'] and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(r),str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
from phase_reference_key_dw import reference_key,_TOLERANCE,_MAX_ITERATIONS
import test_gpu_canopy_phase_energy as phase
import test_gpu_canopy_phase_surface as surface
from noahmp_clm.physics.photosynthesis import LeafParameters
cache={};records=[];failure=None;start=time.monotonic()
def add(family,row,kwargs,label):
    key=reference_key(family,row,kwargs)
    if key in cache:records.append(dict(label=label,family=family,key=key,duplicate=True));return
    value=copy.deepcopy((phase.reference if family=='phase' else surface.reference)(row,**kwargs))
    if family=='phase':
        c=value['condensate'];value['condensate']=SimpleNamespace(mass=c.mass.copy(),enthalpy=c.enthalpy.copy(),temperature=c.temperature.copy(),ice=c.ice.copy(),liquid=c.liquid.copy())
    cache[key]=value;records.append(dict(label=label,family=family,key=key,duplicate=False))
try:
    for dtype in [np.float32,np.float64]:
        for family,module in [('phase',phase),('surface',surface)]:
            arrays=module.batch(dtype) if family=='phase' else module.cases(dtype)
            for k,row in enumerate(zip(*arrays)):add(family,tuple(row),{},family+str(np.dtype(dtype))+':'+str(k))
    for name in ['canopy_phase_humidity_bound.json','canopy_phase_humidity_slow.json']:
        v=json.loads((s/'tests/fixtures'/name).read_text());row=tuple(np.asarray(x,np.int32 if k==8 else np.float64) for k,x in enumerate(v['arrays']));add('phase',row,dict(tolerance=1e-7),'humidity:'+name)
    for name in ['qia_479_phase_jacobian.npz','phase_edge_float64_stencil.npz']:
        with np.load(s/'tests/fixtures'/name,allow_pickle=False) as z:row=tuple(z['a'+str(k)] for k in range(9));extension=z['extension']
        add('phase',row,dict(exchange_extension=extension,tolerance=1e-7,max_iterations=80),'float64-jacobian:'+name)
    for name in ['qia_735_phase_oldwet.json','qia_1110_phase_kink.json']:
        for precision in ['32','64']:
            c=phase.oldwet_case(precision,name);add('phase',tuple(c['arrays']),dict(exchange_extension=c['extension'],leaf_parameters=LeafParameters(*np.asarray(c['parameters'],float)),tolerance=1e-7,max_iterations=80),'saved-existing:'+name+':'+precision)
except Exception as error:failure=type(error).__name__+': '+str(error);(r/'traceback.txt').write_text(traceback.format_exc())
(r/'references.pkl').write_bytes(pickle.dumps(cache,protocol=5));d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_files=571,keys=len(cache),families={family:sum(q['family']==family and not q['duplicate'] for q in records) for family in ['phase','surface']},requested_records=records,reference_pickle_sha256=sha(r/'references.pkl'),key_helper_sha256=sha(r/'phase_reference_key_dw.py'),production_defaults=dict(tolerance=_TOLERANCE,max_iterations=_MAX_ITERATIONS),seconds=time.monotonic()-start,scope='DU actualsource offlineNumPy alloriginalphase/surface referencecalls, exactdtype/shape/inputbytes/parameters/extensions/actualproductiondefaultcontrols. No referencefallback onGPUhost, no input/gate edits or phase/tolerance-key collision. Not GPUtest/fullcanonical/annual/sciencepass.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k] for k in ['pbs_job','failure','keys','families','seconds','source_unchanged','reference_pickle_sha256']}),flush=True);assert failure is None and d['source_unchanged']

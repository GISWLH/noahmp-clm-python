"""Manager-only submit of one independent readonly PBS task, all new files under/tmp."""
import hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path('/tmp/noahmp-ctsm-land-deposition-ob')
assert os.uname().nodename=='manager' and Path(__file__).resolve().parent==ROOT
controls=json.loads((ROOT/'CONTROLS_SHA256.json').read_text())
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in controls.items())
assert not (ROOT/'dispatch.json').exists()
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','compute002',
    'test ! -e /tmp/noahmp-ctsm-land-deposition-ob && mkdir /tmp/noahmp-ctsm-land-deposition-ob'],check=True)
subprocess.run(['scp',*[str(ROOT/n) for n in [*controls,'CONTROLS_SHA256.json']],
    'compute002:'+str(ROOT)+'/'],check=True)
q=subprocess.run(['qsub','-o',str(ROOT/'pbs-output.log'),str(ROOT/'read_ctsm_land_deposition_ob.pbs')],cwd=ROOT,capture_output=True,text=True)
(ROOT/'qsub-stdout.txt').write_text(q.stdout);(ROOT/'qsub-stderr.txt').write_text(q.stderr)
assert q.returncode==0,q.stderr
job=q.stdout.strip();assert re.fullmatch(r'\d+\.manager',job)
record=dict(pbs_job=job,qsub_actual_exit=q.returncode,controls_sha256=controls,cpus=1,memory_gb=4,
    walltime='00:10:00',forward_model_runs=0,source_archive_unchanged=True,
    scope='One readonly originalR actual land-deposition readback. Existing active CPU/GPU trajectories untouched.')
(ROOT/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

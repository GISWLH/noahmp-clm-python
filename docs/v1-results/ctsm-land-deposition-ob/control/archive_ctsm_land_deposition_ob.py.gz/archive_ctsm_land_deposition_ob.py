"""Manager-only terminal closure of original land-deposition readback, failure preserving."""
import hashlib,io,json,os,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/tmp/noahmp-ctsm-land-deposition-ob')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert os.uname().nodename=='manager'
dispatch=json.loads((ROOT/'dispatch.json').read_text());job=dispatch['pbs_job']
qstat=subprocess.check_output(['qstat','-xf',job],text=True)
assert re.search(r'^\s*job_state = F\s*$',qstat,re.M),'Actual F required; E is not closure'
exitcode=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',qstat,re.M).group(1))
for name in ['result.tar.gz','pbs-exit.txt']:
    assert not (ROOT/name).exists()
    subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
assert int((ROOT/'pbs-exit.txt').read_text())==exitcode
with tarfile.open(ROOT/'result.tar.gz') as tf:
    data={m.name.removeprefix('./'):tf.extractfile(m).read() for m in tf if m.isfile()}
assert int(data['worker-exit.txt'])==exitcode
receipt=json.loads(data['receipt.json']) if 'receipt.json' in data else None
result=json.loads(data['readback/land-deposition.json']) if 'readback/land-deposition.json' in data else None
passed=exitcode==0 and receipt is not None and result is not None and receipt['passed'] and result['passed']
if passed:
    assert receipt['pbs_job']==result['pbs_job']==job and receipt['node']==result['node']=='compute002'
    assert receipt['forward_model_runs']==result['forward_model_runs']==0
    assert receipt['environment_archive_sha256']=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
    assert receipt['reader_sha256']==dispatch['controls_sha256']['read_ctsm_land_deposition_ob.py']
    assert all(s['returncode']==0 for s in receipt['stages'])
    assert receipt['fields_sha256']==sha(data['readback/land-deposition.json'])
    assert result['positive_intervals']==17520 and result['stored_rows']==17521
    assert result['original_archive_unchanged'] and not result['scientific_acceptance']
    assert result['array_archive_sha256']==sha(data['readback/land-deposition-original-intervals.npz'])
for name,h in dispatch['controls_sha256'].items():
    raw=(ROOT/name).read_bytes();assert sha(raw)==h;data['control/'+name]=raw
assert data['reader.py']==data['control/read_ctsm_land_deposition_ob.py']
assert data['wrapper.py']==data['control/run_ctsm_land_deposition_ob.py']
for name in ['dispatch.json','qsub-stdout.txt','qsub-stderr.txt','CONTROLS_SHA256.json','result.tar.gz','pbs-exit.txt']:
    data['control/'+name]=(ROOT/name).read_bytes()
data['actual-qstat.txt']=qstat.encode()
output=ROOT/'pbs-output.log'
if output.exists():data['control/pbs-output.log']=output.read_bytes()
data['control/pbs-output-status.json']=(json.dumps(dict(present=output.exists(),
    stdout_stderr='Actual readback/controller logs retained regardless of scheduler stageout file presence.'),indent=2)+'\n').encode()
data['control/archive_ctsm_land_deposition_ob.py']=Path(__file__).read_bytes()
inventory={n:dict(sha256=sha(raw),bytes=len(raw)) for n,raw in data.items()}
data['artifact-inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
target=ROOT/'ctsm-land-deposition-ob-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for n,raw in sorted(data.items()):
        info=tarfile.TarInfo(n);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
with tarfile.open(target) as tf:assert {m.name:tf.extractfile(m).read() for m in tf}==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    pbs_job=job,actual_job_state='F',actual_exit=exitcode,readback_passed=bool(passed),forward_model_runs=0,
    positive_intervals=result.get('positive_intervals') if result else None,
    reader_seconds=result.get('seconds') if result else None,
    original_r_archive_sha256='14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0',
    environment_archive_sha256='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20',
    scientific_acceptance=False,
    scope='Actual originalR landBC/DST/OC readback on fixed17520positive intervals with original masks/units, prior14-month input mapping, original5species/OCzero semantics. Preserve any actual failure. Root parameter/source semantics not actualrootfr; no model/input/QC changes or same-condition science credit.')
(ROOT/'ctsm-land-deposition-ob-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

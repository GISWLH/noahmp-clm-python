"""Use the same pinned portable NetCDF environment for original R land readback."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
root = Path(sys.argv[1])
root.mkdir()
prefix = root.parent / 'portable-ctsm'
prefix.mkdir()
archive = Path('/home/zhangyq/noahmp-v1/ctsm-portable-env-b.tar.gz')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
record = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              passed=False, stages=[], forward_model_runs=0, failure=None)
try:
    assert sha(archive) == '6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
    reader = Path(__file__).with_name('reader.py')
    assert sha(reader) == '741de1808c4d5ff1c96026fb770097f31fac77bac890b457b93a50b6abb16502'
    record.update(environment_archive_sha256=sha(archive), reader_sha256=sha(reader))
    with tarfile.open(archive) as tf:
        tf.extractall(prefix, filter='data')
    env = os.environ.copy()
    for name in ['PYTHONPATH', 'PYTHONHOME', 'LD_LIBRARY_PATH']:
        env.pop(name, None)
    env.update(PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'),
               PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    commands = [('relocate', [str(prefix/'bin/python'), str(prefix/'bin/conda-unpack')]),
                ('readback', [str(prefix/'bin/python'), '-B', str(reader), str(root/'readback')])]
    for name, command in commands:
        start = time.monotonic()
        result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=240)
        (root / (name + '.stdout.txt')).write_text(result.stdout)
        (root / (name + '.stderr.txt')).write_text(result.stderr)
        record['stages'].append(dict(name=name, returncode=result.returncode, seconds=time.monotonic()-start))
        assert result.returncode == 0, result.stderr
    diagnosis = json.loads((root/'readback/land-deposition.json').read_text())
    assert diagnosis['passed'] and diagnosis['failure'] is None and diagnosis['positive_intervals'] == 17520 and diagnosis['original_archive_unchanged']
    record.update(passed=True, fields_sha256=sha(root/'readback/land-deposition.json'))
except Exception as error:
    record['failure'] = type(error).__name__ + ': ' + str(error)
    (root/'traceback.txt').write_text(traceback.format_exc())
(root/'receipt.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if record['passed'] else 1)

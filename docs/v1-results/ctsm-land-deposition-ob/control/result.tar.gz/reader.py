"""PBS-only readback of original R land deposition, retaining original masks and bins."""
import datetime
import hashlib
import io
import json
import os
import re
import sys
import tarfile
import time
import traceback
from pathlib import Path

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
import numpy as np
from netCDF4 import Dataset, date2num, num2date

BASE=Path('/home/zhangyq/noahmp-v1')
OUT=Path(sys.argv[1]);OUT.mkdir()
ARCHIVE=BASE/'ctsm-qia-run-r/case-configuration-private.tar.gz'
EXPECTED='14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0'
SOURCE=BASE/'ctsm-reference-source-bundle-a.tar.gz'
SOURCE_SHA='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
UNITS='days since 2002-12-31 16:00:00'
FIELDS=['BCDEP','DSTDEP','OCDEP']
INPUT_GROUPS={'BCDEP':['BCDEPWET','BCPHODRY','BCPHIDRY'],
 'DSTDEP':[f'DSTX{k:02d}{suffix}' for k in range(1,5) for suffix in ['WD','DD']],
 'OCDEP':['OCDEPWET','OCPHIDRY','OCPHODRY']}
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def value(v):
    if isinstance(v,(np.ndarray,np.generic)):return value(v.tolist())
    if isinstance(v,list):return [value(x) for x in v]
    if isinstance(v,float) and not np.isfinite(v):return str(v)
    return v


def metadata(v):
    return dict(dimensions=v.dimensions,shape=v.shape,dtype=str(v.dtype),
        attributes={n:value(v.getncattr(n)) for n in v.ncattrs()})


def read(v):
    a=np.ma.asarray(v[:]);data=np.ma.getdata(a);masked=np.ma.getmaskarray(a)
    finite=np.isfinite(data)
    info=metadata(v)
    info.update(original_masked_count=int(masked.sum()),original_nonfinite_count=int((~finite).sum()),
        valid_count=int((~masked & finite).sum()))
    return data,masked,info


def compare(actual,mask,reference,dt):
    good=~mask & np.isfinite(actual) & np.isfinite(reference)
    q=dict(total_intervals=len(actual),valid_pairs=int(good.sum()),masked_or_nonfinite_pairs=int((~good).sum()),
        no_masked_values_filled=True,complete_annual_comparison=bool(good.all()))
    if not good.any():return dict(q,status='unmeasured_no_valid_land_pairs')
    x=actual[good].astype(float);y=reference[good];delta=x-y;where=np.flatnonzero(good)
    worst=int(abs(delta).argmax());idx=int(where[worst])
    q.update(status='actual_land_readback_compared',maximum_absolute_rate_difference_kg_m2_s=float(abs(delta).max()),
        mean_rate_bias_kg_m2_s=float(delta.mean()),rms_rate_difference_kg_m2_s=float(np.sqrt(np.mean(delta**2))),
        worst_original_positive_interval_index=idx,actual_rate_at_worst=float(x[worst]),input_rate_at_worst=float(y[worst]),
        original_land_rate_min=float(x.min()),original_land_rate_max=float(x.max()),
        input_rate_min=float(y.min()),input_rate_max=float(y.max()),
        exact_at_history_dtype=bool(np.array_equal(actual[good],reference[good].astype(actual.dtype))),
        nonmatching_at_history_dtype=int(np.count_nonzero(actual[good]!=reference[good].astype(actual.dtype))),
        history_dtype=str(actual.dtype),instantaneous_r=float(np.corrcoef(x,y)[0,1]) if x.std()>0 and y.std()>0 else None,
        annual_actual_kg_m2=float(np.sum(x*dt[good])) if good.all() else None,
        annual_original_input_kg_m2=float(np.sum(y*dt[good])) if good.all() else None,
        annual_difference_kg_m2=float(np.sum(delta*dt[good])) if good.all() else None,
        annual_relative_bias_percent=100.*float(np.sum(delta*dt[good]))/abs(float(np.sum(y*dt[good]))) if good.all() and np.sum(y*dt[good])!=0 else None,
        reference_exact_zero=bool(np.all(y==0)),actual_exact_zero=bool(np.all(x==0)),
        science_acceptance_applied=False)
    return q


def source_index():
    assert sha(SOURCE.read_bytes())==SOURCE_SHA
    definitions={
      'CTSM/src/biogeophys/SoilStateType.F90':dict(lines=[[68,76],[234,259],[391,412]],
       semantics='ROOTFR history registration and rootfr restart are conditional on use_dynroot; ROOTR history on use_cn and inactive by default. Missing input rootfr triggers separate water/carbon initialization; no actual root array reconstructed.'),
      'CTSM/src/biogeophys/RootBiophysMod.F90':dict(lines=[[59,67],[110,172],[175,219],[231,272]],
       semantics='Water/carbon profile methods and variants are separate selectors; actual fractions also depend on geometry, PFT and bedrock. roota/rootb or beta parameters alone are not observed root fractions.'),
      'CTSM/src/biogeophys/SoilMoistStressMod.F90':dict(lines=[[223,251],[274,310],[363,377],[389,438]],
       semantics='ROOTR is effective water uptake fraction, dependent on soil water/temperature and resistance, then normalized; ROOTFR_UNF is an internal normalized unfrozen-root array. Neither is replaceable by the PFT root parameter.'),
      'CTSM/src/biogeophys/AerosolMod.F90':dict(lines=[[206,219],[748,770]],
       semantics='BCDEP, DSTDEP, OCDEP are total dry+wet atmospheric deposition at land columns. DSTDEP sums all four dust bins, so it cannot validate the bins separately.')}
    with tarfile.open(SOURCE) as tf:
        for name,item in definitions.items():
            raw=tf.extractfile(name).read();item.update(sha256=sha(raw),line_count=len(raw.decode().splitlines()),
              pinned_commit='fdfc03a0abec838ec0b66663a6a2f5e619cd2611',
              primary_url='https://github.com/ESCOMP/CTSM/blob/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/'+name.removeprefix('CTSM/'))
    assert sha(SOURCE.read_bytes())==SOURCE_SHA
    return dict(bundle_sha256=SOURCE_SHA,files=definitions,fortran_implementation_copied=False,
        actual_rootfr_reconstructed=False,scope='Read-only semantic index, not new evidence of actual root states.')


started=time.monotonic()
record=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=False,failure=None,
    forward_model_runs=0,archive_sha256=EXPECTED,files=[],comparison={},
    scope='Original R actual land deposition readback only; unchanged original17520 positive intervals and monthly input. No new model, forcing/QC change, driver-to-land substitution or same-condition science acceptance.')
try:
    assert sha(ARCHIVE.read_bytes())==EXPECTED
    arrays={};parts={n:[] for n in FIELDS};masks={n:[] for n in FIELDS};allbounds=[];rawbounds=[];rowfiles=[]
    with tarfile.open(ARCHIVE) as tf:
        names=[m.name for m in tf if m.isfile()]
        histories=sorted(n for n in names if '/run/' in n and '.clm2.h0.' in n and n.endswith('.nc'))
        assert len(histories)==2
        for file_index,name in enumerate(histories):
            raw=tf.extractfile(name).read();entry=dict(member=name,sha256=sha(raw),bytes=len(raw),variables={})
            with Dataset('original-R-history',mode='r',memory=raw) as ds:
                assert ds['time'].units==UNITS
                record.setdefault('history_time_metadata',metadata(ds['time']))
                bounds,bmask,bmeta=read(ds['time_bounds']);assert not bmask.any() and np.isfinite(bounds).all()
                seconds=bounds.astype(float)*86400.;assert float(abs(seconds-np.rint(seconds)).max())<=.01
                rawbounds.append(seconds);allbounds.append(np.rint(seconds).astype(np.int64));rowfiles.extend([file_index]*len(seconds))
                entry['time_bounds']=bmeta;entry['stored_rows']=len(seconds)
                entry['root_fields_present']=[n for n in ds.variables if n.upper() in {'ROOTFR','ROOTR','ROOTFR_UNF','ROOTR_COLUMN'}]
                entry['deposition_field_catalog']={n:metadata(v) for n,v in ds.variables.items() if re.search(r'BCDEP|DSTDEP|OCDEP|DEPOSITION',n,re.I)}
                for field in FIELDS:
                    v=ds[field];data,mask,meta=read(v);assert v.units=='kg/m^2/s'
                    assert 'time'==v.dimensions[0] and np.prod(data.shape[1:])==1
                    parts[field].append(data.reshape(len(seconds)));masks[field].append(mask.reshape(len(seconds)))
                    entry['variables'][field]=meta
            record['files'].append(entry)
        combined=np.concatenate(allbounds);rawcombined=np.concatenate(rawbounds);order=np.argsort(combined[:,0],kind='stable')
        combined=combined[order];valid=(combined[:,0]>=0)&(combined[:,1]<=31536000)
        expected=np.arange(17520)[:,None]*1800+np.array([[0,1800]])
        assert len(combined)==17521 and valid.sum()==17520 and np.array_equal(combined[valid],expected)
        assert np.array_equal(combined[~valid],[[-1800,0]])
        query=expected.mean(axis=1);dt=expected[:,1]-expected[:,0]
        arrays.update(all_time_bounds_seconds=combined,all_raw_time_bounds_seconds=rawcombined[order],
            all_history_file_index=np.asarray(rowfiles,dtype=np.int32)[order],positive_selector=valid,
            positive_time_bounds_seconds=expected,query_original_midpoint_seconds=query)
        aero_name='inputdata/CN-Qia.aero.2002-2004.nc';aero=tf.extractfile(aero_name).read()
        with Dataset('original-R-aero-input',mode='r',memory=aero) as ds:
            coords,tmask,tmeta=read(ds['time']);assert not tmask.any() and coords.shape==(14,)
            calendar=getattr(ds['time'],'calendar','standard');assert calendar=='noleap'
            knots=np.asarray(date2num(num2date(coords,ds['time'].units,calendar),UNITS,calendar),float)*86400.
            assert np.all(np.diff(knots)>0) and query.min()>=knots[0] and query.max()<=knots[-1]
            arrays['original_aerosol_time_14']=coords;arrays['original_aerosol_knots_seconds']=knots
            record['aerosol_input']=dict(member=aero_name,sha256=sha(aero),bytes=len(aero),time=tmeta,
                global_attributes={n:value(ds.getncattr(n)) for n in ds.ncattrs()},variables={})
            sampled={}
            for field in sum(INPUT_GROUPS.values(),[]):
                a,m,meta=read(ds[field]);assert ds[field].units=='kg/m2/s' and a.shape==(14,1,1)
                assert not m.any() and np.isfinite(a).all()
                record['aerosol_input']['variables'][field]=meta
                arrays['original_aero_'+field]=a;arrays['original_aero_mask_'+field]=m
                sampled[field]=np.interp(query,knots,a[:,0,0])
                arrays['expected_component_'+field]=sampled[field]
            assert all(np.all(sampled[n]==0) for n in INPUT_GROUPS['OCDEP'])
            five=np.column_stack((sum(sampled[n] for n in INPUT_GROUPS['BCDEP']),
                *[sampled[f'DSTX{k:02d}WD']+sampled[f'DSTX{k:02d}DD'] for k in range(1,5)]))
            arrays['expected_original_five_species_kg_m2_s']=five
            record['input_five_species']=dict(order=['BC_total','dust1','dust2','dust3','dust4'],
                annual_kg_m2=np.sum(five*dt[:,None],axis=0).tolist(),
                scope='Original input protocol interpolation only; dust-bin input rates do not become measured land dust-bin outputs.')
        met_name='inputdata/CN-Qia.datm.2003.nc';met=tf.extractfile(met_name).read()
        with Dataset('original-R-met-time-only',mode='r',memory=met) as ds:
            bounds,mask,meta=read(ds['time_bounds']);assert not mask.any() and len(bounds)==17520
            calendar=getattr(ds['time'],'calendar','standard')
            seconds=np.asarray(date2num(num2date(bounds,ds['time'].units,calendar),UNITS,calendar),float)*86400.
            assert np.max(abs(seconds-expected))<=.01
            record['original_meteorology_time_binding']=dict(member=met_name,sha256=sha(met),time=metadata(ds['time']),
                time_bounds=meta,positive_intervals=17520,maximum_time_error_seconds=float(abs(seconds-expected).max()),
                driver_values_not_reread_or_substituted=True)
        for field in FIELDS:
            a=np.concatenate(parts[field])[order];mask=np.concatenate(masks[field])[order]
            arrays['all_land_'+field]=a;arrays['all_land_original_mask_'+field]=mask
            arrays['all_land_nonfinite_mask_'+field]=~np.isfinite(a)
            actual=a[valid];landmask=mask[valid];reference=sum(sampled[n] for n in INPUT_GROUPS[field])
            arrays['positive_land_'+field]=actual;arrays['positive_land_original_mask_'+field]=landmask
            arrays['expected_'+field]=reference
            record['comparison'][field]=compare(actual,landmask,reference,dt)
            record['comparison'][field]['mapping_input_fields']=INPUT_GROUPS[field]
            record['comparison'][field]['positive_original_masked_count']=int(landmask.sum())
            record['comparison'][field]['positive_nonfinite_count']=int((~np.isfinite(actual)).sum())
        namelist_name=next(n for n in names if n.endswith('/run/lnd_in'))
        nl=tf.extractfile(namelist_name).read();text=nl.decode()
        terms=re.compile(r'use_cn|use_dynroot|use_hydrstress|perchroot|rooting_profile_',re.I)
        record['actual_root_configuration']=dict(member=namelist_name,sha256=sha(nl),
            matching_lines=[dict(line=i,text=line.strip()) for i,line in enumerate(text.splitlines(),1) if terms.search(line)],
            rootfr_status='unmeasured: actual R/S fields absent in OA; parameters and source initialization not substituted')
        arrays['positive_storage_indices']=order[valid]
    record.update(stored_rows=17521,positive_intervals=17520,excluded_bounds_seconds=[[-1800,0]],
        original_interval_rule_preserved=True,original_monthly_interpolation_rule_preserved=True,
        land_dust1_to4_status='unmeasured separately: original history exposes total DSTDEP only; total closure cannot certify four individual bins',
        oc_scope='Explicit zero common-five-species experiment retained; OC is not folded into BC and this does not validate real-world OC deposition.',
        scientific_acceptance=False,root_semantic_index=source_index())
    np.savez_compressed(OUT/'land-deposition-original-intervals.npz',**arrays)
    record['array_archive_sha256']=sha((OUT/'land-deposition-original-intervals.npz').read_bytes())
    assert sha(ARCHIVE.read_bytes())==EXPECTED
    record.update(passed=True,original_archive_unchanged=True)
except Exception as error:
    record['failure']=type(error).__name__+': '+str(error)
    (OUT/'traceback.txt').write_text(traceback.format_exc())
record['seconds']=time.monotonic()-started
(OUT/'land-deposition.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:record[k] for k in ['pbs_job','passed','failure','forward_model_runs','seconds']}),flush=True)
raise SystemExit(0 if record['passed'] else 1)

from pathlib import Path
import hashlib,json,sys,tarfile
label=sys.argv[1];assert label in ('d','e','f','g')
b=Path('/home/lhwang/work/noahmp-v1');s=b/('richards-native-'+label);r=s/('target-'+label);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text())
assert e['source_unchanged'] and d['source_unchanged'] and e['receipt_sha256']==sha(r/'receipt.json') and d['xml_sha256']==sha(r/'tests.xml') and d['counts']['tests']==4
assert e['returncode']==d['pytest_returncode']==d['worker_exitcode'] and d['node_coverage_exact']
a=b/('richards-native-'+label+'-evidence.tar.gz');assert not a.exists()
source=b/('richards-native-'+label+'-source.tar.gz');package=b/('richards-native-'+label+'-package.json')
assert sha(source)==json.loads(package.read_text())['archive_sha256']
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for p in [source,package]:tf.add(p,arcname='source/'+p.name,recursive=False)
    for n in ['collect_richards_native_'+label+'.py','control_richards_native_'+label+'.py','launch_richards_native_'+label+'.py',Path(__file__).name,'gpu-worker-lifecycle-a/run_pytest_worker_a.py']:
        tf.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,counts=d['counts'],actual_returncode=e['returncode'])))

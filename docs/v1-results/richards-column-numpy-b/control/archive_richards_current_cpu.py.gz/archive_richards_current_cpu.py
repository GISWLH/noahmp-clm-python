from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode,label=sys.argv[1:3];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='column':
    assert label in ('a','b');name='richards-column-numpy-'+label;r=b/name
    d=json.loads((r/'receipt.json').read_text());package=json.loads((r/'package.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=package['numpy_expected'],failures=0,errors=0,skipped=0) and sha(r/'tests.xml')==d['xml_sha256']
    controls=['run_richards_column_numpy_'+label+'.py','richards_column_numpy_'+label+'.pbs','dispatch_richards_column_numpy_'+label+'.py'];source=b/(name+'-source.tar.gz')
elif mode=='heatcpu':
    assert label=='b';name='richards-heat-cpu-b';r=b/name;d=json.loads((r/'receipt.json').read_text());package=json.loads((r/'package.json').read_text())
    assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1037,failures=0,errors=0,skipped=0) and sha(r/'cpu-full.xml')==d['xml_sha256']
    controls=['run_richards_heat_cpu_b.py','richards_heat_cpu_b.pbs','dispatch_richards_heat_cpu_b.py'];source=b/'richards-heat-native-b-source.tar.gz'
else:
    assert mode=='reference' and label=='a';name='richards-column-reference-a';r=b/name;d=json.loads((r/'receipt.json').read_text());package=json.loads((r/'package.json').read_text())
    assert d['source_unchanged'] and len(d['trajectories'])==18 and sha(r/'clm_richards_reference.npz')==d['reference_sha256']
    controls=['run_richards_column_reference_a.py','richards_column_reference_a.pbs','dispatch_richards_column_reference_a.py'];source=b/(name+'-source.tar.gz')
assert (r/'pbs-exit.txt').read_text().strip()=='0' and sha(source)==package['archive_sha256']
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

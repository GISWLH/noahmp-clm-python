from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-column-numpy-b';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=json.loads((r/'package.json').read_text());a=b/'richards-column-numpy-b-source.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==548 and sha(s/'SOURCE_SHA256.json')==package['manifest_sha256'] and all(sha(s/n)==h for n,h in m.items())
(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
start=time.monotonic();xml=r/'tests.xml'
with (r/'tests.log').open('x') as log:
    code=subprocess.run([sys.executable,'-m','pytest','-q','-s','tests/test_clm_richards_column.py','tests/test_richards.py','tests/test_clm_enthalpy_driver.py','tests/test_clm_driver.py','--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
cases=list(ET.parse(xml).iter('testcase'));counts=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
d=dict(scope=package['scope'],pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,counts=counts,
    seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),xml_sha256=sha(xml))
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
assert code==0 and d['source_unchanged'] and counts==dict(tests=59,failures=0,errors=0,skipped=0)

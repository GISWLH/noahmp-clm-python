from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];assert mode in ('g','i');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='g':name='richards-phase-trace-analysis-g';controls=['analyze_richards_phase_traces_g.py','richards_phase_analysis_g.pbs','dispatch_richards_phase_analysis_g.py']
else:name='richards-functions-analysis-i';controls=['analyze_richards_functions_i.py','richards_functions_analysis_i.pbs','dispatch_richards_functions_analysis_i.py']
r=b/name;assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'analysis.json').read_text());assert d['pbs_job'] and d['node'].startswith('compute')
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,io,json,os,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-phase-trace-analysis-g';start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(archive,member,expected):
    path=b/archive;assert sha(path)==expected
    with tarfile.open(path) as tf:
        raw=tf.extractfile(member).read()
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:return dict(z)
phase=load('qia3803-trace-bc-evidence.tar.gz','qia3803-trace-device-c/trace-and-raw.npz','bb609337dba41d65951f7c64cd5671967a82f8fff9e5453af097890efbda2bda')
flow_archive=b/'richards-flow-diagnosis-f-evidence.tar.gz'
with tarfile.open(flow_archive) as tf:
    receipt=json.load(tf.extractfile('richards-flow-diagnosis-f/receipt.json'))
    raw=tf.extractfile('richards-flow-diagnosis-f/flow-and-systems.npz').read();assert hashlib.sha256(raw).hexdigest()==receipt['payload_sha256']
    assert receipt['source_unchanged'] and all(receipt['final_outputs_byte_exact'].values())
    with np.load(io.BytesIO(raw),allow_pickle=False) as z:flow=dict(z)
t=phase['iteration_trace'];valid=t[np.isfinite(t[:,53])]
assert len(valid)==100 and phase['original_raw'].tobytes()==phase['instrumented_raw'].tobytes()
phase_summary=dict(rows=len(valid),first_max_residual=float(valid[0,51]),last_max_residual=float(valid[-1,51]),
    final_x=valid[-1,:12].tolist(),final_residual=valid[-1,12:24].tolist(),last10_x_range=np.ptp(valid[-10:,:12],axis=0).tolist(),
    tail=[dict(iteration=int(row[53]),max_residual=float(row[51]),norm=float(row[46]),chosen_norm=float(row[47]),accepted=float(row[48]),retry=float(row[49]),restarts=float(row[50]),phase_active=row[24:34].tolist()) for row in valid[-15:]])
first={};rows=[]
for i in range(receipt['calls']['cuda']):
    one={}
    for field in ['old','guess','dt','raw','system']:
        a=flow['cuda/'+str(i)+'/'+field];c=flow['jax/'+str(i)+'/'+field]
        equal=a.dtype==c.dtype and a.tobytes()==c.tobytes()
        if not equal:
            delta=abs(a.astype(float)-c.astype(float));where=int(np.argmax(delta))
            one[field]=dict(max_abs=float(delta.max()),flat_index=where,cuda=float(a.ravel()[where]),jax=float(c.ravel()[where]),cuda_dtype=str(a.dtype),jax_dtype=str(c.dtype))
            first.setdefault(field,dict(call=i,**one[field]))
    if i<8:rows.append(dict(call=i,cuda_dt=float(flow['cuda/'+str(i)+'/dt']),jax_dt=float(flow['jax/'+str(i)+'/dt']),differences=one))
f0=flow['cuda/0/system'];j0=flow['jax/0/system'];blocks={}
for name,section in [('residual',slice(0,4)),('flux',slice(4,7)),('matrix',slice(7,23)),('properties',slice(23,39))]:
    blocks[name]=dict(cuda=f0[section].tolist(),jax=j0[section].tolist(),max_abs=float(np.max(abs(f0[section].astype(float)-j0[section].astype(float)))))
d=dict(scope='EHPC compute-only analysis of unchanged exported native traces, no new physical solve or candidate. Original519H phase raw741 exact before/after instrumentation; original543E finaloutputs exact for both flow captures. Reports first differences and actual iteration history; no acceptance or tolerance change.',
    pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,phase=phase_summary,flow=dict(calls=receipt['calls'],first_differences=first,first_calls=rows,initial_system_blocks=blocks),seconds=time.monotonic()-start,
    input_archives_sha256={n:sha(b/n) for n in ['qia3803-trace-bc-evidence.tar.gz','richards-flow-diagnosis-f-evidence.tar.gz']})
(r/'analysis.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps(d,allow_nan=False),flush=True)

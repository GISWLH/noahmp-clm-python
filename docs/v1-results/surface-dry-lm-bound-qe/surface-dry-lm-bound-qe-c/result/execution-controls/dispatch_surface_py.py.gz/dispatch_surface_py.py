"""Explicit manager/compute002 transfer of one frozen PY stage, then qsub."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import socket
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/noahmp-surface-dry-lm-bound-qe-c')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--extract-only', action='store_true')
    args = parser.parse_args()
    assert sys.version_info >= (3, 10) and socket.gethostname() == ('compute002' if args.extract_only else 'manager')
    assert not ROOT.exists() and sha(args.archive.read_bytes()) == args.sha256
    with tarfile.open(args.archive) as archive:
        members = archive.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        files = {m.name: archive.extractfile(m).read() for m in members}
    index = json.loads(files['stage-inventory.json'])
    assert set(index) == set(files) - {'stage-inventory.json'}
    assert all(sha(files[n]) == h for n, h in index.items())
    assert sha(Path(__file__).read_bytes()) == index['execution/dispatch_surface_py.py']
    ROOT.mkdir()
    for name, raw in files.items():
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    if args.extract_only:
        print(json.dumps(dict(stage_sha256=args.sha256, stage_files=len(files))), flush=True)
        return
    remote_archive = '/tmp/noahmp-surface-dry-lm-bound-qe-c-stage.tar.gz'
    remote_dispatcher = '/tmp/dispatch_surface_bound_qe_c.py'
    for path in (str(ROOT), remote_archive, remote_dispatcher):
        subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', path])], check=True)
    for local, remote in ((args.archive, remote_archive), (Path(__file__), remote_dispatcher)):
        subprocess.run(['scp', str(local), 'compute002:' + remote], check=True)
    extract = subprocess.run(['ssh', 'compute002', shlex.join([PYTHON, '-B', remote_dispatcher,
        '--archive', remote_archive, '--sha256', args.sha256, '--extract-only'])], capture_output=True, text=True)
    (ROOT / 'compute-extract.stdout').write_text(extract.stdout)
    (ROOT / 'compute-extract.stderr').write_text(extract.stderr)
    assert extract.returncode == 0
    checked = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', *[str(ROOT / n) for n in index]])], capture_output=True, text=True)
    (ROOT / 'compute-hashes.stdout').write_text(checked.stdout)
    (ROOT / 'compute-hashes.stderr').write_text(checked.stderr)
    assert checked.returncode == 0 and {line.split()[1]: line.split()[0] for line in checked.stdout.splitlines()} == {str(ROOT / n): h for n, h in index.items()}
    result = subprocess.run(['qsub', '-o', str(ROOT / 'pbs-output.log'), str(ROOT / 'execution/bounds_qe.pbs')], capture_output=True, text=True)
    (ROOT / 'qsub.stdout').write_text(result.stdout)
    (ROOT / 'qsub.stderr').write_text(result.stderr)
    assert result.returncode == 0
    job = result.stdout.strip()
    assert job.endswith('.manager') and job.split('.')[0].isdigit()
    record = dict(pbs_job=job, stage_sha256=args.sha256, controls_manifest_sha256=sha(files['preparation/CONTROLS_SHA256.json']),
                  resources='1CPU/2GiB/2min/compute002', offline_saved_array_analysis=True, physical_evaluate_calls=0, LM_replays=0, GPU_calls=0,
                  source_and_capture_bound=True, stage_inventory=index)
    (ROOT / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

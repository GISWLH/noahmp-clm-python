Only QE-c unique paths; unchanged1CPU/2GiB/2min,LF PBS, actual exit propagation/hash checks. No retry of original physical model or LM.

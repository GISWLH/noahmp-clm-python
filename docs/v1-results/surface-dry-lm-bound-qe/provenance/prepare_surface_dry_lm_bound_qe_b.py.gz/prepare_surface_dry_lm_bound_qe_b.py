"""Keep QE1829 failure and fix only private paths and PBS LF for QE-b."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
OLD='surface-dry-lm-bound-qe'
LABEL='surface-dry-lm-bound-qe-b'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution')
    assert not prep.exists() and not execution.exists();prep.mkdir();execution.mkdir()
    oldprep=BASE/(OLD+'-preparation');oldexec=BASE/(OLD+'-execution')
    oldpath=b'/tmp/noahmp-surface-dry-lm-bound-qe';newpath=b'/tmp/noahmp-surface-dry-lm-bound-qe-b'
    name='analyze_saved_bounds_qe.py';oldworker=(oldprep/name).read_bytes()
    worker=oldworker.replace(oldpath,newpath)
    assert worker.replace(newpath,oldpath)==oldworker
    (prep/name).write_bytes(worker)
    (prep/'BINDINGS.json').write_bytes((oldprep/'BINDINGS.json').read_bytes())
    (prep/'README.md').write_bytes((oldprep/'README.md').read_bytes()+b'\nQE-b only fixes original QE1829 interpreter launch: /bin/bash^M bad interpreter, Exit126; numerical worker never started. Preserve original stage and raw spool/qstat. The new worker differs only in its private stage path. All archives, input comparison, bound arithmetic and zero-evaluate policy are unchanged. PBS is explicitly LF encoded and asserts no CR.\n')
    patches=[]
    for filename in ('check_stage_py.py','dispatch_surface_py.py','bounds_qe.pbs'):
        original=(oldexec/filename).read_bytes();changed=original.replace(oldpath,newpath)
        changed=changed.replace(b'dispatch_surface_bound_qe.py',b'dispatch_surface_bound_qe_b.py')
        if filename.endswith('.pbs'):
            changed=changed.replace(b'surface-lm-bound-qe\r\n',b'surface-lm-bound-qe-b\r\n').replace(b'\r\n',b'\n')
            assert changed.startswith(b'#!/bin/bash\n') and b'\r' not in changed
        (execution/filename).write_bytes(changed)
        patches.append(''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile='QE1829/'+filename,tofile='QE-b/'+filename)))
    patches.append(''.join(difflib.unified_diff(oldworker.decode().splitlines(True),worker.decode().splitlines(True),fromfile='QE1829/'+name,tofile='QE-b/'+name)))
    proof=dict(original_1829_stage_sha256=sha((BASE/(OLD+'-stage.tar.gz')).read_bytes()),
        original_worker_sha256=sha(oldworker),new_worker_sha256=sha(worker),worker_reverse_private_path_replacement_byte_exact=True,
        original_PBS_sha256=sha((oldexec/'bounds_qe.pbs').read_bytes()),new_PBS_sha256=sha((execution/'bounds_qe.pbs').read_bytes()),
        original_PBS_CRLF_lines=(oldexec/'bounds_qe.pbs').read_bytes().count(b'\r\n'),
        new_PBS_CRLF_lines=0,new_PBS_shebang_exact=True,binding_archives_unchanged=True,
        original_actual_spool_sha256=sha((BASE/(OLD+'-1829-closure/initial/spool.stdout')).read_bytes()),
        physical_algorithm_or_gate_changes=0)
    (prep/'DIFF_PROOF.json').write_bytes(encode(proof))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'README.md').write_bytes(b'Unique QE-b private paths and LF PBS repair after preserved1829 bad-interpreter failure. Original analysis worker byte exact after reversing private path only. 1CPU/2GiB/2min, original saved inputs, no model/evaluate or LM replay, no automatic retry.\n')
    for folder in (prep,execution):
        (folder/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file()}))
    items={}
    for folder,directory in [('preparation',prep),('execution',execution)]:
        items.update({folder+'/'+p.relative_to(directory).as_posix():p.read_bytes() for p in directory.rglob('*') if p.is_file()})
    with tarfile.open(BASE/(OLD+'-stage.tar.gz')) as t:
        for filename in ('source.tar.gz','py-c-result.tar.gz','pw-result.tar.gz'):items[filename]=t.extractfile(filename).read()
    for filename in ('spool.stdout','qstat.stdout','commands.json'):
        items['prior-1829-'+filename]=(BASE/(OLD+'-1829-closure/initial')/filename).read_bytes()
    items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    for filename,raw in items.items():
        if filename.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),proof=proof)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

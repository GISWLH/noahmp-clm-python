"""Close actual1840 saved-output analysis; retain both earlier execution failures."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'surface-dry-lm-bound-qe-c-closure'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    commands={'qstat':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1840.manager'],
        'result-hash':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','sha256sum /tmp/noahmp-surface-dry-lm-bound-qe-c/result.tar.gz'],
        'pbs-exit':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','cat /tmp/noahmp-surface-dry-lm-bound-qe-c/pbs-exit.txt']}
    captured={};exits={}
    for label,command in commands.items():
        begin=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=60)
        (OUT/(label+'.stdout')).write_bytes(result.stdout);(OUT/(label+'.stderr')).write_bytes(result.stderr)
        exits[label]=dict(actual_exit=result.returncode,command=command,seconds=time.monotonic()-begin,
            stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr));captured[label]=result.stdout
        assert result.returncode==0
    (OUT/'commands.json').write_text(json.dumps(exits,indent=2)+'\n')
    assert all(x in captured['qstat'] for x in (b'Job Id: 1840.manager',b'job_state = F',b'Exit_status = 0',b'Stageout_status = 0'))
    raw=(BASE/'surface-dry-lm-bound-qe-c-result.tar.gz').read_bytes()
    assert sha(raw)==captured['result-hash'].decode().split()[0]=='bd6649543219b15ac5300f83a9221acecf8a4d44215194175fc4fe0c84d86135'
    assert captured['pbs-exit'].strip()==b'0'
    with tarfile.open(BASE/'surface-dry-lm-bound-qe-c-result.tar.gz') as t:files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    assert files['worker-exit.txt'].strip()==files['setup-exit.txt'].strip()==files['stage-after-exit.txt'].strip()==b'0'
    before=json.loads(files['stage-before.json']);after=json.loads(files['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']
    readout=json.loads(files['probe/readout.json'])
    assert readout['pbs_job']=='1840.manager' and readout['passed'] and readout['actual_analysis_exit']==0
    assert readout['Qia_saved_first_phase_inputs_exact_to_PW'] and len(readout['Qia_original_phase_argument_names'])==27
    assert len(readout['Qia_saved_input_comparisons'])==60 and all(r['passed'] for r in readout['Qia_saved_input_comparisons'])
    assert sha(files['probe/raw-output.pkl'])==readout['raw_output_pickle_sha256']
    assert readout['LM_replays']==readout['physical_evaluate_calls']==0
    assert readout['final_x_finite'] and readout['final_x_inside_original_bounds']
    assert readout['final_x_at_lower_indices']==readout['final_x_at_upper_indices']==[]
    assert readout['source_before_after_exact'] and readout['stage_before_after_exact']
    for name,raw in files.items():
        if name.endswith(('.json','.log','.txt','.stdout','.stderr')):
            target=OUT/'readable'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    correction=dict(prior_1830_explanation_superseded=True,
        original_incorrect_interpretation='ULP distance ratio overflow caused strict JSON rejection.',
        actual_saved_nonfinite_scalar_path='Qia_saved_input_comparisons/ground_evaporation_limit/left_value and right_value',
        actual_scalar=dict(finite=False,hex='inf'),
        actual_cause='The unchanged original input ground_evaporation_limit is +inf in both inputs; strict JSON rejected that default scalar. All12 coordinate local-ULP ratios in actual1840 output are finite.',
        original_failure_record_retained=True,no_input_value_changed=True,
        bound_inference='No final x coordinate equals either original bound. Direction/J/r/alpha were not saved; no full no-movement cause inferred before transparent trace.')
    (BASE/'surface-dry-lm-bound-qe-c-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
    closure=dict(pbs_job='1840.manager',job_state='F',PBS_exit=0,Stageout_status=0,worker_exit=0,
        result_sha256=sha((BASE/'surface-dry-lm-bound-qe-c-result.tar.gz').read_bytes()),result_files=len(files),
        source584_and_stage_before_after_exact=True,all27_original_arguments_60_checks_exact=True,
        saved_final_x_all12_strictly_inside_bounds=True,LM_replays=0,physical_evaluate_calls=0,
        original_1822_physical_failure_preserved=True,physical_or_scientific_acceptance=False)
    (BASE/'surface-dry-lm-bound-qe-c-closure.json').write_text(json.dumps(closure,indent=2)+'\n');print(json.dumps(closure))


if __name__=='__main__':main()

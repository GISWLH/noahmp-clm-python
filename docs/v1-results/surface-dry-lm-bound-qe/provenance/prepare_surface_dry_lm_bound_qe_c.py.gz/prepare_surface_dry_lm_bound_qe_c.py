"""Preserve1830 and encode nonfinite diagnostic scalars without altering data."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
OLD='surface-dry-lm-bound-qe-b'
LABEL='surface-dry-lm-bound-qe-c'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution')
    assert not prep.exists() and not execution.exists();prep.mkdir();execution.mkdir()
    oldprep=BASE/(OLD+'-preparation');oldexec=BASE/(OLD+'-execution')
    oldpath=b'/tmp/noahmp-surface-dry-lm-bound-qe-b';newpath=b'/tmp/noahmp-surface-dry-lm-bound-qe-c'
    filename='analyze_saved_bounds_qe.py';original=(oldprep/filename).read_bytes()
    worker=original.replace(oldpath,newpath)
    assert worker.count(b'import json\n')==1
    worker=worker.replace(b'import json\n',b'import json\nimport math\n')
    safe=b'''def json_safe(value):
    if isinstance(value,float) and not math.isfinite(value):
        return dict(finite=False,hex=value.hex())
    if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
    if isinstance(value,list):return [json_safe(v) for v in value]
    return value


'''
    assert worker.count(b'def main():\n')==1
    worker=worker.replace(b'def main():\n',safe+b'def main():\n')
    oldsave=b"        (root/'readout.json').write_text(json.dumps(output,indent=2,ensure_ascii=False,allow_nan=False)+'\\n')"
    newsave=b"        raw_output=pickle.dumps(output,protocol=5)\n        (root/'raw-output.pkl').write_bytes(raw_output)\n        output['raw_output_pickle_sha256']=sha(raw_output)\n        (root/'readout.json').write_text(json.dumps(json_safe(output),indent=2,ensure_ascii=False,allow_nan=False)+'\\n')"
    assert worker.count(oldsave)==1
    worker=worker.replace(oldsave,newsave)
    reverse=worker.replace(newsave,oldsave).replace(safe,b'').replace(b'import json\nimport math\n',b'import json\n').replace(newpath,oldpath)
    assert reverse==original
    (prep/filename).write_bytes(worker)
    (prep/'BINDINGS.json').write_bytes((oldprep/'BINDINGS.json').read_bytes())
    (prep/'README.md').write_bytes(b'Unique root-authorized QE-c saved-output arithmetic,1CPU/2GiB/2min. Original1829 bad-interpreter126 and1830 JSON serialization1 are retained with F/Stageout0. Worker changes only private STAGE path and output serialization: first preserve raw output pickle; explicitly encode a nonfinite diagnostic float as {finite:false,hex:original_float.hex()}, retaining positive/negative inf or NaN semantics. JSON remains allow_nan=False. Original input comparison, source boundary expressions, all arithmetic and zero physical evaluate/LM policy are unchanged; no new local-ULP gate.\n')
    patches=[''.join(difflib.unified_diff(original.decode().splitlines(True),worker.decode().splitlines(True),fromfile='QE-b1830/'+filename,tofile='QE-c/'+filename))]
    for name in ('check_stage_py.py','dispatch_surface_py.py','bounds_qe.pbs'):
        before=(oldexec/name).read_bytes();after=before.replace(oldpath,newpath)
        after=after.replace(b'dispatch_surface_bound_qe_b.py',b'dispatch_surface_bound_qe_c.py').replace(b'surface-lm-bound-qe-b',b'surface-lm-bound-qe-c')
        if name.endswith('.pbs'):assert after.startswith(b'#!/bin/bash\n') and b'\r' not in after
        (execution/name).write_bytes(after)
        patches.append(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='QE-b1830/'+name,tofile='QE-c/'+name)))
    proof=dict(original_1830_stage_sha256=sha((BASE/(OLD+'-stage.tar.gz')).read_bytes()),
        original_worker_sha256=sha(original),new_worker_sha256=sha(worker),reverse_private_path_and_serialization_byte_exact=True,
        bound_input_comparison_and_arithmetic_changes=0,physical_evaluate_calls=0,LM_replays=0,
        new_PBS_LF_and_exact_shebang=True,nonfinite_diagnostic_float_policy='Raw pickle first; finite:false and original float.hex, no clipping/replacement; no new gate.')
    (prep/'DIFF_PROOF.json').write_bytes(encode(proof))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'README.md').write_bytes(b'Only QE-c unique paths; unchanged1CPU/2GiB/2min,LF PBS, actual exit propagation/hash checks. No retry of original physical model or LM.\n')
    for folder in (prep,execution):
        (folder/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file()}))
    items={}
    for folder,directory in [('preparation',prep),('execution',execution)]:items.update({folder+'/'+p.name:p.read_bytes() for p in directory.iterdir() if p.is_file()})
    with tarfile.open(BASE/(OLD+'-stage.tar.gz')) as t:
        for name in ('source.tar.gz','py-c-result.tar.gz','pw-result.tar.gz'):items[name]=t.extractfile(name).read()
    for target,path in [('prior-1829-spool.stdout','surface-dry-lm-bound-qe-1829-closure/initial/spool.stdout'),
        ('prior-1829-qstat.stdout','surface-dry-lm-bound-qe-1829-closure/terminal/qstat.stdout'),
        ('prior-1830-qstat.stdout','surface-dry-lm-bound-qe-b-closure/qstat.stdout'),
        ('prior-1830-worker.stderr','surface-dry-lm-bound-qe-b-closure/readable/worker.stderr'),
        ('prior-1830-failure.json','surface-dry-lm-bound-qe-b-failure.json')]:items[target]=(BASE/path).read_bytes()
    items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),proof=proof)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

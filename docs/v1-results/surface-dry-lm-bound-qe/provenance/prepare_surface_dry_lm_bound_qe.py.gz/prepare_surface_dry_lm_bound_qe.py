"""Freeze a single offline saved-output diagnostic using PY-c transfer controls."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-dry-lm-bound-qe'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution');assert not execution.exists();execution.mkdir()
    binding=dict(archives={'source.tar.gz':'e83342c1b9634e0f12fe898aafd4e49e8e16477b07403bb20b8b3aa5fcf9af92',
        'py-c-result.tar.gz':'c899a551629463dc3f4b159756f762df2f1fd91f23a4527091e24bf27a48b61d',
        'pw-result.tar.gz':'44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef'},
        original_PY_c_job='1822.manager',original_PW_job='1700.manager',physical_evaluate_calls=0,LM_replays=0,
        scope='Exact saved first-call input comparison to original PW frame; saved final LM x versus original source bounds. No reevaluation.')
    (prep/'BINDINGS.json').write_bytes(encode(binding))
    (prep/'README.md').write_text('One root-authorized1CPU/2GiB/2min PBS compute002 offline analysis. Authenticate original PY-c1822 and PW1700 result archives plus frozen candidate source584. Unpickle saved inputs/frame on EHPC only, recursively compare all27 original phase arguments including scalar type and array dtype/shape/C-bytes. Decode only saved x, reconstruct the exact source lower/upper expressions using frozen literal constants, and report exact-bound flags, distances and distances divided by local spacing. The final LM direction/J/r were not saved; do not substitute older PW Newton matrices. No evaluate, LM, solve, model, GPU, new reference, test, fixture or gate is called or changed. Full original1822 physical failure remains. Unique bounded analysis may fail; no automatic retry.\n')
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.relative_to(prep).as_posix():sha(p.read_bytes()) for p in sorted(prep.rglob('*')) if p.is_file()}))
    old=BASE/'surface-dry-lm-py-c-execution'
    changes={}
    for name in ('check_stage_py.py','dispatch_surface_py.py'):
        prior=(old/name).read_text();text=prior.replace('noahmp-surface-dry-lm-py-c','noahmp-surface-dry-lm-bound-qe').replace('dispatch_surface_py_c.py','dispatch_surface_bound_qe.py')
        text=text.replace('surface_py.pbs','bounds_qe.pbs')
        text=text.replace("resources='1CPU/2GiB/10min/compute002', planned_PR_surface_rows=3, full_column_calls=0, GPU_calls=0,", "resources='1CPU/2GiB/2min/compute002', offline_saved_array_analysis=True, physical_evaluate_calls=0, LM_replays=0, GPU_calls=0,")
        (execution/name).write_text(text)
        changes[name]=''.join(difflib.unified_diff(prior.splitlines(True),text.splitlines(True),fromfile='PY-c/'+name,tofile='QE/'+name))
    pbs='''#!/bin/bash
#PBS -N surface-lm-bound-qe
#PBS -l select=1:ncpus=1:mem=2gb:host=compute002_00260924
#PBS -l walltime=00:02:00
#PBS -j oe
set -u
stage=/tmp/noahmp-surface-dry-lm-bound-qe
root="$TMPDIR/qe-result"
py=/home/zhangyq/venvs/noahmp-closeout/bin/python
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/home/zhangyq/noahmp-v1/test-deps
export CUDA_VISIBLE_DEVICES=''
unset PYTHONHOME
test ! -e "$root" || exit 91
test ! -e "$stage/result.tar.gz" || exit 92
mkdir "$root" || exit 93
cp -r "$stage/execution" "$root/execution-controls" || exit 94
cp -r "$stage/preparation" "$root/preparation-controls" || exit 95
cp "$stage/stage-inventory.json" "$root/stage-inventory.json" || exit 96
"$py" -B "$stage/execution/check_stage_py.py" --output "$root/stage-before.json" > "$root/stage-before.log" 2>&1
setup_status=$?
echo "$setup_status" > "$root/setup-exit.txt"
status=$setup_status
if test "$setup_status" -eq 0; then
    "$py" -B "$stage/preparation/analyze_saved_bounds_qe.py" "$root/probe" > "$root/worker.stdout" 2> "$root/worker.stderr"
    worker_status=$?
    echo "$worker_status" > "$root/worker-exit.txt"
    "$py" -B "$stage/execution/check_stage_py.py" --output "$root/stage-after.json" > "$root/stage-after.log" 2>&1
    after_status=$?
    echo "$after_status" > "$root/stage-after-exit.txt"
    status=$worker_status
    if test "$after_status" -ne 0; then status=$after_status; fi
fi
echo "$status" > "$root/pbs-command-exit.txt"
tar -czf "$stage/result.tar.gz" --exclude='./probe/source' -C "$root" . || exit 97
echo "$status" > "$stage/pbs-exit.txt"
exit "$status"
'''
    (execution/'bounds_qe.pbs').write_text(pbs)
    changes['bounds_qe.pbs']=''.join(difflib.unified_diff((old/'surface_py.pbs').read_text().splitlines(True),pbs.splitlines(True),fromfile='PY-c/surface_py.pbs',tofile='QE/bounds_qe.pbs'))
    (execution/'wrapper.diff').write_text('\n'.join(changes.values()))
    (execution/'README.md').write_text('PY-c hash-checked private manager/compute transfer and unique qsub, with new QE root and original result/source inputs. PBS walltime2min; one offline saved-array analysis replaces collect/pytest. Before/after stage hash checks and actual child/PBS exits retained; no numerical model call, retry or physical acceptance.\n')
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={}
    for folder,directory in [('preparation',prep),('execution',execution)]:
        items.update({folder+'/'+p.relative_to(directory).as_posix():p.read_bytes() for p in directory.rglob('*') if p.is_file()})
    for key,filename in [('source.tar.gz','surface-dry-lm-py-source.tar.gz'),('py-c-result.tar.gz','surface-dry-lm-py-c-result.tar.gz'),('pw-result.tar.gz','surface-7275-feasible-root-pw-result.tar.gz')]:
        items[key]=(BASE/filename).read_bytes();assert sha(items[key])==binding['archives'][key]
    items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    package=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),binding=binding)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

"""Preserve actual1829 interpreter-launch failure without numerical replay."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'surface-dry-lm-bound-qe-1829-closure'/sys.argv[1]
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir(parents=True)
    commands={
        'qstat':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1829.manager'],
        'spool':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','cat /var/spool/pbs/spool/1829.manager.OU'],
        'saved-stage-hashes':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2',
            'sha256sum /tmp/noahmp-surface-dry-lm-bound-qe/execution/bounds_qe.pbs /tmp/noahmp-surface-dry-lm-bound-qe/preparation/analyze_saved_bounds_qe.py; test ! -e /tmp/noahmp-surface-dry-lm-bound-qe/result.tar.gz; test ! -e /tmp/noahmp-surface-dry-lm-bound-qe/pbs-exit.txt'],
        'manager-output':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','cat /tmp/noahmp-surface-dry-lm-bound-qe/pbs-output.log']}
    results={}
    for label,command in commands.items():
        begin=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=60)
        (OUT/(label+'.stdout')).write_bytes(result.stdout);(OUT/(label+'.stderr')).write_bytes(result.stderr)
        results[label]=dict(actual_exit=result.returncode,command=command,seconds=time.monotonic()-begin,
            stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
    (OUT/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(dict(snapshot=OUT.name,actual_exits={k:v['actual_exit'] for k,v in results.items()})))


if __name__=='__main__':main()

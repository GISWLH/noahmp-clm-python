"""Retain actual1830 F1 output serialization failure, no replay."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'surface-dry-lm-bound-qe-b-closure'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    commands={'qstat':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1830.manager'],
        'result-hash':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','sha256sum /tmp/noahmp-surface-dry-lm-bound-qe-b/result.tar.gz'],
        'pbs-exit':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','cat /tmp/noahmp-surface-dry-lm-bound-qe-b/pbs-exit.txt']}
    captured={};exits={}
    for label,command in commands.items():
        begin=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=60)
        (OUT/(label+'.stdout')).write_bytes(result.stdout);(OUT/(label+'.stderr')).write_bytes(result.stderr)
        exits[label]=dict(actual_exit=result.returncode,command=command,seconds=time.monotonic()-begin,
            stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr));captured[label]=result.stdout
        assert result.returncode==0
    (OUT/'commands.json').write_text(json.dumps(exits,indent=2)+'\n')
    assert all(x in captured['qstat'] for x in (b'Job Id: 1830.manager',b'job_state = F',b'Exit_status = 1',b'Stageout_status = 0'))
    raw=(BASE/'surface-dry-lm-bound-qe-b-result.tar.gz').read_bytes()
    assert sha(raw)==captured['result-hash'].decode().split()[0]=='ff72f24be5e919b7d086a14999fd1ff105f314a5de5bcb2ccfd10be5731ed1db'
    assert captured['pbs-exit'].strip()==b'1'
    with tarfile.open(BASE/'surface-dry-lm-bound-qe-b-result.tar.gz') as t:files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    assert files['worker-exit.txt'].strip()==b'1' and files['setup-exit.txt'].strip()==files['stage-after-exit.txt'].strip()==b'0'
    assert b'Out of range float values are not JSON compliant: inf' in files['worker.stderr']
    before=json.loads(files['stage-before.json']);after=json.loads(files['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']
    for name,raw in files.items():
        if name.endswith(('.json','.log','.txt','.stdout','.stderr')):
            target=OUT/'readable'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    output=dict(pbs_job='1830.manager',job_state='F',PBS_exit=1,Stageout_status=0,worker_exit=1,setup_exit=0,stage_after_exit=0,
        stage_before_after_exact=True,result_sha256=sha((BASE/'surface-dry-lm-bound-qe-b-result.tar.gz').read_bytes()),result_files=len(files),
        failure='Strict JSON output rejected a diagnostic local-ULP distance ratio that overflowed to positive infinity.',
        numerical_readout_available=False,scientific_or_model_failure=False,LM_replays=0,physical_evaluate_calls=0,original_PY_c_failure_preserved=True)
    (BASE/'surface-dry-lm-bound-qe-b-failure.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output))


if __name__=='__main__':main()

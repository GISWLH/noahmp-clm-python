"""Seal saved-bound analysis and all preceding execution failures unchanged."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-dry-lm-bound-qe'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()


def main():
    closure=json.loads((BASE/'surface-dry-lm-bound-qe-c-closure.json').read_bytes())
    assert closure['job_state']=='F' and closure['PBS_exit']==closure['Stageout_status']==0
    readout=json.loads((BASE/'surface-dry-lm-bound-qe-c-readout.json').read_bytes())
    assert readout['passed'] and readout['LM_replays']==readout['physical_evaluate_calls']==0
    assert readout['Qia_saved_first_phase_inputs_exact_to_PW']
    assert readout['final_x_at_lower_indices']==readout['final_x_at_upper_indices']==[]
    items={'readout.json':(BASE/'surface-dry-lm-bound-qe-c-readout.json').read_bytes(),
        'closure.json':(BASE/'surface-dry-lm-bound-qe-c-closure.json').read_bytes(),
        'correction.json':(BASE/'surface-dry-lm-bound-qe-c-correction.json').read_bytes(),
        'SCOPE.md':b'Unique1840 F0/Stageout0 arithmetic on already saved outputs only:27 original phase arguments/60 full checks exactly match PW, all12 saved final LM coordinates finite and strictly inside original bounds. Zero model/evaluate/LM calls. Direction/J/r/alpha were not saved, so a transparent original-call trace is still required. Original1822 physical LM failure remains; this is not repair, device, full-column, annual or scientific acceptance. Original1829 F126 bad interpreter and1830 F1 strict-JSON failures are preserved; the earlier ULP-overflow explanation is superseded by correction.json, which identifies unchanged default ground_evaporation_limit=+inf.\n'}
    stages=[('surface-dry-lm-bound-qe','238f034da9a3d29811fa8a0a4a8347642790b35f251c94f03d0645b3e661d226'),
        ('surface-dry-lm-bound-qe-b','56d664647c3c113d44f77b93b9a0f8ea48a7e8cdc30aad768fcc9b60ba1bcb66'),
        ('surface-dry-lm-bound-qe-c','64b748f040887a85f5525281203dda2b9df67618cfba4ed81f3633bb6ef0a5d7')]
    for prefix,expected in stages:
        raw=(BASE/(prefix+'-stage.tar.gz')).read_bytes();assert sha(raw)==expected
        items[prefix+'/executed-stage.tar.gz']=raw
        for suffix in ('-deployment','-preparation','-execution'):
            folder=BASE/(prefix+suffix)
            items.update({prefix+suffix+'/'+p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file()})
        items[prefix+'/stage-package.json']=(BASE/(prefix+'-stage-package.json')).read_bytes()
    for prefix,expected in [('surface-dry-lm-bound-qe-b','ff72f24be5e919b7d086a14999fd1ff105f314a5de5bcb2ccfd10be5731ed1db'),
        ('surface-dry-lm-bound-qe-c','bd6649543219b15ac5300f83a9221acecf8a4d44215194175fc4fe0c84d86135')]:
        raw=(BASE/(prefix+'-result.tar.gz')).read_bytes();assert sha(raw)==expected
        items[prefix+'/original-result.tar.gz']=raw
        with tarfile.open(fileobj=io.BytesIO(raw)) as t:
            originals={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
        items.update({prefix+'/result/'+n:b for n,b in originals.items()})
    for foldername in ('surface-dry-lm-bound-qe-1829-closure','surface-dry-lm-bound-qe-b-closure','surface-dry-lm-bound-qe-c-closure'):
        folder=BASE/foldername
        items.update({foldername+'/'+p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file() and 'readable' not in p.relative_to(folder).parts})
    terminal=(BASE/'surface-dry-lm-bound-qe-1829-closure/terminal/qstat.stdout').read_bytes()
    assert all(x in terminal for x in (b'job_state = F',b'Exit_status = 126',b'Stageout_status = 0'))
    for filename in ('surface-dry-lm-bound-qe-b-failure.json','read_surface_lm_bound_qe_1829.py',
        'collect_surface_lm_bound_qe_b_closed.py','collect_surface_lm_bound_qe_c_closed.py',
        'prepare_surface_dry_lm_bound_qe.py','prepare_surface_dry_lm_bound_qe_b.py','prepare_surface_dry_lm_bound_qe_c.py',
        'deploy_surface_dry_lm_bound_qe.py','deploy_surface_dry_lm_bound_qe_b.py','deploy_surface_dry_lm_bound_qe_c.py',Path(__file__).name):
        items['provenance/'+filename]=(BASE/filename).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='1840 trueF0/Stageout0 saved-output arithmetic:27 arguments/60 exact checks; final12 interior coordinates; zero evaluate/LM calls. Original1829F126 and1830F1 retained, default+inf JSON cause corrected. No physical repair, promotion, GPU, column timestep, annual or scientific acceptance.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

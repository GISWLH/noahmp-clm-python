"""PBS-only arithmetic on saved PY-c outputs, with no model reevaluation."""
from pathlib import Path
from dataclasses import fields,is_dataclass
import ast
import hashlib
import io
import json
import os
import pickle
import socket
import sys
import tarfile
import traceback

STAGE=Path('/tmp/noahmp-surface-dry-lm-bound-qe-b')
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def archive(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()]
        names=[m.name.removeprefix('./') for m in members]
        assert len(set(names))==len(names)
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts and '\\' not in n for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def main():
    assert os.name!='nt' and socket.gethostname().split('.')[0]=='compute002'
    assert os.environ.get('PBS_JOBID') and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=Path(sys.argv[1]);assert not root.exists();root.mkdir()
    binding=json.loads((STAGE/'preparation/BINDINGS.json').read_bytes())
    index=json.loads((STAGE/'stage-inventory.json').read_bytes())
    before={n:sha((STAGE/n).read_bytes()) for n in index};assert before==index
    output=dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),passed=False,
        original_physical_failure_preserved=True,original_PY_c_job='1822.manager',
        LM_replays=0,physical_evaluate_calls=0,model_changes=0,GPU_calls=0,
        numerical_scope='Saved final x and saved original first-call inputs only; no evaluate/LM/model call.',
        bindings=binding)
    status=1;source=None;source_before=None
    try:
        for name,expected in binding['archives'].items():assert sha((STAGE/name).read_bytes())==expected
        source_files=archive((STAGE/'source.tar.gz').read_bytes())
        source_manifest=json.loads(source_files.pop('SOURCE_SHA256.json'))
        assert len(source_files)==584 and {n:sha(b) for n,b in source_files.items()}==source_manifest
        source=root/'source';source.mkdir()
        for name,raw in source_files.items():
            target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        source_before={n:sha((source/n).read_bytes()) for n in source_files}
        sys.path.insert(0,str(source/'src'))
        import numpy as np
        py=archive((STAGE/'py-c-result.tar.gz').read_bytes())
        pw=archive((STAGE/'pw-result.tar.gz').read_bytes())
        pyreceipt=json.loads(py['probe/receipt.json'])
        assert pyreceipt['pbs_job']=='1822.manager' and not pyreceipt['passed']
        assert pyreceipt['source_members_exact'] and pyreceipt['immutable_before_after_exact']
        captured=pickle.loads(py['probe/actual-row-0/first-phase-before.pkl'])
        observation=pickle.loads(py['probe/actual-row-0/actual-observation.pkl'])
        frame=pickle.loads(pw['probe/original-model/phase-final-frame.pkl'])['frames'][0]['locals']
        for prefix in ('probe/actual-row-0/first-phase-before','probe/actual-row-0/actual-observation'):
            meta=json.loads(py[prefix+'.json'])
            assert sha(py[prefix+'.pkl'])==meta['pickle_sha256'] and sha(py[prefix+'.npz'])==meta['npz_sha256']
        comparisons=[]
        def compare(left,right,path):
            if is_dataclass(left) or is_dataclass(right):
                valid=is_dataclass(left) and is_dataclass(right) and type(left) is type(right)
                comparisons.append(dict(path=path,kind='dataclass_type',passed=valid))
                if valid:
                    for f in fields(left):compare(getattr(left,f.name),getattr(right,f.name),path+'/'+f.name)
            elif isinstance(left,dict) or isinstance(right,dict):
                valid=isinstance(left,dict) and isinstance(right,dict) and set(left)==set(right)
                comparisons.append(dict(path=path,kind='dictionary_keys',passed=valid))
                if valid:
                    for key in left:compare(left[key],right[key],path+'/'+str(key))
            elif isinstance(left,(list,tuple)) or isinstance(right,(list,tuple)):
                valid=type(left) is type(right) and len(left)==len(right)
                comparisons.append(dict(path=path,kind='sequence',passed=valid))
                if valid:
                    for k,(a,b) in enumerate(zip(left,right)):compare(a,b,path+'/'+str(k))
            elif isinstance(left,(np.ndarray,np.generic)) or isinstance(right,(np.ndarray,np.generic)):
                a,b=np.asarray(left),np.asarray(right)
                valid=a.dtype==b.dtype and a.shape==b.shape and a.tobytes(order='C')==b.tobytes(order='C')
                comparisons.append(dict(path=path,kind='array',passed=valid,left_dtype=a.dtype.str,right_dtype=b.dtype.str,
                    left_shape=list(a.shape),right_shape=list(b.shape),left_payload_sha256=sha(a.tobytes(order='C')),
                    right_payload_sha256=sha(b.tobytes(order='C'))))
            else:
                valid=type(left) is type(right) and left==right
                comparisons.append(dict(path=path,kind='scalar',passed=bool(valid),
                    left_type=type(left).__name__,right_type=type(right).__name__,
                    left_value=left,right_value=right))
        for key,value in captured.items():
            assert key in frame,key
            compare(value,frame[key],key)
        output['Qia_original_phase_argument_names']=list(captured)
        output['Qia_saved_input_comparisons']=comparisons
        output['Qia_saved_first_phase_inputs_exact_to_PW']=all(r['passed'] for r in comparisons)
        constants={}
        for node in ast.parse(source_files['src/noahmp_clm/physics/snowpack.py']).body:
            if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
                if node.targets[0].id in ('TF','CI','CW','LF'):constants[node.targets[0].id]=ast.literal_eval(node.value)
        assert set(constants)=={'TF','CI','CW','LF'}
        TF,CI,CW,LF=(constants[k] for k in ('TF','CI','CW','LF'))
        phase_text=source_files['src/noahmp_clm/physics/canopy_phase_energy.py'].decode()
        lines=[line.strip() for line in phase_text.splitlines()]
        lower_line='lower=np.r_[np.where(mass>0.,(200.-TF)*CI/CW,200.-TF),200.,0.]'
        upper_line='upper=np.r_[np.where(mass>0.,LF/CW+350.-TF,350.-TF),350.,190.]'
        assert lines.count(lower_line)==lines.count(upper_line)==1
        mass=captured['condensate'].mass
        lower=np.r_[np.where(mass>0.,(200.-TF)*CI/CW,200.-TF),200.,0.]
        upper=np.r_[np.where(mass>0.,LF/CW+350.-TF,350.-TF),350.,190.]
        rescue=observation['rescue_records'][0];x=rescue['x']
        assert x.shape==lower.shape==upper.shape==(12,)
        assert rescue['reason']=='no_feasible_displacement' and rescue['last_iteration']==61
        assert rescue['accepted']==20 and rescue['rejected']==11
        coordinates=[]
        for k,(v,lo,hi) in enumerate(zip(x,lower,upper)):
            ulp=float(abs(np.spacing(v)))
            coordinates.append(dict(index=k,name=('leaf_temperature_offset_'+str(k) if k<10 else 'ground_temperature' if k==10 else 'air_specific_humidity_gkg'),
                value=float(v),value_hex=float(v).hex(),lower=float(lo),upper=float(hi),
                finite=bool(np.isfinite(v)),inside=bool(lo<=v<=hi),at_lower=bool(v==lo),at_upper=bool(v==hi),
                distance_to_lower=float(v-lo),distance_to_upper=float(hi-v),ulp_at_x=ulp,
                lower_distance_in_local_ULPs=float((v-lo)/ulp),upper_distance_in_local_ULPs=float((hi-v)/ulp),
                local_ULPs_scope='distance/abs(spacing(x)); not a bitwise representable-number count across the interval'))
        output.update(constants_from_bound_frozen_source=constants,original_bound_source_lines=[lower_line,upper_line],
            mass_all_zero=bool(np.all(mass==0.)),final_x_finite=bool(np.all(np.isfinite(x))),
            final_x_inside_original_bounds=bool(np.all((x>=lower)&(x<=upper))),coordinates=coordinates,
            final_x_at_lower_indices=[r['index'] for r in coordinates if r['at_lower']],
            final_x_at_upper_indices=[r['index'] for r in coordinates if r['at_upper']],
            actual_saved_rescue_fields=list(rescue),saved_LM_direction=None,saved_LM_residual=None,saved_LM_Jacobian=None,
            cause_scope='Original helper saves x and counters only. An exact bound permits an outward coordinate to force common alpha to0; direction was not saved, so this does not establish its sign or exclude roundoff no-movement. No new residual or derivative was evaluated.',
            source_file_count=len(source_files),numpy_version=np.__version__)
        assert output['Qia_saved_first_phase_inputs_exact_to_PW']
        assert output['final_x_finite'] and output['final_x_inside_original_bounds']
        output['passed']=True;status=0
    except BaseException:
        output['exception']=traceback.format_exc()
    finally:
        stage_after={n:sha((STAGE/n).read_bytes()) for n in index}
        output['stage_before_after_exact']=stage_after==before==index
        if source is not None:
            output['source_before_after_exact']={n:sha((source/n).read_bytes()) for n in source_before}==source_before
        if not output['stage_before_after_exact'] or not output.get('source_before_after_exact',False):status=1
        output['actual_analysis_exit']=status
        (root/'readout.json').write_text(json.dumps(output,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return status


if __name__=='__main__':sys.exit(main())

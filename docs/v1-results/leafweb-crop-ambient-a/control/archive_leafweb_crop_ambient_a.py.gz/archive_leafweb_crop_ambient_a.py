from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'leafweb-crop-ambient-a';a=b/'leafweb-crop-ambient-a-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for stage in ['calibration','validation','summary']:assert (r/(stage+'-pbs-exit.txt')).read_text().strip()=='0'
d=json.loads((r/'summary.json').read_text());assert d['all_files']==63 and d['scored_files']==14 and d['scored_light_points']==162 and d['status_counts']=={'fail':11,'unmeasured':49,'pass':3}
assert sha(r/'calibration.json')=='38ea145f176447a01d668fbbc7b3ee215259aa6775f3962f5deca65a48d283dc' and sha(r/'validation.json')=='5da53726dcd60fef34a1cefeb096fcbba7e99b2ada8cef397d3a035bd1382ec9'
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for label in ('a','b','c','d'):
        old=b/('leafweb-crop-inventory-'+label);assert (old/'pbs-exit.txt').read_text().strip()=='0'
        for p in sorted(old.rglob('*')):
            if p.is_file() and p.name!='C3_crop.zip':t.add(p,arcname='inventory-'+label+'/'+p.relative_to(old).as_posix(),recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='EHPC PBS211-214 entire63file format inventory with all partial/misparsed inventories retained;215dark/A-Ci-only fixed27start capacities frozen before216holdout;217summary. Allsource unchanged,14curves162points,3pass/11fail/49unmeasured. Not blanketP2/stomatal/canopy/FLUXNET/science acceptance,no production changes.')))

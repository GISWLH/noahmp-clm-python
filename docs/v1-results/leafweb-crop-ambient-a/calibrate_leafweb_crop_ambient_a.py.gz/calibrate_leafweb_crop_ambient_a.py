"""EHPC PBS A-Ci-only calibration; never predicts or scores light rows."""
from pathlib import Path
from dataclasses import asdict
from itertools import product
import hashlib,json,os,sys,tarfile,time,traceback

assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'leafweb-crop-ambient-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=Path(os.environ['TMPDIR'])/'source';s.mkdir()
a=b/'p6-most-physical-c-source.tar.gz';assert sha(a)=='bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==509 and all(sha(s/n)==v for n,v in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(r)]
import numpy as np
from scipy.optimize import least_squares
from leafweb_crop_reader_a import read_archive,ambient_roles,number,unit_check
from noahmp_clm.physics.photosynthesis import LeafParameters,farquhar_rates

protocol=dict(scope='Prospective crop cross-curve biochemical evaluation at measured Ci,after unscored entire-archive inventory. All63files retained. Not a blind study of the full Leafweb resource,stomatal validation or canopy/FLUXNET acceptance. No production code change.',data_doi='10.25581/ornlsfa.027/1887896',archive_sha256=sha(r/'C3_crop.zip'),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),reader_sha256=sha(r/'leafweb_crop_reader_a.py'),calibrator_sha256=sha(Path(__file__)),selection='All63 files. Ambient OxygenPress/Level exactly21 percent only. At least4 A-Ci and4 held-out light rows,exactly1 ambient dark record,compatible units. Other oxygen/record roles retained but not evaluated. Missing or invalid dark/ACI domain gives explicit unmeasured file; no score-based selection.',parameters='Dark Rd25 from separate ambient DataType0 net rate and original temperature response; PSII from same dark Fm/Fo,prefer FmorFm/FoorFs then documented FmDark/FoDark alternate only if primary invalid. Absorptance .84 and curvature .7 fixed previous assumptions,not measured crop optics. GrowthT298.15,O2ppm210000;no light inputs used for fitting.',fit='27 fixed starts Vcmax25=20/60/180,Jmax25=40/120/360,TPU25=2/10/30. Original bounds [1,1,.1]..[300,600,50],max_nfev2000 each. Select successful minimum A-Ci SSE only,report all starts/Jacobian rank/boundaries. No extra parameter or retry escalation.',freeze='Calibration JSON with all successful parameters and original rows is durably written before separate validation job can evaluate any light prediction. Validation must bind this JSON SHA and same source/reader.',acceptance='Per original leaf protocol: NRMSE=RMSE/abs(mean observed)>1 <=.1 and nearzero points abs(obs)<=1 use fixed .5umol/m2/s absolute. Report signed bias,r,all pairs,all files and each light DataType curve. No r-only substitute or posthoc threshold change.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename)
(r/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
entries=read_archive(r/'C3_crop.zip');inventory=json.loads((b/'leafweb-crop-inventory-d/inventory.json').read_text());prior={f['file']:f for f in inventory['files']}
assert len(entries)==len(prior)==63
start=time.monotonic();results=[]
for entry in entries:
    name=entry['file'];roles=ambient_roles(entry);old=prior[name]
    assert entry['sha256']==old['sha256'] and len(entry['records'])==old['n']
    assert all(len(roles[k])==old['ambient21_prospective'][k+'_n'] for k in ('dark','aci','light'))
    record=dict(file=name,file_sha256=entry['sha256'],units=entry['units'],raw_headers=entry['raw_headers'],canonical_headers=entry['canonical_headers'],ambient_counts={k:len(v) for k,v in roles.items()},status='unmeasured',reason=None)
    results.append(record)
    if not unit_check(entry):record['reason']='Incompatible/missing physical units';continue
    if len(roles['dark'])!=1 or len(roles['aci'])<4 or len(roles['light'])<4:record['reason']='No complete ambient dark/A-Ci/held-out-light protocol';continue
    dark=roles['dark'][0];t,net=number(dark,'Tleaf'),number(dark,'AnetCO2')
    if t is None or net is None or not 200<=t+273.15<=350 or net>=0.:record['reason']='Invalid independent dark respiration or temperature';continue
    fm,fo=number(dark,'FmorFm.'),number(dark,'FoorFs');fluorescence_source='FmorFm/FoorFs'
    if fm is None or fo is None or not 0<=fo<fm:
        fm,fo=number(dark,'FmDark'),number(dark,'FoDark');fluorescence_source='FmDark/FoDark'
    if fm is None or fo is None or not 0<=fo<fm:record['reason']='Missing/invalid independent dark fluorescence';continue
    quantum=1.-fo/fm;factor=float(farquhar_rates(420.,0.,t+273.15,LeafParameters(respiration25=1.))['respiration']);rd=-net/factor
    training=np.asarray([[number(row,k) for k in ('CO2i','PARi','Tleaf','AnetCO2')] for row in roles['aci']],float)
    if not np.all(np.isfinite(training)) or np.any((training[:,0]<0)|(training[:,1]<0)|(training[:,2]+273.15<200)|(training[:,2]+273.15>350)):
        record['reason']='Original A-Ci observations outside model input domain';continue
    def parameters(x):return LeafParameters(vcmax25=float(x[0]),jmax25=float(x[1]),tpu25=float(x[2]),respiration25=rd,quantum_yield_psii=quantum)
    def residual(x):return farquhar_rates(training[:,0],.84*training[:,1],training[:,2]+273.15,parameters(x))['net']-training[:,3]
    fits=[];best=None
    for initial in product((20.,60.,180.),(40.,120.,360.),(2.,10.,30.)):
        fit=least_squares(residual,initial,bounds=([1.,1.,.1],[300.,600.,50.]),max_nfev=2000)
        item=dict(initial=list(initial),success=bool(fit.success),message=fit.message,nfev=fit.nfev,sse=float(fit.fun@fit.fun),parameters=asdict(parameters(fit.x)),jacobian_rank=int(np.linalg.matrix_rank(fit.jac)),active_bounds=fit.active_mask.tolist())
        fits.append(item)
        if fit.success and (best is None or item['sse']<best['sse']):best=item
    record.update(fits=fits,dark_csv_line=dark['csv_line'],dark_fluorescence_source=fluorescence_source,dark_fm=fm,dark_fo=fo,aci_rows=[dict(csv_line=row['csv_line'],values=dict(zip(('ci_ppm','incident_par','leaf_c','observed_net'),map(float,value)))) for row,value in zip(roles['aci'],training)])
    if best is None:record['reason']='No successful fit within fixed original budget';continue
    record.update(status='calibrated',reason=None,parameters=best['parameters'],selected_training_sse=best['sse'],calibration_rmse=float(np.sqrt(best['sse']/len(training))),jacobian_rank=best['jacobian_rank'],active_bounds=best['active_bounds'])
assert all(sha(s/n)==v for n,v in m.items())
out=dict(scope=protocol['scope'],pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,protocol_sha256=sha(r/'protocol.json'),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,archive_sha256=sha(r/'C3_crop.zip'),light_predictions_evaluated=False,files=results,seconds=time.monotonic()-start)
with (r/'calibration.json').open('x') as f:json.dump(out,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'],source_unchanged=True,files=len(results),calibrated=sum(v['status']=='calibrated' for v in results),seconds=out['seconds'],calibration_sha256=sha(r/'calibration.json'),light_predictions_evaluated=False)),flush=True)

"""EHPC PBS only: unscored inventory before choosing a crop holdout protocol."""
from pathlib import Path
from collections import Counter
import csv,hashlib,io,json,math,os,tarfile,time,zipfile

assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'leafweb-crop-inventory-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=r/'C3_crop.zip';assert sha(archive)=='3afdd583949527fd64c6809b0aa6fe8c3cf2a52c31e82998580928d1d336b7ba'
protocol=dict(scope='Unscored inventory of the entire pinned previously downloaded LeafWeb C3_crop archive. No production physics invocation,fitting,light scoring or score-based data selection. CPU data analysis only on EHPC PBS compute node.',data_doi='10.25581/ornlsfa.027/1887896',archive_sha256=sha(archive),ambient_rule='Report every file and every OxygenPress level. Exact21 percent group is the prospective ambient-only domain; other oxygen groups retained and counted,not silently predicted by fixed ambient Gamma. Unit strings are inventoried before any quantitative evaluation.',roles='DataType0 dark;11..25 A-Ci;31..45 light,as previously fixed in grass protocol. Inventory other codes verbatim. No acceptance decision from inventory.',source_archive_sha256='bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe',probe_sha256=sha(Path(__file__)),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename)
(r/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
start=time.monotonic();files=[]
with zipfile.ZipFile(archive) as z:
    for info in sorted(z.infolist(),key=lambda v:v.filename):
        entry=dict(file=info.filename,bytes=info.file_size,crc=info.CRC)
        if info.is_dir() or not info.filename.lower().endswith('.csv'):
            entry['status']='non-data-member';files.append(entry);continue
        raw=z.read(info);entry['sha256']=hashlib.sha256(raw).hexdigest()
        rows=list(csv.DictReader(io.StringIO(raw.decode('cp1252'))));units=rows[0] if rows else {}
        records=rows[1:];entry.update(status='inventoried',n=len(records),headers=list(units),units=units)
        counts=Counter();groups={};invalid=[]
        for index,row in enumerate(records):
            def numeric(key):
                try:
                    value=float(row[key]);return value if math.isfinite(value) else None
                except (KeyError,TypeError,ValueError):return None
            dtype=numeric('DataType');oxygen=numeric('OxygenPress')
            counts[str(dtype)]+=1
            key=str(oxygen);g=groups.setdefault(key,dict(oxygen=oxygen,n=0,dark_n=0,aci_n=0,light_n=0,other_n=0,critical_invalid_rows=[],dark=[]))
            g['n']+=1
            if dtype==0.:role='dark'
            elif dtype is not None and 11.<=dtype<=25.:role='aci'
            elif dtype is not None and 31.<=dtype<=45.:role='light'
            else:role='other'
            g[role+'_n']+=1
            values={k:numeric(k) for k in ['CO2i','PARi','Tleaf','AnetCO2','DataType','FmorFm.','FoorFs','OxygenPress']}
            if any(v is None for v in values.values()):g['critical_invalid_rows'].append(index+3)
            if role=='dark':g['dark'].append(dict(csv_line=index+3,values=values))
        ambient=groups.get('21.0',dict(dark_n=0,aci_n=0,light_n=0,critical_invalid_rows=[]))
        entry.update(data_type_counts=dict(counts),oxygen_groups=groups,ambient21_prospective=dict(dark_n=ambient['dark_n'],aci_n=ambient['aci_n'],light_n=ambient['light_n'],critical_invalid_n=len(ambient['critical_invalid_rows']),basic_count_eligibility=ambient['dark_n']==1 and ambient['aci_n']>=4 and ambient['light_n']>=4 and not ambient['critical_invalid_rows']))
        files.append(entry)
summary=dict(scope=protocol['scope'],pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,archive_sha256=sha(archive),all_members=len(files),csv_files=sum(v['status']=='inventoried' for v in files),basic_ambient21_count_eligible=sum(v.get('ambient21_prospective',{}).get('basic_count_eligibility',False) for v in files),files=files,seconds=time.monotonic()-start)
(r/'inventory.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='files'}),flush=True)

"""Pinned observational CSV reader used only by the controlled experiment."""
from pathlib import Path
import csv,hashlib,io,math,zipfile

ARCHIVE_SHA='3afdd583949527fd64c6809b0aa6fe8c3cf2a52c31e82998580928d1d336b7ba'


def read_archive(path):
    raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==ARCHIVE_SHA
    result=[]
    aliases={'datatype':'DataType','co2i':'CO2i','co2i-correctedforleaks':'CO2i','pari':'PARi','tleaf':'Tleaf','anetco2':'AnetCO2','anetco2-correctedforleaks':'AnetCO2','oxygenlevel':'OxygenPress','oxygenpress':'OxygenPress','fmorfm':'FmorFm.','foorfs':'FoorFs'}
    def canonical(value):
        key=value.strip().lstrip('\ufeff');return aliases.get(key.lower().rstrip(".*'"),key)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        for info in sorted(z.infolist(),key=lambda v:v.filename):
            assert not info.is_dir() and info.filename.lower().endswith('.csv')
            data=z.read(info)
            try:text=data.decode('utf-8-sig');encoding='utf-8-sig'
            except UnicodeDecodeError:text=data.decode('cp1252');encoding='cp1252'
            lines=list(csv.reader(io.StringIO(text)))
            required={'DataType','CO2i','PARi','Tleaf','AnetCO2'}
            where=[i for i,line in enumerate(lines) if required<=set(map(canonical,line))]
            assert len(where)==1,info.filename
            header=where[0];names=list(map(canonical,lines[header]));seen=set()
            for key in set(aliases.values()):assert names.count(key)<=1,(info.filename,key)
            for i,name in enumerate(names):
                if not name or name in seen:names[i]='__extra_column_'+str(i)
                seen.add(names[i])
            units=dict(zip(names,lines[header+1]));records=[]
            for i,line in enumerate(lines[header+2:],start=header+3):
                if any(v.strip() for v in line):records.append(dict(csv_line=i,values=dict(zip(names,line))))
            result.append(dict(file=info.filename,sha256=hashlib.sha256(data).hexdigest(),encoding=encoding,raw_headers=lines[header],canonical_headers=names,units=units,records=records))
    assert len(result)==63
    return result


def number(row,key):
    try:
        value=float(row['values'][key]);return value if math.isfinite(value) else None
    except (ValueError,TypeError,KeyError):return None


def ambient_roles(entry):
    rows=[r for r in entry['records'] if number(r,'OxygenPress')==21.]
    return dict(dark=[r for r in rows if number(r,'DataType')==0.],
        aci=[r for r in rows if number(r,'DataType') is not None and 11.<=number(r,'DataType')<=25.],
        light=[r for r in rows if number(r,'DataType') is not None and 31.<=number(r,'DataType')<=45.])


def unit_check(entry):
    def clean(value):return value.lower().replace('µ','u').replace('μ','u').replace(' ','').replace('^','')
    u={k:clean(v) for k,v in entry['units'].items()}
    rates={'umol/m2/s','umolm-2s-1'}
    return u.get('OxygenPress') in {'%','percent'} and u.get('Tleaf') in {'oc','°c'} and u.get('CO2i') in {'ppm','umol/mol','umolmol-1'} and u.get('PARi') in rates and u.get('AnetCO2') in rates

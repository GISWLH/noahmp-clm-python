from pathlib import Path
from collections import Counter
import hashlib,json,os
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'leafweb-crop-ambient-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'calibration-pbs-exit.txt').read_text().strip()=='0' and (r/'validation-pbs-exit.txt').read_text().strip()=='0'
assert sha(r/'calibration.json')=='38ea145f176447a01d668fbbc7b3ee215259aa6775f3962f5deca65a48d283dc'
d=json.loads((r/'validation.json').read_text());c=json.loads((r/'calibration.json').read_text());assert len(d['files'])==len(c['files'])==63 and d['source_unchanged'] and d['calibration_unchanged']
scored=[f for f in d['files'] if 'statistics' in f];groups={}
for f in scored:
    family='tomato-Basket-Vee' if 'Basket_Vee' in f['file'] else 'rice' if f['file'].startswith('Rice') else 'tomato-Growdena' if f['file'].startswith('Tomato_Growdena') else 'other'
    groups.setdefault(family,[]).append(f)
summary=dict(scope='EHPC PBS descriptive summary of unchanged separate crop calibration/holdout artifacts. Every original file retained,no model/parameter/refit/acceptance change.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,calibration_sha256=sha(r/'calibration.json'),validation_sha256=sha(r/'validation.json'),all_files=63,status_counts=dict(Counter(f['status'] for f in d['files'])),unmeasured_reasons=dict(Counter(f['reason'] for f in d['files'] if f['status']=='unmeasured')),scored_files=len(scored),scored_light_points=sum(f['statistics']['n'] for f in scored),near_zero_points=sum(f['statistics']['near_zero_n'] for f in scored),near_zero_failures=sum(f['statistics']['near_zero_failures'] for f in scored),mean_bias_within10_percent=sum(abs(f['statistics']['relative_mean_bias'])<=.1 for f in scored if f['statistics']['relative_mean_bias'] is not None),families={})
for family,files in groups.items():
    summary['families'][family]=dict(files=len(files),pass_count=sum(f['status']=='pass' for f in files),light_points=sum(f['statistics']['n'] for f in files),normalized_rmse_percent_range=[100.*min(f['statistics']['normalized_rmse'] for f in files),100.*max(f['statistics']['normalized_rmse'] for f in files)],signed_mean_bias_percent_range=[100.*min(f['statistics']['relative_mean_bias'] for f in files),100.*max(f['statistics']['relative_mean_bias'] for f in files)],r_range=[min(f['statistics']['r'] for f in files),max(f['statistics']['r'] for f in files)],jacobian_rank_counts=dict(Counter(f['jacobian_rank'] for f in files)),near_zero_failures=sum(f['statistics']['near_zero_failures'] for f in files))
with (r/'summary.json').open('x') as output:json.dump(summary,output,indent=2,allow_nan=False);output.write('\n')
print(json.dumps(summary),flush=True)

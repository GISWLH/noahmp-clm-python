"""Separate EHPC PBS holdout; fixed capacities are SHA-bound before scoring."""
from pathlib import Path
import hashlib,json,os,sys,tarfile,time

assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'leafweb-crop-ambient-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'calibration-pbs-exit.txt').read_text().strip()=='0'
assert sha(r/'calibration.json')=='38ea145f176447a01d668fbbc7b3ee215259aa6775f3962f5deca65a48d283dc'
calibration=json.loads((r/'calibration.json').read_text());protocol=json.loads((r/'protocol.json').read_text())
assert calibration['source_unchanged'] and calibration['light_predictions_evaluated'] is False and len(calibration['files'])==63
assert sha(r/'protocol.json')==calibration['protocol_sha256'] and sha(r/'leafweb_crop_reader_a.py')==protocol['reader_sha256']
s=Path(os.environ['TMPDIR'])/'source';s.mkdir();a=b/'p6-most-physical-c-source.tar.gz';assert sha(a)=='bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==509 and all(sha(s/n)==v for n,v in m.items()) and sha(s/'SOURCE_SHA256.json')==calibration['source_manifest_sha256']
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(r)]
import numpy as np
from leafweb_crop_reader_a import read_archive,ambient_roles,number
from noahmp_clm.physics.photosynthesis import LeafParameters,farquhar_rates

binding=dict(scope='Separate prospective crop ambient21 holdout after all63file calibration artifact frozen. No fit,capacity/optics/threshold selection,stomatal/canopy/FLUXNET or production-change claim.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,calibration_sha256=sha(r/'calibration.json'),protocol_sha256=sha(r/'protocol.json'),reader_sha256=sha(r/'leafweb_crop_reader_a.py'),validator_sha256=sha(Path(__file__)),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),acceptance=protocol['acceptance'])
(r/'validation-protocol.json').write_text(json.dumps(binding,indent=2)+'\n')
start=time.monotonic();prior={f['file']:f for f in calibration['files']};entries=read_archive(r/'C3_crop.zip');results=[]


def statistics(predicted,observed):
    delta=predicted-observed;near=abs(observed)<=1.;mean=float(observed.mean());rmse=float(np.sqrt(np.mean(delta*delta)))
    nrmse=rmse/abs(mean) if abs(mean)>1. else None
    near_fail=int(np.sum(abs(delta[near])>.5))
    status=('pass' if nrmse<=.1 and near_fail==0 else 'fail') if nrmse is not None else (('pass' if near_fail==0 else 'fail') if np.all(near) else 'indeterminate')
    return dict(n=len(observed),status=status,observed_mean=mean,predicted_mean=float(predicted.mean()),mean_bias=float(delta.mean()),relative_mean_bias=float(delta.mean()/mean) if abs(mean)>1. else None,rmse=rmse,normalized_rmse=nrmse,r=float(np.corrcoef(predicted,observed)[0,1]) if np.ptp(predicted)>0. and np.ptp(observed)>0. else None,near_zero_n=int(near.sum()),near_zero_maximum_absolute=float(np.max(abs(delta[near]))) if near.any() else None,near_zero_failures=near_fail,non_near_zero_pointwise_relative_failures=int(np.sum(abs(delta[~near])>.1*abs(observed[~near]))))


for entry in entries:
    old=prior[entry['file']];assert entry['sha256']==old['file_sha256']
    record={k:old[k] for k in ('file','file_sha256','status','reason','ambient_counts')};results.append(record)
    if old['status']!='calibrated':continue
    p=LeafParameters(**old['parameters']);roles=ambient_roles(entry)
    training=np.asarray([[number(v,k) for k in ('CO2i','PARi','Tleaf','AnetCO2')] for v in roles['aci']],float)
    repro=farquhar_rates(training[:,0],.84*training[:,1],training[:,2]+273.15,p)['net']
    np.testing.assert_allclose(np.sqrt(np.mean((repro-training[:,3])**2)),old['calibration_rmse'],rtol=0.,atol=1e-10)
    rows=roles['light'];light=np.asarray([[number(v,k) for k in ('CO2i','PARi','Tleaf','AnetCO2','DataType')] for v in rows],float)
    if not np.all(np.isfinite(light)) or np.any((light[:,0]<0)|(light[:,1]<0)|(light[:,2]+273.15<200)|(light[:,2]+273.15>350)):
        record.update(status='unmeasured',reason='Held-out observations outside original model input domain; all original rows retained',original_light_rows=rows);continue
    prediction=farquhar_rates(light[:,0],.84*light[:,1],light[:,2]+273.15,p)['net']
    record.update(parameters=old['parameters'],calibration_rmse=old['calibration_rmse'],jacobian_rank=old['jacobian_rank'],active_bounds=old['active_bounds'],statistics=statistics(prediction,light[:,3]),rows=[dict(csv_line=v['csv_line'],data_type=int(point[4]),ci_ppm=float(point[0]),incident_par=float(point[1]),leaf_c=float(point[2]),observed_net=float(point[3]),predicted_net=float(a)) for v,point,a in zip(rows,light,prediction)])
    record['status']=record['statistics']['status'];record['curves']={str(int(code)):statistics(prediction[light[:,4]==code],light[light[:,4]==code,3]) for code in sorted(set(light[:,4]))}
assert all(sha(s/n)==v for n,v in m.items()) and sha(r/'calibration.json')==binding['calibration_sha256']
out=dict(scope=binding['scope'],pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,calibration_unchanged=True,validation_protocol_sha256=sha(r/'validation-protocol.json'),calibration_sha256=binding['calibration_sha256'],files=results,seconds=time.monotonic()-start)
with (r/'validation.json').open('x') as f:json.dump(out,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'],source_unchanged=True,calibration_unchanged=True,seconds=out['seconds'],files=63,scored=sum('statistics' in f for f in results),results=[{k:f.get(k) for k in ('file','status','statistics')} for f in results if 'statistics' in f])),flush=True)

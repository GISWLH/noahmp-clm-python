from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-kg';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=b/'clm-ballberry-jn-package.json';p=json.loads(plan.read_text());assert sha(b/p['archive'])==p['archive_sha256'];(r/'package.json').write_bytes(plan.read_bytes());name='run_hrldas_current_kg.py';raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-hrldas-current-kg
#PBS -q workq
#PBS -l select=1:ncpus=3:mem=12gb
#PBS -l walltime=04:00:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/hrldas-current-kg
hostname >node.txt
/home/zhangyq/venvs/noahmp-closeout/bin/python -u run_hrldas_current_kg.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
''';(r/'job.pbs').write_text(script);q=subprocess.run(['qsub',str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr;d=dict(pbs_job=q.stdout.strip(),controls_sha256={n:sha(r/n) for n in [name,'job.pbs','package.json']},scope='CurrentJN exactoriginal3-site HRLDAS paircold48then336, all17,520requests retained, no oldstate seed or parameter/forcing/height/leaf changes. ActualNumPyfirst onPBScompute beforeGPUhand-off; independentofficialcomparison stillpending.');(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

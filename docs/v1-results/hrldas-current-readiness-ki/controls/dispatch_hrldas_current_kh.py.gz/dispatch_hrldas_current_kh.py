from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-kh';model=b/'hrldas-current-kg'
assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((model/'dispatch.json').read_text())['pbs_job'];assert parent=='1188.manager'
name='compare_hrldas_current_kh.py';raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-hrldas-audit-kh
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=6gb
#PBS -l walltime=00:30:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/hrldas-current-kh
hostname >node.txt
/home/zhangyq/venvs/noahmp-closeout/bin/python -u compare_hrldas_current_kh.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(r/'job.pbs').write_text(script)
q=subprocess.run(['qsub','-W','depend=afterok:'+parent,str(r/'job.pbs')],cwd=r,capture_output=True,text=True)
assert q.returncode==0,q.stderr
d=dict(pbs_job=q.stdout.strip(),dependency='afterok:'+parent,controls_sha256={n:sha(r/n) for n in [name,'job.pbs']},
    scope='Queued independent currentJN NumPy1008packet chain/input/budget audit and strictoriginal3siteHRLDAScold336comparison. ActualmodelF0required; no currentrun or sciencepass fromsubmission.')
(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

"""Freeze existing inputs/controls and consistent live report generations only."""
from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');model=b/'hrldas-current-kg';audit=b/'hrldas-current-kh'
sha=lambda raw:hashlib.sha256(raw).hexdigest();payload={};observed=[]
for root,prefix in [(model,'model'),(audit,'audit')]:
    d=json.loads((root/'dispatch.json').read_text())
    for name,h in d['controls_sha256'].items():
        raw=(root/name).read_bytes();assert sha(raw)==h;payload[prefix+'/'+name]=raw
    payload[prefix+'/dispatch.json']=(root/'dispatch.json').read_bytes()
    state=subprocess.check_output(['qstat','-xf',d['pbs_job']],text=True)
    payload[prefix+'/actual-pbs-qstat.txt']=state.encode()
    observed.append(dict(role=prefix,pbs_job=d['pbs_job'],scope=d['scope']))
for name in ['SOURCE_SHA256.json','inputs/protocol.json']:
    payload['model/'+name]=(model/name).read_bytes()
manifest=sha(payload['model/SOURCE_SHA256.json']);assert manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
package=json.loads((b/'hrldas-current-kg-inputs-package.json').read_text());archive=b/package['archive']
assert sha(archive.read_bytes())==package['sha256']
payload['frozen-inputs/'+archive.name]=archive.read_bytes();payload['frozen-inputs/package.json']=(b/'hrldas-current-kg-inputs-package.json').read_bytes()
rows=[]
for folder in sorted((model/'runs').iterdir()):
    path=folder/'trajectory/report.json'
    for attempt in range(5):
        raw=path.read_bytes();d=json.loads(raw);trace=(path.parent/d['model_npz']).read_bytes();checkpoint=(path.parent/d['checkpoint_file']).read_bytes()
        assert sha(trace)==d['model_npz_sha256'] and sha(checkpoint)==d['checkpoint_sha256']
        if path.read_bytes()==raw:break
    else:raise RuntimeError('No consistent report generation: '+folder.name)
    prefix='model/reports-at-snapshot/'+folder.name
    payload[prefix+'/report.json']=raw;payload[prefix+'/'+d['model_npz']]=trace;payload[prefix+'/'+d['checkpoint_file']]=checkpoint
    rows.append(dict(case=folder.name,steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],status=d['status'],seconds=d['seconds'],source_unchanged=d['source_unchanged']))
    if (folder/'preflight.json').exists():payload[prefix+'/preflight.json']=(folder/'preflight.json').read_bytes()
payload['controls/dispatch_hrldas_current_kg.py']=(b/'dispatch_hrldas_current_kg.py').read_bytes()
payload['controls/dispatch_hrldas_current_kh.py']=(b/'dispatch_hrldas_current_kh.py').read_bytes()
payload['controls/'+Path(__file__).name]=Path(__file__).read_bytes()
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=manifest,case_count=3,rows=rows,jobs=observed,
    scope='ActualcurrentJN NumPy3site HRLDAS pairedcold336 job1188 and independent1008packet+officialcomparison1189afterok control/input/readiness snapshot. Alloriginalconfiguration/weather/metadata/heights/leaf/soil/BGC priors unchanged; no oldtrajectoryseed. Dynamic reports retain true17520request/running state; not independentaudit, officialaccuracy/annual/spinup/GPU/scienceacceptance. No half-written stepTAR copied; model/audit ownfuture receipts remain required.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode()
target=b/'hrldas-current-readiness-ki-evidence.tar.gz';assert not target.exists()
import io
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):
        member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
value=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),rows=rows,scope=snapshot['scope'])
(b/'hrldas-current-readiness-ki-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

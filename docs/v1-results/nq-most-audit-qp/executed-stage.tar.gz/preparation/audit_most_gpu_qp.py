"""Independent EHPC-only full-field/ledger audit of the actual QN MOST run."""
import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path
import socket
import sys
import tarfile
import time
import traceback
import types
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(path,value):
    def clean(v):
        if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)):return [clean(x) for x in v]
        if isinstance(v,float) and not math.isfinite(v):return dict(nonfinite_hex=v.hex())
        return v
    Path(path).write_text(json.dumps(clean(value),indent=2,allow_nan=False)+'\n')
def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=t.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members) and len({m.name for m in members})==len(members)
        return {m.name:t.extractfile(m).read() for m in members}


def main():
    parser=argparse.ArgumentParser()
    for n in ('source','original-source','reference','gpu','output'):parser.add_argument('--'+n,type=Path,required=True)
    a=parser.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists();a.output.mkdir()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());controls_raw=(HERE/'CONTROLS_SHA256.json').read_bytes();controls=json.loads(controls_raw)
    assert all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
    for name,key in [('source','source_archive_sha256'),('reference','QI_evidence_archive_sha256'),('gpu','QN_raw_GPU_archive_sha256')]:assert sha(getattr(a,name).read_bytes())==binding[key]
    sf=unpack(a.source.read_bytes());manifest=json.loads(sf['SOURCE_SHA256.json']);assert len(manifest)==584 and set(sf)==set(manifest)|{'SOURCE_SHA256.json'} and sha(sf['SOURCE_SHA256.json'])==binding['audit_source_manifest_sha256'] and all(sha(sf[n])==h for n,h in manifest.items())
    original_raw=a.original_source.read_bytes();assert sha(original_raw)==binding['historical_NM_archive_sha256'];nm=unpack(original_raw);nm_index=json.loads(nm['SOURCE_SHA256.json'])
    assert sha(nm['SOURCE_SHA256.json'])==binding['historical_NM_manifest_sha256'] and len(nm_index)==584 and set(nm_index)==set(manifest) and all(sha(nm[n])==h for n,h in nm_index.items())
    changed=sorted(n for n in manifest if sf[n]!=nm[n]);assert changed==binding['only_allowed_QH_changed_paths'] and len(changed)==3
    assert all(sha(sf[n])==h==sha(nm[n]) for n,h in binding['original_audit_helper_source_sha256'].items())
    source=a.output/'source'
    for n,raw in sf.items():
        p=source/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    qi=unpack(a.reference.read_bytes());index=json.loads(qi['artifact-inventory.json']);assert set(qi)==set(index)|{'artifact-inventory.json'} and all(sha(qi[n])==v['sha256'] and len(qi[n])==v['bytes'] for n,v in index.items())
    qr=json.loads(qi['actual-result/reference/receipt.json']);assert qr['pbs_job']=='1843.manager' and qr['source584_exact'] and qr['controls_exact'] and qr['physical_calls']==dict(reference_started=2,reference_returned=2,driver_started=2,driver_returned=2)
    assert json.loads(qi['actual-result/reference/reference-summary.json'])['source_manifest_sha256']==binding['QI_reference_source_manifest_sha256']
    qi_stage=unpack(qi['executed-stage.tar.gz']);qi_source=unpack(qi_stage['source.tar.gz'])
    assert sha(qi_stage['source.tar.gz'])==binding['QI_reference_source_archive_sha256'] and sha(qi_source['SOURCE_SHA256.json'])==binding['QI_reference_source_manifest_sha256']
    assert qi_source==sf,'Actual QI reference source and QH audit source must match by complete original bytes, not an assumed role name'
    gpu=unpack(a.gpu.read_bytes());capture=json.loads(gpu['most/device/capture-receipt.json']);controller=json.loads(gpu['controller/controller-receipt.json'])
    assert capture['source_manifest_sha256']==binding['QN_capture_source_manifest_sha256']==binding['audit_source_manifest_sha256'] and capture['source584_exact'] and capture['controls_exact'] and capture['reference_bundle_exact'] and capture['default_XLA_FLAGS'] is None
    assert capture['independent_QI_evidence_archive_sha256']==binding['QI_evidence_archive_sha256'] and capture['NumPy_physical_forward_calls']==0 and not capture['forbidden_CPU_attempts'] and not capture['bridge_errors']
    assert capture['reference_cache_hits']==dict(float32=1,float64=1) and len(capture['complete_actual_reference_requests'])==2
    names={'test_qia_stagnation_jax_reference_and_conservation[float32]','test_qia_stagnation_jax_reference_and_conservation[float64]','test_qia_stagnation_cuda_jax_same_precision'}
    xml=ET.fromstring(gpu['most/device/original3.xml']);xml_records=[dict(name=x.attrib['name'],children=[c.tag for c in x]) for x in xml.iter('testcase')]
    assert len(xml_records)==3 and {x['name'] for x in xml_records}==names and not any('skipped' in x['children'] for x in xml_records)
    assert sha(gpu['most/device/original3.xml'])==capture['original_XML_sha256'] and len(capture['collected_nodes'])==3 and len(capture['reports'])==9
    assert all(sum(r['nodeid']==n['nodeid'] and r['when']==phase for r in capture['reports'])==1 for n in capture['collected_nodes'] for phase in ('setup','call','teardown'))
    tags={'jax-float32-reference','jax-float64-reference','cuda-float32-parity','jax-float32-parity'}
    assert set(capture['native_original_calls'])==tags and all(x['actual_calls_started']==x['actual_calls_returned']==1 for x in capture['native_original_calls'].values())
    sys.path[:0]=[str(source/'src'),str(source/'tests'),str(source/'benchmarks')]
    import numpy as np
    import test_gpu_clm_bgc_column as original_bgc
    import test_gpu_clm_layered_column as original_layered
    from noahmp_clm import clm_enthalpy_driver as cpu_driver
    from noahmp_clm.physics import richards as cpu_richards
    forbidden=[];blocked=[]
    def no_forward(*args,**kwargs):forbidden.append('NumPy physical forward attempted');raise AssertionError(forbidden[-1])
    targets=(original_bgc.reference,original_bgc.step_clm_enthalpy_column,cpu_driver.step_clm_enthalpy_column,cpu_richards.redistribute_soil_enthalpy)
    for module in list(sys.modules.values()):
        if not isinstance(module,types.ModuleType):continue
        filename=vars(module).get('__file__')
        if not isinstance(filename,str):continue
        try:inside=Path(filename).resolve().is_relative_to(source)
        except (OSError,ValueError):continue
        if not inside:continue
        for name,value in list(vars(module).items()):
            if any(value is original for original in targets):blocked.append(dict(module=module.__name__,name=name));setattr(module,name,no_forward)
    started=time.monotonic();checks={};errors=[];ledger_calls=[];result={}
    def packet(files,stem):
        meta=json.loads(files[stem+'.json']);raw=files[stem+'.npz'];assert sha(raw)==meta['npz_sha256']
        if 'pickle_sha256' in meta:assert sha(files[stem+'.pkl'])==meta['pickle_sha256']
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:arrays={n:z[n].copy() for n in z.files}
        used=[]
        def walk(v):
            kind=v['kind']
            if kind=='array':
                q=arrays[v['key']];used.append(v['key']);assert q.dtype.str==v['dtype'] and list(q.shape)==v['shape'] and sha(q.tobytes(order='C'))==v['c_order_sha256'];return q
            if kind=='dict':return {n:walk(x) for n,x in v['items'].items()}
            if kind in ('tuple','list'):
                values=[walk(x) for x in v['items']];return tuple(values) if kind=='tuple' else values
            if kind=='dataclass':return dict(__original_dataclass__=v['module']+'.'+v['name'],fields={n:walk(x) for n,x in v['fields'].items()})
            if kind=='enum':return dict(__original_enum__=v['module']+'.'+v['name'],value=walk(v['value']))
            if kind=='float':return float.fromhex(v['hex'])
            if kind in ('NoneType','str','int','bool'):return v['value']
            raise AssertionError(kind)
        value=walk(meta['tree']);assert len(used)==len(set(used))==len(arrays)==meta['array_count'] and set(used)==set(arrays);return value,meta
    def same(x,y):return x.dtype==y.dtype and x.shape==y.shape and x.tobytes(order='C')==y.tobytes(order='C')
    def flatten(value,prefix=''):
        for key,v in value.items():
            if isinstance(v,dict):yield from flatten(v,prefix+key+'/')
            else:yield prefix+key,v
    try:
        references={};reference_inputs={}
        for dtype in ('float32','float64'):
            ref,meta=packet(qi,'actual-result/reference/'+dtype);req,input_meta=packet(qi,'actual-result/reference/'+dtype+'-input');references[dtype]=ref;reference_inputs[dtype]=req
            requests=[x for x in capture['complete_actual_reference_requests'] if x.get('served')==dtype]
            assert len(requests)==1 and requests[0]['input_tree']==input_meta['tree'] and requests[0]['matches']==[dtype]
        native={};inputs={};fieldcounts={}
        for tag in sorted(tags):
            raw_out,meta=packet(gpu,'most/device/native/'+tag);out=original_layered.host(raw_out)
            req,_=packet(gpu,'most/device/native/'+tag+'-input');dtype='float64' if '-float64-' in tag else 'float32';qi_req=reference_inputs[dtype]
            arrays=req['args'][:-1];forcing=req['args'][-1];kw=req['kwargs'];assert kw['return_surface'] is True
            assert len(arrays)==len(qi_req['args'][0]) and all(same(x[0],y) for x,y in zip(arrays,qi_req['args'][0]))
            assert same(forcing[0],qi_req['args'][1]) and same(kw['environment'][0],qi_req['args'][3]) and same(kw['calendar'][0],qi_req['args'][4])
            geometry=qi_req['kwargs']['most_geometry'];assert geometry['__original_dataclass__']=='noahmp_clm.physics.canopy_most.MOSTGeometry'
            assert list(geometry['fields'].values())==list(map(float,kw['most_geometry'][0]))
            native[tag]=out;inputs[tag]=req;fieldcounts[tag]=len(dict(flatten(out)));most=out['surface']['most']
            legality=dict(iterations=most['iterations'].tolist(),bisection_restarts=most['bisection_restarts'].tolist(),restart_dtype=most['bisection_restarts'].dtype.str,coefficient_residual=most['coefficient_residual'].tolist(),passed=bool(np.all(most['coefficient_residual']<=1e-4) and np.all(most['iterations']<=50) and most['bisection_restarts'].dtype.kind in 'iu' and np.all(most['bisection_restarts']>=0) and np.all(most['bisection_restarts']<=most['iterations'])))
            row=dict(full_return_fields=fieldcounts[tag],reference_input_array_geometry_binding_exact=True,MOST=legality)
            if tag.endswith('-reference'):
                variables={}
                for name in ('h','le','gpp_gc_m2','nee_gc_m2'):
                    actual=float(out['diagnostics'][name][0]);expected=float(references[dtype]['diagnostics'][name]);difference=abs(actual-expected);bound=max(.01 if name.endswith('gc_m2') else .05,.1*abs(expected))
                    variables[name]=dict(actual=actual,independent_QI_reference=expected,absolute_difference=difference,original_bound=bound,relative_difference=None if expected==0. else difference/abs(expected),passed=difference<=bound)
                row['original_reference_variables']=variables
            row['hard_ledger_pass']=True;row['hard_ledger_failures']={}
            for ledger_name,function,args in [('original_MH_impurity_canopy',original_layered.budgets,(arrays[:8],forcing,np.zeros((1,5),arrays[0].dtype),out)),('original_CN',original_bgc.cn_budgets,(arrays,out,np.zeros(1,arrays[0].dtype)))]:
                call=dict(tag=tag,kind=ledger_name,started=1,returned=0,exception=None);ledger_calls.append(call)
                try:row[ledger_name]=function(*args);call['returned']=1
                except Exception:
                    call['exception']=traceback.format_exc();row['hard_ledger_pass']=False;row['hard_ledger_failures'][ledger_name]=call['exception']
            eps=np.finfo(arrays[0].dtype).eps;dep=np.zeros((1,5),arrays[0].dtype)
            row['original_impurity_bound']= (64.*eps*np.maximum(arrays[0][:,:,4:].astype(float).sum(1)+dep.astype(float)*forcing[:,0].astype(float)[:,None],1e-20)).tolist()
            row['original_canopy_bounds']={}
            for name in ('canopy_interception','canopy_post_interception'):
                if name not in out:continue
                d=out[name]['ledger'];scale=abs(d['precipitation_enthalpy_jm2'])+abs(d['ground_liquid_enthalpy_jm2'])+abs(d['ground_ice_enthalpy_jm2'])+abs(arrays[7][:,:,1]).sum(1)+abs(out[name]['cells'][:,:,1]).sum(1)
                row['original_canopy_bounds'][name]=dict(strict_energy_bound=(128.*eps*np.maximum(scale,1.)).tolist(),strict_water_bound=(128.*eps*np.maximum(arrays[7][:,:,0].sum(1)+forcing[:,0]*forcing[:,7]*1000.,1.)).tolist(),actual_original_ledger={n:q.tolist() for n,q in d.items()})
            checks[tag]=row
        left=native['cuda-float32-parity'];right=native['jax-float32-parity'];lf=dict(flatten(left));rf=dict(flatten(right));assert set(lf)==set(rf)
        parity={}
        for name in sorted(lf):
            x,y=lf[name],rf[name];exact=x.dtype==y.dtype and x.shape==y.shape;integer=y.dtype.kind in 'biu'
            passed=exact and bool(np.array_equal(x,y) if integer else np.allclose(x,y,rtol=1e-6,atol=1e-6))
            parity[name]=dict(dtype_left=x.dtype.str,dtype_right=y.dtype.str,shape_left=list(x.shape),shape_right=list(y.shape),dtype_shape_exact=exact,integer_exact_rule=integer,opaque_bytes_exact=exact and x.tobytes()==y.tobytes(),maximum_absolute_difference=float(np.max(abs(x.astype(float)-y.astype(float)),initial=0.)) if x.shape==y.shape else None,passed=passed)
        try:original_helper_parity=dict(passed=True,maximum_absolute_difference=original_layered.compare_same_precision(left,right))
        except AssertionError:original_helper_parity=dict(passed=False,error=traceback.format_exc())
        assert len(ledger_calls)==8 and not forbidden
        original_pytest_pass=capture['actual_original_pytest_returncode']==0 and all(r['outcome']=='passed' and r['wasxfail'] is None for r in capture['reports']) and controller['completed'] and controller['stage_unchanged'] and [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0]
        result=dict(pbs_job=os.environ['PBS_JOBID'],audit_source_manifest_sha256=binding['audit_source_manifest_sha256'],QI_reference_source_manifest_sha256=binding['QI_reference_source_manifest_sha256'],QN_capture_source_manifest_sha256=binding['QN_capture_source_manifest_sha256'],historical_NM_manifest_sha256=binding['historical_NM_manifest_sha256'],only_three_QH_changes=changed,original_audit_helper_source_sha256=binding['original_audit_helper_source_sha256'],QI_evidence_archive_sha256=binding['QI_evidence_archive_sha256'],QN_raw_GPU_archive_sha256=binding['QN_raw_GPU_archive_sha256'],original_GPU_pytest_pass=original_pytest_pass,original_GPU_XML=xml_records,original_GPU_9reports=capture['reports'],native_calls=checks,original_pure_ledger_calls=ledger_calls,complete_parity_fields=len(parity),complete_parity=parity,original_helper_parity=original_helper_parity,original_reference_cache_exact=True,NumPy_physical_forward_calls=0,GPU_calls=0,CPU5_credit='Explicit NR1585 reuse only; original manufactured/no-root tests and all581 noncandidate files unchanged',historical_original_NQ399_of408_and9failures_retained=True)
        result['passed']=original_pytest_pass and all(v['MOST']['passed'] and v['hard_ledger_pass'] and all(x['passed'] for x in v.get('original_reference_variables',{}).values()) for v in checks.values()) and all(v['passed'] for v in parity.values()) and original_helper_parity['passed']
        save(a.output/'audit.json',result)
    except BaseException:errors.append(traceback.format_exc());(a.output/'failure.txt').write_text(errors[-1])
    finally:
        source_exact=all(sha((source/n).read_bytes())==h for n,h in manifest.items());controls_exact=all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
        save(a.output/'receipt.json',dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),source584_exact=source_exact,controls_exact=controls_exact,NumPy_physical_forward_calls=0,GPU_calls=0,forbidden_attempts=forbidden,disabled_actual_CPU_aliases=blocked,actual_original_pure_audit_calls=ledger_calls,errors=errors,seconds=time.monotonic()-started,passed=result.get('passed',False)))
        assert source_exact and controls_exact and not forbidden
    return 0 if result.get('passed') and not errors else 1


if __name__=='__main__':raise SystemExit(main())

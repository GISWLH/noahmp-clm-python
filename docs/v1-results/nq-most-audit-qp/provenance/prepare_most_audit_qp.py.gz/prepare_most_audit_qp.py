"""Freeze QP only after the actual unique QN raw archive is closed/downloaded."""
import ast
import difflib
import gzip
import io
import json
from pathlib import Path
import tarfile

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
PREP=BASE/'nq-most-audit-qp-preparation'
NEW=BASE/'nq-most-audit-qp-execution'
OLD=BASE/'nq-transport-analysis-qo-execution'


def main():
    raw_gpu=(BASE/'nq-most-cache-bridge-qn-gpu-closed/gpu-result.tar.gz').read_bytes();gpu=files(raw_gpu)
    expected=json.loads((BASE/'nq-most-cache-bridge-qn-gpu-closed/gpu-result-hash.json').read_bytes());assert sha(raw_gpu)==expected['sha256'] and len(raw_gpu)==expected['bytes']
    capture=json.loads(gpu['most/device/capture-receipt.json']);controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and len(controller['actual_parents'])==1
    assert set(capture['native_original_calls'])=={'jax-float32-reference','jax-float64-reference','cuda-float32-parity','jax-float32-parity'} and capture['reference_cache_hits']==dict(float32=1,float64=1)
    source=(BASE/'nq-reference-semantics-qh-source.tar.gz').read_bytes();nm=(BASE/'climatology-final-candidate-nm-source.tar.gz').read_bytes();qi=(BASE/'nq-most-reference-qi-evidence.tar.gz').read_bytes()
    roles=json.loads((BASE/'nq-most-audit-qp-source-role-proof.json').read_bytes())
    assert sha(source)==roles['QI_actual_source_archive_sha256']=='004fa5d926d99f076bd5f176eb6b5cc827e64b073026d4d25a27ad2e5a50a0bd' and sha(nm)==roles['historical_NM_archive_sha256'] and sha(qi)==roles['QI_bundle_sha256']
    assert capture['source_manifest_sha256']==roles['QN_capture_source_manifest_sha256'] and roles['QI_actual_summary_manifest_sha256']==roles['audit_source_manifest_sha256']
    binding=dict(source_archive_sha256=sha(source),audit_source_manifest_sha256=roles['audit_source_manifest_sha256'],
                 QI_evidence_archive_sha256=sha(qi),QI_reference_source_archive_sha256=roles['QI_actual_source_archive_sha256'],QI_reference_source_manifest_sha256=roles['QI_actual_summary_manifest_sha256'],
                 QN_raw_GPU_archive_sha256=sha(raw_gpu),QN_capture_source_manifest_sha256=capture['source_manifest_sha256'],QN_executed_stage_sha256='1d814fa98e9897922db9777f2ba98674c9fd4069c1daa4cad014fb47db2d3879',
                 historical_NM_archive_sha256=sha(nm),historical_NM_manifest_sha256=roles['historical_NM_manifest_sha256'],only_allowed_QH_changed_paths=roles['only_allowed_QH_changed_paths'],original_audit_helper_source_sha256=roles['original_audit_helper_source_sha256'],
                 actual_QN_original_pytest_returncode=capture['actual_original_pytest_returncode'],source_files=584,unchanged_to_NM=581,original_native_packets=4,planned_original_pure_audit_calls=8,planned_original_helper_parity_calls=1,
                 planned_NumPy_column_or_reference_or_phase_forward_calls=0,GPU_calls=0,resources='EHPC compute002/1CPU/2GiB/5min',root_pre_execution_review_pending=True)
    PREP.mkdir(exist_ok=False);NEW.mkdir(exist_ok=False)
    for name,origin in [('audit_most_gpu_qp.py','audit_most_gpu_qp.py'),('SOURCE_ROLE_PROOF.json','nq-most-audit-qp-source-role-proof.json'),('SOURCE_AND_LEDGER.diff','nq-most-audit-qp-source-ledger.diff'),('CPU5_REUSE_PROOF.json','nq-reference-semantics-qh-cpu-reuse.json')]:
        raw=(BASE/origin).read_bytes()
        if name.endswith('.py'):ast.parse(raw);assert b'\r' not in raw
        (PREP/name).write_bytes(raw)
    (PREP/'BINDINGS.json').write_bytes(encode(binding))
    (PREP/'README.md').write_text('''# QP independent EHPC audit of actual QN MOST capture — review only

Input roles are explicit and backed by the sealed actual QI source archive: QI1843 reference, QN capture and this audit all use the same private QH584 bytes/manifest da0c59b3…. Original historical NM a39f4877… is a distinct input for provenance only. Recheck all584 files in both sources; exactly the two root-reviewed QG Richards fixtures and the GPU restart semantic test may differ, all581 others and five separately pinned original audit/helper/CPU-test/precip files must be exact. QI reference data are not mislabeled as NM. No source/fixture/test or original physical/parity/ledger gate is altered.

Bind the actual unique QN raw GPU archive and its complete typed four requests/returns, two strict original cache requests, original3node9report/XML coverage and actual original pytest/controller/parent statuses. Re-read all typed NPZ arrays on EHPC, validate dtype/shape/C-byte hashes and decode scalar hex without unpickling or running a model. Independently bind each native initial row/forcing/environment/calendar/geometry to the exact saved QI request; unknown/missing reference data have no fallback.

For both reference nodes report actual H/LE/GPP/NEE, independent QI values, actual absolute/relative difference and original max(absolute floor,10% reference) bounds. Check original coefficient/iteration and integer restart legality, preserving actual0 legal restarts. Original CPU manufactured stagnation/no-root5node source is unchanged and only NR1585 results are explicitly reused, never called a new CPU run.

Apply the unchanged original host conversion and original complete CUDA32/JAX32 compare_same_precision function once, plus report every returned leaf's dtype, shape, exact integer rule and original rtol=atol1e-6 numeric difference. For each of the four native returns independently invoke original layered M/H/impurity/canopy budget and original C/N budget, eight pure audit calls total. Each class has independent started/returned/exception capture so an M/H assertion failure cannot skip C/N or be hidden by a count check. Report actual original residuals and bounds, impurity bound and complete component canopy ledgers/strict bounds. All real imported NumPy column/reference/redistribution definitions and already-imported aliases are forbidden. Original light GPU-host assertions alone supply no independent credit.

This is a single PBS compute0021CPU/2GiB/5min posthoc job,0 column/reference/phase/GPU forward calls. Actual GPU failures and original NQ399/408 with9failed records remain preserved. The complete independent audit must deliver actual F/Stageout and all raw numerical results before any combined3node credit. Stage is prepared only; root must read amended worker/source-role/diff/binding and authorize unique submission. No deployment or numerical execution occurs here.
''',encoding='utf-8',newline='\n')
    controls={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir())};(PREP/'CONTROLS_SHA256.json').write_bytes(encode(controls))
    differences=[]
    for old,new in [('check_stage_qo.py','check_stage_qp.py'),('dispatch_transport_analysis_qo.py','dispatch_most_audit_qp.py'),('analysis_qo.pbs','audit_qp.pbs')]:
        before=(OLD/old).read_text();after=before.replace('transport-analysis-qo','most-audit-qp').replace('check_stage_qo','check_stage_qp').replace('dispatch_transport_analysis_qo','dispatch_most_audit_qp').replace('analysis_qo.pbs','audit_qp.pbs').replace('qo-result','qp-result')
        if old.endswith('.pbs'):
            command='"$py" -B "$stage/preparation/analyze_transport_trace_qo.py" --evidence "$stage/qj-evidence.tar.gz" --output "$root/analysis"'
            assert command in after
            after=after.replace(command,'"$py" -B "$stage/preparation/audit_most_gpu_qp.py" --source "$stage/source.tar.gz" --original-source "$stage/original-source-NM.tar.gz" --reference "$stage/reference-QI-evidence.tar.gz" --gpu "$stage/gpu-QN-raw.tar.gz" --output "$root/audit"')
            after=after.replace("--exclude='./analysis/source'","--exclude='./audit/source'")
            assert after.startswith('#!/bin/bash\n') and '\r' not in after
        else:
            after=after.replace('original_audit_calls=2','original_audit_calls=8');ast.parse(after)
        (NEW/new).write_text(after,encoding='utf-8',newline='\n');differences.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='QO/'+old,tofile='QP/'+new))
    (NEW/'QO_TO_QP.diff').write_text(''.join(differences),encoding='utf-8',newline='\n')
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),QN_raw_GPU_archive_sha256=sha(raw_gpu),resources='1CPU/2GiB/5min/compute002',planned_original_pure_audit_calls=8,planned_reference_calls=0,physical_forward_calls=0,GPU_calls=0,root_authorization_pending=True,single_submission=True,automatic_retry=False)))
    (NEW/'README.md').write_text('QO/QI/PW original manager/compute002 immutable stage/hash/PBS lifecycle on fresh QP paths,1CPU/2GiB/5min. Stage-after failures propagate; actual original audit status is not normalized. Four native packets independently audited,8 original pure ledger calls+1 original parity function,0 physical/reference/phase/GPU forwards. Review only; no submit.\n',encoding='utf-8',newline='\n')
    execution={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir())};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(execution))
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()})
    items.update({'source.tar.gz':source,'original-source-NM.tar.gz':nm,'reference-QI-evidence.tar.gz':qi,'gpu-QN-raw.tar.gz':raw_gpu});items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/'nq-most-audit-qp-stage.tar.gz';assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(passed=True,stage_sha256=sha(target.read_bytes()),stage_files=len(items),preparation_controls=len(controls),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(execution),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),actual_QN_raw_bound=True,explicit_QI_QN_audit_source_roles=True,source581_unchanged_to_NM=True,original_pure_ledger_calls=8,physical_forward_calls=0,GPU_calls=0,root_review_pending=True,submitted=False,numerical_executed=False)
    (BASE/'nq-most-audit-qp-stage-package.json').write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

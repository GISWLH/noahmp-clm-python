"""Deploy only root-reviewed exact PW; save actual command outcomes."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
LOG = BASE / 'nq-most-audit-qp-deployment'
STAGE = BASE / 'nq-most-audit-qp-stage.tar.gz'
DISPATCH = BASE / 'nq-most-audit-qp-execution/dispatch_most_audit_qp.py'
EXPECTED = 'e9af246715fd1c6a178d68cd17fa0ea529ed9e7af7e554bb634b1f2067b2a6a5'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def run(label, command):
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=90)
    (LOG / (label + '.stdout')).write_bytes(result.stdout)
    (LOG / (label + '.stderr')).write_bytes(result.stderr)
    (LOG / (label + '.json')).write_text(json.dumps(dict(command=command, actual_exit=result.returncode,
        seconds=time.monotonic()-started, stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr)), indent=2) + '\n')
    assert result.returncode == 0, (label, result.stderr.decode(errors='replace'))
    return result.stdout


def main():
    assert sha(STAGE.read_bytes()) == EXPECTED and not LOG.exists()
    LOG.mkdir()
    run('preflight-root', ['ssh', 'ehpc', 'test ! -e /tmp/noahmp-most-audit-qp'])
    run('preflight-stage', ['ssh', 'ehpc', 'test ! -e /tmp/noahmp-most-audit-qp-stage.tar.gz'])
    run('preflight-dispatch', ['ssh', 'ehpc', 'test ! -e /tmp/dispatch_most_audit_qp.py'])
    run('upload-stage', ['scp', '-O', str(STAGE), 'ehpc:/tmp/noahmp-most-audit-qp-stage.tar.gz'])
    run('upload-dispatch', ['scp', '-O', str(DISPATCH), 'ehpc:/tmp/dispatch_most_audit_qp.py'])
    hashes = run('uploaded-hashes', ['ssh', 'ehpc', 'sha256sum /tmp/noahmp-most-audit-qp-stage.tar.gz /tmp/dispatch_most_audit_qp.py'])
    assert {line.split()[1]: line.split()[0] for line in hashes.decode().splitlines()} == {
        '/tmp/noahmp-most-audit-qp-stage.tar.gz': EXPECTED,
        '/tmp/dispatch_most_audit_qp.py': sha(DISPATCH.read_bytes())}
    output = run('dispatch', ['ssh', 'ehpc', '/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_most_audit_qp.py --archive /tmp/noahmp-most-audit-qp-stage.tar.gz --sha256 ' + EXPECTED])
    record = json.loads(output)
    assert record['stage_sha256'] == EXPECTED
    print(json.dumps(dict(pbs_job=record['pbs_job'], stage_sha256=EXPECTED, actual_dispatch_exit=0)))


if __name__ == '__main__':
    main()

"""Actual read-only scheduler/compute inventory for the unique authorized QO."""
import json
from pathlib import Path
import subprocess
import time

BASE=Path(__file__).resolve().parent
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -B -f'],['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','hostname']]
record=dict(read_only=True,commands=[])
for i,command in enumerate(commands):
    started=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=60)
    for ext,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
        (BASE/('nq-most-audit-qp-pbs-preflight-'+str(i)+'.'+ext)).write_bytes(raw)
    record['commands'].append(dict(actual_exit=r.returncode,seconds=time.monotonic()-started,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace')))
(BASE/'nq-most-audit-qp-pbs-preflight.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert all(x['actual_exit']==0 for x in record['commands'])
assert 'server_state = Active' in record['commands'][0]['stdout'] and 'scheduling = True' in record['commands'][0]['stdout']
assert record['commands'][1]['stdout'].strip()=='compute002'
print(json.dumps(record))

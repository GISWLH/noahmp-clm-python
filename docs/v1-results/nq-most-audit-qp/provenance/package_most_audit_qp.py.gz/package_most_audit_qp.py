"""Seal actual QP1859 independent audit without any numerical rerun."""
import base64
import gzip
import io
import json
from pathlib import Path
import re
import tarfile

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
LABEL='nq-most-audit-qp'


def main():
    raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes();stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    assert sha(raw)=='20e00e85ead14110e4acf7fd0ed05c8b7e0f80df67bd74aea42cba0aaf57abcf' and sha(stage_raw)=='e9af246715fd1c6a178d68cd17fa0ea529ed9e7af7e554bb634b1f2067b2a6a5'
    actual=files(raw,directories=True);stage=files(stage_raw);index=json.loads(stage['stage-inventory.json'])
    assert set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items()) and actual['stage-inventory.json']==stage['stage-inventory.json']
    for name in ('stage-before.json','stage-after.json'):
        check=json.loads(actual[name]);assert check['passed'] and check['actual']==check['expected']==index and not check['mismatches']
    assert all(actual[n].strip()==b'0' for n in ('worker-exit.txt','pbs-command-exit.txt','setup-exit.txt','stage-after-exit.txt'))
    receipt=json.loads(actual['audit/receipt.json']);audit=json.loads(actual['audit/audit.json']);binding=json.loads(stage['preparation/BINDINGS.json'])
    assert receipt['pbs_job']=='1859.manager' and receipt['passed'] and receipt['source584_exact'] and receipt['controls_exact'] and not receipt['errors'] and not receipt['forbidden_attempts'] and receipt['NumPy_physical_forward_calls']==receipt['GPU_calls']==0
    assert len(receipt['actual_original_pure_audit_calls'])==8 and all(c['started']==c['returned']==1 and c['exception'] is None for c in receipt['actual_original_pure_audit_calls'])
    assert audit['passed'] and audit['original_GPU_pytest_pass'] and audit['original_reference_cache_exact'] and audit['complete_parity_fields']==313 and len(audit['complete_parity'])==313
    assert all(v['passed'] and v['dtype_shape_exact'] and v['opaque_bytes_exact'] for v in audit['complete_parity'].values())
    assert audit['original_helper_parity']==dict(passed=True,maximum_absolute_difference=0.)
    assert audit['audit_source_manifest_sha256']==audit['QI_reference_source_manifest_sha256']==audit['QN_capture_source_manifest_sha256']=='da0c59b35d095df102db32eaebb956c97b02bf02c1553a901d911a0ebd652f80'
    assert audit['historical_NM_manifest_sha256']=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert audit['QN_raw_GPU_archive_sha256']==sha(stage['gpu-QN-raw.tar.gz'])=='78aad10274a38f6ceddea53c0fc2b9bbd9fc7e92ddb9b6028c022baabba3410f'
    assert audit['only_three_QH_changes']==binding['only_allowed_QH_changed_paths'] and audit['original_audit_helper_source_sha256']==binding['original_audit_helper_source_sha256']
    assert len(audit['native_calls'])==4 and all(v['hard_ledger_pass'] and not v['hard_ledger_failures'] and v['MOST']['passed'] and all(x['passed'] for x in v.get('original_reference_variables',{}).values()) for v in audit['native_calls'].values())
    closure=BASE/(LABEL+'-closure');qstat=(closure/'poll-1.stdout').read_text()
    assert 'Job Id: 1859.manager' in qstat and re.search(r'job_state = F\b',qstat) and 'Exit_status = 0' in qstat and 'Stageout_status = 0' in qstat and 'run_count = 1' in qstat
    items={'actual-result/'+n:b for n,b in actual.items()}
    for host in ('manager','compute'):
        metadata=json.loads((closure/(host+'.stdout')).read_bytes());assert metadata['all_stage_immutable'] and metadata['stage_files_before']==metadata['stage_files_after']==index
        assert json.loads((closure/(host+'.json')).read_bytes())['actual_exit']==0
        if host=='compute':assert metadata['result_archive_sha256']==sha(raw) and base64.b64decode(metadata['files']['pbs-exit.txt']).strip()==b'0'
        for name,b in metadata['files'].items():items['closed-'+host+'/'+name]=base64.b64decode(b)
    readout=dict(pbs_job='1859.manager',job_state='F',PBS_exit=0,Stageout_status=0,run_count=1,worker_seconds=receipt['seconds'],actual_original_pure_ledger_calls=receipt['actual_original_pure_audit_calls'],original_helper_parity=audit['original_helper_parity'],complete_parity_fields=313,all313_dtype_shape_integer_1e6_pass=True,all313_same_backend_parity_bytes_exact=True,
                 independent_reference_and_hard_ledger_results=audit['native_calls'],source_roles={n:audit[n] for n in ('audit_source_manifest_sha256','QI_reference_source_manifest_sha256','QN_capture_source_manifest_sha256','historical_NM_manifest_sha256')},
                 source_files=584,unchanged_to_historical_NM=581,only_three_QH_changes=audit['only_three_QH_changes'],original_audit_helper_source_sha256=audit['original_audit_helper_source_sha256'],QI_evidence_archive_sha256=audit['QI_evidence_archive_sha256'],QN_raw_GPU_archive_sha256=audit['QN_raw_GPU_archive_sha256'],original_GPU_pytest_nodes=3,original_GPU_reports=9,original_GPU_pytest_pass=True,NumPy_physical_forward_calls=0,GPU_calls=0,
                 combined_credit='Actual privateQH original3node GPU run plus independent EHPC complete313field/M/H/impurity/canopy/C/N audit pass; no new global408node or scientific/yearly acceptance count',CPU5_credit=audit['CPU5_credit'],historical_original_NQ399_of408_and9failures_retained=True,Richards_original1J_failure_retained=True,source_or_fixtures_or_tests_modified=False,passed=True)
    verification=dict(passed=True,scope='Stdlib sealed archive/hash/status and already-computed EHPC JSON only; no numerical rerun or unpickle',actual_job='1859.manager',actual_PBS_exit=0,actual_Stageout_status=0,actual_worker_exit=0,result_sha256=sha(raw),stage_sha256=sha(stage_raw),actual_result_files=len(actual),original_pure_ledger_calls=8,complete_parity_fields=313,source_roles_closed=True,physical_forward_calls=0,GPU_calls=0)
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    items.update({'readout.json':encode(readout),'verification.json':encode(verification),'original-result.tar.gz':raw,'executed-stage.tar.gz':stage_raw})
    for directory in (closure,BASE/(LABEL+'-deployment')):
        for path in sorted(directory.rglob('*')):
            if path.is_file():items['observations/'+directory.name+'/'+path.relative_to(directory).as_posix()]=path.read_bytes()
    for name in ('audit_most_gpu_qp.py','audit_most_gpu_qp-before-explicit-source-ledger.py','prepare_most_audit_qp.py','check_most_audit_qp_pbs_readonly.py','deploy_most_audit_qp.py','read_most_audit_qp_closed.py','collect_most_audit_qp_closed.py','package_most_audit_qp.py',LABEL+'-source-role-proof.json',LABEL+'-source-ledger.diff',LABEL+'-pbs-preflight.json',LABEL+'-stage-package.json'):
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['SCOPE.md']=b'''# Actual independent QP1859 MOST audit

Actual F0/Stageout0, run1, worker0. Four saved original QN native returns audited independently on EHPC with no column/reference/phase/GPU forwards. Both exact independentQI request/source roles close to actualQH bytes, with581historicalNM files exact and only the previously reviewed3candidate paths changed. All five original audit/helper/CPU-test/precipitation files have separate matching hashes.

Actual original3node GPU coverage,9reports/XML/parent0, two strict exact cache requests and four original native calls are retained. All313complete CUDA/JAX float32 fields pass unchanged1e-6/int/dtype/shape rules, all byte exact, original helper maximum0.0. Two reference nodes retain every actual H/LE/GPP/NEE value, difference and original absolute/10percent bound. All four returns have original M/H/impurity/canopy andC/N pure budgets independently executed,8started/8returned with no exceptions, plus explicit original component/impurity bounds and integer restart legality.0restart is legitimate; originalCPU manufactured restart tests remain unchanged with explicitNR1585 historical5node reuse only.

This supplies independent credit for this privateQH complete3node MOST run. It does not create a new global408node aggregate count or erase originalNQ399/408/9failures, failed years or Richards1J. Production checkout/source/fixtures/tests were not modified or promoted; no model repair/release/scientific-yearly acceptance is inferred. Complete raw actual outputs, complete EHPC numericalJSON, all original datasets/source archives and actual status/closure records remain sealed. Packaging used only stdlib metadata/hash/JSON and did not rerun calculations.
'''
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(label=LABEL,archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Actual QP1859 F0/Stageout0 independent privateQH MOST3node audit: all313parity fields exact,8original hard pure audits pass,2reference bounds pass,0forward/GPU. Original global NQ9failures/Richards1J/year failures retained.',verification=verification)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

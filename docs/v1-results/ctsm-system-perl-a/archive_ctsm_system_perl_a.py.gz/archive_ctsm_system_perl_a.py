from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-system-perl-xml-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'availability.json').read_text());assert r['pbs_job']=='114.manager' and not r['xml_available'] and [v['returncode'] for v in r['results']]==[0,2,2]
names=['check_system_perl_xml_a.py','ctsm_system_perl_xml_a.pbs','availability.json','availability.log','pbs-exit.txt'];dest=base/'ctsm-system-perl-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for n in names:t.add(root/n,arcname=n,recursive=False)
    t.add(Path(__file__),arcname='archive_ctsm_system_perl_a.py',recursive=False)
print(json.dumps(dict(files=len(names)+1,sha256=sha(dest),scope='EHPC PBS114 confirms existing system Perl works but XML::LibXML/Reader are absent. Probe completion is not a dependency/module pass or model/science acceptance.')))

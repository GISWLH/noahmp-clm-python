from pathlib import Path
import json,os,subprocess,time
assert os.environ.get('PBS_JOBID');root=Path('/home/zhangyq/noahmp-v1/ctsm-system-perl-xml-a');rows=[];start=time.monotonic()
for program in ["print $^V,qq(\\n)","use XML::LibXML; print $XML::LibXML::VERSION,qq(\\n)","use XML::LibXML::Reader; print qq(XML reader available\\n)"]:
    r=subprocess.run(['/usr/bin/perl','-e',program],capture_output=True,text=True,timeout=10)
    rows.append(dict(command=['/usr/bin/perl','-e',program],returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
value=dict(scope='System Perl/XML module availability only, not physical/model tests or official output.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,results=rows,xml_available=all(r['returncode']==0 for r in rows),seconds=time.monotonic()-start)
(root/'availability.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

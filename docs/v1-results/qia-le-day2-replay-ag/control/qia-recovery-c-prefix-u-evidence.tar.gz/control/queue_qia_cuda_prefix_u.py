from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-cuda-prefix-queue-u';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();controls={n:sha(b/n) for n in ['launch_qia_cuda_prefix_u.py','control_qia_cuda_prefix_u.py','run_qia_cuda_prefix_u.py']}
if os.environ.get('QIA_PREFIX_QUEUE_U_CHILD')!='1':
    assert not r.exists();r.mkdir()
    (r/'control.py').write_bytes(Path(__file__).read_bytes());env=os.environ.copy();env['QIA_PREFIX_QUEUE_U_CHILD']='1'
    with (r/'queue.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'control.py')],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,controls_sha256=controls,scope='Light queue only; first two launchattempts hit32GiB hostguard before any modeldir/worker. Preserveguard, launch prospective currentC two cold48 validation prefixes only when8GiBGPU/32GiBhost available. No result/year/science pass.')
    (r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));raise SystemExit(0)
launched={};start=time.monotonic();last=-100.
while len(launched)<2:
    assert all(sha(b/n)==h for n,h in controls.items())
    memory=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')));free={}
    for label,device in [('capacity','0'),('capacity_optics','1')]:
        if label in launched:continue
        target=b/('qia-richards-'+label+'-cuda-year-c');assert not target.exists(),str(target)
        free[device]=int(subprocess.check_output(['nvidia-smi','--id='+device,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
        if memory<=32*1024*1024 or free[device]<=8192:continue
        command=[sys.executable,str(b/'launch_qia_cuda_prefix_u.py'),label,device];p=subprocess.run(command,capture_output=True,text=True)
        (r/(label+'-launch-attempt.json')).write_text(json.dumps(dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2)+'\n');assert p.returncode==0,p.stderr
        launched[label]=json.loads((target/'prefix-launch.json').read_text());os.kill(launched[label]['pid'],0)
        memory=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
    if time.monotonic()-last>=60.:
        row=dict(elapsed_seconds=time.monotonic()-start,host_available_kib=memory,gpu_free_mib=free,launched_cases=sorted(launched),scope='Queue/resource telemetry only, not physicalstep or annual pass');(r/'waiting.json').write_text(json.dumps(row,indent=2)+'\n')
        with (r/'waiting-events.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        last=time.monotonic()
    if len(launched)<2:time.sleep(20.)
(r/'exit.json').write_text(json.dumps(dict(returncode=0,launched_cases=launched,scope='Both prefixmodel controllers actually launched. Results remain separate; not prefix/year/science completion.'),indent=2)+'\n')

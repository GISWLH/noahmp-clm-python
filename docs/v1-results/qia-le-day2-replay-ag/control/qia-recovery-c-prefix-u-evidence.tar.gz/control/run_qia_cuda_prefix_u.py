from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-numerical-recovery-c';r=b/('qia-richards-'+label+'-cuda-year-c');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as numpy_runner
import noahmp_clm.clm_enthalpy_driver as numpy_driver
import noahmp_clm.physics.richards as numpy_flow
import cupy as cp
protocol=json.loads((r/'inputs/protocol.json').read_text());case=next(x for x in protocol['cases'] if x['case']==label);assert protocol['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json');count=case['native_state_arrays'];assert count==23 and case['cold_fields']==30
q=r/'inputs'/label;assert sha(q/'cold-reference.npz')==case['cold_sha256'] and sha(q/'batch.json')==case['batch_sha256'] and sha(q/'config.json')==case['configuration_sha256']
steps=r/'prefix-steps';steps.mkdir();captured=0;cold_checked=False;original_step=native.Backend.step;original_audit=native.audit_step;forbidden_originals=[numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy]
def no_cpu_forward(*a,**kw):raise AssertionError('GPU climate integration cannot call NumPy forward physics')
def check_cold(self,*args,**kwargs):
    global cold_checked
    if not cold_checked:
        report=json.loads((r/'trajectory/batch.json').read_text());assert report['status']=='running' and report['steps_completed']==0 and report['steps_requested']==17520 and report['identity']['native_state_arrays']==23 and not report['identity']['compare_jax32']
        p=r/'trajectory'/report['checkpoint_file'];assert sha(p)==report['checkpoint_sha256']
        with np.load(p,allow_pickle=False) as a,np.load(q/'cold-reference.npz',allow_pickle=False) as ref:
            assert set(a.files)==set(ref.files) and len(a.files)==30
            for key in a.files:assert a[key].dtype==ref[key].dtype and a[key].shape==ref[key].shape and a[key].tobytes()==ref[key].tobytes(),key
        native.atomic_json(r/'cold-audit.json',dict(scope='Before first modeltendency, all23primary plus7ledger fields byteexact to independent EHPC356 currentC coldpack. Both forcing/config/source identities fixed; no previous trajectory reused.',cold_fields_exact=30,cold_checkpoint_sha256=sha(p),cpu_reference_sha256=case['cold_sha256'],source_manifest_sha256=sha(s/'SOURCE_SHA256.json')));cold_checked=True
    return original_step(self,*args,**kwargs)
def observe(before,after,forcing,deposition,nitrogen,out):
    global captured
    checked=original_audit(before,after,forcing,deposition,nitrogen,out);values=dict(forcing=np.asarray(forcing),deposition=np.asarray(deposition),nitrogen=np.asarray(nitrogen))
    for prefix,arrays in [('before',before),('after',after)]:
        assert len(arrays)==23
        values.update({prefix+str(k):np.asarray(v) for k,v in enumerate(arrays)})
    def flatten(x,prefix='output/'):
        for k,v in x.items():
            if isinstance(v,dict):flatten(v,prefix+k+'/')
            else:values[prefix+k]=np.asarray(v)
    flatten(out)
    for name,v in zip(['incoming','residual','bound','impurity'],checked):values['recorded/'+name]=np.asarray(v)
    np.savez_compressed(steps/('call-'+str(captured).zfill(5)+'.npz'),**values);captured+=1
    return checked
start=time.monotonic();failure=None;report={}
try:
    native.Backend.step=check_cold;native.audit_step=observe;numpy_runner.step_clm_enthalpy_column=no_cpu_forward;numpy_driver.step_clm_enthalpy_column=no_cpu_forward;numpy_flow.redistribute_soil_enthalpy=no_cpu_forward
    native.run(q/'batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,stop_after=48)
    report,state,rows=native.read_generation(r/'trajectory');assert cold_checked and captured==48 and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['source_unchanged'] and len(state)==30
    native.atomic_json(r/'prefix-report.json',report)
except Exception as error:
    failure=type(error).__name__+': '+str(error);(r/'prefix-traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    native.Backend.step=original_step;native.audit_step=original_audit;numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy=forbidden_originals
cp.cuda.runtime.deviceSynchronize();path=r/'trajectory/batch.json';report=json.loads(path.read_text()) if path.exists() else {};unchanged=all(sha(s/n)==h for n,h in m.items())
d=dict(scope='Current563C realstation capacity/optics originalcold first48 of prospectively fixed17520. Independent EHPC356 cold check before first tendency and NumPyforward forbidden; only host check/capture wrappers, production GPU/math/source unmodified. All23before/after and fulloutputs saved for independent EHPC perstep/cumulative/reference audit. Prefix only, no JAXshadow/sameprecision/year/fullcanonical/science claim. Atexit bypass after explicit CuPybarrier/durable receipt.',case=label,failure=failure,cold_fields_exact=30 if cold_checked else None,captured_step_calls=captured,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barrier_complete=True,report_sha256=sha(path) if path.exists() else None,seconds=time.monotonic()-start)
native.atomic_json(r/'prefix-receipt.json',d);print(json.dumps(d),flush=True);os._exit(0 if failure is None and unchanged else 1)

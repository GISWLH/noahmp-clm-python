from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'qia-recovery-c-prefix-u-evidence.tar.gz';assert not a.exists()
for label in ['capacity','capacity_optics']:
    r=b/('qia-richards-'+label+'-cuda-year-c');d=json.loads((r/'prefix-receipt.json').read_text());e=json.loads((r/'prefix-exit.json').read_text());assert e['returncode']==0 and e['passed'] and e['receipt_sha256']==sha(r/'prefix-receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['cold_fields_exact']==30 and d['captured_step_calls']==48 and d['steps_completed']==48 and d['steps_requested']==17520 and d['status']=='running' and sha(r/'trajectory/batch.json')==d['report_sha256'] and len(list((r/'prefix-steps').glob('call-*.npz')))==48
with tarfile.open(a,'w:gz') as tf:
    for label in ['capacity','capacity_optics']:
        r=b/('qia-richards-'+label+'-cuda-year-c')
        for p in sorted(r.rglob('*')):
            if p.is_file():tf.add(p,arcname=label+'/'+p.relative_to(r).as_posix(),recursive=False)
    r=b/'qia-cuda-prefix-queue-u'
    for p in sorted(r.iterdir()):
        if p.is_file():tf.add(p,arcname='queue/'+p.name,recursive=False)
    for n in ['clm-numerical-recovery-c-source.tar.gz','clm-numerical-recovery-c-package.json','run_qia_cuda_prefix_u.py','control_qia_cuda_prefix_u.py','launch_qia_cuda_prefix_u.py','queue_qia_cuda_prefix_u.py',Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

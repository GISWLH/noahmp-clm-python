from pathlib import Path
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');r=b/('qia-le-'+label+'-replay-ag');s=b/'clm-numerical-recovery-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as numpy_runner
import noahmp_clm.clm_enthalpy_driver as numpy_driver
import noahmp_clm.physics.richards as numpy_flow
import cupy as cp
binding=json.loads((r/'endpoint-binding.json').read_text());e=r/'expected';assert all(sha(e/n)==h for n,h in binding['files_sha256'].items()) and binding['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
a=b/'qia-recovery-c-prefix-u-evidence.tar.gz';assert sha(a)=='8cee7134ee4ad9f51c1c8de03d9f601389df98b39b43ad09a424f061cac8f313';seed=r/'seed';seed.mkdir()
with tarfile.open(a) as tf:tf.extractall(seed,members=[p for p in tf.getmembers() if p.name.startswith(label+'/')],filter='data')
p=seed/label;report,saved,rows=native.read_generation(p/'trajectory');assert report['steps_completed']==48 and report['steps_requested']==17520 and report['status']=='running' and sha(p/'trajectory/batch.json')==sha(e/'certified-prefix-report.json') and report['checkpoint_sha256']==sha(e/'certified-prefix-state.npz')
original_step=native.Backend.step;original_audit=native.audit_step;original_forbidden=[numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy];counter=0;checked=False;failure=None;start=time.monotonic();(r/'captured-steps').mkdir()
def forbidden(*a,**kw):raise AssertionError('Native diagnostic cannot use NumPy forward physics')
def checked_step(self,*a,**kw):
    global checked
    if not checked:
        current,carried,unused=native.read_generation(p/'trajectory');assert current['steps_completed']==48 and set(carried)==set(saved) and len(carried)==30
        for key in saved:assert carried[key].dtype==saved[key].dtype and carried[key].shape==saved[key].shape and carried[key].tobytes()==saved[key].tobytes(),key
        checked=True
    return original_step(self,*a,**kw)
def capture(before,after,f,dep,nitrogen,out):
    global counter
    result=original_audit(before,after,f,dep,nitrogen,out);values=dict(forcing=np.asarray(f),deposition=np.asarray(dep),nitrogen=np.asarray(nitrogen))
    for name,arrays in [('before',before),('after',after)]:values.update({name+str(k):np.asarray(v) for k,v in enumerate(arrays)})
    def flat(d,prefix='output/'):
        for key,value in d.items():
            if isinstance(value,dict):flat(value,prefix+key+'/')
            else:values[prefix+key]=np.asarray(value)
    flat(out)
    for name,value in zip(['incoming','residual','bound','impurity'],result):values['recorded/'+name]=np.asarray(value)
    np.savez_compressed(r/'captured-steps'/('call-'+str(counter).zfill(5)+'.npz'),**values);counter+=1;return result
try:
    native.Backend.step=checked_step;native.audit_step=capture;numpy_runner.step_clm_enthalpy_column=forbidden;numpy_driver.step_clm_enthalpy_column=forbidden;numpy_flow.redistribute_soil_enthalpy=forbidden
    native.run(p/'inputs'/label/'batch.json',p/'trajectory',backend='cuda32',compare_jax32=False,resume=True,stop_after=48)
    report,final,rows=native.read_generation(p/'trajectory');assert checked and counter==48 and report['status']=='running' and report['steps_completed']==96 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None
    with np.load(e/'endpoint-state.npz',allow_pickle=False) as z:expected=dict(z)
    assert len(final)==len(expected)==30 and set(final)==set(expected)
    for key in final:assert final[key].dtype==expected[key].dtype and final[key].shape==expected[key].shape and final[key].tobytes()==expected[key].tobytes(),key
    with np.load(e/'endpoint-trace.npz',allow_pickle=False) as z:trace=dict(z)
    assert len(rows)==1 and set(rows[0][1])==set(trace)
    for key,value in rows[0][1].items():assert value.dtype==trace[key].dtype and value.shape==trace[key].shape and value.tobytes()==trace[key].tobytes(),key
except Exception as error:
    failure=type(error).__name__+': '+str(error);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    native.Backend.step=original_step;native.audit_step=original_audit;numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy=original_forbidden
cp.cuda.runtime.deviceSynchronize();unchanged=all(sha(s/n)==h for n,h in m.items());record=dict(case=label,failure=failure,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),starting_fields_exact=30 if checked else None,captured_calls=counter,ending_fields_exact=30 if failure is None else None,full_original96trace_exact=failure is None,device_barrier_complete=True,seconds=time.monotonic()-start,endpoint_binding_sha256=sha(r/'endpoint-binding.json'),scope='Observation-only current563C privateCUDA exactreplay fixedday2 from ownsuccessful48 through actually committed originalyear96, same originalinput/config/source/guards and all30ledger/state. Originalyears untouched, no NumPyforward/JAXshadow, no year/science acceptance. Atexit bypass after explicitCuPybarrier and durable receipt.')
native.atomic_json(r/'receipt.json',record);print(json.dumps(record),flush=True);os._exit(0 if failure is None and unchanged else 1)

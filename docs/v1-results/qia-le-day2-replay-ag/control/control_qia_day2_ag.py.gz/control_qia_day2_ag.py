from pathlib import Path
import hashlib,json,subprocess,sys,time
label=sys.argv[1];b=Path('/home/lhwang/work/noahmp-v1');r=b/('qia-le-'+label+'-replay-ag');start=time.monotonic();cmd=[sys.executable,'-u',str(b/'run_qia_day2_ag.py'),label]
with (r/'model.log').open('x') as log:p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=cmd),indent=2)+'\n');code=p.wait();path=r/'receipt.json';d=json.loads(path.read_text()) if path.exists() else {};passed=bool(code==0 and d and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['starting_fields_exact']==d['ending_fields_exact']==30 and d['captured_calls']==48 and d['full_original96trace_exact']);record=dict(returncode=code if code else (0 if passed else 1),passed=passed,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest() if d else None,scope='Actual diagnostic replay parent terminal only; not originalannual or science acceptance.')
(r/'exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['returncode'])

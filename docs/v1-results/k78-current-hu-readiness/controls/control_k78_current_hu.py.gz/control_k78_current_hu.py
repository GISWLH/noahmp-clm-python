from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'k78-current-hu'
start = time.monotonic()
rows = []
for name in ['cuda32', 'jax32']:
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and memory>32*1024*1024:break
        time.sleep(20.)
    with (r / (name + '.log')).open('x') as log:
        p = subprocess.Popen([sys.executable, '-u', str(b / 'replay_k78_current_backend_hu.py'), name], stdout=log, stderr=subprocess.STDOUT)
    (r / (name + '-worker.json')).write_text(json.dumps(dict(pid=p.pid)) + '\n')
    code = p.wait()
    receipt = r / name / 'receipt.json'
    row = dict(backend=name, actual_returncode=code, receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None)
    rows.append(row)
    (r / (name + '-exit.json')).write_text(json.dumps(row, indent=2) + '\n')
value = dict(scope='Actual currentFL579 device computations/export/barriers,CPU-side allraw/MHCN acceptance still deferred to EHPC. No timeout-based restart/termination or original model/year modification.',
             workers=rows, seconds=time.monotonic() - start)
(r / 'exit.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)
raise SystemExit(0 if all(v['actual_returncode'] == 0 for v in rows) else 1)

from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s, r = Path('/tmp/noahmp-k78-current-hu/source'), b / 'k78-current-hu'
name = sys.argv[1]
assert name in ['cuda32', 'jax32']
out = r / name
out.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert sha(s / 'SOURCE_SHA256.json') == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert len(m) == 579 and all(sha(s / n) == v for n, v in m.items())
binding = json.loads((r / 'binding.json').read_text())
assert sha(r / 'input.npz') == binding['input_sha256'] == '957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

with np.load(r / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
backend = driver.Backend(name)
prefix = 'a' if name == 'cuda32' else 'shadow'
devices = tuple(backend.xp.asarray(np.ascontiguousarray(data[prefix + str(k)])) for k in range(16))
devices = backend.update_forcing(devices, data['environment'])
before = tuple(backend.host(v) for v in devices)
kwargs = dict(environment=data['calendar_values'], calendar=data['calendar_flags'], nitrogen_deposition_gn_m2=data['nitrogen'],
              deposition=data['deposition'], most_geometry=data['geometry'], leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']), return_surface=True)
start, failure, record, barriers = time.monotonic(), None, None, []
try:
    result_device = backend.step(*devices, data['forcing'], **kwargs)
    result = backend.host(result_device)
    after = tuple(backend.host(v) for v in driver.next_bgc_arrays(devices, result_device))
    flat = {}
    def flatten(value, path=''):
        for key, item in value.items():
            if isinstance(item, dict):
                flatten(item, path + key + '/')
            else:
                flat[path + key] = np.asarray(item)
    flatten(result)
    flat.update({'next' + str(k): v for k, v in enumerate(after)})
    flat.update({'before' + str(k): v for k, v in enumerate(before)})
    np.savez_compressed(out / 'output.npz', **flat)
    if name == 'cuda32':
        backend.xp.cuda.runtime.deviceSynchronize()
        barriers.append('cupy-complete')
    else:
        import jax
        jax.effects_barrier()
        barriers.append('jax-complete')
    record = dict(output_sha256=sha(out / 'output.npz'), raw_fields_including_before_arrays=len(flat),
                  thermal_residual=np.asarray(result['surface']['thermal_layer_residual']).tolist())
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (out / 'traceback.txt').write_text(traceback.format_exc())
unchanged = all(sha(s / n) == v for n, v in m.items())
receipt = dict(scope='CurrentFL579 isolated original K78 input whole-step GPU replay only. Every original raw output and next16/before16 arrays exported without rounding/removal. No failed trajectory resumed or original1e-6/physics gates changed. No NumPy reference/model on xuanze; independent original MHCN/impurity and allraw1e-6 audit deferred to EHPC PBS after both device exports. Worker0 means completed computation/barrier/export,not those deferred acceptance gates. Normal interpreter atexit unvalidated.',
               backend=name, failure=failure, result=record, seconds=time.monotonic() - start, source_unchanged=unchanged,
               source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), input_sha256=sha(r / 'input.npz'), device_barriers=barriers)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
sys.stdout.flush()
sys.stderr.flush()
os._exit(0 if failure is None and unchanged and len(barriers) == 1 else 1)

from pathlib import Path
import hashlib,json,subprocess,re,tarfile,datetime,os
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-current-hu';sha=lambda raw:hashlib.sha256(raw).hexdigest()
launch=json.loads((r/'launch.json').read_text());s=Path('/tmp/noahmp-k78-current-hu/source');m=json.loads((s/'SOURCE_SHA256.json').read_text())
assert len(m)==579 and sha((s/'SOURCE_SHA256.json').read_bytes())==launch['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(sha((s/n).read_bytes())==h for n,h in m.items())
assert all(sha((b/n).read_bytes())==h for n,h in launch['controls_sha256'].items())
os.kill(launch['pid'],0)
exit=json.loads((r/'cuda32-exit.json').read_text());d=json.loads((r/'cuda32/receipt.json').read_text())
assert exit['actual_returncode']==0 and sha((r/'cuda32/receipt.json').read_bytes())==exit['receipt_sha256']
assert d['source_unchanged'] and d['failure'] is None and d['result']['raw_fields_including_before_arrays']==345
assert sha((r/'cuda32/output.npz').read_bytes())==d['result']['output_sha256']
jax=json.loads((r/'jax32-worker.json').read_text());os.kill(jax['pid'],0)
assert not (r/'jax32-exit.json').exists() and not (r/'exit.json').exists()
ps=subprocess.check_output(['ps','-p',','.join(map(str,[launch['pid'],jax['pid'],2816579,2759333,2924722,2953298,2990905])),'-o','pid,etimes,stat,args'],text=True)
year=json.loads((b/'qia-phase-capacity-cuda-year-ej/trajectory/batch.json').read_text())
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),launch=launch,cuda_actual_returncode=0,cuda_receipt=d,
 jax_actual_pid=jax['pid'],jax_running_export_and_cpu_acceptance_pending=True,original_year={k:year.get(k) for k in ['status','steps_completed','steps_requested','seconds']},
 processes=ps,source_unchanged=True,scope='Immutable readiness snapshot only: currentFL579 CUDA actual0/345rawexports, JAX actualalive, allraw sameprecision and independentMHCN audit deferred until bothactualexports. Originalyears/queues alive. Physical1 only; no gates/failedtrajectory/model/source intervention.')
output=b/'k78-current-hu-readiness-evidence.tar.gz';assert not output.exists()
with tarfile.open(output,'w:gz') as tf:
 for p in sorted(r.rglob('*')):
  if p.is_file():tf.add(p,arcname='current/'+p.relative_to(r).as_posix(),recursive=False)
 for n in [*launch['controls_sha256'],Path(__file__).name]:tf.add(b/n,arcname='controls/'+n,recursive=False)
 import io
 raw=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo('snapshot.json');info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=output.name,sha256=sha(output.read_bytes()),bytes=output.stat().st_size,snapshot=value)))

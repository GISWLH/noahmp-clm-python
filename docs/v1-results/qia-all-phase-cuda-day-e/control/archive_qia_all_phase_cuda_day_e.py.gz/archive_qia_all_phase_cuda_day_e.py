from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-all-phase-cuda-year-e';a=b/'qia-all-phase-cuda-day-e-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((r/'exit.json').read_text())['returncode']==1
d=json.loads((r/'day48-primary-audit-e.json').read_text());assert d['primary_cold_fields_exact']==26 and d['device_barrier_complete'] and d['source_unchanged'] and d['steps_completed']==48
assert json.loads((r/'day48-primary-audit-e-exit.json').read_text())['actual_returncode']==0
assert sha(r/'trajectory/batch.json')==d['report_sha256']
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['run_qia_all_phase_cuda_year_e.py','control_qia_all_phase_cuda_year_e.py','launch_qia_all_phase_cuda_year_e.py','audit_qia_all_phase_cuda_day_e.py','control_qia_all_phase_day_audit_e.py','archive_qia_all_phase_cuda_day_e.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Original currentB511 physical48 complete underoriginalhardguards;parent1onlyincorrectstrictshadowfieldset equality. Correctedread-only26coldprimary+index/ledgers exact,22reference shadowextras retained/excludedexplicitly;currentvalidgeneration/trace hashes andsourceidentity verified,auditactual0. No year/science/sameprecision completion.')))

from pathlib import Path
import hashlib,json,os,sys
import numpy as np
import cupy as cp
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-all-phase-cuda-year-e';s=b/'p6-all-phase-final-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==511 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
parent=json.loads((r/'exit.json').read_text());assert parent['returncode']==1
failure=json.loads((r/'receipt.json').read_text());assert failure['failure']=='AssertionError: ' and failure['source_unchanged']
traceback=(r/'traceback.txt').read_text();assert "assert set(a.files)==set(old.files) and len(a.files)==26" in traceback
report,state,cases=native.read_generation(r/'trajectory')
assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['source_unchanged'] and report['same_precision_max_absolute'] is None and report['identity']['compare_jax32'] is False and len(state)==26
assert sha(r/'trajectory'/report['checkpoint_file'])==report['checkpoint_sha256']
cold=list((r/'trajectory').glob('state-0000000-*.npz'));assert len(cold)==1
with np.load(cold[0],allow_pickle=False) as a,np.load(r/'strict-cold-reference.npz',allow_pickle=False) as ref:
    assert len(a.files)==26 and set(a.files)<=set(ref.files)
    omitted=sorted(set(ref.files)-set(a.files));assert len(omitted)==22 and all(k.startswith('shadow') for k in omitted)
    for n in a.files:
        assert a[n].dtype==ref[n].dtype
        if a[n].dtype.kind in 'US':assert np.array_equal(a[n],ref[n]),n
        else:assert bool(cp.array_equal(cp.asarray(a[n]),cp.asarray(ref[n]))),n
    cold_names=sorted(a.files)
# Validate generation hashes/lengths without demanding equality to an older
# model version. The native integrator checked every original hard budget.
traces={}
for case,desc in report['case_reports'].items():
    p=r/'trajectory'/case/desc['file'];assert sha(p)==desc['sha256'];d=json.loads(p.read_text());assert d['status']=='running' and d['steps_completed']==48
    p=p.parent/d['model_npz'];assert sha(p)==d['model_npz_sha256']
    with np.load(p,allow_pickle=False) as z:
        assert all(len(v)==48 for v in z.values());traces[case]=dict(trace_sha256=sha(p),fields=sorted(z.files),report_sha256=sha(r/'trajectory'/case/desc['file']))
cp.cuda.runtime.deviceSynchronize();assert all(sha(s/n)==h for n,h in m.items())
d=dict(scope='Read-only corrected GPU numeric/cold-state audit. Original E model completed48 with original hardguards;only parentpostprocess asserted CUDA-only26 fieldset equal strictreference48. All26 primary/index/ledger coldfields exact;only22reference shadow extras disclosed. Current19primaryplus7ledgers complete generation/nativeidentity/tracehashes verified,not required to equal older source trajectory. No model/input/solver/gate edits or scientific/year/sameprecision acceptance.',source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),primary_cold_fields_exact=26,cold_field_names=cold_names,excluded_reference_shadow_fields=omitted,original_parent_returncode=1,model_status=report['status'],steps_completed=48,report_sha256=sha(r/'trajectory/batch.json'),checkpoint_sha256=report['checkpoint_sha256'],maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],traces=traces,device_barrier_complete=True)
p=r/'day48-primary-audit-e.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();os._exit(0)

from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-b';r=b/'qia-all-phase-cuda-year-e';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==511 and all(sha(s/n)==v for n,v in m.items())
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
start=time.monotonic();failure=None;result=None;barriers=[]
try:
    native.run(r/'inputs/batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,stop_after=48)
    report,state,cases=native.read_generation(r/'trajectory')
    assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and len(state)==26
    assert report['same_precision_max_absolute'] is None
    cold=list((r/'trajectory').glob('state-0000000-*.npz'));assert len(cold)==1
    with np.load(cold[0],allow_pickle=False) as a,np.load(r/'strict-cold-reference.npz',allow_pickle=False) as old:
        assert set(a.files)==set(old.files) and len(a.files)==26
        for key in a.files:np.testing.assert_array_equal(a[key],old[key],err_msg=key)
    native.atomic_json(r/'day48-report.json',report)
    native.atomic_json(r/'day48-cold-audit.json',dict(scope='New own successful48 from original physical cold seed,all26saved fields (19primary plus index and6ledgers) exactly equal original strictA cold input. No archived prefix resumed or same-precision claim.',actual_first48_seconds=time.monotonic()-start,cold_checkpoint_sha256=sha(cold[0]),reference_cold_sha256=sha(r/'strict-cold-reference.npz'),saved_fields_exact=26))
    native.run(r/'inputs/batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,resume=True)
    report,state,cases=native.read_generation(r/'trajectory')
    assert report['status']=='complete' and report['steps_completed']==17520 and report['source_unchanged'] and report['same_precision_max_absolute'] is None
    result=dict(steps_completed=17520,steps_requested=17520,columns=1,native_checkpoint_arrays=26,maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],same_precision_maximum_absolute=None)
except Exception as e:
    failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
import cupy as cp
cp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
unchanged=all(sha(s/n)==v for n,v in m.items());path=r/'trajectory/batch.json';report=json.loads(path.read_text()) if path.exists() else {}
receipt=dict(scope='New frozen511B CUDA-only cold trajectory,own first48 with strict original physical-seed equality then same-source own-prefix continuation to17520. Original failed163/1519/735/3798 and strictA unchanged. CPU911 and actual finalphase11 plus isolated3798 CUDA/JAX380 prerequisites; full canonical1254 separately pending. No JAX shadow in this year,same_precision=None,not spinup/scientific acceptance. Atexit bypass only after barrier/durable receipt.',failure=failure,result=result,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barriers=barriers,seconds=time.monotonic()-start)
native.atomic_json(r/'receipt.json',receipt);print(json.dumps(receipt),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged else 1)

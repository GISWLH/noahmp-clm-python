"""Standard-library-only NumPy32 adapter preparation. No numerical execution."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'clm-drainage-adaptive-pb-g-preparation'
DEST=ROOT/'clm-drainage-adaptive-pb-i-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()


class Explicit32(ast.NodeTransformer):
    def visit_Import(self,node):
        if any(x.name=='jax.numpy' for x in node.names):
            return ast.Import(names=[ast.alias(name='numpy',asname='j')])
        return node
    def visit_ImportFrom(self,node):
        if node.module=='jax':return None
        return node
    def visit_Constant(self,node):
        if type(node.value) is float:
            return ast.Call(func=ast.Name(id='F',ctx=ast.Load()),args=[node],keywords=[])
        return node


HEADER='''"""Explicit NumPy32 evaluation of the frozen NM device phase equations.

Generated from the three original pure functions by import replacement and
float-literal typing only. The local lax adapter executes the same bounded
loops; every barrier and carry rejects an intermediate floating dtype change.
This is NumPy CPU validation, not execution or acceptance of JAX/CUDA.
"""
import numpy as np
F=np.float32
PHASE_AUDIT={'barrier_calls':0,'floating_values_checked':0}

def _check(value):
    if isinstance(value,(tuple,list)):
        for item in value:_check(item)
    elif hasattr(value,'dtype') and value.dtype.kind=='f':
        PHASE_AUDIT['floating_values_checked']+=1
        if value.dtype!=np.float32:
            raise RuntimeError('Phase arithmetic changed explicit float32 dtype')
    return value

class _Lax:
    @staticmethod
    def optimization_barrier(value):
        PHASE_AUDIT['barrier_calls']+=1
        return _check(value)
    @staticmethod
    def fori_loop(start,end,body,carry):
        _check(carry)
        for index in range(start,end):carry=_check(body(index,carry))
        return carry
    @staticmethod
    def while_loop(condition,body,carry):
        _check(carry);iterations=0
        while bool(condition(carry)):
            carry=_check(body(carry));iterations+=1
            if iterations>64:raise RuntimeError('Original phase iteration bound exceeded')
        return carry
lax=_Lax()

'''

FOOTER='''
OUTPUTS=('temperature_offset_k','temperature_k','liquid_kgm2','ice_kgm2',
    'enthalpy_jm2','capacity_jm2k','reconstruction_residual_jm2','iterations','converged')

def run_numpy32(inputs,options,*,inverse=False):
    from noahmp_clm.gpu.enthalpy import validate_soil_thermodynamics
    u=np.asarray(inputs);o=np.asarray(options)
    if u.dtype!=np.float32:raise ValueError('Explicit float32 phase input required')
    validate_soil_thermodynamics(u,o,inverse,np)
    if inverse:
        result=soil_thermodynamics_kernel_jax(u.T,o,inverse=True)
    else:
        w,t,z,por,b,psi=u.T
        h,c,liq=soil_thermodynamics_jax(w,t,z,por,b,psi,o)
        result=np.stack((t,t+F(273.15),liq,w-liq,h,c,np.zeros_like(w),
                         np.zeros_like(w),np.ones_like(w)))
    _check(result)
    if not np.all(np.isfinite(result)) or not np.all(result[-1]>0):
        raise ValueError('Original phase domain or convergence failed')
    return dict(zip(OUTPUTS,result))
'''


def main():
    DEST.mkdir(exist_ok=True)
    binding=json.loads((OLD/'BINDINGS.json').read_bytes())
    assert sha((ROOT/binding['source_archive']).read_bytes())==binding['source_archive_sha256']
    with tarfile.open(ROOT/binding['source_archive']) as t:
        raw=t.extractfile('src/noahmp_clm/gpu/enthalpy.py').read()
    tree=ast.parse(raw.decode());names=['soil_thermodynamics_jax','invert_soil_enthalpy_jax','soil_thermodynamics_kernel_jax']
    functions=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names]
    assert len(functions)==3
    adapted=ast.fix_missing_locations(Explicit32().visit(ast.Module(body=functions,type_ignores=[])))
    (DEST/'phase_numpy32_pbi.py').write_text(HEADER+ast.unparse(adapted)+'\n'+FOOTER,encoding='utf8',newline='\n')
    for name in binding['frozen_dependencies']:
        (DEST/name).write_bytes((OLD/name).read_bytes())
    # Preserve the original reference and its tests untouched in the stage.
    for name in ('adaptive_main_pbg.py','test_adaptive_main_pbg.py'):
        (DEST/name).write_bytes((OLD/name).read_bytes())
    code=(OLD/'adaptive_main_pbg.py').read_text(encoding='utf8')
    old="    if backend=='numpy':\n        from noahmp_clm.column import SoilParams"
    new="""    if backend=='numpy' and c.dtype==xp.float32:
        from phase_numpy32_pbi import run_numpy32
        packed=xp.stack((c[:,4],c[:,5],c[:,2],xp.full(4,p[0],c.dtype),
                         xp.full(4,p[2],c.dtype),xp.full(4,p[1],c.dtype)),axis=1)
        out=run_numpy32(packed,xp.full(4,option,xp.int32),inverse=True)
        temperature=out['temperature_k']
        liquid=xp.where(temperature>=xp.float32(273.15),c[:,4],xp.clip(out['liquid_kgm2'],0,c[:,4]))
    elif backend=='numpy':
        from noahmp_clm.column import SoilParams"""
    assert code.count(old)==1;code=code.replace(old,new)
    rejected="    if backend=='numpy' and c.dtype!=xp.float64:\n        raise ValueError('Independent NumPy phase reference is float64; no hidden NumPy32/64 mixed chain')\n"
    assert code.count(rejected)==1;code=code.replace(rejected,'')
    code=code.replace('Isolated main-band adaptive device orchestration, prepared but unexecuted.',
        'PB-i NumPy32 main-band adaptation; original PB-g retained separately.')
    (DEST/'adaptive_main_pbi.py').write_text(code,encoding='utf8',newline='\n')
    binding['frozen_dependencies'].update({n:sha((DEST/n).read_bytes()) for n in ('adaptive_main_pbg.py','test_adaptive_main_pbg.py')})
    binding.update(original_phase_source_sha256=sha(raw),original_pb_g_archive_sha256='902fc52c7450c1472dba2c3649e67b6ed38a6e57eb0ba1c451a839acf47dcd93',
        phase_adaptation='Original three pure functions: JAX imports to NumPy, float literals to numpy.float32, bounded lax host adapter; original equations/tolerances unchanged.',
        original_float64_tests=8,new_float32_tests=10)
    (DEST/'BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf8',newline='\n')
    proof=dict(actual_static_exit=0,numerical_execution=False,original_phase_sha256=sha(raw),
        phase_functions=names,preserved_float64_tests_sha256=sha((DEST/'test_adaptive_main_pbg.py').read_bytes()),
        original_hard_budget_factor=64,original_phase_residual_factor=8,
        scope='Only stdlib source generation; no arrays or scientific execution locally.')
    (ROOT/'clm-drainage-adaptive-pb-i-static-preparation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8',newline='\n')
    print(json.dumps(proof))


if __name__=='__main__':main()

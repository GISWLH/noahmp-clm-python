# PB-i actual execution and scope

1641.manager is actually F / Exit_status 0 / Stageout_status 0. All 18 cases passed:
the eight unchanged NumPy64 cases and ten additional NumPy32 cases. Full main
integration uses actual phase inversion and unchanged hard 64-epsilon M/H bounds.
These are real component integrations; coupled column, site, annual and GPU runs
are zero. JAX/CUDA remain unexecuted.

The frozen preparation README/test comment incorrectly predicted saturated
float32 initial water as 224.9999847 kg/m2. Actual execution records exactly 225
kg/m2 and zero initial water difference. This is a pre-execution description
error, not a test failure or stock repair. Actual parameter/enthalpy input
quantization is separately reported. The original preparation is not rewritten.

Step refinement moves third-layer export closer to the independent continuous
ODE (default about +2.57%, refined about +0.63%). Its difference from the finite
256-step official reference grows (about -3.54% to -5.36%); both remain
within 10%. Do not label this as monotone convergence to that finite official
discretization. Exact values are derived in run-readout.json.
The bedrock case protects lower stock and bounds the front;
it does not test a trajectory that reaches the interface.

Perched common-thermal-boundary comparison is not closed by these main-flow tests.

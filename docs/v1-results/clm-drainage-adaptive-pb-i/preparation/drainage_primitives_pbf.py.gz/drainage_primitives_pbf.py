"""Isolated four-cell drainage primitives; no production registration.

The main trial removes actual liquid/enthalpy, but does NOT re-equilibrate phase
or advance the adaptive PB-c integrator. Its output must not be reused as a
phase-consistent next input without the original enthalpy inversion.
"""
from functools import lru_cache
from pathlib import Path

import numpy as np

PARAMETER_FIELDS = (
    'porosity', 'suction_m', 'bexp', 'satdk_m_s', 'bedrock_m', 'slope_radians',
    'baseflow_mm_s_per_m', 'perched_scale_per_m', 'threshold', 'yield_floor',
    'retained_liquid_kg_m2', 'ice_exponent')
DIAGNOSTIC_FIELDS = (
    'main_theta_m', 'frost_m_or_zero', 'perched_m_or_zero', 'has_frost',
    'has_perched', 'transition_count', 'active_layers', 'main_rate_kg_m2_s',
    'perched_rate_kg_m2_s', 'main_ice_factor', 'perched_ice_factor',
    'main_specific_yield', 'first_perched_donor_or_minus_one')
TRIAL_FIELDS = ('migrated_front_m', 'requested_kg_m2', 'actual_kg_m2',
                'unavailable_liquid_kg_m2', 'band_exhaustion_kg_m2',
                'liquid_limited', 'water_residual_kg_m2', 'energy_residual_j_m2',
                'water_bound_kg_m2', 'energy_bound_j_m2')


def pack(soil, parameters, duration, front, bottom, dtype=np.float64):
    """One case: cells [liquid, ice, dz, T, total water, enthalpy], SI units."""
    p = soil.params
    cells = np.column_stack((soil.liquid, soil.water-soil.liquid, soil.dz,
                             soil.temperature, soil.water, soil.enthalpy)).astype(dtype)
    pars = np.asarray((p.smcmax, p.saturated_suction_m, p.bexp, p.satdk,
        parameters.bedrock_depth_m, parameters.slope_radians,
        parameters.baseflow_mm_s_per_m, parameters.perched_scale_per_m,
        parameters.saturation_threshold, parameters.minimum_specific_yield,
        parameters.retained_liquid_kg_m2, parameters.ice_impedance_exponent), dtype)
    interval = np.asarray((duration, front, bottom), dtype)
    validate(cells[None], pars[None], interval[None], np)
    return cells, pars, interval


def validate(cells, pars, interval, xp):
    """Strict four-cell public boundary; no repair, clipping or phase inversion."""
    n = len(cells); dt = cells.dtype
    if (n<1 or cells.shape != (n,4,6) or pars.shape != (n,12) or interval.shape != (n,3)
            or dt not in (xp.float32,xp.float64) or pars.dtype != dt or interval.dtype != dt
            or not all(bool(xp.all(xp.isfinite(a))) for a in (cells,pars,interval))):
        raise ValueError('Finite same-precision four-layer cells/parameters/interval required')
    edges = xp.cumsum(cells[:,:,2], axis=1)
    eps = xp.finfo(dt).eps
    matches = xp.sum(xp.abs(edges-pars[:,4,None]) <= 16*eps*xp.maximum(edges[:,-1,None],1),axis=1)
    bad = xp.any((cells[:,:,0]<0)|(cells[:,:,1]<0)|(cells[:,:,2]<=0)
        |(cells[:,:,3]<150)|(cells[:,:,3]>400)|(cells[:,:,4]<0)
        |(cells[:,:,4]>1000*cells[:,:,2]*pars[:,0,None]),axis=1)
    bad |= xp.any(xp.abs(cells[:,:,0]+cells[:,:,1]-cells[:,:,4])
                  >16*eps*xp.maximum(cells[:,:,4],1),axis=1)
    bad |= ((pars[:,0]<=0)|(pars[:,0]>=1)|(pars[:,1]<=0)|(pars[:,2]<=0)
        |(pars[:,3]<0)|(pars[:,4]<=0)|(matches!=1)|(pars[:,5]<0)|(pars[:,5]>=xp.pi/2)
        |(pars[:,6]<0)|(pars[:,7]<0)|(pars[:,8]<=0)|(pars[:,8]>=1)
        |(pars[:,9]<=0)|(pars[:,9]>=pars[:,0])|(pars[:,10]<0)|(pars[:,11]<0)
        |(interval[:,0]<=0)|(interval[:,1]<0)|(interval[:,2]<interval[:,1])
        |(interval[:,2]>pars[:,4]))
    if bool(xp.any(bad)):
        raise ValueError('Invalid stock, phase partition, geometry, rate or trial limits')


def _sy(z,p,xp,s):
    return xp.maximum(p[9], s(-p[0]*xp.expm1(s(-xp.log1p(s(z/p[1]))/p[2]))))


def _integral(a,b,p,xp,s):
    """Analytic PB-c Sy integral, including B=1 and positive floor branches."""
    logfloor=s(-p[2]*xp.log1p(s(-p[9]/p[0])))
    fd=s(p[1]*xp.expm1(logfloor))
    split=xp.minimum(b,xp.maximum(a,fd));length=s(b-split)
    power=s(1-1/p[2]);safe=xp.where(power==0,1,power)
    lr=xp.log1p(s(length/s(p[1]+split)))
    scaled=xp.where(power==0,lr,s(xp.expm1(s(power*lr))/safe))
    retention=s(s(xp.exp(s(-xp.log1p(s(split/p[1]))/p[2]))*s(p[1]+split))*scaled)
    result=s(s(p[9]*s(split-a))+s(p[0]*s(length-retention)))
    return xp.where(b==a,0,xp.where(logfloor>=xp.log1p(s(b/p[1])),s(p[9]*s(b-a)),result))


def _geometry(c,p,xp,s):
    edges=[xp.asarray(0.,c.dtype)]
    for k in range(4): edges.append(s(edges[-1]+c[k,2]))
    edges=xp.stack(edges);centers=s(edges[:-1]+s(.5*c[:,2]))
    active=xp.sum((edges[1:]<=p[4]+16*xp.finfo(c.dtype).eps*xp.maximum(edges[-1],1)).astype(xp.int32))
    sat=s(s(s(c[:,0]/1000)+s(c[:,1]/917))/s(c[:,2]*p[0]))
    ice=xp.minimum(1,s(c[:,1]/s(s(917*c[:,2])*p[0])))
    return edges,centers,active,sat,ice


def _level(sat,centers,edges,count,bottom,threshold,main,xp,s):
    dry=xp.asarray(-1,xp.int32)
    for k in range(4):dry=xp.where((k<count)&(sat[k]<=threshold),k,dry)
    j=xp.clip(dry,0,2);delta=s(sat[j+1]-sat[j])
    fraction=s(s(threshold-sat[j])/xp.where(delta==0,1,delta))
    interp=xp.clip(s(centers[j]+s(fraction*s(centers[j+1]-centers[j]))),0,bottom)
    if main:
        return xp.where(dry<=0,xp.minimum(edges[1],bottom),xp.where(dry==count-1,bottom,interp))
    return xp.where(dry<0,0,xp.where(dry==count-1,bottom,interp))


def _rate(c,p,edges,ice,front,bottom,perched,xp,s):
    fi=xp.sum((edges[1:]<front).astype(xp.int32))
    bi=xp.sum((edges[1:]<bottom).astype(xp.int32))
    thickness=s(bottom-front);weights=[];num=xp.asarray(0.,c.dtype);den=num
    for k in range(4):
        chosen=((k>=fi)&(k<=bi)) if perched else (k>=xp.maximum(fi-1,0))
        w=xp.where(chosen,c[k,2],0);weights.append(w)
        value=xp.power(10.,s(-p[11]*s(.5*s(ice[k]+ice[min(k+1,3)])))) if perched else ice[k]
        num=s(num+s(w*value));den=s(den+w)
    average=s(num/xp.where(den==0,1,den))
    factor=average if perched else xp.power(10.,s(-p[11]*average))
    factor=xp.where(thickness==0,1,factor)
    if perched:
        rate=s(s(s(s(1000*p[7])*xp.sin(p[5]))*s(p[3]*factor))*thickness)
        rate=xp.where(fi>=bi,0,rate)
    else:rate=s(s(s(p[6]*xp.tan(p[5]))*thickness)*factor)
    return rate,factor,xp.stack(weights),fi


def _diagnosis(c,p,xp,s):
    e,z,active,sat,ice=_geometry(c,p,xp,s)
    main=_level(sat,z,e,active,p[4],p[8],True,xp,s)
    fi=xp.asarray(-1,xp.int32);count=xp.asarray(0,xp.int32)
    for k in range(1,4):
        hit=(k<active)&(c[k-1,3]>273.15)&(c[k,3]<=273.15)
        fi=xp.where(hit&(fi<0),k,fi);count=count+hit.astype(xp.int32)
    frost=xp.where(fi>=0,z[xp.maximum(fi,0)],0)
    candidate=_level(sat,z,e,fi+1,frost,p[8],False,xp,s)
    has=(fi>=0)&(main>=frost)&(candidate<frost)
    perch=xp.where(has,candidate,0)
    mq,mf,mw,_=_rate(c,p,e,ice,main,p[4],False,xp,s)
    pq,pf,pw,pi=_rate(c,p,e,ice,perch,frost,True,xp,s)
    pq=xp.where(has,pq,0);pf=xp.where(has,pf,1);pw=xp.where(has,pw,0)
    values=xp.stack((main,frost,perch,(fi>=0).astype(c.dtype),has.astype(c.dtype),
        count.astype(c.dtype),active.astype(c.dtype),mq,pq,mf,pf,_sy(main,p,xp,s),
        xp.where(has,pi+1,-1).astype(c.dtype)))
    return xp.concatenate((values,mw,pw,ice,sat))


def _trial(c,p,u,xp,s):
    e,_,_,_,ice=_geometry(c,p,xp,s)
    duration,front,bottom=u
    rate,_,_,_=_rate(c,p,e,ice,front,bottom,False,xp,s)
    requested=s(rate*duration);remaining=requested;position=front
    active=xp.asarray(True);limited=xp.asarray(False);demands=[]
    for k in range(4):
        left=xp.maximum(position,e[k]);right=xp.minimum(bottom,e[k+1])
        eligible=active&(right>left)&(remaining>0)
        safe_right=xp.maximum(right,left)
        capacity=s(1000*_integral(left,safe_right,p,xp,s))
        take=xp.where(eligible,xp.minimum(remaining,xp.minimum(capacity,xp.maximum(0,s(c[k,0]-p[10])))),0)
        lo=left;hi=safe_right
        for _ in range(64):
            mid=s(.5*s(lo+hi));mass=s(1000*_integral(left,mid,p,xp,s))
            less=mass<take;lo=xp.where(less,mid,lo);hi=xp.where(less,hi,mid)
        el=xp.abs(s(s(1000*_integral(left,lo,p,xp,s))-take))
        eh=xp.abs(s(s(1000*_integral(left,hi,p,xp,s))-take))
        moved=xp.where(el<=eh,lo,hi)
        moved=xp.where(take==0,left,xp.where(take>=capacity,safe_right,moved))
        remaining=s(remaining-take);stop=eligible&(take<capacity)
        limited=limited|(stop&(remaining>0));active=active&~stop
        position=xp.where(eligible,moved,position);demands.append(take)
    demand=xp.stack(demands)
    heat=s(demand*s(334000+s(4180*s(c[:,3]-273.15))))
    water=s(c[:,4]-demand);enthalpy=s(c[:,5]-heat)
    total=xp.asarray(0.,c.dtype);mr=total;hr=total;wm=total;hm=total
    for k in range(4):
        total=s(total+demand[k]);mr=s(mr+s(s(water[k]-c[k,4])+demand[k]))
        hr=s(hr+s(s(enthalpy[k]-c[k,5])+heat[k]))
        wm=s(wm+s(s(xp.abs(c[k,4])+xp.abs(water[k]))+xp.abs(demand[k])))
        hm=s(hm+s(s(xp.abs(c[k,5])+xp.abs(enthalpy[k]))+xp.abs(heat[k])))
    unmet=xp.maximum(0,s(requested-total));eps=xp.finfo(c.dtype).eps
    values=xp.stack((position,requested,total,xp.where(limited,unmet,0),
        xp.where(limited,0,unmet),limited.astype(c.dtype),mr,hr,
        s(64*eps*xp.maximum(wm,1)),s(64*eps*xp.maximum(hm,1))))
    return xp.concatenate((values,demand,heat,water,enthalpy))


def _checked(diag,trial,cells,interval,xp):
    if not all(bool(xp.all(xp.isfinite(v))) for v in (diag,trial)):
        raise RuntimeError('Nonfinite drainage primitive output')
    eps=xp.finfo(cells.dtype).eps
    slack=16*eps*xp.maximum(cells[:,:,0],1)
    if (bool(xp.any(trial[:,10:14]<0)) or bool(xp.any(trial[:,10:14]>cells[:,:,0]+slack))
            or bool(xp.any(xp.abs(trial[:,6])>trial[:,8]))
            or bool(xp.any(xp.abs(trial[:,7])>trial[:,9]))
            or bool(xp.any(trial[:,0]<interval[:,1]))
            or bool(xp.any(trial[:,0]>interval[:,2]))):
        raise RuntimeError('Drainage liquid/front/hard-budget boundary failed')
    return diag,trial


def run_numpy(cells,pars,interval):
    validate(cells,pars,interval,np)
    diag=np.stack([_diagnosis(c,p,np,lambda x:x) for c,p in zip(cells,pars)])
    trial=np.stack([_trial(c,p,u,np,lambda x:x) for c,p,u in zip(cells,pars,interval)])
    return _checked(diag,trial,cells,interval,np)


@lru_cache(maxsize=1)
def _jax_compiled():
    import jax
    import jax.numpy as j
    s=jax.lax.optimization_barrier
    return jax.jit(jax.vmap(lambda c,p,u:(_diagnosis(c,p,j,s),_trial(c,p,u,j,s))))


def run_jax(cells,pars,interval):
    import jax.numpy as j
    values=tuple(map(j.asarray,(cells,pars,interval)));validate(*values,j)
    diag,trial=_jax_compiled()(*values)
    return _checked(diag,trial,values[0],values[2],j)


@lru_cache(maxsize=1)
def _cuda_module():
    import cupy as cp
    return cp.RawModule(code=Path(__file__).with_name('drainage_primitives_pbf.cu').read_text(),
        options=('--std=c++14','--fmad=false','--prec-div=true','--prec-sqrt=true'),
        name_expressions=('drainage<float>','drainage<double>'))


def run_cuda(cells,pars,interval):
    import cupy as cp
    values=tuple(cp.ascontiguousarray(v) for v in (cells,pars,interval));validate(*values,cp)
    n=len(values[0]);diag=cp.empty((n,29),values[0].dtype);trial=cp.empty((n,26),values[0].dtype)
    name='drainage<float>' if values[0].dtype==cp.float32 else 'drainage<double>'
    _cuda_module().get_function(name)(((n+127)//128,),(128,),(*values,diag,trial,np.int32(n)))
    return _checked(diag,trial,values[0],values[2],cp)

from pathlib import Path
import hashlib,io,json,os,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-pressure-consistency-j';a=b/'richards-pressure-consistency-j-input.tar.gz'
sha=lambda raw:hashlib.sha256(raw).hexdigest();result=[]
with tarfile.open(a) as t:
    manifest=json.load(t.extractfile('MANIFEST.json'))
    payload={n:t.extractfile(n).read() for n in manifest}
assert all(sha(raw)==manifest[n] for n,raw in payload.items())
with np.load(io.BytesIO(payload['richards_reference.npz']),allow_pickle=False) as z:reference=dict(z)
for index in range(5):
    with np.load(io.BytesIO(payload['case'+str(index)+'.npz']),allow_pickle=False) as z:data=dict(z)
    p=reference['32/'+str(index)+'/hydraulics'].astype(float)
    dz,por,k,psi,exponent,ref=[p[:,:,i] for i in range(6)];maximum=1000.*dz*por
    comparison={};heads={}
    for backend in ['cuda','jax']:
        w=data[backend+'/water_kg_m2'].astype(float);h=data[backend+'/pressure_head_m'].astype(float)
        relative=np.divide(w,maximum,out=np.zeros_like(w),where=maximum>0.)
        limited=np.maximum(relative,np.divide(.01*ref,por,out=np.ones_like(por),where=por>0.))
        actual=-np.minimum(psi*limited**(-exponent),1e5)
        unsat=(maximum>0.)&(w<maximum)&(relative>=limited)&(h<0.)&(h>-1e5)
        inverse=maximum*(psi/np.maximum(-h,1e-300))**(1./exponent)
        comparison[backend]=dict(water=w.tolist(),reported_head_m=h.tolist(),
            independently_calculated_head_from_stored_water_m=actual.tolist(),unsaturated_identity_mask=unsat.tolist(),
            head_identity_error_m=np.where(unsat,h-actual,0.).tolist(),
            implied_water_minus_actual_kg_m2=np.where(unsat,inverse-w,0.).tolist(),
            maximum_reported_nonlinear_residual_kg_m2=data[backend+'/maximum_nonlinear_residual_kg_m2'].astype(float).tolist())
        heads[backend]=actual
    fields={}
    for key in [n[5:] for n in data if n.startswith('cuda/')]:
        x,y=data['cuda/'+key],data['jax/'+key]
        delta=abs(x.astype(float)-y.astype(float))
        passed=bool(np.array_equal(x,y)) if x.dtype.kind in 'biu' else bool(np.all(delta<=1e-6+1e-6*abs(y.astype(float))))
        fields[key]=dict(dtype=str(x.dtype),maximum_absolute_difference=float(delta.max(initial=0.)),original_same_precision_passed=passed)
    result.append(dict(index=index,fields=fields,identity=comparison,
        independently_calculated_head_backend_difference_m=(heads['cuda']-heads['jax']).tolist()))
d=dict(scope='EHPC compute-only independent constitutive diagnostic of retained actualG failed raw fields0-4. No solver candidate, rounding, tolerance changes or claimed acceptance. Saturated pressure is not determined by storage alone, explicitly masked.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,input_archive_sha256=sha(a.read_bytes()),input_sha256=manifest,cases=result)
(r/'analysis.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps(d),flush=True)

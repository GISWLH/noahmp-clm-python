import numpy as np,jax,jax.numpy as j,cupy as cp
x=j.arange(18,dtype=j.float32);v=np.asarray(jax.jit(lambda x:j.exp2(-x))(x));expected=np.ldexp(np.ones(18,np.float32),-np.arange(18));k=cp.RawKernel('extern "C" __global__ void f(float* y){int k=threadIdx.x;y[k]=exp2f(-(float)k);}','f',options=('--fmad=false','--prec-div=false'));out=cp.empty(18,cp.float32);k((1,),(18,),(out,));cu=cp.asnumpy(out)
for i in range(18):
 if v[i]!=cu[i]:print(i,float(v[i]),float(cu[i]),float(expected[i]))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'stem-station-precision-d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cuda32','jax32']:
 d=json.loads((r/(name+'-most-trace')/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and d['result']['all_original_output_and_next19_bytes_equal'] and sha(r/(name+'-most-trace')/'trace.npz')==d['trace_sha256']
d=json.loads((r/'canonical-stem-counterfactual/receipt.json').read_text());assert d['source_unchanged'] and d['failed']==d['nonzero']==[] and d['fields']==380 and sha(r/'canonical-stem-counterfactual/outputs.npz')==d['outputs_sha256'];comparison=json.loads((r/'most-comparison-finite.json').read_text());assert len(comparison['fixed_input_differences'])==1 and comparison['fixed_input_differences'][0]['field']=='fixed/stem_area'
a=b/'stem-station-cause-d-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for name in ['cuda32-most-trace','jax32-most-trace','canonical-stem-counterfactual']:
  for p in sorted((r/name).iterdir()):t.add(p,arcname=name+'/'+p.name,recursive=False)
 for n in ['cuda32-most-trace.log','jax32-most-trace.log','trace-launch.json','most-comparison.json','most-comparison-finite.json']:t.add(r/n,arcname=n,recursive=False)
 for n in ['trace_stem_station_precision_d.py','launch_stem_station_trace_d.py','compare_stem_station_most_trace_d.py','compare_stem_station_most_trace_finite_d.py','counterfactual_stem_split_d.py','archive_stem_station_cause_d.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import datetime,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';r=b/'stem-station-precision-d';env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'));assert not (r/'trace-launch.json').exists();rows=[]
for name in ['cuda32','jax32']:
 with (r/(name+'-most-trace.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'trace_stem_station_precision_d.py'),name],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 rows.append(dict(backend=name,pid=p.pid))
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=rows,scope='Bounded per-MOST-iteration observation only. Original output bytes must remain unchanged; all physics,50 iterations and1e-6 gate untouched. Original station trajectory stays failed/1.');(r/'trace-launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

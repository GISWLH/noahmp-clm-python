from pathlib import Path
import hashlib,inspect,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';r=b/'stem-station-precision-d';name=sys.argv[1];out=r/(name+'-most-trace');out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s/'src'),str(s/'tests'),str(s/'benchmarks')];import run_fluxnet_native as native;import noahmp_clm.gpu.canopy_most_surface as module
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
binding=json.loads((r/'binding.json').read_text());assert sha(r/'input.npz')==binding['input_sha256'];engine=native.Backend(name);arrays=tuple(engine.xp.asarray(np.ascontiguousarray(data[('a' if name=='cuda32' else 'shadow')+str(k)])) for k in range(19));arrays=engine.update_forcing(arrays,data['environment']);before=tuple(engine.host(v) for v in arrays);flat={};counts=[]
def flatten(value,path):
 if isinstance(value,dict):
  for key,v in value.items():flatten(v,path+key+'/')
 else:flat[path.rstrip('/')]=engine.host(value) if hasattr(value,'shape') else np.asarray(value)
def capture(phase,local):
 count=local['count'];prefix=str(count)+'/'+phase+'/'
 for key in ['current','state','zeta','effective','done','relaxation','stable_bracket','lower','upper','atmosphere']:
  if key in local:flatten(local[key],prefix+key+'/')
 if phase=='before':
  for key in ['trial','extension']:flatten(local[key],prefix+key+'/')
  if count==1:
   for k,v in enumerate(local['arrays']):flatten(v,'fixed/array'+str(k)+'/')
   for key in ['geometry','wind','leaf_dimension','plant_area','stem_area']:flatten(local[key],'fixed/'+key+'/')
 else:
  counts.append(count)
  for key in ['surface','feedback','target','mismatch']:flatten(local[key],prefix+key+'/')
original=module.run_most_surface;source=inspect.getsource(original);marker='        surface=solve(';after='        if previous is not None:\n';assert source.count(marker)==source.count(after)==1;instrumented=source.replace(marker,"        capture('before',locals())\n"+marker).replace(after,"        capture('after',locals())\n"+after);namespace=dict(original.__globals__,capture=capture);exec(compile(instrumented,'<read-only MOST per-iteration trace>','exec'),namespace);module.run_most_surface=namespace['run_most_surface'];failure=None;result=None;start=time.monotonic()
try:
 device=engine.step(*arrays,data['forcing'],environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=native.LeafParameters(**binding['leaf_parameters']),return_surface=True);actual=engine.host(device);following=tuple(engine.host(v) for v in native.next_station_arrays(arrays,device));final={}
 def end_flatten(value,path=''):
  for key,v in value.items():
   if isinstance(v,dict):end_flatten(v,path+key+'/')
   else:final[path+key]=np.asarray(v)
 end_flatten(actual);final.update({'next'+str(k):v for k,v in enumerate(following)})
 with np.load(r/name/'outputs.npz',allow_pickle=False) as baseline:
  assert final.keys()==set(baseline.files)
  same=all(v.dtype==baseline[key].dtype and v.shape==baseline[key].shape and v.tobytes()==baseline[key].tobytes() for key,v in final.items());assert same,'Instrumentation changed original output'
 _,residual,bound,_=native.audit_step(before,following,data['forcing'],data['deposition'],data['nitrogen'],actual)
 result=dict(all_original_output_and_next19_bytes_equal=True,original_fields=len(final),iterations=len(counts),residual_m_h_c_n=residual.tolist(),original_bounds=bound.tolist())
except Exception as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:module.run_most_surface=original
if name=='cuda32':engine.xp.cuda.runtime.deviceSynchronize()
else:
 import jax
 jax.effects_barrier()
np.savez_compressed(out/'trace.npz',**flat);unchanged=all(sha(s/n)==v for n,v in m.items());value=dict(scope='Read-only before/after captures inside original MOST loop, exact original second-step input, original outputs/next19 must match uninstrumented counterfactual bitwise. No numerical source or failed trajectory change; atexit bypassed after device barrier and durable receipt.',backend=name,failure=failure,result=result,source_unchanged=unchanged,trace_sha256=sha(out/'trace.npz'),seconds=time.monotonic()-start);native.atomic_json(out/'receipt.json',value);print(json.dumps(dict(backend=name,failure=failure,seconds=value['seconds'],result=result)),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged else 1)

from pathlib import Path
import hashlib,json,re
import numpy as np
r=Path('/home/lhwang/work/noahmp-v1/stem-station-precision-d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();data={}
for name in ['cuda32','jax32']:
 folder=r/(name+'-most-trace');d=json.loads((folder/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and d['result']['all_original_output_and_next19_bytes_equal'] and sha(folder/'trace.npz')==d['trace_sha256']
 with np.load(folder/'trace.npz',allow_pickle=False) as z:data[name]=dict(z)
a,b=data['cuda32'],data['jax32'];assert a.keys()==b.keys();rows=[]
for key,x in a.items():
 y=b[key]
 if np.array_equal(x,y):continue
 assert np.array_equal(np.isinf(x),np.isinf(y)) and not np.isnan(x).any() and not np.isnan(y).any();delta=np.zeros(x.shape,float);np.subtract(x.astype(float),y.astype(float),out=delta,where=np.isfinite(x)&np.isfinite(y));delta=abs(delta);index=np.unravel_index(np.argmax(delta),delta.shape);rows.append(dict(field=key,maximum_absolute=float(delta.max()),index=list(map(int,index)),cuda=float(x[index]),jax=float(y[index])))
fixed=[v for v in rows if v['field'].startswith('fixed/')];iterations=sorted({int(k.split('/')[0]) for k in a if re.match(r'\d+/',k)});first={}
for category,pattern in [('before',r'^\d+/before/'),('surface',r'^\d+/after/surface/'),('feedback',r'^\d+/after/feedback/'),('target',r'^\d+/after/target/'),('atmosphere',r'^\d+/after/atmosphere')]:
 selected=[v for v in rows if re.match(pattern,v['field'])]
 if selected:
  count=min(int(v['field'].split('/')[0]) for v in selected);first[category]=dict(iteration=count,rows=[v for v in selected if int(v['field'].split('/')[0])==count])
d=dict(scope='Read-only per-MOST trace, both instrumented whole-step380 outputs/next19 bitwise identical to uninstrumented originals. Fixed inputs and first divergent iteration/category reported; no numerical fix or failed trajectory advancement.',fixed_input_differences=fixed,iterations=iterations,first_differences=first,all_nonzero=rows);(r/'most-comparison-finite.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(fixed_input_differences=fixed,iterations=iterations,first_differences=first)))

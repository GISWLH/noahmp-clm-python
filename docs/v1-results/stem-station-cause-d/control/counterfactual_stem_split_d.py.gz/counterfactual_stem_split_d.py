from pathlib import Path
import hashlib,json,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';r=b/'stem-station-precision-d';out=r/'canonical-stem-counterfactual';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s/'src'),str(s/'tests'),str(s/'benchmarks')];import run_fluxnet_native as native;import noahmp_clm.gpu.canopy_most_surface as module;import cupy as cp
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
with np.load(r/'jax32-most-trace/trace.npz',allow_pickle=False) as z:canonical={k:z[k] for k in z.files if k.startswith('fixed/')}
engine=native.Backend('cuda32');arrays=tuple(cp.asarray(np.ascontiguousarray(data['a'+str(k)])) for k in range(19));arrays=engine.update_forcing(arrays,data['environment']);before=tuple(engine.host(v) for v in arrays);binding=json.loads((r/'binding.json').read_text());original=module.run_most_surface;calls=[]
def wrapped(*args,**kwargs):
 for k,value in enumerate(args[0]):np.testing.assert_array_equal(cp.asnumpy(value),canonical['fixed/array'+str(k)])
 current=cp.asnumpy(kwargs['stem_area']);np.testing.assert_array_equal(current,data['a16']*.1 if False else current)
 target=canonical['fixed/stem_area'];calls.append(dict(maximum_absolute_input_change=float(abs(current-target).max())))
 kwargs['stem_area']=cp.ascontiguousarray(cp.asarray(target));return original(*args,**kwargs)
module.run_most_surface=wrapped;start=time.monotonic()
try:device=engine.step(*arrays,data['forcing'],environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=native.LeafParameters(**binding['leaf_parameters']),return_surface=True)
finally:module.run_most_surface=original
actual=engine.host(device);following=tuple(engine.host(v) for v in native.next_station_arrays(arrays,device));_,residual,bound,_=native.audit_step(before,following,data['forcing'],data['deposition'],data['nitrogen'],actual);flat={}
def flatten(value,path=''):
 for key,v in value.items():
  if isinstance(v,dict):flatten(v,path+key+'/')
  else:flat[path+key]=np.asarray(v)
flatten(actual);flat.update({'next'+str(k):v for k,v in enumerate(following)});np.savez_compressed(out/'outputs.npz',**flat);failed=[];nonzero=[]
with np.load(r/'jax32/outputs.npz',allow_pickle=False) as z:
 assert flat.keys()==set(z.files)
 for key,x in flat.items():
  y=z[key];delta=float(abs(x.astype(float)-y.astype(float)).max(initial=0.));passed=bool(np.array_equal(x,y)) if x.dtype.kind in 'iub' else bool(np.allclose(x,y,rtol=1e-6,atol=1e-6))
  if delta:nonzero.append(dict(field=key,maximum_absolute=delta))
  if not passed:failed.append(dict(field=key,maximum_absolute=delta))
cp.cuda.runtime.deviceSynchronize();unchanged=all(sha(s/n)==v for n,v in m.items());value=dict(scope='CUDA-only counterfactual: all9 prepared physical arrays equal original JAX inputs; substitute ONLY the saved original JAX stem-area split at MOST entry. Original model source unchanged, original failed trajectory not advanced. Comparison against actual unmodified JAX380 outputs plus next19, original independent MHCN audit.',source_unchanged=unchanged,calls=calls,fields=len(flat),failed=failed,nonzero=nonzero,residual_m_h_c_n=residual.tolist(),original_bounds=bound.tolist(),seconds=time.monotonic()-start,outputs_sha256=sha(out/'outputs.npz'));native.atomic_json(out/'receipt.json',value);print(json.dumps(value),flush=True)

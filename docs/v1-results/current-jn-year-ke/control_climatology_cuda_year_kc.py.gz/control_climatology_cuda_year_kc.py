from pathlib import Path
import hashlib,json,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'climatology-cuda-year-kc';model=b/'ballberry-climatology-cuda-jt';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();failure=None;code=None
try:
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:break
        (r/'waiting-resource.json').write_text(json.dumps(dict(gpu1_free_mib=free,host_available_kib=mem))+'\n');time.sleep(20.)
    command=[sys.executable,'-u',str(b/'run_climatology_cuda_year_kc.py')]
    with (r/'model.log').open('x') as log:p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
    (r/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2)+'\n');code=p.wait();receipt=model/'year-receipt.json';d=json.loads(receipt.read_text()) if receipt.exists() else {};passed=bool(code==0 and d.get('failure') is None and d.get('source_unchanged') and d.get('continued_fields_exact')==23 and d.get('first_continued_step_captured') and d.get('status')=='complete' and d.get('steps_completed')==d.get('steps_requested')==17520 and d.get('device_barrier_complete'))
except Exception as e:passed=False;failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
value=dict(actual_parent_returncode=code,passed=passed,failure=failure,seconds=time.monotonic()-start,receipt_sha256=sha(model/'year-receipt.json') if (model/'year-receipt.json').exists() else None,scope='ActualcurrentJN batched12full17520 parent/compute/barrier status only. Originalgloballedgers/state carried from independentlyverifiedJT48. Separateall365day/12month/observational/SOC/current1e-6/full407 audits required; no scientific/releasepass from parent0.');(r/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True);raise SystemExit(0 if passed else 1)

"""EHPC-only original-library boundary readback. Differences are evidence, not failures."""
from pathlib import Path
import json
import math
import os
import socket
import subprocess
import sys

assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
from noahmp_clm.physics.snowpack import LF,CW,TF
import saturated_drainage_pb as pb


def save(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')


def real_state(theta,temperature,satdk=1.e-5):
    p=SoilParams(satdk=satdk);dz=np.full(4,.5);w=np.array(theta)*1000.*dz
    return SoilEnthalpyState(w,enthalpy_and_capacity(w,np.array(temperature),dz,p)[0],dz,p)


def records(raw):
    result=[]; rediag=None
    for line in raw.decode().splitlines():
        if not line.startswith('PB_OFFICIAL_'):continue
        words=line.split();key=words[0].removeprefix('PB_OFFICIAL_')
        if key=='STEP':
            result.append(dict(step=int(words[1]),clock_step=int(words[2])))
        elif key=='FINAL_REDIAG':rediag=[float(v) for v in words[1:]]
        else:
            assert result and key not in result[-1]
            result[-1][key]=[float(v) for v in words[1:]]
    assert rediag is not None
    return result,rediag


root,exe=Path(sys.argv[1]),Path(sys.argv[2]);root.mkdir(exist_ok=False)
profiles=[]
for nsteps in (1,4,16):
    profiles.append(dict(name='main_crosslayer_'+str(nsteps),dt=172800//nsteps,nsteps=nsteps,
        theta=[.45]*4,temperature=[290.]*4,baseflow=.001,satdk=1.e-5,
        purpose='Unfrozen connected front: same two-day interval, diagnosed once then migrated front retained.'))
profiles.extend([
    dict(name='perched_cross_donors_exhausted',dt=86400,nsteps=1,theta=[.39,.43,.4,.2],
        temperature=[280.,280.,270.,280.],baseflow=0.,satdk=10.,
        purpose='Deliberately extreme 10 m/s conductivity as a donor/cap stress fixture, not a physically calibrated soil or field validation.'),
    dict(name='watmin_dry',dt=1800,nsteps=1,liquid=[0.]*4,ice=[0.]*4,
        temperature=[280.]*4,baseflow=0.,satdk=1.e-5,
        purpose='Zero drainage rate isolates original watmin redistribution/negative-outlet compensation.'),
    dict(name='liquid_excess',dt=1800,nsteps=1,liquid=[275.]*4,ice=[0.]*4,
        temperature=[280.]*4,baseflow=0.,satdk=1.e-5,
        purpose='Deliberate transient oversaturation outside NM SoilEnthalpyState domain; isolate original bucket/surface stock routing.'),
    dict(name='ice_excess',dt=1800,nsteps=1,liquid=[.01,225.,225.,225.],ice=[260.,0.,0.,0.],
        temperature=[270.,280.,280.,280.],baseflow=0.,satdk=1.e-5,
        purpose='Deliberate top ice excess outside NM SoilEnthalpyState domain; isolate original solid outlet, not a PB phase-state comparison.')])
rows=[]
for spec in profiles:
    here=root/spec['name'];here.mkdir()
    if 'theta' in spec:
        state=real_state(spec['theta'],spec['temperature'],spec['satdk'])
        liquid,ice,temperature=state.liquid,state.ice,state.temperature
    else:
        liquid,ice,temperature=[np.array(spec[k],float) for k in ('liquid','ice','temperature')]
    dt=spec['dt'];slope=.2
    lines=[f"{dt} {math.degrees(slope):.17g} {spec['baseflow']:.17g} {spec['nsteps']}"]
    for j in range(4):
        lines.append(' '.join(format(float(v),'.17g') for v in
            (.5,.45,5.5,355.,spec['satdk']*1000.,liquid[j],ice[j],temperature[j])))
    fixture=here/'fixture.txt';fixture.write_text('\n'.join(lines)+'\n')
    save(here/'profile.json',spec)
    result=subprocess.run([str(exe),str(fixture)],cwd=here,capture_output=True,timeout=30)
    (here/'official.stdout.txt').write_bytes(result.stdout);(here/'official.stderr.txt').write_bytes(result.stderr)
    save(here/'official-exit.json',dict(actual_parent_returncode=result.returncode))
    assert result.returncode==0,result.stderr.decode(errors='replace')
    steps,rediag=records(result.stdout)
    assert len(steps)==spec['nsteps']
    np.testing.assert_array_equal(steps[0]['INITIAL_LIQ'],liquid)
    np.testing.assert_array_equal(steps[0]['INITIAL_ICE'],ice)
    independent=[]
    for i,one in enumerate(steps):
        assert one['step']==i+1
        assert all(math.isfinite(x) for k,v in one.items() if isinstance(v,list) for x in v)
        np.testing.assert_array_equal(one['TEMPERATURE'],temperature)
        if i:
            assert one['clock_step']==steps[i-1]['clock_step']+1
            for initial,final in [('INITIAL_LIQ','FINAL_LIQ'),('INITIAL_ICE','FINAL_ICE')]:
                np.testing.assert_array_equal(one[initial],steps[i-1][final])
            np.testing.assert_array_equal(one['INITIAL_OTHER'],steps[i-1]['OTHER'][:3])
        # q_drain already includes q_rsub_sat: never count it twice.
        # qcharge is printed as an internal diagnostic, not an external flux.
        initial=[*one['INITIAL_LIQ'],*one['INITIAL_ICE'],*one['INITIAL_OTHER'][:2]]
        final=[*one['FINAL_LIQ'],*one['FINAL_ICE'],*one['OTHER'][:2]]
        outlet=dt*(one['PERCHED'][0]+one['MAIN'][0]+one['OTHER'][4]+one['OTHER'][5])
        residual=math.fsum([*final,*(-v for v in initial),outlet])
        bound=128.*np.finfo(float).eps*max(math.fsum(abs(v) for v in initial+final)+abs(outlet),1.)
        assert abs(residual)<=bound,(spec['name'],residual,bound)
        perch=np.array(one['INITIAL_LIQ'])-one['AFTER_PERCH_LIQ']
        main_change=np.array(one['AFTER_PERCH_LIQ'])-one['FINAL_LIQ']
        correction_active=(one['INITIAL_OTHER']!=one['OTHER'][:3] or any(x!=0. for x in one['OTHER'][3:])
            or one['INITIAL_ICE']!=one['FINAL_ICE'])
        independent.append(dict(step=i+1,water_residual_kg_m2=residual,water_bound_kg_m2=bound,
            reported_perched_outlet_kg_m2=dt*one['PERCHED'][0],reported_drain_kg_m2=dt*one['MAIN'][0],
            rsub_sat_included_in_drain_kg_m2=dt*one['OTHER'][3],ice_outlet_kg_m2=dt*one['OTHER'][4],
            qrgwl_outlet_kg_m2=dt*one['OTHER'][5],surface_stock_change_kg_m2=one['OTHER'][0]-one['INITIAL_OTHER'][0],
            WA_stock_change_kg_m2=one['OTHER'][1]-one['INITIAL_OTHER'][1],qcharge_before_after=[one['INITIAL_OTHER'][2],one['OTHER'][2]],
            actual_perched_layer_export_kg_m2=perch.tolist(),
            independent_perched_donor_heat_j_m2=(perch*(LF+CW*(temperature-TF))).tolist(),
            post_perch_to_final_net_liquid_change_kg_m2=main_change.tolist(),
            main_change_not_asserted_export_when_corrected=bool(correction_active),correction_channels_active=bool(correction_active),
            negative_drain_is_correction_compensation_not_aquifer_supply=bool(one['MAIN'][0]<0.)))
    row=dict(name=spec['name'],spec=spec,official_parent_returncode=0,steps=steps,independent_water_ledger=independent,
        total_reported_perched_kg_m2=math.fsum(x['reported_perched_outlet_kg_m2'] for x in independent),
        total_reported_drain_kg_m2=math.fsum(x['reported_drain_kg_m2'] for x in independent),
        final_liquid_kg_m2=steps[-1]['FINAL_LIQ'],final_ice_kg_m2=steps[-1]['FINAL_ICE'],
        final_reported_migrating_main_front_m=steps[-1]['MAIN'][1],final_reported_migrating_perched_front_m=steps[-1]['PERCHED'][1],
        final_rediagnosed_theta_main_perched_frost_m=rediag,
        heat_scope='Only actual pre/post-perch donor mass times fixed supplied donor T; original hydrology has no energy equation. Corrected main layer changes are not labelled donor heat.')
    save(here/'readout.json',row);rows.append(row)

# One new PB-c unfrozen integration over the same interval: original official
# one/four/sixteen-step results remain the independent discrete reference.
s=real_state([.45]*4,[290.]*4)
after,z,ledger=pb.advance_saturated_band(s,172800.,.5,2.,'saturated',pb.DrainageParameters(2.,.2))
convergence=[]
for row in rows[:3]:
    final=np.array(row['final_liquid_kg_m2'])+row['final_ice_kg_m2']
    convergence.append(dict(official_steps=row['spec']['nsteps'],official_dt=row['spec']['dt'],
        official_front_m=row['final_reported_migrating_main_front_m'],pb_front_m=z,
        front_absolute_difference_m=abs(row['final_reported_migrating_main_front_m']-z),
        original_official_final_water=final.tolist(),pb_final_water=after.water.tolist(),
        layer_water_difference=(after.water-final).tolist(),official_total_kg_m2=row['total_reported_drain_kg_m2'],
        pb_total_kg_m2=ledger['drained_kg_m2'],total_relative_difference=ledger['drained_kg_m2']/row['total_reported_drain_kg_m2']-1.))
save(root/'comparisons.json',dict(execution_succeeded=True,profiles=rows,unfrozen_discrete_step_comparison=convergence,
    pb_unfrozen_water_residual=ledger['water_residual_kg_m2'],pb_unfrozen_water_bound=ledger['water_bound_kg_m2'],
    pb_unfrozen_heat_residual=ledger['energy_residual_j_m2'],pb_unfrozen_heat_bound=ledger['energy_bound_j_m2'],
    official_processes=7,official_drainage_steps=25,numpy_component_integrations=1,coupled_column_runs=0,
    physical_acceptance=False,scope='Boundary truth and correction channels; no automatic acceptance from process success or stress-parameter use.'))
print(json.dumps(dict(execution_succeeded=True,profiles=7,official_drainage_steps=25,numpy_component_integrations=1)))

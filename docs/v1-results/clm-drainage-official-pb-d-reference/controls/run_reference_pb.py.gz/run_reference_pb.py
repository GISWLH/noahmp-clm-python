"""PBS-only link of a small caller to unchanged official objects and seven boundary profiles."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE=Path('/tmp/noahmp-clm-drainage-official-pb-d')
BASE=Path('/home/zhangyq/noahmp-v1')
sha=lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def main():
    assert socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
    root=Path(sys.argv[1]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir(); started=time.monotonic()
    receipt=dict(passed=False,pbs_job=os.environ['PBS_JOBID'],node=socket.gethostname(),stages=[],
        component_physics_runs=0,coupled_column_runs=0,GPU_tasks=0,official_implementation_changed=False,
        official_stubs=False,physics_acceptance=False)
    try:
        index=json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/n).read_bytes())==h for n,h in index.items())
        shutil.copytree(STAGE/'controls',root/'controls')
        controls=json.loads((root/'controls/CONTROLS_SHA256.json').read_bytes())
        assert all(sha((root/'controls'/n).read_bytes())==h for n,h in controls.items())
        source=root/'source';source.mkdir()
        archive=STAGE/'source.tar.gz'
        assert sha(archive.read_bytes())=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
        with tarfile.open(archive) as tar:
            tar.extractall(source,filter='data')
        source_index=json.loads((source/'SOURCE_SHA256.json').read_bytes())
        assert len(source_index)==584 and all(sha((source/n).read_bytes())==h for n,h in source_index.items())
        build=BASE/'ctsm-case-build-h/case-configuration-private.tar.gz'
        assert sha(build.read_bytes())=='fff6b1645893854d8a8edc30be80b9be8b562a506eebe021b3a6fdd7d5604781'
        official=root/'official';official.mkdir();objects={}
        with tarfile.open(build) as tar:
            for item in tar:
                if item.isfile() and (item.name.endswith('.mod') or item.name.endswith('.a')):
                    raw=tar.extractfile(item).read()
                    target=official/item.name
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
                    objects[item.name]=dict(sha256=sha(raw),bytes=len(raw))
        save(root/'official-object-identity.json',objects)
        toolchain=root/'toolchain';toolchain.mkdir()
        portable=BASE/'ctsm-portable-env-b.tar.gz'
        assert sha(portable.read_bytes())=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
        with tarfile.open(portable) as tar:tar.extractall(toolchain,filter='data')
        env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('PYTHONPATH',None)
        env.update(PATH=str(toolchain/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(toolchain/'lib'),
                   OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
        def execute(name,command,timeout,run_env=env):
            begun=time.monotonic()
            save(root/(name+'-command.json'),list(map(str,command)))
            with (root/(name+'.stdout.txt')).open('wb') as out,(root/(name+'.stderr.txt')).open('wb') as err:
                result=subprocess.run(command,cwd=root,env=run_env,stdout=out,stderr=err,timeout=timeout)
            receipt['stages'].append(dict(name=name,actual_parent_returncode=result.returncode,seconds=time.monotonic()-begun))
            assert result.returncode==0, name+' failed; original stderr retained'
        execute('relocate',[str(toolchain/'bin/python'),str(toolchain/'bin/conda-unpack')],90)
        compiler=toolchain/'bin/x86_64-conda-linux-gnu-gfortran'
        execute('compiler-version',[str(compiler),'--version'],15)
        modules=sorted({str(p.parent) for p in official.rglob('*.mod')})
        libraries={}
        for path in sorted(official.rglob('*.a')):
            if path.name in libraries:
                assert sha(path.read_bytes())==sha(libraries[path.name].read_bytes())
            else:libraries[path.name]=path
        # Original support archives resolve the original module dependencies;
        # no stub or replacement routine is supplied by this caller.
        exe=root/'drainage_caller'
        command=[str(compiler),'-ffree-line-length-none',*[v for d in modules for v in ('-I',d)],
            str(root/'controls/drainage_caller.f90'),'-o',str(exe),'-Wl,--start-group',
            *map(str,libraries.values()),'-Wl,--end-group','-L'+str(toolchain/'lib'),
            '-Wl,-rpath,'+str(toolchain/'lib'),'-lnetcdff','-lnetcdf','-llapack','-lblas','-lstdc++','-lm']
        execute('compile-original-caller',command,180)
        receipt['caller_executable_sha256']=sha(exe.read_bytes())
        execute('caller-linkage',['ldd',str(exe)],15)
        assert 'not found' not in (root/'caller-linkage.stdout.txt').read_text()
        compare_env=env.copy();compare_env['PYTHONPATH']=':'.join([str(source/'src'),str(root/'controls'),str(BASE/'test-deps')])
        execute('compare',[sys.executable,'-B',str(root/'controls/compare_official_pb.py'),
            str(root/'comparison'),str(exe)],150,compare_env)
        comparison=json.loads((root/'comparison/comparisons.json').read_bytes())
        assert comparison['execution_succeeded'] and len(comparison['profiles'])==7
        assert all(sha((source/n).read_bytes())==h for n,h in source_index.items())
        assert all(sha((official/n).read_bytes())==v['sha256'] for n,v in objects.items())
        assert all(sha((STAGE/n).read_bytes())==h for n,h in index.items())
        receipt.update(passed=True,profiles=7,component_physics_runs=26,official_processes=7,official_drainage_steps=25,numpy_component_integrations=1,source_and_controls_unchanged=True,
            original_official_objects_unchanged=True,original_build_archive_sha256=sha(build.read_bytes()),
            portable_environment_sha256=sha(portable.read_bytes()),source_manifest_sha256=sha((source/'SOURCE_SHA256.json').read_bytes()),
            controls_manifest_sha256=sha((root/'controls/CONTROLS_SHA256.json').read_bytes()))
    except Exception:
        receipt['error']=traceback.format_exc();(root/'failure.txt').write_text(receipt['error'])
    receipt['seconds']=time.monotonic()-started;save(root/'receipt.json',receipt);print(json.dumps(receipt),flush=True)
    # The fixed original source/build/portable archives are separately retained;
    # results contain per-member hashes, no duplicated toolchain/source payload.
    names=[p for p in root.rglob('*') if p.is_file() and not any(x in p.relative_to(root).parts for x in ('source','official','toolchain'))]
    with tarfile.open(STAGE/'result.tar.gz','w:gz') as tar:
        for path in names:tar.add(path,arcname=path.relative_to(root).as_posix())
    return 0 if receipt['passed'] else 1


if __name__=='__main__':raise SystemExit(main())

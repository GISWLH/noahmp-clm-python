# Additional original-library boundary profiles, PB-d

The three successful 1610 cases are not rerun. The unchanged original compiled
CTSM library is called for seven new explicit synthetic inputs: a two-day
unfrozen main front at one/four/sixteen steps, one deliberately extreme perched
donor exhaustion/cross-layer case, and isolated dry-watmin, liquid excess and
ice excess correction cases. No current soil/forcing/site configuration changes.

The large perched conductivity, 10 m/s, is deliberately outside ordinary soil
interpretation. It makes the donor-exhaustion branch reachable in a bounded
test; it is neither fitted nor offered as a scientific soil parameter. The two
excess fixtures are outside the NM enthalpy state's accepted pore capacity.
They read the original correction semantics rather than forcing invalid stocks
into the NumPy component. No acceptance score is assigned to these stress inputs.

The public original routines are unchanged. The caller only adds a step count,
real clock advancement, per-step raw output, retained diagnostic/front state
between drainage steps, and a separate final theta diagnosis. Diagnostic theta
is computed initially; the migrated front is retained for the isolated temporal
refinement. This does not implement a complete Richards/drainage operator split.

Every step prints and independently accounts for liquid, ice, unchanged supplied
temperature, surface water, WA, qcharge, perched drainage, combined drainage,
rsub_sat, solid excess and qrgwl. q_drain already contains rsub_sat and the ledger
must not double-count it. qcharge is an internal diagnostic, not assumed an
external source. Negative q_drain is retained with its sign. Main layer stock
differences in correction-active cases are not identified as drainage parcels.
Original hydrology returns no energy; only identifiable perched donor mass is
multiplied by the supplied temperature's liquid specific enthalpy.

One unchanged PB-c unfrozen component integration is compared with the three
official step sizes. Process/ledger success does not assert <10% comparison;
the actual layer inventories, fronts, outlets and refinement differences are
reported to decide the next scientific change. No official implementation is
copied into an oracle; no external calls are stubbed. Windows prepares only AST,
hashes and archive bytes; all science and original calls run on EHPC PBS.

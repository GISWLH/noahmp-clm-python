"""Stdlib-only excerpt of already-computed PBS diagnostic JSON, no arrays decoded."""
import json
import socket
import subprocess
import tarfile
from pathlib import Path
assert socket.gethostname()=='manager'
root=Path('/tmp/noahmp-clm-drainage-official-pb-d')
if not (root/'result.tar.gz').exists():
    subprocess.run(['scp','compute002:'+str(root/'result.tar.gz'),str(root/'result.tar.gz')],check=True)
with tarfile.open(root/'result.tar.gz') as tar:
    d=json.load(tar.extractfile('comparison/comparisons.json'))
out={k:d[k] for k in ('unfrozen_discrete_step_comparison','pb_unfrozen_water_residual','pb_unfrozen_water_bound',
                      'pb_unfrozen_heat_residual','pb_unfrozen_heat_bound')}
out['profiles']=[{k:r[k] for k in ('name','total_reported_perched_kg_m2','total_reported_drain_kg_m2',
    'final_liquid_kg_m2','final_ice_kg_m2','final_reported_migrating_main_front_m',
    'final_reported_migrating_perched_front_m','final_rediagnosed_theta_main_perched_frost_m')}
    |dict(last_step_ledger=r['independent_water_ledger'][-1],last_step_raw=r['steps'][-1]) for r in d['profiles']]
(root/'boundary-readout.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

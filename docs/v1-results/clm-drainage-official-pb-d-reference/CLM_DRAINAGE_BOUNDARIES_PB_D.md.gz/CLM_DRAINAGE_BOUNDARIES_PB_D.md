# Original-library boundary readback PB-d

Seven new original-library caller processes completed with parent exit 0 on
EHPC compute002, PBS 1615.manager. The enclosing package requires actual F0 and
Stageout0. The caller compiled in 0.26401673 s, numerical readback/comparison
took 2.31648111 s and the complete worker 20.76365298 s. The original library,
portable environment, NM584 and frozen PB-c identities remained unchanged.
No prior three-profile official result was rerun. There were 25 original
drainage steps and one NumPy component integration, zero coupled columns/GPU.

The main unfrozen profile uses the same initial saturated state and two-day
interval. Each refinement retains the migrated front between original calls,
advances the actual clock, and diagnoses theta only initially and separately
at the final state. It does not mimic a full Richards/drainage operator split.

| Original steps | Original outflow kg/m2 | PB-c outflow kg/m2 | PB relative difference | Front absolute difference m |
|---|---:|---:|---:|---:|
| 1 | 52.5424412038 | 42.5034476448 | -19.1064468% | 0.1895541404 |
| 4 | 43.8752751879 | 42.5034476448 | -3.1266529% | 0.0394994006 |
| 16 | 42.8116941081 | 42.5034476448 | -0.7200053% | 0.0089029755 |

At sixteen original steps, layer water differences PB minus reference are
[0, -0.555812096, +0.864058559, 0] kg/m2. The coarse single step exceeds the
10% total-outflow range; step refinement reduces the discrepancy without a
parameter change. This is evidence of a discrete-step difference, not a reason
to fit the continuous component to the two-day frozen-rate step. In particular,
final migrated and theta levels are separate: the sixteen-step original gives
1.0178781893 m and 0.9860913735 m, respectively. PB's migrated front is
1.0089752138 m. The original three-case 1800 s acceptance remains separate.

The perched donor stress uses an explicitly extreme 10 m/s conductivity and
86400 s interval. It is not an ordinary soil or field-acceptance fixture. The
original drains [0, 214.99, 62.7705442899, 0] kg/m2, limited by actual liquid
above .01 in the second and third layers. Its reported migrating perched front
reaches 1.5 m; final theta diagnosis gives perched=frost=1.25 m. Neither is
silently relabelled as the other. Derived liquid donor heat is
[0, 77962468.67, 20138862.0362, 0] J/m2, using original donor mass and supplied
donor temperatures. The original hydrology routine itself returns no energy.
PB-c's large depleted-perched response has not been numerically paired here;
this profile defines the next discrete-supply/cap comparison before revision.

The three isolated corrective cases establish separate channels:

- Dry watmin: soil gains .04 kg/m2, balanced by **negative** total drainage
  -.04 kg/m2. rsub_sat contributes that same -.04 inside q_drain; it is not an
  extra outlet. WA, qcharge and surface water do not change. It is not aquifer
  water supply and is not a license to add an unaccounted floor in PB.
- Liquid excess: [275,275,275,275] becomes [225,225,225,225] kg/m2, with
  +200 kg/m2 in surface water and zero drainage. These temporary excess stocks
  are outside the accepted NM enthalpy-state domain; they were sent only to the
  original caller. Their net layer loss is not subsurface drainage.
- Ice excess: top ice 260 becomes 224.99 kg/m2, with 35.01 kg/m2 in the solid
  excess outlet, unchanged liquid and zero subsurface drainage. This likewise
  is an explicit correction stress input outside NM's accepted pore capacity.

All 25 step ledgers include liquid+ice+surface+WA and the signed independent
outlets. qcharge is printed but not invented as an external source; q_drain is
not counted again through rsub_sat. Actual water residuals satisfy each saved
roundoff bound. The PB unfrozen run has water residual 9.99200722e-16 against
2.55795385e-11 kg/m2, and heat residual -1.16997398e-8 against 1.13988023e-5 J/m2.
Temperature arrays are raw unchanged hydrology inputs, not an official thermal
prediction. The exposed-channel flag alone cannot prove no internal redistribution:
the perched exhaustion record retains tiny ~1e-14 kg/m2 post-perch watmin transfers
even though all external correction channels are zero. Those raw layer changes
remain labelled net changes, not new drainage parcels.

Next smallest work is to compare the already frozen PB-c depleted-perched
operator with this explicit donor reference, then refine the original perched
time interval if needed to separate temporal/cap semantics from layer supply.
Do not copy the original negative-drain floor or its excess correction into a
liquid-only component blindly: whole-column routing already owns distinct
stocks and must be reviewed at its interface. None of these boundary results
changes a running trajectory, proves station accuracy, or closes the full
single-column hydrology gap.

Primary implementation identity: [pinned original SoilHydrologyMod](https://raw.githubusercontent.com/ESCOMP/CTSM/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/src/biogeophys/SoilHydrologyMod.F90),
used read-only to select public calls and channels. The numerical reference is
the unchanged originally compiled libclm.a, not a copied implementation.

"""After real PR termination, export/download and build one flat evidence package."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile
from deploy_failed_surface_probe_pr import execute, PYTHON

BASE = Path(__file__).resolve().parent
OUT = BASE / 'failed-surface-probe-pr-deployment'
LABEL = 'failed-surface-probe-pr'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    exporter = BASE / 'export_failed_surface_probe_pr.py'
    ast.parse(exporter.read_bytes())
    execute('exporter-upload', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', str(exporter),
                                'xuanze-neiwang:/tmp/export_failed_surface_probe_pr.py'])
    result = execute('export', ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'xuanze-neiwang',
                                PYTHON + ' -B /tmp/export_failed_surface_probe_pr.py'])
    remote = json.loads(result)
    archive_path = BASE / (LABEL + '-remote.tar.gz')
    assert not archive_path.exists()
    execute('archive-download', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20',
                                 'xuanze-neiwang:' + remote['archive'], str(archive_path)])
    body = archive_path.read_bytes()
    assert sha(body) == remote['sha256'] and len(body) == remote['bytes']
    with tarfile.open(fileobj=io.BytesIO(body)) as stream:
        members = stream.getmembers()
        assert all(m.isfile() for m in members) and len({m.name for m in members}) == len(members)
        raw = {m.name:stream.extractfile(m).read() for m in members}
    assert len(raw) == remote['artifacts']
    index = json.loads(raw['artifact-inventory.json'])
    assert set(raw) == set(index) | {'artifact-inventory.json'}
    assert all(sha(raw[n]) == item['sha256'] and len(raw[n]) == item['bytes'] for n, item in index.items())
    launch = json.loads(raw['launch.json'])
    terminal = json.loads(raw['exit.json'])
    receipt = json.loads(raw['result/receipt.json']) if 'result/receipt.json' in raw else None
    assert json.loads((OUT / 'launch.json').read_bytes())['actual_returncode'] == 0
    assert json.loads((OUT / 'launch.stdout').read_bytes()) == launch
    controls = json.loads(raw['CONTROLS_SHA256.json'])
    assert sha(raw['CONTROLS_SHA256.json']) == launch['controls_manifest_sha256']
    assert all(sha(raw[n]) == h for n, h in controls.items())
    all_files = {'run/' + n: b for n, b in raw.items()}
    all_files.update({'deployment/' + p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()})
    for name in ('check_failed_surface_probe_pr_static.py', 'failed-surface-probe-pr-static.json',
                 'deploy_failed_surface_probe_pr.py', 'collect_failed_surface_probe_pr.py',
                 'export_failed_surface_probe_pr.py', 'archive_failed_surface_probe_pr.py'):
        all_files['provenance/' + name] = (BASE / name).read_bytes()
    all_files['remote-package.json'] = (json.dumps(remote, indent=2) + '\n').encode()
    readout = dict(launch_parent_exit=0, actual_worker_wait_returncode=terminal.get('actual_parent_returncode'),
                   controller_OS_exit_code=remote['closure']['process']['controller']['OS_exit_code'],
                   all_processes_stopped_or_zombie=True, diagnostic_capture_complete=terminal.get('diagnostic_capture_complete', False),
                   model_call_passed=False, receipt=receipt, remote_archive_sha256=remote['sha256'],
                   controls_manifest_sha256=launch['controls_manifest_sha256'],
                   scope='One original-source NZ3 reconstructed GPU attempt. Original exception and actual nonzero child retained. No trajectory continuation, model fix, scientific/device acceptance or originally absent failed-input byteexact claim.')
    all_files['readout.json'] = (json.dumps(readout, indent=2) + '\n').encode()
    all_files['artifact-inventory.json'] = (json.dumps({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(all_files.items())},indent=2)+'\n').encode()
    archive = BASE / (LABEL + '-evidence.tar.gz')
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as stream:
        for name, raw_bytes in sorted(all_files.items()):
            item = tarfile.TarInfo(name)
            item.size = len(raw_bytes)
            item.mtime = 0
            stream.addfile(item, io.BytesIO(raw_bytes))
    package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
                   artifacts=len(all_files), actual_launcher_exit=0,
                   actual_worker_exit=terminal.get('actual_parent_returncode'),
                   actual_controller_OS_exit=readout['controller_OS_exit_code'],
                   diagnostic_capture_complete=readout['diagnostic_capture_complete'],
                   scope=readout['scope'])
    (BASE / (LABEL + '-package.json')).write_text(json.dumps(package, indent=2)+'\n')
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()

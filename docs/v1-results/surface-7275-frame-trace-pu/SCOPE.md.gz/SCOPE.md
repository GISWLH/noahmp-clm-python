# PU1688 closed failure frame and separate algebra

Actual PBS F1 / Stageout0. The unchanged Qia reference made one attempt, returned zero, and raised the same original Newton stall at iteration30 / line357. The model's real exit1 was recorded by the PBS shell. Its child receipt remains null for its own exit, as required; the parent exit file is authoritative.

One complete final solver traceback frame is retained as original pickle plus typed JSON/NPZ. All15 original encoded inputs,584 source files and frozen controls remain exact. No trace callback, additional residual evaluation, additional linear solve, full-column step, GPU call or year continuation occurred. Final locals can contain stale branch temporaries; no previous iteration history or root-cause conclusion is claimed.

After the model exited, a separate analysis process returned0. It read only saved typed arrays and reported matrix SVD/rank and stored values. It did not import or call model code. The analysis0 does not replace the model/PBS1 or constitute a scientific pass. All original exceptions, logs, source/input/control identities, frame, analysis output and independent actual exit files are preserved.

Expanded source is omitted from the result tar, while the exact source archive remains in the approved stage's PT111 input. The old20608 pre-I/O-guard preparation is historical and unexecuted; final73a47 prep and a1b146 execution alone were submitted.

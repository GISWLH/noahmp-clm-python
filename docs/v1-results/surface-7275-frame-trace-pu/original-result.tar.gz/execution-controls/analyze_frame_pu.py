"""EHPC post-run algebra on saved PU locals; no physical module import or call."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import time

HERE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    assert os.name != 'nt' and socket.gethostname().split('.')[0] == 'compute002'
    assert os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    assert sys.dont_write_bytecode
    root = args.root.resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve())
    assert (root / 'model-exit.txt').read_text().strip() == '1'
    binding = json.loads((HERE / 'EXECUTION_BINDINGS.json').read_bytes())
    model = root / 'model'
    receipt = json.loads((model / 'receipt.json').read_bytes())
    assert receipt['reference_calls_started'] == 1 and receipt['reference_calls_returned'] == 0
    assert receipt['same_PT_exception_message'] and receipt['same_PT_exception_site']
    assert receipt['final_solver_frames_saved'] == 1 and receipt['immutable_checks_passed']
    assert receipt['controls_manifest_sha256'] == binding['preparation_manifest_sha256']
    assert not receipt['settrace_used'] and not receipt['scientific_acceptance']
    assert receipt['whole_column_calls'] == receipt['GPU_calls'] == receipt['annual_years'] == 0
    assert not any(name in receipt for name in ('frame_preservation_error', 'preservation_error', 'traceback_preservation_error'))
    source = model / 'source-nm'
    manifest = json.loads((source / 'SOURCE_SHA256.json').read_bytes())
    assert len(manifest) == 584 and sha((source / 'SOURCE_SHA256.json').read_bytes()) == binding['source_manifest_sha256']
    source_before = {n: sha((source / n).read_bytes()) for n in manifest}
    assert source_before == manifest
    paths = ['phase-final-frame.json', 'phase-final-frame.npz', 'phase-final-frame.pkl', 'receipt.json',
             'input-before.json', 'input-after.json', 'source-before.json', 'source-after.json', 'traceback.txt']
    packet_before = {n: sha((model / n).read_bytes()) for n in paths}
    assert (model / 'input-before.json').read_bytes() == (model / 'input-after.json').read_bytes()
    assert (model / 'source-before.json').read_bytes() == (model / 'source-after.json').read_bytes()
    metadata = json.loads((model / 'phase-final-frame.json').read_bytes())
    assert metadata['schema'] == 'PT-lossless-return-v1'
    assert metadata['npz_sha256'] == packet_before['phase-final-frame.npz']
    assert metadata['pickle_sha256'] == packet_before['phase-final-frame.pkl']
    # Only the saved typed tree is decoded. The raw pickle remains opaque.
    import numpy as np
    descriptors = {}
    def walk(value):
        if isinstance(value, dict):
            if value.get('kind') == 'array':
                assert value['key'] not in descriptors
                descriptors[value['key']] = value
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(metadata['tree'])
    with np.load(model / 'phase-final-frame.npz', allow_pickle=False) as stream:
        assert set(stream.files) == set(descriptors) and len(stream.files) == metadata['array_count']
        arrays = {k: stream[k] for k in stream.files}
    for key, array in arrays.items():
        desc = descriptors[key]
        assert type(array) is np.ndarray and array.dtype.str == desc['dtype'] and list(array.shape) == desc['shape']
        assert sha(array.tobytes(order='C')) == desc['c_order_sha256']

    def decode(node):
        kind = node['kind']
        if kind == 'array':
            return arrays[node['key']]
        if kind == 'float':
            return float.fromhex(node['hex'])
        if kind in ('int', 'bool', 'str', 'NoneType'):
            return node['value']
        if kind in ('tuple', 'list'):
            return [decode(child) for child in node['items']]
        if kind == 'dict':
            return {k: decode(v) for k, v in node['items'].items()}
        if kind == 'dataclass':
            return {'__original_type__': node['module'] + '.' + node['name'],
                    **{k: decode(v) for k, v in node['fields'].items()}}
        raise TypeError('Unsupported saved node ' + kind)

    frame = decode(metadata['tree'])['frames']
    assert len(frame) == 1 and frame[0]['traceback_line'] == 357
    values = frame[0]['locals']
    started = time.monotonic()
    def readable(value):
        if isinstance(value, np.ndarray):
            finite = bool(np.all(np.isfinite(value))) if value.dtype.kind in 'fciub' else None
            if finite is False:
                # No NaN/Inf replacement: retain tokens and explicitly mark them.
                payload = np.vectorize(lambda v: float(v).hex(), otypes=[str])(value).tolist()
                encoding = 'float.hex tokens preserving nonfinite values'
            else:
                payload = value.tolist()
                encoding = 'JSON values'
            return dict(dtype=value.dtype.str, shape=list(value.shape), finite=finite,
                        payload_sha256=sha(value.tobytes(order='C')), values=payload, encoding=encoding)
        if isinstance(value, np.generic):
            return readable(np.asarray(value))
        if isinstance(value, dict):
            return {k: readable(v) for k, v in value.items()}
        if isinstance(value, list):
            return [readable(v) for v in value]
        if type(value) is float and not np.isfinite(value):
            return dict(nonfinite_float_hex=value.hex())
        return value

    matrices = {}
    for name in ('jac', 'local_jac', 'wide_jac'):
        matrix = values[name]
        assert type(matrix) is np.ndarray and matrix.shape == (12, 12) and matrix.dtype == np.float64
        finite = bool(np.all(np.isfinite(matrix)))
        entry = dict(stored=readable(matrix), svd_executed=False, singular_values=None, rank=None, rank_tolerance=None)
        if finite:
            singular = np.linalg.svd(matrix, compute_uv=False)
            tolerance = float(singular[0] * max(matrix.shape) * np.finfo(matrix.dtype).eps)
            entry.update(svd_executed=True, singular_values=singular.tolist(),
                         rank=int(np.count_nonzero(singular > tolerance)), rank_tolerance=tolerance)
        matrices[name] = entry
    keep = ('iteration', 'max_iterations', 'tolerance', 'n', 'fixed_ground_temperature', 'initial_guess',
            'x', 'iteration_x', 'residual', 'phase_active', 'active', 'mass', 'condensate',
            'lower', 'upper', 'delta', 'local_delta', 'wide_delta', 'norm', 'chosen_norm',
            'accepted', 'restarts', 'restart_available', 'alternative', 'ambient', 'old_res',
            'ambient_res', 'backtrack', 'clipped', 'r', 'rr', 'trial', 'trial_norm', 'fresh', 'depleted')
    selected = {name: readable(values[name]) for name in keep if name in values}
    packet_after = {n: sha((model / n).read_bytes()) for n in paths}
    source_after = {n: sha((source / n).read_bytes()) for n in manifest}
    assert packet_after == packet_before and source_after == source_before
    output = dict(schema='PU-post-run-frame-algebra-v1', post_run_analysis=True, model_functions_called=0,
        additional_evaluate_calls=0, additional_linear_solves=0,
        original_model_exit=1, original_exception=receipt['exception_message'],
        scientific_acceptance=False, original_frame=frame[0]['function'], original_line=357,
        source_files=584, source_before_after_exact=True, packet_before=packet_before, packet_after=packet_after,
        typed_arrays=len(arrays), matrices=matrices, saved_locals=selected,
        missing_optional_locals=[name for name in keep if name not in values],
        rank_definition='count(s > s_max * max(matrix.shape) * float64_eps), diagnostic numerical rank only',
        freshness='Final stored branch locals may be stale; no per-iteration history or causal branch attribution is claimed.',
        seconds=time.monotonic()-started)
    (root / 'post-run-analysis.json').write_text(json.dumps(output, indent=2, allow_nan=False) + '\n')
    print(json.dumps(dict(post_run_analysis=True, original_model_exit=1, matrix_ranks={k:v['rank'] for k,v in matrices.items()},
                          frame_unchanged=True, source_files=584, model_functions_called=0)))


if __name__ == '__main__':
    main()

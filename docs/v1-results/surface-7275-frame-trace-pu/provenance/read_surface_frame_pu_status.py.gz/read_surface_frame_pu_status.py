"""Read and preserve actual PU PBS state; no physics or remote mutation."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'surface-7275-frame-trace-pu-status'


def main():
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    destination = ROOT / stamp
    destination.mkdir(parents=True, exist_ok=False)
    commands = {
        'qstat': ['ssh', 'ehpc', 'qstat -xf 1688.manager'],
        'compute-files': ['ssh', 'ehpc-c2', 'ls -l /tmp/noahmp-surface-frame-trace-pu/result.tar.gz /tmp/noahmp-surface-frame-trace-pu/pbs-exit.txt'],
    }
    facts = {}
    for name, command in commands.items():
        result = subprocess.run(command, capture_output=True, timeout=45)
        (destination / (name + '.stdout')).write_bytes(result.stdout)
        (destination / (name + '.stderr')).write_bytes(result.stderr)
        facts[name] = dict(command=command, actual_exit=result.returncode,
                          stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                          stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
        print(name, result.returncode, result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'))
    (destination / 'commands.json').write_text(json.dumps(facts, indent=2) + '\n')
    print('saved', destination)


if __name__ == '__main__':
    main()

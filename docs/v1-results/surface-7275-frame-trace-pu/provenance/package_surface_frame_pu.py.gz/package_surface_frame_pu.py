"""Metadata/raw-payload closure of PU1688; no NumPy import or numerical rerun."""
import base64
import gzip
import io
import json
from pathlib import Path
import re
import tarfile

from package_surface_reference_pt import files, typed_packet, descriptors, sha, encode

BASE = Path(__file__).resolve().parent
LABEL = 'surface-7275-frame-trace-pu'
STAGE_SHA = '12597edcd66a7c22fd71bf2775f585c2745f780a2c9900c1f84b7a18725cf369'
RESULT_SHA = '10060cb3f72a58296563fafa947e7126fd5edb54c1121bf0081d57c41fede256'
PREP_SHA = '73a47e7a4d31bb69c1ad4f9b04b29072e434affed2a2912a46ecc145ce316419'
EXEC_SHA = 'a1b146cb8d4e11752f766f21466267d12b784c5d6d6a1cf1b8d5d828a3a4f156'


def main():
    raw_stage = (BASE / (LABEL + '-stage.tar.gz')).read_bytes()
    raw_result = (BASE / (LABEL + '-result.tar.gz')).read_bytes()
    assert sha(raw_stage) == STAGE_SHA and sha(raw_result) == RESULT_SHA
    stage = files(raw_stage)
    index = json.loads(stage['stage-inventory.json'])
    assert len(stage) == 17 and set(stage) == set(index) | {'stage-inventory.json'}
    assert all(sha(stage[n]) == h for n, h in index.items())
    assert sha(stage['preparation/CONTROLS_SHA256.json']) == PREP_SHA
    assert sha(stage['execution/CONTROLS_SHA256.json']) == EXEC_SHA
    prep = json.loads(stage['preparation/CONTROLS_SHA256.json'])
    execution = json.loads(stage['execution/CONTROLS_SHA256.json'])
    assert len(prep) == len(execution) == 6
    assert all(sha(stage['preparation/' + n]) == h for n, h in prep.items())
    assert all(sha(stage['execution/' + n]) == h for n, h in execution.items())
    review = json.loads(stage['preparation-independent-review.json'])
    assert review['passed'] and not review['blocking_findings'] and review['controls_manifest_sha256'] == PREP_SHA
    pt_raw = stage['pt-evidence.tar.gz']
    assert sha(pt_raw) == 'e039cc8d055612ef427719f2b0cd93076831f5983c18bde133f388c17c59cbc2'
    pt = files(pt_raw)
    pt_index = json.loads(pt['artifact-inventory.json'])
    assert len(pt) == 111 and set(pt) == set(pt_index) | {'artifact-inventory.json'}
    assert all(sha(pt[n]) == h['sha256'] and len(pt[n]) == h['bytes'] for n, h in pt_index.items())
    pt_stage = files(pt['executed-stage.tar.gz'])
    source = files(pt_stage['source.tar.gz'])
    manifest = json.loads(source['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and all(sha(source[n]) == h for n, h in manifest.items())
    original = files(raw_result, directories=True)
    assert len(original) == 42
    assert original['model-exit.txt'].strip() == original['pbs-command-exit.txt'].strip() == b'1'
    assert original['analysis-exit.txt'].strip() == original['setup-exit.txt'].strip() == original['stage-after-exit.txt'].strip() == b'0'
    assert original['stage-inventory.json'] == stage['stage-inventory.json']
    for name in ('stage-before.json', 'stage-after.json'):
        check = json.loads(original[name])
        assert check['passed'] and not check['mismatches'] and check['actual'] == check['expected'] == index
    for name in ['CONTROLS_SHA256.json', *prep]:
        assert original['model/controls/' + name] == stage['preparation/' + name]
    for name in ['CONTROLS_SHA256.json', *execution]:
        assert original['execution-controls/' + name] == stage['execution/' + name]
    receipt = json.loads(original['model/receipt.json'])
    assert receipt['pbs_job'] == '1688.manager' and receipt['row'] == 0
    assert receipt['reference_calls_started'] == 1 and receipt['reference_calls_returned'] == 0
    assert receipt['actual_child_returncode'] is None  # authoritative real wait is the shell exit file
    assert receipt['final_solver_frames_saved'] == 1 and receipt['solver_traceback_lines'] == [357]
    assert receipt['same_PT_exception_site'] and receipt['same_PT_exception_message']
    assert receipt['exception_message'] == 'Canopy phase Newton stalled at iteration 30: residual=13.75804 W/m2'
    assert receipt['exception_message'] in original['model/traceback.txt'].decode()
    assert receipt['exception_message'] in original['model.stderr'].decode()
    assert receipt['immutable_checks_passed'] and receipt['controls_manifest_sha256'] == PREP_SHA
    assert not receipt['scientific_acceptance'] and not receipt['settrace_used']
    assert receipt['whole_column_calls'] == receipt['GPU_calls'] == receipt['annual_years'] == 0
    assert receipt['additional_evaluate_calls'] == receipt['additional_linear_solves'] == 0
    assert not any(k in receipt for k in ('preservation_error', 'frame_preservation_error', 'traceback_preservation_error'))
    assert json.loads(original['model/source-before.json']) == json.loads(original['model/source-after.json']) == manifest
    inputs = json.loads(original['model/input-before.json'])
    assert len(inputs) == 15 and inputs == json.loads(original['model/input-after.json'])
    pr = files(original['model/pr-evidence.tar.gz'])
    assert original['model/pr-evidence.tar.gz'] == pt_stage['pr-evidence.tar.gz']
    captured = json.loads(pr['run/result/surface/call-0001/kernel-input.json'])
    encoded = captured['tree']['items']['arguments_without_output']['items']
    assert len(encoded) == 15
    assert inputs == [dict(dtype=r['dtype'], shape=r['shape'], payload_sha256=r['c_order_sha256']) for r in encoded]
    metadata = json.loads(original['model/phase-final-frame.json'])
    assert typed_packet(original['model/phase-final-frame.npz'], metadata) == 214
    assert sha(original['model/phase-final-frame.pkl']) == metadata['pickle_sha256']
    analysis = json.loads(original['post-run-analysis.json'])
    assert analysis['original_model_exit'] == 1 and not analysis['scientific_acceptance']
    assert analysis['model_functions_called'] == analysis['additional_evaluate_calls'] == analysis['additional_linear_solves'] == 0
    assert analysis['packet_before'] == analysis['packet_after']
    assert all(sha(original['model/' + name]) == h for name, h in analysis['packet_before'].items())
    assert analysis['source_files'] == 584 and analysis['source_before_after_exact']
    assert analysis['typed_arrays'] == 214
    expected = descriptors(metadata['tree'])
    for name, row in analysis['matrices'].items():
        desc = expected['return/frames/0/locals/' + name]
        stored = row['stored']
        assert stored['payload_sha256'] == desc['c_order_sha256']
        assert stored['shape'] == desc['shape'] == [12, 12] and stored['dtype'] == desc['dtype'] == '<f8'
        assert stored['finite'] and row['svd_executed'] and row['rank'] == 12 and len(row['singular_values']) == 12
    assert json.loads(original['analysis.stdout'])['matrix_ranks'] == {k: 12 for k in ('jac', 'local_jac', 'wide_jac')}
    assert original['analysis.stderr'] == b''
    closure = BASE / (LABEL + '-closure')
    qstat = (closure / 'qstat.stdout').read_text()
    assert re.search(r'job_state = F\b', qstat) and 'Exit_status = 1' in qstat and 'Stageout_status = 0' in qstat
    items = {'result/' + n: b for n, b in original.items()}
    for host in ('manager', 'compute'):
        remote = json.loads((closure / (host + '.stdout')).read_bytes())
        command = json.loads((closure / (host + '.json')).read_bytes())
        assert command['actual_exit'] == 0 and remote['all_stage_immutable']
        assert remote['stage_files_before'] == remote['stage_files_after'] == index
        if host == 'compute':
            assert remote['result_archive_sha256'] == RESULT_SHA
            assert base64.b64decode(remote['files']['pbs-exit.txt']).strip() == b'1'
        for name, raw in remote['files'].items():
            items['closed-' + host + '/' + name] = base64.b64decode(raw)
    assert json.loads((closure / 'qstat.json').read_bytes())['actual_exit'] == 0
    assert json.loads(items['closed-manager/dispatch.json'])['stage_sha256'] == STAGE_SHA
    readout = dict(pbs_job='1688.manager', job_state='F', PBS_exit=1, Stageout_status=0,
        actual_model_exit=1, actual_post_run_analysis_exit=0,
        original_exception=receipt['exception_message'], model_seconds=receipt['seconds'],
        analysis_seconds=analysis['seconds'], reference_calls_started=1, reference_calls_returned=0,
        extra_evaluate_calls=0, extra_linear_solves=0, GPU_calls=0, full_column_calls=0,
        matrices={k: {n: v for n, v in row.items() if n != 'stored'} for k, row in analysis['matrices'].items()},
        saved_locals=analysis['saved_locals'], rank_definition=analysis['rank_definition'],
        freshness=analysis['freshness'], scientific_acceptance=False,
        note='All numbers are read from original EHPC JSON, not recomputed on Windows. No cause is inferred from a final frame.')
    verification = dict(passed=True, scope='Stdlib closed raw-hash/header/exit verification only; model remains failed.',
        preparation_manifest_sha256=PREP_SHA, execution_manifest_sha256=EXEC_SHA,
        stage_sha256=STAGE_SHA, original_result_sha256=RESULT_SHA,
        source_files=584, source_before_after_exact=True,
        actual_model_exit=1, actual_analysis_exit=0, actual_PBS_exit=1, actual_Stageout_status=0,
        original_result_files=42, original_input_arrays=15, input_before_after_exact=True,
        original_frame_packets=1, typed_array_descriptors=214, opaque_pickle_hash_exact=True,
        original_frame_preserved_by_analysis=True,
        remote_source_present=json.loads((closure / 'compute.stdout').read_bytes())['original_source_present'],
        PBS_output_present=json.loads((closure / 'manager.stdout').read_bytes())['actual_presence']['pbs-output.log'])
    (BASE / (LABEL + '-readout.json')).write_bytes(encode(readout))
    (BASE / (LABEL + '-verification.json')).write_bytes(encode(verification))
    items['readout.json'] = encode(readout)
    items['verification.json'] = encode(verification)
    items['original-result.tar.gz'] = raw_result
    items['executed-stage.tar.gz'] = raw_stage
    for directory in (BASE / (LABEL + '-deployment'), closure):
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                items[directory.name + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
    for name in ('prepare_surface_frame_trace_pu.py', 'prepare_surface_frame_pu_execution.py',
                 'surface-7275-frame-trace-pu-static.json', 'surface-7275-frame-trace-pu-execution-static.json',
                 'surface-7275-frame-trace-pu-before-io-guard-controls.json', 'surface-7275-frame-trace-pu-before-io-guard.py',
                 'surface-7275-frame-trace-pu-independent-review-rg.json', 'review_surface_frame_trace_pu_rg.py',
                 'deploy_surface_frame_pu.py', 'read_surface_frame_pu_status.py', 'read_surface_frame_pu_closed.py',
                 'collect_surface_frame_pu_closed.py', 'package_surface_frame_pu.py', 'package_surface_reference_pt.py'):
        items['provenance/' + name] = (BASE / name).read_bytes()
    items['SCOPE.md'] = b'''# PU1688 closed failure frame and separate algebra\n\nActual PBS F1 / Stageout0. The unchanged Qia reference made one attempt, returned zero, and raised the same original Newton stall at iteration30 / line357. The model's real exit1 was recorded by the PBS shell. Its child receipt remains null for its own exit, as required; the parent exit file is authoritative.\n\nOne complete final solver traceback frame is retained as original pickle plus typed JSON/NPZ. All15 original encoded inputs,584 source files and frozen controls remain exact. No trace callback, additional residual evaluation, additional linear solve, full-column step, GPU call or year continuation occurred. Final locals can contain stale branch temporaries; no previous iteration history or root-cause conclusion is claimed.\n\nAfter the model exited, a separate analysis process returned0. It read only saved typed arrays and reported matrix SVD/rank and stored values. It did not import or call model code. The analysis0 does not replace the model/PBS1 or constitute a scientific pass. All original exceptions, logs, source/input/control identities, frame, analysis output and independent actual exit files are preserved.\n\nExpanded source is omitted from the result tar, while the exact source archive remains in the approved stage's PT111 input. The old20608 pre-I/O-guard preparation is historical and unexecuted; final73a47 prep and a1b146 execution alone were submitted.\n'''
    inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in sorted(items.items())}
    items['artifact-inventory.json'] = encode(inventory)
    target = BASE / (LABEL + '-evidence.tar.gz')
    assert not target.exists()
    with target.open('wb') as file, gzip.GzipFile(fileobj=file, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
        for name, raw in sorted(items.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
    assert files(target.read_bytes()) == items
    package = dict(label=LABEL, archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
        artifacts=len(items), members=len(items), scope='PU1688 actual F1/Stageout0; original Qia failure frame, model1 and separate post-run algebra0. No extra physical evaluation/GPU/year; no scientific pass.', verification=verification)
    (BASE / (LABEL + '-package.json')).write_bytes(encode(package))
    print(json.dumps(package))


if __name__ == '__main__':
    main()

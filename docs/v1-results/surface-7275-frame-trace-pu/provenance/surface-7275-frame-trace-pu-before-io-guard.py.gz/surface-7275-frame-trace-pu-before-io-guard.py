"""One unchanged PT-b Qia attempt; preserve the original exception frame only."""
import argparse
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import tarfile
import time
import traceback

HERE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        members = stream.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and
                   '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: stream.extractfile(m).read() for m in members}


def authenticate(pt_path, binding):
    raw = pt_path.read_bytes()
    assert sha(raw) == binding['PT_archive_sha256']
    files = unpack(raw)
    inventory = json.loads(files['artifact-inventory.json'])
    assert len(files) == 111 and set(inventory) == set(files) - {'artifact-inventory.json'}
    assert all(sha(files[n]) == row['sha256'] and len(files[n]) == row['bytes'] for n, row in inventory.items())
    terminal = files['surface-7275-numpy-reference-pt-closure/qstat.stdout'].decode()
    assert 'Job Id: 1681.manager' in terminal
    assert all(text in terminal for text in ('job_state = F', 'Stageout_status = 0', 'Exit_status = 1'))
    assert files['closed-compute/pbs-exit.txt'].strip() == b'1'
    prior = json.loads(files['result/receipt.json'])
    assert prior['pbs_job'] == '1681.manager'
    assert [x['actual_child_returncode'] for x in prior['actual_children']] == [1, 0, 0]
    assert not any(x['timed_out'] for x in prior['actual_children'])
    qia = json.loads(files['result/row-0/receipt.json'])
    assert qia['surface_step_calls_started'] == 1 and qia['surface_step_calls_returned'] == 0
    assert binding['expected_exception'] in qia['exception_traceback']
    assert sha(files['executed-stage.tar.gz']) == binding['PT_executed_stage_sha256']
    stage = unpack(files['executed-stage.tar.gz'])
    stage_manifest = json.loads(stage['stage-inventory.json'])
    assert set(stage_manifest) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[n]) == h for n, h in stage_manifest.items())
    for name in ('run_reference_pt.py', 'surface_reference.py', 'BINDINGS.json'):
        expected = files['result/controls/' + name]
        assert stage['controls/' + name] == expected == (HERE / 'pt' / name).read_bytes()
        assert sha(expected) == binding['PT_reused_controls'][name]
    for label in ('before', 'after'):
        assert sha(files['result/source-' + label + '.json']) == binding['PT_source_hash_record_sha256'][label]
    return files, stage


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pt', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args_cli = parser.parse_args()
    # Enforce the compute-only scope BEFORE any scientific import or unpack.
    assert os.name != 'nt' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode
    assert socket.gethostname().split('.')[0] == 'compute002'
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    assert all(os.environ.get(k) == '1' for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'))
    root = args_cli.output.resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
    controls = json.loads((HERE / 'CONTROLS_SHA256.json').read_bytes())
    assert all(sha((HERE / n).read_bytes()) == h for n, h in controls.items())
    files, stage = authenticate(args_cli.pt, binding)
    root.mkdir()
    shutil.copytree(HERE, root / 'controls')
    source = root / 'source-nm'
    source_bytes = unpack(stage['source.tar.gz'])
    manifest = json.loads(source_bytes['SOURCE_SHA256.json'])
    assert sha(stage['source.tar.gz']) == binding['source_archive_sha256']
    assert sha(source_bytes['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
    assert len(manifest) == 584 and set(source_bytes) == set(manifest) | {'SOURCE_SHA256.json'}
    assert all(sha(source_bytes[n]) == h for n, h in manifest.items())
    for name, raw in source_bytes.items():
        target = source / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    pr_path = root / 'pr-evidence.tar.gz'
    pr_path.write_bytes(stage['pr-evidence.tar.gz'])
    sys.path.insert(0, str(HERE / 'pt'))
    import run_reference_pt as pt
    import surface_reference as ref
    pt_binding = json.loads((HERE / 'pt/BINDINGS.json').read_bytes())
    capture, context = pt.authenticate_pr(pr_path, pt_binding)
    ref.bind_source(source)
    args, _, _ = pt.captured_inputs(capture, pt_binding)
    from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
    phase_path = source / binding['phase_source_relative_path']
    assert sha(phase_path.read_bytes()) == binding['phase_source_sha256']
    assert Path(solve_canopy_phase_energy.__code__.co_filename).resolve() == phase_path.resolve()
    assert sys.gettrace() is None
    before_inputs = [ref.array_identity(a) for a in args]
    before_source = {n: sha((source / n).read_bytes()) for n in manifest}
    save(root / 'source-before.json', before_source)
    save(root / 'input-before.json', before_inputs)
    for name in ('result/row-0/receipt.json', 'result/row-0/traceback.txt', 'result/receipt.json'):
        (root / ('PT-' + name.replace('/', '-'))).write_bytes(files[name])
    record = dict(pbs_job=os.environ['PBS_JOBID'], host=socket.gethostname(), row=0,
                  case=context['cases'][0], reference_calls_started=0, reference_calls_returned=0,
                  whole_column_calls=0, GPU_calls=0, annual_years=0,
                  PT_archive_sha256=binding['PT_archive_sha256'], original_PT_PBS_exit=1,
                  source_manifest_sha256=binding['source_manifest_sha256'],
                  controls_manifest_sha256=sha((HERE / 'CONTROLS_SHA256.json').read_bytes()),
                  actual_child_returncode=None, scientific_acceptance=False,
                  final_solver_frames_saved=0, phase_invocation_count=None,
                  phase_invocation_count_note='No per-call observer; traceback contains only the failing invocation',
                  additional_evaluate_calls=0, additional_linear_solves=0,
                  settrace_used=False)
    started = time.monotonic()
    original_error = None
    try:
        record['reference_calls_started'] += 1
        value = ref.reference_one(source, args[:9], 0, coefficients=args[12], profiled=False,
                                  exchange_extension=args[9], vic=args[10], stem_area=None, canopy_optics=None)
        record['reference_calls_returned'] += 1
        pt.dump_return(root / 'unexpected-original-return', value)
    except BaseException as error:
        original_error = error
        record['exception_type'] = type(error).__name__
        record['exception_message'] = str(error)
        record['same_PT_exception_message'] = type(error) is RuntimeError and str(error) == binding['expected_exception']
        (root / 'traceback.txt').write_text(traceback.format_exc())
        try:
            frames = []
            current = error.__traceback__
            while current is not None:
                frame = current.tb_frame
                if frame.f_code is solve_canopy_phase_energy.__code__:
                    # Snapshot only the already-unwound original solver frame.
                    # No f_locals assignment, property evaluation or function
                    # invocation: evaluate itself is excluded, never called.
                    loc = dict(frame.f_locals)
                    callables = {}
                    for name, obj in loc.items():
                        if callable(obj):
                            code = getattr(obj, '__code__', None)
                            callables[name] = dict(module=getattr(obj, '__module__', None),
                                name=getattr(obj, '__qualname__', type(obj).__name__),
                                code_file=None if code is None else code.co_filename,
                                code_first_line=None if code is None else code.co_firstlineno)
                    values = copy.deepcopy({name: obj for name, obj in loc.items() if name not in callables})
                    frames.append(dict(function=frame.f_code.co_name,
                        file=frame.f_code.co_filename, traceback_line=current.tb_lineno,
                        source_sha256=binding['phase_source_sha256'],
                        excluded_callables=callables, locals=values,
                        freshness='Final stored locals only. Branch temporaries may be from earlier branches/iterations; no per-line history is claimed.'))
                current = current.tb_next
            pt.dump_return(root / 'phase-final-frame', dict(frames=frames,
                capture='Original exception traceback, after solver unwound; no trace callbacks',
                additional_evaluate_calls=0, additional_linear_solves=0))
            record['final_solver_frames_saved'] = len(frames)
            record['solver_traceback_lines'] = [f['traceback_line'] for f in frames]
            record['same_PT_exception_site'] = len(frames) == 1 and frames[0]['traceback_line'] == 357
        except BaseException:
            record['frame_preservation_error'] = traceback.format_exc()
        raise
    finally:
        # Preservation errors are separately recorded; they never replace the
        # actual solver exception already propagating out of this try block.
        try:
            after_inputs = [ref.array_identity(a) for a in args]
            after_source = {n: sha((source / n).read_bytes()) for n in manifest}
            save(root / 'source-after.json', after_source)
            save(root / 'input-after.json', after_inputs)
            record.update(source_before_after_exact=before_source == after_source == manifest,
                input_before_after_exact=before_inputs == after_inputs,
                PT_archive_after_sha256=sha(args_cli.pt.read_bytes()),
                PR_archive_after_sha256=sha(pr_path.read_bytes()),
                controls_after_exact=all(sha((HERE / n).read_bytes()) == h for n, h in controls.items()),
                controls_manifest_after_sha256=sha((HERE / 'CONTROLS_SHA256.json').read_bytes()),
                trace_still_absent=sys.gettrace() is None)
            record['immutable_checks_passed'] = (record['source_before_after_exact'] and record['input_before_after_exact']
                and record['PT_archive_after_sha256'] == binding['PT_archive_sha256']
                and record['PR_archive_after_sha256'] == pt_binding['PR_archive_sha256'] and record['controls_after_exact']
                and record['controls_manifest_after_sha256'] == record['controls_manifest_sha256']
                and record['trace_still_absent'])
        except BaseException:
            record['preservation_error'] = traceback.format_exc()
        record['seconds'] = time.monotonic() - started
        save(root / 'receipt.json', record)
        if original_error is None and (record.get('frame_preservation_error') or record.get('preservation_error') or not record.get('immutable_checks_passed')):
            raise RuntimeError('PU observation or immutable-source audit failed; see original evidence')


if __name__ == '__main__':
    main()

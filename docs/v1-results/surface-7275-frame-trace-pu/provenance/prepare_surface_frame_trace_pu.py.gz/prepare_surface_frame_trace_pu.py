"""Freeze metadata only; no NumPy/model imports or execution."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/v1/surface-7275-frame-trace-pu-preparation'
sha = lambda b: hashlib.sha256(b).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def readtar(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        return {m.name: stream.extractfile(m).read() for m in stream.getmembers() if m.isfile()}


def main():
    raw = (ROOT / 'outputs/v1/surface-7275-numpy-reference-pt-evidence.tar.gz').read_bytes()
    assert sha(raw) == 'e039cc8d055612ef427719f2b0cd93076831f5983c18bde133f388c17c59cbc2'
    pt = readtar(raw)
    inventory = json.loads(pt['artifact-inventory.json'])
    assert len(pt) == 111 and set(inventory) == set(pt) - {'artifact-inventory.json'}
    assert all(sha(pt[n]) == row['sha256'] and len(pt[n]) == row['bytes'] for n, row in inventory.items())
    stage = readtar(pt['executed-stage.tar.gz'])
    source = readtar(stage['source.tar.gz'])
    manifest = json.loads(source['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and set(source) == set(manifest) | {'SOURCE_SHA256.json'}
    assert all(sha(source[n]) == h for n, h in manifest.items())
    relative = 'src/noahmp_clm/physics/canopy_phase_energy.py'
    phase = source[relative]
    assert sha(phase) == '8d23b61e1268983514ef75a6f08dba09bf97f75f5bdef5a0c68a54431ed77e3f'
    ast.parse(phase)
    reused = {}
    (OUT / 'pt').mkdir(exist_ok=True)
    for name in ('run_reference_pt.py', 'surface_reference.py', 'BINDINGS.json'):
        data = pt['result/controls/' + name]
        assert data == stage['controls/' + name]
        (OUT / 'pt' / name).write_bytes(data)
        reused[name] = sha(data)
    binding = dict(PT_archive_sha256=sha(raw), PT_archive_members=111,
        PT_executed_stage_sha256=sha(pt['executed-stage.tar.gz']),
        PT_original_result_sha256=sha(pt['original-result.tar.gz']), PT_reused_controls=reused,
        PT_source_hash_record_sha256={k: sha(pt['result/source-' + k + '.json']) for k in ('before', 'after')},
        source_archive_sha256=sha(stage['source.tar.gz']), source_manifest_sha256=sha(source['SOURCE_SHA256.json']),
        phase_source_relative_path=relative, phase_source_sha256=sha(phase),
        PR_archive_sha256=sha(stage['pr-evidence.tar.gz']),
        expected_exception='Canopy phase Newton stalled at iteration 30: residual=13.75804 W/m2',
        original_failed_job='1681.manager', original_PBS_F_exit=1, original_Stageout_status=0,
        original_children=[1, 0, 0], row=0, case='CN-Qia-suction-climate-cycle',
        planned_reference_attempts=1, planned_full_column_calls=0, planned_GPU_calls=0,
        observation='Original exception traceback final frame only; no settrace',
        prepared_only=True, submitted=False, numerical_executed=False)
    save(OUT / 'BINDINGS.json', binding)
    names = ['BINDINGS.json', 'README.md', 'trace_qia_pu.py',
             'pt/BINDINGS.json', 'pt/run_reference_pt.py', 'pt/surface_reference.py']
    assert {str(p.relative_to(OUT)).replace('\\', '/') for p in OUT.rglob('*') if p.is_file()} <= set(names) | {'CONTROLS_SHA256.json'}
    for name in names:
        if name.endswith('.py'):
            ast.parse((OUT / name).read_bytes())
    tree = ast.parse((OUT / 'trace_qia_pu.py').read_bytes())
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ('settrace', 'lstsq', 'evaluate') for n in ast.walk(tree))
    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'reference_one']
    assert len(calls) == 1
    controls = {name: sha((OUT / name).read_bytes()) for name in names}
    save(OUT / 'CONTROLS_SHA256.json', controls)
    result = dict(passed=True, scope='Stdlib archive/hash/AST preparation only; zero numerical execution',
        controls=len(controls), controls_manifest_sha256=sha((OUT / 'CONTROLS_SHA256.json').read_bytes()),
        original_PT_archive_sha256=sha(raw), reused_PT_files_byte_exact=3,
        exact_original_source_files=584, reference_call_sites=1, settrace_call_sites=0,
        extra_evaluate_or_lstsq_call_sites=0, numerical_calls=0, PBS_submissions=0)
    save(ROOT / 'outputs/v1/surface-7275-frame-trace-pu-static.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

"""Independent stdlib static review of PU; does not import its execution code."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE / 'surface-7275-frame-trace-pu-preparation'
EXPECTED = '73a47e7a4d31bb69c1ad4f9b04b29072e434affed2a2912a46ecc145ce316419'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: archive.extractfile(m).read() for m in members}


def call_name(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return call_name(node.value) + '.' + node.attr
    return '<expression>'


def main():
    raw_controls = (PREP / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(raw_controls) == EXPECTED
    controls = json.loads(raw_controls)
    assert len(controls) == 6
    assert {p.relative_to(PREP).as_posix() for p in PREP.rglob('*') if p.is_file()} == set(controls) | {'CONTROLS_SHA256.json'}
    assert all(sha((PREP / n).read_bytes()) == h for n, h in controls.items())
    binding = json.loads((PREP / 'BINDINGS.json').read_bytes())
    raw_pt = (BASE / 'surface-7275-numpy-reference-pt-evidence.tar.gz').read_bytes()
    assert sha(raw_pt) == binding['PT_archive_sha256'] == 'e039cc8d055612ef427719f2b0cd93076831f5983c18bde133f388c17c59cbc2'
    pt = unpack(raw_pt)
    inventory = json.loads(pt['artifact-inventory.json'])
    assert len(pt) == 111 and set(inventory) == set(pt) - {'artifact-inventory.json'}
    assert all(sha(pt[n]) == r['sha256'] and len(pt[n]) == r['bytes'] for n, r in inventory.items())
    assert sha(pt['original-result.tar.gz']) == binding['PT_original_result_sha256']
    assert sha(pt['executed-stage.tar.gz']) == binding['PT_executed_stage_sha256']
    stage = unpack(pt['executed-stage.tar.gz'])
    stage_index = json.loads(stage['stage-inventory.json'])
    assert len(stage) == 11 and set(stage_index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[n]) == h for n, h in stage_index.items())
    for name, h in binding['PT_reused_controls'].items():
        assert (PREP / 'pt' / name).read_bytes() == pt['result/controls/' + name] == stage['controls/' + name]
        assert sha(pt['result/controls/' + name]) == h
    assert sha(stage['source.tar.gz']) == binding['source_archive_sha256']
    source = unpack(stage['source.tar.gz'])
    manifest = json.loads(source['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and set(source) == set(manifest) | {'SOURCE_SHA256.json'}
    assert sha(source['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
    assert all(sha(source[n]) == h for n, h in manifest.items())
    phase = binding['phase_source_relative_path']
    assert sha(source[phase]) == binding['phase_source_sha256']
    assert source[phase].decode().splitlines()[356].strip().startswith("raise RuntimeError(f'Canopy phase Newton stalled")
    for label in ('before', 'after'):
        original = pt['result/source-' + label + '.json']
        assert sha(original) == binding['PT_source_hash_record_sha256'][label]
        assert json.loads(original) == manifest
    assert sha(stage['pr-evidence.tar.gz']) == binding['PR_archive_sha256']
    pr = unpack(stage['pr-evidence.tar.gz'])
    pr_inventory = json.loads(pr['artifact-inventory.json'])
    assert len(pr) == 72 and set(pr_inventory) == set(pr) - {'artifact-inventory.json'}
    assert all(sha(pr[n]) == r['sha256'] and len(pr[n]) == r['bytes'] for n, r in pr_inventory.items())
    qia = json.loads(pt['result/row-0/receipt.json'])
    assert qia['surface_step_calls_started'] == 1 and qia['surface_step_calls_returned'] == 0
    assert binding['expected_exception'] in qia['exception_traceback']
    assert binding['row'] == 0 and binding['case'] == qia['case']
    assert binding['planned_reference_attempts'] == 1
    assert binding['planned_GPU_calls'] == binding['planned_full_column_calls'] == 0

    script = (PREP / 'trace_qia_pu.py').read_text()
    tree = ast.parse(script)
    parsed = [ast.parse((PREP / n).read_text()) for n in controls if n.endswith('.py')]
    assert len(parsed) == 3
    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)]
    names = [call_name(n.func) for n in calls]
    assert names.count('ref.reference_one') == 1
    assert not any(n.split('.')[-1] in ('settrace', 'evaluate', 'lstsq') for n in names)
    reference = next(n for n in calls if call_name(n.func) == 'ref.reference_one')
    expected_call = ast.parse('ref.reference_one(source, args[:9], 0, coefficients=args[12], profiled=False, exchange_extension=args[9], vic=args[10], stem_area=None, canopy_optics=None)', mode='eval').body
    assert ast.dump(reference) == ast.dump(expected_call)
    assert names.count('copy.deepcopy') == 1
    assert all(not isinstance(n.ctx, ast.Store) for n in ast.walk(tree) if isinstance(n, ast.Attribute) and n.attr in ('f_locals', 'f_code', 'flags'))
    assert "frame.f_code is solve_canopy_phase_energy.__code__" in script
    assert "values = copy.deepcopy({name: obj for name, obj in loc.items() if name not in callables})" in script
    main_function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    physical_try = next(n for n in main_function.body if isinstance(n, ast.Try) and any(isinstance(a, ast.Call) and call_name(a.func) == 'ref.reference_one' for b in n.body for a in ast.walk(b)))
    assert len(physical_try.handlers) == 1
    assert isinstance(physical_try.handlers[0].body[-1], ast.Raise) and physical_try.handlers[0].body[-1].exc is None
    assert 'traceback_preservation_error' in script and 'PU receipt preservation failed; original exception remains active' in script
    assert 'actual_child_returncode=None' in script and 'scientific_acceptance=False' in script
    assert 'phase_invocation_count=None' in script
    old = json.loads((BASE / 'surface-7275-frame-trace-pu-before-io-guard-controls.json').read_bytes())
    assert sha((BASE / 'surface-7275-frame-trace-pu-before-io-guard-controls.json').read_bytes()) == '20608fd6af8fcd96836e03ee547fb6a1db7a69b500dfb9daec08e62d14a3cca3'
    assert [n for n in controls if controls[n] != old[n]] == ['trace_qia_pu.py']
    assert sha((BASE / 'surface-7275-frame-trace-pu-before-io-guard.py').read_bytes()) == old['trace_qia_pu.py']
    result = dict(passed=True, blocking_findings=[], nonblocking_findings=[],
        controls=6, controls_manifest_sha256=EXPECTED,
        scope='Independent manual source review plus stdlib raw-archive/hash/AST checks; no prepared-module import, NumPy execution, model attempt, or PBS submission.',
        PT_archive_sha256=binding['PT_archive_sha256'], PT_members=111, original_NM_source_files=584,
        original_PR_members=72, original_PT_controls_byte_exact=3,
        reference_call_sites=1, extra_evaluate_call_sites=0, extra_linear_solve_call_sites=0, settrace_call_sites=0,
        exact_reference_call_matches_PT_Qia=True, exact_original_solver_code_and_line_bound=True,
        input15_and_source584_before_after_checks=True,
        original_RuntimeError_reraised=True,
        resolved_findings=['Two unguarded traceback/receipt I/O writes could replace an already-propagating physical exception. Final73a47 adds only local preservation guards; prior20608 bytes retained.'],
        writer_type_review='Original final locals use scalar/ndarray/list/tuple/dict and supported dataclasses: CanopyExchange, SoilWaterSupply, CanopyCondensate, LeafParameters; the evaluate closure is excluded and only its code identity retained. Actual serialization remains to be observed on EHPC.',
        limits=['Snapshot contains only the failing final frame; no earlier invocation or iteration history is observed.',
                'Final branch temporaries can be stale; their presence does not certify a branch event or complete matrix initialization.',
                'No additional residual or linear-system solve is executed; any later rank/direction analysis must be a distinct EHPC post-run analysis.',
                'Original PT1681 remains F1; future PU wrapper must record actual child/PBS exit and cannot turn an expected failure into a scientific pass.',
                'This review covers six prepared controls; no PBS/dispatch wrapper is included or reviewed.'])
    path = BASE / 'surface-7275-frame-trace-pu-independent-review-rg.json'
    path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(passed=True, controls_manifest_sha256=EXPECTED, review=str(path), review_sha256=sha(path.read_bytes()))))


if __name__ == '__main__':
    main()

"""Freeze one PU EHPC stage using stdlib only; never deploy or submit."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE / 'surface-7275-frame-trace-pu-preparation'
EXECUTION = BASE / 'surface-7275-frame-trace-pu-execution'
PREP_SHA = '73a47e7a4d31bb69c1ad4f9b04b29072e434affed2a2912a46ecc145ce316419'
PT_SHA = 'e039cc8d055612ef427719f2b0cd93076831f5983c18bde133f388c17c59cbc2'
REVIEW_SHA = 'd28bdbe305b9d9e8b21778086a82ff208d62b3b4d1ecf2926d9eee588cf5ed5d'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda obj: (json.dumps(obj, indent=2, allow_nan=False) + '\n').encode()


def main():
    controls = json.loads((PREP / 'CONTROLS_SHA256.json').read_bytes())
    assert sha((PREP / 'CONTROLS_SHA256.json').read_bytes()) == PREP_SHA and len(controls) == 6
    assert all(sha((PREP / n).read_bytes()) == h for n, h in controls.items())
    pt = (BASE / 'surface-7275-numpy-reference-pt-evidence.tar.gz').read_bytes()
    assert sha(pt) == PT_SHA
    review = (BASE / 'surface-7275-frame-trace-pu-independent-review-rg.json').read_bytes()
    assert sha(review) == REVIEW_SHA
    reviewed = json.loads(review)
    assert reviewed['passed'] and not reviewed['blocking_findings'] and reviewed['controls_manifest_sha256'] == PREP_SHA
    binding = dict(preparation_manifest_sha256=PREP_SHA, preparation_controls=6,
        PT_archive_sha256=PT_SHA, preparation_review_sha256=REVIEW_SHA,
        source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
        planned_reference_calls=1, planned_full_column_calls=0, planned_GPU_calls=0,
        post_run_analysis='saved typed frame only; no model import, no residual evaluation, no linear solve',
        PBS_resources='1CPU/2GiB/10min/compute002', preserve_original_model_exit=True,
        current_status='prepared-only', submitted=False)
    (EXECUTION / 'EXECUTION_BINDINGS.json').write_bytes(encode(binding))
    names = ('EXECUTION_BINDINGS.json', 'README.md', 'analyze_frame_pu.py', 'check_stage_pu.py', 'dispatch_frame_pu.py', 'frame_pu.pbs')
    index = {n: sha((EXECUTION / n).read_bytes()) for n in names}
    assert len(index) == 6
    (EXECUTION / 'CONTROLS_SHA256.json').write_bytes(encode(index))
    for directory in (PREP, EXECUTION):
        for path in directory.rglob('*.py'):
            ast.parse(path.read_text())
    analysis = ast.parse((EXECUTION / 'analyze_frame_pu.py').read_text())
    imports = []
    for node in ast.walk(analysis):
        if isinstance(node, ast.Import):
            imports.extend(n.name for n in node.names)
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module or '')
    assert 'numpy' in imports and not any(n.startswith('noahmp_clm') or n == 'pickle' for n in imports)
    calls = [ast.unparse(n.func) for n in ast.walk(analysis) if isinstance(n, ast.Call)]
    assert calls.count('np.linalg.svd') == 1
    assert not any(n.split('.')[-1] in ('evaluate', 'lstsq', 'solve', 'reference_one', 'surface_step', 'run') for n in calls)
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom)) and 'numpy' in ast.unparse(n) for n in analysis.body)
    items = {'preparation/' + n: (PREP / n).read_bytes() for n in [*controls, 'CONTROLS_SHA256.json']}
    items.update({'execution/' + n: (EXECUTION / n).read_bytes() for n in [*index, 'CONTROLS_SHA256.json']})
    items['pt-evidence.tar.gz'] = pt
    items['preparation-independent-review.json'] = review
    items['stage-inventory.json'] = encode({n: sha(b) for n, b in sorted(items.items())})
    target = BASE / 'surface-7275-frame-trace-pu-stage.tar.gz'
    assert not target.exists()
    with target.open('wb') as file, gzip.GzipFile(fileobj=file, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
        for name, raw in sorted(items.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
    with tarfile.open(target) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive.getmembers()} == items
    output = dict(passed=True, scope='Stdlib preparation/AST/hash only; no model or post-run numerical analysis executed; no submission.',
        preparation_manifest_sha256=PREP_SHA, preparation_controls=6,
        execution_manifest_sha256=sha((EXECUTION / 'CONTROLS_SHA256.json').read_bytes()), execution_controls=6,
        stage_sha256=sha(target.read_bytes()), stage_members=len(items), stage_bytes=target.stat().st_size,
        PT_archive_sha256=PT_SHA, preparation_review_sha256=REVIEW_SHA,
        analysis_imports=imports, numerical_execution=False, PBS_submissions=0)
    (BASE / 'surface-7275-frame-trace-pu-execution-static.json').write_bytes(encode(output))
    print(json.dumps(output))


if __name__ == '__main__':
    main()

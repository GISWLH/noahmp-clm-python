"""Read only PU immutable controls and closed-job artifacts on either EHPC host."""
import base64
import hashlib
import json
from pathlib import Path
import socket

ROOT = Path('/tmp/noahmp-surface-frame-trace-pu')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    hostname = socket.gethostname().split('.')[0]
    assert hostname in ('manager', 'compute002')
    index = json.loads((ROOT / 'stage-inventory.json').read_bytes())
    before = {n: sha((ROOT / n).read_bytes()) for n in index}
    assert before == index
    names = (['dispatch.json', 'qsub.stdout', 'qsub.stderr', 'compute-extract.stdout',
              'compute-extract.stderr', 'compute-hashes.stdout', 'compute-hashes.stderr',
              'pbs-output.log'] if hostname == 'manager' else ['pbs-exit.txt'])
    files, presence = {}, {}
    for name in names:
        path = ROOT / name
        presence[name] = path.is_file()
        if path.is_file():
            files[name] = base64.b64encode(path.read_bytes()).decode('ascii')
    result = ROOT / 'result.tar.gz'
    source = Path('/var/tmp/pbs.1688.manager/frame-result/model/source-nm')
    source_present = source.is_dir()
    source_hashes = None
    if hostname == 'compute002' and source_present:
        manifest = json.loads((source / 'SOURCE_SHA256.json').read_bytes())
        source_hashes = {n: sha((source / n).read_bytes()) for n in manifest}
        assert len(manifest) == 584 and source_hashes == manifest
    after = {n: sha((ROOT / n).read_bytes()) for n in index}
    assert after == before
    print(json.dumps(dict(hostname=hostname, stage_files_before=before,
        stage_files_after=after, all_stage_immutable=True, files=files, actual_presence=presence,
        result_archive_sha256=sha(result.read_bytes()) if result.is_file() else None,
        original_source_present=source_present, source_hashes_after_closed=source_hashes)))


if __name__ == '__main__':
    main()

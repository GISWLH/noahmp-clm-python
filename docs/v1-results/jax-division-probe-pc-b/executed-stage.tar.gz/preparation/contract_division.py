"""Frozen PB-v geometry inputs and unchanged PB-t source, no numeric imports."""
from pathlib import Path,PurePosixPath
import hashlib
import io
import json
import tarfile

HERE=Path(__file__).resolve().parent
GPU='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha=lambda r:hashlib.sha256(r).hexdigest()
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def controls():
    raw=(HERE/'CONTROLS_SHA256.json').read_bytes();index=json.loads(raw)
    assert {p.name for p in HERE.iterdir() if p.is_file()}==set(index)|{'CONTROLS_SHA256.json'}
    assert all(sha((HERE/n).read_bytes())==h for n,h in index.items());return sha(raw)
def source_identity(root,binding):
    root=Path(root).resolve();raw=(root/'SOURCE_SHA256.json').read_bytes();index=json.loads(raw)
    assert sha(raw)==binding['source_manifest_sha256'] and len(index)==596
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(index)|{'SOURCE_SHA256.json'}
    assert all(sha((root/n).read_bytes())==h for n,h in index.items())
    return dict(source_files=596,source_manifest_sha256=sha(raw))
def bound_evidence(path,binding):
    raw=Path(path).read_bytes();assert sha(raw)==binding['evidence_archive_sha256'];data={}
    with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
        for m in tar:
            if m.isdir():continue
            name=m.name.removeprefix('./');parts=PurePosixPath(name)
            assert m.isfile() and not parts.is_absolute() and '..' not in parts.parts and '\\' not in name and name not in data
            data[name]=tar.extractfile(m).read()
    for row in binding['groups']:
        backend,case=row['backend'],row['case'];prefix=backend+'/device/'+case+'/'
        capture=json.loads(data[backend+'/device/capture-receipt.json'])
        assert capture['passed'] and capture['source_controls_prior_unchanged'] and capture['source_manifest_sha256']==binding['source_manifest_sha256']
        assert sha(data[prefix+'result.json'])==row['metadata_sha256'] and sha(data[prefix+'result.npz'])==row['npz_sha256']
        meta=json.loads(data[prefix+'result.json']);assert meta['attribution_context_valid'] and all(meta['checks'].values())
    assert len(binding['groups'])==8
    return data

"""Isolated baseline/precise JAX float32 diagnosis with unchanged hardware RN audit."""
import argparse
import importlib.metadata
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

from contract_division import GPU,HERE,bound_evidence,controls,save,sha,source_identity

EXTRA='--xla_backend_extra_options=-nvptx-prec-divf32=2'

def main():
    parser=argparse.ArgumentParser()
    for name in ('source','evidence','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--mode',choices=('baseline','precise'),required=True);args=parser.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='false'
    assert os.environ.get('XLA_FLAGS')==(None if args.mode=='baseline' else EXTRA)
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert all(str(Path(os.environ[k]).resolve()).startswith('/tmp/drainage-pc-b-') for k in
        ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH'))
    assert not args.output.exists();binding=json.loads((HERE/'BINDINGS.json').read_bytes())
    control_sha=controls();identity=source_identity(args.source,binding);prior=bound_evidence(args.evidence,binding)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024
    args.output.mkdir();compiler=args.output/'compiler';compiler.mkdir();sys.path.insert(0,str(args.source.resolve()/'src'))
    import numpy as np  # Immutable packet loading/assembly and output encoding only.
    assert importlib.metadata.version('jax')==importlib.metadata.version('jaxlib')=='0.11.2'
    import jax
    import jax.numpy as j
    assert jax.config.jax_enable_x64 is False
    assert len(jax.devices())==1 and jax.devices()[0].platform=='gpu'
    from noahmp_clm.gpu import clm_drainage_primitives as primitives
    from noahmp_clm.gpu import clm_drainage_diagnosis as diagnosis
    forbidden=[]
    def no_numpy_physics(*a,**kw):
        forbidden.append('NumPy physical function called');raise RuntimeError(forbidden[-1])
    primitives.run_numpy=no_numpy_physics
    barrier=jax.lax.optimization_barrier
    def geometry_context(c,p):
        liquid_divided=barrier(c[:,0]/1000)
        ice_divided=barrier(c[:,1]/917)
        numerator=barrier(liquid_divided+ice_divided)
        denominator=barrier(c[:,2]*p[0])
        saturation=barrier(numerator/denominator)
        density_thickness=barrier(917*c[:,2])
        ice_denominator=barrier(density_thickness*p[0])
        ice_quotient=barrier(c[:,1]/ice_denominator)
        ice_fraction=j.minimum(1,ice_quotient)
        return primitives._diagnosis(c,p,j,barrier),j.stack((liquid_divided,ice_divided,numerator,denominator,
            saturation,density_thickness,ice_denominator,ice_quotient,ice_fraction),axis=1)
    context=jax.jit(jax.vmap(geometry_context));executable=None
    record=dict(capture_completed=False,mode=args.mode,pid=os.getpid(),gpu_uuid=GPU,**identity,
        controls_manifest_sha256=control_sha,actual_XLA_FLAGS=os.environ.get('XLA_FLAGS'),X64_before=False,
        original_diagnosis_attempted=0,original_diagnosis_returned=0,context_attempted=0,context_returned=0,
        hardware_RN_attempted=0,hardware_RN_returned=0,CPU_physical_reference_calls=0,model_calls=0,phase_calls=0,
        scientific_acceptance=False,cases=[],forbidden_cpu_reference_calls=forbidden)
    started=time.monotonic();hardware_inputs=[]
    def host(x):
        if hasattr(x,'block_until_ready'):x.block_until_ready()
        return np.asarray(x).copy()
    try:
        for case in binding['cases']:
            root=args.output/case;root.mkdir();prefix='jax/device/'+case+'/'
            old_meta=json.loads(prior[prefix+'result.json']);raw=prior[prefix+'result.npz']
            assert sha(raw)==old_meta['npz_sha256']
            with np.load(io.BytesIO(raw),allow_pickle=False) as store:
                old={key:store[key].copy() for key in ('input.phase_cells','input.parameters','original.diagnosis','context.diagnosis','context.components')}
            for key,v in old.items():
                desc=old_meta['arrays'][key]
                assert (v.dtype.str,list(v.shape),sha(v.tobytes()))==(desc['dtype'],desc['shape'],desc['c_order_sha256'])
            c,p=(j.asarray(old[k]) for k in ('input.phase_cells','input.parameters'))
            assert c.dtype==p.dtype==j.float32 and c.shape==(1,4,6) and p.shape==(1,12)
            record['original_diagnosis_attempted']+=1
            original=diagnosis.diagnose_clm_drainage(c,p,backend='jax');original.block_until_ready();record['original_diagnosis_returned']+=1
            if executable is None:
                lowered=context.lower(c,p);executable=lowered.compile()
                texts={'context-lowered.mlir':lowered.as_text(),'context-optimized-hlo.txt':executable.as_text(),
                    'original-optimized-hlo.txt':diagnosis._jax_diagnosis().lower(c,p).compile().as_text()}
                for name,text in texts.items():
                    assert isinstance(text,str) and text and not re.search(r'\bf64(?:\[|\b)',text)
                    (compiler/name).write_text(text)
            record['context_attempted']+=1
            augmented,components=executable(c,p);jax.effects_barrier();record['context_returned']+=1
            actual={'input.phase_cells':host(c),'input.parameters':host(p),'original.diagnosis':host(original),
                'context.diagnosis':host(augmented),'context.components':host(components)}
            assert all(v.dtype==np.float32 for v in actual.values())
            original_bytes=actual['original.diagnosis'].tobytes();ops=actual['context.components']
            checks=dict(input_echo_exact=all(sha(actual[n].tobytes())==sha(old[n].tobytes()) for n in ('input.phase_cells','input.parameters')),
                augmented29_same_process_exact=sha(actual['context.diagnosis'].tobytes())==sha(original_bytes),
                saturation_same_process_exact=sha(ops[:,:,4].copy().tobytes())==sha(actual['original.diagnosis'][:,25:29].copy().tobytes()),
                ice_same_process_exact=sha(ops[:,:,8].copy().tobytes())==sha(actual['original.diagnosis'][:,21:25].copy().tobytes()))
            matches_prior={n:sha(v.tobytes())==sha(old[n].tobytes()) for n,v in actual.items()}
            np.savez(root/'result.npz',**actual)
            meta=dict(case=case,mode=args.mode,arrays={n:dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes())) for n,v in actual.items()},
                npz_sha256=sha((root/'result.npz').read_bytes()),checks=checks,context_reproduction_passed=all(checks.values()),
                matches_original_PBv_payloads=matches_prior,baseline_PBv_reproduction_required=args.mode=='baseline',
                all_scientific_intermediates_float32=True,actual_device_barrier_complete=True)
            save(root/'result.json',meta);record['cases'].append(meta);hardware_inputs.append(actual)
        # Same PB-z RN kernel, exact source bytes. Host assembly is opaque data
        # transfer; all arithmetic/equality/counts are performed in this kernel.
        import cupy as cp
        from cupy.cuda import compiler as cc
        from cupy.cuda import function as cf
        assert cp.cuda.runtime.getDeviceCount()==1;cp.cuda.Device(0).use();cp.cuda.runtime.free(0)
        assembled={n:np.concatenate([row[n] for row in hardware_inputs],axis=0) for n in ('input.phase_cells','input.parameters','context.components')}
        device={n:cp.asarray(v) for n,v in assembled.items()}
        code=(HERE/'rn_geometry_probe.cu').read_bytes();assert sha(code)==binding['RN_kernel_sha256']
        options=('--std=c++14','--fmad=false','--prec-div=true','--prec-sqrt=true','--ftz=false',
            '-arch=sm_'+str(cp.cuda.Device(0).compute_capability),'--device-as-default-execution-space')
        program=cc._NVRTCProgram(code.decode(),name='unchanged_PBz_RN.cu',method='cubin');cubin,_=program.compile(options)
        (compiler/'actual-loaded-RN.cubin').write_bytes(cubin);module=cf.Module();module.load(cubin)
        outputs={n:cp.empty((4,4,9),cp.uint32) for n in ('observed_bits','strict_rn_bits','actual_operand_rn_bits','strict_equal','actual_operand_equal')}
        outputs['valid_rows']=cp.empty((4,4),cp.uint32);outputs['group_counts']=cp.zeros((4,3),cp.uint32)
        record['hardware_RN_attempted']+=1
        module.get_function('rn_geometry_probe')((1,),(128,),tuple(device[n] for n in ('input.phase_cells','input.parameters','context.components'))+
            tuple(outputs[n] for n in ('observed_bits','strict_rn_bits','actual_operand_rn_bits','strict_equal','actual_operand_equal','valid_rows','group_counts'))+(np.int32(4),))
        cp.cuda.get_current_stream().synchronize();record['hardware_RN_returned']+=1
        valid=bool(cp.all(outputs['valid_rows']==1));flat={**{n:cp.asnumpy(v) for n,v in device.items()},**{n:cp.asnumpy(v) for n,v in outputs.items()}}
        assert all(sha(flat[n].tobytes())==sha(v.tobytes()) for n,v in assembled.items())
        np.savez(args.output/'hardware-result.npz',**flat)
        save(args.output/'hardware-result.json',dict(npz_sha256=sha((args.output/'hardware-result.npz').read_bytes()),
            arrays={n:dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes())) for n,v in flat.items()},
            uint32_output_encoding={n:v.tolist() for n,v in flat.items() if n in outputs},component_fields=binding['component_fields'],
            cases=binding['cases'],GPU_domain_valid=valid,all_flags_and_counts_computed_inside_kernel=True,
            group_count_columns=['strict_chain_mismatches','actual_operand_mismatches','invalid_rows']))
        apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True)
        own=[line.split(',')[1].strip() for line in apps.splitlines() if line.split(',')[0].strip()==str(os.getpid())]
        assert own and set(own)=={GPU};record['own_process_GPU_UUIDs']=own
        contexts=all(c['context_reproduction_passed'] for c in record['cases'])
        baseline=all(all(c['matches_original_PBv_payloads'].values()) for c in record['cases'])
        record.update(context_reproduction_passed=contexts,all_PBv_payloads_reproduced=baseline,
            baseline_PBv_reproduction_required=args.mode=='baseline',GPU_domain_valid=valid,
            group_counts_computed_inside_GPU=flat['group_counts'].tolist(),actual_RN_options=options,actual_loaded_RN_cubin_sha256=sha(cubin),
            X64_after=bool(jax.config.jax_enable_x64),JAX_version=jax.__version__,CuPy_version=cp.__version__)
        record['capture_completed']=contexts and valid and (baseline if args.mode=='baseline' else True) and not jax.config.jax_enable_x64 and not forbidden
    except BaseException:
        record['error']=traceback.format_exc();(args.output/'failure.txt').write_text(record['error'])
    finally:
        try:
            assert jax.config.jax_enable_x64 is False and source_identity(args.source,binding)==identity and controls()==control_sha
            bound_evidence(args.evidence,binding);record['source_controls_prior_unchanged']=True
        except BaseException:
            record['identity_error']=traceback.format_exc();record['source_controls_prior_unchanged']=False;record['capture_completed']=False
        record['seconds']=time.monotonic()-started;save(args.output/'capture-receipt.json',record)
    return 0 if record['capture_completed'] else 1

if __name__=='__main__':raise SystemExit(main())

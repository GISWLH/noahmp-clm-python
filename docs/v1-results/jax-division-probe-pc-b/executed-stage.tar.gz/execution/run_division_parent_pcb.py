"""PB-s one-worker lifecycle, mechanically adapted from reviewed PO parent."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import sys
import time
import traceback
from contract_division import HERE,GPU,controls,bound_evidence,source_identity,save,sha


def main():
    p=argparse.ArgumentParser()
    for key in ('source','evidence','output'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--mode',choices=('baseline','precise'),required=True)
    a=p.parse_args();assert os.name!='nt'
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());controls();source_identity(a.source,binding);bound_evidence(a.evidence,binding)
    root=a.output.resolve()
    assert str(root).startswith('/tmp/drainage-pc-b-') and not root.exists()
    root.mkdir()
    env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('LD_LIBRARY_PATH',None)
    env.update(PYTHONPATH=str(a.source.resolve()/'src')+':'+str(HERE),
        CUDA_VISIBLE_DEVICES=GPU,JAX_PLATFORMS='cuda',JAX_ENABLE_X64='false',
        XLA_PYTHON_CLIENT_PREALLOCATE='false',PYTHONDONTWRITEBYTECODE='1',
        OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
        CUPY_CACHE_DIR=str(root/'cupy-cache'),JAX_COMPILATION_CACHE_DIR=str(root/'jax-cache'),
        CUDA_CACHE_PATH=str(root/'cuda-cache'),CUDA_PATH='/usr/local/cuda-12.4',
        PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin')
    env.pop('XLA_FLAGS',None)
    if a.mode=='precise':env['XLA_FLAGS']='--xla_backend_extra_options=-nvptx-prec-divf32=2'
    command=[sys.executable,'-B',str(HERE/'capture_division_config.py'),'--source',str(a.source.resolve()),
        '--evidence',str(a.evidence.resolve()),'--output',str(root/'device'),'--mode',a.mode]
    receipt=dict(mode=a.mode,completed=False,returncode=None,error=None,walltime_limit_seconds=900,
        command=command,started_unix=time.time(),gpu_uuid=GPU)
    child=None
    try:
        with (root/'device.stdout.txt').open('wb') as out,(root/'device.stderr.txt').open('wb') as err:
            child=subprocess.Popen(command,env=env,stdout=out,stderr=err)
            receipt['pid']=child.pid
            stat=Path('/proc')/str(child.pid)/'stat'
            receipt['proc_stat_at_launch']=stat.read_text() if stat.exists() else None
            save(root/'device-launch.json',receipt)
            receipt['returncode']=child.wait(timeout=900)
        receipt['completed']=True
    except Exception:
        receipt['error']=traceback.format_exc()
        if child is not None and child.poll() is None:
            child.kill();receipt['returncode']=child.wait()
        receipt['completed']=False
    path=root/'device/capture-receipt.json'
    if path.exists():receipt['device_receipt_sha256']=sha(path.read_bytes())
    receipt['seconds']=time.time()-receipt['started_unix']
    save(root/'device-parent-receipt.json',receipt)
    code=0 if receipt['completed'] and receipt['returncode']==0 else 1
    (root/'device-parent-exit.txt').write_text(str(code)+'\n')
    return code


if __name__=='__main__':raise SystemExit(main())

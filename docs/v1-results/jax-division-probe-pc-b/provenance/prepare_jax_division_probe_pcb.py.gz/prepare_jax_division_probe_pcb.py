"""Freeze two source-supported isolated X64off JAX processes; never deploy."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'jax-division-probe-pc-b-preparation'
EXEC=BASE/'jax-division-probe-pc-b-execution'
OLD=BASE/'drainage-geometry-pb-v-execution'
sha=lambda r:hashlib.sha256(r).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    assert not EXEC.exists();EXEC.mkdir()
    for p in PREP.glob('*.py'):compile(ast.parse(p.read_bytes()),p.name,'exec')
    assert sha((PREP/'rn_geometry_probe.cu').read_bytes())=='a2ce278f8c2ab9e208c64a1ecbb8424b7f8e1c38ab94c1c2a456090be37a19f1'
    (PREP/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file()}))
    names={'run_geometry_parent_pbv.py':'run_division_parent_pcb.py','control_geometry_pbv.py':'control_division_pcb.py','launch_geometry_pbv.py':'launch_division_pcb.py'}
    differences=[]
    for old,new in names.items():
        original=(OLD/old).read_bytes();raw=original
        for a,b in ((b'contract_pbv',b'contract_division'),(b'capture_geometry_pbv.py',b'capture_division_config.py'),
            (b'run_geometry_parent_pbv.py',b'run_division_parent_pcb.py'),(b'control_geometry_pbv.py',b'control_division_pcb.py'),
            (b'/tmp/drainage-pb-s-pbv-',b'/tmp/drainage-pc-b-')):raw=raw.replace(a,b)
        raw=raw.replace(b'backend',b'mode')
        if old=='run_geometry_parent_pbv.py':
            assert b"choices=('cuda','jax')" in raw
            raw=raw.replace(b"choices=('cuda','jax')",b"choices=('baseline','precise')")
            raw=raw.replace(b"JAX_ENABLE_X64='true'",b"JAX_ENABLE_X64='false'")
            anchor=b'    command=[sys.executable'
            assert raw.count(anchor)==1
            raw=raw.replace(anchor,b"    env.pop('XLA_FLAGS',None)\n    if a.mode=='precise':env['XLA_FLAGS']='--xla_backend_extra_options=-nvptx-prec-divf32=2'\n"+anchor)
        if old=='control_geometry_pbv.py':
            raw=raw.replace(b'cuda-parent.',b'baseline-parent.').replace(b'jax-parent.',b'precise-parent.')
        compile(ast.parse(raw),new,'exec');(EXEC/new).write_bytes(raw)
        differences.extend(difflib.unified_diff(original.decode().splitlines(True),raw.decode().splitlines(True),fromfile='PB-v/'+old,tofile='PC-b/'+new))
    binding=json.loads((PREP/'BINDINGS.json').read_bytes())
    policy=dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        source_archive_sha256=binding['source_archive_sha256'],source_manifest_sha256=binding['source_manifest_sha256'],
        evidence_archive_sha256=binding['evidence_archive_sha256'],root='/home/lhwang/work/noahmp-v1/jax-division-probe-pc-b',
        temporary='/tmp/drainage-pc-b-20261026',gpu_uuid='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',
        mode_order=['baseline','precise'],maximum_worker_seconds=900,automatic_retry=False,X64=False,
        root_execution_authorization_pending=True,production_source_modified=False,source_supported_flag=True)
    (EXEC/'EXECUTION_BINDINGS.json').write_bytes(encode(policy));(EXEC/'PBV_TO_PCB.diff').write_text(''.join(differences),encoding='utf-8')
    (EXEC/'README.md').write_text('Prepared-only two-process metadata/lifecycle adaptation of PB-v. Mode baseline explicitly removes XLA_FLAGS; mode precise sets the exact pinned-parser-supported value. Both set X64false.900s wait/kill-and-wait, original resource/thread/fresh-cache/source/provenance checks remain. Root must review source, flag CLI and this stage before unique launch; no deployment is included.\n',encoding='utf-8')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}))
    items={}
    for root,prefix in ((PREP,'preparation'),(EXEC,'execution')):
        for p in root.iterdir():
            if p.is_file():items[prefix+'/'+p.name]=p.read_bytes()
    items['source.tar.gz']=(BASE/'clm-drainage-header-pb-t-source.tar.gz').read_bytes()
    items['prior-device.tar.gz']=(BASE/'drainage-geometry-pb-v-gpu-closed/gpu-result.tar.gz').read_bytes()
    assert sha(items['source.tar.gz'])==binding['source_archive_sha256'] and sha(items['prior-device.tar.gz'])==binding['evidence_archive_sha256']
    items['stage-inventory.json']=encode({n:sha(v) for n,v in sorted(items.items())})
    target=BASE/'jax-division-probe-pc-b-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;archive.addfile(m,io.BytesIO(v))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==items
    report=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),bytes=target.stat().st_size,stage_files=len(items),
        preparation_manifest_sha256=policy['preparation_manifest_sha256'],execution_manifest_sha256=sha(items['execution/CONTROLS_SHA256.json']),
        RN_kernel_byte_identical_PBz=True,X64=False,source_unchanged=True,launched=False,numerical_executed=False)
    (BASE/'jax-division-probe-pc-b-stage-package.json').write_bytes(encode(report));print(json.dumps(report))

if __name__=='__main__':main()

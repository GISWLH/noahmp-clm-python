"""Preserve PC-b raw outputs; label existing GPU flags without numeric decode."""
from pathlib import Path
import gzip
import io
import json
import re
import tarfile
from verify_drainage_1704_pc import files,packet,sha

BASE=Path(__file__).resolve().parent
LABEL='jax-division-probe-pc-b'
encode=lambda x:(json.dumps(x,indent=2,allow_nan=False)+'\n').encode()

def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='85424b5c6dda2706c85498518acba89bc5cae66b9b2ef36f27cd7a2bb9efedbd'
    index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==17 and all(sha(stage[n])==h for n,h in index.items())
    raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes();gpu=files(raw)
    assert sha(raw)=='20e170c8c259ec748405b12d8d7f1bfecf2df1f4b1200f2aeae1df1360072755' and len(gpu)==46
    controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged']
    assert [p['actual_parent_returncode'] for p in controller['actual_parents']]==[0,0]
    closed=json.loads((BASE/(LABEL+'-closed.json')).read_bytes())
    assert not any(row['exists'] for row in closed['live_handles'])
    modes={};array_count=0
    for mode in ('baseline','precise'):
        parent=json.loads(gpu[mode+'/device-parent-receipt.json'])
        capture=json.loads(gpu[mode+'/device/capture-receipt.json'])
        meta=json.loads(gpu[mode+'/device/hardware-result.json'])
        assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
        assert capture['capture_completed'] and capture['context_reproduction_passed']
        assert capture['source_controls_prior_unchanged'] and capture['GPU_domain_valid']
        assert capture['original_diagnosis_attempted']==capture['original_diagnosis_returned']==4
        assert capture['context_attempted']==capture['context_returned']==4
        assert capture['hardware_RN_attempted']==capture['hardware_RN_returned']==1
        assert capture['CPU_physical_reference_calls']==capture['model_calls']==capture['phase_calls']==0
        assert capture['X64_before'] is capture['X64_after'] is False and capture['scientific_acceptance'] is False
        assert capture['actual_XLA_FLAGS']==(None if mode=='baseline' else '--xla_backend_extra_options=-nvptx-prec-divf32=2')
        assert sha(gpu[mode+'/device/compiler/actual-loaded-RN.cubin'])==capture['actual_loaded_RN_cubin_sha256']
        assert '--ftz=false' in capture['actual_RN_options']
        array_count+=packet(gpu[mode+'/device/hardware-result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
        for case in capture['cases']:
            assert case['context_reproduction_passed'] and case['all_scientific_intermediates_float32']
            if mode=='baseline':assert all(case['matches_original_PBv_payloads'].values())
            array_count+=packet(gpu[mode+'/device/'+case['case']+'/result.npz'],dict(sha256=case['npz_sha256'],arrays=case['arrays']))
        texts={name:payload for name,payload in gpu.items() if name.startswith(mode+'/device/compiler/') and name.endswith(('.txt','.mlir'))}
        assert len(texts)==3 and all(not re.search(rb'\bf64(?:\[|\b)',text) for text in texts.values())
        groups=[];words=meta['uint32_output_encoding'];fields=meta['component_fields']
        assert words['group_counts']==capture['group_counts_computed_inside_GPU']
        for k,case in enumerate(meta['cases']):
            groups.append(dict(case=case,GPU_group_counts=words['group_counts'][k],
                actual_operand_false_flags=[dict(layer_zero_based=i,fields=[fields[j] for j,flag in enumerate(row) if flag==0]) for i,row in enumerate(words['actual_operand_equal'][k])],
                strict_chain_false_flags=[dict(layer_zero_based=i,fields=[fields[j] for j,flag in enumerate(row) if flag==0]) for i,row in enumerate(words['strict_equal'][k])]))
        modes[mode]=dict(actual_worker_returncode=parent['returncode'],actual_parent_returncode=0,
            worker_seconds=capture['seconds'],parent_seconds=parent['seconds'],actual_XLA_FLAGS=capture['actual_XLA_FLAGS'],
            X64_before=False,X64_after=False,all_scientific_intermediates_float32=True,
            context_reproduction_passed=True,all_PBv_payloads_reproduced=capture['all_PBv_payloads_reproduced'],
            groups=groups,actual_RN_options=capture['actual_RN_options'],actual_loaded_RN_cubin_sha256=capture['actual_loaded_RN_cubin_sha256'],
            actual_original_diagnosis_calls=4,actual_context_calls=4,actual_hardware_RN_calls=1,CPU_physical_reference_calls=0,
            compiler_texts={name:dict(sha256=sha(text),bytes=len(text)) for name,text in texts.items()})
    readout=dict(modes=modes,controller_seconds=controller['seconds'],actual_controller_OS_returncode=None,
        old_and_new_worker_PIDs_absent=True,source_596_controls_prior_unchanged=True,
        verified_opaque_arrays=array_count,all_flags_and_counts_computed_inside_GPU=True,
        EHPC_Fraction_audit_executed=False,scientific_acceptance=False,
        scope='Two isolated JAX processes, identical original PB-v inputs and unchanged596 physics source. Baseline reproduces all prior29+9 payloads. Both contexts reproduce own original29. GPU RN flags/counts are merely labeled here, never recomputed on CPU. No production default flag/source change, no full integration/P0/annual/same-precision acceptance credit; exact Fraction audit pending.')
    items={'executed-stage.tar.gz':stage_raw,'original-gpu-result.tar.gz':raw,'readout.json':encode(readout),
        'original-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(gpu.items())})}
    for mode in modes:items[mode+'-original-hardware-metadata.json']=gpu[mode+'/device/hardware-result.json']
    for n,v in stage.items():
        if n.startswith(('preparation/','execution/')):items[n]=v
    for p in (BASE/(LABEL+'-gpu-closed')).iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for n in (LABEL+'-stage-package.json',LABEL+'-gpu-deployment.json',LABEL+'-prelaunch.json',LABEL+'-closed.json',
        'prepare_jax_division_probe_pcb.py','prepare_pcb_deployment_helpers.py','deploy_jax_division_pcb.py',
        'read_jax_division_pcb.py','read_gpu_project_ownership_pcb.py','run_pcb_reader.py','collect_jax_division_pcb.py',Path(__file__).name):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-prelaunch.',LABEL+'-prelaunch-exit.',LABEL+'-closed.',LABEL+'-closed-exit.'):
        for p in BASE.glob(prefix+'*'):
            if p.is_file():items['deployment/'+p.name]=p.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;archive.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual baseline/precision2 isolated CUDA1 JAX causal experiment; original computed flags/counts and byte-reproduction evidence. No production/physical acceptance change.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package))
    print(json.dumps(package));print(json.dumps({mode:row['groups'] for mode,row in modes.items()}))

if __name__=='__main__':main()

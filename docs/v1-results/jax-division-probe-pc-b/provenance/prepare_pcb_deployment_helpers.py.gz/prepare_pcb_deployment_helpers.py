"""Mechanically bind reviewed lifecycle helpers to frozen PC-b; no execution."""
from pathlib import Path

base = Path(__file__).resolve().parent
pairs = {
    'deploy_hardware_rn_pbz.py': 'deploy_jax_division_pcb.py',
    'read_hardware_rn_pbz.py': 'read_jax_division_pcb.py',
    'collect_hardware_rn_pbz.py': 'collect_jax_division_pcb.py',
}
changes = {
    'drainage-rn-primitives-pb-z': 'jax-division-probe-pc-b',
    'clm-jax-division-probe-pc-b': 'jax-division-probe-pc-b',
    'drainage-pb-s-pbz-20261026': 'drainage-pc-b-20261026',
    'launch_hardware_rn_pbz.py': 'launch_division_pcb.py',
    '3b35b289ddfffe7fb24671d0cb126626de8f0648905fb5823d0dce207f248293': '85424b5c6dda2706c85498518acba89bc5cae66b9b2ef36f27cd7a2bb9efedbd',
    "for backend in ('cuda','jax'):": "for backend in ('baseline','precise'):",
    "len(controller['actual_parents'])==1": "len(controller['actual_parents'])==2",
}
for old, new in pairs.items():
    target = base / new
    assert not target.exists()
    text = (base / old).read_text(encoding='utf-8')
    for before, after in changes.items():
        text = text.replace(before, after)
    target.write_text(text, encoding='utf-8', newline='\n')

target = base / 'read_gpu_project_ownership_pcb.py'
assert not target.exists()
text = (base / 'read_gpu_project_ownership_pbz.py').read_text(encoding='utf-8')
text = text.replace("r=subprocess.run(['nvidia-smi'", "old_pids={str(pid):(Path('/proc')/str(pid)).exists() for pid in (864244,864246,864677)}\nqj=Path('/home/lhwang/work/noahmp-v1/nq-transport-trace-qj/controller-receipt.json')\nqj_record=json.loads(qj.read_bytes())\nassert qj_record['completed'] and all(row['actual_parent_returncode']==0 for row in qj_record['actual_parents'])\nr=subprocess.run(['nvidia-smi'")
text = text.replace('live_task_python=rows,', 'live_task_python=rows,QJ_old_PID_exists=old_pids,QJ_actual_parent_returncodes=[row[\'actual_parent_returncode\'] for row in qj_record[\'actual_parents\']],')
target.write_text(text, encoding='utf-8', newline='\n')

"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'jax-division-probe-pc-b-stage.tar.gz'
expected='85424b5c6dda2706c85498518acba89bc5cae66b9b2ef36f27cd7a2bb9efedbd'
assert sha(stage.read_bytes())==expected
prelaunch=json.loads((BASE/'jax-division-probe-pc-b-prelaunch.json').read_text(encoding='utf-8-sig'))
assert prelaunch['nvidia_smi_exit']==0 and prelaunch['live_task_python']==[]
assert not any(prelaunch['QJ_old_PID_exists'].values())
assert prelaunch['QJ_actual_parent_returncodes']==[0,0]
target=BASE/'jax-division-probe-pc-b-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'jax-division-probe-pc-b-execution/launch_division_pcb.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/jax-division-probe-pc-b && test ! -e /tmp/drainage-pc-b-20261026 && test ! -e /tmp/noahmp-jax-division-probe-pc-b-stage.tar.gz && test ! -e /tmp/launch_division_pcb.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-jax-division-probe-pc-b-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_division_pcb.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_division_pcb.py --stage /tmp/noahmp-jax-division-probe-pc-b-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('jax-division-probe-pc-b-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('jax-division-probe-pc-b-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

"""Collect one closed PB-v attempt; opaque metadata/hashes only."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
DEST=BASE/'jax-division-probe-pc-b-gpu-closed'
REMOTE='/home/lhwang/work/noahmp-v1/jax-division-probe-pc-b'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main():
    assert not DEST.exists();DEST.mkdir()
    command=['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12',
        *['xuanze-neiwang:'+REMOTE+'/'+n for n in ('gpu-result.tar.gz','gpu-result-hash.json','controller-receipt.json')],str(DEST.resolve())]
    r=subprocess.run(command,capture_output=True,timeout=180)
    (DEST/'scp.stdout').write_bytes(r.stdout);(DEST/'scp.stderr').write_bytes(r.stderr)
    (DEST/'scp-exit.json').write_text(json.dumps(dict(command=command,actual_exit=r.returncode,
        stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)),indent=2)+'\n')
    assert r.returncode==0,r.stderr.decode(errors='replace')
    raw=(DEST/'gpu-result.tar.gz').read_bytes();expected=json.loads((DEST/'gpu-result-hash.json').read_bytes())
    assert sha(raw)==expected['sha256'] and len(raw)==expected['bytes']
    with tarfile.open(DEST/'gpu-result.tar.gz') as archive:
        files={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
    controller=json.loads((DEST/'controller-receipt.json').read_bytes())
    assert files['controller/controller-receipt.json']==(DEST/'controller-receipt.json').read_bytes()
    assert controller['completed'] and controller['stage_unchanged'] and len(controller['actual_parents'])==2
    print(json.dumps(dict(original_GPU_result_sha256=sha(raw),bytes=len(raw),archive_files=len(files),
        actual_parent_returncodes=[x['actual_parent_returncode'] for x in controller['actual_parents']],
        actual_controller_OS_returncode=controller['actual_controller_OS_returncode'],seconds=controller['seconds'])))

if __name__=='__main__':main()

"""Run one read-only stdin reader; retain raw streams and actual SSH exit."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('kind',choices=('prelaunch','progress','closed'));a=p.parse_args()
reader=base/('read_gpu_project_ownership_pcb.py' if a.kind=='prelaunch' else 'read_jax_division_pcb.py')
stem=base/('jax-division-probe-pc-b-'+a.kind)
assert not stem.with_suffix('.json').exists()
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -']
r=subprocess.run(command,input=reader.read_bytes(),capture_output=True,timeout=45)
Path(str(stem)+'.stdout').write_bytes(r.stdout);Path(str(stem)+'.stderr').write_bytes(r.stderr)
Path(str(stem)+'-exit.json').write_text(json.dumps(dict(command=command,actual_exit=r.returncode,reader_sha256=hashlib.sha256(reader.read_bytes()).hexdigest()),indent=2)+'\n')
assert r.returncode==0,r.stderr.decode(errors='replace')
value=json.loads(r.stdout);stem.with_suffix('.json').write_text(json.dumps(value,indent=2)+'\n')
if a.kind=='prelaunch':
    print(json.dumps(value))
else:
    receipts={k:v['value'] for k,v in value['files'].items() if 'receipt' in k}
    print(json.dumps(dict(receipts=receipts,live_handles=value['live_handles'],nvidia_smi=value['nvidia_smi'])))

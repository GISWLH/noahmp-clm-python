import numpy as np,jax,jax.numpy as j,cupy as cp
from jax import lax
s=lax.optimization_barrier
x=np.array([-6.53158,-4.0807,-1.,-12.15789],np.float32)
def old(x):return s(273.15+s(s(j.minimum(x,0.)*4180./2100.)+j.maximum(s(x-79.90430622009569),0.)))
def split(x):return s(273.15+s(s(s(j.minimum(x,0.)*4180.)/2100.)+j.maximum(s(x-79.90430622009569),0.)))
k=cp.RawKernel('extern "C" __global__ void decode(const float* x,float* y){int i=threadIdx.x;y[i]=273.15f+((fminf(x[i],0.f)*4180.f/2100.f)+fmaxf(x[i]-79.90430622009569f,0.f));}','decode',options=('--fmad=false','--prec-div=false'))
a=cp.asarray(x);b=cp.empty_like(a);k((1,),(4,),(a,b));cuda=cp.asnumpy(b)
print('coordinates',x.tolist());print('CUDA',cuda.tolist());print('JAX unseparated',np.asarray(jax.jit(old)(x)).tolist());print('JAX split',np.asarray(jax.jit(split)(x)).tolist())
print(jax.jit(old).lower(j.asarray(x)).compile().as_text())

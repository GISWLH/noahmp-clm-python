# OY normal soil C/N replay — actual EHPC synthetic results

EHPC job `1602.manager` reached **PBS F / Exit_status 0 / Stageout_status 0** on `compute002`; worker and unittest parent also exited0. All **15 tests** ran without skips in **2.961s**. The tests made **27 successful calls to the original normal decomposition physics module**:21 scheduled replay intervals plus6 direct original-function comparison intervals. Coupled-column steps, GPU steps and actual field years were all0. Windows performed only source/AST/hash checks and evidence packaging.

| Independent synthetic check | Actual result |
| --- | --- |
| Small mineral-N competition | Oracle and actual limitation factor both0.0020007887787037333; factor, C7 and N7 maximum absolute errors all0 |
| Newly mineralized N waits one interval | Oracle release0.038359465807576994gN/m²; first uptake0, next uptake0.038359465807576994gN/m²; next-step error0 |
| Six-step replay vs original function | C7, organicN7 and mineralN endpoint differences all0 |
| Six-step separately summed endpoint C budget | Residual−2.6412205755832474e−13gC/m²; sum of original step bounds6.293172740965537e−10gC/m² |
| Six-step separately summed endpoint N budget | Residual8.344019919448442e−16gN/m²; sum of original step bounds5.702607553862777e−11gN/m² |
| Six-step streaming independent absolute step residual maxima | C4.701933287165616e−13gC/m²; N3.838075690598686e−14gN/m² |
| Six-step streaming independent absolute cumulative residual maxima | C4.310996004619483e−13gC/m²; N3.838075690598686e−14gN/m² |

The separately summed endpoint oracle and streaming ledger use different summation orders; both remain within the actual original bounds. No relative-error exemption or1e−4 tolerance replaced conservation. Tests also checked zero N without invented supply, drought/zero litter, deposition plus plant export, litter-before-decay, delayed receiving-pool decomposition, wood transfer of its own organic N, explicit initial inventory differences outside the flux ledger, invalid N/time/rate inputs, calendar/month coverage and refusal of production use. Calendar-only tests inspect full-year timestamp metadata; they do not execute a physical year.

The normal module receives actual prescribed temperature, water potential, explicit litterC7/N7, deposition amount and potential plant demand, with fixed1800s and oxygen1. It computes its own N limitation and actual uptake. Its private replay accepts explicit C7/N7/mineralN; no N is silently derived, raised or forced unlimited. A new explicit initial inventory may differ from a baseline, but the difference is never counted as litter, deposition or a compensating flux. Normal subsequent evolution retains the original C/N equations and bounds.

Preparation manifest `63690d045faa5d197bfcab8a9aa42e5bef033f66ea6e2b12318a99f5dcb72e1d` and execution manifest `73a8cb21182d604123c99dfdfce64d744fcb033e177798ec2c404212376942d7` were unchanged. The exact NM584 source manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f` was verified before and after execution; original `decomposition.py` SHA is `92568251e2884cd96f4a11b3124deb2f6074a0e11e16e598ac497928b7b9b57c`. Independent prelaunch review `bd070ab84c8cebba9e60d740e9eec8889f894d6bac026dddfc277d0d1182d385` found0blocking issues.

The original36-member/35-inventory archive `normal-cn-replay-oy-evidence.tar.gz`, SHA256 `8f3a15472633961d07fd62d452b8a6d34439494073c1d00ab631b3ef9776a67e`, retains all controls, original source/stage/result archives, actual qstat/dispatch/receipts and raw unittest logs. The original preparation README/STATIC_CHECK remain historical prelaunch snapshots and are not rewritten as execution records.

`production_binding_sealed=false` remains enforced. No actual NS/OD annual data, heldout value, conditional fieldC* or usable cold state was read or produced. A future8-training-root yearly application still requires complete original-year closure and a reviewed byte-bound extraction adapter, authenticated original mineral N and defensible explicit organic-N inputs. Prescribed litter/demand replay omits full plant/leaf/NPP feedback; these synthetic results prove neither coupled spinup nor SOC drift below5% per century.

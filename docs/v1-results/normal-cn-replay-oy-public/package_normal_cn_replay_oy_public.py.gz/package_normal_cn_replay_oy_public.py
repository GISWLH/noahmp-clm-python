"""Minimal public wrapper preserving the original closed OY36 evidence bytes."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
label = 'normal-cn-replay-oy-public'
original_package_raw = (ROOT/'normal-cn-replay-oy-package.json').read_bytes()
original_package = json.loads(original_package_raw)
original_raw = (ROOT/original_package['archive']).read_bytes()
assert sha(original_raw) == original_package['sha256'] == '8f3a15472633961d07fd62d452b8a6d34439494073c1d00ab631b3ef9776a67e'
names = [original_package['archive'], 'normal-cn-replay-oy-package.json',
    'NORMAL_CN_REPLAY_OY_RESULTS.md', 'verify_normal_cn_synthetic_oy_archive.py',
    'normal-cn-replay-oy-local-archive-verification.json',
    'normal-cn-replay-oy-actual-independent-review-rg.json',
    'normal-cn-replay-oy-independent-review-rg.json',
    'normal-cn-replay-oy-execution-self-review.json']
artifacts = {name: (ROOT/name).read_bytes() for name in names}
review_raw = artifacts['normal-cn-replay-oy-actual-independent-review-rg.json']
review = json.loads(review_raw)
assert review['passed'] is True and review['blocking_findings'] == []
with tarfile.open(fileobj=io.BytesIO(original_raw)) as archive:
    for name in ['actual-pbs-qstat.txt', 'current/receipt.json',
                 'current/quantified-synthetic-diagnostics.json',
                 'current/unittest.stdout.txt', 'current/unittest.stderr.txt']:
        artifacts['actual-readout/'+name] = archive.extractfile(name).read()
artifacts['package_normal_cn_replay_oy_public.py'] = Path(__file__).read_bytes()
inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in artifacts.items()}
artifacts['inventory.json'] = (json.dumps(inventory, indent=2)+'\n').encode()
destination = ROOT/(label+'-evidence.tar.gz'); assert not destination.exists()
with tarfile.open(destination, 'w:gz') as archive:
    for name, raw in sorted(artifacts.items()):
        item = tarfile.TarInfo(name); item.size = len(raw); item.mode = 0o644
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(destination) as archive:
    assert {m.name: archive.extractfile(m).read() for m in archive} == artifacts
package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
    artifacts=len(artifacts), publication_label=label, pbs_job='1602.manager', actual_pbs_state='F',
    actual_pbs_exit=0, actual_worker_exit=0, actual_unittest_parent_exit=0, tests=15, test_seconds=2.961,
    decomposition_module_steps=27, synthetic_schedule_steps=21,
    closed_evidence_sha256=sha(original_raw), closed_package_sha256=sha(original_package_raw),
    actual_review_sha256=sha(review_raw), production_binding_sealed=False,
    actual_field_years=0, coupled_column_steps=0, gpu_steps=0,
    scope='Actual EHPC1602 F0/worker0/parent0,15synthetic tests with27 original normal-decomposition calls (21scheduled replay+6direct comparison), independent C/N oracles and original budgets. Original36-member archive/package remain byte-exact; concise actual readouts and independent reviews added. No actual annual field data, coupled-column/GPU simulation, cold initializer or SOC/spinup acceptance. Production binding remains false.')
(ROOT/(label+'-package.json')).write_text(json.dumps(package, indent=2)+'\n', encoding='utf-8')
print(json.dumps(package, indent=2))

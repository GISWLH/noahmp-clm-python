"""EHPC-only OY synthetic tests; normal decomposition only; no actual field year or coupled model."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import os
import re
import resource
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-normal-cn-replay-oy')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


def main():
    assert sys.version_info >= (3, 10)
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    result = Path(sys.argv[1]).resolve()
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
    result.mkdir()
    started = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
        python_executable=sys.executable, numpy_version=importlib.metadata.version('numpy'),
        passed=False, error=None, unittest_parent_returncode=None, unittest_timed_out=False,
        coupled_column_steps=0, gpu_steps=0, actual_field_years=0,
        decomposition_module_steps=None, synthetic_schedule_steps=None,
        production_binding_sealed=False, synthetic_test_run=True)
    try:
        inventory = json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/name).read_bytes()) == digest for name, digest in inventory.items())
        eraw = (STAGE/'execution/CONTROLS_SHA256.json').read_bytes(); execution = json.loads(eraw)
        assert all(sha((STAGE/'execution'/name).read_bytes()) == digest for name, digest in execution.items())
        run = json.loads((STAGE/'execution/RUN_BINDINGS.json').read_bytes())
        assert run['authorized'] is True and run['expected_tests'] == 15
        prep_raw = (STAGE/'preparation/CONTROLS_SHA256.json').read_bytes(); prep = json.loads(prep_raw)
        assert sha(prep_raw) == run['preparation_manifest_sha256'] and len(prep) == 4
        assert all(sha((STAGE/'preparation'/name).read_bytes()) == digest for name, digest in prep.items())
        review_raw = (STAGE/'independent-review.json').read_bytes(); review = json.loads(review_raw)
        assert sha(review_raw) == run['independent_review_sha256']
        assert review['passed'] is True and review['blocking_findings'] == []
        assert review['controls_manifest_sha256'] == run['preparation_manifest_sha256'] and review['controls'] == 4
        binding = json.loads((STAGE/'preparation/BINDINGS.json').read_bytes())
        assert binding['production_binding_sealed'] is False and binding['actual_field_years_available'] is False
        for folder, index in [('preparation', prep), ('execution', execution)]:
            dest = result/folder; dest.mkdir()
            for name in [*index, 'CONTROLS_SHA256.json']:
                shutil.copyfile(STAGE/folder/name, dest/name)
        shutil.copyfile(STAGE/'independent-review.json', result/'independent-review.json')
        source_path = STAGE/'inputs/climatology-final-candidate-nm-source.tar.gz'
        assert sha(source_path.read_bytes()) == run['source_archive_sha256']
        with tarfile.open(source_path) as source:
            members = source.getmembers()
            assert all(m.isfile() for m in members) and len({m.name for m in members}) == 585
            raw = source.extractfile('SOURCE_SHA256.json').read()
            assert sha(raw) == run['source_manifest_sha256'] == binding['source_manifest_sha256']
            manifest = json.loads(raw)
            assert len(manifest) == 584 and {m.name for m in members} == set(manifest) | {'SOURCE_SHA256.json'}
            assert all(sha(source.extractfile(name).read()) == digest for name, digest in manifest.items())
        (result/'SOURCE_SHA256.json').write_bytes(raw)
        source_root = result.parent/'source-nm584'; source_root.mkdir()
        with tarfile.open(source_path) as source:
            for name in [*manifest, 'SOURCE_SHA256.json']:
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                target = source_root/name; target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.extractfile(name).read())
        assert all(sha((source_root/name).read_bytes()) == digest for name, digest in manifest.items())
        work = result/'preparation'
        tree = ast.parse((work/'test_normal_cn_replay_oy.py').read_bytes())
        tests = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
        assert len(tests) == len(set(tests)) == 15
        env = os.environ.copy(); env.pop('PYTHONPATH', None); env.pop('PYTHONHOME', None)
        env.update(OY_SOURCE_ROOT=str(source_root), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
        command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(work), '-p', 'test_normal_cn_replay_oy.py', '-v']
        save(result/'unittest-command.json', dict(argv=command, cwd=str(work), tests=tests))
        with (result/'unittest.stdout.txt').open('w') as out, (result/'unittest.stderr.txt').open('w') as err:
            process = subprocess.Popen(command, cwd=work, env=env, stdout=out, stderr=err)
            receipt['actual_unittest_pid'] = process.pid
            try:
                code = process.wait(timeout=480)
            except subprocess.TimeoutExpired:
                receipt['unittest_timed_out'] = True
                process.kill(); code = process.wait()
        receipt['unittest_parent_returncode'] = code
        (result/'unittest-parent-exit.txt').write_text(str(code) + '\n')
        stderr = (result/'unittest.stderr.txt').read_text()
        count = re.search(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
        assert code == 0 and not receipt['unittest_timed_out'], stderr
        assert count and int(count.group(1)) == 15 and re.search(r'^OK$', stderr, re.M)
        assert 'skipped=' not in stderr and 'skipped ' not in stderr
        prefix = 'OY_NUMERICAL_DIAGNOSTICS '
        parsed = [json.loads(line[len(prefix):]) for line in (result/'unittest.stdout.txt').read_text().splitlines() if line.startswith(prefix)]
        assert len(parsed) == 1
        diagnostics = parsed[0]
        assert diagnostics['decomposition_module_steps'] == diagnostics['decomposition_module_successful_steps'] == run['expected_decomposition_module_steps'] == 27
        assert diagnostics['synthetic_schedule_steps'] == run['expected_synthetic_schedule_steps'] == 21
        assert diagnostics['coupled_column_steps'] == diagnostics['gpu_steps'] == diagnostics['actual_field_years'] == 0
        assert len(diagnostics['cases']) == 3
        save(result/'quantified-synthetic-diagnostics.json', diagnostics)
        assert all(sha((source_root/name).read_bytes()) == digest for name, digest in manifest.items())
        receipt.update(decomposition_module_steps=diagnostics['decomposition_module_steps'],
            decomposition_module_successful_steps=diagnostics['decomposition_module_successful_steps'],
            synthetic_schedule_steps=diagnostics['synthetic_schedule_steps'], source_before_after_584_exact=True)
        assert all(sha((work/name).read_bytes()) == digest for name, digest in prep.items())
        assert all(sha((STAGE/name).read_bytes()) == digest for name, digest in inventory.items())
        receipt.update(passed=True, actual_test_count=15, actual_test_seconds=float(count.group(2)),
            test_names=tests, preparation_manifest_sha256=sha(prep_raw), execution_manifest_sha256=sha(eraw),
            independent_review_sha256=sha(review_raw), source_manifest_sha256=run['source_manifest_sha256'],
            source_archive_sha256=run['source_archive_sha256'], source_files_byte_verified=584,
            quantified_synthetic_diagnostics_sha256=sha((result/'quantified-synthetic-diagnostics.json').read_bytes()),
            preparation_and_source_unchanged=True,
            scope='Synthetic-only actual normal soil decomposition, counted module steps and original C/N budget bounds. No actual field-year data, coupled-column/GPU runs, initializer export or SOC acceptance.')
    except Exception as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        (result/'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic() - started
    receipt['maximum_controller_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    save(result/'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

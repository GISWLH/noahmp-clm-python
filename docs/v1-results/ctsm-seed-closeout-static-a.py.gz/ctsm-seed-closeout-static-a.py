from pathlib import Path
import ast
import gzip
import hashlib
import json

r = Path(__file__).resolve().parents[2]
base = r / 'docs/v1-results'
sha = lambda data: hashlib.sha256(data).hexdigest()
groups = {
    'ctsm-qia-seed-pq-a': '575843fa08c4f685ae12c67ba199424cc86df33b8881719a6b81c03083d26d0c',
    'ctsm-qia-seed-r-a': '47d570940cf2cdc2581acf9fd639a4711664d95c3622768349c5b34c5faf8c95',
    'qia-stem-device-day-a': 'f89f148e524ac7a86506c6c1b76deb025c62a2af3dac94c53671882c2ea51758',
    'qia-fresh-phase-numpy-prefix-b': 'e2153494873f139679357d76622fb6b97c2433e7d6208674e574e5ed6268b3f7',
}

def read(group, name):
    p = base / group / name
    raw = p.read_bytes()
    return gzip.decompress(raw) if name.endswith('.gz') else raw

counts = {}
python_files = 0
for name, digest in groups.items():
    assert sha((r / 'outputs/v1' / (name + '-evidence.tar.gz')).read_bytes()) == digest
    m = json.loads(read(name, 'manifest.json'))
    assert m['archive_sha256'] == digest
    for item in m['artifacts']:
        data = (base / name / item['path']).read_bytes()
        assert sha(data) == item['stored_sha256']
        raw = gzip.decompress(data) if item['path'] == item['source'] + '.gz' else data
        assert sha(raw) == item['source_sha256']
        if item['source'].endswith('.py'):
            ast.parse(raw.decode('utf-8-sig'))
            python_files += 1
    counts[name] = len(m['artifacts'])

for group, root in [('ctsm-qia-seed-pq-a', 'ctsm-qia-run-q'), ('ctsm-qia-seed-r-a', 'ctsm-qia-run-r')]:
    config = json.loads(read(group, root + '/configuration.json.gz'))
    assert read(group, root + '/pbs-exit.txt.gz').strip() == b'0'
    assert config['official_model_returncode'] == 0 and config['upstream_original_bytes_unchanged']
    assert all(s['returncode'] == 0 for s in config['stages'])
    summary = json.loads(read(group, 'summary.json.gz'))
    assert summary['history_samples'] == 17521 and summary['last_nstep'] == 17520 and len(summary['raw_history']) == 2
    for row in summary['raw_history']:
        assert sha(read(group, root + '/workspace/' + row['member'])) == row['sha256']

strict = json.loads(read('qia-stem-device-day-a', 'receipt.json.gz'))
exit = json.loads(read('qia-stem-device-day-a', 'exit.json.gz'))
assert exit['returncode'] == 0 and exit['passed'] and sha(read('qia-stem-device-day-a', 'receipt.json.gz')) == exit['receipt_sha256']
assert strict['failure'] is None and strict['device_barriers'] == ['jax-complete', 'cupy-complete']
assert strict['source_manifest_sha256'] == 'f03e43577ba6c0a2c38f3f19f292f868e5075cf14af94b917c48c5ebe304610e'
assert strict['result']['same_precision_maximum_absolute'] == 3.637978807091713e-12
assert all(v['bias_pass'] for v in strict['result']['metrics'].values())
assert strict['result']['instantaneous_flux_criteria_met']

prefix = json.loads(read('qia-fresh-phase-numpy-prefix-b', 'report-snapshot.json.gz'))
assert prefix['status'] == 'running' and prefix['steps_completed'] == 192 and prefix['steps_requested'] == 17520 and prefix['source_unchanged']
for name, field in [('model_npz', 'model_npz_sha256'), ('checkpoint_file', 'checkpoint_sha256')]:
    assert sha(read('qia-fresh-phase-numpy-prefix-b', 'trajectory/' + prefix[name])) == prefix[field]
mraw = read('qia-fresh-phase-numpy-prefix-b', 'SOURCE_SHA256.json.gz')
assert sha(mraw) == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
checked = 0
for name, expected in json.loads(mraw).items():
    if name.startswith(('src/', 'tests/', 'benchmarks/')):
        raw = (r / name).read_bytes()
        assert expected in {sha(raw), sha(raw.replace(b'\r\n', b'\n'))}, name
        checked += 1

snapshot = base / 'v1-live-20261019-1209.json'
assert len(json.loads(snapshot.read_text())['snapshots']) == 2
control = r / 'outputs/v1/inspect_active_1140_a.py'
(base / 'v1-live-20261019-1209-control.py.gz').write_bytes(gzip.compress(control.read_bytes(), mtime=0))
result = dict(scope='Local hashes/metadata/AST only; no model, pytest, data calibration or scientific arrays executed locally. Original numerical model/NetCDF analysis on EHPC PBS; GPU on xuanze. Source510 runtime matches current repository with only CRLF-to-LF representation permitted. Strict48 has older506F identity and never credits510 canonical1250 or newer year precision/science.',
              groups=counts, artifacts=sum(counts.values()), python_artifacts_ast_checked=python_files,
              source510_runtime_files_matching=checked, source510_manifest_sha256=sha(mraw),
              strict48_old506F_source_manifest_sha256=strict['source_manifest_sha256'], strict48_actual_controller_and_worker_returncode=0,
              strict48_same_precision_maximum_absolute=strict['result']['same_precision_maximum_absolute'],
              source510_numpy_original_cold_steps=192, original_requested_steps=17520, numpy_status='running',
              official_Q_and_R_positive_intervals_each=17520, official_Q_and_R_model_and_pbs_returncodes=0,
              raw_official_history_netcdf_files_verified=4, live_snapshot_sha256=sha(snapshot.read_bytes()),
              live_snapshot_control_sha256=sha(control.read_bytes()), audit_control_sha256=sha(Path(__file__).read_bytes()))
(base / 'ctsm-seed-closeout-static-a.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
(base / 'ctsm-seed-closeout-static-a.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps(result))

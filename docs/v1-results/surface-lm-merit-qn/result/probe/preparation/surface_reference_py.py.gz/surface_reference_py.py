"""Prepared EHPC NumPy reference for actual captured NM surface inputs.

This module does not reconstruct a column, rerun MOST, or read a checkpoint.
The caller must authenticate the closed PR capture before supplying its actual
kernel arrays. No capture or numerical execution existed when this was written.
"""
import hashlib
import json
import os
from pathlib import Path
import socket
import sys


MANIFEST_SHA256 = '17b3a586c8cb34dfdd7e893788a6cfc3edbbaf0bf080d988f1b85daac811b197'


def bind_source(source_root):
    """Verify original NM584 before scientific imports; EHPC execution only."""
    if os.name == 'nt' or not os.environ.get('PBS_JOBID') or socket.gethostname().split('.')[0] != 'compute002':
        raise RuntimeError('Numerical reference requires an EHPC compute002 PBS job')
    root = Path(source_root).resolve()
    raw = (root / 'SOURCE_SHA256.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != MANIFEST_SHA256:
        raise ValueError('Expected the original NM source manifest')
    manifest = json.loads(raw)
    if len(manifest) != 584:
        raise ValueError('Expected all 584 original source identities')
    for name, expected in manifest.items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Frozen source mismatch: ' + name)
    for name, module in tuple(sys.modules.items()):
        if name == 'noahmp_clm' or name.startswith('noahmp_clm.') or name in (
                'test_gpu_canopy_surface', 'test_gpu_canopy_phase_surface', 'test_gpu_snicar'):
            location = getattr(module, '__file__', None)
            if location is None or not Path(location).resolve().is_relative_to(root):
                raise ValueError('A scientific module was imported from another source: ' + name)
    sys.path[:0] = [str(root / 'src'), str(root / 'tests')]
    return root


def array_identity(array):
    """Describe actual captured bytes, without changing dtype or shape."""
    return dict(dtype=array.dtype.str, shape=list(array.shape),
                payload_sha256=hashlib.sha256(array.tobytes(order='C')).hexdigest())


def reference_one(source_root, kernel_arrays, row_index, *, coefficients, profiled,
                  exchange_extension=None, stem_area=None, vic=None, canopy_optics=None):
    """Use captured effective32 input values in the unchanged NumPy64 solver.

    `kernel_arrays` are the nine actual main-kernel arrays; `coefficients` is
    its actual coefficient argument, not a repack of the Python dataclass.
    Optional arrays likewise are actual encoded arguments. Current PR fixes
    canopy_optics=None; the optional decode below is not evidence of a tested
    optics path. `profiled` is the observed _kernel flag.
    """
    root = bind_source(source_root)
    import numpy as np
    from noahmp_clm.column import SoilParams
    from noahmp_clm.physics.snowpack import Snowpack
    from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
    from noahmp_clm.physics.canopy_interception import CanopyCondensate
    from noahmp_clm.physics.canopy_energy import CanopyExchange
    from noahmp_clm.physics.canopy_column import surface_step
    from noahmp_clm.physics.photosynthesis import LeafParameters
    from noahmp_clm.gpu.canopy_phase_surface import validate_phase_surface, validate_exchange_extension
    from noahmp_clm.gpu.photosynthesis import prepare_canopy_leaf_parameters

    if len(kernel_arrays) != 9 or type(profiled) is not bool:
        raise ValueError('Nine captured arrays and a literal observed profile flag required')
    if any(type(x) is not np.ndarray or x.dtype != (np.int32 if k == 3 else np.float32)
           for k, x in enumerate(kernel_arrays)):
        raise ValueError('Actual CUDA arrays must already be plain int32/float32; no implicit cast')
    ncol = len(kernel_arrays[0])
    if type(row_index) is not int or not 0 <= row_index < ncol:
        raise ValueError('Invalid captured row index')
    optional = dict(exchange_extension=exchange_extension, stem_area=stem_area,
                    vic=vic, canopy_optics=canopy_optics)
    shapes = dict(exchange_extension=(ncol, 2), stem_area=(ncol, 10),
                  vic=(ncol, 8), canopy_optics=(ncol, 8))
    for name, value in optional.items():
        if value is not None and (type(value) is not np.ndarray or value.dtype != np.float32 or value.shape != shapes[name]):
            raise ValueError('Expected an actual encoded float32 array: ' + name)
    expected_shape = (ncol, 10, 10) if profiled else (10,)
    if type(coefficients) is not np.ndarray or coefficients.dtype != np.float32 or coefficients.shape != expected_shape:
        raise ValueError('Expected actual encoded scalar/profile coefficients and observed profile flag')
    # Reuse the original validator on ALREADY captured float32 coefficients;
    # never reconstruct them from the Python parameter object's nominal values.
    checked, checked_profile = prepare_canopy_leaf_parameters(coefficients, np, ncol, np.float32)
    if checked_profile != profiled or array_identity(checked) != array_identity(coefficients):
        raise ValueError('Original coefficient validation changed the actual input')
    validate_phase_surface(kernel_arrays, np, stem_area=stem_area)
    if exchange_extension is not None:
        validate_exchange_extension(exchange_extension, ncol, np)
    if vic is not None:
        from noahmp_clm.gpu.vic import validate_vic
        validate_vic(vic, ncol, np)
    if canopy_optics is not None:
        from noahmp_clm.gpu.canopy_optics import validate_canopy_optics
        leaf = kernel_arrays[4]
        validate_canopy_optics(leaf if stem_area is None else leaf + stem_area, leaf, canopy_optics, np)
    observed = dict(zip(('snow', 'soil', 'soil_parameters', 'options', 'leaf_area',
                        'exchange', 'factors', 'stores_roots', 'condensate'), kernel_arrays))
    observed['coefficients'] = coefficients
    observed.update({key: value for key, value in optional.items() if value is not None})
    before = {key: array_identity(value) for key, value in observed.items()}

    # This decode follows NM test_gpu_canopy_phase_surface.reference. Float32
    # values lift exactly to float64. The original captured bytes remain intact.
    c, g, p, o, a, u, f, v, condensate = (x[row_index] for x in kernel_arrays)
    snow_count = int(o[0])
    c, g, p, a, u, f, v, condensate = [np.asarray(x, float) for x in (c, g, p, a, u, f, v, condensate)]
    pack = Snowpack(c[:snow_count, 0], c[:snow_count, 1], c[:snow_count, 2], c[:snow_count, 3], c[:snow_count, 4:])
    props = SoilParams(smcmax=p[0], bexp=p[1], smcref=p[2], satdk=p[3],
                       quartz=p[4], smcwlt=p[5], saturated_suction_m=p[6])
    soil = SoilEnthalpyState(g[:, 0], g[:, 1], g[:, 2], props, int(o[1]))
    extra = () if exchange_extension is None else tuple(float(x) for x in exchange_extension[row_index])
    exchange = CanopyExchange(*u[:11], *extra)
    leaf_parameters = (LeafParameters.from_layer_rows(coefficients[row_index]) if profiled
                       else LeafParameters(*(float(x) for x in coefficients)))
    options = dict(leaf_parameters=leaf_parameters)
    if stem_area is not None:
        options['stem_area'] = np.asarray(stem_area[row_index], float)
    if canopy_optics is not None:
        from noahmp_clm.physics.canopy_optics import CanopyOptics
        optics = canopy_optics[row_index]
        options['canopy_optics'] = CanopyOptics(*(tuple(float(x) for x in optics[k:k + 2]) for k in (0, 2, 4, 6)))
    if vic is not None and vic[row_index, 0] == 1:
        from noahmp_clm.physics.vic import VICParameters
        options['infiltration_parameters'] = VICParameters(*(float(x) for x in vic[row_index, 2:]))
    try:
        pack, soil, _, d = surface_step(
            pack, soil, v[0], a, u[11], u[12], exchange,
            canopy_condensate=CanopyCondensate(condensate[:, 0], condensate[:, 1]), root_weights=v[3:],
            vegetated_fraction=u[13], transpiration_limit=u[16], ground_emissivity=u[18], ground_albedo=u[19:21],
            diffuse_fraction=u[21], cosine_zenith=u[22], nitrogen_factor=f[:, 0], water_stress=f[:, 1], **options)
    finally:
        after = {key: array_identity(value) for key, value in observed.items()}
        if after != before:
            raise RuntimeError('Reference mutated an actual captured input')
        bind_source(root)
    d['snow_cells'] = np.zeros((5, 9))
    d['snow_cells'][:, 3] = 54.5
    d['snow_cells'][:len(pack.mass)] = np.column_stack((pack.mass, pack.enthalpy, pack.thickness, pack.radius_um, pack.impurities))
    d['snow_counts'] = len(pack.mass)
    d['soil_cells'] = np.column_stack((soil.water, soil.enthalpy, soil.dz))
    d['soil_temperature'] = soil.temperature
    d['soil_parameters'], d['freezing_option'] = props, int(o[1])
    d['condensate'] = np.column_stack((d['canopy_condensate'].mass, d['canopy_condensate'].enthalpy))
    return d, dict(row_index=row_index, profiled=profiled, actual_input_identities=before,
                   captured_inputs_unchanged=True, source_manifest_sha256=MANIFEST_SHA256,
                   arithmetic='NumPy float64 on exact effective float32 input values',
                   radiation='independently recomputed by original NumPy physics',
                   full_column_calls=0, surface_step_calls=1)


def inspect_raw_output(source_root, raw):
    """Decode the original raw741 layout, retaining every row's failure facts."""
    bind_source(source_root)
    import numpy as np
    from noahmp_clm.gpu.canopy_phase_surface import unpack_phase_surface
    if type(raw) is not np.ndarray or raw.dtype != np.float32 or raw.ndim != 2 or raw.shape[1] != 741:
        raise ValueError('Expected the captured float32 (n,741) output, without filtering rows/fields')
    decoded = unpack_phase_surface(raw)
    rows = []
    for k in range(len(raw)):
        finite = np.isfinite(raw[k])
        scalar = lambda index: float(raw[k, index]) if finite[index] else None
        rows.append(dict(row_index=k, raw_identity=array_identity(raw[k]),
            all_741_finite=bool(finite.all()), nonfinite_field_indices=np.flatnonzero(~finite).tolist(),
            raw_flags={name: scalar(index) for name, index in (
                ('joint_heat_341', 341), ('combined_valid_362', 362),
                ('surface_converged_433', 433), ('canopy_phase_converged_509', 509))},
            raw_diagnostics={name: scalar(index) for name, index in (
                ('surface_temperature_360', 360), ('surface_residual_361', 361),
                ('evaluations_432', 432), ('bracket_left_439', 439), ('bracket_right_440', 440),
                ('phase_iterations_508', 508), ('phase_restarts_732', 732), ('phase_max_residual_733', 733))},
            original_wrapper_row_success=bool(finite.all() and decoded['converged'][k])))
    return decoded, rows


def compare_row(source_root, kernel_arrays, raw, row_index, reference):
    """Report common-field differences and unchanged module checks, no year pass.

    A failed CUDA row is still failed even if common outputs are close. Every
    raw field remains in PR. There is no claimed 1:1 NumPy counterpart for all
    741 implementation diagnostics, and this is not a same-precision check.
    """
    bind_source(source_root)
    import numpy as np
    from test_gpu_canopy_surface import science
    from test_gpu_canopy_phase_surface import budgets
    decoded, facts = inspect_raw_output(source_root, raw)
    if len(raw) != len(kernel_arrays[0]) or not 0 <= row_index < len(raw):
        raise ValueError('Captured input/output row alignment mismatch')
    one = {key: np.asarray(value[row_index]) for key, value in decoded.items() if not isinstance(value, dict)}
    diffs = {}
    for key in sorted(one.keys() & reference.keys()):
        a, b = np.asarray(one[key]), np.asarray(reference[key])
        if a.dtype.kind not in 'biuf' or b.dtype.kind not in 'biuf' or a.shape != b.shape:
            continue
        finite = bool(np.isfinite(a).all() and np.isfinite(b).all())
        diffs[key] = dict(shape=list(a.shape), finite=finite,
                          maximum_absolute_difference=(float(np.max(abs(a.astype(float)-b.astype(float)), initial=0.)) if finite else None))
    checks = {}
    for name, action in (
            ('original_surface_science', lambda: science(one, reference, np.float32)),
            ('original_condensate_mass', lambda: np.testing.assert_allclose(one['condensate'][:, 0], reference['condensate'][:, 0], rtol=.1, atol=.0001)),
            ('original_condensate_heat', lambda: np.testing.assert_allclose(one['condensate'][:, 1], reference['condensate'][:, 1], rtol=.1, atol=1800.)),
            ('original_hard_budgets', lambda: budgets(tuple(x[row_index:row_index+1] for x in kernel_arrays),
                {key: value[row_index:row_index+1] for key, value in decoded.items() if not isinstance(value, dict)}))):
        try:
            result = action()
            checks[name] = dict(passed=True, original_return=result)
        except Exception as exc:
            checks[name] = dict(passed=False, exception_type=type(exc).__name__, message=str(exc))
    return dict(raw=facts[row_index], common_numeric_differences=diffs, checks=checks,
                diagnostic_comparison_only=True, scientific_year_acceptance=False,
                failed_cuda_row_retained=not facts[row_index]['original_wrapper_row_success'])

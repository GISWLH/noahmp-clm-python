"""Copy-only external LM trace for the one unchanged actual-Qia pytest item."""
from pathlib import Path
import copy
import hashlib
import json
import os
import sys
import traceback

import pytest


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    parameters=getattr(getattr(item,'callspec',None),'params',{})
    if item.path.name!='test_actual_surface_py.py' or parameters.get('row')!=0:
        yield
        return
    root=Path(os.environ['PY_RESULT']);target=root/'source/src/noahmp_clm/physics/canopy_phase_energy.py'
    output=root/'external-lm-trace-qn';output.mkdir(exist_ok=False)
    binding=json.loads((root/'preparation/BINDINGS.json').read_bytes())
    raw=target.read_bytes();assert hashlib.sha256(raw).hexdigest()==binding['candidate_phase_sha256']
    lines=raw.decode().splitlines();calls=[];live={};errors=[]
    allowed=('x','lower','upper','active','phase_active','cap','iteration','used_iterations','max_iterations',
        'refresh','residual','jac','scale','scaled','normal','gradient','damping','matrix','factor','direction',
        'alpha','trial','displacement','norm','linear','linear_change','predicted','trial_residual','actual','ratio','record')
    anchors={
        'if detail is None:detail=call(x,True)':'iteration_entered',
        'if refresh:':'current_residual_before_J_decision',
        'if damping is None:damping=max(np.finfo(float).eps,1e-3*float(np.max(np.diag(normal))))':'J_scaling_normal_gradient_complete',
        'matrix=normal+damping*np.eye(n+2)':'damping_before_linear_system',
        'alpha=1./max(1.,float(np.max(abs(direction)/cap)))':'finite_direction_complete',
        'trial=np.clip(x+alpha*direction,lower,upper);displacement=trial-x':'common_alpha_complete',
        'if not np.isfinite(alpha) or alpha<=0. or not np.any(displacement):':'trial_and_displacement_complete',
        "record['rejected']+=1;record['reason']='no_feasible_displacement';return record":'reject_no_feasible_displacement',
        'if not np.isfinite(predicted) or predicted<=0.:':'linear_prediction_complete',
        "record['rejected']+=1;damping*=10.;continue":'reject_nonpositive_prediction',
        'actual=float((residual-trial_residual)@(residual+trial_residual));ratio=actual/predicted':'original_trial_residual_complete',
        'if actual>0. and np.isfinite(ratio) and ratio>=.1:':'actual_reduction_and_ratio_complete',
        "x=trial;detail=trial_detail;record['x']=x.copy();record['accepted']+=1;refresh=True":'accept_original_strict_descent',
        "record['rejected']+=1;damping*=10.":'reject_original_reduction_or_ratio'
    }
    assert all(sum(line.strip()==text for line in lines)==1 for text in anchors)
    def snapshot(frame,event,anchor,arg=None):
        call=calls[live[id(frame)]];values=frame.f_locals;iteration=values.get('iteration')
        if anchor=='J_scaling_normal_gradient_complete':call['ages']['J_iteration']=iteration
        if anchor=='finite_direction_complete':call['ages']['direction_iteration']=iteration
        if anchor=='linear_prediction_complete':call['ages']['prediction_iteration']=iteration
        if anchor=='original_trial_residual_complete':call['ages']['trial_iteration']=iteration
        entry=dict(event=event,anchor=anchor,iteration=iteration,source_line=frame.f_lineno,
            source_text=lines[frame.f_lineno-1],line_event_before_execution=(event=='line'),field_ages=copy.deepcopy(call['ages']),
            locals={name:copy.deepcopy(values[name]) for name in allowed if name in values})
        if values.get('detail') is not None:
            entry['already_computed_detail']={name:copy.deepcopy(values['detail'][name]) for name in ('solver_residual','layer_residual') if name in values['detail']}
        if event=='return':entry['returned_record']=copy.deepcopy(arg)
        if event=='exception':entry['exception_type']=arg[0].__name__;entry['exception_message']=str(arg[1])
        call['events'].append(entry)
    def trace(frame,event,arg):
        if frame.f_code.co_name!='_dry_lm_rescue' or frame.f_code.co_filename!=str(target):return None
        try:
            if event=='call':
                live[id(frame)]=len(calls)
                calls.append(dict(ordinal=len(calls),events=[],ages=dict(J_iteration=None,direction_iteration=None,prediction_iteration=None,trial_iteration=None)))
                snapshot(frame,event,'original_helper_entry')
            elif event=='line':
                anchor=anchors.get(lines[frame.f_lineno-1].strip())
                if anchor:snapshot(frame,event,anchor)
            elif event=='return':snapshot(frame,event,'original_helper_return',arg);live.pop(id(frame))
            elif event=='exception':snapshot(frame,event,'original_helper_exception',arg)
        except BaseException:errors.append(traceback.format_exc())
        return trace
    previous=sys.gettrace();outcome=None
    try:
        if previous is None:sys.settrace(trace)
        else:errors.append('An existing trace function was left unchanged; external capture inconclusive.')
        outcome=yield
    finally:
        sys.settrace(previous)
        packet=dict(nodeid=item.nodeid,source_phase_sha256=hashlib.sha256(raw).hexdigest(),calls=calls,observer_errors=errors,
            extra_evaluate_calls=0,extra_Jacobian_computations=0,source_or_model_locals_assigned=False,
            original_test_exception=str(outcome.excinfo[1]) if outcome is not None and outcome.excinfo else None)
        status=dict(nodeid=item.nodeid,helper_calls=len(calls),observer_errors=errors,extra_evaluate_calls=0,extra_Jacobian_computations=0,
            source_after_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),original_test_outcome_unchanged=True,summaries=[])
        for call in calls:
            returns=[event for event in call['events'] if event['event']=='return']
            if not returns:continue
            event=returns[-1];record=event['returned_record'];values=event['locals']
            if not isinstance(record,dict):
                status['observer_errors'].append('Helper returned no record after an original exception; no physical outcome was replaced.')
                continue
            residual=event.get('already_computed_detail',{}).get('solver_residual')
            status['summaries'].append(dict(helper_call=call['ordinal'],returned=True,reason=record['reason'],converged=record['converged'],
                last_iteration=record['last_iteration'],accepted=record['accepted'],rejected=record['rejected'],
                evaluate_calls=record['evaluate_calls'],evaluate_returns=record['evaluate_returns'],
                lambda_at_return=float(values['damping']) if values.get('damping') is not None else None,
                max_original_residual_at_return=max(abs(float(v)) for v in residual) if residual is not None else None))
        try:
            from run_reference_pt import dump_return
            dump_return(output/'observed',packet)
        except BaseException:
            status['observer_errors'].append(traceback.format_exc())
        # Summary contains only finite counters, hashes and pre-existing computed scalars.
        def safe(value):
            if isinstance(value,float) and (value!=value or value in (float('inf'),-float('inf'))):return dict(finite=False,hex=value.hex())
            if isinstance(value,dict):return {k:safe(v) for k,v in value.items()}
            if isinstance(value,list):return [safe(v) for v in value]
            return value
        (output/'status.json').write_text(json.dumps(safe(status),indent=2,allow_nan=False)+'\n')

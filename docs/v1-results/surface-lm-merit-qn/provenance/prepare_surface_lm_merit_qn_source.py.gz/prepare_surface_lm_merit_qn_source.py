"""Private584-source variant: only stable LM merit-difference arithmetic."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-merit-qn'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-source-preparation');assert not prep.exists();prep.mkdir()
    old_raw=(BASE/'surface-dry-lm-py-source.tar.gz').read_bytes()
    assert sha(old_raw)=='e83342c1b9634e0f12fe898aafd4e49e8e16477b07403bb20b8b3aa5fcf9af92'
    with tarfile.open(fileobj=io.BytesIO(old_raw)) as t:files={m.name:t.extractfile(m).read() for m in t if m.isfile()}
    original_index=json.loads(files.pop('SOURCE_SHA256.json'));assert len(files)==584
    assert {n:sha(raw) for n,raw in files.items()}==original_index
    filename='src/noahmp_clm/physics/canopy_phase_energy.py';original=files[filename]
    old_pred=b'        predicted=norm-float(linear@linear)\n'
    new_pred=b'        linear_change=jac@displacement\n        predicted=-2.*float(residual@linear_change)-float(linear_change@linear_change)\n'
    old_actual=b'        actual=norm-float(trial_residual@trial_residual);ratio=actual/predicted\n'
    new_actual=b'        actual=float((residual-trial_residual)@(residual+trial_residual));ratio=actual/predicted\n'
    assert original.count(old_pred)==original.count(old_actual)==1
    candidate=original.replace(old_pred,new_pred).replace(old_actual,new_actual)
    assert candidate.replace(new_actual,old_actual).replace(new_pred,old_pred)==original
    def evaluate(raw):
        tree=ast.parse(raw);outer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='solve_canopy_phase_energy')
        return next(n for n in outer.body if isinstance(n,ast.FunctionDef) and n.name=='evaluate')
    assert ast.dump(evaluate(original),include_attributes=False)==ast.dump(evaluate(candidate),include_attributes=False)
    before_evaluate=ast.get_source_segment(original.decode(),evaluate(original)).encode()
    after_evaluate=ast.get_source_segment(candidate.decode(),evaluate(candidate)).encode();assert before_evaluate==after_evaluate
    files[filename]=candidate
    index={n:sha(raw) for n,raw in sorted(files.items())}
    assert sum(index[n]==original_index[n] for n in index)==583
    files['SOURCE_SHA256.json']=encode(index)
    target=BASE/(LABEL+'-source.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(files.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==files
    proof=dict(parent_source_archive_sha256=sha(old_raw),candidate_source_archive_sha256=sha(target.read_bytes()),
        parent_manifest_sha256='6dfcfee523d5108d51152884ee7220cf787038146d434c79846072af821c3166',
        candidate_manifest_sha256=sha(files['SOURCE_SHA256.json']),source_files=584,unchanged_other_files=583,
        changed_file=filename,parent_phase_sha256=sha(original),candidate_phase_sha256=sha(candidate),
        reverse_two_merit_expression_replacements_byte_exact=True,evaluate_AST_exact=True,evaluate_source_bytes_exact=True,
        evaluate_source_sha256=sha(before_evaluate),other_formula_gradient_J_lambda_caps_alpha_acceptance_budget_seed_mask_or_gate_changes=0,
        numerical_execution=0,model_success_or_fix_claim=False)
    (prep/'candidate-phase.py').write_bytes(candidate)
    (prep/'candidate.patch').write_bytes(''.join(difflib.unified_diff(original.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='PY-parent/'+filename,tofile='QN/'+filename)).encode())
    (prep/'SOURCE_SHA256.json').write_bytes(files['SOURCE_SHA256.json'])
    (prep/'DIFF_PROOF.json').write_bytes(encode(proof))
    (prep/'BINDINGS.json').write_bytes(encode(dict(source=proof,independent_algebra_evidence=dict(QM_job='1854.manager',QM_result_sha256='74eea2098ab3a0cd9992e694596c8f3de51f99368470a7d2d0308385fe3ba416',
        original_QF_failure_result_sha256='1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd',
        scope='Eight stored53--60 predictions are positive in stable/80digit algebra despite old zero/negative values. This is existing numerical evidence, not proof of nonlinear convergence or a candidate fix.'))))
    (prep/'README.md').write_bytes(b'New private PY-parent584 NumPy candidate changes only the LM merit prediction and actual-reduction difference arithmetic. Keep old norm/linear diagnostics, add linear_change=J@displacement, predicted=-2r.linear_change-||linear_change||2 and actual=(r-trial_r).(r+trial_r). All583 other files and evaluate AST/source bytes unchanged. No gradient/J/lambda/caps/alpha/acceptance/budget80/seed/mask/physical residual/hard ledger/test change. ExistingQM1854 Decimal algebra supports cancellation evidence only. OriginalPY/QF/QM failures retained. Candidate unexecuted and unpromoted; root reads exact patch before single original48-node NumPy validation.\n')
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(prep.iterdir()) if p.is_file()}))
    summary=dict(source_archive=target.name,source_archive_sha256=sha(target.read_bytes()),source_bytes=target.stat().st_size,
        source_manifest_sha256=proof['candidate_manifest_sha256'],phase_sha256=proof['candidate_phase_sha256'],
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),preparation_files=7,unchanged_other_source_files=583,
        evaluate_AST_and_source_bytes_exact=True,numerical_execution=0)
    (BASE/(LABEL+'-source-package.json')).write_bytes(encode(summary));print(json.dumps(summary))


if __name__=='__main__':main()

"""Close unique1856 actual47/48 failure, no local model/array numerical decode."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

BASE=Path(__file__).resolve().parent
OUT=BASE/'surface-lm-merit-qn-closure'
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    commands={'qstat':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1856.manager'],
        'result-hash':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','sha256sum /tmp/noahmp-surface-lm-merit-qn/result.tar.gz'],
        'pbs-exit':['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','cat /tmp/noahmp-surface-lm-merit-qn/pbs-exit.txt']}
    outputs={};receipts={}
    for label,command in commands.items():
        start=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=60)
        (OUT/(label+'.stdout')).write_bytes(result.stdout);(OUT/(label+'.stderr')).write_bytes(result.stderr)
        receipts[label]=dict(actual_exit=result.returncode,command=command,seconds=time.monotonic()-start,
            stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr));outputs[label]=result.stdout;assert result.returncode==0
    (OUT/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
    assert all(v in outputs['qstat'] for v in (b'Job Id: 1856.manager',b'job_state = F',b'Exit_status = 1',b'Stageout_status = 0'))
    path=BASE/'surface-lm-merit-qn-result.tar.gz'
    assert sha(path.read_bytes())==outputs['result-hash'].decode().split()[0]=='3f774feeb13b6556eb2228bb2d4727dd3684ec85c51dfe3a920f5085ecb14553'
    assert outputs['pbs-exit'].strip()==b'1'
    with tarfile.open(path) as t:files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    receipt=json.loads(files['probe/receipt.json']);assert receipt['pbs_job']=='1856.manager' and not receipt['passed']
    assert receipt['immutable_files']==617 and receipt['immutable_before_after_exact'] and receipt['source_members_exact'] and receipt['stage_before_after_exact']
    assert [e['actual_child_returncode'] for e in receipt['actual_children']]==[0,1] and not any(e['timed_out'] for e in receipt['actual_children'])
    tests=json.loads(files['probe/tests-nodes.json']);collect=json.loads(files['probe/collect-nodes.json'])
    assert tests['nodes']==collect['nodes'] and tests['items']==collect['items'] and len(set(tests['nodes']))==48
    assert len(tests['reports'])==144 and not any(r['skipped'] for r in tests['reports'])
    failed=[r for r in tests['reports'] if r['failed']]
    assert len(failed)==1 and failed[0]['when']=='call' and failed[0]['nodeid'].endswith('[actual-Qia]')
    for node in tests['nodes']:
        assert [r['when'] for r in tests['reports'] if r['nodeid']==node]==['setup','call','teardown']
    suite=list(ET.fromstring(files['probe/pytest.xml']))[0]
    assert {k:int(suite.attrib[k]) for k in ('tests','failures','errors','skipped')}==dict(tests=48,failures=1,errors=0,skipped=0)
    trace=json.loads(files['probe/external-lm-trace-qn/status.json'])
    assert trace['helper_calls']==1 and trace['observer_errors']==[]
    last=trace['summaries'][0]
    assert last['last_iteration']==65 and last['accepted']==23 and last['rejected']==12 and last['reason']=='no_feasible_displacement'
    assert last['evaluate_calls']==last['evaluate_returns']==611 and not last['converged']
    assert trace['source_after_sha256']=='37f921d4168f61601872b75d5f4e0e06d8ce52dfaedddf43113f9f2295695351'
    for name,raw in files.items():
        if name.endswith(('.json','.xml','.log','.txt','.stdout','.stderr')):
            target=OUT/'readable'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    readout=dict(pbs_job='1856.manager',job_state='F',PBS_exit=1,Stageout_status=0,actual_test_exit=1,actual_collect_exit=0,
        collected=48,passed=47,failed=1,errors=0,skipped=0,original42_passed=True,unchanged_Cha_HaM_surface_checks_passed=True,
        complete_setup_call_teardown_reports=144,XML_independently_checked=True,source617_immutable_before_after_exact=True,
        source_archive_sha256='adc1a56065a74cbfb9121908fd0a28743d77047280eb059d0e068830b6cf225c',source_files=584,
        original_Qia_Newton_stalled_iteration=30,original_Newton_residual_Wm2=13.75804,actual_Qia_LM_trace=trace,
        result_sha256=sha(path.read_bytes()),result_files=len(files),stable_merit_fixed_original_problem=False,
        GPU_calls=0,complete_column_steps=0,annual_or_scientific_acceptance=False,
        scope='Private two-expression stable-merit candidate still fails originalQia. No promotion, parameter change, budget/seed/gate relaxation or automatic retry.')
    (BASE/'surface-lm-merit-qn-readout.json').write_text(json.dumps(readout,indent=2)+'\n');print(json.dumps(readout))


if __name__=='__main__':main()

"""Reuse actual PY-c48-node execution unchanged except source binding and trace."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-merit-qn'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution')
    assert not prep.exists();prep.mkdir()
    assert {p.name for p in execution.iterdir()}=={'trace_py_qn.py'}
    parent_raw=(BASE/'surface-dry-lm-py-c-stage.tar.gz').read_bytes()
    assert sha(parent_raw)=='6f902b3a722d68c0414a8631f52614643bf1192e56254eeb1c9903d4a5ac0856'
    with tarfile.open(fileobj=io.BytesIO(parent_raw)) as t:parent={m.name:t.extractfile(m).read() for m in t}
    index=json.loads(parent['stage-inventory.json']);assert all(sha(parent[n])==h for n,h in index.items())
    source=json.loads((BASE/(LABEL+'-source-package.json')).read_bytes())
    with tarfile.open(BASE/source['source_archive']) as t:phase=t.extractfile('src/noahmp_clm/physics/canopy_phase_energy.py').read()
    assert sha(phase)==source['phase_sha256']
    for name,raw in parent.items():
        if name.startswith('preparation/') and name!='preparation/CONTROLS_SHA256.json':
            target=prep/name.removeprefix('preparation/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    helper=parent['preparation/surface_reference_py.py']
    current_helper=helper.replace(b'6dfcfee523d5108d51152884ee7220cf787038146d434c79846072af821c3166',source['source_manifest_sha256'].encode())
    assert current_helper.replace(source['source_manifest_sha256'].encode(),b'6dfcfee523d5108d51152884ee7220cf787038146d434c79846072af821c3166')==helper
    (prep/'surface_reference_py.py').write_bytes(current_helper)
    (prep/'canopy_phase_energy.candidate.py').write_bytes(phase)
    tree=ast.parse(phase);function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_rescue')
    (prep/'dry_lm_helper_py.txt').write_bytes((ast.get_source_segment(phase.decode(),function)+'\n').encode())
    (prep/'source.diff').write_bytes((BASE/(LABEL+'-source-preparation/candidate.patch')).read_bytes())
    (prep/'DIFF_PROOF.json').write_bytes((BASE/(LABEL+'-source-preparation/DIFF_PROOF.json')).read_bytes())
    binding=json.loads((prep/'BINDINGS.json').read_bytes())
    binding.update(candidate_source_archive_sha256=source['source_archive_sha256'],candidate_source_manifest_sha256=source['source_manifest_sha256'],
        candidate_phase_sha256=source['phase_sha256'],candidate_reference_helper_sha256=sha(current_helper),
        PY_parent_source_archive_sha256='e83342c1b9634e0f12fe898aafd4e49e8e16477b07403bb20b8b3aa5fcf9af92',
        PY_parent_source_manifest_sha256='6dfcfee523d5108d51152884ee7220cf787038146d434c79846072af821c3166',
        merit_only_changes=True,source_changes_relative_to_PY_parent=1,
        source_change_scope='Only predicted/actual merit difference arithmetic;583 other source files and evaluate AST/bytes unchanged.',
        old_provenance_scope='Copied original PY preparation provenance scripts remain historical and are not executed.')
    (prep/'BINDINGS.json').write_bytes(encode(binding))
    static=json.loads((prep/'STATIC_CHECKS.json').read_bytes())
    static.update(candidate_source_archive_sha256=source['source_archive_sha256'],candidate_source_manifest_sha256=source['source_manifest_sha256'],
        source_variation_scope='Two stable LM merit expressions only; unchanged six-new and42-original tests, inputs, oracle, solver and physical gates.',
        new_test_code_byte_exact_to_PY_c=True,source_binding_helper_reverse_literal_replacement_byte_exact=True)
    (prep/'STATIC_CHECKS.json').write_bytes(encode(static))
    (prep/'README.md').write_bytes(b'PrivateLM-merit-QN. Original actual six-new plus42-source tests and all3 PR surfaces/PW posthoc comparison remain byte exact; no tolerance,80-budget,seed,mask,lambda or physical ledger change. Only source binding/helper MANIFEST literal and candidate display/proof reflect adc1a560 stable-merit source. Original PY1818/1821 metadata failures and1822 physical failure remain provenance, not overwritten. Original19 preparation entries copied, original provenance builders unexecuted. An external pytest plugin observes only actual-Qia helper locals/returns and writes raw evidence after the original call; no extra evaluate/J.\n')
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.relative_to(prep).as_posix():sha(p.read_bytes()) for p in sorted(prep.rglob('*')) if p.is_file()}))
    patches=[]
    for name in ('check_stage_py.py','dispatch_surface_py.py','record_pytest_py.py','run_validation_py.py'):
        original=parent['execution/'+name];changed=original
        if name!='record_pytest_py.py':changed=changed.replace(b'noahmp-surface-dry-lm-py-c',b'noahmp-surface-lm-merit-qn')
        if name=='dispatch_surface_py.py':changed=changed.replace(b'dispatch_surface_py_c.py',b'dispatch_surface_merit_qn.py').replace(b'surface_py.pbs',b'surface_qn.pbs')
        if name=='run_validation_py.py':
            old=b"common=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','-p','record_pytest_py']"
            new=b"common=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','-p','record_pytest_py','-p','trace_py_qn']"
            assert changed.count(old)==1;changed=changed.replace(old,new)
            old2=b"            assert entry['actual_child_returncode']==0 and not entry['timed_out'],mode+' child failed'"
            new2=b"            if mode=='tests':\n                trace_status=root/'external-lm-trace-qn/status.json'\n                if trace_status.exists():record['external_actual_Qia_LM_trace']=json.loads(trace_status.read_bytes())\n            "+old2.lstrip()
            assert changed.count(old2)==1;changed=changed.replace(old2,new2)
            old3=b"        record['passed']=True"
            new3=b"        assert record['external_actual_Qia_LM_trace']['observer_errors']==[]\n        assert record['external_actual_Qia_LM_trace']['helper_calls']>=1\n"+old3
            assert changed.count(old3)==1;changed=changed.replace(old3,new3)
        (execution/name).write_bytes(changed)
        patches.append(''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile='PY-c/'+name,tofile='QN/'+name)))
    pbs=parent['execution/surface_py.pbs'].replace(b'noahmp-surface-dry-lm-py-c',b'noahmp-surface-lm-merit-qn').replace(b'#PBS -N surface-dry-lm-py-c',b'#PBS -N surface-lm-merit-qn')
    assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs
    (execution/'surface_qn.pbs').write_bytes(pbs)
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'README.md').write_bytes(b'OriginalPY-c manager/compute transfer,LF1CPU2GiB10min PBS,48node collect/144phase/XML and immutable/source/member checks. New private stage path and trace_py_qn observer only; test code/gates/data unchanged. Candidate source hash isadc1a560..., one NumPy validation, no retry/tuning. Original model failures remain actual1; external trace is post-call copied evidence and does not replace test outcome.\n')
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={n:raw for n,raw in parent.items() if not n.startswith(('preparation/','execution/')) and n not in ('stage-inventory.json','source.tar.gz')}
    for folder,directory in [('preparation',prep),('execution',execution)]:items.update({folder+'/'+p.relative_to(directory).as_posix():p.read_bytes() for p in directory.rglob('*') if p.is_file()})
    items['source.tar.gz']=(BASE/source['source_archive']).read_bytes();assert sha(items['source.tar.gz'])==source['source_archive_sha256']
    assert items['preparation/test_actual_surface_py.py']==parent['preparation/test_actual_surface_py.py']
    assert items['execution/record_pytest_py.py']==parent['execution/record_pytest_py.py']
    items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    summary=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        source_archive_sha256=source['source_archive_sha256'],preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),
        execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),original_test_code_and_node_recorder_byte_exact=True,
        expected_nodes=48,expected_original_nodes=42,expected_new_nodes=6,physical_gates_or_inputs_changed=False,external_copy_only_trace=True,
        numerical_execution=0,submission=False)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(summary));print(json.dumps(summary))


if __name__=='__main__':main()

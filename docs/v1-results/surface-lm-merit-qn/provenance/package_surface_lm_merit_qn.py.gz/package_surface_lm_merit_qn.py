"""Seal the failed minimal merit candidate and its full original trace/test run."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

from package_surface_feasible_root_pw import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-merit-qn'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    readout=json.loads((BASE/(LABEL+'-readout.json')).read_bytes())
    assert readout['PBS_exit']==1 and readout['Stageout_status']==0 and readout['passed']==47 and readout['failed']==1
    result=(BASE/(LABEL+'-result.tar.gz')).read_bytes();assert sha(result)==readout['result_sha256']
    with tarfile.open(fileobj=io.BytesIO(result)) as t:original={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    assert len(original)==readout['result_files']==116
    stage=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();assert sha(stage)=='d175c852a090836a19877179e292db0acf75dbcad757aaf3519963f9aeda6f3f'
    with tarfile.open(fileobj=io.BytesIO(stage)) as t:staged={m.name:t.extractfile(m).read() for m in t}
    assert len(staged)==40
    index=json.loads(staged['stage-inventory.json']);assert all(sha(staged[n])==h for n,h in index.items())
    before=json.loads(original['stage-before.json']);after=json.loads(original['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']==index
    for folder,prefix in [('preparation','probe/preparation'),('execution','probe/execution')]:
        controls=json.loads(staged[folder+'/CONTROLS_SHA256.json'])
        assert all(staged[folder+'/'+n]==original[prefix+'/'+n] and sha(staged[folder+'/'+n])==h for n,h in controls.items())
    typed={};arrays=0
    for name,raw in original.items():
        if not name.endswith('.json'):continue
        metadata=json.loads(raw)
        if not isinstance(metadata,dict) or 'npz_sha256' not in metadata:continue
        prefix=name.removesuffix('.json')
        count,fortran=opaque_packet(original[prefix+'.npz'],metadata)
        assert sha(original[prefix+'.pkl'])==metadata['pickle_sha256']
        typed[prefix]=dict(opaque_arrays=count,fortran=fortran);arrays+=count
    verification=dict(passed=True,scope='Standard-library raw archives/hash/JSON/opaque NPY headers and C-payloads only; no NumPy, unpickle or numerical decode.',
        result_files=len(original),stage_files=len(staged),typed_packets=len(typed),opaque_arrays=arrays,packets=typed,
        original_test_or_model_failure_preserved=True,physical_model_fixed=False)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    items={'readout.json':(BASE/(LABEL+'-readout.json')).read_bytes(),'verification.json':encode(verification),
        'original-result.tar.gz':result,'stage-inventory.json':staged['stage-inventory.json'],
        'candidate-source.tar.gz':staged['source.tar.gz'],
        'SCOPE.md':b'Unique1856 actualF1/Stageout0: original48 nodes collect,47pass/1actual-Qia failure/0error/0skip;144 original setup/call/teardown and XML complete. PrivatePY-parent candidate changes only two mathematically equivalent merit differences. All583 other files/evaluate unchanged. Stable merit did not repair Qia: originalNewton30 then LM35 attempts,23accept/12reject/611eval returns, no_feasible at total65/80, originalr12max10.769007515983674 andlambda1693508.7808430293. External source-onlycopy trace retained; no new seed/budget/gate/parameter search or promotion. Cha/HaM full original return checks and42 prior tests pass. Full raw116-file result retained; nested old archives not redundantly expanded. QF/QM/earlier failures remain referenced. No GPU/full-column/year/scientific credit.\n'}
    nested={}
    for name,raw in original.items():
        if name.endswith('.tar.gz'):nested[name]=dict(bytes=len(raw),sha256=sha(raw),scope='Original bytes retained inside original-result.tar.gz; not expanded again.')
        else:items['result/'+name]=raw
    items['nested-original-archives.json']=encode(nested)
    inputs={n:dict(bytes=len(staged[n]),sha256=sha(staged[n])) for n in ('source.tar.gz','pr-evidence.tar.gz','pt-evidence.tar.gz','pw-evidence.tar.gz')}
    items['executed-stage-reference.json']=encode(dict(stage_sha256=sha(stage),members=40,inputs=inputs,
        parent_stage_sha256='6f902b3a722d68c0414a8631f52614643bf1192e56254eeb1c9903d4a5ac0856',
        input_scope='Source candidate supplied, old immutable PR/PT/PW archives hash-referenced and retained in raw result and previous evidence.'))
    for folder in ('surface-lm-merit-qn-source-preparation','surface-lm-merit-qn-deployment','surface-lm-merit-qn-closure'):
        root=BASE/folder
        items.update({folder+'/'+p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file() and 'readable' not in p.relative_to(root).parts})
    for name in ('surface-lm-merit-qn-source-package.json','surface-lm-merit-qn-stage-package.json','prepare_surface_lm_merit_qn_source.py',
        'prepare_surface_lm_merit_qn_validation.py','deploy_surface_lm_merit_qn.py','collect_surface_lm_merit_qn_closed.py',Path(__file__).name):
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['prior-evidence-references.json']=encode({label:json.loads((BASE/(label+'-package.json')).read_bytes()) for label in
        ('surface-dry-lm-py-c','surface-lm-transparent-trace-qf','surface-lm-event-analysis-qm')})
    items['artifact-inventory.json']=encode({n:dict(bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='1856 actualF1/Stageout0 original48-node NumPy test:47pass/1Qia fail,617immutable exact, LM65/80 residual10.769007516/611eval. Two stable merit expressions alone did not repair; full raw/source/trace retained, no promotion/GPU/annual or scientific credit.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package));print(json.dumps(dict(typed_packets=len(typed),opaque_arrays=arrays)))


if __name__=='__main__':main()

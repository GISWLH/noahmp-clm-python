"""EHPC plain-array fixture export from CLOSED MI reference results only.

No model tendency or thermodynamic solver is executed. Frozen source is expanded
only in PBS TMPDIR to deserialize existing trusted reference dataclasses.
"""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import pickle
import re
import subprocess
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID') and os.uname().nodename.startswith('compute')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'surface-root-fixture-mz'
reference = b / 'climatology-failed-reference-mi'
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
started = time.monotonic()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw_sha = lambda v: hashlib.sha256(v).hexdigest()
parent_hash = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
input_hash = 'd40644c23c9b31feabd3032528157ef38b9bd54b694a9191862704ab1ac59ffb'
archive = b / 'clm-ballberry-jn-source.tar.gz'
assert sha(archive) == '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert sha(source / 'SOURCE_SHA256.json') == parent_hash and len(manifest) == 581
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]


def actual_success(job):
    result = subprocess.check_output(['qstat', '-xf', job], text=True)
    assert re.search(r'^Job Id: ' + re.escape(job) + r'\s*$', result, re.M)
    assert re.search(r'^\s*job_state = F\s*$', result, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', result, re.M)
    return result


qstat = actual_success('1537.manager')
(r / 'numpy-reference-actual-qstat.txt').write_text(qstat)
assert (reference / 'pbs-exit.txt').read_text().strip() == '0'
receipt_path = reference / 'receipt.json'
assert sha(receipt_path) == '754b03900bd8a6ca8b4e4e237f7744f8c58d9ddb1314f3972f446b7164634a5f'
receipt = json.loads(receipt_path.read_text())
assert receipt['pbs_job'] == '1537.manager' and receipt['passed'] and receipt['all12_attempts_completed']
assert receipt['source_unchanged'] and receipt['source_manifest_sha256'] == parent_hash
assert receipt['failed_attempt_index'] == 2657 and receipt['original_year_parent_exit'] == 1
assert sha(reference / 'diagnostic-input.npz') == receipt['diagnostic_input_sha256'] == input_hash
assert sha(reference / 'binding.json') == receipt['binding_sha256'] == 'b027cc2e4655ba4986bc55c58470e5dfd48b66abfa400e43574b373ee28bd578'
binding = json.loads((reference / 'binding.json').read_text())
assert binding['source_manifest_sha256'] == parent_hash and binding['diagnostic_input_sha256'] == input_hash
assert len(binding['cases']) == len(receipt['results']) == 12
with np.load(reference / 'diagnostic-input.npz', allow_pickle=False) as data:
    original = dict(data)
assert all('a' + str(k) in original for k in range(16))
assert original['a0'].shape[0] == len(original['forcing']) == 12
assert all(value.dtype.kind in 'biuf' and np.isfinite(value).all() for value in original.values())
assert all(original['a' + str(k)].shape[0] == 12 for k in range(16))
payload = dict(original)
provenance = []
expected = {'h': [], 'le': [], 'soil_temperature': []}
for index, row in enumerate(receipt['results']):
    assert row['column'] == index and row['case'] == binding['cases'][index]['case']
    assert row['passed'] and row['failure'] is None
    name = row['reference_file']
    assert name == 'case-' + str(index).zfill(2) + '-reference.pkl.gz'
    path = reference / name
    assert sha(path) == row['reference_sha256']
    packet = pickle.loads(gzip.decompress(path.read_bytes()))
    result = packet['result']
    for key in ['h', 'le']:
        value = np.asarray(result['diagnostics'][key])
        assert value.shape == () and value.dtype == np.dtype('float64') and np.isfinite(value)
        expected[key].append(value)
    temperature = np.asarray(result['soil_temperature'])
    assert temperature.shape == (4,) and temperature.dtype == np.dtype('float64') and np.isfinite(temperature).all()
    expected['soil_temperature'].append(temperature)
    provenance.append(dict(column=index, case=row['case'], reference_file=name,
                           reference_sha256=row['reference_sha256'], original_reference_passed=True,
                           independent_budget=row['independent_budget']))
for key, values in expected.items():
    payload['numpy/' + key] = np.stack(values)

# Preserve the actual old-source failures without deriving any reference from them.
negative_archive = b / 'climatology-failed-step-mj-export.tar.gz'
assert sha(negative_archive) == 'dfe8e96e2835889fa578c9a74608c682393897f6f3380149283958566a755116'
negative = {}
with tarfile.open(negative_archive) as tf:
    assert raw_sha(tf.extractfile('diagnostic-input.npz').read()) == input_hash
    assert tf.extractfile('binding.json').read() == (reference / 'binding.json').read_bytes()
    for label in ['original-jn', 'density-md']:
        raw = tf.extractfile(label + '/receipt.json').read()
        old = json.loads(raw)
        parent = json.load(tf.extractfile(label + '-exit.json'))
        assert parent['receipt_sha256'] == raw_sha(raw)
        assert parent['actual_diagnostic_parent_returncode'] == 0 and parent['diagnostic_passed']
        assert old['diagnostic_completed'] and old['source_unchanged'] and old['device_barrier_complete']
        assert old['physical_state_input_arrays_unchanged_after_attempt']
        assert old['tendency_succeeded'] is False and parent['tendency_succeeded'] is False
        assert old['tendency_failure'] == 'RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False'
        assert old['diagnostic_input_sha256'] == input_hash and old['original_surface_calls'] == 10
        assert old['failed_attempt_index'] == 2657 and old['captured_failed_surface_calls'] == 1
        negative[label] = dict(receipt=old, receipt_sha256=raw_sha(raw), actual_diagnostic_parent=parent,
            failed_capture_member=label + '/failed-surface-00.pkl.gz',
            failed_capture_sha256=raw_sha(tf.extractfile(label + '/failed-surface-00.pkl.gz').read()),
            original_traceback=tf.extractfile(label + '/tendency-traceback.txt').read().decode())
mk_root = b / 'climatology-failed-step-audit-mk'
mk = json.loads((mk_root / 'audit.json').read_text())
mk_qstat = actual_success('1539.manager')
assert (mk_root / 'pbs-exit.txt').read_text().strip() == '0'
assert mk['pbs_job'] == '1539.manager' and mk['passed'] and mk['source_unchanged']
assert mk['reference_input_sha256'] == input_hash and mk['device_export_sha256'] == sha(negative_archive)
assert mk['failed_surface_args_bitwise_equal_between_variants']
assert mk['failed_surface_kwargs_equal_between_variants'] and mk['failed_surface_returned_fields_bitwise_equal_between_variants']
assert len(mk['results']) == 2 and all(row['failed_columns'] == [0, 1] and not row['original_tendency_succeeded'] for row in mk['results'])
negative_record = dict(scope='Original JN and density-only MD fail the same exact physical point. '
    'Diagnostic parent zero is not physical success. No GPU output is a reference value.',
    archive=str(negative_archive), archive_sha256=sha(negative_archive), variants=negative,
    independent_MK_audit=mk, independent_MK_audit_sha256=sha(mk_root / 'audit.json'),
    independent_MK_actual_qstat=mk_qstat, independent_MK_actual_qstat_sha256=raw_sha(mk_qstat.encode()))
(r / 'negative-controls.json').write_text(json.dumps(negative_record, indent=2, allow_nan=False) + '\n')
fixture_path = r / 'cng_surface_root_contraction.npz'
assert not fixture_path.exists()
np.savez_compressed(fixture_path, **payload)
with np.load(fixture_path, allow_pickle=False) as saved:
    assert set(saved.files) == set(payload)
    for key, value in payload.items():
        assert saved[key].dtype == value.dtype and saved[key].shape == value.shape
        assert saved[key].tobytes() == value.tobytes(), key
input_arrays = {key: dict(shape=list(value.shape), dtype=str(value.dtype), raw_sha256=raw_sha(value.tobytes()))
                for key, value in original.items()}
reference_arrays = {key: dict(shape=list(value.shape), dtype=str(value.dtype), raw_sha256=raw_sha(value.tobytes()))
                    for key, value in payload.items() if key.startswith('numpy/')}
assert all(sha(source / name) == digest for name, digest in manifest.items())
meta = dict(fixture_sha256=sha(fixture_path), original_diagnostic_input_sha256=input_hash,
    original_binding_sha256=receipt['binding_sha256'], binding=binding,
    numpy_reference_pbs_job='1537.manager', numpy_reference_actual_exit=0,
    numpy_reference_receipt_sha256=sha(receipt_path),
    numpy_reference_actual_qstat_sha256=sha(r / 'numpy-reference-actual-qstat.txt'),
    parent_source_manifest_sha256=parent_hash, parent_source_archive_sha256=sha(archive),
    source_files_verified=581, parent_source_unchanged=True,
    original_input_arrays=input_arrays, independent_reference_arrays=reference_arrays,
    independent_references=provenance, numpy_reference_receipt=receipt,
    negative_controls_sha256=sha(r / 'negative-controls.json'),
    negative_control_archive_sha256=sha(negative_archive),
    exporter_pbs_job=os.environ['PBS_JOBID'], exporter_node=os.uname().nodename,
    exporter_sha256=sha(Path(__file__)), utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Plain-array fixture: exact 12-column MI failed2657 input and existing independent MI1537 '
          'NumPy H/LE/soil-temperature values. All original input arrays byteexact. No new physical '
          'solve, no GPU-derived reference, no restart or annual/scientific acceptance. Raw pickle '
          'files stay in provenance archive, not in the permanent plain-array fixture.')
metadata_path = r / 'cng_surface_root_contraction.json'
metadata_path.write_text(json.dumps(meta, indent=2, allow_nan=False) + '\n')
record = dict(passed=True, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
    source_manifest_sha256=parent_hash, source_unchanged=True, source_files_verified=581,
    original_input_arrays=len(original), original_state_arrays=16, columns=12,
    all_original_input_arrays_byteexact=True, independent_reference_packets_verified=12,
    independent_reference_arrays=len(reference_arrays), no_model_tendencies_executed=True,
    old_source_negative_controls_verified=['original-jn', 'density-md'],
    fixture_sha256=sha(fixture_path), metadata_sha256=sha(metadata_path),
    negative_controls_sha256=sha(r / 'negative-controls.json'), seconds=time.monotonic() - started)
(r / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

"""Small EHPC compute export; frozen source expands only under PBS TMPDIR."""
from pathlib import Path
import hashlib
import json
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'surface-root-fixture-mz'
assert not r.exists()
control = 'export_surface_root_fixture_mz.py'
raw = (b / control).read_bytes()
assert b'\r\n' not in raw
assert (b / 'climatology-failed-reference-mi/receipt.json').is_file()
r.mkdir()
(r / control).write_bytes(raw)
script = '''#!/bin/bash
#PBS -N clm-surface-fixture-mz
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=3gb
#PBS -l walltime=00:05:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/surface-root-fixture-mz
/home/zhangyq/venvs/noahmp-closeout/bin/python -u export_surface_root_fixture_mz.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(r / 'job.pbs').write_text(script)
result = subprocess.run(['qsub', str(r / 'job.pbs')], cwd=r, capture_output=True, text=True)
assert result.returncode == 0, result.stderr
record = dict(pbs_job=result.stdout.strip(), controls_sha256={name: hashlib.sha256((r / name).read_bytes()).hexdigest()
    for name in [control, 'job.pbs']}, scope='Read-only MI1537 values export on compute; no physical recomputation or GPU task')
(r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

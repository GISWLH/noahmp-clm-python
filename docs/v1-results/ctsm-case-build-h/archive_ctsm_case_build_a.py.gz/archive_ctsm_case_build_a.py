from pathlib import Path
import gzip,hashlib,io,json,re,sys,tarfile
base=Path('/home/zhangyq/noahmp-v1');label,job=sys.argv[1:3];assert label in ['d','e','f','g','h'];root=base/('ctsm-case-build-'+label);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'configuration.json').read_text());assert r['pbs_job']==job and r['upstream_original_bytes_unchanged'];overall=int((root/'pbs-exit.txt').read_text())
names=[(root/n,n) for n in ['build_ctsm_case_'+label+'.py','ctsm_case_build_'+label+'.pbs','configuration.json','configuration.log','node.txt','pbs-exit.txt']];extras=[];errors={};workspace=root/'case-configuration-private.tar.gz'
with tarfile.open(workspace) as t:
    for m in t:
        if not m.isfile():continue
        if m.name in ['machine-adaptation.json','resource-adaptation.json','compiler-adaptation.json','link-adaptation.json']:extras.append((m.name,t.extractfile(m).read()))
        if m.name in ['case-setup.stdout.txt','case-setup.stderr.txt','preview-namelists.stdout.txt','preview-namelists.stderr.txt','case-build.stdout.txt','case-build.stderr.txt','executable-linkage.stdout.txt','executable-linkage.stderr.txt','netcdf-link-flags.stdout.txt','netcdf-link-flags.stderr.txt'] or '.bldlog' in m.name:
            data=t.extractfile(m).read()
            if data.startswith(b'\x1f\x8b'):data=gzip.decompress(data)
            lines=[];omitted=0
            for line in data.decode(errors='replace').splitlines()[-50:]:
                if re.search(r'(token|password|authorization|secret|api_key)\s*[=:]',line,re.I):lines.append('[credential-like line omitted]');omitted+=1
                else:lines.append(line)
            errors[m.name]=dict(tail=lines,credential_like_lines_omitted=omitted)
extras.append(('safe-error-excerpts.json',(json.dumps(errors,indent=2)+'\n').encode()))
extras.append(('private-workspace-binding.json',(json.dumps(dict(path=str(workspace),sha256=sha(workspace),scope='Original generated case/output private archive retained on server only; not included here.',overall_exitcode=overall),indent=2)+'\n').encode()))
names.append((Path(__file__),Path(__file__).name));archive=base/('ctsm-case-build-'+label+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,name in names:t.add(p,arcname=name,recursive=False)
    for name,data in extras:
        m=tarfile.TarInfo(name);m.size=len(data);t.addfile(m,io.BytesIO(data))
print(json.dumps(dict(files=len(names)+len(extras),path=str(archive),sha256=sha(archive),overall_exitcode=overall,stages=[dict(stage=v['stage'],returncode=v['returncode']) for v in r['stages']])))

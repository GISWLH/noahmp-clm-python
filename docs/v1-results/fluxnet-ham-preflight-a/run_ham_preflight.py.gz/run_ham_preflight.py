"""Uncalibrated physical execution check; never score heldout observations."""
import argparse
from dataclasses import asdict, replace
from datetime import datetime, timedelta
import hashlib,json,pickle,time,traceback
from pathlib import Path
import numpy as np
from noahmp_clm.column import ColumnState,SoilParams,Forcing
from noahmp_clm.clm_state import CLMColumnState,clm_options
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.biogeochemistry import BGCState,BGCParameters
from noahmp_clm.physics.plant_cn import PlantState,PlantParameters
from noahmp_clm.physics.decomposition import DecompositionState,DecompositionParameters
from noahmp_clm.physics.phenology import PhenologyParameters,PhenologyEnvironment,critical_gdd
from noahmp_clm.physics.canopy_most import MOSTGeometry
from fluxnet_solar import solar_geometry


def encode(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,np.generic):return value.item()
    raise TypeError(type(value).__name__)


parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True)
parser.add_argument('--steps',type=int,default=48);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();data=np.load(args.input,allow_pickle=False)
assert args.steps<=len(data['forcing']) and args.steps>0
# USDA STAS class 9 CLAY LOAM, official NoahmpTable (locked upstream 17751dc).
soil=SoilParams(name='STAS-9-clay-loam',smcmax=.465,smcwlt=.103,smcref=.382,satdk=2.45e-6,bexp=8.17,quartz=.35)
# Explicit seed for execution/spinup, not measured deep soil or carbon stocks.
temp=273.15+float(data['obs_TS_F_MDS_1'][0]);theta=float(data['obs_SWC_F_MDS_1'][0])/100.
old=ColumnState(soil=soil,dz=np.array([.05,.15,.20,.25]),tsoil=np.full(4,temp),smc=np.full(4,theta),
                ts=temp,lai=0.,fveg=1.,z0m=.03,options=replace(clm_options(),OptSurfaceDrag=1,OptRainSnowPartition=5,
                                                          OptRunoffSurface=6,OptRunoffSubsurface=6))
state=CLMColumnState.from_column(old,options=old.options).with_layered_canopy()
plant_parameters=PlantParameters(allocation=(.5,0.,.5),turnover_days=(365.,365.,365.),stem_live_n_fraction=0.)
plant=PlantState(np.array([0.,0.,150.]),np.array([0.,0.,150./42.]),150.,6.)
carbon=np.array([50.,100.,100.,0.,300.,3000.,3000.])
soil_cn=DecompositionState(carbon,carbon/np.array([37.5,37.5,37.5,263.1578947368,8.,11.,11.]),2.)
bgc_parameters=BGCParameters(plant=plant_parameters,decomposition=DecompositionParameters(sand_fraction=.4),
                             maximum_lai=3.,saturated_potential_mpa=-.263*1000.*9.81/1e6)
threshold=critical_gdd(float(data['forcing'][:,1].mean()))
state=state.with_phenology(PhenologyParameters(gdd_threshold=threshold,lai_maximum=3.))
state=state.with_biogeochemistry(BGCState(plant,soil_cn),bgc_parameters)
geometry=MOSTGeometry(wind_height=2.2,temperature_height=2.2,humidity_height=2.2,displacement=.2,
                       momentum_roughness=.03,heat_roughness=.003,water_roughness=.003)
initial=state;net=np.zeros(4);maximum=np.zeros(4);bounds=np.zeros(4);stepmax=np.zeros(4);days=[]
daily=np.zeros(6);started=time.monotonic()
report={'scope':'CN-HaM 2002 uncalibrated cold-start execution preflight; NOT spinup or observational acceptance',
 'input_sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),
 'source_manifest_sha256':hashlib.sha256(Path('SOURCE_SHA256.json').read_bytes()).hexdigest() if Path('SOURCE_SHA256.json').exists() else None,
 'initial_state':asdict(state),'most_geometry':asdict(geometry),'notes':[
  '0.65 m column thickness, clay loam, 2.2 m forcing heights from station metadata; STAS-9 hydraulic values from official table.',
  'Initial shallow observed temperature/water are extended uniformly solely as a spinup seed; SWE=0 is unknown initial snow.',
  'Single grass PFT, fveg=1, d=2/3 canopy height and z0m=0.1 height, heat/water z0=0.1 z0m are provisional geometry assumptions.',
  'Leaf/root allocation 0.5/0.5, SLA and physiological defaults, initial carbon/nitrogen stocks are uncalibrated scenarios.',
  'Aerosol and N deposition zero for execution check only; climatological deposition required for final evaluation.',
  'P_F 2002 is entirely ERA-filled and totals 2620.564 mm; retain original product, investigate before observational acceptance.'],
 'steps_requested':args.steps,'steps_completed':0,'status':'running'}


def totals(s):return np.array([s.water_kgm2,s.enthalpy_jm2,s.carbon_gc_m2,s.nitrogen_gn_m2])
def save(status,step):
 report.update(status=status,steps_completed=step,seconds=time.monotonic()-started,
               maximum_cumulative_residual_m_h_c_n=maximum,maximum_step_residual_m_h_c_n=stepmax,
               cumulative_numerical_bounds_m_h_c_n=bounds,daily=days)
 args.output.write_text(json.dumps(report,indent=2,default=encode,allow_nan=False)+'\n',encoding='utf-8')
save('running',0)
for index in range(args.steps):
 f=Forcing(*data['forcing'][index]);stamp=datetime.strptime(str(data['time_start'][index]),'%Y%m%d%H%M')
 co2,mu,diffuse=data['environment'][index]
 def length(day):return solar_geometry(day.replace(hour=12,minute=0),37.607432,101.332,8)['daylength_seconds']
 current,previous,before=[length(stamp-timedelta(days=k)) for k in range(3)]
 increasing=current>previous
 solstice=bool(stamp.hour==0 and stamp.minute==0 and increasing and previous<=before)
 environment=PhenologyEnvironment(current,bool(increasing),solstice,37.607432)
 try:
  after,d=step_clm_enthalpy_column(state,f,co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),
                                  phenology_environment=environment,most_geometry=geometry)
  inputs=np.array([f.prcp*f.dt*1000.,d['precipitation_enthalpy_jm2']+
   (f.swdown+f.lwdown-d['outgoing_shortwave']-d['outgoing_longwave']-d['h']-d['le'])*f.dt,
   -d['nee_gc_m2'],0.])
  inputs[0]-=d['et_mm']+d['runoff_mm'];inputs[1]-=d['advected_enthalpy_jm2']+d['runoff_enthalpy_jm2']
  residual=totals(after)-totals(state)-inputs
  eps=np.finfo(float).eps
  mb=32*eps*max(state.water_kgm2+after.water_kgm2+f.prcp*f.dt*1000.+abs(d['et_mm'])+d['runoff_mm'],1.)
  storage=sum(float(abs(a).sum()) for s in (state,after) for a in (s.ground.enthalpy,s.snow.enthalpy,s.canopy_condensate.enthalpy))
  hb=float(np.sum(d['thermal']['convergence_tolerance_jm2']))+f.dt*float(np.sum(abs(d['layer_residual'])))
  hb+=32*eps*max(storage+abs(d['precipitation_enthalpy_jm2'])+abs(d['atmospheric_energy_jm2'])+
                 abs(d['advected_enthalpy_jm2'])+abs(d['runoff_enthalpy_jm2']),1.)+1e-5
  cn=d['biogeochemistry'];bound=np.array([mb,hb,cn['carbon_bound_gc_m2'],cn['nitrogen_bound_gn_m2']])
  assert np.all(abs(residual)<=bound),(residual,bound)
  net+=inputs;bounds+=bound;cumulative=totals(after)-totals(initial)-net
  assert np.all(abs(cumulative)<=bounds),(cumulative,bounds)
  maximum=np.maximum(maximum,abs(cumulative));stepmax=np.maximum(stepmax,abs(residual))
  daily+=np.array([d['et_mm'],d['h']*f.dt,d['le']*f.dt,d['gpp_gc_m2'],d['nee_gc_m2'],d['runoff_mm']])
  state=after
  if (index+1)%48==0:
   days.append({'date':stamp.strftime('%Y-%m-%d'),'et_mm':daily[0],'h_jm2':daily[1],'le_jm2':daily[2],
                'gpp_gc_m2':daily[3],'nee_gc_m2':daily[4],'runoff_mm':daily[5],'end_swe_m':state.swe,
                'end_soil_temperature_k':state.tsoil,'end_soil_total_water_m3m3':state.smc,'end_lai':state.lai})
   daily[:]=0.;save('running',index+1)
   print(json.dumps({'day':len(days),'steps':index+1,'max_cumulative':maximum.tolist(),'seconds':time.monotonic()-started}),flush=True)
 except Exception:
  report['failure']=traceback.format_exc();report['failed_index']=index
  args.output.with_suffix('.failure.json').write_text(json.dumps({'state':asdict(state),'forcing':asdict(f),
   'environment':asdict(environment),'co2':co2,'mu':mu,'diffuse':diffuse},default=encode,indent=2),encoding='utf-8')
  # Internal exact-state recovery only; never load pickle from external input.
  args.output.with_suffix('.failure.pkl').write_bytes(pickle.dumps((state,f,environment,geometry,co2,mu,diffuse)))
  save('failed',index);raise
report['final_state']=asdict(state);save('complete',args.steps)
args.output.with_suffix('.checkpoint.pkl').write_bytes(pickle.dumps(state))
print(json.dumps({'status':'complete','steps':args.steps,'seconds':time.monotonic()-started}),flush=True)

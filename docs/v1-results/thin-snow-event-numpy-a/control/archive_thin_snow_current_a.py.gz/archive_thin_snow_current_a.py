from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert mode in ('numpy','reference','cpu')
name='thin-snow-event-'+mode+'-a';r=b/name;d=json.loads((r/'receipt.json').read_text());package=json.loads((r/'package.json').read_text());assert d['source_unchanged'] and (r/'pbs-exit.txt').read_text().strip()=='0'
if mode=='reference':
    assert len(d['records'])==8 and sha(r/'vanishing_snow_event_reference.npz')==d['reference_sha256']
    source=b/'thin-snow-event-numpy-a-source.tar.gz'
elif mode=='numpy':
    assert d['returncode']==0 and d['counts']==dict(tests=37,failures=0,errors=0,skipped=0) and sha(r/'tests.xml')==d['xml_sha256']
    source=b/'thin-snow-event-numpy-a-source.tar.gz'
else:
    assert d['returncode']==0 and d['counts']==dict(tests=1068,failures=0,errors=0,skipped=0) and sha(r/'cpu-full.xml')==d['xml_sha256']
    source=b/'thin-snow-event-native-a-source.tar.gz'
assert sha(source)==package['archive_sha256'];a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['run_thin_snow_event_'+mode+'_a.py','thin_snow_event_'+mode+'_a.pbs','dispatch_thin_snow_event_'+mode+'_a.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

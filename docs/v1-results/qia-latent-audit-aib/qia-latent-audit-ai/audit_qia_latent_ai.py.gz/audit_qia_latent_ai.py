from pathlib import Path
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-latent-audit-ai';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots={};start=time.monotonic()
for label,name,expected in [('source','clm-numerical-recovery-c-source.tar.gz','61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'),('replay','qia-le-day2-replay-ag-evidence.tar.gz','9fbe97eb57015e457ab4fe85b91bb0df2685682e39dde631cf696c3d8462a500'),('official','qia-official-latent-afc-evidence.tar.gz','05382ed5251cee5cdfdaa18e6bdd26941a4944a4dca676f97476965fb205a5e5')]:
    a=b/name;assert sha(a)==expected;p=Path(os.environ['TMPDIR'])/label;p.mkdir();roots[label]=p
    with tarfile.open(a) as tf:tf.extractall(p,filter='data')
s=roots['source'];m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
u=Path(os.environ['TMPDIR'])/'prefix';u.mkdir();a=roots['replay']/'control/qia-recovery-c-prefix-u-evidence.tar.gz';assert sha(a)=='8cee7134ee4ad9f51c1c8de03d9f601389df98b39b43ad09a424f061cac8f313'
with tarfile.open(a) as tf:tf.extractall(u,filter='data')
official=roots['official']/'qia-official-latent-afc';ref_receipt=json.loads((official/'receipt.json').read_text());runtime=json.loads((official/'runtime-receipt.json').read_text());assert (official/'pbs-exit.txt').read_text().strip()=='0' and ref_receipt['component_sum_within_history_rounding'] and runtime['diagnosis_receipt_sha256']==sha(official/'receipt.json') and sha(official/'official-latent-first480.npz')==ref_receipt['output_sha256']
with np.load(official/'official-latent-first480.npz',allow_pickle=False) as z:reference=dict(z)
assert np.array_equal(reference['time_bounds_seconds'][:96],np.arange(96)[:,None]*1800+[[0,1800]])
cases=[]
for label in ['capacity','capacity_optics']:
    p=roots['replay']/label;prefix=u/label;failure=None;summary={}
    try:
        d=json.loads((p/'receipt.json').read_text());exit_record=json.loads((p/'exit.json').read_text());assert exit_record['passed'] and exit_record['returncode']==0 and exit_record['receipt_sha256']==sha(p/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['starting_fields_exact']==d['ending_fields_exact']==30 and d['captured_calls']==48 and d['full_original96trace_exact']
        binding=json.loads((p/'endpoint-binding.json').read_text());e=p/'expected';assert all(sha(e/n)==h for n,h in binding['files_sha256'].items());v=json.loads((e/'prefix-verification.json').read_text());assert v['passed'] and v['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
        pr=json.loads((prefix/'prefix-receipt.json').read_text());px=json.loads((prefix/'prefix-exit.json').read_text());assert px['passed'] and px['returncode']==0 and px['receipt_sha256']==sha(prefix/'prefix-receipt.json') and pr['failure'] is None and pr['captured_step_calls']==48 and pr['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
        report,saved,rows=native.read_generation(p/'seed'/label/'trajectory');assert report['steps_completed']==96 and report['steps_requested']==17520 and report['status']=='running' and report['identity']['source_sha256']==native.source_hashes() and len(rows)==1
        trace=rows[0][1];assert str(trace['time_start'][0])=='200301010000' and str(trace['time_end'][-1])=='200301030000';cfg=rows[0][0]['configuration'];assert cfg['column']['fveg']==1.
        with np.load(e/'endpoint-state.npz',allow_pickle=False) as z:endpoint=dict(z)
        assert len(saved)==len(endpoint)==30 and set(saved)==set(endpoint)
        for k in saved:assert saved[k].dtype==endpoint[k].dtype and saved[k].shape==endpoint[k].shape and saved[k].tobytes()==endpoint[k].tobytes()
        with np.load(e/'endpoint-trace.npz',allow_pickle=False) as z:
            assert set(trace)==set(z.files)
            for k in trace:assert trace[k].dtype==z[k].dtype and trace[k].shape==z[k].shape and trace[k].tobytes()==z[k].tobytes()
        with np.load(prefix/'inputs'/label/'cold-reference.npz',allow_pickle=False) as z:cold=dict(z)
        cold_paths=list((prefix/'trajectory').glob('state-0000000-*.npz'));assert len(cold_paths)==1
        with np.load(cold_paths[0],allow_pickle=False) as z:
            assert len(cold)==30 and set(z.files)==set(cold)
            for k in cold:assert cold[k].dtype==z[k].dtype and cold[k].shape==z[k].shape and cold[k].tobytes()==z[k].tobytes()
        previous=tuple(cold['a'+str(k)] for k in range(23));initial=cold['initial'];net=np.zeros((1,4));recorded_net=net.copy();bounds=net.copy();max_step=net.copy();max_cumulative=net.copy();max_ratio=net.copy();impurity_max=np.zeros((1,5));values=[];mass_join_max=0.;mass_join_ratio=0.
        for index in range(96):
            folder=prefix/'prefix-steps' if index<48 else p/'captured-steps';filename='call-'+str(index if index<48 else index-48).zfill(5)+'.npz'
            with np.load(folder/filename,allow_pickle=False) as z:data=dict(z)
            before=tuple(data['before'+str(k)] for k in range(23));after=tuple(data['after'+str(k)] for k in range(23))
            for x,y in zip(before,previous):assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes()
            out={}
            for key,value in data.items():
                if not key.startswith('output/'):continue
                parts=key.split('/')[1:];target=out
                for part in parts[:-1]:target=target.setdefault(part,{})
                target[parts[-1]]=value
            incoming,residual,unused,tracer=native.audit_step(before,after,data['forcing'],data['deposition'],data['nitrogen'],out);bound=data['recorded/bound'];assert np.all(abs(residual)<=bound)
            np.testing.assert_array_equal(incoming,data['recorded/incoming']);np.testing.assert_array_equal(residual,data['recorded/residual'])
            net+=incoming;recorded_net+=data['recorded/incoming'];bounds+=bound;cumulative=native.totals(after)-initial-net;assert np.all(abs(cumulative)<=bounds);max_step=np.maximum(max_step,abs(residual));max_cumulative=np.maximum(max_cumulative,abs(cumulative));max_ratio=np.maximum(max_ratio,abs(residual)/bound);impurity_max=np.maximum(impurity_max,tracer);previous=after
            if index==47:
                with np.load(e/'certified-prefix-state.npz',allow_pickle=False) as z:
                    for k,value in enumerate(previous):assert value.tobytes()==z['a'+str(k)].tobytes()
                    for key,value in [('initial',initial),('net',recorded_net),('bounds',bounds)]:np.testing.assert_array_equal(value,z[key])
            surface=out['surface'];dt=float(data['forcing'][0,0]);wet_mass=float(np.asarray(surface['wet_evaporation'],float).sum()*dt);trans_mass=float(np.asarray(surface['transpiration'],float).sum()*dt);ground_mass=float(surface['ground_vapor_mass_kgm2'][0]);et=float(out['diagnostics']['et_mm'][0]);le=float(out['diagnostics']['le'][0]);assert le==float(trace['le_wm2'][index])==float(surface['le'][0]) and et==float(trace['et_mm'][index])
            mass_join=wet_mass+trans_mass+ground_mass-et;rounding=32.*np.finfo(np.float32).eps*max(abs(wet_mass)+abs(trans_mass)+abs(ground_mass)+abs(et),1e-20);assert abs(mass_join)<=rounding;mass_join_max=max(mass_join_max,abs(mass_join));mass_join_ratio=max(mass_join_ratio,abs(mass_join)/rounding)
            wet_latent=float(np.asarray(surface['vapor_latent_energy'],float).sum()/dt);trans_latent=2.5e6*float(np.asarray(surface['transpiration'],float).sum());ground_latent=le-wet_latent-trans_latent
            values.append([le,wet_latent,trans_latent,ground_latent,et,wet_mass,trans_mass,ground_mass,float(np.asarray(before[7],float)[:,:,0].sum()),float(np.asarray(after[7],float)[:,:,0].sum()),float(data['forcing'][0,5]),float(data['forcing'][0,7])*dt*1000.])
        for k in range(23):assert previous[k].dtype==saved['a'+str(k)].dtype and previous[k].tobytes()==saved['a'+str(k)].tobytes()
        for key,value in [('initial',initial),('net',recorded_net),('bounds',bounds)]:np.testing.assert_array_equal(saved[key],value)
        a=np.asarray(values);np.savez_compressed(r/(label+'-components.npz'),values=a,time_start=trace['time_start'],time_end=trace['time_end'],reference_FCEV=reference['FCEV'][:96],reference_FCTR=reference['FCTR'][:96],reference_FGEV=reference['FGEV'][:96],reference_LE=reference['EFLX_LH_TOT'][:96])
        daily=[]
        for day in range(2):
            q=slice(day*48,(day+1)*48);model={k:float(a[q,j].mean()) for j,k in enumerate(['total','wet_canopy','transpiration','ground_derived'])};ref={k:float(reference[n][q].mean(dtype=float)) for k,n in [('total','EFLX_LH_TOT'),('wet_canopy','FCEV'),('transpiration','FCTR'),('ground_derived','FGEV')]}
            daily.append(dict(day=day+1,model_latent_wm2=model,official_latent_wm2=ref,model_minus_official_wm2={k:model[k]-ref[k] for k in model},model_et_and_components_mm={k:float(a[q,j].sum()) for j,k in enumerate(['total','wet_canopy','transpiration','ground'],start=4)},official_total_et_mm=float(reference['QFLX_EVAP_TOT'][q].sum(dtype=float)*1800.),precipitation_mm=float(a[q,11].sum()),model_canopy_water_start_end_kgm2=[float(a[day*48,8]),float(a[(day+1)*48-1,9])]))
        summary=dict(passed=True,physical_pairs=96,all23state_chains_exact=True,all30final_fields_exact=True,full_original96trace_exact=True,maximum_independent_step_m_h_c_n=max_step.tolist(),maximum_independent_cumulative_m_h_c_n=max_cumulative.tolist(),original_cumulative_bounds=bounds.tolist(),maximum_step_original_guard_ratio=max_ratio.tolist(),maximum_impurity_residual=impurity_max.tolist(),independent_et_component_mass_join_maximum_kgm2=mass_join_max,maximum_et_component_history_rounding_ratio=mass_join_ratio,component_columns=['total_LE_Wm2','wet_canopy_LE_Wm2','transpiration_LE_Wm2','ground_LE_Wm2_DERIVED_from_total_minus_wet_minus_trans','et_mm','wet_mass_mm','transpiration_mass_mm','ground_mass_mm','canopy_mass_before_kgm2','canopy_mass_after_kgm2','SW_Wm2','precip_mm'],daily=daily,components_sha256=sha(r/(label+'-components.npz')))
    except Exception as err:
        failure=type(err).__name__+': '+str(err);(r/(label+'-traceback.txt')).write_text(traceback.format_exc());summary.update(passed=False,failure=failure)
    summary['case']=label;cases.append(summary)
record=dict(passed=all(c['passed'] for c in cases),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,cases=cases,scope='Bothcurrent563C actual96 firsttwo-days independent all23beforeafter/cold30/final30/cumulative originalguard audits, originalfirst48 + private exactfixedday2 replay through actually committed96. Nativewet latent from actualvaporparcelJ/dt; transp latent from actualmass*originalLV; groundlatent is explicitly DERIVED remainder of actualtotal, not an independentlymeasured closure. ET masspartition direct actualthreefluxes checked at historyrounding. Official masscomponents unavailable, not fabricated. Rawcomponent comparison is diagnostic, no parameter selection, broad10day causalclaim or completeyear/spinup/scientific acceptance.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True);assert record['passed'] and record['source_unchanged']

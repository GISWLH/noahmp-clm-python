from pathlib import Path
import ast
b=Path(__file__).resolve().parent
s=(b/'audit_qia_latent_ai.py').read_text().replace('qia-latent-audit-ai','qia-latent-audit-aib').replace('maximum_et_component_history_rounding_ratio=mass_join_ratio','maximum_et_component_history_rounding_ratio=float(mass_join_ratio)')
check="""for case_label in ['capacity','capacity_optics']:
    with np.load(b/'qia-latent-audit-ai'/(case_label+'-components.npz'),allow_pickle=False) as old,np.load(r/(case_label+'-components.npz'),allow_pickle=False) as new:
        assert set(old.files)==set(new.files)
        for key in old.files:assert old[key].dtype==new[key].dtype and old[key].shape==new[key].shape and old[key].tobytes()==new[key].tobytes()
"""
s=s.replace('record=dict(passed=',check+'record=dict(serialization_only_replay_arrays_equal_to_original_AI=True,passed=');ast.parse(s);(b/'audit_qia_latent_aib.py').write_bytes(s.encode())
for src,dst in [('qia_latent_audit_ai.pbs','qia_latent_audit_aib.pbs'),('dispatch_qia_latent_audit_ai.py','dispatch_qia_latent_audit_aib.py')]:
    s=(b/src).read_text().replace('qia-latent-audit-ai','qia-latent-audit-aib').replace('audit_qia_latent_ai.py','audit_qia_latent_aib.py').replace('qia_latent_audit_ai.pbs','qia_latent_audit_aib.pbs')
    if dst.endswith('.py'):ast.parse(s)
    (b/dst).write_bytes(s.encode())

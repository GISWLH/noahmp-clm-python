from pathlib import Path
import hashlib,json,sys,tarfile
mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='official':
    b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-official-latent-afc';d=json.loads((r/'receipt.json').read_text());runtime=json.loads((r/'runtime-receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['diagnosis_complete'] and d['pbs_job']=='364.manager' and runtime['diagnosis_receipt_sha256']==sha(r/'receipt.json') and all(v['returncode']==0 for v in runtime['stages']) and sha(r/'official-latent-first480.npz')==d['output_sha256']
    items=[]
    for name in ['qia-official-latent-af','qia-official-latent-afb','qia-official-latent-afc']:
        root=b/name
        if name!=r.name:assert (root/'pbs-exit.txt').read_text().strip()=='1' and 'ModuleNotFoundError' in (root/'inspect.log').read_text()
        items += [(p,name+'/'+p.relative_to(root).as_posix()) for p in sorted(root.rglob('*')) if p.is_file()]
    controls=['dispatch_qia_official_latent_af.py','dispatch_qia_official_latent_afb.py','dispatch_qia_official_latent_afc.py',Path(__file__).name];name='qia-official-latent-afc'
elif mode=='replay':
    b=Path('/home/lhwang/work/noahmp-v1');items=[]
    for label in ['capacity','capacity_optics']:
        root=b/('qia-le-'+label+'-replay-ag');d=json.loads((root/'receipt.json').read_text());e=json.loads((root/'exit.json').read_text());assert e['returncode']==0 and e['passed'] and e['receipt_sha256']==sha(root/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['starting_fields_exact']==d['ending_fields_exact']==30 and d['captured_calls']==48 and d['full_original96trace_exact']
        for p in sorted(root.rglob('*')):
            if not p.is_file():continue
            rel=p.relative_to(root).as_posix()
            if rel.startswith('seed/') and not rel.startswith('seed/'+label+'/trajectory/'):continue
            items.append((p,label+'/'+rel))
    controls=['freeze_qia_day2_ag.py','run_qia_day2_ag.py','control_qia_day2_ag.py','launch_qia_day2_ag.py','qia-recovery-c-prefix-u-evidence.tar.gz',Path(__file__).name];name='qia-le-day2-replay-ag'
elif mode=='audit':
    b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-latent-audit-aib';d=json.loads((r/'receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and d['pbs_job']=='366.manager' and d['serialization_only_replay_arrays_equal_to_original_AI']
    assert all(c['passed'] and c['physical_pairs']==96 and c['all23state_chains_exact'] and c['all30final_fields_exact'] and c['full_original96trace_exact'] for c in d['cases'])
    old=b/'qia-latent-audit-ai';assert (old/'pbs-exit.txt').read_text().strip()=='1' and 'float32 is not JSON serializable' in (old/'audit.log').read_text();items=[]
    for root in [old,r]:items += [(p,root.name+'/'+p.relative_to(root).as_posix()) for p in sorted(root.rglob('*')) if p.is_file()]
    controls=['dispatch_qia_latent_audit_ai.py','dispatch_qia_latent_audit_aib.py','prepare_qia_latent_aib.py',Path(__file__).name];name='qia-latent-audit-aib'
else:raise ValueError(mode)
items += [(b/n,'control/'+n) for n in controls];a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

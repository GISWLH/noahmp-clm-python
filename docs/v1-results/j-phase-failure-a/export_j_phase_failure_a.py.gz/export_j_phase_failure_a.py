from pathlib import Path
import datetime,hashlib,json,tarfile
import run_fluxnet_native as native
base=Path('/home/lhwang/work/noahmp-v1');original=base/'fluxnet-first-climate-cycle-20261017-j';folder=original/'cuda-day';source=native.ROOT;root=base/'failure-j-phase-a';root.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
report,state,cases=native.read_generation(folder);index=report['steps_completed'];assert report['status']=='failed' and index>5472 and index<17520 and 'CUDA layered phase surface failed' in report['failure'] and report['source_unchanged']
checkpoint=folder/report['checkpoint_file'];assert sha(checkpoint)==report['checkpoint_sha256'] and int(state['index'])==index
pairs=[(folder/'batch.json','original/global-batch.json'),(checkpoint,'original/'+checkpoint.name),(original/'batch.json','original/input-batch.json'),(original/'protocol.json','original/protocol.json'),(source/'SOURCE_SHA256.json','original/SOURCE_SHA256.json'),(original/'cuda-annual-resume.log','original/cuda-annual-resume.log')]
for r,data in cases:
    case=r['case'];desc=report['case_reports'][case];path=folder/case/desc['file'];trace=path.parent/r['model_npz'];assert r['status']=='failed' and r['steps_completed']==index and sha(trace)==r['model_npz_sha256'];pairs.extend([(path,'original/'+case+'/'+path.name),(trace,'original/'+case+'/'+trace.name)])
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Original failed J generation, no status/checkpoint/source edits. Full17520 request remains incomplete; original I4016 fix crossed but new phase solve failed.',status='failed',index=index,steps_requested=17520,checkpoint_file=checkpoint.name,checkpoint_sha256=sha(checkpoint),global_report_sha256=sha(folder/'batch.json'),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),source_files=len(manifest),source_unchanged=True)
(root/'original-failure-binding.json').write_text(json.dumps(value,indent=2)+'\n');pairs.extend([(root/'original-failure-binding.json','original-failure-binding.json'),(Path(__file__),Path(__file__).name)]);archive=base/'j-phase-failure-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(**value,files=len(pairs),archive=str(archive),archive_sha256=sha(archive))))

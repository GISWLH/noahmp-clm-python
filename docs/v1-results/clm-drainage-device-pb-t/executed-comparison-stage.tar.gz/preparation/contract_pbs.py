"""Frozen PB-r input/source identity, without numerical execution."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import tarfile

HERE = Path(__file__).resolve().parent
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def files(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        result = {}
        for member in archive:
            name = member.name.removeprefix('./')
            if not member.isfile():
                assert member.isdir()
                continue
            part = PurePosixPath(name)
            assert not part.is_absolute() and '..' not in part.parts and '\\' not in name
            assert name not in result
            result[name] = archive.extractfile(member).read()
        return result


def controls():
    raw = (HERE/'CONTROLS_SHA256.json').read_bytes()
    index = json.loads(raw)
    assert {p.name for p in HERE.iterdir() if p.is_file()} == set(index)|{'CONTROLS_SHA256.json'}
    assert all(sha((HERE/name).read_bytes()) == digest for name, digest in index.items())
    return sha(raw)


def source_identity(root, binding):
    root = Path(root).resolve()
    raw = (root/'SOURCE_SHA256.json').read_bytes()
    assert sha(raw) == binding['source_manifest_sha256']
    index = json.loads(raw)
    assert len(index) == 596
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == set(index)|{'SOURCE_SHA256.json'}
    assert all(sha((root/name).read_bytes()) == digest for name, digest in index.items())
    return dict(source_files=596, source_manifest_sha256=sha(raw))


def bound_evidence(path, binding):
    raw = Path(path).read_bytes()
    assert sha(raw) == binding['evidence_archive_sha256']
    outer = files(raw)
    assert len(outer) == 149
    inventory = json.loads(outer['artifact-inventory.json'])
    assert set(inventory) == set(outer)-{'artifact-inventory.json'}
    assert all(sha(outer[n]) == row['sha256'] and len(outer[n]) == row['bytes'] for n,row in inventory.items())
    qstat = outer['closure/actual-qstat.stdout.txt'].decode()
    assert all(t in qstat for t in ('Job Id: 1704.manager', 'job_state = F', 'Exit_status = 0', 'Stageout_status = 0'))
    original_raw = outer['original-result.tar.gz']
    assert sha(original_raw) == binding['original_result_sha256']
    original = files(original_raw)
    record = json.loads(original['receipt.json'])
    assert record['passed'] and record['pbs_job'] == '1704.manager'
    assert record['numerical_parent_returncode'] == 0 and record['actual_tests'] == 24
    assert record['failures'] == record['errors'] == record['skipped'] == 0
    for case in binding['cases']:
        entry = binding['cases'][case]
        for name,key in ((entry['npz'],'npz_sha256'), (entry['json'],'json_sha256'), (entry['reference'],'reference_sha256')):
            assert sha(original[name]) == entry[key]
    return original

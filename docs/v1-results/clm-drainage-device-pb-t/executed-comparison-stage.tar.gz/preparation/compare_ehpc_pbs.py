"""EHPC-only complete CUDA/JAX pairing, original physical rules and hard ledgers."""
import argparse
import io
import json
import math
import os
from pathlib import Path
import socket
import sys

from contract_pbs import HERE, GPU, bound_evidence, controls, save, sha


def main():
    parser = argparse.ArgumentParser()
    for name in ('cuda','jax','evidence','output'):
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert not args.output.exists()
    args.output.mkdir()
    import numpy as np
    binding = json.loads((HERE/'BINDINGS.json').read_bytes())
    control_sha = controls()
    original = bound_evidence(args.evidence,binding)
    captures = {backend:json.loads((root/'capture-receipt.json').read_bytes())
                for backend,root in (('cuda',args.cuda),('jax',args.jax))}
    assert all(r['backend']==b and r['gpu_uuid']==GPU and r['source_manifest_sha256']==binding['source_manifest_sha256']
               and r['controls_manifest_sha256']==control_sha for b,r in captures.items())
    roots = dict(cuda=args.cuda,jax=args.jax)
    def arrays(raw,meta):
        assert sha(raw)==meta['npz_sha256']
        with np.load(io.BytesIO(raw),allow_pickle=False) as store:
            result={key:store[key].copy() for key in store.files}
        assert set(result)==set(meta['arrays'])
        for key,value in result.items():
            d=meta['arrays'][key]
            assert (value.dtype.str,list(value.shape),sha(value.tobytes()))==(d['dtype'],d['shape'],d['c_order_sha256'])
        return result
    def same_precision(actual,reference):
        assert set(actual)==set(reference)
        rows={}
        for key,a in actual.items():
            b=reference[key]
            assert a.dtype==b.dtype and a.shape==b.shape
            finite=bool(np.all(np.isfinite(a)) and np.all(np.isfinite(b)))
            difference=np.abs(a.astype(float)-b.astype(float))
            exact=np.full(a.shape,a.dtype.kind in 'biu',dtype=bool)
            if key in ('actual.diagnosis_before','actual.diagnosis_after_perched','actual.diagnosis_after'):
                exact[..., [3,4,5,6,12]]=True
            bound=np.where(exact,0.,1e-6+1e-6*np.abs(b.astype(float)))
            passed=finite and bool(np.all(difference<=bound))
            rows[key]=dict(dtype=a.dtype.str,shape=list(a.shape),finite=finite,
                exact_elements=int(np.count_nonzero(exact)), maximum_absolute_difference=float(difference.max(initial=0)),
                maximum_scaled_float_difference=float(np.max(np.where(exact,0.,difference/np.where(bound>0,bound,1.)),initial=0)),passed=passed)
        return dict(passed=all(r['passed'] for r in rows.values()),fields=rows)
    def physical(actual,cpu_record,reference):
        rows={}
        direct={'water':('actual.cells',0),'enthalpy':('actual.cells',1),
                'temperature':('actual.temperature_k',None),'liquid':('actual.liquid_kg_m2',None),'ice':('actual.ice_kg_m2',None)}
        for key,rule in cpu_record['comparisons'].items():
            if key in ('hard_budget','reference_hard_budget'):continue
            if key in direct:
                field,col=direct[key];a=actual[field][0]
                if col is not None:a=a[:,col]
            elif key.startswith(('diagnosis_before.','diagnosis_after_perched.','diagnosis_after.')):
                prefix,field=key.split('.')
                a=actual['actual.'+prefix][0, {'water_table_m':0,'frost_table_m':1,'perched_water_table_m':2}[field]]
            else:a=actual['actual.'+key][0]
            b=np.asarray(rule['reference'],float)
            assert a.shape==b.shape
            bound=np.maximum(rule['absolute_tolerance'],rule['relative_fraction']*abs(b))
            delta=a.astype(float)-b
            finite=bool(np.all(np.isfinite(a)) and np.all(np.isfinite(b)))
            rows[key]=dict(difference=delta.tolist(),maximum_absolute_difference=float(np.max(abs(delta),initial=0)),
                absolute_tolerance=rule['absolute_tolerance'],relative_fraction=rule['relative_fraction'],
                passed=finite and bool(np.all(abs(delta)<=bound)))
        for stage in ('diagnosis_before','diagnosis_after_perched','diagnosis_after'):
            for index,key in ((3,'frost_table_m'),(4,'perched_water_table_m')):
                value=float(actual['actual.'+stage][0,index]);expected=int(reference[stage][key] is not None)
                rows[stage+'.has_'+key]=dict(actual=value,reference=expected,exact_required=True,passed=value==expected)
        return dict(passed=all(r['passed'] for r in rows.values()),fields=rows)
    def behavior(actual,inputs,name,reference):
        rows={}
        for kind in ('saturated','perched'):
            band=next((b for b in reference['bands'] if b['kind']==kind),None)
            called=bool(actual['actual.'+kind+'.invoked'][0])
            elapsed=float(actual['actual.'+kind+'.elapsed_seconds'][0])
            clock=float(actual['actual.'+kind+'.clock_residual_seconds'][0])
            accepted=int(actual['actual.'+kind+'.accepted_substeps'][0])
            ok=(band is not None and elapsed==float(inputs['input.dt'][0]) and clock==0.) if called else (elapsed==0. and accepted==0)
            rows[kind+'.original_clock_contract']=dict(invoked=called,elapsed_seconds=elapsed,
                requested_seconds=float(inputs['input.dt'][0]),clock_residual_seconds=clock,accepted_substeps=accepted,passed=ok)
        profile=name.removesuffix('-float32')
        for kind,required in (('saturated',profile in ('warm','nonuniform_dz','two_bands')),
                              ('perched',profile in ('perched_micro','perched_stress','option2','two_bands'))):
            if required:
                invoked=bool(actual['actual.'+kind+'.invoked'][0]);flow=float(actual['actual.'+kind+'.drained_kg_m2'][0])
                rows[kind+'.original_active_outlet']=dict(invoked=invoked,drained_kg_m2=flow,passed=invoked and flow>0.)
        if profile=='zero_slope':
            invoked=bool(actual['actual.saturated.invoked'][0]);flow=float(actual['actual.drained_kg_m2'][0])
            rows['zero_slope.original_zero_outlet']=dict(invoked=invoked,drained_kg_m2=flow,passed=invoked and flow==0.)
        return dict(passed=all(r['passed'] for r in rows.values()),fields=rows)
    def hard(actual,inputs):
        rows={}
        stages=(('combined',inputs['input.cells'][0],actual['actual.cells'][0],''),
                ('perched',actual['actual.phase_cells_before'][0],actual['actual.phase_cells_after_perched'][0],'perched.'),
                ('saturated',actual['actual.phase_cells_after_perched'][0],actual['actual.phase_cells_final'][0],'saturated.'))
        for name,before,after,prefix in stages:
            for label,stock,col,flow,residual,boundkey in (
                ('water','water',4,'layer_mass_kg_m2','water_residual_kg_m2','water_bound_kg_m2'),
                ('heat','enthalpy',5,'layer_enthalpy_j_m2','energy_residual_j_m2','energy_bound_j_m2')):
                column=0 if label=='water' else 1
                old=before[:,column] if name=='combined' else before[:,col]
                new=after[:,column] if name=='combined' else after[:,col]
                exported=actual['actual.'+prefix+flow][0]
                reported=float(actual['actual.'+prefix+residual][0]);bound=float(actual['actual.'+prefix+boundkey][0])
                independent=math.fsum([*map(float,new),*map(float,-old),*map(float,exported)])
                ok=all(math.isfinite(v) for v in (reported,bound,independent)) and bound>=0 and abs(reported)<=bound and abs(independent)<=bound
                rows[name+'.'+label]=dict(native_residual=reported,independent_residual=independent,
                    original_native_bound=bound,original_factor=64,passed=ok)
        return dict(passed=all(r['passed'] for r in rows.values()),fields=rows)
    report=dict(passed=False,pbs_job=os.environ['PBS_JOBID'],source_manifest_sha256=binding['source_manifest_sha256'],
        controls_manifest_sha256=control_sha,cases=[],gpu_capture_status={b:r['passed'] for b,r in captures.items()},
        scope='Actual device component captures against original 1704 inputs/reference. No new forward/reference/official/column/year run.')
    for name,entry in binding['cases'].items():
        cpu_meta=json.loads(original[entry['json']])
        reference=json.loads(original[entry['reference']])
        cpu_values=arrays(original[entry['npz']],dict(npz_sha256=cpu_meta['sha256'],arrays=cpu_meta['arrays']))
        cpu_actual={k:v for k,v in cpu_values.items() if k.startswith('actual.')}
        row=dict(case=name,backends={},cuda32_jax32=dict(passed=False,reason='Not both completed'))
        device_values={}
        for backend in ('cuda','jax'):
            path=roots[backend]/name
            if not (path/'result.json').exists():
                row['backends'][backend]=dict(passed=False,reason='Device case did not complete')
                continue
            meta=json.loads((path/'result.json').read_bytes())
            assert meta['actual_device_barrier_complete'] and meta['own_process_gpu_uuids'] and set(meta['own_process_gpu_uuids'])=={GPU}
            actual=arrays((path/'result.npz').read_bytes(),meta)
            device_values[backend]=actual
            physical_result=physical(actual,cpu_meta,reference);budget=hard(actual,cpu_values);contracts=behavior(actual,cpu_values,name,reference)
            row['backends'][backend]=dict(passed=physical_result['passed'] and budget['passed'] and contracts['passed'],physical64=physical_result,
                hard_ledgers=budget,original_behavior=contracts,numpy32_sameprecision_diagnostic=same_precision(actual,cpu_actual))
        if len(device_values)==2:row['cuda32_jax32']=same_precision(device_values['cuda'],device_values['jax'])
        row['passed']=all(r['passed'] for r in row['backends'].values()) and row['cuda32_jax32']['passed']
        report['cases'].append(row)
    report['passed']=all(report['gpu_capture_status'].values()) and len(report['cases'])==8 and all(r['passed'] for r in report['cases'])
    assert controls()==control_sha
    save(args.output/'comparison.json',report)
    print(json.dumps(dict(passed=report['passed'],actual_cases=len(report['cases']),pbs_job=report['pbs_job'])))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())

"""Verify one fresh GPU stage, extract its frozen source and launch once."""
import argparse
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import subprocess
import sys
import tarfile

sha=lambda raw:hashlib.sha256(raw).hexdigest()


def unpack(path):
    with tarfile.open(path) as archive:
        members=archive.getmembers()
        assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
        assert len({m.name for m in members})==len(members)
        return {m.name:archive.extractfile(m).read() for m in members}


def write(root,items):
    for name,raw in items.items():
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)


def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',type=Path,required=True);p.add_argument('--sha256',required=True);a=p.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode
    assert sha(a.stage.read_bytes())==a.sha256
    items=unpack(a.stage);index=json.loads(items['stage-inventory.json'])
    assert set(index)==set(items)-{'stage-inventory.json'} and all(sha(items[n])==h for n,h in index.items())
    policy=json.loads(items['execution/EXECUTION_BINDINGS.json']);root=Path(policy['root']);temporary=Path(policy['temporary'])
    assert not root.exists() and not temporary.exists()
    assert sha(items['preparation/CONTROLS_SHA256.json'])==policy['preparation_manifest_sha256']
    assert sha(items['source.tar.gz'])==policy['source_archive_sha256']
    assert sha(items['pbr-evidence.tar.gz'])==policy['evidence_archive_sha256']
    root.mkdir();temporary.mkdir();write(root,items)
    source=unpack(root/'source.tar.gz');manifest=json.loads(source['SOURCE_SHA256.json'])
    assert len(manifest)==596 and set(source)==set(manifest)|{'SOURCE_SHA256.json'}
    assert sha(source['SOURCE_SHA256.json'])==policy['source_manifest_sha256'] and all(sha(source[n])==h for n,h in manifest.items())
    write(temporary/'source',source)
    env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('LD_LIBRARY_PATH',None)
    env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'preparation'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    with (root/'controller.log').open('xb') as log:
        child=subprocess.Popen([sys.executable,'-B','-u',str(root/'execution/control_device_pbs.py')],cwd=root,env=env,
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    stat=Path('/proc')/str(child.pid)/'stat'
    record=dict(controller_pid=child.pid,proc_stat_at_launch=stat.read_text() if stat.exists() else None,
        stage_sha256=a.sha256,preparation_manifest_sha256=policy['preparation_manifest_sha256'],gpu_uuid=policy['gpu_uuid'],
        actual_controller_OS_returncode=None,root=str(root),temporary=str(temporary),backend_order=policy['backend_order'],single_launch=True)
    (root/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)


if __name__=='__main__':main()

"""Closed PB-t actual evidence, using opaque packet hashes and computed JSON only."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files, packet, sha

BASE=Path(__file__).resolve().parent
LABEL='clm-drainage-device-pb-t'
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()

def main():
    gpu_stage_raw=(BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes()
    cpu_stage_raw=(BASE/(LABEL+'-comparison-stage.tar.gz')).read_bytes()
    gpu_raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes()
    cpu_raw=(BASE/(LABEL+'-comparison-closed/result.tar.gz')).read_bytes()
    assert [sha(x) for x in (gpu_stage_raw,cpu_stage_raw,gpu_raw,cpu_raw)]==[
        'c0ba227ea2ff6daf6e038938c4c8e6812c5d9f62caad9297a06408ae64246aad',
        'b78651152620dff37b2c1b4822b770998b346c5cddff21ec3fe0dc7d2f29ce04',
        '69daf37ba4bdef8990de4325ba7bd3d8b38690adc4751fc0ae5f254cef669eea',
        '0ca941620dc56ffc924b79273a7902ae7cb6aee9b6770713bb93941a8c58d669']
    gpu_stage,cpu_stage,gpu,cpu=map(files,(gpu_stage_raw,cpu_stage_raw,gpu_raw,cpu_raw))
    for stage in (gpu_stage,cpu_stage):
        index=json.loads(stage['stage-inventory.json'])
        assert len(stage)==22 and set(index)==set(stage)-{'stage-inventory.json'}
        assert all(sha(stage[n])==h for n,h in index.items())
    for name in gpu_stage:
        if name.startswith(('preparation/','execution/')):assert gpu_stage[name]==cpu_stage[name]
    assert cpu_stage['gpu-result.tar.gz']==gpu_raw
    binding=json.loads(gpu_stage['preparation/BINDINGS.json'])
    assert sha(gpu_stage['source.tar.gz'])==binding['source_archive_sha256']=='da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d'
    source=files(gpu_stage['source.tar.gz']);source_index=json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index)==596 and all(sha(source[n])==h for n,h in source_index.items())
    assert sha(source['SOURCE_SHA256.json'])==binding['source_manifest_sha256']
    controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and controller['actual_controller_OS_returncode'] is None
    assert [x['actual_parent_returncode'] for x in controller['actual_parents']]==[0,0]
    captures={};arrays=0
    for backend in ('cuda','jax'):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json'])
        raw=gpu[backend+'/device/capture-receipt.json'];capture=json.loads(raw)
        assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
        assert parent['device_receipt_sha256']==sha(raw)
        assert capture['passed'] and len(capture['cases'])==8 and capture['actual_model_attempts']==capture['actual_model_returns']==8
        assert capture['source_controls_evidence_unchanged'] and not capture['forbidden_cpu_reference_calls']
        assert capture['source_manifest_sha256']==binding['source_manifest_sha256']
        assert capture['controls_manifest_sha256']==sha(gpu_stage['preparation/CONTROLS_SHA256.json'])
        captures[backend]=capture
        for name in binding['cases']:
            meta=json.loads(gpu[backend+'/device/'+name+'/result.json'])
            assert meta['actual_device_barrier_complete'] and meta['actual_encoded_parameters_phase_duration_echo_exact'] and meta['initial_phase_stock_payload_exact']
            assert set(meta['own_process_gpu_uuids'])=={'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'}
            assert len(meta['arrays'])==75
            arrays+=packet(gpu[backend+'/device/'+name+'/result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
    qstat=(BASE/(LABEL+'-comparison-closed/qstat.stdout')).read_text()
    assert all(v in qstat for v in ('Job Id: 1828.manager','job_state = F','Exit_status = 1','Stageout_status = 0','run_count = 1'))
    assert cpu['worker-exit.txt'].strip()==cpu['pbs-command-exit.txt'].strip()==b'1'
    assert cpu['setup-exit.txt'].strip()==cpu['stage-after-exit.txt'].strip()==b'0'
    assert cpu['worker.stderr']==cpu['run/comparison.stderr']==b''
    index=json.loads(cpu_stage['stage-inventory.json'])
    for name in ('stage-before.json','stage-after.json'):
        check=json.loads(cpu[name]);assert check['passed'] and check['actual']==check['expected']==index
    for directory,prefix in (('preparation','preparation-controls'),('execution','execution-controls')):
        controls=json.loads(cpu_stage[directory+'/CONTROLS_SHA256.json'])
        for name in [*controls,'CONTROLS_SHA256.json']:assert cpu[prefix+'/'+name]==cpu_stage[directory+'/'+name]
    parent=json.loads(cpu['run/comparison-parent-receipt.json'])
    assert parent['comparison_child_attempts']==1 and parent['comparison_child_returncode']==1 and parent['stage_unchanged']
    comparison=json.loads(cpu['run/comparison/comparison.json'])
    assert not comparison['passed'] and comparison['gpu_capture_status']==dict(cuda=True,jax=True) and len(comparison['cases'])==8
    cases=[]
    for row in comparison['cases']:
        assert all(x['passed'] and x['physical64']['passed'] and x['hard_ledgers']['passed'] and x['original_behavior']['passed'] for x in row['backends'].values())
        cases.append(dict(case=row['case'],passed=row['passed'],cuda32_jax32_passed=row['cuda32_jax32']['passed'],
            sameprecision_failed_fields={n:x for n,x in row['cuda32_jax32']['fields'].items() if not x['passed']},
            backends={b:dict(physical64=x['physical64'],hard_ledgers=x['hard_ledgers'],original_behavior=x['original_behavior'],
                numpy32_additional_sameprecision_passed=x['numpy32_sameprecision_diagnostic']['passed'],
                numpy32_additional_failed_fields={n:y for n,y in x['numpy32_sameprecision_diagnostic']['fields'].items() if not y['passed']}) for b,x in row['backends'].items()}))
    assert sum(x['passed'] for x in cases)==4
    readout=dict(actual_GPU_parent_returncodes=[0,0],actual_GPU_worker_returncodes=[0,0],original_controller_OS_returncode=None,
        GPU_timeouts=0,cuda_complete_cases=8,jax_complete_cases=8,opaque_arrays_verified=arrays,
        worker_seconds={b:x['seconds'] for b,x in captures.items()},parent_seconds={x['backend']:x['parent_receipt']['seconds'] for x in controller['actual_parents']},
        actual_comparison_job='1828.manager',actual_comparison_PBS_state='F',actual_comparison_PBS_exit=1,actual_comparison_Stageout_status=0,
        actual_comparison_child_exit=1,comparison_seconds=parent['seconds'],P0_behavior_and_hard_budget_passed_backend_cases=16,
        primary_cuda32_jax32_passed_cases=4,primary_cuda32_jax32_total_cases=8,overall_validation_passed=False,cases=cases,
        scope='PB-t CUDA-header compile repair with fresh actual CUDA/JAX captures; original EHPC P0/behavior/hard budgets all16 pass, primary all75-field1e-6/exact gate4/8 cases fails. No arithmetic/gate changes, full column, annual or production credit. Numeric statistics copied only from already-computed EHPC JSON.')
    verification=dict(evidence_verified=True,overall_model_validation_passed=False,source_files=596,preparation_controls=5,execution_controls=12,
        opaque_array_headers_and_hashes_verified=arrays,source_controls_inputs_unchanged=True,local_numerical_decode=False,local_model_runs=0,
        original_GPU_result_sha256=sha(gpu_raw),original_comparison_result_sha256=sha(cpu_raw),actual_GPU_parent_returncodes=[0,0],actual_comparison_F_exit=1,Stageout_status=0)
    items={'executed-gpu-stage.tar.gz':gpu_stage_raw,'executed-comparison-stage.tar.gz':cpu_stage_raw,
        'original-gpu-result.tar.gz':gpu_raw,'original-comparison-result.tar.gz':cpu_raw,
        'readout.json':encode(readout),'verification.json':encode(verification)}
    for n,raw in gpu_stage.items():
        if n.startswith(('preparation/','execution/')):items[n]=raw
    for leaf in (LABEL+'-gpu-closed',LABEL+'-comparison-closed'):
        for path in (BASE/leaf).iterdir():
            if path.is_file() and not path.name.endswith('.tar.gz'):items['closure/'+leaf+'/'+path.name]=path.read_bytes()
    for name in (LABEL+'-gpu-deployment.json',LABEL+'-comparison-deployment.json',LABEL+'-gpu-stage-package.json',LABEL+'-comparison-stage-package.json',
        'clm-drainage-header-pb-t-independent-qd.json','verify_drainage_pbt_independent_qd.py','verify_drainage_1704_pc.py',
        'prepare_drainage_device_pbt_qd.py','deploy_drainage_device_pbt_gpu_qd.py','deploy_drainage_device_pbt_compare_qd.py',
        'collect_stage_drainage_device_pbt_qd.py','collect_drainage_device_pbt_compare_closed_qd.py','read_drainage_device_pbt_qd.py',Path(__file__).name):
        items['provenance/'+name]=(BASE/name).read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-compare-deploy-',LABEL+'-progress-qd-'):
        for path in BASE.glob(prefix+'*'):
            if path.is_file():items['deployment/'+path.name]=path.read_bytes()
    for path in (BASE/'clm-drainage-header-pb-t-preparation').iterdir():
        if path.is_file():items['source-change/'+path.name]=path.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(raw),bytes=len(raw)) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for n,raw in sorted(items.items()):
                member=tarfile.TarInfo(n);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual PB-t CUDA/JAX workers0,16 completed encoded32 backend cases. EHPC1828 F1/Stageout0:16/16 P0/behavior/independent hard budgets pass; primary75-field1e-6/exact gate4/8 case pass, failures retained. Header-only compile fix, no full-column/year/production credit.')
    for suffix,value in (('readout',readout),('verification',verification),('package',package)):(BASE/(LABEL+'-'+suffix+'.json')).write_bytes(encode(value))
    print(json.dumps(package))

if __name__=='__main__':main()

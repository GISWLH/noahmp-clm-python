"""Independent standard-library-only verification of the prepared PB-t patch."""
from pathlib import Path
import hashlib
import json
import struct
import tarfile

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def read_archive(leaf,expected):
    path=BASE/leaf
    assert sha(path.read_bytes())==expected
    with tarfile.open(path) as archive:
        members=archive.getmembers()
        assert all(m.isfile() for m in members)
        assert len({m.name for m in members})==len(members)
        data={m.name:archive.extractfile(m).read() for m in members}
    index=json.loads(data['SOURCE_SHA256.json'])
    assert len(index)==596 and set(data)==set(index)|{'SOURCE_SHA256.json'}
    assert all(sha(data[n])==h for n,h in index.items())
    return data,index

def main():
    parent,old=read_archive('clm-drainage-warm-phase-pb-r-source.tar.gz','bbdac3f45871de1e43fc309b023c0e5c4430574bcf292b85e6f5997e620fe84a')
    candidate,new=read_archive('clm-drainage-header-pb-t-source.tar.gz','da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d')
    name='src/noahmp_clm/gpu/cuda/clm_drainage_primitives_kernel.cu'
    changed=[n for n in old if candidate[n]!=parent[n]]
    assert changed==[name]
    old_headers=b'#include <math.h>\n#include <float.h>\n'
    new_header=candidate[name].split(b'template<class T>',1)[0]
    prefix,body=parent[name].split(old_headers,1)
    assert new_header.startswith(prefix)
    compatibility=new_header[len(prefix):]
    assert candidate[name]==prefix+compatibility+body
    assert candidate[name].replace(compatibility,old_headers)==parent[name]
    assert struct.pack('<f',float('1.1920928955078125e-7')).hex()=='00000034'
    assert struct.pack('<d',float('2.220446049250313080847263336181640625e-16')).hex()=='000000000000b03c'
    summaries={}
    for leaf in ('clm-drainage-header-pb-t-preparation','clm-drainage-device-pb-t-preparation'):
        root=BASE/leaf;manifest=(root/'CONTROLS_SHA256.json').read_bytes();index=json.loads(manifest)
        assert all(sha((root/n).read_bytes())==h for n,h in index.items())
        summaries[leaf]=dict(files=len(index),manifest_sha256=sha(manifest))
    for leaf in ('contract_pbs.py','capture_device_pbs.py','compare_ehpc_pbs.py'):
        assert (BASE/'clm-drainage-device-pb-t-preparation'/leaf).read_bytes()==(BASE/'clm-drainage-device-pb-s-preparation'/leaf).read_bytes()
    result=dict(actual_stdlib_exit=0,source_files=596,unchanged_source_files=595,changed=changed,
        parent_manifest_sha256=sha(parent['SOURCE_SHA256.json']),candidate_manifest_sha256=sha(candidate['SOURCE_SHA256.json']),
        kernel_body_sha256=sha(body),reverse_header_replacement_byte_exact=True,preparation=summaries,
        numerical_capture_comparison_controls_byte_exact=True,numerical_execution=False,launched=False)
    target=BASE/'clm-drainage-header-pb-t-independent-qd.json'
    assert not target.exists()
    target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()

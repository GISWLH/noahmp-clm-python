"""Mechanical PB-t external wrappers/stage; no numerical-source changes."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
OLD=BASE/'clm-drainage-device-pb-s-execution'
NEW=BASE/'clm-drainage-device-pb-t-execution'
PREP=BASE/'clm-drainage-device-pb-t-preparation'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def archive(path,files):
    assert not path.exists()
    with path.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,raw in sorted(files.items()):
                member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644
                tar.addfile(member,io.BytesIO(raw))
    with tarfile.open(path) as tar:
        assert {m.name:tar.extractfile(m).read() for m in tar}==files
    return sha(path.read_bytes())

def main():
    assert not NEW.exists();NEW.mkdir()
    old_index=json.loads((OLD/'CONTROLS_SHA256.json').read_bytes())
    assert len(old_index)==11 and all(sha((OLD/n).read_bytes())==h for n,h in old_index.items())
    new_files={}
    diffs=[]
    for name in old_index:
        raw=(OLD/name).read_bytes()
        if name=='EXECUTION_BINDINGS.json':
            item=json.loads(raw)
            item.update(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
                source_archive_sha256='da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d',
                source_manifest_sha256='1d6031e5d9c9af3c027378c2c559bb17ce80fdeac141bef1862260180b9be661',
                root='/home/lhwang/work/noahmp-v1/clm-drainage-device-pb-t',
                temporary='/tmp/drainage-pb-s-pbt-20261026',source_modified=True,preparation_modified=True,
                change_scope='PB-t CUDA-header-only candidate; unchanged kernel body and all numerical controls')
            updated=encode(item)
        elif name=='run_device_parent_pbs.py':
            updated=raw
        else:
            updated=raw.replace(b'/tmp/noahmp-drainage-device-pb-s-compare',b'/tmp/noahmp-drainage-device-pb-t-compare')
            updated=updated.replace(b'/tmp/dispatch_compare_pbs.py',b'/tmp/dispatch_compare_pbt.py')
            if name=='README.md':
                updated+=b'\nPB-t reuse: external lifecycle wrappers are mechanically copied. The worker parent is byte-identical, preserving the legacy cache-path guard; the policy points to fresh /tmp/drainage-pb-s-pbt-20261026. Only persistent/private paths, preparation/source identity and explanatory binding metadata change. The original PB-s numerical capture/contract/comparison files remain byte-identical. Root authorized one CUDA then JAX run and one EHPC comparison, without retry.\n'
            if name=='compare_pbs.pbs':
                updated=updated.replace(b'#PBS -N drainage-device-pbs-compare',b'#PBS -N drainage-device-pbt-compare')
        if name.endswith('.py'):
            assert b'\0' not in updated;compile(ast.parse(updated),name,'exec')
        new_files[name]=updated
        diffs.extend(difflib.unified_diff(raw.decode().splitlines(True),updated.decode().splitlines(True),fromfile='PB-s/'+name,tofile='PB-t/'+name))
        (NEW/name).write_bytes(updated)
    (NEW/'PB_S_TO_PB_T.diff').write_text(''.join(diffs),encoding='utf-8')
    new_files['PB_S_TO_PB_T.diff']=(NEW/'PB_S_TO_PB_T.diff').read_bytes()
    manifest=encode({n:sha(raw) for n,raw in sorted(new_files.items())})
    (NEW/'CONTROLS_SHA256.json').write_bytes(manifest)
    assert new_files['run_device_parent_pbs.py']==(OLD/'run_device_parent_pbs.py').read_bytes()
    files={'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()}
    files.update({'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()})
    files['source.tar.gz']=(BASE/'clm-drainage-header-pb-t-source.tar.gz').read_bytes()
    files['pbr-evidence.tar.gz']=(BASE/'clm-drainage-warm-phase-pb-r-evidence.tar.gz').read_bytes()
    files['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(files.items())})
    target=BASE/'clm-drainage-device-pb-t-gpu-stage.tar.gz'
    digest=archive(target,files)
    result=dict(stage=target.name,stage_files=len(files),stage_sha256=digest,
        execution_controls=len(new_files),execution_manifest_sha256=sha(manifest),
        source_archive_sha256=sha(files['source.tar.gz']),preparation_manifest_sha256=sha(files['preparation/CONTROLS_SHA256.json']),
        worker_parent_byte_exact=True,launched=False,numerical_executed=False)
    (BASE/'clm-drainage-device-pb-t-gpu-stage-package.json').write_bytes(encode(result))
    print(json.dumps(result))

if __name__=='__main__':main()

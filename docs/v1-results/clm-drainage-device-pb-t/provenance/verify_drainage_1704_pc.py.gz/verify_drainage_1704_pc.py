"""Independent 1704 closure and opaque array evidence check; stdlib only."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import tarfile
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
EXPECTED = '0dc619264334c45aabafc398b42202df717dd07e58cfcfab19080b5a0cb82739'


def files(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        result = {}
        for member in archive:
            name = member.name.removeprefix('./')
            if not member.isfile():
                assert member.isdir()
                continue
            path = PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
            assert name not in result
            result[name] = archive.extractfile(member).read()
        return result


def packet(raw, record):
    assert sha(raw) == record['sha256']
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == {name+'.npy' for name in record['arrays']}
        for name, descriptor in record['arrays'].items():
            entry = archive.read(name+'.npy')
            assert entry[:6] == b'\x93NUMPY'
            version = tuple(entry[6:8])
            assert version in ((1, 0), (2, 0), (3, 0))
            width = 2 if version == (1, 0) else 4
            size = int.from_bytes(entry[8:8+width], 'little')
            header = ast.literal_eval(entry[8+width:8+width+size].decode())
            payload = entry[8+width+size:]
            assert header['fortran_order'] is False
            assert header['descr'] == descriptor['dtype']
            assert list(header['shape']) == descriptor['shape']
            assert sha(payload) == descriptor['c_order_sha256']
    return len(record['arrays'])


def main():
    raw = (BASE/'clm-drainage-warm-phase-pb-r-evidence.tar.gz').read_bytes()
    assert sha(raw) == EXPECTED
    package = files(raw)
    assert len(package) == 149
    inventory = json.loads(package['artifact-inventory.json'])
    assert set(inventory) == set(package)-{'artifact-inventory.json'}
    assert all(sha(package[n]) == row['sha256'] and len(package[n]) == row['bytes']
               for n, row in inventory.items())
    qstat = package['closure/actual-qstat.stdout.txt'].decode()
    assert all(text in qstat for text in ('Job Id: 1704.manager', 'job_state = F',
                                        'Exit_status = 0', 'Stageout_status = 0'))
    original_raw = package['original-result.tar.gz']
    original = files(original_raw)
    original_inventory = json.loads(package['original-result-inventory.json'])
    assert set(original_inventory) == set(original)
    assert all(sha(original[n]) == row['sha256'] and len(original[n]) == row['bytes']
               for n, row in original_inventory.items())
    receipt = json.loads(original['receipt.json'])
    assert receipt['pbs_job'] == '1704.manager' and receipt['passed']
    assert receipt['numerical_parent_returncode'] == receipt['collect_parent_returncode'] == 0
    assert receipt['actual_collected_nodes'] == receipt['actual_tests'] == 24
    assert receipt['failures'] == receipt['errors'] == receipt['skipped'] == 0
    assert original['worker-exit.txt'].strip() == b'0'
    collected, run = (json.loads(original[n]) for n in ('collect-nodes.json', 'run-nodes.json'))
    assert collected == run and len(set(run)) == 24
    suites = ET.fromstring(original['tests.xml'])
    suites = [suites] if suites.tag == 'testsuite' else list(suites)
    assert sum(int(s.attrib['tests']) for s in suites) == 24
    assert all(int(s.attrib[k]) == 0 for s in suites for k in ('failures', 'errors', 'skipped'))
    before, after = (json.loads(original[n]) for n in ('immutable-before.json', 'immutable-after.json'))
    assert before == after and len(before) == 1041
    assert all(sha(original[n]) == digest for n, digest in before.items())
    source = json.loads(original['source/SOURCE_SHA256.json'])
    assert len(source) == 596
    assert sha(original['source/SOURCE_SHA256.json']) == '2c926ee7e94eb13a770da1023406ed74cdb131dbafddcbc994cbb110401ee35d'
    assert all(sha(original['source/'+n]) == digest for n, digest in source.items())
    assert receipt['gold_summary_records'] == [dict(cases=20, diagnostic_trial_fields_byteexact=647, full_integrations=0)]
    records, count = {}, 0
    for name in original:
        if name.startswith('results/') and name.endswith('.json') and not name.endswith('-original-reference.json'):
            row = json.loads(original[name])
            assert row['case']+'.json' == PurePosixPath(name).name
            count += packet(original['results/'+row['file']], row)
            assert all(value['passed'] for value in row['comparisons'].values())
            records[row['case']] = row
    assert len(records) == 17
    profiles = ('warm', 'frozen', 'perched_micro', 'perched_stress', 'zero_slope', 'option2', 'nonuniform_dz', 'two_bands')
    selected = {}
    for profile in profiles:
        name = profile+'-float32'
        row = records[name]
        expected = {'input.cells': ('<f4', [1,4,3]), 'input.properties': ('<f4',[1,7]),
                    'input.options': ('<i4',[1]), 'input.dt': ('<f4',[1]),
                    'actual.encoded_parameters': ('<f4',[1,12])}
        assert all((row['arrays'][key]['dtype'], row['arrays'][key]['shape']) == value
                   for key, value in expected.items())
        selected[name] = dict(npz='results/'+row['file'], json='results/'+name+'.json',
            reference='results/'+name+'-original-reference.json',
            npz_sha256=row['sha256'], json_sha256=sha(original['results/'+name+'.json']),
            reference_sha256=sha(original['results/'+name+'-original-reference.json']),
            arrays=row['arrays'])
    report = dict(passed=True, actual_job='1704.manager', actual_PBS_state='F', actual_PBS_exit=0,
        Stageout_status=0, actual_tests=24, failures=0, errors=0, skipped=0,
        package_sha256=EXPECTED, original_result_sha256=sha(original_raw), source_files=596,
        source_manifest_sha256=sha(original['source/SOURCE_SHA256.json']), immutable_files=1041,
        reference_records=17, opaque_array_payloads_verified=count, encoded32_cases=selected,
        post_richards_precision='float64 only; no claimed float32 device coverage',
        scope='Independent original closure/JSON/NPY header/opaque payload proof. No numerical decoding, reference rerun or GPU/scientific acceptance.')
    (BASE/'clm-drainage-warm-phase-pb-r-actual-independent-review-pc.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k != 'encoded32_cases'}))


if __name__ == '__main__':
    main()

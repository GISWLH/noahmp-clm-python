from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'richards-native-e';r=b/'richards-flow-diagnosis-f';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==543 and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(s/'src'),str(s/'tests')]
import cupy as cp
import jax
import jax.numpy as j
from noahmp_clm.gpu.richards import _run,_compiled_step,_system,_properties
from noahmp_clm.gpu.cuda.richards import _step
with np.load(s/'tests/fixtures/richards_reference.npz',allow_pickle=False) as z:inputs=[z['32/4/'+k] for k in ['water','hydraulics','dt']]
with np.load(s/'target-e/diagnostics/case4.npz',allow_pickle=False) as z:original=dict(z)
data={};counts={};exact={};start=time.monotonic();system=jax.jit(_system);properties=jax.jit(_properties)
source=(s/'src/noahmp_clm/gpu/cuda/richards_kernel.cu').read_text()
marker='        sum+=dz;z[i]=sum-.5f*dz;';assert source.count(marker)==1
source=source.replace(marker,'        richards_properties[4*i]=water[i];richards_properties[4*i+1]=dw[i];richards_properties[4*i+2]=head[i];richards_properties[4*i+3]=dh[i];\n'+marker)
source='__device__ float richards_properties[40];\n'+source+'''
extern "C" __global__ void richards_probe(const float* u,const float* old,const float* p,float dt,float* out,int n) {
    if(blockIdx.x||threadIdx.x)return;
    float residual[10],q[10],a[100];richards_system(u,old,p,dt,n,residual,q,a);
    for(int i=0;i<n;++i)out[i]=residual[i];
    for(int i=0;i<n-1;++i)out[n+i]=q[i];
    for(int i=0;i<n*n;++i)out[2*n-1+i]=a[i];
    for(int i=0;i<4*n;++i)out[2*n-1+n*n+i]=richards_properties[i];
}
'''
(r/'diagnostic-kernel.cu').write_text(source)
compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('richards_probe',));probe=compiled.get_function('richards_probe')
for backend,xp,stepper in [('cuda',cp,_step),('jax',j,_compiled_step())]:
    calls=[]
    def observed(old,guess,p,dt):
        raw=stepper(old,guess,p,dt);i=len(calls);prefix=backend+'/'+str(i)+'/'
        get=lambda a:a.get() if hasattr(a,'get') else np.asarray(a)
        data.update({prefix+'old':get(old),prefix+'guess':get(guess),prefix+'raw':get(raw),prefix+'dt':np.asarray(dt)})
        if backend=='cuda':
            n=len(old);pr=cp.empty(n*n+6*n-1,cp.float32)
            probe((1,),(1,),(cp.ascontiguousarray(guess),cp.ascontiguousarray(old),cp.ascontiguousarray(p),np.float32(dt),pr,np.int32(n)))
            data[prefix+'system']=cp.asnumpy(pr)
        else:
            res,q,a=system(guess,old,p,dt);w,dw,h,dh=properties(guess,p)
            data[prefix+'system']=get(j.concatenate((res,q,a.ravel(),j.stack((w,dw,h,dh),axis=1).ravel())))
        calls.append(i);return raw
    result=_run(*(xp.asarray(v) for v in inputs),xp,observed)
    counts[backend]=len(calls);exact[backend]=all(getattr(v,'dtype',None)==original[backend+'/'+k].dtype and np.asarray(v.get() if hasattr(v,'get') else v).tobytes()==original[backend+'/'+k].tobytes() for k,v in result.items())
    for k,v in result.items():data[backend+'/final/'+k]=v.get() if hasattr(v,'get') else np.asarray(v)
np.savez_compressed(r/'flow-and-systems.npz',**data)
cp.cuda.runtime.deviceSynchronize();jax.effects_barrier();assert all(sha(s/n)==h for n,h in m.items())
d=dict(scope='GPU-only read-only source543E exact failedsameprecision case4 adaptive calls and initial primitive systems. Both final outputs must reproduce original saved arrays byte-exact before tracing conclusions. CUDA system instrumentation is private, original kernels/source/gates unchanged. No scientific or native gate pass; atexit bypass after barriers/durable receipt.',
    calls=counts,final_outputs_byte_exact=exact,source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),payload_sha256=sha(r/'flow-and-systems.npz'),device_barriers_complete=True,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

"""Metadata-only evidence snapshots; numerical model/analysis already onPBS."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();outputs=[]
def archive(name,items,scope):
    a=b/(name+'-evidence.tar.gz');assert not a.exists();assert len({n for p,n in items})==len(items)
    with tarfile.open(a,'w:gz') as t:
        for p,n in items:t.add(p,arcname=n,recursive=False)
        t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    outputs.append(dict(name=name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items)+1,scope=scope))
fs=b/'qia-water-response-fs';assert (fs/'pbs-exit.txt').read_text().strip()=='0';assert (fs/'result.json').exists();archive('qia-water-response-gc',[(p,'current/'+p.relative_to(fs).as_posix()) for p in sorted(fs.rglob('*')) if p.is_file()],'ActualPBS444 paired48surface-only response, all96calls andhardwater/heatbounds. Fixedstates/MOSTboundary; artificialbeta1 upperboundnot a feasible soilprofile/trajectory/spinup/sciencepass.')
fu=b/'multisite-spinup-inputs-fu';fv=b/'multisite-numpy-cold-fv';assert (fu/'pbs-exit.txt').read_text().strip()==(fv/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((fv/'receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and len(d['cases'])==12 and all(q['failure'] is None and q['captured_steps']==48 for q in d['cases']);inventory=[]
for p in sorted((fv/'runs').glob('*/steps/call-*.pkl.gz')):inventory.append(dict(path=p.relative_to(fv).as_posix(),sha256=sha(p),bytes=p.stat().st_size))
assert len(inventory)==576;(fv/'step-packet-inventory.json').write_text(json.dumps(dict(packets=inventory,scope='All576immutabletrustedNumPystepcaptures remainatEHPC; theirhashinventory preservedhere. Completefinalstates/traces preservedseparately. Not omittedfailedcases.'),indent=2)+'\n');items=[]
for root,prefix in [(fu,'preparation'),(fv,'numpy-reference')]:
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        relative=p.relative_to(root)
        if 'steps' in relative.parts:continue
        if relative.parts[0]=='inputs' and p.suffix=='.npz' and p.name!='cold-reference.npz':continue
        items.append((p,prefix+'/'+relative.as_posix()))
items.extend((b/n,'control/'+n) for n in ['multisite-spinup-fu-package.json','prepare_multisite_spinup_fu.py','dispatch_multisite_spinup_inputs_fu.py','run_multisite_numpy_cold_fv.py','dispatch_multisite_numpy_fv.py'])
archive('multisite-cold-reference-gc',items,'ActualPBS445preparationand446NumPy12x48allpassedcurrent579. Complete3siteyearinputidentities, all12configs/declaredplan/cold23, finalNumPystates/traces/receipts,576packethashinventory. FullforcingarchivedseparatelybydeclaredSHA, notregenerated. No annual/spinup/observationalpass.')
items=[]
for name in ['soil-stress-gpu-summary-fx','soil-stress-gpu-summary-fy','soil-stress-gpu-summary-fz']:
    root=b/name;assert (root/'pbs-exit.txt').read_text().strip()==('0' if name.endswith('fz') else '1')
    items.extend((p,name+'/'+p.name) for p in sorted(root.iterdir()) if p.is_file())
a=b/'soil-stress-coupled-fq-complete-evidence.tar.gz';assert sha(a)=='54e1580a1adb8fe74799318b97d2cc81a45fac82950ded066d61b6ff69e77d66';items.append((a,'device/actual-original12-evidence.tar.gz'))
archive('soil-stress-gpu-complete-gc',items,'Actualsame-sourceGPU12parent0/FQalloriginaltestsplusPBS449fullper-variablelogreadback. Original447/448parserfailurespreserved, no modelrerun/math/gate changes; full404/1552/years/sciencepending.')
(b/'science-checkpoint-gc-package.json').write_text(json.dumps(outputs,indent=2)+'\n');print(json.dumps(outputs),flush=True)

"""Allfirst48 paired surface replays: actualbeta vs one, fixedactualboundary.

This is a diagnostic upper response, not a trajectory, valid soil state,
calibration or a substitute for coupled MOST/spinup/observation validation.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import gzip,hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-water-response-fs';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();archive=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(archive)=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==v for n,v in m.items());full=json.loads((b/'soil-stress-coupled-fl-cpu/full-receipt.json').read_text());assert full['returncode']==0 and full['counts']==dict(tests=1148,failures=0,errors=0,skipped=0) and full['source_unchanged'] and full['source_manifest_sha256']==manifest
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
from noahmp_clm.physics.canopy_column import surface_step
fc=json.loads((b/'qia-warm-analysis-fc/analysis.json').read_text());assert fc['stage']=='first48' and fc['source_unchanged'] and len(fc['packet_inventory'])==48;inventory=fc['packet_inventory'];assert all(sha(Path(q['path']))==q['sha256'] for q in inventory);protocol=dict(source_manifest_sha256=manifest,original_analysis_sha256=sha(b/'qia-warm-analysis-fc/analysis.json'),all48_packets=inventory,steps=48,variants=['actual-beta','beta-one-fixed-boundary'],unmodified_source=True,budget_contract=dict(water_absolute_kgm2=2e-10,heat_absolute_jm2=.01,scope='Existing NumPy layered-phase-surface extensive mass/heat contract; independent sums, not percent tolerance'),scope='Prospectivelyallfirst48 original full24h, paired replay using exactcaptured surface state/forcing/geometry/rootwater and lastactualMOST boundary. Only secondvariant sets canopywater_stress=1. No soilwater/enthalpy/N/PFT/height/forcing/source changes and no next-step advancement; independenthalf-hours, no flux-feedbackMOST recomputation. Measures localpotentialresponse only, not feasiblealternative soil state, coupledtrajectory/sciencepass/calibration or spinup. Baseline mustmatch captured H/LE/GPP/ET and leafT under existing physical reference tolerances; no cherry-picked times.')
(r/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());(r/'raw').mkdir();start=time.monotonic()

def run_one(k):
    path=Path(inventory[k]['path']);packet=pickle.loads(gzip.decompress(path.read_bytes()));args=packet['surface_input']['args'];kwargs=packet['surface_input']['kwargs'];captured=packet['diagnostics'];assert not len(args[0].mass) and args[2]==1800.;before=hashlib.sha256(pickle.dumps((args,kwargs),protocol=5)).hexdigest();old_mass=float(args[0].mass.sum()+args[1].water.sum()+kwargs['canopy_condensate'].mass.sum());old_heat=float(args[0].enthalpy.sum()+args[1].enthalpy.sum()+kwargs['canopy_condensate'].enthalpy.sum());answers={}
    for label in protocol['variants']:
        controls=dict(kwargs)
        if label!='actual-beta':controls['water_stress']=1.
        snow,soil,canopy,d=surface_step(*args,**controls);dt=args[2];after_mass=float(snow.mass.sum()+soil.water.sum()+canopy);after_heat=float(snow.enthalpy.sum()+soil.enthalpy.sum()+d['canopy_enthalpy_after_jm2']);atmosphere=float((args[4]+args[5]-d['outgoing_shortwave']-d['outgoing_longwave']-d['h']-d['le'])*dt);water=after_mass-old_mass+d['et_kgm2']+d['runoff_kgm2'];heat=after_heat-old_heat-atmosphere+d['advected_enthalpy_jm2']+d['runoff_enthalpy_jm2'];assert abs(water)<2e-10 and abs(heat)<.01,(k,label,water,heat);assert abs(water-d['water_residual_kgm2'])<2e-12 and abs(heat-d['energy_residual_jm2'])<1e-7
        assert hashlib.sha256(pickle.dumps((args,kwargs),protocol=5)).hexdigest()==before,'Surface call mutated capturedphysical input'
        (r/'raw'/(str(k).zfill(3)+'-'+label+'.pkl.gz')).write_bytes(gzip.compress(pickle.dumps(dict(snow=snow,soil=soil,canopy=canopy,diagnostics=d),protocol=5),mtime=0))
        summary=dict(water_factor=float(controls['water_stress']),H_Wm2=float(d['h']),LE_Wm2=float(d['le']),GPP_umol_m2s=float(d['gpp']),ET_mm=float(d['et_kgm2']),transpiration_LE_Wm2=float(2.5e6*np.asarray(d['transpiration']).sum()),wet_LE_Wm2=float(np.asarray(d['vapor_parcels']['latent_energy_jm2']).sum()/dt),ground_LE_Wm2=float(d['ground_latent_energy_jm2']/dt),leaf_temperature_k=np.asarray(d['leaf_temperature']).tolist(),soil_temperature_k=soil.temperature.tolist(),water_residual_kgm2=water,heat_residual_jm2=heat)
        if label=='actual-beta':
            errors={}
            for name,floor,absolute in [('h',10.,1.),('le',10.,1.),('gpp',.01,.001),('et_kgm2',.001,.0001)]:
                actual=float(d[name]);ref=float(captured[name]);delta=abs(actual-ref);limit=absolute if abs(ref)<=floor else .1*abs(ref);assert delta<=limit,(k,name,delta,limit);errors[name]=dict(actual=actual,captured=ref,absolute_difference=delta)
            leaf=float(np.max(abs(np.asarray(d['leaf_temperature'])-np.asarray(captured['leaf_temperature']))));assert leaf<.05;summary.update(captured_baseline_errors=errors,captured_leaf_temperature_max_abs_k=leaf)
        answers[label]=summary
    return dict(index=k,packet_sha256=inventory[k]['sha256'],inputs_unchanged=True,results=answers)

results=[];failure=None
try:
    with ProcessPoolExecutor(max_workers=4) as pool:
        for row in pool.map(run_one,range(48)):
            results.append(row);(r/'progress.json').write_text(json.dumps(dict(completed=len(results),requested=48,last_index=row['index']))+'\n')
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
summary={}
if len(results)==48:
    assert [q['index'] for q in results]==list(range(48))
    for label in protocol['variants']:
        values=[q['results'][label] for q in results];summary[label]={name:dict(minimum=float(min(q[name] for q in values)),maximum=float(max(q[name] for q in values)),mean=float(np.mean([q[name] for q in values])),sum=float(np.sum([q[name] for q in values]))) for name in ['water_factor','H_Wm2','LE_Wm2','GPP_umol_m2s','ET_mm','transpiration_LE_Wm2','wet_LE_Wm2','ground_LE_Wm2','water_residual_kgm2','heat_residual_jm2']}
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),completed=len(results),requested=48,seconds=time.monotonic()-start,summary=summary,all48=results,scope=protocol['scope']);(r/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:result[k] for k in ['pbs_job','failure','completed','seconds','summary','source_unchanged']}),flush=True);assert failure is None and result['source_unchanged'] and len(results)==48

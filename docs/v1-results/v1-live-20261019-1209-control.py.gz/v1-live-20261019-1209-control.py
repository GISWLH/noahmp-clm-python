from pathlib import Path
import datetime
import json
import os
import sys

b = Path(sys.argv[1])
xuanze = str(b).startswith('/home/lhwang/')
cases = {
    'previous506': 'p6-phase-final-check-a/full-by-file-a/progress.json',
    'current510_exit': 'p6-fresh-phase-edge-a/full-controller-a/exit.json',
    'current510_worker': 'p6-fresh-phase-edge-a/full-controller-a/worker.json',
    'cuda_year_D': 'qia-physical-cuda-year-d/trajectory/batch.json',
    'strict_day_A': 'qia-stem-device-day-a/trajectory/batch.json',
} if xuanze else {'numpy_cold_510': 'qia-fresh-phase-numpy-week-a/trajectory/report.json',
                  'numpy_cold_receipt': 'qia-fresh-phase-numpy-week-a/receipt.json'}
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), host=os.uname().nodename,
              scope='Read-only live JSON/proc metadata; running snapshot is not completion, no numerical analysis.', cases={})
for name, filename in cases.items():
    p = b / filename
    if not p.exists():
        record['cases'][name] = dict(present=False)
        continue
    d = json.loads(p.read_text())
    keys = ['status', 'steps_completed', 'steps_requested', 'covered_nodes', 'covered_gpu_nodes', 'collected_nodes',
            'active', 'failure', 'source_unchanged', 'same_precision_max_absolute', 'maximum_cumulative_residual_m_h_c_n',
            'returncode', 'actual_returncode', 'passed', 'pid', 'utc', 'seconds']
    record['cases'][name] = dict(present=True, **{n: d[n] for n in keys if n in d})
record['processes'] = {}
for pid in ([2242411, 2557162, 2659844, 2750196] if xuanze else []):
    p = Path('/proc') / str(pid)
    record['processes'][str(pid)] = dict(present=p.exists(), command=(p / 'cmdline').read_bytes().replace(b'\0', b' ').decode() if p.exists() else None)
print(json.dumps(record, indent=2))

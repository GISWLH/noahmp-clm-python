from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
source=Path(sys.argv[1]);root=Path(sys.argv[2]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(manifest)==493 and all(sha(source/n)==v for n,v in manifest.items())
from test_gpu_canopy_phase_surface import cases,reference
arrays=cases(np.float64);rows=[];begun=time.monotonic()
for index,row in enumerate(zip(*arrays)):
 started=time.monotonic();failure=None;result=None
 try:
  d=reference(row)
  assert abs(d['energy_residual_jm2'])<.01 and abs(d['water_residual_kgm2'])<2e-10 and np.max(abs(d['layer_residual']))<1.05e-7
  result=dict(h=d['h'],le=d['le'],water_residual_kgm2=d['water_residual_kgm2'],heat_residual_jm2=d['energy_residual_jm2'],max_layer_residual_wm2=float(np.max(abs(d['layer_residual']))))
 except BaseException as e:
  failure=type(e).__name__+': '+str(e);(root/f'matrix-{index}-traceback.txt').write_text(traceback.format_exc())
  np.savez_compressed(root/f'matrix-{index}-failed-input.npz',**{'a'+str(k):a for k,a in enumerate(row)})
 r=dict(index=index,failure=failure,result=result,seconds=time.monotonic()-started);rows.append(r)
 (root/'matrix-progress.json').write_text(json.dumps(dict(rows=rows,expected=len(arrays[0])),indent=2)+'\n');print(json.dumps(r),flush=True)
unchanged=all(sha(source/n)==v for n,v in manifest.items());passed=unchanged and all(r['failure'] is None for r in rows)
record=dict(scope='EHPC NumPy reference side of all existing float64 GPU phase-surface cases, specifically checks the NumPy reference that failed source492 target. No device validation or extra pytest coverage implied.',passed=passed,rows=rows,source_unchanged=unchanged,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),seconds=time.monotonic()-begun,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename)
(root/'matrix-receipt.json').write_text(json.dumps(record,indent=2)+'\n');raise SystemExit(0 if passed else 1)

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-kink-numpy-year-h';assert not r.exists();r.mkdir();controls={}
for n in ['run_qia_kink_numpy_year_h.py','qia_kink_numpy_year_h.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia_kink_numpy_year_h.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,controls_sha256=controls,scope='Original-cold year only, no failed1110/changed-source continuation; exact943CPU/14GPU/independenthardbudget checks insidePBS before model launch.'),indent=2)+'\n');print(job)

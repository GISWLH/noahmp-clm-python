from pathlib import Path
from dataclasses import fields,is_dataclass
import hashlib,json,os,pickle,struct,subprocess,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics']
b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-richards-'+label+'-numpy-year-a');s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'thin-snow-event-native-a-source.tar.gz';assert sha(a)=='21895b2ced35a664e3522b539ef43ccd61ea2d3ffff56f36645d6e6abad5d994'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==558 and all(sha(s/n)==h for n,h in m.items())
cpu=b/'thin-snow-event-cpu-a';d=json.loads((cpu/'receipt.json').read_text())
assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1068,failures=0,errors=0,skipped=0) and json.loads((cpu/'SOURCE_SHA256.json').read_text())==m
old=b/('qia-richards-'+label+'-firstday-b');old_receipt=json.loads((old/'receipt.json').read_text());old_report=json.loads((old/'trajectory/report.json').read_text())
assert (old/'pbs-exit.txt').read_text().strip()=='0' and old_receipt['returncode']==0 and old_receipt['source_unchanged'] and old_report['status']=='running' and old_report['steps_completed']==48 and sha(old/'trajectory/report.json')==old_receipt['report_sha256']
comparison=b/'qia-richards-comparison-b';comparison_record=json.loads((comparison/'comparison.json').read_text());assert (comparison/'pbs-exit.txt').read_text().strip()=='0' and comparison_record['source_unchanged'] and len(comparison_record['cases'][label]['metrics'])==14
config=json.loads((old/'config.json').read_text());before=json.loads(json.dumps(config))
config['case']='qia-richards-'+label+'-cold-2003'
config['scope']='Prospectively declared full2003 cold-start17520 NumPy climate year, exact558 physical source/full1068CPU and actual originalcold48/all14officialR metrics. Both capacity and capacity+originalPFT optics variants retained; originalforcing/heights/stores/traits/roots/soil/VICsurface/explicit zero-flux Richards and physical/hardMHCN/convergence controls unchanged. Fresh cold first48 must match all stored trace fields and every checkpoint state/ledger bit, then continue the same new run to original year end. No defaultselection/calibration or completeyear/spinup/multisite/science claim before actual termination and independent checks. Heterogeneoussoil/aquifer/officialDAYL/SP-CN and inherited rawGPU/3803 limitations remain.'
assert {k for k in config if config[k]!=before[k]}=={'case','scope'}
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
inputs=b/'qia-stem-inputs-a/inputs';assert sha(inputs/'CN-Qia.npz')==old_report['forcing_npz_sha256']=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960' and sha(inputs/'CN-Qia.json')==old_report['forcing_manifest_sha256']
with np.load(inputs/'CN-Qia.npz',allow_pickle=False) as z:
    assert len(z['time_start'])==17520 and str(z['time_start'][0])=='200301010000' and str(z['time_end'][-1])=='200401010000'
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
cmd=[sys.executable,'-u',str(s/'benchmarks/run_fluxnet_column.py'),'--input',str(inputs/'CN-Qia.npz'),'--input-manifest',str(inputs/'CN-Qia.json'),'--config',str(r/'config.json'),'--output',str(r/'trajectory')]
launch=dict(scope=config['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_archive_sha256=sha(a),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cpu_receipt_sha256=sha(cpu/'receipt.json'),firstday_receipt_sha256=sha(old/'receipt.json'),firstday_report_sha256=sha(old/'trajectory/report.json'),all14_comparison_sha256=sha(comparison/'comparison.json'),configuration_sha256=sha(r/'config.json'),original_configuration_sha256=sha(old/'config.json'),nonphysical_configuration_changes=['case','scope'],cold_prefix_command=[*cmd,'--stop-after','48'],continuous_year_command=[*cmd,'--resume'])
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');started=time.monotonic();stage='cold_prefix';code=None;failure=None;equal_count=0
def same(x,y,path='checkpoint'):
    global equal_count
    assert type(x) is type(y),(path,type(x),type(y))
    if isinstance(x,np.ndarray):assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes(),path;equal_count+=1
    elif is_dataclass(x):
        for f in fields(x):same(getattr(x,f.name),getattr(y,f.name),path+'/'+f.name)
    elif isinstance(x,dict):
        assert x.keys()==y.keys(),path
        for k in x:same(x[k],y[k],path+'/'+str(k))
    elif isinstance(x,(list,tuple)):
        assert len(x)==len(y),path
        for i,(a,c) in enumerate(zip(x,y)):same(a,c,path+'/'+str(i))
    elif isinstance(x,(float,np.floating)):assert struct.pack('d',float(x))==struct.pack('d',float(y)),path;equal_count+=1
    else:assert x==y,path;equal_count+=1
try:
    with (r/'model.log').open('x') as log:code=subprocess.run([*cmd,'--stop-after','48'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    p=r/'trajectory/report.json';current=json.loads(p.read_text());assert code==0 and current['status']=='running' and current['steps_completed']==48 and current['steps_requested']==17520
    left=r/'trajectory'/current['model_npz'];right=old/'trajectory'/old_report['model_npz'];assert sha(left)==current['model_npz_sha256'] and sha(right)==old_report['model_npz_sha256']
    with np.load(left,allow_pickle=False) as x,np.load(right,allow_pickle=False) as y:
        assert set(x.files)==set(y.files)
        for k in x.files:same(x[k],y[k],'trace/'+k)
        trace_fields=len(x.files)
    left=r/'trajectory'/current['checkpoint_file'];right=old/'trajectory'/old_report['checkpoint_file'];assert sha(left)==current['checkpoint_sha256'] and sha(right)==old_report['checkpoint_sha256'];sys.path[:0]=[str(s/'src')]
    same(pickle.loads(left.read_bytes()),pickle.loads(right.read_bytes()))
    prefix=dict(scope='Own fresh558 year run at48/17520, not completeyear; every trace and fullcheckpoint state/ledger leaf exact to retained successful556R-B48. Source model+runner unchanged, only prospectivecase/scope metadata differ. Same own run continues.',first48_all_trace_and_state_exact=True,checked_leaf_fields=equal_count,trace_fields=trace_fields,own_report_sha256=sha(p),original_report_sha256=sha(old/'trajectory/report.json'),own_checkpoint_sha256=sha(left),original_checkpoint_sha256=sha(right),original_requested_steps=17520)
    (r/'prefix-audit.json').write_text(json.dumps(prefix,indent=2)+'\n');print(json.dumps(prefix),flush=True)
    stage='continuous_year'
    with (r/'model.log').open('a') as log:code=subprocess.run([*cmd,'--resume'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
except Exception as error:
    failure=type(error).__name__+': '+str(error);(r/'controller-failure.txt').write_text(traceback.format_exc())
p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else None
receipt=dict(scope=launch['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,stage=stage,controller_failure=failure,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-started,status=report['status'] if report else None,steps_completed=report['steps_completed'] if report else None,steps_requested=report['steps_requested'] if report else None,report_sha256=sha(p) if p.exists() else None)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert failure is None and code==0 and receipt['source_unchanged'] and report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520 and report['source_unchanged']

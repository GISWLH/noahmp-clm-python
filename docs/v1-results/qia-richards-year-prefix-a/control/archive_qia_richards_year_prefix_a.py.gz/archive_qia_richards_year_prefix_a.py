from pathlib import Path
import hashlib,io,json,subprocess,tarfile
from datetime import datetime,timezone
b=Path('/home/zhangyq/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();data={};rows=[]
def add(p,n):data[n]=p.read_bytes()
for label in ['capacity','capacity_optics']:
    r=b/('qia-richards-'+label+'-numpy-year-a');old=b/('qia-richards-'+label+'-firstday-b');prefix=json.loads((r/'prefix-audit.json').read_text());launch=json.loads((r/'launch.json').read_text());dispatch=json.loads((r/'dispatch.json').read_text())
    assert prefix['first48_all_trace_and_state_exact'] and prefix['checked_leaf_fields']==166 and prefix['trace_fields']==29 and prefix['original_requested_steps']==17520
    original=json.loads((old/'trajectory/report.json').read_text());assert sha((old/'trajectory/report.json').read_bytes())==prefix['original_report_sha256'] and prefix['own_checkpoint_sha256']==prefix['original_checkpoint_sha256']==original['checkpoint_sha256']
    # Snapshot the current atomic report, whose bytes can differ from the
    # earlier online prefix report solely because the same run continued.
    raw=(r/'trajectory/report.json').read_bytes();report=json.loads(raw)
    assert report['steps_requested']==17520 and report['steps_completed']>=48 and report['source_unchanged'] and report['configuration_sha256']==launch['configuration_sha256'] and report['status'] in ['running','complete','failed']
    for n in ['dispatch.json','launch.json','prefix-audit.json','config.json','SOURCE_SHA256.json','run_qia_richards_numpy_year_a.py','qia_richards_numpy_year_a.pbs','node.txt','controller.log','model.log']:
        add(r/n,label+'/'+n)
    data[label+'/current-report-snapshot.json']=raw
    for key,digest in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:
        p=r/'trajectory'/report[key];payload=p.read_bytes();assert sha(payload)==report[digest];data[label+'/current-generation/'+p.name]=payload
    for n in ['trace-0000048.npz','state-0000048.pkl']:
        p=old/'trajectory'/n;payload=p.read_bytes()
        if n.endswith('.pkl'):assert sha(payload)==prefix['own_checkpoint_sha256']
        else:assert sha(payload)==original['model_npz_sha256']
        data[label+'/certified-original48/'+n]=payload
    add(old/'trajectory/report.json',label+'/certified-original48/report.json')
    status=subprocess.run(['qstat','-f',dispatch['pbs_job']],text=True,capture_output=True)
    rows.append(dict(case=label,pbs_job=dispatch['pbs_job'],qstat_returncode=status.returncode,qstat=status.stdout,qstat_error=status.stderr,current_status=report['status'],current_steps=report['steps_completed'],current_report_sha256=sha(raw),observed_online_prefix_report_sha256=prefix['own_report_sha256'],prefix_checkpoint_byte_exact_to_retained_reference=True,original_requested_steps=17520))
record=dict(utc=datetime.now(timezone.utc).isoformat(),scope='Read-only snapshot of actual558 two NumPy cold-year jobs and certified48 prefix. Online audit proved29tracefields/fullstate166 leaves exact; checkpoint SHA itself equals retained originalB48. Mutable report is separately snapshotted under its actual current hash; observed earlier prefix report hash is not falsely assigned to this later snapshot. Original whole17520 requests and all ongoing jobs unchanged, not annual/spinup/scientific completion.',cases=rows)
data['snapshot.json']=(json.dumps(record,indent=2)+'\n').encode()
for n in ['dispatch_qia_richards_numpy_year_a.py',Path(__file__).name]:add(b/n,'control/'+n)
add(b/'thin-snow-event-native-a-source.tar.gz','source/thin-snow-event-native-a-source.tar.gz')
a=b/'qia-richards-year-prefix-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n,raw in data.items():
        info=tarfile.TarInfo(n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,utc=record['utc'],cases=[{k:row[k] for k in ['case','pbs_job','current_status','current_steps','qstat_returncode']} for row in rows])))

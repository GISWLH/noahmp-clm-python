from pathlib import Path
import hashlib,json,os,subprocess
b=Path('/home/zhangyq/noahmp-v1');cpu=b/'thin-snow-event-cpu-a';d=json.loads((cpu/'receipt.json').read_text())
assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1068,failures=0,errors=0,skipped=0)
available=os.statvfs(b).f_favail;assert available>2000,available
for label in ['capacity','capacity_optics']:
    old=b/('qia-richards-'+label+'-firstday-b');d=json.loads((old/'receipt.json').read_text());assert (old/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['steps_completed']==48
    r=b/('qia-richards-'+label+'-numpy-year-a');assert not r.exists();r.mkdir();controls={}
    for n in ['run_qia_richards_numpy_year_a.py','qia_richards_numpy_year_a.pbs']:
        raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
    p=subprocess.run(['qsub','-v','CAPACITY_CASE='+label,str(r/'qia_richards_numpy_year_a.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
    record=dict(case=label,pbs_job=p.stdout.strip(),controls_sha256=controls,free_home_inodes_before_dispatch=available,scope='Two prospectively fixed complete2003 cold years17520 on EHPC compute, exact558/full1068. Originalcold first48 trace+allstate equality to successfulB before same-own-run continuation. Both variants retained; queued is not completeyear or scientific pass.')
    (r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

"""Stage only own complete-parent paths and actual PBS afterok cycle2/3 chains."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

base = Path('/home/zhangyq/noahmp-v1')
root = base / 'climatology-numpy-cycles-hp'
assert not root.exists()
prior = base / 'climatology-numpy-years-gt'
old = json.loads((prior / 'plan.json').read_text())
year_jobs = json.loads((prior / 'year-dispatch.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert old['source_manifest_sha256'] == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert len(old['cases']) == 12 and len(year_jobs['jobs']) == 156
assert sha(base / 'snapshot_numpy_history_gt.py') == '67aac2578012ae9f6af03ed162bd5f5827c5a275695246c7d68369a5a7b66b94'
root.mkdir()
controls = {}
for name in ['run_climatology_numpy_cycle_hp.py', 'climatology_numpy_cycle_hp.pbs', 'snapshot_numpy_history_gt.py']:
    raw = (base / name).read_bytes()
    assert b'\r\n' not in raw
    (root / name).write_bytes(raw)
    controls[name] = sha(root / name)
points = [0, 48, 1440, 2880, 4320, 5760, 7200, 8640, 10080, 11520, 12960, 14400, 15840, 17280, 17520]
scope = ('Prospectiveall12 originalGMclimatology independentNumPy repeatedoriginalyear cycles2/3, onlyafter ownactualGT17520parent0. '
    'Full6 physicalstate/globalMHCNledgerobjects carriedbyteexact; onlycycle-localforcingindex0, cumulativeledger_steps/segmentsmonotonic. '
    'Derivedcyclemetadata explicitlylabelled, actualparentreport/state retained. First48 fullstep packets eachcycle plus alloriginalgenerationbytes '
    'preservedinSHAverifiedhistoryZIP; allnumericalsegmentlogs/receipts/actualparentPBSproof sealed/readbackSHA/CRC/fsync before logunlink, '
    'onePBSlog/exitfilepercycle retained sohomeinodeusebounded. CurrentactualPBSsuccess fromafterok/qstat, never inferredfromworkerreceipt. '
    'SamecurrentFL579 source/config/forcing/QC/splits andoriginalphysicalguards, no failedprefix/reseed/ledgerreset, model/default/observedscorefit. '
    'Boundedfirstbatch2/3 within originalmax20 protocol, not actualyear/spinup/SOC/observational/calibration/holdout or GPU/sameprecision acceptance.')
plan = dict(source_manifest_sha256=old['source_manifest_sha256'], cases=old['cases'],
    controls_sha256=controls, segments=list(map(list, zip(points[:-1], points[1:]))), cycles_requested=[2, 3],
    original_maximum_cycles=20, input_archive_sha256='b33fba4f80f7cde8a7e127d27694dc7c2e370e7cd8a6b2142db211c86dccba0e', scope=scope)
(root / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
jobs = []
for case in old['cases']:
    name = case['case']
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name)
    final = next(q for q in year_jobs['jobs'] if q['case'] == name and q['target'] == 17520)
    status = subprocess.check_output(['qstat', '-f', final['pbs_job']], text=True)
    assert not re.search(r'^\s*job_state = F\s*$', status, re.M), 'Do not attach staleafterok; actualterminalparents require explicit terminalvalidation'
    dependency = final['pbs_job']
    (root / name).mkdir()
    for number in [2, 3]:
        folder = root / name / ('cycle-' + str(number).zfill(2))
        folder.mkdir()
        (folder / 'trajectory').mkdir()
        (folder / 'generations').mkdir()
        for start, target in plan['segments']:
            env = 'CLM_CASE=' + name + ',CLM_CYCLE=' + str(number) + ',START_INDEX=' + str(start) + ',END_INDEX=' + str(target)
            p = subprocess.run(['qsub', '-o', str(folder / 'pbs.log'), '-v', env, '-W', 'depend=afterok:' + dependency,
                str(root / 'climatology_numpy_cycle_hp.pbs')], cwd=folder, capture_output=True, text=True)
            assert p.returncode == 0, p.stderr
            job = p.stdout.strip()
            jobs.append(dict(case=name, cycle=number, start=start, target=target, pbs_job=job, afterok=dependency))
            dependency = job
            (root / 'dispatch.json').write_text(json.dumps(dict(jobs=jobs, controls_sha256=controls, scope=scope), indent=2) + '\n')
assert len(jobs) == 336
print(json.dumps(dict(jobs=336, cases=12, cycles=[2, 3], first=jobs[0]['pbs_job'], last=jobs[-1]['pbs_job'],
    controls_sha256=controls, plan_sha256=sha(root / 'plan.json'), scope=scope)), flush=True)

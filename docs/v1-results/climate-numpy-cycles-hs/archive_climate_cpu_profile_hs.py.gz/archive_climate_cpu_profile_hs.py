"""Freeze actual cycle dependencies and the completed real-step profile."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import subprocess
import tarfile

base = Path('/home/zhangyq/noahmp-v1')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
root = base / 'climatology-numpy-cycles-hp'
plan = json.loads((root / 'plan.json').read_text())
dispatch = json.loads((root / 'dispatch.json').read_text())
assert len(dispatch['jobs']) == 336 and len(plan['cases']) == 12 and plan['cycles_requested'] == [2, 3]
assert all(sha((root / n).read_bytes()) == h for n, h in plan['controls_sha256'].items())
raw = subprocess.check_output(['qstat', '-f', *[q['pbs_job'] for q in dispatch['jobs']]], text=True)
sections = {part.splitlines()[0].strip(): part for part in raw.split('Job Id: ')[1:]}
assert len(sections) == 336
for job in dispatch['jobs']:
    text = sections[job['pbs_job']]
    assert re.search(r'^\s*job_state = H\s*$', text, re.M)
    assert 'afterok:' + job['afterok'] in text
for case in plan['cases']:
    for number in [2, 3]:
        folder = root / case['case'] / ('cycle-' + str(number).zfill(2))
        assert not any((folder / 'trajectory').iterdir()) and not any((folder / 'generations').iterdir())
items = {'actual-all336-pbs-status.txt': raw.encode()}
for p in root.iterdir():
    if p.is_file():
        items['current/' + p.name] = p.read_bytes()
parents = []
for case in plan['cases']:
    name = case['case']
    raw = (base / 'climatology-numpy-years-gt' / name / 'trajectory/report.json').read_bytes()
    current = json.loads(raw)
    assert current['status'] == 'running' and current['steps_completed'] < current['steps_requested'] == 17520
    items['incomplete-original-parents/' + name + '.json'] = raw
    parents.append(dict(case=name, original_status='running', original_saved_steps=current['steps_completed'],
        original_requested_steps=17520, all_new_cycle_seeds_absent=True))
items['snapshot.json'] = (json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    actual_held_jobs=336, cases=parents, original_source_manifest_sha256=plan['source_manifest_sha256'],
    scope='Actual336 PBS dependency records H, all24 newcycle trajectory/history folders empty, ownoriginalyear incomplete. Startuprequirements notyet satisfied; no actualcycle/positivecarry test/spinup/equilibrium credit. ' + plan['scope']), indent=2) + '\n').encode()
items['prepare_climatology_numpy_cycles_hp.py'] = (base / 'prepare_climatology_numpy_cycles_hp.py').read_bytes()
items['archive_climate_cpu_profile_hs.py'] = Path(__file__).read_bytes()


def package(name, contents, scope):
    archive = base / (name + '-evidence.tar.gz')
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as tf:
        for path, data in contents.items():
            member = tarfile.TarInfo(path)
            member.size = len(data)
            tf.addfile(member, io.BytesIO(data))
    with tarfile.open(archive) as tf:
        for member in tf:
            assert tf.extractfile(member).read() == contents[member.name]
    record = dict(archive_sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size, artifacts=len(contents),
        source_manifest_sha256=plan['source_manifest_sha256'], scope=scope)
    (base / (name + '-package.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(name=name, **record)), flush=True)


package('climate-numpy-cycles-hs', items, plan['scope'])
profile = base / 'numpy-winter-profile-hq'
assert (profile / 'pbs-exit.txt').read_text().strip() == '0'
receipt = json.loads((profile / 'receipt.json').read_text())
assert receipt['passed'] and receipt['source_unchanged'] and receipt['exact_returned_state_diagnostic_leaves'] == 441
status = subprocess.check_output(['qstat', '-xf', '832.manager'], text=True)
assert re.search(r'^\s*job_state = F\s*$', status, re.M) and re.search(r'^\s*Exit_status = 0\s*$', status, re.M)
(profile / 'actual-pbs-qstat.txt').write_text(status)
contents = {'prepare_numpy_profile_hq.py': (base / 'prepare_numpy_profile_hq.py').read_bytes()}
for p in sorted(profile.rglob('*')):
    if p.is_file():
        contents['current/' + p.relative_to(profile).as_posix()] = p.read_bytes()
package('numpy-winter-profile-hq', contents, receipt['scope'])

"""Independent NumPy repeated climate cycle segments with all physical ledgers."""
from pathlib import Path
from copy import deepcopy
from dataclasses import asdict
import contextlib
import fcntl
import gzip
import hashlib
import io
import json
import os
import pickle
import re
import subprocess
import sys
import tarfile
import time
import traceback
import zipfile
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'climatology-numpy-cycles-hp'
name = os.environ['CLM_CASE']
assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name)
number = int(os.environ['CLM_CYCLE'])
start = int(os.environ['START_INDEX'])
target = int(os.environ['END_INDEX'])
assert number in [2, 3]
plan = json.loads((root / 'plan.json').read_text())
assert [start, target] in plan['segments']
case = next(q for q in plan['cases'] if q['case'] == name)
folder = root / name / ('cycle-' + str(number).zfill(2))
trajectory = folder / 'trajectory'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(root / n) == digest for n, digest in plan['controls_sha256'].items())
lock = (root / name / 'case.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
dispatch = json.loads((root / 'dispatch.json').read_text())
job = next(q for q in dispatch['jobs'] if q['case'] == name and q['cycle'] == number and q['start'] == start)
assert job['target'] == target and job['pbs_job'] == os.environ['PBS_JOBID']
parent_qstat = subprocess.check_output(['qstat', '-xf', job['afterok']], text=True)
assert re.search(r'^\s*job_state = F\s*$', parent_qstat, re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', parent_qstat, re.M)
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == plan['source_manifest_sha256']
assert all(sha(source / n) == digest for n, digest in manifest.items())
inputs = Path(os.environ['TMPDIR']) / 'inputs'
inputs.mkdir()
archive = base / 'multisite-climatology-gm-inputs.tar.gz'
assert sha(archive) == plan['input_archive_sha256']
with tarfile.open(archive) as tf:
    tf.extractall(inputs, filter='data')
sys.path[:0] = [str(root), str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner
from snapshot_numpy_history_gt import snapshot_generation

full = json.loads((base / 'soil-stress-coupled-fl-cpu/full-receipt.json').read_text())
assert full['returncode'] == 0 and full['source_unchanged'] and full['source_manifest_sha256'] == source_sha
assert full['counts'] == dict(tests=1148, failures=0, errors=0, skipped=0)
assert sha(inputs / case['configuration']) == case['configuration_sha256']


def key(a, b):
    return 'segments/' + str(a).zfill(6) + '-' + str(b).zfill(6)


def previous_receipt(location, a, b):
    with zipfile.ZipFile(location / 'segments.zip') as z:
        path = key(a, b)
        raw = z.read(path + '/receipt.json')
        record = json.loads(z.read(path + '/ARCHIVE_MANIFEST.json'))
        assert hashlib.sha256(raw).hexdigest() == record['sha256']['receipt.json']
        return json.loads(raw)


seed_proof = None
if start == 0:
    assert not any(trajectory.iterdir())
    if number == 2:
        parent_root = base / 'climatology-numpy-years-gt' / name
        parent = json.loads((parent_root / 'segment-017280-receipt.json').read_text())
        assert (parent_root / 'segment-017280-pbs-exit.txt').read_text().strip() == '0'
    else:
        parent_root = root / name / 'cycle-02'
        parent = previous_receipt(parent_root, 17280, 17520)
        assert (parent_root / 'last-pbs-exit.txt').read_text().strip() == '0'
    original = parent_root / 'trajectory/report.json'
    raw = original.read_bytes()
    old = json.loads(raw)
    assert parent['failure'] is None and parent['source_unchanged'] and parent['model_completed_segment']
    assert parent['steps_completed'] == parent['steps_requested'] == 17520 and parent['status'] == 'complete'
    assert parent['report_sha256'] == sha(original) and old['status'] == 'complete'
    assert old['steps_completed'] == old['steps_requested'] == 17520 and old['source_unchanged'] and 'failure' not in old
    assert old['source_sha256'] == runner.source_hashes() and old['configuration_sha256'] == case['configuration_sha256']
    for field, digest in [('checkpoint_file', 'checkpoint_sha256'), ('model_npz', 'model_npz_sha256')]:
        assert sha(parent_root / 'trajectory' / old[field]) == old[digest]
    state_raw = (parent_root / 'trajectory' / old['checkpoint_file']).read_bytes()
    saved = pickle.loads(state_raw)
    assert len(saved) == 7 and saved[-1] == 17520
    assert old.get('ledger_steps', 17520) == (number - 1) * 17520
    assert old.get('ledger_segments', 1) == number - 1
    (folder / 'parent-complete-report.json').write_bytes(raw)
    (folder / 'parent-complete-state.pkl').write_bytes(state_raw)
    seed = saved[:-1] + (0,)
    assert pickle.dumps(seed[:6], protocol=5) == pickle.dumps(saved[:6], protocol=5)
    state_path = trajectory / 'state-0000000.pkl'
    state_path.write_bytes(pickle.dumps(seed))
    trace_path = trajectory / 'trace-0000000.npz'
    with np.load(parent_root / 'trajectory' / old['model_npz'], allow_pickle=False) as z:
        assert all(len(z[n]) == 17520 for n in z.files)
        np.savez_compressed(trace_path, **{n: z[n][:0].copy() for n in z.files})
    report = deepcopy(old)
    report.update(status='running', steps_completed=0, seconds=0., initial_state=asdict(seed[0]),
        checkpoint_file=state_path.name, checkpoint_sha256=sha(state_path), model_npz=trace_path.name,
        model_npz_sha256=sha(trace_path), ledger_steps=(number-1)*17520, ledger_segments=number,
        climate_cycle=number, previous_ledger_steps=(number-1)*17520,
        initial_run=dict(mode='cycle', report_sha256=sha(original), checkpoint_sha256=old['checkpoint_sha256'],
            parent_job=job['afterok'], previous_ledger_steps=(number-1)*17520, previous_segments=number-1),
        cycle_metadata_scope='New derivedcycle metadata with actualparentfinalstate as cycleinitialstate; alloriginal six physical/state/globalledger objects carried exactly. Onlylocalforcingindex restarts0; originalglobalinitialMHCN/net/bounds/maxima retained. Originalparentreport/state saved separately, not relabelled as new originalexecution.')
    runner.atomic_json(trajectory / 'report.json', report)
    seed_proof = dict(parent_source_manifest_sha256=parent['source_manifest_sha256'], actual_parent_job=job['afterok'],
        actual_parent_pbs_exit=0, six_original_state_and_ledger_objects_protocol5_byteexact=True,
        original_parent_seven_tuple_sha256=hashlib.sha256(state_raw).hexdigest(),
        new_cycle_local_index=0, global_ledger_steps=(number-1)*17520)
    runner.atomic_json(folder / 'cycle-start-proof.json', seed_proof)
else:
    prior_start = next(a for a, b in plan['segments'] if b == start)
    previous = previous_receipt(folder, prior_start, start)
    assert (folder / 'last-pbs-exit.txt').read_text().strip() == '0'
    assert previous['failure'] is None and previous['source_unchanged'] and previous['model_completed_segment']
    assert previous['steps_completed'] == start and previous['steps_requested'] == 17520
    assert previous['report_sha256'] == sha(trajectory / 'report.json')
old = json.loads((trajectory / 'report.json').read_text())
assert old['status'] == 'running' and 'failure' not in old and old['steps_completed'] == start
assert old['steps_requested'] == 17520 and old['source_sha256'] == runner.source_hashes()
assert old['ledger_steps'] == (number-1)*17520 + start and old['ledger_segments'] == number
for field, digest in [('checkpoint_file', 'checkpoint_sha256'), ('model_npz', 'model_npz_sha256')]:
    assert sha(trajectory / old[field]) == old[digest]
saved = pickle.loads((trajectory / old['checkpoint_file']).read_bytes())
assert len(saved) == 7 and saved[-1] == start
expected = pickle.dumps(saved[0], protocol=5)
original_step = runner.step_clm_enthalpy_column
original_json = runner.atomic_json
first_exact = False
calls = 0
history = folder / 'generations/history.zip'
snapshot_generation(trajectory, history)
packets = tarfile.open(folder / 'first48-steps.tar.gz', 'w:gz') if start == 0 else None
failure = None
model_completed = False
begun = time.monotonic()
log_path = folder / ('segment-' + str(start).zfill(6) + '-model.log')


def first(state, forcing, **kwargs):
    global first_exact, calls
    if not first_exact:
        assert pickle.dumps(state, protocol=5) == expected
        first_exact = True
    after, diagnostics = original_step(state, forcing, **kwargs)
    if packets is not None:
        raw = gzip.compress(pickle.dumps(dict(before=state, forcing=forcing, kwargs=kwargs,
            after=after, diagnostics=diagnostics), protocol=5), mtime=0)
        member = tarfile.TarInfo('call-' + str(calls).zfill(5) + '.pkl.gz')
        member.size = len(raw)
        packets.addfile(member, io.BytesIO(raw))
    calls += 1
    return after, diagnostics


def observe(path, value):
    if Path(path).resolve() == (trajectory / 'report.json').resolve():
        value.update(ledger_steps=(number-1)*17520+value['steps_completed'], ledger_segments=number,
                     climate_cycle=number, previous_ledger_steps=(number-1)*17520)
        original_json(path, value)
        snapshot_generation(trajectory, history)
    else:
        original_json(path, value)


with log_path.open('x') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
    try:
        runner.step_clm_enthalpy_column = first
        runner.atomic_json = observe
        result = runner.run(inputs / case['input'], inputs / case['input_manifest'], inputs / case['configuration'],
            trajectory, resume=True, stop_after=target-start)
        assert first_exact and calls == target-start and result['source_unchanged']
        assert result['steps_completed'] == target and result['steps_requested'] == 17520
        assert result['status'] == ('complete' if target == 17520 else 'running')
        assert result['ledger_steps'] == (number-1)*17520+target and result['ledger_segments'] == number
        model_completed = True
    except Exception as exc:
        failure = type(exc).__name__ + ': ' + str(exc)
        traceback.print_exc()
    finally:
        runner.step_clm_enthalpy_column = original_step
        runner.atomic_json = original_json
        if packets is not None:
            packets.close()
report = json.loads((trajectory / 'report.json').read_text())
record = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, case=name, cycle=number,
    source_manifest_sha256=source_sha, source_unchanged=all(sha(source / n) == digest for n, digest in manifest.items()),
    controls_unchanged=all(sha(root / n) == digest for n, digest in plan['controls_sha256'].items()),
    failure=failure, model_completed_segment=model_completed, start_index=start, target_index=target,
    first_continued_physical_state_byteexact=first_exact, calls=calls, status=report['status'],
    steps_completed=report['steps_completed'], steps_requested=report['steps_requested'],
    ledger_steps=report['ledger_steps'], ledger_segments=report['ledger_segments'],
    report_sha256=sha(trajectory / 'report.json'), initial_cycle_seed_proof=seed_proof,
    history_zip_sha256=sha(history), first48_capture_sha256=sha(folder / 'first48-steps.tar.gz') if start == 0 else None,
    previous_actual_parent_job=job['afterok'], previous_actual_parent_pbs_exit=0,
    seconds=time.monotonic()-begun, scope=plan['scope'])
raw = (json.dumps(record, indent=2) + '\n').encode()
if failure is not None or not record['source_unchanged'] or not record['controls_unchanged'] or not model_completed:
    (folder / ('segment-' + str(start).zfill(6) + '-failed-receipt.json')).write_bytes(raw)
    print(json.dumps(record), flush=True)
    raise SystemExit(1)
contents = {'receipt.json': raw, 'model.log': log_path.read_bytes(), 'actual-parent-pbs-qstat.txt': parent_qstat.encode()}
digests = {n: hashlib.sha256(data).hexdigest() for n, data in contents.items()}
archive_manifest = (json.dumps(dict(sha256=digests, current_job=os.environ['PBS_JOBID'],
    scope='Originalsuccessfulnumericalworker receipt/log plus actualsuccessfulparentPBSstatus; currentactualPBSexit is validated by nextafterokworker or terminalaudit, not claimedbeforethisjobreturns.'), indent=2) + '\n').encode()
with zipfile.ZipFile(folder / 'segments.zip', 'a', compression=zipfile.ZIP_DEFLATED) as z:
    prefix = key(start, target)
    assert prefix + '/receipt.json' not in z.namelist()
    for n, data in contents.items():
        z.writestr(prefix + '/' + n, data)
    z.writestr(prefix + '/ARCHIVE_MANIFEST.json', archive_manifest)
with (folder / 'segments.zip').open('rb') as stream:
    os.fsync(stream.fileno())
with zipfile.ZipFile(folder / 'segments.zip') as z:
    assert z.read(prefix + '/ARCHIVE_MANIFEST.json') == archive_manifest and z.testzip() is None
    assert all(hashlib.sha256(z.read(prefix + '/' + n)).hexdigest() == digest for n, digest in digests.items())
assert log_path.resolve().parent == folder.resolve() and hashlib.sha256(log_path.read_bytes()).hexdigest() == digests['model.log']
log_path.unlink()
print(json.dumps(record), flush=True)

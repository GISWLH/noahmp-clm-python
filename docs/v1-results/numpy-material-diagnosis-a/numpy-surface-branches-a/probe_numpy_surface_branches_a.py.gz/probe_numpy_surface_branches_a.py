from pathlib import Path
import hashlib,json,os,pickle,sys,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-surface-branches-a';name=sys.argv[1];out=root/name;out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());begun=time.monotonic();sys.path.insert(0,str(source/'src'))
from noahmp_clm.physics.canopy_column import surface_step
import noahmp_clm.physics.canopy_phase_energy as phase
original=base/'numpy-annual-failure-probe-a'/name;r=json.loads((original/'probe.json').read_text());row=r['surface_calls'][-1];p=original/row['file'];assert sha(p)==row['sha256'];args,kwargs=pickle.loads(p.read_bytes());previous=phase.solve_canopy_phase_energy;latest=None;samples={};counts=0
def wrapped(*args,**kwargs):
    global latest
    latest=(args,kwargs)
    return previous(*args,**kwargs)
def profile(frame,event,arg):
    global counts
    if event=='return' and frame.f_code.co_name=='evaluate' and Path(frame.f_code.co_filename).name=='canopy_column.py' and arg is not None:
        value,details=arg;counts+=1;sample=dict(temperature=float(frame.f_locals['temperature']),residual=float(value),details=details,phase_input=latest);key='positive' if value>0. else 'negative';samples[key]=sample
        if counts==1:samples['first']=sample
phase.solve_canopy_phase_energy=wrapped;failure=None
try:sys.setprofile(profile);surface_step(*args,**kwargs)
except BaseException as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:sys.setprofile(None);phase.solve_canopy_phase_energy=previous
brief={}
for key,value in samples.items():
    p=out/(key+'-sample.pkl');p.write_bytes(pickle.dumps(value));d=value['details'];can=d['result'];brief[key]=dict(temperature=value['temperature'],residual=value['residual'],snow_layers=len(d['snow'].mass),snow_mass=d['snow'].mass.tolist(),soil_temperature=d['soil'].temperature.tolist(),soil_water=d['soil'].water.tolist(),soil_enthalpy=d['soil'].enthalpy.tolist(),ground_vapor_kgm2=d['ground_mass'],root_mass_kgm2=d['root_mass'].tolist(),canopy_water=d['canopy_water'],h=can['h'],le=can['le'],leaf_temperature=can['leaf_temperature'].tolist(),canopy_temperature=can['canopy_temperature'],canopy_humidity=can['canopy_humidity'],thermal_residual_jm2=d['thermal']['residual_jm2'],sample_sha256=sha(p))
assert all(sha(source/n)==v for n,v in m.items());value=dict(scope='Diagnostic last positive/negative scalar surface trials and their explicit physical canopy input/results. Original frozen NumPy source/parameters/tolerances unchanged; no state advanced.',case=name,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,failure=failure,counts=counts,samples=brief,seconds=time.monotonic()-begun);(out/'branches.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

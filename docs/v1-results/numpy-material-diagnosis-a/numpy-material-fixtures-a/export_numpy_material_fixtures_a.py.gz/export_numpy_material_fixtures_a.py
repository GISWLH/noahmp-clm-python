from pathlib import Path
from dataclasses import asdict,replace
import hashlib,json,os,pickle,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-material-fixtures-a';sys.path[:0]=[str(source/'src'),str(source/'benchmarks')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());import run_fluxnet_column as driver
terminal=base/'fluxnet-numpy-current-first-year-a';original=json.loads((terminal/'exit.json').read_text());cuda=json.loads((root/'cuda-reference.json').read_text());assert cuda['status']=='all-valid-and-within-numerical-gates';records=[]
def encode(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)
for row,gpu in zip(original['cases'],cuda['rows']):
    assert row['case']==gpu['case'];archive=terminal/row['terminal_archive'];assert sha(archive)==row['terminal_archive_sha256']
    with tarfile.open(archive) as t:r=json.load(t.extractfile('report.json'));raw=t.extractfile(r['checkpoint_file']).read();assert hashlib.sha256(raw).hexdigest()==r['checkpoint_sha256'];state,_,_,_,_,_,index=pickle.loads(raw)
    c=r['configuration'];folder=base/'fluxnet-first-climate-cycle-20261017-h/inputs';path=folder/(c['site']+'.npz');meta=json.loads((folder/(c['site']+'.json')).read_text());assert sha(path)==r['forcing_npz_sha256']
    with np.load(path,allow_pickle=False) as z:data=dict(z)
    stamps=driver.validate_input(data,meta,path);f=driver.Forcing(*data['forcing'][index]);co2,mu,diffuse=map(float,data['environment'][index]);dep=driver.DepositionSchedule(c);env=driver.calendar(stamps[index],meta,c['phenology'] is not None)
    records.append(dict(case=row['case'],index=index,timestamp=str(data['time_start'][index]),state=asdict(state),forcing=vars(f),kwargs=dict(co2_ppm=co2,cosine_zenith=mu,diffuse_fraction=diffuse,leaf_dimension=c['leaf_dimension_m'],leaf_parameters=c['leaf_parameters'],most_geometry=c['most_geometry'],phenology_environment=None if env is None else asdict(env),deposition_rates=dep.aerosol(stamps[index],f.dt),nitrogen_deposition_gn_m2=dep.nitrogen_rate*f.dt),historical_failure=r['failure'].splitlines()[-1],original_state_sha256=r['checkpoint_sha256'],original_terminal_archive_sha256=sha(archive),native_cuda_h_wm2=gpu['actual']['h_wm2'],native_cuda_le_wm2=gpu['actual']['le_wm2']))
value=dict(scope='Four original NumPy121 failed states/next forcing as portable JSON, unchanged data, with source-bound CUDA32 numerical cross-check values. No original annual relabel/resume; runtime solver changes require actual tests.',source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),cuda_reference_sha256=sha(root/'cuda-reference.json'),cases=records);(root/'numpy_annual_material_events.json').write_text(json.dumps(value,indent=2,default=encode,allow_nan=False)+'\n')
import noahmp_clm.physics.canopy_phase_energy as phase
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
q=base/'numpy-annual-failure-probe-a/CN-Qia-suction-climate-cycle';binding=json.loads((q/'probe.json').read_text());item=binding['surface_calls'][-1];p=q/item['file'];assert sha(p)==item['sha256'];args,kwargs=pickle.loads(p.read_bytes());old=phase.solve_canopy_phase_energy;saved=None
def capture(*a,**kw):
    global saved
    try:return old(*a,**kw)
    except RuntimeError:saved=(a,kw);raise
phase.solve_canopy_phase_energy=capture
try:surface_step(*args,**kwargs)
except RuntimeError as e:error=str(e)
finally:phase.solve_canopy_phase_energy=old
assert saved is not None;a,kw=saved;leaf,sw,lw,e,condensate,dt=a;plain=replace(e,atmosphere_water_velocity=None,potential_temperature=None);arrays=pack_canopy_phase(leaf,sw,lw,plain,condensate,dt,dtype=np.float64,**kw);p=root/'qia_479_phase_jacobian.npz';np.savez_compressed(p,**{'a'+str(k):v for k,v in enumerate(arrays)},extension=np.asarray([e.water_velocity,e.heat_temperature]),leaf_parameters=pack_leaf_parameters(kw.get('leaf_parameters'),np.float64));(root/'qia-phase-binding.json').write_text(json.dumps(dict(scope='Original failed fixed Qia canopy phase input with actual MOST water velocity/potential temperature, packing only.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,error=error,input_sha256=sha(p),fixed_ground_temperature=kw['fixed_ground_temperature']),indent=2)+'\n');assert all(sha(source/n)==v for n,v in m.items());print(json.dumps(dict(cases=len(records),whole_fixture_sha256=sha(root/'numpy_annual_material_events.json'),phase_fixture_sha256=sha(p))),flush=True)

from pathlib import Path
from dataclasses import astuple
import hashlib,json,os,pickle,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-failure-native-packet-a';sys.path[:0]=[str(source/'src'),str(source/'benchmarks')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
import run_fluxnet_column as driver
from noahmp_clm.gpu.clm_bgc_column import pack_clm_bgc_columns,pack_bgc_environment
terminal=base/'fluxnet-numpy-current-first-year-a';r=json.loads((terminal/'exit.json').read_text());states=[];records=[];forcing=[];environment=[];phenology=[];deposition=[];nitrogen=[];geometry=[];dimensions=[];parameters=[]
for row in r['cases']:
    archive=terminal/row['terminal_archive'];assert sha(archive)==row['terminal_archive_sha256']
    with tarfile.open(archive) as t:
        report=json.load(t.extractfile('report.json'));raw=t.extractfile(report['checkpoint_file']).read();assert hashlib.sha256(raw).hexdigest()==report['checkpoint_sha256'];state,_,_,_,_,_,index=pickle.loads(raw)
    c=report['configuration'];folder=base/'fluxnet-first-climate-cycle-20261017-h/inputs';path=folder/(c['site']+'.npz');meta=json.loads((folder/(c['site']+'.json')).read_text());assert sha(path)==report['forcing_npz_sha256']
    with np.load(path,allow_pickle=False) as z:data=dict(z)
    stamps=driver.validate_input(data,meta,path);f=data['forcing'][index];dep=driver.DepositionSchedule(c);states.append(state);forcing.append(f);environment.append(data['environment'][index]);phenology.append(driver.calendar(stamps[index],meta,c['phenology'] is not None));deposition.append(dep.aerosol(stamps[index],f[0]));nitrogen.append(dep.nitrogen_rate*f[0]);geometry.append(astuple(driver.MOSTGeometry(**c['most_geometry'])));dimensions.append(c['leaf_dimension_m']);parameters.append(c['leaf_parameters']);records.append(dict(case=row['case'],index=index,timestamp=str(data['time_start'][index]),original_terminal_archive_sha256=sha(archive)))
assert all(v==parameters[0] for v in parameters);environment=np.asarray(environment);arrays=pack_clm_bgc_columns(states,dtype=np.float64,co2_ppm=environment[:,0],cosine_zenith=environment[:,1],diffuse_fraction=environment[:,2],leaf_dimension=np.asarray(dimensions));e,cal=pack_bgc_environment(phenology,dtype=np.float64);path=root/'native-inputs.npz';np.savez_compressed(path,**{f'a{k}':v for k,v in enumerate(arrays)},forcing=np.asarray(forcing),forcing_environment=environment,environment=e,calendar=cal,deposition=np.asarray(deposition),nitrogen=np.asarray(nitrogen),geometry=np.asarray(geometry));assert all(sha(source/n)==v for n,v in m.items());value=dict(scope='Data packing only on compute node: exact four failed NumPy states/next forcing retained in float64 native ABI, no physical tendency executed or original annual/state resumed. Native float32 replay must disclose quantization and audit every returned budget.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,cases=records,leaf_parameters=parameters[0],native_input_sha256=sha(path));(root/'packet.json').write_text(json.dumps(value,indent=2)+'\n');(root/'SOURCE_SHA256.json').write_bytes((source/'SOURCE_SHA256.json').read_bytes());archive=base/'numpy-failure-native-packet-a.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(root.iterdir()):
        if p.is_file():t.add(p,arcname=p.name,recursive=False)
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),packet=value)),flush=True)

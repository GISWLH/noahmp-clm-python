from pathlib import Path
import hashlib,json,os,pickle,sys,time,traceback,types
import numpy as np
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-surface-candidates-a';name=sys.argv[1];out=root/name;out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());sys.path.insert(0,str(source/'src'))
import noahmp_clm.physics.canopy_phase_energy as phase
original=base/'numpy-annual-failure-probe-a'/name;r=json.loads((original/'probe.json').read_text());record=r['surface_calls'][-1];p=original/record['file'];assert sha(p)==record['sha256'];args,kwargs=pickle.loads(p.read_bytes());baseline_phase=phase.solve_canopy_phase_energy
text=(source/'src/noahmp_clm/physics/canopy_column.py').read_text();needle='        for iteration in range(60):\n';assert text.count(needle)==1
event_code='''        solved_event=False
        for event in (TF,np.nextafter(TF,-np.inf),np.nextafter(TF,np.inf)):
            if left<=event<=right:
                event_value,event_details=evaluate(float(event))
                if abs(event_value)<=temperature_tolerance:
                    details=event_details;solved_event=True;break
        for iteration in range(60):
            if solved_event:break
'''
event=text.replace(needle,event_code)
old='        actual=float(pack.temperature[0] if len(pack.mass) else ground.temperature[0])'
post='''        # Diagnostic candidate: evaluate the surface after the same existing
        # conservative meltwater routing that is committed below the solve.
        end_pack,end_flow=drain_liquid(pack,return_ledger=True)
        if infiltration_parameters is None:
            end_ground,_,_=infiltrate(ground,end_flow['drainage_kgm2'],end_flow['drainage_enthalpy_jm2'])
        else:
            from .vic import infiltrate_vic
            end_ground,_,_=infiltrate_vic(ground,end_flow['drainage_kgm2'],end_flow['drainage_enthalpy_jm2'],infiltration_parameters)
        actual=float(end_pack.temperature[0] if len(end_pack.mass) else end_ground.temperature[0])'''
assert event.count(old)==1;post_event=event.replace(old,post);phase_text=(source/'src/noahmp_clm/physics/canopy_phase_energy.py').read_text();jac='step=1e-4 if k<n+1 else 1e-5';assert phase_text.count(jac)==2
def module(code,label):
    p=out/(label+'.py');p.write_text(code);v=types.ModuleType('noahmp_clm.physics._diagnostic_'+label);v.__package__='noahmp_clm.physics';exec(compile(code,str(p),'exec'),v.__dict__);return v
rows=[]
for label,code,jacobian in [('event-sides',event,None),('post-routing-event',post_event,None),('post-routing-small-jacobian',post_event,phase_text.replace(jac,'step=1e-6 if k<n+1 else 1e-7'))]:
    candidate=module(code,label);phase.solve_canopy_phase_energy=baseline_phase if jacobian is None else module(jacobian,label+'-phase').solve_canopy_phase_energy;begun=time.monotonic();row=dict(candidate=label)
    try:
        snow,soil,water,d=candidate.surface_step(*args,**kwargs);eps=np.finfo(float).eps;old_snow,old_soil,dt=args[:3];old_canopy=kwargs['canopy_condensate'];old_mass=float(old_snow.mass.sum()+old_soil.water.sum()+old_canopy.mass.sum());new_mass=float(snow.mass.sum()+soil.water.sum()+water);old_heat=float(np.abs(old_snow.enthalpy).sum()+np.abs(old_soil.enthalpy).sum()+np.abs(old_canopy.enthalpy).sum());new_heat=float(np.abs(snow.enthalpy).sum()+np.abs(soil.enthalpy).sum()+np.abs(d['canopy_condensate'].enthalpy).sum());mb=32*eps*max(old_mass+new_mass+abs(d['et_kgm2'])+d['runoff_kgm2'],1.);hb=float(np.sum(d['thermal']['convergence_tolerance_jm2']))+dt*float(np.abs(d['layer_residual']).sum())+32*eps*max(old_heat+new_heat+abs(d['atmospheric_energy_jm2'])+abs(d['advected_enthalpy_jm2'])+abs(d['runoff_enthalpy_jm2']),1.)+1e-5;assert abs(d['water_residual_kgm2'])<=mb and abs(d['energy_residual_jm2'])<=hb
        p=out/(label+'-output.pkl');p.write_bytes(pickle.dumps((snow,soil,water,d)));row.update(status='returned-original-budgets',surface_temperature=d['surface_temperature'],snow_layers=len(snow.mass),h=d['h'],le=d['le'],water_residual_kgm2=d['water_residual_kgm2'],heat_residual_jm2=d['energy_residual_jm2'],water_original_numerical_bound_kgm2=mb,heat_original_numerical_bound_jm2=hb,surface_evaluations=d['surface_evaluations'],output_sha256=sha(p))
    except BaseException as e:row.update(status='failed',failure=type(e).__name__+': '+str(e));(out/(label+'-traceback.txt')).write_text(traceback.format_exc())
    finally:phase.solve_canopy_phase_energy=baseline_phase
    row['seconds']=time.monotonic()-begun;rows.append(row);print(json.dumps(row),flush=True)
assert all(sha(source/n)==v for n,v in m.items());value=dict(scope='Independent NumPy diagnostic candidates only: phase-side endpoint, actual post-routing thermal surface, and smaller finite-difference Jacobian. Original physical functions/routing/iteration/convergence/budget limits retained except explicitly named candidate algorithm; no production/frozen source edits or annual state advanced. Candidates are not adopted or scientific acceptance.',case=name,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,rows=rows);(out/'candidates.json').write_text(json.dumps(value,indent=2)+'\n')

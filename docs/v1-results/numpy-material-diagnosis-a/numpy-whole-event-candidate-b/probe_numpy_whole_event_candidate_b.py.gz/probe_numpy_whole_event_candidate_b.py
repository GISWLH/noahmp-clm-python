from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time,traceback,types
import numpy as np
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-whole-event-candidate-b';name=sys.argv[1];out=root/name;out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
import run_fluxnet_column as driver
import noahmp_clm.clm_enthalpy_driver as model
import noahmp_clm.physics.canopy_phase_energy as phase
text=(source/'src/noahmp_clm/physics/canopy_column.py').read_text();needle='        actual=float(pack.temperature[0] if len(pack.mass) else ground.temperature[0])';assert text.count(needle)==1
replacement='''        # Independent diagnostic preview of the exact committed compaction,
        # meltwater drainage and soil admission; no state mutation here.
        end_pack=compact(pack,dt,ice_before=ice_before,remap=False) if len(pack.mass) else pack
        end_pack,end_flow=drain_liquid(end_pack,return_ledger=True)
        if infiltration_parameters is None:
            end_ground,_,_=infiltrate(ground,end_flow['drainage_kgm2'],end_flow['drainage_enthalpy_jm2'])
        else:
            from .vic import infiltrate_vic
            end_ground,_,_=infiltrate_vic(ground,end_flow['drainage_kgm2'],end_flow['drainage_enthalpy_jm2'],infiltration_parameters)
        actual=float(end_pack.temperature[0] if len(end_pack.mass) else end_ground.temperature[0])'''
surface_text=text
surface_text=surface_text.replace('    if abs(fc)>temperature_tolerance:', '    material_event_resolved=False;root_residual=fc\n    if abs(fc)>temperature_tolerance:')
surface_text=surface_text.replace('        for iteration in range(60):', '        left_value,left_details=evaluate(left);right_value,right_details=evaluate(right)\n        for iteration in range(60):')
surface_text=surface_text.replace('            trial=(left*fr-right*fl)/(fr-fl) if fr!=fl else .5*(left+right)', '            trial=left+.5*(right-left)')
surface_text=surface_text.replace('            value,details=evaluate(trial)', '            value,details=evaluate(trial);root_residual=value')
surface_text=surface_text.replace('            if value>0.: left,fl=trial,value\n            else: right,fr=trial,value', """            if value>0.: left,fl,left_details=trial,value,details
            else: right,fr,right_details=trial,value,details
            # Distinguish a resolved vanishing-snow material event from a
            # residual-converged root. Match native representational bracket
            # handling without accepting any invalid component or budget.
            if right-left<=2.*np.finfo(float).eps*273.15 and fl>=0. and fr<=0.:
                if len(left_details['snow'].mass)!=len(right_details['snow'].mass):
                    root_residual,details=(fl,left_details) if abs(fl)<=abs(fr) else (fr,right_details)
                    material_event_resolved=True;break""")
surface_text=surface_text.replace('        if abs(residual)<=temperature_tolerance:details=plateau','        if abs(residual)<=temperature_tolerance:details=plateau;root_residual=residual')
surface_text=surface_text.replace('        surface_branch_evaluations=branch_evaluations,','        surface_branch_evaluations=branch_evaluations,surface_vapor_event=material_event_resolved,surface_root_residual_k=float(root_residual),')
phase_text=(source/'src/noahmp_clm/physics/canopy_phase_energy.py').read_text();needle='step=1e-4 if k<n+1 else 1e-5';assert phase_text.count(needle)==2;phase_text=phase_text.replace(needle,'step=1e-6 if k<n+1 else 1e-7')
def module(code,label):
    p=out/(label+'.py');p.write_text(code);v=types.ModuleType('noahmp_clm.physics._diagnostic_'+label);v.__package__='noahmp_clm.physics';exec(compile(code,str(p),'exec'),v.__dict__);return v
candidate=module(surface_text,'event-bracket');p_candidate=module(phase_text,'phase-small-jacobian');terminal=base/'fluxnet-numpy-current-first-year-a';r=json.loads((terminal/'exit.json').read_text());row=[r for r in r['cases'] if r['case']==name][0];archive=terminal/row['terminal_archive'];assert sha(archive)==row['terminal_archive_sha256']
with tarfile.open(archive) as t:
    report=json.load(t.extractfile('report.json'));raw=t.extractfile(report['checkpoint_file']).read();assert hashlib.sha256(raw).hexdigest()==report['checkpoint_sha256'];state,initial,net,bounds,maximum,stepmax,index=pickle.loads(raw)
c=report['configuration'];folder=base/'fluxnet-first-climate-cycle-20261017-h/inputs';path=folder/(c['site']+'.npz');meta=json.loads((folder/(c['site']+'.json')).read_text());assert sha(path)==report['forcing_npz_sha256']
with np.load(path,allow_pickle=False) as z:data=dict(z)
stamps=driver.validate_input(data,meta,path);f=driver.Forcing(*data['forcing'][index]);co2,mu,diffuse=data['environment'][index];dep=driver.DepositionSchedule(c);old_surface=model.surface_step;old_phase=phase.solve_canopy_phase_energy;failure=None;result=None;begun=time.monotonic()
try:
    model.surface_step=candidate.surface_step;phase.solve_canopy_phase_energy=p_candidate.solve_canopy_phase_energy
    after,d=driver.step_clm_enthalpy_column(state,f,co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),leaf_dimension=c['leaf_dimension_m'],leaf_parameters=driver.LeafParameters(**c['leaf_parameters']),most_geometry=driver.MOSTGeometry(**c['most_geometry']),phenology_environment=driver.calendar(stamps[index],meta,c['phenology'] is not None),deposition_rates=dep.aerosol(stamps[index],f.dt),nitrogen_deposition_gn_m2=dep.nitrogen_rate*f.dt)
    incoming,residual,bound=driver.audit_step(state,after,f,d,dep.nitrogen_rate*f.dt);cumulative=driver.totals(after)-initial-(net+incoming);assert np.all(np.abs(cumulative)<=bounds+bound);actual=float(after.snow.temperature[0] if len(after.snow.mass) else after.ground.temperature[0]);p=out/'whole-output.pkl';p.write_bytes(pickle.dumps((after,d)));result=dict(h=d['h'],le=d['le'],surface_temperature=d['surface_temperature'],actual_end_surface_temperature=actual,surface_endpoint_mismatch_k=actual-d['surface_temperature'],surface_vapor_event=d.get('surface_vapor_event'),surface_root_residual_k=d.get('surface_root_residual_k'),step_m_h_c_n=residual.tolist(),original_step_bounds=bound.tolist(),cumulative_m_h_c_n=cumulative.tolist(),original_cumulative_bounds=(bounds+bound).tolist(),output_sha256=sha(p))
except BaseException as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:model.surface_step=old_surface;phase.solve_canopy_phase_energy=old_phase
assert all(sha(source/n)==v for n,v in m.items());value=dict(scope='Unadopted counterfactual single whole-step diagnostic from original failed state. Explicit derived surface/phase function hashes identify changed runtime algorithms despite unchanged original source bytes. Bisection plus explicitly identified vanishing-snow signed-bracket event and smaller Jacobian only; physical equations/routing unchanged; original80/root/convergence/MHCN gates and cumulative baseline ledger retained. Original failed annual/state not advanced or relabeled.',case=name,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,index=index,timestamp=str(data['time_start'][index]),original_source_unchanged=True,candidate_algorithms_sha256={p.name:sha(p) for p in [out/'event-bracket.py',out/'phase-small-jacobian.py']},failure=failure,result=result,seconds=time.monotonic()-begun);(out/'whole.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

"""EHPC-only original-library boundary readback. Differences are evidence, not failures."""
from pathlib import Path
import json
import hashlib
import math
import os
import socket
import subprocess
import sys

assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
from noahmp_clm.physics.snowpack import LF,CW,TF
import saturated_drainage_pb as pb


def save(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')


def real_state(theta,temperature,satdk=1.e-5):
    p=SoilParams(satdk=satdk);dz=np.full(4,.5);w=np.array(theta)*1000.*dz
    return SoilEnthalpyState(w,enthalpy_and_capacity(w,np.array(temperature),dz,p)[0],dz,p)


def records(raw):
    result=[]; rediag=None
    for line in raw.decode().splitlines():
        if not line.startswith('PB_OFFICIAL_'):continue
        words=line.split();key=words[0].removeprefix('PB_OFFICIAL_')
        if key=='STEP':
            result.append(dict(step=int(words[1]),clock_step=int(words[2])))
        elif key=='FINAL_REDIAG':rediag=[float(v) for v in words[1:]]
        else:
            assert result and key not in result[-1]
            result[-1][key]=[float(v) for v in words[1:]]
    assert rediag is not None
    return result,rediag


root,exe=Path(sys.argv[1]),Path(sys.argv[2]);root.mkdir(exist_ok=False)
prior_path=Path(__file__).resolve().parent/'reference-pb-d-comparisons.json'
binding=json.loads((prior_path.parent/'REFERENCE_BINDINGS.json').read_text())
assert hashlib.sha256(prior_path.read_bytes()).hexdigest()==binding['original_member_sha256']
prior=json.loads(prior_path.read_bytes())
profiles=[]
for nsteps in (384,960):
    original=next(r['spec'] for r in prior['profiles'] if r['name']=='perched_cross_donors_exhausted')
    assert 86400 % nsteps == 0
    profiles.append(dict(original,name='perched_cross_donors_'+str(nsteps),dt=86400//nsteps,nsteps=nsteps))
rows=[]
for spec in profiles:
    here=root/spec['name'];here.mkdir()
    if 'theta' in spec:
        state=real_state(spec['theta'],spec['temperature'],spec['satdk'])
        liquid,ice,temperature=state.liquid,state.ice,state.temperature
    else:
        liquid,ice,temperature=[np.array(spec[k],float) for k in ('liquid','ice','temperature')]
    dt=spec['dt'];slope=.2
    lines=[f"{dt} {math.degrees(slope):.17g} {spec['baseflow']:.17g} {spec['nsteps']}"]
    for j in range(4):
        lines.append(' '.join(format(float(v),'.17g') for v in
            (.5,.45,5.5,355.,spec['satdk']*1000.,liquid[j],ice[j],temperature[j])))
    fixture=here/'fixture.txt';fixture.write_text('\n'.join(lines)+'\n')
    save(here/'profile.json',spec)
    result=subprocess.run([str(exe),str(fixture)],cwd=here,capture_output=True,timeout=30)
    (here/'official.stdout.txt').write_bytes(result.stdout);(here/'official.stderr.txt').write_bytes(result.stderr)
    save(here/'official-exit.json',dict(actual_parent_returncode=result.returncode))
    assert result.returncode==0,result.stderr.decode(errors='replace')
    steps,rediag=records(result.stdout)
    assert len(steps)==spec['nsteps']
    np.testing.assert_array_equal(steps[0]['INITIAL_LIQ'],liquid)
    np.testing.assert_array_equal(steps[0]['INITIAL_ICE'],ice)
    independent=[]
    for i,one in enumerate(steps):
        assert one['step']==i+1
        assert all(math.isfinite(x) for k,v in one.items() if isinstance(v,list) for x in v)
        np.testing.assert_array_equal(one['TEMPERATURE'],temperature)
        if i:
            assert one['clock_step']==steps[i-1]['clock_step']+1
            for initial,final in [('INITIAL_LIQ','FINAL_LIQ'),('INITIAL_ICE','FINAL_ICE')]:
                np.testing.assert_array_equal(one[initial],steps[i-1][final])
            np.testing.assert_array_equal(one['INITIAL_OTHER'],steps[i-1]['OTHER'][:3])
        # q_drain already includes q_rsub_sat: never count it twice.
        # qcharge is printed as an internal diagnostic, not an external flux.
        initial=[*one['INITIAL_LIQ'],*one['INITIAL_ICE'],*one['INITIAL_OTHER'][:2]]
        final=[*one['FINAL_LIQ'],*one['FINAL_ICE'],*one['OTHER'][:2]]
        outlet=dt*(one['PERCHED'][0]+one['MAIN'][0]+one['OTHER'][4]+one['OTHER'][5])
        residual=math.fsum([*final,*(-v for v in initial),outlet])
        bound=128.*np.finfo(float).eps*max(math.fsum(abs(v) for v in initial+final)+abs(outlet),1.)
        assert abs(residual)<=bound,(spec['name'],residual,bound)
        perch=np.array(one['INITIAL_LIQ'])-one['AFTER_PERCH_LIQ']
        main_change=np.array(one['AFTER_PERCH_LIQ'])-one['FINAL_LIQ']
        correction_active=(one['INITIAL_OTHER']!=one['OTHER'][:3] or any(x!=0. for x in one['OTHER'][3:])
            or one['INITIAL_ICE']!=one['FINAL_ICE'])
        independent.append(dict(step=i+1,water_residual_kg_m2=residual,water_bound_kg_m2=bound,
            reported_perched_outlet_kg_m2=dt*one['PERCHED'][0],reported_drain_kg_m2=dt*one['MAIN'][0],
            rsub_sat_included_in_drain_kg_m2=dt*one['OTHER'][3],ice_outlet_kg_m2=dt*one['OTHER'][4],
            qrgwl_outlet_kg_m2=dt*one['OTHER'][5],surface_stock_change_kg_m2=one['OTHER'][0]-one['INITIAL_OTHER'][0],
            WA_stock_change_kg_m2=one['OTHER'][1]-one['INITIAL_OTHER'][1],qcharge_before_after=[one['INITIAL_OTHER'][2],one['OTHER'][2]],
            actual_perched_layer_export_kg_m2=perch.tolist(),
            independent_perched_donor_heat_j_m2=(perch*(LF+CW*(temperature-TF))).tolist(),
            post_perch_to_final_net_liquid_change_kg_m2=main_change.tolist(),
            main_change_not_asserted_export_when_corrected=bool(correction_active),correction_channels_active=bool(correction_active),
            negative_drain_is_correction_compensation_not_aquifer_supply=bool(one['MAIN'][0]<0.)))
    row=dict(name=spec['name'],spec=spec,official_parent_returncode=0,steps=steps,independent_water_ledger=independent,
        total_reported_perched_kg_m2=math.fsum(x['reported_perched_outlet_kg_m2'] for x in independent),
        total_reported_drain_kg_m2=math.fsum(x['reported_drain_kg_m2'] for x in independent),
        final_liquid_kg_m2=steps[-1]['FINAL_LIQ'],final_ice_kg_m2=steps[-1]['FINAL_ICE'],
        final_reported_migrating_main_front_m=steps[-1]['MAIN'][1],final_reported_migrating_perched_front_m=steps[-1]['PERCHED'][1],
        final_rediagnosed_theta_main_perched_frost_m=rediag,
        heat_scope='Only actual pre/post-perch donor mass times fixed supplied donor T; original hydrology has no energy equation. Corrected main layer changes are not labelled donor heat.')
    save(here/'readout.json',row);rows.append(row)

# The actual evolving PB-c result from 1616 is reused, not rerun or retuned.
from dataclasses import replace
history_path=Path(__file__).resolve().parent/'reference-pb-e-comparisons.json'
assert hashlib.sha256(history_path.read_bytes()).hexdigest()==binding['pb_e_comparisons_sha256']
history=json.loads(history_path.read_bytes())
original=next(r for r in prior['profiles'] if r['name']=='perched_cross_donors_exhausted')
spec=original['spec'];initial=real_state(spec['theta'],spec['temperature'],spec['satdk'])
np.testing.assert_array_equal(initial.liquid,original['steps'][0]['INITIAL_LIQ'])
np.testing.assert_array_equal(initial.ice,original['steps'][0]['INITIAL_ICE'])
np.testing.assert_array_equal(initial.temperature,original['steps'][0]['TEMPERATURE'])
parameters=pb.DrainageParameters(2.,.2,baseflow_mm_s_per_m=0.)
diag=pb.diagnose_water_tables(initial,parameters);front=diag['perched_water_table_m'];bottom=diag['frost_table_m']
assert diag['water_table_m']==2.
source_path=Path(pb.__file__);source_before=hashlib.sha256(source_path.read_bytes()).hexdigest()
old_rate=pb.potential_outflow
calls=[]
def immutable_ice_rate(current,z,b,kind,params):
    # The only changed input of the original rate routine is its coefficient
    # source state. The live stocks, donor availability, heat and phase inversion
    # are untouched. No isothermal forcing or compensating heat is imposed.
    assert kind=='perched' and params==parameters
    live_main=pb.diagnose_water_tables(current,params)['water_table_m']
    assert live_main==diag['water_table_m']
    q,geometry=old_rate(initial,z,b,kind,params)
    calls.append(dict(front_m=z,rate_kg_m2_s=q,main_for_Sy_m=live_main,
        minimum_live_liquid_kg_m2=float(np.min(current.liquid)),ice_factor=geometry['ice_factor']))
    return q,geometry

def plain(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,(np.integer,np.floating,np.bool_)):return v.item()
    if isinstance(v,dict):return {k:plain(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [plain(x) for x in v]
    return v

diagnostics=[]
for label,control in [('default',pb.IntegrationControls()),('refined',replace(pb.IntegrationControls(),
        maximum_step_seconds=900.,relative_tendency_tolerance=.00025,maximum_temperature_change_k=.025))]:
    calls.clear();pb.potential_outflow=immutable_ice_rate
    try:after,z,ledger=pb.advance_saturated_band(initial,86400.,front,bottom,'perched',parameters,control)
    finally:pb.potential_outflow=old_rate
    assert abs(ledger['water_residual_kg_m2'])<=ledger['water_bound_kg_m2']
    assert abs(ledger['energy_residual_j_m2'])<=ledger['energy_bound_j_m2']
    assert hashlib.sha256(source_path.read_bytes()).hexdigest()==source_before==binding['unchanged_pb_c_sha256']
    comparisons=[]
    for row in rows:
        mass=np.array(row['steps'][0]['INITIAL_LIQ'])-np.array(row['final_liquid_kg_m2'])
        error=ledger['layer_mass_kg_m2']-mass
        comparisons.append(dict(official_steps=row['spec']['nsteps'],official_dt_seconds=row['spec']['dt'],
            original_official_mass=mass.tolist(),diagnostic_actual_mass=ledger['layer_mass_kg_m2'].tolist(),
            difference_kg_m2=error.tolist(),relative_difference=[None if abs(v)<.01 else float(e/v) for e,v in zip(error,mass)],
            within_10pct_or_abs_001=[bool(abs(e)<=max(.001,.1*abs(v))) for e,v in zip(error,mass)],
            official_front=row['final_reported_migrating_perched_front_m'],diagnostic_front=z,
            official_total=row['total_reported_perched_kg_m2'],diagnostic_total=ledger['drained_kg_m2'],
            total_relative_difference=ledger['drained_kg_m2']/row['total_reported_perched_kg_m2']-1.))
    diagnostics.append(dict(label=label,controls=vars(control),coefficient_evaluations=calls.copy(),
        ledger=plain(ledger),final_water=after.water.tolist(),final_liquid=after.liquid.tolist(),
        final_ice=after.ice.tolist(),final_temperature=after.temperature.tolist(),comparisons=comparisons,
        Sy_diagnosis_remained_initial=True,
        actual_liquid_cap_inactive=ledger['unavailable_liquid_kg_m2']==0.,
        actual_geometric_cap_inactive=ledger['band_exhaustion_kg_m2']==0.,
        thermal_boundary_matched=False,external_heat_added_j_m2=0.,
        scope='Hydraulic coefficient isolation only; actual internal temperature/phase still evolve with conservative liquid enthalpy export.'))
result=dict(execution_succeeded=True,profiles=rows,immutable_coefficient_diagnostics=diagnostics,
    original_1616_dynamic_pb_result=history['pb_perched'],
    source_pb_c_sha256=source_before,original_1616_archive_sha256=binding['pb_e_archive_sha256'],
    official_processes=2,official_drainage_steps=1344,numpy_component_integrations=2,
    coupled_column_runs=0,GPU_tasks=0,physical_acceptance=False,
    scope='Extreme-Ks perched stress only. Original 384/960 true clock steps plus two immutable-initial-ice coefficient diagnostics, with actual heat withdrawal/phase conserved; no same-thermal-boundary or complete perched acceptance claimed.')
save(root/'comparisons.json',result)
print(json.dumps(dict(execution_succeeded=True,profiles=2,official_drainage_steps=1344,numpy_component_integrations=2)))

"""Metadata/raw-output readback only, manager; no NumPy/model import."""
from pathlib import Path
import json
import socket
import tarfile

assert socket.gethostname()=='manager'
root=Path('/tmp/noahmp-clm-drainage-hydraulic-pb-h')
with tarfile.open(root/'result.tar.gz') as t:
    result=json.loads(t.extractfile('comparison/comparisons.json').read())
    receipt=json.loads(t.extractfile('receipt.json').read())
dynamic=result['original_1616_dynamic_pb_result']['adaptive_ledger']
comparisons=[]
for row in result['profiles']:
    original=[a-b for a,b in zip(row['steps'][0]['INITIAL_LIQ'],row['final_liquid_kg_m2'])]
    difference=[a-b for a,b in zip(dynamic['layer_mass_kg_m2'],original)]
    comparisons.append(dict(official_steps=row['spec']['nsteps'],original_official_layer=original,
        original_1616_dynamic_layer=dynamic['layer_mass_kg_m2'],difference_kg_m2=difference,
        relative_difference=[None if abs(b)<.01 else d/b for d,b in zip(difference,original)],
        original_official_total=row['total_reported_perched_kg_m2'],
        original_1616_dynamic_total=dynamic['drained_kg_m2'],
        total_relative_difference=dynamic['drained_kg_m2']/row['total_reported_perched_kg_m2']-1.,
        official_max_abs_water_residual=max(abs(a['water_residual_kg_m2']) for a in row['independent_water_ledger']),
        official_max_water_bound=max(a['water_bound_kg_m2'] for a in row['independent_water_ledger']),
        official_correction_channel_nonzero_steps=sum(a['correction_channels_active'] for a in row['independent_water_ledger'])))
diagnostics=[{k:v for k,v in d.items() if k!='coefficient_evaluations'} for d in result['immutable_coefficient_diagnostics']]
out=dict(receipt=receipt,actual_new_official_profiles=2,actual_new_official_steps=1344,
    historical_192_and_dynamic_Numpy_are_reused_not_new_calls=True,
    dispatch_scope_six_profile_text_is_stale_template_not_actual_count=True,
    dynamic_1616_vs_new_official=comparisons,immutable_coefficient_diagnostics=diagnostics,
    source_file_unchanged=result['source_pb_c_sha256'],physical_acceptance=False,
    scope='Hydraulic coefficient isolation and finer original discrete reference; complete thermal boundary remains unmatched, no parameter fit or production change.')
(root/'hydraulic-readout.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

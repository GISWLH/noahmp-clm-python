"""Flat actual-F closure of seven new original-library boundary profiles."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname()=='manager'
ROOT=Path('/tmp/noahmp-clm-drainage-hydraulic-pb-h');JOB='1631.manager'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
qstat=subprocess.check_output(['qstat','-xf',JOB]);state=qstat.decode()
assert re.search(r'^\s*job_state = F\s*$',state,re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$',state,re.M)
code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',state,re.M).group(1))
for name in ('result.tar.gz','pbs-exit.txt','controller.log'):
    remote=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
    if not (ROOT/name).exists():subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
    assert sha((ROOT/name).read_bytes())==remote
assert int((ROOT/'pbs-exit.txt').read_text())==code
with tarfile.open(ROOT/'result.tar.gz') as tar:
    members={m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
receipt=json.loads(members['receipt.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002' and receipt['passed']==(code==0)
assert receipt['coupled_column_runs']==receipt['GPU_tasks']==0
assert not receipt['official_implementation_changed'] and not receipt['official_stubs']
if code==0:
    assert receipt['profiles']==2 and receipt['official_drainage_steps']==1344 and receipt['numpy_component_integrations']==2
    assert all(s['actual_parent_returncode']==0 for s in receipt['stages'])
    assert receipt['original_official_objects_unchanged'] and receipt['source_and_controls_unchanged']
    output=json.loads(members['comparison/comparisons.json'])
    assert output['execution_succeeded'] and len(output['profiles'])==2
    assert all(row['official_parent_returncode']==0 for row in output['profiles'])
    assert sum(len(row['steps']) for row in output['profiles'])==1344
    assert all(abs(a['water_residual_kg_m2'])<=a['water_bound_kg_m2'] for row in output['profiles'] for a in row['independent_water_ledger'])
controls=json.loads(members['controls/CONTROLS_SHA256.json'])
assert all(sha(members['controls/'+n])==h for n,h in controls.items())
data={n:v for n,v in members.items() if n!='drainage_caller'}
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt',
             'compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt','controller.log'):
    data['scheduler/'+name]=(ROOT/name).read_bytes()
data['scheduler/actual-qstat.txt']=qstat
data['hydraulic-readout.json']=(ROOT/'hydraulic-readout.json').read_bytes()
data['read_drainage_pbh.py']=Path('/tmp/read_drainage_pbh.py').read_bytes()
data['CLM_DRAINAGE_HYDRAULIC_PB_H.md']=(ROOT/'CLM_DRAINAGE_HYDRAULIC_PB_H.md').read_bytes()
data['complete-result-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v),included=n!='drainage_caller') for n,v in members.items()},indent=2)+'\n').encode()
data['closed-run.json']=(json.dumps(dict(pbs_job=JOB,actual_state='F',actual_exit=code,Stageout_status=0,
    original_result_archive=str(ROOT/'result.tar.gz'),original_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),
    original_result_members=len(members),omitted_executable_sha256=sha(members['drainage_caller']),
    source_and_original_build_archives_separately_bound_in_receipt=True),indent=2)+'\n').encode()
data['archive_drainage_hydraulic_pbh.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
target=ROOT/'clm-drainage-hydraulic-pb-h-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tar:
    for n,v in sorted(data.items()):
        item=tarfile.TarInfo(n);item.size=len(v);tar.addfile(item,io.BytesIO(v))
with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_state='F',actual_exit=code,Stageout_status=0,profiles=2,official_drainage_steps=1344,
    numpy_component_integrations=2,coupled_column_runs=0,GPU_runs=0,physical_acceptance=False,
    scope='Two new unchanged-library original perched 384/960 clock profiles (1344 steps), default/refined immutable-initial-ice rate-coefficient diagnostics with actual enthalpy/phase conserved. Original1616 dynamic result reused. All channels and hard ledgers preserved. Hydraulic isolation is not a same-thermal-boundary/full-perched result; no source, donor, parameter, production or annual change. The old dispatch six-profile wording is retained as stale template; actual counts are2/1344.')
(ROOT/'clm-drainage-hydraulic-pb-h-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

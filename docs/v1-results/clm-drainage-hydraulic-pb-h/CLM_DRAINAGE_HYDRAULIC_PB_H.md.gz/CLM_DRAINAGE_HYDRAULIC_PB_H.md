# PB-h actual hydraulic coefficient isolation

EHPC 1631.manager is actual F0 / Stageout0. The unchanged original public caller
ran two new profiles with 384 and 960 real clock steps (225 and 90 s; 1,344 new
official steps). The compare stage took 26.845737 s and worker 55.818427 s. The
original 192-step reference and dynamic PB-c result are reused from sealed 1616,
not counted as new calls. The dispatch scope retained an old “six-profile” label;
actual inputs, worker receipt and all raw records unambiguously contain two.

This is the same deliberately extreme Ksat=10 m/s perched stress, not a usual
soil benchmark. Two diagnostic PB-c integrations keep only the rate routine's
ice coefficient source at its immutable initial state. Migrating geometry,
donor availability, actual liquid enthalpy withdrawal and phase inversion remain
live. Every coefficient evaluation confirms the main theta depth used for Sy
stays 2 m. Both runs have zero unavailable-liquid and geometric-cap amounts.
No physical source file, donor rule or parameter is changed and no external heat
is added. The energy boundary remains different from the official water-only
substeps, which retain the supplied temperature and ice.

| Comparison with new 960-step official run | Layer 2 export kg/m² | Layer 3 export kg/m² | Total kg/m² |
|---|---:|---:|---:|
| Original official | 8.550544684 | 11.933940379 | 20.484485063 |
| Fixed initial ice coefficient, default controls | 8.249848429 | 11.983064192 | 20.232912621 |
| Difference | −3.516691% | +0.411631% | −1.228112% |
| Fixed coefficient, tighter controls | 8.204953653 | 11.985378423 | 20.190332076 |
| Difference | −4.041743% | +0.431023% | −1.435979% |
| Original 1616 dynamic-ice PB-c, reused | 8.249848429 | 13.385717194 | 21.635565622 |
| Difference | −3.516691% | **+12.165109%** | +5.619280% |

The new 384-step official exports are 8.350617614 and 11.965419471 kg/m²,
total 20.316037085 kg/m². The two fixed-coefficient diagnostic runs meet the
original 10% / .001 kg/m² per-layer criterion against both new references. The
official 384→960 totals are not monotonic, so these runs do not establish a
formal asymptotic order. The actual evolving PB-c third-layer difference remains
above 10%; the diagnostic result is not substituted for that physical result.

The default fixed-coefficient run has 98 accepted / 4 rejected substeps; tighter
controls have 370 / 4. Their final third-layer temperatures are 268.019883681 and
268.019615635 K, with ice 130.640742693 and 130.638983945 kg/m². Initial T/ice
were 270 K / 137.219455710 kg/m²; the reused dynamic run ended at 267.755206525 K
/ 129.770703014 kg/m². These are actual conserved enthalpy responses, not an
isothermal overwrite.

Maximum diagnostic |water residual| is 7.10543e-15 kg/m² against 2.01794e-11;
maximum |heat residual| is 4.65661e-9 J/m² against 6.07506e-6. Original official
960-step maximum |water residual| is 1.36557e-14 against 4.03588e-11 kg/m², and
no correction channel is active in either new official profile. All WA,
qcharge, surface stock, ice and other outlets are retained in the raw evidence.
Official hydrology supplies no heat truth; derived donor heat remains labelled.

This isolates ice-coefficient feedback as a material contributor in this stress
case and supports the hydraulic stencil/donor semantics under comparable
coefficients. It does not establish matched thermal boundaries or complete
perched acceptance. No GPU, coupled-column, annual run or calibration is involved.

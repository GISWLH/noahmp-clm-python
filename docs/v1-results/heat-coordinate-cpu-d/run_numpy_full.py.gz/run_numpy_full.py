from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json,time,os,hashlib
r=Path.cwd();out=r/'numpy-full';out.mkdir(exist_ok=False);exe='/home/zhangyq/venvs/noahmp-closeout/bin/python'
files=[p for p in sorted((r/'tests').glob('test_*.py')) if not p.name.startswith(('test_gpu','test_cuda','test_jax'))]
(out/'selection.json').write_text(json.dumps(dict(scope='CPU NumPy portion only; native GPU/JAX/CUDA test files explicitly excluded, final full pytest still required',files=[p.name for p in files],source_manifest_sha256=hashlib.sha256((r/'SOURCE_SHA256.json').read_bytes()).hexdigest()),indent=2)+'\n')
started=time.monotonic();results=[]
def run(p):
 t=time.monotonic()
 with (out/(p.stem+'.log')).open('w') as log:result=subprocess.run([exe,'-m','pytest',str(p),'-q','-s','--junitxml='+str(out/(p.stem+'.xml'))],stdout=log,stderr=subprocess.STDOUT)
 return dict(file=p.name,returncode=result.returncode,seconds=time.monotonic()-t)
with ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(run,p) for p in files]
 for future in as_completed(futures):
  results.append(future.result());temporary=out/'progress.json.tmp';temporary.write_text(json.dumps(dict(files_completed=len(results),files_total=len(files),seconds=time.monotonic()-started,results=results),indent=2)+'\n');os.replace(temporary,out/'progress.json')
summary=dict(scope='CPU file-isolated NumPy suite; not final all-backend pytest',files_total=len(files),seconds=time.monotonic()-started,failures=[x for x in results if x['returncode']],results=results)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');raise SystemExit(1 if summary['failures'] else 0)

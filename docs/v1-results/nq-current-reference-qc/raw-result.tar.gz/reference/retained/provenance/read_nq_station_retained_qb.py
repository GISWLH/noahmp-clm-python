"""Read only the exact three retained pytest paths named in original logs."""
from pathlib import Path
import base64
import datetime
import hashlib
import json

roots=[Path('/tmp/pytest-of-lhwang/pytest-460/test_closed_native_station_com'+str(i)) for i in range(3)]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={};before={};found={}
for i,root in enumerate(roots):
    found[str(root)]=root.is_dir()
    if not root.is_dir():continue
    names=sorted(p for p in root.rglob('*') if p.is_file())
    for p in names:
        raw=p.read_bytes();key='case'+str(i)+'/'+str(p.relative_to(root))
        files[key]=base64.b64encode(raw).decode();before[key]=sha(raw)
after={}
for i,root in enumerate(roots):
    if not found[str(root)]:continue
    for p in sorted(root.rglob('*')):
        if p.is_file():after['case'+str(i)+'/'+str(p.relative_to(root))]=sha(p.read_bytes())
assert before==after
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Existing original failing station pytest files only; no new model or re-execution.',
    roots=found,sha256_before=before,sha256_after=after,files=files),indent=2))

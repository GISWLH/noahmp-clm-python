"""Read the terminal NQ receipt and three failing modules; no task control."""
from pathlib import Path
import base64
import datetime
import hashlib
import json

ROOT=Path('/home/lhwang/work/noahmp-v1/candidate-full-gpu-nq')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
plan=json.loads((ROOT/'plan.json').read_bytes())
source=Path(plan['source'])
raw_manifest=(source/'SOURCE_SHA256.json').read_bytes()
assert sha(raw_manifest)=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
manifest=json.loads(raw_manifest)
before={n:sha((source/n).read_bytes()) for n in manifest}
assert len(manifest)==584 and before==manifest
terminal=json.loads((ROOT/'exit.json').read_bytes())
assert len(terminal['records'])==72 and terminal['new_nodes_attempted']==376
failed=[row for row in terminal['records'] if not row['passed']]
assert {row['file'] for row in failed}=={'test_gpu_most_stagnation.py','test_gpu_clm_richards_column.py','test_gpu_fluxnet_richards_runner.py'}
names={'SOURCE_SHA256.json','plan.json','launch.json','candidate-full-gpu-nq-spec.json',
       'collection.json','collection-actual-exit.json','exit.json','progress.json','controller.log'}|set(plan['controls_sha256'])
optional={}
for row in failed:
    stem=Path(row['file']).stem
    names.update(stem+s for s in ('-exit.json','-receipt.json','-expected.json','.log','.xml'))
    assert sha((ROOT/(stem+'-receipt.json')).read_bytes())==row['receipt_sha256']
    for name in (str(row['pid'])+'-cache-events.jsonl',):
        optional[name]=(ROOT/name).is_file()
        if optional[name]:names.add(name)
    diagnostics=ROOT/(stem+'-diagnostics')
    if diagnostics.is_dir():
        names.update(str(p.relative_to(ROOT)) for p in diagnostics.rglob('*') if p.is_file())
files={n:(ROOT/n).read_bytes() for n in sorted(names)}
assert all(sha(files[n])==h for n,h in plan['controls_sha256'].items())
assert files['SOURCE_SHA256.json']==raw_manifest
assert {n:sha((ROOT/n).read_bytes()) for n in names}=={n:sha(raw) for n,raw in files.items()}
after={n:sha((source/n).read_bytes()) for n in manifest}
assert before==after
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    root=str(ROOT),source=str(source),source_sha256_before=before,source_sha256_after=after,
    all_selected_closed_files_unchanged=True,optional_presence=optional,
    detached_controller_os_exit=None,detached_controller_os_exit_note='No external parent wait receipt is provided.',
    files={n:base64.b64encode(raw).decode() for n,raw in files.items()}),indent=2))

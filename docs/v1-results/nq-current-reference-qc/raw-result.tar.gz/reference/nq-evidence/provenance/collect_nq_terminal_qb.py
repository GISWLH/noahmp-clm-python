"""Read remaining closed evidence once; no task/source mutations."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent;sha=lambda raw:hashlib.sha256(raw).hexdigest()
prior=json.loads((BASE/'candidate-progress-pz.json').read_bytes())
original=json.loads((BASE/'nq-failures-qb-raw.json').read_bytes())
request=dict(prior_closed_files=[r['file'] for r in prior['closed']],
    captured_sha256={n:sha(base64.b64decode(raw)) for n,raw in original['files'].items()},
    failure_capture_raw_sha256=sha((BASE/'nq-failures-qb-raw.json').read_bytes()),
    snapshot_sha256=sha((BASE/'candidate-progress-qb.json').read_bytes()))
script=(BASE/'read_nq_terminal_qb.py').read_bytes()+b'\nmain('+repr(request).encode()+b')\n'
target=BASE/'nq-terminal-qb-raw.json';assert not target.exists()
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B -']
result=subprocess.run(cmd,input=script,capture_output=True,timeout=180)
target.write_bytes(result.stdout);(BASE/'nq-terminal-qb.stderr').write_bytes(result.stderr)
(BASE/'nq-terminal-qb-exit.json').write_text(json.dumps(dict(actual_ssh_exit=result.returncode,
    executed_stdin_sha256=sha(script),stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr),
    completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd),indent=2)+'\n')
assert result.returncode==0,result.stderr.decode(errors='replace')
doc=json.loads(result.stdout)
print(json.dumps(dict(actual_ssh_exit=0,files=len(doc['files']),raw_bytes=len(result.stdout),utc=doc['utc'])))

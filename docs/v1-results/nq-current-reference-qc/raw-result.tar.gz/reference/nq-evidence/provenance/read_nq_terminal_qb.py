"""Read complete immutable NQ terminal metadata and only newly closed logs."""
from pathlib import Path
import base64
import datetime
import hashlib
import json

ROOT=Path('/home/lhwang/work/noahmp-v1/candidate-full-gpu-nq')
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main(request):
    plan=json.loads((ROOT/'plan.json').read_bytes());source=Path(plan['source'])
    manifest_raw=(source/'SOURCE_SHA256.json').read_bytes()
    assert sha(manifest_raw)=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    manifest=json.loads(manifest_raw)
    before={n:sha((source/n).read_bytes()) for n in manifest}
    assert len(manifest)==584 and before==manifest
    old=request['captured_sha256']
    assert all(sha((ROOT/n).read_bytes())==h for n,h in old.items())
    terminal_raw=(ROOT/'exit.json').read_bytes()
    assert sha(terminal_raw)==old['exit.json']
    terminal=json.loads(terminal_raw);spec=json.loads((ROOT/'candidate-full-gpu-nq-spec.json').read_bytes())
    records=terminal['records']
    assert len(records)==72 and [r['file'] for r in records]==spec['new_files_in_order']
    prior=request['prior_closed_files']
    assert len(prior)==25 and set(prior).issubset({r['file'] for r in records})
    names=set()
    for row in records:
        stem=Path(row['file']).stem
        names.update(stem+s for s in ('-exit.json','-receipt.json','-expected.json','.xml'))
        assert sha((ROOT/(stem+'-receipt.json')).read_bytes())==row['receipt_sha256']
        if row['file'] not in prior:
            names.add(stem+'.log')
            diagnostics=ROOT/(stem+'-diagnostics')
            if diagnostics.is_dir():
                names.update(str(p.relative_to(ROOT)) for p in diagnostics.rglob('*') if p.is_file())
            cache=str(row['pid'])+'-cache-events.jsonl'
            if (ROOT/cache).is_file():names.add(cache)
    # Existing complete-failure capture is byte-bound rather than transferred twice.
    names-=set(old)
    files={n:(ROOT/n).read_bytes() for n in sorted(names)}
    assert {n:sha((ROOT/n).read_bytes()) for n in names}=={n:sha(raw) for n,raw in files.items()}
    assert all(sha((ROOT/n).read_bytes())==h for n,h in old.items())
    after={n:sha((source/n).read_bytes()) for n in manifest};assert after==before
    print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_files=len(manifest),source_sha256_before=before,source_sha256_after=after,
        selected_closed_files_unchanged=True,terminal_sha256=sha(terminal_raw),request=request,
        repeated_existing_capture_files=0,files={n:base64.b64encode(raw).decode() for n,raw in files.items()}),indent=2))

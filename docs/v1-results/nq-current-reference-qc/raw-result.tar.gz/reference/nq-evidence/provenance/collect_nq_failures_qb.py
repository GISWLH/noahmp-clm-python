"""One bounded read-only SSH capture of terminal receipts; preserve actual exit."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
script=(BASE/'read_nq_failures_qb.py').read_bytes()
target=BASE/'nq-failures-qb-raw.json'
assert not target.exists()
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B -']
result=subprocess.run(cmd,input=script,capture_output=True,timeout=120)
target.write_bytes(result.stdout)
(BASE/'nq-failures-qb.stderr').write_bytes(result.stderr)
record=dict(actual_ssh_exit=result.returncode,executed_stdin_sha256=hashlib.sha256(script).hexdigest(),
    stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
    completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd)
(BASE/'nq-failures-qb-exit.json').write_text(json.dumps(record,indent=2)+'\n')
assert result.returncode==0,result.stderr.decode(errors='replace')
doc=json.loads(result.stdout)
print(json.dumps(dict(actual_ssh_exit=0,files=len(doc['files']),raw_bytes=len(result.stdout),
    source_unchanged=doc['source_sha256_before']==doc['source_sha256_after'],utc=doc['utc'])))

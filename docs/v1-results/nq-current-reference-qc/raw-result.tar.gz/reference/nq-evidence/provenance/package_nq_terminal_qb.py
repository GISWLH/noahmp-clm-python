"""Static complete NQ terminal audit and lossless incremental evidence package."""
from pathlib import Path, PurePosixPath
import base64
import ast
from collections import Counter
import gzip
import hashlib
import io
import json
import tarfile
import xml.etree.ElementTree as ET

BASE=Path(__file__).resolve().parent
LABEL='nq-terminal-qb'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()

def decoded(path):
    doc=json.loads(path.read_bytes())
    out={}
    for name,value in doc['files'].items():
        p=PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts
        out[name]=base64.b64decode(value)
    return doc,out

first,files=decoded(BASE/'nq-failures-qb-raw.json')
later,extra=decoded(BASE/'nq-terminal-qb-raw.json')
assert not set(files)&set(extra)
assert later['request']['captured_sha256']=={n:sha(raw) for n,raw in files.items()}
files.update(extra)
manifest=json.loads(files['SOURCE_SHA256.json'])
assert len(manifest)==584 and sha(files['SOURCE_SHA256.json'])=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert first['source_sha256_before']==first['source_sha256_after']==later['source_sha256_before']==later['source_sha256_after']==manifest
plan=json.loads(files['plan.json']);spec=json.loads(files['candidate-full-gpu-nq-spec.json'])
assert all(sha(files[n])==h for n,h in plan['controls_sha256'].items())
assert sha(files['candidate-full-gpu-nq-spec.json'])==plan['spec_sha256']
terminal=json.loads(files['exit.json']);records=terminal['records']
assert not terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
assert len(records)==72 and [r['file'] for r in records]==spec['new_files_in_order']
snapshot=json.loads((BASE/'candidate-progress-qb.json').read_bytes())
assert snapshot['closed']==records and snapshot['first']['processes']==snapshot['second']['processes']==[]
assert json.loads(files['collection-actual-exit.json'])['actual_parent_returncode']==0
assert json.loads(files['collection.json'])['passed']
totals=Counter();modules=[];failure_cases=[]
jax_only={'test_gpu_batch_shape','test_gpu_jax','test_gpu_numerical_components','test_gpu_pack','test_gpu_parity'}
source_archive=BASE/'climatology-final-candidate-nm-source.tar.gz'
assert sha(source_archive.read_bytes())=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(source_archive) as source_handle:
    for stem in jax_only:
        code=source_handle.extractfile('tests/'+stem+'.py').read()
        assert sha(code)==manifest['tests/'+stem+'.py']
        parsed=ast.parse(code)
        imports=[ast.unparse(n) for n in ast.walk(parsed) if isinstance(n,(ast.Import,ast.ImportFrom))]
        imported_strings=[arg.value for n in ast.walk(parsed) if isinstance(n,ast.Call)
            for arg in n.args[:1] if isinstance(arg,ast.Constant) and isinstance(arg.value,str)
            and isinstance(n.func,ast.Attribute) and n.func.attr in ('importorskip','import_module')]
        assert not any('cupy' in x or '.cuda' in x for x in imports+imported_strings)
for row in records:
    stem=Path(row['file']).stem
    receipt_raw=files[stem+'-receipt.json'];receipt=json.loads(receipt_raw)
    expected_raw=files[stem+'-expected.json'];expected=json.loads(expected_raw)
    assert json.loads(files[stem+'-exit.json'])==row
    assert sha(receipt_raw)==row['receipt_sha256']
    assert receipt['nodes']==expected and len(expected)==len(set(expected))==row['expected_tests']
    assert sha(expected_raw)==receipt['expected_nodes_sha256']
    assert receipt['test_sha256']==manifest['tests/'+row['file']]
    assert sha(files[stem+'.xml'])==receipt['xml_sha256']
    assert receipt['source_unchanged'] and receipt['source_files']==584 and not receipt['errors']
    assert receipt['source_manifest_sha256']==sha(files['SOURCE_SHA256.json'])
    assert receipt['node_coverage_exact']
    counts=receipt['counts'];assert counts['tests']==len(expected) and counts['errors']==counts['skipped']==0
    failed=counts['failures'];passed=counts['tests']-failed
    assert row['actual_parent_returncode']==receipt['worker_exitcode']==receipt['pytest_returncode']==(1 if failed else 0)
    assert row['passed']==receipt['passed']==receipt['all_setup_call_teardown_phases_passed']==(not failed)
    barriers={x['backend']:x['status'] for x in receipt['device_barriers']}
    assert barriers==({'jax':'complete'} if stem in jax_only else {'jax':'complete','cupy':'complete'})
    cases=list(ET.fromstring(files[stem+'.xml']).iter('testcase'))
    assert len(cases)==len(expected)
    assert Counter(c.attrib['name'] for c in cases)==Counter(n.split('::')[-1] for n in expected)
    actual_failures=[]
    for case in cases:
        assert not case.findall('error') and not case.findall('skipped')
        for failure in case.findall('failure'):
            actual_failures.append(dict(file=row['file'],name=case.attrib['name'],
                message=failure.attrib.get('message',''),original_traceback=failure.text or ''))
    assert len(actual_failures)==failed
    failure_cases.extend(actual_failures)
    totals.update(tests=counts['tests'],passed=passed,failed=failed,errors=0,skipped=0)
    modules.append(dict(file=row['file'],tests=counts['tests'],passed=passed,failed=failed,
        actual_parent_returncode=row['actual_parent_returncode'],seconds=row['seconds'],
        receipt_sha256=row['receipt_sha256'],device_barriers=barriers))
assert dict(totals)==dict(tests=376,passed=367,failed=9,errors=0,skipped=0)
assert len([r for r in records if r['passed']])==69
assert terminal['new_nodes_attempted']==376 and terminal['reused_nodes']==32 and terminal['total_gpu_nodes']==408
assert len(plan['reused'])==9 and sum(r['tests'] for r in plan['reused'])==32
assert terminal['reused']==plan['reused']
reused_scope='32 prior tests whose source/dependency and original receipts were checked by the unchanged NQ controller; this capture does not rerun them.'
summary=dict(passed=False,evidence_verified=True,sample_utc=snapshot['second']['utc'],
    source_files=584,source_unchanged=True,source_manifest_sha256=sha(files['SOURCE_SHA256.json']),
    new_modules=72,fully_successful_new_modules=69,failed_new_modules=3,new_tests=dict(totals),
    verified_reused_tests=32,reused_scope=reused_scope,total_tests=408,passed_tests=399,failed_tests=9,
    total_scientific_acceptance=False,detached_controller_os_exit=None,
    terminal_record=dict(passed=terminal['passed'],failure=terminal['failure'],seconds=terminal['seconds']),
    active_task_pids=[],physical_gpu_uuid='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',
    module_results=modules,failure_cases=failure_cases,
    original_years={k:dict(status=v['status'],steps=v['steps_completed'],eta=None) for k,v in snapshot['years'].items()},
    scope='Complete original new-test receipts/XML/actual parent returns and unchanged-source audit. Nine original test failures remain; no rerun or changed gates. Counts include 32 provenance-checked reused tests, not 408 newly executed tests. Scientific/annual acceptance is not achieved.')
assert all(v['status']=='failed' and v['steps']==7275 for v in summary['original_years'].values())
(BASE/(LABEL+'-readout.json')).write_bytes(encode(summary))
items={'nq/'+n:raw for n,raw in files.items()}
for name in ('candidate-progress-qb.json','candidate-progress-qb.stderr','candidate-progress-qb-exit.json',
    'candidate-progress-qb-sampler-hash.stdout','candidate-progress-qb-sampler-hash.stderr',
    'sample_candidate_progress_qb.py','review_candidate_concurrency_nt.py',
    'read_nq_failures_qb.py','collect_nq_failures_qb.py','nq-failures-qb-exit.json','nq-failures-qb.stderr',
    'read_nq_terminal_qb.py','collect_nq_terminal_qb.py','nq-terminal-qb-exit.json','nq-terminal-qb.stderr',
    'package_nq_terminal_qb-initial-checker.py','nq-terminal-qb-initial-check.json',Path(__file__).name):
    items['provenance/'+name]=(BASE/name).read_bytes()
items['readout.json']=encode(summary)
items['artifact-inventory.json']=encode({n:dict(bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(items.items())})
target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
        for name,raw in sorted(items.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644
            archive.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as archive:
    assert {m.name:archive.extractfile(m).read() for m in archive}==items
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,
    artifacts=len(items),scope=summary['scope'])
(BASE/(LABEL+'-package.json')).write_bytes(encode(package))
print(json.dumps(dict(package=package,new_tests=dict(totals),passed_including_reused=399,failed=9)))

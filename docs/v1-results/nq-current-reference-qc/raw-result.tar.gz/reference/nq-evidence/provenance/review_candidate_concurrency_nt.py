"""Read-only five-second resource sample for existing NQ/NS/NZ workers."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import time

BASE = Path('/home/lhwang/work/noahmp-v1')
load = lambda p: json.loads(Path(p).read_text())
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
nq = BASE / 'candidate-full-gpu-nq'
progress = load(nq / 'progress.json')
pids = {load(nq / 'launch.json')['pid'], progress['pid'], 3042732}
years = {}
for label, name in [('NS', 'climatology-cold48-np'), ('NZ', 'hrldas-candidate-cold48-ny')]:
    folder = BASE / name / 'cold48'
    pids.update([load(folder / 'year-launch.json')['pid'], load(folder / 'year-worker.json')['pid']])
    value = load(folder / 'trajectory/batch.json')
    years[label] = {k: value.get(k) for k in ['status', 'steps_completed', 'steps_requested', 'ledger_steps', 'ledger_segments', 'checkpoint_file']}
    years[label]['log_tail'] = (folder / 'year-model.log').read_text(errors='replace').splitlines()[-15:]
    years[label]['bgc_chunks'] = len(list((folder / 'year-bgc-diagnostics').glob('*.npz')))


def sample():
    values = {}
    for folder in Path('/proc').iterdir():
        if not folder.name.isdigit():
            continue
        try:
            if folder.stat().st_uid != os.getuid():
                continue
            parts = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
            values[int(folder.name)] = dict(pid=int(folder.name), ppid=int(parts[1]),
                state=parts[0], user_ticks=int(parts[11]), system_ticks=int(parts[12]),
                start_ticks=int(parts[19]), minor_faults=int(parts[7]), major_faults=int(parts[9]))
        except (FileNotFoundError, ProcessLookupError):
            pass
    wanted = set(pids)
    while True:
        expanded = wanted | {p for p, v in values.items() if v['ppid'] in wanted}
        if expanded == wanted:
            break
        wanted = expanded
    result = []
    allowed = {'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'XLA_FLAGS',
               'CUDA_VISIBLE_DEVICES', 'JAX_COMPILATION_CACHE_DIR', 'CUPY_CACHE_DIR'}
    for pid in sorted(wanted & set(values)):
        value, folder = values[pid], Path('/proc') / str(pid)
        try:
            value['cmdline'] = (folder / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace').strip()
            value['status'] = {line.split(':')[0]: line.split(':', 1)[1].strip()
                for line in (folder / 'status').read_text().splitlines()
                if line.split(':')[0] in {'VmRSS', 'VmHWM', 'VmSwap', 'Threads', 'Cpus_allowed_list', 'voluntary_ctxt_switches', 'nonvoluntary_ctxt_switches'}}
            value['environment'] = {}
            for item in (folder / 'environ').read_bytes().split(b'\0'):
                key, sep, data = item.partition(b'=')
                if sep and key.decode(errors='replace') in allowed:
                    value['environment'][key.decode()] = data.decode(errors='replace')
            value['wchan'] = (folder / 'wchan').read_text().strip()
            result.append(value)
        except (FileNotFoundError, ProcessLookupError):
            pass
    return dict(utc=utc(), monotonic=time.monotonic(), processes=result,
        meminfo={line.split(':')[0]: line.split(':', 1)[1].strip() for line in Path('/proc/meminfo').read_text().splitlines()
                 if line.split(':')[0] in {'MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'}},
        vmstat={line.split()[0]: int(line.split()[1]) for line in Path('/proc/vmstat').read_text().splitlines()
                if line.split()[0] in {'pswpin', 'pswpout', 'pgmajfault'}},
        loadavg=Path('/proc/loadavg').read_text().strip(),
        pressure={name: ((Path('/proc/pressure') / name).read_text() if (Path('/proc/pressure') / name).exists()
                         else '<unavailable: missing kernel PSI file>') for name in ['cpu', 'memory', 'io']})


first = sample()
gpu = []
for index in range(3):
    gpu.append(dict(utc=utc(), output=subprocess.check_output(['nvidia-smi', '--id=1',
        '--query-gpu=index,uuid,memory.used,memory.free,utilization.gpu,utilization.memory',
        '--format=csv'], text=True)))
    if index != 2:
        time.sleep(2.5)
second = sample()
apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,used_gpu_memory,process_name', '--format=csv'], text=True)
spec = load(nq / 'candidate-full-gpu-nq-spec.json')
closed = []
for name in spec['new_files_in_order']:
    path = nq / (Path(name).stem + '-exit.json')
    if path.exists():
        closed.append(load(path))
cache = []
for pid in pids:
    path = nq / (str(pid) + '-cache-events.jsonl')
    if path.exists():
        cache.extend(json.loads(line) for line in path.read_text().splitlines())
result = dict(scope='Five-second read-only sample; no task control, source/cache mutation, model import or new physical computation.',
    ticks_per_second=os.sysconf('SC_CLK_TCK'), logical_cpu_count=os.cpu_count(),
    first=first, second=second, gpu_samples=gpu, gpu_processes=apps,
    progress=progress, closed=closed, years=years, current_cache_events=cache,
    current_module_log_tail=(nq / (Path(progress['file']).stem + '.log')).read_text(errors='replace').splitlines()[-20:])
print(json.dumps(result, indent=2, allow_nan=False))

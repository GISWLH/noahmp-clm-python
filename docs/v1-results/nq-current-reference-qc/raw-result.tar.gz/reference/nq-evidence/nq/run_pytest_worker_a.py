"""One pytest session per isolated worker; preserve pytest/async results before _exit.

Only interpreter shutdown handlers are bypassed, after pytest.main returned,
all collected test setup/call/teardown reports exist, device barriers completed,
XML/manifest validation and a durable receipt. Failures remain nonzero.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,sys,time,xml.etree.ElementTree as ET
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ['source','test-file','expected','receipt','xml']:parser.add_argument('--'+key,type=Path,required=True)
    args=parser.parse_args();source=args.source.resolve();test=args.test_file.resolve();dest=args.receipt.resolve();xml=args.xml.resolve()
    assert not dest.exists() and not xml.exists() and test.is_file()
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text())
    verify=lambda:all(sha(source/n)==v for n,v in manifest.items())
    assert verify();expected=json.loads(args.expected.read_text());assert expected and len(set(expected))==len(expected) and all(n.startswith(test.name+'::') for n in expected)
    before_test_sha=sha(test);begun=time.monotonic();collected=[];reports=[]
    def normalize(node):
        prefix=node.split('::',1);return Path(prefix[0]).name+'::'+prefix[1]
    class Capture:
        def pytest_collection_finish(self,session):collected.extend(normalize(item.nodeid) for item in session.items)
        def pytest_runtest_logreport(self,report):reports.append(dict(node=normalize(report.nodeid),when=report.when,outcome=report.outcome))
    import pytest
    code=int(pytest.main([str(test),'-q','-s','--junitxml='+str(xml)],plugins=[Capture()]))
    after_pytest=time.monotonic();errors=[];barriers=[]
    # Do not import or initialize unused backends. Synchronization failures
    # are recorded as failures even if pytest itself returned0.
    for name in ['jax','cupy']:
        if name not in sys.modules:continue
        try:
            if name=='jax':sys.modules[name].effects_barrier()
            else:sys.modules[name].cuda.runtime.deviceSynchronize()
            barriers.append(dict(backend=name,status='complete'))
        except BaseException as e:
            barriers.append(dict(backend=name,status='failed',error=type(e).__name__+': '+str(e)));errors.append('Device synchronization failed: '+name)
    counts=dict(tests=0,failures=0,errors=0,skipped=0)
    try:
        for case in ET.parse(xml).getroot().iter('testcase'):
            counts['tests']+=1
            for key,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]:counts[key]+=int(case.find(tag) is not None)
    except BaseException as e:errors.append('XML validation: '+type(e).__name__)
    exact=set(collected)==set(expected) and len(collected)==len(expected)
    complete_phases=all(sum(v==dict(node=node,when=phase,outcome='passed') for v in reports)==1 for node in expected for phase in ['setup','call','teardown'])
    unchanged=verify() and sha(test)==before_test_sha
    passed=code==0 and exact and complete_phases and counts==dict(tests=len(expected),failures=0,errors=0,skipped=0) and unchanged and not errors
    exit_code=0 if passed else (code if code else 70)
    value=dict(scope='Exactly one original pytest.main session. Interpreter atexit shutdown bypassed only after complete fixture/test phases, explicit device synchronization, exact node/XML/source checks and durable receipt. This does not validate JAX interpreter shutdown behavior.',
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pytest_returncode=code,worker_exitcode=exit_code,passed=passed,counts=counts,nodes=collected,expected_nodes_sha256=sha(args.expected),node_coverage_exact=exact,all_setup_call_teardown_phases_passed=complete_phases,
        device_barriers=barriers,errors=errors,source_files=len(manifest),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),source_unchanged=unchanged,test_file=str(test),test_sha256=before_test_sha,xml_sha256=sha(xml) if xml.exists() else None,
        worker_sha256=sha(Path(__file__)),pytest_seconds=after_pytest-begun,seconds=time.monotonic()-begun,interpreter_atexit_handlers_bypassed=True)
    temp=dest.with_name(dest.name+'.tmp')
    with temp.open('w') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(temp,dest)
    print('ISOLATED_PYTEST_WORKER '+json.dumps({k:v for k,v in value.items() if k not in ['nodes']}),flush=True)
    sys.stdout.flush();sys.stderr.flush();return exit_code
if __name__=='__main__':
    exit_code=70
    try:exit_code=main()
    except BaseException as e:print('PYTEST_WORKER_WRAPPER_ERROR '+type(e).__name__+': '+str(e),file=sys.stderr,flush=True)
    finally:
        sys.stdout.flush();sys.stderr.flush()
    os._exit(exit_code)

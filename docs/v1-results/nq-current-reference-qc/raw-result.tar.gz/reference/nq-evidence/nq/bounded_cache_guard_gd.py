"""Process-local validation resource control; no physical input/output edits."""
from pathlib import Path
import datetime,functools,gc,json,os,resource,sys,time
ROOT=Path(__file__).resolve().parent
LIMIT=16*1024*1024
THRESHOLD=3*1024*1024
CALLS=0


def status():
    d={}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('VmRSS:','VmSwap:','VmHWM:')):d[line.split(':')[0]]=int(line.split()[1])
    d['measured_peak_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return d


def log(d):
    d.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid())
    with (ROOT/(str(os.getpid())+'-cache-events.jsonl')).open('a') as f:f.write(json.dumps(d)+'\n')


def ready(value):
    if isinstance(value,dict):
        for one in value.values():ready(one)
    elif isinstance(value,(tuple,list)):
        for one in value:ready(one)
    elif hasattr(value,'block_until_ready'):value.block_until_ready()


def wrap(function,label):
    @functools.wraps(function)
    def call(*args,**kwargs):
        global CALLS
        value=function(*args,**kwargs);ready(value)
        if 'cupy' in sys.modules:sys.modules['cupy'].cuda.runtime.deviceSynchronize()
        if 'jax' in sys.modules:sys.modules['jax'].effects_barrier()
        CALLS+=1;before=status();cleared=False;begun=time.monotonic()
        if before['VmRSS']>THRESHOLD:
            sys.modules['jax'].clear_caches();gc.collect();cleared=True
        after=status();log(dict(label=label,call=CALLS,before=before,after=after,cleared_process_local_jax_cache=cleared,cleanup_seconds=time.monotonic()-begun,scope='After completeoriginalmodelcall/devicebarriers, inputs/kwargs/returnedobject unchanged. No source/test/gate edits, no shared/disk cache clear or otherprocess change. Originalpytest unconfigure/GC still run.'))
        if after['measured_peak_kib']>LIMIT:
            import pytest
            pytest.exit('Validation worker exceeded16GiB measuredhostpeak; incomplete resource attempt, never a physics pass',returncode=85)
        return value
    return call


def pytest_configure(config):
    import jax
    assert callable(jax.clear_caches)
    import run_fluxnet_native as native
    native.Backend.step=wrap(native.Backend.step,'native.Backend.step')
    log(dict(event='configured',limits=dict(clear_above_rss_kib=THRESHOLD,abort_above_peak_kib=LIMIT),status=status()))


def pytest_collection_modifyitems(session,config,items):
    for module in {item.module for item in items}:
        name=Path(module.__file__).name
        if name=='test_gpu_clm_richards_column.py':module.advance=wrap(module.advance,name+'.advance')
        if name=='test_gpu_clm_capacity_column.py':module.run=wrap(module.run,name+'.run')


def pytest_sessionfinish(session,exitstatus):
    log(dict(event='sessionfinish',pytest_exitstatus=int(exitstatus),calls=CALLS,status=status()))

"""NQ full GPU validation on NM584; prepare-only until root supplies promotion proof.

Launch never waits for authorization/evidence. Missing closed MX/NF evidence or
old-JO replacement proof rejects launch before creating any queue directories.
"""
from pathlib import Path
import argparse
import datetime
import os
import runpy
import subprocess
import sys
import tarfile
import time
import traceback
from candidate_gpu_contract_nq import (
    ARCHIVE, BASE, GPU, GUARD, ROOT, SOURCE, TMP, WORKER,
    closed_reuse, promotion_check, read, receipt_check, sha, validate_spec, verify_source, write,
)


def environment(source):
    env = os.environ.copy()
    for key in ['LD_LIBRARY_PATH', 'PYTEST_PLUGINS']:
        env.pop(key, None)
    env.update(PYTHONPATH=':'.join(map(str, [ROOT, source, source / 'src', source / 'tests', source / 'benchmarks'])),
               PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU,
               CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda',
               JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false',
               JAX_COMPILATION_CACHE_DIR=str(TMP / 'jax-cache'), CUPY_CACHE_DIR=str(TMP / 'cupy-cache'),
               CUDA_CACHE_PATH=str(TMP / 'cuda-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NOAHMP_REQUIRE_GPU='1')
    return env


def resources(stage):
    while True:
        uuid, free = [v.strip() for v in subprocess.check_output(
            ['nvidia-smi', '--id=1', '--query-gpu=uuid,memory.free', '--format=csv,noheader,nounits'], text=True).strip().split(',')]
        assert uuid == GPU
        memory = int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
        value = dict(stage=stage, physical_gpu_uuid=uuid, gpu_free_mib=int(free), host_available_kib=memory,
                     utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if int(free) > 8192 and memory > 32 * 1024 * 1024:
            return value
        write(ROOT / 'waiting-resource.json', value)
        time.sleep(20.)


def launch(preflight):
    assert not ROOT.exists() and not TMP.exists(), 'One immutable experiment only'
    promotion_check(preflight)
    for name in ['surface-root-regression-mx', 'surface-root-permanent-nf']:
        terminal = read(BASE / name / 'exit.json')
        assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
    archive = BASE / 'climatology-final-candidate-nm-source.tar.gz'
    assert sha(archive) == ARCHIVE
    spec_path = BASE / 'candidate-full-gpu-nq-spec.json'
    spec = read(spec_path)
    validate_spec(spec)
    generic = BASE / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
    assert sha(generic) == WORKER and sha(BASE / 'bounded_cache_guard_gd.py') == GUARD
    ROOT.mkdir()
    TMP.mkdir()
    source = TMP / 'source'
    source.mkdir()
    with tarfile.open(archive) as tf:
        tf.extractall(source, filter='data')
    verify_source(source, SOURCE, 584)
    inheritance, reused = closed_reuse(source, spec)
    (ROOT / 'SOURCE_SHA256.json').write_bytes((source / 'SOURCE_SHA256.json').read_bytes())
    (ROOT / 'candidate-full-gpu-nq-spec.json').write_bytes(spec_path.read_bytes())
    proof_folder = ROOT / 'preflight'
    proof_folder.mkdir()
    for name in ['promotion.json', 'old-jo-snapshot.json', 'old-jo-stop.json']:
        (proof_folder / name).write_bytes((Path(preflight) / name).read_bytes())
    write(ROOT / 'inheritance-proof.json', inheritance)
    # Preserve full original records and identities, never relabel them as NM runs.
    for label, old in [('MX', BASE / 'surface-root-regression-mx'), ('NF', BASE / 'surface-root-permanent-nf')]:
        dest = ROOT / 'reused' / label
        dest.mkdir(parents=True)
        for name in ['plan.json', 'exit.json', 'launch.json']:
            (dest / name).write_bytes((old / name).read_bytes())
        old_source = Path(read(old / 'plan.json')['source'] if label == 'MX' else read(old / 'plan.json')['variants']['positive']['source'])
        (dest / 'ORIGINAL_SOURCE_SHA256.json').write_bytes((old_source / 'SOURCE_SHA256.json').read_bytes())
    for row in reused:
        dest = ROOT / 'reused' / ('MX' if row['stem'] else 'NF') / Path(row['file']).stem
        dest.mkdir()
        old = Path(row['original_root'])
        names = ([row['stem'] + suffix for suffix in ['-receipt.json', '-expected.json', '-exit.json', '.xml', '.log']]
                 if row['stem'] else ['receipt.json', 'expected.json', 'worker-actual-exit.json', 'audit.json', 'phases.json', 'junit.xml', 'worker.log'])
        for name in names:
            (dest / name).write_bytes((old / name).read_bytes())
    controls = [BASE / 'candidate_gpu_contract_nq.py', Path(__file__), generic, BASE / 'bounded_cache_guard_gd.py']
    for path in controls:
        assert b'\r\n' not in path.read_bytes()
        (ROOT / path.name).write_bytes(path.read_bytes())
    plan = dict(source=str(source), source_manifest_sha256=SOURCE, controls_sha256={p.name: sha(ROOT / p.name) for p in controls},
                spec_sha256=sha(spec_path), reused=reused, gpu_nodes=408, new_nodes=376,
                scope='NM584 GPU408 = closed ML MX31 + closed NF1 with verified offline-assessor-only inheritance '
                      '+ 376 freshly executed NM nodes. No old JN full-suite credit; all original gates retained.')
    write(ROOT / 'plan.json', plan)
    with (ROOT / 'controller.log').open('x') as log:
        child = subprocess.Popen([sys.executable, '-u', str(ROOT / Path(__file__).name), 'control'],
            cwd=source, env=environment(source), stdin=subprocess.DEVNULL, stdout=log,
            stderr=subprocess.STDOUT, start_new_session=True)
    value = dict(pid=child.pid, physical_gpu_index=1, physical_gpu_uuid=GPU,
                 utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **plan)
    write(ROOT / 'launch.json', value)
    print(__import__('json').dumps(value), flush=True)


def collect(plan, spec):
    source = Path(plan['source'])
    verify_source(source, SOURCE, 584)
    import pytest
    nodes = []
    class Capture:
        def pytest_collection_finish(self, session):
            nodes.extend(item.nodeid for item in session.items)
    code = int(pytest.main(['--collect-only', '-q', 'tests'], plugins=[Capture()]))
    barriers = []
    for name in ['jax', 'cupy']:
        if name in sys.modules:
            if name == 'jax':
                sys.modules[name].effects_barrier()
            else:
                sys.modules[name].cuda.runtime.deviceSynchronize()
            barriers.append(dict(backend=name, status='complete'))
    gpu = [n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu', 'test_cuda', 'test_jax'))]
    expected_gpu = {'tests/' + n for values in spec['gpu_nodes_by_file'].values() for n in values}
    non_nk = {n for n in nodes if n.split('::')[0] != 'tests/test_clm_spinup.py'}
    exact = set(gpu) == expected_gpu and non_nk == set(spec['original_non_nk_nodes'])
    verify_source(source, SOURCE, 584)
    passed = code == 0 and len(nodes) == len(set(nodes)) == 1576 and len(gpu) == 408 and exact
    write(ROOT / 'collection.json', dict(passed=passed, returncode=code, nodes=nodes, total_count=len(nodes),
          gpu_count=len(gpu), cpu_count=len(nodes)-len(gpu), exact_gpu_and_non_nk_node_sets=exact,
          source_manifest_sha256=SOURCE, source_unchanged=True, device_barriers=barriers,
          scope='Actual collection only. It is not full CPU or GPU numerical execution credit.'))
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0 if passed else 71)


def worker(plan, name):
    source = Path(plan['source'])
    verify_source(source, SOURCE, 584)
    assert sha(ROOT / 'run_pytest_worker_a.py') == WORKER and sha(ROOT / 'bounded_cache_guard_gd.py') == GUARD
    os.environ['PYTEST_PLUGINS'] = 'bounded_cache_guard_gd'
    stem = Path(name).stem
    sys.argv = ['run_pytest_worker_a.py', '--source', str(source), '--test-file', str(source / 'tests' / name),
                '--expected', str(ROOT / (stem + '-expected.json')), '--receipt', str(ROOT / (stem + '-receipt.json')),
                '--xml', str(ROOT / (stem + '.xml'))]
    runpy.run_path(str(ROOT / 'run_pytest_worker_a.py'), run_name='__main__')


def control(plan, spec):
    source = Path(plan['source'])
    records, failure = [], None
    started = time.monotonic()
    try:
        validate_spec(spec)
        assert all(sha(ROOT / n) == h for n, h in plan['controls_sha256'].items())
        assert sha(ROOT / 'candidate-full-gpu-nq-spec.json') == plan['spec_sha256']
        promotion_check(ROOT / 'preflight')
        resources('collect')
        with (ROOT / 'collection.log').open('x') as log:
            code = subprocess.run([sys.executable, '-u', str(ROOT / Path(__file__).name), 'collect'],
                                  cwd=source, stdout=log, stderr=subprocess.STDOUT).returncode
        write(ROOT / 'collection-actual-exit.json', dict(actual_parent_returncode=code))
        assert code == 0 and read(ROOT / 'collection.json')['passed']
        # Recheck original closed sources/evidence after collection, before any reuse.
        _, reused = closed_reuse(source, spec)
        assert reused == plan['reused']
        for name in spec['new_files_in_order']:
            availability = resources(name)
            verify_source(source, SOURCE, 584)
            stem = Path(name).stem
            nodes = spec['gpu_nodes_by_file'][name]
            write(ROOT / (stem + '-expected.json'), nodes)
            env = environment(source)
            diagnostics = ROOT / (stem + '-diagnostics')
            diagnostics.mkdir()
            for key in ['NOAHMP_CAPACITY_COLUMN_DIAGNOSTICS', 'NOAHMP_PFT_DIAGNOSTICS', 'NOAHMP_RICHARDS_COLUMN_DIAGNOSTICS',
                        'NOAHMP_RICHARDS_STATION_DIAGNOSTICS', 'NOAHMP_CAPACITY_STATION_DIAGNOSTICS',
                        'NOAHMP_PHASE_COORDINATE_DIAGNOSTICS', 'NOAHMP_THIN_EVENT_DIAGNOSTICS']:
                env[key] = str(diagnostics)
            begun = time.monotonic()
            with (ROOT / (stem + '.log')).open('x') as log:
                child = subprocess.Popen([sys.executable, '-u', str(ROOT / Path(__file__).name), 'worker', '--test-file', name],
                                         cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT)
            write(ROOT / 'progress.json', dict(file=name, pid=child.pid, records=records, reused=reused, resources=availability))
            code = child.wait()
            receipt_path = ROOT / (stem + '-receipt.json')
            row = dict(file=name, pid=child.pid, expected_tests=len(nodes), actual_parent_returncode=code,
                       seconds=time.monotonic()-begun, passed=False,
                       receipt_sha256=sha(receipt_path) if receipt_path.exists() else None)
            try:
                # Candidate row gets provisional success only for full evidence validation.
                receipt_check(ROOT, stem, dict(row, passed=(code == 0)), nodes, source, SOURCE)
                row['passed'] = True
            except Exception as error:
                row['verification_error'] = type(error).__name__ + ': ' + str(error)
            records.append(row)
            write(ROOT / (stem + '-exit.json'), row)
            print(__import__('json').dumps(row), flush=True)
            # Keep failures; independent complete files continue without retries or gate changes.
    except Exception as error:
        failure = type(error).__name__ + ': ' + str(error)
        (ROOT / 'traceback.txt').write_text(traceback.format_exc())
    unchanged = False
    try:
        verify_source(source, SOURCE, 584)
        unchanged = True
    except Exception:
        pass
    passed = (failure is None and unchanged and sum(v['expected_tests'] for v in records) == 376
              and all(v['passed'] for v in records))
    write(ROOT / 'exit.json', dict(passed=passed, failure=failure, records=records, reused=plan['reused'],
          new_nodes_attempted=sum(v['expected_tests'] for v in records), reused_nodes=32, total_gpu_nodes=408,
          seconds=time.monotonic()-started, source_manifest_sha256=SOURCE, source_unchanged=unchanged, scope=plan['scope']))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['launch', 'control', 'collect', 'worker'])
    parser.add_argument('--preflight', type=Path)
    parser.add_argument('--test-file')
    args = parser.parse_args()
    if args.mode == 'launch':
        assert args.preflight is not None
        launch(args.preflight)
    else:
        current_plan = read(ROOT / 'plan.json')
        current_spec = read(ROOT / 'candidate-full-gpu-nq-spec.json')
        if args.mode == 'control':
            control(current_plan, current_spec)
        elif args.mode == 'collect':
            collect(current_plan, current_spec)
        else:
            worker(current_plan, args.test_file)

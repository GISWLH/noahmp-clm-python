"""Prepared EHPC-only current-NM reference of immutable Richards test inputs."""
import argparse
from dataclasses import fields, is_dataclass
from enum import Enum
import hashlib
import io
import json
import os
from pathlib import Path
import pickle
import socket
import sys
import tarfile
import time
import traceback

HERE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(path,value):
    def scalar_or_array(obj):
        if hasattr(obj,'tolist'):return obj.tolist()
        raise TypeError('Non-JSON metadata '+str(type(obj)))
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False,default=scalar_or_array)+'\n')

def extract(path,target,expected):
    raw=Path(path).read_bytes();assert sha(raw)==expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as handle:
        members=handle.getmembers()
        assert len({m.name for m in members})==len(members)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        files={m.name:handle.extractfile(m).read() for m in members}
    for name,raw in files.items():
        p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    return files

def main():
    parser=argparse.ArgumentParser()
    for key in ('source','station','nq','output'):parser.add_argument('--'+key,type=Path,required=True)
    args=parser.parse_args()
    assert os.name!='nt' and socket.gethostname().split('.')[0]=='compute002' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=args.output.resolve();assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists();root.mkdir()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes())
    controls=json.loads((HERE/'CONTROLS_SHA256.json').read_bytes())
    assert all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
    source=root/'source';source_files=extract(args.source,source,binding['NM_source_archive_sha256'])
    manifest=json.loads(source_files['SOURCE_SHA256.json'])
    assert len(manifest)==584 and sha(source_files['SOURCE_SHA256.json'])==binding['NM_source_manifest_sha256']
    assert set(source_files)==set(manifest)|{'SOURCE_SHA256.json'}
    assert all(sha(source_files[n])==h for n,h in manifest.items())
    retained=root/'retained';station_files=extract(args.station,retained,binding['station_retained_archive_sha256'])
    archive_index=json.loads(station_files['artifact-inventory.json'])
    assert set(archive_index)==set(station_files)-{'artifact-inventory.json'}
    assert all(sha(station_files[n])==v['sha256'] and len(station_files[n])==v['bytes'] for n,v in archive_index.items())
    nqfiles=extract(args.nq,root/'nq-evidence',binding['NQ_terminal_archive_sha256'])
    nq_index=json.loads(nqfiles['artifact-inventory.json'])
    assert set(nq_index)==set(nqfiles)-{'artifact-inventory.json'}
    assert all(sha(nqfiles[n])==v['sha256'] and len(nqfiles[n])==v['bytes'] for n,v in nq_index.items())
    for name,expected in binding['unchanged_fixture_sha256'].items():assert sha((source/'tests/fixtures'/name).read_bytes())==expected
    sys.path[:0]=[str(source/'src'),str(source/'tests'),str(source/'benchmarks')]
    import numpy as np
    import richards_column_cases as cases
    import run_fluxnet_column as runner
    import run_fluxnet_native as native_io
    from noahmp_clm.column import Forcing
    from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
    from noahmp_clm.physics.canopy_most import MOSTGeometry
    from noahmp_clm.physics.richards import RichardsHydrology
    assert Path(step_clm_enthalpy_column.__code__.co_filename).resolve()==(source/'src/noahmp_clm/clm_enthalpy_driver.py').resolve()
    packet_counts={}
    def capture(path,value):
        # Pickle is the original complete return, written before inspection.
        path.parent.mkdir(parents=True,exist_ok=True);path.with_suffix('.pkl').write_bytes(pickle.dumps(value,protocol=5))
        arrays={}
        def walk(v,key):
            if isinstance(v,(np.ndarray,np.generic)):
                a=np.asarray(v);assert a.dtype.kind!='O';arrays[key]=a
                return dict(kind='array',key=key,dtype=a.dtype.str,shape=list(a.shape),c_order_sha256=sha(a.tobytes(order='C')))
            if is_dataclass(v):return dict(kind='dataclass',module=type(v).__module__,name=type(v).__name__,fields={f.name:walk(getattr(v,f.name),key+'/'+f.name) for f in fields(v)})
            if isinstance(v,dict):
                assert all(type(k) is str for k in v)
                return dict(kind='dict',items={k:walk(x,key+'/'+k) for k,x in v.items()})
            if isinstance(v,(list,tuple)):return dict(kind=type(v).__name__,items=[walk(x,key+'/'+str(i)) for i,x in enumerate(v)])
            if isinstance(v,Enum):return dict(kind='enum',module=type(v).__module__,name=type(v).__name__,value=walk(v.value,key+'/value'))
            if type(v) is float:return dict(kind='float',hex=v.hex())
            if v is None or type(v) in (str,int,bool):return dict(kind=type(v).__name__,value=v)
            raise TypeError('Unsupported original return '+str(type(v)))
        tree=walk(value,'return');np.savez_compressed(path.with_suffix('.npz'),**arrays)
        save(path.with_suffix('.json'),dict(schema='QC-lossless-return-v1',tree=tree,array_count=len(arrays),npz_sha256=sha(path.with_suffix('.npz').read_bytes()),pickle_sha256=sha(path.with_suffix('.pkl').read_bytes())))
        packet_counts[str(path.relative_to(root))]=len(arrays)
    def difference(actual,expected,relative,absolute,floor):
        a,b=np.broadcast_arrays(np.asarray(actual,float),np.asarray(expected,float));delta=abs(a-b)
        bound=np.where(abs(b)>floor,relative*abs(b),absolute)
        return dict(maximum_absolute=float(delta.max(initial=0.)),maximum_relative_nonzero=float(np.max(delta[abs(b)>floor]/abs(b[abs(b)>floor]),initial=0.)),passed=bool(np.all(np.isfinite(a)) and np.all(np.isfinite(b)) and np.all(delta<=bound)),relative=relative,absolute=absolute,zero_floor=floor)
    records=[];calls=dict(started=0,returned=0);started=time.monotonic()
    before_source={n:sha((source/n).read_bytes()) for n in manifest}
    save(root/'source-before.json',before_source)
    try:
        reference_path=source/'tests/fixtures/clm_richards_reference.npz'
        with np.load(reference_path,allow_pickle=False) as archive:old={k:archive[k] for k in archive.files}
        # Every saved non-expected array is immutable; no call to initial().
        inputs={k:v.copy() for k,v in old.items() if '/expected/' not in k}
        input_ids={k:dict(dtype=v.dtype.str,shape=list(v.shape),sha256=sha(v.tobytes(order='C'))) for k,v in inputs.items()}
        save(root/'column-input-identities-before.json',input_ids)
        output_arrays={}
        for precision in ('32','64'):
            for index,kind in enumerate(cases.KINDS):
                prefix=precision+'/'+str(index)+'/'
                c={k[len(prefix):]:v for k,v in inputs.items() if k.startswith(prefix)}
                arrays=tuple(c['initial/'+str(i)] for i in range(int(c['arrays'])))
                state=cases.decode(arrays,kind);geometry=c.get('geometry')
                kwargs=dict(zip(('co2_ppm','cosine_zenith','diffuse_fraction','leaf_dimension'),arrays[4][0,7:11].astype(float)))
                kwargs['soil_hydrology']=None if kind=='legacy' else RichardsHydrology()
                if geometry is not None:kwargs['most_geometry']=MOSTGeometry(*map(float,geometry[0]))
                if kind in ('bgc','structure'):kwargs['nitrogen_deposition_gn_m2']=float(c['nitrogen'][0])
                for step in range(2):
                    out=root/'columns'/precision/kind/('step'+str(step));before_state=state
                    forcing=Forcing(*c['forcing'][step,0].astype(float));options=dict(kwargs,deposition_rates=c['deposition'][step,0].astype(float))
                    capture(out.with_name(out.name+'-input'),dict(args=(state,forcing),kwargs=options))
                    calls['started']+=1;state,d=step_clm_enthalpy_column(state,forcing,**options);calls['returned']+=1
                    capture(out,(state,d))
                    assert abs(d['water_residual_kgm2'])<3e-10 and abs(d['energy_residual_jm2'])<.02
                    cn=None
                    if state.bgc_state is not None:
                        carbon=state.bgc_state.total_carbon-before_state.bgc_state.total_carbon+d['nee_gc_m2']
                        nitrogen=state.bgc_state.total_nitrogen-before_state.bgc_state.total_nitrogen-float(c['nitrogen'][0])
                        bg=d['biogeochemistry'];assert abs(carbon)<=bg['carbon_bound_gc_m2'] and abs(nitrogen)<=bg['nitrogen_bound_gn_m2']
                        cn=dict(carbon=carbon,nitrogen=nitrogen,carbon_bound=bg['carbon_bound_gc_m2'],nitrogen_bound=bg['nitrogen_bound_gn_m2'])
                    packed=cases.pack(state,kind,np.float64);tag=prefix+'expected/'+str(step)+'/'
                    values=dict(soil_cells=packed[1],options=packed[3],temperature_k=state.ground.temperature[None,:])
                    values.update({'diagnostics/'+k:np.asarray([d[k]]) for k in ('h','le','gpp_gcm2','et_mm','runoff_mm','swe','prcp_mm','precipitation_enthalpy_jm2')})
                    if 'nee_gc_m2' in d:values['diagnostics/nee_gc_m2']=np.asarray([d['nee_gc_m2']])
                    output_arrays.update({tag+k:v for k,v in values.items()})
                    old_differences={k:difference(v,old[tag+k],.1,(1. if k in ('diagnostics/h','diagnostics/le') else (1e-7 if k=='diagnostics/swe' else .0001)),(10. if k in ('diagnostics/h','diagnostics/le') else (1e-6 if k=='diagnostics/swe' else .001))) for k,v in values.items() if k in ('diagnostics/h','diagnostics/le','diagnostics/gpp_gcm2','diagnostics/et_mm','diagnostics/runoff_mm','diagnostics/swe')}
                    record=dict(precision=precision,kind=kind,step=step,water_residual=d['water_residual_kgm2'],heat_residual=d['energy_residual_jm2'],carbon_nitrogen=cn,versus_historical_reference=old_differences)
                    # Complete existing device arrays exist only for these cases.
                    packet='nq/test_gpu_clm_richards_column-diagnostics/'+kind+'-'+str(step)+'.npz'
                    if precision=='32' and packet in nqfiles:
                        with np.load(io.BytesIO(nqfiles[packet]),allow_pickle=False) as archive:device={k:archive[k] for k in archive.files}
                        paired={}
                        for key in device:
                            if not key.startswith('cuda/'):continue
                            a,b=device[key],device['jax/'+key[5:]];assert a.dtype==b.dtype and a.shape==b.shape
                            exact=a.dtype.kind in 'biu';ok=np.array_equal(a,b) if exact else np.allclose(a,b,rtol=1e-6,atol=1e-6,equal_nan=False)
                            paired[key[5:]]=dict(dtype=a.dtype.str,shape=list(a.shape),passed=bool(ok),byte_equal=a.tobytes()==b.tobytes(),maximum_absolute=float(np.max(abs(a.astype(float)-b.astype(float)),initial=0.)))
                        record['original_cuda_jax_fields']=paired
                        record['device_vs_current_numpy']={}
                        for backend in ('cuda','jax'):
                            comparisons={k:difference(device[backend+'/diagnostics/'+k],d[k],.1,1. if k in ('h','le') else (1e-7 if k=='swe' else .0001),10. if k in ('h','le') else (1e-6 if k=='swe' else .001)) for k in ('h','le','gpp_gcm2','et_mm','runoff_mm','swe')}
                            comparisons['soil_cells']=dict(maximum_absolute=float(np.max(abs(device[backend+'/soil_cells'].astype(float)-packed[1]),initial=0.)))
                            record['device_vs_current_numpy'][backend]=comparisons
                    records.append(record)
        after_ids={k:dict(dtype=v.dtype.str,shape=list(v.shape),sha256=sha(v.tobytes(order='C'))) for k,v in inputs.items()}
        assert after_ids==input_ids;save(root/'column-input-identities-after.json',after_ids)
        np.savez_compressed(root/'current-column-reference-values.npz',**output_arrays)
        # Original station configuration and actual serialized forcing are reused.
        with np.load(source/'tests/fixtures/clm_richards_station_reference.npz',allow_pickle=False) as archive:station_fixture={k:archive[k] for k in archive.files}
        original=runner.step_clm_enthalpy_column;station_records=[]
        for structured in (0,1):
            original_case=retained/('case'+str(structured))
            expected_config=json.loads(str(station_fixture[str(structured)+'/config_json']))
            config=json.loads((original_case/'config.json').read_bytes());assert config==expected_config
            with np.load(original_case/'forcing.npz',allow_pickle=False) as archive:data={k:archive[k] for k in archive.files}
            names={k[len(str(structured)+'/input/'):]:v for k,v in station_fixture.items() if k.startswith(str(structured)+'/input/')}
            assert set(data)==set(names)
            assert all(data[k].dtype==v.dtype and data[k].shape==v.shape and data[k].tobytes()==v.tobytes() for k,v in names.items())
            count=[0];returned_states=[]
            def observed(*a,**kw):
                step=count[0];path=root/'stations'/str(structured)/('step'+str(step))
                capture(path.with_name(path.name+'-input'),dict(args=a,kwargs=kw))
                calls['started']+=1;answer=original(*a,**kw);calls['returned']+=1;count[0]+=1
                capture(path,answer);returned_states.append(answer[0]);return answer
            runner.step_clm_enthalpy_column=observed
            report=runner.run(original_case/'forcing.npz',original_case/'meta.json',original_case/'config.json',root/('station-run-'+str(structured)))
            assert report['status']=='complete' and report['steps_completed']==count[0]==4
            runner.step_clm_enthalpy_column=original
            with np.load(root/('station-run-'+str(structured))/report['model_npz'],allow_pickle=False) as archive:reference={k:archive[k] for k in archive.files}
            comparisons=[]
            for case_index in ((0,) if structured==0 else (1,2)):
                device_report,saved,rows=native_io.read_generation(retained/('case'+str(case_index))/'whole')
                assert device_report['status']=='complete' and device_report['steps_completed']==4 and len(rows)==1
                trace=rows[0][1];result={}
                for name,scale,absolute,floor,offset in [('h_wm2',1.,1.,10.,0.),('le_wm2',1.,1.,10.,0.),('gpp_gc_m2',48.,.1,1.,0.),('nee_gc_m2',48.,.1,1.,0.),('et_mm',48.,.05,.5,0.),('runoff_mm',48.,.05,.5,0.),('tsoil_k',1.,.5,5.,273.15),('smc_m3m3',1.,.002,.02,0.),('swe_m',1.,.0001,.001,0.)]:
                    result[name]=difference((trace[name].astype(float)-offset)*scale,(reference[name].astype(float)-offset)*scale,.1,absolute,floor)
                actual_arrays=native_io.checkpoint_arrays(saved,device_report['identity'])
                dtype=actual_arrays[0].dtype;state_count=len(actual_arrays)
                env=data['environment'][-1]
                packed=native_io.pack_station_arrays([returned_states[-1]],state_count,dtype=np.float64,co2_ppm=np.asarray([env[0]]),cosine_zenith=np.asarray([env[1]]),diffuse_fraction=np.asarray([env[2]]),leaf_dimension=np.asarray([config['leaf_dimension_m']]))
                state_differences={str(i):dict(actual_dtype=a.dtype.str,reference_dtype=b.dtype.str,shape=list(a.shape),maximum_absolute=float(np.max(abs(a.astype(float)-b.astype(float)),initial=0.))) for i,(a,b) in enumerate(zip(actual_arrays,packed))}
                assert len(packed)==state_count
                initial_files=list((retained/('case'+str(case_index))/'whole').glob('state-0000000-*.npz'));assert len(initial_files)==1
                with np.load(initial_files[0],allow_pickle=False) as archive:initial_saved={k:archive[k] for k in archive.files}
                initial_arrays=native_io.checkpoint_arrays(initial_saved,device_report['identity'])
                first=data['environment'][0]
                initial_packed=native_io.pack_station_arrays([runner.build_state(config)],state_count,dtype=dtype,co2_ppm=np.asarray([first[0]],dtype),cosine_zenith=np.asarray([first[1]],dtype),diffuse_fraction=np.asarray([first[2]],dtype),leaf_dimension=np.asarray([config['leaf_dimension_m']],dtype))
                assert all(a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes() for a,b in zip(initial_arrays,initial_packed))
                comparisons.append(dict(original_device_case=case_index,backend=device_report['identity'].get('backend'),physical_variables=result,final_state_arrays=state_differences,initial_state_arrays_exact_at_device_precision=True,state_array_scope='Descriptive differences only; physical gates are the original per-variable conditions above. NumPy uses the original unchanged configuration; actual native initial quantization is independently checked.'))
                capture(root/'stations'/str(structured)/('original-device-case'+str(case_index)),dict(report=device_report,state=saved,trace=trace))
            station_records.append(dict(structured=structured,physical_calls=count[0],report=report,device_comparisons=comparisons))
        assert calls==dict(started=44,returned=44)
        save(root/'reference-readout.json',dict(reference_completed=True,scientific_acceptance=False,source_manifest_sha256=binding['NM_source_manifest_sha256'],physical_calls=calls,columns=records,stations=station_records,packet_counts=packet_counts,scope='Current original NM NumPy references and analysis of original NQ device outputs only. No fixture/test/model/gate edits, GPU run, annual or observation acceptance.'))
    except BaseException:
        (root/'failure.txt').write_text(traceback.format_exc());raise
    finally:
        after_source={n:sha((source/n).read_bytes()) for n in manifest}
        save(root/'source-after.json',after_source)
        controls_exact=all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
        retained_exact=all(sha((retained/n).read_bytes())==sha(raw) for n,raw in station_files.items())
        nq_exact=all(sha((root/'nq-evidence'/n).read_bytes())==sha(raw) for n,raw in nqfiles.items())
        save(root/'receipt.json',dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),physical_calls=calls,seconds=time.monotonic()-started,source584_exact=after_source==before_source==manifest,controls_exact=controls_exact,retained_inputs_exact=retained_exact,nq_inputs_exact=nq_exact,GPU_calls=0,fixtures_modified=False,scientific_acceptance=False))
        assert after_source==before_source==manifest and controls_exact and retained_exact and nq_exact

if __name__=='__main__':main()

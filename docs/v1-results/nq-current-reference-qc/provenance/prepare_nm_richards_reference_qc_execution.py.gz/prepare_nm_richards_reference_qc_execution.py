"""Freeze original QC proposal with mechanical PW PBS controls; stdlib only."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'nq-current-reference-qc-preparation'
OLD=BASE/'surface-7275-feasible-root-pw-execution'
EXEC=BASE/'nq-current-reference-qc-execution'
SHA='638f67134f1de7d017e3af18c8a9a4cf24a12b3173b9b46cf88e2301c7dced57'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda obj:(json.dumps(obj,indent=2,allow_nan=False)+'\n').encode()

def main():
    assert sha((PREP/'CONTROLS_SHA256.json').read_bytes())==SHA
    controls=json.loads((PREP/'CONTROLS_SHA256.json').read_bytes())
    assert len(controls)==5 and all(sha((PREP/n).read_bytes())==h for n,h in controls.items())
    binding=json.loads((PREP/'BINDINGS.json').read_bytes())
    archives={new:(BASE/old).read_bytes() for new,old in (
        ('source.tar.gz','climatology-final-candidate-nm-source.tar.gz'),
        ('station.tar.gz','nq-station-retained-qb-evidence.tar.gz'),
        ('nq.tar.gz','nq-terminal-qb-evidence.tar.gz'))}
    assert sha(archives['source.tar.gz'])==binding['NM_source_archive_sha256']
    assert sha(archives['station.tar.gz'])==binding['station_retained_archive_sha256']
    assert sha(archives['nq.tar.gz'])==binding['NQ_terminal_archive_sha256']
    EXEC.mkdir(exist_ok=False);diffs=[]
    for old,new in (('check_stage_pw.py','check_stage_qc.py'),('dispatch_feasible_pw.py','dispatch_reference_qc.py')):
        before=(OLD/old).read_text()
        after=before.replace('surface-feasible-root-pw','current-reference-qc').replace('dispatch_feasible_pw','dispatch_reference_qc').replace('check_stage_pw','check_stage_qc').replace('feasible_pw.pbs','reference_qc.pbs').replace('PW stage','QC stage').replace('frozen PW','frozen QC')
        if old.startswith('dispatch'):
            after=after.replace('planned_surface_calls=1, full_column_calls=0','planned_surface_calls=0, full_column_calls=44')
        ast.parse(after);(EXEC/new).write_text(after,encoding='utf-8',newline='\n')
        diffs.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old,tofile=new))
    before=(OLD/'feasible_pw.pbs').read_text()
    after=before.replace('surface-feasible-pw','current-reference-qc').replace('surface-feasible-root-pw','current-reference-qc').replace('pw-result','qc-result').replace('check_stage_pw.py','check_stage_qc.py')
    old='"$py" -B "$stage/preparation/probe_feasible_root_pw.py" --pu "$stage/pu-evidence.tar.gz" --pt "$stage/pt-evidence.tar.gz" --output "$root/probe" > "$root/worker.stdout" 2> "$root/worker.stderr"'
    new='"$py" -B "$stage/preparation/run_nm_richards_reference_qc.py" --source "$stage/source.tar.gz" --station "$stage/station.tar.gz" --nq "$stage/nq.tar.gz" --output "$root/reference" > "$root/worker.stdout" 2> "$root/worker.stderr"'
    assert old in after;after=after.replace(old,new)
    optional='    if test -f "$root/probe/diagnostic-status.txt"; then\n        cp "$root/probe/diagnostic-status.txt" "$root/diagnostic-status.txt"\n    fi\n'
    assert optional in after;after=after.replace(optional,'')
    after=after.replace("--exclude='./probe/original-model/source-nm'","--exclude='./reference/source'")
    (EXEC/'reference_qc.pbs').write_text(after,encoding='utf-8',newline='\n')
    diffs.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='feasible_pw.pbs',tofile='reference_qc.pbs'))
    (EXEC/'README.md').write_text('QC mechanically reuses original PW manager/compute002 dispatch, stage pre/post hashes and 1CPU/2GiB/10min PBS. The unchanged prepared worker runs exactly 44 current-NM NumPy column calls on original immutable inputs; all return trees, packet comparisons, budgets, actual worker/PBS/Stageout statuses remain separate. No model, tests, fixture, physical tolerance or GPU execution changes. This stage was prepared after prior root authorization; actual submission is separately recorded.\n',encoding='utf-8')
    (EXEC/'EXECUTION_BINDINGS.json').write_bytes(encode(dict(preparation_manifest_sha256=SHA,source_manifest_sha256=binding['NM_source_manifest_sha256'],planned_column_calls=44,GPU_calls=0,resources='1CPU/2GiB/10min/compute002',stage_status='prepared-only',all_preparation_files_unchanged=True)))
    index={p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode(index))
    (BASE/'nq-current-reference-qc-execution.diff').write_text(''.join(diffs),encoding='utf-8')
    items={'preparation/'+n:(PREP/n).read_bytes() for n in [*controls,'CONTROLS_SHA256.json']}
    items.update({'execution/'+n:(EXEC/n).read_bytes() for n in [*index,'CONTROLS_SHA256.json']})
    items.update(archives)
    items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/'nq-current-reference-qc-stage.tar.gz';assert not target.exists()
    with target.open('wb') as output,gzip.GzipFile(fileobj=output,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
        for n,raw in sorted(items.items()):
            member=tarfile.TarInfo(n);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==items
    result=dict(passed=True,scope='Stdlib metadata controls only; numerical execution not started',preparation_manifest_sha256=SHA,execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(index),stage_sha256=sha(target.read_bytes()),stage_members=len(items),stage_bytes=target.stat().st_size,execution_diff_sha256=sha((BASE/'nq-current-reference-qc-execution.diff').read_bytes()),original_worker_sha256=sha((PREP/'run_nm_richards_reference_qc.py').read_bytes()),planned_column_calls=44)
    (BASE/'nq-current-reference-qc-execution-static.json').write_bytes(encode(result));print(json.dumps(result))

if __name__=='__main__':main()

"""Read exact QC closed-job metadata only; no model/numerical import."""
import base64
import hashlib
import json
from pathlib import Path
import socket

ROOT=Path('/tmp/noahmp-current-reference-qc')
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main():
    host=socket.gethostname().split('.')[0];assert host in ('manager','compute002')
    index=json.loads((ROOT/'stage-inventory.json').read_bytes())
    before={n:sha((ROOT/n).read_bytes()) for n in index};assert before==index
    names=(['dispatch.json','qsub.stdout','qsub.stderr','compute-extract.stdout','compute-extract.stderr','compute-hashes.stdout','compute-hashes.stderr','pbs-output.log'] if host=='manager' else ['pbs-exit.txt'])
    files={n:base64.b64encode((ROOT/n).read_bytes()).decode('ascii') for n in names if (ROOT/n).is_file()}
    result=ROOT/'result.tar.gz'
    after={n:sha((ROOT/n).read_bytes()) for n in index};assert after==before
    print(json.dumps(dict(hostname=host,stage_files_before=before,stage_files_after=after,all_stage_immutable=True,files=files,actual_presence={n:(ROOT/n).is_file() for n in names},result_archive_sha256=sha(result.read_bytes()) if result.is_file() else None)))

if __name__=='__main__':main()

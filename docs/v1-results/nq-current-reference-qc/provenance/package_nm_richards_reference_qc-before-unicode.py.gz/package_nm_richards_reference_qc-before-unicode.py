"""Preserve actual QC raw receipts/typed opaque returns; no local physics."""
import base64
import gzip
import io
import json
from pathlib import Path

from package_surface_reference_pt import files,sha,encode
from package_surface_feasible_root_pw import opaque_packet
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='nq-current-reference-qc'
STAGE='fc32c805f013f46d0d10cc6ebda741bc263c4dfd129dd69db06018a48b9c4d3f'
PREP='638f67134f1de7d017e3af18c8a9a4cf24a12b3173b9b46cf88e2301c7dced57'
EXEC='564ac54840877515228f2722f2a616eed23a69d129f9a8e08b0b513302a5da50'

def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();assert sha(stage_raw)==STAGE
    stage=files(stage_raw);index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==16 and set(stage)==set(index)|{'stage-inventory.json'}
    assert all(sha(stage[n])==h for n,h in index.items())
    assert sha(stage['preparation/CONTROLS_SHA256.json'])==PREP and sha(stage['execution/CONTROLS_SHA256.json'])==EXEC
    closure=BASE/(LABEL+'-closure');compute=json.loads((closure/'compute.stdout').read_bytes());manager=json.loads((closure/'manager.stdout').read_bytes())
    for observed in (compute,manager):assert observed['all_stage_immutable'] and observed['stage_files_before']==observed['stage_files_after']==index
    raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes();assert sha(raw)==compute['result_archive_sha256']
    result=files(raw,directories=True)
    assert result['setup-exit.txt'].strip()==result['stage-after-exit.txt'].strip()==b'0'
    for name in ('stage-before.json','stage-after.json'):
        doc=json.loads(result[name]);assert doc['passed'] and doc['actual']==doc['expected']==index and doc['mismatches']==[]
    assert result['stage-inventory.json']==stage['stage-inventory.json']
    for n in json.loads(stage['execution/CONTROLS_SHA256.json']):assert result['execution-controls/'+n]==stage['execution/'+n]
    assert result['execution-controls/CONTROLS_SHA256.json']==stage['execution/CONTROLS_SHA256.json']
    status=int(result['worker-exit.txt'].strip());assert int(result['pbs-command-exit.txt'].strip())==status
    assert int(base64.b64decode(compute['files']['pbs-exit.txt']).strip())==status
    qstats=[p.read_bytes() for p in sorted(closure.glob('poll-*.stdout'))]
    final=[v for v in qstats if b'job_state = F' in v];assert len(final)==1
    text=final[0].decode();assert 'Exit_status = '+str(status) in text and 'Stageout_status = 0' in text
    receipt=json.loads(result['reference/receipt.json'])
    assert receipt['pbs_job']=='1827.manager' and receipt['host']=='compute002'
    assert all(receipt[k] for k in ('source584_exact','controls_exact','retained_inputs_exact','nq_inputs_exact'))
    assert receipt['GPU_calls']==0 and not receipt['fixtures_modified'] and not receipt['scientific_acceptance']
    binding=json.loads(stage['preparation/BINDINGS.json']);source=files(stage['source.tar.gz']);manifest=json.loads(source['SOURCE_SHA256.json'])
    assert sha(source['SOURCE_SHA256.json'])==binding['NM_source_manifest_sha256'] and len(manifest)==584
    assert json.loads(result['reference/source-before.json'])==json.loads(result['reference/source-after.json'])==manifest
    packet_counts={};fortran={}
    for name,b in result.items():
        if not name.endswith('.json'):continue
        doc=json.loads(b)
        if not isinstance(doc,dict) or doc.get('schema')!='QC-lossless-return-v1':continue
        stem=name.removesuffix('.json');packet_counts[stem],fortran[stem]=opaque_packet(result[stem+'.npz'],doc)
        assert sha(result[stem+'.pkl'])==doc['pickle_sha256']
    completed='reference/reference-readout.json' in result
    readout=json.loads(result['reference/reference-readout.json']) if completed else None
    if completed:
        assert readout['reference_completed'] and not readout['scientific_acceptance']
        assert readout['physical_calls']==receipt['physical_calls']==dict(started=44,returned=44)
        assert len(readout['columns'])==36 and len(readout['stations'])==2 and status==0
        assert {n.removeprefix('reference/'):c for n,c in packet_counts.items()}==readout['packet_counts']
    verification=dict(passed=True,scope='Raw PBS/SSH/stage/receipt hashes and opaque typed payload verification only',pbs_job='1827.manager',actual_PBS_exit=status,actual_Stageout_status=0,source584_exact=True,stage16_exact=True,preparation_manifest_sha256=PREP,execution_manifest_sha256=EXEC,stage_sha256=STAGE,result_sha256=sha(raw),opaque_packets=len(packet_counts),opaque_arrays=sum(packet_counts.values()),fortran_packets={n:v for n,v in fortran.items() if v},reference_completed=completed,physical_calls=receipt['physical_calls'],scientific_acceptance=False)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    readout_outer=dict(actual_job=verification,reference_readout=readout,failure=result.get('reference/failure.txt',b'').decode(),scope='Current NM NumPy on immutable original inputs; comparisons are computed only on EHPC. Original NQ failures and historical BF fixtures remain unchanged. No annual/observational acceptance or fixture update.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout_outer))
    items={'executed-stage.tar.gz':stage_raw,'raw-result.tar.gz':raw,'verification.json':encode(verification),'readout.json':encode(readout_outer)}
    for name,b in result.items():
        if name.startswith(('reference/nq-evidence/','reference/retained/')):continue
        items['actual-result/'+name]=b
    for directory in (BASE/(LABEL+'-deployment'),closure):
        for p in sorted(directory.iterdir()):
            if p.is_file():items['observations/'+directory.name+'/'+p.name]=p.read_bytes()
    for n in ('prepare_nm_richards_reference_qc_execution.py','deploy_nm_richards_reference_qc.py','read_nm_richards_reference_qc_closed.py','collect_nm_richards_reference_qc_closed.py','package_nm_richards_reference_qc.py',LABEL+'-execution.diff',LABEL+'-execution-static.json'):
        items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(v),sha256=sha(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;archive.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope=readout_outer['scope'])
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(dict(package=package,verification=verification)))

if __name__=='__main__':main()

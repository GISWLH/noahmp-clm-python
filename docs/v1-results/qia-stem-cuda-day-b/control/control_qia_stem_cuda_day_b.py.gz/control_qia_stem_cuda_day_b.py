from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-stem-cuda-day-b';start=time.monotonic()
with (r/'model.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'run_qia_stem_cuda_day_b.py')],stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();receipt=json.loads((r/'receipt.json').read_text()) if (r/'receipt.json').exists() else None;passed=bool(code==0 and receipt and receipt['failure'] is None and receipt['source_unchanged']);d=dict(returncode=code,passed=passed,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256((r/'receipt.json').read_bytes()).hexdigest() if receipt else None);(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);raise SystemExit(0 if passed else 1)

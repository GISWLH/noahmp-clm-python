from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-f';r=b/'qia-stem-cuda-day-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from noahmp_clm.validation import compare_series
start=time.monotonic();failure=None;result=None;barriers=[]
try:
 native.run(r/'inputs/batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,stop_after=48)
 report,state,cases=native.read_generation(r/'trajectory');assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['identity']['native_state_arrays']==19 and len(state)==26 and len(cases)==1
 assert report['identity']['compare_jax32'] is False and report['same_precision_max_absolute'] is None
 cold=list((r/'trajectory').glob('state-0000000-*.npz'));assert len(cold)==1
 with np.load(cold[0],allow_pickle=False) as z:newcold=dict(z)
 with np.load(r/'strict-reference-cold0.npz',allow_pickle=False) as z:strictcold=dict(z)
 assert len(newcold)==26 and set(newcold)<=strictcold.keys()
 for key,value in newcold.items():np.testing.assert_array_equal(value,strictcold[key])
 reference=r/'numpy-reference/trajectory';ref=json.loads((reference/'report.json').read_text());assert ref['status']=='running' and ref['steps_completed']==48 and ref['steps_requested']==17520 and ref['source_unchanged'] and sha(reference/ref['model_npz'])==ref['model_npz_sha256']
 case,actual=cases[0];assert case['configuration_sha256']==ref['configuration_sha256'] and case['forcing_npz_sha256']==ref['forcing_npz_sha256'] and case['forcing_manifest_sha256']==ref['forcing_manifest_sha256']
 with np.load(reference/ref['model_npz'],allow_pickle=False) as z:expected=dict(z)
 assert actual.keys()==expected.keys()
 for key in ['time_start','time_end']:np.testing.assert_array_equal(actual[key],expected[key])
 assert str(actual['time_start'][0])=='200301010000' and str(actual['time_end'][-1])=='200301020000'
 with np.load(r/'inputs/CN-Qia.npz',allow_pickle=False) as z:dt=np.asarray(z['forcing'][:48,0],float)
 assert dt.sum()==86400.;metrics={}
 for field,variable in [('h_wm2','h_wm2'),('le_wm2','le_wm2'),('et_mm','et_mm_day'),('runoff_mm','runoff_mm_day'),('gpp_gc_m2','gpp_gc_day'),('nee_gc_m2','nee_gc_day'),('swe_m','swe_m')]:
  factor=86400./dt if field in ['et_mm','runoff_mm','gpp_gc_m2','nee_gc_m2'] else 1.
  metrics[field]=compare_series(actual[field]*factor,expected[field]*factor,variable,weights=dt)
 for field,variable,offset in [('tsoil_k','tsoil_c',273.15),('smc_m3m3','smc',0.),('liquid_m3m3','smc',0.)]:
  assert actual[field].shape==expected[field].shape==(48,4)
  for layer in range(4):metrics[field+'/'+str(layer)]=compare_series(actual[field][:,layer]-offset,expected[field][:,layer]-offset,variable,weights=dt)
 assert all(v['bias_pass'] for v in metrics.values()),metrics
 for key in native.structure_trace_keys(case['configuration']):
  x,y=np.asarray(actual[key],float),np.asarray(expected[key],float);normal=abs(y)>.0001
  np.testing.assert_allclose(x[normal],y[normal],rtol=.1,atol=0.);np.testing.assert_allclose(x[~normal],y[~normal],rtol=0.,atol=1e-6)
 import cupy as cp
 cp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
 result=dict(columns=1,primary_cold_seed_arrays_exact=26,actual_steps=48,original_requested_steps=17520,native_checkpoint_arrays=26,metrics=metrics,
  instantaneous_flux_criteria_met=all(metrics[k]['correlation_pass'] is True for k in ['h_wm2','le_wm2']),
  same_precision_maximum_absolute=report['same_precision_max_absolute'],maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],
  sai_initial=case['configuration']['canopy_structure']['initial_sai'],sai_final=float(actual['sai_m2m2'][-1]),
  numpy_reference_report_sha256=sha(reference/'report.json'),device_report_sha256=sha(r/'trajectory/batch.json'))
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
unchanged=all(sha(s/n)==v for n,v in m.items());receipt=dict(scope='Actual locked Qia meteorology and predeclared SAI case, independent CUDA32-only first48 of17520, cold primary19 plus7 ledger arrays exactly equal original strictA cold seed, original MHCN and NumPy engineering gates. No JAX shadow/same-precision result in this run; original strictA remains independent and its1e-6 gate is not waived. Completed canonical22 module evidence is separate. NumPy48 reference ran on EHPC. Daily equivalent-rate bias and near-zero engineering comparison, not a spun-up year/FLUXNET acceptance. Interpreter atexit bypass only after device barriers/durable receipt; normal shutdown unvalidated.',failure=failure,result=result,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barriers=barriers,seconds=time.monotonic()-start);native.atomic_json(r/'receipt.json',receipt);print(json.dumps(receipt),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and len(barriers)==1 else 1)

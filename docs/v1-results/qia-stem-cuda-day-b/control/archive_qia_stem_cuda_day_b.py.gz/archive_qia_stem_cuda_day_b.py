from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-stem-cuda-day-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());exit=json.loads((r/'exit.json').read_text());report=json.loads((r/'trajectory/batch.json').read_text());assert exit['returncode']==0 and exit['passed'] and sha(r/'receipt.json')==exit['receipt_sha256'] and d['failure'] is None and d['source_unchanged'] and d['device_barriers']==['cupy-complete'] and d['result']['primary_cold_seed_arrays_exact']==26 and d['result']['actual_steps']==48 and d['result']['same_precision_maximum_absolute'] is None and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520
a=b/'qia-stem-cuda-day-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.rglob('*')):
  if p.is_file() and not p.relative_to(r).parts[0]=='numpy-reference':t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
 for name in ['run_qia_stem_cuda_day_b.py','control_qia_stem_cuda_day_b.py','launch_qia_stem_cuda_day_b.py']:t.add(b/name,arcname='control/'+name,recursive=False)
 t.add(b/'p6-stem-split-f/SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False);t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 summary=dict(scope=d['scope'],source_unchanged=True,seconds=d['seconds'],metrics=d['result']['metrics'],maximum_cumulative_m_h_c_n=d['result']['maximum_cumulative_m_h_c_n'],numpy_reference_archive_sha256='a7dfdd99e9258a626047d9361a63020563961395ef42470c53caeae9a30382b5',strict_paired_A_result='still independent and pending,not substituted by CUDA-only B',original_requested_steps=17520,actual_steps=48)
 data=(json.dumps(summary,indent=2)+'\n').encode();info=tarfile.TarInfo('summary.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,seconds=d['seconds'],main_metrics={k:v for k,v in d['result']['metrics'].items() if k in ['h_wm2','le_wm2','et_mm','gpp_gc_m2','nee_gc_m2']},maximum_cumulative_m_h_c_n=d['result']['maximum_cumulative_m_h_c_n'])))

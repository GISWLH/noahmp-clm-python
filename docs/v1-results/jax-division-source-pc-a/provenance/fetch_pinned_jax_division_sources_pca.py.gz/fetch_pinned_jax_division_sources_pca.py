"""Archive pinned primary build/code sources; no model/numerical execution."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import urllib.request

BASE=Path(__file__).resolve().parent/'jax-division-source-pc-a'
JAX='32544801e26115ac1794926d027148abf3baf009'
XLA='91888df6ce85102c30220e41d952065925e10886'
LLVM='7024b9e1b423b3c3c6ac76ab6a73cb2c9e4ef842'
SOURCES={
    'jax-MODULE.bazel':f'https://raw.githubusercontent.com/jax-ml/jax/{JAX}/MODULE.bazel',
    'xla-nvptx_backend.cc':f'https://raw.githubusercontent.com/openxla/xla/{XLA}/xla/service/gpu/llvm_gpu_backend/nvptx_backend.cc',
    'xla-llvm_command_line_options.h':f'https://raw.githubusercontent.com/openxla/xla/{XLA}/xla/service/llvm_ir/llvm_command_line_options.h',
    'xla-debug_options_flags.cc':f'https://raw.githubusercontent.com/openxla/xla/{XLA}/xla/debug_options_flags.cc',
    'xla-llvm-workspace.bzl':f'https://raw.githubusercontent.com/openxla/xla/{XLA}/third_party/llvm/workspace.bzl',
    'pinned-vendored-LLVM-NVPTXISelLowering.cpp':f'https://raw.githubusercontent.com/llvm/llvm-project/{LLVM}/llvm/lib/Target/NVPTX/NVPTXISelLowering.cpp',
}

def fetch(pair):
    name,url=pair;target=BASE/name;assert not target.exists()
    with urllib.request.urlopen(url,timeout=45) as response:
        assert response.status==200;raw=response.read()
    target.write_bytes(raw)
    return name,dict(url=url,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),actual_HTTP_status=200)

def main():
    target=BASE/'SOURCES.json';assert not target.exists()
    with ThreadPoolExecutor(max_workers=4) as pool:result=dict(pool.map(fetch,SOURCES.items()))
    target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))

if __name__=='__main__':main()

"""Pinned-source/installed-metadata inspection; no flag trial or new execution."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
ROOT=BASE/'jax-division-source-pc-a'
LABEL='jax-division-source-pc-a'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    meta=json.loads((ROOT/'installed-metadata.json').read_text(encoding='utf-8-sig'))
    identities={k:r['values'] for k,r in meta['source_files'].items()}
    for n in ('jax/version.py','jaxlib/version.py','jax_cuda12_plugin/version.py'):
        assert identities[n]['_release_version']=='0.11.2' and identities[n]['_git_hash']=='32544801e26115ac1794926d027148abf3baf009'
    assert meta['installed_library']['strings_command_exit']==0
    assert {'nvptx-prec-divf32','xla_backend_extra_options'}<=set(meta['installed_library']['exact_option_strings'])
    index=json.loads((ROOT/'SOURCES.json').read_bytes())
    assert all(sha((ROOT/n).read_bytes())==r['sha256'] and r['actual_HTTP_status']==200 for n,r in index.items())
    assert b'91888df6ce85102c30220e41d952065925e10886' in (ROOT/'jax-MODULE.bazel').read_bytes()
    assert b'7024b9e1b423b3c3c6ac76ab6a73cb2c9e4ef842' in (ROOT/'xla-llvm-workspace.bzl').read_bytes()
    assert b'backend_llvm_opts.emplace_back("-nvptx-prec-divf32=1")' in (ROOT/'xla-nvptx_backend.cc').read_bytes()
    readout=dict(inspection_completed=True,installed_JAX_jaxlib_GPU_plugin_git='32544801e26115ac1794926d027148abf3baf009',
        XLA_dependency_commit='91888df6ce85102c30220e41d952065925e10886',
        OpenXLA_vendored_LLVM_commit='7024b9e1b423b3c3c6ac76ab6a73cb2c9e4ef842',
        installed_library_sha256=meta['installed_library']['sha256'],installed_option_strings_present=True,
        source_supported_diagnostic_option='--xla_backend_extra_options=-nvptx-prec-divf32=2',
        flag_runtime_acceptance_tested=False,flag_numerical_effect_tested=False,new_GPU_calls=0,CPU_physical_reference_calls=0,
        dtype_or_global_X64_changed=False,production_changed=False,proposed_probe='Two isolated baseline/precision2 JAX-only contexts with X64off and unchanged explicit float32 inputs; root review and unique later authorization required',
        bounds='LLVM backend precision selection cannot restore earlier HLO constant-divide reciprocal folds. Source/string evidence does not prove the executed kernel honors the option or fixes geometry/adaptive/physical gates. No mixed-FP64 fallback or custom divider algorithm prepared.')
    items={'readout.json':encode(readout),'REVIEW.md':(BASE/'JAX_DIVISION_SOURCE_PCA_REVIEW.md').read_bytes()}
    for p in ROOT.iterdir():
        if p.is_file():items['source-inspection/'+p.name]=p.read_bytes()
    for n in ('collect_jax_division_source_metadata_pca.py','fetch_pinned_jax_division_sources_pca.py',Path(__file__).name):items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;archive.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual installed0.11.2 source/library identity plus exact JAX→OpenXLA→LLVM pins and primary option/default/override sources. Precision2 flag is source-supported, not executed; no GPU/model/FP64/globalX64/production changes or numerical repair credit.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

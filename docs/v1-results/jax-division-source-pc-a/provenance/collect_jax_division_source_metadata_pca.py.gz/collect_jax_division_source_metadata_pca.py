"""Read installed source/build identities and supported-option strings; no JAX import."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT=Path('/home/lhwang/venvs/noahmp-phase3b/lib/python3.12/site-packages')
sha=lambda r:hashlib.sha256(r).hexdigest()
report=dict(source_metadata_only=True,GPU_calls=0,NumPy_imports=0,JAX_imports=0,source_files={})
for name in ('jax/version.py','jaxlib/version.py','jax_cuda12_plugin/version.py','jax_plugins/xla_cuda12/version.py'):
    p=ROOT/name
    if not p.exists():continue
    raw=p.read_bytes();tree=ast.parse(raw);values={}
    for node in tree.body:
        key=None;value=None
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):key=node.targets[0].id;value=node.value
        if isinstance(node,ast.AnnAssign) and isinstance(node.target,ast.Name):key=node.target.id;value=node.value
        if key in ('_release_version','_git_hash','_version'):
            try:values[key]=ast.literal_eval(value)
            except (ValueError,TypeError):pass
    report['source_files'][name]=dict(sha256=sha(raw),values=values,raw_source=raw.decode())
p=ROOT/'jax/_src/lax/lax.py';raw=p.read_bytes();lines=raw.decode().splitlines()
start=next(i for i,line in enumerate(lines) if line.startswith('def div('))
report['lax_div']=dict(source_file=str(p),whole_source_sha256=sha(raw),first_line=start+1,lines=lines[start:start+29])
library=ROOT/'jaxlib/libjax_common.so'
h=hashlib.sha256()
with library.open('rb') as f:
    for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
wanted={b'nvptx-prec-divf32',b'xla_backend_extra_options',b'xla_gpu_enable_fast_min_max'}
child=subprocess.Popen(['strings',str(library)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
present=[]
for line in child.stdout:
    value=line.rstrip(b'\n')
    if value in wanted:present.append(value.decode())
err=child.stderr.read();code=child.wait()
report['installed_library']=dict(path=str(library),bytes=library.stat().st_size,sha256=h.hexdigest(),
    strings_command_exit=code,strings_stderr=err.decode(errors='replace'),exact_option_strings=present)
print(json.dumps(report))

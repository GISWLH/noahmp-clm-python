# PC-a source-supported float32 division diagnostic — not executed

The actual installed JAX/jaxlib0.11.2 version sources name commit `32544801e26115ac1794926d027148abf3baf009`. Its [MODULE.bazel](https://github.com/jax-ml/jax/blob/32544801e26115ac1794926d027148abf3baf009/MODULE.bazel#L27) pins OpenXLA `91888df6ce85102c30220e41d952065925e10886`. Installed-library source/flag strings are captured read-only in `jax-division-source-pc-a/installed-metadata.json`; no JAX initialization, flag trial, model or GPU computation occurred for this inspection.

The pinned [NVPTX backend](https://github.com/openxla/xla/blob/91888df6ce85102c30220e41d952065925e10886/xla/service/gpu/llvm_gpu_backend/nvptx_backend.cc#L200) inserts `-nvptx-prec-divf32=1`, then appends extracted backend extras after the defaults (lines210–216). The pinned [option extractor](https://github.com/openxla/xla/blob/91888df6ce85102c30220e41d952065925e10886/xla/service/llvm_ir/llvm_command_line_options.h#L34) preserves a non-`xla_` key/value as the LLVM option. The [debug flag parser](https://github.com/openxla/xla/blob/91888df6ce85102c30220e41d952065925e10886/xla/debug_options_flags.cc#L1468) accepts comma-separated backend key/value entries.

OpenXLA's own [LLVM dependency pin](https://github.com/openxla/xla/blob/91888df6ce85102c30220e41d952065925e10886/third_party/llvm/workspace.bzl#L20) names LLVM `7024b9e1b423b3c3c6ac76ab6a73cb2c9e4ef842`. In that exact vendored compiler dependency, [NVPTXISelLowering.cpp:91–102](https://github.com/llvm/llvm-project/blob/7024b9e1b423b3c3c6ac76ab6a73cb2c9e4ef842/llvm/lib/Target/NVPTX/NVPTXISelLowering.cpp#L91) maps precision level1 to full division and level2 to IEEE division; lines126–128 explicitly honor a supplied option. This dependency source is used only through the OpenXLA build pin, not a current unrelated compiler version.

There is therefore a concrete, source-supported diagnostic option:

```
XLA_FLAGS=--xla_backend_extra_options=-nvptx-prec-divf32=2
```

It selects float32 division code generation and does not require FP64 or enabling global X64. It is a compiler/backend option rather than a per-operation JAX numerical guarantee. The actual `lax.div(x,y)` implementation has no accuracy/rounding argument and directly binds the StableHLO divide primitive. Presence of the option strings in the installed library is supporting metadata, not proof that the resulting executable honors the requested semantics.

This flag cannot restore divisions already transformed into multiplication by a float32 reciprocal during HLO optimization. Existing PB-v HLO proves that transformation for constants1000/917; PB-z proves own-operand mismatches in both constant and variable divisions. A variable-division improvement must not be reported as a complete geometry or adaptive-trajectory repair.

## Proposed minimum independent test for root review

Use the unchanged PB-t596-source archive and four closed PB-v input frames. Two unique isolated JAX processes run on CUDA1: original backend settings and this one documented override, both with `JAX_ENABLE_X64=false` throughout. Each process executes four original batch1 pure diagnoses plus four augmented9-intermediate geometry contexts, preserving source/input identities. No physical source edit, adaptive loop, phase solve, new divider algorithm, FP64 intermediate, parameter sweep or whole-year restart.

Save exact environment/accepted option, before/after X64 state, all input/output dtypes and bits, original/context optimized HLO and available emitted PTX. Require all scientific intermediates to remain float32, source/inputs unchanged and each augmented context to reproduce its same-process original29 geometry fields. The baseline must reproduce the prior explicit32 observations or be marked inconclusive. Unknown/unsupported option errors stop the unique attempt and remain evidence; do not try another guessed spelling/value.

After capture, the already-reviewed independent CUDA hardware-RN kernel may classify each new observed operation using its actual operands, with all equality flags/counts computed on GPU. Keep variable-quotient results separate from constant-reciprocal results. This would need a separately bound input stage and root execution authorization; none is included in this source inspection. EHPC Fraction audit remains pending.

Proposed budget:900s per JAX process, original8GiB GPU/32GiB host/one-thread gates and distinct fresh caches, no automatic retry. QJ currently owns the scheduled CUDA1 work; this proposal does not reserve or launch a process. A successful isolated probe would still require a later reviewer decision and full physical/precision/ledger validation before any production configuration change. No mixed-FP64 fallback is prepared because a concrete float32 option exists to examine first.

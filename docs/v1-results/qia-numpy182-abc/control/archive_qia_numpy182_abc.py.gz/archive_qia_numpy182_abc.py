from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');a=b/'qia-numpy182-abc-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(a,'w:gz') as t:
    for name in ['qia-physical-numpy-182-a','qia-physical-numpy-182-b','qia-physical-numpy-182-c','qia182-phase-fixture-export-a']:
        r=b/name;assert (r/'pbs-exit.txt').read_text().strip()=='0'
        for p in sorted(r.rglob('*')):
            if p.is_file():t.add(p,arcname=name+'/'+p.relative_to(r).as_posix(),recursive=False)
    assert json.loads((b/'qia-physical-numpy-182-c/probe.json').read_text())['failure'] is None
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Original182 exact trace/warm80 failure,cold80 root41,numerical fresh-phase endpoint51,whole-step candidate hardMHCN,typedfixture export. Alloriginalsource files unchanged,80/tol1e-7 unchanged,not originalyear advancement/production/science acceptance.')))

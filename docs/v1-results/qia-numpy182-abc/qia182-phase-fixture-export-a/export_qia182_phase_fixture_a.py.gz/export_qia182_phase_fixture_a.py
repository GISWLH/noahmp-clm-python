from pathlib import Path
from dataclasses import fields, is_dataclass
import hashlib
import json
import math
import os
import pickle
import sys
import tarfile

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia182-phase-fixture-export-a'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-most-physical-c-source.tar.gz'
assert sha(a) == 'bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
sys.path[:0] = [str(b / 'test-deps'), str(s / 'src')]
import numpy as np

old = b / 'qia-physical-numpy-182-a'
assert (old / 'pbs-exit.txt').read_text().strip() == '0'
record = json.loads((old / 'probe.json').read_text())
assert record['failure'] is not None and record['source_unchanged'] and record['failed_index']==182
p = old / 'failed-phase-call.pkl'
call = pickle.loads(p.read_bytes())
call['initial_guess']=call['kwargs'].pop('initial_guess')

def clean(value):
    if is_dataclass(value):
        return dict(__type__=type(value).__name__, data={f.name: clean(getattr(value, f.name)) for f in fields(value)})
    if isinstance(value, np.ndarray):
        return dict(__array__=clean(value.tolist()), dtype=str(value.dtype))
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        assert not math.isnan(value)
        return dict(__float__='inf' if value > 0 else '-inf')
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value

result = dict(scope='Actual Qia182 fresh-condensate phase-edge call: original warm80 fails,unseeded80 reaches root41,and exact-endpoint trial reaches same root51. Unchanged equations/stores/tolerance1e-7/update80; original fullstep/checkpoint in archived probes. Typed data only; no pickled executable in test fixture. Original step/call in archived probes, not a fitted or future-step seed.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, original_call_sha256=sha(p), original_probe_sha256=sha(old / 'probe.json'), call=clean(call))
output = r / 'qia_182_phase_edge.json'
output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(scope='Metadata serialization only on EHPC PBS,no physics/model execution.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, fixture_sha256=sha(output), original_call_sha256=sha(p), bytes=output.stat().st_size)), flush=True)

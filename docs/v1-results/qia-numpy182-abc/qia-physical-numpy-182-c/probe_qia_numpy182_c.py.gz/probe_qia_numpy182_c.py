from pathlib import Path
import hashlib
import inspect
import json
import os
import pickle
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-physical-numpy-182-c'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
s = scratch / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-most-physical-c-source.tar.gz'
assert sha(a) == 'bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 509 and all(sha(s / n) == h for n, h in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s), str(s / 'src'), str(s / 'benchmarks')]
import numpy as np
import run_fluxnet_column as original
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-physical-numpy-week-c'
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert receipt['returncode'] == 1 and receipt['source_unchanged'] and report['steps_completed'] == report['failed_index'] == 182
assert sha(old / 'trajectory/report.json') == receipt['report_sha256']
assert sha(old / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
old_manifest = json.loads((old / 'SOURCE_SHA256.json').read_text())
assert old_manifest==manifest
state, initial, net, bounds, maximum, stepmax, index = pickle.loads((old / 'trajectory' / report['checkpoint_file']).read_bytes())
assert index == 182
inputs = b / 'qia-stem-inputs-a/inputs'
protocol = json.loads((inputs.parent / 'protocol.json').read_text())
assert all(sha(inputs / n) == h for n, h in protocol['inputs_sha256'].items())
config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
metadata = json.loads((inputs / 'CN-Qia.json').read_text())
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    data = dict(z)
stamps = original.validate_input(data, metadata, inputs / 'CN-Qia.npz')
f = original.Forcing(*data['forcing'][index])
co2, mu, diffuse = data['environment'][index]
environment = original.calendar(stamps[index], metadata, config['phenology'] is not None)
schedule = original.DepositionSchedule(config)
dep = schedule.aerosol(stamps[index], f.dt)
nitrogen = schedule.nitrogen_rate * f.dt
geometry = original.MOSTGeometry(**config['most_geometry'])
leaf = original.LeafParameters(**config['leaf_parameters'])
real=phase.solve_canopy_phase_energy
candidate=b/'qia-physical-numpy-182-b/candidate.py'
assert sha(candidate)=='3ca6f8e8257fdc04e7478400259c39b831fca5973df4084bca8b06f525d8f5b2'
events=[];namespace=dict(real.__globals__,event_log=events)
exec(compile(candidate.read_text(),'<whole182 numerical fresh-phase endpoint>','exec'),namespace)
phase.solve_canopy_phase_energy=namespace['solve_canopy_phase_energy']
start = time.monotonic()
failure, result = None, None
try:
    after, d = original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
    incoming, residual, bound = original.audit_step(state, after, f, d, nitrogen)
    cumulative = original.totals(after) - initial - (net + incoming)
    assert np.all(abs(residual)<=bound) and np.all(abs(cumulative)<=bounds+bound)
    (r / 'diagnostic-step183.pkl').write_bytes(pickle.dumps((state, after, f, d)))
    result = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=(bounds+bound).tolist(), diagnostics={k:float(d[v]) for k,v in original.TRACE.items()}, diagnostic_state_sha256=sha(r/'diagnostic-step183.pkl'))
except Exception as e:
    failure = type(e).__name__+': '+str(e)
    (r/'traceback.txt').write_text(traceback.format_exc())
phase.solve_canopy_phase_energy=real
assert all(sha(s/n)==v for n,v in manifest.items())
record=dict(scope='Diagnostic whole182 numerical exact-next-phase-endpoint candidate only for old-dry newly phase-active leaves. Runtime replacement only,all source files/equations/old stores/tol1e-7/80 and independent fullstep MHCN unchanged; original failed year not continued,not production/science acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,result=result,event_steps=events,source_unchanged=True,source_files=509,original_failed_checkpoint_sha256=report['checkpoint_sha256'],seconds=time.monotonic()-start)
(r/'probe.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps(record,allow_nan=False),flush=True)
assert failure is None

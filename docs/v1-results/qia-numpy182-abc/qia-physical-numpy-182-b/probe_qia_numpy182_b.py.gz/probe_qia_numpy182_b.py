"""Bounded isolated solver diagnosis; no production source/equation change."""
from pathlib import Path
import hashlib,inspect,json,os,pickle,sys,tarfile,time,traceback
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-physical-numpy-182-b';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'p6-most-physical-c-source.tar.gz';assert sha(a)=='bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==509 and all(sha(s/n)==v for n,v in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src')]
import numpy as np
from noahmp_clm.physics import canopy_phase_energy as module
old=b/'qia-physical-numpy-182-a';p=old/'failed-phase-call.pkl';binding=json.loads((old/'probe.json').read_text());assert sha(p)==binding['captured_call_sha256'] and binding['source_unchanged']
call=pickle.loads(p.read_bytes());args,kwargs=call['args'],call['kwargs'];real=module.solve_canopy_phase_energy
assert kwargs['tolerance']==1e-7 and kwargs.get('max_iterations',80)==80
last={};events=[];start=time.monotonic();runs=[]


def trace(frame,event,arg):
    if frame.f_code is real.__code__ and event=='exception':last.update(frame.f_locals)
    return trace if frame.f_code is real.__code__ else None


def execute(label,solve,kw):
    result=None;error=None
    try:
        result=solve(*args,**kw)
        old=args[4];dt=args[5];parcel=result['vapor_parcels']
        water=result['condensate'].mass+dt*result['wet_evaporation']-old.mass
        storage=(result['condensate'].enthalpy-old.enthalpy).sum()/dt
        transp=(result['transpiration']*(module.LF+module.CW*(result['leaf_temperature']-module.TF))).sum()-result['root_uptake']@kw['root_enthalpy']
        independent_heat=result['rnet']-result['h']-result['le']-result['ground_heat']-storage-parcel['advected_enthalpy_jm2'].sum()/dt-transp
        observed=dict(iterations=result['iterations'],restarts=result['restarts'],maximum_solver_residual=float(np.max(abs(result['solver_residual']))),maximum_parcel_residual=float(np.max(abs(result['layer_residual']))),independent_heat_residual_Wm2=float(independent_heat),maximum_water_residual_kgm2=float(np.max(abs(water))),h=result['h'],le=result['le'],gpp=result['gpp'],leaf_temperature=result['leaf_temperature'].tolist(),phase_coordinates=result['phase_coordinates'].tolist())
        (r/(label+'-output.pkl')).write_bytes(pickle.dumps(result))
    except Exception as e:
        error=type(e).__name__+': '+str(e);observed=None;(r/(label+'-traceback.txt')).write_text(traceback.format_exc())
    record=dict(label=label,error=error,result=observed);runs.append(record);return result


sys.settrace(trace)
try:execute('original-warm80',real,kwargs)
finally:sys.settrace(None)
assert last and runs[-1]['error'] is not None
x=last['x'].copy();evaluate=last['evaluate'];n=last['n'];active=last['phase_active'];mass=last['mass'];lower=last['lower'];upper=last['upper']
res=evaluate(x);jac=np.empty((n+2,n+2))
for k in range(n+2):
    step=1e-6 if k<n+1 else 1e-7;lo=x.copy();hi=x.copy();lo[k]=max(lower[k],x[k]-step);hi[k]=min(upper[k],x[k]+step);jac[:,k]=(evaluate(hi)-evaluate(lo))/(hi[k]-lo[k])
delta=np.linalg.lstsq(jac,-res,rcond=None)[0];delta/=max(1.,float(np.max(abs(delta)/np.r_[np.full(n,20.),5.,5.])))
endpoint_trials=[]
for k in range(n):
    if active[k] and mass[k]==0. and delta[k]!=0.:
        for edge in (0.,module.LF/module.CW):
            alpha=(edge-x[k])/delta[k]
            if 0.<alpha<=1.:
                trial=np.clip(x+alpha*delta,lower,upper);trial[k]=edge;rr=evaluate(trial)
                endpoint_trials.append(dict(layer=k,edge=edge,alpha=float(alpha),maximum_residual=float(np.max(abs(rr))),norm=float(rr@rr)))
execute('original-no-warm80',real,{**kwargs,'initial_guess':None})
source=inspect.getsource(real);marker='        norm=float(residual@residual);accepted=False;chosen_norm=norm'
assert source.count(marker)==1;source=source.replace(marker,'        iteration_x=x.copy()\n'+marker)
marker='        if not accepted or chosen_norm>.999*norm:'
injection="""        crossing=[]
        for k in range(n):
            if phase_active[k] and mass[k]==0. and delta[k]!=0.:
                for edge in (0.,LF/CW):
                    alpha=(edge-iteration_x[k])/delta[k]
                    if 0.<alpha<=1.:crossing.append((alpha,k,edge))
        if crossing:
            alpha,k,edge=min(crossing)
            trial=np.clip(iteration_x+alpha*delta,lower,upper);trial[k]=edge
            rr=evaluate(trial);event_norm=float(rr@rr)
            if event_norm<chosen_norm:
                x=trial;accepted=True;chosen_norm=event_norm
                event_log.append(dict(iteration=iteration,layer=k,edge=edge,alpha=float(alpha),norm_before=norm,norm_after=event_norm))
"""
assert source.count(marker)==1;source=source.replace(marker,injection+marker)
namespace=dict(real.__globals__,event_log=events);exec(compile(source,'<diagnostic exact fresh-condensate phase endpoint>','exec'),namespace)
execute('diagnostic-fresh-endpoint80',namespace[real.__name__],kwargs)
assert all(sha(s/n)==v for n,v in m.items())
record=dict(scope='EHPC bounded isolated182 original warm80,original no-warm80,and numerical exact-next-phase-edge trial only for old-dry newly phase-active leaves. Same equations/tol80/oldMHCN; candidate only,no production change/year continuation or acceptance. Independent whole-canopy heat/water reconstruction from solved extensive parcels retained.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,call_sha256=sha(p),original_final_norm=float(res@res),original_final_maximum_residual=float(np.max(abs(res))),endpoint_trials=endpoint_trials,runs=runs,event_steps=events,instrumented_candidate_sha256=hashlib.sha256(source.encode()).hexdigest(),seconds=time.monotonic()-start)
(r/'candidate.py').write_text(source)
(r/'probe.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True)

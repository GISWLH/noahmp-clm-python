from pathlib import Path
import json

b = Path('/home/zhangyq/noahmp-v1')
for key in ['p', 'q']:
    r = b / ('ctsm-qia-run-' + key)
    d = json.loads((r / 'configuration.json').read_text())
    result = {n: d[n] for n in ['pbs_job', 'node', 'failure', 'seconds', 'official_model_returncode', 'upstream_original_bytes_unchanged'] if n in d}
    result['stages'] = [{n: s[n] for n in ['stage', 'returncode', 'seconds']} for s in d['stages']]
    result['pbs_exit'] = (r / 'pbs-exit.txt').read_text().strip() if (r / 'pbs-exit.txt').exists() else None
    if (r / 'partial-seed-audit.json').exists():
        seed = json.loads((r / 'partial-seed-audit.json').read_text())
        result['seed_audit'] = {n: seed[n] for n in ['checks', 'maximum_liquid_theta_error_m3m3', 'inactive_bedrock_water_zero', 'official_nstep_rad_prev', 'official_fresh_vegetation_accumulators']}
    if (r / 'year-boundary.json').exists():
        audit = json.loads((r / 'year-boundary.json').read_text())
        result['year_audit'] = {n: audit[n] for n in ['positive_intervals', 'original_samples', 'all_direct_met_fields_exact_at_history_dtype', 'fields_sha256']}
    print(json.dumps(dict(case=key, result=result)))

from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
p, q = [b / ('ctsm-qia-run-' + v) for v in ['p', 'q']]
pd, qd = [json.loads((v / 'configuration.json').read_text()) for v in [p, q]]
assert (p / 'pbs-exit.txt').read_text().strip() == '1' and 'official_model_returncode' not in pd
assert [(s['stage'], s['returncode']) for s in pd['stages'] if s['returncode']] == [('preview-namelists', 1)]
assert (q / 'pbs-exit.txt').read_text().strip() == '0' and qd['official_model_returncode'] == 0
assert pd['upstream_original_bytes_unchanged'] and qd['upstream_original_bytes_unchanged'] and all(s['returncode'] == 0 for s in qd['stages'])
audit = json.loads((q / 'year-boundary.json').read_text())
seed = json.loads((q / 'partial-seed-audit.json').read_text())
assert audit['positive_intervals'] == 17520 and audit['all_direct_met_fields_exact_at_history_dtype']
assert sha(q / 'official-year-fields.npz') == audit['fields_sha256'] and seed['maximum_liquid_theta_error_m3m3'] == 0.
assert all(v.get('maximum_temperature_error_K', v.get('maximum_absolute', 0.)) == 0. for v in seed['checks'].values())
day, bad, good = [b / v for v in ['ctsm-qia-seed-firstday-a', 'ctsm-qia-canopy-start-a', 'ctsm-qia-canopy-start-b']]
assert (day / 'pbs-exit.txt').read_text().strip() == (good / 'pbs-exit.txt').read_text().strip() == '0'
assert (bad / 'pbs-exit.txt').read_text().strip() == '1' and 'ModuleNotFoundError' in (bad / 'diagnosis.log').read_text()
comparison = json.loads((day / 'diagnosis.json').read_text())
assert sha(day / 'native-trace-snapshot.npz') == comparison['native_trace_snapshot_sha256']
assert sha(day / 'native-report-snapshot.json') == comparison['native_report_snapshot_sha256']
assert comparison['cases']['Q']['official_fields_sha256'] == audit['fields_sha256'] and not comparison['scientific_acceptance']
canopy_receipt = json.loads((good / 'receipt.json').read_text())
assert all(s['returncode'] == 0 for s in canopy_receipt['stages']) and sha(good / 'diagnosis.json') == canopy_receipt['diagnosis_sha256']
a = b / 'ctsm-qia-seed-pq-a-evidence.tar.gz'
assert not a.exists()
samples, steps, raw_history = 0, [], []
with tarfile.open(a, 'w:gz') as t:
    for root in [p, q, day, bad, good]:
        for f in sorted(root.iterdir()):
            if f.is_file() and f.name != 'case-configuration-private.tar.gz':
                t.add(f, arcname=root.name + '/' + f.name, recursive=False)
    for root in [p, q]:
        with tarfile.open(root / 'case-configuration-private.tar.gz') as source:
            for m in source:
                if not m.isfile():
                    continue
                is_history = root == q and m.name.startswith('output/case/run/') and '.clm2.h0.' in m.name and m.name.endswith('.nc')
                keep = is_history or m.name.endswith(('.stdout.txt', '.stderr.txt', '-adaptation.json', '.stream')) or m.name.startswith('case/user_nl_') or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in', 'drv_in', 'lnd_in'])) or m.name in ['inputdata/CN-Qia.partial-hydrothermal-init.nc', 'inputdata/CN-Qia.official-interpolated-cold.nc']
                if not keep:
                    continue
                raw = source.extractfile(m).read()
                info = tarfile.TarInfo(root.name + '/workspace/' + m.name)
                info.size = len(raw)
                t.addfile(info, io.BytesIO(raw))
                if is_history:
                    digest = hashlib.sha256(raw).hexdigest()
                    assert qd['model_outputs'][Path(m.name).name]['sha256'] == digest
                    raw_history.append(dict(member=m.name, sha256=digest, bytes=len(raw)))
                if root == q and 'lnd.log.' in m.name:
                    text = raw.decode(errors='replace')
                    samples += text.count('Writing current time sample')
                    steps.extend(map(int, re.findall(r'clm: completed timestep\s+(\d+)', text)))
    assert samples == 17521 and max(steps) == 17520 and len(raw_history) == 2
    summary = dict(scope='Actual official Q full17520-bin standard-init_interp predeclared native hydrothermal cold experiment,model/PBS0,original2930 source unchanged. Original P internal-namelist failure and PBS229 NetCDF environment failure preserved; corrected public interface and pinned-environment read-only PBS230 diagnosis actual0. Original O and all positive bins retained. Initial canopy still0 firstbin,soil/depth/aquifer/SP-CN/fresh default rolling states remain unmatched; not science/Python-year/spinup acceptance.',
                   official_Q_pbs='227.manager', official_Q_model_and_pbs_returncode=0,
                   official_Q_model_seconds=next(s['seconds'] for s in qd['stages'] if s['stage'] == 'official-model'),
                   official_Q_total_seconds=qd['seconds'], history_samples=samples, last_nstep=max(steps),
                   source_bundle_sha256='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',
                   partial_seed_audit_sha256=sha(q / 'partial-seed-audit.json'), year_fields_sha256=audit['fields_sha256'],
                   original_P_private_sha256=sha(p / 'case-configuration-private.tar.gz'), original_Q_private_sha256=sha(q / 'case-configuration-private.tar.gz'),
                   comparison_sha256=sha(day / 'diagnosis.json'), canopy_diagnosis_sha256=sha(good / 'diagnosis.json'), raw_history=raw_history)
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    for name in ['inspect_ctsm_pq_results_a.py', 'archive_ctsm_qia_seed_pq_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, official_model_returncode=0, positive_bins=17520, raw_history_files=len(raw_history))))

from pathlib import Path
import hashlib
import json
import os
import re
import tarfile

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-canopy-start-b'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
cases = {}
for key in ['o', 'q']:
    original = b / ('ctsm-qia-run-' + key)
    config = json.loads((original / 'configuration.json').read_text())
    audit = json.loads((original / 'year-boundary.json').read_text())
    assert (original / 'pbs-exit.txt').read_text().strip() == '0' and config['official_model_returncode'] == 0
    assert sha(original / 'official-year-fields.npz') == audit['fields_sha256']
    with np.load(original / 'official-year-fields.npz', allow_pickle=False) as z:
        selected = {name: np.asarray(z[name]) for name in ['TLAI', 'TSAI', 'FPSN', 'FSH', 'EFLX_LH_TOT']}
        bounds = np.asarray(z['time_bounds_seconds'])
    assert np.array_equal(bounds[:48], np.arange(48)[:, None] * 1800 + [[0, 1800]])
    canopy = {}
    for name, values in selected.items():
        values = values.reshape(17520)
        canopy[name] = dict(first8=values[:8].tolist(), first48_zero_indices=np.flatnonzero(values[:48] == 0).tolist(),
                            year_zero_count=int(np.sum(values == 0)), first48_mean=float(values[:48].mean()))
    row = dict(configuration_sha256=sha(original / 'configuration.json'), raw_fields_sha256=audit['fields_sha256'], fields=canopy)
    with tarfile.open(original / 'case-configuration-private.tar.gz') as t:
        wanted = [m for m in t if m.isfile() and (m.name == 'output/case/run/case.clm2.h0.2002-12-31-57600.nc' or
                  key == 'q' and m.name in ['inputdata/CN-Qia.official-interpolated-cold.nc', 'inputdata/surfdata.CN-Qia.engineering.nc'])]
        assert len(wanted) == (3 if key == 'q' else 1)
        row['netcdf'] = []
        for member in wanted:
            p = scratch / (key + '-' + Path(member.name).name)
            p.write_bytes(t.extractfile(member).read())
            with Dataset(p) as d:
                info = dict(member=member.name, sha256=sha(p), variables=list(d.variables), selected={})
                if '.clm2.h0.' in member.name:
                    bt = np.asarray(d['time_bounds'][:], float) * 86400.
                    take = (bt[:, 0] >= 0) & (bt[:, 1] <= 86400.)
                    assert take.sum() == 48
                    for name in d.variables:
                        if re.search('BTRAN|BSW|WATSAT|SUCSAT|HKSAT|ROOTFR', name, re.I):
                            v = d[name]
                            if 'time' not in v.dimensions:
                                continue
                            values = np.ma.asarray(v[:])[take]
                            info['selected'][name] = dict(units=getattr(v, 'units', None), shape=values.shape,
                                                        values=values.filled(None).tolist(), masked=int(np.ma.getmaskarray(values).sum()))
                elif 'interpolated-cold' in member.name:
                    for name in ['tlai', 'tsai', 'elai', 'esai', 'htop', 'hbot', 'FRAC_VEG_NOSNO_ALB', 'timemgr_rst_curr_ymd', 'timemgr_rst_curr_tod']:
                        v = d[name]
                        a = np.ma.asarray(v[:])
                        info['selected'][name] = dict(units=getattr(v, 'units', None), values=a.filled(None).tolist(), masked=int(np.ma.getmaskarray(a).sum()))
                else:
                    for name in ['MONTHLY_LAI', 'MONTHLY_SAI', 'MONTHLY_HEIGHT_TOP', 'MONTHLY_HEIGHT_BOT']:
                        if name in d.variables:
                            v = d[name]
                            a = np.ma.asarray(v[:])
                            info['selected'][name] = dict(units=getattr(v, 'units', None), dimensions=v.dimensions, values=a.filled(None).tolist())
                row['netcdf'].append(info)
    cases[key.upper()] = row
record = dict(scope='Read-only original O/Q initial canopy and actual positive-bin history diagnosis on EHPC PBS. No changed initial state, meteorology, model/source, parameters, time relabeling or science acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, cases=cases)
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(pbs_job=record['pbs_job'], cases={k: v['fields'] for k, v in cases.items()})), flush=True)

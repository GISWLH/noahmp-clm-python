from pathlib import Path
import ast
import json

r = Path(__file__).resolve().parent
p = (r / 'run_ctsm_qia_p.py').read_text().replace('ctsm-qia-run-p', 'ctsm-qia-run-q')
old = "    nl += [\"finidat = ' '\",\"finidat_interp_source = '\"+str(inputs/'CN-Qia.partial-hydrothermal-init.nc')+\"'\",\"finidat_interp_dest = '\"+str(inputs/'CN-Qia.official-interpolated-cold.nc')+\"'\"]"
new = "    nl += [\"finidat = '\"+str(inputs/'CN-Qia.partial-hydrothermal-init.nc')+\"'\",\"use_init_interp = .true.\",\"finidat_interp_dest = '\"+str(inputs/'CN-Qia.official-interpolated-cold.nc')+\"'\"]"
assert p.count(old) == 1
p = p.replace(old, new).replace('CLM_FORCE_COLDSTART=on', 'CLM_FORCE_COLDSTART=off')
ast.parse(p)
(r / 'run_ctsm_qia_q.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_p.pbs').read_text().replace('ctsm-qia-run-p', 'ctsm-qia-run-q').replace('run_ctsm_qia_p.py', 'run_ctsm_qia_q.py').replace('clm-qia-official-p', 'clm-qia-official-q')
(r / 'ctsm_qia_run_q.pbs').write_bytes(p.encode())
d = json.loads((r / 'ctsm-qia-run-p-protocol.json').read_text())
d['scope'] = d['scope'].replace('official P ', 'official Q ')
d['prior_P_failure'] = 'PBS226 preview failed on internal finidat_interp_source name; no integration. Q uses documented finidat plus use_init_interp=true and automatic internal translation, CLM_FORCE_COLDSTART=off for this prescribed initial input. No physics/data/target changes.'
(r / 'ctsm-qia-run-q-protocol.json').write_bytes((json.dumps(d, indent=2) + '\n').encode())
print('Prepared documented use_init_interp interface Q; P unchanged')

"""Serialize standard DATM COPYALL fields on PBS; no model source changes."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
met, native_root = map(Path, sys.argv[1:3])
base = native_root.parent.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
protocol = json.loads((native_root.parent / 'protocol.json').read_text())
assert all(sha(native_root / n) == v for n, v in protocol['inputs_sha256'].items())
source = base / 'ctsm-reference-source-bundle-a.tar.gz'
assert sha(source) == 'f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
contracts = []
with tarfile.open(source) as t:
    for name, intervals in [('CTSM/cime/src/components/data_comps/datm/datm_comp_mod.F90', [(103, 153), (663, 710), (924, 942), (1000, 1026)]), ('CTSM/cime/src/share/util/shr_precip_mod.F90', [(17, 45)]), ('CTSM/cime/src/share/util/shr_const_mod.F90', [(24, 38)])]:
        raw = t.extractfile(name).read()
        lines = raw.decode().splitlines()
        contracts.append(dict(source=name, source_sha256=hashlib.sha256(raw).hexdigest(), ranges=[dict(first=a, last=b, lines=[str(i+1)+':'+lines[i] for i in range(a-1, b)]) for a, b in intervals]))
with np.load(native_root / 'CN-Qia.npz', allow_pickle=False) as z:
    forcing = np.asarray(z['forcing'], float)
assert forcing.shape == (17520, 8)

def attributes(v):
    return {n: repr(v.getncattr(n)) for n in v.ncattrs()}

def fingerprint(d):
    result = {}
    for n, v in d.variables.items():
        a = np.ma.asarray(v[:])
        assert not np.any(np.ma.getmaskarray(a)), n
        a = np.asarray(a)
        result[n] = dict(dtype=str(a.dtype), dimensions=v.dimensions, shape=a.shape, attributes=attributes(v), data_sha256=hashlib.sha256(a.tobytes(order='C')).hexdigest())
    return result

original_sha = sha(met)
with Dataset(met, 'r+') as d:
    before, global_before = fingerprint(d), attributes(d)
    shape = d['TBOT'].shape
    temperature = np.asarray(d['TBOT'][:], float)
    humidity = np.asarray(d['QBOT'][:], float)
    pressure = np.asarray(d['PSRF'][:], float)
    wind = np.asarray(d['WIND'][:], float)
    precipitation = np.asarray(d['PRECTmms'][:], float)
    assert np.array_equal(temperature.reshape(-1), forcing[:, 1])
    assert np.array_equal(humidity.reshape(-1), forcing[:, 2])
    assert np.array_equal(pressure.reshape(-1), forcing[:, 4])
    assert np.min(temperature) > 180. and np.all(pressure > 0.) and np.all(wind >= 0.)
    # Preserve original CLMNCEP wind direction, ideal-moist-air density
    # convention and temperature-only precipitation ramp. Only qsat capping
    # is bypassed. This input adapter is outside the Python physical model.
    rdair = (6.02214e26 * 1.38065e-23) / 28.966
    vapor_pressure = (humidity * pressure) / (.622 + .378 * humidity)
    density = (pressure - .378 * vapor_pressure) / (temperature * rdair)
    rain_fraction = np.clip((temperature - 273.15) * .5, 0., 1.)
    convective, stratiform = precipitation * .1, precipitation * .9
    direct, diffuse = np.asarray(d['SWDNDIR_COMMON'][:]), np.asarray(d['SWDNDF_COMMON'][:])
    new = {
        'U_COPY': (wind / np.sqrt(2.), 'm s-1'), 'V_COPY': (wind / np.sqrt(2.), 'm s-1'),
        'PTEM_COPY': (temperature, 'K'), 'PSLV_COPY': (pressure, 'Pa'), 'DENS_COPY': (density, 'kg m-3'),
        'SWNDR_COPY': (direct * .5, 'W m-2'), 'SWVDR_COPY': (direct * .5, 'W m-2'),
        'SWNDF_COPY': (diffuse * .5, 'W m-2'), 'SWVDF_COPY': (diffuse * .5, 'W m-2'),
        'RAINC_COPY': (np.maximum(0., convective * rain_fraction), 'mm s-1'),
        'RAINL_COPY': (np.maximum(0., stratiform * rain_fraction), 'mm s-1'),
        'SNOWC_COPY': (np.maximum(0., convective * (1 - rain_fraction)), 'mm s-1'),
        'SNOWL_COPY': (np.maximum(0., stratiform * (1 - rain_fraction)), 'mm s-1'),
    }
    for name, (value, units) in new.items():
        assert name not in d.variables and value.shape == shape and np.isfinite(value).all()
        v = d.createVariable(name, 'f8', d['TBOT'].dimensions)
        v.units = units
        v.long_name = 'Explicit standard COPYALL ' + name
        v[:] = value
    assert attributes(d) == global_before
    after = fingerprint(d)
    assert all(after[n] == v for n, v in before.items())
with Dataset(met) as d:
    actual = fingerprint(d)
    assert all(actual[n] == v for n, v in before.items())
    assert all(np.array_equal(np.asarray(d[n][:]), value) for n, (value, units) in new.items())
record = dict(scope='Standard pinned DATM COPYALL stream-input serialization only on EHPC PBS,not coupled-system/urban or Python physics development. Preserve all original17520 meteorology/CF fields and prior common SW fields, plus same CLMNCEP wind/density conventions and0-2C rain ramp. Original QBOT bypasses CLMNCEP qsat cap. No fit or change to native inputs,soil/cold-state or upstream source.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, source_bundle_sha256=sha(source), source_contract=contracts,
              before_copyall_met_sha256=original_sha, derived_met_sha256=sha(met), original_native_sha256=sha(native_root / 'CN-Qia.npz'),
              original_variables_unchanged=True, original_variable_fingerprints=before,
              added_variables=list(new), official_dry_air_constant_JkgK=rdair,
              maximum_precipitation_sum_error_mm_s=float(np.max(abs(sum(new[n][0] for n in ['RAINC_COPY', 'RAINL_COPY', 'SNOWC_COPY', 'SNOWL_COPY']) - precipitation))),
              swnet_scope='Faxa_swnet not prescribed: driver defaults to0 in COPYALL; it is a DATM diagnostic, not any of the four incident solar components consumed by this all-stub single forest land reference. Actual land fields must be verified; no general coupled-system equivalence claimed.')
print(json.dumps(record), flush=True)

from pathlib import Path
import ast
import json

r = Path(__file__).resolve().parent
p = (r / 'run_ctsm_qia_o.py').read_text().replace('ctsm-qia-run-o', 'ctsm-qia-run-p')
marker = "    value['copyall_derivation']=json.loads((scratch/'copyall-input.stdout.txt').read_text())"
assert p.count(marker) == 1
p = p.replace(marker, marker + "\n    assert run('partial-common-seed',[py,str(root/'make_ctsm_qia_partial_seed_a.py'),'make',str(inputs),str(root)])==0\n    value['partial_seed']=json.loads((root/'partial-seed.json').read_text())")
marker = "    (case/'user_nl_clm').write_text('\\n'.join(nl)+'\\n')"
assert p.count(marker) == 1
p = p.replace(marker, "    nl += [\"finidat = ' '\",\"finidat_interp_source = '\"+str(inputs/'CN-Qia.partial-hydrothermal-init.nc')+\"'\",\"finidat_interp_dest = '\"+str(inputs/'CN-Qia.official-interpolated-cold.nc')+\"'\"]\n" + marker)
marker = "            if model_code==0:\n                assert run('year-boundary-audit'"
assert p.count(marker) == 1
p = p.replace(marker, "            if model_code==0:\n                assert run('partial-seed-audit',[py,str(root/'make_ctsm_qia_partial_seed_a.py'),'audit',str(inputs),str(root)])==0\n                value['partial_seed_audit']=json.loads((root/'partial-seed-audit.json').read_text())\n                assert run('year-boundary-audit'")
p = p.replace("soil_scope='Nearest original coarse-grid soil,10SL_3.5m/default official cold stores; not matched to Python four-layer original cold seed.'", "soil_scope='Original coarse soil and official10hydro/15thermal retained. Standard init_interp source contains only geometry and predeclared original Python T278.722/theta.28/zero snow-canopy. All other physical/historical fields absent and remain official fresh cold defaults. Not all background conditions matched.'")
p = p.replace("coarse soil/default official cold stores not matched to Python", "coarse soil and official fresh background defaults; predeclared Python hydrothermal cold fields transferred through standard init_interp, not an all-conditions match")
p = p.replace("Same upstream", "Same upstream")
ast.parse(p)
(r / 'run_ctsm_qia_p.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_o.pbs').read_text().replace('ctsm-qia-run-o', 'ctsm-qia-run-p').replace('run_ctsm_qia_o.py', 'run_ctsm_qia_p.py').replace('clm-qia-official-o', 'clm-qia-official-p')
(r / 'ctsm_qia_run_p.pbs').write_bytes(p.encode())
protocol = dict(scope='Prospective additional official SP Qia experiment. Keep original O meteorology/deposition/coarse soil/PFT/geometry/LAI/physics. Transfer original Python predeclared T278.722K/theta0.28/zero snow-canopy through standard official init_interp partial source; no old historical physical/counter values or output-score selection. Not all-conditions match: soil/depth/aquifer/SP-CN/fresh official rolling defaults remain. Original O and failed Python trajectories preserved.',
                original_O_private_sha256='0123de586c89dfc65abb0adf424bdaa2155441d50438e5dd2b5bb99e120ce6d1',
                official_source_bundle_sha256='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',
                steps=17520, evaluation='Input/seed feed-through first; science criteria unchanged, no scientific pass from model exit alone.')
(r / 'ctsm-qia-run-p-protocol.json').write_bytes((json.dumps(protocol, indent=2) + '\n').encode())
print(json.dumps(dict(controller='run_ctsm_qia_p.py', bytes=(r / 'run_ctsm_qia_p.py').stat().st_size)))

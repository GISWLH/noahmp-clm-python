from pathlib import Path
import datetime
import hashlib
import json
import subprocess

r = Path('/home/zhangyq/noahmp-v1/ctsm-qia-run-p')
assert not (r / 'launch.json').exists()
files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(r.iterdir()) if p.suffix in ['.py', '.pbs', '.json']}
qstat = subprocess.check_output(['qstat', '-f', '226.manager'], text=True)
(r / 'launch-qstat.txt').write_text(qstat)
value = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pbs_job='226.manager',
             scope='Actual queued/running official P experiment submitted after hydrothermal targets/protocol frozen. No completion or science pass inferred. Original O/upstream and live Python/GPU jobs unchanged.',
             controls_sha256=files, pbs_node='compute002' if 'compute002' in qstat else None)
(r / 'launch.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value))

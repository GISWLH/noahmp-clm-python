"""Locate the first backend difference in the retained same-input failure."""
from pathlib import Path
import json
import numpy as np
import cupy as cp
import noahmp_clm.gpu.canopy_most as jm
import noahmp_clm.gpu.cuda.canopy_most as cm
import noahmp_clm.gpu.canopy_phase_surface as js
import noahmp_clm.gpu.cuda.canopy_phase_surface as cs
root=Path('/home/lhwang/work/noahmp-v1/p6-native-fluxnet-b')
records=[]
trace=root/'height-paired-a/iteration-trace-b'
def serial(value):
    if isinstance(value,list):return [serial(x) for x in value]
    if isinstance(value,dict):return {k:serial(v) for k,v in value.items()}
    if isinstance(value,float) and not np.isfinite(value):return str(value)
    return value
def record(value):
    value=serial(value);records.append(value)
    with (trace/'records.jsonl').open('a') as f:f.write(json.dumps(value,allow_nan=False)+'\n')
def host(v):
    a=cp.asnumpy(v) if isinstance(v,cp.ndarray) else np.asarray(v)
    if a.ndim and a.shape[0]==27:a=a[24]
    return a.tolist()
def coefficient_wrapper(name,fn):
    def wrapped(*a,**kw):
        out=fn(*a,**kw)
        record(dict(backend=name,kind='coefficients',input=[host(v) for v in a],
            output={k:host(v) for k,v in out.items()}))
        return out
    return wrapped
def surface_wrapper(name,fn):
    def wrapped(*a,**kw):
        out=fn(*a,**kw)
        record(dict(backend=name,kind='surface',exchange=host(a[5]),extension=host(kw['exchange_extension']),
            output={k:host(out[k]) for k in ['h','le','leaf_temperature','phase_coordinates','max_solver_residual','converged'] if k in out}))
        return out
    return wrapped
jm.run_canopy_most_jax=coefficient_wrapper('jax32',jm.run_canopy_most_jax)
cm.run_canopy_most_cuda=coefficient_wrapper('cuda32',cm.run_canopy_most_cuda)
js.run_canopy_phase_surface_jax=surface_wrapper('jax32',js.run_canopy_phase_surface_jax)
cs.run_canopy_phase_surface_cuda=surface_wrapper('cuda32',cs.run_canopy_phase_surface_cuda)
source=(root/'replay_height_same_precision_failure.py').read_text().replace("outdir=run/'failure-replay'","outdir=run/'iteration-trace-b'")
ns=dict(__name__='__main__',__file__=str(root/'replay_height_same_precision_failure.py'))
try:exec(compile(source,str(root/'replay_height_same_precision_failure.py'),'exec'),ns)
finally:
    (trace/'iteration-trace.json').write_text(json.dumps(records,indent=2,allow_nan=False)+'\n')

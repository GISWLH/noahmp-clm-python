from pathlib import Path
import time,traceback
import numpy as np
import noahmp_clm.physics.canopy_phase_energy as module
from test_gpu_canopy_phase_surface import cases,reference
code=Path(module.__file__).read_text();arrays=cases(np.float32)
for count in (24,30):
 exec(compile(code.replace('range(18)','range('+str(count)+')'),'<diagnostic longer backtracking>', 'exec'),module.__dict__)
 start=time.perf_counter()
 try:
  d=reference(tuple(v[15] for v in arrays));print(count,'solved',d['energy_residual_jm2'],d['surface_evaluations'],d['iterations'],time.perf_counter()-start,flush=True)
 except Exception:traceback.print_exc()

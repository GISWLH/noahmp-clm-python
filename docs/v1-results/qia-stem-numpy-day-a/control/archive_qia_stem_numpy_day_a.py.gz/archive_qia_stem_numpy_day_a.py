from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-stem-numpy-day-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());report=json.loads((r/'trajectory/report.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['steps_completed']==48 and d['steps_requested']==17520 and (r/'pbs-exit.txt').read_text().strip()=='0' and report['source_unchanged'];assert sha(r/'trajectory/report.json')==d['report_sha256']
for key,digest in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:assert sha(r/'trajectory'/report[key])==report[digest]
a=b/'qia-stem-numpy-day-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.rglob('*')):
  if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
 t.add(b/'qia-stem-inputs-a.tar.gz',arcname='control/qia-stem-inputs-a.tar.gz',recursive=False);t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,maximum_cumulative=report['maximum_cumulative_residual_m_h_c_n'])))

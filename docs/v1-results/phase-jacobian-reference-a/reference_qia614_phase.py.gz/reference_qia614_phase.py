from pathlib import Path
import hashlib,json,os,time
import numpy as np
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.physics.photosynthesis import LeafParameters
from run_fluxnet_column import source_hashes
assert os.environ.get('PBS_JOBID')
root=Path.cwd()
with np.load(root/'phase-reference-inputs.npz',allow_pickle=False) as z:v={k:x.astype(float) for k,x in z.items()}
u=v['u'];b=v['boundary'];soil=v['soil'];c=v['condensate'];n=int(v['snow_count']);snow=v['snow'];f=v['factors']
pack=Snowpack(snow[:n,0],snow[:n,1],snow[:n,2],snow[:n,3],snow[:n,4:]) if n else None
exchange=CanopyExchange(*u[:11],atmosphere_water_velocity=v['extension'][0],potential_temperature=v['extension'][1])
begun=time.monotonic()
d=solve_canopy_phase_energy(v['leaf'],u[11],u[12],exchange,CanopyCondensate(c[:,0],c[:,1]),b[4],
    soil_supply=SoilWaterSupply(soil[1:5],soil[5:9],soil[9]),root_enthalpy=b[5:9],vegetated_fraction=u[13],
    transpiration_limit=u[16],ground_evaporation_limit=u[17],ground_emissivity=u[18],ground_albedo=u[19:21],
    diffuse_fraction=u[21],cosine_zenith=u[22],nitrogen_factor=f[:,0],water_stress=f[:,1],
    fixed_ground_temperature=b[1],ground_is_ice=bool(b[2]),ground_shares_soil=bool(b[3]),snowpack=pack,leaf_parameters=LeafParameters(*v['leaf_parameters']))
result=dict(scope='Independent NumPy64 phase solver at actual G614 fixed-boundary/root-supply operands; no soil H reinterpretation, full step or annual acceptance.',
    seconds=time.monotonic()-begun,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_sha256=source_hashes(),
    inputs_sha256=hashlib.sha256((root/'phase-reference-inputs.npz').read_bytes()).hexdigest(),result={k:d[k] for k in ['phase_coordinates','leaf_temperature','canopy_humidity','layer_residual','solver_residual','canopy_water_residual','h','le','iterations','restarts']})
(root/'reference.json').write_text(json.dumps(result,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x.item())+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x.item()),flush=True)

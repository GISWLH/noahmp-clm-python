"""Retain exact native failure operands; no invalid state is ever committed."""
from pathlib import Path
from dataclasses import astuple
import argparse,hashlib,json,traceback
import numpy as np
from run_fluxnet_native import Backend,load_batch,calendar,pack_bgc_environment,source_hashes
from fluxnet_deposition import DepositionSchedule
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
import noahmp_clm.gpu.cuda.canopy_phase_surface as surface_module

p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root
run=root/'cuda-year';report=json.loads((run/'batch.json').read_text())
assert report['status']=='failed';index=report['steps_completed']
assert report['identity']['source_sha256']==source_hashes()
dest=root/f'failure-{index}-capture-a';dest.mkdir(exist_ok=False)
cases=load_batch(root/'batch.json')
with np.load(run/report['checkpoint_file'],allow_pickle=False) as z:arrays=tuple(z[f'a{k}'] for k in range(16))
engine=Backend('cuda32');dtype=np.float32
forcing=np.asarray([c['data']['forcing'][index] for c in cases],dtype)
env=np.asarray([c['data']['environment'][index] for c in cases],dtype)
geometry=np.asarray([astuple(MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype)
e,cal=pack_bgc_environment([calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype)
schedules=[DepositionSchedule(c['config']) for c in cases]
deposition=np.asarray([d.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,d) in enumerate(zip(cases,schedules))],dtype)
nitrogen=np.array([d.nitrogen_rate for d in schedules],dtype)*forcing[:,0]
np.savez_compressed(dest/'whole-column-inputs.npz',**{f'a{k}':v for k,v in enumerate(arrays)},
    forcing=forcing,forcing_environment=env,environment=e,calendar=cal,geometry=geometry,deposition=deposition,nitrogen=nitrogen)
original=surface_module.run_canopy_phase_surface_cuda;count=0
def flatten(d,prefix=''):
    out={}
    for k,v in d.items():
        if isinstance(v,dict):out.update(flatten(v,prefix+k+'/'))
        else:out[prefix+k]=engine.host(v)
    return out
def wrapped(*args,**kw):
    global count
    count+=1;result=original(*args,**dict(kw,raise_on_failure=False));flat=flatten(result)
    if not np.all(flat['converged']) or not all(np.all(np.isfinite(v)) for v in flat.values()):
        inputs={f'a{k}':engine.host(v) for k,v in enumerate(args)}
        for key in ['exchange_extension','vic']:
            if kw.get(key) is not None:inputs[key]=engine.host(kw[key])
        np.savez_compressed(dest/'failed-surface-inputs.npz',**inputs)
        np.savez_compressed(dest/'failed-surface-output.npz',**flat)
        keys=['converged','canopy_converged','surface_temperature','surface_temperature_residual',
            'surface_root_bracket_k','max_solver_residual','surface_evaluations','thermal_layer_residual']
        summary=dict(index=index,surface_call=count,cases=[c['case'] for c in cases],
            time_start=[str(c['data']['time_start'][index]) for c in cases],
            nonfinite_fields=[k for k,v in flat.items() if not np.all(np.isfinite(v))],
            **{k:flat[k].tolist() for k in keys})
        (dest/'surface-failure.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(json.dumps(summary),flush=True)
        raise RuntimeError('Captured original unconverged surface; not accepted')
    return result
surface_module.run_canopy_phase_surface_cuda=wrapped
try:
    device=tuple(engine.xp.asarray(v) for v in arrays)
    engine.step(*engine.update_forcing(device,env),forcing,environment=e,calendar=cal,
        nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,most_geometry=geometry,
        leaf_parameters=LeafParameters(**cases[0]['config']['leaf_parameters']),return_surface=True)
    status='complete';failure=None
except Exception:status='failed';failure=traceback.format_exc()
summary=dict(status=status,index=index,calls=count,source_sha256=source_hashes(),failure=failure,
    artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.glob('*.npz')})
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(status=status,index=index,calls=count)),flush=True)

"""Isolated equal-merit exact-event experiment; every original final bound retained."""
from pathlib import Path
import hashlib,json
import numpy as np
import cupy as cp
root=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-f');dest=root/'phase-event-probe-a';dest.mkdir(exist_ok=False)
with np.load(root/'qia_phase_event_56_inputs.npz',allow_pickle=False) as z:x=dict(z)
cuda=Path.cwd()/'src/noahmp_clm/gpu/cuda'
original='\n'.join((cuda/name).read_text() for name in ['enthalpy_kernel.cu','column_heat_kernel.cu'])
needle='accepted=good&&(trial_merit<merit||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);'
parts=original.split(needle);assert len(parts)==3
coupled='''bool exact_event=false;
            for(int i=0;i<ns;++i)exact_event=exact_event||(ev0[i]&&step==f0[i])||(ev1[i]&&step==f1[i]);
            accepted=good&&(trial_merit<merit||(exact_event&&trial_merit==merit)||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);'''
scalar='''bool exact_event=(land0&&scalar_step==e0)||(land1&&scalar_step==e1);
                accepted=good&&(trial_merit<merit||(exact_event&&trial_merit==merit)||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);'''
experimental=parts[0]+coupled+parts[1]+scalar+parts[2]
outcomes={}
for name,source in [('original',original),('exact-event',experimental)]:
    module=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_joint_heat',))
    n=len(x['cells']);out=cp.empty((n,77),cp.float32)
    module.get_function('run_joint_heat')(((n+31)//32,),(32,),(*[cp.asarray(x[k]) for k in ['cells','props','options','boundary']],out,np.int32(n)))
    value=cp.asnumpy(out);np.save(dest/(name+'.npy'),value,allow_pickle=False)
    if name=='original':np.testing.assert_array_equal(value,x['original'])
    norm=abs(value[:,45:54])/value[:,62:71]
    outcomes[name]=dict(source_sha256=hashlib.sha256(source.encode()).hexdigest(),
        converged=value[:,75].astype(bool).tolist(),iterations=value[:,74].tolist(),norm=norm.max(1).tolist(),
        independent_energy_residual=((value[:,:9].astype(float)-x['cells'][:,:,1].astype(float)).sum(1)-x['boundary'][:,0].astype(float)*(value[:,73].astype(float)+x['cells'][:,:,4].astype(float).sum(1))).tolist())
(dest/'experimental-kernel.cu').write_text(experimental)
summary=dict(scope='Isolated extra acceptance of a strictly represented phase-event move with exactly unchanged weighted merit; unchanged final bounds, no production edits.',rows=len(x['cells']),outcomes=outcomes)
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)

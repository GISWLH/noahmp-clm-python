"""Compare preserved first-day prefixes after the working aliases advanced."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
from compare_station_backend_day import compare
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-f';dest=root/'first-day-validation';dest.mkdir(exist_ok=False)
for archive,expected,prefix in [(base/'first-climate-day-f-native-evidence.tar.gz','eb750c88265fcd7eb92cef702ed91fe8da3d05121b17b51034264a53ce7d14ac',None),
    (root/'numpy-first-day-f-evidence.tar.gz','4c9e645098fffd1642fb0553489996f89113b29f90ba8f4e0b5f205298507be7','numpy-first-day/')]:
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
    with tarfile.open(archive) as t:
        for m in t.getmembers():
            p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
            if prefix and not m.name.startswith(prefix):continue
            target=dest/m.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read())
result=compare(dest,'cuda-year','numpy-first-day')
result['numpy_receipt_provenance']='Derived prefix receipts explicitly retain original48 trace/state and later continuation report identity. Original aliases advanced to96 before archival; no new physics executed to reconstruct these receipts.'
(dest/'backend-day-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')

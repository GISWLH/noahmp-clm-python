from pathlib import Path
import hashlib,json,time,traceback
import numpy as np
import run_fluxnet_native as native
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-joint-chord-a';root=base/'numpy-failure-cuda-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());ref=json.loads((root/'whole-reference.json').read_text());assert sha(root/'native-inputs.npz')==ref['native_input_sha256']
with np.load(root/'native-inputs.npz',allow_pickle=False) as z:values={k:np.ascontiguousarray(z[k].astype(np.float32 if z[k].dtype.kind=='f' else np.int32)) for k in z.files}
engine=native.Backend('cuda32');leaf=LeafParameters(**ref['leaf_parameters']);rows=[];begun=time.monotonic()
for index,original in enumerate(ref['cases']):
    start=time.monotonic();row=dict(case=original['case'],status='failed')
    try:
        arrays=tuple(values[f'a{k}'][index:index+1] for k in range(16));f=values['forcing'][index:index+1];deposition=values['deposition'][index:index+1];nitrogen=values['nitrogen'][index:index+1];device=engine.update_forcing(tuple(engine.xp.asarray(v) for v in arrays),values['forcing_environment'][index:index+1]);gpu=engine.step(*device,f,environment=values['environment'][index:index+1],calendar=values['calendar'][index:index+1],nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,most_geometry=values['geometry'][index:index+1],leaf_parameters=leaf,return_surface=True);out=engine.host(gpu);next_device=native.next_bgc_arrays(device,gpu);after=tuple(engine.host(v) for v in next_device);incoming,res,bound,tracer=native.audit_step(arrays,after,f,deposition,nitrogen,out);t,liquid=engine.soil(next_device);d=out['diagnostics'];g=after[1]
        actual=dict(h_wm2=float(d['h'][0]),le_wm2=float(d['le'][0]),tsoil_c=(t[0]-273.15).tolist(),smc=(g[0,:,0]/(1000.*g[0,:,2])).tolist(),liquid=(liquid[0]/(1000.*g[0,:,2])).tolist(),swe_m=float(after[0][0,:,0].sum()/1000.),et_mm=float(d['et_mm'][0]),runoff_mm=float(d['runoff_mm'][0]),gpp_gc_m2=float(d['gpp_gc_m2'][0]),nee_gc_m2=float(d['nee_gc_m2'][0]));metrics={}
        for key,var,factor in [('h_wm2','h_wm2',1.),('le_wm2','le_wm2',1.),('tsoil_c','tsoil_c',1.),('smc','smc',1.),('liquid','smc',1.),('swe_m','swe_m',1.),('et_mm','et_mm_day',48.),('runoff_mm','runoff_mm_day',48.),('gpp_gc_m2','gpp_gc_day',48.),('nee_gc_m2','nee_gc_day',48.)]:
            left=np.atleast_1d(actual[key])*factor;right=np.atleast_1d(original[key])*factor;assert left.shape==right.shape;metrics[key]=[compare_series(np.array([a]),np.array([b]),var) for a,b in zip(left,right)]
        flat={}
        def flatten(value,path='output'):
            if isinstance(value,dict):
                for k,v in value.items():flatten(v,path+'/'+k)
            else:flat[path]=np.asarray(value)
        flatten(out)
        for k,v in enumerate(after):flat['next/a'+str(k)]=v
        p=root/(original['case']+'-output.npz');np.savez_compressed(p,**flat);passed=all(v['bias_pass'] for values in metrics.values() for v in values);row.update(status='valid-within-point-numerical-gates' if passed else 'valid-comparison-failed',actual=actual,metrics=metrics,independent_m_h_c_n=res.tolist(),original_bounds=bound.tolist(),impurity_residual=tracer.tolist(),output_sha256=sha(p),numpy_reference_material_event=original['material_event'],numpy_reference_root_residual_k=original['root_residual_k'])
    except BaseException as e:row['failure']=type(e).__name__+': '+str(e);(root/(original['case']+'-traceback.txt')).write_text(traceback.format_exc())
    row['seconds']=time.monotonic()-start;rows.append(row);print(json.dumps(row),flush=True)
assert all(sha(source/n)==v for n,v in m.items());value=dict(scope='Native CUDA32 whole steps from original failed NumPy states quantized64-to32, normal raising retained and every returned step independently audited. Compare against explicitly unadopted NumPy material-event/smaller-Jacobian counterfactuals at10percent/near-zero absolute gates, Celsius soil temperature. Single-point comparisons have no instantaneous correlation/day/month/observational acceptance claim, and no JAX trajectory claim.',status='all-valid-and-within-numerical-gates' if all(r['status']=='valid-within-point-numerical-gates' for r in rows) else 'failed-or-incomplete',source_unchanged=True,rows=rows,seconds=time.monotonic()-begun);(root/'summary.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');raise SystemExit(0 if value['status']=='all-valid-and-within-numerical-gates' else 1)

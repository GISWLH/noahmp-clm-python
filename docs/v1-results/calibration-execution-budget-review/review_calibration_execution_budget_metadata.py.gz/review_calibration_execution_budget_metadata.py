"""Read-only stdlib metadata audit; never imports/runs a physical model."""
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/v1'
sha = lambda b: hashlib.sha256(b).hexdigest()
om = OUT / 'fluxnet-calibration-om-evidence.tar.gz'
nm = OUT / 'climatology-final-candidate-nm-source.tar.gz'
assert sha(om.read_bytes()) == '1581110dab18462127cb4baf54eef327de9bfd15eb3da72d3dc01670512ba7ac'
assert sha(nm.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
rows = defaultdict(list)
with tarfile.open(om) as archive:
    for m in archive.getmembers():
        p = Path(m.name)
        if m.isfile() and m.name.startswith('result/applied/') and p.suffix == '.json' and not p.stem.endswith('-receipt'):
            b = archive.extractfile(m).read()
            cfg = json.loads(b)
            rows[p.parent.name].append((m.name, cfg, sha(b)))
assert len(rows) == 23 and sum(map(len, rows.values())) == 184
original_cases = sorted(v[1]['case'] for v in rows['om-baseline'])
assert len(set(original_cases)) == 8
groups = defaultdict(list)
configurations = []
for candidate, values in sorted(rows.items()):
    assert len(values) == 8 and sorted(v[1]['case'] for v in values) == original_cases
    leaf = {json.dumps(v[1]['leaf_parameters'], sort_keys=True, separators=(',', ':')) for v in values}
    assert len(leaf) == 1
    for name, cfg, digest in values:
        assert cfg.get('canopy_structure') is None and cfg.get('canopy_capacity') is None
        assert cfg.get('soil_hydrology') is None
        assert cfg['site'] in ('CN-Cng', 'CN-Qia')
        configurations.append(dict(candidate=candidate, original_case=cfg['case'], member=name, sha256=digest))
    groups[leaf.pop()].append(candidate)
assert len(groups) == 19
five = next(v for v in groups.values() if len(v) == 5)
assert set(five) == {'om-baseline', 'om-oat-mr_b-low', 'om-oat-mr_b-high', 'om-oat-q10-low', 'om-oat-q10-high'}
source = []
with tarfile.open(nm) as archive:
    members = [m for m in archive.getmembers() if m.isfile()]
    for name in ('benchmarks/run_fluxnet_native.py', 'benchmarks/assess_clm_spinup.py', 'src/noahmp_clm/gpu/clm_bgc_column.py'):
        match = [m for m in members if m.name == name or m.name.endswith('/' + name)]
        assert len(match) == 1
        b = archive.extractfile(match[0]).read()
        assert b == (ROOT / name).read_bytes()
        source.append(dict(path=name, sha256=sha(b), byte_identical_to_frozen_nm=True))
result = dict(
    created_utc=datetime.now(timezone.utc).isoformat(),
    scope='Stdlib metadata/count/hash and workload arithmetic only. No model, numerical state/statistics, holdout prediction, remote job or parameter selection.',
    source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
    om_archive_sha256=sha(om.read_bytes()), source_files=source,
    actual_metadata=dict(candidates=23, sites=2, seeds=2, bgc_potential_mappings=2, columns=184,
                        native_state_arrays=16, unique_full_leaf_dictionaries=19, original_cases=original_cases),
    groups=[dict(leaf_sha256=sha(k.encode()), ball_berry_slope=json.loads(k)['ball_berry_slope'],
                 candidates=v, columns=8 * len(v)) for k, v in sorted(groups.items())],
    configurations=configurations,
    grouping_status=dict(default_candidate_batches=23, potential_batches_after_new_identity_adapter=19,
                         additional_required='Explicit unique native transport labels and bijective candidate/original-case binding; candidate controls and scorer/auditor binding review. Original configuration case/SHA unchanged.',
                         forty_column_runtime_or_memory_measured=False),
    budgets=dict(
        first_year_steps=17520, second_year_steps=17568,
        twenty_initial_cycles=dict(column_years=184 * 20, column_steps=184 * 20 * 17520,
                                   batch_years_23_groups=23 * 20, batch_years_19_groups=19 * 20),
        twenty_initial_plus_two_separate_training_years=dict(column_years=184 * 22,
            column_steps=184 * (21 * 17520 + 17568), batch_years_23_groups=23 * 22, batch_years_19_groups=19 * 22,
            status='Conditional cost envelope only; scoring-year relation to existing maximum20 replay protocol is not frozen.'),
        twenty_first_year_replays_including_eligible_training_year_plus_second_year=dict(column_years=184 * 21,
            column_steps=184 * (20 * 17520 + 17568), batch_years_23_groups=23 * 21, batch_years_19_groups=19 * 21,
            status='Alternative only if a predeclared eligibility rule permits first training year within20; no retrospective reuse declared here.'),
        two_training_years_only=dict(column_years=184 * 2, column_steps=184 * (17520 + 17568)),
        cold48_reference_column_steps_upper_bound=184 * 48,
        hundred_normal_cycles_plus_two_training_years=dict(column_years=184 * 102,
            column_steps=184 * (101 * 17520 + 17568), status='Cost illustration, not authorized or prepared execution.'),
        wallclock_eta=None, scientific_total_budget_frozen=False),
    root_decision_not_implementation='Four initialization/BGC families each weight1/4; all48 training cells required. OO implementation/freeze remains separate.',
    production_or_existing_controls_changed=False, model_or_pbs_started=False,
    code_sha256=sha(Path(__file__).read_bytes()))
destination = OUT / 'CALIBRATION_EXECUTION_BUDGET_REVIEW.json'
destination.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(metadata_verified=True, candidates=23, columns=184, possible_groups=19,
                     destination=str(destination), sha256=sha(destination.read_bytes())), ensure_ascii=False))

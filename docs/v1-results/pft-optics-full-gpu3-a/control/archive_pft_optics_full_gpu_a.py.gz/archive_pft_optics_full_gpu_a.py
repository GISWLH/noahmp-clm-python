from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-a';r=s/'full-bgc-a';d=json.loads((r/'exit.json').read_text());rec=json.loads((r/'receipt.json').read_text());assert d['passed'] and d['returncode']==0 and rec['counts']==dict(tests=3,failures=0,errors=0,skipped=0) and rec['source_unchanged'] and rec['passed'];a=b/'pft-optics-full-gpu3-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname='full-bgc-a/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['launch_pft_optics_full_gpu_a.py','control_pft_optics_full_gpu_a.py','archive_pft_optics_full_gpu_a.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

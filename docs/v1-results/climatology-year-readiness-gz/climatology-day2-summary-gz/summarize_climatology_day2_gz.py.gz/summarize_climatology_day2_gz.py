from pathlib import Path
import json,os
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-day2-summary-gz';q=b/'climatology-day2-audit-gy';d=json.loads((q/'receipt.json').read_text());assert (q/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and len(d['cases'])==12;cases=d['cases'];metrics={};daily={}
for key in cases[0]['all13_trace_metrics']:
    rows=[c['all13_trace_metrics'][key] for c in cases];metrics[key]=dict(maximum_absolute_difference=max(q['maximum_absolute_difference'] for q in rows),maximum_gate_ratio=max(q['maximum_gate_ratio'] for q in rows),minimum_defined_r=min([q['instantaneous_correlation'] for q in rows if q['instantaneous_correlation'] is not None],default=None))
for day in range(2):
    values={}
    for key in cases[0]['daily'][day]:
        rows=[c['daily'][day][key] for c in cases];relative=[abs(q['relative_bias_percent']) for q in rows if q['relative_bias_percent'] is not None];values[key]=dict(maximum_absolute_difference=max(q['absolute_difference'] for q in rows),maximum_absolute_nonzero_relative_bias_percent=max(relative) if relative else None)
    daily[str(day+1)]=values
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,source_manifest_sha256=d['source_manifest_sha256'],source_unchanged=d['source_unchanged'],actual12x96_independent=True,actual23_first_continued_fields_exact=True,raw_bgc_fields_per_step=d['day2_bgc_keys'],all13_trace_metrics=metrics,daily=daily,maximum_cumulative_m_h_c_n=np.max([q['maximum_cumulative_m_h_c_n'] for q in cases],axis=0).tolist(),maximum_rederived_day2_cn_residual=np.max([q['maximum_rederived_day2_cn_residual'] for q in cases],axis=0).tolist(),scope='All12currentmetadata/nonzeroclimatology fullfirst2days, actualGXcopyruntime0/independent798GY0. Originalphysics/inputs/gates/source unchanged, queuedoriginalyearprefixuntouched. All76BGCfieldsfirstrecordexact tofulloutput, all48CNchains/actualinputs verified; notfullyear/spinup/JAXsameprecision/observedscience.');(r/'summary.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out),flush=True)

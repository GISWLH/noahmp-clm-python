"""Independent NumPy complete-year reference segments; actualsuccessful48 only."""
from pathlib import Path
import fcntl,hashlib,json,os,pickle,sys,tarfile,time,traceback
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');root=b/'climatology-numpy-years-gt';name=os.environ['CLM_CASE'];start=int(os.environ['START_INDEX']);target=int(os.environ['END_INDEX']);plan=json.loads((root/'plan.json').read_text());case=next(q for q in plan['cases'] if q['case']==name);assert [start,target] in plan['segments'];r=root/name;from snapshot_numpy_history_gt import file_sha as sha;controls=json.loads((root/'controls.json').read_text());assert all(sha(root/n)==h for n,h in controls.items());lock=(r/'case.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);s=Path(os.environ['TMPDIR'])/'source';s.mkdir();a=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(a)=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest==plan['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==h for n,h in m.items());inputs=Path(os.environ['TMPDIR'])/'inputs';inputs.mkdir();a=b/'multisite-climatology-gm-inputs.tar.gz';assert sha(a)=='b33fba4f80f7cde8a7e127d27694dc7c2e370e7cd8a6b2142db211c86dccba0e'
with tarfile.open(a) as t:t.extractall(inputs,filter='data')
sys.path[:0]=[str(root),str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
from snapshot_numpy_history_gt import snapshot_generation
full=json.loads((b/'soil-stress-coupled-fl-cpu/full-receipt.json').read_text());assert full['returncode']==0 and full['counts']==dict(tests=1148,failures=0,errors=0,skipped=0) and full['source_unchanged'] and full['source_manifest_sha256']==manifest
# CPU442wrapper failure was downstream reference-cache bookkeeping, not pytest.
# Bind successful443 reference preparation explicitly, without relabelling442.
reference=Path(plan['reference_receipt_root']);assert (reference/'pbs-exit.txt').read_text().strip()=='0';ref=json.loads((reference/'reference-receipt.json').read_text());assert ref['source_manifest_sha256']==manifest and ref['source_unchanged'] and ref['all64_reference_calls_actually_executed']
lineage=json.loads((r/'lineage.json').read_text());trajectory=r/'trajectory';path=trajectory/'report.json';old=json.loads(path.read_text());assert old['status']=='running' and 'failure' not in old and old['steps_completed']==start and old['steps_requested']==17520 and old['source_sha256']==runner.source_hashes() and sha(inputs/case['configuration'])==old['configuration_sha256']==case['configuration_sha256']
if start==48:assert sha(path)==lineage['own48_report_sha256']
else:
    previous_start=next(pair[0] for pair in plan['segments'] if pair[1]==start);previous=json.loads((r/('segment-'+str(previous_start).zfill(6)+'-receipt.json')).read_text());assert (r/('segment-'+str(previous_start).zfill(6)+'-pbs-exit.txt')).read_text().strip()=='0' and previous['failure'] is None and previous['source_unchanged'] and previous['model_completed_segment'] and previous['steps_completed']==start and previous['report_sha256']==sha(path)
for k,h in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:assert sha(trajectory/old[k])==old[h]
saved=pickle.loads((trajectory/old['checkpoint_file']).read_bytes());assert len(saved)==7 and saved[-1]==start;original=runner.step_clm_enthalpy_column;checked=False;first_sha=None
def first(state,*args,**kwargs):
    global checked,first_sha
    if not checked:
        raw=pickle.dumps(state,protocol=5);assert raw==pickle.dumps(saved[0],protocol=5),'Originalresume changed the saved physical state';first_sha=hashlib.sha256(raw).hexdigest();checked=True
    return original(state,*args,**kwargs)
history=r/'generations/history.zip';history_snapshots=[snapshot_generation(trajectory,history)];original_json=runner.atomic_json
def observe_generation(path,value):
    original_json(path,value)
    if Path(path).resolve()==(trajectory/'report.json').resolve():history_snapshots.append(snapshot_generation(trajectory,history))
begun=time.monotonic();failure=None;model_completed=False;archival=None
try:
    runner.step_clm_enthalpy_column=first;runner.atomic_json=observe_generation;report=runner.run(inputs/case['input'],inputs/case['input_manifest'],inputs/case['configuration'],trajectory,resume=True,stop_after=target-start);assert checked and report['status']==('complete' if target==17520 else 'running') and report['steps_completed']==target and report['steps_requested']==17520 and report['source_unchanged'];model_completed=True
    archival=dict(history_zip='generations/history.zip',sha256=sha(history),generation_snapshots=history_snapshots,all_original_reports_states_traces_readback_sha_verified=True,current_three_files_retained=True)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/('segment-'+str(start).zfill(6)+'-traceback.txt')).write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:runner.step_clm_enthalpy_column=original;runner.atomic_json=original_json
report=json.loads(path.read_text());d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,case=name,start_index=start,target_index=target,failure=failure,model_completed_segment=model_completed,first_continued_state_exact=checked,first_state_protocol5_sha256=first_sha,original_checkpoint_tuple_fields=7,continued_start_report=old,status=report['status'],steps_completed=report['steps_completed'],steps_requested=report['steps_requested'],report_sha256=sha(path),source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),closed_generation_archival=archival,seconds=time.monotonic()-begun,scope='Actualcurrent579 complete17520yearrequest, independentNumPy reference, successfulown625climatologycold48 continuedonly. Sameallstate/forcing/config/source/initial/net/bounds/maximum/stepmax/index, explicitfirststatebytecheck, originalMHCN/impurity. Everyoriginalreport/state/traceincludingresumesaves losslesslyZIParchived/readbackSHAverifiedbeforeliteralclosedfileunlink; activegenerationuntouched, boundedhomeinodeuse. OnlyIOobserverchanges, originalphysicaltendencies/resume/ledgersunchanged. Per-caseafterokstopsanyfailure, othercasesindependent. Completedsegment isnotyear/spinup/observationalpass.');(r/('segment-'+str(start).zfill(6)+'-receipt.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='continued_start_report'}),flush=True);assert failure is None and d['source_unchanged'] and model_completed and d['steps_completed']==target

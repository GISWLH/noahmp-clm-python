"""LosslessNumPyhistory inoneZIP; retaincurrentgenerationandalloriginalreports."""
from pathlib import Path
import hashlib,json,os,re,zipfile

def file_sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def snapshot_generation(trajectory,history):
    trajectory=Path(trajectory).resolve(strict=True);history=Path(history).resolve();assert trajectory.name=='trajectory' and history.parent.name=='generations' and history.parent.parent==trajectory.parent and history.suffix=='.zip';pointer=trajectory/'report.json';raw=pointer.read_bytes();report=json.loads(raw);assert report['status'] in ['running','complete','failed'];index=report['steps_completed'];protected={report['checkpoint_file'],report['model_npz']};assert len(protected)==2;contents={'report.json':raw}
    for key,h in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
        p=trajectory/report[key];assert p.resolve(strict=True).parent==trajectory and not p.is_symlink();data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==report[h];contents[p.name]=data
    hashes={n:hashlib.sha256(data).hexdigest() for n,data in contents.items()};members={n:'blobs/'+hashes[n]+'/'+n for n in contents};record=dict(index=index,status=report['status'],report_sha256=hashes['report.json'],members=members,sha256=hashes,scope='Originalpointer/checkpoint/tracebytes, no reserializationofphysicalvalues or alteredidentity. SameindexresumesavesremainseparatesnapshotsbyactualreportSHA.');manifest=(json.dumps(record,indent=2)+'\n').encode();manifest_name='snapshots/'+hashes['report.json']+'.json';prune=[]
    with zipfile.ZipFile(history,'a',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
        names=set(z.namelist())
        for name,data in contents.items():
            member=members[name]
            if member not in names:z.writestr(member,data)
            assert hashlib.sha256(z.read(member)).hexdigest()==hashes[name]
        if manifest_name not in names:z.writestr(manifest_name,manifest)
        assert z.read(manifest_name)==manifest
        if report['status']!='failed':
            for p in sorted(trajectory.iterdir()):
                match=re.fullmatch(r'(?:state-([0-9]{7})\.pkl|trace-([0-9]{7})\.npz)',p.name)
                if not match or p.name in protected:continue
                assert int(match[1] or match[2])<index and p.resolve(strict=True).parent==trajectory and not p.is_symlink();digest=file_sha(p);member='blobs/'+digest+'/'+p.name;assert hashlib.sha256(z.read(member)).hexdigest()==digest,'ClosedgenerationmustalreadyexistlosslesslyinZIP';prune.append((p,digest,member))
    with history.open('rb') as f:os.fsync(f.fileno())
    with zipfile.ZipFile(history) as z:
        assert z.read(manifest_name)==manifest
        for name,member in members.items():assert hashlib.sha256(z.read(member)).hexdigest()==hashes[name]
        for _,digest,member in prune:assert hashlib.sha256(z.read(member)).hexdigest()==digest
        snapshots=sum(n.startswith('snapshots/') for n in z.namelist())
    assert pointer.read_bytes()==raw
    for p,digest,_ in prune:assert p.resolve(strict=True).parent==trajectory and p.name not in protected and file_sha(p)==digest
    for p,_,_ in prune:p.unlink()
    assert pointer.read_bytes()==raw and all(file_sha(trajectory/report[k])==report[h] for k,h in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]);return dict(active_index=index,status=report['status'],active_report_sha256=hashes['report.json'],snapshot_member=manifest_name,snapshots_retained=snapshots,closed_files_sha_verified_and_pruned=len(prune),history_bytes=history.stat().st_size,current_three_files_unchanged=True)

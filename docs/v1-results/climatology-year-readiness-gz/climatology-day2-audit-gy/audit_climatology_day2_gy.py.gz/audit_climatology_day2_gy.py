"""IndependentPBS day2GWobserver/continuation/BGCtrace/NumPy96 audit."""
from pathlib import Path
from datetime import datetime
import hashlib,io,json,os,pickle,sys,tarfile,zipfile
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-day2-audit-gy';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();device=Path(os.environ['TMPDIR'])/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(a)=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from fluxnet_deposition import DepositionSchedule
a=b/'climatology-year-preflight-gx-evidence.tar.gz';assert sha(a)==json.loads((r/'package.json').read_text())['device_archive_sha256']
with tarfile.open(a) as t:t.extractall(device,filter='data')
p=device/'preflight';exit_record=json.loads((p/'exit.json').read_text());receipt=json.loads((p/'year-receipt.json').read_text());assert exit_record['passed'] and exit_record['actual_parent_returncode']==0 and exit_record['receipt_sha256']==sha(p/'year-receipt.json') and receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete'] and receipt['continued_fields_exact']==23 and receipt['first_continued_step_captured'] and receipt['bgc_diagnostic_steps']==48 and len(receipt['bgc_diagnostic_chunks'])==1;report,saved,rows=native.read_generation(p/'trajectory');assert report['status']=='running' and report['steps_completed']==96 and report['steps_requested']==17520 and report['identity']['source_sha256']==native.source_hashes() and len(rows)==12 and len(saved)==23
with np.load(p/'validated-prefix-state.npz',allow_pickle=False) as z:prior=dict(z)
binding=json.loads((p/'year-prefix-binding.json').read_text());assert sha(p/'validated-prefix-state.npz')==binding['prefix_checkpoint_sha256'] and sha(p/'validated-prefix-report.json')==binding['prefix_batch_report_sha256'];prefix=json.loads((p/'validated-prefix-report.json').read_text());assert prefix['status']=='running' and prefix['steps_completed']==48
with np.load(p/'first-continued-step.npz',allow_pickle=False) as z:first=dict(z)
before=tuple(first['before'+str(k)] for k in range(16));after=tuple(first['after'+str(k)] for k in range(16))
for k,v in enumerate(before):assert v.dtype==prior['a'+str(k)].dtype and v.shape==prior['a'+str(k)].shape and v.tobytes()==prior['a'+str(k)].tobytes()
out={}
for key,value in first.items():
    if not key.startswith('output/'):continue
    parts=key.split('/')[1:];target=out
    for part in parts[:-1]:target=target.setdefault(part,{})
    target[parts[-1]]=value
incoming,residual,bound,tracer=native.audit_step(before,after,first['forcing'],first['deposition'],first['nitrogen'],out);assert np.all(abs(residual)<=first['recorded/bound']);np.testing.assert_allclose(bound,first['recorded/bound'],rtol=1e-12,atol=1e-12)
chunk=receipt['bgc_diagnostic_chunks'][0];assert chunk['first']==48 and chunk['end']==96;path=p/'year-bgc-diagnostics/steps-0000048-0000096.npz';assert sha(path)==chunk['sha256']
with np.load(path,allow_pickle=False) as z:bgc=dict(z)
assert all(v.shape[0]==48 and v.dtype.kind!='O' for v in bgc.values());bgc_keys=[k for k in bgc if k.startswith('bgc/')]
for key in bgc_keys:
    expected=first['output/biogeochemistry/'+key.removeprefix('bgc/')];assert bgc[key][0].dtype==expected.dtype and bgc[key][0].shape==expected.shape and bgc[key][0].tobytes()==expected.tobytes(),key
for key,expected in [('before_plant',before[11]),('before_soil_cn',before[13]),('after_plant',after[11]),('after_soil_cn',after[13])]:np.testing.assert_array_equal(bgc[key][0],expected)
np.testing.assert_array_equal(bgc['before_plant'][1:],bgc['after_plant'][:-1]);np.testing.assert_array_equal(bgc['before_soil_cn'][1:],bgc['after_soil_cn'][:-1]);np.testing.assert_array_equal(bgc['after_plant'][-1],saved['a11']);np.testing.assert_array_equal(bgc['after_soil_cn'][-1],saved['a13'])
loaded=native.load_batch(p/'inputs/batch.json');schedules=[DepositionSchedule(q['config']) for q in loaded]
for j in range(48):
    index=48+j;f=np.asarray([q['data']['forcing'][index] for q in loaded],np.float32);n=np.asarray([q.nitrogen_rate for q in schedules],np.float32)*f[:,0];dep=np.asarray([q.aerosol(datetime.strptime(str(c['data']['time_start'][index]),'%Y%m%d%H%M'),float(f[k,0])) for k,(c,q) in enumerate(zip(loaded,schedules))],np.float32);np.testing.assert_array_equal(bgc['forcing'][j],f);np.testing.assert_array_equal(bgc['nitrogen'][j],n);np.testing.assert_array_equal(bgc['deposition'][j],dep)
def totals_cn(plant,soil):return np.stack((plant[:,:,:3].astype(float).sum(-1)+plant[:,:,6].astype(float)+soil[:,:,:7].astype(float).sum(-1),plant[:,:,3:6].astype(float).sum(-1)+plant[:,:,7].astype(float)+soil[:,:,7:].astype(float).sum(-1)),axis=-1)
netc=bgc['bgc/allocation/gpp_gc_m2'].astype(float)-bgc['bgc/allocation/autotrophic_respiration_gc_m2'].astype(float)-bgc['bgc/decomposition/heterotrophic_respiration_gc_m2'].astype(float);cn_residual=totals_cn(bgc['after_plant'],bgc['after_soil_cn'])-totals_cn(bgc['before_plant'],bgc['before_soil_cn'])-np.stack((netc,bgc['nitrogen'].astype(float)),axis=-1)
specs={'h_wm2':(1.,0.,10.,1.),'le_wm2':(1.,0.,10.,1.),'gpp_gc_m2':(48.,0.,1.,.1),'nee_gc_m2':(48.,0.,1.,.1),'autotrophic_respiration_gc_m2':(48.,0.,1.,.1),'heterotrophic_respiration_gc_m2':(48.,0.,1.,.1),'et_mm':(48.,0.,.5,.05),'runoff_mm':(48.,0.,.5,.05),'tsoil_k':(1.,273.15,5.,.5),'smc_m3m3':(1.,0.,.02,.002),'liquid_m3m3':(1.,0.,.02,.002),'swe_m':(1.,0.,.001,.0001),'lai':(1.,0.,.1,.01)};cases=[];proof=json.loads((b/'climatology-numpy-years-gt/all12-pilot-proof.json').read_text())
for column,(descriptor,trace) in enumerate(rows):
    name=descriptor['case'];c=b/'climatology-numpy-years-gt'/name;pilot_path=c/'segment-000048-receipt.json';witness=next(q for q in proof['cases'] if q['case']==name);assert sha(pilot_path)==witness['pilot_receipt_sha256'] and witness['actual_pbs_exit']==0;pilot=json.loads(pilot_path.read_text());assert pilot['source_unchanged'] and pilot['source_manifest_sha256']==manifest and pilot['failure'] is None and pilot['steps_completed']==96
    with zipfile.ZipFile(c/'generations/history.zip') as z:
        snap=json.loads(z.read('snapshots/'+pilot['report_sha256']+'.json'));blobs={k:z.read(v) for k,v in snap['members'].items()};assert all(hashlib.sha256(blobs[k]).hexdigest()==h for k,h in snap['sha256'].items());reference=json.loads(blobs['report.json']);assert reference['steps_completed']==96 and reference['status']=='running' and reference['configuration_sha256']==descriptor['configuration_sha256'];state,*_rest=pickle.loads(blobs[reference['checkpoint_file']]);assert _rest[-1]==96
        with np.load(io.BytesIO(blobs[reference['model_npz']]),allow_pickle=False) as archive:ref=dict(archive)
    for key in ['time_start','time_end']:np.testing.assert_array_equal(trace[key],ref[key])
    error=trace['step_residual_m_h_c_n'].astype(float);limits=trace['step_bound_m_h_c_n'].astype(float);cumulative=trace['cumulative_residual_m_h_c_n'].astype(float);assert np.all(abs(error)<=limits) and np.all(abs(cumulative)<=np.cumsum(limits,axis=0)) and np.all(abs(cn_residual[:,column])<=limits[48:96,2:]);np.testing.assert_allclose(cn_residual[:,column],error[48:96,2:],rtol=1e-12,atol=1e-10);metrics={};failed=[]
    for key,(scale,offset,floor,absolute) in specs.items():
        actual=(trace[key].astype(float)-offset)*scale;expected=(ref[key].astype(float)-offset)*scale;difference=abs(actual-expected);limit=np.where(abs(expected)<=floor,absolute,.1*abs(expected));corr=float(np.corrcoef(actual.ravel(),expected.ravel())[0,1]) if actual.std()>0 and expected.std()>0 else None;passed=bool(np.all(difference<=limit))
        if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and float(np.ptp(expected))>absolute:passed=passed and corr is not None and corr>.85
        if not passed:failed.append(key)
        metrics[key]=dict(passed=passed,maximum_absolute_difference=float(difference.max()),maximum_gate_ratio=float((difference/limit).max()),instantaneous_correlation=corr,scale=scale,offset=offset)
    daily=[]
    for day in range(2):
        scores={};sel=slice(day*48,(day+1)*48)
        for key,floor,absolute in [('h_wm2',10.,1.),('le_wm2',10.,1.),('et_mm',.5,.05),('runoff_mm',.5,.05),('gpp_gc_m2',1.,.1),('nee_gc_m2',1.,.1)]:
            actual=float(trace[key][sel].mean() if key.endswith('wm2') else trace[key][sel].sum());expected=float(ref[key][sel].mean() if key.endswith('wm2') else ref[key][sel].sum());limit=absolute if abs(expected)<=floor else .1*abs(expected);passed=abs(actual-expected)<=limit
            if not passed:failed.append('day'+str(day)+'/'+key)
            scores[key]=dict(passed=passed,model=actual,reference=expected,absolute_difference=abs(actual-expected),relative_bias_percent=None if abs(expected)<=floor else 100.*(actual-expected)/abs(expected))
        daily.append(scores)
    plant=state.bgc_state.plant;soil=state.bgc_state.soil;plant_ref=np.r_[plant.carbon,plant.nitrogen,plant.reserve_carbon,plant.reserve_nitrogen];soil_ref=np.r_[soil.carbon,soil.nitrogen,soil.mineral_nitrogen];pools={}
    for key,actual,expected,floor,absolute in [('plant_C',saved['a11'][column,[0,1,2,6]],plant_ref[[0,1,2,6]],1.,.1),('plant_N',saved['a11'][column,[3,4,5,7]],plant_ref[[3,4,5,7]],.01,.001),('soil_C',saved['a13'][column,:7],soil_ref[:7],1.,.1),('soil_N',saved['a13'][column,7:],soil_ref[7:],.01,.001)]:
        delta=abs(actual-expected);limit=np.where(abs(expected)<=floor,absolute,.1*abs(expected));passed=bool(np.all(delta<=limit));pools[key]=dict(passed=passed,maximum_absolute_difference=float(delta.max()),maximum_gate_ratio=float((delta/limit).max()))
        if not passed:failed.append(key)
    record=dict(case=name,passed=not failed,failed_fields=failed,all13_trace_metrics=metrics,daily=daily,cn_pools=pools,maximum_cumulative_m_h_c_n=abs(cumulative).max(axis=0).tolist(),maximum_rederived_day2_cn_residual=abs(cn_residual[:,column]).max(axis=0).tolist(),all48_actual_day2_inputs_exact=True,all48_bgc_plant_soil_cn_chains_exact=True);cases.append(record)
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=all(q['passed'] for q in cases),source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),cases=cases,actual_continued_fields_exact=23,first_continued_independent_budget_maximum=abs(residual).max(axis=0).tolist(),day2_bgc_keys=len(bgc_keys),all_first_bgc_values_exact_to_full_step_output=True,scope='Independentcurrent96vsactualGTNumPy96, all12cases/all2days retained, original13traces/daily/CNpool10%/nearzero/r and MHCN/impurityfirststep gates. All23initialcarryfields authenticated; rawBGCday2 CNchains/feedthrough/firstrawoutput verified, all96recordedbudgetbounds checked. GWIOobserver exercisedoncopy, originalGOyearprefixunchanged. Notfullwaterstatechainreplayatall96steps, JAXsameprecision, full17520year, spinup orobservationalacceptance.');(r/'receipt.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(passed=out['passed'],cases=[dict(case=q['case'],passed=q['passed'],failed_fields=q['failed_fields']) for q in cases],day2_bgc_keys=out['day2_bgc_keys'])),flush=True);assert out['passed'] and out['source_unchanged']

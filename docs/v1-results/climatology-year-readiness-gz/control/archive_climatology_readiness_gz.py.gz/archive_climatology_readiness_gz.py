"""Metadata-onlycompletecurrentyearreadiness/projection; originalbytes kept."""
from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile,time,zipfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-numpy-years-gt';sha=lambda raw:hashlib.sha256(raw).hexdigest();proof=json.loads((r/'all12-pilot-proof.json').read_text());jobs=json.loads((r/'year-dispatch.json').read_text());assert proof['passed'] and len(proof['cases'])==12 and len(jobs['jobs'])==156;items={};snapshots=[]
for p in sorted(r.iterdir()):
    if p.is_file():items['cpu-pilots/control/'+p.name]=p.read_bytes()
for case in proof['cases']:
    name=case['case'];root=r/name;pilot_raw=(root/'segment-000048-receipt.json').read_bytes();pilot=json.loads(pilot_raw);assert sha(pilot_raw)==case['pilot_receipt_sha256'] and case['actual_pbs_exit']==0 and pilot['failure'] is None and pilot['source_unchanged'] and pilot['model_completed_segment'] and pilot['first_continued_state_exact'] and pilot['steps_completed']==96;assert (root/'segment-000048-pbs-exit.txt').read_text().strip()=='0'
    for p in sorted(root.iterdir()):
        if p.is_file() and (p.name.startswith('segment-000048') or p.name=='lineage.json'):items['cpu-pilots/cases/'+name+'/'+p.name]=p.read_bytes()
    records=[q['snapshot_member'] for q in pilot['closed_generation_archival']['generation_snapshots']];assert len(records)==4;data={}
    for attempt in range(5):
        try:
            with zipfile.ZipFile(root/'generations/history.zip') as z:
                for n in records:
                    raw=z.read(n);entry=json.loads(raw);data[n]=raw
                    for key,member in entry['members'].items():
                        value=z.read(member);assert sha(value)==entry['sha256'][key];data[member]=value
            break
        except zipfile.BadZipFile:
            if attempt==4:raise
            time.sleep(.2)
    target=io.BytesIO()
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for n,raw in sorted(data.items()):z.writestr(n,raw)
    raw=target.getvalue();items['cpu-pilots/cases/'+name+'/pilot-snapshots-projection.zip']=raw;projection=dict(original_receipt_history_zip_sha256=pilot['closed_generation_archival']['sha256'],rebuilt_pilot_subset_zip_sha256=sha(raw),four_original_snapshots=records,every_original_member_payload_byteexact=True,scope='Read-onlyprojectionfromcurrentlyappend-onlyhistoryZIP. ContainerisrebuiltnotoriginalpilotZIPhash; everyoriginal48/96report/state/tracepayloadSHAverifiedagainstoriginalsnapshotmanifest. Currentyearfilesnotmodified.');items['cpu-pilots/cases/'+name+'/projection.json']=(json.dumps(projection,indent=2)+'\n').encode();current_raw=(root/'trajectory/report.json').read_bytes();current=json.loads(current_raw);items['cpu-pilots/cases/'+name+'/current-report.json']=current_raw;active=None
    for row in [q for q in jobs['jobs'] if q['case']==name]:
        status=subprocess.run(['qstat','-f',row['pbs_job']],capture_output=True,text=True)
        if status.returncode==0 and re.search(r'^\s*job_state = R\s*$',status.stdout,re.M):active=row['pbs_job'];items['cpu-pilots/cases/'+name+'/actual-current-pbs.txt']=status.stdout.encode();break
    snapshots.append(dict(case=name,pilot_actual_exit=0,source_manifest_sha256=pilot['source_manifest_sha256'],current_saved_steps=current['steps_completed'],steps_requested=current['steps_requested'],status=current['status'],actual_running_pbs=active))
for name in ['climatology-day2-audit-gy','climatology-day2-summary-gz']:
    root=b/name;assert (root/'pbs-exit.txt').read_text().strip()=='0';items.update({name+'/'+p.name:p.read_bytes() for p in sorted(root.iterdir()) if p.is_file()})
d=json.loads((b/'climatology-day2-audit-gy/receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and len(d['cases'])==12 and all(q['passed'] for q in d['cases']);original=b/'climatology-year-preflight-gx-evidence.tar.gz';assert sha(original.read_bytes())=='c9c703432a67a4a66ae5d5a2b34f2e1b5cd1ec075a17b2f177b02b37d1c4e3c7';live=json.loads((b/'climatology-gw-live-gz.json').read_text());assert live['queue_actual_live'] and live['queued_year_prefix_still_original48'];items['queued-year/verified-live-snapshot.json']=(b/'climatology-gw-live-gz.json').read_bytes();items['control/'+Path(__file__).name]=Path(__file__).read_bytes();out=b/'climatology-year-readiness-gz-evidence.tar.gz';assert not out.exists();inventory=[]
with tarfile.open(out,'w:gz') as t:
    with tarfile.open(original) as source:
        for member in source:
            assert member.isfile();raw=source.extractfile(member).read();inventory.append(dict(path=member.name,sha256=sha(raw),bytes=len(raw)))
            if member.name.startswith('preflight/inputs/CN-') and member.name.endswith('.npz'):continue
            assert member.name not in items;t.addfile(member,io.BytesIO(raw))
    for n,raw in items.items():info=tarfile.TarInfo(n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    raw=(json.dumps(dict(current_cpu_years=snapshots,actual_gw_queue_live=True,original_GX_archive_sha256=sha(original.read_bytes()),all_original_GX_members=inventory,scope='Actual629-640all12continued96PBS0+156primaryyearsegments642-797/currentjobsverified; everyoriginalpilotreport/state/tracepayloadprojectedlosslessly. ActualGX12xday2worker0/798all12NumPy96audit0/799metrics0. GW2953298actuallylivewaitingGD, originalGO48unchanged. FullforcingrawNPZkeptinfrozenoriginalarchive; no full17520/year/spinup/JAXsameprecision/observationalacceptance.'),indent=2)+'\n').encode();info=tarfile.TarInfo('readiness-snapshot.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(out) as t:count=len(t.getnames());assert count==len(set(t.getnames()))
print(json.dumps(dict(name='climatology-year-readiness-gz',sha256=sha(out.read_bytes()),bytes=out.stat().st_size,artifacts=count,current_cpu_years=snapshots)),flush=True)

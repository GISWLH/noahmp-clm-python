from pathlib import Path
import hashlib,json
import numpy as np
r=Path('/home/lhwang/work/noahmp-v1/stem-station-precision-d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();data={}
for name in ['cuda32','jax32','jax32-primary']:
 d=json.loads((r/name/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and sha(r/name/'outputs.npz')==d['result']['output_sha256']
 with np.load(r/name/'outputs.npz',allow_pickle=False) as z:data[name]=dict(z)
a,b,repeat=(data[k] for k in ['cuda32','jax32','jax32-primary']);assert a.keys()==b.keys()==repeat.keys();deterministic=all(np.array_equal(b[k],repeat[k]) for k in b);rows=[];failed=[]
for key,x in a.items():
 y=b[key];delta=abs(x.astype(float)-y.astype(float));maximum=float(delta.max(initial=0.));equal=bool(np.array_equal(x,y));passed=equal if x.dtype.kind in 'iub' else bool(np.allclose(x,y,rtol=1e-6,atol=1e-6));row=dict(field=key,maximum_absolute=maximum,passed=passed,bitwise_equal=equal)
 if maximum:
  index=np.unravel_index(np.argmax(delta),delta.shape);row.update(index=list(map(int,index)),cuda=float(x[index]),jax=float(y[index]))
 rows.append(row)
 if not passed:failed.append(row)
d=dict(scope='Exact original504C second step after1 accepted interval, both original19 inputs bitwise identical. Original1e-6 all-fields comparison, independent per-backend original MHCN checks; additional JAX on primary input tests repeated arithmetic. No trajectory resume or gate relaxation.',fields=rows,failed=failed,jax_shadow_primary_outputs_bitwise_equal=deterministic,next19_bitwise_equal=all(np.array_equal(a['next'+str(k)],b['next'+str(k)]) for k in range(19)));(r/'comparison.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(fields=len(rows),failed=failed,nonzero=[v for v in rows if v['maximum_absolute']],jax_repeat_bitwise_equal=deterministic,next19_bitwise_equal=d['next19_bitwise_equal'])))

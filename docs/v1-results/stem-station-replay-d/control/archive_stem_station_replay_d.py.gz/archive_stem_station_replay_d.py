from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'stem-station-precision-d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();comparison=json.loads((r/'comparison.json').read_text());assert len(comparison['fields'])==380 and len(comparison['failed'])==22 and comparison['next19_bitwise_equal'] and comparison['jax_shadow_primary_outputs_bitwise_equal']
for name in ['cuda32','jax32','jax32-primary']:
 d=json.loads((r/name/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and sha(r/name/'outputs.npz')==d['result']['output_sha256']
a=b/'stem-station-replay-d-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [r/n for n in ['input.npz','binding.json','SOURCE_SHA256.json','launch.json','comparison.json']]:t.add(p,arcname=p.name,recursive=False)
 for name in ['cuda32','jax32','jax32-primary']:
  for p in sorted((r/name).iterdir()):t.add(p,arcname=name+'/'+p.name,recursive=False)
  t.add(r/(name+'.log'),arcname=name+'.log',recursive=False)
 for n in ['export_stem_station_precision_d.py','replay_stem_station_precision_d.py','launch_stem_station_precision_d.py','compare_stem_station_precision_d.py','archive_stem_station_replay_d.py']:t.add(b/n,arcname='control/'+n,recursive=False)
 # Preserve the invalid zero-index preparation as failed control history,
 # not as a numerical replay or evidence that its missing packet existed.
 old=b/'stem-station-precision-c'
 for p in sorted(old.rglob('*')):
  if p.is_file():t.add(p,arcname='failed-preparation-c/'+p.relative_to(old).as_posix(),recursive=False)
 for n in ['export_stem_station_precision_c.py','replay_stem_station_precision_c.py','launch_stem_station_precision_c.py']:t.add(b/n,arcname='failed-preparation-c/control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

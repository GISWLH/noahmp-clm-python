from pathlib import Path
import datetime,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';r=b/'stem-station-precision-d';env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'));assert not (r/'launch.json').exists();rows=[]
for name in ['cuda32','jax32','jax32-primary']:
 with (r/(name+'.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'replay_stem_station_precision_d.py'),name],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 rows.append(dict(backend=name,pid=p.pid))
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=rows,scope='Bounded exact failed second-step plus same-primary-input JAX replay on GPU0. Original failed new station trajectory stays stopped; GPU1 frozen502/493 tests unchanged. No gate/precision/physics change.');(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
from dataclasses import astuple
import hashlib,json,sys,tarfile
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';original=b/'stem-station-device-c';r=b/'stem-station-precision-c';r.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==504 and all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s/'src'),str(s/'tests'),str(s/'benchmarks')];import run_fluxnet_native as native
report,state,_=native.read_generation(original/'continuous');assert report['status']=='failed' and report['steps_completed']==0 and report['steps_requested']==4 and report['identity']['native_state_arrays']==19;cases=native.load_batch(original/'inputs/batch.json');index=0
forcing=np.asarray([c['data']['forcing'][index] for c in cases],np.float32);environment=np.asarray([c['data']['environment'][index] for c in cases],np.float32)
env,cal=native.pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],False) for c in cases],dtype=np.float32);schedules=[native.DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([v.nitrogen_rate for v in schedules],np.float32)*forcing[:,0];deposition=np.asarray([v.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,v) in enumerate(zip(cases,schedules))],np.float32);geometry=np.asarray([astuple(native.MOSTGeometry(**c['config']['most_geometry'])) for c in cases],np.float32)
payload={prefix+str(k):state[prefix+str(k)] for prefix in ['a','shadow'] for k in range(19)};payload.update(forcing=forcing,environment=environment,calendar_values=env,calendar_flags=cal,nitrogen=nitrogen,deposition=deposition,geometry=geometry);np.savez_compressed(r/'input.npz',**payload);equal=all(np.array_equal(state['a'+str(k)],state['shadow'+str(k)]) for k in range(19));assert equal
d=dict(scope='Original new504C failed native station first step,19-array primary and independent shadow cold states bitwise identical. Exact forcing/geometry/calendar/deposition exported, no failed step accepted or advanced.',source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(r/'input.npz'),leaf_parameters=cases[0]['config']['leaf_parameters'],initial19_bitwise_equal=equal,original_failure=report['failure']);(r/'binding.json').write_text(json.dumps(d,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
a=b/'stem-station-device-failure-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(original.rglob('*')):
  if p.is_file():t.add(p,arcname='original/'+p.relative_to(original).as_posix(),recursive=False)
 for p in r.iterdir():t.add(p,arcname='diagnostic-input/'+p.name,recursive=False)
 for n in ['run_stem_station_device_c.py','control_stem_station_device_c.py','launch_stem_station_device_c.py','export_stem_station_precision_c.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,input_sha256=sha(r/'input.npz'),initial19_bitwise_equal=equal)))

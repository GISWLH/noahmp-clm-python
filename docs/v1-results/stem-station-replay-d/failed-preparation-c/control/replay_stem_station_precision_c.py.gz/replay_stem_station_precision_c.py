from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';r=b/'stem-station-precision-c';name=sys.argv[1];out=r/name;out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());binding=json.loads((r/'binding.json').read_text());assert sha(r/'input.npz')==binding['input_sha256'];sys.path[:0]=[str(s/'src'),str(s/'tests'),str(s/'benchmarks')];import run_fluxnet_native as native
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
engine=native.Backend(name);prefix='a' if name=='cuda32' else 'shadow';arrays=tuple(engine.xp.asarray(np.ascontiguousarray(data[prefix+str(k)])) for k in range(19));arrays=engine.update_forcing(arrays,data['environment']);before=tuple(engine.host(v) for v in arrays);start=time.monotonic();failure=None;result=None;barriers=[]
try:
 device=engine.step(*arrays,data['forcing'],environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=native.LeafParameters(**binding['leaf_parameters']),return_surface=True);output=engine.host(device);after=tuple(engine.host(v) for v in native.next_station_arrays(arrays,device));flat={}
 def flatten(value,path=''):
  for key,v in value.items():
   if isinstance(v,dict):flatten(v,path+key+'/')
   else:flat[path+key]=np.asarray(v)
 flatten(output);flat.update({'next'+str(k):v for k,v in enumerate(after)});np.savez_compressed(out/'outputs.npz',**flat);_,residual,bound,_=native.audit_step(before,after,data['forcing'],data['deposition'],data['nitrogen'],output)
 if name=='cuda32':engine.xp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
 else:
  import jax
  jax.effects_barrier();barriers.append('jax-complete')
 result=dict(output_sha256=sha(out/'outputs.npz'),residual_m_h_c_n=residual.tolist(),original_bounds=bound.tolist())
except Exception as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
unchanged=all(sha(s/n)==v for n,v in m.items());value=dict(scope='Counterfactual exact original failed native station first step only. Per-backend original independent MHCN checks required, original1e-6 compare remains separate/unrelaxed; no original trajectory advancement. Interpreter atexit bypassed after receipt/barrier; normal shutdown unvalidated.',backend=name,failure=failure,result=result,source_unchanged=unchanged,device_barriers=barriers,seconds=time.monotonic()-start);native.atomic_json(out/'receipt.json',value);print(json.dumps(dict(backend=name,failure=failure,seconds=value['seconds'])),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged else 1)

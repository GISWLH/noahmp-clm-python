"""Postprocess all frozen height scenarios and the predeclared baselines."""
from pathlib import Path
import json,hashlib,subprocess,os
import numpy as np
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-fluxnet-evaluation-c';native=base/'p6-native-fluxnet-b';old=base/'p6-molten-snow-gpu-a'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((native/'SOURCE_SHA256.json').read_text())
assert all(sha(native/p)==h for p,h in source.items())
report=json.loads((native/'height-cuda-a/batch.json').read_text());assert report['status']=='complete' and report['steps_completed']==336
out=root/'results';out.mkdir(exist_ok=False)
exe='/home/lhwang/venvs/noahmp-phase3b/bin/python';env=os.environ.copy();env.update(PYTHONPATH='src:tests:benchmarks',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
cmd=[exe,'benchmarks/summarize_fluxnet_height_sensitivity.py','--root',str(native/'height-cuda-a'),'--cases',str(old/'inputs/configs/cases.json'),'--protocol',str(old/'profile_output/fluxnet-height-sensitivity-protocol.json'),'--output',str(out/'height-sensitivity-cuda32.json')]
subprocess.run(cmd,cwd=root,env=env,check=True)
sensitivity=json.loads((out/'height-sensitivity-cuda32.json').read_text());assert sensitivity['complete_cases']==27
summaries=[]
for site,case in [('CN-Cng','CN-Cng-tq6-w2'),('CN-Qia','CN-Qia-tq39.6-w39.6'),('CN-Cha','CN-Cha-tq61.8-w61.8')]:
    model=native/'height-cuda-a'/case;r=json.loads((model/'report.json').read_text())
    command=[exe,'benchmarks/evaluate_fluxnet_series.py','--model',str(model/r['model_npz']),'--model-manifest',str(model/'report.json'),
        '--observations',str(old/'inputs'/(site+'.npz')),'--observation-manifest',str(old/'inputs'/(site+'.json')),
        '--soil-operator',str(native/'soil-operators'/(site+'.json')),'--output',str(out/(site+'-baseline-observations.json'))]
    subprocess.run(command,cwd=root,env=env,check=True)
    e=json.loads((out/(site+'-baseline-observations.json')).read_text());metrics={}
    for field,instant in e['instantaneous'].items():
        days=[v[field]['metrics'] for v in e['daily'].values()];measured=[v for v in days if v['status']=='measured']
        rel=[v['relative_bias']*100 for v in measured if v['relative_bias'] is not None]
        near=[v['absolute_bias'] for v in measured if v['near_zero']]
        metrics[field]={'instantaneous_qc_or_partition_r':instant['metrics'].get('r'),
            'instantaneous_samples':instant['metrics']['n'],'daily_measured':len(measured),'daily_unmeasured':len(days)-len(measured),
            'daily_bias_within_predeclared_bound':sum(v['bias_pass'] for v in measured),
            'daily_relative_bias_percent_range':None if not rel else [min(rel),max(rel)],
            'near_zero_max_absolute_daily_bias':None if not near else max(near)}
    summaries.append({'site':site,'case':case,'metrics':metrics})
    print(site,json.dumps(metrics),flush=True)
ranges={}
for site in ['CN-Cng','CN-Qia','CN-Cha']:
    cases=[v for k,v in sensitivity['cases'].items() if k.startswith(site)]
    values={}
    for field in ['h_wm2','le_wm2','et_mm','gpp_gc_m2','nee_gc_m2','runoff_mm','lai']:
        rows=[c['comparison_to_baseline']['whole_window'][field] for c in cases]
        rel=[r['relative_bias']*100 for r in rows if r.get('relative_bias') is not None]
        values[field]={'absolute_signed_mean_response_range':[min(r['bias'] for r in rows),max(r['bias'] for r in rows)],
            'relative_percent_range':None if not rel else [min(rel),max(rel)],'units':rows[0]['units']}
    ranges[site]=values;print('sensitivity',site,json.dumps(values),flush=True)
result={'scope':'Seven-day cold-start height response and predeclared baseline observation comparison; nominal common soil/C3 parameters, no spinup/calibration, not site acceptance',
    'backend':'CUDA32','complete_cases':27,'steps_each':336,'column_steps':9072,
    'model_source_manifest_sha256':sha(native/'SOURCE_SHA256.json'),'evaluation_source_manifest_sha256':sha(root/'SOURCE_SHA256.json'),
    'instrument_sha256':sha(Path(__file__)),'batch_report_sha256':sha(native/'height-cuda-a/batch.json'),
    'seconds':report['seconds'],'maximum_cumulative_m_h_c_n':np.array(report['maximum_cumulative_residual_m_h_c_n']).max(0).tolist(),
    'minimum_cumulative_bounds_m_h_c_n':np.array(report['cumulative_numerical_bounds_m_h_c_n']).min(0).tolist(),
    'fixed_baseline_observation_summary':summaries,'height_response_ranges':ranges}
(out/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print('finished',result['seconds'],result['maximum_cumulative_m_h_c_n'],result['minimum_cumulative_bounds_m_h_c_n'])

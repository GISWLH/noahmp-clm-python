"""Read-only task process inventory and UUID metadata before unique RN launch."""
from pathlib import Path
import json
import os
import subprocess
import time

rows=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit() or int(p.name)==os.getpid():continue
    try:
        if p.stat().st_uid!=os.getuid():continue
        args=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if args and 'python' in args.split()[0] and ('noahmp' in args or 'drainage-pb' in args):
            rows.append(dict(pid=int(p.name),cmdline=args,stat=(p/'stat').read_text()))
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
r=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,memory.free','--format=csv,noheader'],capture_output=True,text=True)
print(json.dumps(dict(observed_unix=time.time(),live_task_python=rows,nvidia_smi_exit=r.returncode,stdout=r.stdout,stderr=r.stderr)))

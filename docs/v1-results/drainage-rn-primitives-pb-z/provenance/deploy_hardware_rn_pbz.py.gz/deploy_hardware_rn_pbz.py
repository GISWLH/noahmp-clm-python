"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'drainage-rn-primitives-pb-z-stage.tar.gz'
expected='3b35b289ddfffe7fb24671d0cb126626de8f0648905fb5823d0dce207f248293'
assert sha(stage.read_bytes())==expected
prelaunch=json.loads((BASE/'drainage-rn-primitives-pb-z-prelaunch.json').read_text(encoding='utf-8-sig'))
assert prelaunch['nvidia_smi_exit']==0 and prelaunch['live_task_python']==[]
target=BASE/'drainage-rn-primitives-pb-z-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'drainage-rn-primitives-pb-z-execution/launch_hardware_rn_pbz.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/clm-drainage-rn-primitives-pb-z && test ! -e /tmp/drainage-pb-s-pbz-20261026 && test ! -e /tmp/noahmp-drainage-rn-primitives-pb-z-stage.tar.gz && test ! -e /tmp/launch_hardware_rn_pbz.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-drainage-rn-primitives-pb-z-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_hardware_rn_pbz.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_hardware_rn_pbz.py --stage /tmp/noahmp-drainage-rn-primitives-pb-z-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('drainage-rn-primitives-pb-z-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('drainage-rn-primitives-pb-z-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

"""Freeze the root-reviewed RN diagnostic and mechanical single-worker stage."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'drainage-rn-primitives-pb-z-preparation'
EXEC=BASE/'drainage-rn-primitives-pb-z-execution'
OLD=BASE/'drainage-geometry-pb-v-execution'
sha=lambda x:hashlib.sha256(x).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    assert not EXEC.exists();EXEC.mkdir()
    assert sha((PREP/'CONTROLS_SHA256.json').read_bytes())=='ba7683da5573110983d3682e3867f5999fed98712612811a5cf5e9d13d72b2fe'
    ci=json.loads((PREP/'CONTROLS_SHA256.json').read_bytes());assert all(sha((PREP/n).read_bytes())==h for n,h in ci.items())
    binding=json.loads((PREP/'BINDINGS.json').read_bytes());diff=[]
    mapping={'run_geometry_parent_pbv.py':'run_hardware_rn_parent_pbz.py','control_geometry_pbv.py':'control_hardware_rn_pbz.py','launch_geometry_pbv.py':'launch_hardware_rn_pbz.py'}
    for old,new in mapping.items():
        raw=(OLD/old).read_bytes();updated=raw
        for before,after in ((b'contract_pbv',b'contract_rn'),(b'capture_geometry_pbv.py',b'capture_hardware_rn.py'),
            (b'run_geometry_parent_pbv.py',b'run_hardware_rn_parent_pbz.py'),(b'control_geometry_pbv.py',b'control_hardware_rn_pbz.py'),
            (b'/tmp/drainage-pb-s-pbv-',b'/tmp/drainage-pb-s-pbz-')):updated=updated.replace(before,after)
        compile(ast.parse(updated),new,'exec');(EXEC/new).write_bytes(updated)
        diff.extend(difflib.unified_diff(raw.decode().splitlines(True),updated.decode().splitlines(True),fromfile='PB-v/'+old,tofile='PB-z/'+new))
    policy=dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        source_archive_sha256=binding['source_archive_sha256'],source_manifest_sha256=binding['source_manifest_sha256'],
        evidence_archive_sha256=binding['evidence_archive_sha256'],root='/home/lhwang/work/noahmp-v1/clm-drainage-rn-primitives-pb-z',
        temporary='/tmp/drainage-pb-s-pbz-20261026',gpu_uuid='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',backend_order=['cuda'],
        maximum_worker_seconds=900,single_launch=True,automatic_retry=False,root_code_review_received=True,
        source_modified=False,CPU_physical_reference_calls=0,model_calls=0,scientific_acceptance=False)
    (EXEC/'EXECUTION_BINDINGS.json').write_bytes(encode(policy));(EXEC/'PB_V_TO_PB_Z.diff').write_text(''.join(diff),encoding='utf-8')
    (EXEC/'README.md').write_text('Mechanical PB-v lifecycle reuse: contract/entry/controller/parent names and fresh paths only.900s timeout and actual wait/kill-and-wait receipt handling retained. Only one CUDA child consumes both original CUDA/JAX recorded input groups. Root reviewed and authorized the frozen RN diagnostic; unique deployment requires current CUDA1 ownership check, no automatic retry.\n',encoding='utf-8')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}))
    files={}
    for root,prefix in ((PREP,'preparation'),(EXEC,'execution')):
        for p in root.iterdir():
            if p.is_file():files[prefix+'/'+p.name]=p.read_bytes()
    files['source.tar.gz']=(BASE/'clm-drainage-header-pb-t-source.tar.gz').read_bytes()
    files['prior-device.tar.gz']=(BASE/'drainage-geometry-pb-v-gpu-closed/gpu-result.tar.gz').read_bytes()
    assert sha(files['source.tar.gz'])==policy['source_archive_sha256'] and sha(files['prior-device.tar.gz'])==policy['evidence_archive_sha256']
    files['stage-inventory.json']=encode({n:sha(v) for n,v in sorted(files.items())})
    target=BASE/'drainage-rn-primitives-pb-z-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for n,v in sorted(files.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;tar.addfile(m,io.BytesIO(v))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==files
    record=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),stage_files=len(files),bytes=target.stat().st_size,
        preparation_manifest_sha256=policy['preparation_manifest_sha256'],execution_manifest_sha256=sha(files['execution/CONTROLS_SHA256.json']),
        source_archive_sha256=policy['source_archive_sha256'],prior_device_archive_sha256=policy['evidence_archive_sha256'],launched=False)
    (BASE/'drainage-rn-primitives-pb-z-stage-package.json').write_bytes(encode(record));print(json.dumps(record))

if __name__=='__main__':main()

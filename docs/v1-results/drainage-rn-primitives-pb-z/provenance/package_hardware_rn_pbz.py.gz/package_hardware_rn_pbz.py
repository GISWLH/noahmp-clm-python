"""Closed GPU-computed hardware-RN diagnostic flags; no local numeric decode."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,packet,sha

BASE=Path(__file__).resolve().parent
LABEL='drainage-rn-primitives-pb-z'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='3b35b289ddfffe7fb24671d0cb126626de8f0648905fb5823d0dce207f248293'
    si=json.loads(stage['stage-inventory.json']);assert len(stage)==16 and all(sha(stage[n])==h for n,h in si.items())
    raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes();gpu=files(raw)
    assert sha(raw)=='b6c6188ccecb61789b06d1d336914a0d8783d38418bb99589a78427f28e68ae6' and len(gpu)==13
    controller=json.loads(gpu['controller/controller-receipt.json']);parent=json.loads(gpu['cuda/device-parent-receipt.json'])
    capture=json.loads(gpu['cuda/device/capture-receipt.json']);meta=json.loads(gpu['cuda/device/result.json'])
    assert controller['completed'] and controller['stage_unchanged'] and [p['actual_parent_returncode'] for p in controller['actual_parents']]==[0]
    assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
    assert capture['capture_completed'] and capture['source_controls_prior_unchanged'] and capture['GPU_domain_valid']
    assert capture['hardware_reference_kernel_attempted']==capture['hardware_reference_kernel_returned']==1
    assert capture['CPU_physical_reference_calls']==capture['model_calls']==capture['phase_calls']==0
    assert '--ftz=false' in capture['actual_compile_options'] and capture['scientific_acceptance'] is False
    assert sha(gpu['cuda/device/ACTUAL-LOADED-RETURNED.cubin'])==capture['actual_loaded_cubin_sha256']
    verified=packet(gpu['cuda/device/result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
    assert meta['actual_device_barrier_complete'] and meta['input_echo_payloads_exact'] and meta['all_equality_flags_computed_inside_kernel']
    assert set(meta['own_process_gpu_uuids'])=={'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'}
    groups=[];words=meta['uint32_output_encoding'];fields=meta['component_fields']
    assert words['group_counts']==capture['group_counts_computed_inside_kernel'] and len(meta['groups'])==8
    for k,g in enumerate(meta['groups']):
        groups.append(dict(backend=g['backend'],case=g['case'],GPU_group_counts=words['group_counts'][k],
            actual_operand_false_flags=[dict(layer_zero_based=i,fields=[fields[j] for j,flag in enumerate(row) if flag==0]) for i,row in enumerate(words['actual_operand_equal'][k])],
            strict_chain_false_flags=[dict(layer_zero_based=i,fields=[fields[j] for j,flag in enumerate(row) if flag==0]) for i,row in enumerate(words['strict_equal'][k])]))
    readout=dict(actual_worker_returncode=0,actual_parent_returncode=0,actual_controller_OS_returncode=None,
        controller_seconds=controller['seconds'],parent_seconds=parent['seconds'],worker_seconds=capture['seconds'],
        hardware_reference_kernel_attempted=1,hardware_reference_kernel_returned=1,CPU_physical_reference_calls=0,model_calls=0,
        groups=groups,group_count_columns=meta['group_count_columns'],actual_compile_options=capture['actual_compile_options'],
        actual_loaded_cubin_sha256=capture['actual_loaded_cubin_sha256'],verified_opaque_arrays=verified,source_controls_prior_unchanged=True,
        all_flags_and_counts_computed_inside_kernel=True,EHPC_Fraction_audit_executed=False,scientific_acceptance=False,
        scope='Independent explicit CUDA RN add/mul/div hardware reference on original PB-v operands. All flags/counts are original kernel outputs, merely labeled here. Both constant and variable JAX divisions have own-operand mismatches; original CUDA groups have none. No original model, precision gate, physical gate or production source changes; Fraction final audit remains pending.')
    items={'executed-stage.tar.gz':stage_raw,'original-gpu-result.tar.gz':raw,
        'original-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(gpu.items())}),
        'readout.json':encode(readout),'original-kernel-output-metadata.json':gpu['cuda/device/result.json']}
    for n,v in stage.items():
        if n.startswith(('preparation/','execution/')):items[n]=v
    for p in (BASE/(LABEL+'-gpu-closed')).iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for n in (LABEL+'-stage-package.json',LABEL+'-gpu-deployment.json',LABEL+'-prelaunch.json',
        'prepare_hardware_rn_pbz.py','deploy_hardware_rn_pbz.py','read_hardware_rn_pbz.py','read_gpu_project_ownership_pbz.py','collect_hardware_rn_pbz.py',Path(__file__).name):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-progress-'):
        for p in BASE.glob(prefix+'*'):
            if p.is_file():items['deployment/'+p.name]=p.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;archive.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual PB-z CUDA1 hardware-RN worker/parent0,1 diagnostic kernel on32 rows; original GPU-generated bit/equality/count metadata. CUDA4groups zero mismatches, JAX constant/variable own-operand mismatches retained. No model/gate/source changes; independent Fraction audit pending.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

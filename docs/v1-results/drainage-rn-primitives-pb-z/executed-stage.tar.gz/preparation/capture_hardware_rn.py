"""Independent CUDA RN primitive diagnostic; host only transfers/encodes bytes."""
import argparse
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

from contract_rn import GPU,HERE,bound_evidence,controls,save,sha,source_identity

def main():
    p=argparse.ArgumentParser()
    for name in ('source','evidence','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--backend',choices=('cuda',),required=True);a=p.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert not a.output.exists();binding=json.loads((HERE/'BINDINGS.json').read_bytes());control_sha=controls()
    identity=source_identity(a.source,binding);data=bound_evidence(a.evidence,binding)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024
    a.output.mkdir();record=dict(capture_completed=False,scientific_acceptance=False,backend='cuda',gpu_uuid=GPU,pid=os.getpid(),
        **identity,controls_manifest_sha256=control_sha,hardware_reference_kernel_attempted=0,hardware_reference_kernel_returned=0,
        CPU_physical_reference_calls=0,model_calls=0,phase_calls=0,original_input_groups=8,source_of_inputs='Closed PB-v actual CUDA/JAX geometry packets')
    started=time.monotonic()
    try:
        import numpy as np  # Original packet loading/reordering and output encoding only.
        import cupy as cp
        from cupy.cuda import compiler as cc
        from cupy.cuda import function as cf
        assert cp.cuda.runtime.getDeviceCount()==1;cp.cuda.Device(0).use();cp.cuda.runtime.free(0)
        inputs=[]
        for row in binding['groups']:
            prefix=row['backend']+'/device/'+row['case']+'/'
            meta=json.loads(data[prefix+'result.json'])
            with np.load(io.BytesIO(data[prefix+'result.npz']),allow_pickle=False) as store:
                values={key:store[key].copy() for key in ('input.phase_cells','input.parameters','context.components')}
            for key,v in values.items():
                desc=meta['arrays'][key]
                assert (v.dtype.str,list(v.shape),sha(v.tobytes()))==(desc['dtype'],desc['shape'],desc['c_order_sha256'])
            inputs.append(values)
        # Stack is opaque packet assembly, without host model arithmetic.
        host_inputs={key:np.concatenate([v[key] for v in inputs],axis=0) for key in inputs[0]}
        device={key:cp.asarray(v) for key,v in host_inputs.items()}
        assert device['input.phase_cells'].shape==(8,4,6) and device['input.parameters'].shape==(8,12) and device['context.components'].shape==(8,4,9)
        arch=cp.cuda.Device(0).compute_capability
        options=('--std=c++14','--fmad=false','--prec-div=true','--prec-sqrt=true','--ftz=false',
            '-arch=sm_'+str(arch),'--device-as-default-execution-space')
        code=(HERE/'rn_geometry_probe.cu').read_bytes()
        # Deliberately bypass RawModule's cache helper, which appends -ftz=true.
        # The independent reference explicitly preserves IEEE subnormals.
        program=cc._NVRTCProgram(code.decode(),name='rn_geometry_probe.cu',method='cubin')
        cubin,mapping=program.compile(options);(a.output/'ACTUAL-LOADED-RETURNED.cubin').write_bytes(cubin)
        module=cf.Module();module.load(cubin);kernel=module.get_function('rn_geometry_probe')
        outputs={n:cp.empty((8,4,9),cp.uint32) for n in ('observed_bits','strict_rn_bits','actual_operand_rn_bits','strict_equal','actual_operand_equal')}
        outputs['valid_rows']=cp.empty((8,4),cp.uint32);outputs['group_counts']=cp.zeros((8,3),cp.uint32)
        record['hardware_reference_kernel_attempted']+=1
        kernel((1,),(128,),tuple(device[n] for n in ('input.phase_cells','input.parameters','context.components'))+
            tuple(outputs[n] for n in ('observed_bits','strict_rn_bits','actual_operand_rn_bits','strict_equal','actual_operand_equal','valid_rows','group_counts'))+(np.int32(8),))
        cp.cuda.get_current_stream().synchronize();record['hardware_reference_kernel_returned']+=1
        valid=bool(cp.all(outputs['valid_rows']==1))
        flat={**{n:cp.asnumpy(v) for n,v in device.items()},**{n:cp.asnumpy(v) for n,v in outputs.items()}}
        for key,v in host_inputs.items():assert sha(flat[key].tobytes())==sha(v.tobytes())
        np.savez(a.output/'result.npz',**flat)
        apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True)
        own=[line.split(',')[1].strip() for line in apps.splitlines() if line.split(',')[0].strip()==str(os.getpid())]
        assert own and set(own)=={GPU}
        descriptors={n:dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes())) for n,v in flat.items()}
        save(a.output/'result.json',dict(npz_sha256=sha((a.output/'result.npz').read_bytes()),arrays=descriptors,
            groups=binding['groups'],component_fields=binding['component_fields'],actual_device_barrier_complete=True,own_process_gpu_uuids=own,
            uint32_output_encoding={n:v.tolist() for n,v in flat.items() if n in outputs},
            group_count_columns=['strict_chain_mismatches','actual_operand_mismatches','invalid_rows'],GPU_domain_valid=valid,
            input_echo_payloads_exact=True,all_equality_flags_computed_inside_kernel=True))
        record.update(capture_completed=valid,GPU_domain_valid=valid,actual_loaded_cubin_sha256=sha(cubin),actual_compile_options=options,
            actual_source_sha256=sha(code),CuPy_version=cp.__version__,compiler_implementation_sha256=sha(Path(cc.__file__).read_bytes()),
            group_counts_computed_inside_kernel=flat['group_counts'].tolist(),reference_kind='Explicit hardware RN intrinsics; independent Fraction audit still pending')
    except BaseException:
        record['error']=traceback.format_exc();(a.output/'failure.txt').write_text(record['error'])
    finally:
        try:
            assert controls()==control_sha and source_identity(a.source,binding)==identity
            bound_evidence(a.evidence,binding);record['source_controls_prior_unchanged']=True
        except BaseException:
            record['identity_error']=traceback.format_exc();record['source_controls_prior_unchanged']=False;record['capture_completed']=False
        record['seconds']=time.monotonic()-started;save(a.output/'capture-receipt.json',record)
    return 0 if record['capture_completed'] else 1

if __name__=='__main__':raise SystemExit(main())

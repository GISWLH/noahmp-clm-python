# HRLDAS LQ 三站年度只读状态与耗时估计

快照 UTC：2026-10-25T06:51:44.560829+00:00。数据来自 EHPC 原 jobs.json、qstat -xf、append_journal_lp.Journal 和 compute002 作业 session 的只读 ps。未运行物理、解码数组、提交或修改作业。

| 站点 | 最新实际 F0 段 | 已成功步数 / 天 | 当前作业 | 最近480步实际耗时 | 估计剩余计算时间 |
|---|---|---:|---|---:|---:|
| CN-Qia | 1423.manager，912→1392 | 1392 / 29 | 1424.manager R，1392→1872 | 4502.793 s | 49.02 h（41.52–56.52 h） |
| CN-Cha | 1468.manager，4752→5232 | 5232 / 109 | 1469.manager R，5232→5712 | 1128.777 s | 8.28 h（7.90–9.01 h） |
| CN-HaM | 1502.manager，3312→3792 | 3792 / 79 | 1503.manager R，3792→4272 | 1710.493 s | 13.86 h（13.36–14.34 h） |

运行中的三个分段均计 **0 步通过**。同一作业 session 的 Python 进程实际存在并处于 R：Qia PID 203356、Cha PID 207689、HaM PID 206556。Qia/Cha/HaM 当前 qstat 累计墙钟分别为 1804/442/826 秒；ps 获取较晚且调度器资源字段有刷新间隔，两个读数不当成同时刻精确计时。

通过证据：逐站仅计连续 actual F0 段；核对原 receipt 的请求/实际停止位置、failure=null、source_unchanged、首步全状态 exact；逐段父 F0、原7字段种子检查点 SHA、最终 report/checkpoint/trace SHA 均匹配。读取原 journal 时校验每帧完整性与 SHA；没有对 pickle/NPZ 数值做反序列化。JN 源身份仍为 e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5，本状态不重标为 NM。

估计方法：Qia 用最近2个、Cha/HaM 用最近3个实际 F0 完整480步分段的秒/步；中位数给点估计，近期最小/最大速度给外推范围，仅扣除当前在跑段已用墙钟。此范围是样本速度范围，不是置信区间，也不保证全年后续物理成本保持不变。估计不含未来排队、调度收尾和最终年度审计；后续物理迭代成本变化可使实际时间超出范围。三站并行，当前由 Qia 限制总体完成时间，约49小时的点估计不是发布日期。

最终年度审计 1536.manager 仍为 H（系统依赖保持），等待 1457.manager、1494.manager、1531.manager 全部 afterok。没有将排队、单段成功或年度运行等同于观测/科学验收。

JSON证据：`hrldas-lq-status-wp.json`，SHA256 `96fb6f45a284e0c05d45adf1d2cc2aadfd9fe94c67203f941fad43827ae4a15d`。包含最新成功回执、连续分段耗时与哈希、当前真实进程、各待跑作业状态、关键原 qstat 全文及估计参数。读取脚本：`read_hrldas_lq_status_wp.py`，SSH stdin 在 EHPC 执行，实际退出0；本机只汇总该元数据。

"""Read-only pytest report observer; never changes fixture or test outcomes."""
from pathlib import Path
import json
import os

REPORTS = []


def pytest_runtest_logreport(report):
    head, suffix = report.nodeid.split('::', 1)
    REPORTS.append(dict(node=Path(head).name + '::' + suffix, when=report.when,
                        outcome=report.outcome, longrepr=str(report.longrepr) if report.failed else None))


def pytest_sessionfinish(session, exitstatus):
    path = Path(os.environ['NF_PHASE_RECEIPT'])
    with path.open('x') as stream:
        json.dump(dict(pytest_exitstatus=int(exitstatus), reports=REPORTS), stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

"""Archive completed NF evidence after actual negative1 and positive0 only."""
from pathlib import Path
import hashlib
import json
import os
import tarfile

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE / 'surface-root-permanent-nf'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = json.loads((ROOT / 'exit.json').read_text())
assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
assert [r['actual_parent_returncode'] for r in terminal['records']] == [1, 0]
assert [r['physical_test_passed'] for r in terminal['records']] == [False, True]
pid = json.loads((ROOT / 'launch.json').read_text())['pid']
process_stat = Path('/proc') / str(pid) / 'stat'
assert not process_stat.exists() or process_stat.read_text().rsplit(')', 1)[1].split()[0] == 'Z'
provenance = BASE / 'surface-root-permanent-nf-historical-negative-controls.json'
assert sha(provenance) == '94c97b83b6330e538e93555d358f3e67debac3c0de0af54de651c7bdb76e5623'
(ROOT / 'historical-negative-controls.json').write_bytes(provenance.read_bytes())
(ROOT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
plan = json.loads((ROOT / 'plan.json').read_text())
for variant, row in plan['variants'].items():
    source = Path(row['source'])
    manifest_path = source / 'SOURCE_SHA256.json'
    assert sha(manifest_path) == row['source_manifest_sha256']
    manifest = json.loads(manifest_path.read_text())
    assert len(manifest) == 584 and all(sha(source / n) == h for n, h in manifest.items())
    assert json.loads((ROOT / variant / 'collection-actual-exit.json').read_text())['actual_parent_returncode'] == 0
    audit = json.loads((ROOT / variant / 'audit.json').read_text())
    assert audit['source_manifest_sha256'] == row['source_manifest_sha256']
files = sorted(p for p in ROOT.rglob('*') if p.is_file())
assert all(not p.is_symlink() for p in files)
hashes = {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
archive = BASE / 'surface-root-permanent-nf-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for path in files:
        tf.add(path, arcname=path.relative_to(ROOT).as_posix(), recursive=False)
assert hashes == {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
with tarfile.open(archive) as tf:
    assert set(tf.getnames()) == set(hashes)
    assert all(hashlib.sha256(tf.extractfile(n).read()).hexdigest() == h for n, h in hashes.items())
package = dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
               artifact_details={n: dict(sha256=h, bytes=(ROOT / n).stat().st_size) for n, h in hashes.items()},
               artifacts=len(hashes), actual_worker_parent_codes=[1, 0],
               original_negative_failure_preserved=True,
               source_manifests={v: p['source_manifest_sha256'] for v, p in plan['variants'].items()},
               scope=plan['scope'])
path = BASE / 'surface-root-permanent-nf-package.json'
with path.open('x') as stream:
    json.dump(package, stream, indent=2)
    stream.write('\n')
    stream.flush()
    os.fsync(stream.fileno())
print(json.dumps({k: v for k, v in package.items() if k != 'artifact_details'}), flush=True)

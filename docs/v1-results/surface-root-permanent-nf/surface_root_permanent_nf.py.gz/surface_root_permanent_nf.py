"""Frozen JN+fixture negative control, followed by ML4+same-fixture regression.

All numerical execution is on physical xuanze CUDA1. The original pytest
worker and resource guard are copied byte-for-byte. No NumPy forward reference
is recalculated; the test consumes the independently exported MI1537 fixture.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import runpy
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE / 'surface-root-permanent-nf'
TMP = Path('/tmp/noahmp-surface-root-permanent-nf')
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
ARCHIVE = '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
PARENT = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
ML = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
JO = '522be9c62aa9aa6cad64d4e614ac20f4d221f4cb90bea1deb9ecb63e9ad7b658'
WORKER = '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
GUARD = '4744d25ffde851c942816edf4e7078ce2179b48faa2fdb7c08d0b05100f4bd58'
CHANGES = {
    'src/noahmp_clm/gpu/snow_evolution.py': 'f4724a3462d66caa8c4b93e20ca0022dabf6ed62cee9209de71c7ef4faeee297',
    'src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu': 'd8a7dcee2eb6a2243fd76fff26e65fe37b0509d0d011424918b1292a07705840',
    'src/noahmp_clm/gpu/canopy_surface.py': '4836ed4306c4d13c91e3c4860b738fc671a41293a70a1e6815459211cdf0f92a',
    'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu': 'a21741d4a4225cd7f4b132cb327da3f575e413d76e983970db000aa5aff06139',
}
TEST = 'test_gpu_surface_root_contraction.py'
NODE = TEST + '::test_actual_cng_bounded_surface_root_original_gates'
FAILURE = 'CUDA layered phase surface failed; inspect with raise_on_failure=False'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    temp = path.with_name(path.name + '.tmp')
    with temp.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def verify(source, digest):
    path = source / 'SOURCE_SHA256.json'
    manifest = json.loads(path.read_text())
    return (sha(path) == digest and len(manifest) == 584
            and all(sha(source / name) == value for name, value in manifest.items()))


def environment(variant, source):
    env = os.environ.copy()
    for key in ['LD_LIBRARY_PATH', 'PYTEST_PLUGINS']:
        env.pop(key, None)
    cache = TMP / variant
    env.update(PYTHONPATH=':'.join(map(str, [ROOT, source, source / 'src', source / 'tests', source / 'benchmarks'])),
               PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU,
               CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda',
               JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false',
               JAX_COMPILATION_CACHE_DIR=str(cache / 'jax-cache'), CUPY_CACHE_DIR=str(cache / 'cupy-cache'),
               CUDA_CACHE_PATH=str(cache / 'cuda-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
               NOAHMP_REQUIRE_GPU='1', NF_PHASE_RECEIPT=str(ROOT / variant / 'phases.json'))
    return env


def ready_resources(stage):
    while True:
        gpu_line = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=uuid,memory.free',
                                            '--format=csv,noheader,nounits'], text=True).strip()
        uuid, free = [v.strip() for v in gpu_line.split(',')]
        assert uuid == GPU
        memory = int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines()
                          if v.startswith('MemAvailable:')))
        value = dict(stage=stage, physical_gpu_index=1, physical_gpu_uuid=uuid,
                     gpu_free_mib=int(free), host_available_kib=memory,
                     utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if int(free) > 8192 and memory > 32 * 1024 * 1024:
            return value
        write(ROOT / 'waiting-resource.json', value)
        time.sleep(20.)


def prepare():
    assert not ROOT.exists() and not TMP.exists(), 'Immutable one-shot attempt, never overwrite'
    archive = BASE / 'clm-ballberry-jn-source.tar.gz'
    bundle = BASE / 'surface-root-permanent-nf-additions.tar.gz'
    spec_path = BASE / 'surface-root-permanent-nf-spec.json'
    spec = json.loads(spec_path.read_text())
    assert sha(archive) == ARCHIVE and spec['parent_manifest_sha256'] == PARENT
    assert sha(bundle) == spec['additions_archive_sha256']
    patch_path = BASE / 'surface-root-ml-patch.json'
    patch = json.loads(patch_path.read_text())
    assert patch['parent_source_manifest_sha256'] == PARENT and set(patch['changes']) == set(CHANGES)
    original_collection = BASE / 'ballberry-jo-full-gpu/collection.json'
    assert sha(original_collection) == JO
    generic = BASE / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
    guard = BASE / 'bounded_cache_guard_gd.py'
    assert sha(generic) == WORKER and sha(guard) == GUARD
    controls = [Path(__file__), BASE / 'surface_root_phases_nf.py']
    assert all(b'\r\n' not in v.read_bytes() for v in controls)
    ROOT.mkdir()
    TMP.mkdir()
    for path in controls + [generic, guard, spec_path, patch_path, bundle]:
        (ROOT / path.name).write_bytes(path.read_bytes())
    (ROOT / 'original-JO-collection.json').write_bytes(original_collection.read_bytes())
    with tarfile.open(bundle) as tf:
        assert set(tf.getnames()) == set(spec['additions_sha256'])
    plans = {}
    for variant in ['negative', 'positive']:
        output = ROOT / variant
        output.mkdir()
        source = TMP / variant / 'source'
        source.mkdir(parents=True)
        with tarfile.open(archive) as tf:
            tf.extractall(source, filter='data')
        manifest_path = source / 'SOURCE_SHA256.json'
        assert sha(manifest_path) == PARENT
        parent = json.loads(manifest_path.read_text())
        assert len(parent) == 581 and all(sha(source / n) == h for n, h in parent.items())
        (output / 'PARENT_SOURCE_SHA256.json').write_bytes(manifest_path.read_bytes())
        derived = dict(parent)
        if variant == 'positive':
            for name, change in patch['changes'].items():
                assert change['before_sha256'] == parent[name]
                (source / name).write_text(change['after_text'])
                assert sha(source / name) == change['after_sha256'] == CHANGES[name]
                derived[name] = CHANGES[name]
            manifest_path.write_text(json.dumps(derived, indent=2) + '\n')
            assert sha(manifest_path) == ML
            (output / 'ML_SOURCE_SHA256.json').write_bytes(manifest_path.read_bytes())
        with tarfile.open(bundle) as tf:
            tf.extractall(source, filter='data')
        for name, digest in spec['additions_sha256'].items():
            assert name not in parent and sha(source / name) == digest
            derived[name] = digest
        manifest_path.write_text(json.dumps(derived, indent=2) + '\n')
        digest = spec['derived_manifest_sha256'][variant]
        assert verify(source, digest)
        assert {n for n in parent if sha(source / n) != parent[n]} == (set(CHANGES) if variant == 'positive' else set())
        (output / 'SOURCE_SHA256.json').write_bytes(manifest_path.read_bytes())
        write(output / 'expected.json', [NODE])
        plans[variant] = dict(source=str(source), source_manifest_sha256=digest, source_files=584)
    control_hashes = {p.name: sha(ROOT / p.name) for p in controls + [generic, guard]}
    plan = dict(variants=plans, controls_sha256=control_hashes, additions_sha256=spec['additions_sha256'],
                parent_manifest_sha256=PARENT, ml_manifest_sha256=ML,
                scope='Same permanent regression, all12 original inputs/345 fields/original hard budgets. '
                      'JN negative remains physical failure. ML positive must pass. Collection is not full-suite execution credit.')
    write(ROOT / 'plan.json', plan)
    with (ROOT / 'controller.log').open('x') as log:
        process = subprocess.Popen([sys.executable, '-u', str(ROOT / Path(__file__).name), 'control'],
                                   cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
    launch = dict(pid=process.pid, physical_gpu_index=1, physical_gpu_uuid=GPU,
                  utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **plan)
    write(ROOT / 'launch.json', launch)
    print(json.dumps(launch), flush=True)


def collect(variant, plan):
    source = Path(plan['variants'][variant]['source'])
    digest = plan['variants'][variant]['source_manifest_sha256']
    assert verify(source, digest)
    import pytest
    nodes = []
    class Capture:
        def pytest_collection_finish(self, session):
            nodes.extend(item.nodeid for item in session.items)
    code = int(pytest.main(['--collect-only', '-q', 'tests'], plugins=[Capture()]))
    barriers = []
    for name in ['jax', 'cupy']:
        if name in sys.modules:
            if name == 'jax':
                sys.modules[name].effects_barrier()
            else:
                sys.modules[name].cuda.runtime.deviceSynchronize()
            barriers.append(dict(backend=name, status='complete'))
    original = json.loads((ROOT / 'original-JO-collection.json').read_text())['nodes']
    gpu = [n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu', 'test_jax', 'test_cuda'))]
    unchanged = verify(source, digest)
    exact = set(nodes) == set(original) | {'tests/' + NODE}
    passed = code == 0 and len(nodes) == len(set(nodes)) == 1564 and len(gpu) == 408 and exact and unchanged
    write(ROOT / variant / 'collection.json', dict(passed=passed, returncode=code, nodes=nodes,
          total_count=len(nodes), gpu_count=len(gpu), cpu_count=len(nodes)-len(gpu),
          original_nodes_retained_exact=exact, source_manifest_sha256=digest,
          source_unchanged=unchanged, device_barriers=barriers, scope='Collection only, no numerical execution credit.'))
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0 if passed else 71)


def worker(variant, plan):
    source = Path(plan['variants'][variant]['source'])
    assert verify(source, plan['variants'][variant]['source_manifest_sha256'])
    assert sha(ROOT / 'run_pytest_worker_a.py') == WORKER
    assert sha(ROOT / 'bounded_cache_guard_gd.py') == GUARD
    os.environ['PYTEST_PLUGINS'] = 'bounded_cache_guard_gd,surface_root_phases_nf'
    out = ROOT / variant
    sys.argv = ['run_pytest_worker_a.py', '--source', str(source), '--test-file', str(source / 'tests' / TEST),
                '--expected', str(out / 'expected.json'), '--receipt', str(out / 'receipt.json'),
                '--xml', str(out / 'junit.xml')]
    runpy.run_path(str(ROOT / 'run_pytest_worker_a.py'), run_name='__main__')


def run_child(mode, variant, plan):
    source = Path(plan['variants'][variant]['source'])
    resources = ready_resources(mode + ':' + variant)
    assert verify(source, plan['variants'][variant]['source_manifest_sha256'])
    out = ROOT / variant
    start = time.monotonic()
    with (out / (mode + '.log')).open('x') as log:
        process = subprocess.Popen([sys.executable, '-u', str(ROOT / Path(__file__).name), mode, variant],
                                   cwd=source, env=environment(variant, source), stdout=log, stderr=subprocess.STDOUT)
    write(ROOT / 'progress.json', dict(stage=mode, variant=variant, pid=process.pid, resources=resources))
    code = process.wait()
    row = dict(mode=mode, variant=variant, pid=process.pid, actual_parent_returncode=code,
               seconds=time.monotonic()-start, resources=resources)
    write(out / (mode + '-actual-exit.json'), row)
    print(json.dumps(row), flush=True)
    return row


def audit_worker(variant, actual, plan):
    out = ROOT / variant
    receipt = json.loads((out / 'receipt.json').read_text())
    phases = json.loads((out / 'phases.json').read_text())
    source = Path(plan['variants'][variant]['source'])
    expected_code = 1 if variant == 'negative' else 0
    assert actual['actual_parent_returncode'] == receipt['worker_exitcode'] == receipt['pytest_returncode'] == expected_code
    assert receipt['errors'] == [] and receipt['node_coverage_exact'] and receipt['nodes'] == [NODE]
    assert receipt['source_files'] == 584 and receipt['source_unchanged'] and verify(source, receipt['source_manifest_sha256'])
    assert receipt['source_manifest_sha256'] == plan['variants'][variant]['source_manifest_sha256']
    assert receipt['worker_sha256'] == WORKER and receipt['test_sha256'] == plan['additions_sha256']['tests/' + TEST]
    assert receipt['expected_nodes_sha256'] == sha(out / 'expected.json') and receipt['xml_sha256'] == sha(out / 'junit.xml')
    assert {v['backend']: v['status'] for v in receipt['device_barriers']} == dict(jax='complete', cupy='complete')
    assert receipt['counts'] == dict(tests=1, failures=expected_code, errors=0, skipped=0)
    assert phases['pytest_exitstatus'] == expected_code
    assert [(v['node'], v['when'], v['outcome']) for v in phases['reports']] == [
        (NODE, 'setup', 'passed'), (NODE, 'call', 'failed' if expected_code else 'passed'), (NODE, 'teardown', 'passed')]
    result = dict(**actual, receipt_sha256=sha(out / 'receipt.json'), phases_sha256=sha(out / 'phases.json'),
                  source_manifest_sha256=receipt['source_manifest_sha256'], source_unchanged=True,
                  physical_test_passed=receipt['passed'], counts=receipt['counts'])
    if variant == 'negative':
        cases = list(ET.parse(out / 'junit.xml').getroot().iter('testcase'))
        text = cases[0].find('failure').text
        assert FAILURE in text and 'gpu/cuda/canopy_phase_surface.py' in text
        assert 'RuntimeError' in text and not receipt['passed'] and not receipt['all_setup_call_teardown_phases_passed']
        result.update(expected_original_physical_failure_observed=True, original_failure=FAILURE)
    else:
        assert receipt['passed'] and receipt['all_setup_call_teardown_phases_passed']
        lines = (out / 'worker.log').read_text().splitlines()
        metrics = {}
        for backend in ['cuda32', 'jax32']:
            prefix = 'Cng bounded root ' + backend + ' '
            matched = [v[v.index(prefix)+len(prefix):] for v in lines if prefix in v]
            assert len(matched) == 1
            metrics[backend] = json.loads(matched[0])
        prefix = 'Cng all345 same precision '
        matched = [v[v.index(prefix)+len(prefix):] for v in lines if prefix in v]
        assert len(matched) == 1
        differences = json.loads(matched[0])
        assert len(differences) == 345
        result.update(metrics=metrics, same_precision_maximum_absolute_difference=differences)
    write(out / 'audit.json', result)
    return result


def control(plan):
    records = []
    failure = None
    try:
        assert all(sha(ROOT / n) == h for n, h in plan['controls_sha256'].items())
        for variant in ['negative', 'positive']:
            actual = run_child('collect', variant, plan)
            assert actual['actual_parent_returncode'] == 0
            assert json.loads((ROOT / variant / 'collection.json').read_text())['passed']
        for variant in ['negative', 'positive']:
            actual = run_child('worker', variant, plan)
            records.append(audit_worker(variant, actual, plan))
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        (ROOT / 'traceback.txt').write_text(traceback.format_exc())
    unchanged = all(verify(Path(v['source']), v['source_manifest_sha256']) for v in plan['variants'].values())
    passed = failure is None and len(records) == 2 and unchanged
    write(ROOT / 'exit.json', dict(passed=passed, failure=failure, source_unchanged=unchanged,
          records=records, scope=plan['scope'], completion_means='Negative actual1 reproduces original physics failure; positive actual0 passes all original gates.'))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'control', 'collect', 'worker'])
    parser.add_argument('variant', nargs='?', choices=['negative', 'positive'])
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare()
    else:
        current_plan = json.loads((ROOT / 'plan.json').read_text())
        if args.mode == 'control':
            control(current_plan)
        elif args.mode == 'collect':
            collect(args.variant, current_plan)
        else:
            worker(args.variant, current_plan)

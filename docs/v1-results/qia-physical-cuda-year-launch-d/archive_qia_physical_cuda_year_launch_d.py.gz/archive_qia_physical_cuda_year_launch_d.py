from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-physical-cuda-year-d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((r/'launch.json').read_text());pid=json.loads((r/'worker.json').read_text())['pid'];assert b'run_qia_physical_cuda_year_d.py' in Path('/proc',str(pid),'cmdline').read_bytes()
raw=(r/'trajectory/batch.json').read_bytes();d=json.loads(raw);assert d['status']=='running' and d['steps_completed']>=48 and d['steps_requested']==17520 and d['same_precision_max_absolute'] is None and d['source_unchanged']
for n,h in launch['exact_copied_prefix_files'].items():
    assert sha(r/'seed-own-c'/n)==h
    if n.startswith('inputs/') or n.endswith('.npz'):assert sha(r/n)==h
obs=dict(scope='Actual509C own physically valid48-to17520 continuation. Original newC parent1 was metadata-only; model running48 and corrected GPU primary26/previousCUDA48trace22 audit0. All copied prefix/input bytes verified at launch and immutable NPZ/input copies remain exact. No failed-physics/source-changed prefix resumed; original old failed1519/163 unchanged. Snapshot not complete year/science/current canonical1249.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),committed_steps=d['steps_completed'],requested_steps=17520,same_precision_max_absolute=None,maximum_cumulative_m_h_c_n=d['maximum_cumulative_residual_m_h_c_n'],source_manifest_sha256=launch['source_manifest_sha256'],ps=subprocess.check_output(['ps','-p',str(pid)+',2242411,2634162','-o','pid,ppid,stat,etime,pcpu,args'],text=True))
a=b/'qia-physical-cuda-year-launch-d-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in [r/'launch.json',r/'worker.json',b/'run_qia_physical_cuda_year_d.py',b/'control_qia_physical_cuda_year_d.py',b/'launch_qia_physical_cuda_year_d.py',Path(__file__)]:t.add(p,arcname=p.name,recursive=False)
    for n,data in [('observation.json',(json.dumps(obs,indent=2)+'\n').encode()),('captured-batch.json',raw)]:
        info=tarfile.TarInfo(n);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,observation=obs)))

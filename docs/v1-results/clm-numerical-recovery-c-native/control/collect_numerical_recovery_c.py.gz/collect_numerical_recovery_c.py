from pathlib import Path
import hashlib,json,os,sys
import pytest
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-numerical-recovery-c';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==v for n,v in m.items());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(item.nodeid for item in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));assert code==0 and len(nodes)==len(set(nodes))==1461
gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];assert len(gpu)==390 and len(nodes)-len(gpu)==1071
expected=[n.split('/',1)[1] for n in gpu if Path(n.split('::')[0]).name in ('test_gpu_richards.py','test_gpu_richards_enthalpy.py')];assert len(expected)==8
barriers=[]
for name in ['jax','cupy']:
    if name in sys.modules:
        if name=='jax':sys.modules[name].effects_barrier()
        else:sys.modules[name].cuda.runtime.deviceSynchronize()
        barriers.append(name)
assert all(sha(s/n)==v for n,v in m.items())
d=dict(returncode=code,nodes=nodes,expected=expected,source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barriers=barriers,
    scope='563-recovery-C exact canonical collection only; no full-suite execution. Interpreter shutdown bypass after pytest return/barriers/durable receipt.')
with (r/'collection.json').open('x') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
sys.stdout.flush();sys.stderr.flush();os._exit(0)

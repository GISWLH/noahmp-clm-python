from pathlib import Path
import hashlib,json,os,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-numerical-recovery-c';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items())
with (r/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(b/'collect_numerical_recovery_c.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0;expected=json.loads((r/'collection.json').read_text())['expected'];assert len(expected)==8
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';records=[]
for label,filename,variable in [('water','test_gpu_richards.py','NOAHMP_RICHARDS_DIAGNOSTICS'),('heat','test_gpu_richards_enthalpy.py','NOAHMP_RICHARDS_HEAT_DIAGNOSTICS')]:
    q=r/label;q.mkdir();nodes=[n for n in expected if n.split('::')[0]==filename];assert len(nodes)==4;(q/'expected.json').write_text(json.dumps(nodes,indent=2)+'\n');env=os.environ.copy();env[variable]=str(q/'diagnostics')
    command=[sys.executable,'-u',str(worker),'--source',str(s),'--test-file',str(s/'tests'/filename),'--expected',str(q/'expected.json'),'--receipt',str(q/'receipt.json'),'--xml',str(q/'tests.xml')]
    with (q/'tests.log').open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
    (q/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2)+'\n');code=p.wait();d=json.loads((q/'receipt.json').read_text()) if (q/'receipt.json').exists() else {};unchanged=all(sha(s/n)==h for n,h in m.items())
    passed=bool(code==d.get('worker_exitcode')==d.get('pytest_returncode')==0 and d.get('passed') and d.get('source_unchanged') and d.get('all_setup_call_teardown_phases_passed') and d.get('node_coverage_exact') and d.get('counts')==dict(tests=4,failures=0,errors=0,skipped=0) and d.get('xml_sha256')==sha(q/'tests.xml') and d.get('source_manifest_sha256')==sha(s/'SOURCE_SHA256.json') and unchanged)
    row=dict(label=label,passed=passed,returncode=code if code else (0 if passed else 1),receipt_sha256=sha(q/'receipt.json') if d else None);(q/'exit.json').write_text(json.dumps(row,indent=2)+'\n');records.append(row)
    if not passed:break
passed=len(records)==2 and all(v['passed'] for v in records);record=dict(scope='563-recovery-C formal unmodified production water4+heat4. Exact original nodes/XML/source, allraw1e-6/integer/reference/independent physicalbudget gates, explicit barriers and stableworkeratexit disclosure retained. No private runtimepatch; wholecolumn/station/full1461/year/science acceptance independent.',passed=passed,returncode=0 if passed else 1,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,records=records)
(r/'exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['returncode'])

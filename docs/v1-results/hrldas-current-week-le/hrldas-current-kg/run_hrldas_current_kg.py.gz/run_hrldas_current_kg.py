"""CurrentJN, exact original3-site HRLDAS paired configurations, cold336 only."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import gzip,hashlib,io,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-kg';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();plan=json.loads((r/'package.json').read_text());a=b/plan['archive'];assert sha(a)==plan['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest==plan['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());full=json.loads((b/'ballberry-jn-full/receipt.json').read_text());assert full['passed'] and full['source_unchanged'] and full['source_manifest_sha256']==manifest and full['counts']==dict(tests=1156,failures=0,errors=0,skipped=0) and (b/'ballberry-jn-full/pbs-exit.txt').read_text().strip()=='0';sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
import run_fluxnet_native as native
from compare_hrldas_suction_prefix import bind_suction_configurations,PROTOCOL_SHA,ARCHIVE_SHA,GENERATOR_SHA,SITES
old=b/'fluxnet-first-climate-cycle-20261017-h/inputs';official=b/'hrldas-three-climate-b';assert sha(official/'protocol.json')==PROTOCOL_SHA and sha(b/'hrldas-three-climate-b-evidence.tar.gz')==ARCHIVE_SHA;protocol=json.loads((official/'protocol.json').read_text());assert protocol['instrument_sha256']==GENERATOR_SHA
inputs=r/'inputs';inputs.mkdir();cases=[];bindings=[];copied={};metadata={};cold=[]
with tarfile.open(b/'hrldas-three-climate-b-evidence.tar.gz') as tf:
    assert tf.extractfile('protocol.json').read()==(official/'protocol.json').read_bytes()
    for site in SITES:
        for name in ['prepared-manifest.json','audit.json','run-receipt.json']:
            p=official/site/name;assert tf.extractfile(site+'/'+name).read()==p.read_bytes();metadata[site+'/'+name]=sha(p)
        prepared=json.loads((official/site/'prepared-manifest.json').read_text());paths=prepared['inputs_sha256'];origin=Path(next(k for k in paths if k.endswith('-config.json')));assert sha(origin)==paths[str(origin)];new=old/(site+'-config.json');binding=bind_suction_configurations(origin.read_bytes(),new.read_bytes(),prepared,site);bindings.append(binding)
        for suffix in ['.npz','.json']:
            original=Path(next(k for k in paths if k.endswith(suffix) and not k.endswith('-config.json')));target=old/(site+suffix);assert sha(original)==paths[str(original)]==sha(target)
        for name in [site+'.npz',site+'.json',site+'-config.json']:(inputs/name).write_bytes((old/name).read_bytes());copied[name]=sha(inputs/name)
        (inputs/(site+'-original-config.json')).write_bytes(origin.read_bytes());copied[site+'-original-config.json']=sha(origin)
        c=json.loads(new.read_text());cases.append(dict(case=c['case'],site=site,input=site+'.npz',input_manifest=site+'.json',configuration=site+'-config.json'));cold.append(runner.build_state(c))
batch=dict(cases=[{k:v for k,v in c.items() if k!='site'} for c in cases]);runner.atomic_json(inputs/'batch.json',batch);loaded=native.load_batch(inputs/'batch.json');assert len(loaded)==3 and native.native_state_count(loaded)==16;env=np.asarray([c['data']['environment'][0] for c in loaded],np.float32);arrays=native.pack_station_arrays(cold,16,dtype=np.float32,co2_ppm=env[:,0],cosine_zenith=env[:,1],diffuse_fraction=env[:,2],leaf_dimension=np.asarray([c['config']['leaf_dimension_m'] for c in loaded],np.float32));zero=np.zeros((3,4));data={f'a{k}':v for k,v in enumerate(arrays)};data.update(index=np.array(0),initial=native.totals(arrays),net=zero.copy(),bounds=zero.copy(),maximum=zero.copy(),stepmax=zero.copy(),tracermax=np.zeros((3,5)));np.savez_compressed(inputs/'cold-reference.npz',**data)
locked=dict(pbs_job=os.environ['PBS_JOBID'],source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),official_protocol_sha256=PROTOCOL_SHA,official_archive_sha256=ARCHIVE_SHA,official_generator_sha256=GENERATOR_SHA,original_I_inputs_sha256=copied,original_official_metadata_sha256=metadata,bindings=bindings,case_count=3,cases=cases,requested_steps=17520,preflight_steps=48,diagnostic_steps=336,cold_fields=23,primary_arrays=16,cold_reference_sha256=sha(inputs/'cold-reference.npz'),scope='CurrentJN exact original3-site suction-derived configurations/weather/metadata, sourceonly updated. Same soil/PFT/heights/plantCN/phenology/leaf/deposition priors; no oldtrajectory/modelstate loaded, no calibration or selection. Cold firstweek structuralcomparison only, not matching allNoahphysics/annual/spinup/scientificacceptance.')
runner.atomic_json(inputs/'protocol.json',locked);archive=b/'hrldas-current-kg-inputs.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(inputs.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(inputs).as_posix(),recursive=False)
runner.atomic_json(b/'hrldas-current-kg-inputs-package.json',dict(archive=archive.name,sha256=sha(archive),source_manifest_sha256=manifest,protocol_sha256=sha(inputs/'protocol.json'),case_count=3,cold_fields=23));(r/'runs').mkdir();started=time.monotonic()

def advance(c):
    folder=r/'runs'/c['case'];folder.mkdir();packets=tarfile.open(folder/'steps.tar.gz','w:gz');counter=0;original=runner.step_clm_enthalpy_column;failure=None;start=time.monotonic();preflight=None
    def observe(state,forcing,**kwargs):
        nonlocal counter
        try:after,diagnostic=original(state,forcing,**kwargs)
        except Exception:
            blob=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs),protocol=5),mtime=0);member=tarfile.TarInfo('failed-before-'+str(counter).zfill(5)+'.pkl.gz');member.size=len(blob);packets.addfile(member,io.BytesIO(blob));raise
        blob=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs,after=after,diagnostics=diagnostic),protocol=5),mtime=0);member=tarfile.TarInfo('call-'+str(counter).zfill(5)+'.pkl.gz');member.size=len(blob);packets.addfile(member,io.BytesIO(blob));counter+=1;return after,diagnostic
    try:
        runner.step_clm_enthalpy_column=observe
        report=runner.run(inputs/c['input'],inputs/c['input_manifest'],inputs/c['configuration'],folder/'trajectory',stop_after=48);assert counter==48 and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['source_unchanged'];preflight=dict(passed=True,steps_completed=48,steps_requested=17520,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),report_sha256=sha(folder/'trajectory/report.json'));runner.atomic_json(folder/'preflight.json',preflight)
        report=runner.run(inputs/c['input'],inputs/c['input_manifest'],inputs/c['configuration'],folder/'trajectory',resume=True,stop_after=288);assert counter==336 and report['steps_completed']==336 and report['steps_requested']==17520 and report['status']=='running' and report['source_unchanged']
    except Exception as e:failure=type(e).__name__+': '+str(e);(folder/'traceback.txt').write_text(traceback.format_exc())
    finally:runner.step_clm_enthalpy_column=original;packets.close()
    p=folder/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else {};value=dict(case=c['case'],site=c['site'],failure=failure,preflight=preflight,captured_steps=counter,steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),status=report.get('status'),source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),configuration_sha256=sha(inputs/c['configuration']),report_sha256=sha(p) if p.exists() else None,packets_sha256=sha(folder/'steps.tar.gz'),seconds=time.monotonic()-start,scope='ActualcurrentJN freshcold48 then ownverified336 continuation, original17,520 request remainsrunning. ExactoriginalpairedHRLDAS configurations/forcing, fullstate/diagnostics/inputs retained. No official/observational/annual acceptance from this integration.');runner.atomic_json(folder/'receipt.json',value);print(json.dumps(value),flush=True);return value

results=[]
with ProcessPoolExecutor(max_workers=3) as pool:
    for value in pool.map(advance,cases):results.append(value);runner.atomic_json(r/'progress.json',dict(completed_cases=len(results),cases=results))
passed=len(results)==3 and all(c['failure'] is None and c['source_unchanged'] and c['captured_steps']==c['steps_completed']==336 and c['steps_requested']==17520 for c in results);value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=passed,cases=results,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),input_protocol_sha256=sha(inputs/'protocol.json'),seconds=time.monotonic()-started,scope=locked['scope']);runner.atomic_json(r/'receipt.json',value);print(json.dumps({k:v for k,v in value.items() if k!='cases'}),flush=True);raise SystemExit(0 if passed and value['source_unchanged'] else 1)

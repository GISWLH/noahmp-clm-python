from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');payload={};sha=lambda raw:hashlib.sha256(raw).hexdigest();summary=json.loads((b/'hrldas-current-kh/comparison.json').read_text());assert summary['source_unchanged'] and summary['actual_model_parent_zero_job']=='1188.manager' and all(x['steps']==336 and x['all_original_step_and_cumulative_m_h_c_n_gates_passed'] for x in summary['independent_audits'].values())
for name,job in [('hrldas-current-kg','1188.manager'),('hrldas-current-kh','1189.manager')]:
    root=b/name;status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M) and (root/'pbs-exit.txt').read_text().strip()=='0';dispatch=json.loads((root/'dispatch.json').read_text());assert dispatch['pbs_job']==job and all(sha((root/n).read_bytes())==h for n,h in dispatch['controls_sha256'].items())
    for p in sorted(root.rglob('*')):
        if p.is_file():assert not p.is_symlink();payload[name+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
    payload[name+'/actual-pbs-qstat.txt']=status.encode()
official=b/'hrldas-three-climate-b';payload['official/protocol.json']=(official/'protocol.json').read_bytes();assert sha(payload['official/protocol.json'])==summary['official_protocol_sha256']
for site in ['CN-Qia','CN-Cha','CN-HaM']:
    for name in ['prepared-manifest.json','audit.json']:payload['official/'+site+'/'+name]=(official/site/name).read_bytes()
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_model_exit=0,actual_audit_exit=0,source_manifest_sha256=summary['source_manifest_sha256'],closed_old_generations_archive_sha256='e81f8a92e1a1d7fff831f6cfef90d191e0d12bd5d940e1c3976eac118c19cc77',scope='CurrentJN originalthreeofficialpaired cold336 each, all1008fullpackets/inputs/currentfinalreports/state/trace/controls andactual1188/1189F0, strictoriginalseven-day scientificresults preserved. OlderclosedKGgenerations losslesslycompactedLM, latest336protected. Allthree dailycriteria false; audit0 isnotscientific/year/spinup/GPU/releasepass.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();payload['control/'+Path(__file__).name]=Path(__file__).read_bytes();target=b/'hrldas-current-week-le-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for m in tf:assert tf.extractfile(m).read()==payload[m.name]
out=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'hrldas-current-week-le-package.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

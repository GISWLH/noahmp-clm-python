"""Device printf only: original saved surface, arithmetic and limits unchanged."""
from pathlib import Path
import json
import numpy as np
import cupy as cp
import noahmp_clm.gpu.cuda.canopy_phase_surface as module
root=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-c/failure-262-replay-a')
names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu',
    'enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu',
    'snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu')
source='\n'.join(Path(module.__file__).with_name(name).read_text() for name in names)
line='trial=fminf(right-.05f*span,fmaxf(left+.05f*span,trial));'
assert source.count(line)==1
source=source.replace(line,line+'\nif(threadIdx.x==0&&blockIdx.x==0)printf("root %d left %.12g right %.12g fl %.12g fr %.12g trial %.12g\\n",k,left,right,fl,fr,trial);')
compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_canopy_phase_surface_vic',))
module._kernel=lambda extended=False,vic=False:compiled.get_function('run_canopy_phase_surface_vic')
with np.load(root/'failed-surface-inputs.npz',allow_pickle=False) as z:arrays={k:z[k] for k in z}
out=module.run_canopy_phase_surface_cuda(*[arrays[f'a{k}'] for k in range(9)],
    exchange_extension=arrays['exchange_extension'],vic=arrays['vic'],raise_on_failure=False)
cp.cuda.get_current_stream().synchronize()
print(json.dumps(dict(converged=cp.asnumpy(out['converged']).tolist(),bracket=cp.asnumpy(out['surface_root_bracket_k']).tolist())),flush=True)

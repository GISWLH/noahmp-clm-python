from pathlib import Path
import hashlib,json,os,sys
import pytest

base=Path('/home/lhwang/work/noahmp-v1');source=base/'clm-capacity-final-f';root=source/'target-f'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text())
assert len(manifest)==532 and all(sha(source/n)==h for n,h in manifest.items());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(item.nodeid for item in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));assert code==0 and len(nodes)==len(set(nodes))==1344
gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))]
assert len(gpu)==363 and len(nodes)-len(gpu)==981
groups={}
for filename,count in [('test_gpu_canopy_capacity.py',3),('test_gpu_canopy_capacity_layers.py',3),('test_gpu_canopy_phase_energy.py',14),('test_gpu_clm_capacity_column.py',3)]:
    expected=[n.split('/',1)[1] for n in gpu if Path(n.split('::')[0]).name==filename];assert len(expected)==count
    groups[filename]=expected
barriers=[]
for name in ['jax','cupy']:
    if name in sys.modules:
        if name=='jax':sys.modules[name].effects_barrier()
        else:sys.modules[name].cuda.runtime.deviceSynchronize()
        barriers.append(name)
assert all(sha(source/n)==h for n,h in manifest.items())
record=dict(scope='Exact532F collect-only1344=981CPU+363GPU, not execution. Atexit bypass after pytestreturn/barriers/durable receipt.',returncode=code,nodes=nodes,groups=groups,
            source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),source_unchanged=True,device_barriers=barriers)
with (root/'collection.json').open('x') as output:json.dump(record,output,indent=2);output.flush();os.fsync(output.fileno())
sys.stdout.flush();sys.stderr.flush();os._exit(0)

from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile

base=Path('/home/lhwang/work/noahmp-v1');source=base/'clm-capacity-final-f';assert not source.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((base/'clm-capacity-final-f-package.json').read_text());archive=base/'clm-capacity-final-f-source.tar.gz'
assert sha(archive)==package['archive_sha256']
for name,key in [('clm-capacity-reference-e-receipt.json','numpy_receipt_sha256'),('clm-capacity-reference-e-reference.json','reference_receipt_sha256')]:assert sha(base/name)==package[key]
receipt=json.loads((base/'clm-capacity-reference-e-receipt.json').read_text());reference=json.loads((base/'clm-capacity-reference-e-reference.json').read_text())
assert receipt['returncode']==0 and receipt['counts']==dict(tests=53,failures=0,errors=0,skipped=0) and receipt['source_unchanged'] and reference['source_unchanged']
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>8192
memory=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());assert int(memory['MemAvailable'].split()[0])>16*1024*1024
source.mkdir()
with tarfile.open(archive) as tf:tf.extractall(source,filter='data')
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(manifest)==532 and all(sha(source/n)==h for n,h in manifest.items()) and sha(source/'SOURCE_SHA256.json')==package['manifest_sha256']
root=source/'target-f';root.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[source,source/'src',source/'tests',source/'benchmarks'])),
    PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
    JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
with (root/'controller.log').open('x') as log:child=subprocess.Popen([sys.executable,'-u',str(base/'control_clm_capacity_target_f.py')],cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(scope=package['scope'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=child.pid,device=0,free_gpu_mib=free,source_archive_sha256=sha(archive),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),
            controls_sha256={n:sha(base/n) for n in ['collect_clm_capacity_target_f.py','control_clm_capacity_target_f.py',Path(__file__).name]})
(root/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

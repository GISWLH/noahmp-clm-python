from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'numpy-annual-failure-probe-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (root/'pbs-exit.txt').read_text().strip()=='0';profile=root/'profile_output/numpy-annual-failure-a';profile.mkdir(parents=True,exist_ok=False);brief=[]
for site in ['CN-Cng','CN-Qia','CN-Cha','CN-HaM']:
    p=root/(site+'-suction-climate-cycle')/'probe.json';r=json.loads(p.read_text());assert r['source_unchanged'] and r['failure'];(profile/(site+'-probe.json')).write_bytes(p.read_bytes());last=r['exceptions'][-1]['selected'] if r['exceptions'] else {};brief.append(dict(site=site,index=r['index'],timestamp=r['timestamp'],failure=r['failure'],surface_evaluations=len(r['surface_evaluations']),last_surface_evaluations=r['surface_evaluations'][-3:],root_selected={k:v for k,v in last.items() if not isinstance(v,list)},seconds=r['seconds']))
(root/'compact.json').write_text(json.dumps(brief,indent=2)+'\n');archive=base/'numpy-annual-failure-probe-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    paths=[p for p in sorted(root.rglob('*')) if p.is_file()]
    for p in paths:t.add(p,arcname=p.relative_to(root).as_posix(),recursive=False)
    t.add(base/'p6-spinup-assessment-c/SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False);t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
print(json.dumps(dict(name='numpy-annual-failure-probe-a',sha256=sha(archive),files=len(paths)+2,brief=brief)))

from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-annual-failure-probe-a';name=sys.argv[1];out=root/name;out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());begun=time.monotonic()
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
import run_fluxnet_column as driver
import noahmp_clm.clm_enthalpy_driver as model
import noahmp_clm.physics.canopy_column as surface
terminal=base/'fluxnet-numpy-current-first-year-a';exit_report=json.loads((terminal/'exit.json').read_text());row=[r for r in exit_report['cases'] if r['case']==name];assert len(row)==1;row=row[0];archive=terminal/row['terminal_archive'];assert sha(archive)==row['terminal_archive_sha256']
with tarfile.open(archive) as t:
    r=json.load(t.extractfile('report.json'));raw=t.extractfile(r['checkpoint_file']).read();assert hashlib.sha256(raw).hexdigest()==r['checkpoint_sha256'];saved=pickle.loads(raw)
state,initial,net,bounds,maximum,stepmax,index=saved;assert index==r['steps_completed'] and r['status']=='failed' and r['source_unchanged'];c=r['configuration'];inputs=base/'fluxnet-first-climate-cycle-20261017-h/inputs';path=inputs/(c['site']+'.npz');meta_path=inputs/(c['site']+'.json');assert sha(path)==r['forcing_npz_sha256'] and sha(meta_path)==r['forcing_manifest_sha256'];meta=json.loads(meta_path.read_text())
with np.load(path,allow_pickle=False) as z:data=dict(z)
stamps=driver.validate_input(data,meta,path);f=driver.Forcing(*data['forcing'][index]);co2,mu,diffuse=data['environment'][index];dep=driver.DepositionSchedule(c);old_step=model.surface_step;old_phase=surface.solve_canopy_phase_energy if hasattr(surface,'solve_canopy_phase_energy') else None;records=[];exceptions=[];surface_calls=[]
def observe_surface(*args,**kwargs):
    filename='surface-call-'+str(len(surface_calls))+'.pkl';p=out/filename;p.write_bytes(pickle.dumps((args,kwargs)));surface_calls.append(dict(file=filename,sha256=sha(p)));return old_step(*args,**kwargs)
def trace(frame,event,arg):
    code=frame.f_code;file=Path(code.co_filename).name;local=frame.f_locals
    if event=='return' and file=='canopy_column.py' and code.co_name=='evaluate':
        rec=dict(trial_temperature_k=float(local['temperature']),returned=arg is not None)
        if arg is not None:
            value,d=arg;rec.update(residual_k=float(value),snow_layers=len(d['snow'].mass),actual_temperature_k=float(d['snow'].temperature[0] if len(d['snow'].mass) else d['soil'].temperature[0]),thermal_residual_jm2=float(d['thermal']['residual_jm2']))
        records.append(rec)
    if event=='exception' and file in ['canopy_column.py','canopy_phase_energy.py'] and code.co_name in ['surface_step','solve_canopy_phase_energy']:
        selected={}
        for key in (['left','right','fl','fr','trial','value','fc','center','iteration','evaluations','temperature_tolerance'] if file=='canopy_column.py' else ['iteration','max_iterations','residual','x','lower','upper','phase_active','mass','tolerance','restarts']):
            if key in local:
                v=local[key];selected[key]=v.tolist() if isinstance(v,np.ndarray) else (v.item() if isinstance(v,np.generic) else v)
        exceptions.append(dict(file=file,line=frame.f_lineno,function=code.co_name,error=type(arg[1]).__name__+': '+str(arg[1]),selected=selected))
    return trace
model.surface_step=observe_surface;failure=None;result=None
try:
    sys.settrace(trace)
    after,d=driver.step_clm_enthalpy_column(state,f,co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),leaf_dimension=c['leaf_dimension_m'],leaf_parameters=driver.LeafParameters(**c['leaf_parameters']),most_geometry=driver.MOSTGeometry(**c['most_geometry']),phenology_environment=driver.calendar(stamps[index],meta,c['phenology'] is not None),deposition_rates=dep.aerosol(stamps[index],f.dt),nitrogen_deposition_gn_m2=dep.nitrogen_rate*f.dt)
    incoming,residual,bound=driver.audit_step(state,after,f,d,dep.nitrogen_rate*f.dt);result=dict(residual=residual.tolist(),bound=bound.tolist())
except BaseException as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:sys.settrace(None);model.surface_step=old_step
assert all(sha(source/n)==v for n,v in m.items());value=dict(scope='Exact failed NumPy121 previous state/next interval diagnostic. Selected surface scalar evaluations and exception physical coordinates only; no global locals/environment dump or production source edits, no invalid advance, no convergence/budget tolerance changes.',case=name,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,index=index,timestamp=str(data['time_start'][index]),original_terminal_archive_sha256=sha(archive),source_unchanged=True,failure=failure,result=result,surface_calls=surface_calls,surface_evaluations=records,exceptions=exceptions,seconds=time.monotonic()-begun)
(out/'probe.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(case=name,failure=failure,surface_evaluations=len(records),seconds=time.monotonic()-begun)),flush=True)

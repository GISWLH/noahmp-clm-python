from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
kind=sys.argv[1];assert kind in ['cuda32','jax32'];b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-b';r=b/('qia3803-full-'+kind+'-b');assert not r.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items())
# This is a separate32-bit whole-point diagnostic, not native4 acceptance.
# A had actual JAX32/CUDA32/science/raw passes and only a prephysics64 packing
# failure; B changes that GPU test metadata alone, no production bytes.
import xml.etree.ElementTree as ET
prior=b/'phase-coordinate-native-a';old=json.loads((prior/'SOURCE_SHA256.json').read_text())
assert all(m[n]==h for n,h in old.items() if n.startswith('src/'))
target=json.loads((prior/'target-a/receipt.json').read_text());assert target['source_unchanged'] and target['counts']==dict(tests=4,failures=1,errors=0,skipped=0)
cases=list(ET.parse(prior/'target-a/tests.xml').getroot().iter('testcase'));assert len(cases)==4
needed=['test_retained_surface_reference_and_original_extensive_budgets[jax32]','test_retained_surface_reference_and_original_extensive_budgets[cuda32]','test_retained_surface_all_outputs_same_precision']
for name in needed:
    rows=[v for v in cases if v.attrib['name']==name];assert len(rows)==1 and len(rows[0])==0
ref=json.loads((b/'qia3803-whole-reference-a-receipt.json').read_text());assert ref['source_unchanged'] and ref['source_manifest_sha256']==sha(prior/'SOURCE_SHA256.json')
cpu=json.loads((b/'phase-coordinate-target-b-receipt.json').read_text());assert cpu['returncode']==0 and cpu['source_unchanged'] and cpu['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and cpu['counts']==dict(tests=5,failures=0,errors=0,skipped=0)
if kind=='jax32':assert json.loads((b/'qia3803-full-cuda32-h/exit.json').read_text())['passed']
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines());assert free>6144 and int(mem['MemAvailable'].split()[0])>16*1024*1024
r.mkdir();env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
controls={n:sha(b/n) for n in ['launch_qia3803_full_b.py','control_qia3803_full_b.py','run_qia3803_full_b.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_qia3803_full_b.py'),kind],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='Original3803 frozen563-coordinate-B fullstep32 diagnostic after exactB CPU5, sameproductionA350 wholeNumPyMHCN and actualA JAX32/CUDA32/raw3passes; A64prephysics aliasfailure and pendingBnative4 explicitly retained. No failedtrajectory resumed.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,backend=kind,device=0,free_memory_mib=free,controls_sha256=controls,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'));(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

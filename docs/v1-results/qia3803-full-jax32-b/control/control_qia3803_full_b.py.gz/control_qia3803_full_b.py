from pathlib import Path
import hashlib,json,subprocess,sys,time
kind=sys.argv[1];b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-b';r=b/('qia3803-full-'+kind+'-b');start=time.monotonic();cmd=[sys.executable,'-u',str(b/'run_qia3803_full_b.py'),kind]
with (r/'model.log').open('x') as log:p=subprocess.Popen(cmd,cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=cmd),indent=2)+'\n');code=p.wait();receipt=json.loads((r/'receipt.json').read_text()) if (r/'receipt.json').exists() else None;good=bool(receipt and code==0 and receipt['failure'] is None and receipt['source_unchanged'] and receipt['input_unchanged'] and receipt['device_barrier_complete'])
d=dict(returncode=code,passed=good,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256((r/'receipt.json').read_bytes()).hexdigest() if receipt else None);(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);raise SystemExit(0 if good else 1)

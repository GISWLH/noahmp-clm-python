from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as ET
base=Path('/home/lhwang/work/noahmp-v1');model=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((model/'SOURCE_SHA256.json').read_text());assert all(sha(model/n)==v for n,v in m.items())
receipt=json.loads((model/'target-delegated-to-full-a.json').read_text())
assert receipt['source_unchanged'] and receipt['all_deferred_present_in_canonical_queue'] and receipt['canonical_and_annual_identity_unchanged']
completed=receipt['completed_results'];assert len(completed)==2
for row in completed:
    assert row['returncode']==0 and row['source_unchanged']
    stem=Path(row['file']).stem;tests=list(ET.parse(model/(stem+'.xml')).getroot().iter('testcase'))
    assert len(tests)==3 and all(all(t.find(k) is None for k in ['failure','error','skipped']) for t in tests)
def archive(name,pairs,scope):
    dest=base/(name+'-evidence.tar.gz');assert not dest.exists()
    with tarfile.open(dest,'w:gz') as t:
        for path,label in pairs:t.add(path,arcname=label,recursive=False)
    print(json.dumps(dict(name=name,files=len(pairs),archive_sha256=sha(dest),scope=scope)))
names=['SOURCE_SHA256.json','gpu-target-launch.json','run_most_oscillation_gpu_a.py','launch_most_oscillation_gpu_a.py',
       'target-before-delegation-a.json','full-before-target-delegation-a.json','target-delegated-to-full-a.json','delegate_most_target_to_full_a.py',
       'gpu-target-progress.json','gpu-target-controller.log','test_gpu_most_oscillation.log','test_gpu_most_oscillation.xml',
       'test_gpu_most_stagnation.log','test_gpu_most_stagnation.xml','test_gpu_most_feedback_rounding.log',
       'tests/test_most_stagnation.py','tests/test_gpu_most_stagnation.py','full-by-file-a/selection.json']
optional=model/'test_gpu_most_feedback_rounding.xml'
if optional.exists():names.append(optional.name)
pairs=[(model/n,n) for n in names]+[(Path(__file__),'archive_most_stable_profile_a.py')]
archive('most-stable-target-prefix-a',pairs,'Two completed original target files / six tests; remaining three files explicitly delegated to canonical full GPU325 queue. Interrupted active-file output is not a pass or a numerical failure. No target/full/annual/scientific completion claim.')
profile=base/'profile_output/most-slow-a';summary=json.loads((profile/'summary.json').read_text())
assert summary['source_unchanged_at_recovery'] and len(summary['snapshots'])==3 and not summary['per_call_durations_available']
for name,digest in summary['artifacts'].items():assert sha(profile/name)==digest
for path in profile.glob('0*.json'):
    threads=json.loads(path.read_text());assert isinstance(threads,list)
    assert all(not f.get('locals') for thread in threads for f in thread['frames'])
names=['00-target-3981208.json','00-target-3981208.stderr.txt','01-annual-3983588.json','01-annual-3983588.stderr.txt',
       '02-target-3981208.json','02-target-3981208.stderr.txt','gpu-snapshot.txt','probe_most_slow_a.py','recover_most_slow_a.py','summary.json']
pairs=[(profile/n,'snapshots/'+n) for n in names]+[(model/'SOURCE_SHA256.json','SOURCE_SHA256.json'),(Path(__file__),'archive_most_stable_profile_a.py')]
archive('most-readonly-stack-a',pairs,'Three instantaneous read-only owned-process stack samples, no locals/environment; original metadata-wrapper failure and read-only recovery retained. No statistical hotspot, timing, speedup, or production instrumentation claim.')

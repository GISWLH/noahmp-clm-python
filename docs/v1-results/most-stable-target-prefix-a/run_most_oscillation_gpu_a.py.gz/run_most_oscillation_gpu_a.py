from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
verify=lambda:all(sha(root/n)==v for n,v in manifest.items())
assert verify()
files=['tests/test_gpu_most_oscillation.py','tests/test_gpu_most_stagnation.py','tests/test_gpu_most_feedback_rounding.py','tests/test_gpu_canopy_most.py','tests/test_gpu_clm_most_column.py']
started=time.monotonic();results=[]
for file in files:
    name=Path(file).stem;command=[sys.executable,'-m','pytest','-q','-s',file,'--junitxml='+name+'.xml']
    begin=time.monotonic()
    with (root/(name+'.log')).open('w') as stream:
        proc=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT)
        (root/'gpu-target-progress.json').write_text(json.dumps(dict(status='running',active=dict(file=file,pid=proc.pid),results=results),indent=2)+'\n')
        code=proc.wait()
    counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/(name+'.xml')).getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
    value=dict(file=file,returncode=code,seconds=time.monotonic()-begin,counts=counts,source_unchanged=verify())
    results.append(value);print(json.dumps(value),flush=True)
    if code or not value['source_unchanged'] or any(counts[k] for k in ['failures','errors','skipped']):break
passed=len(results)==len(files) and all(r['returncode']==0 and r['source_unchanged'] and all(r['counts'][k]==0 for k in ['failures','errors','skipped']) for r in results)
value=dict(status='complete' if passed else 'failed',seconds=time.monotonic()-started,source_files=len(manifest),source_unchanged=verify(),results=results,node=os.uname().nodename,scope='Current frozen MOST source; original limits, independent budgets and CUDA32/JAX32 1e-6 all-field gate. No annual or scientific acceptance claim.')
(root/'gpu-target-summary.json').write_text(json.dumps(value,indent=2)+'\n')
(root/'gpu-target-progress.json').write_text(json.dumps(value,indent=2)+'\n')
assert passed

from pathlib import Path
import hashlib,json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-most-oscillation-a'
receipt=root/'gpu-target-launch.json';assert not receipt.exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(root/'src')+':'+str(root/'tests')+':'+str(root/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_most_oscillation_gpu_a.py')]
with (root/'gpu-target-controller.log').open('w') as stream:
    proc=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
value=dict(pid=proc.pid,gpu=0,command=command,runner_sha256=hashlib.sha256((root/'run_most_oscillation_gpu_a.py').read_bytes()).hexdigest())
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

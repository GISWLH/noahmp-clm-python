"""Stop only the redundant owned target group, preserving canonical full coverage."""
from pathlib import Path
import datetime,hashlib,json,os,signal,time
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-most-oscillation-a'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=root/'target-delegated-to-full-a.json';assert not out.exists()
m=json.loads((root/'SOURCE_SHA256.json').read_text())
assert all(sha(root/n)==v for n,v in m.items())
target_id,full_id,annual_id=3942782,3968670,3983588
def identity(pid):
    proc=Path('/proc')/str(pid)
    if not proc.exists():return None
    stat=(proc/'stat').read_text().split(') ',1)[1].split()
    cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode()
    return dict(pid=pid,uid=proc.stat().st_uid,cwd=os.readlink(proc/'cwd'),command=cmd,pgid=os.getpgid(pid),start_ticks=stat[19],state=stat[0])
def same(before,after):
    return after is not None and all(before[k]==after[k] for k in ['pid','uid','cwd','command','pgid','start_ticks'])
progress_raw=(root/'gpu-target-progress.json').read_bytes();p=json.loads(progress_raw)
selection=json.loads((root/'full-by-file-a/selection.json').read_text())
full_progress_raw=(root/'full-by-file-a/progress.json').read_bytes();full=json.loads(full_progress_raw)
assert all(r['passed'] and r['returncode']==0 for r in full['results'])
canonical=identity(full_id);annual=identity(annual_id)
for who,script in [(canonical,'run_most_full_gpu_b.py'),(annual,'benchmarks/run_fluxnet_native.py')]:
    assert who and who['uid']==os.getuid() and script in who['command'] and who['cwd']==str(root)
assert 'fluxnet-first-climate-cycle-20261017-j/batch.json' in annual['command'] and '--resume' in annual['command']
assert canonical['pgid']!=target_id and annual['pgid']!=target_id
files=['tests/test_gpu_most_oscillation.py','tests/test_gpu_most_stagnation.py','tests/test_gpu_most_feedback_rounding.py','tests/test_gpu_canopy_most.py','tests/test_gpu_clm_most_column.py']
done={r['file'] for r in p['results'] if r['returncode']==0 and r['source_unchanged'] and all(r['counts'][k]==0 for k in ['failures','errors','skipped'])}
assert len(done)==len(p['results']) and len(done)>=2
pending=[f for f in files if f not in done];assert set(pending)<=set(selection['gpu_files'])
actions=[];members=[]
if pending:
    parent=identity(target_id);child=identity(p['active']['pid'])
    assert parent and parent['uid']==os.getuid() and parent['pgid']==target_id and parent['cwd']==str(root) and 'run_most_oscillation_gpu_a.py' in parent['command']
    assert child and child['uid']==os.getuid() and child['pgid']==target_id and child['cwd']==str(root) and p['active']['file'] in child['command']
    for proc in Path('/proc').iterdir():
        if proc.name.isdigit():
            try:
                entry=identity(int(proc.name))
                if entry and entry['pgid']==target_id:members.append(entry)
            except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    assert {v['pid'] for v in members}=={target_id,child['pid']}
    (root/'target-before-delegation-a.json').write_bytes(progress_raw)
    (root/'full-before-target-delegation-a.json').write_bytes(full_progress_raw)
    assert same(parent,identity(target_id)) and same(child,identity(child['pid']))
    os.killpg(target_id,signal.SIGINT);actions.append(dict(signal='SIGINT',group=target_id))
    time.sleep(2)
    for original in members:
        after=identity(original['pid'])
        if after and after['state']!='Z':
            assert same(original,after)
            os.kill(original['pid'],signal.SIGTERM);actions.append(dict(signal='SIGTERM',pid=original['pid']))
    time.sleep(2)
else:
    assert p['status']=='complete'
assert same(canonical,identity(full_id)) and same(annual,identity(annual_id))
remaining=[identity(v['pid']) for v in members]
assert all(v is None or v['state']=='Z' for v in remaining)
assert all(sha(root/n)==v for n,v in m.items())
result=dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Duplicate target queue scheduling supersession; canonical full GPU queue retains all remaining original checks. No full-target completion, numerical failure, annual or scientific acceptance claim.',source_manifest_sha256=sha(root/'SOURCE_SHA256.json'),source_files=len(m),source_unchanged=True,completed_results=p['results'],deferred_files=pending,all_deferred_present_in_canonical_queue=True,canonical_selection_sha256=sha(root/'full-by-file-a/selection.json'),original_progress_sha256=hashlib.sha256(progress_raw).hexdigest(),canonical_identity=canonical,annual_identity=annual,stopped_members=members,actions=actions,remaining_members=remaining,canonical_and_annual_identity_unchanged=True)
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

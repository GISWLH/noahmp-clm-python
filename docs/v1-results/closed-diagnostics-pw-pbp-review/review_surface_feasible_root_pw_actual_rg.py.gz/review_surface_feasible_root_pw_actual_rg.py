"""Independent PW1700 closed review; only stdlib JSON/opaque array bytes."""
import ast
import base64
import hashlib
import io
import json
import math
from pathlib import Path
import re
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
LABEL = 'surface-7275-feasible-root-pw'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all((m.isfile() or m.isdir()) and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        members = [m for m in members if m.isfile()]
        names = [m.name.removeprefix('./') for m in members]
        assert len(names) == len(set(names))
        return {n: archive.extractfile(m).read() for n, m in zip(names, members)}


def check_inventory(files, name):
    index = json.loads(files[name])
    assert set(index) == set(files) - {name}
    for key, entry in index.items():
        assert sha(files[key]) == (entry if isinstance(entry, str) else entry['sha256'])
        if isinstance(entry, dict):
            assert len(files[key]) == entry['bytes']
    return index


def arrays(tree):
    result = {}
    def walk(node):
        if isinstance(node, dict):
            if node.get('kind') == 'array':
                assert node['key'] not in result
                result[node['key']] = node
            else:
                for child in node.values():
                    walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)
    walk(tree)
    return result


def scalar(node):
    kind = node['kind']
    if kind == 'float':
        return float.fromhex(node['hex'])
    if kind in ('NoneType', 'int', 'str', 'bool'):
        return node['value']
    if kind == 'dict':
        return {k: scalar(v) for k, v in node['items'].items()}
    if kind in ('list', 'tuple'):
        return [scalar(v) for v in node['items']]
    return node  # Arrays and dataclasses remain opaque original descriptors.


def check_packet(blob, meta):
    assert sha(blob) == meta['npz_sha256']
    descriptors = arrays(meta['tree'])
    assert len(descriptors) == meta['array_count']
    fortran = []
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and set(names) == {k + '.npy' for k in descriptors}
        for name, d in descriptors.items():
            raw = archive.read(name + '.npy')
            assert raw[:6] == b'\x93NUMPY' and tuple(raw[6:8]) in ((1,0), (2,0), (3,0))
            width = 2 if raw[6] == 1 else 4
            header_size = int.from_bytes(raw[8:8+width], 'little')
            start = 8 + width + header_size
            h = ast.literal_eval(raw[8+width:start].decode())
            assert set(h) == {'descr','fortran_order','shape'}
            assert h['descr'] == d['dtype'] and list(h['shape']) == d['shape']
            assert re.fullmatch(r'[<>=|][biuf][1248]', h['descr'])
            assert type(h['fortran_order']) is bool
            itemsize, shape = int(h['descr'][2:]), h['shape']
            payload = raw[start:]
            count = math.prod(shape)
            assert len(payload) == count * itemsize
            if h['fortran_order']:
                fortran.append(name)
                # Independent F-linear -> C-linear permutation of opaque items.
                # No struct float decode, array import, or numerical operation.
                reordered = bytearray(len(payload))
                for source_index in range(count):
                    remainder = source_index
                    destination_index = 0
                    for dimension in shape:
                        coordinate = remainder % dimension
                        remainder //= dimension
                        destination_index = destination_index * dimension + coordinate
                    reordered[destination_index*itemsize:(destination_index+1)*itemsize] = payload[source_index*itemsize:(source_index+1)*itemsize]
                payload = bytes(reordered)
            assert sha(payload) == d['c_order_sha256']
    return len(descriptors), fortran


def main():
    package = json.loads((BASE / (LABEL + '-package.json')).read_bytes())
    blob = (BASE / package['archive']).read_bytes()
    assert sha(blob) == package['sha256'] == '1da564dddfcf23ec7a39669309337cfc6064209571d4619f3cd3d2800c749c31'
    files = unpack(blob)
    assert len(files) == package['artifacts'] == 144 and len(blob) == package['bytes']
    check_inventory(files, 'artifact-inventory.json')
    original_blob = files['original-result.tar.gz']
    assert sha(original_blob) == '44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef'
    original = unpack(original_blob)
    assert len(original) == 86
    assert all(files['result/' + n] == b for n, b in original.items())
    stage = unpack(files['executed-stage.tar.gz'])
    stage_index = check_inventory(stage, 'stage-inventory.json')
    assert len(stage) == 23
    for directory, expected, count, result_prefix in (
        ('preparation', '858566c1b94b1852ed01f38e78e0dfe43456f2eb2efd39b1c81885e363d2441a', 12, 'probe/controls'),
        ('execution', 'dafb1301902086870ab55efc897d247c31fd23359368af276905ff3e6ffefdb7', 5, 'execution-controls')):
        raw = stage[directory + '/CONTROLS_SHA256.json']
        assert sha(raw) == expected
        manifest = json.loads(raw)
        assert len(manifest) == count
        for name in [*manifest, 'CONTROLS_SHA256.json']:
            value = stage[directory + '/' + name]
            if name in manifest:
                assert sha(value) == manifest[name]
            assert original[result_prefix + '/' + name] == value
    for name in ('stage-before.json', 'stage-after.json'):
        record = json.loads(original[name])
        assert record['passed'] and record['actual'] == record['expected'] == stage_index and not record['mismatches']
    binding = json.loads(stage['preparation/BINDINGS.json'])
    prior = {}
    for kind, count in [('pu', 100), ('pt', 111)]:
        old_blob = stage[kind + '-evidence.tar.gz']
        assert sha(old_blob) == binding[kind.upper() + '_archive_sha256']
        prior[kind] = unpack(old_blob)
        assert len(prior[kind]) == count
        check_inventory(prior[kind], 'artifact-inventory.json')
    pt_stage = unpack(prior['pt']['executed-stage.tar.gz'])
    source = unpack(pt_stage['source.tar.gz'])
    source_manifest = json.loads(source['SOURCE_SHA256.json'])
    assert len(source_manifest) == 584 and set(source) == set(source_manifest) | {'SOURCE_SHA256.json'}
    assert sha(pt_stage['source.tar.gz']) == binding['source_archive_sha256']
    assert sha(source['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
    assert all(sha(source[n]) == h for n,h in source_manifest.items())
    terminal = files[LABEL + '-closure/qstat.stdout'].decode()
    assert 'Job Id: 1700.manager' in terminal
    for key, value in [('job_state','F'), ('Exit_status','1'), ('Stageout_status','0')]:
        assert re.search(r'^\s*' + key + ' = ' + value + r'\s*$', terminal, re.M)
    assert original['worker-exit.txt'].strip() == original['pbs-command-exit.txt'].strip() == b'1'
    assert original['diagnostic-status.txt'].strip() == original['probe/diagnostic-status.txt'].strip() == b'0'
    assert original['setup-exit.txt'].strip() == original['stage-after-exit.txt'].strip() == b'0'
    remote = json.loads(files[LABEL + '-closure/compute.stdout'])
    assert remote['result_archive_sha256'] == sha(original_blob)
    assert base64.b64decode(remote['files']['pbs-exit.txt']).strip() == b'1'
    receipt = json.loads(original['probe/receipt.json'])
    assert receipt['pbs_job'] == '1700.manager' and receipt['actual_child_returncode'] is None
    assert receipt['original_reference_wrapper_calls'] == 1 and receipt['original_reference_wrapper_returns'] == 0
    assert receipt['original_exception_message'] == binding['expected_exception']
    assert binding['expected_exception'] in original['worker.stderr'].decode()
    assert receipt['diagnostic_status'] == 0 and receipt['immutable_checks_passed']
    assert receipt['conditional_roots_validated'] == ['stored_ambient']
    assert receipt['diagnostic_progress'] == dict(evaluate_calls_started=589, evaluate_calls_returned=589)
    assert receipt['full_column_calls'] == receipt['GPU_calls'] == receipt['physical_time_steps_completed'] == 0
    assert receipt['original_model_repaired'] is receipt['scientific_model_acceptance'] is False
    for name in ('source-before-diagnostic.json','source-after-diagnostic.json'):
        assert json.loads(original['probe/' + name]) == source_manifest
    input_checks = [json.loads(original['probe/' + n]) for n in (
        'input-before-diagnostic.json','input-after-diagnostic.json','original-model/input-before.json','original-model/input-after.json')]
    assert len(input_checks[0]) == 15 and all(x == input_checks[0] for x in input_checks)
    packet = {n.removeprefix('probe/original-model/'): b for n,b in original.items() if n.startswith('probe/original-model/')}
    packet.update({'source-nm/' + n: b for n,b in source.items()})
    assert len(packet) == 605
    actual_packet = {n:sha(b) for n,b in packet.items()}
    assert actual_packet == json.loads(original['probe/original-packet-before-diagnostic.json']) == json.loads(original['probe/original-packet-after-diagnostic.json'])
    typed = {}
    fortran = {}
    for name, value in original.items():
        if name.endswith('.json'):
            meta = json.loads(value)
            if isinstance(meta, dict) and meta.get('schema') == 'PT-lossless-return-v1':
                stem = name[:-5]
                typed[stem], f = check_packet(original[stem + '.npz'], meta)
                if f:
                    fortran[stem] = f
                assert sha(original[stem + '.pkl']) == meta['pickle_sha256']
    assert len(typed) == 9 and sum(typed.values()) == 572
    assert fortran == {f'probe/diagnostic/{name}-diagnostic': ['return/optimizer_result/jac'] for name in ('stalled_x','stored_ambient')}
    closure = [json.loads(original['probe/' + name + '.json'])['tree'] for name in (
        'closure-before-diagnostic','closure-after-diagnostic','diagnostic/closure-before','diagnostic/closure-after')]
    assert all(x == closure[0] for x in closure)
    summary = scalar(json.loads(original['probe/diagnostic/diagnostic-summary.json'])['tree'])
    assert summary['additional_original_evaluate_calls_started'] == summary['additional_original_evaluate_calls_returned'] == 589
    assert summary['original_closure_before_after_exact'] and summary['original_exception_retained']
    starts = []
    for name, count, root in [('stalled_x',288,False), ('stored_ambient',301,True)]:
        meta = json.loads(original['probe/diagnostic/' + name + '-diagnostic.json'])
        entry = scalar(meta['tree'])
        descriptors = arrays(meta['tree'])
        assert entry['counters'] == dict(started=count,returned=count,detail_started=1,detail_returned=1)
        assert descriptors['return/returned_evaluations/x']['shape'] == descriptors['return/returned_evaluations/r12']['shape'] == [count,12]
        assert descriptors['return/returned_evaluations/seconds']['shape'] == descriptors['return/returned_evaluations/detail_call']['shape'] == [count]
        assert entry['original_solver_tolerance'] == 1e-7 and entry['original_physical_tolerance'] == 1e-7*1.01
        assert entry['finite_residuals'] and entry['within_original_bounds'] and entry['first_evaluated_point_equals_declared_seed']
        assert entry['diagnostic_root_found'] is root and entry['optimizer_returned']
        assert entry['seconds'] < 45 and count <= 6000
        r, p = entry['maximum_original_12_residual'], entry['maximum_original_physical11_residual']
        assert math.isfinite(r) and math.isfinite(p)
        assert (r <= 1e-7 and p <= 1e-7*1.01) is root
        starts.append(dict(name=name, calls=count, seconds=entry['seconds'], root=root, r12_max=r, physical11_max=p,
            optimizer_status=entry['optimizer_result']['status'], optimizer_nfev=entry['optimizer_result']['nfev']))
    assert starts[0]['r12_max'] == 10.769007465341872 and starts[0]['physical11_max'] == 1.7446254742888212
    assert starts[1]['r12_max'] == starts[1]['physical11_max'] == 9.61564161627848e-13
    readout = json.loads(files['readout.json'])
    assert readout == json.loads((BASE / (LABEL + '-readout.json')).read_bytes())
    for actual, row in zip(starts, readout['starts']):
        assert actual['name'] == row['name'] and actual['calls'] == row['counters']['started'] == row['counters']['returned']
        assert actual['r12_max'] == row['maximum_original_12_residual'] and actual['physical11_max'] == row['maximum_original_physical11_residual']
        assert actual['root'] is row['diagnostic_root_found']
    report = dict(passed=True, blocking_findings=[], scope='Independent PW1700 closed evidence review, not model acceptance or root-cause inference.',
        archive_sha256=sha(blob), archive_members=144, result_sha256=sha(original_blob), result_files=86,
        actual_job='1700.manager', actual_PBS_state='F', actual_PBS_exit=1, Stageout_status=0,
        actual_worker_exit=1, diagnostic_status=0, original_reference_calls=1, original_reference_returns=0,
        original_exception=binding['expected_exception'], additional_evaluate_started=589, additional_evaluate_returned=589,
        starts=starts, source_files=584, encoded_inputs=15, original_packet_files=605,
        all_source_input_packet_closure_before_after_exact=True, typed_packets=9, opaque_array_payloads=572,
        fortran_array_members=fortran,
        fortran_check='Independent F-linear to C-linear permutation of dtype-sized opaque byte slices; no floating-point value decoding.',
        preparation_manifest_sha256=sha(stage['preparation/CONTROLS_SHA256.json']), execution_manifest_sha256=sha(stage['execution/CONTROLS_SHA256.json']),
        no_model_repair_or_GPU_or_column_or_year_or_scientific_acceptance=True,
        limitations=['Root feasibility applies to this original fixed active mask and bounds; no causal conclusion.',
                     'Original Qia model failure remains PBS/worker1. Diagnostic0 does not convert it to a model pass.',
                     '589 residual evaluations are extra physics-function diagnostic work, not completed model timesteps.',
                     'Array descriptors and payload bytes were verified; numerical maxima are original EHPC JSON scalars, not recomputed locally.'],
        verifier_sha256=sha(Path(__file__).read_bytes()))
    target = BASE / (LABEL + '-actual-independent-review-rg.json')
    target.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(passed=True, review_sha256=sha(target.read_bytes()), typed=9, opaque_payloads=572, starts=starts)))


if __name__ == '__main__':
    main()

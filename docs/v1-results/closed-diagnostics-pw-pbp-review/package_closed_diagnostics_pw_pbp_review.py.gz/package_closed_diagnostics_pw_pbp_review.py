"""Preserve independent closed-evidence reviews; standard-library metadata only."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
LABEL = 'closed-diagnostics-pw-pbp-review'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
names = ('surface-7275-feasible-root-pw-actual-independent-review-rg.json',
         'review_surface_feasible_root_pw_actual_rg.py',
         'clm-drainage-adapter-pb-p-b-independent-review-rg.json',
         'review_drainage_adapter_pbp_b_actual_rg.py',
         'verify_pu_pv_px_root.py', Path(__file__).name)
items = {name: (BASE / name).read_bytes() for name in names}
for name in (names[0], names[2]):
    review = json.loads(items[name])
    assert review['passed'] and not review['blocking_findings']
result = subprocess.run([sys.executable, '-X', 'utf8', str(BASE / 'verify_pu_pv_px_root.py')],
                        capture_output=True, check=True)
assert not result.stderr
proof = json.loads(result.stdout)
assert proof['passed'] and len(proof['archives']) == 5
assert all(row['published_artifacts'] == row['artifacts'] for row in proof['archives'])
items['root-static-publication-proof.json'] = result.stdout
items['artifact-inventory.json'] = encode({name: dict(bytes=len(raw), sha256=sha(raw))
                                         for name, raw in sorted(items.items())})
target = BASE / (LABEL + '-evidence.tar.gz')
assert not target.exists()
with target.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, raw in sorted(items.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(raw), 0o644
            archive.addfile(entry, io.BytesIO(raw))
with tarfile.open(target) as archive:
    assert {member.name: archive.extractfile(member).read() for member in archive} == items
package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
    artifacts=len(items), scope='Independent static reviews of PW1700 original model F1 / diagnostic0 '
    'and PB-p-b1695 23/24 F1, plus root archive/inventory/publication proof. '
    'No local numerical decoding or model execution, no repair, GPU, annual or scientific acceptance.')
(BASE / (LABEL + '-package.json')).write_bytes(encode(package))
print(json.dumps(package))

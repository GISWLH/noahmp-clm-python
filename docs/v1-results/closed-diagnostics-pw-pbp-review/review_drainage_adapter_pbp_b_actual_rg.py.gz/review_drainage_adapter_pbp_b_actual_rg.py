"""Review closed PB-p-b bytes, raw statuses and stored scalars; no NumPy."""
import ast
import hashlib
import io
import json
import math
from pathlib import Path
import re
import struct
import tarfile
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parent
LABEL = 'clm-drainage-adapter-pb-p-b'
sha = lambda b: hashlib.sha256(b).hexdigest()


def unpack(blob):
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        members = archive.getmembers()
        assert all((m.isfile() or m.isdir()) and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        members = [m for m in members if m.isfile()]
        names = [m.name.removeprefix('./') for m in members]
        assert len(names) == len(set(names))
        return {name: archive.extractfile(m).read() for name, m in zip(names, members)}


def inventory(files, name):
    index = json.loads(files[name])
    assert set(index) == set(files) - {name}
    for n, entry in index.items():
        expected = entry if isinstance(entry, str) else entry['sha256']
        assert sha(files[n]) == expected
        if isinstance(entry, dict):
            assert len(files[n]) == entry['bytes']


def npz_headers(blob):
    result = {}
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and all(n.endswith('.npy') for n in names)
        for name in names:
            raw = archive.read(name)
            assert raw[:6] == b'\x93NUMPY'
            major, minor = raw[6:8]
            assert major in (1, 2, 3) and minor == 0
            start = 10 if major == 1 else 12
            size = struct.unpack('<H' if major == 1 else '<I', raw[8:start])[0]
            header = ast.literal_eval(raw[start:start+size].decode('utf8' if major == 3 else 'latin1').strip())
            assert set(header) == {'descr', 'fortran_order', 'shape'} and not header['fortran_order']
            dtype = header['descr']
            assert isinstance(dtype, str) and re.fullmatch(r'[<>=|][biuf][1248]', dtype)
            payload = raw[start+size:]
            assert len(payload) == math.prod(header['shape']) * int(dtype[2:])
            result[name[:-4]] = dict(dtype=dtype, shape=list(header['shape']), bytes=len(payload), c_order_sha256=sha(payload))
    return result


def scalars(value):
    if isinstance(value, list):
        return [x for child in value for x in scalars(child)]
    assert type(value) in (float, int) and math.isfinite(value)
    return [value]


def main():
    package = json.loads((BASE / (LABEL + '-package.json')).read_bytes())
    blob = (BASE / package['archive']).read_bytes()
    assert sha(blob) == package['sha256'] == '245bf8564b19cae636d3a3036b0c6bb0ec22759a93575b65db0db54b447156bb'
    assert len(blob) == package['bytes']
    files = unpack(blob)
    assert len(files) == package['artifacts'] == 139
    inventory(files, 'artifact-inventory.json')
    raw_blob = files['original-result.tar.gz']
    assert sha(raw_blob) == package['raw_result_sha256'] == '31a0e40de7119a43042d5a850f1480ad121a77fc08da5cc3b6dd158e9b7de400'
    raw = unpack(raw_blob)
    raw_index = json.loads(files['original-result-inventory.json'])
    assert len(raw) == 1103 and set(raw_index) == set(raw)
    assert all(sha(raw[n]) == r['sha256'] and len(raw[n]) == r['bytes'] for n, r in raw_index.items())
    status = files['closure/actual-qstat.stdout.txt'].decode()
    assert 'Job Id: 1695.manager' in status
    for key, value in [('job_state', 'F'), ('Exit_status', '1'), ('Stageout_status', '0')]:
        assert re.search(r'^\s*' + key + r' = ' + value + r'\s*$', status, re.M)
    assert files['closure/compute-pbs-exit.stdout.txt'].strip() == raw['worker-exit.txt'].strip() == b'1'
    receipt = json.loads(raw['receipt.json'])
    assert receipt['numerical_parent_returncode'] == 1 and receipt['collect_parent_returncode'] == 0
    assert receipt['passed'] is False and receipt['pbs_job'] == '1695.manager'
    cases = list(ET.fromstring(raw['tests.xml']).iter('testcase'))
    failures = [c for c in cases if c.find('failure') is not None]
    assert len(cases) == 24 and len(failures) == 1
    assert all(c.find('error') is None and c.find('skipped') is None for c in cases)
    failed = failures[0]
    assert failed.attrib['name'] == 'test_adapter_independent_physics_reference[nonuniform_dz-float64]'
    failure_text = failed.find('failure').text
    assert 'source/src/noahmp_clm/gpu/clm_drainage_primitives.py:65: ValueError' in failure_text
    assert 'Invalid stock, phase partition, geometry, rate or trial limits' in failure_text
    nodes = json.loads(raw['collect-nodes.json'])
    assert nodes == json.loads(raw['run-nodes.json']) and len(nodes) == len(set(nodes)) == 24
    assert {n.split('::', 1)[1] for n in nodes} == {c.attrib['name'] for c in cases}
    assert re.search(r'^1 failed, 23 passed, 1 warning in 16\.76s$', raw['numerical.stdout.txt'].decode(), re.M)
    before = json.loads(raw['immutable-before.json'])
    assert before == json.loads(raw['immutable-after.json']) and len(before) == 1033
    assert all(sha(raw[n]) == h for n, h in before.items())
    source = json.loads(raw['source/SOURCE_SHA256.json'])
    parent = json.loads(raw['reference/BASE_PBL_SOURCE_SHA256.json'])
    assert len(source) == 596 and all(sha(raw['source/' + n]) == h for n, h in source.items())
    assert len(parent) == 586 and all(source[n] == h for n, h in parent.items())
    for folder, count in [('preparation', 19), ('execution', 7), ('reference', 4)]:
        control = json.loads(raw[folder + '/CONTROLS_SHA256.json'])
        assert len(control) == count and all(sha(raw[folder + '/' + n]) == h for n, h in control.items())
    stage = unpack(files['original-executed-stage.tar.gz'])
    inventory(stage, 'stage-inventory.json')
    assert len(stage) == 37
    dispatch = json.loads(files['scheduler/dispatch.json'])
    assert dispatch['stage_archive_sha256'] == sha(files['original-executed-stage.tar.gz'])
    binding = json.loads(raw['preparation/BINDINGS.json'])
    assert sha(stage['source.tar.gz']) == binding['source_archive_sha256']
    assert unpack(stage['source.tar.gz']) == {n.removeprefix('source/'): b for n, b in raw.items() if n.startswith('source/')}
    gold = {n.removeprefix('sealed-gold/'): b for n, b in raw.items() if n.startswith('sealed-gold/')}
    inventory(gold, 'artifact-inventory.json')
    assert len(gold) == 345 and unpack(stage['gold.tar.gz']) == gold
    recipes = json.loads(gold['gold/case-recipes.json'])
    assert len(recipes) == 20
    gold_header_arrays = gold_runtime_asserted_fields = 0
    for recipe in recipes:
        for leaf in ('input32.npz', 'numpy32.npz'):
            name = 'gold/' + recipe['name'] + '/' + leaf
            meta = json.loads(gold[name + '.json'])
            assert sha(gold[name]) == meta['npz_sha256']
            headers = npz_headers(gold[name])
            assert headers == meta['arrays']
            gold_header_arrays += len(headers)
            if leaf == 'numpy32.npz':
                gold_runtime_asserted_fields += sum(k.startswith(('diagnosis.', 'trial.')) for k in headers)
    assert gold_runtime_asserted_fields == 647
    gold_log = [json.loads(line.split('PB_P_GOLD ', 1)[1]) for line in raw['numerical.stdout.txt'].decode().splitlines() if 'PB_P_GOLD ' in line]
    assert gold_log == json.loads(raw['parsed-gold-records.json']) == [dict(cases=20, diagnostic_trial_fields_byteexact=647, full_integrations=0)]
    records = json.loads(raw['parsed-diagnostics.json'])
    log_records = [json.loads(line.split('PB_P_DIAGNOSTIC ', 1)[1]) for line in raw['numerical.stdout.txt'].decode().splitlines() if 'PB_P_DIAGNOSTIC ' in line]
    assert records == log_records and len(records) == 16
    assert 'results/nonuniform_dz-float64.npz' not in raw
    result_arrays = 0
    for record in records:
        saved = json.loads(raw['results/' + record['case'] + '.json'])
        assert saved['comparisons'] == record['comparisons']
        data = raw['results/' + saved['file']]
        assert sha(data) == saved['sha256']
        headers = npz_headers(data)
        assert set(headers) == set(saved['arrays'])
        for k, value in saved['arrays'].items():
            assert all(headers[k][field] == value[field] for field in value)
        result_arrays += len(headers)
        comparisons = record['comparisons']
        assert all(item['passed'] is True for item in comparisons.values())
        for item in comparisons.values():
            if 'signed_difference' in item:
                differences, bounds = scalars(item['signed_difference']), scalars(item['bound'])
                assert len(differences) == len(bounds) and all(abs(d) <= b for d, b in zip(differences, bounds))
                assert max(map(abs, differences), default=0) == item['maximum_absolute_difference']
        for key, residuals in [('hard_budget', [('water_residual','water_bound'), ('heat_residual','heat_bound')]),
                               ('reference_hard_budget', [('water_residual_kg_m2','water_bound_kg_m2'), ('energy_residual_j_m2','energy_bound_j_m2')])]:
            for residual, bound in residuals:
                r, b = comparisons[key][residual], comparisons[key][bound]
                assert math.isfinite(r) and math.isfinite(b) and b >= 0 and abs(r) <= b
    observation = json.loads(raw['run-observation.json'])
    assert observation['calls'] == receipt['actual_calls']
    assert not observation['cupy_imported'] and not observation['jax_imported']
    assert receipt['coupled_column_runs'] == receipt['official_caller_runs'] == 0
    assert observation['calls']['main_trial'] == dict(attempted=85, returned=84, raised=1,
        requested_backend_counts={'numpy':85}, returned_backend_counts={'numpy':84})
    readout = json.loads(files['run-readout.json'])
    assert readout == json.loads((BASE / (LABEL + '-readout.json')).read_bytes())
    assert readout['receipt'] == receipt
    rows = readout['successful_diagnostic_records']
    assert len(rows) == 16 and {r['case'] for r in rows} == {r['case'] for r in records}
    by_case = {r['case']: r['comparisons'] for r in records}
    for row in rows:
        v = by_case[row['case']]
        assert row['saturated_mass_kg_m2'] == v['saturated.drained_kg_m2']['actual']
        assert row['perched_mass_kg_m2'] == v['perched.drained_kg_m2']['actual']
        assert row['largest_layer_mass_difference_kg_m2'] == max(x['maximum_absolute_difference'] for k,x in v.items() if 'layer_mass' in k)
        assert row['largest_layer_enthalpy_difference_j_m2'] == max(x['maximum_absolute_difference'] for k,x in v.items() if 'layer_enthalpy' in k)
        assert row['largest_temperature_difference_k'] == v['temperature']['maximum_absolute_difference']
        assert row['independent_represented_stock_budget'] == v['hard_budget']
        assert row['reference_hard_budget'] == v['reference_hard_budget']
        original_ledger = json.loads(raw['results/' + row['case'] + '-original-reference.json'])
        assert all(original_ledger[k] == value for k,value in v['reference_hard_budget'].items() if k != 'passed')
    maxima = {field: max(rows, key=lambda r: r[field]) for field in (
        'largest_layer_mass_difference_kg_m2', 'largest_layer_enthalpy_difference_j_m2', 'largest_temperature_difference_k')}
    report = dict(passed=True, blocking_findings=[], scope='Independent closed-evidence review, not a successful model/test claim.',
        actual_job='1695.manager', actual_PBS_state='F', actual_PBS_exit=1, Stageout_status=0,
        actual_worker_exit=1, actual_pytest_exit=1, tests=24, passed_tests=23, failed_tests=1, skipped=0,
        warnings=1, warning_scope='Overflow during the intentional rejected float16 raw-input cast; original warning preserved.',
        failed_node=failed.attrib['name'], failure_observed='Original main primitive input-domain ValueError during second-half adaptive trial, before completed adapter reference/budget comparison. Exact rejecting predicate remains unestablished.',
        physical_bias_failure_claimed=False, source_files=596, parent586_exact=True, immutable_files_exact=1033,
        archive_sha256=sha(blob), archive_members=139, raw_result_sha256=sha(raw_blob), raw_result_members=1103,
        successful_records=16, successful_npz_array_headers_and_payload_hashes_verified=result_arrays,
        gold_cases=20, gold_npz_array_headers_and_payload_hashes_verified=gold_header_arrays,
        gold_runtime_dtype_shape_byte_assertions=647,
        gold_parity_evidence_scope='Original passing test/log checks all 647 returned fields against sealed gold. This independent review verifies original assertions, golden descriptors/payload hashes and execution status; it does not recompute arrays or claim separately archived new gold-return arrays.',
        original_completed_case_budget_and_difference_records=rows,
        largest_recorded_differences={k:dict(case=v['case'], value=v[k]) for k,v in maxima.items()},
        actual_calls=receipt['actual_calls'], no_GPU_or_JAX_import=True, no_full_column_or_official_new_caller_or_year_or_production_credit=True,
        limitations=['Failed nonuniform float64 case has no final adapter output, hard budget or reference difference result.',
                     'Tiny-negative-ice explanation remains an unconfirmed hypothesis; truncated raw failure cannot establish the rejecting predicate.',
                     'All numbers are archived EHPC results or scalar comparisons of those records; no local numerical array or physical execution.'],
        verifier_sha256=sha(Path(__file__).read_bytes()))
    target = BASE / (LABEL + '-independent-review-rg.json')
    target.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(passed=True, review_sha256=sha(target.read_bytes()), array_headers=result_arrays,
        gold_headers=gold_header_arrays, recorded_maxima=report['largest_recorded_differences'])))


if __name__ == '__main__':
    main()

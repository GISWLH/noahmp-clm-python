"""Independent static archive/inventory and publication proof; stdlib only."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/v1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
rows = []
for label in ('surface-7275-frame-trace-pu', 'cpu-year-status-pv', 'candidate-progress-px',
              'clm-drainage-adapter-pb-p-b', 'surface-7275-feasible-root-pw'):
    package = json.loads((OUT / (label + '-package.json')).read_bytes())
    archive = OUT / package['archive']
    assert sha(archive.read_bytes()) == package['sha256']
    with tarfile.open(archive) as handle:
        items = {}
        for member in handle:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in items
            items[member.name] = handle.extractfile(member).read()
    assert len(items) == package['artifacts']
    inventory_names = [name for name in items if name in ('inventory.json', 'artifact-inventory.json')]
    assert len(inventory_names) == 1
    inventory_name = inventory_names[0]
    inventory = json.loads(items[inventory_name])
    assert set(inventory) == set(items) - {inventory_name}
    for name, descriptor in inventory.items():
        assert sha(items[name]) == descriptor['sha256']
        assert len(items[name]) == descriptor['bytes']
    destination = ROOT / 'docs/v1-results' / label
    published = None
    if destination.exists():
        manifest = json.loads((destination / 'manifest.json').read_bytes())
        assert manifest['archive_sha256'] == package['sha256']
        assert len(manifest['artifacts']) == len(items)
        assert {item['source'] for item in manifest['artifacts']} == set(items)
        for item in manifest['artifacts']:
            raw = (destination / item['path']).read_bytes()
            assert sha(raw) == item['stored_sha256']
            original = gzip.decompress(raw) if item['path'] == item['source'] + '.gz' else raw
            assert original == items[item['source']]
            assert sha(original) == item['source_sha256']
        published = len(manifest['artifacts'])
    rows.append(dict(label=label, artifacts=len(items), inventory_entries=len(inventory),
                     archive_sha256=package['sha256'], published_artifacts=published))
print(json.dumps(dict(passed=True, archives=rows,
    scope='Raw hashes/inventory/publication only. No model, numerical array or pickle decoding; no scientific acceptance.')))

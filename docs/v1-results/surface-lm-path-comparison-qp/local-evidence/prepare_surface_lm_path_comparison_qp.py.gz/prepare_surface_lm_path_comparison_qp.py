"""Metadata-only QP stage freeze. Submission requires root worker review."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-path-comparison-qp'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
INPUTS={
    'qn':('surface-lm-merit-qn-result.tar.gz','3f774feeb13b6556eb2228bb2d4727dd3684ec85c51dfe3a920f5085ecb14553'),
    'qf':('surface-lm-transparent-trace-qf-result.tar.gz','1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd'),
    'qm':('surface-lm-event-analysis-qm-result.tar.gz','74eea2098ab3a0cd9992e694596c8f3de51f99368470a7d2d0308385fe3ba416'),
    'pw':('surface-7275-feasible-root-pw-result.tar.gz','44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')}


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution')
    assert not execution.exists();execution.mkdir()
    raw_inputs={name:(BASE/path).read_bytes() for name,(path,_) in INPUTS.items()}
    assert all(sha(raw_inputs[name])==expected for name,(_,expected) in INPUTS.items())
    with tarfile.open(fileobj=io.BytesIO(raw_inputs['qf'])) as t:
        serializer=t.extractfile('./probe/trace/run_reference_pt.py').read()
    assert serializer==(BASE/'surface-lm-event-analysis-qm-preparation/serialization_pt.py').read_bytes()
    (prep/'serialization_pt.py').write_bytes(serializer)
    worker=prep/'analyze_saved_paths_qp.py';tree=ast.parse(worker.read_bytes())
    imports=[node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)]
    imports.extend(alias.name for node in ast.walk(tree) if isinstance(node,ast.Import) for alias in node.names)
    assert not any(name and name.startswith('noahmp_clm') for name in imports)
    assert not any(isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ('loads','load') and isinstance(node.func.value,ast.Name) and node.func.value.id=='pickle' for node in ast.walk(tree))
    inventory=(BASE/(LABEL+'-inventory.json')).read_bytes()
    assert sha(inventory)=='00d06394db2ce66140ae507f1ac77f68bb789e611078d9bd1a6e5f2faf4c8cca'
    (prep/'original-record-inventory.json').write_bytes(inventory)
    (prep/'PLAN.md').write_bytes((BASE/(LABEL+'-PLAN.md')).read_bytes())
    (prep/'BINDINGS.json').write_bytes(encode(dict(
        input_archives={name:dict(local_file=path,sha256=expected) for name,(path,expected) in INPUTS.items()},
        serializer_sha256=sha(serializer),worker_sha256=sha(worker.read_bytes()),inventory_sha256=sha(inventory),
        original_QN_model_exit=1,original_QF_model_exit=1,original_QM_analysis_exit=0,
        model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,new_reference_solves=0,
        source_or_controls_modified=False,physical_source_imported=False,
        PW_scope='Saved function evaluations and final optimizer fields only; no accepted PW iteration path is invented. Root remains posthoc, never a seed.',
        missing_records=['PW accepted iterates/per-iteration lambda/radius/scale','QN full per-point gas/root-uptake/limiter margins'],
        no_basin_local_minimum_or_physical_degeneracy_conclusion=True)))
    (prep/'README.md').write_bytes(b'One prepared1CPU2GiB5min EHPC PBS algebra job, not submitted until root reads this worker. Authenticate all4 original QN/QF/QM/PW archives and lossless typed payloads; original model source is not imported. All27 arguments are independently compared to the original PW frame. QN/QF final J/r/x/scale/gradient must match their exact refresh-point bytes and field ages. Existing J/JS SVD reports weak left/right modes, dominant rows and physical coordinates, projections and singular values without forming normal equations. QN23 actual accepted trials are compared only to PW returned function evaluations; unavailable accepted PW path/lambda/radius/scale stays missing. Original exchange/supply constants are read; water_velocity is explicit alias selection from saved fields, +inf is retained, effective shared-soil ground cap uses only each saved PW detail at its own point. No fresh model/evaluate/J or reference solve, seed/mask/equation/gate/budget change. Near-singular J and small gradient do not prove a nonlinear local minimum or physical degeneracy. Raw pickle precedes typedJSON/NPZ, nonfinite floats use explicithex. Before/after hashes and actual child/PBS status preserved.\n')
    (prep/'STATIC_CHECKS.json').write_bytes(encode(dict(AST_parse_exit=0,model_imports=0,pickle_load_calls=0,
        numerical_execution=0,prepared_only=True,all27_identity_rechecked_on_remote_worker=True)))
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(prep.iterdir()) if p.is_file()}))
    old=BASE/'surface-lm-event-analysis-qm-execution';patches=[]
    for original_name,target_name in [('check_stage_qm.py','check_stage_qp.py'),('dispatch_analysis_qm.py','dispatch_analysis_qp.py')]:
        original=(old/original_name).read_bytes()
        changed=original.replace(b'noahmp-surface-lm-event-analysis-qm',b'noahmp-surface-lm-path-comparison-qp')
        changed=changed.replace(b'analysis_qm',b'analysis_qp')
        (execution/target_name).write_bytes(changed)
        patches.append(''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile='QM/'+original_name,tofile='QP/'+target_name)))
    original=(old/'analysis_qm.pbs').read_bytes()
    pbs=original.replace(b'surface-lm-event-qm',b'surface-lm-path-qp').replace(b'noahmp-surface-lm-event-analysis-qm',b'noahmp-surface-lm-path-comparison-qp')
    pbs=pbs.replace(b'qm-result',b'qp-result').replace(b'check_stage_qm',b'check_stage_qp').replace(b'analyze_saved_lm_events_qm.py',b'analyze_saved_paths_qp.py')
    needle=b'--qf "$stage/qf-result.tar.gz" --pw "$stage/pw-result.tar.gz"'
    assert pbs.count(needle)==1
    pbs=pbs.replace(needle,b'--qn "$stage/qn-result.tar.gz" --qf "$stage/qf-result.tar.gz" --qm "$stage/qm-result.tar.gz" --pw "$stage/pw-result.tar.gz"')
    assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs
    (execution/'analysis_qp.pbs').write_bytes(pbs)
    patches.append(''.join(difflib.unified_diff(original.decode().splitlines(True),pbs.decode().splitlines(True),fromfile='QM/analysis_qm.pbs',tofile='QP/analysis_qp.pbs')))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'README.md').write_bytes(b'Mechanical QM unique manager/compute transfer/hash/qsub wrapper. Only privateQP path, worker and4 bound raw input arguments change;1CPU2GiB5min remains. LF/shebang, before/after stage checks and worker/PBS actual exits retained. Numerical analysis success is distinct from originalQN1856/QF1844 model failures. Prepared only; root must read worker before submission.\n')
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={folder+'/'+p.name:p.read_bytes() for folder,directory in [('preparation',prep),('execution',execution)] for p in directory.iterdir() if p.is_file()}
    items.update({name+'-result.tar.gz':raw for name,raw in raw_inputs.items()})
    items['stage-inventory.json']=encode({name:sha(raw) for name,raw in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(raw);t.addfile(entry,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    result=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),
        worker_sha256=sha(worker.read_bytes()),PBS_LF_shebang_verified=True,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        physical_source_imported=False,submission_performed=False,root_worker_review_required=True)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(result));print(json.dumps(result))


if __name__=='__main__':main()

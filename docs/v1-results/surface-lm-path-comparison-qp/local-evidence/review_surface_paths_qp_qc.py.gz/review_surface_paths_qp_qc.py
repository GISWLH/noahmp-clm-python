"""Independent static-only review of LM saved-path QP; no numeric imports."""
import ast
import json
from pathlib import Path

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent


def main():
    label='surface-lm-path-comparison-qp';raw=(BASE/(label+'-stage.tar.gz')).read_bytes()
    assert sha(raw)=='5b0bee7af8256dae739aa10822d7b773142d3eb646d2ba102bda6ad18f6c79b0'
    stage=files(raw);index=json.loads(stage['stage-inventory.json']);assert len(stage)==19 and set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    bind=json.loads(stage['preparation/BINDINGS.json']);worker=stage['preparation/analyze_saved_paths_qp.py'];ast.parse(worker)
    assert sha(worker)==bind['worker_sha256']=='5c4e82fe3c27f9febdc2aa3ea28293009d447923b71f0e0d7baf2f27f3ddd96f'
    assert worker==(BASE/(label+'-preparation/analyze_saved_paths_qp.py')).read_bytes()
    assert sha(stage['preparation/serialization_pt.py'])==bind['serializer_sha256']
    inputs={}
    for name,v in bind['input_archives'].items():
        value=(BASE/v['local_file']).read_bytes();assert sha(value)==v['sha256'];inputs[name]=files(value,directories=True)
    before=json.loads(inputs['qn']['probe/actual-row-0/first-phase-before.json'])['tree']['items']
    frame=json.loads(inputs['pw']['probe/original-model/phase-final-frame.json'])['tree']['items']['frames']['items'][0]['items']['locals']['items']
    def strip_array_key(v):
        if isinstance(v,dict):return {k:strip_array_key(x) for k,x in v.items() if not (v.get('kind')=='array' and k=='key')}
        if isinstance(v,list):return [strip_array_key(x) for x in v]
        return v
    checks={k:strip_array_key(v)==strip_array_key(frame[k]) for k,v in before.items()};assert len(checks)==27 and all(checks.values())
    pbs=stage['execution/analysis_qp.pbs'];assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs and b'walltime=00:05:00' in pbs and b'ncpus=1:mem=2gb' in pbs
    for name,b in stage.items():
        if name.endswith('.py'):ast.parse(b)
    report=dict(passed=True,blocking_findings=[],scope='Independent readonly static/code/hash and original JSON typed descriptor review only; no numerical package import, NPZ decode, unpickle, model/evaluate/Jacobian, pytest, SVD or submission',stage_sha256=sha(raw),stage_members=19,worker_sha256=sha(worker),all27_original_typed_input_descriptors_exact_excluding_only_array_key_paths=checks,
                all27_identity_retains_tuple_list_dataclass_types_and_float_hex=True,
                review_findings=[
                    'select_point checks J_age and exact own x/r/J/scale/scaled/gradient against its original refresh event before using the matrix.',
                    'Accepted QN trials require matched direction/prediction/trial ages and a matching original J refresh point; displacement identity is explicit.',
                    'PW final optimizer J is paired with saved optimizer.fun, while optimizer x/fun versus final detail mismatches are separately reported; no Jacobian refresh or PW x_scale identity is asserted.',
                    'PW saved evaluations are explicitly not accepted iterations; actual accepted PW path divergence stays undetermined.',
                    'Python +inf inputs remain float hex in typed identity; no finite clamp or near-zero relative gate is introduced.',
                    'SVD weak modes, distances and gradients are kept as point-specific algebra; no basin/local-minimum/physical-degeneracy or production solver fix is claimed.',
                    'Only NumPy/serialization are imported after the EHPC/PBS guard; no physical source is imported and no model/evaluate/new-J callback exists.',
                    'PBS wrapper retains actual analysis return and propagates stage-after failure; original physical failure is separately retained.'
                ],limits='Static review is not numerical execution or acceptance; the prepared actual job still must deliver original F/Stageout and complete raw results.')
    (BASE/'surface-lm-path-comparison-qp-independent-review-qc.json').write_bytes(encode(report));print(json.dumps({k:v for k,v in report.items() if k not in ('all27_original_typed_input_descriptors_exact_excluding_only_array_key_paths','review_findings')}))


if __name__=='__main__':main()

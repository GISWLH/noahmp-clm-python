"""Unique root-authorized QP algebra deployment; no model/evaluate/new J."""
from pathlib import Path
import hashlib
import json
import re
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
LOG=BASE/'surface-lm-path-comparison-qp-deployment'
STAGE=BASE/'surface-lm-path-comparison-qp-stage.tar.gz'
DISPATCH=BASE/'surface-lm-path-comparison-qp-execution/dispatch_analysis_qp.py'
EXPECTED='5b0bee7af8256dae739aa10822d7b773142d3eb646d2ba102bda6ad18f6c79b0'
sha=lambda b:hashlib.sha256(b).hexdigest()


def run(label,command):
    start=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=120)
    (LOG/(label+'.stdout')).write_bytes(result.stdout);(LOG/(label+'.stderr')).write_bytes(result.stderr)
    (LOG/(label+'.json')).write_text(json.dumps(dict(command=command,actual_exit=result.returncode,
        seconds=time.monotonic()-start,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)),indent=2)+'\n')
    assert result.returncode==0,(label,result.stderr.decode(errors='replace'))
    return result.stdout


def main():
    assert sha(STAGE.read_bytes())==EXPECTED and not LOG.exists();LOG.mkdir()
    ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc']
    scp=['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12']
    health=run('PBS-health',ssh+['qstat -Bf'])
    assert re.search(rb'^\s*server_state = Active\s*$',health,re.M)
    assert re.search(rb'^\s*scheduling = True\s*$',health,re.M)
    for job,code in [('1856.manager',1),('1844.manager',1),('1854.manager',0)]:
        terminal=run('input-terminal-'+job,ssh+['qstat -fx '+job])
        assert re.search(rb'^\s*job_state = F\s*$',terminal,re.M)
        assert re.search(rb'^\s*Exit_status = '+str(code).encode()+rb'\s*$',terminal,re.M)
        assert re.search(rb'^\s*Stageout_status = 0\s*$',terminal,re.M)
    capacity_code="import os,json; s=os.statvfs('/tmp'); print(json.dumps(dict(available_bytes=s.f_bavail*s.f_frsize,available_inodes=s.f_favail)))"
    for host in ('ehpc','ehpc-c2'):
        capacity=json.loads(run('capacity-'+host,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12',host,
            shlex.join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B','-c',capacity_code])]))
        assert capacity['available_bytes']>=12*1024**3 and capacity['available_inodes']>=20000
    live=run('PBS-live',ssh+['qstat -fx 1831.manager'])
    assert all(v in live for v in (b'job_state = F',b'Exit_status = 1',b'Stageout_status = 0'))
    parent=run('PBS-parent-live',ssh+['qstat -fx 1813.manager'])
    assert all(v in parent for v in (b'job_state = F',b'Exit_status = 0',b'Stageout_status = 0'))
    remote='/tmp/noahmp-surface-lm-path-comparison-qp'
    dispatcher='/tmp/dispatch_surface_analysis_qp.py'
    for label,path in [('root',remote),('stage',remote+'-stage.tar.gz'),('dispatch',dispatcher)]:
        run('preflight-'+label,ssh+['test ! -e '+path])
    run('upload-stage',scp+[str(STAGE),'ehpc:'+remote+'-stage.tar.gz'])
    run('upload-dispatch',scp+[str(DISPATCH),'ehpc:'+dispatcher])
    uploaded=run('uploaded-hashes',ssh+['sha256sum '+remote+'-stage.tar.gz '+dispatcher])
    assert {line.split()[1]:line.split()[0] for line in uploaded.decode().splitlines()}=={
        remote+'-stage.tar.gz':EXPECTED,dispatcher:sha(DISPATCH.read_bytes())}
    output=run('dispatch',ssh+['/home/zhangyq/venvs/noahmp-closeout/bin/python -B '+dispatcher+
        ' --archive '+remote+'-stage.tar.gz --sha256 '+EXPECTED])
    record=json.loads(output);assert record['stage_sha256']==EXPECTED
    print(json.dumps(dict(pbs_job=record['pbs_job'],stage_sha256=EXPECTED,actual_dispatch_exit=0)))


if __name__=='__main__':main()

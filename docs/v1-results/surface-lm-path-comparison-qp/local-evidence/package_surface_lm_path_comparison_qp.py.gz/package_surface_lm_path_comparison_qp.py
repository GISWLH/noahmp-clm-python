"""Seal QP actual algebra evidence; original heavy inputs are hash references."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-path-comparison-qp'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def contents(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()];names=[m.name.removeprefix('./') for m in members]
        assert len(set(names))==len(names) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    assert sha(stage_raw)=='5b0bee7af8256dae739aa10822d7b773142d3eb646d2ba102bda6ad18f6c79b0'
    stage=contents(stage_raw);index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==19 and set(index)==set(stage)-{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    result_raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes()
    assert sha(result_raw)=='cd637241f42bf4dec071151dc7de64056dcd33fb8fc72545ee3c7eee02ea8d15'
    result=contents(result_raw);assert len(result)==28
    for folder,copy in [('preparation','preparation-controls'),('execution','execution-controls')]:
        manifest=json.loads(stage[folder+'/CONTROLS_SHA256.json'])
        for name in [*manifest,'CONTROLS_SHA256.json']:
            original=stage[folder+'/'+name]
            if name in manifest:assert sha(original)==manifest[name]
            assert result[copy+'/'+name]==original
    for name in ('setup-exit.txt','worker-exit.txt','stage-after-exit.txt','pbs-command-exit.txt'):assert result[name].strip()==b'0'
    before=json.loads(result['stage-before.json']);after=json.loads(result['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']==index
    qstat=(BASE/(LABEL+'-closure/initial-qstat.stdout')).read_bytes()
    assert re.search(rb'^Job Id: 1866.manager\s*$',qstat,re.M)
    for field,value in [('job_state','F'),('Exit_status','0'),('Stageout_status','0')]:
        assert re.search(rb'^\s*'+field.encode()+rb' = '+value.encode()+rb'\s*$',qstat,re.M)
    report=json.loads((BASE/(LABEL+'-readout.json')).read_bytes())
    assert report['analysis_completed'] and report['actual_analysis_exit']==0 and report['immutable_before_after_exact']
    assert len(report['all27_original_inputs_exact'])==27 and all(report['all27_original_inputs_exact'].values())
    assert report['QM_original_saved_J_r_exact_to_QF'] and report['original_ambient_seed_exact']
    assert len(report['QN_recorded_accepted_trials'])==23 and not report['first_accepted_algorithm_path_divergence']['determined']
    assert report['model_calls']==report['evaluate_calls']==report['new_Jacobian_computations']==0
    closure=dict(pbs_job='1866.manager',job_state='F',PBS_exit=0,Stageout_status=0,actual_analysis_exit=0,
        result_sha256=sha(result_raw),stage_sha256=sha(stage_raw),result_files=28,stage_files=19,
        own_point_and_age_verified=True,all27_original_inputs_exact=True,original_ambient_seed_exact=True,
        original_QN_model_failure_preserved=True,original_QF_model_failure_preserved=True,
        model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,nonlinear_basin_or_minimum_proved=False,
        physical_degeneracy_proved=False,scientific_acceptance=False,production_source_changed=False,
        array_gauge_note=report['readout_array_gauge_note'])
    (BASE/(LABEL+'-closure.json')).write_bytes(encode(closure))
    items={'original-result.tar.gz':result_raw,'stage-inventory.json':stage['stage-inventory.json']}
    items.update({'actual-result/'+name:raw for name,raw in result.items()})
    items.update({'executed-controls/'+name:raw for name,raw in stage.items() if name.startswith(('preparation/','execution/'))})
    references={name:dict(sha256=sha(raw),bytes=len(raw),included=False,
        scope='Original prior result archive already sealed separately; original bytes retained unchanged locally and in corresponding evidence package.')
        for name,raw in stage.items() if name.endswith('-result.tar.gz')}
    items['HEAVY-INPUT-REFERENCES.json']=encode(references)
    for folder in (BASE/(LABEL+'-closure'),BASE/(LABEL+'-deployment')):
        for p in sorted(folder.rglob('*')):
            if p.is_file():items[folder.name+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
    for name in (LABEL+'-readout.json',LABEL+'-closure.json',LABEL+'-stage-package.json',LABEL+'-independent-review-qc.json',
        'review_surface_paths_qp_qc.py','prepare_surface_lm_path_comparison_qp.py','deploy_surface_lm_path_comparison_qp.py',
        'collect_surface_lm_path_comparison_qp.py','package_surface_lm_path_comparison_qp.py'):
        items['local-evidence/'+name]=(BASE/name).read_bytes()
    items['README.md']=b'QP1866 actualF0/Stageout0 offline algebra only, zero model/evaluate/newJacobian. Full original result raw and28 members plus exact executed controls, stage hash/inventory, independent static review, actual command exits and typed raw data retained. Four heavy original input result archives are explicit byte/hash references to their already sealed evidence, not duplicated. QN1856 and QF1844 original model failures remain failures. Weak mode, gradient and point closeness do not prove a nonlinear minimum, physical degeneracy or a repair. Ground prescribed-temperature residual row usesK, leaf/water rows useWm2. Raw full-U projection signs differ from the explicitly gauged weakest pair as documented. Windows verification only reads JSON scalars and opaque dtype-sized payload bytes; no unpickle/NumPy/numerical decode.\n'
    items['artifact-inventory.json']=encode({name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    assert contents(target.read_bytes())==items
    package=dict(label=LABEL,artifacts=len(items),bytes=target.stat().st_size,sha256=sha(target.read_bytes()),
        actual_PBS_job='1866.manager',actual_PBS_exit=0,Stageout_status=0,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        original_QN_model_exit=1,scientific_or_solver_acceptance=False)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

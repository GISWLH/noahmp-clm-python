"""EHPC-only existing-path/SVD algebra. No model/evaluate/new Jacobian call."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import socket
import sys
import tarfile
import time
import traceback

if os.name=='nt' or not os.environ.get('PBS_JOBID') or socket.gethostname().split('.')[0]!='compute002':
    raise RuntimeError('Saved-path numerical analysis requires EHPC compute002 PBS')

import numpy as np
from serialization_pt import dump_return

sha=lambda raw:hashlib.sha256(raw).hexdigest()


def archive(path,expected):
    raw=path.read_bytes();assert sha(raw)==expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()]
        names=[m.name.removeprefix('./') for m in members]
        assert len(names)==len(set(names)) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def unpack(files,prefix):
    metadata=json.loads(files[prefix+'.json']);raw=files[prefix+'.npz']
    assert sha(raw)==metadata['npz_sha256'] and sha(files[prefix+'.pkl'])==metadata['pickle_sha256']
    def decode(node,arrays):
        kind=node['kind']
        if kind=='array':
            value=arrays[node['key']]
            assert value.dtype.str==node['dtype'] and list(value.shape)==node['shape']
            assert sha(value.tobytes(order='C'))==node['c_order_sha256']
            return value.copy()
        if kind=='dict':return {key:decode(value,arrays) for key,value in node['items'].items()}
        if kind in ('list','tuple'):return [decode(value,arrays) for value in node['items']]
        if kind=='dataclass':return {key:decode(value,arrays) for key,value in node['fields'].items()}
        if kind=='float':return float.fromhex(node['hex'])
        assert kind in ('NoneType','bool','int','str'),'Unsupported typed leaf:'+kind
        return node['value']
    with np.load(io.BytesIO(raw),allow_pickle=False) as arrays:return decode(metadata['tree'],arrays)


def exact(left,right):
    a,b=np.asarray(left),np.asarray(right)
    return a.dtype==b.dtype and a.shape==b.shape and a.tobytes(order='C')==b.tobytes(order='C')


def exact_tree(left,right):
    if isinstance(left,np.ndarray) or isinstance(right,np.ndarray):return exact(left,right)
    if type(left) is not type(right):return False
    if isinstance(left,dict):return left.keys()==right.keys() and all(exact_tree(value,right[key]) for key,value in left.items())
    if isinstance(left,list):return len(left)==len(right) and all(exact_tree(a,b) for a,b in zip(left,right))
    if type(left) is float:return left.hex()==right.hex()
    return left==right


def weak_modes(jac,residual,scale,caps,rows,columns):
    def one(matrix,to_physical,label):
        u,s,vh=np.linalg.svd(matrix,full_matrices=False)
        left=u[:,-1].copy();right=vh[-1].copy()
        # Fix an otherwise arbitrary SVD sign by the dominant residual row.
        pivot=int(np.argmax(abs(left)))
        if left[pivot]<0.:left=-left;right=-right
        projection=float(left@residual);total=float(residual@residual)
        physical=to_physical*right;normalizer=float(np.max(abs(physical)/caps))
        physical_cap_normalized=physical/normalizer if normalizer>0. else physical.copy()
        left_order=np.argsort(-abs(left));right_order=np.argsort(-abs(physical_cap_normalized/caps))
        return dict(matrix_kind=label,singular_values=s.tolist(),condition=float(s[0]/s[-1]) if s[-1]!=0. else float('inf'),
            weak_left=left,weak_right=right,physical_right=physical,physical_right_normalized_to_original_caps=physical_cap_normalized,
            physical_right_fraction_of_original_caps=physical_cap_normalized/caps,
            all_left_mode_residual_projections=u.T@residual,smallest_to_next_singular_value_ratio=float(s[-1]/s[-2]) if s[-2]!=0. else None,
            residual_projection=projection,residual_projection_squared_fraction=projection*projection/total if total>0. else None,
            residual_orthogonal_component_norm=float(np.linalg.norm(residual-projection*left)),
            original_gradient_norm=float(np.linalg.norm(matrix.T@residual)),weak_right_gradient_projection=float(right@(matrix.T@residual)),
            dominant_residual_rows=[dict(index=int(k),name=rows[k],coefficient=float(left[k]),saved_residual=float(residual[k])) for k in left_order],
            dominant_physical_coordinates=[dict(index=int(k),name=columns[k],physical_component=float(physical_cap_normalized[k]),fraction_of_original_cap=float(physical_cap_normalized[k]/caps[k])) for k in right_order],
            SVD_identity_max_error=float(np.max(abs(matrix@right-s[-1]*left))),
            sign_convention='Largest-absolute weak left row positive. Raw solver row units retained, including prescribed ground-temperature K row.')
    return dict(original_J=one(jac,np.ones(12),'original stored J'),
        recorded_column_scaled_J=one(jac*scale,scale,'J times original recorded scale'))


def select_point(events):
    final=[event for event in events if event['event']=='return'][-1]
    values=final['locals'];age=final['field_ages']['J_iteration']
    candidates=[event for event in events if event['anchor']=='J_scaling_normal_gradient_complete' and event['iteration']==age]
    assert len(candidates)==1
    refreshed=candidates[0]['locals']
    for name in ('x','residual','jac','scale','scaled','gradient'):
        assert exact(values[name],refreshed[name]),'Stored J/scale point mismatch:'+name
    assert exact(values['scaled'],values['jac']*values['scale'])
    return final,values


def scalar_or_array(value):
    if isinstance(value,np.ndarray):return value.item() if value.shape==() else value.copy()
    return value


def main():
    parser=argparse.ArgumentParser()
    for name in ('qn','qf','qm','pw'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')=='' and np.__version__=='2.2.6'
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=args.output.resolve();assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists();root.mkdir()
    inputs={name:getattr(args,name) for name in ('qn','qf','qm','pw')}
    expected=dict(qn='3f774feeb13b6556eb2228bb2d4727dd3684ec85c51dfe3a920f5085ecb14553',
        qf='1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd',
        qm='74eea2098ab3a0cd9992e694596c8f3de51f99368470a7d2d0308385fe3ba416',
        pw='44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')
    immutable={str(path):sha(path.read_bytes()) for path in [*inputs.values(),Path(__file__),Path(__file__).with_name('serialization_pt.py')]}
    report=dict(pbs_job=os.environ['PBS_JOBID'],analysis_completed=False,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        original_QN_physical_failure_preserved=True,basin_or_local_minimum_proved=False,physical_vs_derivative_degeneracy_proved=False,
        production_solver_change=False,original_inputs_or_controls_changed=False)
    start=time.monotonic();status=1
    try:
        data={name:archive(path,expected[name]) for name,path in inputs.items()}
        qn=unpack(data['qn'],'probe/external-lm-trace-qn/observed')
        assert not qn['observer_errors'] and len(qn['calls'])==1
        qn_events=qn['calls'][0]['events'];qf=unpack(data['qf'],'probe/trace/raw-observation')
        assert len(qn_events)==373 and len(qf['events'])==367
        qn_final,qn_values=select_point(qn_events);qf_final,qf_values=select_point(qf['events'])
        before=unpack(data['qn'],'probe/actual-row-0/first-phase-before')
        frame=unpack(data['pw'],'probe/original-model/phase-final-frame')['frames'][0]['locals']
        # Independently repeat the static all27 descriptor identity on decoded originals.
        input_checks={key:exact_tree(value,frame[key]) for key,value in before.items()}
        assert len(input_checks)==27 and all(input_checks.values())
        report['all27_original_inputs_exact']=input_checks
        caps=np.r_[np.full(10,20.),5.,5.]
        columns=['leaf_temperature_offset_K['+str(k)+']' for k in range(10)]+['ground_temperature_K','canopy_humidity_g_per_kg']
        rows=['leaf_energy_Wm2['+str(k)+']' for k in range(10)]+[
            'prescribed_ground_temperature_constraint_K' if before['fixed_ground_temperature'] is not None else 'ground_energy_Wm2','air_water_times_LV_Wm2']
        report['row_and_coordinate_units']=dict(rows=rows,columns=columns,original_caps=caps)
        for label,event,values in [('QN',qn_final,qn_values),('QF',qf_final,qf_values)]:
            report[label+'_final']=dict(iteration=event['iteration'],J_age=event['field_ages']['J_iteration'],
                direction_age=event['field_ages']['direction_iteration'],x=values['x'].copy(),r=values['residual'].copy(),
                max_residual=float(np.max(abs(values['residual']))),lambda_at_return=float(values['damping']),scale=values['scale'].copy(),
                original_J_and_scale_point_bytes_verified=True,weak_modes=weak_modes(values['jac'],values['residual'],values['scale'],caps,rows,columns))
        qm=unpack(data['qm'],'probe/analysis')
        assert qm['analysis_completed'] and exact(qm['final_iteration']['J'],qf_values['jac']) and exact(qm['final_iteration']['r'],qf_values['residual'])
        report['QM_original_saved_J_r_exact_to_QF']=True
        report['QN_QF_weak_mode_alignment']={key:dict(
            absolute_left_inner_product=float(abs(report['QN_final']['weak_modes'][key]['weak_left']@report['QF_final']['weak_modes'][key]['weak_left'])),
            absolute_right_inner_product=float(abs(report['QN_final']['weak_modes'][key]['weak_right']@report['QF_final']['weak_modes'][key]['weak_right'])),
            scope='Point-specific stored matrices; alignment is not proof of an identical nonlinear basin.')
            for key in ('original_J','recorded_column_scaled_J')}
        pw={seed:unpack(data['pw'],'probe/diagnostic/'+seed+'-diagnostic') for seed in ('stalled_x','stored_ambient')}
        first_enter=next(event for event in qn_events if event['anchor']=='iteration_entered')
        assert exact(first_enter['locals']['x'],pw['stored_ambient']['initial'])
        report['original_ambient_seed_exact']=True
        comparisons={}
        for name,reference in pw.items():
            x=reference['last_attempted_x'];r=reference['original_detail']['solver_residual']
            optimizer=reference['optimizer_result'];jac=optimizer['jac']
            comparisons[name]=dict(saved_root_flag=reference['diagnostic_root_found'],saved_x=x.copy(),saved_r=r.copy(),
                max_saved_residual=float(np.max(abs(r))),QN_minus_saved_x=qn_values['x']-x,QN_minus_saved_r=qn_values['residual']-r,
                max_coordinate_difference=float(np.max(abs(qn_values['x']-x))),max_difference_in_original_caps=float(np.max(abs(qn_values['x']-x)/caps)),
                max_residual_vector_difference=float(np.max(abs(qn_values['residual']-r))),
                optimizer_x_exact_to_final_detail_x=exact(optimizer['x'],x),optimizer_fun_exact_to_final_detail_r=exact(optimizer['fun'],r),
                optimizer_x=optimizer['x'].copy(),optimizer_fun=optimizer['fun'].copy(),
                optimizer_vs_detail_max_coordinate_difference=float(np.max(abs(optimizer['x']-x))),
                optimizer_vs_detail_max_residual_difference=float(np.max(abs(optimizer['fun']-r))),
                final_optimizer_J_weak_modes=weak_modes(jac,optimizer['fun'],np.ones(12),caps,rows,columns),
                J_scope='Saved final optimizer J only. No explicit Jacobian refresh trace or original per-iteration scaling vector; identity scale here is diagnostic, not claimed PW x_scale.',
                saved_transpiration_total=float(np.sum(reference['original_detail']['transpiration'])),
                saved_ground_evaporation=float(reference['original_detail']['ground_evaporation']),
                saved_root_uptake=reference['original_detail']['root_uptake'].copy())
        report['PW_final_posthoc_comparisons']=comparisons
        accepted=[]
        for event in qn_events:
            if event['anchor']!='accept_original_strict_descent':continue
            values=event['locals'];age=event['field_ages']
            assert age['direction_iteration']==age['prediction_iteration']==age['trial_iteration']==event['iteration']
            refreshed=[e for e in qn_events if e['anchor']=='J_scaling_normal_gradient_complete' and e['iteration']==age['J_iteration']]
            assert len(refreshed)==1
            for key in ('x','residual','jac','scale','scaled'):assert exact(values[key],refreshed[0]['locals'][key])
            assert exact(values['scaled'],values['jac']*values['scale'])
            assert exact(values['displacement'],values['trial']-values['x'])
            row=dict(iteration=event['iteration'],J_age=age['J_iteration'],x_before=values['x'].copy(),accepted_trial=values['trial'].copy(),
                original_lambda=float(values['damping']),original_alpha=float(values['alpha']),original_ratio=float(values['ratio']),
                scale=values['scale'].copy(),displacement=values['displacement'].copy(),
                bound_hit_indices=np.flatnonzero((values['trial']==values['lower'])|(values['trial']==values['upper'])),PW_evaluation_distances={})
            for name,reference in pw.items():
                points=reference['returned_evaluations']['x'];residuals=reference['returned_evaluations']['r12']
                distances=np.max(abs(points-values['trial'])/caps,axis=1);nearest=int(np.argmin(distances))
                matching=[int(k) for k,point in enumerate(points) if exact(point,values['trial'])]
                row['PW_evaluation_distances'][name]=dict(returned_calls=len(points),nearest_saved_call_index=nearest,
                    nearest_distance_in_original_caps=float(distances[nearest]),nearest_saved_r12_max=float(np.max(abs(residuals[nearest]))),
                    exact_matching_saved_call_indices=matching,these_are_not_accepted_iteration_indices=True)
            accepted.append(row)
        assert len(accepted)==23
        report['QN_recorded_accepted_trials']=accepted
        report['first_QN_accepted_trial_without_exact_saved_PW_evaluation']={
            name:next((row['iteration'] for row in accepted if not row['PW_evaluation_distances'][name]['exact_matching_saved_call_indices']),None)
            for name in pw}
        report['first_accepted_algorithm_path_divergence']=dict(determined=False,
            reason='PW saved callback evaluations include finite-difference calls and lack accepted-iterate labels/lambda/radius/scaling history. No accepted PW path is invented or new reference solve run.')
        e=frame['e'];water=e['atmosphere_velocity'] if e['atmosphere_water_velocity'] is None else e['atmosphere_water_velocity']
        controls={key:scalar_or_array(frame[key]) for key in ('tr_limit','atm_h','bare_h','heat_den','heat_weight','vapor_conductance','rho','fv','active','phase_active','roots','root_h')}
        controls.update(exchange={key:scalar_or_array(value) for key,value in e.items()},water_velocity_from_saved_property_inputs=scalar_or_array(water),
            water_velocity_scope='Alias selection from saved fields according to unchanged source; no model property called.',
            ground_evaporation_limit_input=before['ground_evaporation_limit'],transpiration_limit_input=scalar_or_array(before['transpiration_limit']),
            fixed_ground_temperature=before['fixed_ground_temperature'],ground_shares_soil=before['ground_shares_soil'],soil_supply=before['soil_supply'],
            immutable_closure_scope='Original PW frame constants for same27 captured inputs; no new physical recomputation.',QN_per_point_gas_uptake_and_limiter_margin_history='not stored')
        for name,reference in pw.items():
            cap=before['ground_evaporation_limit']
            if before['soil_supply'] is not None and before['ground_shares_soil']:
                cap=min(cap,max(0.,float(before['soil_supply']['surface'])-float(reference['original_detail']['root_uptake'][0])))
            controls['PW_'+name+'_derived_effective_shared_ground_cap']=cap
        report['actual_saved_controls']=controls
        report.update(analysis_completed=True,interpretation_limits=[
            'Distances and small gradients do not establish a basin or nonlinear local minimum.',
            'Weak-mode projections alone do not separate true physical degeneracy from finite-difference error.',
            'QN per-point full gas/uptake margins and PW accepted-iteration/radius/lambda/scaling records remain missing.',
            'PW ambient root is a saved feasible-root witness; it was never supplied to a model seed.'])
        status=0
    except BaseException:report['exception']=traceback.format_exc()
    finally:
        report['immutable_before_after_exact']=all(sha(Path(name).read_bytes())==digest for name,digest in immutable.items())
        if not report['immutable_before_after_exact']:status=1
        report.update(actual_analysis_exit=status,seconds=time.monotonic()-start)
        dump_return(root/'analysis',report)
    return status


if __name__=='__main__':sys.exit(main())

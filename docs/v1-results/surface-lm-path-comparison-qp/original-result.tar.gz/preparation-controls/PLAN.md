# QP saved-path and weak-mode diagnosis — prepared only

QN1856 remains actualF1/Stageout0,47/48 tests, original Qia residual10.769007515983674 after65/80 total iterations. No candidate is promoted. The next proposed computation is one1CPU/2GiB/5min EHPC PBS algebra job on saved outputs. It calls no model/evaluate function and computes no new finite-difference or analytic Jacobian. Root reads this plan and the worker before submission.

## Authoritative records and gaps

`surface-lm-path-comparison-qp-inventory.json` binds the exact input archives and descriptors. All27 QN first-phase arguments match the original PW input descriptors, and the first actual LM seed is byte-identical to PW's stored ambient seed. QN has373 external events, actual accepted/rejected branches, complete steps, lambda, scales, bounds, Jacobians and residuals with field ages. QM contains the earlier QF saved Jacobians/residuals. PW contains288 stalled-seed and301 ambient-seed returned evaluations plus final optimizer x/r/J/gradient.

PW evaluation records do **not** label accepted iterates and do not retain per-iteration lambda, trust radius or actual scaling vectors. Its finite-difference calls are included in the evaluation arrays. The analysis will not relabel these calls as accepted iterations or reconstruct new Jacobians from them. Exact first *accepted-step* divergence between the algorithms is therefore unavailable from the current packets. It can instead report each recorded QN accepted trial's distance to all saved PW evaluation points, exact byte matches, and the first QN accepted trial without a matching recorded PW point, explicitly retaining that narrower meaning.

QN copied solver/physical residuals at line anchors, but not complete gas, transpiration, uptake or limiter-margin histories. PW original-frame closure constants are available: normalized `e`, `tr_limit`, `rho`, `fv`, `atm_h`, `bare_h`, `heat_den`, `heat_weight`, `vapor_conductance`, masks and root supplies. Their source/input identity is tied to the same27 inputs; they are not reconstructed by a new model call. `e.water_velocity` is the source-defined selection between the stored atmosphere-water and atmosphere velocities; the report will identify that derivation rather than pretend it was a separate captured field. Input ground limit is+inf and must remain+inf. The effective shared-soil ground cap depends on uptake; only saved details at their own PW points may establish it. Missing QN-point limiter margins remain missing.

## One proposed offline analysis

1. Authenticate QN, QM and PW archives, every used packet/payload, and source/control hashes. Compare current x/r against each recorded Jacobian refresh point before using that matrix. Every stale or missing quantity is marked rather than silently substituted.
2. Report QN accepted steps and recorded bounds/caps/alpha/scales/lambda. Compare its last point/residual with both saved PW outcomes, and compare its accepted-trial sequence against **evaluation** sequences without claiming PW acceptance. Close coordinates or residuals alone do not establish a basin or local minimum.
3. Compute SVDs of existing QN/QM matrices only. For the weakest left/right modes, report dominant residual rows and coordinates, signed projections onto the saved residual, squared projection fractions, gradient projections, and the actual physical-coordinate direction after undoing recorded scaling. Columns are leaf coordinates0–9, ground temperature10, humidity in g/kg11; rows are10 leaf equations, ground equation, and air-water balance multiplied byLV. Sign comparisons use a stated gauge or absolute modal inner products.
4. Read actual saved exchange velocities, fixed ground temperature, tr_limit and input/effective-ground limitations where recorded. Report heat/water conductance and supply context alongside modes. Existing PW final optimizer Jacobians may be compared only at their own saved points, with point/residual distances shown; different points/stencils cannot isolate numerical derivative error.
5. Return explicit limits: nonzero stored finite-difference gradient is not proof about the exact nonlinear gradient; near-singular J is not proof of physical degeneracy; a small gradient and similar residual are not proof of a nonroot local minimum. Existing ambient-TRF root remains an actual feasible-root witness.

Raw pickle precedes typed NPZ/JSON; nonfinite scalars use explicit hex. This job changes no candidate, seed, equation, parameter, mask,80-iteration budget, test or physical ledger. No observations are fitted. If current records are insufficient, it reports the gap; it does not silently run another reference solve.

## Defined trust-region option for later review

This is a mathematical proposal, **not** an implemented or approved model change. Keep the original dry-only eligibility, old successful fast paths, original residuals and all convergence/parcel gates. Let the original column scale beS andA=JS. Solve the dense least-squares trust-region subproblem

\[
\min_{\|p\|_2\le\Delta}\|r+Ap\|_2^2,
\qquad A=U\Sigma V^T,
\qquad p(\lambda)=-V\,\operatorname{diag}\!\left(\frac{\sigma_i}{\sigma_i^2+\lambda}\right)U^Tr.
\]

Choose lambda=0 for a feasible minimum-norm Gauss–Newton step; otherwise solve the monotone radius equation for nonnegative lambda using a predeclared bracket and fixed inner iteration cap. The inner calculation is algebra only; every rejected or accepted physical trial still consumes the original remaining outer80 budget. No small-gradient or small-step stopping condition can accept a nonroot.

For an initial fixed design, setDelta0=||caps/S||2 andDeltamax=Delta0 from the unchanged original caps. Retain the original common-alpha cap/bound rule, and compute predicted reduction from the **actual representable displacement**. Retain acceptance actual>0 andrho>=.1. Define radius shrink forrho<.25 and enlargement forrho>.75 at a radius-limited unprojected step, with fixed factors1/4 and2; the detailed inner accuracy/endpoint rules must be frozen in the later implementation plan before its single test. This makes radius/step control explicit instead of trying different lambda constants. It is not asserted to escape the current recorded nonroot neighborhood.

Do not formA^TA to obtain the weak-direction step. The dense decomposition and secular solve are finite small-matrix operations suitable for independently implemented NumPy/JAX/native-CUDA paths. Actual backend precision, rank handling and decomposition parity still require separate verification; no SciPy production solver or CPU alias is proposed. Original10% physical,1e-6 same-precision and hard-conservation gates remain.

One predeclared later model test is the original captured Qia phase/surface case, with the original ambient seed and80 budget and the existing physical/parcel/reference checks; Cha/HaM and all42 original tests remain mandatory regressions. No source candidate is created by this document, and success is not inferred from the subproblem alone.

## Mathematical sources and version scope

The official documentation describes dense TRF through a singular-value based subproblem, bound-aware steps and Jacobian scaling; it also documents callback/evaluation distinctions. The API/source version recorded for PW is1.16.3. These references motivate the mathematical option and the recording gaps, not a copied implementation: [SciPy1.16.3 primary API/source](https://github.com/scipy/scipy/blob/v1.16.3/scipy/optimize/_lsq/least_squares.py), [official least_squares documentation and primary references](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.least_squares.html). The latter currently serves1.18.0; no claim is made that its defaults were the original PW execution settings.

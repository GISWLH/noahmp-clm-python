def _dry_lm_rescue(evaluate, ambient, lower, upper, active, phase_active,
                   tolerance, used_iterations, max_iterations):
    """One bounded dry-only LM recovery; no change to old stores or equations.

    Every attempted recovery update consumes the caller's remaining iteration
    budget, including rejected or unsolvable updates. Residual/detail calls are
    counted separately from iterations and never represented as time steps.
    """
    x=np.asarray(ambient,float).copy();n=len(x)-2
    lower=np.asarray(lower,float).copy();upper=np.asarray(upper,float).copy()
    active=np.asarray(active,bool).copy();phase_active=np.asarray(phase_active,bool).copy()
    record=dict(entered=False,converged=False,x=x,last_iteration=used_iterations,
        original_stalled_iteration=used_iterations,initial_used_iterations=used_iterations,
        maximum_iterations=max_iterations,iterations=0,accepted=0,rejected=0,linear_failures=0,
        linear_attempts=0,trial_evaluations=0,
        evaluate_calls=0,evaluate_returns=0,reason='iteration_budget')
    if (used_iterations>=max_iterations or np.any(phase_active)
            or np.any(~np.isfinite(x)) or np.any((x<lower)|(x>upper))):
        record['reason']='ineligible_seed_or_budget'
        return record
    record['entered']=True
    cap=np.r_[np.full(n,20.),5.,5.]
    damping=None;refresh=True;detail=None
    def call(z,details=False):
        record['evaluate_calls']+=1
        answer=evaluate(z,details)
        record['evaluate_returns']+=1
        return answer
    def phase_change(z,value):
        fresh=(~phase_active)&active&(abs(z[:n])<=.05)&(value['wet_evaporation']<0.)
        depleted=phase_active&(value['condensate'].mass==0.)&(z[:n]>0.)&(z[:n]<LF/CW)&(abs(value['solver_residual'][:n])>tolerance)
        return np.any(fresh)|np.any(depleted)
    for iteration in range(used_iterations+1,max_iterations+1):
        record['iterations']+=1;record['last_iteration']=iteration
        if detail is None:detail=call(x,True)
        residual=detail['solver_residual']
        if not np.all(np.isfinite(residual)):
            record['reason']='nonfinite_residual';return record
        if phase_change(x,detail):
            record['reason']='phase_coordinate_change';return record
        if np.max(abs(residual))<=tolerance:
            record.update(converged=True,reason='root',x=x.copy());return record
        if refresh:
            jac=np.empty((n+2,n+2))
            for k in range(n+2):
                step=1e-6 if k<n+1 else 1e-7
                lo=x.copy();hi=x.copy();lo[k]=max(lower[k],x[k]-step);hi[k]=min(upper[k],x[k]+step)
                if not hi[k]>lo[k]:
                    record['reason']='no_derivative_interval';return record
                jac[:,k]=(call(hi)-call(lo))/(hi[k]-lo[k])
            if not np.all(np.isfinite(jac)):
                record['reason']='nonfinite_jacobian';return record
            scale=cap/np.maximum(1.,np.linalg.norm(jac*cap,axis=0))
            scaled=jac*scale;normal=scaled.T@scaled;gradient=scaled.T@residual
            if damping is None:damping=max(np.finfo(float).eps,1e-3*float(np.max(np.diag(normal))))
            refresh=False
        if not np.isfinite(damping) or damping<=0.:
            record['reason']='nonfinite_damping';return record
        matrix=normal+damping*np.eye(n+2)
        record['linear_attempts']+=1
        try:
            factor=np.linalg.cholesky(matrix)
            if not np.all(np.isfinite(factor)) or np.any(np.diag(factor)<=0.):
                raise np.linalg.LinAlgError('Invalid regularized Cholesky pivot')
            direction=scale*np.linalg.solve(factor.T,np.linalg.solve(factor,-gradient))
            if not np.all(np.isfinite(direction)):
                raise np.linalg.LinAlgError('Nonfinite regularized direction')
        except np.linalg.LinAlgError:
            record['linear_failures']+=1;record['rejected']+=1;damping*=10.
            continue
        alpha=1./max(1.,float(np.max(abs(direction)/cap)))
        for k in range(n+2):
            if direction[k]>0.:alpha=min(alpha,(upper[k]-x[k])/direction[k])
            elif direction[k]<0.:alpha=min(alpha,(lower[k]-x[k])/direction[k])
        trial=np.clip(x+alpha*direction,lower,upper);displacement=trial-x
        if not np.isfinite(alpha) or alpha<=0. or not np.any(displacement):
            record['rejected']+=1;record['reason']='no_feasible_displacement';return record
        norm=float(residual@residual);linear=residual+jac@displacement
        linear_change=jac@displacement
        predicted=-2.*float(residual@linear_change)-float(linear_change@linear_change)
        if not np.isfinite(predicted) or predicted<=0.:
            record['rejected']+=1;damping*=10.;continue
        record['trial_evaluations']+=1
        trial_detail=call(trial,True);trial_residual=trial_detail['solver_residual']
        if not np.all(np.isfinite(trial_residual)):
            record['reason']='nonfinite_trial';return record
        if phase_change(trial,trial_detail):
            record['reason']='phase_coordinate_change';return record
        actual=float((residual-trial_residual)@(residual+trial_residual));ratio=actual/predicted
        if actual>0. and np.isfinite(ratio) and ratio>=.1:
            x=trial;detail=trial_detail;record['x']=x.copy();record['accepted']+=1;refresh=True
            if ratio>.75:damping=max(np.finfo(float).eps,damping/3.)
            elif ratio<.25:damping*=10.
            # The final permitted update may reach the root: no extra update.
            if np.max(abs(trial_residual))<=tolerance:
                record.update(converged=True,reason='root');return record
        else:
            record['rejected']+=1;damping*=10.
    return record

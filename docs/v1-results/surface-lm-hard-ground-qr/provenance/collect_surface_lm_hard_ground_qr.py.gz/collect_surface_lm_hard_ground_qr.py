"""Collect unique1870 raw outcomes without assuming physical or observer success."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-qr'
OUT=BASE/(LABEL+'-closure')
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    def run(name,command):
        start=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=90)
        (OUT/(name+'.stdout')).write_bytes(p.stdout);(OUT/(name+'.stderr')).write_bytes(p.stderr)
        (OUT/(name+'-exit.json')).write_text(json.dumps(dict(command=command,actual_exit=p.returncode,
            seconds=time.monotonic()-start,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr)),indent=2)+'\n')
        assert p.returncode==0
        return p.stdout
    qstat=run('initial-qstat',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1870.manager'])
    remote='/tmp/noahmp-surface-lm-hard-ground-qr'
    result_hash=run('result-hash',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','sha256sum '+remote+'/result.tar.gz']).decode().split()[0]
    external=run('pbs-exit',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','cat '+remote+'/pbs-exit.txt']).strip().decode()
    target=BASE/(LABEL+'-result.tar.gz');assert not target.exists()
    run('download-result',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2:'+remote+'/result.tar.gz',str(target)])
    assert sha(target.read_bytes())==result_hash
    with tarfile.open(target) as t:files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    receipt=json.loads(files['probe/receipt.json'])
    reports=json.loads(files['probe/tests-nodes.json']) if 'probe/tests-nodes.json' in files else None
    collect=json.loads(files['probe/collect-nodes.json']) if 'probe/collect-nodes.json' in files else None
    trace=json.loads(files['probe/external-lm-trace-qr/status.json']) if 'probe/external-lm-trace-qr/status.json' in files else None
    counts=None;xml=None
    if reports is not None:
        assert reports['nodes']==collect['nodes'] and reports['items']==collect['items']
        assert len(set(reports['nodes']))==48 and len(reports['reports'])==144
        for node in reports['nodes']:assert [r['when'] for r in reports['reports'] if r['nodeid']==node]==['setup','call','teardown']
        counts=dict(collected=48,passed_calls=sum(r['when']=='call' and r['passed'] for r in reports['reports']),
            failed_reports=[{key:r.get(key) for key in ('nodeid','when','failed','longrepr')} for r in reports['reports'] if r['failed']],
            skipped_reports=sum(r['skipped'] for r in reports['reports']),complete_phase_reports=144)
        suite=list(ET.fromstring(files['probe/pytest.xml']))[0]
        xml={key:int(suite.attrib[key]) for key in ('tests','failures','errors','skipped')}
    for name,raw in files.items():
        if name.endswith(('.json','.xml','.log','.txt','.stdout','.stderr')):
            output=OUT/'readable'/name;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(raw)
    def field(name):
        match=re.search(rb'^\s*'+name.encode()+rb' = (\S+)\s*$',qstat,re.M)
        return match.group(1).decode() if match else None
    readout=dict(pbs_job='1870.manager',job_state=field('job_state'),PBS_exit=field('Exit_status'),Stageout_status=field('Stageout_status'),
        terminal_closed=field('job_state')=='F' and field('Stageout_status') is not None,external_PBS_command_exit=external,
        result_sha256=result_hash,result_files=len(files),actual_children=receipt['actual_children'],
        original_wrapper_passed=receipt['passed'],wrapper_exception=receipt.get('exception'),
        source_members_exact=receipt['source_members_exact'],immutable_before_after_exact=receipt['immutable_before_after_exact'],
        immutable_files=receipt['immutable_files'],stage_before_after_exact=receipt['stage_before_after_exact'],
        actual_node_reports=counts,independent_XML=xml,external_actual_Qia_trace=trace,
        scope='One root-authorized original48-node fixed-ground private candidate. Original children/status and observer metadata are separated; no promotion or parameter/budget/seed/gate retry.',
        GPU_calls=0,complete_column_steps=0,annual_or_scientific_acceptance=False)
    (BASE/(LABEL+'-readout.json')).write_text(json.dumps(readout,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:value for key,value in readout.items() if key not in ('actual_node_reports','actual_children')},indent=2))
    print(json.dumps(dict(node_reports=counts,children=receipt['actual_children']),indent=2))


if __name__=='__main__':main()

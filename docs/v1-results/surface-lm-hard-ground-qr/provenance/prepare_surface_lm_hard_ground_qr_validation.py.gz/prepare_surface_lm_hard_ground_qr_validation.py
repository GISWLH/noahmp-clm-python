"""Mechanically bind original QN48 nodes to root-authorized hard-ground source."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-qr'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def main():
    source_prep=BASE/(LABEL+'-preparation');proof=json.loads((source_prep/'DIFF_PROOF.json').read_bytes())
    source_path=BASE/(LABEL+'-source.tar.gz');assert sha(source_path.read_bytes())==proof['candidate_source_sha256']=='3cbf7962a927f0a7da7c47cbccd7b1813db5b248199b4a4c8aecf0fa16d679da'
    source=dict(source_archive=source_path.name,archive_basename=source_path.name,source_archive_sha256=proof['candidate_source_sha256'],
        source_manifest_sha256=proof['candidate_manifest_sha256'],phase_sha256=proof['candidate_phase_sha256'],
        scope='Private NumPy dry-rescue hard prescribed-ground source only; not promoted.',numerical_execution=0)
    (BASE/(LABEL+'-source-package.json')).write_bytes(encode(source))
    parent_raw=(BASE/'surface-lm-merit-qn-stage.tar.gz').read_bytes();assert sha(parent_raw)=='d175c852a090836a19877179e292db0acf75dbcad757aaf3519963f9aeda6f3f'
    with tarfile.open(fileobj=io.BytesIO(parent_raw)) as t:parent={m.name:t.extractfile(m).read() for m in t}
    parent_index=json.loads(parent['stage-inventory.json']);assert len(parent)==40 and all(sha(parent[name])==digest for name,digest in parent_index.items())
    prep=BASE/(LABEL+'-validation-preparation');assert not prep.exists();prep.mkdir()
    execution=BASE/(LABEL+'-execution');assert {p.name for p in execution.iterdir()}=={'trace_py_qr.py'}
    for name,raw in parent.items():
        if name.startswith('preparation/') and name!='preparation/CONTROLS_SHA256.json':
            path=prep/name.removeprefix('preparation/');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    with tarfile.open(source_path) as t:phase=t.extractfile('src/noahmp_clm/physics/canopy_phase_energy.py').read()
    assert sha(phase)==source['phase_sha256']
    old_manifest=b'17b3a586c8cb34dfdd7e893788a6cfc3edbbaf0bf080d988f1b85daac811b197'
    helper=parent['preparation/surface_reference_py.py'];assert helper.count(old_manifest)==1
    new_helper=helper.replace(old_manifest,source['source_manifest_sha256'].encode())
    assert new_helper.replace(source['source_manifest_sha256'].encode(),old_manifest)==helper
    (prep/'surface_reference_py.py').write_bytes(new_helper)
    (prep/'canopy_phase_energy.candidate.py').write_bytes(phase)
    tree=ast.parse(phase);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_fixed_ground_rescue')
    (prep/'dry_lm_helper_py.txt').write_bytes((ast.get_source_segment(phase.decode(),node)+'\n').encode())
    (prep/'source.diff').write_bytes((source_prep/'candidate.patch').read_bytes());(prep/'DIFF_PROOF.json').write_bytes((source_prep/'DIFF_PROOF.json').read_bytes())
    binding=json.loads((prep/'BINDINGS.json').read_bytes())
    binding.update(candidate_source_archive_sha256=source['source_archive_sha256'],candidate_source_manifest_sha256=source['source_manifest_sha256'],
        candidate_phase_sha256=source['phase_sha256'],candidate_reference_helper_sha256=sha(new_helper),
        QN_parent_source_archive_sha256='adc1a56065a74cbfb9121908fd0a28743d77047280eb059d0e068830b6cf225c',
        QN_parent_source_manifest_sha256=old_manifest.decode(),merit_only_changes=False,hard_fixed_ground_change_only=True,
        source_change_scope='Only dry rescue with prescribed Tf fixes ground exactly and removes its row/column from linear unknowns; no-constraint helper body unchanged. Full12 and physical11/parcel gates/evaluate source unchanged;583 other files exact.')
    (prep/'BINDINGS.json').write_bytes(encode(binding))
    static=json.loads((prep/'STATIC_CHECKS.json').read_bytes())
    static.update(candidate_source_archive_sha256=source['source_archive_sha256'],candidate_source_manifest_sha256=source['source_manifest_sha256'],
        source_variation_scope='Only root-approved dry prescribed-ground hard constraint.',
        test_code_byte_exact_to_QN=True,new_test_code_byte_exact_to_PY_c=True,no_fixed_ground_helper_body_exact=True,
        source_binding_helper_reverse_literal_replacement_byte_exact=True)
    (prep/'STATIC_CHECKS.json').write_bytes(encode(static))
    (prep/'README.md').write_bytes(b'PrivateLM hard-groundQR, one root-authorized original48-node NumPy validation. Original6 new+42 original tests, data,10percent/hard gates,80budget,ambient free coordinates,phase masks,lambda,caps/alpha/acceptance unchanged. Prescribed ground is enforced exactly only in dry rescue; fixed row/column omitted from11x11 unknowns. None helper branch/evaluate source byteexact to QN. Original PY/QF/QM/QN failures retained. Copy-only exact-code observer records existing nested-call inputs and helper locals, everytrialTf bytes/J shape/freeindices/seedidentity and field ages,0extraevaluate/J. Original provenance builders remain historical/unexecuted.\n')
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.relative_to(prep).as_posix():sha(p.read_bytes()) for p in sorted(prep.rglob('*')) if p.is_file()}))
    patches=[]
    for name in ('check_stage_py.py','dispatch_surface_py.py','record_pytest_py.py','run_validation_py.py'):
        old=parent['execution/'+name];changed=old
        if name!='record_pytest_py.py':changed=changed.replace(b'noahmp-surface-lm-merit-qn',b'noahmp-surface-lm-hard-ground-qr')
        if name=='dispatch_surface_py.py':changed=changed.replace(b'dispatch_surface_merit_qn.py',b'dispatch_surface_hard_ground_qr.py').replace(b'surface_qn.pbs',b'surface_qr.pbs')
        if name=='run_validation_py.py':
            changed=changed.replace(b'trace_py_qn',b'trace_py_qr').replace(b'external-lm-trace-qn',b'external-lm-trace-qr')
            needle=b"        record['passed']=True"
            assert changed.count(needle)==1
            metadata_checks=b"        trace=record['external_actual_Qia_LM_trace']\n        assert trace['fixed_ground_all_calls_and_trials_exact'] and trace['linear_problem_shape_and_indices_exact']\n        assert trace['non_ground_ambient_seed_exact'] and trace['original_call_counts_exact']\n        assert trace['live_helper_frames']==trace['live_nested_frames']==0\n"
            changed=changed.replace(needle,metadata_checks+needle)
        (execution/name).write_bytes(changed)
        patches.append(''.join(difflib.unified_diff(old.decode().splitlines(True),changed.decode().splitlines(True),fromfile='QN/'+name,tofile='QR/'+name)))
    old=parent['execution/surface_qn.pbs'];pbs=old.replace(b'noahmp-surface-lm-merit-qn',b'noahmp-surface-lm-hard-ground-qr').replace(b'#PBS -N surface-lm-merit-qn',b'#PBS -N surface-lm-ground-qr')
    assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs
    (execution/'surface_qr.pbs').write_bytes(pbs)
    patches.append(''.join(difflib.unified_diff(parent['execution/trace_py_qn.py'].decode().splitlines(True),(execution/'trace_py_qr.py').read_text().splitlines(True),fromfile='QN/trace_py_qn.py',tofile='QR/trace_py_qr.py')))
    patches.append(''.join(difflib.unified_diff(old.decode().splitlines(True),pbs.decode().splitlines(True),fromfile='QN/surface_qn.pbs',tofile='QR/surface_qr.pbs')))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'README.md').write_bytes(b'OriginalQN unique manager/compute transfer,LF1CPU2GiB10min PBS,collect48/144phase/XML and full immutable checks. PrivateQR paths/new sourcebinding/copy-only exact code observer only. Original tests/record_pytest bytes unchanged. Original actual child exit preserved; additional metadata checks require everycall/trialTfexact,11x11/freeidx/seedidentity and sourcehash transparency. No newevaluate/J. Failure is retained without parameter/budget/seed changes or retry.\n')
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={name:raw for name,raw in parent.items() if not name.startswith(('preparation/','execution/')) and name not in ('source.tar.gz','stage-inventory.json')}
    items.update({folder+'/'+p.relative_to(directory).as_posix():p.read_bytes() for folder,directory in [('preparation',prep),('execution',execution)] for p in directory.rglob('*') if p.is_file()})
    items['source.tar.gz']=source_path.read_bytes()
    assert items['preparation/test_actual_surface_py.py']==parent['preparation/test_actual_surface_py.py'] and items['execution/record_pytest_py.py']==parent['execution/record_pytest_py.py']
    items['stage-inventory.json']=encode({name:sha(raw) for name,raw in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    out=dict(stage_sha256=sha(target.read_bytes()),archive_basename=target.name,scope='One authorized fixed-ground NumPy48-node validation, not a release.',
        stage_members=len(items),bytes=target.stat().st_size,source_archive_sha256=source['source_archive_sha256'],
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),
        observer_sha256=sha((execution/'trace_py_qr.py').read_bytes()),original_tests_and_node_recorder_bytes_exact=True,
        expected_nodes=48,expected_original_nodes=42,expected_new_nodes=6,physical_gates_or_inputs_changed=False,
        observer_metadata_invariant_checks_added=True,extra_evaluate_or_J=0,numerical_execution=0,submission=False)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(out));print(json.dumps(out))


if __name__=='__main__':main()

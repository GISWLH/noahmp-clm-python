"""Private source-only fixed-ground constraint candidate; no execution."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-qr'
PHASE='src/noahmp_clm/physics/canopy_phase_energy.py'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def main():
    parent=BASE/'surface-lm-merit-qn-source.tar.gz';parent_raw=parent.read_bytes()
    assert sha(parent_raw)=='adc1a56065a74cbfb9121908fd0a28743d77047280eb059d0e068830b6cf225c'
    with tarfile.open(parent) as t:files={m.name:t.extractfile(m).read() for m in t if m.isfile()}
    manifest=json.loads(files['SOURCE_SHA256.json']);assert len(manifest)==584 and all(sha(files[n])==h for n,h in manifest.items())
    before=files[PHASE];text=before.decode();tree=ast.parse(before);lines=text.splitlines(True)
    old_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_rescue')
    old=''.join(lines[old_node.lineno-1:old_node.end_lineno])
    signature='def _dry_lm_rescue(evaluate, ambient, lower, upper, active, phase_active,\n                   tolerance, used_iterations, max_iterations):'
    assert old.count(signature)==1
    fixed=old.replace(signature,'def _dry_lm_fixed_ground_rescue(evaluate, ambient, lower, upper, active, phase_active,\n                                tolerance, used_iterations, max_iterations, fixed_ground_temperature):')
    changes=[
        ('x=np.asarray(ambient,float).copy();n=len(x)-2',
         'x=np.asarray(ambient,float).copy();n=len(x)-2\n    x[n]=float(fixed_ground_temperature)\n    free=np.r_[np.arange(n),n+1]'),
        ("evaluate_calls=0,evaluate_returns=0,reason='iteration_budget')",
         "evaluate_calls=0,evaluate_returns=0,reason='iteration_budget',\n        fixed_ground_temperature_hex=float(fixed_ground_temperature).hex(),\n        free_coordinates=free.copy(),fixed_ground_coordinate=n,\n        ground_constraint_row_excluded_from_linear_problem=True,full12_root_gate_retained=True)"),
        ("    def call(z,details=False):\n        record['evaluate_calls']+=1",
         "    def call(z,details=False):\n        if np.asarray(z[n]).tobytes()!=np.asarray(float(fixed_ground_temperature)).tobytes():\n            raise RuntimeError('Dry rescue changed prescribed ground temperature')\n        record['evaluate_calls']+=1"),
        ('jac=np.empty((n+2,n+2))\n            for k in range(n+2):',
         'jac=np.empty((n+1,n+1))\n            for column,k in enumerate(free):'),
        ('jac[:,k]=(call(hi)-call(lo))/(hi[k]-lo[k])',
         'jac[:,column]=(call(hi)[free]-call(lo)[free])/(hi[k]-lo[k])'),
        ('scale=cap/np.maximum(1.,np.linalg.norm(jac*cap,axis=0))',
         'scale=cap[free]/np.maximum(1.,np.linalg.norm(jac*cap[free],axis=0))'),
        ('scaled=jac*scale;normal=scaled.T@scaled;gradient=scaled.T@residual',
         'scaled=jac*scale;normal=scaled.T@scaled;gradient=scaled.T@residual[free]'),
        ('matrix=normal+damping*np.eye(n+2)',
         'matrix=normal+damping*np.eye(n+1)'),
        ('direction=scale*np.linalg.solve(factor.T,np.linalg.solve(factor,-gradient))',
         'direction=np.zeros(n+2)\n            direction[free]=scale*np.linalg.solve(factor.T,np.linalg.solve(factor,-gradient))'),
        ('trial=np.clip(x+alpha*direction,lower,upper);displacement=trial-x',
         'trial=np.clip(x+alpha*direction,lower,upper)\n        trial[n]=float(fixed_ground_temperature);displacement=trial-x'),
        ('norm=float(residual@residual);linear=residual+jac@displacement',
         'norm=float(residual[free]@residual[free]);linear=residual[free]+jac@displacement[free]'),
        ('linear_change=jac@displacement',
         'linear_change=jac@displacement[free]'),
        ('predicted=-2.*float(residual@linear_change)-float(linear_change@linear_change)',
         'predicted=-2.*float(residual[free]@linear_change)-float(linear_change@linear_change)')]
    for original,changed in changes:
        assert fixed.count(original)==1,original
        fixed=fixed.replace(original,changed)
    wrapper=old.replace(signature,'def _dry_lm_rescue(evaluate, ambient, lower, upper, active, phase_active,\n                   tolerance, used_iterations, max_iterations, *, fixed_ground_temperature=None):')
    delegate='''    if fixed_ground_temperature is not None:
        return _dry_lm_fixed_ground_rescue(evaluate,ambient,lower,upper,active,phase_active,
            tolerance,used_iterations,max_iterations,fixed_ground_temperature)
'''
    needle='    x=np.asarray(ambient,float).copy();n=len(x)-2'
    assert wrapper.count(needle)==1;wrapper=wrapper.replace(needle,delegate+needle)
    assert wrapper.replace(delegate,'').replace('max_iterations, *, fixed_ground_temperature=None):','max_iterations):')==old
    assert text.count(old)==1
    changed=text.replace(old,fixed+'\n\n'+wrapper)
    call='dry_lm_record=_dry_lm_rescue(evaluate,ambient,lower,upper,active,phase_active,\n                    tolerance,iteration,max_iterations)'
    new_call='dry_lm_record=_dry_lm_rescue(evaluate,ambient,lower,upper,active,phase_active,\n                    tolerance,iteration,max_iterations,fixed_ground_temperature=fixed_ground_temperature)'
    assert changed.count(call)==1;changed=changed.replace(call,new_call)
    after=changed.encode();after_tree=ast.parse(after)
    evaluate=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='evaluate')
    new_evaluate=next(n for n in ast.walk(after_tree) if isinstance(n,ast.FunctionDef) and n.name=='evaluate')
    old_eval=''.join(lines[evaluate.lineno-1:evaluate.end_lineno]).encode()
    new_lines=changed.splitlines(True);new_eval=''.join(new_lines[new_evaluate.lineno-1:new_evaluate.end_lineno]).encode()
    assert old_eval==new_eval and ast.dump(evaluate,include_attributes=False)==ast.dump(new_evaluate,include_attributes=False)
    original_other={name:raw for name,raw in files.items() if name not in (PHASE,'SOURCE_SHA256.json')}
    files[PHASE]=after;files['SOURCE_SHA256.json']=encode({name:sha(files[name]) for name in sorted(manifest)})
    assert len(original_other)==583 and all(files[name]==raw for name,raw in original_other.items())
    prep=BASE/(LABEL+'-preparation');assert not prep.exists();prep.mkdir()
    (prep/'candidate.patch').write_bytes(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile='QN/'+PHASE,tofile='QR/'+PHASE)).encode())
    (prep/'candidate_phase.py').write_bytes(after)
    (prep/'original_helper.py').write_bytes(old.encode());(prep/'fixed_ground_helper.py').write_bytes(fixed.encode())
    proof=dict(parent_source_sha256=sha(parent_raw),parent_manifest_sha256=sha(json.dumps(manifest,indent=2).encode()+b'\n'),
        parent_phase_sha256=sha(before),candidate_phase_sha256=sha(after),candidate_manifest_sha256=sha(files['SOURCE_SHA256.json']),
        unchanged_other_source_files=583,evaluate_source_bytes_exact=True,evaluate_AST_exact=True,
        no_fixed_ground_original_helper_body_exact_after_removing_delegation=True,
        fixed_ground_unknown_indices='0..n-1 and n+1; full state envelope keeps prescribed ground coordinate n exactly',
        fixed_ground_linear_problem='Original J with row n and column n removed, built only for those free coordinates; no ground finite difference',
        max_total_iterations_unchanged=80,remaining_budget_rule_unchanged=True,
        original_caps_alpha_lambda_acceptance_stable_merit_seed_nonfixed_coordinates_masks_unchanged=True,
        full12_residual_root_gate_and_physical11_parcel_checks_unchanged=True,
        original_helper_signature=signature,new_keyword='fixed_ground_temperature=None',
        original_callsite=call,new_callsite=new_call,physical_execution=False,source_promoted=False)
    (prep/'DIFF_PROOF.json').write_bytes(encode(proof))
    target=BASE/(LABEL+'-source.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(files.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==files
    proof['candidate_source_sha256']=sha(target.read_bytes());proof['candidate_source_bytes']=target.stat().st_size
    (prep/'DIFF_PROOF.json').write_bytes(encode(proof))
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(prep.iterdir()) if p.is_file()}))
    print(json.dumps(proof))


if __name__=='__main__':main()

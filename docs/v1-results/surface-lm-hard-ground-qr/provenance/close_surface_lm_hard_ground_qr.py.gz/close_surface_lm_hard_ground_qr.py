"""Finalize actual1870 F/Stageout metadata; never retry a model or observer."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import time

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-qr'
OUT=BASE/(LABEL+'-closure')
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    target=OUT/'final-qstat.stdout';assert not target.exists()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1870.manager']
    start=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=60)
    target.write_bytes(result.stdout);target.with_suffix('.stderr').write_bytes(result.stderr)
    (OUT/'final-qstat-exit.json').write_text(json.dumps(dict(command=command,actual_exit=result.returncode,seconds=time.monotonic()-start,
        stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)),indent=2)+'\n')
    assert result.returncode==0
    fields={field:re.search(rb'^\s*'+field.encode()+rb' = (\S+)\s*$',result.stdout,re.M).group(1).decode()
        for field in ('job_state','Exit_status','Stageout_status')}
    assert fields==dict(job_state='F',Exit_status='1',Stageout_status='0')
    readout=json.loads((BASE/(LABEL+'-readout.json')).read_bytes())
    assert readout['external_PBS_command_exit']=='1' and readout['independent_XML']==dict(tests=48,failures=1,errors=0,skipped=0)
    assert [entry['actual_child_returncode'] for entry in readout['actual_children']]==[0,1]
    assert readout['immutable_before_after_exact'] and readout['source_members_exact'] and readout['stage_before_after_exact'] and readout['immutable_files']==617
    trace=readout['external_actual_Qia_trace'];assert not trace['observer_errors']
    for key in ('fixed_ground_all_calls_and_trials_exact','linear_problem_shape_and_indices_exact','non_ground_ambient_seed_exact','original_call_counts_exact'):
        assert trace[key]
    assert trace['live_helper_frames']==trace['live_nested_frames']==0 and trace['helper_calls']==1
    assert trace['captured_original_physical_calls']==542 and trace['summaries'][0]['evaluate_returns']==542
    closure=dict(pbs_job='1870.manager',job_state='F',PBS_exit=1,Stageout_status=0,worker_exit=1,actual_collect_exit=0,actual_pytest_exit=1,
        collected=48,passed=47,failed=1,errors=0,skipped=0,complete_setup_call_teardown=144,XML_independently_checked=True,
        original42_and_Cha_HaM_passed=True,original_actual_Qia_failed=True,immutable617_source_and_stage_exact=True,
        source_sha256='3cbf7962a927f0a7da7c47cbccd7b1813db5b248199b4a4c8aecf0fa16d679da',
        result_sha256=readout['result_sha256'],result_files=116,observer_errors=[],extra_evaluate_or_J=0,
        hard_Tf_all542_calls_and_trials_exact=True,linear11_problem_and_indices_exact=True,original_non_ground_ambient_seed_exact=True,
        original_failure=trace['summaries'][0],hard_ground_change_fixed_Qia=False,source_promoted=False,
        GPU_calls=0,complete_column_steps=0,annual_or_scientific_acceptance=False,
        terminal_scope='Final F1/Stageout0 is distinct from the retained earlier E1 snapshot; no model retry or source/gate change after result.')
    (BASE/(LABEL+'-final-closure.json')).write_text(json.dumps(closure,indent=2,allow_nan=False)+'\n');print(json.dumps(closure))


if __name__=='__main__':main()

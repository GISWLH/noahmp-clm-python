"""Copy-only exact-code trace of actual-Qia fixed-ground rescue and calls."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import os
import struct
import sys
import traceback

import pytest


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    parameters=getattr(getattr(item,'callspec',None),'params',{})
    if item.path.name!='test_actual_surface_py.py' or parameters.get('row')!=0:
        yield
        return
    root=Path(os.environ['PY_RESULT']);target=root/'source/src/noahmp_clm/physics/canopy_phase_energy.py'
    output=root/'external-lm-trace-qr';output.mkdir(exist_ok=False)
    binding=json.loads((root/'preparation/BINDINGS.json').read_bytes())
    raw=target.read_bytes();assert hashlib.sha256(raw).hexdigest()==binding['candidate_phase_sha256']
    lines=raw.decode().splitlines();tree=ast.parse(raw)
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_fixed_ground_rescue')
    nested=next(n for n in ast.walk(node) if isinstance(n,ast.FunctionDef) and n.name=='call')
    anchors={
        'if detail is None:detail=call(x,True)':'iteration_entered',
        'if refresh:':'current_residual_before_J_decision',
        'if damping is None:damping=max(np.finfo(float).eps,1e-3*float(np.max(np.diag(normal))))':'J_scaling_normal_gradient_complete',
        'matrix=normal+damping*np.eye(n+1)':'damping_before_linear_system',
        'alpha=1./max(1.,float(np.max(abs(direction)/cap)))':'finite_direction_complete',
        'trial=np.clip(x+alpha*direction,lower,upper)':'common_alpha_complete',
        'if not np.isfinite(alpha) or alpha<=0. or not np.any(displacement):':'trial_and_displacement_complete',
        "record['rejected']+=1;record['reason']='no_feasible_displacement';return record":'reject_no_feasible_displacement',
        'if not np.isfinite(predicted) or predicted<=0.:':'linear_prediction_complete',
        "record['rejected']+=1;damping*=10.;continue":'reject_nonpositive_prediction',
        'actual=float((residual-trial_residual)@(residual+trial_residual));ratio=actual/predicted':'original_trial_residual_complete',
        'if actual>0. and np.isfinite(ratio) and ratio>=.1:':'actual_reduction_and_ratio_complete',
        "x=trial;detail=trial_detail;record['x']=x.copy();record['accepted']+=1;refresh=True":'accept_original_strict_descent',
        "record['rejected']+=1;damping*=10.":'reject_original_reduction_or_ratio'}
    scoped={i+1:line.strip() for i,line in enumerate(lines) if node.lineno<=i+1<=node.end_lineno}
    assert all(list(scoped.values()).count(text)==1 for text in anchors)
    allowed=('ambient','x','lower','upper','active','phase_active','cap','free','n','fixed_ground_temperature',
        'iteration','used_iterations','max_iterations','refresh','residual','jac','scale','scaled','normal','gradient',
        'damping','matrix','factor','direction','alpha','trial','displacement','norm','linear','linear_change',
        'predicted','trial_residual','actual','ratio','record')
    calls=[];live={};errors=[];ground_checks=[];linear_checks=[];seed_checks=[];nested_calls=[];nested_live={}
    helper_code=None;nested_code=None
    def exact_ground(value,n,tf):
        existing=value[n:n+1].copy()
        return dict(ground=existing,original_Tf_hex=float(tf).hex(),
            exact=existing.dtype.str=='<f8' and existing.shape==(1,) and existing.tobytes()==struct.pack('<d',tf))
    def snapshot(frame,event,anchor,arg=None):
        call=calls[live[id(frame)]];values=frame.f_locals;iteration=values.get('iteration')
        if anchor=='J_scaling_normal_gradient_complete':call['ages']['J_iteration']=iteration
        if anchor=='finite_direction_complete':call['ages']['direction_iteration']=iteration
        if anchor=='linear_prediction_complete':call['ages']['prediction_iteration']=iteration
        if anchor=='original_trial_residual_complete':call['ages']['trial_iteration']=iteration
        entry=dict(event=event,anchor=anchor,iteration=iteration,source_line=frame.f_lineno,
            source_text=lines[frame.f_lineno-1],line_event_before_execution=event=='line',field_ages=copy.deepcopy(call['ages']),
            locals={name:copy.deepcopy(values[name]) for name in allowed if name in values})
        if values.get('detail') is not None:
            entry['already_computed_detail']={name:copy.deepcopy(values['detail'][name]) for name in ('solver_residual','layer_residual') if name in values['detail']}
        if 'x' in values and 'n' in values:
            check=exact_ground(values['x'],values['n'],values['fixed_ground_temperature']);check.update(scope='current_x',iteration=iteration,anchor=anchor);ground_checks.append(check)
        if anchor=='iteration_entered' and not call['seed_checked']:
            free=values['free'];same=values['x'][free].tobytes()==values['ambient'][free].tobytes()
            seed_checks.append(dict(non_ground_ambient_bytes_exact=same));call['seed_checked']=True
        if anchor=='trial_and_displacement_complete':
            check=exact_ground(values['trial'],values['n'],values['fixed_ground_temperature']);check.update(scope='trial',iteration=iteration);ground_checks.append(check)
        if anchor=='J_scaling_normal_gradient_complete':
            n=values['n'];linear_checks.append(dict(iteration=iteration,J_shape=list(values['jac'].shape),
                scale_shape=list(values['scale'].shape),free=values['free'].copy(),
                exact=values['jac'].shape==(n+1,n+1) and values['scale'].shape==(n+1,) and values['free'].tolist()==list(range(n))+[n+1]))
        if event=='return':entry['returned_record']=copy.deepcopy(arg)
        if event=='exception':entry.update(exception_type=arg[0].__name__,exception_message=str(arg[1]))
        call['events'].append(entry)
    def trace(frame,event,arg):
        nonlocal helper_code,nested_code
        if frame.f_code.co_filename!=str(target):return None
        try:
            if helper_code is None and event=='call' and frame.f_code.co_name=='_dry_lm_fixed_ground_rescue':
                actual=frame.f_globals.get('_dry_lm_fixed_ground_rescue')
                assert getattr(actual,'__code__',None) is frame.f_code and frame.f_code.co_firstlineno==node.lineno
                helper_code=frame.f_code
                matching=[code for code in helper_code.co_consts if hasattr(code,'co_name') and code.co_name=='call' and code.co_firstlineno==nested.lineno]
                assert len(matching)==1;nested_code=matching[0]
            if frame.f_code is helper_code:
                if event=='call':
                    live[id(frame)]=len(calls);calls.append(dict(ordinal=len(calls),events=[],seed_checked=False,
                        ages=dict(J_iteration=None,direction_iteration=None,prediction_iteration=None,trial_iteration=None)))
                    snapshot(frame,event,'original_fixed_helper_entry')
                elif event=='line':
                    anchor=anchors.get(scoped.get(frame.f_lineno))
                    if anchor:snapshot(frame,event,anchor)
                elif event=='return':snapshot(frame,event,'original_fixed_helper_return',arg);live.pop(id(frame))
                elif event=='exception':snapshot(frame,event,'original_fixed_helper_exception',arg)
                return trace
            if frame.f_code is nested_code:
                if event=='call':
                    values=frame.f_locals
                    check=exact_ground(values['z'],values['n'],values['fixed_ground_temperature']);check.update(scope='every_original_physical_call',ordinal=len(nested_calls))
                    ground_checks.append(check)
                    nested_live[id(frame)]=len(nested_calls)
                    nested_calls.append(dict(ordinal=len(nested_calls),helper_call=live[id(frame.f_back)],z=copy.deepcopy(values['z']),details=copy.deepcopy(values['details']),
                        existing_evaluate_calls_before_original_increment=values['record']['evaluate_calls'],ground_check=copy.deepcopy(check),returned=False,exception=None))
                elif event=='exception':nested_calls[nested_live[id(frame)]]['exception']=dict(type=arg[0].__name__,message=str(arg[1]))
                elif event=='return':
                    row=nested_calls[nested_live.pop(id(frame))];row['returned']=arg is not None;row['original_return_type']=type(arg).__name__
                return trace
        except BaseException:errors.append(traceback.format_exc())
        return None
    previous=sys.gettrace();outcome=None
    try:
        if previous is None:sys.settrace(trace)
        else:errors.append('Existing trace left unchanged; capture inconclusive.')
        outcome=yield
    finally:
        sys.settrace(previous)
        packet=dict(nodeid=item.nodeid,source_phase_sha256=hashlib.sha256(raw).hexdigest(),calls=calls,nested_original_physical_calls=nested_calls,
            ground_checks=ground_checks,linear_checks=linear_checks,seed_checks=seed_checks,observer_errors=errors,
            extra_evaluate_calls=0,extra_Jacobian_computations=0,source_or_model_locals_assigned=False,
            original_test_exception=str(outcome.excinfo[1]) if outcome is not None and outcome.excinfo else None)
        status=dict(nodeid=item.nodeid,helper_calls=len(calls),observer_errors=errors,extra_evaluate_calls=0,extra_Jacobian_computations=0,
            source_after_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),original_test_outcome_unchanged=True,summaries=[],
            captured_original_physical_calls=len(nested_calls),fixed_ground_all_calls_and_trials_exact=bool(ground_checks) and all(check['exact'] for check in ground_checks),
            linear_problem_shape_and_indices_exact=bool(linear_checks) and all(check['exact'] for check in linear_checks),
            non_ground_ambient_seed_exact=bool(seed_checks) and all(check['non_ground_ambient_bytes_exact'] for check in seed_checks),
            live_helper_frames=len(live),live_nested_frames=len(nested_live),original_call_counts_exact=bool(calls))
        for call in calls:
            returns=[event for event in call['events'] if event['event']=='return']
            if not returns:continue
            event=returns[-1];record=event['returned_record'];values=event['locals']
            if not isinstance(record,dict):errors.append('Original helper abnormal return(None); no outcome replaced.');continue
            status['summaries'].append(dict(helper_call=call['ordinal'],reason=record['reason'],converged=record['converged'],
                last_iteration=record['last_iteration'],accepted=record['accepted'],rejected=record['rejected'],
                evaluate_calls=record['evaluate_calls'],evaluate_returns=record['evaluate_returns'],lambda_at_return=values.get('damping')))
            own=[row for row in nested_calls if row['helper_call']==call['ordinal']]
            status['original_call_counts_exact'] &= len(own)==record['evaluate_calls'] and sum(row['returned'] for row in own)==record['evaluate_returns']
        try:
            from run_reference_pt import dump_return
            dump_return(output/'observed',packet)
        except BaseException:errors.append(traceback.format_exc())
        def safe(value):
            if isinstance(value,float) and (value!=value or value in (float('inf'),-float('inf'))):return dict(finite=False,hex=value.hex())
            if isinstance(value,dict):return {k:safe(v) for k,v in value.items()}
            if isinstance(value,list):return [safe(v) for v in value]
            return value
        (output/'status.json').write_text(json.dumps(safe(status),indent=2,allow_nan=False)+'\n')

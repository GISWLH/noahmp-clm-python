import json,traceback
from pathlib import Path
import numpy as np
from check_canopy_phase_energy_reference import trajectory
try:trajectory(336)
except Exception as error:
    report=dict(error=repr(error));tb=error.__traceback__
    while tb:
        frame=tb.tb_frame;v=frame.f_locals
        if frame.f_code.co_name=='trajectory':
            report['trajectory']=dict(step=v['step'],column=v['column'],air=v['air'],sw=v['sw'],lw=v['lw'],base=v['base'],
                exchange=vars(v['e']),mass=v['wet'].mass.tolist(),enthalpy=v['wet'].enthalpy.tolist())
        if frame.f_code.co_name=='solve_canopy_phase_energy':
            r=v['evaluate'](v['x'],True)
            report['solver']=dict(coordinates=v['x'].tolist(),residual=v['residual'].tolist(),restarts=v['restarts'],
                temperature=r['leaf_temperature'].tolist(),mass=r['condensate'].mass.tolist(),enthalpy=r['condensate'].enthalpy.tolist())
        tb=tb.tb_next
    Path('/home/lhwang/work/noahmp-v1/canopy-phase-g-trajectory-failure.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)
    raise

from pathlib import Path
import hashlib,json,os,sys
import pytest

base=Path('/home/lhwang/work/noahmp-v1');source=base/'capacity-station-final-c';root=source/'target-c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text())
assert len(manifest)==535 and all(sha(source/n)==h for n,h in manifest.items());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(item.nodeid for item in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));assert code==0 and len(nodes)==len(set(nodes))==1375
gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))]
assert len(gpu)==366 and len(nodes)-len(gpu)==1009
groups={}
for filename,count in [('test_gpu_fluxnet_capacity_runner.py',3)]:
    expected=[n.split('/',1)[1] for n in gpu if Path(n.split('::')[0]).name==filename];assert len(expected)==count
    groups[filename]=expected
barriers=[]
for name in ['jax','cupy']:
    if name in sys.modules:
        if name=='jax':sys.modules[name].effects_barrier()
        else:sys.modules[name].cuda.runtime.deviceSynchronize()
        barriers.append(name)
assert all(sha(source/n)==h for n,h in manifest.items())
record=dict(scope='Exact535C collect-only1375=1009CPU+366GPU, not execution. Atexit bypass after pytestreturn/barriers/durable receipt.',returncode=code,nodes=nodes,groups=groups,
            source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),source_unchanged=True,device_barriers=barriers)
with (root/'collection.json').open('x') as output:json.dump(record,output,indent=2);output.flush();os.fsync(output.fileno())
sys.stdout.flush();sys.stderr.flush();os._exit(0)

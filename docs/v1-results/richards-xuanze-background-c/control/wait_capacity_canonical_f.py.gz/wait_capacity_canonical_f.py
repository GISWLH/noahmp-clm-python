from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-capacity-final-f';r=s/'full-controller-f'
launch=json.loads((r/'launch.json').read_text())
for path,pid in [(b/'p6-all-phase-final-b/full-controller-a/exit.json',3386981),(s/'full-bgc-f/exit.json',3802989)]:
    while not path.exists():
        assert Path('/proc/'+str(pid)).exists(),'Predecessor missing without actual parent exit: '+str(path)
        time.sleep(30)
whole=json.loads((s/'full-bgc-f/exit.json').read_text())
if not whole.get('passed') or whole['returncode']!=0:
    (r/'prerequisite-failed.json').write_text(json.dumps(dict(scope='Own frozen532F whole3 failed; remaining GPU not launched or credited. Original full3 evidence retained, no restart.',whole_exit=whole),indent=2)+'\n')
    raise SystemExit(1)
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines())
    if free>8192 and int(mem['MemAvailable'].split()[0])>16*1024*1024:break
    time.sleep(30)
for name,h in launch['controls_sha256'].items():assert hashlib.sha256((b/name).read_bytes()).hexdigest()==h
with (r/'full.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-u',str(b/'run_capacity_canonical_f.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=1,
    predecessor_exit=json.loads((b/'p6-all-phase-final-b/full-controller-a/exit.json').read_text()),whole3_exit=whole,
    scope='Actual frozen532F canonical1344 execution after actualsame-source981CPU/23GPU and predecessor exit; current533 station edits have no credit from this snapshot.'),indent=2)+'\n')
code=p.wait();(r/'exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
raise SystemExit(code)

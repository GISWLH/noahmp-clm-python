from pathlib import Path
import datetime,hashlib,io,json,os,signal,subprocess,sys,tarfile,time
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'fluxnet-numpy-current-first-year-a';inputs=base/'fluxnet-first-climate-cycle-20261017-h';scratch=Path(os.environ['TMPDIR']).resolve()/'numpy-current-first-year';scratch.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(manifest)==488 and all(sha(source/n)==v for n,v in manifest.items())
archive=base/'most-j4176-prefix-evidence.tar.gz';assert sha(archive)=='8e4b3aa2eb68bea9ac65f7083e82d23ac9acd9413c4b870eeeb2603f4006870f'
with tarfile.open(archive) as t:
    native=json.load(t.extractfile('gpu-SOURCE_SHA256.json'));proof=json.load(t.extractfile('immutable-4176-export.json'));prior={v['case']:json.load(t.extractfile(v['case']+'/'+v['report'])) for v in proof['cases']}
old_code=[n for n in native if n.startswith(('src/','tests/','benchmarks/','examples/'))];assert len(old_code)==483 and all(manifest[n]==native[n] for n in old_code)
batch=json.loads((inputs/'batch.json').read_text());assert len(batch['cases'])==4;rows=[]
for row in batch['cases']:
    paths={k:Path(row[k]) for k in ['input','input_manifest','configuration']};r=prior[row['case']]
    assert r['steps_requested']==17520 and r['steps_completed']==4176 and r['status']=='running' and r['source_unchanged']
    for key,field in [('input','forcing_npz_sha256'),('input_manifest','forcing_manifest_sha256'),('configuration','configuration_sha256')]:assert sha(paths[key])==r[field]
    rows.append(dict(**row,hashes={k:sha(v) for k,v in paths.items()}))
protocol=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Fresh independent NumPy64 first climate year, four original locked configurations/forcing/physical seeds. Same174 runtime and483 existing code/test/benchmark bytes as frozen J; no source change/checkpoint migration/calibration/height selection. Full17520 intervals per case required; not spinup or scientific acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),native_prefix_archive_sha256=sha(archive),unchanged_existing_code_test_benchmark_files=483,cases=rows)
(root/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(root/'SOURCE_SHA256.json').write_bytes((source/'SOURCE_SHA256.json').read_bytes())
jobs=[];results=[];failure=None
try:
    for row in rows:
        folder=scratch/row['case'];command=[sys.executable,'-u',str(source/'benchmarks/run_fluxnet_column.py'),'--input',row['input'],'--input-manifest',row['input_manifest'],'--config',row['configuration'],'--output',str(folder)]
        log=(root/(row['case']+'.log')).open('w');p=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);log.close();jobs.append((p,row,folder))
    (root/'launch.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=[dict(pid=p.pid,case=row['case'],output=str(folder)) for p,row,folder in jobs]),indent=2)+'\n')
    while any(p.poll() is None for p,_,_ in jobs):
        progress=[]
        for p,row,folder in jobs:
            report=folder/'report.json';r=json.loads(report.read_text()) if report.exists() else {}
            progress.append(dict(case=row['case'],pid=p.pid,returncode=p.poll(),status=r.get('status'),steps_completed=r.get('steps_completed',0),steps_requested=r.get('steps_requested'),seconds=r.get('seconds')))
        temp=root/'progress.json.tmp';temp.write_text(json.dumps(dict(status='running',cases=progress,seconds=time.monotonic()-begun),indent=2)+'\n');os.replace(temp,root/'progress.json');time.sleep(15)
except BaseException as e:failure=type(e).__name__+': '+str(e)
finally:
    for p,_,_ in jobs:
        if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
    for p,row,folder in jobs:
        try:code=p.wait(timeout=15)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
        report=folder/'report.json';r=json.loads(report.read_text()) if report.exists() else {};complete=code==0 and r.get('status')=='complete' and r.get('steps_completed')==r.get('steps_requested')==17520 and r.get('source_unchanged') is True
        paths=[report]
        for key,field in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:
            if key in r:
                path=folder/r[key];assert path.parent==folder and sha(path)==r[field];paths.append(path)
        dest=root/(row['case']+'-terminal-output.tar.gz')
        with tarfile.open(dest,'w:gz') as t:
            for path in paths:
                if path.exists():t.add(path,arcname=path.name,recursive=False)
        results.append(dict(case=row['case'],pid=p.pid,returncode=code,status=r.get('status'),steps_completed=r.get('steps_completed',0),steps_requested=r.get('steps_requested'),seconds=r.get('seconds'),complete=complete,maximum_cumulative_m_h_c_n=r.get('maximum_cumulative_residual_m_h_c_n'),failure=r.get('failure'),terminal_archive=dest.name,terminal_archive_sha256=sha(dest)))
    unchanged=all(sha(source/n)==v for n,v in manifest.items());complete=failure is None and unchanged and len(results)==4 and all(v['complete'] for v in results)
    value=dict(scope=protocol['scope'],pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,status='complete' if complete else 'failed',source_unchanged=unchanged,cases=results,failure=failure,seconds=time.monotonic()-begun)
    (root/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)
raise SystemExit(0 if complete else 1)

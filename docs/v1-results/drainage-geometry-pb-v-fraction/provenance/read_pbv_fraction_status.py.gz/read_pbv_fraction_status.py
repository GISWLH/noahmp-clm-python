"""Read one actual1845 qstat without executing analysis or resubmission."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

p=argparse.ArgumentParser();p.add_argument('label');a=p.parse_args()
base=Path(__file__).resolve().parent
assert a.label.isalnum()
stem=base/('drainage-geometry-pb-v-analysis-1845-status-'+a.label)
assert not Path(str(stem)+'.stdout').exists()
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc','qstat -xf 1845.manager']
r=subprocess.run(command,capture_output=True,timeout=45)
for suffix,raw in (('.stdout',r.stdout),('.stderr',r.stderr)):Path(str(stem)+suffix).write_bytes(raw)
Path(str(stem)+'-exit.json').write_text(json.dumps(dict(command=command,actual_exit=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()),indent=2)+'\n')
print(r.stdout.decode(errors='replace'));raise SystemExit(r.returncode)

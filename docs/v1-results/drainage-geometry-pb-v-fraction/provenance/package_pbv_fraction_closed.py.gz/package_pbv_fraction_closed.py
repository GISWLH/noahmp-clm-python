"""Verify closed EHPC1845 exact-RNE audit; no local numeric/pickle decode."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
LABEL='drainage-geometry-pb-v-fraction'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def main():
    stage_raw=(BASE/'drainage-geometry-pb-v-analysis-stage.tar.gz').read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='86c9b8a2a1884ba4e4b6f571f0d2ba0ec1f1386cc0887efb779fc31b5c4928ed'
    index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==12 and all(sha(stage[n])==h for n,h in index.items())
    source=BASE/'drainage-geometry-pb-v-analysis-result'
    raw=(source/'result.tar.gz').read_bytes();original=files(raw)
    assert sha(raw)=='0863648515d5ea0e2edb72ce1405bad327d2b3643b9cd6f1c79be4909f67a70e'
    final=BASE/'drainage-geometry-pb-v-analysis-1845-final-qstat.stdout'
    qstat=final.read_text()
    assert all(value in qstat for value in ('Job Id: 1845.manager','job_state = F','Exit_status = 0','Stageout_status = 0','run_count = 1'))
    assert (source/'pbs-exit.txt').read_bytes().strip()==b'0'
    assert all(original[n].strip()==b'0' for n in ('setup-exit.txt','worker-exit.txt','pbs-command-exit.txt','stage-after-exit.txt'))
    assert original['worker.stderr']==b''
    for name in ('stage-before.json','stage-after.json'):
        row=json.loads(original[name]);assert row['passed'] and row['expected']==row['actual']==index
    for prefix,stored in (('preparation','preparation-controls'),('execution','execution-controls')):
        controls=json.loads(stage[prefix+'/CONTROLS_SHA256.json'])
        assert all(original[stored+'/'+n]==stage[prefix+'/'+n] for n in [*controls,'CONTROLS_SHA256.json'])
    report=json.loads(original['diagnosis.json'])
    assert report['completed'] and report['passed'] and report['context_reproduction_passed'] and len(report['cases'])==8
    assert report['physical_forward_calls']==0 and all(report['rounding_reference'].values())
    assert report['original_GPU_input_sha256']=='f5221539e4ab7371171b1b67e4b488317e5157d62ddec002dd3d6792e0b6c9b9'
    assert all(row['attribution_context_valid'] and all(row['checks'].values()) for row in report['cases'])
    groups=[dict(backend=row['backend'],case=row['case'],context_valid=row['attribution_context_valid'],layers=[dict(layer=layer['layer'],
        own_operand_non_RN_operations=[op for op in layer['operations'] if not op['operation_correctly_rounded']],
        strict_chain_false_fields=[op['field'] for op in layer['operations'] if not op['strict_chain_match']]) for layer in row['layers']]) for row in report['cases']]
    readout=dict(actual_job='1845.manager',actual_PBS_state='F',actual_PBS_exit=0,Stageout_status=0,run_count=1,
        compute_node='compute002',resources='1CPU/2GiB/5min',setup_worker_command_stage_after_exits=[0,0,0,0],
        physical_forward_calls=0,new_GPU_calls=0,context_reproduction_passed=True,rounding_reference=report['rounding_reference'],
        original_GPU_input_sha256=report['original_GPU_input_sha256'],complete_raw_pickle_bytes=len(original['diagnosis.pickle']),
        complete_raw_pickle_sha256=sha(original['diagnosis.pickle']),groups=groups,
        local_pickle_or_array_numeric_decode=False,source_stage_unchanged=True,
        scope='Exact Fraction/integer real arithmetic and explicit IEEE binary32 nearest-even audit of original closed PB-v geometry. All operations/boolean classifications here were computed on EHPC; local processing merely labels existing JSON. This establishes recorded per-operation RN discrepancies, not a full-trajectory repair or new scientific/P0/same-precision acceptance. Original failures remain.')
    items={'executed-stage.tar.gz':stage_raw,'original-result.tar.gz':raw,'final-qstat.stdout':final.read_bytes(),
        'readout.json':encode(readout),'original-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(original.items())})}
    for name,payload in stage.items():
        if name.startswith(('preparation/','execution/')):items[name]=payload
    for path in source.iterdir():
        if path.is_file() and not path.name.endswith('.tar.gz'):items['closure/'+path.name]=path.read_bytes()
    for path in (BASE/'drainage-geometry-pb-v-analysis-health').iterdir():
        if path.is_file():items['recovery-health/'+path.name]=path.read_bytes()
    for name in ('drainage-geometry-pb-v-analysis-stage-package.json','drainage-geometry-pb-v-analysis-deployment.json',
        'prepare_drainage_geometry_pbv_analysis.py','deploy_drainage_geometry_pbv_analysis.py','verify_pbv_fraction_pbs_health.py',
        'read_pbv_fraction_status.py','collect_pbv_fraction_result.py',Path(__file__).name):items['provenance/'+name]=(BASE/name).read_bytes()
    for prefix in ('drainage-geometry-pb-v-analysis-deploy-','drainage-geometry-pb-v-analysis-1845-status-'):
        for path in BASE.glob(prefix+'*'):
            if path.is_file():items['delivery/'+path.name]=path.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name,payload in sorted(items.items()):
                member=tarfile.TarInfo(name);member.size=len(payload);member.mode=0o644;archive.addfile(member,io.BytesIO(payload))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='EHPC1845 F0/Stageout0 exact Fraction/integer IEEE-RNE audit of original PB-v8 groups; no new physical/GPU calls or acceptance credit.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

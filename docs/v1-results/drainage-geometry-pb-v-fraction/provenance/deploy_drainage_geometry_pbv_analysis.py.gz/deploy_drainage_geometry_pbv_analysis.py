"""One authorized comparison PBS submission; raw command exits preserved."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'drainage-geometry-pb-v-analysis-stage.tar.gz'
expected='86c9b8a2a1884ba4e4b6f571f0d2ba0ec1f1386cc0887efb779fc31b5c4928ed'
assert sha(stage.read_bytes())==expected
target=BASE/'drainage-geometry-pb-v-analysis-deployment.json'
assert not target.exists()
dispatcher=BASE/'drainage-geometry-pb-v-analysis-execution/dispatch_compare_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',
    'test ! -e /tmp/noahmp-drainage-geometry-pb-v-analysis && test ! -e /tmp/noahmp-drainage-geometry-pb-v-analysis-stage.tar.gz && test ! -e /tmp/dispatch_geometry_pbv_analysis.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'ehpc:/tmp/noahmp-drainage-geometry-pb-v-analysis-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(dispatcher),'ehpc:/tmp/dispatch_geometry_pbv_analysis.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',
     '/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_geometry_pbv_analysis.py --archive /tmp/noahmp-drainage-geometry-pb-v-analysis-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_submit=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('drainage-geometry-pb-v-analysis-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('drainage-geometry-pb-v-analysis-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['dispatch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['dispatch']))

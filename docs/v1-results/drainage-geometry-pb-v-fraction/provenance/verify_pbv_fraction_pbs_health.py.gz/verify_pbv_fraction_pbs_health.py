"""Readonly PBS recovery check before the single preauthorized Fraction job."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess

base=Path(__file__).resolve().parent/'drainage-geometry-pb-v-analysis-health'
assert not base.exists();base.mkdir()
queries={'server':'qstat -Bf','nodes':'pbsnodes -av','1813':'qstat -xf 1813.manager','1831':'qstat -xf 1831.manager'}
def read(pair):
    name,query=pair;command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',query]
    result=subprocess.run(command,capture_output=True,timeout=45)
    (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
    row=dict(command=command,actual_exit=result.returncode,stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    (base/(name+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n')
    return name,row,result.stdout.decode(errors='replace')
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(read,queries.items()))
assert all(row['actual_exit']==0 for _,row,_ in results)
text={name:stdout for name,_,stdout in results}
assert 'server_state = Active' in text['server'] and 'scheduling = True' in text['server']
for name,exitcode in (('1813',0),('1831',1)):
    assert all(token in text[name] for token in ('job_state = F','Exit_status = '+str(exitcode),'Stageout_status = 0'))
assert all(node in text['nodes'] for node in ('compute000','compute001','compute002'))
assert text['nodes'].count('state = free')==3
print(json.dumps(dict(actual_exits={name:row['actual_exit'] for name,row,_ in results},server_Active=True,scheduling=True,three_nodes_free=True,job1813_F0_stageout0=True,job1831_F1_stageout0=True,no_quota_number_claim=True)))

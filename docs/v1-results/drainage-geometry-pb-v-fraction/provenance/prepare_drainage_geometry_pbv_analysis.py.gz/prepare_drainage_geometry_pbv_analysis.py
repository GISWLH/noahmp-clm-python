"""Prepare one EHPC exact-output analysis stage; no submission or numerical run."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'drainage-geometry-pb-v-analysis-preparation'
EXEC=BASE/'drainage-geometry-pb-v-analysis-execution'
OLD=BASE/'drainage-rounding-pb-u-execution'
INPUT='f5221539e4ab7371171b1b67e4b488317e5157d62ddec002dd3d6792e0b6c9b9'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    assert not EXEC.exists();EXEC.mkdir()
    previous=b'/tmp/noahmp-drainage-rounding-pb-u';current=b'/tmp/noahmp-drainage-geometry-pb-v-analysis'
    for n in ('dispatch_compare_pbs.py','check_stage_pbs.py'):
        raw=(OLD/n).read_bytes().replace(previous,current).replace(b'/tmp/dispatch_rounding_pbu.py',b'/tmp/dispatch_geometry_pbv_analysis.py')
        compile(ast.parse(raw),n,'exec');(EXEC/n).write_bytes(raw)
    raw=(OLD/'compare_pbs.pbs').read_bytes().replace(previous,current)
    raw=raw.replace(b'drainage-rounding-pbu',b'drainage-geom-pbv-ref').replace(b'$TMPDIR/rounding-result',b'$TMPDIR/geometry-analysis-result')
    original=b'"$py" -B "$stage/preparation/analyze_pbt_outputs.py" --input "$stage/gpu-result.tar.gz" --output "$root/diagnosis.json"'
    replacement=b'"$py" -B "$stage/preparation/analyze_geometry_exact_pbv_b.py" --input "$stage/gpu-result.tar.gz" --input-sha256 '+INPUT.encode()+b' --output "$root/diagnosis.json"'
    assert raw.count(original)==1;raw=raw.replace(original,replacement);assert b'\r' not in raw
    (EXEC/'compare_pbs.pbs').write_bytes(raw)
    (EXEC/'README.md').write_text('Prepared-only PB-v exact analysis. Original PB-u explicit manager/compute transfer/check/PBS pattern,1CPU/2GiB/5min, no submission while PBS unavailable. Worker compares exact Fraction/IEEE reference against original captured operands and has explicit overall context reproduction gate/exit1. No physical forward calls.\n',encoding='utf-8')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}))
    files={}
    for root,prefix in ((PREP,'preparation'),(EXEC,'execution')):
        for p in root.iterdir():
            if p.is_file():files[prefix+'/'+p.name]=p.read_bytes()
    files['gpu-result.tar.gz']=(BASE/'drainage-geometry-pb-v-gpu-closed/gpu-result.tar.gz').read_bytes();assert sha(files['gpu-result.tar.gz'])==INPUT
    files['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(files.items())})
    target=BASE/'drainage-geometry-pb-v-analysis-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,raw in sorted(files.items()):
                m=tarfile.TarInfo(n);m.size=len(raw);m.mode=0o644;archive.addfile(m,io.BytesIO(raw))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==files
    record=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),stage_files=len(files),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha(files['preparation/CONTROLS_SHA256.json']),execution_manifest_sha256=sha(files['execution/CONTROLS_SHA256.json']),
        actual_GPU_input_sha256=INPUT,prepared_only=True,launched=False,numerical_executed=False,
        resources='1CPU/2GiB/5min/compute002',physical_forward_calls=0,context_invalid_returns=1)
    (BASE/'drainage-geometry-pb-v-analysis-stage-package.json').write_bytes(encode(record));print(json.dumps(record))

if __name__=='__main__':main()

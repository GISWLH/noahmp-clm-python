"""EHPC-only IEEE binary32 nearest-even geometry reference, exact rational core."""
import argparse
from fractions import Fraction
import hashlib
import io
import json
import math
from pathlib import Path
import pickle
import socket
import struct
import tarfile

import numpy as np

sha=lambda raw:hashlib.sha256(raw).hexdigest()

def fraction_from_bits(bits):
    sign=-1 if bits>>31 else 1;exponent=(bits>>23)&255;mantissa=bits&0x7fffff
    if exponent==255:raise ValueError('Exact reference requires finite operands')
    if exponent==0:return Fraction(sign*mantissa,1<<149)
    mantissa|=1<<23;shift=exponent-150
    return Fraction(sign*mantissa*(1<<shift),1) if shift>=0 else Fraction(sign*mantissa,1<<-shift)

def scaled(value,shift):
    return value*(1<<shift) if shift>=0 else value/Fraction(1<<-shift)

def nearest_even_integer(value):
    assert value>=0
    q,r=divmod(value.numerator,value.denominator)
    if 2*r>value.denominator or (2*r==value.denominator and q&1):q+=1
    return q

def round_binary32(value,zero_sign=0):
    assert isinstance(value,Fraction)
    sign=0x80000000 if value<0 or (value==0 and zero_sign) else 0
    value=abs(value)
    if value==0:return sign
    exponent=value.numerator.bit_length()-value.denominator.bit_length()
    if value<scaled(Fraction(1),exponent):exponent-=1
    if exponent < -126:
        return sign|nearest_even_integer(scaled(value,149))
    mantissa=nearest_even_integer(scaled(value,23-exponent))
    if mantissa==1<<24:mantissa>>=1;exponent+=1
    if exponent>127:return sign|0x7f800000
    assert 1<<23<=mantissa<1<<24
    return sign|((exponent+127)<<23)|(mantissa-(1<<23))

def operation(op,a,b):
    x,y=fraction_from_bits(a),fraction_from_bits(b)
    if op=='add':
        value=x+y;zero_sign=int(x==0 and y==0 and bool(a>>31) and bool(b>>31))
    elif op=='mul':value=x*y;zero_sign=(a>>31)^(b>>31)
    elif op=='div':
        if y==0:raise ValueError('Zero denominator in recorded positive geometry')
        value=x/y;zero_sign=(a>>31)^(b>>31)
    elif op=='min1':
        return (a if x<=1 else 0x3f800000),dict(op=op,exact_numerator=str(min(x,Fraction(1)).numerator),exact_denominator=str(min(x,Fraction(1)).denominator))
    else:raise ValueError(op)
    return round_binary32(value,zero_sign),dict(op=op,exact_numerator=str(value.numerator),exact_denominator=str(value.denominator))

def verify_rounding():
    assert round_binary32(Fraction(1)+Fraction(1,1<<24))==0x3f800000
    assert round_binary32(Fraction(1)+Fraction(3,1<<24))==0x3f800002
    assert round_binary32(Fraction(1,1<<150))==0
    assert round_binary32(Fraction(3,1<<150))==2
    assert round_binary32(Fraction(0),1)==0x80000000
    maximum=fraction_from_bits(0x7f7fffff)
    assert round_binary32(maximum)==0x7f7fffff
    assert round_binary32(maximum+Fraction(1<<103))==0x7f800000
    for bits in (0,1,2,0x007fffff,0x00800000,0x3f000000,0x3f800000,0x3f800001,0x447a0000,0x7f7fffff,0x80000001,0xbf800000):
        assert round_binary32(fraction_from_bits(bits))==bits
    return dict(passed=True,halfway_nearest_even=True,subnormal_and_normal_boundary=True,overflow_halfway=True,signed_zero=True)

def unpack(raw):
    out={}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for m in archive:
            if m.isdir():continue
            n=m.name.removeprefix('./')
            assert m.isfile() and n not in out and not Path(n).is_absolute() and '..' not in Path(n).parts
            out[n]=archive.extractfile(m).read()
    return out

def load(data,backend,case):
    prefix=backend+'/device/'+case+'/';meta=json.loads(data[prefix+'result.json']);raw=data[prefix+'result.npz']
    assert sha(raw)==meta['npz_sha256']
    with np.load(io.BytesIO(raw),allow_pickle=False) as store:values={n:store[n].copy() for n in store.files}
    assert set(values)==set(meta['arrays'])
    for n,v in values.items():
        d=meta['arrays'][n]
        assert (v.dtype.str,list(v.shape),sha(v.tobytes()))==(d['dtype'],d['shape'],d['c_order_sha256'])
        assert v.dtype==np.float32
    return values,meta

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--input-sha256',required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert socket.gethostname()=='compute002' and not a.output.exists()
    raw=a.input.read_bytes();assert sha(raw)==a.input_sha256;data=unpack(raw)
    binding=json.loads((Path(__file__).parent/'BINDINGS.json').read_bytes())
    rows=[];packets={};checks=verify_rounding()
    thousand=round_binary32(Fraction(1000));density=round_binary32(Fraction(917))
    for backend in ('cuda','jax'):
        receipt=json.loads(data[backend+'/device/capture-receipt.json'])
        assert receipt['source_manifest_sha256']==binding['source_manifest_sha256']
        assert receipt['original_diagnosis_returned']==receipt['geometry_context_returned']==4
        source_context_valid=bool(receipt.get('source_controls_prior_unchanged')) and receipt.get('gpu_uuid')==binding['GPU_UUID']
        for case in binding['cases']:
            values,meta=load(data,backend,case);packets[backend+'/'+case]=dict(arrays=values,metadata=meta)
            c=values['input.phase_cells'].view(np.uint32)[0];parameters=values['input.parameters'].view(np.uint32)[0]
            actual=values['context.components'].view(np.uint32)[0];layers=[]
            for k in range(4):
                liquid,ice,dz=map(int,c[k,:3]);porosity=int(parameters[0]);reference=[];operations=[]
                for index in range(9):
                    # Strict reference follows the original operation grouping.
                    def operands(history):
                        return (('div',liquid,thousand),('div',ice,density),('add',history[0],history[1]),
                            ('mul',dz,porosity),('div',history[2],history[3]),('mul',density,dz),
                            ('mul',history[5],porosity),('div',ice,history[6]),('min1',history[7],0x3f800000))[index]
                    # Fill unavailable future references only to build the tuple;
                    # the selected operation accesses already-produced entries.
                    expected_op,x,y=operands(reference+[0]*(9-len(reference)))
                    expected,exact=operation(expected_op,x,y);reference.append(expected)
                    actual_op,ax,ay=operands([int(v) for v in actual[k]])
                    rounded_actual_operands,actual_exact=operation(actual_op,ax,ay)
                    observed=int(actual[k,index])
                    operations.append(dict(field=meta['component_fields'][index],actual_bits=f'0x{observed:08x}',
                        strict_chain_bits=f'0x{expected:08x}',strict_chain_match=observed==expected,
                        actual_operand_bits=[f'0x{ax:08x}',f'0x{ay:08x}'],
                        correctly_rounded_actual_operands_bits=f'0x{rounded_actual_operands:08x}',
                        operation_correctly_rounded=observed==rounded_actual_operands,exact_chain_operation=exact,
                        exact_actual_operand_operation=actual_exact,
                        actual_value=struct.unpack('<f',struct.pack('<I',observed))[0]))
                layers.append(dict(layer=k,operations=operations))
            rows.append(dict(backend=backend,case=case,attribution_context_valid=meta['attribution_context_valid'] and source_context_valid,source_controls_prior_unchanged=source_context_valid,checks=meta['checks'],layers=layers))
    context_reproduction_passed=all(row['attribution_context_valid'] and all(row['checks'].values()) for row in rows) and len(rows)==8
    report=dict(completed=True,passed=context_reproduction_passed,context_reproduction_passed=context_reproduction_passed,rounding_reference=checks,source_manifest_sha256=binding['source_manifest_sha256'],
        original_GPU_input_sha256=sha(raw),physical_forward_calls=0,cases=rows,
        scope='Fraction/integer exact-real operations plus explicit binary32 nearest-even rounding, no float64-cast reference. Attribution requires original-context reproduction; intermediate-context mismatches remain inconclusive.')
    with a.output.with_suffix('.pickle').open('xb') as out:pickle.dump(dict(report=report,original_packets=packets),out,protocol=5)
    def safe(x):
        if isinstance(x,float) and not math.isfinite(x):return dict(nonfinite='NaN' if math.isnan(x) else ('+Inf' if x>0 else '-Inf'))
        if isinstance(x,dict):return {k:safe(v) for k,v in x.items()}
        if isinstance(x,(list,tuple)):return [safe(v) for v in x]
        return x
    a.output.write_text(json.dumps(safe(report),indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(completed=True,passed=context_reproduction_passed,context_reproduction_passed=context_reproduction_passed,backend_cases=len(rows),physical_forward_calls=0)))
    return 0 if context_reproduction_passed else 1

if __name__=='__main__':raise SystemExit(main())

from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'optics-surface-dg'
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
    if free>8192 and mem>32*1024*1024:break
    (r/'waiting.json').write_text(json.dumps(dict(gpu_free_mib=free,host_available_kib=mem))+'\n');time.sleep(20.)
start=time.monotonic()
with (r/'model.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'probe_optics_surface_dg.py')],stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid),indent=2)+'\n');code=p.wait();path=r/'receipt.json';d=json.loads(path.read_text()) if path.exists() else {};good=code==0 and d.get('expected_failure_reproduced') and d.get('raw_surface_captured') and d.get('source_unchanged') and d.get('original_year_report_unchanged');row=dict(actual_child_returncode=code,diagnostic_delivered=bool(good),seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None,scope='Actualprivateprobe parentwait only; originalyear remainsfailed356, notresumed.');(r/'exit.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);raise SystemExit(0 if good else 1)

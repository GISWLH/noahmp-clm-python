"""One private copied failed tendency; diagnostic outputs never enter a trajectory."""
from pathlib import Path
from dataclasses import astuple
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=Path('/tmp/noahmp-bounded-cn-co/source');r=b/'optics-surface-dg';old=b/'qia-bounded-capacity_optics-cuda-year-cy';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==568 and all(sha(s/n)==h for n,h in m.items())
terminal=json.loads((old/'year-exit.json').read_text());year=json.loads((old/'year-receipt.json').read_text());assert terminal['returncode']==1 and not terminal['passed'] and year['source_unchanged'];old_hash=sha(old/'trajectory/batch.json')
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as cpu
import noahmp_clm.clm_enthalpy_driver as model
import noahmp_clm.gpu.cuda.canopy_phase_surface as surface
import cupy as cp
report,saved,prior=native.read_generation(old/'trajectory');index=report['steps_completed'];assert report['status']=='failed' and index==356 and report['steps_requested']==17520
cases=native.load_batch(old/'inputs/capacity_optics/batch.json');dtype=np.float32;a=native.checkpoint_arrays(saved,report['identity']);assert len(a)==23 and len(cases)==1
forcing=np.asarray([c['data']['forcing'][index] for c in cases],dtype);environment=np.asarray([c['data']['environment'][index] for c in cases],dtype)
calendar,flags=native.pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype)
schedules=[native.DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([q.nitrogen_rate for q in schedules],dtype)*forcing[:,0];deposition=np.asarray([q.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,q) in enumerate(zip(cases,schedules))],dtype)
geometry=np.asarray([astuple(native.MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype);leaf=np.asarray([astuple(native.LeafParameters(**c['config']['leaf_parameters'])) for c in cases],dtype)
capacity_environment=native.pack_capacity_environment([native.capacity_environment(c['stamps'][index],c['metadata'],True) for c in cases],dtype=dtype)
from noahmp_clm.physics.canopy_optics import CanopyOptics
from noahmp_clm.gpu.canopy_optics import pack_canopy_optics
optics=np.stack([pack_canopy_optics(CanopyOptics(**c['config']['canopy_optics']),dtype) for c in cases])
kwargs=dict(environment=calendar,calendar=flags,nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,most_geometry=geometry,leaf_parameters=leaf,return_surface=True,soil_hydrology=native.batch_hydrology(cases),capacity_environment=capacity_environment,canopy_optics=optics)
engine=native.Backend('cuda32');device=engine.update_forcing(tuple(cp.asarray(v) for v in a),environment);before=tuple(engine.host(v) for v in device);original=surface.run_canopy_phase_surface_cuda;calls=0;captured=False;diagnostic={}
def flatten(value,prefix,packet):
    for key,v in value.items():
        if isinstance(v,dict):flatten(v,prefix+key+'/',packet)
        else:packet[prefix+key]=engine.host(v)
def wrapped(*arrays,**controls):
    global calls,captured,diagnostic
    calls+=1
    try:return original(*arrays,**controls)
    except RuntimeError as error:
        if str(error)!='CUDA layered phase surface failed; inspect with raise_on_failure=False':raise
        packet={'input'+str(k):engine.host(v) for k,v in enumerate(arrays)}
        for key,v in controls.items():
            if v is not None:packet['control/'+key]=engine.host(v)
        result=original(*arrays,**{**controls,'raise_on_failure':False});flatten(result,'output/',packet)
        np.savez_compressed(r/'failed-surface-input-output.npz',**packet);captured=True
        diagnostic={key:engine.host(result[key]).tolist() for key in ['converged','canopy_converged','iterations','restarts','max_solver_residual','layer_residual','leaf_temperature','ground_temperature'] if key in result}
        diagnostic['nonfinite_output_fields']=[key for key,value in packet.items() if key.startswith('output/') and not np.all(np.isfinite(value))]
        (r/'surface-diagnostic.json').write_text(json.dumps(diagnostic,indent=2)+'\n');raise
def blocked(*args,**kw):raise AssertionError('Diagnostic cannot use NumPy forward physics')
failure=None;start=time.monotonic();output=False
try:
    surface.run_canopy_phase_surface_cuda=wrapped;cpu.step_clm_enthalpy_column=blocked;model.step_clm_enthalpy_column=blocked
    engine.step(*device,forcing,**kwargs);output=True
except Exception as error:failure=type(error).__name__+': '+str(error);(r/'traceback.txt').write_text(traceback.format_exc())
finally:surface.run_canopy_phase_surface_cuda=original
cp.cuda.runtime.deviceSynchronize()
packet=dict(forcing=forcing,environment=environment,calendar=calendar,calendar_flags=flags,nitrogen=nitrogen,deposition=deposition,geometry=geometry,leaf_parameters=leaf,capacity_environment=capacity_environment,canopy_optics=optics)
packet.update({'before'+str(k):v for k,v in enumerate(before)});packet.update({'saved_'+k:v for k,v in saved.items() if k in ['initial','net','bounds','maximum','stepmax','tracermax','index']});np.savez_compressed(r/'tendency-inputs-and-ledger.npz',**packet)
for name in ['year-exit.json','year-receipt.json','year-traceback.txt']:(r/name).write_bytes((old/name).read_bytes())
(r/'failed-batch-report.json').write_bytes((old/'trajectory/batch.json').read_bytes());(r/'configuration.json').write_text(json.dumps(cases[0]['config'],indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
d=dict(expected_failure_reproduced=failure==year['failure'],failure=failure,output_produced=output,raw_surface_captured=captured,surface_calls=calls,failed_zero_based_step=index,local_timestamp=str(cases[0]['stamps'][index]),seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_year_report_unchanged=sha(old/'trajectory/batch.json')==old_hash,original_year_parent_exit=terminal['returncode'],device_barrier_complete=True,diagnostic=diagnostic,scope='Private copiedcurrentCN failed356 single tendency on physical1. Original solver failure re-raised, diagnostic raise_on_failureFalse result saved then discarded, never advanced or resumedfailedyear; no source/test/gate/forcing/config edits or NumPyforward. Diagnosticdelivery is not physics/conservation/annual pass.')
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0 if d['expected_failure_reproduced'] and captured and d['source_unchanged'] and d['original_year_report_unchanged'] else 1)

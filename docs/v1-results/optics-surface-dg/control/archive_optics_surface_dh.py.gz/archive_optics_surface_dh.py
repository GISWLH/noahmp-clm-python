from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'optics-surface-dg';d=json.loads((r/'exit.json').read_text());assert d['actual_child_returncode']==0 and d['diagnostic_delivered'];v=json.loads((r/'receipt.json').read_text());assert v['expected_failure_reproduced'] and v['raw_surface_captured'] and v['source_unchanged'] and v['original_year_report_unchanged'];old=b/'qia-bounded-capacity_optics-cuda-year-cy';d=json.loads((old/'year-exit.json').read_text());assert d['returncode']==1 and not d['passed'];a=b/'optics-surface-dg-evidence.tar.gz';assert not a.exists();items=[]
for root,prefix in [(r,'probe'),(old,'original-failed-year')]:
    items.extend((p,prefix+'/'+p.relative_to(root).as_posix()) for p in sorted(root.rglob('*')) if p.is_file())
items.append((Path(__file__),'control/'+Path(__file__).name))
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

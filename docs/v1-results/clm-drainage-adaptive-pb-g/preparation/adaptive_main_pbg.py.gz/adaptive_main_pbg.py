"""Isolated main-band adaptive device orchestration, prepared but unexecuted.

Unexecuted preparation. Scientific arrays stay on the selected backend; host
scalars choose substep acceptance. No production registration or perched path.
NumPy64 is the independent reference; JAX64/JAX32 and CUDA32 keep their explicit
input precision. Float32 uses outlet-based local errors to avoid subtracting
nearby 225 kg/m2 stocks; its physical accuracy remains to be measured.
"""
import math

import drainage_primitives_pbf as primitives
from saturated_drainage_pb import IntegrationControls


def _backend(name):
    if name=='numpy':
        import numpy as xp
        return xp,primitives.run_numpy
    if name=='jax':
        import jax
        import jax.numpy as xp
        if not jax.config.jax_enable_x64:
            raise ValueError('Enable JAX x64 configuration so explicit 64-bit inputs cannot silently truncate')
        return xp,primitives.run_jax
    if name=='cuda':
        import cupy as xp
        return xp,primitives.run_cuda
    raise ValueError('Choose numpy, jax or cuda explicitly')


def _phase(c,p,option,xp,backend):
    """Re-invert unchanged extensive stocks using the existing backend operator."""
    if backend=='numpy':
        from noahmp_clm.column import SoilParams
        from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
        soil=SoilEnthalpyState(c[:,4],c[:,5],c[:,2],
            SoilParams(smcmax=float(p[0]),saturated_suction_m=float(p[1]),
                       bexp=float(p[2]),satdk=float(p[3])),option)
        liquid=soil.liquid;temperature=soil.temperature
    else:
        if backend=='jax':
            from noahmp_clm.gpu.enthalpy import run_soil_thermodynamics_jax as inverse
        else:
            from noahmp_clm.gpu.cuda.enthalpy import run_soil_thermodynamics_cuda as inverse
        packed=xp.stack((c[:,4],c[:,5],c[:,2],xp.full(4,p[0],c.dtype),
                         xp.full(4,p[2],c.dtype),xp.full(4,p[1],c.dtype)),axis=1)
        out=inverse(packed,xp.full(4,option,xp.int32),inverse=True)
        if out['temperature_k'].dtype!=c.dtype or out['liquid_kgm2'].dtype!=c.dtype:
            raise RuntimeError('Phase operator silently changed requested precision')
        if not bool(xp.all(out['converged'])):
            raise RuntimeError('Original device phase inversion did not converge')
        temperature=out['temperature_k']
        liquid=xp.where(temperature>=273.15,c[:,4],xp.clip(out['liquid_kgm2'],0,c[:,4]))
    return xp.stack((liquid,c[:,4]-liquid,c[:,2],temperature,c[:,4],c[:,5]),axis=1)


def _stocks(c,water,enthalpy,xp):
    # First four fields are placeholders until _phase; no forced T/ice is used.
    return xp.stack((c[:,0],c[:,1],c[:,2],c[:,3],water,enthalpy),axis=1)


def _kahan(total,compensation,value):
    increment=value-compensation;updated=total+increment
    return updated,(updated-total)-increment


def advance_main_band(cells,parameters,freezing_option,duration_seconds,front_m,bottom_m,
                      controls=IntegrationControls(),backend='numpy'):
    """One four-layer column, actual phase inversion after every liquid trial.

    Returns phase-consistent cells, migrated front and cumulative extensive
    ledger. Host control synchronization is deliberate at this isolated stage;
    it is not a fused/performance-qualified native column kernel.
    """
    xp,run=_backend(backend);c=xp.asarray(cells);p=xp.asarray(parameters)
    if c.dtype not in (xp.float32,xp.float64) or p.dtype!=c.dtype:
        raise ValueError('Explicit same-precision float32 or float64 inputs required')
    if backend=='numpy' and c.dtype!=xp.float64:
        raise ValueError('Independent NumPy phase reference is float64; no hidden NumPy32/64 mixed chain')
    if backend=='cuda' and c.dtype!=xp.float32:
        raise ValueError('Original CUDA phase supports float32 only; never silently truncate float64')
    low_precision=c.dtype==xp.float32
    if type(freezing_option) is not int or freezing_option not in (1,2):
        raise ValueError('Original integer phase option 1 or 2 required')
    if (isinstance(duration_seconds,bool) or not math.isfinite(duration_seconds) or duration_seconds<=0
            or not isinstance(controls,IntegrationControls)):
        raise ValueError('Positive finite duration and original integration controls required')
    interval=xp.asarray([duration_seconds,front_m,bottom_m],c.dtype)
    primitives.validate(c[None],p[None],interval[None],xp)
    # Explicit quantization belongs to the input contract, not a silent phase cast.
    duration_seconds=float(interval[0]);front_m=float(interval[1]);bottom_m=float(interval[2])
    initial=_phase(c,p,freezing_option,xp,backend)
    # Reject inconsistent explicit input phase rather than silently replacing it.
    scale=64*xp.finfo(c.dtype).eps*xp.maximum(xp.abs(initial[:,:4])+xp.abs(c[:,:4]),1)
    if bool(xp.any(xp.abs(initial[:,:4]-c[:,:4])>scale)):
        raise ValueError('Supplied temperature/phase is inconsistent with original extensive inversion')
    current=initial;front=xp.asarray(front_m,c.dtype);elapsed=0.
    step=min(duration_seconds,controls.maximum_step_seconds)
    mass=xp.zeros(4,c.dtype);heat=xp.zeros(4,c.dtype)
    mc=xp.zeros(4,c.dtype);hc=xp.zeros(4,c.dtype)
    accounts=xp.zeros(3,c.dtype);ac=xp.zeros(3,c.dtype)
    accepted=rejected=0;maximum_ratio=0.

    def trial(state,z,seconds):
        u=xp.stack((xp.asarray(seconds,c.dtype),z,xp.asarray(bottom_m,c.dtype)))
        _,output=run(state[None],p[None],u[None]);one=output[0]
        after=_phase(_stocks(state,one[18:22],one[22:26],xp),p,freezing_option,xp,backend)
        return after,one[0],one

    while elapsed<duration_seconds:
        if accepted+rejected>=controls.maximum_attempts:
            raise RuntimeError('Main drainage adaptive attempt budget exhausted')
        step=min(step,duration_seconds-elapsed)
        if low_precision:
            step=float(xp.asarray(step,c.dtype))
            if step>duration_seconds-elapsed:
                step=float(xp.nextafter(xp.asarray(step,c.dtype),xp.asarray(0.,c.dtype)))
            if step<=0.:raise RuntimeError('No representable positive remaining float32 time step')
        coarse,coarse_front,coarse_ledger=trial(current,front,step)
        if float(coarse_ledger[1])==0.:
            elapsed=duration_seconds;break
        half,half_front,a=trial(current,front,.5*step)
        fine,fine_front,b=trial(half,half_front,.5*step)
        ratios=[]
        for k,offset,tolerance in ((4,10,controls.water_absolute_tolerance_kg_m2),(5,14,controls.energy_absolute_tolerance_j_m2)):
            if low_precision:
                # These are the actual extensive exports used by the canonical
                # state, not stock differences quantized at large background W/H.
                coarse_increment=coarse_ledger[offset:offset+4]
                fine_increment=a[offset:offset+4]+b[offset:offset+4]
                magnitude=xp.maximum(xp.abs(coarse_increment),xp.abs(fine_increment))
                resolution=4*xp.finfo(c.dtype).eps*magnitude
                bound=xp.maximum(tolerance+controls.relative_tendency_tolerance*magnitude,resolution)
                ratios.append(float(xp.max(xp.abs(coarse_increment-fine_increment)/bound)))
            else:
                bound=tolerance+controls.relative_tendency_tolerance*xp.maximum(
                    xp.abs(coarse[:,k]-current[:,k]),xp.abs(fine[:,k]-current[:,k]))
                ratios.append(float(xp.max(xp.abs(coarse[:,k]-fine[:,k])/bound)))
        front_scale=controls.front_absolute_tolerance_m+controls.relative_tendency_tolerance*xp.maximum(
            xp.abs(coarse_front-front),xp.abs(fine_front-front))
        if low_precision:
            # Two independently rounded positions cannot resolve sub-ULP depth
            # differences. This changes only local temporal control, not M/H.
            depth_resolution=2*xp.finfo(c.dtype).eps*xp.maximum(xp.abs(coarse_front),xp.abs(fine_front))
            front_scale=xp.maximum(front_scale,depth_resolution)
        ratios.append(float(xp.abs(coarse_front-fine_front)/front_scale))
        ratios.append(float(xp.max(xp.abs(fine[:,3]-current[:,3])))/controls.maximum_temperature_change_k)
        stored=1000*primitives._integral(front,xp.asarray(bottom_m,c.dtype),p,xp,lambda x:x)
        fraction_scale=controls.maximum_band_storage_fraction*stored+controls.water_absolute_tolerance_kg_m2
        ratios.append(float((a[2]+b[2])/fraction_scale))
        ratio=max(ratios)
        if not math.isfinite(ratio):raise RuntimeError('Nonfinite adaptive error ratio')
        if ratio>1.:
            rejected+=1;step*=max(.1,.8/math.sqrt(ratio))
            if step<1e-8:raise RuntimeError('Main drainage temporal/thermal substep underflow')
            continue
        for one in (a,b):
            mass,mc=_kahan(mass,mc,one[10:14]);heat,hc=_kahan(heat,hc,one[14:18])
            accounts,ac=_kahan(accounts,ac,xp.stack((one[1],one[3],one[4])))
        canonical=_phase(_stocks(initial,initial[:,4]-mass,initial[:,5]-heat,xp),p,freezing_option,xp,backend)
        for k in (4,5):
            rounding=64*xp.finfo(c.dtype).eps*xp.maximum(xp.sum(xp.abs(canonical[:,k])+xp.abs(fine[:,k])),1)
            if bool(xp.max(xp.abs(canonical[:,k]-fine[:,k]))>rounding):
                raise RuntimeError('Accepted main trial disagrees with Kahan extensive state')
        current=canonical;front=fine_front;elapsed+=step;accepted+=1;maximum_ratio=max(maximum_ratio,ratio)
        if bool(b[5]) and float(b[2])==0.:
            # Rate-only accounting from a non-mutating frozen trial, no extra phase step.
            u=xp.stack((xp.asarray(duration_seconds-elapsed,c.dtype),front,xp.asarray(bottom_m,c.dtype)))
            if elapsed<duration_seconds:
                _,blocked=run(current[None],p[None],u[None]);unmet=blocked[0,1]
                accounts,ac=_kahan(accounts,ac,xp.stack((unmet,unmet,xp.asarray(0.,c.dtype))))
            elapsed=duration_seconds
        step=min(controls.maximum_step_seconds,step*min(2.,max(.5,.8/math.sqrt(max(ratio,1e-12)))))
    # Extensive final stocks use cumulative outlets once, never repeated subtraction.
    final=_phase(_stocks(initial,initial[:,4]-mass,initial[:,5]-heat,xp),p,freezing_option,xp,backend)
    mr=xp.sum((final[:,4]-initial[:,4])+mass);hr=xp.sum((final[:,5]-initial[:,5])+heat)
    mb=64*xp.finfo(c.dtype).eps*xp.maximum(xp.sum(xp.abs(initial[:,4])+xp.abs(final[:,4])+xp.abs(mass)),1)
    hb=64*xp.finfo(c.dtype).eps*xp.maximum(xp.sum(xp.abs(initial[:,5])+xp.abs(final[:,5])+xp.abs(heat)),1)
    if bool(xp.abs(mr)>mb) or bool(xp.abs(hr)>hb):raise RuntimeError('Adaptive main hard M/H ledger failed')
    ledger=dict(kind='saturated',layer_mass_kg_m2=mass,layer_enthalpy_j_m2=heat,
        drained_kg_m2=xp.sum(mass),drained_enthalpy_j_m2=xp.sum(heat),
        water_residual_kg_m2=mr,energy_residual_j_m2=hr,water_bound_kg_m2=mb,energy_bound_j_m2=hb,
        initial_front_m=front_m,migrated_front_m=front,band_bottom_m=bottom_m,elapsed_seconds=elapsed,
        potential_requested_kg_m2=accounts[0],unavailable_liquid_kg_m2=accounts[1],band_exhaustion_kg_m2=accounts[2],
        accepted_substeps=accepted,rejected_substeps=rejected,maximum_accepted_error_ratio=maximum_ratio,
        quantized_requested_duration_seconds=duration_seconds,clock_residual_seconds=elapsed-duration_seconds,
        backend=backend,precision=str(c.dtype),perched_evolution=False,production_registered=False,
        local_error_basis='actual outlet increments plus front representability' if low_precision else 'original PB-c stock differences',
        float32_physical_accuracy_validated=False)
    return final,front,ledger

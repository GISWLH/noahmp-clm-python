# PB-g adaptive main band — implementation prepared, not yet numerically tested

This extends the real PB-f primitives to original extensive phase inversion after
each trial, full/two-half-step rejection, thermal and finite-storage controls,
ordered donors, cumulative Kahan outlets, canonical initial-minus-outlet stocks,
explicit blocked-front accounting, and final hard M/H budgets. It handles one
four-layer main band at a time; host control synchronizes device scalars. It is
not yet a fused or performance-qualified column kernel, and it does not implement
perched evolution or register in production. No tests/compilation/device execution
are claimed for this directory. Frozen PB-f/f2 and PB-c remain unchanged.

`advance_main_band(cells, parameters, freezing_option, duration_seconds, front_m,
bottom_m, controls, backend)` returns phase-consistent six-field cells, the
migrating front, and a cumulative extensive ledger. The packing/units are those
of PB-f. Main theta diagnostics are not substituted for a migrating front during
the interval. All outputs, input stocks, hard budgets and actual elapsed clock
are checked. Failed attempts/thermal-domain inversions raise rather than return
partial success. No watmin or thermal source is inserted.

Precision is explicit. NumPy64 uses the original independent SoilEnthalpyState
inversion. JAX64/JAX32 use the existing JAX phase operator with matching dtype;
CUDA32 uses the existing CUDA phase operator. CUDA64 is rejected before its
original float32-only inverse can silently truncate. NumPy32 is rejected rather
than presenting a float64 phase solve as an all-float32 reference. JAX x64 must
be enabled so explicit float64 inputs cannot silently become float32. Device
float32 inputs are explicitly quantized first; substep times are representable
float32 values and the cumulative clock uses their actual values.

For float64 the local estimator remains the PB-c difference in W/H stocks. For
float32 it compares the actual exported mass/enthalpy of the coarse trial with
the sum of the two half-trial exports. Mathematically these are the same local
increments, but this avoids cancellation of nearby approximately 225 kg/m²
stocks. The resolution floor is `4*eps*max(abs(coarse_export),abs(fine_export))`
for each local export. Front error cannot resolve two rounded depth values below
`2*eps*max(abs(coarse_front),abs(fine_front))`; only that local estimator uses this
floor. Maximum temperature change, original relative tendency tolerance, and
remaining-band storage fraction remain in force. **None of these change the
original `64*eps*extensive_scale` hard M/H bounds.** This is a prepared control
choice, not a demonstrated float32 accuracy result; actual timestep refinement,
NumPy64 ODE/reference comparisons and JAX32/CUDA32 1e-6 tests are still required.

The prepared EHPC-only NumPy tests exercise real coupled phase/main-band
integration, the actual immutable 1616 256-step original reference and independent
continuous Sy ODE, frozen-stock comparison to PB-c, dry/no-mining, zero slope,
attempt failure, bad phase and mixed-precision rejection. There are seven test
methods / eight expected parameterized cases (static count, not collected).
Run only in an isolated EHPC compute002 PBS task with existing dependencies and
exact NM584 source on PYTHONPATH. No JAX is currently installed in the authorized
EHPC environment; no alternate JAX version is installed for this test. GPU runs
remain root-scheduled for physical CUDA1 without disturbing active NQ/NS/NZ.

The unresolved PB-e perched differences remain a separate scientific boundary.
Do not alter donor layers to match an official hydrology-only fixed-T/ice step
with an actual enthalpy-withdrawal phase-changing component. A future explicit
immutable-coefficient diagnostic and/or matched thermal-boundary reference must
keep this distinction and its energy ledger visible.

from pathlib import Path
import datetime,hashlib,json,os,sys
b=Path('/home/zhangyq/noahmp-v1').resolve();scratch=Path('/var/tmp/zhangyq-noahmp-inode-20261019-a');scratch.mkdir(exist_ok=True);assert not scratch.is_symlink() and scratch.stat().st_uid==os.getuid();sha=lambda raw:hashlib.sha256(raw).hexdigest()
report=scratch/'cache-inventory.json'
if sys.argv[1]=='inventory':
    files=[];dirs=[]
    for root,names,leaves in os.walk(b,followlinks=False):
        p=Path(root);names[:]=[n for n in names if not (p/n).is_symlink() and n!='.git']
        if p.name=='__pycache__':
            dirs.append(str(p))
            for n in leaves:
                q=p/n
                if q.suffix=='.pyc' and not q.is_symlink():files.append(dict(path=str(q),bytes=q.stat().st_size,mtime_ns=q.stat().st_mtime_ns))
    d=dict(scope='Only generatedPython bytecode caches in this project; no .py/.cu/.so/inputs/logs/modeloutputs/sourcehashmanifest removed. Metadata-only inode recovery; activePBS295 uses compute-localsource.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=str(b),files=files,cache_directories=dirs)
    report.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(files=len(files),directories=len(dirs),bytes=sum(v['bytes'] for v in files),report=str(report),report_sha256=sha(report.read_bytes()))))
else:
    assert sys.argv[1]=='clean' and sha(report.read_bytes())==sys.argv[2];d=json.loads(report.read_text());removed=[]
    for row in d['files']:
        q=Path(row['path']);resolved=q.resolve();assert resolved.is_relative_to(b) and not q.is_symlink() and q.parent.name=='__pycache__' and q.suffix=='.pyc'
        if q.exists():
            stat=q.stat();assert stat.st_size==row['bytes'] and stat.st_mtime_ns==row['mtime_ns'];q.unlink();removed.append(str(q))
    removed_dirs=[]
    for n in sorted(d['cache_directories'],key=len,reverse=True):
        q=Path(n);assert q.resolve().is_relative_to(b) and not q.is_symlink() and q.name=='__pycache__'
        if q.exists() and not any(q.iterdir()):q.rmdir();removed_dirs.append(n)
    result=dict(scope=d['scope'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),removed_bytecode_files=removed,removed_empty_cache_directories=removed_dirs,inventory_sha256=sys.argv[2]);(scratch/'cache-cleaned.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(removed_files=len(removed),removed_directories=len(removed_dirs),receipt=str(scratch/'cache-cleaned.json'))))

from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
import sys
import tarfile

base = Path('/home/zhangyq/noahmp-v1')
mode = sys.argv[1]
if mode == 'audit':
    root = base / 'qia1110-paired-audit-j'
    assert (root / 'pbs-exit.txt').read_text().strip() == '0'
    audit = json.loads((root / 'audit.json').read_text())
    assert audit['passed'] and audit['source_unchanged'] and len(audit['fields']) == 380
    archive = base / 'qia1110-paired-audit-j-evidence.tar.gz'
    files = [(p.relative_to(base).as_posix(), p) for name in ['qia1110-paired-audit-i', 'qia1110-paired-audit-j']
             for p in sorted((base / name).rglob('*')) if p.is_file()]
    files.extend(('control/' + name, base / name) for name in
                 ['audit_qia1110_paired_i.py', 'qia1110_paired_i.pbs', 'dispatch_qia1110_paired_i.py',
                  'audit_qia1110_paired_j.py', 'qia1110_paired_j.pbs', 'dispatch_qia1110_paired_j.py'])
    record = dict(scope='Actual PBS296 compute002: current519H native CUDA32/JAX32 all361 outputs+19 states at original1e-6; independent original step/cumulative MHCN and impurity bounds. Earlier i dispatch hit ENOSPC before qsub; its partial extraction retained, no physics result credited. Storage recovered before fresh j submission; no failed model trajectory resumed.',
                  utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pbs_exit=0,
                  maximum_absolute_difference=audit['maximum_absolute_difference'])
else:
    assert mode == 'inode'
    root = Path('/var/tmp/zhangyq-noahmp-inode-20261019-a')
    archive = root.parent / 'ehpc-inode-recovery-b-evidence.tar.gz'
    files = [(p.name, p) for p in sorted(root.iterdir()) if p.is_file()]
    files.extend(('control/' + name, root.parent / name) for name in
                 ['reclaim_ehpc_cache_inodes_a.py', 'reclaim_ehpc_source_inodes_b.py'])
    record = dict(scope='Metadata-only EHPC inode recovery. Removed226 generated pyc and32 empty cache dirs; then4025 manifest-hash-verified inactive source duplicates and106 empty dirs after archive verification and byte-identical local backup. All original trajectories, official outputs, controls, manifests, inputs and shared test dependencies retained. Full duplicate source archive retained for restoration. No scientific computing on login node.',
                  utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  df_i=subprocess.check_output(['df', '-i', str(base)], text=True),
                  df_h=subprocess.check_output(['df', '-h', str(base)], text=True),
                  qstat=subprocess.check_output(['qstat', '-u', 'zhangyq'], text=True))
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for name, path in files:
        tf.add(path, arcname=name, recursive=False)
    tf.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
    raw = (json.dumps(record, indent=2) + '\n').encode()
    info = tarfile.TarInfo('snapshot.json'); info.size = len(raw)
    tf.addfile(info, io.BytesIO(raw))
print(json.dumps(dict(archive=str(archive), sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), bytes=archive.stat().st_size, snapshot=record)))

from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import tarfile

base = Path('/home/zhangyq/noahmp-v1').resolve()
scratch = Path('/var/tmp/zhangyq-noahmp-inode-20261019-a')
assert scratch.is_dir() and not scratch.is_symlink() and scratch.stat().st_uid == os.getuid()
report = scratch / 'source-inventory-b.json'
archive = scratch / 'inactive-source-duplicates-b.tar.gz'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
names = ['p6-validation-source-d', 'p6-phase-jacobian-gpu-b', 'p6-surface-secant-e',
         'p6-snow-branch-numpy-a', 'p6-snow-branch-numpy-b', 'p6-heat-coordinate-d',
         'p6-heat-phase-event-a', 'p6-mixed-phase-feedback-c', 'p6-spinup-assessment-c']

def checked(path):
    assert path.resolve().is_relative_to(base) and not path.is_symlink()
    assert all(not p.is_symlink() for p in path.parents if p.is_relative_to(base))
    return path

if sys.argv[1] == 'inventory':
    assert not report.exists() and not archive.exists()
    qstat = subprocess.check_output(['qstat', '-u', 'zhangyq'], text=True)
    rows = []
    manifests = []
    for name in names:
        root = checked(base / name)
        manifest = checked(root / 'SOURCE_SHA256.json')
        if not manifest.is_file():
            continue
        manifests.append(dict(path=str(manifest), sha256=sha(manifest.read_bytes())))
        for relative, expected in json.loads(manifest.read_text()).items():
            rel = Path(relative)
            assert not rel.is_absolute() and '..' not in rel.parts
            if rel.parts[0] not in {'src', 'tests', 'benchmarks', 'examples'}:
                continue
            path = checked(root / rel)
            if not path.exists():
                continue
            assert path.is_file() and sha(path.read_bytes()) == expected, path
            stat = path.stat()
            rows.append(dict(path=str(path), archive_path=str(path.relative_to(base)),
                             sha256=expected, bytes=stat.st_size, mtime_ns=stat.st_mtime_ns))
    assert rows
    with tarfile.open(archive, 'w:gz') as tf:
        for row in rows:
            tf.add(row['path'], arcname=row['archive_path'], recursive=False)
        for row in manifests:
            tf.add(row['path'], arcname=str(Path(row['path']).relative_to(base)), recursive=False)
    with tarfile.open(archive) as tf:
        for row in rows:
            assert sha(tf.extractfile(row['archive_path']).read()) == row['sha256']
    record = dict(scope='Reclaim only manifest-verified inactive extracted source duplicates after archive hash verification and a local backup. Original results, input/forcing, official outputs, trajectories, controls, manifests and shared dependencies remain. Active PBS295 uses a different compute-local source.',
                  utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), base=str(base),
                  qstat=qstat, archive=str(archive), archive_sha256=sha(archive.read_bytes()),
                  manifests=manifests, files=rows)
    report.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(files=len(rows), bytes=sum(r['bytes'] for r in rows),
                          archive_sha256=record['archive_sha256'], report_sha256=sha(report.read_bytes()))))
elif sys.argv[1] == 'clean':
    assert sha(report.read_bytes()) == sys.argv[2]
    record = json.loads(report.read_text())
    assert sha(archive.read_bytes()) == record['archive_sha256'] == sys.argv[3]
    removed = []
    with tarfile.open(archive) as tf:
        for row in record['files']:
            path = checked(Path(row['path']))
            assert path.is_file()
            stat = path.stat()
            assert (stat.st_size, stat.st_mtime_ns) == (row['bytes'], row['mtime_ns'])
            assert sha(path.read_bytes()) == row['sha256'] == sha(tf.extractfile(row['archive_path']).read())
        for row in record['files']:
            path = checked(Path(row['path']))
            path.unlink()
            removed.append(str(path))
    empty = []
    for name in names:
        root = checked(base / name)
        for source_dir in ['src', 'tests', 'benchmarks', 'examples']:
            folder = root / source_dir
            if not folder.is_dir():
                continue
            for current, dirs, files in os.walk(folder, topdown=False, followlinks=False):
                path = checked(Path(current))
                if not any(path.iterdir()):
                    path.rmdir()
                    empty.append(str(path))
    result = dict(scope=record['scope'], utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  inventory_sha256=sys.argv[2], backup_archive_sha256=sys.argv[3],
                  removed_files=removed, removed_empty_directories=empty,
                  df_i=subprocess.check_output(['df', '-i', str(base)], text=True))
    receipt = scratch / 'source-cleaned-b.json'
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(removed_files=len(removed), removed_empty_directories=len(empty), df_i=result['df_i'])))
else:
    raise ValueError(sys.argv)

from pathlib import Path
import datetime, hashlib, io, json, subprocess, tarfile

b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-stem-device-day-a'
launch=json.loads((r/'worker.json').read_text());pid=launch['pid'];proc=Path('/proc')/str(pid)
assert (proc/'cmdline').exists() and b'run_qia_stem_device_day_a.py' in (proc/'cmdline').read_bytes()
elapsed=int(subprocess.check_output(['ps','-p',str(pid),'-o','etimes='],text=True).strip())
assert elapsed>=1800,elapsed
assert not (r/'exit.json').exists()
raw=(r/'trajectory/batch.json').read_bytes();d=json.loads(raw)
value=dict(scope='Read-only actual Qia CUDA32/JAX32 worker observation after30min; committed checkpoint is not an iteration counter or proof of a stall. Preserve original live process/source/inputs/gates and continue official CTSM work. No restart,device reset or other-user process action.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),worker=launch,elapsed_seconds=elapsed,ps=subprocess.check_output(['ps','-p',str(pid),'-o','pid,ppid,stat,etime,pcpu,wchan:32,args'],text=True),committed_report=d)
a=b/'qia-stem-device-wait-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [Path(__file__),r/'worker.json',r/'launch.json',r/'protocol.json',b/'run_qia_stem_device_day_a.py',b/'control_qia_stem_device_day_a.py',b/'launch_qia_stem_device_day_a.py']:
  t.add(p,arcname=p.name,recursive=False)
 for name,data in [('observation.json',(json.dumps(value,indent=2)+'\n').encode()),('captured-batch.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),elapsed_seconds=elapsed,ps=value['ps'])))

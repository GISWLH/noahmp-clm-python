from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-official-tenday-ad';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();roots={}
for label,name,expected in [('source','clm-numerical-recovery-c-source.tar.gz','61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'),('gpu','qia-gpu-year-snapshot-aa-evidence.tar.gz','0a0597497ce8bf3925bdcef4d7f45467d35723cc280e99f08962cc48e2a4927d')]:
    a=b/name;assert sha(a)==expected;p=Path(os.environ['TMPDIR'])/label;p.mkdir();roots[label]=p
    with tarfile.open(a) as tf:tf.extractall(p,filter='data')
s=roots['source'];m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from noahmp_clm.validation import compare_series
prereq=b/'qia-tenday-comparison-ab';d=json.loads((prereq/'receipt.json').read_text());assert (prereq/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and d['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
official=b/'ctsm-qia-run-r';audit=json.loads((official/'year-boundary.json').read_text());assert (official/'pbs-exit.txt').read_text().strip()=='0' and sha(official/'official-year-fields.npz')==audit['fields_sha256']
with np.load(official/'official-year-fields.npz',allow_pickle=False) as z:ref=dict(z)
n=480;assert ref['time_bounds_seconds'].shape==(17520,2) and np.array_equal(ref['time_bounds_seconds'][:n],np.arange(n)[:,None]*1800+[[0,1800]])
original=json.loads((b/'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json').read_text());dz=np.asarray(original['column']['dz'],float);te=np.r_[0.,np.cumsum(dz)];se=np.r_[0.,np.cumsum(np.asarray(ref['DZSOI'],float).reshape(15))];overlap=np.maximum(0.,np.minimum(te[1:,None],se[None,1:])-np.maximum(te[:-1,None],se[None,:-1]))/dz[:,None];assert np.max(abs(overlap.sum(1)-1.))<1e-14 and np.all(overlap[:,10:]==0.)
np.savez_compressed(r/'reference-first480.npz',**{k:(v[:n] if np.asarray(v).ndim and len(v)==17520 else v) for k,v in ref.items()});(r/'reference-year-boundary.json').write_bytes((official/'year-boundary.json').read_bytes())
cases={}
for label in ['capacity','capacity_optics']:
    folder=roots['gpu']/('qia-richards-'+label+'-cuda-year-c')/'trajectory';report,saved,rows=native.read_generation(folder);assert len(rows)==1 and report['identity']['source_sha256']==native.source_hashes() and report['status']=='running' and report['steps_completed']==480 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None
    case_report,model=rows[0];assert case_report['forcing_npz_sha256']=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960' and case_report['configuration']['column']['dz']==original['column']['dz']
    assert str(model['time_start'][0])=='200301010000' and str(model['time_end'][-1])=='200301110000'
    series={}
    for name,source,factor,unit in [('h_wm2','FSH',1.,'h_wm2'),('le_wm2','EFLX_LH_TOT',1.,'le_wm2'),('et_mm','QFLX_EVAP_TOT',86400.,'et_mm_day'),('runoff_mm','QRUNOFF',86400.,'runoff_mm_day'),('gpp_gc_m2','FPSN',12.0107e-6*86400.,'gpp_gc_day'),('swe_m','H2OSNO',.001,'swe_m')]:
        actual=np.asarray(model[name],float).reshape(n)*(48. if name in ['et_mm','runoff_mm','gpp_gc_m2'] else 1.);expected=np.asarray(ref[source][:n],float).reshape(n)*factor;series[name]=(actual,expected,unit)
    soil_t=np.asarray(ref['TSOI'][:n],float).reshape(n,15)@overlap.T;soil_w=np.asarray(ref['H2OSOI'][:n],float).reshape(n,10)@overlap[:,:10].T
    for name,expected,unit,offset in [('tsoil_k',soil_t,'tsoil_c',273.15),('smc_m3m3',soil_w,'smc',0.)]:
        for layer in range(4):series[name+'/'+str(layer)]=(model[name][:,layer]-offset,expected[:,layer]-offset,unit)
    assert len(series)==14;periods={'whole_fixed_tenday':slice(0,n)};periods.update({str(model['time_start'][k*48])[:8]:slice(k*48,(k+1)*48) for k in range(10)})
    metrics={name:{key:compare_series(a[q],c[q],unit,weights=np.full(len(a[q]),1800.)) for key,(a,c,unit) in series.items()} for name,q in periods.items()}
    cases[label]=dict(status='Originalcold first480/10day scientific diagnostic; not completeyear or spinup',configuration=case_report['configuration'],metrics=metrics,model_trace_sha256=case_report['model_npz_sha256'],case_report_sha256=report['case_reports'][case_report['case']]['sha256'],checkpoint_sha256=report['checkpoint_sha256'],original_maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],same_precision_max_absolute=None,nee_reference_status='unmeasured: officialSP output has no matching NEE reference')
record=dict(diagnosis_complete=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,reference_full_fields_sha256=audit['fields_sha256'],reference_audit_sha256=sha(official/'year-boundary.json'),reference_subset_sha256=sha(r/'reference-first480.npz'),soil_overlap_weights=overlap.tolist(),cases=cases,scope='Both prospective variants actualcurrentCUDA563C fixedoriginalcold first480/10days vs officialCTSM-R sameforcing, all14 whole/daily metrics retained using original10percent/r/nearzeroabsolute validation and layeroverlap. NumPy engineering prereqEHPC360actual0. NEE officialSP unmeasured. Coldstate/soil/PFT/SP-CN/root/physics/initialmemory differences remain; not parameter selection/default/calibration, full17520, spinup, multisite/multiyear or fullscience acceptance. A successful diagnostic exit says allrequestedmetrics were computed, not allscientificmetrics passed.')
(r/'comparison.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(diagnosis_complete=True,source_unchanged=record['source_unchanged'],pbs_job=record['pbs_job'],seconds=record['seconds'],cases={label:row['metrics']['whole_fixed_tenday'] for label,row in cases.items()}),allow_nan=False),flush=True);assert record['source_unchanged']

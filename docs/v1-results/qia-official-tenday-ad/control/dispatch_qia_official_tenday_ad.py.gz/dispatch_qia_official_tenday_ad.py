from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-official-tenday-ad';assert not r.exists();r.mkdir();controls={}
for n in ['compare_qia_official_tenday_ad.py','qia_official_tenday_ad.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'qia_official_tenday_ad.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

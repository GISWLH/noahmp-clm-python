from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-f';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'summary.json').read_text());assert d['status']=='complete' and d['collected_nodes']==3 and d['source_unchanged'] and len(d['results'])==1;row=d['results'][0];v=row['receipt'];assert row['returncode']==v['worker_exitcode']==v['pytest_returncode']==0 and v['passed'] and v['counts']==dict(tests=3,failures=0,errors=0,skipped=0);assert all(x['status']=='complete' for x in v['device_barriers']);a=b/'stem-split-regression-f-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname=p.name,recursive=False)
 for n in ['SOURCE_SHA256.json','tests/test_gpu_stem_column_precision.py','tests/fixtures/stem_station_second_step.npz']:t.add(s/n,arcname='source/'+n,recursive=False)
 for n in ['p6-stem-split-f-package.json','launch_stem_split_target_f.py','run_stem_split_target_f.py','archive_stem_split_regression_f.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,counts=v['counts'],seconds=d['seconds'])))

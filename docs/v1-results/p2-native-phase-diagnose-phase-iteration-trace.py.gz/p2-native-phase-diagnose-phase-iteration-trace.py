import numpy as np,jax,jax.numpy as j,cupy as cp
from check_canopy_phase_gpu import packed,cases,random_cases
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase,phase_energy_kernel_jax
from noahmp_clm.gpu.cuda.canopy_phase_energy import _kernel
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as rk
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.snicar import _jax_tables
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
indices=[41,48,56,58,67,68];raw=[*cases(),*random_cases(60)];arrays=packed([pack_canopy_phase(a,sw,lw,e,c,1800.,dtype=np.float32,**kw) for _,a,sw,lw,e,c,kw in [raw[i] for i in indices]],np.float32)
jp=j.asarray(pack_leaf_parameters(dtype=np.float32));tabs=_jax_tables('float32')
@jax.jit
def jrun(arrays,limit):
 return jax.vmap(lambda *row:phase_energy_kernel_jax(*row,jp,*tabs,max_iterations=limit))(*arrays)
ja_arrays=tuple(map(j.asarray,arrays));a,u,f,soil,stem,c,b,snow,n=[cp.asarray(x) for x in arrays];area=cp.ascontiguousarray(a+stem);ru=cp.ascontiguousarray(radiation_inputs(area,u,cp));rad=cp.empty((len(a),584),cp.float32);rk(True)((1,),(32,),(area,snow,n,ru,*_tables(),rad,np.int32(len(a))))
out=cp.empty((len(a),298),cp.float32);params=cp.asarray(pack_leaf_parameters(dtype=np.float32));records={}
for limit in range(8):
 ja=np.asarray(jrun(ja_arrays,j.asarray(limit,j.int32)));_kernel()((1,),(32,),(a,u,f,soil,stem,c,b,rad,params,out,np.int32(len(a)),np.int32(limit),np.float32(.005)));cu=cp.asnumpy(out)
 records[f'jax_{limit}']=ja;records[f'cuda_{limit}']=cu
 for i,original in enumerate(indices):
  idx=np.where(ja[i,275:285]!=cu[i,275:285])[0]
  print('iteration',limit,'row',original,'coordinate errors',[(int(k),float(ja[i,275+k]),float(cu[i,275+k])) for k in idx], 'q',float(ja[i,12]-cu[i,12]),'max output',float(np.max(abs(ja[i]-cu[i]))),flush=True)
np.savez('phase-iteration-trace.npz',**records)

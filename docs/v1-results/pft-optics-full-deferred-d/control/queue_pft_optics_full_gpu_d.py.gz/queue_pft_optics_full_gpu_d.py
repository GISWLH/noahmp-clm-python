from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';r=s/'full-bgc-wait-d';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items())
controls={n:sha(b/n) for n in ['wait_pft_optics_full_gpu_d.py','queue_pft_optics_full_gpu_d.py','launch_pft_optics_full_gpu_d.py','control_pft_optics_full_gpu_d.py']}
record=dict(scope='Queue B original full3 only after actual A full3 controller exit and B targets20 success, then memory guards. No model killed/source mutated; queue is not execution or acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_archive_sha256='b4f6a97821e6eadc266541139142572b7abf102bea621a278f11860ff5a61004',controls_sha256=controls,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'))
(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'wait_pft_optics_full_gpu_d.py')],cwd=s,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record['pid']=p.pid;(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';r=s/'full-controller-e';old=s/'full-controller-d';assert not r.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());original=json.loads((old/'launch.json').read_text());assert original['pid']==3582193
assert original['cpu_archive_sha256']==sha(b/'pft-optics-cpu-final-d-evidence.tar.gz')=='b4f6a97821e6eadc266541139142572b7abf102bea621a278f11860ff5a61004' and original['gpu20_archive_sha256']==sha(b/'pft-optics-gpu20-d-evidence.tar.gz')=='335464328ee60f4a79ed172d27c891bac9e5615ae42aa6b7bc1618f808eff493'
for n,h in original['controls_sha256'].items():assert sha(b/n)==h
assert not (old/'worker.json').exists() and not (old/'exit.json').exists() and not (s/'full-by-file-d').exists()
controls={n:sha(b/n) for n in ['launch_pft_canonical_gpu0_e.py','wait_pft_canonical_gpu0_e.py','run_pft_optics_canonical_e.py','collect_pft_optics_canonical_d.py']};r.mkdir();pid=original['pid'];proc=Path('/proc/'+str(pid));assert proc.exists() and proc.stat().st_uid==os.getuid();argv=(proc/'cmdline').read_bytes().split(b'\0');assert str(b/'wait_pft_optics_canonical_d.py').encode() in argv
guard=dict(scope='Only ownidleD waiter superseded to move plannedcanonical onto GPU0 after D BGC3. Older511 actualworker alreadyrunningGPU1 is untouched. No model/pytest worker signaled.',pid=pid,verified_uid=os.getuid(),argv=[v.decode() for v in argv if v],start_ticks=int((proc/'stat').read_text().split()[21]),original_launch_sha256=sha(old/'launch.json'))
stopped=False
try:
    os.kill(pid,signal.SIGSTOP);stopped=True;deadline=time.monotonic()+5
    while (proc/'stat').read_text().split()[2] not in ['T','t']:assert time.monotonic()<deadline;time.sleep(.05)
    children=(proc/'task'/str(pid)/'children').read_text().strip();assert not children and not (old/'worker.json').exists() and not (s/'full-by-file-d').exists(),'Original D already launched; resume and leave model untouched'
    guard.update(children='',worker_absent=True,action='SIGTERM to verified stopped idleD coordinator only');(r/'superseded-idle-d.json').write_text(json.dumps(guard,indent=2)+'\n');os.kill(pid,signal.SIGTERM)
finally:
    if stopped:
        try:os.kill(pid,signal.SIGCONT)
        except ProcessLookupError:pass
deadline=time.monotonic()+10
while proc.exists() and (proc/'stat').read_text().split()[2]!='Z':assert time.monotonic()<deadline;time.sleep(.05)
guard.update(observed_terminal_state='absent' if not proc.exists() else 'Z',actual_returncode='not observable externally; no fabricated parent exit');(r/'superseded-idle-d.json').write_text(json.dumps(guard,indent=2)+'\n')
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
record=dict(scope='ActualcurrentD canonical1291 scheduledGPU0 after D BGC3 actualexit/resourceguard. Original511 onGPU1 left running; only ownidleD queue superseded with ownership/child guards. CPU940/GPU20 exactprereqs, no collection/completion/science claim.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=0,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls,original_plan_sha256=sha(old/'launch.json'),wait_for_actual_exit=str(s/'full-bgc-d/exit.json'))
(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'wait_pft_canonical_gpu0_e.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record['pid']=p.pid;(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(launch=record,guard=guard)))

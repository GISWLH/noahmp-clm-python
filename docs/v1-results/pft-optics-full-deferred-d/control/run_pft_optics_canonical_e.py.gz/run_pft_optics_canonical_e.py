from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'pft-optics-final-d'
r = s / 'full-by-file-d'
r.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
begun = time.monotonic()

def verify():
    assert len(m) == 518 and all(sha(s / n) == v for n, v in m.items())

def nodes(raw):
    result = []
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(k) is None for k in ['failure', 'error', 'skipped'])
        parts = c.attrib['classname'].split('.')
        where = [i for i, n in enumerate(parts) if n.startswith('test_')]
        assert len(where) == 1
        i = where[0]
        result.append('tests/' + parts[i] + '.py::' + '::'.join(parts[i+1:] + [c.attrib['name']]))
    assert len(result) == len(set(result))
    return set(result)

verify()
with (r / 'collection.log').open('x') as log:
    code = subprocess.run([sys.executable, '-u', str(b / 'collect_pft_optics_canonical_d.py')], cwd=s, stdout=log, stderr=subprocess.STDOUT).returncode
assert code == 0
collection = json.loads((r / 'collection.json').read_text())
allnodes = set(collection['nodes'])
assert len(allnodes) == 1291 and collection['source_unchanged'] and collection['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json')
gpu = {n for n in allnodes if Path(n.split('::')[0]).name.startswith(('test_gpu', 'test_jax', 'test_cuda'))}
cpu = allnodes - gpu
assert len(cpu) == 940 and len(gpu) == 351

cpu_path=b/'pft-optics-cpu-final-d-evidence.tar.gz'
assert sha(cpu_path)=='b4f6a97821e6eadc266541139142572b7abf102bea621a278f11860ff5a61004'
with tarfile.open(cpu_path) as t:a={v.name:t.extractfile(v).read() for v in t if v.isfile()}
assert json.loads(a['SOURCE_SHA256.json'])==m
cpu_receipt=json.loads(a['receipt.json'])
assert a['pbs-exit.txt'].strip()==b'0' and cpu_receipt['returncode']==0 and cpu_receipt['source_unchanged'] and cpu_receipt['counts']==dict(tests=940,failures=0,errors=0,skipped=0)
assert nodes(a['cpu-full.xml'])==cpu and hashlib.sha256(a['cpu-full.xml']).hexdigest()==cpu_receipt['xml_sha256']
launch=json.loads((s/'full-controller-d/launch.json').read_text())
gpu_path=b/'pft-optics-gpu20-d-evidence.tar.gz';assert sha(gpu_path)==launch['gpu20_archive_sha256']
with tarfile.open(gpu_path) as t:g={v.name:t.extractfile(v).read() for v in t if v.isfile()}
assert json.loads(g['SOURCE_SHA256.json'])==m and json.loads(g['targets-d/exit.json'])['passed']
prefix=set()
def verify_prefix(file,raw_receipt,raw_exit,raw_xml):
    rec=json.loads(raw_receipt);ex=json.loads(raw_exit);found=nodes(raw_xml)
    expected={n for n in gpu if n.split('::')[0]==file}
    assert found==expected and ex['passed'] and ex['returncode']==rec['worker_exitcode']==rec['pytest_returncode']==0
    assert hashlib.sha256(raw_receipt).hexdigest()==ex['receipt_sha256'] and hashlib.sha256(raw_xml).hexdigest()==rec['xml_sha256']
    assert rec['passed'] and rec['source_unchanged'] and rec['node_coverage_exact'] and rec['all_setup_call_teardown_phases_passed'] and rec['counts']==dict(tests=len(expected),failures=0,errors=0,skipped=0)
    assert rec['test_sha256']==m[file] and rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
    assert prefix.isdisjoint(found);prefix.update(found)
for name in ['test_gpu_canopy_optics','test_gpu_canopy_snow_radiation','test_gpu_canopy_phase_energy']:
    path='targets-d/'+name+'/'
    verify_prefix('tests/'+name+'.py',g[path+'receipt.json'],g[path+'exit.json'],g[path+'targets.xml'])
assert len(prefix)==20
bgc=s/'full-bgc-d'
bgc_exit=json.loads((bgc/'exit.json').read_text())
if bgc_exit['passed']:
    verify_prefix('tests/test_gpu_clm_optics_column.py',(bgc/'receipt.json').read_bytes(),(bgc/'exit.json').read_bytes(),(bgc/'targets.xml').read_bytes())
covered = cpu | prefix
worker = b / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
assert sha(worker) == '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
pending = sorted({n.split('::')[0] for n in gpu} - {n.split('::')[0] for n in prefix}, key=lambda n: ('_column' in n or 'surface' in n, n))
scope = 'Frozen518D actualcanonical1291: same-sourceEHPC940 and actualGPU20 plusoriginalBGC3 ifpassed; everyremainingnode executed onxuanze GPU0 after actualBGC exit;olderGPU1 workers left running. No A/oldsource credit,allraw1e-6/ints/phases/barriers/hardbudgets retained. Not climateyear/science/release acceptance.'
(r / 'selection.json').write_text(json.dumps(dict(scope=scope, collected_nodes=sorted(allnodes), cpu_nodes=940, gpu_nodes=351, same_source_gpu_prefix_nodes=sorted(prefix), pending_files=pending, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json')), indent=2) + '\n')
results = []

def save(active=None):
    d = dict(scope=scope, status='running', covered_nodes=len(covered), covered_gpu_nodes=len(covered) - 940, collected_nodes=1291, active=active, results=results, seconds=time.monotonic() - begun)
    tmp = r / 'progress.json.tmp'
    tmp.write_text(json.dumps(d, indent=2) + '\n')
    os.replace(tmp, r / 'progress.json')

save()
for file in pending:
    verify()
    name = Path(file).stem
    expected = {n for n in gpu if n.split('::')[0] == file}
    expected_path = r / (name + '-expected.json')
    expected_path.write_text(json.dumps(sorted(Path(n.split('::')[0]).name + '::' + n.split('::', 1)[1] for n in expected), indent=2) + '\n')
    receipt_path, xml = r / (name + '-receipt.json'), r / (name + '.xml')
    start = time.monotonic()
    with (r / (name + '.log')).open('x') as log:
        p = subprocess.Popen([sys.executable, '-u', str(worker), '--source', str(s), '--test-file', str(s / file), '--expected', str(expected_path), '--receipt', str(receipt_path), '--xml', str(xml)], cwd=s, stdout=log, stderr=subprocess.STDOUT)
        save(dict(file=file, pid=p.pid))
        code = p.wait()
    row = dict(file=file, pid=p.pid, returncode=code, seconds=time.monotonic() - start, passed=False)
    if receipt_path.exists():
        rec = json.loads(receipt_path.read_text())
        row['receipt'] = rec
        if code == rec['worker_exitcode'] == rec['pytest_returncode'] == 0 and rec['passed'] and rec['source_unchanged'] and rec['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and rec['test_sha256'] == m[file] and rec['xml_sha256'] == sha(xml) and nodes(xml.read_bytes()) == expected:
            row['passed'] = True
            covered.update(expected)
    results.append(row)
    save()
    print(json.dumps({k: v for k, v in row.items() if k != 'receipt'}), flush=True)
verify()
complete = covered == allnodes and all(x['passed'] for x in results)
(r / 'summary.json').write_text(json.dumps(dict(scope=scope, status='complete' if complete else 'failed', source_unchanged=True, collected_nodes=1291, covered_nodes=len(covered), all_node_coverage_exact=covered == allnodes, results=results, same_source_gpu_prefix_nodes=sorted(prefix), seconds=time.monotonic() - begun), indent=2) + '\n')
raise SystemExit(0 if complete else 1)

from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';r=s/'full-bgc-wait-d';launch=json.loads((r/'launch.json').read_text());old=b/'pft-optics-final-a/full-bgc-a/exit.json';prefix=s/'targets-d/exit.json'
while not old.exists() or not prefix.exists():
    if not old.exists():assert Path('/proc/3489760').exists(),'Original A controller missing without actual exit'
    time.sleep(15)
assert json.loads(prefix.read_text())['passed']
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines())
    if free>6144 and int(mem['MemAvailable'].split()[0])>12*1024*1024:break
    time.sleep(15)
for n,h in launch['controls_sha256'].items():assert hashlib.sha256((b/n).read_bytes()).hexdigest()==h
with (r/'dispatch.log').open('x') as f:p=subprocess.run([sys.executable,'-u',str(b/'launch_pft_optics_full_gpu_d.py'),launch['cpu_archive_sha256']],stdout=f,stderr=subprocess.STDOUT)
(r/'dispatch-exit.json').write_text(json.dumps(dict(returncode=p.returncode,scope='Actual launch command exit only; full3 worker execution has its own full-bgc-d/exit.json. No A process signaled.'),indent=2)+'\n');raise SystemExit(p.returncode)

from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';r=s/'full-controller-e';launch=json.loads((r/'launch.json').read_text());bgc=s/'full-bgc-d/exit.json'
while not bgc.exists():time.sleep(15)
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines())
    if free>6144 and int(mem['MemAvailable'].split()[0])>12*1024*1024:break
    time.sleep(15)
for n,h in launch['controls_sha256'].items():assert hashlib.sha256((b/n).read_bytes()).hexdigest()==h
with (r/'full.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'run_pft_optics_canonical_e.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=0,free_memory_mib=free,bgc_actual_exit=json.loads(bgc.read_text()),scope='Current518D exact940CPU/20GPU plusBGC3ifpassed,alluncoverednodes actual execution; olderGPU1 model not signaled.'),indent=2)+'\n')
code=p.wait();(r/'exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(code)

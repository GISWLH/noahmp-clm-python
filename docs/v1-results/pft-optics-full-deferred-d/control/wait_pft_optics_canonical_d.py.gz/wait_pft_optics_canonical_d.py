from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'pft-optics-final-d'
r = s / 'full-controller-d'
launch = json.loads((r / 'launch.json').read_text())
old = Path(launch['wait_for_actual_exit'])
old_pid = launch['wait_for_original_pid']
missing = None
while not old.exists():
    if not Path('/proc/' + str(old_pid)).exists():
        if missing is None:
            missing = time.monotonic()
        if time.monotonic() - missing > 120:
            raise RuntimeError('Original predecessor missing without actual parent exit receipt; current GPU worker not launched')
    else:
        missing = None
    time.sleep(30)
previous = json.loads(old.read_text())

bgc=s/'full-bgc-d/exit.json'
while not bgc.exists():
    dispatch=s/'full-bgc-wait-d/dispatch-exit.json'
    if dispatch.exists():assert json.loads(dispatch.read_text())['returncode']==0,'BGC3 launch failed; canonical worker not started'
    time.sleep(30)

while True:
    free = int(subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
    if free > 2048:
        break
    time.sleep(30)
for name, digest in launch['controls_sha256'].items():
    assert hashlib.sha256((b / name).read_bytes()).hexdigest() == digest
with (r / 'full.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'run_pft_optics_canonical_d.py')], cwd=s, stdout=log, stderr=subprocess.STDOUT)
(r / 'worker.json').write_text(json.dumps(dict(pid=p.pid, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), original_actual_exit=previous, device=1, free_memory_mib=free, scope='Current source exact940CPU+20GPU verified before all uncovered GPU nodes; actual collection and phases/exits still required,not science acceptance.'), indent=2) + '\n')
code = p.wait()
(r / 'exit.json').write_text(json.dumps(dict(returncode=code, utc=datetime.datetime.now(datetime.timezone.utc).isoformat()), indent=2) + '\n')
raise SystemExit(code)

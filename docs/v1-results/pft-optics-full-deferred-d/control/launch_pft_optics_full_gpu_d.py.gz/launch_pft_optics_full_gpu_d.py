from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';r=s/'full-bgc-d';assert not r.exists();digest=sys.argv[1];assert len(digest)==64;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==518 and all(sha(s/n)==h for n,h in m.items())
a=b/'pft-optics-cpu-final-d-evidence.tar.gz';assert sha(a)==digest
with tarfile.open(a) as t:
    assert json.loads(t.extractfile('SOURCE_SHA256.json').read())==m;cpu=json.loads(t.extractfile('receipt.json').read());assert cpu['returncode']==0 and cpu['counts']==dict(tests=940,failures=0,errors=0,skipped=0) and cpu['source_unchanged']
prefix=json.loads((s/'targets-d/exit.json').read_text());assert prefix['passed'] and prefix['source_unchanged'] and len(prefix['results'])==3 and all(v['passed'] and v['returncode']==0 for v in prefix['results'])
collection=json.loads((s/'targets-d/collection.json').read_text());expected=collection['groups']['test_gpu_clm_optics_column.py'];assert len(expected)==3
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>6144
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());assert int(mem['MemAvailable'].split()[0])>12*1024*1024
r.mkdir();(r/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',NOAHMP_PFT_DIAGNOSTICS=str(r/'diagnostics'))
controls={n:sha(b/n) for n in ['launch_pft_optics_full_gpu_d.py','control_pft_optics_full_gpu_d.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_pft_optics_full_gpu_d.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='Actualsame-source518 CPU940+GPUcomponent5/legacy15 verified before fullstructuredBGC/MOST3 two-step/reference/raw1e-6/int-exact validation. Existingyears/oldGPUfull notstopped. Notcomplete351/1291/year/science.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_memory_mib=free,cpu_evidence_sha256=sha(a),prefix_exit_sha256=sha(s/'targets-d/exit.json'),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls)
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

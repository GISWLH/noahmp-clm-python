from pathlib import Path
import datetime,hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';r=s/'full-controller-d';launch=json.loads((r/'launch.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());a=b/'pft-optics-full-deferred-d-evidence.tar.gz';assert not a.exists();names=['full-controller-d','full-bgc-wait-d']
if (s/'full-bgc-d').exists():names.append('full-bgc-d')
if (s/'full-controller-e').exists():names.append('full-controller-e')
record=dict(scope='Actual frozen518D deferred canonical1291 and BGC3 scheduling/source/control/guard metadata. Originalold506 model untouched; onlyverifiedownedidle511 coordinator maybesuperseded per savedguard. Running/queued not executioncompletion/science acceptance. A3 separate actual0 not creditedD.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),canonical_launched=(r/'worker.json').exists(),canonical_exit=(r/'exit.json').exists(),bgc_launched=(s/'full-bgc-d/worker.json').exists(),bgc_exit=(s/'full-bgc-d/exit.json').exists())
with tarfile.open(a,'w:gz') as t:
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    for name in names:
        for p in sorted((s/name).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
    for n in ['collect_pft_optics_canonical_d.py','run_pft_optics_canonical_d.py','wait_pft_optics_canonical_d.py','launch_pft_optics_canonical_d.py','wait_pft_optics_full_gpu_d.py','queue_pft_optics_full_gpu_d.py','launch_pft_optics_full_gpu_d.py','control_pft_optics_full_gpu_d.py','archive_pft_deferred_d.py']:t.add(b/n,arcname='control/'+n,recursive=False)
    for n in ['launch_pft_canonical_gpu0_e.py','wait_pft_canonical_gpu0_e.py','run_pft_optics_canonical_e.py']:
        t.add(b/n,arcname='control/'+n,recursive=False)
    old=b/'p6-phase-final-check-a/full-by-file-a/progress.json'
    if old.exists():t.add(old,arcname='original506-progress.json',recursive=False)
    raw=(json.dumps(record,indent=2)+'\n').encode();i=tarfile.TarInfo('snapshot.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,snapshot=record)))

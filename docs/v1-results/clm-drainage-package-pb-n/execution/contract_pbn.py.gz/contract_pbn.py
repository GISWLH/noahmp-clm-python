"""Small stdlib serialization helpers; no physical calculation."""
from pathlib import Path
import hashlib
import json


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

"""Compute-node-only exact NumPy32 replay of sealed 1665 inputs."""
import os
import socket
assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')

from pathlib import Path
import importlib
import json
import sys
import time
import traceback
import numpy as np
from arrays_pbn import descriptor, freeze, read_arrays, run_one
from contract_pbn import sha, save


def main():
    root = Path(sys.argv[1]).resolve()
    source = root / 'source'
    gold = root / 'sealed-gold/gold'
    output = root / 'parity'
    output.mkdir()
    source_index = json.loads((source / 'SOURCE_SHA256.json').read_bytes())
    module_names = ['noahmp_clm.gpu.' + n for n in (
        'clm_drainage_primitives', 'clm_perched_drainage_primitives',
        'clm_drainage_adaptive', 'clm_perched_drainage_adaptive', '_clm_drainage_numpy32_phase')]
    module_names += ['noahmp_clm.physics.clm_saturated_drainage']
    module_paths = {}
    for name in module_names:
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(source / 'src')
        relative = path.relative_to(source).as_posix()
        assert sha(path.read_bytes()) == source_index[relative]
        module_paths[name] = dict(path=str(path), source_relative_path=relative, sha256=source_index[relative])
    save(output / 'module-paths.json', module_paths)
    recipes = json.loads((gold / 'case-recipes.json').read_bytes())
    assert len(recipes) == 20 and sum(r['full'] for r in recipes) == 17
    records = []
    started = time.monotonic()
    summary = dict(passed=False, records=records, actual_trial_calls=0, actual_full_calls=0,
        actual_inverse_calls=0, completed_cases=0, numeric_fields_compared=0,
        GPU_calls=0, JAX_calls=0, float64_component_calls=0, coupled_column_runs=0)
    try:
        for row in recipes:
            name = row['name']
            target = output / name
            target.mkdir()
            inputs = read_arrays(gold / name / 'input32.npz')
            expected = read_arrays(gold / name / 'numpy32.npz')
            assert all(inputs[n].dtype == np.dtype('float32') for n in ('cells', 'parameters', 'interval'))
            input_before = {k: descriptor(v) for k, v in inputs.items()}
            observed = {}
            record = dict(case=name, passed=False, observed=observed)
            records.append(record)
            try:
                values, metadata = run_one(inputs, row, 'numpy', reference64=False, observed=observed)
                freeze(target / 'actual32.npz', values)
                save(target / 'run.json', metadata)
                assert {k: descriptor(v) for k, v in inputs.items()} == input_before
                assert set(values) == set(expected), name
                comparison = {}
                for key in values:
                    a, b = np.asarray(values[key]), expected[key]
                    item = dict(actual=descriptor(a), expected=descriptor(b),
                        dtype_equal=a.dtype == b.dtype, shape_equal=a.shape == b.shape,
                        bytes_equal=a.tobytes(order='C') == b.tobytes(order='C'))
                    item['passed'] = item['dtype_equal'] and item['shape_equal'] and item['bytes_equal']
                    comparison[key] = item
                save(target / 'all-numeric-byte-comparison.json', comparison)
                assert all(v['passed'] for v in comparison.values()), name
                original_run = json.loads((gold / name / 'numpy32-run.json').read_bytes())
                for key in ('actual_trial_calls', 'actual_full_calls', 'trial_attempted', 'full_attempted',
                            'phase', 'returned_nonnumeric', 'hard_ledgers', 'transferred_inputs_byteexact'):
                    assert metadata[key] == original_run[key], (name, key)
                record.update(passed=True, numeric_fields=len(comparison), input_arrays_unchanged=True,
                    all_numeric_dtype_shape_bytes_equal=True, original_nonnumeric_and_hard_audits_equal=True,
                    hard_ledgers=metadata['hard_ledgers'], seconds=metadata['seconds'])
            finally:
                save(target / 'observed-calls.json', observed)
                summary.update(actual_trial_calls=sum(r['observed'].get('actual_trial_calls', 0) for r in records),
                    actual_full_calls=sum(r['observed'].get('actual_full_calls', 0) for r in records),
                    actual_inverse_calls=sum(r['observed'].get('phase', {}).get('actual_inverse_calls', 0) for r in records),
                    completed_cases=sum(r['passed'] for r in records),
                    numeric_fields_compared=sum(r.get('numeric_fields', 0) for r in records))
                save(output / 'partial-summary.json', summary)
            print('PB_N_PARITY ' + json.dumps(record, allow_nan=False), flush=True)
        assert summary['actual_trial_calls'] == 20 and summary['actual_full_calls'] == 17
        assert summary['completed_cases'] == 20 and summary['numeric_fields_compared'] == 1106
        summary['passed'] = True
    except Exception:
        summary['error'] = traceback.format_exc()
        (output / 'failure.txt').write_text(summary['error'])
    summary.update(seconds=time.monotonic() - started, precision='float32',
        scope='Exact sealed1665 input32 replay through seven packaged imports/resources. Every returned numeric dtype/shape/byte plus original hard bounds compared. CPU only; no64/JAX/CUDA/coupled/annual validation.')
    save(output / 'summary.json', summary)
    print(json.dumps(summary, allow_nan=False), flush=True)
    return 0 if summary['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

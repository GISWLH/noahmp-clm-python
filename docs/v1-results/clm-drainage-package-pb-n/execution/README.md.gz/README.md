# PB-n CPU package parity

One1CPU/2GB/10min PBS job on compute002, using the existing closeout Python and NumPy2.2.6. Source593 is the already reviewed seven-file import/resource-only candidate. Preparation23 and original345-member1665 gold archive are verified before and after. No adapter, connection, guard or production edit.

The copied original PO encoder has only qualified imports, observer module path, and an explicit NumPy32-only guard/dead64-branch restriction. encoder.patch and ENCODER_ADAPTATION.json preserve every change; original_arrays_po.py is byte exact. The package IntegrationControls is constructed from the original recipe dictionary. All original numerical encoding and64eps hard accounts are retained. No fixtures, state arrays, references or64 results are regenerated.

Each of20 actual input32 NPZ files is read with its original descriptor. Run20 direct trials and17 complete components; count returns only after completion, retain partial attempts on failure. Every1106 returned numeric field must have the original dtype/shape/C-order bytes. Record actual import paths under source593, phase converged/dtype, original hard residuals/bounds, nonnumeric metadata, input immutability and before/after hashes. This is packaging parity only: no64/JAX/CUDA/whole column/site/year/scientific acceptance credit.

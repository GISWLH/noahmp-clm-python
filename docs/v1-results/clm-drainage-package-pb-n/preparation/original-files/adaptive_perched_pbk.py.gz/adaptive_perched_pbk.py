"""Separate perched full phase/adaptive loop; immutable I main path retained."""
import math
import drainage_primitives_pbf as primitives
import perched_primitives_pbk as perched
from saturated_drainage_pb import IntegrationControls
from adaptive_main_pbi import _phase, _stocks, _kahan, _backend as _main_backend

def _backend(name):
    xp,_=_main_backend(name)
    run={'numpy':perched.run_numpy_perched,'jax':perched.run_jax_perched,'cuda':perched.run_cuda_perched}[name]
    return xp,run

def advance_perched_band(cells,parameters,freezing_option,duration_seconds,front_m,bottom_m,
                      controls=IntegrationControls(),backend='numpy'):
    """One four-layer column, actual phase inversion after every liquid trial.

    Returns phase-consistent cells, migrated front and cumulative extensive
    ledger. Host control synchronization is deliberate at this isolated stage;
    it is not a fused/performance-qualified native column kernel.
    """
    xp,run=_backend(backend);c=xp.asarray(cells);p=xp.asarray(parameters)
    if c.dtype not in (xp.float32,xp.float64) or p.dtype!=c.dtype:
        raise ValueError('Explicit same-precision float32 or float64 inputs required')
    if backend=='cuda' and c.dtype!=xp.float32:
        raise ValueError('Original CUDA phase supports float32 only; never silently truncate float64')
    low_precision=c.dtype==xp.float32
    if type(freezing_option) is not int or freezing_option not in (1,2):
        raise ValueError('Original integer phase option 1 or 2 required')
    if (isinstance(duration_seconds,bool) or not math.isfinite(duration_seconds) or duration_seconds<=0
            or not isinstance(controls,IntegrationControls)):
        raise ValueError('Positive finite duration and original integration controls required')
    interval=xp.asarray([duration_seconds,front_m,bottom_m],c.dtype)
    primitives.validate(c[None],p[None],interval[None],xp)
    # Explicit quantization belongs to the input contract, not a silent phase cast.
    duration_seconds=float(interval[0]);front_m=float(interval[1]);bottom_m=float(interval[2])
    initial=_phase(c,p,freezing_option,xp,backend)
    # Reject inconsistent explicit input phase rather than silently replacing it.
    scale=64*xp.finfo(c.dtype).eps*xp.maximum(xp.abs(initial[:,:4])+xp.abs(c[:,:4]),1)
    if bool(xp.any(xp.abs(initial[:,:4]-c[:,:4])>scale)):
        raise ValueError('Supplied temperature/phase is inconsistent with original extensive inversion')
    current=initial;front=xp.asarray(front_m,c.dtype);elapsed=0.
    step=min(duration_seconds,controls.maximum_step_seconds)
    mass=xp.zeros(4,c.dtype);heat=xp.zeros(4,c.dtype)
    mc=xp.zeros(4,c.dtype);hc=xp.zeros(4,c.dtype)
    accounts=xp.zeros(3,c.dtype);ac=xp.zeros(3,c.dtype)
    accepted=rejected=0;maximum_ratio=0.

    def trial(state,z,seconds):
        u=xp.stack((xp.asarray(seconds,c.dtype),z,xp.asarray(bottom_m,c.dtype)))
        _,output=run(state[None],p[None],u[None]);one=output[0]
        after=_phase(_stocks(state,one[18:22],one[22:26],xp),p,freezing_option,xp,backend)
        return after,one[0],one

    while elapsed<duration_seconds:
        if accepted+rejected>=controls.maximum_attempts:
            raise RuntimeError('Perched drainage adaptive attempt budget exhausted')
        step=min(step,duration_seconds-elapsed)
        if low_precision:
            step=float(xp.asarray(step,c.dtype))
            if step>duration_seconds-elapsed:
                step=float(xp.nextafter(xp.asarray(step,c.dtype),xp.asarray(0.,c.dtype)))
            if step<=0.:raise RuntimeError('No representable positive remaining float32 time step')
        coarse,coarse_front,coarse_ledger=trial(current,front,step)
        if float(coarse_ledger[1])==0.:
            elapsed=duration_seconds;break
        half,half_front,a=trial(current,front,.5*step)
        fine,fine_front,b=trial(half,half_front,.5*step)
        ratios=[]
        for k,offset,tolerance in ((4,10,controls.water_absolute_tolerance_kg_m2),(5,14,controls.energy_absolute_tolerance_j_m2)):
            if low_precision:
                # These are the actual extensive exports used by the canonical
                # state, not stock differences quantized at large background W/H.
                coarse_increment=coarse_ledger[offset:offset+4]
                fine_increment=a[offset:offset+4]+b[offset:offset+4]
                magnitude=xp.maximum(xp.abs(coarse_increment),xp.abs(fine_increment))
                resolution=4*xp.finfo(c.dtype).eps*magnitude
                bound=xp.maximum(tolerance+controls.relative_tendency_tolerance*magnitude,resolution)
                ratios.append(float(xp.max(xp.abs(coarse_increment-fine_increment)/bound)))
            else:
                bound=tolerance+controls.relative_tendency_tolerance*xp.maximum(
                    xp.abs(coarse[:,k]-current[:,k]),xp.abs(fine[:,k]-current[:,k]))
                ratios.append(float(xp.max(xp.abs(coarse[:,k]-fine[:,k])/bound)))
        front_scale=controls.front_absolute_tolerance_m+controls.relative_tendency_tolerance*xp.maximum(
            xp.abs(coarse_front-front),xp.abs(fine_front-front))
        if low_precision:
            # Two independently rounded positions cannot resolve sub-ULP depth
            # differences. This changes only local temporal control, not M/H.
            depth_resolution=2*xp.finfo(c.dtype).eps*xp.maximum(xp.abs(coarse_front),xp.abs(fine_front))
            front_scale=xp.maximum(front_scale,depth_resolution)
        ratios.append(float(xp.abs(coarse_front-fine_front)/front_scale))
        ratios.append(float(xp.max(xp.abs(fine[:,3]-current[:,3])))/controls.maximum_temperature_change_k)
        main_depth=primitives._diagnosis(current,p,xp,lambda x:x)[0]
        sy=primitives._sy(main_depth,p,xp,lambda x:x)
        stored=(1000*sy)*(xp.asarray(bottom_m,c.dtype)-front)
        fraction_scale=controls.maximum_band_storage_fraction*stored+controls.water_absolute_tolerance_kg_m2
        ratios.append(float((a[2]+b[2])/fraction_scale))
        ratio=max(ratios)
        if not math.isfinite(ratio):raise RuntimeError('Nonfinite adaptive error ratio')
        if ratio>1.:
            rejected+=1;step*=max(.1,.8/math.sqrt(ratio))
            if step<1e-8:raise RuntimeError('Perched drainage temporal/thermal substep underflow')
            continue
        for one in (a,b):
            mass,mc=_kahan(mass,mc,one[10:14]);heat,hc=_kahan(heat,hc,one[14:18])
            accounts,ac=_kahan(accounts,ac,xp.stack((one[1],one[3],one[4])))
        canonical=_phase(_stocks(initial,initial[:,4]-mass,initial[:,5]-heat,xp),p,freezing_option,xp,backend)
        for k in (4,5):
            rounding=64*xp.finfo(c.dtype).eps*xp.maximum(xp.sum(xp.abs(canonical[:,k])+xp.abs(fine[:,k])),1)
            if bool(xp.max(xp.abs(canonical[:,k]-fine[:,k]))>rounding):
                raise RuntimeError('Accepted perched trial disagrees with Kahan extensive state')
        current=canonical;front=fine_front;elapsed+=step;accepted+=1;maximum_ratio=max(maximum_ratio,ratio)
        if bool(b[5]) and float(b[2])==0.:
            # Rate-only accounting from a non-mutating frozen trial, no extra phase step.
            u=xp.stack((xp.asarray(duration_seconds-elapsed,c.dtype),front,xp.asarray(bottom_m,c.dtype)))
            if elapsed<duration_seconds:
                _,blocked=run(current[None],p[None],u[None]);unmet=blocked[0,1]
                accounts,ac=_kahan(accounts,ac,xp.stack((unmet,unmet,xp.asarray(0.,c.dtype))))
            elapsed=duration_seconds
        step=min(controls.maximum_step_seconds,step*min(2.,max(.5,.8/math.sqrt(max(ratio,1e-12)))))
    # Extensive final stocks use cumulative outlets once, never repeated subtraction.
    final=_phase(_stocks(initial,initial[:,4]-mass,initial[:,5]-heat,xp),p,freezing_option,xp,backend)
    mr=xp.sum((final[:,4]-initial[:,4])+mass);hr=xp.sum((final[:,5]-initial[:,5])+heat)
    mb=64*xp.finfo(c.dtype).eps*xp.maximum(xp.sum(xp.abs(initial[:,4])+xp.abs(final[:,4])+xp.abs(mass)),1)
    hb=64*xp.finfo(c.dtype).eps*xp.maximum(xp.sum(xp.abs(initial[:,5])+xp.abs(final[:,5])+xp.abs(heat)),1)
    if bool(xp.abs(mr)>mb) or bool(xp.abs(hr)>hb):raise RuntimeError('Adaptive perched hard M/H ledger failed')
    ledger=dict(kind='perched',layer_mass_kg_m2=mass,layer_enthalpy_j_m2=heat,
        drained_kg_m2=xp.sum(mass),drained_enthalpy_j_m2=xp.sum(heat),
        water_residual_kg_m2=mr,energy_residual_j_m2=hr,water_bound_kg_m2=mb,energy_bound_j_m2=hb,
        initial_front_m=front_m,migrated_front_m=front,band_bottom_m=bottom_m,elapsed_seconds=elapsed,
        potential_requested_kg_m2=accounts[0],unavailable_liquid_kg_m2=accounts[1],band_exhaustion_kg_m2=accounts[2],
        accepted_substeps=accepted,rejected_substeps=rejected,maximum_accepted_error_ratio=maximum_ratio,
        quantized_requested_duration_seconds=duration_seconds,clock_residual_seconds=elapsed-duration_seconds,
        backend=backend,precision=str(c.dtype),perched_evolution=True,production_registered=False,
        local_error_basis='actual outlet increments plus front representability' if low_precision else 'original PB-c stock differences',
        float32_physical_accuracy_validated=False)
    return final,front,ledger

# Minimal EHPC NumPy32 parity proposal — not executed

Use1CPU/2GB/10min on compute002 PBS/TMPDIR and the existing closeout Python/test-deps, no installs. Root must review this candidate and plan before a wrapper is submitted. Do not launchGPU or alter1665/1659 or any old source/control/evidence.

Inputs:

- Exact candidate593 archive and manifest in BINDINGS.json; verify every member before and after.
- Actual1665 gold archive drainage-gold-po-b-evidence.tar.gz, SHA6ccfddeff32993f82819c9425774d6b3da7cfbc1e0e17ea14acf24aaa272db51. Verify345 members/inventory, original F0/Stageout0, controls82c291…d40, gold seal and per-payload sidecars before decoding.
- GOLD32_BINDINGS.json binds all20 original input32.npz + numpy32.npz files and sidecars. Recipes supply only which function/control arguments were actually used. Never regenerate arrays from fixture functions; reuse the frozen option/int, interval, cells and parameters exactly, without another quantization.

Proposed small test adapter: copy the original PO numeric-return field encoder/hard-audit code, with explicit package imports replacing old standalone names and the typed-phase observer pointing to noahmp_clm.gpu._clm_drainage_numpy32_phase. Construct IntegrationControls from noahmp_clm.physics.clm_saturated_drainage (same exact class text as PB-c, package identity differs). Restrict execution to dtypefloat32 and reference64=False. The unused64-main branch is not run or relabeled; do not load/call original G as an alleged packaged64 equivalent.

For each of20 records, run one packaged main/perched trial; for the17 full records also run packaged I/K full adaptive with the exact stored interval and controls. This means20 newly observed primitive returns +17 newly observed full integrations if all succeed; internal adaptive trial/phase counts are separately recorded, not multiplied from the recipe. No original fixture/test rerun and no new model/column tendency.

Every frozen numeric return key must be present exactly, including all diagnosis fields/weights, trial data, full state/front, both outlets, all residuals/bounds, quantized clock, accepted/rejected counts and error-ratio diagnostics. Require identical dtype, shape and C-order bytes to original numpy32 output; no rtol escape and no dropping diagnostic fields. Report first mismatch and preserve all partial records. All input payloads remain byteexact after invocation. Non-numeric strings/control metadata are retained and compared separately; wall-clock runtime is freshly measured, not an equality target.

Keep original64eps trial/full hard M/H checks and phase convergence from the sealed numeric helper. Independently audit the stored actual before/after/export values using the original same bound, as PO did. No widened conservation gate. Assert the actual functions and typed-phase module resolve under the extracted candidate593 source, not outputs/sealed standalone modules. Patch transparent observer only to count/inspect original returns, never change physical results. Persist command, full stdout/stderr, per-case return descriptors, mismatch flags, exact module/resource hashes, source/control before-after proof and actual observed counters. Preserve failure as failure.

Only after real PBS F/Stageout and parent exit are known, seal a compact raw result with candidate and gold SHA bindings. A successful result means package-relative imports/resource changes preserve NumPy32 behavior on these20 original cases. It does not confer JAX/CUDA, full native column, annual, official coupled or general state-space acceptance. Original64main gold has G-specific extra fields; do not advertise64 full-tree byte parity in this job.

"""Separate perched array trial; immutable F/I/main dependencies are retained."""
from functools import lru_cache
from pathlib import Path
import numpy as np
from . import clm_drainage_primitives as base

PERCHED_TRIAL_FIELDS=base.TRIAL_FIELDS+('layer_mass[4]','layer_heat[4]',
    'water_after[4]','enthalpy_after[4]','main_depth_for_Sy','specific_yield','first_donor')


def _trial(c,p,u,xp,s):
    e,z,active,sat,ice=base._geometry(c,p,xp,s)
    main=base._level(sat,z,e,active,p[4],p[8],True,xp,s)
    sy=base._sy(main,p,xp,s)
    duration,front,bottom=u
    rate,_,_,fi=base._rate(c,p,e,ice,front,bottom,True,xp,s)
    bi=xp.sum((e[1:]<bottom).astype(xp.int32))
    requested=s(rate*duration);capacity=s(s(1000*sy)*s(bottom-front))
    desired=xp.minimum(requested,capacity);remaining=desired;demands=[]
    for k in range(4):
        eligible=(rate>0)&(k>fi)&(k<=bi)&(remaining>0)
        take=xp.where(eligible,xp.minimum(remaining,xp.maximum(0,s(c[k,0]-p[10]))),0)
        demands.append(take);remaining=s(remaining-take)
    demand=xp.stack(demands)
    heat=s(demand*s(334000+s(4180*s(c[:,3]-273.15))))
    water=s(c[:,4]-demand);enthalpy=s(c[:,5]-heat)
    total=xp.asarray(0.,c.dtype);mr=total;hr=total;wm=total;hm=total
    for k in range(4):
        total=s(total+demand[k]);mr=s(mr+s(s(water[k]-c[k,4])+demand[k]))
        hr=s(hr+s(s(enthalpy[k]-c[k,5])+heat[k]))
        wm=s(wm+s(s(xp.abs(c[k,4])+xp.abs(water[k]))+xp.abs(demand[k])))
        hm=s(hm+s(s(xp.abs(c[k,5])+xp.abs(enthalpy[k]))+xp.abs(heat[k])))
    front=xp.minimum(bottom,s(front+s(total/s(1000*sy))))
    eps=xp.finfo(c.dtype).eps;limited=total<desired
    values=xp.stack((front,requested,total,xp.maximum(0,s(desired-total)),
        xp.maximum(0,s(requested-desired)),limited.astype(c.dtype),mr,hr,
        s(64*eps*xp.maximum(wm,1)),s(64*eps*xp.maximum(hm,1))))
    metadata=xp.stack((main,sy,(fi+1).astype(c.dtype)))
    return xp.concatenate((values,demand,heat,water,enthalpy,metadata))


def run_numpy_perched(cells,pars,interval):
    base.validate(cells,pars,interval,np)
    def checked(value):
        if hasattr(value,'dtype') and value.dtype.kind=='f' and value.dtype!=cells.dtype:
            raise RuntimeError('Perched arithmetic changed explicit dtype')
        return value
    diag=np.stack([base._diagnosis(c,p,np,checked) for c,p in zip(cells,pars)])
    trial=np.stack([_trial(c,p,u,np,checked) for c,p,u in zip(cells,pars,interval)])
    if diag.dtype!=cells.dtype or trial.dtype!=cells.dtype:raise RuntimeError('Perched output dtype changed')
    return base._checked(diag,trial,cells,interval,np)


@lru_cache(maxsize=1)
def _compiled_jax():
    import jax
    import jax.numpy as j
    s=jax.lax.optimization_barrier
    return jax.jit(jax.vmap(lambda c,p,u:(base._diagnosis(c,p,j,s),_trial(c,p,u,j,s))))


def run_jax_perched(cells,pars,interval):
    import jax.numpy as j
    args=tuple(j.asarray(x) for x in (cells,pars,interval));base.validate(*args,j)
    diag,trial=_compiled_jax()(*args)
    if diag.dtype!=args[0].dtype or trial.dtype!=args[0].dtype:raise RuntimeError('Perched JAX dtype changed')
    return base._checked(diag,trial,args[0],args[2],j)


@lru_cache(maxsize=1)
def _compiled_cuda():
    import cupy as cp
    # Original helper text is read unchanged; only the new perched kernel is added.
    code=(Path(__file__).parent / 'cuda' / 'clm_drainage_primitives_kernel.cu').read_text()+(Path(__file__).parent / 'cuda' / 'clm_perched_drainage_kernel.cu').read_text()
    return cp.RawModule(code=code,options=('--std=c++14','--fmad=false','--prec-div=true','--prec-sqrt=true'),
        name_expressions=('perched<float>',))


def run_cuda_perched(cells,pars,interval):
    import cupy as cp
    args=tuple(cp.ascontiguousarray(x) for x in (cells,pars,interval));base.validate(*args,cp)
    if args[0].dtype!=cp.float32:raise ValueError('Original CUDA phase chain requires explicit float32')
    n=len(args[0]);diag=cp.empty((n,29),cp.float32);trial=cp.empty((n,29),cp.float32)
    _compiled_cuda().get_function('perched<float>')(((n+127)//128,),(128,),(*args,diag,trial,np.int32(n)))
    return base._checked(diag,trial,args[0],args[2],cp)

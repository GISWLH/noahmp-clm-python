# PB-n package-only candidate

This is a separate593-source candidate, not the original NM584/PB-l586 identity. All586 PB-l source files remain byteexact. Seven additional files carry the F/K primitives, two original CUDA texts, I/K adaptive loops, and the I typed32 phase helper. Changes are only package-relative imports and CUDA resource paths. No mathematics, operation order, controls, default values, dtype policy or error bounds change. No column adapter, raw-dtype guard or existing column connection is implemented here.

`IMPORT_RESOURCE_PROOF.json` records every exact replacement and old/new hash. Reversing those replacements recovers original bytes; canonical ASTs including all original functions agree. `candidate.patch` contains the complete changed-text diff. The unchanged CUDA/phase files are also present under original-files and new-files, and their equal hashes are explicit in the proof. Candidate `SOURCE_SHA256.json` is sealed in the archive and copied as CANDIDATE_SOURCE_SHA256.json. The base586 manifest and original NM584 manifest remain available.

The isolated source archive is ../clm-drainage-package-pb-n-source.tar.gz. Only the new-files tree is expanded here; installing or importing the candidate for numerical validation must use the full source archive on EHPC. No production path is edited. Package code cannot import outputs, external sibling test modules or mutate sys.path.

Source comments saying isolated/unexecuted are retained as original bytes; this candidate has no CPU parity or GPU qualification yet. The native raw-dtype guard and tile diagnosis parameter reachability are design requirements in ../CLM_NATIVE_DRAINAGE_PB_N_DESIGN.md, not implemented claims. CUDA32/full adaptive only; this task does not add CUDA64 support even though the original F primitive text contains an unused double instantiation.

The next proposed CPU job is described in CPU_PARITY_PLAN.md. It is not submitted. Full input32 payloads and numeric output sidecars are bound to actual1665 F0 gold, not reconstructed from recipes or console output. NumPy32 exact parity would establish only package-boundary behavior; JAX/CUDA and column integration remain untested.

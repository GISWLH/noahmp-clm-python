"""Preserve actual PBS closure and complete package-parity outputs, stdlib only."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname() == 'manager'
ROOT = Path('/tmp/noahmp-clm-drainage-package-pb-n')
JOB = '1673.manager'
LABEL = 'clm-drainage-package-pb-n'
sha = lambda b: hashlib.sha256(b).hexdigest()
qstat = subprocess.check_output(['qstat', '-xf', JOB])
status = qstat.decode()
assert re.search(r'^\s*job_state = F\s*$', status, re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$', status, re.M)
code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', status, re.M).group(1))
for name in ('result.tar.gz', 'pbs-exit.txt'):
    digest = subprocess.check_output(['ssh', 'compute002', 'sha256sum', str(ROOT / name)]).decode().split()[0]
    if not (ROOT / name).exists():
        subprocess.run(['scp', 'compute002:' + str(ROOT / name), str(ROOT / name)], check=True)
    assert sha((ROOT / name).read_bytes()) == digest
assert int((ROOT / 'pbs-exit.txt').read_text()) == code
with tarfile.open(ROOT / 'result.tar.gz') as archive:
    members = [m for m in archive if m.isfile()]
    assert len({m.name.removeprefix('./') for m in members}) == len(members)
    raw = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in members}
receipt = json.loads(raw['receipt.json'])
assert receipt['pbs_job'] == JOB and receipt['node'] == 'compute002'
assert int(raw['worker-exit.txt']) == code
summary = json.loads(raw['parity/summary.json']) if 'parity/summary.json' in raw else None
index = json.loads(raw['source/SOURCE_SHA256.json'])
assert len(index) == 593 and all(sha(raw['source/' + n]) == h for n, h in index.items())
binding = json.loads(raw['preparation/BINDINGS.json'])
assert sha(raw['source/SOURCE_SHA256.json']) == binding['source_manifest_sha256']
base = json.loads(raw['preparation/BASE_PBL_SOURCE_SHA256.json'])
assert len(base) == 586 and all(index[n] == h for n, h in base.items())
for folder in ('preparation', 'execution'):
    controls = json.loads(raw[folder + '/CONTROLS_SHA256.json'])
    assert all(sha(raw[folder + '/' + n]) == h for n, h in controls.items())
gold_binding = json.loads(raw['preparation/GOLD32_BINDINGS.json'])
assert all(sha(raw['sealed-gold/' + n]) == h for n, h in gold_binding['members'].items())
assert sha((ROOT / 'gold.tar.gz').read_bytes()) == gold_binding['archive_sha256']
if code == 0:
    assert receipt['passed'] and receipt['numerical_parent_returncode'] == 0
    assert summary['passed'] and summary['completed_cases'] == 20
    assert summary['actual_trial_calls'] == 20 and summary['actual_full_calls'] == 17
    assert summary['numeric_fields_compared'] == 1106
    assert json.loads(raw['immutable-before.json']) == json.loads(raw['immutable-after.json'])
    assert receipt['source_controls_gold_unchanged']
    diagnostic = [json.loads(line.split('PB_N_PARITY ', 1)[1]) for line in raw['numerical.stdout.txt'].decode().splitlines() if 'PB_N_PARITY ' in line]
    assert diagnostic == summary['records'] and len(diagnostic) == 20
else:
    assert not receipt['passed']
comparisons = {}
hard = []
if summary:
    for row in summary['records']:
        name = row['case']
        member = 'parity/' + name + '/all-numeric-byte-comparison.json'
        if member in raw:
            comparison = json.loads(raw[member])
            comparisons[name] = dict(fields=len(comparison), all_equal=all(v['passed'] for v in comparison.values()))
        for stage, channels in row.get('hard_ledgers', {}).items():
            for channel, values in channels.items():
                hard.append(dict(case=name, stage=stage, channel=channel, **values))
    if code == 0:
        assert sum(v['fields'] for v in comparisons.values()) == 1106
        assert all(v['all_equal'] for v in comparisons.values())
readout = dict(job=JOB, job_state='F', exit_status=code, Stageout_status=0, receipt=receipt,
    comparisons=comparisons, original_hard_budget_rows=hard,
    maximum_absolute_native_residual={c: max((abs(r['native_residual']) for r in hard if r['channel'] == c), default=None) for c in ('water', 'heat')},
    maximum_original_bound_fraction={c: max((abs(r['native_residual']) / r['original_bound'] for r in hard if r['channel'] == c and r['original_bound'] > 0), default=None) for c in ('water', 'heat')},
    source_archive_sha256=binding['archive_sha256'], original_gold_archive_sha256=gold_binding['archive_sha256'],
    CPU_only=True, precision='float32', GPU_executed=False, JAX_executed=False, float64_component_executed=False,
    native_adapter_implemented=False, newCLM_dtype_guard_implemented=False, production_promoted=False,
    scope='Package/import/resource parity only: actual20 direct trials/17 full32 integrations from sealed1665 exact inputs. Complete1106 numeric dtype/shape/bytes and original64eps hard accounts. No GPU/JAX/64/coupled/annual acceptance.')
data = {n: b for n, b in raw.items() if not n.startswith(('source/', 'sealed-gold/'))}
data['source-manifest.json'] = raw['source/SOURCE_SHA256.json']
# Preserve each sealed input/output32 byte once in this evidence, not a new model reference.
for name in gold_binding['members']:
    data['original1665/' + name] = raw['sealed-gold/' + name]
for name in ('gold/case-recipes.json', 'gold/export-summary.json', 'gold/export-receipt.json',
             'gold/gold-inventory.json', 'closure/actual-qstat-final.txt'):
    data['original1665/' + name] = raw['sealed-gold/' + name]
for name in ('dispatch.json', 'stage-inventory.json', 'qsub.stdout.txt', 'qsub.stderr.txt',
             'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt', 'pbs-exit.txt'):
    data['scheduler/' + name] = (ROOT / name).read_bytes()
data['scheduler/actual-qstat.txt'] = qstat
if (ROOT / 'pbs-output.log').exists(): data['scheduler/pbs-output.log'] = (ROOT / 'pbs-output.log').read_bytes()
for name in ('stage_drainage_package_pbn.py', 'clm-drainage-package-pb-n-stage-preparation.json'):
    data['provenance/' + name] = (ROOT / name).read_bytes()
data['provenance/independent-review-wo.json'] = (ROOT / 'provenance/independent-review-wo.json').read_bytes()
data['archive_drainage_package_pbn.py'] = Path(__file__).read_bytes()
data['run-readout.json'] = (json.dumps(readout, indent=2, allow_nan=False) + '\n').encode()
data['closed-run.json'] = (json.dumps(dict(job=JOB, actual_job_state='F', actual_exit=code, Stageout_status=0,
    raw_result_sha256=sha((ROOT / 'result.tar.gz').read_bytes()), original_result_members=len(raw),
    source_archive_sha256=binding['archive_sha256'], gold_archive_sha256=gold_binding['archive_sha256']), indent=2) + '\n').encode()
data['original-result-members.json'] = (json.dumps({n: dict(sha256=sha(b), bytes=len(b), included=n in data)
    for n, b in raw.items()}, indent=2) + '\n').encode()
data['artifact-inventory.json'] = (json.dumps({n: dict(sha256=sha(b), bytes=len(b)) for n, b in data.items()}, indent=2) + '\n').encode()
archive = ROOT / (LABEL + '-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for name, value in sorted(data.items()):
        info = tarfile.TarInfo(name); info.size = len(value); t.addfile(info, io.BytesIO(value))
with tarfile.open(archive) as t:
    assert {m.name: t.extractfile(m).read() for m in t} == data
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size, artifacts=len(data),
    actual_job=JOB, actual_job_state='F', actual_exit=code, Stageout_status=0,
    actual_trial_calls=receipt.get('actual_trial_calls'), actual_full_calls=receipt.get('actual_full_calls'),
    numeric_fields_compared=receipt.get('numeric_fields_compared'), source_archive_sha256=binding['archive_sha256'],
    gold_archive_sha256=gold_binding['archive_sha256'], scope=readout['scope'])
(ROOT / (LABEL + '-package.json')).write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

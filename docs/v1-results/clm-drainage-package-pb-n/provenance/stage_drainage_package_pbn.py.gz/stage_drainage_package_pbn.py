"""Stdlib-only PB-n exact32 stage construction; never executes numerical code."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
PREP = ROOT / 'clm-drainage-package-pb-n-preparation'
EXEC = ROOT / 'clm-drainage-package-pb-n-execution'
sha = lambda b: hashlib.sha256(b).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf8', newline='\n')


def main():
    assert sha((PREP / 'CONTROLS_SHA256.json').read_bytes()) == '2fcc5e798ba3d50151b1dbfe60bccd97e6f7242ceaa6075ebe31a2a25c5b3d3f'
    prep_index = json.loads((PREP / 'CONTROLS_SHA256.json').read_bytes())
    assert len(prep_index) == 23 and all(sha((PREP / n).read_bytes()) == h for n, h in prep_index.items())
    binding = json.loads((PREP / 'BINDINGS.json').read_bytes())
    gold_binding = json.loads((PREP / 'GOLD32_BINDINGS.json').read_bytes())
    source = ROOT / binding['archive']
    gold = ROOT / gold_binding['archive']
    assert sha(source.read_bytes()) == binding['archive_sha256']
    assert sha(gold.read_bytes()) == gold_binding['archive_sha256']
    with tarfile.open(gold) as t:
        original = t.extractfile('preparation/arrays_po.py').read()
        assert len(t.getmembers()) == 345
    (EXEC / 'original_arrays_po.py').write_bytes(original)
    old = original.decode()
    replacements = [
        ('from contract_po import sha, save', 'from contract_pbn import sha, save'),
        ('from saturated_drainage_pb import IntegrationControls', 'from noahmp_clm.physics.clm_saturated_drainage import IntegrationControls'),
        ("'numpy':('phase_numpy32_pbi','run_numpy32')", "'numpy':('noahmp_clm.gpu._clm_drainage_numpy32_phase','run_numpy32')"),
        ('    import drainage_primitives_pbf as main_trial', '    import noahmp_clm.gpu.clm_drainage_primitives as main_trial'),
        ('    import perched_primitives_pbk as perched_trial', '    import noahmp_clm.gpu.clm_perched_drainage_primitives as perched_trial'),
        ('    import adaptive_main_pbi as main', '    import noahmp_clm.gpu.clm_drainage_adaptive as main'),
        ('    import adaptive_main_pbg as original_main64\n', ''),
        ('    import adaptive_perched_pbk as perched', '    import noahmp_clm.gpu.clm_perched_drainage_adaptive as perched'),
        ("def run_one(inputs, row, backend, reference64=False, observed=None):\n", "def run_one(inputs, row, backend, reference64=False, observed=None):\n    assert backend == 'numpy' and reference64 is False\n    assert all(inputs[k].dtype == np.dtype('float32') for k in ('cells','parameters','interval'))\n"),
        ("execute=perched.advance_perched_band if kind=='perched' else (original_main64.advance_main_band if reference64 else main.advance_main_band)",
         "execute=perched.advance_perched_band if kind=='perched' else main.advance_main_band"),
    ]
    new = old
    for a, b in replacements:
        assert new.count(a) == 1, a
        new = new.replace(a, b)
    (EXEC / 'arrays_pbn.py').write_text(new, encoding='utf8', newline='\n')
    (EXEC / 'encoder.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
        fromfile='sealed1665/preparation/arrays_po.py', tofile='execution/arrays_pbn.py')), encoding='utf8', newline='\n')
    oldtree = ast.parse(old); newtree = ast.parse(new)
    unchanged = []
    for node in oldtree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name not in ('run_one', 'phase_observer'):
            other = next(v for v in newtree.body if isinstance(v, type(node)) and v.name == node.name)
            assert ast.dump(node, include_attributes=False) == ast.dump(other, include_attributes=False)
            unchanged.append(node.name)
    # Prove the only executed run_one arithmetic/control changes are imports,
    # an input-scope guard and removal of the unreachable original64 branch.
    rebuilt = old
    for a, b in replacements: rebuilt = rebuilt.replace(a, b)
    assert rebuilt == new
    save(EXEC / 'ENCODER_ADAPTATION.json', dict(original_archive_sha256=gold_binding['archive_sha256'],
        original_member='preparation/arrays_po.py', original_sha256=sha(original), adapted_sha256=sha(new.encode()),
        exact_replacements=[dict(old=a, new=b) for a, b in replacements], unchanged_function_AST=unchanged,
        numeric_formula_changes=0, original_64eps_checks_retained=True, input_scope='numpy/float32/reference64=False only'))
    oldexec = ROOT / 'clm-drainage-active-n-pb-m-execution'
    for filename in ('component_pb.pbs', 'dispatch_component_pb.py'):
        code = (oldexec / filename).read_text(encoding='utf8')
        code = code.replace('clm-drainage-active-n-pb-m', 'clm-drainage-package-pb-n')
        code = code.replace('drainage-active-n-pbm', 'drainage-package-pbn')
        code = code.replace('dispatch_drainage_active_n_pbm.py', 'dispatch_drainage_package_pbn.py')
        code = code.replace('PB-m one active-N test, two real NumPy steps on exact PB-l586 candidate; no previous12 rerun, site, annual, official call or GPU execution.',
            'PB-n exact NumPy32 package parity: sealed1665 input32,20trials17full,allnumeric byte equality. No64/JAX/CUDA/coupled/site/annual execution.')
        (EXEC / filename).write_text(code, encoding='utf8', newline='\n')
    (EXEC / 'README.md').write_text('''# PB-n CPU package parity

One1CPU/2GB/10min PBS job on compute002, using the existing closeout Python and NumPy2.2.6. Source593 is the already reviewed seven-file import/resource-only candidate. Preparation23 and original345-member1665 gold archive are verified before and after. No adapter, connection, guard or production edit.

The copied original PO encoder has only qualified imports, observer module path, and an explicit NumPy32-only guard/dead64-branch restriction. encoder.patch and ENCODER_ADAPTATION.json preserve every change; original_arrays_po.py is byte exact. The package IntegrationControls is constructed from the original recipe dictionary. All original numerical encoding and64eps hard accounts are retained. No fixtures, state arrays, references or64 results are regenerated.

Each of20 actual input32 NPZ files is read with its original descriptor. Run20 direct trials and17 complete components; count returns only after completion, retain partial attempts on failure. Every1106 returned numeric field must have the original dtype/shape/C-order bytes. Record actual import paths under source593, phase converged/dtype, original hard residuals/bounds, nonnumeric metadata, input immutability and before/after hashes. This is packaging parity only: no64/JAX/CUDA/whole column/site/year/scientific acceptance credit.
''', encoding='utf8', newline='\n')
    for path in EXEC.glob('*.py'): ast.parse(path.read_bytes())
    exec_index = {p.relative_to(EXEC).as_posix(): sha(p.read_bytes()) for p in sorted(EXEC.rglob('*')) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    save(EXEC / 'CONTROLS_SHA256.json', exec_index)
    raw = {'source.tar.gz': source.read_bytes(), 'gold.tar.gz': gold.read_bytes()}
    for folder, label in ((PREP, 'preparation'), (EXEC, 'execution')):
        raw.update({label + '/' + p.relative_to(folder).as_posix(): p.read_bytes() for p in sorted(folder.rglob('*')) if p.is_file()})
    raw['provenance/independent-review-wo.json'] = (ROOT / 'clm-drainage-package-pb-n-independent-review-wo.json').read_bytes()
    raw['stage-inventory.json'] = (json.dumps({n: sha(b) for n, b in sorted(raw.items())}, indent=2) + '\n').encode()
    archive = ROOT / 'clm-drainage-package-pb-n-stage.tar.gz'
    with tarfile.open(archive, 'w:gz') as t:
        for name, data in sorted(raw.items()):
            info = tarfile.TarInfo(name); info.size = len(data); t.addfile(info, io.BytesIO(data))
    report = dict(actual_static_exit=0, stage_sha256=sha(archive.read_bytes()), members=len(raw),
        source_archive_sha256=binding['archive_sha256'], source_files=593, original_PBl_exact=586,
        gold_archive_sha256=gold_binding['archive_sha256'], gold_members=345,
        preparation_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()), preparation_controls=23,
        execution_manifest_sha256=sha((EXEC / 'CONTROLS_SHA256.json').read_bytes()), execution_controls=len(exec_index),
        encoder_adaptation_sha256=sha((EXEC / 'ENCODER_ADAPTATION.json').read_bytes()),
        numerical_execution=False, PBS_submitted=False, scope='Static stage only; planned20trial17full exact32 parity.')
    save(ROOT / 'clm-drainage-package-pb-n-stage-preparation.json', report)
    print(json.dumps(report))


if __name__ == '__main__': main()

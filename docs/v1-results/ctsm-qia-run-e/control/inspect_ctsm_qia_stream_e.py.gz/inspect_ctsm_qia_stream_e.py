from pathlib import Path
import tarfile

b=Path('/home/zhangyq/noahmp-v1')
with tarfile.open(b/'ctsm-qia-run-e/case-configuration-private.tar.gz') as t:
 for m in t:
  if m.isfile() and (m.name.endswith('qia.met.stream') or 'atm.log.' in m.name or ('datm.streams.txt.CLM1PT' in m.name and m.size<20000)):
   print('FILE',m.name);print(t.extractfile(m).read().decode(errors='replace')[:12000])
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 for m in t:
  if m.isfile() and m.name.endswith('shr_stream_mod.F90'):
   p=t.extractfile(m).read().decode();lines=p.splitlines();wanted=set()
   for i,line in enumerate(lines):
    if any(s in line for s in ['subroutine shr_stream_readUpToTag','end subroutine shr_stream_readUpToTag','tag not found']):wanted.update(range(max(0,i-5),min(len(lines),i+55)))
   print('FILE',m.name);print('\n'.join(str(i+1)+':'+lines[i] for i in sorted(wanted)))

from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'run_ctsm_qia_d.py').read_text().replace('ctsm-qia-run-d', 'ctsm-qia-run-e')
old = '"finidat = \'\'",'
assert p.count(old) == 1
p = p.replace(old, '')
old = 'CLM_CO2_TYPE=diagnostic\''
assert p.count(old) == 1
p = p.replace(old, 'CLM_CO2_TYPE=diagnostic,CLM_FORCE_COLDSTART=on\'')
ast.parse(p)
(r / 'run_ctsm_qia_e.py').write_text(p)
p = (r / 'ctsm_qia_run_d.pbs').read_text().replace('ctsm-qia-run-d', 'ctsm-qia-run-e').replace('run_ctsm_qia_d.py', 'run_ctsm_qia_e.py').replace('clm-qia-official-d', 'clm-qia-official-e')
(r / 'ctsm_qia_run_e.pbs').write_bytes(p.encode())

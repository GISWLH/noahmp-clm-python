# PC-e actual complete drainage candidate evidence

Private source changes exactly one CUDA float32 geometry helper; 595 files and the CUDA double else expressions are byte preserved. JAX/default flags, the original CuPy wrapper (actual effective -ftz=true), references, tolerance and hard budgets are unchanged. Preparation snapshots retain historical/prepared-only metadata; actual closure and readout describe this executed experiment.

CUDA and JAX each returned all eight original component cases with worker/parent exit0; five task PIDs were verified gone. Controller OS exit was not independently obtained. Other projects shared the GPU and were untouched; walltimes are delivery records, not performance measurements. Actual original Module return frames, source, CUBIN, name mappings and cache payloads are preserved without padding/recompiling/loading extra modules.

EHPC compute002 job1873 ran once, F1 / Stageout0. All16 backend P0/behavior/unchanged64eps hard budgets pass. Primary all75-field1e-6/exact pairing is5/8: stress, option2 and two_bands remain failures. In stress, drained water differs by0.01140594482421875kg/m2, heat4151.25J/m2 and accepted count1. Option2 differs by0.015460014343261719kg/m2 and5625.75J/m2. Two_bands retains0.015625J/m2 residual differences. Full per-field absolute/scaled differences and independent budgets are in comparison.json and readout.json. No gate or expected value was changed. No production/full-column/year/official/FLUXNET credit.

Local verification uses stdlib archive/hash/JSON and opaque NPY headers only. All numeric comparisons were executed by the unchanged comparator on EHPC. Full original GPU and PBS output archives and executed stages are retained.

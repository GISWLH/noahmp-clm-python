"""Freeze complete8-case/backend candidate and readonly loaded-CUDA evidence."""
from pathlib import Path
import ast
import difflib
import gzip
import io
import json
import tarfile
import urllib.request
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
OLDPREP=BASE/'clm-drainage-device-pb-t-preparation';OLDEXEC=BASE/'clm-drainage-device-pb-t-execution'
PREP=BASE/'clm-drainage-device-pc-e-preparation';EXEC=BASE/'clm-drainage-device-pc-e-execution'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def main():
    assert not PREP.exists() and not EXEC.exists();PREP.mkdir();EXEC.mkdir()
    source=(BASE/'clm-drainage-geometry-pc-e-source.tar.gz').read_bytes();sources=files(source)
    assert sha(source)=='11e34ddd06737df105e69b4c7e253baaeda4708c56746b35aab4d9ff3fea3515'
    source_manifest=sha(sources['SOURCE_SHA256.json']);assert source_manifest=='09c2704f76b170a621f77cfe67b61225f2f0f9f70aa97d66182d8000253f5cba'
    kernel=sources['src/noahmp_clm/gpu/cuda/clm_drainage_primitives_kernel.cu']
    perched=kernel+sources['src/noahmp_clm/gpu/cuda/clm_perched_drainage_kernel.cu']
    oldbinding=json.loads((OLDPREP/'BINDINGS.json').read_bytes());binding=dict(oldbinding)
    binding.update(source_archive_sha256=sha(source),source_manifest_sha256=source_manifest,
        cuda_compiler_implementation_sha256='09226d26ab41bf6e7b5b6e57b59187b4c3a5637690747af9a83d288a87d0fb6e',
        cuda_cache_implementation_sha256='ba5dbfa01eae039b865cfc399a2079ef373fa9766b5700f46e39d2a212b0fced',
        cuda_load_sources={sha(kernel):dict(label='main',name_expressions=['drainage<float>','drainage<double>','drainage_diagnosis<float>']),
            sha(perched):dict(label='perched',name_expressions=['perched<float>'])},
        PC_e_scope='One CUDA float32 geometry source candidate; all original numerical references/gates retained',
        XLA_FLAGS='unset; unchanged default',expected_references_refreshed=False,production_checkout_modified=False)
    assert len(binding['cases'])==8 and binding['cases']==oldbinding['cases']
    assert all(binding[key]==value for key,value in oldbinding.items() if key not in ('source_archive_sha256','source_manifest_sha256'))
    (PREP/'BINDINGS.json').write_bytes(encode(binding))
    for name in ('contract_pbs.py','compare_ehpc_pbs.py'):(PREP/name).write_bytes((OLDPREP/name).read_bytes())
    observer=(BASE/'cuda_load_proof_pce.py').read_bytes();ast.parse(observer);(PREP/'cuda_load_proof_pce.py').write_bytes(observer)
    before=(OLDPREP/'capture_device_pbs.py').read_text();after=before
    after=after.replace("assert os.environ.get('JAX_PLATFORMS') == 'cuda' and os.environ.get('JAX_ENABLE_X64','').lower() == 'true'", "assert os.environ.get('JAX_PLATFORMS') == 'cuda' and os.environ.get('JAX_ENABLE_X64','').lower() == 'true'\n    assert os.environ.get('XLA_FLAGS') is None, 'Original default JAX flags only'")
    after=after.replace("started = time.monotonic()\n    try:\n        for name, entry", "started = time.monotonic();cuda_load_observer=None\n    try:\n        if args.backend == 'cuda':\n            from cuda_load_proof_pce import ActualCudaLoadProof\n            cuda_load_observer=ActualCudaLoadProof(args.output,binding);cuda_load_observer.install()\n        for name, entry")
    after=after.replace("    finally:\n        try:", "    finally:\n        if cuda_load_observer is not None:\n            proof=cuda_load_observer.finish();record['actual_cuda_load_proof']=proof\n            record['passed']=record['passed'] and proof['passed']\n        record['actual_XLA_FLAGS']=os.environ.get('XLA_FLAGS')\n        try:")
    ast.parse(after);assert after!=before
    (PREP/'capture_device_pbs.py').write_text(after,encoding='utf-8',newline='\n')
    (PREP/'PBT_TO_PCE_CAPTURE.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='PB-t/capture_device_pbs.py',tofile='PC-e/capture_device_pbs.py')),encoding='utf-8',newline='\n')
    for name in ('candidate.patch','DIFF_PROOF.json'):(PREP/('SOURCE_'+name)).write_bytes((BASE/'clm-drainage-geometry-pc-e-source-preparation'/name).read_bytes())
    for name in ('compiler.py','_compiler_cache.py'):(PREP/('ACTUAL-LIBRARY-'+name+'.txt')).write_bytes((BASE/'drainage-elf-tail-pb-x'/name).read_bytes())
    primary={}
    for name,path in [('function.pxd','cupy/cuda/function.pxd'),('function.pyx','cupy/cuda/function.pyx'),('raw.pyx','cupy/_core/raw.pyx')]:
        url='https://raw.githubusercontent.com/cupy/cupy/v14.2.0/'+path
        with urllib.request.urlopen(url,timeout=30) as response:raw=response.read()
        (PREP/('PRIMARY-CuPy14.2-'+name+'.txt')).write_bytes(raw);primary[path]=dict(url=url,sha256=sha(raw))
    (PREP/'LOAD_PROOF_PRIMARY_SOURCES.json').write_bytes(encode(primary))
    (PREP/'README.md').write_text('''# PC-e full drainage candidate — prepared only

Source11e34ddd…3515 contains exactly the reviewedPC-d geometry proposal9f175c77…9082 in the one CUDA kernel file,595 other source files byte-exact toPB-t. CUDA64 retains its original else expressions; allPython/NumPy/JAX/otherCUDA and originalRawModule wrapper options are unchanged. This is a private source clone, not a checkout edit. The standalonePC-d ftzfalse kernel does not substitute for complete-wrapper validation.

Original PB-t contract and EHPC comparator are byte-identical. The same8 actual encoded32 cases/backend and all17 original1704 NumPy references remain frozen, with all75fields, originalCUDA32/JAX32 1e-6+1e-6*abs(reference), integer exact comparisons,P0/10%/absolute-near-zero checks, behavior/clocks and original64eps independent hard ledgers. No expected value/reference/gate refresh or CPU model run occurs. JAX_ENABLE_X64=true follows the existingPB-t full capture, not a new precision workaround; all original case arrays remainfloat32. XLA_FLAGS is explicitly absent, preserving the default backend and excluding priorprecision2 experiments.

The only capture additions are a fail-only default-flags assertion and an external sys.setprofile observer. It observes returns of the original installedCuPy14.2 _compile_with_cache_cuda, after that function's originalModule.load. It changes no compiler arguments, code, return objects or arithmetic, invokes no extra compiler/Module.load/kernel/model, and restores the previous profiler. For the two explicitly SHA-bound changed-source combinations (main andmain+perched), it preserves actual source bytes, effective options including automatic-ftz=true, the original loadedcubin bytes, nonzero original returnedModule handle/mapping and original private-cache bytes when present. Cache SHA1/name-map/payload checks bind disk bytes to the exact originally loadedcubin. No trailing-NUL repair/padding or supplementary compilation occurs. Source/implementation mismatches, logging errors or missing target-load proof are explicit delivery failures; they never replace a compiler exception or relax physical gates. Other generated compile returns retain source hashes/options as metadata only.

Actual library compiler/cache sources are hash-bound; primaryCuPy14.2 Cython sources documentRawModule's prepend_cupy_headers=false path and publicModule.ptr/mapping. All source/load evidence stays in the output directory, so the existing controller's cache exclusion does not discard it. Existing numerical captures remain unchanged; independent full-value comparison still occurs only in a subsequently bound EHPC result stage.

Lifecycle remains fresh CUDA then JAX on physicalCUDA1,1thread,privatelegacy-prefix caches,8GiB GPU/32GiB host startup gates,3600s/backend and actual wait/kill-wait. Root must review sourceproof, observer/capture diff and mechanical execution diff, and independently authorize any launch afterQS allPID closure. This preparation uploads/submits/compiles/runs nothing; original failures stay preserved.
''',encoding='utf-8',newline='\n')
    (PREP/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file()}))
    oldindex=json.loads((OLDEXEC/'CONTROLS_SHA256.json').read_bytes());assert all(sha((OLDEXEC/n).read_bytes())==h for n,h in oldindex.items())
    diffs=[]
    for name in oldindex:
        raw=(OLDEXEC/name).read_bytes();updated=raw
        if name=='EXECUTION_BINDINGS.json':
            policy=json.loads(raw);policy.update(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
                source_archive_sha256=sha(source),source_manifest_sha256=source_manifest,
                root='/home/lhwang/work/noahmp-v1/clm-drainage-device-pc-e',temporary='/tmp/drainage-pb-s-pce-20261026',
                prepared_only=True,root_execution_authorization_pending=True,change_scope='Root-reviewed float32 CUDA geometry1file candidate; original gates/references/wrapperflags retained plus readonly load proof')
            updated=encode(policy)
        elif name=='run_device_parent_pbs.py':
            updated=raw.replace(b"env.pop('LD_LIBRARY_PATH',None)",b"env.pop('LD_LIBRARY_PATH',None);env.pop('XLA_FLAGS',None)")
        elif name=='README.md':
            updated=b'Prepared-only PC-e complete module candidate. Original PB-t CUDA then JAX8cases each,3600s/backend,8GiB32GiB/one-thread/privatecache/wait gates. Source1file geometry change; defaultXLAflags explicitly absent, unchangedRawModule options/automaticftztrue. Contract/comparator and all17goldrefs/P0/1e-6/integer/hard budgets unchanged. Root finalreview/unique authorization required; wait actualQS allPID closure. No GPU/CPU/model execution in preparation.\n'
        elif name.endswith(('.py','.pbs')):
            updated=raw.replace(b'/tmp/noahmp-drainage-device-pb-t-compare',b'/tmp/noahmp-drainage-device-pc-e-compare')
            updated=updated.replace(b'/tmp/dispatch_compare_pbt.py',b'/tmp/dispatch_compare_pce.py')
            updated=updated.replace(b'#PBS -N drainage-device-pbt-compare',b'#PBS -N drainage-device-pce-compare')
        if name.endswith('.py'):ast.parse(updated)
        (EXEC/name).write_bytes(updated)
        if updated!=raw:diffs.extend(difflib.unified_diff(raw.decode().splitlines(True),updated.decode().splitlines(True),fromfile='PB-t/'+name,tofile='PC-e/'+name))
    (EXEC/'PBT_TO_PCE.diff').write_text(''.join(diffs),encoding='utf-8',newline='\n')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'}))
    oldgpu=files((BASE/'clm-drainage-device-pb-t-gpu-stage.tar.gz').read_bytes());evidence=oldgpu['pbr-evidence.tar.gz']
    assert sha(evidence)==binding['evidence_archive_sha256']=='0dc619264334c45aabafc398b42202df717dd07e58cfcfab19080b5a0cb82739'
    pbr=files(files(evidence)['original-result.tar.gz']);references=[n for n in pbr if n.startswith('results/') and n.endswith('-original-reference.json')]
    assert len(references)==17
    items={prefix+'/'+p.name:p.read_bytes() for root,prefix in ((PREP,'preparation'),(EXEC,'execution')) for p in root.iterdir() if p.is_file()}
    items.update({'source.tar.gz':source,'pbr-evidence.tar.gz':evidence});items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/'clm-drainage-device-pc-e-gpu-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,raw in sorted(items.items()):
                m=tarfile.TarInfo(name);m.size=len(raw);m.mode=0o644;tar.addfile(m,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    proof=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),bytes=target.stat().st_size,stage_files=len(items),
        preparation_manifest_sha256=sha(items['preparation/CONTROLS_SHA256.json']),execution_manifest_sha256=sha(items['execution/CONTROLS_SHA256.json']),
        source_archive_sha256=sha(source),source_manifest_sha256=source_manifest,source596_other595_byte_exact=True,
        contract_byte_exact=(PREP/'contract_pbs.py').read_bytes()==(OLDPREP/'contract_pbs.py').read_bytes(),
        comparator_byte_exact=(PREP/'compare_ehpc_pbs.py').read_bytes()==(OLDPREP/'compare_ehpc_pbs.py').read_bytes(),
        original_cases_each_backend=8,original_reference_records=17,original_gates_unchanged=True,
        default_XLA_FLAGS_unset=True,original_CuPy_wrapper_options_unchanged=True,actual_load_observer_readonly=True,
        prepared_only=True,launched=False,numerical_executed=False)
    (BASE/'clm-drainage-device-pc-e-gpu-stage-package.json').write_bytes(encode(proof));print(json.dumps(proof))

if __name__=='__main__':main()

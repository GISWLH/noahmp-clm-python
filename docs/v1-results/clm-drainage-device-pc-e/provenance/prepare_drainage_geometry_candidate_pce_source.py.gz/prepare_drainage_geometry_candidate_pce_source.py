"""One-file private source candidate; no production edit or numerical execution."""
from pathlib import Path
import difflib
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
DEST=BASE/'clm-drainage-geometry-pc-e-source-preparation'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
assert not DEST.exists();DEST.mkdir()
stage=files((BASE/'drainage-default-geometry-pc-d-stage.tar.gz').read_bytes())
oldraw=stage['source.tar.gz'];old=files(oldraw)
assert sha(oldraw)=='da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d'
oldmanifest=json.loads(old['SOURCE_SHA256.json']);assert len(oldmanifest)==596 and all(sha(old[n])==h for n,h in oldmanifest.items())
path='src/noahmp_clm/gpu/cuda/clm_drainage_primitives_kernel.cu'
proposal=stage['preparation/PROPOSAL-ONLY-kernel.cu.txt'];helper=stage['preparation/geometry_default_pcd.cuh']
guard=json.loads(stage['preparation/SOURCE_PROPOSAL_GUARD.json'])
assert sha(proposal)==guard['proposed_kernel_sha256'] and sha(helper)==guard['helper_sha256']
assert sha(proposal).startswith('9f175c77') and sha(helper).startswith('747f')
new=dict(old);new[path]=proposal
manifest={name:sha(new[name]) for name in sorted(oldmanifest)};new['SOURCE_SHA256.json']=encode(manifest)
changed=[name for name in oldmanifest if old[name]!=new[name]];assert changed==[path]
assert all(old[n]==new[n] for n in oldmanifest if n!=path)
needle=b'    sat[k]=(c[6*k]/T(1000)+c[6*k+1]/T(917))/(c[6*k+2]*p[0]);\n    ice[k]=mn(T(1),c[6*k+1]/((T(917)*c[6*k+2])*p[0]));\n'
assert needle in proposal and b'    }else{\n'+needle+b'    }\n' in proposal
target=BASE/'clm-drainage-geometry-pc-e-source.tar.gz';assert not target.exists()
with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w') as archive:
        for name,raw in sorted(new.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
assert files(target.read_bytes())==new
patch=''.join(difflib.unified_diff(old[path].decode().splitlines(True),proposal.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(DEST/'candidate.patch').write_text(patch,encoding='utf-8',newline='\n')
(DEST/'original-kernel.cu.txt').write_bytes(old[path]);(DEST/'candidate-kernel.cu.txt').write_bytes(proposal)
(DEST/'SOURCE_SHA256.json').write_bytes(new['SOURCE_SHA256.json'])
proof=dict(parent_source_archive_sha256=sha(oldraw),parent_source_manifest_sha256=sha(old['SOURCE_SHA256.json']),
    candidate_source_archive_sha256=sha(target.read_bytes()),candidate_source_manifest_sha256=sha(new['SOURCE_SHA256.json']),
    source_files=596,source_archive_members=597,changed_source_files=changed,unchanged_parent_files=595,
    original_kernel_sha256=sha(old[path]),candidate_kernel_sha256=sha(proposal),helper_sha256=sha(helper),
    exact_root_reviewed_PC_d_proposal=True,CUDAdouble_original_else_expressions_byte_exact=True,
    NumPy_JAX_all_Python_and_other_CUDA_files_byte_exact=True,CuPy_RawModule_wrapper_options_unchanged=True,
    source_expected_references_or_gates_refreshed=False,production_checkout_modified=False,
    numerical_executed=False,GPU_compile_attempted=False,launched=False)
(DEST/'DIFF_PROOF.json').write_bytes(encode(proof))
(DEST/'README.md').write_text('Private complete-module source candidate only. OriginalPB-t596 files receive exactly the root-reviewedPC-d float32 geometry proposal in1CUDA file; all595 others are byte-exact, including NumPy/JAX/allPython/otherCUDA and originalCuPy wrapper options. Originaldouble statements remain byte-exact in else. No expected/reference/gate update, production edit, compile or run. Full original wrapper validation,8cases/backend,17references,P0,1e-6/integer and hard budgets remain required before any promotion.\n',encoding='utf-8',newline='\n')
(DEST/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file()}))
(BASE/'clm-drainage-geometry-pc-e-source-package.json').write_bytes(encode(proof));print(json.dumps(proof))

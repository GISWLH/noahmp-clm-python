"""Bind approved PB-t transport/read/collection helpers to frozen PC-e stage."""
from pathlib import Path

base=Path(__file__).resolve().parent
pairs=[('deploy_drainage_device_pbt_gpu_qd.py','deploy_drainage_device_pce_gpu.py'),
    ('read_drainage_device_pbt_qd.py','read_drainage_device_pce.py'),
    ('collect_stage_drainage_device_pbt_qd.py','collect_stage_drainage_device_pce.py'),
    ('deploy_drainage_device_pbt_compare_qd.py','deploy_drainage_device_pce_compare.py')]
for old,new in pairs:
    text=(base/old).read_text();text=text.replace('clm-drainage-device-pb-t','clm-drainage-device-pc-e')
    text=text.replace('drainage-pb-s-pbt-20261026','drainage-pb-s-pce-20261026')
    text=text.replace('launch_drainage_device_pbt.py','launch_drainage_device_pce.py').replace('dispatch_compare_pbt.py','dispatch_compare_pce.py')
    text=text.replace('noahmp-drainage-device-pb-t','noahmp-drainage-device-pc-e')
    text=text.replace('c0ba227ea2ff6daf6e038938c4c8e6812c5d9f62caad9297a06408ae64246aad','b2c4ddf10dac1f77fbab7fee8d75ff1b6928164a756552733cec7d529195e59f')
    if new=='deploy_drainage_device_pce_gpu.py':
        text=text.replace("assert sha(stage.read_bytes())==expected", "assert sha(stage.read_bytes())==expected\nprelaunch_path=BASE/'clm-drainage-device-pc-e-prelaunch.json'\nprelaunch=json.loads(prelaunch_path.read_bytes())\nassert prelaunch['nvidia_smi_exit']==0 and not prelaunch['live_task_python']\nassert prelaunch['QS_parents']==[0,0] and not any(prelaunch['QS_PID_exists'].values())\nassert prelaunch['target_GPU_memory_free_MiB']>8192 and prelaunch['host_available_KiB']>32*1024*1024")
        text=text.replace("record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None)", "record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None,\n    prelaunch_sha256=sha(prelaunch_path.read_bytes()),external_workloads_shared=True,performance_measurement=False,\n    external_GPU_processes=prelaunch['own_GPU_processes']+prelaunch['other_user_GPU_processes_untouched'])")
    target=base/new;assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(base/'read_gpu_project_ownership_pcd.py').read_text()
text=text.replace('nq-most-cache-bridge-qn','nq-hidden-step-trace-qs').replace('(886777,886778,886779)','(925070,925071,925259,925072,925260)')
text=text.replace('QN_parents','QS_parents').replace('QN_PID_exists','QS_PID_exists')
target=base/'read_gpu_project_ownership_pce.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')

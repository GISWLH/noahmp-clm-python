"""Preserve one actual5PID release observation for inter-agent scheduling."""
from pathlib import Path
import json
import subprocess

base=Path(__file__).resolve().parent;stem=base/'clm-drainage-device-pc-e-final-release'
assert not stem.with_suffix('.json').exists()
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -']
r=subprocess.run(command,input=(base/'read_pce_final_release.py').read_bytes(),capture_output=True,timeout=35)
Path(str(stem)+'.stdout').write_bytes(r.stdout);Path(str(stem)+'.stderr').write_bytes(r.stderr)
Path(str(stem)+'-exit.json').write_text(json.dumps(dict(command=command,actual_exit=r.returncode),indent=2)+'\n')
assert r.returncode==0,r.stderr.decode(errors='replace');record=json.loads(r.stdout)
assert not any(record['proc_exists'].values())
stem.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

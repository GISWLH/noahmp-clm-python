"""Readonly final full-candidate actual controller/parents/workers handles."""
from pathlib import Path
import json

root=Path('/home/lhwang/work/noahmp-v1/clm-drainage-device-pc-e')
controller=json.loads((root/'controller-receipt.json').read_bytes());launch=json.loads((root/'launch.json').read_bytes())
assert controller['completed'] and controller['stage_unchanged'] and len(controller['actual_parents'])==2
pids=dict(controller=launch['controller_pid']);parents={};workers={}
for row in controller['actual_parents']:
    backend=row['backend'];receipt=row.get('parent_receipt')
    assert receipt is not None
    pids[backend+'_worker']=receipt['pid'];pids[backend+'_parent']=int(receipt['proc_stat_at_launch'].rpartition(') ')[2].split()[1])
    parents[backend]=row['actual_parent_returncode'];workers[backend]=receipt['returncode']
print(json.dumps(dict(actual_parent_exits=parents,actual_worker_exits=workers,controller_completed=True,stage_unchanged=True,
    actual_controller_OS_exit_unknown=True,pids=pids,proc_exists={name:(Path('/proc')/str(pid)).exists() for name,pid in pids.items()},external_processes_untouched=True)))

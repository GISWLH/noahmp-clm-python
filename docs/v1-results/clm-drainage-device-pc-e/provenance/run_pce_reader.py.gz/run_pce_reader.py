"""Store one readonly PC-e status/ownership observation, compact metadata output."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('kind',choices=('prelaunch','progress','closed'));p.add_argument('--suffix',default='');a=p.parse_args()
assert not a.suffix or a.suffix.isalnum()
reader=base/('read_gpu_project_ownership_pce.py' if a.kind=='prelaunch' else 'read_drainage_device_pce.py')
stem=base/('clm-drainage-device-pc-e-'+a.kind+a.suffix)
assert not stem.with_suffix('.json').exists()
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -']
r=subprocess.run(command,input=reader.read_bytes(),capture_output=True,timeout=35)
Path(str(stem)+'.stdout').write_bytes(r.stdout);Path(str(stem)+'.stderr').write_bytes(r.stderr)
Path(str(stem)+'-exit.json').write_text(json.dumps(dict(command=command,actual_exit=r.returncode,reader_sha256=hashlib.sha256(reader.read_bytes()).hexdigest()),indent=2)+'\n')
assert r.returncode==0,r.stderr.decode(errors='replace')
value=json.loads(r.stdout);stem.with_suffix('.json').write_text(json.dumps(value,indent=2)+'\n')
if a.kind=='prelaunch':print(json.dumps(value))
else:
    rows=[]
    for name,row in value['files'].items():
        v=row['value']
        if name.endswith('controller-receipt.json') or name.endswith('device-parent-receipt.json'):rows.append(dict(file=name,value=v))
        if name.endswith('capture-receipt.json'):
            proof=v.get('actual_cuda_load_proof',{})
            rows.append(dict(file=name,passed=v['passed'],actual_model_attempts=v['actual_model_attempts'],actual_model_returns=v['actual_model_returns'],
                completed_cases=len(v['cases']),error=v.get('error'),load_proof_passed=proof.get('passed'),load_proof_errors=proof.get('errors'),
                actual_load_labels=proof.get('observed_target_source_labels'),source_controls_evidence_unchanged=v.get('source_controls_evidence_unchanged')))
    print(json.dumps(dict(rows=rows,live_handles=value['live_handles'],nvidia_smi=value['nvidia_smi'])))

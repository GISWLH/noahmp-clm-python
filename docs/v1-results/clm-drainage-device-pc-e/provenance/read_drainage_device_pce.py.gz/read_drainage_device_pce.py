"""Read only the unique PB-t controller/worker receipts and process handles."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT=Path('/home/lhwang/work/noahmp-v1/clm-drainage-device-pc-e')
TEMP=Path('/tmp/drainage-pb-s-pce-20261026')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result=dict(observed_unix=time.time(),files={},live_handles=[])
for name in ('launch.json','controller-progress.json','controller-receipt.json','gpu-result-hash.json'):
    path=ROOT/name
    if path.exists():
        raw=path.read_bytes();result['files'][str(path)]=dict(sha256=sha(raw),value=json.loads(raw))
for backend in ('cuda','jax'):
    for name in ('device-launch.json','device-parent-receipt.json','device/capture-receipt.json','device/capture-error.json'):
        path=TEMP/backend/name
        if path.exists():
            raw=path.read_bytes();result['files'][str(path)]=dict(sha256=sha(raw),value=json.loads(raw))
for row in list(result['files'].values()):
    for key in ('controller_pid','pid'):
        pid=row['value'].get(key)
        if pid:
            path=Path('/proc')/str(pid)/'stat'
            result['live_handles'].append(dict(pid=pid,exists=path.exists(),stat=path.read_text() if path.exists() else None))
r=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,memory.free','--format=csv,noheader'],capture_output=True,text=True)
result['nvidia_smi']=dict(actual_exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
print(json.dumps(result))

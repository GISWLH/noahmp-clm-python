"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'clm-drainage-device-pc-e-gpu-stage.tar.gz'
expected='b2c4ddf10dac1f77fbab7fee8d75ff1b6928164a756552733cec7d529195e59f'
assert sha(stage.read_bytes())==expected
prelaunch_path=BASE/'clm-drainage-device-pc-e-prelaunch.json'
prelaunch=json.loads(prelaunch_path.read_bytes())
assert prelaunch['nvidia_smi_exit']==0 and not prelaunch['live_task_python']
assert prelaunch['QS_parents']==[0,0] and not any(prelaunch['QS_PID_exists'].values())
assert prelaunch['target_GPU_memory_free_MiB']>8192 and prelaunch['host_available_KiB']>32*1024*1024
target=BASE/'clm-drainage-device-pc-e-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'clm-drainage-device-pc-e-execution/launch_device_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/clm-drainage-device-pc-e && test ! -e /tmp/drainage-pb-s-pce-20261026 && test ! -e /tmp/noahmp-clm-drainage-device-pc-e-stage.tar.gz && test ! -e /tmp/launch_drainage_device_pce.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-clm-drainage-device-pc-e-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_drainage_device_pce.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_drainage_device_pce.py --stage /tmp/noahmp-clm-drainage-device-pc-e-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None,
    prelaunch_sha256=sha(prelaunch_path.read_bytes()),external_workloads_shared=True,performance_measurement=False,
    external_GPU_processes=prelaunch['own_GPU_processes']+prelaunch['other_user_GPU_processes_untouched'])
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('clm-drainage-device-pc-e-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('clm-drainage-device-pc-e-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

"""Seal actual PC-e evidence; stdlib archive/hash/header checks, no numeric decode."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import struct
import tarfile
from verify_drainage_1704_pc import files, packet, sha

BASE=Path(__file__).resolve().parent
LABEL='clm-drainage-device-pc-e'
SOURCE_LABEL='clm-drainage-geometry-pc-e-source'
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()

def main():
    names=[LABEL+'-gpu-stage.tar.gz',LABEL+'-comparison-stage.tar.gz',
           LABEL+'-gpu-closed/gpu-result.tar.gz',LABEL+'-comparison-closed/result.tar.gz']
    raw=[(BASE/n).read_bytes() for n in names]
    assert list(map(sha,raw))==[
        'b2c4ddf10dac1f77fbab7fee8d75ff1b6928164a756552733cec7d529195e59f',
        'f37b755cdda0eb33ee3f8eec16bbb37cee0a0a65dd7523d9d4ff3be1464398ba',
        '48c18366b82b011702bad1ca2649fe5cd327088b16cd41a82b45387f6534fb31',
        '801116682c0d82e20816d7f38a1097f7df53d4bed4efc90f9a4aa576d8c46110']
    gpu_stage,cpu_stage,gpu,cpu=map(files,raw)
    for stage in (gpu_stage,cpu_stage):
        index=json.loads(stage['stage-inventory.json'])
        assert len(stage)==33 and set(index)==set(stage)-{'stage-inventory.json'}
        assert all(sha(stage[n])==h for n,h in index.items())
    for n in gpu_stage:
        if n.startswith(('preparation/','execution/')):assert gpu_stage[n]==cpu_stage[n]
    assert cpu_stage['gpu-result.tar.gz']==raw[2]
    binding=json.loads(gpu_stage['preparation/BINDINGS.json'])
    assert sha(gpu_stage['source.tar.gz'])==binding['source_archive_sha256']=='11e34ddd06737df105e69b4c7e253baaeda4708c56746b35aab4d9ff3fea3515'
    source=files(gpu_stage['source.tar.gz']);source_index=json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index)==596 and all(sha(source[n])==h for n,h in source_index.items())
    assert sha(source['SOURCE_SHA256.json'])==binding['source_manifest_sha256']=='09c2704f76b170a621f77cfe67b61225f2f0f9f70aa97d66182d8000253f5cba'
    parent_raw=(BASE/'clm-drainage-header-pb-t-source.tar.gz').read_bytes()
    assert sha(parent_raw)=='da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d'
    original=files(parent_raw);original_index=json.loads(original['SOURCE_SHA256.json'])
    assert set(source_index)==set(original_index) and len(original_index)==596
    assert all(sha(original[n])==h for n,h in original_index.items())
    changed=[n for n in source_index if source[n]!=original[n]]
    target='src/noahmp_clm/gpu/cuda/clm_drainage_primitives_kernel.cu'
    assert changed==[target]
    assert sha(source[target])=='9f175c7744e7e1bfea93a121758dee241ac0b38960ca3f4618e65ae20b4a9082'
    old_lines=b'    sat[k]=(c[6*k]/T(1000)+c[6*k+1]/T(917))/(c[6*k+2]*p[0]);\n    ice[k]=mn(T(1),c[6*k+1]/((T(917)*c[6*k+2])*p[0]));\n'
    assert old_lines in original[target] and b'    }else{\n'+old_lines+b'    }\n' in source[target]
    for leaf in ('contract_pbs.py','compare_ehpc_pbs.py'):
        assert gpu_stage['preparation/'+leaf]==(BASE/'clm-drainage-device-pb-t-preparation'/leaf).read_bytes()
    controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and controller['actual_controller_OS_returncode'] is None
    assert [x['actual_parent_returncode'] for x in controller['actual_parents']]==[0,0]
    captures={};arrays=0
    for backend in ('cuda','jax'):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json'])
        capture_raw=gpu[backend+'/device/capture-receipt.json'];capture=json.loads(capture_raw)
        assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
        assert parent['device_receipt_sha256']==sha(capture_raw)
        assert capture['passed'] and len(capture['cases'])==8 and capture['actual_model_attempts']==capture['actual_model_returns']==8
        assert capture['source_controls_evidence_unchanged'] and not capture['forbidden_cpu_reference_calls']
        assert capture['source_manifest_sha256']==binding['source_manifest_sha256']
        assert capture['controls_manifest_sha256']==sha(gpu_stage['preparation/CONTROLS_SHA256.json'])
        assert capture['actual_XLA_FLAGS'] is None
        captures[backend]=capture
        for name in binding['cases']:
            meta=json.loads(gpu[backend+'/device/'+name+'/result.json'])
            assert meta['actual_device_barrier_complete'] and meta['actual_encoded_parameters_phase_duration_echo_exact'] and meta['initial_phase_stock_payload_exact']
            assert set(meta['own_process_gpu_uuids'])=={'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'}
            assert len(meta['arrays'])==75
            arrays+=packet(gpu[backend+'/device/'+name+'/result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
    load=json.loads(gpu['cuda/device/actual-cuda-loads/receipt.json'])
    assert load['passed'] and not load['errors'] and load['implementations_after_unchanged']
    assert load['observed_target_source_labels']==load['required_target_source_labels']==['main','perched']
    assert all(load[k]==0 for k in ('extra_compiler_calls','extra_Module_load_calls','extra_kernel_launches','extra_model_calls'))
    assert not load['compile_arguments_changed'] and not load['return_objects_changed']
    for row in load['records']:
        prefix='cuda/device/actual-cuda-loads/'
        cubin=gpu[prefix+row['actual_cubin_file']];cache=gpu[prefix+row['original_cache_copy']]
        assert sha(cubin)==row['actual_cubin_sha256'] and len(cubin)==row['actual_cubin_bytes']
        assert sha(gpu[prefix+row['actual_source_file']])==row['source_sha256']
        assert sha(cache)==row['original_cache_sha256'] and len(cache)==row['original_cache_bytes']
        assert cache[:40]==hashlib.sha1(cache[40:]).hexdigest().encode()
        payload=cache[40:];magic=b'\x93CUPYNE\x00';assert payload.startswith(magic)
        pos=len(magic);count=struct.unpack_from('<I',payload,pos)[0];pos+=4
        mangled=[]
        for _ in range(count):
            size=struct.unpack_from('<I',payload,pos)[0];pos+=4
            mangled.append(payload[pos:pos+size].decode());pos+=size
        assert count==len(row['actual_name_expressions']) and payload[pos:]==cubin
        assert mangled==[row['actual_mapping'][n] for n in sorted(row['actual_name_expressions'])]
        assert row['original_return_was_loaded_Module'] and row['original_mod_identity_preserved'] and row['actual_module_ptr']!=0
        assert row['actual_loaded_cubin_equals_original_cache_payload']
        assert '-ftz=true' in row['actual_options'] and '--ftz=false' not in row['actual_options']
    qstat=(BASE/(LABEL+'-comparison-closed/qstat.stdout')).read_text()
    assert all(v in qstat for v in ('Job Id: 1873.manager','job_state = F','Exit_status = 1','Stageout_status = 0','run_count = 1'))
    assert cpu['worker-exit.txt'].strip()==cpu['pbs-command-exit.txt'].strip()==b'1'
    assert cpu['setup-exit.txt'].strip()==cpu['stage-after-exit.txt'].strip()==b'0'
    assert cpu['worker.stderr']==cpu['run/comparison.stderr']==b''
    index=json.loads(cpu_stage['stage-inventory.json'])
    for name in ('stage-before.json','stage-after.json'):
        check=json.loads(cpu[name]);assert check['passed'] and check['actual']==check['expected']==index
    for directory,prefix in (('preparation','preparation-controls'),('execution','execution-controls')):
        controls=json.loads(cpu_stage[directory+'/CONTROLS_SHA256.json'])
        for name in [*controls,'CONTROLS_SHA256.json']:assert cpu[prefix+'/'+name]==cpu_stage[directory+'/'+name]
    parent=json.loads(cpu['run/comparison-parent-receipt.json'])
    assert parent['comparison_child_attempts']==1 and parent['comparison_child_returncode']==1 and parent['stage_unchanged']
    comparison=json.loads(cpu['run/comparison/comparison.json'])
    assert not comparison['passed'] and comparison['gpu_capture_status']==dict(cuda=True,jax=True) and len(comparison['cases'])==8
    cases=[]
    for row in comparison['cases']:
        assert all(x['passed'] and x['physical64']['passed'] and x['hard_ledgers']['passed'] and x['original_behavior']['passed'] for x in row['backends'].values())
        cases.append(dict(case=row['case'],passed=row['passed'],cuda32_jax32_passed=row['cuda32_jax32']['passed'],
            sameprecision_failed_fields={n:x for n,x in row['cuda32_jax32']['fields'].items() if not x['passed']},
            backends={b:dict(physical64=x['physical64'],hard_ledgers=x['hard_ledgers'],original_behavior=x['original_behavior'],
                numpy32_additional_sameprecision_passed=x['numpy32_sameprecision_diagnostic']['passed'],
                numpy32_additional_failed_fields={n:y for n,y in x['numpy32_sameprecision_diagnostic']['fields'].items() if not y['passed']}) for b,x in row['backends'].items()}))
    assert sum(x['passed'] for x in cases)==5
    release=json.loads((BASE/(LABEL+'-final-release.json')).read_bytes())
    assert release['controller_completed'] and release['stage_unchanged'] and not any(release['proc_exists'].values())
    assert all(v==0 for v in release['actual_parent_exits'].values()) and all(v==0 for v in release['actual_worker_exits'].values())
    readout=dict(actual_GPU_parent_returncodes=[0,0],actual_GPU_worker_returncodes=[0,0],original_controller_OS_returncode=None,
        GPU_timeouts=0,cuda_complete_cases=8,jax_complete_cases=8,opaque_arrays_verified=arrays,
        worker_seconds={b:x['seconds'] for b,x in captures.items()},parent_seconds={x['backend']:x['parent_receipt']['seconds'] for x in controller['actual_parents']},
        elapsed_seconds_scope='Shared external training load; delivery times only, not performance measurements',
        actual_comparison_job='1873.manager',actual_comparison_PBS_state='F',actual_comparison_PBS_exit=1,actual_comparison_Stageout_status=0,
        actual_comparison_child_exit=1,comparison_seconds=parent['seconds'],P0_behavior_and_hard_budget_passed_backend_cases=16,
        primary_cuda32_jax32_passed_cases=5,primary_cuda32_jax32_total_cases=8,overall_validation_passed=False,cases=cases,
        actual_cuda_loaded_records=load['records'],actual_cuda_load_proof_passed=True,actual_XLA_FLAGS=dict(cuda=None,jax=None),
        GPU_release=release,
        scope='One private CUDA float32 geometry candidate. Original P0/behavior/64eps hard budgets16/16 pass; primary75-field1e-6/exact gate5/8. Frozen now passes; stress/option2/two_bands failures retained. No production/full-column/year/official/FLUXNET validation credit. All numbers copied from actual EHPC JSON; no local numerical decoding.')
    verification=dict(evidence_verified=True,overall_model_validation_passed=False,source_files=596,changed_source_files=changed,unchanged_parent_files=595,
        original_CUDAdouble_else_expressions_preserved=True,original_comparator_and_contract_byte_exact=True,
        opaque_array_headers_and_hashes_verified=arrays,source_controls_inputs_unchanged=True,local_numerical_decode=False,local_model_runs=0,
        actual_original_wrapper_effective_ftz=True,actual_loaded_cubin_and_cache_preserved=True,
        original_GPU_result_sha256=sha(raw[2]),original_comparison_result_sha256=sha(raw[3]),actual_GPU_parent_returncodes=[0,0],actual_comparison_F_exit=1,Stageout_status=0)
    items={'executed-gpu-stage.tar.gz':raw[0],'executed-comparison-stage.tar.gz':raw[1],
        'original-gpu-result.tar.gz':raw[2],'original-comparison-result.tar.gz':raw[3],
        'readout.json':encode(readout),'verification.json':encode(verification),'comparison.json':cpu['run/comparison/comparison.json'],
        'actual-cuda-load-receipt.json':gpu['cuda/device/actual-cuda-loads/receipt.json']}
    for n,data in gpu_stage.items():
        if n.startswith(('preparation/','execution/')):items[n]=data
    for leaf in (LABEL+'-gpu-closed',LABEL+'-comparison-closed',LABEL+'-comparison-preflight'):
        for path in (BASE/leaf).iterdir():
            if path.is_file() and not path.name.endswith('.tar.gz'):items['closure/'+leaf+'/'+path.name]=path.read_bytes()
    for leaf in (SOURCE_LABEL+'-preparation',):
        for path in (BASE/leaf).iterdir():
            if path.is_file():items['source-change/'+path.name]=path.read_bytes()
    for n in (LABEL+'-gpu-deployment.json',LABEL+'-comparison-deployment.json',LABEL+'-gpu-stage-package.json',LABEL+'-comparison-stage-package.json',SOURCE_LABEL+'-package.json',
        'verify_drainage_1704_pc.py','prepare_drainage_geometry_candidate_pce_source.py','prepare_drainage_geometry_candidate_pce_stage.py',
        'prepare_pce_deployment_helpers.py','deploy_drainage_device_pce_gpu.py','deploy_drainage_device_pce_compare.py',
        'collect_stage_drainage_device_pce.py','collect_drainage_device_pce_compare_closed.py','read_drainage_device_pce.py',
        'run_pce_reader.py','read_pce_final_release.py','run_pce_final_release.py',Path(__file__).name):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-compare-deploy-',LABEL+'-progressFirst',LABEL+'-progressSecond',LABEL+'-prelaunch',LABEL+'-final-release',LABEL+'-external-workloads'):
        for path in BASE.glob(prefix+'*'):
            if path.is_file():items['deployment/'+path.name]=path.read_bytes()
    items['README.md']=b'''# PC-e actual complete drainage candidate evidence\n\nPrivate source changes exactly one CUDA float32 geometry helper; 595 files and the CUDA double else expressions are byte preserved. JAX/default flags, the original CuPy wrapper (actual effective -ftz=true), references, tolerance and hard budgets are unchanged. Preparation snapshots retain historical/prepared-only metadata; actual closure and readout describe this executed experiment.\n\nCUDA and JAX each returned all eight original component cases with worker/parent exit0; five task PIDs were verified gone. Controller OS exit was not independently obtained. Other projects shared the GPU and were untouched; walltimes are delivery records, not performance measurements. Actual original Module return frames, source, CUBIN, name mappings and cache payloads are preserved without padding/recompiling/loading extra modules.\n\nEHPC compute002 job1873 ran once, F1 / Stageout0. All16 backend P0/behavior/unchanged64eps hard budgets pass. Primary all75-field1e-6/exact pairing is5/8: stress, option2 and two_bands remain failures. In stress, drained water differs by0.01140594482421875kg/m2, heat4151.25J/m2 and accepted count1. Option2 differs by0.015460014343261719kg/m2 and5625.75J/m2. Two_bands retains0.015625J/m2 residual differences. Full per-field absolute/scaled differences and independent budgets are in comparison.json and readout.json. No gate or expected value was changed. No production/full-column/year/official/FLUXNET credit.\n\nLocal verification uses stdlib archive/hash/JSON and opaque NPY headers only. All numeric comparisons were executed by the unchanged comparator on EHPC. Full original GPU and PBS output archives and executed stages are retained.\n'''
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(data),bytes=len(data)) for n,data in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for n,data in sorted(items.items()):
                member=tarfile.TarInfo(n);member.size=len(data);member.mode=0o644;archive.addfile(member,io.BytesIO(data))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual CUDA/JAX8+8; original-wrapper load proof0; EHPC1873 F1/Stageout0. P0/behavior/hard16/16, primary75-field1e-6/exact5/8. Private partial geometry candidate; failures retained, no production or annual credit.')
    for suffix,value in (('readout',readout),('verification',verification),('package',package)):(BASE/(LABEL+'-'+suffix+'.json')).write_bytes(encode(value))
    print(json.dumps(package))

if __name__=='__main__':main()

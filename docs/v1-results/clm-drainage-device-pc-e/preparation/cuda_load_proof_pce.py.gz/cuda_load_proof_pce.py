"""Observe original CuPy compiler returns; never compile/load/launch or alter args."""
from pathlib import Path
import hashlib
import json
import os
import sys
import traceback

sha=lambda raw:hashlib.sha256(raw).hexdigest()

class ActualCudaLoadProof:
    def __init__(self,output,binding):
        import cupy as cp
        from cupy.cuda import compiler as cc
        assert cp.__version__=='14.2.0'
        self.cc=cc;self.compiler_path=Path(cc.__file__).resolve()
        self.compiler_sha=sha(self.compiler_path.read_bytes())
        assert self.compiler_sha==binding['cuda_compiler_implementation_sha256']
        self.cache_path=self.compiler_path.with_name('_compiler_cache.py')
        assert sha(self.cache_path.read_bytes())==binding['cuda_cache_implementation_sha256']
        from cupy.cuda import function as cf
        self.function_binary=dict(path=str(Path(cf.__file__).resolve()),sha256=sha(Path(cf.__file__).read_bytes()))
        self.expected_cache_sha=binding['cuda_cache_implementation_sha256']
        self.target_code=cc._compile_with_cache_cuda.__code__
        self.expected=binding['cuda_load_sources'];self.output=Path(output)/'actual-cuda-loads';self.output.mkdir()
        self.cache=Path(os.environ['CUPY_CACHE_DIR']).resolve()
        assert str(self.cache).startswith('/tmp/drainage-pb-s-')
        self.previous=None;self.callback=self._capture;self.records=[];self.other_compile_returns=[];self.errors=[];self.installed=False
    def install(self):
        self.previous=sys.getprofile();assert self.previous is None,'Do not replace an existing profiler'
        sys.setprofile(self.callback);self.installed=True
    def _capture(self,frame,event,arg):
        if event!='return' or frame.f_code is not self.target_code:return
        try:
            local=frame.f_locals;source=local.get('source')
            if not isinstance(source,str):return
            source_bytes=source.encode();source_hash=sha(source_bytes)
            if source_hash not in self.expected:
                self.other_compile_returns.append(dict(source_sha256=source_hash,backend=local.get('backend'),actual_options=list(local.get('options',()))))
                if 'geometry_default_f32' in source:self.errors.append('Changed-source combination outside explicit source allowlist')
                return
            if len(self.records)>=32:
                self.errors.append('Explicit32target-load evidence cap exceeded');return
            spec=self.expected[source_hash];row=dict(label=spec['label'],source_sha256=source_hash,
                actual_options=list(local.get('options',())),backend=local.get('backend'),arch=local.get('arch'),
                actual_name_expressions=list(local.get('name_expressions') or ()),
                cache_in_memory=bool(local.get('cache_in_memory')),to_ltoir=bool(local.get('to_ltoir')),
                original_return_was_loaded_Module=False)
            self.records.append(row);stem=self.output/(str(len(self.records)-1)+'-'+spec['label'])
            source_file=Path(str(stem)+'.actual-source.cu');source_file.write_bytes(source_bytes)
            assert arg is not None and local.get('mod') is arg
            assert isinstance(local.get('cubin'),bytes) and not row['to_ltoir']
            assert set(row['actual_name_expressions'])==set(spec['name_expressions'])
            assert isinstance(arg.ptr,int) and arg.ptr!=0
            cubin=local['cubin'];cubin_file=Path(str(stem)+'.actual-loaded-returned.cubin');cubin_file.write_bytes(cubin)
            row.update(original_return_was_loaded_Module=True,actual_module_ptr=arg.ptr,
                original_mod_identity_preserved=True,actual_mapping=dict(arg.mapping),actual_cubin_sha256=sha(cubin),
                actual_cubin_bytes=len(cubin),actual_source_file=source_file.name,actual_cubin_file=cubin_file.name)
            assert '-ftz=true' in row['actual_options'] and '--ftz=false' not in row['actual_options']
            cache_name=local.get('name');assert isinstance(cache_name,str) and Path(cache_name).name==cache_name
            cache_file=self.cache/cache_name;row['actual_cache_filename']=cache_name
            row['actual_cache_file_present']=cache_file.is_file()
            if cache_file.is_file():
                raw=cache_file.read_bytes();assert raw[:40]==hashlib.sha1(raw[40:]).hexdigest().encode()
                decoded=self.cc._decode_cache_payload(raw[40:],len(row['actual_name_expressions']))
                assert decoded is not None and decoded[1]==cubin
                assert decoded[0]==[arg.mapping[name] for name in sorted(row['actual_name_expressions'])]
                copy=Path(str(stem)+'.original-cache.bin');copy.write_bytes(raw)
                row.update(original_cache_sha256=sha(raw),original_cache_bytes=len(raw),
                    actual_loaded_cubin_equals_original_cache_payload=True,original_cache_copy=copy.name)
            Path(str(stem)+'.json').write_text(json.dumps(row,indent=2,allow_nan=False)+'\n')
        except BaseException:
            # Instrumentation errors never replace a compiler return/exception.
            self.errors.append(traceback.format_exc())
    def finish(self):
        if self.installed:
            if sys.getprofile() is not self.callback:self.errors.append('Profiler unexpectedly replaced')
            sys.setprofile(self.previous);self.installed=False
        labels={row['label'] for row in self.records if row.get('original_return_was_loaded_Module')}
        expected={row['label'] for row in self.expected.values()}
        unchanged=sha(self.compiler_path.read_bytes())==self.compiler_sha and sha(self.cache_path.read_bytes())==self.expected_cache_sha
        passed=labels==expected and not self.errors and unchanged and all(row.get('original_return_was_loaded_Module') for row in self.records)
        result=dict(passed=passed,records=self.records,other_compile_returns=self.other_compile_returns,errors=self.errors,
            observed_target_source_labels=sorted(labels),required_target_source_labels=sorted(expected),
            compiler_implementation_sha256=self.compiler_sha,cache_implementation_sha256=sha(self.cache_path.read_bytes()),
            function_extension=self.function_binary,implementations_after_unchanged=unchanged,
            other_process_environ_or_private_identity_read=False,compile_arguments_changed=False,return_objects_changed=False,
            extra_compiler_calls=0,extra_Module_load_calls=0,extra_kernel_launches=0,extra_model_calls=0,
            scope='Original compiler Python return frames after their original Module.load; complete actual source/cubin/effectiveflags/module handle and optional exact cache payload. No recompile, binary padding, replacement module or standalone flags.')
        (self.output/'receipt.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        return result

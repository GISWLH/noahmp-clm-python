"""One GPU backend capture of eight sealed encoded32 inputs; no CPU reference."""
import argparse
from dataclasses import asdict
import functools
import importlib
import importlib.metadata
import io
import inspect
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

from contract_pbs import GPU, HERE, bound_evidence, controls, save, sha, source_identity


def main():
    parser = argparse.ArgumentParser()
    for name in ('source','evidence','output'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--backend', choices=('cuda','jax'), required=True)
    args = parser.parse_args()
    assert os.name != 'nt' and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == GPU
    assert os.environ.get('JAX_PLATFORMS') == 'cuda' and os.environ.get('JAX_ENABLE_X64','').lower() == 'true'
    assert os.environ.get('XLA_FLAGS') is None, 'Original default JAX flags only'
    assert all(os.environ.get(k) == '1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    caches = [Path(os.environ[k]).resolve() for k in ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH')]
    assert len(set(caches)) == 3 and all(str(p).startswith('/tmp/drainage-pb-s-') for p in caches)
    assert not args.output.exists()
    control_sha = controls()
    binding = json.loads((HERE/'BINDINGS.json').read_bytes())
    identity = source_identity(args.source, binding)
    original = bound_evidence(args.evidence, binding)
    free = int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'], text=True).strip())
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
    assert free > 8192 and available > 32*1024*1024, 'Existing 8GiB GPU/32GiB host startup gate'
    args.output.mkdir()
    sys.path.insert(0, str(args.source.resolve()/'src'))
    import numpy as np  # Encoding/opaque input transfer only; no NumPy physical reference.
    if args.backend == 'jax':
        assert importlib.metadata.version('jax') == importlib.metadata.version('jaxlib') == '0.11.2'
        import jax
        jax.config.update('jax_enable_x64', True)
        assert len(jax.devices()) == 1 and jax.devices()[0].platform == 'gpu'
        synchronize = lambda: jax.effects_barrier()
        def host(value):
            if hasattr(value,'block_until_ready'): value.block_until_ready()
            return np.asarray(value)
    else:
        import cupy as cp
        assert cp.cuda.runtime.getDeviceCount() == 1
        cp.cuda.Device(0).use()
        cp.cuda.runtime.free(0)
        synchronize = lambda: cp.cuda.get_current_stream().synchronize()
        def host(value):
            return cp.asnumpy(value) if isinstance(value,cp.ndarray) else np.asarray(value)
    from noahmp_clm.gpu import clm_drainage_column as adapter
    from noahmp_clm.gpu import clm_drainage_adaptive as main_band
    from noahmp_clm.gpu import clm_perched_drainage_adaptive as perched_band
    from noahmp_clm.gpu import clm_drainage_primitives as main_primitive
    from noahmp_clm.gpu import clm_perched_drainage_primitives as perched_primitive
    from noahmp_clm.gpu import clm_drainage_diagnosis as diagnosis
    from noahmp_clm.physics.clm_hydrology import CLMVerticalHydrology
    from noahmp_clm.physics.clm_saturated_drainage import DrainageParameters, IntegrationControls
    calls = {}
    def observe(module, name, label):
        function = getattr(module,name)
        signature = inspect.signature(function)
        counts = calls[label] = dict(attempted=0, returned=0, raised=0, requested_backend_counts={})
        @functools.wraps(function)
        def wrapped(*a,**kw):
            counts['attempted'] += 1
            bound = signature.bind(*a,**kw)
            bound.apply_defaults()
            requested = bound.arguments.get('backend',args.backend)
            counts['requested_backend_counts'][requested] = counts['requested_backend_counts'].get(requested,0)+1
            assert requested == args.backend, 'Observed call attempted a different backend'
            try: result = function(*a,**kw)
            except BaseException:
                counts['raised'] += 1
                raise
            counts['returned'] += 1
            return result
        setattr(module,name,wrapped)
        return wrapped
    for module,name,label in ((main_primitive,'run_'+args.backend,'main_device_trial'),
        (perched_primitive,'run_'+args.backend+'_perched','perched_device_trial'),
        (main_band,'advance_main_band','main_full'), (perched_band,'advance_perched_band','perched_full')):
        observe(module,name,label)
    phase = observe(main_band,'_phase','device_phase')
    perched_band._phase = phase
    adapter.diagnose_clm_drainage = observe(diagnosis,'diagnose_clm_drainage','pure_diagnosis')
    inverse_module = importlib.import_module('noahmp_clm.gpu.'+('cuda.enthalpy' if args.backend=='cuda' else 'enthalpy'))
    observe(inverse_module,'run_soil_thermodynamics_'+args.backend,'actual_device_inverse')
    forbidden = []
    def no_cpu_reference(*a,**kw):
        forbidden.append('NumPy physical function reached')
        raise RuntimeError(forbidden[-1])
    main_primitive.run_numpy = no_cpu_reference
    perched_primitive.run_numpy_perched = no_cpu_reference
    importlib.import_module('noahmp_clm.gpu._clm_drainage_numpy32_phase').run_numpy32 = no_cpu_reference
    importlib.import_module('noahmp_clm.physics.clm_saturated_drainage').drain_saturated_soil = no_cpu_reference
    record = dict(passed=False, backend=args.backend, precision='float32', pid=os.getpid(), gpu_uuid=GPU,
        controls_manifest_sha256=control_sha, **identity, cases=[], calls=calls, forbidden_cpu_reference_calls=forbidden,
        setup_gpu_free_mib=free, setup_host_available_kib=available, actual_model_attempts=0, actual_model_returns=0,
        field_years=0, coupled_columns=0, scientific_acceptance=False, physical_comparisons_executed=False)
    record['environment'] = dict(python=sys.version,python_executable=sys.executable,
        numpy=np.__version__,backend_version=jax.__version__ if args.backend=='jax' else cp.__version__)
    started = time.monotonic();cuda_load_observer=None
    try:
        if args.backend == 'cuda':
            from cuda_load_proof_pce import ActualCudaLoadProof
            cuda_load_observer=ActualCudaLoadProof(args.output,binding);cuda_load_observer.install()
        for name, entry in binding['cases'].items():
            row = args.output/name
            row.mkdir()
            meta = json.loads(original[entry['json']])
            with np.load(io.BytesIO(original[entry['npz']]), allow_pickle=False) as store:
                values = {key:store[key].copy() for key in ('input.cells','input.properties','input.options','input.dt','actual.encoded_parameters')}
            for key,value in values.items():
                assert (value.dtype.str,list(value.shape),sha(value.tobytes())) == (meta['arrays'][key]['dtype'],meta['arrays'][key]['shape'],meta['arrays'][key]['c_order_sha256'])
            before = {key:sha(value.tobytes()) for key,value in values.items()}
            drainage = dict(zip(binding['drainage_parameter_fields'], map(float,values['actual.encoded_parameters'][0,4:])))
            config = CLMVerticalHydrology(DrainageParameters(**drainage), integration=IntegrationControls(**binding['integration_controls']))
            assert asdict(config.integration) == binding['integration_controls']
            record['actual_model_attempts'] += 1
            actual = adapter.run_clm_drainage(*(values[key] for key in ('input.cells','input.properties','input.options','input.dt')),config,backend=args.backend)
            record['actual_model_returns'] += 1
            synchronize()
            flat = {}
            def flatten(tree,prefix=''):
                for key,value in tree.items():
                    label = prefix+key
                    if isinstance(value,dict): flatten(value,label+'.')
                    else: flat['actual.'+label] = host(value).copy()
            flatten(actual)
            expected = {key:desc for key,desc in meta['arrays'].items() if key.startswith('actual.')}
            assert set(flat) == set(expected)
            assert all(value.dtype.str == expected[key]['dtype'] and list(value.shape) == expected[key]['shape'] for key,value in flat.items())
            echoes = {'actual.encoded_parameters':'actual.encoded_parameters',
                      'actual.phase_option':'input.options','actual.duration_seconds':'input.dt'}
            assert all(sha(flat[key].tobytes()) == sha(values[original_key].tobytes()) for key,original_key in echoes.items())
            phase = flat['actual.phase_cells_before']
            assert sha(phase[:,:,[4,5]].tobytes()) == sha(values['input.cells'][:,:,:2].tobytes())
            assert sha(phase[:,:,2].tobytes()) == sha(values['input.cells'][:,:,2].tobytes())
            assert before == {key:sha(value.tobytes()) for key,value in values.items()}
            np.savez(row/'result.npz', **flat)
            output_meta = {key:dict(dtype=value.dtype.str,shape=list(value.shape),c_order_sha256=sha(value.tobytes())) for key,value in flat.items()}
            apps = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True)
            own = [line.split(',')[1].strip() for line in apps.splitlines() if line.split(',')[0].strip()==str(os.getpid())]
            assert own and set(own) == {GPU}
            case = dict(case=name, arrays=output_meta, npz_sha256=sha((row/'result.npz').read_bytes()),
                input_hashes_unchanged=True, actual_device_barrier_complete=True, own_process_gpu_uuids=own,
                actual_encoded_parameters_phase_duration_echo_exact=True, initial_phase_stock_payload_exact=True,
                effective_drainage=drainage, integration_controls=asdict(config.integration))
            save(row/'result.json',case)
            record['cases'].append(case)
            print('PB_S_DEVICE_CASE '+json.dumps(dict(case=name,backend=args.backend,fields=len(flat),barrier_complete=True)),flush=True)
        assert len(record['cases']) == 8 and not forbidden
        assert calls['actual_device_inverse']['returned'] == calls['device_phase']['returned'] > 0
        assert source_identity(args.source,binding) == identity and controls() == control_sha
        bound_evidence(args.evidence,binding)
        record['source_controls_evidence_unchanged'] = True
        record['passed'] = True
    except BaseException:
        record['error'] = traceback.format_exc()
        (args.output/'failure.txt').write_text(record['error'],encoding='utf-8')
    finally:
        if cuda_load_observer is not None:
            proof=cuda_load_observer.finish();record['actual_cuda_load_proof']=proof
            record['passed']=record['passed'] and proof['passed']
        record['actual_XLA_FLAGS']=os.environ.get('XLA_FLAGS')
        try:
            assert source_identity(args.source,binding) == identity and controls() == control_sha
            bound_evidence(args.evidence,binding)
            record['source_controls_evidence_unchanged'] = True
        except BaseException:
            record['source_controls_evidence_unchanged'] = False
            record['post_run_identity_error'] = traceback.format_exc()
            record['passed'] = False
        record['seconds'] = time.monotonic()-started
        save(args.output/'capture-receipt.json',record)
    return 0 if record['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

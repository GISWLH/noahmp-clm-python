from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics']
b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-'+label+'-firstday-d');s=Path(os.environ['TMPDIR'])/'source';s.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'capacity-station-final-c-source.tar.gz'
assert sha(a)=='7341089ec7d992674e0976272dd0b4940e082f9baa7b887649ee1d130a3b4fe5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==535 and all(sha(s/n)==h for n,h in m.items())
prior=b/'capacity-station-numpy-b';rec=json.loads((prior/'receipt.json').read_text())
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and rec['counts']==dict(tests=154,failures=0,errors=0,skipped=0) and rec['source_unchanged']
original=b/'qia-stem-inputs-a/inputs'
assert sha(original/'CN-Qia.npz')=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
assert sha(original/'CN-Qia-stem-config.json')=='339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1'
cfg=json.loads((original/'CN-Qia-stem-config.json').read_text());before=json.loads(json.dumps(cfg))
traits=json.loads((b/'ctsm-qia-run-s/physiology-restarts.json').read_text())['original_traits']
values={name:traits[key]['value'] for name,key in [('specific_leaf_area','slatop'),('leaf_cn','leafcn'),('rubisco_nitrogen_fraction','flnr'),('foliage_nitrogen_factor','fnitr')]}
assert values==dict(specific_leaf_area=.01,leaf_cn=58.,rubisco_nitrogen_fraction=.0509,foliage_nitrogen_factor=1.)
cfg['canopy_capacity']=dict(parameters=values,time_step_seconds=1800.,initial_temperature_k=293.15)
cfg['leaf_parameters']['ball_berry_slope']=traits['mbbopt']['value']
if label=='capacity_optics':
    optics=json.loads((b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json').read_text())['traits']
    cfg['canopy_optics']={name:[optics[v]['values'],optics[n]['values']] for name,v,n in [
        ('leaf_reflectance','rholvis','rholnir'),('leaf_transmittance','taulvis','taulnir'),
        ('stem_reflectance','rhosvis','rhosnir'),('stem_transmittance','tausvis','tausnir')]}
assert all(cfg[n]==v for n,v in before.items() if n not in ['scope','leaf_parameters'])
cfg['scope']='Prospective original-cold48: explicit originalPFT1 C3 traits/BB slope, causal completed-interval ten-day history and multilayer leafN profile; second case also originalPFT1 opticalfractions. Bothcases retained, no scoreselection/default/calibration change. Same originalLAI/SAI/CN/soil/roots/heights/met/CO2/window. NOAAcurrent/annualmaxdaylength approximation, sphericalangles and originalSP/CN differences disclosed; not officialDAYL/accumulator timing matching, realyear/spinup/scientific acceptance.'
(r/'config.json').write_text(json.dumps(cfg,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
cmd=[sys.executable,'-u',str(s/'benchmarks/run_fluxnet_column.py'),'--input',str(original/'CN-Qia.npz'),'--input-manifest',str(original/'CN-Qia.json'),
    '--config',str(r/'config.json'),'--output',str(r/'trajectory'),'--stop-after','48']
launch=dict(scope=cfg['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,command=cmd,
    source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_archive_sha256=sha(a),configuration_sha256=sha(r/'config.json'),
    original_configuration_sha256=sha(original/'CN-Qia-stem-config.json'),numpy154_receipt_sha256=sha(prior/'receipt.json'),
    physiology_diagnosis_sha256=sha(b/'ctsm-qia-run-s/physiology-restarts.json'),optical_diagnosis_sha256=sha(b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json'))
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');start=time.monotonic()
with (r/'model.log').open('x') as log:code=subprocess.run(cmd,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else None
receipt=dict(scope=cfg['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,seconds=time.monotonic()-start,
    source_unchanged=all(sha(s/n)==h for n,h in m.items()),status=report['status'] if report else None,steps_completed=report['steps_completed'] if report else None,report_sha256=sha(p) if p.exists() else None)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert code==0 and receipt['source_unchanged'] and report['status']=='running' and report['steps_completed']==48

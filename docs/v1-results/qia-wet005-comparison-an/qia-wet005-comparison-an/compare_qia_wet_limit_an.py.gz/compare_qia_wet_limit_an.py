from pathlib import Path
import dataclasses,hashlib,json,os,pickle,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-wet005-comparison-an';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=Path(os.environ['TMPDIR'])/'source';s.mkdir();a=b/'clm-numerical-recovery-c-source.tar.gz';assert sha(a)=='61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
from noahmp_clm.validation import compare_series
official=b/'ctsm-qia-run-r';audit=json.loads((official/'year-boundary.json').read_text());assert (official/'pbs-exit.txt').read_text().strip()=='0' and sha(official/'official-year-fields.npz')==audit['fields_sha256']
with np.load(official/'official-year-fields.npz',allow_pickle=False) as z:reference=dict(z)
n=96;assert np.array_equal(reference['time_bounds_seconds'][:n],np.arange(n)[:,None]*1800+[[0,1800]])
def equal_state(a,c):
    if dataclasses.is_dataclass(a):return equal_state(dataclasses.asdict(a),dataclasses.asdict(c))
    if isinstance(a,dict):assert set(a)==set(c);return all(equal_state(a[k],c[k]) for k in a)
    if isinstance(a,(tuple,list)):assert len(a)==len(c);return all(equal_state(x,y) for x,y in zip(a,c))
    if isinstance(a,np.ndarray):return a.dtype==c.dtype and a.shape==c.shape and a.tobytes()==c.tobytes()
    return bool(a==c)
def metrics(trace,overlap):
    series={}
    for name,source,factor,unit in [('h_wm2','FSH',1.,'h_wm2'),('le_wm2','EFLX_LH_TOT',1.,'le_wm2'),('et_mm','QFLX_EVAP_TOT',86400.,'et_mm_day'),('runoff_mm','QRUNOFF',86400.,'runoff_mm_day'),('gpp_gc_m2','FPSN',12.0107e-6*86400.,'gpp_gc_day'),('swe_m','H2OSNO',.001,'swe_m')]:
        actual=np.asarray(trace[name][:n],float).reshape(n)*(48. if name in ['et_mm','runoff_mm','gpp_gc_m2'] else 1.);expected=np.asarray(reference[source][:n],float).reshape(n)*factor;series[name]=(actual,expected,unit)
    soil_t=reference['TSOI'][:n].astype(float).reshape(n,15)@overlap.T;soil_w=reference['H2OSOI'][:n].astype(float).reshape(n,10)@overlap[:,:10].T
    for name,expected,unit,offset in [('tsoil_k',soil_t,'tsoil_c',273.15),('smc_m3m3',soil_w,'smc',0.)]:
        for layer in range(4):series[name+'/'+str(layer)]=(trace[name][:n,layer]-offset,expected[:,layer]-offset,unit)
    assert len(series)==14;periods={'whole_fixed_two_days':slice(0,96),'20030101':slice(0,48),'20030102':slice(48,96)}
    return {name:{key:compare_series(a[q],c[q],unit,weights=np.full(len(a[q]),1800.)) for key,(a,c,unit) in series.items()} for name,q in periods.items()}
cases={};start=time.monotonic()
for label in ['capacity','capacity_optics']:
    p=b/('qia-wet005-'+label+'-numpy-ajb');d=json.loads((p/'receipt.json').read_text());assert (p/'pbs-exit.txt').read_text().strip()=='0' and d['failure'] is None and d['private_runtime_patch'] and d['controlled_maximum_wetted_fraction']==.05 and d['source_files_unchanged'] and d['captured_calls']==96 and d['steps_completed']==96 and d['steps_requested']==17520 and d['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
    rp=p/'trajectory/report.json';report=json.loads(rp.read_text());assert sha(rp)==d['report_sha256'] and report['status']=='running';cfg=report['configuration'];cp=p/'trajectory'/report['checkpoint_file'];assert sha(cp)==report['checkpoint_sha256'];stored=pickle.loads(cp.read_bytes());state,initial,net,bounds,maximum,stepmax,index=stored;assert index==96
    trace_path=p/'trajectory'/report['model_npz'];assert sha(trace_path)==report['model_npz_sha256']
    with np.load(trace_path,allow_pickle=False) as z:model=dict(z)
    assert str(model['time_start'][0])=='200301010000' and str(model['time_end'][-1])=='200301030000'
    previous=runner.build_state(cfg);independent_initial=runner.totals(previous);independent_net=np.zeros(4);independent_bounds=np.zeros(4);step_max=np.zeros(4);cumulative_max=np.zeros(4);component=[];closure_max=0.
    for k in range(96):
        v=pickle.loads((p/'captured-steps'/('call-'+str(k).zfill(5)+'.pkl')).read_bytes());assert equal_state(previous,v['before']);incoming,residual,bound=runner.audit_step(v['before'],v['after'],v['forcing'],v['diagnostic'],v['nitrogen'])
        for actual,expected in zip((incoming,residual,bound),v['original_guard']):np.testing.assert_array_equal(actual,expected)
        independent_net+=incoming;independent_bounds+=bound;cumulative=runner.totals(v['after'])-independent_initial-independent_net;assert np.all(abs(cumulative)<=independent_bounds);step_max=np.maximum(step_max,abs(residual));cumulative_max=np.maximum(cumulative_max,abs(cumulative));previous=v['after'];diag=v['diagnostic'];dt=v['forcing'].dt
        for key in ['canopy_interception','canopy_post_interception']:assert np.max(diag[key]['wet_fraction'])<=.05
        wet=float(diag['vapor_parcels']['latent_energy_jm2'].sum()/dt);trans=float(2500000.*diag['transpiration'].sum());ground=float(diag['ground_latent_energy_jm2']/dt);closure=wet+trans+ground-diag['le'];closure_max=max(closure_max,abs(closure));assert abs(closure)<1e-10
        component.append([diag['le'],wet,trans,ground,diag['et_mm']])
    assert equal_state(previous,state)
    for actual,expected in [(independent_initial,initial),(independent_net,net),(independent_bounds,bounds),(step_max,stepmax),(cumulative_max,maximum)]:np.testing.assert_array_equal(actual,expected)
    baseline=b/('qia-richards-'+label+'-numpy-year-a');base_raw=(baseline/'trajectory/report.json').read_bytes();base=json.loads(base_raw);assert base['source_unchanged'] and base['steps_requested']==17520 and base['steps_completed']>=96
    old=json.loads((baseline/'SOURCE_SHA256.json').read_text());common={name:h for name,h in old.items() if (name.startswith('src/') and not name.startswith('src/noahmp_clm/gpu/')) or name.startswith('benchmarks/')};assert len(common)==172 and all(m[name]==h for name,h in common.items());assert set(cfg)==set(base['configuration']) and {key for key in cfg if cfg[key]!=base['configuration'][key]}<= {'case','scope'}
    source_trace=baseline/'trajectory'/base['model_npz'];assert sha(source_trace)==base['model_npz_sha256'];(r/(label+'-baseline-report.json')).write_bytes(base_raw);(r/(label+'-baseline-trace.npz')).write_bytes(source_trace.read_bytes())
    with np.load(source_trace,allow_pickle=False) as z:original={key:value[:96] for key,value in dict(z).items()}
    for key in ['time_start','time_end']:np.testing.assert_array_equal(model[key],original[key])
    dz=np.asarray(cfg['column']['dz']);te=np.r_[0.,np.cumsum(dz)];se=np.r_[0.,np.cumsum(reference['DZSOI'].astype(float).reshape(15))];overlap=np.maximum(0.,np.minimum(te[1:,None],se[None,1:])-np.maximum(te[:-1,None],se[None,:-1]))/dz[:,None];assert np.max(abs(overlap.sum(1)-1.))<1e-14 and np.all(overlap[:,10:]==0.)
    a=np.asarray(component);np.savez_compressed(r/(label+'-private-components.npz'),values=a,time_start=model['time_start'],time_end=model['time_end']);days=[]
    for day in range(2):
        q=slice(day*48,(day+1)*48);days.append(dict(day=day+1,total_le_mean_wm2=float(a[q,0].mean()),wet_canopy_le_mean_wm2=float(a[q,1].mean()),transpiration_le_mean_wm2=float(a[q,2].mean()),ground_le_mean_wm2=float(a[q,3].mean()),et_mm=float(a[q,4].sum())))
    cases[label]=dict(private_runtime_patch=True,baseline_report_status=base['status'],baseline_original_steps_completed=base['steps_completed'],baseline_source172files_exact=True,private_receipt_sha256=sha(p/'receipt.json'),private_report_sha256=sha(rp),all96state_chains_and_original_guards_exact=True,independent_maximum_step_m_h_c_n=step_max.tolist(),independent_maximum_cumulative_m_h_c_n=cumulative_max.tolist(),original_cumulative_bounds=bounds.tolist(),maximum_direct_energy_component_closure_wm2=closure_max,component_columns=['LE_Wm2','wet_canopy_Wm2','transpiration_Wm2','ground_Wm2','ET_mm'],direct_components_daily=days,baseline_cap1_metrics=metrics(original,overlap),private_cap005_metrics=metrics(model,overlap))
record=dict(diagnosis_complete=True,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_files_unchanged=all(sha(s/name)==h for name,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,reference_full_fields_sha256=audit['fields_sha256'],cases=cases,scope='IndependentEHPC all96 owncoldstate/ledger/guard re-audit and ALL14 whole/two daily officialmetrics. Bothcontrolled variants originalNumPybaselinecap1 vs privatefileunchangedC runtimecap.05; identical172NPphysics/runner and nonmetadata configs/input/times, no scores selected. Directprivatewet/trans/ground energy components sumchecked; SP NEE unavailable. Diagnosticdelivery0 is not scientificpass, not formalnewproduction/GPU/fullyear/spinup/multisite acceptance.')
(r/'comparison.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(diagnosis_complete=True,pbs_job=record['pbs_job'],seconds=record['seconds']),allow_nan=False),flush=True);assert record['source_files_unchanged']

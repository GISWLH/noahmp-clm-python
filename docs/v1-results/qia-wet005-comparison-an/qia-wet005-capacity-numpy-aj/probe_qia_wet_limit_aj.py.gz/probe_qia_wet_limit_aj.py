from pathlib import Path
import hashlib,json,os,pickle,re,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics'];b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-wet005-'+label+'-numpy-aj');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=Path(os.environ['TMPDIR'])/'source';s.mkdir();a=b/'clm-numerical-recovery-c-source.tar.gz';assert sha(a)=='61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());cpu=json.loads((b/'numerical-recovery-cpu-c/receipt.json').read_text());assert (b/'numerical-recovery-cpu-c/pbs-exit.txt').read_text().strip()=='0' and cpu['returncode']==0 and cpu['source_unchanged'] and cpu['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and cpu['counts']==dict(tests=1071,failures=0,errors=0,skipped=0)
official=b/'ctsm-qia-run-r';official_archive=official/'case-configuration-private.tar.gz';assert sha(official_archive)=='14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0'
with tarfile.open(official_archive) as tf:nl=tf.extractfile('output/case/run/lnd_in').read()
text=nl.decode();maximum=float(re.search(r'(?m)^\s*maximum_leaf_wetted_fraction\s*=\s*([.0-9]+)',text).group(1));assert maximum==.05 and re.search(r'(?m)^\s*use_clm5_fpi\s*=\s*\.true\.',text) and re.search(r'(?m)^\s*interception_fraction\s*=\s*1\.0',text)
(r/'official-lnd_in.txt').write_bytes(nl);a=b/'ctsm-reference-source-bundle-a.tar.gz';assert sha(a)=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
with tarfile.open(a) as tf:hydrology=tf.extractfile('CTSM/src/biogeophys/CanopyHydrologyMod.F90').read()
assert b'min (fwet(p),maximum_leaf_wetted_fraction)' in hydrology
provenance=dict(official_configuration_archive_sha256=sha(official_archive),official_lnd_in_sha256=hashlib.sha256(nl).hexdigest(),pinned_CanopyHydrologyMod_sha256=hashlib.sha256(hydrology).hexdigest(),maximum_leaf_wetted_fraction=maximum,interception_fraction=1.,use_clm5_fpi=True,scope='Read-only originalofficialR actualnamelist + pinnedoriginalupstream algorithm. No upstreamcode copied into Python implementation. Originalnative563C wetarea cap1 differs from actualofficial.05; independentprivate controlledfraction trial only.')
(r/'wetness-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
import noahmp_clm.physics.canopy_interception as interception
import noahmp_clm.physics.canopy_phase_energy as phase
original_coverage=interception.coverage;original_phase_coverage=phase.coverage;original_audit=runner.audit_step;captured=0
def limited_coverage(state,leaf_area,*,stem_area=0.,vegetated_fraction=1.):
    result=original_coverage(state,leaf_area,stem_area=stem_area,vegetated_fraction=vegetated_fraction)
    leaves,stems,area=interception._geometry(state,leaf_area,stem_area,vegetated_fraction)
    wet=np.minimum(result['wet_fraction'],maximum);result['wet_fraction']=wet;result['dry_fraction']=(1.-wet)*np.divide(leaves,area,out=np.zeros_like(area),where=area>0.);return result
# Independent scalar geometry table: store/cap = (desired covered area)^1.5;
# the observed official bound acts on exposed area, never on mass or enthalpy.
property_records=[]
for t in [260.,273.15,290.]:
    for expected in [0.,.001,.01,.05,.2,1.]:
        leaves=np.full(10,.3);stems=np.full(10,.05);mass=np.full(10,.1*.35*expected**1.5);state=interception.CanopyCondensate.from_temperature(mass,t,liquid_fraction=.5 if t==273.15 else None);before=(state.mass.tobytes(),state.enthalpy.tobytes());got=limited_coverage(state,leaves,stem_area=stems);target=min(maximum,expected)
        assert abs(got['wet_fraction']-target).max()<2e-16 and abs(got['dry_fraction']-(1.-target)*(.3/.35)).max()<3e-16 and before==(state.mass.tobytes(),state.enthalpy.tobytes())
        property_records.append(dict(temperature_k=t,unlimited_exposed_fraction=expected,target_wet_fraction=target,maximum_absolute_wet_error=float(abs(got['wet_fraction']-target).max())))
(r/'geometry-reference.json').write_text(json.dumps(dict(cases=property_records,scope='18 scalar geometry reference cases, including liquid/ice/mixed/zero/highstore, originalM/H exact and leaf-only dryarea. Not a fullmodule validation or scientificfit.'),indent=2)+'\n')
inputs=Path(os.environ['TMPDIR'])/'inputs';inputs.mkdir();a=b/'qia-recovery-c-inputs-u.tar.gz';assert sha(a)=='b5f3f02c09336140ab0d492bad9cade5e55076de62a4eb1a18c6aad1cabbe5fe'
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
cfg=json.loads((inputs/label/'config.json').read_text());before=json.loads(json.dumps(cfg));cfg['case']='qia-wet005-'+label+'-cold-prefix96';cfg['scope']='Prospectively fixed controlledprivateNumPy runtimecoverage .05 from actualofficialR namelist, alloriginalphysicalinputs/initialstates/forcing unchanged. Original563C production stillcap1 and originalyears untouched. Newcold original17520request stop96 only; full14officialmetrics later, no calibration/default/production/science/year/spinup pass.';assert {k for k in cfg if cfg[k]!=before[k]}=={'case','scope'};config=r/'configuration.json';config.write_text(json.dumps(cfg,indent=2)+'\n');(r/'captured-steps').mkdir()
def capture(old,new,forcing,diagnostic,nitrogen):
    global captured
    result=original_audit(old,new,forcing,diagnostic,nitrogen)
    raw=pickle.dumps(dict(before=old,after=new,forcing=forcing,diagnostic=diagnostic,nitrogen=nitrogen,original_guard=result));(r/'captured-steps'/('call-'+str(captured).zfill(5)+'.pkl')).write_bytes(raw);captured+=1;return result
failure=None;report={};start=time.monotonic()
try:
    interception.coverage=limited_coverage;phase.coverage=limited_coverage;runner.audit_step=capture
    report=runner.run(inputs/'CN-Qia.npz',inputs/'CN-Qia.json',config,r/'trajectory',stop_after=96)
    assert report['status']=='running' and report['steps_completed']==96 and report['steps_requested']==17520 and captured==96 and report['source_unchanged']
except Exception as err:
    failure=type(err).__name__+': '+str(err);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:interception.coverage=original_coverage;phase.coverage=original_phase_coverage;runner.audit_step=original_audit
unchanged=all(sha(s/n)==h for n,h in m.items());p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else report
record=dict(case=label,failure=failure,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,private_runtime_patch=True,patched_bindings=['canopy_interception.coverage','canopy_phase_energy.coverage'],controlled_maximum_wetted_fraction=maximum,geometry_reference_cases=18,source_files_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),captured_calls=captured,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),seconds=time.monotonic()-start,report_sha256=sha(p) if p.exists() else None,scope='PrivateNumPy causal candidate only, originalC coveragefunction wrapped with actualofficial .05 exposedarea cap, sourcefiles/otherphysics/initialstate/forcing/parameters/tolerances unchanged. Originalcold96/17520 and 18independentgeometry cases; hardMHCN originalguards. No formalnewproduction source/moduleCPU/GPU, no scoreselectedinput/default or science/year/spinup acceptance.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True);assert failure is None and unchanged

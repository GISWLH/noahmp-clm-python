from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in manifest.items())
begun=time.monotonic();files=['tests/test_gpu_phase_jacobian_boundary.py','tests/test_gpu_canopy_phase_energy.py']
code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml=phase-target.xml']).returncode
assert all(sha(root/k)==v for k,v in manifest.items())
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'phase-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
(root/'phase-target-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun,counts=counts,source_files=len(manifest),source_unchanged=True,node=os.uname().nodename,files=files),indent=2)+'\n')
assert code==0 and all(counts[k]==0 for k in ['failures','errors','skipped'])

# PP saved snapshot: terminal year failures and NQ timing

At 2026-10-25 13:54:52 UTC, NS and NZ both report failed at 7275/17520 steps, with the CUDA layered phase surface exception. Their running-year estimates are null. Their parent exit-code files are outside this snapshot; no exit code is inferred.

NQ has 116 new plus 32 inherited tests closed (148/408), with no failed closed record. The optics file remains active and gains no partial file credit. Remaining timing uses the enumerated two recent modules once plus 49 historical module min/max times multiplied by 1.3/2.6: 20.33973586185235–42.79610241898687 hours, conditional, with no elapsed-time subtraction. This is not a release ETA.

The snapshot has two matching task processes and one CUDA1 compute app, not the formerly running six processes/three apps. Three instantaneous GPU samples show 0% utilization; the active NQ worker still accrues CPU time. No internal execution phase is inferred.

Original snapshot, empty stderr, original timing source, original PO calculation script, PP adaptation, result, and independent scalar audit are retained. No SSH sampling, array decoding, model calls, task changes or GPU launch were performed by this review.

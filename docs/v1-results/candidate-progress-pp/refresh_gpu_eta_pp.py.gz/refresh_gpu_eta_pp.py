"""Derive PP timing/status metadata from saved JSON only; no remote/model calls."""
from collections import Counter
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
UUID = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    names = ('GPU_ETA_NQ.json', 'candidate-progress-pp.json', 'candidate-progress-pp.stderr')
    raw = {name: (ROOT / name).read_bytes() for name in names}
    original = json.loads(raw[names[0]])
    snapshot = json.loads(raw[names[1]])
    modules = {row['file']: row for row in original['modules_in_execution_order']}
    assert len(modules) == len(original['modules_in_execution_order'])
    closed = snapshot['closed']
    assert closed == snapshot['progress']['records']
    assert len({r['file'] for r in closed}) == len(closed)
    failed = [r for r in closed if r['actual_parent_returncode'] != 0 or r['passed'] is not True]
    for row in closed:
        assert row['expected_tests'] == modules[row['file']]['tests']
        assert re.fullmatch('[0-9a-f]{64}', row['receipt_sha256'])
    passed_names = {r['file'] for r in closed if r not in failed}
    remaining = [r for name, r in modules.items() if name not in passed_names]
    recent = [r for r in remaining if r['timing_group'] != 'older_history']
    older = [r for r in remaining if r['timing_group'] == 'older_history']
    assert all(r['baseline_min_seconds'] == r['baseline_max_seconds'] for r in recent)
    recent_seconds = math.fsum(r['baseline_min_seconds'] for r in recent)
    older_seconds = [math.fsum(r['baseline_' + k + '_seconds'] for r in older) for k in ('min', 'max')]
    hours = [(recent_seconds + factor * old) / 3600 for factor, old in zip((1.3, 2.6), older_seconds)]
    reused = snapshot['progress']['reused']
    assert all(r['actual_parent_returncode'] == 0 for r in reused)
    assert not ({r['file'] for r in reused} & set(modules))
    fresh_count = sum(r['expected_tests'] for r in closed if r not in failed)
    reused_count = sum(r['tests'] for r in reused)
    assert fresh_count + reused_count + sum(r['tests'] for r in remaining) == 408
    current = snapshot['progress']['file']
    assert current not in passed_names

    first = {r['pid']: r for r in snapshot['first']['processes']}
    second = {r['pid']: r for r in snapshot['second']['processes']}
    assert first.keys() == second.keys()
    duration = snapshot['second']['monotonic'] - snapshot['first']['monotonic']
    assert duration > 0
    processes = []
    for pid, row in second.items():
        before = first[pid]
        assert before['start_ticks'] == row['start_ticks']
        assert before['environment']['CUDA_VISIBLE_DEVICES'] == row['environment']['CUDA_VISIBLE_DEVICES'] == UUID
        ticks = row['user_ticks'] + row['system_ticks'] - before['user_ticks'] - before['system_ticks']
        processes.append(dict(pid=pid, ppid=row['ppid'], state=row['state'], start_ticks=row['start_ticks'],
            cmdline=row['cmdline'], cpu_seconds=ticks / snapshot['ticks_per_second'],
            mean_cpu_cores=ticks / snapshot['ticks_per_second'] / duration,
            rss_kib=int(row['status']['VmRSS'].split()[0]), swap_kib=int(row['status']['VmSwap'].split()[0]),
            cuda_visible_devices=UUID))
    gpu_apps = [r for r in csv.DictReader(io.StringIO(snapshot['gpu_processes']), skipinitialspace=True)
                if r['gpu_uuid'] == UUID]
    gpu_pids = sorted(int(r['pid']) for r in gpu_apps)
    assert set(gpu_pids) <= set(second)
    gpu_samples = []
    for sample in snapshot['gpu_samples']:
        rows = list(csv.DictReader(io.StringIO(sample['output']), skipinitialspace=True))
        assert len(rows) == 1 and rows[0]['index'] == '1' and rows[0]['uuid'] == UUID
        r = rows[0]
        gpu_samples.append(dict(utc=sample['utc'], utilization_percent=int(r['utilization.gpu [%]'].split()[0]),
            used_mib=int(r['memory.used [MiB]'].split()[0]), free_mib=int(r['memory.free [MiB]'].split()[0])))

    years = {}
    for name, data in snapshot['years'].items():
        logs = []
        for line in data['log_tail']:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(row, dict):
                logs.append(row)
        assert data['steps_completed'] == data['ledger_steps']
        state = data['status']
        terminal = [r for r in logs if r.get('status') in ('failed', 'complete')]
        summary = dict(status=state, completed=data['steps_completed'], requested=data['steps_requested'],
            ledger_steps=data['ledger_steps'], ledger_segments=data['ledger_segments'],
            checkpoint_file=data['checkpoint_file'], sampled_bgc_chunks=data['bgc_chunks'],
            conditional_remaining_hours=None, remaining_eta_reason='Terminal status; no running extrapolation.',
            parent_returncode=None, parent_returncode_provenance='Not included in this saved progress snapshot.')
        if state in ('failed', 'complete'):
            assert terminal
            end = terminal[-1]
            assert end['status'] == state and end['steps_completed'] == data['steps_completed']
            assert end['steps_requested'] == data['steps_requested']
            summary.update({k: end[k] for k in ('failure', 'source_unchanged', 'source_manifest_sha256',
                'continued_fields_exact', 'first_continued_step_captured', 'device_barrier_complete',
                'seconds', 'report_sha256', 'maximum_host_rss_kib', 'bgc_diagnostic_steps') if k in end})
            chunks = end['bgc_diagnostic_chunks']
            assert len(chunks) == data['bgc_chunks']
            assert all(r['end'] - r['first'] == 48 for r in chunks)
            assert all(a['end'] == b['first'] for a, b in zip(chunks, chunks[1:]))
            summary['declared_bgc_chunks'] = dict(count=len(chunks), first=chunks[0]['first'], end=chunks[-1]['end'],
                diagnostic_steps=end['bgc_diagnostic_steps'],
                reported_unchunked_steps=end['bgc_diagnostic_steps'] - sum(r['end'] - r['first'] for r in chunks),
                content_verified=False)
        elif state == 'running':
            rows = [r for r in logs if 'steps' in r and 'seconds' in r]
            assert len(rows) >= 2
            a, b = rows[0], rows[-1]
            assert b['steps'] == data['steps_completed'] and b['steps'] > a['steps']
            rate = (b['seconds'] - a['seconds']) / (b['steps'] - a['steps'])
            assert rate > 0
            summary.update(recent_window_first=a, recent_window_last=b, recent_seconds_per_batch_step=rate,
                conditional_remaining_hours=(data['steps_requested'] - b['steps']) * rate / 3600,
                remaining_eta_reason='Conditional extrapolation of saved recent-window scalar timings.')
        else:
            summary['remaining_eta_reason'] = 'Unsupported/nonrunning status; no extrapolation.'
        years[name] = summary

    formula = (f"sum of the {len(recent)} remaining recent module baseline parent times once, plus "
               f"1.3 times the sum of the {len(older)} remaining historical minimum times (lower) or "
               f"2.6 times their maximum times (upper), divided by 3600; no active elapsed subtraction.")
    result = dict(sample_utc=snapshot['second']['utc'], input_sha256={n: sha(v) for n, v in raw.items()},
        scope='Saved PP snapshot review and scalar timing arithmetic only; no remote resampling or model execution.',
        ssh_exit_status=dict(value=0, provenance='Reported by root with task handoff; no separate raw SSH-exit artifact supplied.'),
        stderr_bytes=len(raw[names[2]]),
        regression=dict(completed=fresh_count + reused_count, fresh=fresh_count, reused=reused_count, total=408,
            closed_modules=len(passed_names), failed_closed_modules=failed, remaining_modules=len(remaining),
            remaining_nodes=sum(r['tests'] for r in remaining), current_file=current, current_pid=snapshot['progress']['pid'],
            current_module_new_credit=0, remaining_hours=None if failed else hours,
            formula=formula, active_elapsed_subtracted_seconds=0,
            remaining_timing_groups=dict(Counter(r['timing_group'] for r in remaining)),
            recent_baseline_seconds=recent_seconds, historical_min_max_seconds=older_seconds,
            remaining_modules_enumerated=[{k: r[k] for k in ('file', 'tests', 'timing_group', 'baseline_min_seconds', 'baseline_max_seconds')} for r in remaining],
            closed_receipt_references=closed,
            receipt_limit='Snapshot records and receipt SHA references checked; no full receipt/XML byte archive reread by this task.'),
        years=years, process_count=len(second), processes=processes, physical_gpu=1, gpu_uuid=UUID,
        matching_gpu_app_count=len(gpu_apps), matching_gpu_app_pids=gpu_pids, gpu_samples=gpu_samples,
        sample_duration_seconds=duration, host_available_kib=int(snapshot['second']['meminfo']['MemAvailable'].split()[0]),
        limitations=[
            'NQ timing is conditional planning metadata, not a release deadline or confidence interval.',
            'Historical timings remain performance context, never new execution credit.',
            'The current module is retained once at its full baseline duration; elapsed time is not subtracted.',
            'NS/NZ failed statuses invalidate prior running-year ETA; no completion forecast is provided.',
            'Only two task processes and one matching GPU app are present in this snapshot; the former six-process/three-app claim is not retained.',
            'Three instantaneous GPU utilization samples do not identify all internal execution phases.',
            'BGC chunk ranges and hashes are log declarations, not a new byte/content audit; reported unchunked records are not credited as archived chunks.',
        ])
    target = ROOT / 'GPU_ETA_NQ_PP_REFRESH.json'
    target.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(sha256=sha(target.read_bytes()), completed=result['regression']['completed'],
                         remaining_hours=result['regression']['remaining_hours'],
                         years={k: {'status': v['status'], 'completed': v['completed'], 'eta': v['conditional_remaining_hours']} for k, v in years.items()})))


if __name__ == '__main__':
    main()

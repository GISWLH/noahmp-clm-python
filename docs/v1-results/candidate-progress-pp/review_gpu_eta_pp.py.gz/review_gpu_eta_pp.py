"""Independent scalar audit and one small evidence package; no SSH/NumPy."""
import ast
import csv
from decimal import Decimal, localcontext
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path(__file__).resolve().parent
UUID = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def main():
    inputs = ('candidate-progress-pp.json', 'candidate-progress-pp.stderr', 'GPU_ETA_NQ.json',
              'refresh_gpu_eta_pp.py', 'GPU_ETA_NQ_PP_REFRESH.json')
    raw = {n: (ROOT / n).read_bytes() for n in inputs}
    snap = json.loads(raw[inputs[0]])
    prior = json.loads(raw[inputs[2]])
    result = json.loads(raw[inputs[4]])
    for name, digest in result['input_sha256'].items():
        assert sha(raw[name]) == digest
    tree = ast.parse(raw['refresh_gpu_eta_pp.py'])
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(v.name for v in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.add(node.module)
    assert imports <= {'collections', 'csv', 'hashlib', 'io', 'json', 'math', 'pathlib', 're'}
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                   and n.func.id in ('exec', 'eval', '__import__') for n in ast.walk(tree))
    closed = snap['closed']
    assert closed == snap['progress']['records'] and len(closed) == 21
    assert all(r['passed'] is True and r['actual_parent_returncode'] == 0 for r in closed)
    assert all(re.fullmatch('[0-9a-f]{64}', r['receipt_sha256']) for r in closed)
    completed = {r['file'] for r in closed}
    assert len(completed) == len(closed)
    modules = prior['modules_in_execution_order']
    lookup = {r['file']: r for r in modules}
    assert len(lookup) == len(modules) == 72
    assert all(r['expected_tests'] == lookup[r['file']]['tests'] for r in closed)
    remaining = [r for r in modules if r['file'] not in completed]
    recent = [r for r in remaining if r['timing_group'] != 'older_history']
    historical = [r for r in remaining if r['timing_group'] == 'older_history']
    assert [r['file'] for r in recent] == ['test_gpu_clm_optics_column.py', 'test_gpu_photosynthesis.py']
    assert len(historical) == 49 and len(remaining) == 51
    assert sum(r['expected_tests'] for r in closed) == 116
    assert sum(r['tests'] for r in snap['progress']['reused']) == 32
    assert all(r['actual_parent_returncode'] == 0 for r in snap['progress']['reused'])
    assert sum(r['tests'] for r in remaining) == 260
    assert 116 + 32 + 260 == result['regression']['total'] == 408
    assert result['regression']['completed'] == 148
    assert result['regression']['active_elapsed_subtracted_seconds'] == 0
    assert 'JO18' not in result['regression']['formula']
    assert 'IV5' not in result['regression']['formula']
    assert result['regression']['remaining_modules_enumerated'] == [
        {k: r[k] for k in ('file', 'tests', 'timing_group', 'baseline_min_seconds', 'baseline_max_seconds')}
        for r in remaining]
    with localcontext() as context:
        context.prec = 50
        recent_total = sum((Decimal.from_float(r['baseline_min_seconds']) for r in recent), Decimal(0))
        decimal_hours = [(recent_total + Decimal(factor) * sum(
            (Decimal.from_float(r['baseline_' + key + '_seconds']) for r in historical), Decimal(0))) / Decimal(3600)
            for factor, key in [('1.3', 'min'), ('2.6', 'max')]]
        errors = [abs(float(value) - actual) for value, actual in zip(decimal_hours, result['regression']['remaining_hours'])]
    assert max(errors) < 1e-12  # scalar timing arithmetic cross-check; not a physics tolerance
    first = {r['pid']: r for r in snap['first']['processes']}
    last = {r['pid']: r for r in snap['second']['processes']}
    assert set(first) == set(last) == {3709288, 4014180}
    for pid in first:
        assert first[pid]['start_ticks'] == last[pid]['start_ticks']
        assert first[pid]['environment']['CUDA_VISIBLE_DEVICES'] == last[pid]['environment']['CUDA_VISIBLE_DEVICES'] == UUID
        assert first[pid]['status']['VmSwap'] == last[pid]['status']['VmSwap'] == '0 kB'
    apps = list(csv.DictReader(io.StringIO(snap['gpu_processes']), skipinitialspace=True))
    apps = sorted(int(r['pid']) for r in apps if r['gpu_uuid'] == UUID)
    assert apps == result['matching_gpu_app_pids'] == [4014180]
    assert result['process_count'] == 2 and result['matching_gpu_app_count'] == 1
    assert result['gpu_uuid'] == UUID and result['physical_gpu'] == 1
    assert snap['progress']['pid'] == 4014180
    assert snap['progress']['file'] == 'test_gpu_clm_optics_column.py' not in completed
    assert result['regression']['current_module_new_credit'] == 0
    assert [r['utilization_percent'] for r in result['gpu_samples']] == [0, 0, 0]
    years = {}
    for name, year in snap['years'].items():
        final = json.loads(year['log_tail'][-1])
        derived = result['years'][name]
        assert year['status'] == final['status'] == derived['status'] == 'failed'
        assert year['steps_completed'] == year['ledger_steps'] == final['steps_completed'] == derived['completed'] == 7275
        assert year['steps_requested'] == final['steps_requested'] == derived['requested'] == 17520
        assert final['failure'] == 'RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False'
        assert derived['conditional_remaining_hours'] is None and derived['parent_returncode'] is None
        assert final['source_unchanged'] is True and final['device_barrier_complete'] is True
        assert final['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
        assert len(final['bgc_diagnostic_chunks']) == year['bgc_chunks'] == 150
        assert final['bgc_diagnostic_steps'] == 7227
        assert final['bgc_diagnostic_chunks'][-1]['end'] == 7248
        assert derived['declared_bgc_chunks']['reported_unchunked_steps'] == 27
        years[name] = {k: derived[k] for k in ('status', 'completed', 'requested', 'failure', 'report_sha256',
                                             'conditional_remaining_hours', 'parent_returncode')}
    review = dict(passed=True, blocking_findings=[], execution_failures_found=['NS', 'NZ'],
        review_scope='Independent source/snapshot interpretation and scalar recomputation only; passed describes this metadata audit, not the failed year simulations.',
        input_sha256={n: sha(v) for n, v in raw.items()},
        snapshot_utc=snap['second']['utc'], completed=148, fresh=116, reused=32, total=408,
        recent_modules=[r['file'] for r in recent], historical_modules=49, remaining_nodes=260,
        decimal_recomputed_hours=[str(v) for v in decimal_hours], scalar_difference_hours=errors,
        active_elapsed_subtracted_seconds=0, years=years,
        sampled_task_pids=sorted(last), matching_gpu_app_pids=apps,
        six_pids_three_apps_claim_rejected=True,
        receipt_limit='Closed receipt status/SHA references are verified in saved snapshot only; original receipt/XML files are not embedded in this small snapshot.',
        transport_limit='SSH exit0 is root-reported; raw stderr is present and empty. The sample alone does not contain annual parent exit-code files.',
        scientific_arrays_decoded=0, model_calls=0, remote_calls=0)
    review_path = ROOT / 'gpu-eta-pp-independent-review-rg.json'
    dump(review_path, review)
    readme = ROOT / 'candidate-progress-pp-README.md'
    readme.write_text(
        '# PP saved snapshot: terminal year failures and NQ timing\n\n'
        'At 2026-10-25 13:54:52 UTC, NS and NZ both report failed at 7275/17520 steps, '
        'with the CUDA layered phase surface exception. Their running-year estimates are null. '
        'Their parent exit-code files are outside this snapshot; no exit code is inferred.\n\n'
        'NQ has 116 new plus 32 inherited tests closed (148/408), with no failed closed record. '
        'The optics file remains active and gains no partial file credit. Remaining timing uses '
        'the enumerated two recent modules once plus 49 historical module min/max times multiplied '
        'by 1.3/2.6: 20.33973586185235–42.79610241898687 hours, conditional, with no elapsed-time subtraction. '
        'This is not a release ETA.\n\n'
        'The snapshot has two matching task processes and one CUDA1 compute app, not the formerly '
        'running six processes/three apps. Three instantaneous GPU samples show 0% utilization; '
        'the active NQ worker still accrues CPU time. No internal execution phase is inferred.\n\n'
        'Original snapshot, empty stderr, original timing source, original PO calculation script, '
        'PP adaptation, result, and independent scalar audit are retained. No SSH sampling, array '
        'decoding, model calls, task changes or GPU launch were performed by this review.\n', encoding='utf-8')
    files = list(inputs) + ['refresh_gpu_eta_po.py', Path(__file__).name, review_path.name, readme.name]
    data = {name: (ROOT / name).read_bytes() for name in files}
    inventory = {name: dict(sha256=sha(value), bytes=len(value)) for name, value in data.items()}
    data['INVENTORY.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
    archive_path = ROOT / 'candidate-progress-pp-evidence.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name, value in data.items():
            item = tarfile.TarInfo(name)
            item.size = len(value)
            item.mode = 0o644
            archive.addfile(item, io.BytesIO(value))
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert set(archive.getnames()) == set(data)
        assert all(archive.extractfile(name).read() == value for name, value in data.items())
    package = dict(archive=archive_path.name, sha256=sha(archive_path.read_bytes()), bytes=archive_path.stat().st_size,
        artifacts=len(data), inventory_files=len(inventory), sample_utc=snap['second']['utc'],
        review_sha256=sha(review_path.read_bytes()),
        scope='Saved PP snapshot: NS/NZ actual failed statuses at7275/17520 and null year ETA; NQ148/408, remaining2recent+49history at original1.3/2.6 factors,20.3397–42.7961h with zero elapsed subtraction. Two sampled task processes/one CUDA1 app. Scalar-only independent review; no new SSH/model/task/GPU actions; no full annual or receipt byte-closure claim.')
    dump(ROOT / 'candidate-progress-pp-package.json', package)
    print(json.dumps(package))


if __name__ == '__main__':
    main()

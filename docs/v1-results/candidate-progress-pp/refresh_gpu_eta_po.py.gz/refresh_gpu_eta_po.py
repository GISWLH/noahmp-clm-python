"""Read JSON metadata only; no model import, array decoding, or new simulation."""
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

root = Path(__file__).resolve().parent
paths = [root / "GPU_ETA_NQ.json", root / "candidate-progress-po.json"]
raw = [path.read_bytes() for path in paths]
original, snapshot = map(json.loads, raw)
modules = {row["file"]: row for row in original["modules_in_execution_order"]}
closed = snapshot["closed"]
closed_names = {row["file"] for row in closed}
assert len(closed_names) == len(closed)
for row in closed:
    assert row["actual_parent_returncode"] == 0 and row["passed"] is True
    assert row["expected_tests"] == modules[row["file"]]["tests"]
remaining = [row for name, row in modules.items() if name not in closed_names]
recent = [row for row in remaining if row["timing_group"] != "older_history"]
older = [row for row in remaining if row["timing_group"] == "older_history"]
assert len(older) == 49
recent_seconds = math.fsum(row["baseline_min_seconds"] for row in recent)
assert all(row["baseline_min_seconds"] == row["baseline_max_seconds"] for row in recent)
remaining_hours = [
    (recent_seconds + factor * math.fsum(row[f"baseline_{key}_seconds"] for row in older)) / 3600
    for factor, key in [(1.3, "min"), (2.6, "max")]
]
new = sum(row["expected_tests"] for row in closed)
reused = sum(row["tests"] for row in snapshot["progress"]["reused"])
assert reused == 32 and new + reused + sum(row["tests"] for row in remaining) == 408
uuid = "GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452"
assert all(row["environment"]["CUDA_VISIBLE_DEVICES"] == uuid for row in snapshot["second"]["processes"])
years = {}
for name, data in snapshot["years"].items():
    rows = [json.loads(line) for line in data["log_tail"]]
    first, last = rows[0], rows[-1]
    assert last["steps"] == data["steps_completed"] == data["ledger_steps"]
    assert last["seconds"] > first["seconds"] and last["steps"] > first["steps"]
    seconds_per_step = (last["seconds"] - first["seconds"]) / (last["steps"] - first["steps"])
    years[name] = {
        "status": data["status"], "completed": data["steps_completed"],
        "requested": data["steps_requested"],
        "recent_window_first": first, "recent_window_last": last,
        "recent_seconds_per_batch_step": seconds_per_step,
        "conditional_remaining_hours": (data["steps_requested"] - last["steps"]) * seconds_per_step / 3600,
    }
result = {
    "sample_utc": datetime.fromisoformat(snapshot["second"]["utc"]).astimezone(timezone.utc).isoformat(),
    "scope": "Read-only remote sample plus scalar timing metadata; no model execution or task changes.",
    "input_sha256": {path.name: hashlib.sha256(data).hexdigest() for path, data in zip(paths, raw)},
    "physical_gpu": 1, "gpu_uuid": uuid, "all_task_processes_bound": True,
    "regression": {"completed": new + reused, "fresh": new, "reused": reused, "total": 408,
                   "closed_modules": len(closed), "remaining_modules": len(remaining),
                   "current_file": snapshot["progress"]["file"], "remaining_hours": remaining_hours,
                   "formula": original["estimate"]["formula"], "active_elapsed_subtracted_seconds": 0},
    "years": years,
    "gpu_samples": snapshot["gpu_samples"],
    "limitations": [
        "Conditional planning estimates, not confidence intervals or release dates.",
        "Recent winter simulation speed need not persist through the full year.",
        "The three jobs run concurrently; their times are not summed.",
        "Fresh compilation, changing load, failures, retries or resource waits can extend estimates.",
        "Spinup, calibration, further modules and v1.0.0 release are excluded.",
    ],
}
output = root / "GPU_ETA_NQ_PO_REFRESH.json"
assert not output.exists()
output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
print(json.dumps({"utc": result["sample_utc"], "gpu": 1, "regression": result["regression"],
                  "years": {name: {key: row[key] for key in ["completed", "requested", "recent_seconds_per_batch_step", "conditional_remaining_hours"]} for name, row in years.items()}}))

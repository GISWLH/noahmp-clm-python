"""Reversible archival of exact inactive frozen source copies; keep all results."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1').resolve();out=b/'source-reclamation-eh';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();q=subprocess.run(['qstat','-u','zhangyq'],capture_output=True,text=True);assert q.returncode==0 and not q.stdout.strip(),q.stdout
(out/'qstat-before.txt').write_text(q.stdout+q.stderr);ps=subprocess.check_output(['ps','-u','zhangyq','-o','pid,args'],text=True);(out/'processes-before.txt').write_text(ps);roots=['p6-first-month-a','p6-hrldas-native-year-a','p6-hrldas-native-year-b','p6-hrldas-suction-binding-a','p6-most-oscillation-a','p6-phase-jacobian-gpu-a','p6-suction-coupled-b','p6-suction-coupled-c','p6-suction-coupled-d','p6-suction-numpy-coupled-a'];rows=[];before=os.statvfs(b).f_favail
for label in roots:
    root=(b/label).resolve();assert root.parent==b and root.name==label and not (b/label).is_symlink();assert str(root)+'/' not in ps,'Named source root has an active ownprocess'
    manifest=root/'SOURCE_SHA256.json';m=json.loads(manifest.read_text());assert len(m)>=400 and all(isinstance(h,str) and len(h)==64 for h in m.values());files=[];valid=True
    for name,digest in m.items():
        relative=PurePosixPath(name);assert not relative.is_absolute() and '..' not in relative.parts
        path=root/name;assert path.resolve().is_relative_to(root) and not path.is_symlink()
        if not path.is_file() or sha(path)!=digest:valid=False;break
        files.append(path)
    if not valid:rows.append(dict(root=label,reclaimed=False,reason='Not all source bytes match manifest; leftentiretreeuntouched'));continue
    archive=out/(label+'-source.tar.gz');assert not archive.exists()
    with tarfile.open(archive,'w:gz') as tf:
        for name in m:tf.add(root/name,arcname=name,recursive=False)
        tf.add(manifest,arcname='SOURCE_SHA256.json',recursive=False)
    with tarfile.open(archive) as tf:
        assert set(tf.getnames())==set(m)|{'SOURCE_SHA256.json'}
        for name,digest in m.items():assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==digest
        assert hashlib.sha256(tf.extractfile('SOURCE_SHA256.json').read()).hexdigest()==sha(manifest)
    archive_sha=sha(archive);check=subprocess.run(['qstat','-u','zhangyq'],capture_output=True,text=True);assert check.returncode==0 and not check.stdout.strip()
    parents=set()
    for path in files:
        assert path.resolve().is_relative_to(root) and sha(path)==m[path.relative_to(root).as_posix()];parents.update(p for p in path.parents if p!=root and p.is_relative_to(root));path.unlink()
    removed_dirs=0
    for directory in sorted(parents,key=lambda p:len(p.parts),reverse=True):
        try:directory.rmdir();removed_dirs+=1
        except OSError:pass
    row=dict(root=label,reclaimed=True,source_files_removed=len(files),empty_source_dirs_removed=removed_dirs,archive=str(archive),archive_sha256=archive_sha,source_manifest_sha256=sha(manifest),scope='Only manifestlisted exactinactive source files removed after fullarchive verification; originalmanifest and every nonmanifest result/checkpoint/log retained. Reversible by extracting thisarchive.');(root/'SOURCE_RECLAIMED_EH.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
    if os.statvfs(b).f_favail>5000:break
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_inodes_before=before,free_inodes_after=os.statvfs(b).f_favail,records=rows,scope='Explicitnamed inactiveNoahmp frozen-source copies only; no runningPBS jobs/ownprocess referencingselectedroots. Backups verifiedeveryrawsourcehash before deletion, no model/state/result/sourcechange or sharedcache deletion. Metadata/archive/filesystem work onlogin only, no numericalphysics.');(out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

from pathlib import Path
import datetime,hashlib,json,os,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'source-reclamation-eh';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert len(d['records'])==10
for q in d['records']:
    assert q['reclaimed'] and sha(Path(q['archive']))==q['archive_sha256'] and q['source_files_removed']>0
    assert (b/q['root']/'SOURCE_SHA256.json').exists() and sha(b/q['root']/'SOURCE_SHA256.json')==q['source_manifest_sha256']
v=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_inodes_later_observation=os.statvfs(b).f_favail,scope='Laterquota refresh observation, not a rewrite of originalreceipt immediate567/567. Only exactinactive namedsource copies reclaimed; verified restorablearchives and manifests remain, allnon-source results/checkpoints/logs preserved.')
(r/'later-observation.json').write_text(json.dumps(v,indent=2)+'\n');items=[(p,'reclamation/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['reclaim_inactive_sources_eh.py',Path(__file__).name]);a=b/'source-reclamation-eq-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),later_observation=v)),flush=True)

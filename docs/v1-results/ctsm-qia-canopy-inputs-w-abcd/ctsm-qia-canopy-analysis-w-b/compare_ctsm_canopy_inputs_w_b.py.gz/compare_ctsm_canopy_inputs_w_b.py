from pathlib import Path
from datetime import datetime,timedelta
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-canopy-analysis-w-b';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'p6-all-phase-final-b-source.tar.gz';assert sha(a)=='1456f86a97f1a744da13d0a1805d3dfa815ef810d4c386799f47ac233b6ffef4'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src'),str(s/'benchmarks')]
from fluxnet_solar import solar_geometry
d=json.loads((b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json').read_text());assert (b/'ctsm-qia-canopy-inputs-w-a/pbs-exit.txt').read_text().strip()=='0'
original=b/'qia-stem-inputs-a/inputs';assert sha(original/'CN-Qia.npz')=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
with np.load(original/'CN-Qia.npz',allow_pickle=False) as z:data={n:np.array(v) for n,v in z.items()}
config=json.loads((original/'CN-Qia-stem-config.json').read_text());stamps=[datetime.strptime(str(v),'%Y%m%d%H%M') for v in data['time_start'][:48]];sw=np.asarray(data['forcing'][:48,5],float);day=sw>1.;assert int(day.sum())==21
field=d['original_S48_history']['fields']
def values(n):
    v=field[n];assert v['masked']==v['nonfinite']==0,n;return np.asarray(v['values'],float).reshape(48)
names=['FSDSVI','FSDSVD','FSDSNI','FSDSND'];split=np.array([values(n) for n in names]).T
fsds=values('FSDS');errors=dict(original_FSDS_vs_native_SW_max_Wm2=float(abs(fsds-sw).max()),four_original_bands_minus_FSDS_max_Wm2=float(abs(split.sum(1)-fsds).max()))
fractions=dict(scope='Radiation fractions are original S histories vs supplied native environment; diagnostic means over all21 SW>1 intervals,not selected byscore.',official_diffuse_fraction_energy_weighted=float(split[day][:,[1,3]].sum()/split[day].sum()),native_diffuse_fraction_energy_weighted=float(np.sum(sw[day]*data['environment'][:48,0][day])/sw[day].sum()),official_visible_fraction_energy_weighted=float(split[day][:,[0,1]].sum()/split[day].sum()),native_visible_fraction=.5,original_split_Wm2=split.tolist(),native_environment=np.asarray(data['environment'][:48],float).tolist())
# Approximate astronomy only: use the already declared NOAA station driver,
# including its local-standard/UTC convention, and its own full-year maximum.
# This is not a measured official DAYL or an exact reconstruction of its orbit.
noon=[datetime(2003,1,1,12)+timedelta(days=k) for k in range(365)]
length=lambda v:solar_geometry(v,config['latitude'],config['longitude'],config['utc_offset_hours'])['daylength_seconds']
annual=np.array([length(v) for v in noon]);first=np.array([length(v+timedelta(minutes=15)) for v in stamps]);factor=np.clip((first/annual.max())**2,.01,1.)
photosyn=json.loads((b/'ctsm-qia-run-s/physiology-restarts.json').read_text());upper=float(photosyn['equation_maximum_vcmax25_without_daylength']);kn=float(np.exp(.00963*upper-2.43));lai=float(config['column']['lai']);profile=(1.-np.exp(-kn*lai))/(kn*lai)
derived=dict(scope='Approximate NOAA-based daylength diagnosis only,not measured official DAYL/max_DAYL or exact orbital reconstruction;existing native solar formula and all365days fixed a priori. Source canopy-N profile analytic average is conditional on top capacity/LAI,not measured canopy photosynthesis or claimed actual nlevcan branch.',daylength_seconds=first.tolist(),maximum_native_NOAA_year_daylength_seconds=float(annual.max()),derived_capacity_daylength_factor=factor.tolist(),daylight_factor_min=float(factor[day].min()),daylight_factor_max=float(factor[day].max()),upper_vcmax25=upper,approximate_daylight_vcmax25_min=upper*float(factor[day].min()),approximate_daylight_vcmax25_max=upper*float(factor[day].max()),source_kn=kn,conditional_exponential_N_mean_factor=profile,native_uniform_profile_factor=1.)
settings=[]
with tarfile.open(b/'ctsm-qia-run-r/case-configuration-private.tar.gz') as t:
    for v in t:
        if v.isfile() and v.name.startswith('output/case/run/') and Path(v.name).name in ['lnd_in','drv_in','datm_in']:
            raw=t.extractfile(v).read();lines=[line.strip() for line in raw.decode().splitlines() if any(w in line.lower() for w in ['co2','nlevcan','orb_','calendar'])];settings.append(dict(path=v.name,sha256=hashlib.sha256(raw).hexdigest(),settings=lines))
availability={n:dict(masked=v.get('masked'),nonfinite=v.get('nonfinite'),shape=v.get('shape')) for n,v in field.items() if n in ['PARVEGLN','LAISUN','LAISHA','GSSUN','GSSHA','GSSUNLN','GSSHALN']}
result=dict(scope='EHPC PBS read-only originalR/S48 vs native inputs; all48 intervals and21 predeclared daylight intervals retained. Optical/Nprofile/daylength/spectral fraction hypotheses only,not changes to production defaults,calibration,scientific pass or official measuredDAYL.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),original_W_diagnosis_sha256=sha(b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json'),errors=errors,radiation_fractions=fractions,conditional_capacity_diagnosis=derived,actual_generated_namelist_settings=settings,original_optional_field_availability=availability)
(r/'diagnosis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());print(json.dumps({k:result[k] for k in ['pbs_job','errors','actual_generated_namelist_settings','original_optional_field_availability']}),flush=True)

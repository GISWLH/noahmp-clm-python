from pathlib import Path
import hashlib,json,re,tarfile
b=Path('/home/zhangyq/noahmp-v1');a=b/'ctsm-reference-source-bundle-a.tar.gz';assert hashlib.sha256(a.read_bytes()).hexdigest()=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6';rows=[]
with tarfile.open(a) as t:
    for m in t:
        if not m.isfile() or not m.name.startswith('CTSM/src/') or not m.name.endswith('.F90'):continue
        raw=t.extractfile(m).read();lines=raw.decode().splitlines();selected=[]
        for i,line in enumerate(lines):
            if m.name.endswith('PhotosynthesisMod.F90') and re.search(r'\bkn\s*\([^)]*\)\s*=|nscaler\s*=|vcmax25\s*=|vcmax25top\s*=|jmax25\s*=|fnps\s*=',line,re.I):selected.append(i)
            if re.search(r'max_dayl[^!]*=|dayl\([^!]*=|dayl_factor[^!]*=|function\s+daylength|subroutine\s+daylength',line,re.I):selected.append(i)
        if selected:rows.append(dict(path=m.name,sha256=hashlib.sha256(raw).hexdigest(),matches=[dict(line=i+1,excerpt='\n'.join(lines[max(0,i-3):min(len(lines),i+7)])) for i in sorted(set(selected))]))
d=dict(scope='Pinned official source read only: locate actual canopy-N scaling and daylength calculation before any independent diagnosis,not runtime measuredDAYL or newphysics/default.',source_bundle_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),rows=rows)
p=b/'ctsm-qia-canopy-inputs-w-a/source-targeted-b.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))

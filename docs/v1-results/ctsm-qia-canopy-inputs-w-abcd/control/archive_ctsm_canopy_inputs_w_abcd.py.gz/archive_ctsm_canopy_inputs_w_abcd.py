from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=[b/'ctsm-qia-canopy-inputs-w-a']+[b/('ctsm-qia-canopy-analysis-w-'+n) for n in ['b','c','d']]
for r in roots:assert (r/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((roots[-1]/'diagnosis.json').read_text());assert d['pbs_job']=='266.manager' and d['source_unchanged']
summary=dict(scope='Original263 NetCDF optical/Nprofile/radiation inventory0. Original264/265 completed0 diagnostics retained as invalidanalysis: BwrongnativeCO2column, Cswappedofficialdirect/diffuse labels. Corrected266 assertsnativecolumn2 metadata and NetCDFlong_names/units;all48intervals/21predeclaredSW>1 retained. No model/default/input/config/calibration edits. ApproximateNOAAdaylfactor not measuredofficialDAYL;conditionalNprofile not actualcanopyGPP. OfficialdiagnosticCO2runtime stillunmeasured;367 isonly buildcommandargument,not claimed measuredforcing.',actual_jobs=['263.manager','264.manager','265.manager','266.manager'],source_manifest_sha256=d['source_manifest_sha256'],original_W_sha256=d['original_W_diagnosis_sha256'],errors=d['errors'],radiation_fraction_summary={k:v for k,v in d['radiation_fractions'].items() if k not in ['native_environment','original_split_Wm2']},conditional_capacity_summary={k:v for k,v in d['conditional_capacity_diagnosis'].items() if k not in ['daylength_seconds','derived_capacity_daylength_factor']})
a=b/'ctsm-qia-canopy-inputs-w-abcd-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for r in roots:
        for p in sorted(r.iterdir()):
            if p.is_file():t.add(p,arcname=r.name+'/'+p.name,recursive=False)
    for n in ['read_ctsm_canopy_sources_w_b.py','archive_ctsm_canopy_inputs_w_abcd.py']:t.add(b/n,arcname='control/'+n,recursive=False)
    raw=(json.dumps(summary,indent=2)+'\n').encode();i=tarfile.TarInfo('summary.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,json,os,re,tarfile
import numpy as np
from netCDF4 import Dataset
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-canopy-inputs-w-a';scratch=Path(os.environ['TMPDIR'])/'canopy-data-w';scratch.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
official=b/'ctsm-qia-run-r';assert (official/'pbs-exit.txt').read_text().strip()=='0'
config=json.loads((official/'configuration.json').read_text());assert config['official_model_returncode']==0 and config['upstream_original_bytes_unchanged']
name='inputdata/clm5_params.c171117.nc'
with tarfile.open(official/'case-configuration-private.tar.gz') as t:
    p=scratch/Path(name).name;p.write_bytes(t.extractfile(name).read())
assert sha(p)=='f255cceecfcdffbd44bc2a4e1fe6777193751baff30688389dd04c56029cbf0f'
traits={}
pattern=re.compile('rhol|rhos|taul|taus|xl|orient|leafcn|slatop|dsladlai|flnr|fnitr|kn|vcmax|jmax|qe|theta|quant|psi|kcn|nscal',re.I)
with Dataset(p) as nc:
    for n,v in nc.variables.items():
        if not pattern.search(n):continue
        a=np.ma.asarray(v[:]);selection='global scalar/array'
        if 'pft' in v.dimensions:
            axis=v.dimensions.index('pft');a=np.take(a,1,axis=axis);selection='original PFT index1; no score-based selection'
        row=dict(units=getattr(v,'units',None),long_name=getattr(v,'long_name',None),dimensions=v.dimensions,selection=selection,shape=a.shape)
        if a.dtype.kind in 'fiu' and a.size<=64:
            mask=np.ma.getmaskarray(a);bad=~np.isfinite(np.ma.getdata(a));row.update(masked=int(mask.sum()),nonfinite=int(bad.sum()),values=np.ma.masked_array(np.ma.getdata(a),mask=mask|bad).tolist())
        else:row['status']='not reduced: nonnumeric or >64'
        traits[n]=row
history={};s=b/'ctsm-qia-run-s';assert (s/'pbs-exit.txt').read_text().strip()=='0'
with tarfile.open(s/'case-configuration-private.tar.gz') as t:
    members=[m for m in t if m.isfile() and '.clm2.h0.' in m.name and m.name.endswith('.nc')];assert len(members)==1
    m=members[0];p=scratch/Path(m.name).name;p.write_bytes(t.extractfile(m).read())
with Dataset(p) as nc:
    all_history_variable_names=list(nc.variables)
    bounds=np.asarray(nc['time_bounds'][:],float)*86400.;take=(bounds[:,0]>=0)&(bounds[:,1]<=86400.);assert take.sum()==48
    candidates=[n for n in nc.variables if re.search('PAR|SUN|SHA|LAI|SAI|VCM|GPP|FPSN|FSA|FSR|FSDS|ALB|BTRAN',n,re.I)]
    for n in candidates:
        v=nc[n];a=np.ma.asarray(v[:]);row=dict(units=getattr(v,'units',None),long_name=getattr(v,'long_name',None),dimensions=v.dimensions)
        if v.dimensions and v.dimensions[0]=='time':a=a[take]
        if a.dtype.kind in 'fiu' and a.size<=256:
            mask=np.ma.getmaskarray(a);bad=~np.isfinite(np.ma.getdata(a));row.update(shape=a.shape,masked=int(mask.sum()),nonfinite=int(bad.sum()),values=np.ma.masked_array(np.ma.getdata(a),mask=mask|bad).tolist())
        else:row.update(shape=a.shape,status='not reduced: nonnumeric or >256')
        history[n]=row
history_file=dict(path=m.name,sha256=sha(p),fields=history,all_variable_names=all_history_variable_names)
a=b/'ctsm-reference-source-bundle-a.tar.gz';assert sha(a)=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
sources=[]
with tarfile.open(a) as t:
    for m in t:
        if not m.isfile() or not m.name.startswith('CTSM/src/') or not re.search('Photosynthesis|CanopyFluxes|SurfaceAlbedo|SurfaceRadiation',m.name) or not m.name.endswith('.F90'):continue
        raw=t.extractfile(m).read();lines=raw.decode().splitlines();indices=[i for i,l in enumerate(lines) if re.search(r'kn\b|kn_\w+|nscal|nscal\w+|vcmax25\w*\s*=|rhol\b|taul\b|rhos\b|taus\b|dsladlai|slatop|fnps',l,re.I)]
        sources.append(dict(path=m.name,sha256=hashlib.sha256(raw).hexdigest(),matched_lines=len(indices),excerpts=[dict(line=i+1,text='\n'.join(lines[max(i-2,0):min(i+4,len(lines))])) for i in indices[:30]],remaining_matched_lines=[i+1 for i in indices[30:]]))
record=dict(scope='Read-only originalR/S PFT1 optical/Nprofile/quantum parameters and available S48 radiation/photosynthesis histories; pinned source structure only, no official/model/input/config/window edits or default selection. Absent diagnostics remain unmeasured. CPU numerical/NetCDF work only EHPC PBS;not scientific validation.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,parameter_sha256='f255cceecfcdffbd44bc2a4e1fe6777193751baff30688389dd04c56029cbf0f',traits=traits,original_S48_history=history_file,pinned_source_excerpts=sources)
(r/'diagnosis.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pbs_job=record['pbs_job'],traits=list(traits),history_fields=list(history),source_files=[x['path'] for x in sources])),flush=True)

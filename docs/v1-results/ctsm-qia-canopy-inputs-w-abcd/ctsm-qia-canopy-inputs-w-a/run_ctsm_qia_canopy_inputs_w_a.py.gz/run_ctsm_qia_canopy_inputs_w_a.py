from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile
import time

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-canopy-inputs-w-a'
scratch = Path(os.environ['TMPDIR']) / 'canopy-portable-w-a'
scratch.mkdir()
archive = b / 'ctsm-portable-env-b.tar.gz'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(archive) == '6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(archive) as t:
    t.extractall(scratch, filter='data')
env = os.environ.copy()
for name in ['PYTHONPATH', 'PYTHONHOME', 'LD_LIBRARY_PATH']:
    env.pop(name, None)
env.update(PATH=str(scratch / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(scratch / 'lib'),
           PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
stages = []
for name, command in [('relocate', [str(scratch / 'bin/python'), str(scratch / 'bin/conda-unpack')]),
                      ('diagnosis', [str(scratch / 'bin/python'), str(r / 'inspect_ctsm_qia_canopy_inputs_w_a.py')])]:
    start = time.monotonic()
    p = subprocess.run(command, env=env, cwd=r, text=True, capture_output=True, timeout=180)
    (r / (name + '.stdout.txt')).write_text(p.stdout)
    (r / (name + '.stderr.txt')).write_text(p.stderr)
    stages.append(dict(stage=name, returncode=p.returncode, seconds=time.monotonic() - start))
    assert p.returncode == 0, p.stderr
receipt = dict(scope='EHPC PBS original R/S PFT optical/Nprofile/quantum input readback and pinned-source structure;all masks retained,no physical/config/default edits,not science pass.',
               pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, stages=stages, diagnosis_sha256=sha(r / 'diagnosis.json'))
(r / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)

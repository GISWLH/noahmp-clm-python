from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'snow-candidate-component-me';tmp=Path(os.environ['TMPDIR']);device=tmp/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((b/'snow-candidate-md-component-export.json').read_text());a=b/package['archive'];assert sha(a)==package['sha256']
with tarfile.open(a) as tf:tf.extractall(device,filter='data')
meta=json.loads((device/'candidate.json').read_text());parent=json.loads((device/'PARENT_SOURCE_SHA256.json').read_text());derived=json.loads((device/'CANDIDATE_SHA256.json').read_text());patch=json.loads((device/'patch.json').read_text());assert sha(device/'CANDIDATE_SHA256.json')==meta['derived_manifest_sha256']==package['derived_manifest_sha256'] and sha(device/'PARENT_SOURCE_SHA256.json')==meta['parent_manifest_sha256']==patch['parent_source_manifest_sha256'];changed=[n for n in parent if parent[n]!=derived[n]];assert set(changed)==set(patch['changes']) and len(changed)==2 and len(parent)==len(derived)==581
for n,d in patch['changes'].items():assert d['before_sha256']==parent[n] and hashlib.sha256(d['after_text'].encode()).hexdigest()==d['after_sha256']==derived[n]
for job in ['1533.manager','1534.manager']:
    q=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);(r/(job+'-actual-qstat.txt')).write_text(q)
baseline=tmp/'baseline';baseline.mkdir()
with tarfile.open(b/'snow-arithmetic-mb-export.tar.gz') as tf:tf.extractall(baseline,filter='data')
assert sha(baseline/'reference.npz')==sha(device/'reference.npz')==meta['reference_sha256'];refmeta=json.loads((device/'reference-receipt.json').read_text());assert refmeta['passed'] and refmeta['reference_sha256']==meta['reference_sha256'];exit=json.loads((device/'component-exit.json').read_text());assert exit['passed'] and len(exit['records'])==3;started=time.monotonic()
with np.load(device/'reference.npz',allow_pickle=False) as z:ref=z['decimal80_represented_branch'];physical=z['decimal80_physical_branch']
golden=ref[:,8].astype(np.float32);values={};checks=[]
for name in ['cuda','jax-x64','jax-default32']:
    parent_exit=next(x for x in exit['records'] if x['backend']==name);receipt=json.loads((device/('component-'+name+'-receipt.json')).read_text());assert parent_exit['passed'] and parent_exit['actual_parent_returncode']==0 and sha(device/('component-'+name+'-receipt.json'))==parent_exit['receipt_sha256'] and receipt['failure'] is None and receipt['candidate_source_unchanged'] and receipt['device_barrier_complete'] and receipt['derived_manifest_sha256']==meta['derived_manifest_sha256'] and sha(device/('component-'+name+'-results.npz'))==receipt['output_sha256']
    with np.load(device/('component-'+name+'-results.npz'),allow_pickle=False) as z:fields=dict(z)
    density=fields['fresh_density'];assert density.shape==(6099,) and density.dtype==np.dtype('float32') and density.tobytes()==golden.tobytes();base_name='cuda' if name=='cuda' else 'jax'
    with np.load(baseline/(base_name+'-results.npz'),allow_pickle=False) as z:
        for key,value in fields.items():
            if key=='fresh_density' or key.startswith('direct-helper'):continue
            old=z['production-'+key];assert value.dtype==old.dtype and value.shape==old.shape and value.tobytes()==old.tobytes(),(name,key)
    check=dict(backend=name,all6099_density_nearest_decimal80_float32=True,all_other_original_module_fields_byteexact=True,maximum_density_absolute_error_kgm3=float(abs(density.astype(float)-ref[:,8]).max()),maximum_density_relative_percent=float((100*abs(density.astype(float)-ref[:,8])/abs(ref[:,8])).max()))
    if name.startswith('jax'):
        wanted=name=='jax-x64';assert receipt['jax_x64_flag_after_component']==wanted;assert fields['direct-helper32'].dtype==np.dtype('float32') and fields['direct-helper32'][:,0].tobytes()==golden.tobytes() and fields['direct-helper32'][:,1].tobytes()==fields['fresh_radius'].tobytes();check['external_x64_flag_restored']=True
        if wanted:
            value=fields['direct-helper64'];assert value.shape==(6099,2) and value.dtype==np.dtype('float64');np.testing.assert_allclose(value[:,0],physical[:,8],rtol=1e-12,atol=1e-10);np.testing.assert_allclose(value[:,1],physical[:,9],rtol=1e-12,atol=1e-10);check['maximum_float64_density_error_kgm3']=float(abs(value[:,0]-physical[:,8]).max());check['maximum_float64_radius_error_um']=float(abs(value[:,1]-physical[:,9]).max())
    checks.append(check);values[name]=fields
assert values['cuda']['fresh_density'].tobytes()==values['jax-x64']['fresh_density'].tobytes()==values['jax-default32']['fresh_density'].tobytes()
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,seconds=time.monotonic()-started,parent_manifest_sha256=meta['parent_manifest_sha256'],derived_manifest_sha256=meta['derived_manifest_sha256'],device_export_sha256=sha(a),reference_sha256=meta['reference_sha256'],changed_source_files=changed,checks=checks,scope='PrivateMD component6099 actualreference verification, alloriginalnon-density modulefields byteexact, allnewfloat32 densitynearestDecimal80 andcrossbackend exact, JAXexternalX64off/on preserved andtruefloat64reference. Originalparent581/derived581/only2changedfiles bound. Authorizes originalinput whole-step probe only; no productionpromotion/fullK78/science/release acceptance.')
(r/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

"""Independent Decimal80/NumPy reference before fresh-snow arithmetic probes."""
from pathlib import Path
from decimal import Decimal,localcontext
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'snow-arithmetic-reference-ma';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src')]
from noahmp_clm.physics.snow_evolution import fresh_snow_properties
with tarfile.open(b/'k78-joint-ku-cuda32-export.tar.gz') as tf:raw=tf.extractfile('input.npz').read()
assert hashlib.sha256(raw).hexdigest()=='957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
import io
with np.load(io.BytesIO(raw),allow_pickle=False) as z:forcing=z['forcing']
original=np.column_stack((forcing[:,1]-np.float32(273.15),forcing[:,3])).astype(np.float32)
t=np.unique(np.r_[np.linspace(-123.14999,56.84999,61,dtype=np.float32),np.array([-60.,-30.,-15.,0.,2.,30.],np.float32),*[np.array([np.nextafter(np.float32(x),np.float32(-np.inf)),np.float32(x),np.nextafter(np.float32(x),np.float32(np.inf))]) for x in [-15.,2.]]]);u=np.unique(np.r_[np.linspace(0.,25.,49,dtype=np.float32),np.array([0.,.1,1.,5.,10.,25.,100.,1000.],np.float32),np.nextafter(np.float32(.1),np.float32(0.)),np.nextafter(np.float32(.1),np.float32(np.inf))]);tt,uu=np.meshgrid(t,u,indexing='ij');grid=np.column_stack((tt.ravel(),uu.ravel()));rng=np.random.default_rng(210325);random=np.column_stack((rng.uniform(-123.149,56.849,2048),rng.uniform(0.,100.,2048))).astype(np.float32);inputs=np.vstack((original,grid,random));assert inputs.dtype==np.float32 and np.isfinite(inputs).all();started=time.monotonic();reference=[];physical=[]
def high(offset,wind,represented_branch):
    D=Decimal
    with localcontext() as ctx:
        ctx.prec=80;t=D.from_float(float(offset));u=D.from_float(float(wind));x=max(min(t,D(2))+D(15),D(0));power=x*x.sqrt();thermal=D(50)+D('1.7')*power if t>D(-15) else -D('3.833')*t-D('.0333')*t*t;w=u/D(5);exponential=(D(2)*w).exp();hyper=(exponential-D(1))/(exponential+D(1));base=(D(1)+hyper)/D(2);loadpow=(D('8.8')*base.ln()).exp();limit=D.from_float(float(np.float32(.1))) if represented_branch else D('.1');load=D('266.861')*loadpow if u>limit else D(0);density=min(max(thermal+load,D(30)),D(917));radius=D('54.5')+D(5)*min(max(t+D(30),D(0)),D(30));return [float(v) for v in [x,power,thermal,w,hyper,base,loadpow,load,density,radius]]
for offset,wind in inputs:reference.append(high(offset,wind,True));physical.append(high(offset,wind,False))
reference=np.asarray(reference);physical=np.asarray(physical);density,radius=fresh_snow_properties(273.15+inputs[:,0].astype(float),inputs[:,1].astype(float));error=np.abs(density-physical[:,8]);assert error.max()<1e-9 and np.max(abs(radius-physical[:,9]))<1e-9;np.savez_compressed(r/'reference.npz',inputs=inputs,decimal80_represented_branch=reference,decimal80_physical_branch=physical,numpy_physical_density=density,numpy_physical_radius=radius,original_forcing=forcing)
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),cases=len(inputs),original_k78_cases=4,grid_cases=len(grid),random_cases=len(random),reference_fields=['thermal_base','thermal_power1p5','thermal','wind_over5','tanh','loading_base','loading_power8p8','loading','density','radius'],maximum_numpy_physical_density_error_kgm3=float(error.max()),maximum_numpy_physical_radius_error_um=float(abs(radius-physical[:,9]).max()),represented_threshold_wind_ms=float(np.float32(.1)),physical_threshold_wind_ms=.1,represented_vs_physical_branch_difference_count=int(np.count_nonzero(reference[:,8]!=physical[:,8])),reference_sha256=sha(r/'reference.npz'),seconds=time.monotonic()-started,scope='OriginalJN NumPy formula plus separatelywritten Decimal80, exactquantizedinput and separatelyreported representedfloat32 .1 branch/physicaldecimal .1 branch. Fixedfullvalidator temperature domain, thresholdadjacencies, winds0to1000 andseededrandom grid beforeGPU, no K78-only fitting/source/gate change or scientific/wholecolumn acceptance.')
(r/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);assert out['source_unchanged']

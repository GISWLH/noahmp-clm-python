"""Static private-candidate editing from the exact frozen JN archive."""
from pathlib import Path
import hashlib,json,re,tarfile
r=Path(__file__).resolve().parent
names=['src/noahmp_clm/gpu/snow_evolution.py','src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu']
with tarfile.open(r/'clm-ballberry-jn-source.tar.gz') as tf:
    parent=json.loads(tf.extractfile('SOURCE_SHA256.json').read());raw={n:tf.extractfile(n).read() for n in names}
old={n:v.decode('utf-8').replace('\r\n','\n') for n,v in raw.items()}
jax_text='''def fresh_snow_jax(offset,wind):
    import jax
    import jax.numpy as j
    from jax import lax
    s=lax.optimization_barrier
    offset=j.asarray(offset);dtype=offset.dtype;wind=j.asarray(wind,dtype=dtype)
    active_wind=wind>j.asarray(.1,dtype=dtype)
    radius=s(54.5+s(5.*j.clip(s(offset+30.),0.,30.)))
    # Evaluate this analytic density in double before rounding to the state
    # precision. Float32 tanh differences otherwise perturb snow geometry.
    # The local context preserves callers with the default X64 flag disabled.
    context=getattr(jax,'enable_x64',None)
    if context is None:
        from jax.experimental import enable_x64 as context
    with context():
        t=offset.astype(j.float64);u=wind.astype(j.float64)
        thermal=j.where(offset>-15.,s(50.+s(1.7*j.power(j.maximum(s(j.minimum(t,2.)+15.),0.),1.5))),
            s(s(-3.833*t)-s(s(.0333*t)*t)))
        loading=j.where(active_wind,s(266.861*j.power(s(s(1.+j.tanh(u/5.))/2.),8.8)),0.)
        density=j.clip(s(thermal+loading),30.,917.).astype(dtype)
        return j.stack((density,radius))
'''
cuda_text='''__device__ void snow_fresh_properties(float offset,float wind,float* out) {
    // Local double evaluation rounds the analytic density once to the state
    // precision; float tanh differences must not perturb new-snow geometry.
    double t=(double)offset,u=(double)wind;
    double thermal=offset>-15.f?50.+1.7*pow(fmax(fmin(t,2.)+15.,0.),1.5):
        (-3.833*t)-(.0333*t)*t;
    double loading=wind>.1f?266.861*pow((1.+tanh(u/5.))/2.,8.8):0.;
    out[0]=(float)fmin(917.,fmax(30.,thermal+loading));
    out[1]=54.5f+5.f*fminf(30.f,fmaxf(0.f,offset+30.f));
}
'''
changed={names[0]:re.sub(r'def fresh_snow_jax\(offset,wind\):.*?(?=\n\ndef snow_evolution_kernel_jax)',jax_text,old[names[0]],flags=re.S),names[1]:re.sub(r'__device__ void snow_fresh_properties\(float offset,float wind,float\* out\) \{.*?\n\}',cuda_text.rstrip(),old[names[1]],count=1,flags=re.S)}
changes={}
for name,text in changed.items():
    assert text!=old[name] and hashlib.sha256(raw[name]).hexdigest()==parent[name]
    p=r/'snow-candidate-md'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8',newline='\n');changes[name]=dict(before_sha256=parent[name],after_sha256=hashlib.sha256(text.encode()).hexdigest(),after_text=text)
out=dict(parent_source_manifest_sha256='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5',changes=changes,reference_job='1533.manager',independent_probe_audit_job='1534.manager',text_line_endings_normalized_from_crlf_to_lf=True,scope='PRIVATE twofile candidate only. Analyticfreshdensity localdouble evaluation, originalrepresentedfloat32 branchmask/radius/returnedstateprecision. NumPy/Decimal80 first6099 reference, MB/MC firstdifference tanh andall64nearest32 evidence. Production/liveyears/current407/source untouched. Component X64on/off andfulloriginalK78/independentbudgets stillrequired.')
(r/'snow-candidate-md-patch.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print({n:v['after_sha256'] for n,v in changes.items()})

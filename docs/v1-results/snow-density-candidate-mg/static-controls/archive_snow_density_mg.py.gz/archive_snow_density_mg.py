from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');payload={};sha=lambda raw:hashlib.sha256(raw).hexdigest();completed=[]
for name,job,receipt in [('snow-arithmetic-reference-ma','1533.manager','receipt.json'),('snow-arithmetic-audit-mc','1534.manager','audit.json'),('snow-candidate-component-me','1535.manager','audit.json'),('snow-candidate-k78-mf','1538.manager','audit.json')]:
    root=b/name;status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M) and (root/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((root/receipt).read_text());assert d['passed'];dispatch=json.loads((root/'dispatch.json').read_text());assert dispatch['pbs_job']==job and all(sha((root/n).read_bytes())==h for n,h in dispatch['controls_sha256'].items())
    for p in sorted(root.iterdir()):
        if p.is_file():payload[name+'/'+p.name]=p.read_bytes()
    payload[name+'/actual-pbs-qstat.txt']=status.encode();completed.append(dict(root=name,pbs_job=job,actual_exit=0))
for name,digest in [('snow-arithmetic-mb-export.tar.gz','fec08d63b2476c5fe660a90c3f91a9fd5cb2f93179fc911952c66788b42f4fb8'),('snow-candidate-md-component-export.tar.gz','fe97d35111a803248005b5490388c2c75adc50998cca0054eeb019990497bb20'),('snow-candidate-md-whole-export.tar.gz','ddb1b6dbe22694901cfd3c3d943d3e56ab761d0d92630f348e5bd0d88616ae51')]:
    raw=(b/name).read_bytes();assert sha(raw)==digest;payload['device/'+name]=raw
for name in ['prepare_snow_patch_md.py','prepare_snow_audit_mf.py',Path(__file__).name]:payload['static-controls/'+name]=(b/name).read_bytes()
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=completed,parent_source_manifest_sha256='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5',private_derived_manifest_sha256='5118b142c11de8e788a2eaf452e067e435337510bc371d3c9db8bb0d4bbe805b',static_reference_control_python='3.11; starredsubscript rejected by initial Ruff default3.10 parse, explicitpy311 F821 passed. Production minimumPython untouched.',scope='NumPy/Decimal806099 first1533F0; MB/MC originalmodule fidelity6099 andtanhfirstdifference1534F0; privateMD2GPUfiles localdouble density, ME1535F0 all6099nearest32/defaultX64off-on/f64ref/othermodulefields byteexact; bothwholeGPU actual0 thenMF1538F0 strictall329/16before/integer/float32/1e-6 andoriginalMHCN/fiveimpurity: maximumrawdifference0. Privatecandidateonly, productioncurrent407/source/year unchanged. CurrentJN12case year separatelyfailedat2657, notfixed/resumed/acceptedbyK78proof. No fullsuite/annual/SOC/observation/releasepass.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();a=b/'snow-density-candidate-mg-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for n,raw in sorted(payload.items()):member=tarfile.TarInfo(n);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(a) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
out=dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'snow-density-candidate-mg-package.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

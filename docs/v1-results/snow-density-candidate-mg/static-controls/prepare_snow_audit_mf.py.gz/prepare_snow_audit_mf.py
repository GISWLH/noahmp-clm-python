"""Static adaptation of the original KF all-field and conservation auditor."""
from pathlib import Path
r=Path(__file__).resolve().parent;text=(r/'audit_k78_kf.py').read_text(encoding='utf-8')
changes={
"r = b / 'k78-current-kf'":"r = b / 'snow-candidate-k78-mf'",
"packet = b / 'k78-corrected-js-device-export.tar.gz'":"packet = b / 'snow-candidate-md-whole-export.tar.gz'",
"t.extractall(r / 'device', filter='data')":"t.extractall(Path(os.environ['TMPDIR']) / 'device', filter='data')",
"d = r / 'device'":"d = Path(os.environ['TMPDIR']) / 'device'",
"assert (d / 'SOURCE_SHA256.json').read_bytes() == (s / 'SOURCE_SHA256.json').read_bytes()":'''assert (d / 'PARENT_SOURCE_SHA256.json').read_bytes() == (s / 'SOURCE_SHA256.json').read_bytes()
candidate = json.loads((d/'candidate.json').read_text())
derived = json.loads((d/'CANDIDATE_SHA256.json').read_text())
patch = json.loads((d/'patch.json').read_text())
assert sha(d/'CANDIDATE_SHA256.json') == candidate['derived_manifest_sha256'] == metadata['derived_manifest_sha256']
assert candidate['parent_manifest_sha256'] == sha(s/'SOURCE_SHA256.json')
assert len(derived)==len(m)==581 and set(derived)==set(m)
assert {n for n in m if m[n]!=derived[n]} == set(patch['changes']) and len(patch['changes'])==2
for n,change in patch['changes'].items():
    assert change['before_sha256']==m[n] and hashlib.sha256(change['after_text'].encode()).hexdigest()==change['after_sha256']==derived[n]
original = b/'k78-corrected-js-device-export.tar.gz'
assert sha(original)=='c669ab766e826dd668852d5b80b5a9226ecccaaa6a777836878642b99c9ccdc1'
with tarfile.open(original) as baseline:
    assert baseline.extractfile('binding.json').read() == (d/'binding.json').read_bytes()
    assert baseline.extractfile('input.npz').read() == (d/'input.npz').read_bytes()
ack=json.loads((d/'component-audit-ack.json').read_text())
assert ack['passed'] and ack['actual_pbs_exit']==0 and ack['derived_manifest_sha256']==candidate['derived_manifest_sha256']
import subprocess
status=subprocess.check_output(['qstat','-xf','1535.manager'],text=True)
assert re.search(r'^\\s*job_state = F\\s*$',status,re.M) and re.search(r'^\\s*Exit_status = 0\\s*$',status,re.M)
(r/'component-actual-pbs-qstat.txt').write_text(status)''',
"(d / (name + '-exit.json'))":"(d / ('whole-' + name + '-exit.json'))",
"exit['actual_returncode'] == 0 and receipt['failure'] is None and receipt['source_unchanged']":"exit['actual_parent_returncode'] == 0 and receipt['failure'] is None and receipt['candidate_source_unchanged'] and receipt['derived_manifest_sha256']==candidate['derived_manifest_sha256']",
"exports[name] = fields":"assert len(fields)==345\n    exports[name] = fields",
"failed = [v for v in rows if not v['passed']]":"failed = [v for v in rows if not v['passed']]\nassert len(rows)==345 and len(model_rows)==329",
"scope='Actual currentJN581 original K78 whole-step replay on xuanze,then independent original production MHCN/impurity audit and every raw output/next16 field rtol=atol1e-6,int exact,float32/dtype validation on EHPC PBS. Primary/shadow original16 inputs independently verified exact. No original failed trajectory advancement or source/physics/gate change; not full-suite/year/science acceptance.'":"scope='PRIVATE MD twofilefreshdensity candidate originalK78 whole-step, afterME1535actualreference0. Independent unchangedoriginalJN NumPy budgets and strictall329model/next plus16originalbefore arrays, rtol=atol1e-6/int/dtype/float32 andalloriginalMHCN/fiveimpuritygates. Originalinput andleafbinding exacttoimmutableJSexport. No failedtrajectory/source/production/gate/M1 edit or fullsuite/year/scientific/release acceptance.'",
"source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=":"independent_reference_parent_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), executed_gpu_derived_manifest_sha256=candidate['derived_manifest_sha256'], changed_gpu_source_files=list(patch['changes']), original_binding_sha256=sha(d/'binding.json'), source_unchanged="
}
for before,after in changes.items():
    assert text.count(before)==1,(before,text.count(before));text=text.replace(before,after)
(r/'audit_snow_k78_mf.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared original all345/int/float32/1e-6 and MHCN/impurity auditor with private twofile identity and exact originalbinding guards.')

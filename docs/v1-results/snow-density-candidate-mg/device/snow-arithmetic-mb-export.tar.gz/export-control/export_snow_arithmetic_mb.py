from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'snow-arithmetic-probe-mb';sha=lambda raw:hashlib.sha256(raw).hexdigest();d=json.loads((r/'exit.json').read_text());assert d['passed'] and len(d['records'])==2 and all(x['passed'] and x['actual_parent_returncode']==0 for x in d['records'])
for row in d['records']:
    name=row['backend'];raw=(r/(name+'-receipt.json')).read_bytes();assert sha(raw)==row['receipt_sha256'];v=json.loads(raw);assert v['source_unchanged'] and v['device_barrier_complete'] and v['failure'] is None and sha((r/(name+'-results.npz')).read_bytes())==v['output_sha256']
payload={p.name:p.read_bytes() for p in r.iterdir() if p.is_file()};payload['export-control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/'snow-arithmetic-mb-export.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for n,raw in sorted(payload.items()):m=tarfile.TarInfo(n);m.size=len(raw);tf.addfile(m,io.BytesIO(raw))
with tarfile.open(a) as tf:
    assert len(tf.getmembers())==len(payload)
    for m in tf:assert tf.extractfile(m).read()==payload[m.name]
out=dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(payload),scope='MB actualbothGPUparent0 andbarriers, originalJN sourceunchanged. Original6099productionmodule plusarithmeticvariants exports, independentMApreparedfirst. No EHPCfidelity/causality/candidateapproval or production/K78/sciencepass yet.');(b/'snow-arithmetic-mb-export.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

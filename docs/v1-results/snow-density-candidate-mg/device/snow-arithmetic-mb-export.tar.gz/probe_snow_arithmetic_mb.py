"""Original production fresh snow plus explicit arithmetic candidates, GPU only."""
from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');r=b/'snow-arithmetic-probe-mb';s=Path('/tmp/noahmp-k78-corrected-js/source');name=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert name in ['cuda','jax'] and len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src')];ref=json.loads((r/'reference-receipt.json').read_text());assert ref['passed'] and ref['source_unchanged'] and ref['source_manifest_sha256']==manifest and sha(r/'reference.npz')==ref['reference_sha256']
with np.load(r/'reference.npz',allow_pickle=False) as z:inputs=z['inputs']
n=len(inputs);assert n==ref['cases']==6099;c=np.zeros((n,5,9),np.float32);c[:,:,3]=54.5;o=np.zeros((n,5),np.int32);u=np.zeros((n,23),np.float32);u[:,21:]=inputs;start=time.monotonic();failure=None;barrier=False
try:
    if name=='cuda':
        import cupy as cp
        from noahmp_clm.gpu.cuda.snow_evolution import run_snow_evolution_cuda
        original={k:cp.asnumpy(v) for k,v in run_snow_evolution_cuda(c,o,u).items()}
        source='\n'.join((s/'src/noahmp_clm/gpu/cuda'/v).read_text() for v in ['snow_mass_kernel.cu','snow_evolution_kernel.cu'])
        source+='''
extern "C" __global__ void snow_arithmetic_probe(const float* in,float* out,int count) {
 for(int i=blockIdx.x*blockDim.x+threadIdx.x;i<count;i+=blockDim.x*gridDim.x) {
  float t=in[2*i],w=in[2*i+1];float* v=out+15*i;
  float x=fmaxf(fminf(t,2.f)+15.f,0.f),p=powf(x,1.5f);
  float thermal=t>-15.f?50.f+1.7f*p:(-3.833f*t)-(.0333f*t)*t;
  float wd=w/5.f,h=tanhf(wd),base=(1.f+h)/2.f,lp=powf(base,8.8f),load=w>.1f?266.861f*lp:0.f;
  float raw[2];snow_fresh_properties(t,w,raw);
  v[0]=x;v[1]=p;v[2]=thermal;v[3]=wd;v[4]=h;v[5]=base;v[6]=lp;v[7]=load;v[8]=fminf(917.f,fmaxf(30.f,thermal+load));v[9]=raw[1];v[10]=raw[0];v[11]=raw[1];
  float sq=x*sqrtf(x),st=t>-15.f?50.f+1.7f*sq:(-3.833f*t)-(.0333f*t)*t;v[12]=fminf(917.f,fmaxf(30.f,st+load));
  double dt=(double)t,dw=(double)w,dx=fmax(fmin(dt,2.)+15.,0.);double dth=t>-15.f?50.+1.7*pow(dx,1.5):(-3.833*dt)-(.0333*dt)*dt;
  v[13]=fminf(917.f,fmaxf(30.f,(float)dth+load));double dl=w>.1f?266.861*pow((1.+tanh(dw/5.))/2.,8.8):0.;v[14]=(float)fmin(917.,fmax(30.,dth+dl));
 }
}
'''
        kernel=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('snow_arithmetic_probe',)).get_function('snow_arithmetic_probe');raw=cp.empty((n,15),cp.float32);kernel((min((n+63)//64,4096),),(64,),(cp.asarray(inputs),raw,np.int32(n)));details=cp.asnumpy(raw);cp.cuda.runtime.deviceSynchronize();barrier=True
    else:
        import jax
        import jax.numpy as j
        from jax import lax
        from noahmp_clm.gpu.snow_evolution import run_snow_evolution_jax,fresh_snow_jax
        assert jax.config.jax_enable_x64 and jax.default_backend()=='gpu'
        original={k:np.asarray(v) for k,v in run_snow_evolution_jax(c,o,u).items()};stop=lax.optimization_barrier
        def detail(t,w):
            x=j.maximum(stop(j.minimum(t,2.)+15.),0.);p=j.power(x,1.5);thermal=j.where(t>-15.,stop(50.+stop(1.7*p)),stop(stop(-3.833*t)-stop(stop(.0333*t)*t)));wd=w/5.;h=j.tanh(wd);base=stop(stop(1.+h)/2.);lp=j.power(base,8.8);load=j.where(w>.1,stop(266.861*lp),0.);density=j.clip(stop(thermal+load),30.,917.);raw=fresh_snow_jax(t,w);sq=stop(x*j.sqrt(x));st=j.where(t>-15.,stop(50.+stop(1.7*sq)),stop(stop(-3.833*t)-stop(stop(.0333*t)*t)));variant_sqrt=j.clip(stop(st+load),30.,917.);dt,dw=t.astype(j.float64),w.astype(j.float64);dx=j.maximum(stop(j.minimum(dt,2.)+15.),0.);dth=j.where(t>-15.,stop(50.+stop(1.7*j.power(dx,1.5))),stop(stop(-3.833*dt)-stop(stop(.0333*dt)*dt)));variant_thermal64=j.clip(stop(dth.astype(j.float32)+load),30.,917.);dl=j.where(w>.1,stop(266.861*j.power(stop(stop(1.+j.tanh(dw/5.))/2.),8.8)),0.);variant_all64=j.clip(stop(dth+dl),30.,917.).astype(j.float32);return j.stack((x,p,thermal,wd,h,base,lp,load,density,raw[1],raw[0],raw[1],variant_sqrt,variant_thermal64,variant_all64))
        result=jax.jit(jax.vmap(detail))(j.asarray(inputs[:,0]),j.asarray(inputs[:,1]));result.block_until_ready();details=np.asarray(result);jax.effects_barrier();barrier=True
    np.savez_compressed(r/(name+'-results.npz'),details=details,**{'production-'+k:v for k,v in original.items()})
except Exception as e:failure=type(e).__name__+': '+str(e);(r/(name+'-traceback.txt')).write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(backend=name,failure=failure,source_unchanged=unchanged,source_manifest_sha256=manifest,device_barrier_complete=barrier,cases=n,reference_sha256=sha(r/'reference.npz'),output_sha256=sha(r/(name+'-results.npz')) if (r/(name+'-results.npz')).exists() else None,seconds=time.monotonic()-start,scope='OriginalproductionJN snowevolution plus separatelyexportedexplicitformula parts andthree arithmeticcandidates, originalfloat32 inputs/branchmask. Candidates sqrt32/thermal64/all64 onlyprobe, noproduction edit or fullcolumn/K78/scientific acceptance. EHPCmustfirstverify debugdensitymatchesoriginalproduction beforeoperand conclusions. No NumPyforwardphysics onxuanze.')
(r/(name+'-receipt.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barrier else 1)

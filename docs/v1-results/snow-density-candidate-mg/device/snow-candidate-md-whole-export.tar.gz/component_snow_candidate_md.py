from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
r=Path(__file__).resolve().parent;meta=json.loads((r/'candidate.json').read_text());s=Path(meta['source']);name=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((r/'CANDIDATE_SHA256.json').read_text());assert name in ['cuda','jax-x64','jax-default32'] and all(sha(s/n)==h for n,h in m.items()) and sha(r/'reference.npz')==meta['reference_sha256'];sys.path[:0]=[str(s),str(s/'src')]
with np.load(r/'reference.npz',allow_pickle=False) as z:inputs=z['inputs']
n=len(inputs);assert n==6099;c=np.zeros((n,5,9),np.float32);c[:,:,3]=54.5;o=np.zeros((n,5),np.int32);u=np.zeros((n,23),np.float32);u[:,21:]=inputs;start=time.monotonic();failure=None;barrier=False;flag=None
try:
    if name=='cuda':
        import cupy as cp
        from noahmp_clm.gpu.cuda.snow_evolution import run_snow_evolution_cuda
        result={k:cp.asnumpy(v) for k,v in run_snow_evolution_cuda(c,o,u).items()};cp.cuda.runtime.deviceSynchronize();barrier=True
    else:
        import jax
        import jax.numpy as j
        from noahmp_clm.gpu.snow_evolution import run_snow_evolution_jax,fresh_snow_jax
        wanted=name=='jax-x64';jax.config.update('jax_enable_x64',wanted);assert jax.default_backend()=='gpu'
        result={k:np.asarray(v) for k,v in run_snow_evolution_jax(c,o,u).items()};flag=bool(jax.config.jax_enable_x64);assert flag==wanted
        direct=jax.jit(jax.vmap(fresh_snow_jax))(j.asarray(inputs[:,0]),j.asarray(inputs[:,1]));direct.block_until_ready();result['direct-helper32']=np.asarray(direct);assert bool(jax.config.jax_enable_x64)==wanted
        if wanted:
            direct64=jax.jit(jax.vmap(fresh_snow_jax))(j.asarray(inputs[:,0],j.float64),j.asarray(inputs[:,1],j.float64));direct64.block_until_ready();result['direct-helper64']=np.asarray(direct64)
        jax.effects_barrier();barrier=True
    np.savez_compressed(r/('component-'+name+'-results.npz'),**result)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/('component-'+name+'-traceback.txt')).write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(backend=name,failure=failure,candidate_source_unchanged=unchanged,parent_manifest_sha256=meta['parent_manifest_sha256'],derived_manifest_sha256=meta['derived_manifest_sha256'],device_barrier_complete=barrier,jax_x64_flag_after_component=flag,cases=n,reference_sha256=sha(r/'reference.npz'),output_sha256=sha(r/('component-'+name+'-results.npz')) if (r/('component-'+name+'-results.npz')).exists() else None,seconds=time.monotonic()-start,scope='PrivateMD twofilecandidate originalmodule6099 outputs, JAXglobalflag on/off anddirect64 inputs. Localdoubledensity mustroundback tooriginalstateprecision andrestoreexternalflag. Compute0 isnotreference/K78/production/scientific acceptance; MEindependentactual0 requiredbeforewhole-step.')
(r/('component-'+name+'-receipt.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barrier else 1)

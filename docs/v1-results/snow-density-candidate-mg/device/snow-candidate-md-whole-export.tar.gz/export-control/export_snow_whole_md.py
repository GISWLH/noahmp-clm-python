from pathlib import Path
import hashlib,io,json,tarfile
r=Path('/home/lhwang/work/noahmp-v1/snow-candidate-md');b=r.parent;sha=lambda raw:hashlib.sha256(raw).hexdigest();exit=json.loads((r/'exit.json').read_text());assert exit['passed'] and len(exit['records'])==5 and all(x['passed'] and x['actual_parent_returncode']==0 for x in exit['records']);meta=json.loads((r/'candidate.json').read_text());s=Path(meta['source']);m=json.loads((r/'CANDIDATE_SHA256.json').read_text());assert sha((r/'CANDIDATE_SHA256.json').read_bytes())==meta['derived_manifest_sha256'] and all(sha((s/n).read_bytes())==h for n,h in m.items())
for name in ['cuda32','jax32']:
    row=next(x for x in exit['records'] if x['stage']=='whole' and x['backend']==name);raw=(r/name/'receipt.json').read_bytes();assert sha(raw)==row['receipt_sha256'];receipt=json.loads(raw);assert receipt['failure'] is None and receipt['candidate_source_unchanged'] and receipt['device_barriers'] and sha((r/name/'output.npz').read_bytes())==receipt['result']['output_sha256']
payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()};payload['export-control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/'snow-candidate-md-whole-export.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for n,raw in sorted(payload.items()):member=tarfile.TarInfo(n);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(a) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
out=dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(payload),derived_manifest_sha256=meta['derived_manifest_sha256'],scope='PrivateMD bothoriginalK78 wholecomputations actualparent0/345raw/barriers afterME1535actual0. Allsource/input/patch/controls/actualcomponent/wholeexits kept. Originalsameprecision/MHCN/impurity gates stillrequire independentMF, no productionpromotion/scientific/release pass.');(b/'snow-candidate-md-whole-export.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

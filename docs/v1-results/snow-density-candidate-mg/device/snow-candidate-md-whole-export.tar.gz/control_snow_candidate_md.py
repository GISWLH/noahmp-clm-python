from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
def run(stage,name,script):
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:break
        time.sleep(20.)
    label=stage+'-'+name
    with (r/(label+'-worker.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/script),name],stdout=log,stderr=subprocess.STDOUT)
    (r/(label+'-worker.json')).write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();q=r/('component-'+name+'-receipt.json') if stage=='component' else r/name/'receipt.json';d=json.loads(q.read_text()) if q.exists() else {};v=dict(stage=stage,backend=name,actual_parent_returncode=code,passed=bool(code==0 and d.get('failure') is None and d.get('candidate_source_unchanged') and (d.get('device_barrier_complete') or d.get('device_barriers'))),receipt_sha256=sha(q) if q.exists() else None);(r/(label+'-exit.json')).write_text(json.dumps(v,indent=2)+'\n');records.append(v);assert v['passed'],label
for name in ['cuda','jax-x64','jax-default32']:run('component',name,'component_snow_candidate_md.py')
(r/'component-exit.json').write_text(json.dumps(dict(records=records,passed=True),indent=2)+'\n')
while not (r/'component-audit-ack.json').exists():time.sleep(20.)
ack=json.loads((r/'component-audit-ack.json').read_text());meta=json.loads((r/'candidate.json').read_text());assert ack['passed'] and ack['actual_pbs_exit']==0 and ack['derived_manifest_sha256']==meta['derived_manifest_sha256']
for name in ['cuda32','jax32']:run('whole',name,'replay_snow_candidate_md.py')
(r/'exit.json').write_text(json.dumps(dict(records=records,passed=True),indent=2)+'\n')

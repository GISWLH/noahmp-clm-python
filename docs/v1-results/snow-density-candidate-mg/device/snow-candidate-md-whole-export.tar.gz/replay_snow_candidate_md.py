from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
r=Path(__file__).resolve().parent;meta=json.loads((r/'candidate.json').read_text());s=Path(meta['source']);name=sys.argv[1];out=r/name;out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((r/'CANDIDATE_SHA256.json').read_text());assert name in ['cuda32','jax32'] and all(sha(s/n)==h for n,h in m.items()) and sha(r/'input.npz')==meta['original_k78_input_sha256'];ack=json.loads((r/'component-audit-ack.json').read_text());assert ack['passed'] and ack['actual_pbs_exit']==0 and ack['derived_manifest_sha256']==meta['derived_manifest_sha256'];sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as driver
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
binding=json.loads((r/'binding.json').read_text());backend=driver.Backend(name);prefix='a' if name=='cuda32' else 'shadow';devices=tuple(backend.xp.asarray(np.ascontiguousarray(data[prefix+str(k)])) for k in range(16));devices=backend.update_forcing(devices,data['environment']);before=tuple(backend.host(v) for v in devices);kwargs=dict(environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']),return_surface=True);start=time.monotonic();failure=None;barriers=[];result_metadata=None
try:
    result_device=backend.step(*devices,data['forcing'],**kwargs);result=backend.host(result_device);after=tuple(backend.host(v) for v in driver.next_bgc_arrays(devices,result_device));flat={}
    def flatten(value,path=''):
        for key,item in value.items():
            if isinstance(item,dict):flatten(item,path+key+'/')
            else:flat[path+key]=np.asarray(item)
    flatten(result);flat.update({'next'+str(k):v for k,v in enumerate(after)});flat.update({'before'+str(k):v for k,v in enumerate(before)});assert len(flat)==345;np.savez_compressed(out/'output.npz',**flat)
    if name=='cuda32':backend.xp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
    else:
        import jax
        jax.effects_barrier();barriers.append('jax-complete')
    result_metadata=dict(original_raw_fields=345,output_sha256=sha(out/'output.npz'))
except Exception as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(backend=name,failure=failure,result=result_metadata,candidate_source_unchanged=unchanged,parent_manifest_sha256=meta['parent_manifest_sha256'],derived_manifest_sha256=meta['derived_manifest_sha256'],input_sha256=sha(r/'input.npz'),device_barriers=barriers,seconds=time.monotonic()-start,scope='PRIVATE MD originalK78 whole-step onunchanged input afterME6099actualreference0. Onlyfreshdensity evaluation2files differ, no drop/round/exportfilter/input/gate/M1/production/liveyear changes. ActualEHPC originalall329sameprecision/16before/budget audit stillrequired, not productionfix or scientific/releasepass.')
(out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barriers else 1)

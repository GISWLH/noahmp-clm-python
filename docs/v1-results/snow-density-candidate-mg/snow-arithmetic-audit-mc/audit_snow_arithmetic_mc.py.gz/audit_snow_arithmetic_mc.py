from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'snow-arithmetic-audit-mc';tmp=Path(os.environ['TMPDIR'])/'device';tmp.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((b/'snow-arithmetic-mb-export.json').read_text());a=b/package['archive'];assert sha(a)==package['sha256']
with tarfile.open(a) as tf:tf.extractall(tmp,filter='data')
q=subprocess.check_output(['qstat','-xf','1533.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);(r/'reference-actual-qstat.txt').write_text(q);reference=json.loads((tmp/'reference-receipt.json').read_text());assert reference['passed'] and reference['source_unchanged'] and sha(tmp/'reference.npz')==reference['reference_sha256'];exit=json.loads((tmp/'exit.json').read_text());assert exit['passed'] and len(exit['records'])==2;started=time.monotonic()
with np.load(tmp/'reference.npz',allow_pickle=False) as z:inputs=z['inputs'];ref=z['decimal80_represented_branch'];physical=z['decimal80_physical_branch']
values={};fidelity=[]
for name in ['cuda','jax']:
    parent=next(x for x in exit['records'] if x['backend']==name);d=json.loads((tmp/(name+'-receipt.json')).read_text());assert parent['actual_parent_returncode']==0 and parent['passed'] and sha(tmp/(name+'-receipt.json'))==parent['receipt_sha256'] and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and sha(tmp/(name+'-results.npz'))==d['output_sha256'] and d['reference_sha256']==reference['reference_sha256']
    with np.load(tmp/(name+'-results.npz'),allow_pickle=False) as z:raw=z['details'];original=z['production-fresh_density'];radius=z['production-fresh_radius']
    assert raw.shape==(6099,15) and raw.dtype==original.dtype==radius.dtype==np.dtype('float32') and np.isfinite(raw).all();direct=raw[:,10].tobytes()==original.tobytes() and raw[:,11].tobytes()==radius.tobytes();decomposed=raw[:,8].tobytes()==original.tobytes() and raw[:,9].tobytes()==radius.tobytes();fidelity.append(dict(backend=name,direct_original_helper_matches_production_module=direct,explicit_arithmetic_matches_production_density_and_radius=decomposed,explicit_density_mismatch_count=int(np.count_nonzero(raw[:,8].view(np.uint32)!=original.view(np.uint32)))));values[name]=raw
variants=[];golden=ref[:,8].astype(np.float32);same_threshold=ref[:,8]==physical[:,8]
for label,k in [('original',10),('sqrt32',12),('thermal64',13),('all64',14)]:
    x,y=values['cuda'][:,k],values['jax'][:,k];backend=[]
    for name,v in [('cuda',x),('jax',y)]:
        error=np.abs(v.astype(float)-ref[:,8]);physical_error=np.abs(v.astype(float)-physical[:,8]);assert np.all(error<=.1*np.abs(ref[:,8]));backend.append(dict(backend=name,maximum_density_error_kgm3=float(error.max()),maximum_density_relative_percent=float((100*error/abs(ref[:,8])).max()),maximum_physical_density_relative_percent=float((100*physical_error/abs(physical[:,8])).max()),maximum_same_branch_density_error_kgm3=float(error[same_threshold].max()),nearest_decimal80_float32_mismatch_count=int(np.count_nonzero(v.view(np.uint32)!=golden.view(np.uint32))),k78_density_kgm3=v[:4].tolist(),k78_nearest_decimal80_float32=(v[:4].view(np.uint32)==golden[:4].view(np.uint32)).tolist()))
    variants.append(dict(variant=label,cuda_jax_bitwise_mismatch_count=int(np.count_nonzero(x.view(np.uint32)!=y.view(np.uint32))),maximum_backend_absolute_difference_kgm3=float(np.max(abs(x.astype(float)-y.astype(float)))),backends=backend))
parts=reference['reference_fields'];k78=[]
for row in range(4):
    different=[]
    for k in range(10):
        x,y=values['cuda'][row,k],values['jax'][row,k]
        if x.tobytes()!=y.tobytes():different.append(dict(field=parts[k],cuda=float(x),jax=float(y),decimal80=float(ref[row,k]),absolute_backend_difference=abs(float(x)-float(y))))
    k78.append(dict(column=row,offset_k=float(inputs[row,0]),wind_ms=float(inputs[row,1]),different_formula_parts=different))
passed=all(x['direct_original_helper_matches_production_module'] and x['explicit_arithmetic_matches_production_density_and_radius'] for x in fidelity);out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=passed,source_manifest_sha256=reference['source_manifest_sha256'],device_export_sha256=sha(a),reference_sha256=reference['reference_sha256'],cases=len(inputs),fidelity=fidelity,k78_parts=k78,variants=variants,seconds=time.monotonic()-started,scope='IndependentMC actualoriginal6099module/helper/decomposition fidelity beforeinterpretingparts. NumPy/Decimal80 independentlyprecededGPU. Candidatecomparison fullfixedgrid/random, representedbranch andphysicalthreshold bothreported, no observationalfit/caseonlychoice or production/input/gate/source edit. Evenfidelity/candidate0 isnot originalfullK78/scientific/releasepass; wholejointgeometry causalproof remainsLW.')
(r/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);raise SystemExit(0 if passed else 1)

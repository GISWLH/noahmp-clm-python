from pathlib import Path
import hashlib,inspect,json,os,time,traceback
import numpy as np
from test_gpu_clm_bgc_column import reference
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
root=Path.cwd();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in m.items())
path=root/'i4016-whole-inputs.npz';assert sha(path)=='f7ddec083458d4b4ca88effc7b00c0aed8714b2276cb559498118db027b774f3'
with np.load(path,allow_pickle=False) as z:v=dict(z)
leaf=json.loads((root.parent/'fluxnet-first-climate-cycle-20261017-h/inputs/CN-Qia-config.json').read_text())['leaf_parameters'];assert leaf==vars(LeafParameters())
import noahmp_clm.physics.canopy_most as most_module
source=inspect.getsource(most_module.solve_surface_most)
source=source.replace('previous=None;history=[]','previous=None;history=[];relaxation=.5;previous_stability_residual=None;previous_mismatch=None')
marker='        previous=dict('
added='''        stability_residual=target['zeta']-zeta
        if previous_stability_residual is not None and not stable_bracket and mismatch>1e-4:
            if stability_residual*previous_stability_residual<0. and mismatch>previous_mismatch:
                relaxation=max(.0625,.5*relaxation)
        previous_stability_residual=stability_residual;previous_mismatch=mismatch
'''
assert marker in source
source=source.replace(marker,added+marker)
old="zeta=.5*(zeta+target['zeta']);effective=.5*(effective+target['effective_wind'])"
new="zeta=(.5*(zeta+target['zeta']) if relaxation==.5 else zeta+relaxation*(target['zeta']-zeta));effective=(.5*(effective+target['effective_wind']) if relaxation==.5 else effective+relaxation*(target['effective_wind']-effective))"
assert old in source;source=source.replace(old,new)
(root/'numpy-adaptive-candidate.py').write_text(source)
namespace=most_module.__dict__.copy();exec(compile(source,str(root/'numpy-adaptive-candidate.py'),'exec'),namespace)
most_module.solve_surface_most=namespace['solve_surface_most']
a=[v[f'a{k}'].copy() for k in range(16)];a[4][:,7:10]=v['forcing_environment'];rows=[];begin=time.monotonic()
for k,site in enumerate(['CN-Cng','CN-Qia','CN-Cha','CN-HaM']):
    started=time.monotonic();row=dict(site=site)
    try:
        out=reference(tuple(x[k] for x in a),v['forcing'][k],v['deposition'][k],v['environment'][k],v['calendar'][k],v['nitrogen'][k],1.,most_geometry=MOSTGeometry(*map(float,v['geometry'][k])))
        d=out['diagnostics'];row.update(status='complete',h=d['h'],le=d['le'],most=d['most'])
    except Exception:row.update(status='failed',failure=traceback.format_exc())
    row['seconds']=time.monotonic()-started;rows.append(row);print(json.dumps(row),flush=True)
assert all(sha(root/k)==v for k,v in m.items())
(root/'i4016-numpy-adaptive.json').write_text(json.dumps(dict(scope='Isolated adaptive NumPy candidate on original I4016 whole inputs; 50 iterations and all original tolerances, no production adoption or parameter changes.',node=os.uname().nodename,pbs_job=os.environ['PBS_JOBID'],source_unchanged=True,seconds=time.monotonic()-begin,rows=rows),indent=2)+'\n')

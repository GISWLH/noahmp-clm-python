def solve_surface_most(solve_surface,exchange,wind,geometry,*,leaf_dimension=.04,
                       plant_area=3.,time_step,max_iterations=50):
    """Iterate transfer with H/E from a pure, fixed-old-state surface solve.

    ``solve_surface(exchange)`` returns snow, soil, canopy mass, diagnostics.
    Every trial starts from the SAME old extensive stores. Only the final
    converged trial is committed; precipitation/unloading must stay outside
    this iteration. A failed iteration raises without advancing any store.
    """
    from dataclasses import replace
    import numpy as np
    if not isinstance(max_iterations,int) or max_iterations<2:
        raise ValueError('MOST requires at least two surface solves')
    if not math.isfinite(time_step) or time_step<=0:raise ValueError('Positive MOST time step required')
    zeta=0.;effective=max(1.,float(wind));previous=None;history=[];relaxation=.5;previous_stability_residual=None;previous_mismatch=None
    stable_bracket=False;lower=0.;upper=2.;bisection_restarts=0
    theta=exchange.air_temperature+.0098*geometry.temperature_height
    for iteration in range(1,max_iterations+1):
        velocities=canopy_exchange(zeta,effective,geometry,leaf_dimension=leaf_dimension,plant_area=plant_area)
        boundary=replace(exchange,atmosphere_velocity=velocities['heat_velocity'],
            atmosphere_water_velocity=velocities['water_velocity'],potential_temperature=theta,
            leaf_velocity=velocities['leaf_velocity'],ground_velocity=velocities['ground_velocity'])
        result=solve_surface(boundary);d=result[-1]
        vapor=float(d['et_kgm2']/time_step)
        target=flux_stability(exchange.air_temperature,exchange.specific_humidity,exchange.pressure,
            wind,float(d['h']),vapor,velocities['friction_velocity'],geometry)
        updated=canopy_exchange(target['zeta'],target['effective_wind'],geometry,
            leaf_dimension=leaf_dimension,plant_area=plant_area)
        mismatch=max(abs(updated[k]-velocities[k])/velocities[k] for k in
            ('friction_velocity','heat_velocity','water_velocity','leaf_velocity','ground_velocity'))
        history.append(dict(zeta=zeta,effective_wind=effective,h=float(d['h']),water_vapor=vapor,
                            target_zeta=target['zeta'],coefficient_residual=mismatch))
        if iteration==1:stable_bracket=target['zeta']>0.
        if previous is not None:
            dh=abs(d['h']-previous['h']);de=abs(vapor-previous['vapor'])
            dt=float(np.max(abs(d['leaf_temperature']-previous['temperature']),initial=0.))
            if mismatch<=1e-4 and dh<=.05 and de<=2e-8 and dt<=.01:
                d['most']=dict(**velocities,**target,used_zeta=zeta,used_effective_wind=effective,
                    iterations=iteration,coefficient_residual=mismatch,heat_change_wm2=float(dh),
                    vapor_change_kgm2s=float(de),leaf_temperature_change_k=dt,history=history)
                d['most']['bisection_restarts']=bisection_restarts
                return result
        stability_residual=target['zeta']-zeta
        if previous_stability_residual is not None and not stable_bracket and mismatch>1e-4:
            if stability_residual*previous_stability_residual<0. and mismatch>previous_mismatch:
                relaxation=max(.0625,.5*relaxation)
        previous_stability_residual=stability_residual;previous_mismatch=mismatch
        previous=dict(h=float(d['h']),vapor=vapor,temperature=np.array(d['leaf_temperature'],copy=True))
        if stable_bracket:
            # At the neutral trial F=target-zeta > 0; at zeta=2, F<=0
            # by the physical envelope. Stable buoyancy has no convective
            # wind, so this is a scalar root at the prescribed effective
            # wind. Bisection avoids the near-unit Picard slope in calm,
            # strongly stable columns. Every bracket trial retains old M/H.
            if target['zeta']>=zeta:lower=zeta
            else:upper=zeta
            midpoint=.5*(lower+upper)
            if midpoint==zeta:
                # An inner-solver discontinuity may exhaust the representable
                # bracket. Resume damped feedback; all acceptance tests above
                # and the original iteration budget still apply.
                stable_bracket=False;bisection_restarts+=1
            else:zeta=midpoint
        if not stable_bracket:
            zeta=(.5*(zeta+target['zeta']) if relaxation==.5 else zeta+relaxation*(target['zeta']-zeta));effective=(.5*(effective+target['effective_wind']) if relaxation==.5 else effective+relaxation*(target['effective_wind']-effective))
    raise RuntimeError(f'MOST flux feedback did not converge in {max_iterations} iterations; '
                       f'coefficient residual={mismatch:.9g}, zeta={zeta:.9g}')

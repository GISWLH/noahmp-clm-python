from pathlib import Path
import hashlib
import json
import os
import pickle
import sys
import tarfile
import time

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-stem-numpy-163-b'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-stem-assessment-a-source.tar.gz'
assert sha(a) == '214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s / 'src')]
import numpy as np
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-stem-numpy-163-a'
record = json.loads((old / 'probe.json').read_text())
assert (old / 'pbs-exit.txt').read_text().strip() == '0' and sha(old / 'failed-phase-call.pkl') == record['captured_call_sha256']
call = pickle.loads((old / 'failed-phase-call.pkl').read_bytes())
real = phase.solve_canopy_phase_energy
captured = {}

def trace(frame, event, arg):
    if frame.f_code is not real.__code__:
        return None
    if event == 'exception':
        captured.update(evaluate=frame.f_locals['evaluate'], x=frame.f_locals['x'].copy(), stale_residual=frame.f_locals['residual'].copy(), iteration=frame.f_locals['iteration'], tolerance=frame.f_locals['tolerance'], max_iterations=frame.f_locals['max_iterations'])
    return trace

failure = None
start = time.monotonic()
try:
    sys.settrace(trace)
    real(*call['args'], **call['kwargs'])
except RuntimeError as e:
    failure = str(e)
finally:
    sys.settrace(None)
assert failure and 'Canopy phase energy did not converge' in failure
actual = captured['evaluate'](captured['x'], True)
old_condensate = call['args'][4]
dt = call['args'][5]
water = actual['condensate'].mass - old_condensate.mass + dt * actual['wet_evaporation']
energy = actual['rnet'] - actual['h'] - actual['le'] - actual['ground_heat'] - actual['canopy_storage_change_wm2'] - actual['wet_advected_heat_wm2'] - actual['transpiration_net_heat_wm2']
result = dict(scope='Original captured phase call rerun unchanged/max80/tol1e-7. After original failure only, evaluate final accepted x and independent parcel mass/energy terms; do not return this diagnostic state to original trajectory or change solver source. Tests final-update off-by-one hypothesis only.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, original_failure=failure,
              source_unchanged=all(sha(s / n) == v for n, v in manifest.items()), captured_call_sha256=sha(old / 'failed-phase-call.pkl'),
              iteration=captured['iteration'], max_iterations=captured['max_iterations'], tolerance=captured['tolerance'],
              stale_residual_maximum=float(abs(captured['stale_residual']).max()),
              final_solver_residual=actual['solver_residual'].tolist(), final_solver_residual_maximum=float(abs(actual['solver_residual']).max()),
              final_parcel_energy_residual_maximum_Wm2=float(abs(actual['layer_residual']).max()),
              reconstructed_column_energy_residual_Wm2=float(energy), maximum_reconstructed_layer_water_residual_kgm2=float(abs(water).max()),
              canopy_air_water_residual_kgm2s=float(actual['air_water_residual']),
              final_x=captured['x'].tolist(), seconds=time.monotonic() - start)
(r / 'probe.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(result, allow_nan=False), flush=True)
assert result['source_unchanged'] and result['final_solver_residual_maximum'] <= captured['tolerance']
assert result['final_parcel_energy_residual_maximum_Wm2'] <= captured['tolerance'] * 1.01

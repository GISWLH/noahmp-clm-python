from pathlib import Path
import hashlib
import inspect
import json
import os
import pickle
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-stem-numpy-163-a'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
s = scratch / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-stem-assessment-a-source.tar.gz'
assert sha(a) == '214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 506 and all(sha(s / n) == h for n, h in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s), str(s / 'src'), str(s / 'benchmarks')]
import numpy as np
import run_fluxnet_column as original
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-stem-numpy-week-a'
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert receipt['returncode'] == 1 and receipt['source_unchanged'] and report['steps_completed'] == report['failed_index'] == 163
assert sha(old / 'trajectory/report.json') == receipt['report_sha256']
assert sha(old / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
assert json.loads((old / 'SOURCE_SHA256.json').read_text()) == manifest
state, initial, net, bounds, maximum, stepmax, index = pickle.loads((old / 'trajectory' / report['checkpoint_file']).read_bytes())
assert index == 163
inputs = b / 'qia-stem-inputs-a/inputs'
protocol = json.loads((inputs.parent / 'protocol.json').read_text())
assert all(sha(inputs / n) == h for n, h in protocol['inputs_sha256'].items())
config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
metadata = json.loads((inputs / 'CN-Qia.json').read_text())
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    data = dict(z)
stamps = original.validate_input(data, metadata, inputs / 'CN-Qia.npz')
f = original.Forcing(*data['forcing'][index])
co2, mu, diffuse = data['environment'][index]
environment = original.calendar(stamps[index], metadata, config['phenology'] is not None)
schedule = original.DepositionSchedule(config)
dep = schedule.aerosol(stamps[index], f.dt)
nitrogen = schedule.nitrogen_rate * f.dt
geometry = original.MOSTGeometry(**config['most_geometry'])
leaf = original.LeafParameters(**config['leaf_parameters'])
real = phase.solve_canopy_phase_energy
records, last = [], {}
signature = inspect.signature(real)

def numeric(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value

def trace_call(frame, event, arg):
    if frame.f_code is not real.__code__:
        return None
    if event == 'line' and frame.f_lineno == 202:
        v = frame.f_locals
        records.append(dict(iteration=v['iteration'], maximum_residual=float(np.max(abs(v['residual']))), residual=v['residual'].tolist(), x=v['x'].tolist(), phase_active=v['phase_active'].tolist(), restarts=v['restarts']))
    if event == 'exception':
        v = frame.f_locals
        for n in ['x', 'residual', 'jac', 'delta', 'phase_active', 'mass', 'active', 'lower', 'upper', 'restarts', 'iteration', 'tolerance', 'max_iterations', 'norm', 'chosen_norm', 'backtrack', 'accepted', 'shortwave']:
            if n in v:
                last[n] = numeric(v[n])
    return trace_call

def wrapped(*args, **kwargs):
    records.clear()
    try:
        sys.settrace(trace_call)
        return real(*args, **kwargs)
    except Exception:
        bound = signature.bind(*args, **kwargs)
        bound.apply_defaults()
        (r / 'failed-phase-call.pkl').write_bytes(pickle.dumps(dict(args=args, kwargs=kwargs)))
        last['arguments_summary'] = {n: numeric(bound.arguments[n]) for n in ['leaf_area', 'stem_area', 'swdown', 'lwdown', 'dt', 'fixed_ground_temperature', 'tolerance', 'max_iterations', 'cosine_zenith', 'diffuse_fraction']}
        raise
    finally:
        sys.settrace(None)

phase.solve_canopy_phase_energy = wrapped
failure = None
start = time.monotonic()
try:
    original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (r / 'traceback.txt').write_text(traceback.format_exc())
finally:
    phase.solve_canopy_phase_energy = real
    sys.settrace(None)
unchanged = all(sha(s / n) == h for n, h in manifest.items())
assert unchanged
record = dict(scope='Original failed NumPy163 exact next-step replay on EHPC PBS, unchanged506 source/checkpoint/forcing/solver controls. sys.settrace observes only outer phase-Newton locals; no mathematical values or return behavior changed. Original failure required,not a physics pass. Actual failing phase-call arguments retained for bounded independent probes.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, failure=failure, source_unchanged=unchanged, failed_index=index, forcing_time_start=str(data['time_start'][index]), original_failed_report_sha256=sha(old / 'trajectory/report.json'), original_failed_checkpoint_sha256=report['checkpoint_sha256'], iterations=records, last=last, seconds=time.monotonic() - start, captured_call_sha256=sha(r / 'failed-phase-call.pkl') if (r / 'failed-phase-call.pkl').exists() else None)
(r / 'probe.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(failure=failure, source_unchanged=unchanged, iterations=len(records), last_maximum_residual=records[-1]['maximum_residual'] if records else None, seconds=record['seconds'])), flush=True)
assert failure is not None and 'Canopy phase energy did not converge' in failure

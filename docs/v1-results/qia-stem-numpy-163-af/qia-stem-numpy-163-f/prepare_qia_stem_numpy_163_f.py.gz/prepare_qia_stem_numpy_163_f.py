from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'probe_qia_stem_numpy_163_c.py').read_text().replace('qia-stem-numpy-163-c', 'qia-stem-numpy-163-f')
marker = 'after, d = original.step_clm_enthalpy_column'
assert p.count(marker) == 1
addition = '''# API-only bounded counterfactual, not a production source edit or annual resume.
real_phase = phase.solve_canopy_phase_energy
def budget100(*args, **kwargs):
    assert 'max_iterations' not in kwargs
    return real_phase(*args, **kwargs, max_iterations=100)
phase.solve_canopy_phase_energy = budget100
(r / 'control.json').write_text(json.dumps(dict(scope='Whole-step diagnostic only, source byte unchanged but phase API budget100 replaces original default80. Original tol1e-7 and all independent bounds remain. No production gate/budget edit or original trajectory resume.', original_budget=80, counterfactual_budget=100, original_tolerance=1e-7), indent=2)+'\\n')
'''
p = p.replace(marker, addition + marker)
p = p.replace('Candidate NumPy final-update check only:', 'Counterfactual NumPy final-update check plus explicit phase API budget100 only:')
p = p.replace('same tol1e-7/max80 and exact', 'same tol1e-7, original isolated phase max80 but whole-step phase API max100, exact')
ast.parse(p)
(r / 'probe_qia_stem_numpy_163_f.py').write_bytes(p.encode())
p = (r / 'qia_stem_numpy_163_c.pbs').read_text().replace('qia-stem-numpy-163-c', 'qia-stem-numpy-163-f').replace('probe_qia_stem_numpy_163_c.py', 'probe_qia_stem_numpy_163_f.py').replace('clm-qia-163-fixed-c', 'clm-qia-163-budget-f')
(r / 'qia_stem_numpy_163_f.pbs').write_bytes(p.encode())

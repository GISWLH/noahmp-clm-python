from pathlib import Path
import hashlib
import inspect
import json
import os
import pickle
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-stem-numpy-163-f'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
s = scratch / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-phase-final-check-a-source.tar.gz'
assert sha(a) == '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 506 and all(sha(s / n) == h for n, h in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s), str(s / 'src'), str(s / 'benchmarks')]
import numpy as np
import run_fluxnet_column as original
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-stem-numpy-week-a'
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert receipt['returncode'] == 1 and receipt['source_unchanged'] and report['steps_completed'] == report['failed_index'] == 163
assert sha(old / 'trajectory/report.json') == receipt['report_sha256']
assert sha(old / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
old_manifest = json.loads((old / 'SOURCE_SHA256.json').read_text())
assert [n for n in manifest if n.startswith('src/') and old_manifest[n] != manifest[n]] == ['src/noahmp_clm/physics/canopy_phase_energy.py']
state, initial, net, bounds, maximum, stepmax, index = pickle.loads((old / 'trajectory' / report['checkpoint_file']).read_bytes())
assert index == 163
inputs = b / 'qia-stem-inputs-a/inputs'
protocol = json.loads((inputs.parent / 'protocol.json').read_text())
assert all(sha(inputs / n) == h for n, h in protocol['inputs_sha256'].items())
config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
metadata = json.loads((inputs / 'CN-Qia.json').read_text())
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    data = dict(z)
stamps = original.validate_input(data, metadata, inputs / 'CN-Qia.npz')
f = original.Forcing(*data['forcing'][index])
co2, mu, diffuse = data['environment'][index]
environment = original.calendar(stamps[index], metadata, config['phenology'] is not None)
schedule = original.DepositionSchedule(config)
dep = schedule.aerosol(stamps[index], f.dt)
nitrogen = schedule.nitrogen_rate * f.dt
geometry = original.MOSTGeometry(**config['most_geometry'])
leaf = original.LeafParameters(**config['leaf_parameters'])
start = time.monotonic()
saved = b / 'qia-stem-numpy-163-a/failed-phase-call.pkl'
baseline = json.loads((b / 'qia-stem-numpy-163-b/probe.json').read_text())
assert sha(saved) == baseline['captured_call_sha256']
call = pickle.loads(saved.read_bytes())
isolated = phase.solve_canopy_phase_energy(*call['args'], **call['kwargs'])
assert isolated['iterations'] == 80
assert np.array_equal(isolated['phase_coordinates'], np.asarray(baseline['final_x'][:10]))
assert np.max(abs(isolated['solver_residual'])) <= 1e-7
# API-only bounded counterfactual, not a production source edit or annual resume.
real_phase = phase.solve_canopy_phase_energy
def budget100(*args, **kwargs):
    assert 'max_iterations' not in kwargs
    return real_phase(*args, **kwargs, max_iterations=100)
phase.solve_canopy_phase_energy = budget100
(r / 'control.json').write_text(json.dumps(dict(scope='Whole-step diagnostic only, source byte unchanged but phase API budget100 replaces original default80. Original tol1e-7 and all independent bounds remain. No production gate/budget edit or original trajectory resume.', original_budget=80, counterfactual_budget=100, original_tolerance=1e-7), indent=2)+'\n')
after, d = original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
incoming, residual, bound = original.audit_step(state, after, f, d, nitrogen)
cumulative = original.totals(after) - initial - (net + incoming)
assert np.all(abs(residual) <= bound) and np.all(abs(cumulative) <= bounds + bound)
assert all(sha(s / n) == v for n, v in manifest.items())
(r / 'diagnostic-step164.pkl').write_bytes(pickle.dumps((state, after, f, d)))
record = dict(scope='Counterfactual NumPy final-update check plus explicit phase API budget100 only: same tol1e-7, original isolated phase max80 but whole-step phase API max100, exact frozen failed163 state/forcing. Isolated phase root equals original already accepted final x, then whole physical step audited against original independent MHCN bounds. One-step diagnostic only; original failed trajectory remains unchanged and is not resumed into a changed-source year.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, source_unchanged=True, original_failed_checkpoint_sha256=report['checkpoint_sha256'], source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), step_residual_m_h_c_n=residual.tolist(), step_numerical_bound_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), cumulative_numerical_bound_m_h_c_n=(bounds + bound).tolist(), phase_iterations=isolated['iterations'], phase_max_solver_residual=float(np.max(abs(isolated['solver_residual']))), phase_max_parcel_energy_residual=float(np.max(abs(isolated['layer_residual']))), diagnostics={k: float(d[v]) for k, v in original.TRACE.items()}, diagnostic_state_sha256=sha(r / 'diagnostic-step164.pkl'), seconds=time.monotonic()-start)
(r / 'probe.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
print(json.dumps(record, allow_nan=False), flush=True)

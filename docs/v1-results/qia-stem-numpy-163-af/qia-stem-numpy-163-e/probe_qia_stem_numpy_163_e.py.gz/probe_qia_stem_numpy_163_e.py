from pathlib import Path
import hashlib
import json
import os
import pickle
import sys
import tarfile
import time

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-stem-numpy-163-e'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-phase-final-check-a-source.tar.gz'
assert sha(a) == '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s / 'src')]
import numpy as np
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy

old = b / 'qia-stem-numpy-163-d'
record = json.loads((old / 'probe.json').read_text())
assert (old / 'pbs-exit.txt').read_text().strip() == '0' and sha(old / 'failed-phase-call.pkl') == record['captured_call_sha256']
call = pickle.loads((old / 'failed-phase-call.pkl').read_bytes())
rows = []
for budget in [80, 100, 160]:
    start = time.monotonic()
    kw = dict(call['kwargs'], max_iterations=budget)
    row = dict(declared_update_budget=budget, unchanged_tolerance=kw['tolerance'], scope='Diagnostic only; no production budget/source or original failed trajectory changed.')
    try:
        result = solve_canopy_phase_energy(*call['args'], **kw)
        water = result['condensate'].mass - call['args'][4].mass + call['args'][5] * result['wet_evaporation']
        row.update(returned=True, iterations=result['iterations'], solver_residual_maximum=float(abs(result['solver_residual']).max()), parcel_energy_residual_maximum=float(abs(result['layer_residual']).max()), layer_water_residual_maximum=float(abs(water).max()))
    except RuntimeError as e:
        row.update(returned=False, error=str(e))
    row['seconds'] = time.monotonic() - start
    rows.append(row)
    print(json.dumps(row), flush=True)
assert all(sha(s / n) == v for n, v in manifest.items())
d = dict(scope='Bounded counterfactual solver budget diagnostic for later nested phase failure under frozen final-check candidate. Same physical call/tol1e-7, only explicit API max_iterations80/100/160 inspected; no production gate/budget changes or whole-step/year acceptance.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, source_unchanged=True, captured_call_sha256=record['captured_call_sha256'], rows=rows)
(r / 'probe.json').write_text(json.dumps(d, indent=2, allow_nan=False) + '\n')

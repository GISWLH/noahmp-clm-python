from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'probe_qia_stem_numpy_163_a.py').read_text().split('real = phase.solve_canopy_phase_energy', 1)[0]
p = p.replace('qia-stem-numpy-163-a', 'qia-stem-numpy-163-c').replace('p6-stem-assessment-a-source.tar.gz', 'p6-phase-final-check-a-source.tar.gz').replace('214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5', '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87')
p = p.replace("assert json.loads((old / 'SOURCE_SHA256.json').read_text()) == manifest", "old_manifest = json.loads((old / 'SOURCE_SHA256.json').read_text())\nassert [n for n in manifest if n.startswith('src/') and old_manifest[n] != manifest[n]] == ['src/noahmp_clm/physics/canopy_phase_energy.py']")
p += '''start = time.monotonic()
saved = b / 'qia-stem-numpy-163-a/failed-phase-call.pkl'
baseline = json.loads((b / 'qia-stem-numpy-163-b/probe.json').read_text())
assert sha(saved) == baseline['captured_call_sha256']
call = pickle.loads(saved.read_bytes())
isolated = phase.solve_canopy_phase_energy(*call['args'], **call['kwargs'])
assert isolated['iterations'] == 80
assert np.array_equal(isolated['phase_coordinates'], np.asarray(baseline['final_x'][:10]))
assert np.max(abs(isolated['solver_residual'])) <= 1e-7
after, d = original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
incoming, residual, bound = original.audit_step(state, after, f, d, nitrogen)
cumulative = original.totals(after) - initial - (net + incoming)
assert np.all(abs(residual) <= bound) and np.all(abs(cumulative) <= bounds + bound)
assert all(sha(s / n) == v for n, v in manifest.items())
(r / 'diagnostic-step164.pkl').write_bytes(pickle.dumps((state, after, f, d)))
record = dict(scope='Candidate NumPy final-update check only: same tol1e-7/max80 and exact frozen failed163 state/forcing. Isolated phase root equals original already accepted final x, then whole physical step audited against original independent MHCN bounds. One-step diagnostic only; original failed trajectory remains unchanged and is not resumed into a changed-source year.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, source_unchanged=True, original_failed_checkpoint_sha256=report['checkpoint_sha256'], source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), step_residual_m_h_c_n=residual.tolist(), step_numerical_bound_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), cumulative_numerical_bound_m_h_c_n=(bounds + bound).tolist(), phase_iterations=isolated['iterations'], phase_max_solver_residual=float(np.max(abs(isolated['solver_residual']))), phase_max_parcel_energy_residual=float(np.max(abs(isolated['layer_residual']))), diagnostics={k: float(d[v]) for k, v in original.TRACE.items()}, diagnostic_state_sha256=sha(r / 'diagnostic-step164.pkl'), seconds=time.monotonic()-start)
(r / 'probe.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\\n')
print(json.dumps(record, allow_nan=False), flush=True)
'''
ast.parse(p)
(r / 'probe_qia_stem_numpy_163_c.py').write_bytes(p.encode())
p = (r / 'qia_stem_numpy_163_a.pbs').read_text().replace('qia-stem-numpy-163-a', 'qia-stem-numpy-163-c').replace('probe_qia_stem_numpy_163_a.py', 'probe_qia_stem_numpy_163_c.py').replace('clm-qia-163-probe-a', 'clm-qia-163-fixed-c')
(r / 'qia_stem_numpy_163_c.pbs').write_bytes(p.encode())

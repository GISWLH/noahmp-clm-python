from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'qia-stem-numpy-163-af-evidence.tar.gz'
assert not a.exists()
rows = []
with tarfile.open(a, 'w:gz') as t:
    for letter, code in [('a', 0), ('b', 0), ('c', 1), ('d', 0), ('e', 0), ('f', 1)]:
        r = b / ('qia-stem-numpy-163-' + letter)
        assert (r / 'pbs-exit.txt').read_text().strip() == str(code)
        data = json.loads((r / 'probe.json').read_text()) if (r / 'probe.json').exists() else None
        if data:
            assert data['source_unchanged']
        for p in sorted(r.iterdir()):
            if p.is_file():
                t.add(p, arcname=r.name + '/' + p.name, recursive=False)
        rows.append(dict(case=r.name, actual_pbs_returncode=code, diagnosis=data,
                         model_failure_traceback_retained=(r / 'probe.log').exists()))
    source = b / 'p6-phase-final-check-a-source.tar.gz'
    assert sha(source) == '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87'
    with tarfile.open(source) as frozen:
        for name in ['SOURCE_SHA256.json', 'src/noahmp_clm/physics/canopy_phase_energy.py', 'tests/test_canopy_phase_energy.py']:
            raw = frozen.extractfile(name).read()
            info = tarfile.TarInfo('candidate-source/' + name)
            info.size = len(raw)
            t.addfile(info, io.BytesIO(raw))
    summary = dict(scope='Actual EHPC Qia163 original failure/read-only Newton trace A, original accepted-final-x independent evaluation B, minimal final-check candidate whole-step failure C, later nested-call trace D, bounded80/100/160 diagnostic E, and whole-step100-budget counterfactual failure F. Original year remains failed163. Candidate fixes false final-update failure but whole step is still unresolved; no production tolerance/update-budget/equation/conservation changes and no scientific/annual acceptance.',
                   candidate_source_archive_sha256=sha(source), original_week_archive_sha256='9671ccfeb13e16e47a0a1fb92bc02c415461335f1fe5b0d54a1e0d88bc0fb73c', cases=rows)
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, cases=[dict(case=x['case'], actual_pbs_returncode=x['actual_pbs_returncode']) for x in rows])))

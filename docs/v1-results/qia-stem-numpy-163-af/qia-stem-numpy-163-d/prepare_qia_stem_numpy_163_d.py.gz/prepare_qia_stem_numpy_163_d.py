from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'probe_qia_stem_numpy_163_a.py').read_text()
p = p.replace('qia-stem-numpy-163-a', 'qia-stem-numpy-163-d').replace('p6-stem-assessment-a-source.tar.gz', 'p6-phase-final-check-a-source.tar.gz').replace('214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5', '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87')
p = p.replace("assert json.loads((old / 'SOURCE_SHA256.json').read_text()) == manifest", "old_manifest = json.loads((old / 'SOURCE_SHA256.json').read_text())\nassert [n for n in manifest if n.startswith('src/') and old_manifest[n] != manifest[n]] == ['src/noahmp_clm/physics/canopy_phase_energy.py']")
p = p.replace('Original failed NumPy163 exact next-step replay', 'Candidate with final-update check, original failed NumPy163 exact next-step replay; later nested phase failure retained')
marker = 'real = phase.solve_canopy_phase_energy'
before = '''old_phase = b / 'qia-stem-numpy-163-a/failed-phase-call.pkl'
old_phase_record = json.loads((b / 'qia-stem-numpy-163-b/probe.json').read_text())
assert sha(old_phase) == old_phase_record['captured_call_sha256']
old_call = pickle.loads(old_phase.read_bytes())
isolated = phase.solve_canopy_phase_energy(*old_call['args'], **old_call['kwargs'])
assert isolated['iterations'] == 80 and np.max(abs(isolated['solver_residual'])) <= 1e-7
assert np.array_equal(isolated['phase_coordinates'], np.asarray(old_phase_record['final_x'][:10]))
(r / 'original-phase-root.json').write_text(json.dumps(dict(scope='Only original first phase false failure fixed; this does not establish whole-step success.', iterations=isolated['iterations'], maximum_solver_residual=float(np.max(abs(isolated['solver_residual']))), maximum_parcel_energy_residual=float(np.max(abs(isolated['layer_residual'])))), indent=2)+'\\n')
'''
assert p.count(marker) == 1
p = p.replace(marker, before + marker)
ast.parse(p)
(r / 'probe_qia_stem_numpy_163_d.py').write_bytes(p.encode())
p = (r / 'qia_stem_numpy_163_a.pbs').read_text().replace('qia-stem-numpy-163-a', 'qia-stem-numpy-163-d').replace('probe_qia_stem_numpy_163_a.py', 'probe_qia_stem_numpy_163_d.py').replace('clm-qia-163-probe-a', 'clm-qia-163-probe-d')
(r / 'qia_stem_numpy_163_d.pbs').write_bytes(p.encode())

"""Original JN winter energy attribution diagnostics; no parameter or state edits."""
from pathlib import Path
from dataclasses import fields,is_dataclass
import gzip,hashlib,io,json,os,pickle,re,subprocess,sys,tarfile,time
import numpy as np

assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=Path.cwd();tmp=Path(os.environ['TMPDIR'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
started=time.monotonic()
packs={
 'source':('clm-ballberry-jn-source.tar.gz','44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'),
 'device':('climatology-failed-year-mh-export.tar.gz','f728890bfe81cddae1d85ae2effa69e4eb541b6f1e9ba12b335f90374d098340'),
 'prefix':('climatology-reported-prefix-mq-evidence.tar.gz','7d0b21a36215903acd305e652985852df923c48c73ba3e09ba84e0d33fc0a89b'),
 'reference':('climatology-failure-reference-mi-evidence.tar.gz','ab43480e39005440d4be19bdf1f359d2d634adc9b7c61068a49406f4b0aac436')}
for label,(name,digest) in packs.items():
 a=b/name;assert sha(a)==digest;dest=tmp/label;dest.mkdir()
 with tarfile.open(a) as t:t.extractall(dest,filter='data')
s=tmp/'source';device=tmp/'device';prefix=tmp/'prefix';reference=tmp/'reference'
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json')
assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as runner
import test_gpu_clm_bgc_column as reference_module
import noahmp_clm.clm_enthalpy_driver as driver
from noahmp_clm.physics.energy import SIGMA,LV,RD
from noahmp_clm.physics.snowpack import CI,CW,LF,TF
from noahmp_clm.physics.canopy_energy import _ice_saturation,_saturation

proof={}
for name in ('1537.manager','1541.manager','1542.manager'):
 q=subprocess.check_output(['qstat','-xf',name],text=True)
 assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M)
 proof[name]=q
(r/'prior-pbs-qstat.json').write_text(json.dumps(proof,indent=2)+'\n')
cases=native.load_batch(device/'inputs/batch.json');assert len(cases)==12 and native.native_state_count(cases)==16
evaluation=json.loads((prefix/'receipt.json').read_text());assert evaluation['evaluation_delivered']
assert json.loads((device/'snapshot.json').read_text())['actual_year_parent_returncode']==1
def summary(x):
 x=np.asarray(x,float);return dict(count=int(x.size),mean=float(x.mean()),minimum=float(x.min()),maximum=float(x.max()))
def soil_heat(t,theta,liquid,dz,porosity):
 water=theta*1000.*dz;liq=liquid*1000.*dz
 return ((1.-porosity)*2e6*dz+CI*water+(CW-CI)*liq)*(t-TF)+LF*liq
monthly=[]
for k,c in enumerate(cases):
 folder=device/'reported2640'/c['case'];p=next(folder.glob('report-0002640-*.json'));report=json.loads(p.read_text())
 prior=evaluation['cases'][k];assert prior['case']==c['case'] and sha(p)==prior['original_report_sha256']
 trace_path=folder/report['model_npz'];assert sha(trace_path)==prior['original_trace_sha256']
 with np.load(trace_path,allow_pickle=False) as z:t=dict(z)
 with np.load(folder/report['batch_checkpoint_file'],allow_pickle=False) as z:checkpoint=dict(z)
 assert len(t['time_start'])==2640 and all(str(v)[4:6]=='01' for v in t['time_start'][:1488])
 assert str(t['time_start'][1488])[4:6]=='02'
 config=c['config'];column=config['column'];cold=runner.build_state(config)
 assert native.structure_configuration(config) is None and cold.sai==0.
 f=np.asarray(c['data']['forcing'][:1488],np.float32).astype(float);dt=f[:,0];seconds=float(dt.sum())
 cold_arrays=native.pack_station_arrays([cold],16,dtype=np.float32)
 dz=cold_arrays[1][0,:,2].astype(float);porosity=float(cold_arrays[2][0,0])
 temp=np.asarray(t['tsoil_k'],float);theta=np.asarray(t['smc_m3m3'],float);liq=np.asarray(t['liquid_m3m3'],float)
 enthalpy=soil_heat(temp,theta,liq,dz,porosity)
 check_heat=checkpoint['a1'][k,:,1].astype(float)
 reconstruction_error=float(np.max(abs(enthalpy[-1]-check_heat)))
 cold_heat=cold_arrays[1][0,:,1].astype(float)
 stock_change=enthalpy[1487]-cold_heat
 observed={field:summary(c['data']['obs_'+field][:1488]) for field in ['H_F_MDS','LE_F_MDS']}
 qc={field:{str(v):int(n) for v,n in zip(*np.unique(c['data']['qc_'+field][:1488],return_counts=True))} for field in ['H_F_MDS','LE_F_MDS']}
 before_liq=np.r_[cold.ground.liquid[0]/(1000.*cold.ground.dz[0]),liq[:1487,0]]
 view=cold.parameter_view();resistance=[]
 for value in before_liq:
  view.smc=np.array([value,*cold.smc[1:]])
  resistance.append(driver.ground_resistance(view,config['column']['options']['OptGroundResistanceEvap'],snow_cover=False))
 resistance=np.asarray(resistance)
 leafless=bool(np.all(t['lai'][:1488]==0.));snow_before=np.r_[cold.swe,t['swe_m'][:1487]]
 bare_mask=(snow_before==0.)&(t['swe_m'][:1488]==0.)&(f[:,7]==0.)
 bare_proxy=(1.-column['albedo'])*f[:,5]+column['emiss']*(f[:,6]-SIGMA*temp[:1488,0]**4)
 groups={}
 for label,mask in [('whole_january',np.ones(1488,bool)),('no_snow_before_after_and_zero_precip',bare_mask)]:
  groups[label]=dict(intervals=int(mask.sum()),swdown_wm2=summary(f[mask,5]),lwdown_wm2=summary(f[mask,6]),
   model_h_wm2=summary(t['h_wm2'][:1488][mask]),model_le_wm2=summary(t['le_wm2'][:1488][mask]),
   model_h_plus_le_wm2=summary((t['h_wm2'][:1488]+t['le_wm2'][:1488])[mask]),
   observed_h_plus_le_filled_wm2=summary((c['data']['obs_H_F_MDS'][:1488]+c['data']['obs_LE_F_MDS'][:1488])[mask]),
   snowfree_resistance_from_before_trace_sm=summary(resistance[mask]))
  if leafless:groups[label]['bare_rnet_proxy_using_final_topsoil_temperature_wm2']=summary(bare_proxy[mask])
 row=dict(case=c['case'],site=config['site'],configuration_sha256=sha(c['paths']['configuration']),
  leafless_january=leafless,configured_lai_initial=column['lai'],configured_sai=0.,structure_enabled=False,
  effective_leafless_surface_fveg=0. if leafless else None,retained_most_geometry=config['most_geometry'],
  observed_filled_fluxes=observed,observed_flux_qc_counts=qc,groups=groups,
  soil_heat_storage_change_jm2=stock_change.tolist(),soil_heat_release_month_mean_wm2=-float(stock_change.sum())/seconds,
  reconstructed_heat_check_at_checkpoint2640_max_layer_error_jm2=reconstruction_error,
  scope='All twelve complete January cases. Soil storage reconstructed from original returned T/theta/liquid; not the full column hard budget. Rnet is a bare-ground end-step-temperature proxy, never actual snow/canopy radiation. Explicit snowfree/no-precip subgroup applies the source bare-ground identity and retains all observations, not a score-selected subset. Resistance is source formula on pre-step trace liquid, not proof of each actual trial boundary. No state/parameter change, spinup or scientific pass.')
 monthly.append(row);print(json.dumps(dict(case=c['case'],soil_release=row['soil_heat_release_month_mean_wm2'],leafless=leafless,rs=summary(resistance))),flush=True)

# Replay the exact twelve saved failed-input NumPy reference points only. These
# are February 25 points, not a resumed year or evidence of a January cause.
input_path=reference/'diagnostic-input.npz';binding=json.loads((reference/'binding.json').read_text())
assert sha(input_path)==binding['diagnostic_input_sha256'];mi=json.loads((reference/'receipt.json').read_text());assert mi['passed']
with np.load(input_path,allow_pickle=False) as z:payload=dict(z)
original_resistance=driver.ground_resistance;captured=[]
def recorded_resistance(state,option,**kwargs):
 value=original_resistance(state,option,**kwargs)
 captured.append(dict(option=option,snow_cover=kwargs.get('snow_cover',False),resistance_sm=value,
  top_liquid_m3m3=float(state.smc[0]),top_dz_m=float(state.dz[0]),soil_porosity=float(state.soil.smcmax)))
 return value
def equal(a,b):
 if isinstance(a,np.ndarray):
  assert isinstance(b,np.ndarray) and a.dtype==b.dtype and a.shape==b.shape and np.array_equal(a,b,equal_nan=True)
 elif is_dataclass(a):
  assert type(a)==type(b)
  for f in fields(a):equal(getattr(a,f.name),getattr(b,f.name))
 elif isinstance(a,dict):
  assert a.keys()==b.keys()
  for key in a:equal(a[key],b[key])
 elif isinstance(a,(list,tuple)):
  assert len(a)==len(b)
  for x,y in zip(a,b):equal(x,y)
 else:assert a==b,(a,b)
point_rows=[];stream=tarfile.open(r/'point-results.tar.gz','w:gz')
driver.ground_resistance=recorded_resistance
try:
 for k,c in enumerate(cases):
  captured.clear();old=pickle.loads(gzip.decompress((reference/f'case-{k:02d}-reference.pkl.gz').read_bytes()))
  assert sha(reference/f'case-{k:02d}-reference.pkl.gz')==mi['results'][k]['reference_sha256']
  assert c['config'].get('soil_hydrology') is None and c['config'].get('canopy_optics') is None
  forcing=payload['forcing'][k].astype(float);f=runner.Forcing(*forcing)
  got,before,after=reference_module.reference(tuple(payload['a'+str(i)][k] for i in range(16)),payload['forcing'][k],payload['deposition'][k],payload['calendar_values'][k],payload['calendar_flags'][k],payload['nitrogen'][k],1.,most_geometry=native.MOSTGeometry(*map(float,payload['geometry'][k])),leaf_parameters=native.LeafParameters(**binding['leaf_parameters']),return_states=True)
  equal(got,old['result']);equal(before,old['before']);equal(after,old['after']);assert len(captured)==1
  incoming,residual,bound=runner.audit_step(before,after,f,got['diagnostics'],float(payload['nitrogen'][k]))
  d=got['diagnostics'];rs=captured[0]['resistance_sm'];ra=1./d['most']['water_velocity'];tg=d['flux_surface_temperature']
  qsat=float((_ice_saturation if tg<TF else _saturation)(tg,f.ps)[0]);rho=f.ps/(RD*f.tair*(1.+.61*f.qair));lv=d['ground_latent_heat']
  fixed_boundary_potential=rho*lv*(qsat-f.qair)/(ra+rs)
  no_soil_resistance=rho*lv*(qsat-f.qair)/ra
  leafless=bool(d['biogeochemistry']['lai_used']==0.);rn=f.swdown+f.lwdown-d['outgoing_shortwave']-d['outgoing_longwave']
  row=dict(case=c['case'],time_start=binding['cases'][k]['time_start'],all_saved_numpy_output_and_before_after_values_exact=True,
   original_independent_residual_m_h_c_n=residual.tolist(),original_independent_bounds_m_h_c_n=bound.tolist(),
   ground_resistance_capture=captured[0],atmosphere_water_resistance_sm=ra,resistance_share_soil=rs/(rs+ra),
   lai_used=d['biogeochemistry']['lai_used'],sai=before.sai,snow_before_m=before.swe,snow_after_m=after.swe,
   h_wm2=d['h'],le_wm2=d['le'],rnet_wm2=rn,ground_heat_wm2=d['ground_heat'],
   soil_heat_change_wm2=float((after.ground.enthalpy-before.ground.enthalpy).sum()/f.dt),
   total_heat_change_wm2=(after.enthalpy_jm2-before.enthalpy_jm2)/f.dt,
   precip_heat_wm2=d['precipitation_enthalpy_jm2']/f.dt,advected_heat_wm2=d['advected_enthalpy_jm2']/f.dt,runoff_heat_wm2=d['runoff_enthalpy_jm2']/f.dt,
   ground_vapor_kgm2s=d['ground_evaporation'],ground_latent_wm2=d['ground_latent_energy_jm2']/f.dt,
   fixed_boundary_bare_le_with_source_resistance_wm2=fixed_boundary_potential if leafless else None,
   fixed_boundary_bare_le_with_zero_soil_resistance_wm2=no_soil_resistance if leafless else None,
   leafless=leafless,ground_flux_temperature_k=tg,
   scope='Exact MI February25 single-step replay, all original outputs/states equal and hard budgets preserved. Zero-soil-resistance value is an algebraic conductance contrast at unchanged solved boundary only, not a new physical solution, parameter recommendation or January attribution.')
  point_rows.append(row)
  raw=gzip.compress(pickle.dumps(dict(result=got,before=before,after=after,resistance=captured[0]),protocol=5),mtime=0)
  item=tarfile.TarInfo(f'case-{k:02d}.pkl.gz');item.size=len(raw);stream.addfile(item,io.BytesIO(raw))
  print(json.dumps(dict(point=c['case'],h=d['h'],le=d['le'],rs=rs,ra=ra,source_identical=True)),flush=True)
finally:driver.ground_resistance=original_resistance;stream.close()
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,diagnostic_delivered=len(monthly)==len(point_rows)==12,
 source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),
 inputs={n:dict(archive=a,sha256=h) for n,(a,h) in packs.items()},monthly=monthly,points=point_rows,
 point_archive_sha256=sha(r/'point-results.tar.gz'),seconds=time.monotonic()-started,scope=__doc__)
(r/'diagnostic.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
assert out['diagnostic_delivered'] and out['source_unchanged']
print(json.dumps({k:v for k,v in out.items() if k not in ('monthly','points')}),flush=True)

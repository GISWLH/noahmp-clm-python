from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');label='winter-causality-mw';r=b/label
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
job=json.loads((r/'dispatch.json').read_text())['pbs_job']
q=subprocess.check_output(['qstat','-xf',job],text=True)
assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M)
assert (r/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((r/'diagnostic.json').read_text())
assert d['diagnostic_delivered'] and d['source_unchanged'] and len(d['monthly'])==len(d['points'])==12
assert all(x['all_saved_numpy_output_and_before_after_values_exact'] for x in d['points'])
assert sha(r/'point-results.tar.gz')==d['point_archive_sha256']
(r/'actual-qstat.txt').write_text(q)
payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()}
payload['control/'+Path(__file__).name]=Path(__file__).read_bytes()
payload['control/dispatch_winter_causality_mw.py']=(b/'dispatch_winter_causality_mw.py').read_bytes()
a=b/(label+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for name,raw in sorted(payload.items()):
  member=tarfile.TarInfo(name);member.size=len(raw);t.addfile(member,io.BytesIO(raw))
with tarfile.open(a) as t:
 assert len(t.getmembers())==len(payload)
 for member in t:assert t.extractfile(member).read()==payload[member.name]
out=dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(payload),
 scope=d['scope']+' Original failed year remains failed. Complete January soil-storage reconstruction, explicitly qualified bare-ground radiation proxy, fixed original QC and twelve exact February25 reference-point replays. Source and physics unchanged, no fitting or annual/spinup/scientific acceptance.')
(b/(label+'-package.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

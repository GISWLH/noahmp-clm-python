from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'winter-causality-mw';assert not r.exists();r.mkdir()
n='diagnose_winter_causality_mw.py';raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-winter-causality
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=6gb
#PBS -l walltime=00:20:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd ROOTPATH
/home/zhangyq/venvs/noahmp-closeout/bin/python -u diagnose_winter_causality_mw.py >worker.log 2>&1
code=$?
printf '%s\n' "$code" >pbs-exit.txt
exit "$code"
'''.replace('ROOTPATH',str(r))
(r/'job.pbs').write_text(script);q=subprocess.run(['qsub',str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr
out=dict(pbs_job=q.stdout.strip(),controls_sha256={n:hashlib.sha256(raw).hexdigest(),'job.pbs':hashlib.sha256(script.encode()).hexdigest()})
(r/'dispatch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

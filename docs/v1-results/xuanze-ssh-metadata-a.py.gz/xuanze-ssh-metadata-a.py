from pathlib import Path
import datetime
import json
import socket
import subprocess
import time

root = Path(__file__).resolve().parents[2]
alias = 'xuanze-neiwang'
cfg = dict(line.split(' ', 1) for line in subprocess.check_output(['ssh', '-G', alias], text=True).splitlines() if ' ' in line)
result = dict(scope='Read-only connection metadata for already-authorized xuanze alias only. No model/source/state action;timeout terminates only this owned local SSH diagnostic client,never detached remote workers. No inferred model failures or resource cause from access timeout.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), alias=alias)
start = time.monotonic()
try:
    with socket.create_connection((cfg['hostname'], int(cfg['port'])), timeout=5.) as s:
        result['tcp_connect_seconds'] = time.monotonic() - start
        s.settimeout(5.)
        result['ssh_banner'] = s.recv(256).decode(errors='replace').strip()
except Exception as e:
    result['socket_failure'] = type(e).__name__ + ': ' + str(e)
start = time.monotonic()
command = ['ssh', '-vv', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'ConnectionAttempts=1', alias, '/bin/true']
try:
    p = subprocess.run(command, text=True, capture_output=True, timeout=20.)
    result['ssh_returncode'] = p.returncode
    stderr = p.stderr
except subprocess.TimeoutExpired as e:
    result['ssh_returncode'] = None
    result['owned_metadata_client_timeout_seconds'] = 20.
    stderr = e.stderr.decode(errors='replace') if isinstance(e.stderr, bytes) else (e.stderr or '')
result['ssh_seconds'] = time.monotonic() - start
patterns = ['Remote protocol version', 'Authenticated to ', 'Entering interactive session', 'Sending command:', 'Connection timed out', 'Connection closed', 'kex_exchange_identification', 'SSH2_MSG_KEXINIT']
result['connection_stage_lines'] = [line.replace(cfg['hostname'], '[server]').replace(cfg.get('user', ''), '[user]') for line in stderr.splitlines() if any(p in line for p in patterns)]
p = root / 'outputs/v1/xuanze-ssh-metadata-a.json'
assert not p.exists(); p.write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))

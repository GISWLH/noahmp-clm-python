# Closed NP GPU cold48 original data

`original/cold48-evidence.tar.gz` is the complete original 7 MB archive, unchanged;
`original/cold48-package.json` is its unchanged original package. No numerical
arrays were deserialized or reconstructed. The outer and every inner member hash
were checked. Runtime controls were downloaded from the closed xuanze NP root and
match its actual plan and original preparation. The exact NM584 source is already
public in the NR evidence package; `source-binding.json` records that identity.

The actual GPU parent exited 0 after 12 x 48 steps. Independent audit 1586.manager
is separately published as `climatology-cold48-np-pair`; this package preserves
the underlying GPU data. This is CUDA-only candidate cold48, without a claim of
same-precision, annual, observational, full-regression or production acceptance.
It contains no continuation entry and does not authorize continuing any year.

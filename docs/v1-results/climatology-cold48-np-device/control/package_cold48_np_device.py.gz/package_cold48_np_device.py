"""Publishable envelope for already closed NP data; all numerical archives stay byte exact."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path, PurePosixPath

BASE = Path(__file__).resolve().parent
RAW = BASE / 'climatology-cold48-np-download'
CONTROLS = BASE / 'climatology-cold48-np-device-controls'
LABEL = 'climatology-cold48-np-device'
DEVICE = 'ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416'
SOURCE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda data: (json.dumps(data, indent=2) + '\n').encode()


def read_archive(raw):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as tf:
        for member in tf:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in result
            result[member.name] = tf.extractfile(member).read()
    return result


def main():
    device = (RAW / 'cold48-evidence.tar.gz').read_bytes()
    original_package = (RAW / 'cold48-package.json').read_bytes()
    package = json.loads(original_package)
    assert sha(device) == package['device_archive_sha256'] == DEVICE
    assert package['source_manifest_sha256'] == TARGET
    assert package['candidate_only'] and package['continuation_allowed'] is False
    inner = read_archive(device)
    receipt = json.loads(inner['current/receipt.json'])
    end = json.loads(inner['current/exit.json'])
    assert end['passed'] and end['actual_parent_returncode'] == 0 and end['failure'] is None
    assert end['receipt_sha256'] == sha(inner['current/receipt.json'])
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
    assert receipt['source_manifest_sha256'] == TARGET
    assert receipt['cases'] == 12 and receipt['captured_step_calls'] == receipt['steps_completed'] == 48
    assert receipt['cold_fields_exact'] == 23 and receipt['primary_state_arrays'] == 16
    assert receipt['report_sha256'] == sha(inner['current/trajectory/batch.json'])
    assert receipt['steps_requested'] == 17520 and receipt['status'] == 'running'
    assert sum(n.startswith('current/steps/call-') and n.endswith('.npz') for n in inner) == 48
    plan = json.loads(inner['control/plan.json'])
    assert plan['source_archive_sha256'] == SOURCE and plan['source_manifest_sha256'] == TARGET
    payload = {'original/cold48-evidence.tar.gz': device, 'original/cold48-package.json': original_package}
    for name in ['plan.json', 'launch.json']:
        data = (CONTROLS / name).read_bytes()
        assert data == inner['control/' + name]
        payload['control/' + name] = data
    controls_sha = {}
    with tarfile.open(BASE / 'climatology-cold48-np-preparation-evidence.tar.gz') as tf:
        for name in ['run_cold48_np.py', 'control_cold48_np.py', 'launch_cold48_np.py',
                     'archive_cold48_np.py', 'climatology_contract_np.py', 'surface_regression_contract_mx.py']:
            data = (CONTROLS / name).read_bytes()
            assert sha(data) == plan['controls_sha256'][name]
            assert data == tf.extractfile('prepared/' + name).read()
            payload['control/' + name] = data
            controls_sha[name] = sha(data)
    public_root = BASE.parents[1] / 'docs/v1-results/climatology-final-cpu-nr'
    public_manifest = json.loads((public_root / 'manifest.json').read_text())
    source_member = 'control/climatology-final-candidate-nm-source.tar.gz'
    entry = next(item for item in public_manifest['artifacts'] if item['source'] == source_member)
    public_source = (public_root / entry['path']).read_bytes()
    assert sha(public_source) == entry['stored_sha256'] == entry['source_sha256'] == SOURCE
    assert public_source == (BASE / 'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    with tarfile.open(fileobj=io.BytesIO(public_source)) as tf:
        source_manifest = tf.extractfile('SOURCE_SHA256.json').read()
        assert sha(source_manifest) == TARGET and len(json.loads(source_manifest)) == 584
    assert gzip.decompress((public_root / 'SOURCE_SHA256.json.gz').read_bytes()) == source_manifest
    nr = json.loads((BASE / 'climatology-final-cpu-nr-package.json').read_text())
    assert nr['sha256'] == public_manifest['archive_sha256']
    assert nr['source_archive_sha256'] == SOURCE and nr['source_manifest_sha256'] == TARGET
    payload['source-binding.json'] = encode(dict(source_manifest_sha256=TARGET, source_files=584,
        source_archive_sha256=SOURCE, public_source_path='docs/v1-results/climatology-final-cpu-nr/' + entry['path'],
        public_nr_archive_sha256=nr['sha256'], byte_equal_to_original_np_source=True,
        note='Source identity relation only. The already closed NP record remains candidate-only and is not relabeled as an annual or full-regression run.'))
    payload['runtime-controls-sha256.json'] = encode(dict(downloaded_from='xuanze-neiwang:/home/lhwang/work/noahmp-v1/climatology-cold48-np',
        controls=controls_sha, all_match_actual_plan=True, all_match_original_preparation=True,
        launch_and_plan_byte_equal_to_closed_inner_archive=True))
    payload['inner-artifact-inventory.json'] = encode({n: dict(sha256=sha(data), bytes=len(data)) for n, data in inner.items()})
    payload['verification.json'] = encode(dict(device_archive_sha256=DEVICE, inner_artifacts=len(inner),
        original_archive_bytes_preserved=True, original_package_bytes_preserved=True,
        inner_member_hashes_verified=True, gpu_actual_parent_returncode=0,
        cold_fields_exact=23, primary_state_arrays=16, captured_steps=48, cases=12,
        receipt_sha256=sha(inner['current/receipt.json']), source_manifest_sha256=TARGET,
        candidate_only=True, continuation_allowed=False, model_execution=False,
        arrays_deserialized=False, model_files_extracted_to_disk=False))
    payload['README.md'] = ('''# Closed NP GPU cold48 original data

`original/cold48-evidence.tar.gz` is the complete original 7 MB archive, unchanged;
`original/cold48-package.json` is its unchanged original package. No numerical
arrays were deserialized or reconstructed. The outer and every inner member hash
were checked. Runtime controls were downloaded from the closed xuanze NP root and
match its actual plan and original preparation. The exact NM584 source is already
public in the NR evidence package; `source-binding.json` records that identity.

The actual GPU parent exited 0 after 12 x 48 steps. Independent audit 1586.manager
is separately published as `climatology-cold48-np-pair`; this package preserves
the underlying GPU data. This is CUDA-only candidate cold48, without a claim of
same-precision, annual, observational, full-regression or production acceptance.
It contains no continuation entry and does not authorize continuing any year.
''').encode()
    payload['control/package_cold48_np_device.py'] = Path(__file__).read_bytes()
    inventory = {n: dict(sha256=sha(data), bytes=len(data)) for n, data in payload.items()}
    payload['artifact-inventory.json'] = encode(inventory)
    archive = BASE / (LABEL + '-evidence.tar.gz')
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as tf:
        for name, data in sorted(payload.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    restored = read_archive(archive.read_bytes())
    assert restored == payload
    assert restored['original/cold48-evidence.tar.gz'] == device
    checked_inner = read_archive(restored['original/cold48-evidence.tar.gz'])
    assert checked_inner == inner
    for name, identity in json.loads(restored['inner-artifact-inventory.json']).items():
        assert sha(checked_inner[name]) == identity['sha256'] and len(checked_inner[name]) == identity['bytes']
    result = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
        artifacts=len(payload), inner_artifacts=len(inner), source_manifest_sha256=TARGET,
        original_device_archive_sha256=DEVICE, original_device_bytes=len(device),
        actual_gpu_parent_exit=0, cases=12, steps=48, inner_and_outer_hashes_verified=True,
        candidate_only=True, continuation_allowed=False,
        scope='Complete original closed NP CUDA-only12x48 archive nested unchanged, actual parent0, controls/source identity and inner/outer hashes. Separate1586 F0 paired evidence. No annual, same-precision, full-regression, observational or promotion claim.')
    (BASE / (LABEL + '-package.json')).write_bytes(encode(result))
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

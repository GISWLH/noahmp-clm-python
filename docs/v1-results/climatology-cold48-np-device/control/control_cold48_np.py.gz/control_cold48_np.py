"""One candidate cold48 worker, actual exit only; no year/cycle entry point."""
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from climatology_contract_np import TARGET, load, prerequisites, sha, verify_source

root = Path(os.environ['NP_ROOT'])
folder = root / 'cold48'
started = time.monotonic()
code = None
failure = None
passed = False
try:
    plan = load(root / 'plan.json')
    assert all(sha(root / n) == h for n, h in plan['controls_sha256'].items())
    verify_source(Path(os.environ['NP_SOURCE']))
    proof = prerequisites(Path('/home/lhwang/work/noahmp-v1'))
    (folder / 'start-prerequisites.json').write_text(json.dumps(proof, indent=2) + '\n')
    command = [sys.executable, '-u', str(root / 'run_cold48_np.py')]
    with (folder / 'model.log').open('x') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    (folder / 'worker.json').write_text(json.dumps(dict(pid=process.pid, command=command)) + '\n')
    code = process.wait()
    record = load(folder / 'receipt.json')
    passed = bool(code == 0 and record['failure'] is None and record['source_unchanged']
                  and record['source_manifest_sha256'] == TARGET and record['device_barrier_complete']
                  and record['cold_fields_exact'] == 23 and record['primary_state_arrays'] == 16
                  and record['cases'] == 12 and record['captured_step_calls'] == record['steps_completed'] == 48
                  and record['steps_requested'] == 17520 and record['status'] == 'running')
    verify_source(Path(os.environ['NP_SOURCE']))
except Exception as error:
    failure = type(error).__name__ + ': ' + str(error)
    (folder / 'controller-traceback.txt').write_text(traceback.format_exc())
result = dict(passed=bool(passed and failure is None), actual_parent_returncode=code, failure=failure,
              source_manifest_sha256=TARGET, seconds=time.monotonic()-started,
              receipt_sha256=sha(folder / 'receipt.json') if (folder / 'receipt.json').exists() else None,
              candidate_only=True, continuation_allowed=False,
              scope='Private candidate12x48 only. New independent576pair audit required; no production/fullMX31/year credit. '
                    'Any future reuse needs completeMX31/NF, formal promotion and a separate exact binding.')
(folder / 'exit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['passed'] else 1)

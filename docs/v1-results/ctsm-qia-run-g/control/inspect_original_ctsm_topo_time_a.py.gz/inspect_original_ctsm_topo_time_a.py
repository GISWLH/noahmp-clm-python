from pathlib import Path
import io,json,sys,tarfile
sys.path.insert(0,'/home/zhangyq/noahmp-v1/test-deps')
from scipy.io import netcdf_file
b=Path('/home/zhangyq/noahmp-v1')
for archive in b.glob('*static*.tar.gz'):
 with tarfile.open(archive) as t:
  for m in t:
   if m.isfile() and 'topodata' in m.name and m.name.endswith('.nc'):
    with netcdf_file(io.BytesIO(t.extractfile(m).read()),mmap=False) as d:
     print(json.dumps(dict(archive=archive.name,file=m.name,dimensions=d.dimensions,topo_dimensions=d.variables['TOPO'].dimensions,time_values=d.variables['time'][:].tolist(),time_attrs={k:(v.decode() if isinstance(v,bytes) else str(v)) for k,v in d.variables['time']._attributes.items()})))

from pathlib import Path
import tarfile
b=Path('/home/zhangyq/noahmp-v1')
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 for m in t:
  if m.isfile() and 'UrbanTimeVar' in m.name and m.name.endswith('.F90'):
   lines=t.extractfile(m).read().decode().splitlines();wanted=set()
   for i,line in enumerate(lines):
    if any(s in line.lower() for s in ['subroutine init','shr_strdata_init','stream_fldfilename','if (','return','end subroutine']):wanted.update(range(max(0,i-2),min(len(lines),i+5)))
   print(m.name);print('\n'.join(str(i+1)+':'+lines[i] for i in sorted(wanted))[:20000])

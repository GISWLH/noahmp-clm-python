from pathlib import Path
import ast

r=Path(__file__).resolve().parent
p=(r/'run_ctsm_qia_f.py').read_text().replace('ctsm-qia-run-f','ctsm-qia-run-g')
marker="    py=str(prefix/'bin/python');assert run('relocate',[py,str(prefix/'bin/conda-unpack')])==0"
assert p.count(marker)==1
p=p.replace(marker,marker+"\n    assert run('topo-time-coordinate',[py,str(root/'restore_ctsm_topo_time_a.py'),str(inputs/'CN-Qia.topo.nc'),point_record['files']['CN-Qia.topo.nc']['sha256']])==0\n    value['topography_time_metadata_restore']=json.loads((scratch/'topo-time-coordinate.stdout.txt').read_text())")
ast.parse(p);(r/'run_ctsm_qia_g.py').write_text(p)
p=(r/'ctsm_qia_run_f.pbs').read_text().replace('ctsm-qia-run-f','ctsm-qia-run-g').replace('run_ctsm_qia_f.py','run_ctsm_qia_g.py').replace('clm-qia-official-f','clm-qia-official-g')
(r/'ctsm_qia_run_g.pbs').write_bytes(p.encode())

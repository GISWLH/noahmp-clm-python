from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-column-numpy-a';s=Path(os.environ['TMPDIR']).resolve()/'source';s.mkdir(exist_ok=False);a=b/'p6-stem-column-numpy-a-source.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(a)=='2b4504cd15800ea48bc458455eafb3b61e6d1bcf5aa307e670f7b2469eeebd60'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==496 and all(sha(s/n)==v for n,v in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
def run(label,files,expected):
 start=time.monotonic();xml=r/(label+'.xml')
 with (r/(label+'.log')).open('w') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 counts={key:sum(int(v.attrib[key]) for v in ET.parse(xml).getroot().iter('testsuite')) for key in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==v for n,v in m.items());record=dict(scope='Actual NumPy structure/full-column checks only; native SAI extension not yet synchronized. Existing493 GPU regression remains a separate frozen source. No annual/spinup/scientific claim.',returncode=code,counts=counts,source_files=len(m),source_unchanged=unchanged,source_archive_sha256=sha(a),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start)
 (r/(label+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n');print(label,json.dumps(record),flush=True)
 return code==0 and unchanged and counts==dict(tests=expected,failures=0,errors=0,skipped=0)
passed=run('targets',['tests/test_vegetation_structure.py','tests/test_clm_stem_column.py'],40)
if not passed:raise SystemExit(1)
files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
raise SystemExit(0 if run('cpu-full',files,848) else 1)

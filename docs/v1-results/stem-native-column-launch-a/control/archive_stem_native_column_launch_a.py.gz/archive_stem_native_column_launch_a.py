from pathlib import Path
import datetime,hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-native-column-a';r=s/'target-a';a=b/'stem-native-column-launch-a-evidence.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==502 and all(sha(s/n)==v for n,v in m.items());progress=(r/'progress.json').read_bytes();d=json.loads(progress)
assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [s/'SOURCE_SHA256.json',r/'launch.json',r/'collection.json',r/'test_gpu_vegetation_structure-receipt.json',r/'test_gpu_vegetation_structure.xml',r/'test_gpu_vegetation_structure.log']:
  t.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
 for n in ['launch_stem_native_column_a.py','run_stem_native_column_a.py','archive_stem_native_column_launch_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
 import io
 for name,value in [('captured-progress.json',progress),('snapshot.json',(json.dumps(dict(scope='Read-only launch/running snapshot of new502 target19. Only completed canonical files with real0 receipts credited; active file not counted. Not full regression/annual/scientific acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active=d['active'],completed=[dict(file=v['file'],passed=v['passed']) for v in d['results']]),indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(name);info.size=len(value);t.addfile(info,io.BytesIO(value))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

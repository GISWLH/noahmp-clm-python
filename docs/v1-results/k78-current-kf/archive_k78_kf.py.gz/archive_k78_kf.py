from pathlib import Path
import hashlib,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-current-kf';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
launch=json.loads((r/'dispatch.json').read_text());job=launch['pbs_job']
status=subprocess.check_output(['qstat','-xf',job],text=True)
assert re.search(r'^\s*job_state = F\s*$',status,re.M)
exit=int(re.search(r'^\s*Exit_status = (\d+)\s*$',status,re.M).group(1))
assert (r/'pbs-exit.txt').read_text().strip()==str(exit)
d=json.loads((r/'audit.json').read_text());assert exit==(0 if d['passed'] and d['source_unchanged'] else 1)
assert d['raw_model_and_next_fields']==329 and d['additional_before_arrays']==16
assert d['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items())
(r/'actual-pbs-qstat.txt').write_text(status)
archive=b/'k78-current-kf-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(r.rglob('*')):
  if p.is_file():
   assert not p.is_symlink();name='current/'+p.relative_to(r).as_posix();inventory[name]=sha(p);tf.add(p,arcname=name,recursive=False)
 for n in ['dispatch_k78_kf.py',Path(__file__).name]:inventory[n]=sha(b/n);tf.add(b/n,arcname=n,recursive=False)
 packet=b/'k78-corrected-js-device-export.tar.gz';assert sha(packet)==launch['packet_sha256'];inventory['original-device-export.tar.gz']=sha(packet);tf.add(packet,arcname='original-device-export.tar.gz',recursive=False)
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(inventory)
 for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),actual_pbs=job,actual_pbs_exit=exit,audit_passed=d['passed'],failed=d['failed'],budgets=d['budgets'],scope='CurrentJN581 originalK78bothactualGPU0 then actualindependentaudit, raw329field1e-6/int/dtypes+16exactbefore and alloriginalMHCN/impuritygates unchanged. Allrealzero/nonzeroexits retained, no failedtrajectoryadvancement/fullsuite/year/observedscienceclaim.')
(b/'k78-current-kf-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

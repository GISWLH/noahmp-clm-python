from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'k78-corrected-js'
start = time.monotonic()
rows = []
# Regression required because productionphysics changed, not an unchanged
# restart of oldK78. Wait real own-source validation and retain exactoldinput.
while not (b/'ballberry-iv-gpu/exit.json').exists() or not (b/'ballberry-jo-full-gpu/cpu-ready.json').exists():
    (r/'waiting-validation.json').write_text(json.dumps(dict(target37_terminal=(b/'ballberry-iv-gpu/exit.json').exists(),cpu1156_ready=(b/'ballberry-jo-full-gpu/cpu-ready.json').exists()))+'\n');time.sleep(20.)
proof=json.loads((b/'ballberry-iv-gpu/exit.json').read_text());cpu=json.loads((b/'ballberry-jo-full-gpu/cpu-evidence/receipt.json').read_text())
assert proof['passed'] and proof['source_unchanged'] and cpu['passed'] and cpu['pytest_returncode']==0 and cpu['counts']==dict(tests=1156,failures=0,errors=0,skipped=0) and proof['source_manifest_sha256']=='49b318061863d443adb394083fcf46c8a1c830669b612898b3730f6b5cdf2e9e' and cpu['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
inheritance=json.loads((b/'ballberry-jo-full-gpu/inheritance-proof.json').read_text());assert inheritance['parent_manifest_sha256']==proof['source_manifest_sha256'] and inheritance['current_manifest_sha256']==cpu['source_manifest_sha256'] and inheritance['only_changed_file']==['tests/test_leaf_root.py'] and inheritance['production_gpu_tests_fixtures_benchmarks_all_byteexact']
for name in ['cuda32', 'jax32']:
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and memory>32*1024*1024:break
        time.sleep(20.)
    with (r / (name + '.log')).open('x') as log:
        p = subprocess.Popen([sys.executable, '-u', str(b / 'replay_k78_backend_js.py'), name], stdout=log, stderr=subprocess.STDOUT)
    (r / (name + '-worker.json')).write_text(json.dumps(dict(pid=p.pid)) + '\n')
    code = p.wait()
    receipt = r / name / 'receipt.json'
    row = dict(backend=name, actual_returncode=code, receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None)
    rows.append(row)
    (r / (name + '-exit.json')).write_text(json.dumps(row, indent=2) + '\n')
value = dict(scope='Actual currentJN581 device computations/export/barriers,CPU-side allraw/MHCN acceptance still deferred to EHPC. No timeout-based restart/termination or original model/year modification.',
             workers=rows, seconds=time.monotonic() - start)
(r / 'exit.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)
raise SystemExit(0 if all(v['actual_returncode'] == 0 for v in rows) else 1)

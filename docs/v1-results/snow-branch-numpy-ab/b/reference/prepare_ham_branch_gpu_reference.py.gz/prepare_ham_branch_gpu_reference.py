"""Independent NumPy solutions for both native input precisions, on EHPC."""
from dataclasses import asdict,astuple,replace
from pathlib import Path
import hashlib,json,time
import numpy as np
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.gpu.clm_bgc_column import pack_clm_bgc_columns,pack_bgc_environment
from test_molten_precipitation import ham_failure
from test_surface_snow_branch import record
from test_gpu_clm_bgc_column import reference
from run_fluxnet_column import source_hashes

r=Path.cwd();metadata=record();assert metadata['leaf_parameters']==asdict(LeafParameters())
state,f,kwargs=ham_failure('ham_surface_branch.json');factors=[(t,p) for p in [.5,1.,2.] for t in [.5,1.,2.]]
forcing=[replace(f,dt=f.dt*t,prcp=f.prcp*p) for t,p in factors];output={};metrics={};started=time.monotonic()
for label,dtype in [('f32',np.float32),('f64',np.float64)]:
    arrays=pack_clm_bgc_columns([state]*len(factors),dtype=dtype,co2_ppm=kwargs['co2_ppm'],
        cosine_zenith=kwargs['cosine_zenith'],diffuse_fraction=kwargs['diffuse_fraction'],leaf_dimension=metadata['leaf_dimension_m'])
    forcings=np.array([list(vars(value).values()) for value in forcing],dtype)
    env,cal=pack_bgc_environment([kwargs['phenology_environment']]*len(factors),dtype=dtype)
    geometry=np.array([astuple(kwargs['most_geometry'])]*len(factors),dtype)
    output.update({label+f'_a{k}':v for k,v in enumerate(arrays)})
    output.update({label+'_'+k:v for k,v in dict(forcing=forcings,environment=env,calendar=cal,geometry=geometry).items()})
    refs=[]
    for i,row in enumerate(zip(*arrays)):
        ref=reference(row,forcings[i],np.zeros(5),env[i],cal[i],0.,1.,most_geometry=MOSTGeometry(*map(float,geometry[i])))
        refs.append(ref)
        print(label,i,factors[i],ref['diagnostics']['h'],ref['diagnostics']['le'],flush=True)
    for name in ['h','le','et_mm','runoff_mm','gpp_gc_m2','nee_gc_m2']:
        output[label+'_ref_'+name]=np.array([ref['diagnostics'][name] for ref in refs],float)
    output[label+'_ref_soil_temperature']=np.array([ref['soil_temperature'] for ref in refs],float)
    output[label+'_ref_smc']=np.array([ref['soil_cells'][:,0]/(1000.*ref['soil_cells'][:,2]) for ref in refs],float)
    output[label+'_ref_swe_m']=np.array([ref['snow_cells'][:,0].sum()/1000. for ref in refs],float)
    metrics[label]={k:output[label+'_ref_'+k].tolist() for k in ['h','le','et_mm','gpp_gc_m2','nee_gc_m2']}
fixture=r/'ham_surface_branch_gpu.npz';np.savez_compressed(fixture,**output)
report=dict(scope='Nine saved-state dt/precip perturbations, each independently solved by NumPy from its native quantized inputs. Sum-one physiological fractions are reconstructed by the established reference helper only; no host physical tendency supplies either GPU backend. Not observation acceptance.',
    input_fixture_sha256=hashlib.sha256((Path('tests/fixtures/ham_surface_branch.json')).read_bytes()).hexdigest(),
    fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),source_sha256=source_hashes(),
    factors=factors,reference_values=metrics,seconds=time.monotonic()-started)
(r/'ham_surface_branch_gpu.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(fixture_sha256=report['fixture_sha256'],seconds=report['seconds'])),flush=True)

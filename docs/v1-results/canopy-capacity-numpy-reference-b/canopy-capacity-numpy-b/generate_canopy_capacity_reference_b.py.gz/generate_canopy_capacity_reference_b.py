# Executed only by the successful NumPy PBS reference worker, with its frozen
# source already extracted into compute-local TMPDIR. No local physics run.
sys.path[:0] = [str(source / 'src')]
from noahmp_clm.physics.canopy_capacity import TemperatureMemory, CanopyCapacityParameters, canopy_capacity_profile
from noahmp_clm.physics.photosynthesis import LeafParameters
from dataclasses import astuple
import numpy as np

rng = np.random.default_rng(734921)
export = {}
summary = {}
for precision in ['32', '64']:
    dtype = np.dtype('float' + precision)
    size = 32
    leaf = rng.uniform(0., .8, (size, 10)); leaf[0] = 0.; leaf[1, ::2] = 0.
    environment = np.column_stack((rng.uniform(0., 45000., size), np.full(size, 45000.), rng.uniform(270., 320., size)))
    environment[:4, 0] = [0., 100., 30000., 45000.]
    traits = np.column_stack((rng.uniform(.005, .04, size), rng.uniform(15., 100., size),
                             rng.uniform(.015, .08, size), rng.uniform(.2, 1., size)))
    traits[:4] = [.01, 58., .0509, 1.]
    template = np.broadcast_to(np.asarray(astuple(LeafParameters())), (size, 10)).copy()
    leaf, environment, traits, template = (np.asarray(a, dtype) for a in (leaf, environment, traits, template))
    profiles = [canopy_capacity_profile(leaf[k].astype(float), *environment[k].astype(float),
                CanopyCapacityParameters(*traits[k].astype(float)), leaf_parameters=LeafParameters(*template[k].astype(float)))
                for k in range(size)]
    prefix = precision + '/'
    for name, values in [('leaf', leaf), ('environment', environment), ('traits', traits), ('template', template)]:
        export[prefix + name] = values
    for key in profiles[0]: export[prefix + 'expected/' + key] = np.asarray([one[key] for one in profiles])
    values = np.asarray(rng.uniform(265., 310., (6, 480)), dtype)
    controls = np.asarray([[0,0], [1,1], [32,32], [479,479], [480,0], [480,237]], np.int32)
    forcing = np.asarray([[1800., 293.15, t] for t in [270., 280., 290., 300., 310., 273.15]], dtype)
    old_mean = []; new_mean = []; next_values = []; next_controls = []
    for k in range(6):
        dt, initial, air = map(float, forcing[k])
        memory = TemperatureMemory(values[k].astype(float), dt, *map(int, controls[k]), initial)
        after = memory.append(air, dt)
        old_mean.append(memory.mean_temperature_k); new_mean.append(after.mean_temperature_k)
        next_values.append(after.values); next_controls.append([after.count, after.cursor])
    export[prefix + 'memory_values'] = values
    export[prefix + 'memory_controls'] = controls
    export[prefix + 'memory_forcing'] = forcing
    export[prefix + 'expected_memory_values'] = np.asarray(next_values)
    export[prefix + 'expected_memory_controls'] = np.asarray(next_controls, np.int32)
    export[prefix + 'expected_memory_means'] = np.column_stack((old_mean, new_mean))
    summary[precision] = dict(profile_cases=size, memory_cases=6, memory_samples=480)
path = root / 'canopy_capacity_reference.npz'
np.savez_compressed(path, **export)
record = dict(pbs_job=os.environ['PBS_JOBID'], source_manifest_sha256=sha(source / 'SOURCE_SHA256.json'),
              reference_sha256=sha(path), cases=summary,
              scope='Frozen NumPy522B reference at separately quantized32/64 inputs, generated on compute002 after all41 reference/unit tests actual0. Directly tests capacity/memory components only; no integrated column/default/GPU/science acceptance.')
(root / 'reference.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

from pathlib import Path
import hashlib
import json
import subprocess

base = Path('/home/zhangyq/noahmp-v1'); root = base / 'canopy-capacity-numpy-b'
assert not root.exists(); root.mkdir()
controls = {}
for name in ['generate_canopy_capacity_reference_b.py', 'run_canopy_capacity_numpy_b.py', 'canopy_capacity_numpy_b.pbs', 'canopy-capacity-numpy-b-package.json']:
    raw = (base / name).read_bytes()
    if name.endswith(('.py', '.pbs')): assert b'\r\n' not in raw
    (root / ('package.json' if name.endswith('-package.json') else name)).write_bytes(raw)
    controls[name] = hashlib.sha256(raw).hexdigest()
job = subprocess.check_output(['qsub', str(root / 'canopy_capacity_numpy_b.pbs')], cwd=root, text=True).strip()
(root / 'dispatch.json').write_text(json.dumps(dict(pbs_job=job, controls_sha256=controls), indent=2) + '\n')
print(job)

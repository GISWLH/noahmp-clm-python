from pathlib import Path
import hashlib
import json
import sys
import tarfile

mode = sys.argv[1]
if mode == 'numpy':
    base = Path('/home/zhangyq/noahmp-v1'); roots = ['canopy-capacity-numpy-a', 'canopy-capacity-numpy-b']
    for name in roots:
        assert (base/name/'pbs-exit.txt').read_text().strip() == '0'
        receipt = json.loads((base/name/'receipt.json').read_text())
        assert receipt['returncode'] == 0 and receipt['source_unchanged'] and receipt['counts'] == dict(tests=41,failures=0,errors=0,skipped=0)
    name = 'canopy-capacity-numpy-reference-b'
    controls = ['dispatch_canopy_capacity_numpy_a.py','dispatch_canopy_capacity_numpy_b.py','generate_canopy_capacity_reference_b.py']
    sources = ['canopy-capacity-numpy-a-source.tar.gz','canopy-capacity-numpy-b-source.tar.gz']
else:
    assert mode == 'gpu'
    base = Path('/home/lhwang/work/noahmp-v1'); roots = ['canopy-capacity-gpu-a/target-a']
    result = json.loads((base/roots[0]/'exit.json').read_text())
    assert result['returncode'] == 0 and result['passed'] and result['source_unchanged']
    name = 'canopy-capacity-gpu3-a'
    controls = ['collect_canopy_capacity_gpu_a.py','control_canopy_capacity_gpu_a.py','launch_canopy_capacity_gpu_a.py',
                'gpu-worker-lifecycle-a/run_pytest_worker_a.py']
    sources = ['canopy-capacity-gpu-a-source.tar.gz','canopy-capacity-gpu-a-package.json',
               'canopy-capacity-numpy-b-receipt.json','canopy-capacity-reference-b.json']
archive = base/(name+'-evidence.tar.gz'); assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for root in roots:
        for path in sorted((base/root).rglob('*')):
            if path.is_file(): tf.add(path,arcname=path.relative_to(base).as_posix(),recursive=False)
    for control in controls:
        tf.add(base/control,arcname='control/'+control,recursive=False)
    for source in sources:
        tf.add(base/source,arcname='source/'+source,recursive=False)
    if mode == 'gpu': tf.add(base/'canopy-capacity-gpu-a/SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    tf.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)))

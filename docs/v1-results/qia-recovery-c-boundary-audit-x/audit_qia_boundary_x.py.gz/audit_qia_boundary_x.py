from pathlib import Path
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-recovery-c-boundary-audit-x';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();device=Path(os.environ['TMPDIR'])/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
a=b/'clm-numerical-recovery-c-source.tar.gz';assert sha(a)=='61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
a=b/'qia-recovery-c-year-boundary-w-evidence.tar.gz';archive_record=json.loads((r/'dispatch.json').read_text());assert sha(a)==archive_record['boundary_archive_sha256']
with tarfile.open(a) as t:t.extractall(device,filter='data')
meta=json.loads((device/'archive-record.json').read_text());assert all(sha(device/n)==h for n,h in meta['artifact_sha256'].items())
cases=[]
for label in ['capacity','capacity_optics']:
    p=device/label;failure=None;summary={}
    try:
        v=json.loads((p/'prefix-verification.json').read_text());guard=json.loads((p/'year-start-audit.json').read_text());report=json.loads((p/'validated-prefix-report.json').read_text())
        assert v['passed'] and v['cold_fields_exact']==30 and v['physical_step_pairs']==48 and len(v['all23physical_trace_metrics'])==24 and v['all23state_chains_and_final_checkpoint_exact']
        assert v['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')==guard['source_manifest_sha256'] and guard['saved_fields_exact']==30
        assert guard['cpu_verification_sha256']==sha(p/'prefix-verification.json') and sha(p/'validated-prefix-report.json')==v['prefix_batch_report_sha256']
        assert report['steps_completed']==48 and report['steps_requested']==17520 and report['status']=='running' and report['same_precision_max_absolute'] is None
        assert sha(p/'validated-prefix-state.npz')==guard['current_checkpoint_sha256']==guard['verified_prefix_checkpoint_sha256']==v['prefix_checkpoint_sha256']
        with np.load(p/'validated-prefix-state.npz',allow_pickle=False) as z:prior=dict(z)
        with np.load(p/'first-continued-step.npz',allow_pickle=False) as z:d=dict(z)
        assert len(prior)==30
        before=tuple(d['before'+str(k)] for k in range(23));after=tuple(d['after'+str(k)] for k in range(23))
        for k,value in enumerate(before):assert value.dtype==prior['a'+str(k)].dtype and value.shape==prior['a'+str(k)].shape and value.tobytes()==prior['a'+str(k)].tobytes()
        out={}
        for name,value in d.items():
            if not name.startswith('output/'):continue
            parts=name.split('/')[1:];target=out
            for part in parts[:-1]:target=target.setdefault(part,{})
            target[parts[-1]]=value
        incoming,residual,calculated_bound,tracer=native.audit_step(before,after,d['forcing'],d['deposition'],d['nitrogen'],out)
        bound=d['recorded/bound'];assert np.all(abs(residual)<=bound) and np.all(abs(d['recorded/residual'])<=bound)
        # Recompute from the immutable48 ledger; no counter or residual reset.
        net=prior['net']+incoming;recorded_net=prior['net']+d['recorded/incoming'];bounds=prior['bounds']+bound
        cumulative=native.totals(after)-prior['initial']-net;recorded_cumulative=native.totals(after)-prior['initial']-recorded_net
        assert np.all(abs(cumulative)<=bounds) and np.all(abs(recorded_cumulative)<=bounds)
        summary=dict(passed=True,saved_fields=30,before_state_fields_exact=23,returned_fields=sum(k.startswith('output/') for k in d),independent_step_m_h_c_n=residual.tolist(),original_step_bound_m_h_c_n=bound.tolist(),independent_cumulative_m_h_c_n=cumulative.tolist(),original_cumulative_bound_m_h_c_n=bounds.tolist(),independent_impurity_residual=tracer.tolist(),incoming_recompute_maximum_absolute=float(abs(incoming-d['recorded/incoming']).max()),residual_recompute_maximum_absolute=float(abs(residual-d['recorded/residual']).max()),prefix_checkpoint_sha256=sha(p/'validated-prefix-state.npz'),continued_step_sha256=sha(p/'first-continued-step.npz'))
    except Exception as error:
        failure=type(error).__name__+': '+str(error);(r/(label+'-traceback.txt')).write_text(traceback.format_exc());summary.update(passed=False,failure=failure)
    summary['case']=label;cases.append(summary)
record=dict(passed=all(v['passed'] for v in cases),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),cases=cases,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,scope='Independent CPU compute audit of actual first step after own verified successful CUDA48, all23 physical predecessor arrays exact, all30 bootstrap fields bound by matching prefix/worker hashes, original MHCN/impurity perstep and cumulative guards without ledger reset. No complete year/JAXraw/spinup/observational scientific claim.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True);assert record['passed'] and record['source_unchanged']

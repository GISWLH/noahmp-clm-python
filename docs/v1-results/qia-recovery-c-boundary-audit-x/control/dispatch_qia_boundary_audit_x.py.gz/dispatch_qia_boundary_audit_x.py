from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-recovery-c-boundary-audit-x';assert not r.exists();r.mkdir();controls={}
for n in ['audit_qia_boundary_x.py','qia_boundary_audit_x.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
a=b/'qia-recovery-c-year-boundary-w-evidence.tar.gz';h=hashlib.sha256(a.read_bytes()).hexdigest()
p=subprocess.run(['qsub',str(r/'qia_boundary_audit_x.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,boundary_archive_sha256=h);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

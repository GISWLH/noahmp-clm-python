from pathlib import Path
import hashlib
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-phase-final-check-a'
r = s / 'target-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads((r / 'exit.json').read_text())
receipt = json.loads((r / 'receipt.json').read_text())
assert d['passed'] and d['returncode'] == 0 and sha(r / 'receipt.json') == d['receipt_sha256']
assert receipt['passed'] and receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0
assert receipt['source_unchanged'] and receipt['all_setup_call_teardown_phases_passed'] and receipt['node_coverage_exact']
assert receipt['counts'] == dict(tests=8, failures=0, errors=0, skipped=0)
assert sha(r / 'targets.xml') == receipt['xml_sha256'] and sha(s / 'SOURCE_SHA256.json') == receipt['source_manifest_sha256']
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 506 and all(sha(s / n) == v for n, v in m.items())
a = b / 'phase-final-check-gpu-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():
            t.add(p, arcname=p.name, recursive=False)
    t.add(s / 'SOURCE_SHA256.json', arcname='SOURCE_SHA256.json', recursive=False)
    for name in ['control_phase_final_check_gpu_a.py', 'launch_phase_final_check_gpu_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, counts=receipt['counts'], seconds=d['seconds'])))

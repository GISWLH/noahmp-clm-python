from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-assessment-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'p6-stem-assessment-a-source.tar.gz';assert sha(a)=='214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
def run(label,files,expected):
 start=time.monotonic();xml=r/(label+'.xml')
 with (r/(label+'.log')).open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 counts={key:sum(int(v.attrib[key]) for v in ET.parse(xml).getroot().iter('testsuite')) for key in ['tests','failures','errors','skipped']};same=all(sha(s/n)==v for n,v in m.items());d=dict(scope='Exact506 assessment-only revision, all production model/GPU/native driver bytes identical to506F. Synthetic full-calendar transaction/SAI/provenance gates are not real climate spinup or observational acceptance.',returncode=code,counts=counts,expected_tests=expected,source_files=506,source_unchanged=same,source_archive_sha256=sha(a),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start);(r/(label+'-receipt.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return code==0 and same and counts==dict(tests=expected,failures=0,errors=0,skipped=0)
if not run('targets',['tests/test_clm_spinup.py','tests/test_hrldas_native_year.py'],69):raise SystemExit(1)
files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
raise SystemExit(0 if run('cpu-full',files,899) else 1)

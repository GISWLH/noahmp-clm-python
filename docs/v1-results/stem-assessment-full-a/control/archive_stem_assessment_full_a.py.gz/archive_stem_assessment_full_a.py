from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-assessment-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,count in [('targets',69),('cpu-full',899)]:
 d=json.loads((r/(label+'-receipt.json')).read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=count,failures=0,errors=0,skipped=0)
assert (r/'pbs-exit.txt').read_text().strip()=='0';a=b/'stem-assessment-full-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname=p.name,recursive=False)
 with tarfile.open(b/'p6-stem-assessment-a-source.tar.gz') as source:
  for n in ['benchmarks/assess_clm_spinup.py','benchmarks/compare_hrldas_native_year.py','tests/test_clm_spinup.py','tests/test_hrldas_native_year.py']:
   member=source.getmember(n);t.addfile(member,source.extractfile(member))
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

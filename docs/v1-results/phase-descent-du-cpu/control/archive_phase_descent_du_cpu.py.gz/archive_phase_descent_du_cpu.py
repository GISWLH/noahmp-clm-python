from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-descent-du-cpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (r/'pbs-exit.txt').read_text().strip()=='0';meta=json.loads((r/'package.json').read_text())
for stem,count in [('target',43),('full',1120)]:
    d=json.loads((r/(stem+'-receipt.json')).read_text());assert d['returncode']==0 and d['source_unchanged'] and d['source_manifest_sha256']==meta['manifest_sha256'] and d['counts']==dict(tests=count,failures=0,errors=0,skipped=0) and sha(r/(stem+'.xml'))==d['xml_sha256']
items=[(p,'cpu/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['clm-phase-descent-du-source.tar.gz','dispatch_phase_descent_du_cpu.py',Path(__file__).name]);a=b/'phase-descent-du-cpu-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

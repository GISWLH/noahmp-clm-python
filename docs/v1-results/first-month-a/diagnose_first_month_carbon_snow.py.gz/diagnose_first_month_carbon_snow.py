from pathlib import Path
from datetime import datetime
import hashlib,json,os,time
import numpy as np
assert os.environ.get('PBS_JOBID')
root=Path.cwd();base=root.parent;prefix=base/'suction-i1488-prefix';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();out=root/'first-month-carbon-snow.json';assert not out.exists()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in manifest.items());begin=time.monotonic();sites={}
for site in ['CN-Cng','CN-Qia','CN-Cha','CN-HaM']:
    folder=prefix/(site+'-suction-climate-cycle');reports=list(folder.glob('report-0001488-*.json'));assert len(reports)==1
    report_path=reports[0];r=json.loads(report_path.read_text());trace_path=folder/Path(r['model_npz']).name
    weather=base/'fluxnet-first-climate-cycle-20261017-h/inputs'/(site+'.npz');config=base/'fluxnet-first-climate-cycle-20261017-h/inputs'/(site+'-config.json')
    assert r['status']=='running' and r['steps_completed']==1488 and r['steps_requested']==17520 and sha(trace_path)==r['model_npz_sha256'] and sha(weather)==r['forcing_npz_sha256'] and sha(config)==r['configuration_sha256']
    c=json.loads(config.read_text())
    with np.load(trace_path,allow_pickle=False) as z:
        flux={key:float(np.asarray(z[key],float).sum()) for key in ['gpp_gc_m2','nee_gc_m2','autotrophic_respiration_gc_m2','heterotrophic_respiration_gc_m2']}
        summary=dict(lai_initial_from_config=float(c['column']['lai']),lai_first_end=float(z['lai'][0]),lai_last=float(z['lai'][-1]),lai_minimum=float(z['lai'].min()),lai_maximum=float(z['lai'].max()),
            swe_initial_from_config_m=c['column']['swe'],swe_last_m=float(z['swe_m'][-1]),swe_minimum_m=float(z['swe_m'].min()),swe_maximum_m=float(z['swe_m'].max()))
    with np.load(weather,allow_pickle=False) as z:
        months=np.array([str(s)[:6] for s in z['time_start']]);f=np.asarray(z['forcing'],float)
        precipitation={month:float(np.sum(f[months==month,7]*f[months==month,0])*1000.) for month in sorted(set(months))}
    sites[site]=dict(scope='Model-only component/forcing inventory for fixed first January; no causal attribution or parameter fit.',carbon_integrals_gc_m2=flux,
        diagnostic_nee_ra_rh_gpp_identity_residual_gc_m2=flux['nee_gc_m2']-flux['autotrophic_respiration_gc_m2']-flux['heterotrophic_respiration_gc_m2']+flux['gpp_gc_m2'],
        state_summary=summary,original_full_forcing_monthly_precipitation_mm=precipitation,
        initial_soil_carbon_pools_gc_m2=c['biogeochemistry']['soil_state']['carbon'],initial_plant_carbon_pools_gc_m2=c['biogeochemistry']['plant_state']['carbon'],
        source_sha256={str(p):sha(p) for p in [report_path,trace_path,weather,config]})
assert all(sha(root/k)==v for k,v in manifest.items())
result=dict(scope='Original first-month carbon partition and snow/precipitation inventory; no physical integration or acceptance/causality claim.',node=os.uname().nodename,pbs_job=os.environ['PBS_JOBID'],seconds=time.monotonic()-begin,source_unchanged=True,sites=sites,instrument_sha256=sha(__file__))
out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result,allow_nan=False),flush=True)

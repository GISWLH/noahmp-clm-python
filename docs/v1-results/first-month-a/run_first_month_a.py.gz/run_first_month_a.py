from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();base=root.parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in m.items())
previous=json.loads((base/'p6-public-clm-driver-b/SOURCE_SHA256.json').read_text());assert all(previous[k]==v for k,v in m.items() if k.startswith('src/'))
prefix=base/'suction-i1488-prefix';index=json.loads((prefix/'immutable-1488-export.json').read_text());gpu=json.loads((prefix/'gpu-SOURCE_SHA256.json').read_text())
for case in index['cases']:
    r=json.loads((prefix/case['case']/case['report']).read_text());assert all(gpu[k]==v for k,v in r['source_sha256'].items())
files=sorted(str(p) for p in Path('tests').glob('test_hrldas*.py'))+['tests/test_clm_first_month.py','tests/test_fluxnet_evaluation.py','tests/test_fluxnet_soil_operator.py']
begin=time.monotonic();code=subprocess.run([sys.executable,'-m','pytest','-q',*files,'--junitxml=first-month-target.xml']).returncode
counts={k:sum(int(s.attrib[k]) for s in ET.parse('first-month-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
comparison_code=None;comparison_seconds=None
if code==0:
    command=[sys.executable,'-u',str(root/'benchmarks/compare_clm_first_month.py'),'--model-root',str(prefix),'--configuration-root',str(base/'fluxnet-first-climate-cycle-20261017-h/inputs'),
        '--reference-root',str(base/'hrldas-three-climate-b'),'--reference-archive',str(base/'hrldas-three-climate-b-evidence.tar.gz'),'--soil-operators',str(root/'soil-operators'),'--output',str(root/'first-month-comparison.json')]
    start=time.monotonic()
    with (root/'first-month-comparison.log').open('w') as stream:comparison_code=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT).returncode
    comparison_seconds=time.monotonic()-start
assert all(sha(root/k)==v for k,v in m.items())
(root/'first-month-receipt.json').write_text(json.dumps(dict(target_returncode=code,comparison_returncode=comparison_code,counts=counts,seconds=time.monotonic()-begin,comparison_seconds=comparison_seconds,
    source_files=len(m),source_unchanged=True,runtime_identical_public_b=True,original_i_report_source_identities_verified=True,node=os.uname().nodename,pbs_job=os.environ['PBS_JOBID'],files=files,
    scope='Synthetic/data-integrity tests plus actual January official and observed diagnostic evaluation; no full annual, spinup/calibration/holdout or scientific acceptance.'),indent=2)+'\n')
assert code==0 and comparison_code==0 and counts['failures']==counts['errors']==counts['skipped']==0

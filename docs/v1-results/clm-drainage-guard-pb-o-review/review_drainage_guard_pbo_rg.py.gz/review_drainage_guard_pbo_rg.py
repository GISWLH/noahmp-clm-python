"""Independent stdlib review of frozen PB-o source/stage; no model imports."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()


def untar(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: archive.extractfile(m).read() for m in members}


def main():
    manifests = {
        'preparation': 'eaaec34067f643e5efa6dbe69686cf7cd34542bf3a38fdaac275ce21a76a939c',
        'execution': '770ae4960e0b5f86edb16af9754790f7f3bb98cdde441d2a347b1af54383e94d'}
    controls = {}
    for folder, expected in manifests.items():
        path = OUT / ('clm-drainage-guard-pb-o-' + folder)
        raw = (path / 'CONTROLS_SHA256.json').read_bytes()
        assert sha(raw) == expected
        index = json.loads(raw)
        actual = {p.relative_to(path).as_posix(): p.read_bytes() for p in path.rglob('*') if p.is_file()}
        assert set(actual) == set(index) | {'CONTROLS_SHA256.json'}
        assert all(sha(actual[name]) == value for name, value in index.items())
        assert len(index) == {'preparation': 17, 'execution': 12}[folder]
        for name, value in actual.items():
            if name.endswith('.py'):
                compile(ast.parse(value), name, 'exec')
        controls[folder] = actual
    binding = json.loads(controls['preparation']['BINDINGS.json'])
    source_raw = (OUT / binding['source_archive']).read_bytes()
    assert sha(source_raw) == binding['source_archive_sha256'] == '2fb0a929d97fe9af2880aa802e15701cf85da395df12a473062a49e1c8c853bc'
    source = untar(source_raw)
    source_index = json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index) == 594 and set(source) == set(source_index) | {'SOURCE_SHA256.json'}
    assert sha(source['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
    assert all(sha(source[name]) == value for name, value in source_index.items())
    parent_raw = (OUT / binding['parent_archive']).read_bytes()
    assert sha(parent_raw) == binding['parent_archive_sha256']
    parent = untar(parent_raw)
    parent_index = json.loads(parent['SOURCE_SHA256.json'])
    assert len(parent_index) == 593
    changed = sorted(n for n in parent_index if source[n] != parent[n])
    added = sorted(set(source_index) - set(parent_index))
    assert set(changed) == set(binding['modified_new_PBn_modules']) and added == list(binding['new_files'])
    for name in changed:
        change = binding['modified_new_PBn_modules'][name]
        assert sha(parent[name]) == change['old_sha256'] and sha(source[name]) == change['new_sha256']
        rebuilt = parent[name].decode()
        for replacement in change['replacements']:
            assert rebuilt.count(replacement['old']) == 1
            rebuilt = rebuilt.replace(replacement['old'], replacement['new'])
        assert rebuilt.encode() == source[name]
    tests = ast.parse(controls['preparation']['test_guard_pbo.py'])
    methods = [n.name for n in ast.walk(tests) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    assert len(methods) == len(set(methods)) == 12
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr.startswith('skip') for n in ast.walk(tests))

    stage_meta = json.loads((OUT / 'clm-drainage-guard-pb-o-stage-preparation.json').read_bytes())
    stage_raw = (OUT / 'clm-drainage-guard-pb-o-stage.tar.gz').read_bytes()
    assert sha(stage_raw) == stage_meta['stage_sha256'] == 'c280749d25b0e8c948209dcb38b1729062bac2fee9dad79bea31edd6cf9594c6'
    stage = untar(stage_raw)
    stage_index = json.loads(stage['stage-inventory.json'])
    assert len(stage) == 38 and set(stage_index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[name]) == value for name, value in stage_index.items())
    assert stage['source.tar.gz'] == source_raw
    for folder, files in controls.items():
        assert all(stage[folder + '/' + name] == value for name, value in files.items())
    gold = (OUT / 'drainage-gold-po-b-evidence.tar.gz').read_bytes()
    assert stage['gold.tar.gz'] == gold and sha(gold) == '6ccfddeff32993f82819c9425774d6b3da7cfbc1e0e17ea14acf24aaa272db51'
    gold_files = untar(gold)
    gold_index = json.loads(gold_files['artifact-inventory.json'])
    assert len(gold_files) == 345 and set(gold_index) == set(gold_files) - {'artifact-inventory.json'}
    assert all(sha(gold_files[name]) == value for name, value in gold_index.items())
    ref = json.loads(stage['reference/CONTROLS_SHA256.json'])
    assert all(sha(stage['reference/' + n]) == h for n, h in ref.items())
    gold_binding = json.loads(stage['reference/GOLD32_BINDINGS.json'])
    assert gold_binding['archive_sha256'] == sha(gold)
    assert all(sha(gold_files[n]) == h for n, h in gold_binding['members'].items())
    base = json.loads(stage['reference/BASE_PBL_SOURCE_SHA256.json'])
    assert len(base) == 586 and all(source_index[n] == h for n, h in base.items())
    reuse = json.loads(controls['execution']['REUSE_BINDINGS.json'])
    evidence_raw = (OUT / 'clm-drainage-package-pb-n-evidence.tar.gz').read_bytes()
    assert sha(evidence_raw) == reuse['parent_evidence_sha256'] == 'bd5e179136af200b9f57906c8334dc1a7473f8377cf317464fcbfc4fef71e9a7'
    evidence = untar(evidence_raw)
    for name, value in reuse['exact_retained_execution_members'].items():
        assert sha(controls['execution'][name]) == value
        assert controls['execution'][name] == evidence['execution/' + name]
    assert len(reuse['exact_retained_execution_members']) == 6
    assert stage['reference/parent1673-closed-run.json'] == evidence['closed-run.json']
    wrapper = controls['execution']['run_component_pb.py'].decode()
    assert wrapper.index('guard_result = subprocess.run') < wrapper.index("assert guard_result.returncode == 0 and len(testcases) == 12") < wrapper.index('result = subprocess.run(command,')
    assert "assert receipt['guard_failures'] == receipt['guard_errors'] == receipt['guard_skipped'] == 0" in wrapper
    assert "str(root / 'source/src')" in wrapper and "len(source_index) == 594" in wrapper
    report = dict(passed=True, blocking_findings=[], nonblocking_findings=[],
        preparation_manifest_sha256=manifests['preparation'], execution_manifest_sha256=manifests['execution'],
        controls=29, stage_archive_sha256=sha(stage_raw), stage_members=38,
        source_archive_sha256=sha(source_raw), source_files=594, unchanged_PBl_files=586,
        source_guard_only_changes=changed, source_added=added,
        gold_archive_sha256=sha(gold), gold_members=345,
        original1673_execution_members_exact=list(reuse['exact_retained_execution_members']),
        guard_test_names=methods, guard_tests_run_before_parity=True,
        planned_parity={'recipes': 20, 'trial_returns': 20, 'full_returns': 17, 'numeric_fields': 1106},
        manual_review=['All eight new entries reject raw metadata mismatches before their original conversions/backends/phase.',
            'Explicit pack32 is retained; four candidate modules equal parent bytes except the declared guard insertions.',
            'Original CUDA kernels and typed NumPy32 phase are among unchanged base586 files.',
            'Guard pytest and parity use separate child interpreters with source/src first in PYTHONPATH; 12 zero-failure/zero-skip tests gate parity.',
            'Parity verifies original imported module paths/SHA and exact1665 input32; it cannot silently use installed old primitives.',
            'All sealed numeric dtype/shape/bytes, original64eps-hard-ledger expressions and observed execution counters remain in original1673 six-file driver.',
            'Timeout/failure remains nonzero with logs, partial results and wrapper receipt; no numerical acceptance exists yet.'],
        numerical_execution=False, PBS_submitted=False, model_imports=0,
        scope='Static stdlib source/archive/AST and manual execution-path review only; not guard/parity/device execution.')
    target = OUT / 'clm-drainage-guard-pb-o-independent-review-rg.json'
    target.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(passed=True, blocking_findings=[], review_sha256=sha(target.read_bytes()), stage_sha256=sha(stage_raw))))


if __name__ == '__main__':
    main()

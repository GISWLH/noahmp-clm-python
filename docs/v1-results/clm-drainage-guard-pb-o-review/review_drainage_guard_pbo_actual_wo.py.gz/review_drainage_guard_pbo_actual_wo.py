"""Narrow independent PB-o closure audit; stdlib headers/opaque bytes only."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import math
import re
import xml.etree.ElementTree as ET
from review_drainage_gold_pob_wo import untar, check_npz, terminal

BASE = Path(__file__).resolve().parent
sha = lambda body: hashlib.sha256(body).hexdigest()


def main():
    label = 'clm-drainage-guard-pb-o'
    package = json.loads((BASE / (label + '-package.json')).read_bytes())
    body = (BASE / package['archive']).read_bytes()
    assert sha(body) == package['sha256'] == 'e53c2cb8d5b79059e9784b3a33b9f79e48096b9957a32d272de1460d4a84ced2'
    assert len(body) == package['bytes'] == 539972
    raw = untar(body)
    assert len(raw) == package['artifacts'] == 274
    get = lambda n: json.loads(raw[n])
    index = get('artifact-inventory.json')
    assert set(raw) == set(index) | {'artifact-inventory.json'}
    assert all(sha(raw[n]) == item['sha256'] and len(raw[n]) == item['bytes'] for n, item in index.items())
    terminal(raw['scheduler/actual-qstat.txt'], '1678.manager', 0)
    assert re.search(rb'^\s*exec_host = compute002/', raw['scheduler/actual-qstat.txt'], re.M)
    assert raw['worker-exit.txt'].strip() == raw['scheduler/pbs-exit.txt'].strip() == b'0'
    assert raw['scheduler/qsub.stdout.txt'].strip() == b'1678.manager'
    receipt, summary = get('receipt.json'), get('parity/summary.json')
    assert receipt['pbs_job'] == '1678.manager' and receipt['node'] == 'compute002' and receipt['passed']
    assert receipt['guard_parent_returncode'] == receipt['numerical_parent_returncode'] == 0
    assert receipt['guard_tests'] == 12 and receipt['guard_failures'] == receipt['guard_errors'] == receipt['guard_skipped'] == 0
    xml = ET.fromstring(raw['guard-tests.xml'])
    tests = list(xml.iter('testcase'))
    assert len(tests) == 12 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in tests)
    suite = next(xml.iter('testsuite'))
    assert {k:suite.attrib[k] for k in ('tests','failures','errors','skipped')} == dict(tests='12',failures='0',errors='0',skipped='0')
    assert suite.attrib['hostname'] == 'compute002'
    names = [c.attrib['name'] for c in tests]
    tree = ast.parse(raw['preparation/test_guard_pbo.py'])
    assert set(names) == {n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
    assert re.search(rb'12 passed in [0-9.]+s', raw['guard.stdout.txt']) and not raw['guard.stderr.txt'].strip()
    assert 'from noahmp_clm.gpu import _clm_drainage_input_guard as guard' in raw['preparation/test_guard_pbo.py'].decode()
    assert not raw['numerical.stderr.txt'].strip()
    parent_body = (BASE / 'clm-drainage-package-pb-n-evidence.tar.gz').read_bytes()
    reuse = get('execution/REUSE_BINDINGS.json')
    assert sha(parent_body) == reuse['parent_evidence_sha256'] == 'bd5e179136af200b9f57906c8334dc1a7473f8377cf317464fcbfc4fef71e9a7'
    parent = untar(parent_body)
    terminal(parent['scheduler/actual-qstat.txt'], '1673.manager', 0)
    assert len(reuse['exact_retained_execution_members']) == 6
    assert all(raw['execution/'+n] == parent['execution/'+n] and sha(raw['execution/'+n]) == h for n,h in reuse['exact_retained_execution_members'].items())
    source_body = (BASE / (label+'-source.tar.gz')).read_bytes()
    assert sha(source_body) == receipt['source_archive_sha256'] == package['source_archive_sha256']
    source = untar(source_body)
    assert source['SOURCE_SHA256.json'] == raw['source-manifest.json']
    source_index = get('source-manifest.json')
    assert len(source_index) == 594 and len(source) == 595 and all(sha(source[n]) == h for n,h in source_index.items())
    base = get('reference/BASE_PBL_SOURCE_SHA256.json')
    assert len(base) == 586 and all(source_index[n] == h for n,h in base.items())
    guard_name = 'src/noahmp_clm/gpu/_clm_drainage_input_guard.py'
    assert source[guard_name] == raw['preparation/new-files/'+guard_name]
    guard_tree = ast.parse(source[guard_name])
    assert {'require_trial_inputs','require_adaptive_inputs','require_jax_precision'} <= {n.name for n in guard_tree.body if isinstance(n,ast.FunctionDef)}
    for item in get('parity/module-paths.json').values():
        assert item['path'].startswith('/var/tmp/pbs.1678.manager/result/source/src/') and item['sha256'] == source_index[item['source_relative_path']]
    gold_body = (BASE / 'drainage-gold-po-b-evidence.tar.gz').read_bytes()
    assert sha(gold_body) == receipt['gold_archive_sha256'] == '6ccfddeff32993f82819c9425774d6b3da7cfbc1e0e17ea14acf24aaa272db51'
    gold = untar(gold_body)
    assert len(gold) == 345
    gold_index = json.loads(gold['artifact-inventory.json'])
    assert set(gold) == set(gold_index) | {'artifact-inventory.json'} and all(sha(gold[n]) == h for n,h in gold_index.items())
    immutable = {}
    for folder,count in (('preparation',17),('execution',12),('reference',3)):
        controls = get(folder+'/CONTROLS_SHA256.json')
        assert len(controls) == count and all(sha(raw[folder+'/'+n]) == h for n,h in controls.items())
        immutable.update({folder+'/'+n:h for n,h in controls.items()})
        immutable[folder+'/CONTROLS_SHA256.json'] = sha(raw[folder+'/CONTROLS_SHA256.json'])
    immutable.update({'source/'+n:sha(b) for n,b in source.items()})
    immutable.update({'sealed-gold/'+n:sha(b) for n,b in gold.items()})
    assert immutable == get('immutable-before.json') == get('immutable-after.json')
    assert len(immutable) == receipt['immutable_files_verified'] == 975
    assert sha(raw['preparation/CONTROLS_SHA256.json']) == receipt['preparation_manifest_sha256']
    assert sha(raw['execution/CONTROLS_SHA256.json']) == receipt['execution_manifest_sha256']
    target_bindings = get('reference/GOLD32_BINDINGS.json')['members']
    assert all(raw['original1665/'+n] == gold[n] and sha(gold[n]) == h for n,h in target_bindings.items())
    lines = raw['numerical.stdout.txt'].decode().splitlines()
    rows = [json.loads(line.removeprefix('PB_N_PARITY ')) for line in lines if line.startswith('PB_N_PARITY ')]
    assert rows == summary['records'] and len(rows) == 20 and json.loads(lines[-1]) == summary
    assert summary['passed'] and summary['completed_cases'] == 20
    trial = full = inverse = fields = npz_count = npy_count = 0
    hard = []
    for row in rows:
        name = row['case']; prefix = 'parity/'+name+'/'; old = 'original1665/gold/'+name+'/'
        observed, run = get(prefix+'observed-calls.json'), get(prefix+'run.json')
        assert row['passed'] and row['observed'] == observed
        assert observed['actual_trial_calls'] == observed['trial_attempted'] == 1
        assert observed['actual_full_calls'] == observed['full_attempted'] and observed['actual_full_calls'] in (0,1)
        if observed['actual_full_calls']:
            assert observed['phase']['all_converged'] and observed['phase']['input_dtype'] == 'float32'
        for key in ('phase','actual_trial_calls','actual_full_calls','trial_attempted','full_attempted','returned_nonnumeric','hard_ledgers','transferred_inputs_byteexact'):
            assert run[key] == json.loads(parent[prefix+'run.json'])[key] == get(old+'numpy32-run.json')[key]
        trial += observed['actual_trial_calls']; full += observed['actual_full_calls']; inverse += observed['phase'].get('actual_inverse_calls',0)
        actual_meta, old_meta = get(prefix+'actual32.npz.json'), get(old+'numpy32.npz.json')
        actual = check_npz(raw[prefix+'actual32.npz'],actual_meta)
        expected = check_npz(raw[old+'numpy32.npz'],old_meta)
        inputs = check_npz(raw[old+'input32.npz'],get(old+'input32.npz.json'))
        npz_count += 3; npy_count += len(actual)+len(expected)+len(inputs)
        assert actual == expected and actual_meta['arrays'] == old_meta['arrays']
        assert all(inputs[k]['dtype'] == '<f4' for k in ('cells','parameters','interval'))
        compare = get(prefix+'all-numeric-byte-comparison.json')
        assert set(compare) == set(actual) and len(compare) == row['numeric_fields']
        assert all(v['passed'] and v['dtype_equal'] and v['shape_equal'] and v['bytes_equal'] and v['actual']==v['expected']==old_meta['arrays'][k] for k,v in compare.items())
        fields += len(compare)
        for stage,channels in run['hard_ledgers'].items():
            for channel,budget in channels.items():
                assert budget['original_factor'] == 64 and budget['explicit_dtype'] == 'float32' and budget['backend'] == 'numpy' and budget['passed']
                assert all(math.isfinite(budget[k]) for k in ('native_residual','independent_residual','original_bound'))
                assert abs(budget['native_residual']) <= budget['original_bound'] and abs(budget['independent_residual']) <= budget['original_bound']
                hard.append(dict(case=name,stage=stage,channel=channel,**budget))
    assert (trial,full,inverse,fields,npz_count,npy_count) == (20,17,5768,1106,60,2292)
    assert len(hard) == 74 and hard == get('run-readout.json')['original_hard_budget_rows']
    maxima = {channel:dict(maximum_absolute_residual=max(abs(r['native_residual']) for r in hard if r['channel']==channel),
                maximum_original_bound_fraction=max(abs(r['native_residual'])/r['original_bound'] for r in hard if r['channel']==channel)) for channel in ('water','heat')}
    for key in ('GPU_calls','JAX_calls','float64_component_calls','coupled_column_runs'):
        assert receipt[key] == summary[key] == 0
    publication = BASE.parents[1] / 'docs/v1-results' / label
    manifest = json.loads((publication/'manifest.json').read_bytes())
    assert manifest['archive_sha256'] == package['sha256'] and len(manifest['artifacts']) == 274
    for item in manifest['artifacts']:
        stored = (publication/item['path']).read_bytes()
        assert sha(stored) == item['stored_sha256']
        content = gzip.decompress(stored) if item['path'].endswith('.gz') and not item['source'].endswith('.gz') else stored
        assert content == raw[item['source']] and sha(content) == item['source_sha256']
    result = dict(passed=True,blocking_findings=[],actual_static_exit=0,archive_sha256=package['sha256'],artifacts=274,
        actual_job='1678.manager',actual_F0=True,Stageout_status=0,guard_parent_exit=0,numerical_parent_exit=0,
        guard_tests=names,guard_XML_seconds=float(suite.attrib['time']),guard_worker_seconds=receipt['guard_seconds'],
        guard_failures=0,guard_errors=0,guard_skipped=0,parent1673_retained_execution_files=6,
        source_files=594,unchanged_PBl_files=586,guard_source_sha256=source_index[guard_name],
        guard_import_evidence='Original pytest12 executed the qualified new guard import and its assertions under frozen source-first PYTHONPATH; four measured package module paths resolve to that source. Guard __file__ was not separately printed; no standalone path-observer evidence is claimed.',
        immutable_before_after_files=975,actual_trial_calls=trial,actual_full_calls=full,actual_successful_phase_inverse_calls=inverse,
        complete_numeric_fields_dtype_shape_payload_equal=fields,npz_header_payloads_checked=npz_count,npy_header_payloads_checked=npy_count,
        original_hard_budget_rows=74,maxima=maxima,publication_files_verified=274,
        preparation_manifest_sha256=receipt['preparation_manifest_sha256'],execution_manifest_sha256=receipt['execution_manifest_sha256'],
        worker_seconds=receipt['seconds'],numeric_seconds=summary['seconds'],
        scope='CPU guard negative/metadata checks and exact NumPy32 parity only. No JAX/CUDA device, float64 component, native ABI, coupled-column or annual credit. Local checks are stdlib raw logs/XML/JSON/NPY header and opaque payload SHA; zero local numerical imports or execution.',
        script_sha256=sha(Path(__file__).read_bytes()),header_helper_sha256=sha((BASE/'review_drainage_gold_pob_wo.py').read_bytes()))
    target=BASE/(label+'-actual-independent-review-wo.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(passed=True,blocking_findings=[],review_sha256=sha(target.read_bytes()),guard_tests=12,fields=fields,source_files=594,publication_files=274,maxima=maxima)))


if __name__ == '__main__':
    main()

"""Evaluate a genuinely completed EC CUDA year, preserving backend/source identity."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics'];b=Path('/home/zhangyq/noahmp-v1');r=Path(os.environ['NV_ROOT'])/'evaluation';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-phase-descent-ec-source.tar.gz';assert sha(a)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from compare_hrldas_native_year import check_ledgers,check_final_checkpoint
from noahmp_clm.validation import compare_series
packet=Path(os.environ['NV_ROOT'])/'native-year.tar.gz';packet_metadata=json.loads((r/'packet.json').read_text());assert sha(packet)==packet_metadata['sha256']
root=r/'device';root.mkdir()
with tarfile.open(packet) as tf:tf.extractall(root,filter='data')
parent=json.loads((root/'year-exit.json').read_text());d=json.loads((root/'year-receipt.json').read_text())
assert parent['returncode']==0 and parent['passed'] and sha(root/'year-receipt.json')==parent['receipt_sha256']
assert d['failure'] is None and d['source_unchanged'] and d['status']=='complete' and d['steps_completed']==d['steps_requested']==17520 and d['device_barrier_complete'] and d['source_manifest_sha256']==manifest
assert (root/'SOURCE_SHA256.json').read_bytes()==(s/'SOURCE_SHA256.json').read_bytes()
folder=root/'trajectory';batch,saved,pairs=native.read_generation(folder);assert len(pairs)==1
report,model=pairs[0];cfg=report['configuration']
assert report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520 and report['source_unchanged'] and report['source_sha256']==native.source_hashes() and report['backend']=='cuda32' and report['same_precision_max_absolute'] is None
assert batch['status']=='complete' and batch['steps_completed']==batch['steps_requested']==17520 and int(saved['index'])==17520
ledger_checks=check_ledgers(model,report);final_checks=check_final_checkpoint(folder/batch['checkpoint_file'],model,report)
report_path=folder/report['case']/batch['case_reports'][report['case']]['file']
assert sha(report_path)==batch['case_reports'][report['case']]['sha256']
inputs=Path(os.environ['TMPDIR'])/'inputs';inputs.mkdir();a=b/'qia-phase-cold-ef-inputs.tar.gz';assert sha(a)=='2325f371ca0fe1a798be898449525bf51b45f46758d772e644644037152046bb'
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
config_files=[p for p in inputs.rglob('*.json') if sha(p)==report['configuration_sha256']];assert len(config_files)==1 and json.loads(config_files[0].read_text())==cfg
assert sha(inputs/'CN-Qia.npz')==report['forcing_npz_sha256'] and sha(inputs/'CN-Qia.json')==report['forcing_manifest_sha256']
assert str(model['time_start'][0])=='200301010000' and str(model['time_end'][-1])=='200401010000';n=17520;official=b/'ctsm-qia-run-r';boundary=json.loads((official/'year-boundary.json').read_text());assert (official/'pbs-exit.txt').read_text().strip()=='0' and sha(official/'official-year-fields.npz')==boundary['fields_sha256']
with np.load(official/'official-year-fields.npz',allow_pickle=False) as z:ref=dict(z)
assert ref['time_bounds_seconds'].shape==(n,2) and np.array_equal(ref['time_bounds_seconds'],np.arange(n)[:,None]*1800+[[0,1800]])
start=time.monotonic();failure=None
try:
    dz=np.asarray(cfg['column']['dz'],float);te=np.r_[0.,np.cumsum(dz)];se=np.r_[0.,np.cumsum(np.asarray(ref['DZSOI'],float).reshape(15))];overlap=np.maximum(0.,np.minimum(te[1:,None],se[None,1:])-np.maximum(te[:-1,None],se[None,:-1]))/dz[:,None];assert np.max(abs(overlap.sum(1)-1.))<1e-14 and np.all(overlap[:,10:]==0.)
    series={}
    for name,source,factor,unit in [('h_wm2','FSH',1.,'h_wm2'),('le_wm2','EFLX_LH_TOT',1.,'le_wm2'),('et_mm','QFLX_EVAP_TOT',86400.,'et_mm_day'),('runoff_mm','QRUNOFF',86400.,'runoff_mm_day'),('gpp_gc_m2','FPSN',12.0107e-6*86400.,'gpp_gc_day'),('swe_m','H2OSNO',.001,'swe_m')]:
        actual=np.asarray(model[name],float).reshape(n)*(48. if name in ['et_mm','runoff_mm','gpp_gc_m2'] else 1.);expected=np.asarray(ref[source],float).reshape(n)*factor;series[name]=(actual,expected,unit)
    soil_t=np.asarray(ref['TSOI'],float).reshape(n,15)@overlap.T;soil_w=np.asarray(ref['H2OSOI'],float).reshape(n,10)@overlap[:,:10].T
    for name,expected,unit,offset in [('tsoil_k',soil_t,'tsoil_c',273.15),('smc_m3m3',soil_w,'smc',0.)]:
        for layer in range(4):series[name+'/'+str(layer)]=(model[name][:,layer]-offset,expected[:,layer]-offset,unit)
    assert len(series)==14;labels=np.asarray(model['time_start'],str);groups={'year':{'2003':np.ones(n,bool)},'daily':{},'monthly':{}}
    for frequency,width,count in [('daily',8,365),('monthly',6,12)]:
        stamps=np.asarray([value[:width] for value in labels]);unique=np.unique(stamps);assert len(unique)==count;groups[frequency]={name:stamps==name for name in unique}
    metrics={frequency:{date:{name:compare_series(x[mask],y[mask],unit,weights=np.full(int(mask.sum()),1800.)) for name,(x,y,unit) in series.items()} for date,mask in dates.items()} for frequency,dates in groups.items()}
    cumulative={}
    for frequency,dates in groups.items():
        cumulative[frequency]={}
        for date,mask in dates.items():
            cumulative[frequency][date]={}
            for name in ['h_wm2','le_wm2','et_mm','runoff_mm','gpp_gc_m2']:
                x,y,unit=series[name];factor=1800. if name in ['h_wm2','le_wm2'] else 1800./86400.
                cumulative[frequency][date][name]=dict(model_integral=float(np.sum(x[mask])*factor),reference_integral=float(np.sum(y[mask])*factor),integral_units='J/m2' if name in ['h_wm2','le_wm2'] else ('gC/m2' if name=='gpp_gc_m2' else 'mm'),intervals=int(mask.sum()))
    (r/'official-comparison.json').write_text(json.dumps(dict(metrics=metrics,period_integrals=cumulative,independent_ledger_checks=ledger_checks,independent_final_storage_checks=final_checks,backend='cuda32',cold_start_not_spinup=True,soil_overlap_weights=overlap.tolist(),source_manifest_sha256=manifest,model_report_sha256=sha(report_path),reference_full_fields_sha256=boundary['fields_sha256'],nee_reference_status='unmeasured: officialSP output has no matchingNEE reference',scope='All365days/12months/whole2003 fixedcoldyear, original14fields/10percent/r/nearzeroabsolute gates, temperatureC and soiloverlap preserved. Scientificfailures retained, no bestvariant/date selection, calibration or spinup claim.'),indent=2,allow_nan=False)+'\n')
    operator=b/'height-observations-ea/CN-Qia-soil-operator.json';assert sha(operator)=='49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095';(r/'soil-operator.json').write_bytes(operator.read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    command=[sys.executable,str(s/'benchmarks/evaluate_fluxnet_series.py'),'--model',str(report_path.parent/report['model_npz']),'--model-manifest',str(report_path),'--observations',str(inputs/'CN-Qia.npz'),'--observation-manifest',str(inputs/'CN-Qia.json'),'--soil-operator',str(r/'soil-operator.json'),'--output',str(r/'fluxnet-observations.json')]
    with (r/'observations.log').open('x') as log:code=subprocess.run(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    assert code==0,'Observation evaluator execution failure; original output retained'
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,case=label,evaluation_delivered=failure is None,failure=failure,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),model_report_sha256=sha(report_path),model_complete_steps=17520,reference_fields_sha256=boundary['fields_sha256'],output_sha256={p.name:sha(p) for p in [r/'official-comparison.json',r/'fluxnet-observations.json'] if p.exists()},seconds=time.monotonic()-start,scope='All2003daily/monthly/annual evaluation onlyafter actualcompleteEC CUDA-onlyyear parent0. Bothfixedvariants independent and retained; originalobservedQC/corrected/raw/GPPNT/DT/NEE/soil operators/gates, no per-score selection. OldECsource identity retained,not currentFL579/fullsameprecision credit. Successfulanalysisexit means allmetrics delivered, never scientificpass/spinup/multisite/multiyear/holdout/calibration or release.')
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert failure is None and d['source_unchanged']

"""Read-only export after actual EC optics year parent0; never runs a model."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import tarfile

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE / 'qia-phase-capacity_optics-cuda-year-ej'
SOURCE = Path('/tmp/noahmp-phase-descent-ec/source')
OUT = Path('/tmp/noahmp-ec-optics-year-nv-export')
MANIFEST = '96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())

terminal, receipt = read(ROOT / 'year-exit.json'), read(ROOT / 'year-receipt.json')
assert terminal['returncode'] == 0 and terminal['passed']
assert terminal['receipt_sha256'] == sha(ROOT / 'year-receipt.json')
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
assert receipt['status'] == 'complete' and receipt['steps_completed'] == receipt['steps_requested'] == 17520
assert receipt['source_manifest_sha256'] == MANIFEST
assert receipt['continued_fields_exact'] == 30 and receipt['first_continued_step_captured']
manifest = read(SOURCE / 'SOURCE_SHA256.json')
assert sha(SOURCE / 'SOURCE_SHA256.json') == MANIFEST and len(manifest) == 571
assert all(sha(SOURCE / n) == h for n, h in manifest.items())
folder = ROOT / 'trajectory'
report = read(folder / 'batch.json')
assert receipt['report_sha256'] == sha(folder / 'batch.json')
assert report['status'] == 'complete' and report['steps_completed'] == report['steps_requested'] == 17520
assert report['source_unchanged'] and report['same_precision_max_absolute'] is None
assert report['identity']['backend'] == 'cuda32' and not report['identity']['compare_jax32']
assert sha(folder / report['checkpoint_file']) == report['checkpoint_sha256']
files = [ROOT / n for n in ['year-exit.json', 'year-receipt.json', 'year-launch.json',
    'year-start-audit.json', 'prefix-verification.json', 'prefix-exit.json',
    'prefix-receipt.json', 'first-continued-step.npz']]
assert all(p.is_file() for p in files)
files += [folder / 'batch.json', folder / report['checkpoint_file']]
cold, = folder.glob('state-0000000-*.npz')
files.append(cold)
assert len(report['case_reports']) == 1
for name, descriptor in report['case_reports'].items():
    case = folder / name
    path = case / descriptor['file']
    data = read(path)
    assert sha(path) == descriptor['sha256']
    assert data['status'] == 'complete' and data['steps_completed'] == data['steps_requested'] == 17520
    assert data['batch_checkpoint_sha256'] == report['checkpoint_sha256']
    assert sha(case / data['model_npz']) == data['model_npz_sha256']
    assert (case / 'report.json').read_bytes() == path.read_bytes()
    files += [path, case / data['model_npz'], case / 'report.json']
    generation = cold.stem[len('state-'):]
    for stem, suffix in [('report-', '.json'), ('trace-', '.npz')]:
        path = case / (stem + generation + suffix)
        assert path.is_file()
        files.append(path)
payload = {}
for p in files:
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT.resolve())
    payload[p.relative_to(ROOT).as_posix()] = p.read_bytes()
payload['SOURCE_SHA256.json'] = (SOURCE / 'SOURCE_SHA256.json').read_bytes()
payload['export-controls/export_ec_optics_year_nv.py'] = Path(__file__).read_bytes()
inventory = {n: dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw)) for n, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = OUT / 'native-year.tar.gz'
assert OUT.is_dir() and not target.exists()
with tarfile.open(target, 'w:gz') as t:
    for name, raw in sorted(payload.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        t.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as t:
    assert {m.name: t.extractfile(m).read() for m in t} == payload
assert all(sha(SOURCE / n) == h for n, h in manifest.items())
assert receipt['report_sha256'] == sha(folder / 'batch.json')
value = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), case='capacity_optics',
    archive=target.name, sha256=sha(target), bytes=target.stat().st_size, artifacts=len(payload),
    original_parent_returncode=0, original_year_seconds=receipt['seconds'], original_controller_seconds=terminal['seconds'],
    original_root=str(ROOT), source_manifest_sha256=MANIFEST, model_complete_steps=17520,
    scope='Actual original EC571 CUDA-only complete optics year parent0. Original source/inputs/state/trace untouched. '
          'Read-only archive with original 30-field cold/final checkpoints and first continued step. '
          'No invented historical IG failure; original manifest is read from its actual private source path. '
          'No new model or NM acceptance; independent EHPC full-year science audit follows.')
(OUT / 'native-year-package.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)

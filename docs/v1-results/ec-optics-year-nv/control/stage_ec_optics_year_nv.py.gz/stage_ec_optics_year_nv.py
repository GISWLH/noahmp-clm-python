"""Build fresh analysis input only after a validated true terminal native export."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import tarfile

HERE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--export', type=Path, required=True)
args = parser.parse_args()
native = (args.export / 'native-year.tar.gz').read_bytes()
package_raw = (args.export / 'native-year-package.json').read_bytes()
package = json.loads(package_raw)
assert sha(native) == package['sha256'] and package['original_parent_returncode'] == 0
assert package['model_complete_steps'] == 17520 and package['case'] == 'capacity_optics'
assert package['source_manifest_sha256'] == '96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
with tarfile.open(fileobj=io.BytesIO(native)) as t:
    members = t.getmembers()
    assert all(m.isfile() for m in members) and len({m.name for m in members}) == len(members) == package['artifacts']
    raw = {m.name: t.extractfile(m).read() for m in members}
inventory = json.loads(raw['artifact-inventory.json'])
assert set(inventory) == set(raw) - {'artifact-inventory.json'}
assert all(sha(raw[n]) == v['sha256'] and len(raw[n]) == v['bytes'] for n, v in inventory.items())
terminal, receipt = json.loads(raw['year-exit.json']), json.loads(raw['year-receipt.json'])
assert terminal['returncode'] == 0 and terminal['passed'] and terminal['receipt_sha256'] == sha(raw['year-receipt.json'])
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
assert receipt['source_manifest_sha256'] == package['source_manifest_sha256'] == sha(raw['SOURCE_SHA256.json'])
assert receipt['status'] == 'complete' and receipt['steps_completed'] == receipt['steps_requested'] == 17520
assert receipt['report_sha256'] == sha(raw['trajectory/batch.json'])
files = {p.name: p.read_bytes() for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.md')}
assert 'plan.json' not in files
plan = dict(case='capacity_optics', source_manifest_sha256=package['source_manifest_sha256'],
    native_archive_sha256=sha(native), original_parent_returncode=0, original_year_steps=17520,
    controls_sha256={n: sha(v) for n, v in files.items()}, expected_reference_sha256={
        'clm-phase-descent-ec-source.tar.gz': '8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e',
        'qia-phase-cold-ef-inputs.tar.gz': '2325f371ca0fe1a798be898449525bf51b45f46758d772e644644037152046bb',
        'ctsm-qia-run-r/year-boundary.json': 'a4fae509ffcf461761627d4e5295e98d8b0837a82445e07063d73864b95d8405',
        'ctsm-qia-run-r/official-year-fields.npz': '431afb47af338a8fa8702a55044ee5a3b9e59647aba2bddbf4ac9317ba41a889',
        'ctsm-qia-run-r/pbs-exit.txt': '9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa',
        'height-observations-ea/CN-Qia-soil-operator.json': '49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095'},
    scope='Original EC571 complete optics native year, independent fixed all365days/12months/year audit only. '
          'No source, forcing, QC, operator, gate, period selection or new model change. '
          'Original scientific failures retained; never NM new-year acceptance.')
files.update({'plan.json': (json.dumps(plan, indent=2) + '\n').encode(),
              'native-year.tar.gz': native, 'native-year-package.json': package_raw})
target = HERE.parent / 'ec-optics-year-nv-input.tar.gz'
assert not target.exists()
with tarfile.open(target, 'w:gz') as t:
    for name, value in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(value)
        t.addfile(member, io.BytesIO(value))
with tarfile.open(target) as t:
    assert {m.name: t.extractfile(m).read() for m in t} == files
result = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
              artifacts=len(files), native_archive_sha256=sha(native), source_manifest_sha256=plan['source_manifest_sha256'],
              scope=plan['scope'], pbs_submitted=False)
(HERE.parent / 'ec-optics-year-nv-input-package.json').write_text(json.dumps(result, indent=2) + '\n')
(HERE.parent / 'ec-optics-year-nv-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(result, indent=2))

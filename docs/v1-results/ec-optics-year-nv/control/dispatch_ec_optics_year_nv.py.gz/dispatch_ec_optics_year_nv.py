"""Two explicit independent PBS analyses; original full-year evaluation bodies."""
from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys

ROOT = Path('/tmp/noahmp-ec-optics-year-nv')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
stage = sys.argv[1]
assert stage in ['evaluation', 'summary'] and os.uname().nodename == 'manager'
plan = read(ROOT / 'plan.json')
assert sha(ROOT / 'native-year.tar.gz') == plan['native_archive_sha256']
assert all(sha(ROOT / n) == h for n, h in plan['controls_sha256'].items())
assert all(sha(Path('/home/zhangyq/noahmp-v1') / n) == h for n, h in plan['expected_reference_sha256'].items())
manager = ROOT / (stage + '-manager')
assert not manager.exists()
parent_qstat = None
if stage == 'evaluation':
    code = "from pathlib import Path; p=Path(" + repr(str(ROOT)) + "); assert not p.exists(); p.mkdir()"
    subprocess.run(['ssh', 'compute002', 'python3 -B -c ' + shlex.quote(code)], check=True)
    names = [*plan['controls_sha256'], 'plan.json', 'native-year.tar.gz', 'native-year-package.json']
    subprocess.run(['scp', *[str(ROOT / n) for n in names], 'compute002:' + str(ROOT) + '/'], check=True)
else:
    parent = read(ROOT / 'evaluation-manager/dispatch.json')['pbs_job']
    parent_qstat = subprocess.check_output(['qstat', '-xf', parent], text=True)
    assert re.search(r'^\s*job_state = F\s*$', parent_qstat, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', parent_qstat, re.M)
    code = "from pathlib import Path; import json; r=Path(" + repr(str(ROOT / 'evaluation')) + "); assert (r/'pbs-exit.txt').read_text().strip()=='0'; d=json.loads((r/'receipt.json').read_text()); assert d['evaluation_delivered'] and d['source_unchanged'] and d['model_complete_steps']==17520"
    subprocess.run(['ssh', 'compute002', 'python3 -B -c ' + shlex.quote(code)], check=True)
code = "from pathlib import Path; import json,hashlib; r=Path(" + repr(str(ROOT)) + "); plan=json.loads((r/'plan.json').read_text()); assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in plan['controls_sha256'].items()); p=r/" + repr(stage) + "; assert not p.exists(); p.mkdir()"
if stage == 'evaluation':
    code += "; (p/'packet.json').write_text(json.dumps(dict(sha256=plan['native_archive_sha256'],archive='native-year.tar.gz'))+'\\n')"
subprocess.run(['ssh', 'compute002', 'python3 -B -c ' + shlex.quote(code)], check=True)
manager.mkdir()
if parent_qstat is not None:
    (manager / 'parent-actual-qstat.txt').write_text(parent_qstat)
worker = 'evaluate_ec_optics_year_nv.py' if stage == 'evaluation' else 'summarize_ec_optics_year_nv.py'
pbs = f'''#!/bin/bash
#PBS -N ec-optics-{stage}-nv
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=2gb:host=compute002_00260924
#PBS -l walltime=00:20:00
#PBS -j oe
#PBS -o {ROOT}/{stage}-pbs-output.log
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export NV_ROOT={ROOT} CAPACITY_CASE=capacity_optics
cd {ROOT}/{stage}
hostname >node.txt
{PYTHON} -B -u {ROOT}/{worker} >evaluation.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(manager / 'job.pbs').write_text(pbs)
job = subprocess.run(['qsub', str(manager / 'job.pbs')], cwd=manager, capture_output=True, text=True)
(manager / 'qsub-stdout.txt').write_text(job.stdout)
(manager / 'qsub-stderr.txt').write_text(job.stderr)
assert job.returncode == 0, job.stderr
value = dict(stage=stage, pbs_job=job.stdout.strip(), controls_sha256=plan['controls_sha256'],
    plan_sha256=sha(ROOT / 'plan.json'), pbs_sha256=sha(manager / 'job.pbs'),
    native_archive_sha256=plan['native_archive_sha256'], source_manifest_sha256=plan['source_manifest_sha256'],
    original_year_parent_returncode=0,
    scope='Original EC optics fixed complete17520 evaluation only. Actual independent PBS analysis, '
          '365days/12months/year, same scientific gates and all observed products/QC/operators. '
          'No new model, calibration, period selection or NM acceptance credit.')
(manager / 'dispatch.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)

"""Archive original completed EC optics and both real closed independent analyses."""
from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-ec-optics-year-nv')
BASE = Path('/home/zhangyq/noahmp-v1')
SOURCE = '96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_text())
plan = read(ROOT / 'plan.json')
assert all(sha((ROOT / n).read_bytes()) == h for n, h in plan['controls_sha256'].items())
assert all(sha((BASE / n).read_bytes()) == h for n, h in plan['expected_reference_sha256'].items())
payload, proof, results = {}, [], {}
for stage in ['evaluation', 'summary']:
    manager = ROOT / (stage + '-manager')
    launch = read(manager / 'dispatch.json')
    job = launch['pbs_job']
    qstat = subprocess.check_output(['qstat', '-xf', job], text=True)
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
    dest = ROOT / ('closed-' + stage)
    assert not dest.exists()
    subprocess.run(['scp', '-r', 'compute002:' + str(ROOT / stage), str(dest)], check=True)
    assert (dest / 'pbs-exit.txt').read_text().strip() == '0'
    receipt = read(dest / 'receipt.json')
    assert receipt.get('passed', receipt.get('evaluation_delivered')) and receipt['source_unchanged']
    assert receipt['source_manifest_sha256'] == SOURCE and receipt['pbs_job'] == job
    assert receipt['node'] == 'compute002'
    if stage == 'evaluation':
        assert receipt['model_complete_steps'] == 17520 and receipt['failure'] is None
        assert all(sha((dest / n).read_bytes()) == h for n, h in receipt['output_sha256'].items())
    else:
        assert receipt['summary_sha256'] == sha((dest / 'summary.json').read_bytes())
        summary = read(dest / 'summary.json')
        assert summary['model_complete_steps'] == 17520 and summary['case'] == 'capacity_optics'
        assert len(summary['official14fields']) == 14
        assert all(v['complete_days'] == 365 and v['complete_months'] == 12 for v in summary['official14fields'].values())
        assert summary['parent_evaluation_receipt_sha256'] == sha((results['evaluation'] / 'receipt.json').read_bytes())
    results[stage] = dest
    payload[stage + '/actual-qstat.txt'] = qstat.encode()
    for directory, prefix in [(dest, stage), (manager, stage + '/manager')]:
        for p in directory.rglob('*'):
            if p.is_file():
                assert not p.is_symlink()
                payload[prefix + '/' + p.relative_to(directory).as_posix()] = p.read_bytes()
    output = ROOT / (stage + '-pbs-output.log')
    if output.is_file():
        payload[stage + '/scheduler-output.log'] = output.read_bytes()
    proof.append(dict(stage=stage, pbs_job=job, actual_pbs_state='F', actual_pbs_exit=0,
                      receipt_sha256=sha((dest / 'receipt.json').read_bytes())))
for name in [*plan['controls_sha256'], 'plan.json', 'native-year.tar.gz', 'native-year-package.json']:
    payload['control/' + name] = (ROOT / name).read_bytes()
for name in ['clm-phase-descent-ec-source.tar.gz', 'qia-phase-cold-ef-inputs.tar.gz',
             'ctsm-qia-run-r/year-boundary.json', 'ctsm-qia-run-r/official-year-fields.npz',
             'ctsm-qia-run-r/pbs-exit.txt', 'height-observations-ea/CN-Qia-soil-operator.json']:
    payload['original-reference/' + name] = (BASE / name).read_bytes()
inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
archive = ROOT / 'ec-optics-year-nv-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for name, raw in sorted(payload.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        t.addfile(member, io.BytesIO(raw))
with tarfile.open(archive) as t:
    assert {m.name: t.extractfile(m).read() for m in t} == payload
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
    artifacts=len(payload), actual_completed_jobs=proof, source_manifest_sha256=SOURCE,
    original_year_parent_returncode=0, original_year_steps=17520,
    native_archive_sha256=plan['native_archive_sha256'], case='capacity_optics',
    scope='Original EC571 optics complete native17520 parent0 plus real independent EHPC full365days/12months/year '
          '14 official CTSM fields, every FLUXNET product/ownQC/operator, original all23 physical arrays and '
          '7 checkpoint ledger/index fields. Scientific failures and cold SOC transient remain explicit. '
          'Analysis success is not science acceptance; no NM584, spinup, new annual model or release credit.')
(ROOT / 'ec-optics-year-nv-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

# NV：旧 EC optics 完整年度独立评价

数值评价复用已实际完成的 capacity 年 IH1175/IM1176 两段代码。已核对原归档内脚本字节；适配只改 `/tmp` 结果根与 native 导出包路径，所有原断言、数值表达式、指标、QC、观测算子及门限不变，记录在 `path-adaptation.json`。未新跑模型，不修改观测、强迫、参数或筛选时段。

旧任务为 xuanze `qia-phase-capacity_optics-cuda-year-ej`，worker PID3042732，原 EC571 manifest `96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20`，不是 NM584。必须同时满足 `year-exit.json` 实际 parent0、完整回执、device barrier、17520/17520、同源哈希和完整冷/末状态链，才能调用只读导出。不得从 live 前缀推断完成。

导出脚本 `export_ec_optics_year_nv.py` 保留原冷/末23物理数组及7个 index/累计账字段、12个月完整 trace、首个继续步和实际回执；元数据/归档在 xuanze 执行，不计算任何新模型。原 IL 修复的 manifest 实际路径已保留，但不伪造 optics 曾发生 capacity 的 IG 路径错误。导出目标仅新 `/tmp/noahmp-ec-optics-year-nv-export`，不修改原轨迹。原 source/输入/输出全部为只读。

EHPC 执行位置固定 `/tmp/noahmp-ec-optics-year-nv`，PBS 强制 compute002_00260924、1 CPU、2 GiB、20分钟。原源码仅在每个作业的 PBS TMPDIR 解包，实际参考只读使用现有 `/home/zhangyq/noahmp-v1` 文件。`dispatch_ec_optics_year_nv.py evaluation` 独立提交全年评价；只有该 job 真实 F0 后，`dispatch_ec_optics_year_nv.py summary` 才提交原汇总。不能把 E/worker0当 F，也不能把分析 F0当科学通过。

全年固定 CN-Qia 2003，17520×1800秒：官方14字段逐365日、12月、全年，H/LE/ET/径流/GPP/SWE和四层土温、土湿；官方 SP 无匹配 NEE 则保留“未测”。FLUXNET 原 corrected/raw、GPP NT/DT、NEE、各自 QC 及原测深映射均保留。原 M/H/C/N 步/累计账、23状态的末储量、冷/末七库C和八项N、SWE消失端点及SOC冷启动漂移诊断均保留。一个冷年不能证明长期SOC准平衡。

已只读核验 EHPC 原输入：EC source包 `8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e`；EF强迫包 `2325f371ca0fe1a798be898449525bf51b45f46758d772e644644037152046bb`；官方 fields `431afb47af338a8fa8702a55044ee5a3b9e59647aba2bddbf4ac9317ba41a889`；土壤算子 `49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095`。无新下载/替换参考数据。

完成后 `archive_ec_optics_year_nv.py` 要求两段真实 F0，归档全部日/月/年原始指标、完整原 native 输出、源/参考/原QC观测输入、实际调度记录、控制和 SHA 清单，生成带 `scope` 的通用 package。输出实际偏差和失败项；绝不给 NM 新年度、当前GPU回归、spinup或发布记通过。

import sys,numpy as np,json
sys.path.insert(0,'tests')
from test_gpu_canopy_surface import cases
from noahmp_clm.gpu.cuda.canopy_surface import run_canopy_surface_cuda
import cupy as cp
r=run_canopy_surface_cuda(*cases(np.float32,6),raise_on_failure=False)
for k in ('converged','surface_evaluations','surface_temperature','surface_temperature_residual','thermal_snow_counts','thermal_layer_residual','thermal_layer_tolerance','snow_counts','soil_cells','energy_residual_jm2'):
 print(k,cp.asnumpy(r[k]),flush=True)

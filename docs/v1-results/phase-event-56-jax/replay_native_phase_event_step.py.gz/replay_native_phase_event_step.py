"""A new-source step from trusted saved operands; never rewrite old identity."""
from pathlib import Path
import argparse,hashlib,json,time,traceback
import numpy as np
from run_fluxnet_native import Backend,source_hashes,audit_step
from noahmp_clm.gpu.clm_bgc_column import next_bgc_arrays
from noahmp_clm.physics.photosynthesis import LeafParameters

p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--index',type=int,required=True)
p.add_argument('--backend',default='cuda32',choices=['cuda32','jax32']);args=p.parse_args()
root=args.root;dest=Path.cwd()/f'saved-step-{args.index}-{args.backend}-a';dest.mkdir(exist_ok=False)
old=json.loads((root/'cuda-year/batch.json').read_text());assert old['steps_completed']==args.index and old['status']=='failed'
prior=old['identity']['source_sha256'];current=source_hashes()
differences={k:dict(old=v,new=current[k]) for k,v in prior.items() if current[k]!=v}
assert set(differences)=={'src/noahmp_clm/gpu/column_heat.py',
    'src/noahmp_clm/gpu/cuda/column_heat_kernel.cu'}
path=root/f'failure-{args.index}-capture-a/whole-column-inputs.npz'
with np.load(path,allow_pickle=False) as z:x=dict(z)
before=tuple(x[f'a{k}'] for k in range(16));engine=Backend(args.backend);started=time.monotonic()
report=dict(scope='Actual failed four-column state and forcing under corrected numerical source. Not an annual resume or observation result.',
    backend=args.backend,input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_sha256=current,source_differences=differences)
def flatten(d,prefix=''):
    result={}
    for k,v in d.items():
        if isinstance(v,dict):result.update(flatten(v,prefix+k+'/'))
        else:result[prefix+k]=np.asarray(v)
    return result
try:
    device=tuple(engine.xp.asarray(v) for v in before);forced=engine.update_forcing(device,x['forcing_environment'])
    result=engine.step(*forced,x['forcing'],environment=x['environment'],calendar=x['calendar'],
        nitrogen_deposition_gn_m2=x['nitrogen'],deposition=x['deposition'],most_geometry=x['geometry'],
        leaf_parameters=LeafParameters(),return_surface=True)
    out=engine.host(result);after=tuple(engine.host(v) for v in next_bgc_arrays(forced,result))
    _,residual,bound,tracer=audit_step(before,after,x['forcing'],x['deposition'],x['nitrogen'],out)
    flat=flatten(out);np.savez_compressed(dest/'outputs.npz',**flat)
    np.savez_compressed(dest/'next-state.npz',**{f'a{k}':v for k,v in enumerate(after)})
    report.update(status='complete',residual=residual,bound=bound,tracer_residual=tracer,
        most_iterations=out['surface']['most']['iterations'],h=out['diagnostics']['h'],le=out['diagnostics']['le'])
    if args.backend=='jax32':
        maximum=0.
        with np.load(dest.with_name(f'saved-step-{args.index}-cuda32-a')/'outputs.npz',allow_pickle=False) as z:
            assert set(z.files)==set(flat)
            for key,value in flat.items():
                if value.dtype.kind in 'iub':np.testing.assert_array_equal(value,z[key],err_msg=key)
                else:
                    np.testing.assert_allclose(value,z[key],rtol=1e-6,atol=1e-6,err_msg=key)
                    maximum=max(maximum,float(abs(value.astype(float)-z[key].astype(float)).max()))
        report['same_precision_max_absolute']=maximum
except Exception:report.update(status='failed',failure=traceback.format_exc())
report['seconds']=time.monotonic()-started
def encode(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)
(dest/'summary.json').write_text(json.dumps(report,indent=2,default=encode,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_sha256','source_differences']},default=encode),flush=True)


"""EHPC-only same-input CUDA/JAX phase comparisons, preserving original gates."""
import argparse
import io
import json
import os
from pathlib import Path
import socket
import sys

from phase_cross_contract_qf import HERE,GPU,sha,save,controls,source_identity,original_inputs

def main():
    p=argparse.ArgumentParser()
    for n in ('source','nq','cuda','jax','output'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args()
    assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists();a.output.mkdir()
    import numpy as np
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());control_sha=controls();manifest=source_identity(a.source,binding)
    cells,properties,option,original=original_inputs(a.source,a.nq,binding)
    roots=dict(cuda=a.cuda,jax=a.jax);outputs={};inputs={};receipts={}
    def load(path):
        meta=json.loads(path.with_suffix('.json').read_bytes());raw=path.with_suffix('.npz').read_bytes();assert sha(raw)==meta['npz_sha256']
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:arrays={n:z[n].copy() for n in z.files}
        assert set(arrays)==set(meta['arrays'])
        for n,v in arrays.items():assert dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes(order='C')))==meta['arrays'][n]
        return arrays
    def pair(x,y):
        assert x.keys()==y.keys();rows={}
        for n,u in x.items():
            v=y[n];assert u.dtype==v.dtype and u.shape==v.shape
            exact=u.dtype.kind in 'biu' or n in ('output/iterations','output/converged')
            delta=abs(u.astype(float)-v.astype(float));bound=0. if exact else 1e-6+1e-6*abs(v.astype(float))
            rows[n]=dict(dtype=u.dtype.str,shape=list(u.shape),CUDA=u.tolist(),JAX=v.tolist(),integer_or_counter_exact=exact,maximum_absolute=float(np.max(delta,initial=0.)),byte_equal=u.tobytes()==v.tobytes(),passed=bool(np.all(np.isfinite(u)) and np.all(np.isfinite(v)) and np.all(delta<=bound)))
        return dict(passed=all(r['passed'] for r in rows.values()),fields=rows)
    ledger={};reproduction={}
    original_fields={'temperature_offset_k':'temperature_offset_k','temperature_k':'temperature_k','liquid_kgm2':'liquid_kg_m2','ice_kgm2':'ice_kg_m2','reconstruction_residual_jm2':'phase_reconstruction_residual_j_m2','iterations':'phase_iterations','converged':'phase_converged'}
    for backend,root in roots.items():
        r=json.loads((root/'capture-receipt.json').read_bytes());receipts[backend]=r
        assert r['backend']==backend and r['gpu_uuid']==GPU and r['source_manifest_sha256']==binding['source_manifest_sha256'] and r['controls_manifest_sha256']==control_sha and r['calls']==dict(started=2,returned=2) and r['source584_exact']
        assert r['column_calls']==r['transport_calls']==r['NumPy_physical_calls']==0
        for origin in ('cuda','jax'):
            tag=backend+'/'+origin;u=load(root/(origin+'-input'));v=load(root/origin);inputs[tag]=u;outputs[tag]=v
            expected_u=np.concatenate((cells[origin],np.broadcast_to(properties[[0,1,3]],(4,3))),axis=1)
            expected_o=np.full(4,option[0],np.int32)
            assert u['primitive_inputs'].dtype==expected_u.dtype and u['primitive_inputs'].shape==expected_u.shape and u['primitive_inputs'].tobytes()==expected_u.tobytes()
            assert u['primitive_options'].dtype==expected_o.dtype and u['primitive_options'].tobytes()==expected_o.tobytes()
            for name in ('cells','properties','phase_option'):
                assert v['after/'+name].dtype==u[name].dtype and v['after/'+name].shape==u[name].shape and v['after/'+name].tobytes()==u[name].tobytes()
            # Original inverse convergence bound only; no new transport or extensive state update.
            output=v['output/reconstruction_residual_jm2'];liquid=v['output/liquid_kgm2'];h=u['primitive_inputs'][:,1]
            scale=np.maximum(np.maximum(abs(h),abs(np.float32(334000.)*liquid)),np.float32(1.))
            bound=np.maximum(np.float32(2e-8),np.float32(8.)*np.finfo(h.dtype).eps*scale)
            ledger[tag]=dict(W_H_dz_input_echo_byte_exact=True,authoritative_W_H_modified=False,inverse_all_converged=bool(np.all(v['output/converged']>0)),original_reconstruction_residual=output.tolist(),original_inverse_bound_jm2=bound.tolist(),within_original_inverse_bound=bool(np.all(abs(output)<=bound)),scope='Phase-only original inverse; no column advance or new M/H transport ledger. Original full-column hard ledgers remain unchanged and are not replaced by this tolerance.')
            assert ledger[tag]['inverse_all_converged'] and ledger[tag]['within_original_inverse_bound']
            if backend==origin:
                reproduction[tag]={}
                for field,old_field in original_fields.items():
                    actual=v['output/'+field];expected=original[origin+'/soil_hydrology/'+old_field][0]
                    equal=np.array_equal(actual.astype(expected.dtype),expected)
                    reproduction[tag][field]=dict(original=expected.tolist(),replay=actual.tolist(),exact_values=bool(equal),original_dtype=expected.dtype.str,replay_dtype=actual.dtype.str)
    comparisons={}
    for origin in ('cuda','jax'):
        assert inputs['cuda/'+origin]['primitive_inputs'].tobytes()==inputs['jax/'+origin]['primitive_inputs'].tobytes()
        comparisons[origin]=pair(outputs['cuda/'+origin],outputs['jax/'+origin])
    original_reproduced=all(r['exact_values'] for d in reproduction.values() for r in d.values())
    common_agreement=all(r['passed'] for r in comparisons.values())
    inference=('Inconclusive: original diagonal outputs not all reproduced exactly' if not original_reproduced else ('Both operators agree for both common inputs; original different inputs account for the recorded phase difference at this precision' if common_agreement else 'At least one identical input still differs between native phase operators; input drift alone cannot explain the original difference'))
    assert source_identity(a.source,binding)==manifest and controls()==control_sha
    save(a.output/'phase-cross-readout.json',dict(analysis_completed=True,pbs_job=os.environ['PBS_JOBID'],source_manifest_sha256=binding['source_manifest_sha256'],comparisons=comparisons,original_diagonal_reproduction=reproduction,original_diagonal_all_exact=original_reproduced,inverse_original_bounds=ledger,inference=inference,same_precision_all_passed=common_agreement,source584_exact=True,GPU_calls_in_this_analysis=0,physical_column_calls=0,original_NQ_failures_retained=True,scientific_acceptance=False,original_gate='float rtol=atol=1e-6; integer and logical counters exact; no accepted-limit reclassification'))
    # A successful delivery cannot make an actual same-precision failure green.
    if not common_agreement or not original_reproduced:return 1
    return 0

if __name__=='__main__':sys.exit(main())

"""Closed phase2x2 source/receipt/opaque-payload closure, without local physics."""
import gzip
import io
import json
from pathlib import Path
import tarfile
from package_surface_reference_pt import files,sha,encode
from package_nm_richards_reference_qc import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='nq-phase-cross-qf'
GPU_STAGE='15751714a92efdbce7c7d31c190814945a0398ba2dbb18b1862471e6da507e43'
CPU_STAGE='47b7181829f287241b7e048566ace629b97ba425ea5e043e5194306c6f53ff41'
GPU_RAW='c779606df850a73d2ea241fb9893f3049b07681bd253731981104eb7761c74f6'
CPU_RAW='9365c34b207122c584cbe6997658e08aa946cae77d7b8ef8b8635fe8d79ed571'

def main():
    gpu_stage_raw=(BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes();cpu_stage_raw=(BASE/(LABEL+'-comparison-stage.tar.gz')).read_bytes()
    gpu_raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes();cpu_raw=(BASE/(LABEL+'-comparison-result.tar.gz')).read_bytes()
    assert [sha(v) for v in (gpu_stage_raw,cpu_stage_raw,gpu_raw,cpu_raw)]==[GPU_STAGE,CPU_STAGE,GPU_RAW,CPU_RAW]
    gs,cs,gpu,cpu=[files(v,directories=True) for v in (gpu_stage_raw,cpu_stage_raw,gpu_raw,cpu_raw)]
    for stage,count in ((gs,21),(cs,22)):
        index=json.loads(stage['stage-inventory.json']);assert len(stage)==count and set(stage)==set(index)|{'stage-inventory.json'}
        assert all(sha(stage[n])==h for n,h in index.items())
    assert all(gs[n]==cs[n] for n in gs if n!='stage-inventory.json')
    assert cs['gpu-result.tar.gz']==gpu_raw
    source=files(gs['source.tar.gz']);source_index=json.loads(source['SOURCE_SHA256.json']);assert len(source_index)==584
    assert set(source)==set(source_index)|{'SOURCE_SHA256.json'} and all(sha(source[n])==h for n,h in source_index.items())
    assert all(cpu['run/source/'+n]==raw for n,raw in source.items())
    controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and controller['error'] is None and controller['actual_controller_OS_returncode'] is None
    assert len(controller['actual_parents'])==2 and [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0,0]
    captures={};opaque={}
    for backend in ('cuda','jax'):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json']);assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
        assert gpu[backend+'/device-parent-exit.txt'].strip()==b'0'
        receipt=json.loads(gpu[backend+'/device/capture-receipt.json']);captures[backend]=receipt
        assert receipt['calls']==dict(started=2,returned=2) and receipt['source584_exact'] and receipt['column_calls']==receipt['transport_calls']==receipt['NumPy_physical_calls']==0
        assert receipt['source_manifest_sha256']==sha(source['SOURCE_SHA256.json']) and receipt['gpu_uuid']=='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
        assert receipt['controls_manifest_sha256']==sha(gs['preparation/CONTROLS_SHA256.json'])
        for origin in ('cuda','jax'):
            for suffix in ('','-input'):
                stem=backend+'/device/'+origin+suffix;meta=json.loads(gpu[stem+'.json'])
                tree=dict(kind='dict',items={n:dict(kind='array',key=n,**d) for n,d in meta['arrays'].items()})
                opaque[stem]=opaque_packet(gpu[stem+'.npz'],dict(npz_sha256=meta['npz_sha256'],array_count=len(meta['arrays']),tree=tree))[0]
    for n in ('setup-exit.txt','worker-exit.txt','stage-after-exit.txt','pbs-command-exit.txt'):assert cpu[n].strip()==b'0'
    index=json.loads(cs['stage-inventory.json'])
    for n in ('stage-before.json','stage-after.json'):
        d=json.loads(cpu[n]);assert d['passed'] and d['expected']==d['actual']==index and not d['mismatches']
    parent=json.loads(cpu['run/comparison-parent-receipt.json']);assert parent['pbs_job']=='1842.manager' and parent['comparison_child_returncode']==0 and parent['comparison_child_attempts']==1 and parent['stage_unchanged'] and not parent['missing_capture_receipts']
    closure=BASE/(LABEL+'-comparison-closure');terminal=[p.read_bytes() for p in closure.glob('poll-*.stdout') if b'job_state = F' in p.read_bytes()];assert len(terminal)==1
    assert all(x in terminal[0] for x in (b'Exit_status = 0',b'Stageout_status = 0',b'run_count = 1'))
    for host in ('manager','compute'):
        d=json.loads((closure/(host+'.stdout')).read_bytes());assert d['all_stage_immutable'] and d['stage_files_before']==d['stage_files_after']==index
    readout=json.loads(cpu['run/comparison/phase-cross-readout.json'])
    assert readout['analysis_completed'] and readout['original_diagonal_all_exact'] and readout['same_precision_all_passed'] and readout['source584_exact'] and readout['original_NQ_failures_retained']
    assert all(v['passed'] and all(f['byte_equal'] and f['passed'] for f in v['fields'].values()) for v in readout['comparisons'].values())
    assert all(v['W_H_dz_input_echo_byte_exact'] and not v['authoritative_W_H_modified'] and v['inverse_all_converged'] and v['within_original_inverse_bound'] for v in readout['inverse_original_bounds'].values())
    verification=dict(passed=True,pbs_job='1842.manager',actual_PBS_exit=0,actual_Stageout_status=0,source584_exact=True,actual_GPU_parent_exits=[0,0],actual_detached_controller_OS_exit=None,actual_native_inverse_calls=4,actual_full_column_calls=0,actual_transport_calls=0,actual_NumPy_physical_calls=0,opaque_packets=len(opaque),opaque_arrays=sum(opaque.values()),gpu_stage_sha256=GPU_STAGE,comparison_stage_sha256=CPU_STAGE,gpu_raw_sha256=GPU_RAW,comparison_raw_sha256=CPU_RAW,common_input_all_output_bytes_equal=True,original_diagonal_all_exact=True,original_column_1J_same_precision_failure_resolved=False,scientific_acceptance=False)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    items={'executed-gpu-stage.tar.gz':gpu_stage_raw,'executed-comparison-stage.tar.gz':cpu_stage_raw,'raw-gpu-result.tar.gz':gpu_raw,'raw-comparison-result.tar.gz':cpu_raw,'verification.json':encode(verification),'readout.json':cpu['run/comparison/phase-cross-readout.json']}
    items.update({'actual-gpu/'+n:b for n,b in gpu.items()})
    items.update({'actual-comparison/'+n:b for n,b in cpu.items() if not n.startswith('run/source/')})
    for directory in (closure,BASE/(LABEL+'-gpu-closed'),BASE/'nq-phase-cross-qf-preparation-unexecuted-before-diagonal-gate'):
        for p in sorted(directory.iterdir()):
            if p.is_file() and p.name!='gpu-result.tar.gz':items['observations/'+directory.name+'/'+p.name]=p.read_bytes()
    for n in ('prepare_nq_phase_reference_followups_qf_qg.py','prepare_phase_cross_qf_execution.py','deploy_phase_cross_qf_gpu.py','collect_stage_phase_cross_qf.py','deploy_phase_cross_qf_compare.py','read_phase_cross_qf.py','read_phase_cross_qf_compare_closed.py','collect_phase_cross_qf_compare_closed.py','package_phase_cross_qf.py',LABEL+'-gpu-deployment.json',LABEL+'-comparison-deployment.json',LABEL+'-progress-1.json',LABEL+'-progress-1.stderr',LABEL+'-progress-1-exit.json',LABEL+'-gpu-stage-package.json',LABEL+'-comparison-stage-package.json'):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for p in BASE.glob(LABEL+'-*-deploy-*'):
        if p.is_file():items['provenance/'+p.name]=p.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Original NM584 phase2x2 CUDA1 replay4 inverse calls; actual GPU parents0/0 and EHPC1842 F0/Stageout0. Common-input all-fields byte equal; original diagonal residual1J/0J reproduced exactly, isolating original input drift. No transport advance/source/test/fixture/gate change; original column1J same-precision failure remains unresolved.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(dict(package=package,verification=verification)))

if __name__=='__main__':main()

"""Freeze two independent review-only followups using stdlib hashes/headers."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
def files(path):
    with tarfile.open(path) as t:
        out={}
        for m in t:
            if m.isdir():continue
            n=m.name.removeprefix('./');assert m.isfile() and n not in out;out[n]=t.extractfile(m).read()
        return out
def header(raw):
    assert raw[:6]==b'\x93NUMPY';width=2 if raw[6:8]==b'\x01\x00' else 4
    size=int.from_bytes(raw[8:8+width],'little');h=ast.literal_eval(raw[8+width:8+width+size].decode())
    return dict(dtype=h['descr'],shape=list(h['shape']),fortran_order=h['fortran_order'],opaque_stored_payload_sha256=sha(raw[8+width+size:]))
def freeze(label,items):
    root=BASE/label;root.mkdir(exist_ok=False)
    for n,b in items.items():
        if n.endswith('.py'):ast.parse(b)
        (root/n).write_bytes(b)
    manifest={n:sha(b) for n,b in sorted(items.items())};(root/'CONTROLS_SHA256.json').write_bytes(encode(manifest))
    return dict(directory=label,prepared_only=True,submitted=False,controls=len(manifest),controls_manifest_sha256=sha((root/'CONTROLS_SHA256.json').read_bytes()),files=manifest)
def main():
    source_path=BASE/'climatology-final-candidate-nm-source.tar.gz';source=files(source_path)
    source_sha=sha(source_path.read_bytes());manifest_sha=sha(source['SOURCE_SHA256.json'])
    assert source_sha=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d' and manifest_sha=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    source_index=json.loads(source['SOURCE_SHA256.json']);assert len(source_index)==584 and all(sha(source[n])==h for n,h in source_index.items())
    nq_path=BASE/'nq-terminal-qb-evidence.tar.gz';nq=files(nq_path);nq_sha=sha(nq_path.read_bytes())
    assert nq_sha=='e6e7c16c8ac7587ccd3ef192d59c422b1754f1d75a06fc33edc3bdd5321b1ba9'
    packet_path='nq/test_gpu_clm_richards_column-diagnostics/aggregate-0.npz';packet=nq[packet_path]
    inputs={}
    with zipfile.ZipFile(io.BytesIO(packet)) as z:
        for n in ('cuda/soil_hydrology/cells.npy','jax/soil_hydrology/cells.npy','cuda/soil_cells.npy','jax/soil_cells.npy'):
            inputs['captured/'+n]=header(z.read(n))
    fixture=source['tests/fixtures/clm_richards_reference.npz']
    with zipfile.ZipFile(io.BytesIO(fixture)) as z:
        for n in ('32/1/initial/2.npy','32/1/initial/3.npy'):inputs['fixture/'+n]=header(z.read(n))
    qf_binding=dict(prepared_only=True,submitted=False,source_archive_sha256=source_sha,source_manifest_sha256=manifest_sha,source_files=584,nq_archive_sha256=nq_sha,packet_path=packet_path,packet_sha256=sha(packet),fixture_sha256=sha(fixture),gpu_uuid='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',planned_native_inverse_calls=4,planned_column_calls=0,planned_transport_calls=0,planned_NumPy_physical_calls=0,original_pair_gate='rtol=atol=1e-6; all integers/iterations/converged exact',original_failures_retained=True)
    qf_readme='''# QF phase cross replay — review only, not launched

Use original NM584 and exactly the two four-cell final states from original NQ aggregate-0. The original full packet has126 CUDA/JAX fields,117 byte-identical and9 different. EHPC1827 quantified all9: only phase_reconstruction_residual remains outside the unchanged1e-6 gate (1J); no blanket nine-field failure is claimed. All original failures remain.

Two independently started backends on xuanze physical CUDA1 each invoke the unchanged original richards_enthalpy._phase twice. For each origin CUDA/JAX, actual captured soil_hydrology/cells is the exact input; soil_cells equals it. Full properties come from original32/aggregate initial2 indices[0,1,3,6], phase from original initial3[:,1]. The original helper builds six-column inverse inputs, echoed before each actual native inverse. No timestep, full column, transport, state advancement, W/H replacement, CPU physical reference or changed gate occurs.

Proposed GPU invocation per backend: capture_phase_cross_qf.py --source NM584_DIRECTORY --nq nq-terminal-qb-evidence.tar.gz --backend cuda|jax --output NEW_DIRECTORY. Use xuanze phase3b Python, CUDA12.4, JAX/jaxlib0.11.2, original environment and UUID; preallocation off, eightGiB GPU/thirty-twoGiB host startup gate; private caches under /tmp/nq-phase-cross-qf-...; one thread;3600s/backend and no auto retry. Host NumPy only loads unchanged inputs and serializes original returns. All nine primitive outputs plus exact original cells/properties/options and actual primitive inputs are captured with dtype/shape/opaque hashes. Both children must be reaped and failures retained.

Then, separately on EHPC PBS compute002,1CPU/2GiB/5min, compare_phase_cross_qf.py --source NM584_DIRECTORY --nq ORIGINAL_ARCHIVE --cuda CUDA_OUTPUT --jax JAX_OUTPUT --output "$TMPDIR/NEW". It verifies source584/controls/input byte identity, both original diagonal output reproductions, two identical-input CUDA/JAX comparisons and every field/counter. Original inverse convergence bound is reported unchanged; W/H/dz input echo is byte exact. This is not a replacement for full-column original extensive ledgers. A same-input1e-6 failure stays actual comparison exit1; it is not an accepted old limit. Inference is conditional on diagonal reproduction, and no diagnostic is zeroed or omitted.

If both common-input pairs agree, investigate prior transport input arithmetic. If a common-input pair differs, input drift alone is insufficient; inspect actual phase operator order. No source or test patch is proposed in QF. PBS/GPU launcher metadata will be prepared mechanically after root reviews this contract.
'''
    qf_items={n:(BASE/n).read_bytes() for n in ('phase_cross_contract_qf.py','capture_phase_cross_qf.py','compare_phase_cross_qf.py')}
    qf_items.update({'BINDINGS.json':encode(qf_binding),'INPUT_HEADERS.json':encode(inputs),'README.md':qf_readme.encode()})
    qf=freeze('nq-phase-cross-qf-preparation',qf_items)
    qc=BASE/'nq-current-reference-qc-result.tar.gz';qc_sha=sha(qc.read_bytes());assert qc_sha=='925f44a18f501652f6050409895adf4f1fb2a81ff441d0e19a0241108cef55c1'
    qg_binding=dict(prepared_only=True,submitted=False,source_archive_sha256=source_sha,source_manifest_sha256=manifest_sha,source_files=584,qc_job='1827.manager',qc_result_archive_sha256=qc_sha,qc_evidence_sha256='618bde93a8a954399df7578ced72b9e573731f6433b952fc3d3ef1cf7ecd2c1b',reused_original_physical_calls=44,new_physical_calls=0,GPU_calls=0,checkout_fixture_edits=False)
    qg_readme='''# QG completed-QC values and minimal fixture proposal — review only

Run only a posthoc analysis on EHPC PBS compute002,1CPU/2GiB/5min, original CPU-only/thread1/venv/test-deps environment: reference_values_qg.py --source ORIGINAL_NM_SOURCE.tar.gz --qc ORIGINAL_QC1827_RESULT.tar.gz --output "$TMPDIR/NEW". No model is imported and no physical call or GPU work is performed. The original44/44 successful QC calls, all584 source files and immutable original inputs/returns are checked before reading saved arrays. Windows preparation only hashes archives/NPY headers; numerical decoding and differences occur solely in this PBS job.

The analysis emits every original/current expected array value and difference, including both precision five-layer GPP and all original station H/LE/GPP/NEE/ET/soil/snow traces. It preserves raw BF historical reference and NQ original XML/failure archives. Existing five-layer GPU full outputs were not exported beyond XML failures: printed GPP cannot certify full-return equality, so no such credit is invented. Current station GPU/current-NumPy comparisons already exist in QC1827 and are not rerun.

Minimal proposed fixture update is restricted to private result artifacts for review: column NPZ has exactly654 original keys; all250 non-expected inputs remain dtype/shape/bytes identical, all404 expected keys take actual unchanged QC1827 NumPy values. Station NPZ retains every input, config_json and metadata_json byte exactly; replaces only trace arrays with the actual two original four-step QC traces and report_json with each original QC report. No current checkout fixture or model/test/gate is modified by this analysis. New private NPZ identities, changed fields and actual source/QC bindings are fully recorded. Applying a proposed fixture to a reviewed new source and actually rerunning all affected tests are separate future actions, not QG success.

Historical BF383 fixture source a60417e5...e29 preceded the accepted current CLM soil-beta and Ball-Berry changes. Current NumPy must supply the replacement, not GPU output. No acceptance tolerance is enlarged; original nine NQ failures remain historical failures. Same-precision phase failure is addressed independently by QF, not repaired by reference replacement.
'''
    proposal='''# Reviewable minimal followup change plan (not applied)

1. After independent QG value/identity review, copy only its two proposed reference NPZs into a new private source, retain old BF originals and source metadata in evidence. No forcing, configuration, geometry, initial state, dtype/shape, near-zero policy, physical tolerance or original test body change is needed for the historical-reference mismatch. Keep the current production source unmodified until root authorization; actually rerun full affected Richards column/station files before claiming any of the seven old reference-related failures resolved.
2. The aggregate1J CUDA/JAX primitive difference is a separate actual same-precision failure. Fixture updates cannot resolve it, and original all-output1e-6/integer assertions must remain.
3. MOST counter semantics: shared native scheduler increments bisection_restarts only for active stable_bracket, not-done and a representable midpoint equal to current zeta. Ordinary convergence can legitimately report0. Both unconditional historical ==1 assertions in test_gpu_most_stagnation therefore encode an incidental old trajectory. Proposed later patch is exactly those two assertions: require integer dtype and0<=counter<=iterations. Preserve coefficient1e-4/iterations50, all physical references, complete same-precision/integer checks and four independent budgets. Preserve tests/test_most_stagnation.py byte for byte, especially manufactured has_root/no_root cases with exact one restart/27 iterations/root and explicit no-root rejection. The original float32 reference node stopped before budgets, and the original parity node stopped before parity/budgets; those checks get no success credit until actual rerun.
'''
    qg_items={'reference_values_qg.py':(BASE/'reference_values_qg.py').read_bytes(),'BINDINGS.json':encode(qg_binding),'README.md':qg_readme.encode(),'MINIMAL_FIXTURE_AND_MOST_PLAN.md':proposal.encode(),'ORIGINAL_MOST_TEST_PLAN.md':(BASE/'nq-current-reference-qc-preparation/MOST_TEST_PLAN.md').read_bytes()}
    qg=freeze('nq-reference-values-qg-preparation',qg_items)
    result=dict(passed=True,scope='Stdlib source/archive/input-header controls only; neither followup executed',phase_cross=qf,reference_values=qg)
    (BASE/'nq-phase-reference-followups-qf-qg-static.json').write_bytes(encode(result));print(json.dumps(result))

if __name__=='__main__':main()

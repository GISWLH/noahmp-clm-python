"""Mechanical PB-t lifecycle wrappers for the root-reviewed original phase2x2."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
OLD=BASE/'clm-drainage-device-pb-t-execution'
NEW=BASE/'nq-phase-cross-qf-execution'
PREP=BASE/'nq-phase-cross-qf-preparation'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()

def archive(path,items):
    assert not path.exists()
    with path.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    with tarfile.open(path) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    return sha(path.read_bytes())

def main():
    prep_sha=sha((PREP/'CONTROLS_SHA256.json').read_bytes());assert prep_sha=='c2e219c652cff8b3322cd80e7c9edd217cbecd7b7ab8ac76e297d2dbbb9c7938'
    prep_index=json.loads((PREP/'CONTROLS_SHA256.json').read_bytes());assert all(sha((PREP/n).read_bytes())==h for n,h in prep_index.items())
    old_index=json.loads((OLD/'CONTROLS_SHA256.json').read_bytes());assert all(sha((OLD/n).read_bytes())==h for n,h in old_index.items())
    NEW.mkdir(exist_ok=False);diff=[];new_files={}
    for n in old_index:
        if n.endswith('.diff'):continue
        before=(OLD/n).read_text();after=before
        after=after.replace('noahmp-drainage-device-pb-t-compare','noahmp-phase-cross-qf-compare').replace('/tmp/dispatch_compare_pbt.py','/tmp/dispatch_compare_qf.py').replace('pbr-evidence.tar.gz','nq-evidence.tar.gz')
        if n=='EXECUTION_BINDINGS.json':
            d=json.loads(after);d.update(preparation_manifest_sha256=prep_sha,source_archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',evidence_archive_sha256='e6e7c16c8ac7587ccd3ef192d59c422b1754f1d75a06fc33edc3bdd5321b1ba9',root='/home/lhwang/work/noahmp-v1/nq-phase-cross-qf',temporary='/tmp/nq-phase-cross-qf-20261026',source_modified=False,preparation_modified=True,change_scope='Original NM584 phase primitive2x2 only; two captured final states, two native inverse calls per backend,0 full columns/transport/CPU reference',native_inverse_calls=4,full_column_calls=0,transport_calls=0)
            after=json.dumps(d,indent=2)+'\n'
        elif n=='launch_device_pbs.py':
            assert 'len(manifest)==596' in after;after=after.replace('len(manifest)==596','len(manifest)==584')
        elif n=='run_device_parent_pbs.py':
            after=after.replace('from contract_pbs import HERE,GPU,controls,bound_evidence,source_identity,save,sha','from phase_cross_contract_qf import HERE,GPU,controls,original_inputs,source_identity,save,sha')
            after=after.replace("('source','evidence','output')","('source','nq','output')").replace('bound_evidence(a.evidence,binding)','original_inputs(a.source,a.nq,binding)').replace('a.evidence','a.nq')
            after=after.replace('/tmp/drainage-pb-s-','/tmp/nq-phase-cross-qf-').replace('capture_device_pbs.py','capture_phase_cross_qf.py').replace('--evidence','--nq')
        elif n=='control_device_pbs.py':after=after.replace('--evidence','--nq')
        elif n=='run_compare_pbs.py':
            old="    with tarfile.open(STAGE/'gpu-result.tar.gz') as archive:\n        members=archive.getmembers()\n        assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)\n        assert len({m.name for m in members})==len(members)\n        for member in members:\n            path=root/'gpu'/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(archive.extractfile(member).read())\n"
            new="    for filename,prefix in (('gpu-result.tar.gz','gpu'),('source.tar.gz','source')):\n        with tarfile.open(STAGE/filename) as archive:\n            members=archive.getmembers()\n            assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)\n            assert len({m.name for m in members})==len(members)\n            for member in members:\n                path=root/prefix/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(archive.extractfile(member).read())\n"
            assert old in after;after=after.replace(old,new)
            after=after.replace("for n in binding['cases']","for n in ('cuda-origin','jax-origin')")
            after=after.replace('compare_ehpc_pbs.py','compare_phase_cross_qf.py').replace("'--evidence',str(STAGE/'nq-evidence.tar.gz')","'--source',str(root/'source'),'--nq',str(STAGE/'nq-evidence.tar.gz')")
        elif n=='compare_pbs.pbs':after=after.replace('drainage-device-pbt-compare','phase-cross-qf-compare')
        elif n=='README.md':after='QF reuses PB-t actual lifecycle with fresh private paths, original NM584/NQ bindings and the reviewed phase2x2 capture/comparison. Two actual native inverse calls per backend,0 full columns or transport. Both original parent actual exits and errors are preserved; detached controller OS exit remains unknown. Startup8GiB GPU/32GiB host,3600s/backend,1thread/private caches unchanged. EHPC1CPU/2GiB/5min performs comparison only; original diagonal reproduction and same-input1e-6/integer failure retain nonzero exit. Root authorized one launch and one comparison, no retry.\n'
        if n.endswith('.py'):assert '\x00' not in after;ast.parse(after)
        raw=after.encode();new_files[n]=raw;(NEW/n).write_bytes(raw)
        diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='PB-t/'+n,tofile='QF/'+n))
    new_files['PB_T_TO_QF.diff']=''.join(diff).encode();(NEW/'PB_T_TO_QF.diff').write_bytes(new_files['PB_T_TO_QF.diff'])
    manifest=encode({n:sha(raw) for n,raw in sorted(new_files.items())});(NEW/'CONTROLS_SHA256.json').write_bytes(manifest)
    items={'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()}
    items.update({'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()})
    items['source.tar.gz']=(BASE/'climatology-final-candidate-nm-source.tar.gz').read_bytes();items['nq-evidence.tar.gz']=(BASE/'nq-terminal-qb-evidence.tar.gz').read_bytes()
    items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/'nq-phase-cross-qf-gpu-stage.tar.gz';digest=archive(target,items)
    record=dict(stage_sha256=digest,stage_files=len(items),execution_controls=len(new_files),execution_manifest_sha256=sha(manifest),preparation_manifest_sha256=prep_sha,source584_unchanged=True,planned_inverse_calls=4,full_column_calls=0,transport_calls=0,NumPy_physical_calls=0,numerical_executed=False)
    (BASE/'nq-phase-cross-qf-gpu-stage-package.json').write_bytes(encode(record))
    deploy=(BASE/'deploy_drainage_device_pbt_gpu_qd.py').read_text().replace('clm-drainage-device-pb-t','nq-phase-cross-qf').replace('/tmp/drainage-pb-s-pbt-20261026','/tmp/nq-phase-cross-qf-20261026').replace('launch_drainage_device_pbt.py','launch_nq_phase_cross_qf.py').replace('c0ba227ea2ff6daf6e038938c4c8e6812c5d9f62caad9297a06408ae64246aad',digest)
    ast.parse(deploy);(BASE/'deploy_phase_cross_qf_gpu.py').write_text(deploy,encoding='utf-8',newline='\n');print(json.dumps(record))

if __name__=='__main__':main()

"""Collect the one closed PB-t device run and prepare its original EHPC comparison."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='nq-phase-cross-qf'
DEST=BASE/(LABEL+'-gpu-closed')
REMOTE='/home/lhwang/work/noahmp-v1/'+LABEL
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def unpack(path):
    with tarfile.open(path) as archive:
        files={}
        for m in archive:
            if m.isdir():continue
            assert m.isfile() and m.name not in files and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            files[m.name]=archive.extractfile(m).read()
        return files

def main():
    assert not DEST.exists();DEST.mkdir()
    command=['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12',
        *['xuanze-neiwang:'+REMOTE+'/'+n for n in ('gpu-result.tar.gz','gpu-result-hash.json','controller-receipt.json')],str(DEST.resolve())]
    r=subprocess.run(command,capture_output=True,timeout=180)
    (DEST/'scp.stdout').write_bytes(r.stdout);(DEST/'scp.stderr').write_bytes(r.stderr)
    (DEST/'scp-exit.json').write_bytes(encode(dict(command=command,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr))))
    assert r.returncode==0,r.stderr.decode(errors='replace')
    raw=(DEST/'gpu-result.tar.gz').read_bytes();gpu=unpack(DEST/'gpu-result.tar.gz')
    expected=json.loads((DEST/'gpu-result-hash.json').read_bytes())
    assert sha(raw)==expected['sha256'] and len(raw)==expected['bytes']
    controller=json.loads((DEST/'controller-receipt.json').read_bytes())
    assert (DEST/'controller-receipt.json').read_bytes()==gpu['controller/controller-receipt.json']
    assert controller['completed'] and controller['stage_unchanged']
    assert len(controller['actual_parents'])==2
    for backend in ('cuda','jax'):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json'])
        assert parent['completed'] and parent['error'] is None
        # Failure remains evidence and proceeds to the unchanged explicit comparator.
    files={'execution/'+p.name:p.read_bytes() for p in (BASE/(LABEL+'-execution')).iterdir() if p.is_file()}
    files.update({'preparation/'+p.name:p.read_bytes() for p in (BASE/(LABEL+'-preparation')).iterdir() if p.is_file()})
    files['nq-evidence.tar.gz']=(BASE/'nq-terminal-qb-evidence.tar.gz').read_bytes()
    files['source.tar.gz']=(BASE/'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    files['gpu-result.tar.gz']=raw
    files['stage-inventory.json']=encode({n:sha(value) for n,value in sorted(files.items())})
    stage=BASE/(LABEL+'-comparison-stage.tar.gz');assert not stage.exists()
    with stage.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,value in sorted(files.items()):
                m=tarfile.TarInfo(name);m.size=len(value);m.mode=0o644;archive.addfile(m,io.BytesIO(value))
    assert unpack(stage)==files
    record=dict(stage=stage.name,stage_files=len(files),stage_sha256=sha(stage.read_bytes()),
        original_gpu_result_sha256=sha(raw),actual_parent_returncodes=[x['actual_parent_returncode'] for x in controller['actual_parents']],
        actual_controller_OS_returncode=controller['actual_controller_OS_returncode'],single_comparison_planned=True,launched=False)
    (BASE/(LABEL+'-comparison-stage-package.json')).write_bytes(encode(record))
    print(json.dumps(record))

if __name__=='__main__':main()

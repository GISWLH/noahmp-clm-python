"""One EHPC comparison child, preserving unavailable capture as explicit failure."""
from pathlib import Path,PurePosixPath
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time

STAGE=Path('/tmp/noahmp-phase-cross-qf-compare')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')


def main():
    root=Path(sys.argv[1]);assert not root.exists();root.mkdir()
    index=json.loads((STAGE/'stage-inventory.json').read_bytes());assert all(sha((STAGE/n).read_bytes())==h for n,h in index.items())
    for filename,prefix in (('gpu-result.tar.gz','gpu'),('source.tar.gz','source')):
        with tarfile.open(STAGE/filename) as archive:
            members=archive.getmembers()
            assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
            assert len({m.name for m in members})==len(members)
            for member in members:
                path=root/prefix/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(archive.extractfile(member).read())
    missing=[b for b in ('cuda','jax') if not (root/'gpu'/b/'device/capture-receipt.json').exists()]
    started=time.monotonic();code=1
    record=dict(missing_capture_receipts=missing,comparison_child_returncode=None,comparison_child_attempts=0,
        pbs_job=os.environ.get('PBS_JOBID'),model_forward_calls=0)
    if missing:
        binding=json.loads((STAGE/'preparation/BINDINGS.json').read_bytes())
        save(root/'comparison-unavailable.json',dict(passed=False,reason='Original GPU capture receipt missing',
            missing_backends=missing,cases=[dict(case=n,passed=False,reason='One or both original captures did not complete') for n in ('cuda-origin','jax-origin')]))
    else:
        command=[sys.executable,'-B',str(STAGE/'preparation/compare_phase_cross_qf.py'),'--cuda',str(root/'gpu/cuda/device'),
            '--jax',str(root/'gpu/jax/device'),'--source',str(root/'source'),'--nq',str(STAGE/'nq-evidence.tar.gz'),'--output',str(root/'comparison')]
        record['comparison_child_attempts']=1
        with (root/'comparison.stdout').open('xb') as out,(root/'comparison.stderr').open('xb') as err:
            result=subprocess.run(command,stdout=out,stderr=err,timeout=240)
        code=result.returncode;record['comparison_child_returncode']=code
    record['seconds']=time.monotonic()-started;record['stage_unchanged']=all(sha((STAGE/n).read_bytes())==h for n,h in index.items())
    save(root/'comparison-parent-receipt.json',record)
    return code if record['stage_unchanged'] else 1


if __name__=='__main__':raise SystemExit(main())

"""Hash the exact PB-s comparison stage before/after work; no scientific import."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/noahmp-phase-cross-qf-compare')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    index = json.loads((ROOT / 'stage-inventory.json').read_bytes())
    actual = {n: sha((ROOT / n).read_bytes()) for n in index}
    passed = actual == index
    args.output.write_text(json.dumps(dict(passed=passed, expected=index, actual=actual,
        mismatches=[n for n in index if index[n] != actual[n]]), indent=2) + '\n')
    assert passed


if __name__ == '__main__':
    main()

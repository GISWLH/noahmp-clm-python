"""Only two original native phase inverse calls per GPU backend; no advancement."""
import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

from phase_cross_contract_qf import HERE,GPU,sha,save,controls,source_identity,original_inputs

def main():
    p=argparse.ArgumentParser()
    for n in ('source','nq','output'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--backend',choices=('cuda','jax'),required=True);a=p.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='true'
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    caches=[Path(os.environ[n]).resolve() for n in ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH')]
    assert len(set(caches))==3 and all(str(n).startswith('/tmp/nq-phase-cross-qf-') for n in caches)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(n.split()[1] for n in Path('/proc/meminfo').read_text().splitlines() if n.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024,'Original 8GiB GPU /32GiB host startup gate'
    assert not a.output.exists();a.output.mkdir()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());control_sha=controls();manifest=source_identity(a.source,binding)
    cells,properties,option,original=original_inputs(a.source,a.nq,binding)
    sys.path.insert(0,str(a.source.resolve()/'src'))
    import numpy as np  # Encoding and transfer only; no NumPy physical reference or comparisons.
    if a.backend=='cuda':
        import cupy as xp
        assert xp.cuda.runtime.getDeviceCount()==1;xp.cuda.Device(0).use();xp.cuda.runtime.free(0)
        from noahmp_clm.gpu.cuda.enthalpy import run_soil_thermodynamics_cuda as inverse
        sync=lambda:xp.cuda.get_current_stream().synchronize()
        host=lambda v:xp.asnumpy(v) if isinstance(v,xp.ndarray) else np.asarray(v)
        versions=dict(cupy=xp.__version__)
    else:
        import jax
        assert importlib.metadata.version('jax')==importlib.metadata.version('jaxlib')=='0.11.2'
        jax.config.update('jax_enable_x64',True)
        assert len(jax.devices())==1 and jax.devices()[0].platform=='gpu'
        import jax.numpy as xp
        from noahmp_clm.gpu.enthalpy import run_soil_thermodynamics_jax as inverse
        sync=lambda:jax.effects_barrier()
        def host(v):
            if hasattr(v,'block_until_ready'):v.block_until_ready()
            return np.asarray(v)
        versions=dict(jax=importlib.metadata.version('jax'),jaxlib=importlib.metadata.version('jaxlib'))
    from noahmp_clm.gpu.richards_enthalpy import _phase
    assert Path(_phase.__code__.co_filename).resolve()==(a.source/'src/noahmp_clm/gpu/richards_enthalpy.py').resolve()
    assert Path(inverse.__code__.co_filename).resolve().is_relative_to(a.source.resolve()/'src')
    calls=dict(started=0,returned=0);started=time.monotonic();captures={}
    def capture(path,values):
        for v in values.values():assert isinstance(v,np.ndarray) and v.dtype.kind!='O'
        np.savez_compressed(path.with_suffix('.npz'),**values)
        d=dict(npz_sha256=sha(path.with_suffix('.npz').read_bytes()),arrays={k:dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes(order='C'))) for k,v in values.items()})
        save(path.with_suffix('.json'),d);return d
    try:
        for origin in ('cuda','jax'):
            c=xp.asarray(cells[origin]);prop=xp.asarray(properties);phase=xp.asarray(option[0],dtype=xp.int32)
            before=dict(cells=host(c),properties=host(prop),phase_option=host(phase))
            name=a.output/origin
            def observed(u,o,*,inverse):
                assert inverse is True
                capture(name.with_name(name.name+'-input'),dict(**before,primitive_inputs=host(u),primitive_options=host(o)))
                calls['started']+=1;out=actual_inverse(u,o,inverse=True);sync();calls['returned']+=1
                return out
            actual_inverse=inverse
            out=_phase(c,prop,phase,xp,observed);sync()
            values={'output/'+k:host(v) for k,v in out.items()}
            values.update({'after/'+k:host(v) for k,v in dict(cells=c,properties=prop,phase_option=phase).items()})
            captures[origin]=capture(name,values)
        assert calls==dict(started=2,returned=2)
    except BaseException:
        (a.output/'failure.txt').write_text(traceback.format_exc());raise
    finally:
        assert source_identity(a.source,binding)==manifest and controls()==control_sha
        save(a.output/'capture-receipt.json',dict(backend=a.backend,gpu_uuid=GPU,source_manifest_sha256=binding['source_manifest_sha256'],controls_manifest_sha256=control_sha,input_nq_archive_sha256=binding['nq_archive_sha256'],calls=calls,source584_exact=True,versions=versions,seconds=time.monotonic()-started,captures=captures,column_calls=0,transport_calls=0,NumPy_physical_calls=0,scope='Original phase inverse only, both captured final states. No changed W/H, model, gates or full-column claim.'))

if __name__=='__main__':main()

"""Source/input/controls contract for the original aggregate phase cross replay."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE=Path(__file__).resolve().parent
GPU='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def controls():
    b=(HERE/'CONTROLS_SHA256.json').read_bytes();expected=json.loads(b)
    assert all(sha((HERE/n).read_bytes())==h for n,h in expected.items());return sha(b)
def source_identity(root,binding):
    raw=(root/'SOURCE_SHA256.json').read_bytes();manifest=json.loads(raw)
    assert len(manifest)==584 and sha(raw)==binding['source_manifest_sha256']
    assert all(sha((root/n).read_bytes())==h for n,h in manifest.items());return manifest
def original_inputs(source,nq,binding):
    import numpy as np  # Original encoded input loading only on GPU; no host physics.
    raw=nq.read_bytes();assert sha(raw)==binding['nq_archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=t.getmembers();assert len({m.name for m in members})==len(members) and all(m.isfile() for m in members)
        files={m.name:t.extractfile(m).read() for m in members}
    inventory=json.loads(files['artifact-inventory.json'])
    assert set(inventory)==set(files)-{'artifact-inventory.json'}
    assert all(sha(files[n])==v['sha256'] and len(files[n])==v['bytes'] for n,v in inventory.items())
    packet=files[binding['packet_path']];assert sha(packet)==binding['packet_sha256']
    with np.load(io.BytesIO(packet),allow_pickle=False) as z:data={n:z[n].copy() for n in z.files}
    fixture=(source/'tests/fixtures/clm_richards_reference.npz').read_bytes();assert sha(fixture)==binding['fixture_sha256']
    with np.load(io.BytesIO(fixture),allow_pickle=False) as z:
        p=z['32/1/initial/2'].copy();options=z['32/1/initial/3'].copy()
    cells={b:data[b+'/soil_hydrology/cells'][0].copy() for b in ('cuda','jax')}
    assert all(c.dtype.str=='<f4' and c.shape==(4,3) for c in cells.values())
    assert all(data[b+'/soil_cells'].tobytes()==data[b+'/soil_hydrology/cells'].tobytes() for b in cells)
    properties=p[0,[0,1,3,6]].copy();option=options[0,1:2].copy()
    assert properties.dtype.str=='<f4' and properties.shape==(4,) and option.dtype.kind in 'iu'
    return cells,properties,option,data

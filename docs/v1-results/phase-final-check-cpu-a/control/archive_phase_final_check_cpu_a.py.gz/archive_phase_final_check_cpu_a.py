from pathlib import Path
import hashlib
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'phase-final-check-cpu-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert (r / 'pbs-exit.txt').read_text().strip() == '0'
for name, code, counts in [('original-regression', 1, dict(tests=2, failures=1, errors=0, skipped=0)), ('fixed-regression', 0, dict(tests=2, failures=0, errors=0, skipped=0)), ('cpu-full', 0, dict(tests=901, failures=0, errors=0, skipped=0))]:
    d = json.loads((r / (name + '-receipt.json')).read_text())
    assert d['returncode'] == code and d['counts'] == counts and d['source_unchanged'] and sha(r / (name + '.xml')) == d['xml_sha256']
a = b / 'phase-final-check-cpu-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():
            t.add(p, arcname=p.name, recursive=False)
    source = b / 'p6-phase-final-check-a-source.tar.gz'
    assert sha(source) == '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87'
    with tarfile.open(source) as frozen:
        for name in ['src/noahmp_clm/physics/canopy_phase_energy.py', 'tests/test_canopy_phase_energy.py']:
            member = frozen.getmember(name)
            t.addfile(member, frozen.extractfile(member))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, counts=d['counts'], seconds=d['seconds'])))

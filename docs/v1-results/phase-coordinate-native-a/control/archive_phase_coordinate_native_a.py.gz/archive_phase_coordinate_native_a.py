from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-a';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text());assert e['returncode']==1 and not e['passed'] and e['receipt_sha256']==sha(r/'receipt.json') and d['counts']==dict(tests=4,failures=1,errors=0,skipped=0) and d['source_unchanged'] and d['xml_sha256']==sha(r/'tests.xml')
a=b/'phase-coordinate-native-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname='target-a/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['phase-coordinate-native-a-source.tar.gz','phase-coordinate-native-a-package.json','phase-coordinate-target-a-receipt.json','collect_phase_coordinate_a.py','control_phase_coordinate_a.py','launch_phase_coordinate_a.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

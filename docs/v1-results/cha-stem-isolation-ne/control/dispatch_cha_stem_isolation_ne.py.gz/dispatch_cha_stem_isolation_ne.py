from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/tmp/noahmp-cha-stem-isolation-ne')
result = root / 'manager'
if result.exists():
    assert not list(result.iterdir()), 'A launch already exists; do not resubmit it'
else:
    result.mkdir()
runner = 'run_cha_stem_isolation_ne.py'
raw = (root / runner).read_bytes()
assert b'\r\n' not in raw
subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'compute002',
                'mkdir -p /tmp/noahmp-cha-stem-isolation-ne/result && test ! -e /tmp/noahmp-cha-stem-isolation-ne/result/worker.log'], check=True)
subprocess.run(['scp', str(root / runner), 'compute002:' + str(root / runner)], check=True)
script = '''#!/bin/bash
#PBS -N clm-cha-stem-ne
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=6gb:host=compute002_00260924
#PBS -l walltime=00:20:00
#PBS -j oe
#PBS -o /tmp/noahmp-cha-stem-isolation-ne/pbs-output.log
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /tmp/noahmp-cha-stem-isolation-ne/result
/home/zhangyq/venvs/noahmp-closeout/bin/python -u /tmp/noahmp-cha-stem-isolation-ne/run_cha_stem_isolation_ne.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(result / 'job.pbs').write_text(script)
q = subprocess.run(['qsub', str(result / 'job.pbs')], cwd=result, capture_output=True, text=True)
assert q.returncode == 0, q.stderr
out = dict(pbs_job=q.stdout.strip(), host_resource='compute002_00260924',
           controls_sha256={runner:hashlib.sha256(raw).hexdigest(), 'job.pbs':hashlib.sha256(script.encode()).hexdigest()},
           scope='Only independent PBS single-step diagnostics; all stage/results use manager and compute002 /tmp. Shared HOME source/MI archives read-only.')
(result / 'dispatch.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out), flush=True)

from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

root = Path('/tmp/noahmp-cha-stem-isolation-ne')
launch = json.loads((root / 'manager/dispatch.json').read_text())
q = subprocess.check_output(['qstat', '-xf', launch['pbs_job']], text=True)
assert re.search(r'^\s*job_state = F\s*$', q, re.M)
actual_exit = int(re.search(r'^\s*Exit_status = (\d+)\s*$', q, re.M).group(1))
dest = root / 'compute-result'
assert not dest.exists()
subprocess.run(['scp', '-r', 'compute002:/tmp/noahmp-cha-stem-isolation-ne/result', str(dest)], check=True)
assert int((dest / 'pbs-exit.txt').read_text()) == actual_exit
d = json.loads((dest / 'receipt.json').read_text())
assert d['complete'] and d['worker_exit_status'] == actual_exit and d['source_unchanged']
sha = lambda raw: hashlib.sha256(raw).hexdigest()
for row in d['scenarios']:
    if row['status'] == 'success':
        assert sha((dest / row['record']).read_bytes()) == row['record_sha256']
payload = {p.relative_to(dest).as_posix():p.read_bytes() for p in dest.rglob('*') if p.is_file()}
payload['actual-qstat.txt'] = q.encode()
for n in ['manager/dispatch.json', 'manager/job.pbs', 'run_cha_stem_isolation_ne.py', 'dispatch_cha_stem_isolation_ne.py', 'archive_cha_stem_isolation_ne.py']:
    payload['control/' + n] = (root / n).read_bytes()
pbs_output = root / 'pbs-output.log'
if pbs_output.exists():
    payload['control/pbs-output.log'] = pbs_output.read_bytes()
payload['control/pbs-output-status.json'] = (json.dumps(dict(
    expected_path=str(pbs_output), present=pbs_output.exists(),
    worker_stdout_stderr_file='worker.log',
    note='The wrapper redirected all worker output to the complete compute-node worker.log; do not invent absent PBS-stage output.'), indent=2) + '\n').encode()
payload['control/operational-notes.json'] = (json.dumps(dict(
    provenance='Controlling-assistant record of actual prelaunch/collection tool outputs, not numerical case failures.',
    prelaunch=dict(exit_status=1, pbs_submitted=False, reason='Remote legacy scp rejected -O; dispatcher then used the supported default legacy SCP protocol.'),
    premature_archive=dict(exit_status=1, observed_pbs_state='E', observed_pbs_exit=0,
                          reason='F-state dependency assertion rejected archiving before terminal F. No archive was created by that attempt.')),
    indent=2) + '\n').encode()
assert sha(payload['control/run_cha_stem_isolation_ne.py']) == launch['controls_sha256']['run_cha_stem_isolation_ne.py']
assert sha(payload['control/manager/job.pbs']) == launch['controls_sha256']['job.pbs']
inventory = {n:dict(sha256=sha(raw), bytes=len(raw)) for n, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
archive = root / 'cha-stem-isolation-ne-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for n, raw in sorted(payload.items()):
        info = tarfile.TarInfo(n)
        info.size = len(raw)
        tf.addfile(info, io.BytesIO(raw))
with tarfile.open(archive) as tf:
    assert len(tf.getmembers()) == len(payload)
    for m in tf:
        assert tf.extractfile(m).read() == payload[m.name]
out = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
           artifacts=len(payload), pbs_job=launch['pbs_job'], actual_pbs_exit=actual_exit,
           all16_success=d['all16_success'], successful_calls=d['successful_calls'], seconds=d['seconds'], scope=d['scope'])
(root / 'cha-stem-isolation-ne-package.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out), flush=True)

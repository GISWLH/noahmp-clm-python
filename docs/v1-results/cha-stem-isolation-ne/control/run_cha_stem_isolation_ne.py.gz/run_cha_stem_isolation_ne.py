"""Exact-input Cha single-step stem-area diagnostic; no calibration or year restart."""
from pathlib import Path
from dataclasses import fields, is_dataclass
import copy
import gzip
import hashlib
import json
import os
import pickle
import struct
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
started = time.monotonic()
base = Path('/home/zhangyq/noahmp-v1')
root = Path.cwd()
assert root == Path('/tmp/noahmp-cha-stem-isolation-ne/result')
scratch = Path(os.environ['TMPDIR']) / 'cha-stem-isolation-ne'
scratch.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
archives = {
    'source': ('clm-ballberry-jn-source.tar.gz', '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'),
    'mi': ('climatology-failure-reference-mi-evidence.tar.gz', 'ab43480e39005440d4be19bdf1f359d2d634adc9b7c61068a49406f4b0aac436'),
}
for name, (filename, digest) in archives.items():
    raw = (base / filename).read_bytes()
    assert sha(raw) == digest
    dest = scratch / name
    dest.mkdir()
    with tarfile.open(base / filename) as tf:
        tf.extractall(dest, filter='data')
source, mi = scratch / 'source', scratch / 'mi'
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
manifest_sha = sha((source / 'SOURCE_SHA256.json').read_bytes())
assert len(manifest) == 581
assert manifest_sha == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert all(sha((source / n).read_bytes()) == h for n, h in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'tests'), str(source / 'benchmarks')]
import numpy as np
import test_gpu_clm_bgc_column as reference
import run_fluxnet_column as runner
import run_fluxnet_native as native

binding = json.loads((mi / 'binding.json').read_text())
mi_receipt = json.loads((mi / 'receipt.json').read_text())
assert mi_receipt['passed']
assert binding['source_manifest_sha256'] == manifest_sha
input_raw = (mi / 'diagnostic-input.npz').read_bytes()
assert sha(input_raw) == binding['diagnostic_input_sha256']
with np.load(mi / 'diagnostic-input.npz', allow_pickle=False) as z:
    payload = dict(z)
for old, new in [('diagnostic-input.npz', 'mi-input.npz'), ('binding.json', 'mi-binding.json'), ('receipt.json', 'mi-receipt.json')]:
    (root / new).write_bytes((mi / old).read_bytes())
indices = [k for k, c in enumerate(binding['cases']) if c['site'] == 'CN-Cha']
assert indices == [8, 9, 10, 11]
assert all(binding['cases'][k]['time_start'] == '200302250830' and binding['cases'][k]['time_end'] == '200302250900' for k in indices)


def exact(a, b, path='root', omit=frozenset()):
    """Recursive type/shape/byte equality, including signed zero and NaN payload."""
    assert type(a) is type(b), (path, type(a).__name__, type(b).__name__)
    if isinstance(a, np.ndarray):
        assert a.dtype == b.dtype and a.shape == b.shape, (path, 'array contract')
        assert not a.dtype.hasobject
        assert a.tobytes() == b.tobytes(), (path, 'array bytes')
    elif isinstance(a, np.generic):
        assert a.dtype == b.dtype and a.tobytes() == b.tobytes(), (path, 'numpy scalar bytes')
    elif is_dataclass(a):
        for f in fields(a):
            if f.name not in omit:
                exact(getattr(a, f.name), getattr(b, f.name), path + '.' + f.name)
    elif isinstance(a, dict):
        ak, bk = set(a) - omit, set(b) - omit
        assert ak == bk, (path, 'dict keys', sorted(ak - bk), sorted(bk - ak))
        for key in ak:
            exact(a[key], b[key], path + '.' + str(key))
    elif isinstance(a, (list, tuple)):
        assert len(a) == len(b), (path, 'sequence length')
        for k, (x, y) in enumerate(zip(a, b)):
            exact(x, y, path + '.' + str(k))
    elif isinstance(a, float):
        assert struct.pack('!d', a) == struct.pack('!d', b), (path, 'float bytes', a, b)
    else:
        assert a == b, (path, a, b)


def comparable_result(result):
    x = dict(result)
    x.pop('structure_state', None)
    x.pop('canopy_geometry', None)
    for key in ('diagnostics', 'surface'):
        x[key] = dict(x[key])
        x[key].pop('canopy_geometry', None)
        x[key].pop('vegetation_structure', None)
    return x


def json_value(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {k: json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_value(v) for v in value]
    return value


def summary(got, before, after, forcing, nitrogen):
    d = got['diagnostics']
    incoming, residual, bound = runner.audit_step(before, after, forcing, d, nitrogen)
    direct = ['h', 'le', 'rnet', 'outgoing_shortwave', 'outgoing_longwave',
              'soil_absorbed_shortwave', 'snow_absorbed_shortwave',
              'ground_heat', 'ground_nonshortwave_heat', 'ground_sensible', 'leaf_sensible',
              'ground_evaporation', 'ground_latent_energy_jm2', 'ground_latent_heat',
              'wet_evaporation', 'transpiration', 'root_uptake',
              'flux_surface_temperature', 'ground_temperature', 'surface_temperature',
              'leaf_temperature', 'canopy_temperature', 'canopy_humidity',
              'canopy_storage_change_wm2', 'wet_advected_heat_wm2', 'transpiration_advected_heat_wm2',
              'root_advected_heat_wm2', 'transpiration_net_heat_wm2',
              'precipitation_enthalpy_jm2', 'atmospheric_energy_jm2', 'advected_enthalpy_jm2',
              'runoff_enthalpy_jm2', 'water_residual_kgm2', 'energy_residual_jm2',
              'et_mm', 'runoff_mm', 'gpp_gcm2', 'nee_gc_m2', 'layer_residual', 'solver_residual',
              'surface_root_residual_k', 'surface_root_converged', 'surface_evaluations']
    values = {key: json_value(d[key]) for key in direct}
    values.update(
        swdown_wm2=forcing.swdown, lwdown_wm2=forcing.lwdown,
        net_longwave_wm2=forcing.lwdown - d['outgoing_longwave'],
        canopy_absorbed_shortwave_by_returned_balance_wm2=forcing.swdown - d['outgoing_shortwave'] - d['soil_absorbed_shortwave'] - float(d['snow_absorbed_shortwave'].sum()),
        ground_latent_wm2=d['ground_latent_energy_jm2'] / forcing.dt,
        canopy_latent_wm2=float(d['vapor_parcels']['latent_energy_jm2'].sum()) / forcing.dt,
        soil_heat_change_wm2=float((after.ground.enthalpy - before.ground.enthalpy).sum()) / forcing.dt,
        total_heat_change_wm2=(after.enthalpy_jm2 - before.enthalpy_jm2) / forcing.dt,
        lai_before=before.lai, lai_used=d['biogeochemistry']['lai_used'], lai_after=after.lai,
        sai_before=before.sai, sai_after=after.sai,
        snow_before_m=before.swe, snow_after_m=after.swe,
        before_totals_m_h_c_n=runner.totals(before).tolist(), after_totals_m_h_c_n=runner.totals(after).tolist(),
        incoming_m_h_c_n=incoming.tolist(), independent_residual_m_h_c_n=residual.tolist(), independent_bound_m_h_c_n=bound.tolist(),
        thermal_layer_residual_jm2=json_value(d['thermal']['layer_residual_jm2']),
        thermal_convergence_tolerance_jm2=json_value(d['thermal']['convergence_tolerance_jm2']),
        most=json_value(d['most']),
        canopy_geometry=json_value(d.get('canopy_geometry')),
        biogeochemistry=json_value(d['biogeochemistry']),
    )
    return values


original_step = reference.step_clm_enthalpy_column
active = {}
base_calls = {}
old_reference = {}
completed = {}
rows = []
original_payload = copy.deepcopy(payload)
for k in indices:
    filename = f'case-{k:02d}-reference.pkl.gz'
    raw = (mi / filename).read_bytes()
    assert sha(raw) == mi_receipt['results'][k]['reference_sha256']
    (root / ('mi-' + filename)).write_bytes(raw)
    old_reference[k] = pickle.loads(gzip.decompress(raw))


def guarded_step(state, forcing, *args, **kwargs):
    k, scenario = active['index'], active['scenario']
    active['calls'] += 1
    active['constructed_input'] = copy.deepcopy((state, forcing, args, kwargs))
    assert active['calls'] == 1
    prior = old_reference[k]['before']
    assert state.canopy_condensate is not None
    assert len(state.canopy_condensate.mass) == 10
    assert len(state.snow.mass) == 0 and state.swe == 0.
    if scenario == 'A-original':
        exact(state, prior, 'A-state')
        base_calls[k] = copy.deepcopy((forcing, args, kwargs))
    else:
        exact(state, prior, 'structured-state', omit=frozenset({'sai', 'canopy_structure_parameters'}))
        exact((forcing, args, kwargs), base_calls[k], 'forcing-and-keyword-inputs')
        p = state.canopy_structure_parameters
        assert int(p.scheme) == 0 and p.canopy_top_m == 32. and p.canopy_bottom_m == 0. and p.short_vegetation is False
        assert state.sai == active['sai']
    active['input_byte_gate'] = True
    return original_step(state, forcing, *args, **kwargs)


def write_receipt(final=False):
    immutable = all(sha((source / n).read_bytes()) == h for n, h in manifest.items())
    failed = [r for r in rows if r['status'] != 'success']
    out = dict(scope=__doc__, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
               requested_cases=4, requested_scenarios=4, requested_calls=16, recorded_scenarios=len(rows),
               successful_calls=sum(r['status'] == 'success' for r in rows),
               complete=final, all16_success=final and len(rows) == 16 and not failed,
               source_manifest_sha256=manifest_sha, source_unchanged=immutable,
               diagnostic_input_sha256=sha(input_raw),
               archive_inputs={k: dict(archive=v[0], sha256=v[1]) for k, v in archives.items()},
               stem_geometry=dict(scheme='PRESCRIBED', canopy_top_m=32., canopy_bottom_m=0., short_vegetation=False,
                                  scope='Explicit no-snow burial placeholder, not a new observed crown base; original MOST unchanged.'),
               all_payload_bytes_unchanged=True,
               seconds=time.monotonic() - started, scenarios=rows,
               exclusions='No new live leaf area, PFT mixing weights, dry-wood heat store, optical parameters, numerical tolerance, forcing or original-year change. The 0.8/1.5 inputs are distinct literature-method diagnostic scenarios, not a confidence interval or calibrated parameters.')
    exact(payload, original_payload, 'original-payload-after-calls')
    out['worker_exit_status'] = (0 if out['all16_success'] and immutable else 1) if final else None
    (root / 'receipt.json').write_text(json.dumps(out, indent=2, allow_nan=False) + '\n')
    return out


def run_one(k, scenario, sai):
    start = time.monotonic()
    label = f'{k:02d}-{scenario}'
    row = dict(index=k, case=binding['cases'][k]['case'], scenario=scenario, prescribed_sai=sai,
               time_start=binding['cases'][k]['time_start'], time_end=binding['cases'][k]['time_end'], status='running')
    active.clear()
    active.update(index=k, scenario=scenario, sai=sai, calls=0, input_byte_gate=False)
    print(json.dumps(dict(start=label, case=row['case'])), flush=True)
    computed = None
    try:
        options = dict(most_geometry=native.MOSTGeometry(*map(float, payload['geometry'][k])),
                       leaf_parameters=native.LeafParameters(**binding['leaf_parameters']), return_states=True)
        if scenario != 'A-original':
            options['canopy_structure'] = (np.array([sai]), np.array([32., 0.]), np.array([0, 0], np.int32))
        got, before, after = reference.reference(
            tuple(payload['a' + str(i)][k] for i in range(16)), payload['forcing'][k], payload['deposition'][k],
            payload['calendar_values'][k], payload['calendar_flags'][k], payload['nitrogen'][k], 1., **options)
        computed = dict(result=got, before=before, after=after)
        assert active['input_byte_gate'] and active['calls'] == 1
        if scenario == 'A-original':
            prior = old_reference[k]
            exact(got, prior['result'], 'A-result')
            exact(before, prior['before'], 'A-before')
            exact(after, prior['after'], 'A-after')
            row['full_mi_replay_byte_exact'] = True
        else:
            baseline = completed[(k, 'A-original')]
            exact(got['diagnostics']['biogeochemistry']['lai_used'], baseline['result']['diagnostics']['biogeochemistry']['lai_used'], 'lai-used')
            assert got['diagnostics']['biogeochemistry']['lai_used'] == 0.
            if scenario == 'B-structured-zero':
                exact(comparable_result(got), comparable_result(baseline['result']), 'B-common-result')
                exact(before, baseline['before'], 'B-before', omit=frozenset({'sai', 'canopy_structure_parameters'}))
                exact(after, baseline['after'], 'B-after', omit=frozenset({'sai', 'canopy_structure_parameters'}))
                row['zero_sai_physical_bridge_byte_exact'] = True
        forcing = runner.Forcing(*payload['forcing'][k].astype(float))
        values = summary(got, before, after, forcing, float(payload['nitrogen'][k]))
        record = dict(result=got, before=before, after=after, forcing=forcing, original_index=k,
                      scenario=scenario, input_arguments=base_calls[k], summary=values)
        raw = gzip.compress(pickle.dumps(record, protocol=5), mtime=0)
        filename = label + '.pkl.gz'
        (root / filename).write_bytes(raw)
        completed[(k, scenario)] = record
        row.update(status='success', record=filename, record_sha256=sha(raw), values=values, original_hard_budget_passed=True)
    except Exception as error:
        row.update(status='failure', exception_type=type(error).__name__, exception=str(error), traceback=traceback.format_exc())
        (root / (label + '-failure.txt')).write_text(row['traceback'])
        raw = gzip.compress(pickle.dumps(dict(computed=computed, constructed_input=active.get('constructed_input')), protocol=5), mtime=0)
        filename = label + '-failure-state.pkl.gz'
        (root / filename).write_bytes(raw)
        row.update(record=filename, record_sha256=sha(raw))
    row.update(actual_calls=active['calls'], input_byte_gate=active['input_byte_gate'], seconds=time.monotonic() - start)
    rows.append(row)
    write_receipt()
    print(json.dumps({key: row[key] for key in ['index', 'case', 'scenario', 'status', 'input_byte_gate', 'seconds']}), flush=True)


reference.step_clm_enthalpy_column = guarded_step
try:
    for k in indices:
        run_one(k, 'A-original', 0.)
    a_passed = all((k, 'A-original') in completed for k in indices)
    for k in indices:
        if a_passed:
            run_one(k, 'B-structured-zero', 0.)
        else:
            rows.append(dict(index=k, case=binding['cases'][k]['case'], scenario='B-structured-zero', status='dependency-skipped', reason='At least one exact original replay failed; no bridge conclusion.'))
    bridges_passed = a_passed and all((k, 'B-structured-zero') in completed for k in indices)
    for scenario, sai in [('C-sai-0p8', .8), ('D-sai-1p5', 1.5)]:
        for k in indices:
            if bridges_passed:
                run_one(k, scenario, sai)
            else:
                rows.append(dict(index=k, case=binding['cases'][k]['case'], scenario=scenario, prescribed_sai=sai, status='dependency-skipped', reason='Original replay or zero-SAI bridge failed; no pure-SAI attribution.'))
finally:
    reference.step_clm_enthalpy_column = original_step
receipt = write_receipt(final=True)
print(json.dumps({k: receipt[k] for k in ['pbs_job', 'node', 'complete', 'all16_success', 'successful_calls', 'source_unchanged', 'seconds', 'worker_exit_status']}), flush=True)
sys.exit(receipt['worker_exit_status'])

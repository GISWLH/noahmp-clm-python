from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
import resource
b=Path(os.environ['NM_ROOT']);s=Path(os.environ['NM_SOURCE']);r=b/'cold48';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==584 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]

from climatology_contract_nm import verify_source, verify_inputs, load as nm_load
nm_root=Path(os.environ['NM_ROOT']); nm_plan=nm_load(nm_root/'plan.json')
assert all(sha(nm_root/n)==h for n,h in nm_plan['controls_sha256'].items())
verify_source(s); verify_inputs(nm_root/'cold48/inputs',nm_load(nm_root/'reference-reuse.json'))
import run_fluxnet_native as native
import run_fluxnet_column as numpy_runner
import noahmp_clm.clm_enthalpy_driver as numpy_driver
import noahmp_clm.physics.richards as numpy_flow
import cupy as cp
verification=json.loads((r/'prefix-verification.json').read_text());binding=json.loads((r/'year-prefix-binding.json').read_text());assert verification['passed'] and verification['source_unchanged'] and verification['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and verification['cold_fields_exact']==23 and verification['physical_step_pairs']==576 and verification['all16state_chains_and_final_checkpoint_exact'] and len(verification['cases'])==12 and all(c['passed'] and c['all48_actual_deposition_inputs_byteexact_to_declared_climatology'] for c in verification['cases'])
assert sha(r/'trajectory/batch.json')==binding['prefix_batch_report_sha256'];report,saved,rows=native.read_generation(r/'trajectory');assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['checkpoint_sha256']==binding['prefix_checkpoint_sha256'] and report['same_precision_max_absolute'] is None and len(saved)==23 and len(rows)==12
(r/'validated-prefix-state.npz').write_bytes((r/'trajectory'/report['checkpoint_file']).read_bytes());(r/'validated-prefix-report.json').write_bytes((r/'trajectory/batch.json').read_bytes())
start=time.monotonic();failure=None;checked_start=False;captured_first=False;original_step=native.Backend.step;original_audit=native.audit_step;original_forbidden=[numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy]
def forbidden(*a,**kw):raise AssertionError('Native climate year cannot use NumPy forward physics')
def check_start(self,*a,**kw):
    global checked_start
    if not checked_start:
        current=json.loads((r/'trajectory/batch.json').read_text());assert current['steps_completed']==48 and current['status']=='running'
        with np.load(r/'trajectory'/current['checkpoint_file'],allow_pickle=False) as z,np.load(r/'validated-prefix-state.npz',allow_pickle=False) as prior:
            assert set(z.files)==set(prior.files) and len(z.files)==23
            for key in z.files:assert z[key].dtype==prior[key].dtype and z[key].shape==prior[key].shape and z[key].tobytes()==prior[key].tobytes(),key
        native.atomic_json(r/'year-start-audit.json',dict(scope='Immediately before first continued tendency, all16primary+7ledger fields exact to own independently verified successful48. Same source/config/forcing/identity/request17520, no failedprefix or reset.',saved_fields_exact=23,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),verified_prefix_checkpoint_sha256=binding['prefix_checkpoint_sha256'],current_checkpoint_sha256=sha(r/'trajectory'/current['checkpoint_file']),cpu_verification_sha256=sha(r/'prefix-verification.json')));checked_start=True
    return original_step(self,*a,**kw)
bgc_index=48;bgc_buffer=[];bgc_folder=r/'year-bgc-diagnostics';bgc_folder.mkdir();bgc_chunks=[]
def retain_bgc(before,after,f,dep,nitrogen,out):
    global bgc_index
    row=dict(forcing=np.asarray(f).copy(),deposition=np.asarray(dep).copy(),nitrogen=np.asarray(nitrogen).copy(),before_plant=np.asarray(before[11]).copy(),before_soil_cn=np.asarray(before[13]).copy(),after_plant=np.asarray(after[11]).copy(),after_soil_cn=np.asarray(after[13]).copy())
    def flatten(d,prefix='bgc/'):
        for k,v in d.items():
            if isinstance(v,dict):flatten(v,prefix+k+'/')
            else:row[prefix+k]=np.asarray(v).copy()
    flatten(out['biogeochemistry']);assert all(v.dtype.kind!='O' for v in row.values());bgc_buffer.append(row);bgc_index+=1
    if bgc_index%48==0:
        begin=bgc_index-len(bgc_buffer);path=bgc_folder/('steps-'+str(begin).zfill(7)+'-'+str(bgc_index).zfill(7)+'.npz');native.write_npz(path,**{k:np.stack([a[k] for a in bgc_buffer]) for k in row});bgc_chunks.append(dict(first=begin,end=bgc_index,sha256=sha(path)));bgc_buffer.clear()
def first_step(before,after,f,dep,nitrogen,out):
    global captured_first
    result=original_audit(before,after,f,dep,nitrogen,out)
    if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>4*1024*1024:raise RuntimeError('CUDA-onlyyear exceeded4GiB measuredhostpeak')
    if not captured_first:
        values=dict(forcing=np.asarray(f),deposition=np.asarray(dep),nitrogen=np.asarray(nitrogen))
        for prefix,arrays in [('before',before),('after',after)]:values.update({prefix+str(k):np.asarray(v) for k,v in enumerate(arrays)})
        def flat(d,prefix='output/'):
            for k,v in d.items():
                if isinstance(v,dict):flat(v,prefix+k+'/')
                else:values[prefix+k]=np.asarray(v)
        flat(out)
        for name,value in zip(['incoming','residual','bound','impurity'],result):values['recorded/'+name]=np.asarray(value)
        np.savez_compressed(r/'first-continued-step.npz',**values);captured_first=True
    retain_bgc(before,after,f,dep,nitrogen,out)
    return result
try:
    native.Backend.step=check_start;native.audit_step=first_step;numpy_runner.step_clm_enthalpy_column=forbidden;numpy_driver.step_clm_enthalpy_column=forbidden;numpy_flow.redistribute_soil_enthalpy=forbidden
    native.run(r/'inputs/batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,resume=True)
    report,saved,rows=native.read_generation(r/'trajectory');assert checked_start and captured_first and report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520 and report['source_unchanged'] and report['same_precision_max_absolute'] is None and bgc_index==17520 and not bgc_buffer
except Exception as error:
    failure=type(error).__name__+': '+str(error);(r/'year-traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    native.Backend.step=original_step;native.audit_step=original_audit;numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy=original_forbidden
cp.cuda.runtime.deviceSynchronize();p=r/'trajectory/batch.json';report=json.loads(p.read_text()) if p.exists() else {};unchanged=all(sha(s/n)==h for n,h in m.items())
d=dict(bgc_diagnostic_chunks=bgc_chunks,bgc_diagnostic_steps=bgc_index-48,scope='NMintegratedML4plusNFplusNK584 original12case full17520 CUDA-onlyyear fromownfreshNM48 afternewactualF0independentcold23/16chains/MHCN/impurity/13trace/eachCNpool/nonzeroinputaudit. All23state/ledger fields exactbeforefirstcontinuedtendency; no failedprefix/reset/NumPyforward/JAXshadow. ActualBGCturnover/allocation/decomposition/soilpotential/plantandsoilCN archivedeach48forlaterindependentSOCanalysis; first48rawNMpackets retained. CurrentJO407 andJS1e-6 regression remainindependent/pending andcannotbecreditedfromthisyear. Original32GiBhost/8GiBGPUstart and4GiBmeasuredpeak, originalallphysicalgates. No full407/sameprecision/observedscience/spinupclaim; CuPybarrier/durable receipt beforeatexit bypass',case='all12-climatology',failure=failure,maximum_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),continued_fields_exact=23 if checked_start else None,first_continued_step_captured=captured_first,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),same_precision_max_absolute=report.get('same_precision_max_absolute'),device_barrier_complete=True,seconds=time.monotonic()-start,report_sha256=sha(p) if p.exists() else None)
native.atomic_json(r/'year-receipt.json',d);print(json.dumps(d),flush=True);os._exit(0 if failure is None and unchanged else 1)

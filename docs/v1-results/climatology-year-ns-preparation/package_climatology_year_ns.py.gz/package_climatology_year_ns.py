"""Package prepared NS controls and original static evidence; no runtime action."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

p = Path(__file__).resolve().parent
d = p / 'climatology-year-ns-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
controls = json.loads((d / 'CONTROLS_SHA256.json').read_text())
assert all(sha((d / n).read_bytes()) == h for n, h in controls.items())
status = json.loads((d / 'static-check.json').read_text())
assert status['status'] == 'prepared_only' and status['controls_sha256'] == controls
assert status['static_native_resume_identity_exact'] and not status['numerical_execution']
assert not (d / 'promotion.json').exists()
files = {f'prepared/{f.name}': f.read_bytes() for f in d.iterdir() if f.is_file()}
files['check_climatology_year_ns.py'] = (p / 'check_climatology_year_ns.py').read_bytes()
files['package_climatology_year_ns.py'] = Path(__file__).read_bytes()
files['origin/run_year_nm.py'] = (p / 'climatology-preparation-nm/run_year_nm.py').read_bytes()
inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = p / 'climatology-year-ns-preparation-evidence.tar.gz'
assert not target.exists(), 'Do not silently replace an archived preparation'
with tarfile.open(target, 'w:gz') as t:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        t.addfile(item, io.BytesIO(raw))
with tarfile.open(target) as t:
    assert {m.name: t.extractfile(m).read() for m in t} == files
package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
    artifacts=len(files), status='prepared_only', source_manifest_sha256=status['source_manifest_sha256'],
    source_archive_sha256=status['source_archive_sha256'], device_archive_sha256=status['device_archive_sha256'],
    nr_actual='1585.manager F0, 1168/0/0/0', np_pair_actual='1586.manager F0, 576 pairs',
    np_pair_archive_sha256='a1a7b9703af3fc10683e2f3da5413426023297198603cbba65ee7dc3cf28be43',
    original_year_observers_ast_exact=4, original_year_asserts_ast_exact=10,
    original_native_run_call_ast_exact=True, control_directory_separate=True,
    original_np_candidate_flags_unchanged=True, numerical_execution=False, gpu_launches=0,
    pbs_submissions=0, collection_executed=False, remote_mutations=False,
    future_command='/home/lhwang/venvs/noahmp-phase3b/bin/python -B /home/lhwang/work/noahmp-v1/climatology-year-ns-preparation/launch_year_ns.py year',
    pending='Complete original MX31/NF checks, formal root promotion.json and fresh runtime still-held48/immutable-input/source/resource checks. No automatic continuation.')
(p / 'climatology-year-ns-preparation-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package, indent=2))

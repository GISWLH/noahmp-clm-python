# NS：从封存的 NP 冷 48 步接续完整年度（仅准备）

本目录只有独立控制与静态证据；未运行模型、collect、GPU、PBS，也未修改远程源、原 NP 控制/输入/封存包或生产 runner。唯一入口为 `launch_year_ns.py year`。没有冷启动入口、任意 resume 路径、cycle2/3 或自动启动下一阶段。

固定源为 NM 的 584 文件：manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f`，源包 `39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d`。继续使用 `/tmp/noahmp-climatology-cold48-np/source` 与原 `/home/lhwang/work/noahmp-v1/climatology-cold48-np/cold48/inputs/batch.json`，不重新解包或生成状态。

已从本地实际 NP 设备封存包验证：SHA `ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416`；原 parent0；12 配置、完成 48/请求 17520 步；`ledger_steps=48, ledger_segments=1`；检查点 SHA `08381d13933e809519ea9ca57471372cf814d1b07605bec3ad56e61013f2fc16`。检查点包含 `a0..a15` 及 index/initial/net/bounds/maximum/stepmax/tracermax 全部 23 字段。静态检查只读归档字节与文件名，未在本机求值物理数组。

原 native 严格 identity 由 batch、12 组配置与强迫、全部前向源文件哈希及 cuda32/shadow=false 组成，不含控制目录；归档 identity 与 NM 重建的元数据完全一致。因此新控制目录可以调用原 `native.run(..., resume=True)`，直接继续**同一 NP trajectory 原路径**。不接失败 JN2657，不裁剪、不重新初始化、不改 index 或全局账；resume 仍执行原 identity 完整相等检查。NP 原 `candidate_only=true/continuation_allowed=false` 保留，新授权只写入独立 NS 凭证。年度运行将推进 live trajectory 的 batch 指针和新状态/trace，并添加 `year-*` 文件；原封存包保留第 48 步证据。

启动前，NS 要求以下条件全部具备；缺任一项会拒绝，且不会创建 NS 运行目录：

- 原 NM 全合同逐字节复制，重新检查完整 MX 的 8 模块/31 节点实际 parent0、NF 原负控1/正控0、完整 phase/barrier/node/source 证据，以及 NK 原实际 F0；额外检查 NF 345 字段最大差为 0。
- 随包 NR 精确归档 SHA `6c77ee006ab9a815569039f491a7b1bd69fd118c1886ab178f72cbe0bd58466a`，实际 `1585.manager F0`、1168/0/0/0、原1156+新增12节点、同源584及执行覆盖。
- 随包原 EHPC **1586.manager 实际 F0** 的 `climatology-cold48-np-pair-evidence.tar.gz`，固定 SHA `a1a7b9703af3fc10683e2f3da5413426023297198603cbba65ee7dc3cf28be43`；核验其全部 artifact inventory、576 对、23 冷字段、16 状态链与最终检查点、12 全配置及非零沉降输入检查。该原审计耗时 4.9462 秒且全部通过，NS 没有重跑它。
- root 在正式晋升后将 `promotion.template.json` 填为独立 `promotion.json`，记录真实 40 位 commit，保留模板中的精确源/NP/NR/1586 归档哈希，并显式设 `allow_np48_to_year=true`。默认模板为 false，不构成授权；不得改原 NP 许可字段。
- 原 NP 封存包、全部原控制与输入仍一致；**封存包内每个原文件与 live NP 原文件逐字节一致**，特别是仍保留 48 步的 batch、检查点、12 组 generation report/trace。以此绑定全部原状态与全局账；已推进、失败或重置的轨迹均拒绝。
- 原 NP controller/worker 已退出；目标是物理 CUDA1 UUID `GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452`，启动时 GPU 空闲 >8 GiB、主机可用 >32 GiB；沿用运行中实测峰值 4 GiB 门，NS 使用独立私有编译缓存。

未来 root 将本准备目录及晋升文件放到 xuanze 的独立准备目录后，使用现有 GPU Python 环境执行 `python -B launch_year_ns.py year`。运行目录固定为 `/home/lhwang/work/noahmp-v1/climatology-year-ns`，缓存 `/tmp/noahmp-climatology-year-ns`，均必须尚不存在；只启动一次，不提供失败后覆写/续跑入口。launcher、controller、worker 均在第一步前重查证据；另将原实际 F0 审计字节与 NS/NP 计划绑定。这里没有执行该命令。

推荐未来固定准备路径为 `/home/lhwang/work/noahmp-v1/climatology-year-ns-preparation`。root 满足上述条件并在该目录落盘真实 `promotion.json` 后，仅执行以下一次命令。Python 路径直接取自原 NP 成功 worker 回执，未猜测环境：

```sh
/home/lhwang/venvs/noahmp-phase3b/bin/python -B /home/lhwang/work/noahmp-v1/climatology-year-ns-preparation/launch_year_ns.py year
```

`run_year_ns.py` 由 NM 年度 worker 做路径/合同/回执说明适配。`forbidden`、`check_start`、`retain_bgc`、`first_step` 四函数 AST 完全相同；原 worker 全部 10 个 assert AST 及唯一 `native.run` 调用完全相同。每 48 步留存真实 BGC 诊断、首次继续前 23 字段逐字节检查、第一步实际包、原 M/H/C/N 与杂质硬门、禁 NumPy 前向/禁 JAX shadow 均保留。结束另核对完整年 ledger=17520/1 与原 identity；全量 GPU 回归、科学观测与 SOC 长期准平衡仍需独立验证。

静态复核命令：`E:/miniconda3/python.exe -B outputs/v1/check_climatology_year_ns.py`；接口只读检查：`E:/miniconda3/python.exe -B outputs/v1/climatology-year-ns-preparation/launch_year_ns.py --help`。`static-check.json` 和 `CONTROLS_SHA256.json` 保存结果及控制哈希。静态检查验证封存的 48 步，**不声称已核验远端当前仍保留状态或已满足晋升条件**；运行前合同负责这些检查。一个完整年度也不构成 SOC 准平衡或 FLUXNET 验收。

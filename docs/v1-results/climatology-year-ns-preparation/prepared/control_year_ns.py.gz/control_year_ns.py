"""One actual year worker; never automatically launches another year or cycle."""
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from climatology_contract_ns import NP_ROOT, NP_SOURCE, NS_ROOT, TARGET, load, preflight, sha, verify_np_static, verify_year_binding

assert Path(os.environ['NS_ROOT']) == NS_ROOT and Path(os.environ['NS_SOURCE']) == NP_SOURCE
folder = NP_ROOT / 'cold48'
started = time.monotonic()
code, failure, passed = None, None, False
try:
    plan = load(NS_ROOT / 'plan.json')
    assert all(sha(NS_ROOT / n) == h for n, h in plan['controls_sha256'].items())
    assert plan['original_np_plan_sha256'] == sha(NP_ROOT / 'plan.json')
    verify_year_binding(NS_ROOT, preflight(NS_ROOT))
    command = [sys.executable, '-u', str(NS_ROOT / 'run_year_ns.py')]
    with (folder / 'year-model.log').open('x') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    with (folder / 'year-worker.json').open('x') as stream:
        json.dump(dict(pid=process.pid, command=command), stream)
    code = process.wait()
    record = load(folder / 'year-receipt.json')
    passed = bool(code == 0 and record['failure'] is None and record['source_unchanged']
        and record['source_manifest_sha256'] == TARGET and record['device_barrier_complete']
        and record['status'] == 'complete' and record['steps_completed'] == record['steps_requested'] == 17520
        and record['continued_fields_exact'] == 23 and record['first_continued_step_captured']
        and record['bgc_diagnostic_steps'] == 17472)
    if passed:
        report = load(folder / 'trajectory/batch.json')
        prefix = load(folder / 'validated-prefix-report.json')
        assert record['report_sha256'] == sha(folder / 'trajectory/batch.json')
        assert report['ledger_steps'] == 17520 and report['ledger_segments'] == 1
        assert report['identity'] == prefix['identity']
    verify_np_static()
    assert all(sha(NS_ROOT / n) == h for n, h in plan['controls_sha256'].items())
    assert plan['original_np_plan_sha256'] == sha(NP_ROOT / 'plan.json')
except Exception as error:
    failure = type(error).__name__ + ': ' + str(error)
    (folder / 'year-controller-traceback.txt').write_text(traceback.format_exc())
result = dict(stage='year', passed=bool(passed and failure is None), failure=failure,
    actual_parent_returncode=code, source_manifest_sha256=TARGET,
    receipt_sha256=sha(folder / 'year-receipt.json') if (folder / 'year-receipt.json').exists() else None,
    seconds=time.monotonic() - started,
    scope='NS actual parent exit for complete same NP trajectory. Original physical gates and '
          'successful48 state/ledger identity retained; no SOC convergence, observed science, '
          'full GPU regression or next-cycle credit inferred.')
with (folder / 'year-exit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['passed'] else 1)

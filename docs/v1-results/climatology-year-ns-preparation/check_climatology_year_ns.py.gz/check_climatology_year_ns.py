"""Standard-library-only static review of NS; no imports of runners or model."""
import ast
import datetime
import hashlib
import io
import json
import tarfile
import zipfile
from pathlib import Path

P = Path(__file__).resolve().parent
D = P / 'climatology-year-ns-preparation'
NM = P / 'climatology-preparation-nm'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
sha = lambda path: digest(path.read_bytes())
dump = lambda value: ast.dump(value, include_attributes=False)
expected_source = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
archive_source = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
device = 'ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416'
for name in ['climatology_contract_nm.py', 'EXPECTED_SOURCE_SHA256.json', 'soc-strict-boundary-nk-evidence.tar.gz']:
    assert (D / name).read_bytes() == (NM / name).read_bytes()
assert sha(D / 'EXPECTED_SOURCE_SHA256.json') == expected_source
manifest = json.loads((D / 'EXPECTED_SOURCE_SHA256.json').read_bytes())
assert len(manifest) == 584
assert sha(P / 'climatology-final-candidate-nm-source.tar.gz') == archive_source
assert sha(D / 'climatology-final-cpu-nr-evidence.tar.gz') == '6c77ee006ab9a815569039f491a7b1bd69fd118c1886ab178f72cbe0bd58466a'

old = ast.parse((NM / 'run_year_nm.py').read_text())
new = ast.parse((D / 'run_year_ns.py').read_text())
functions = ['forbidden', 'check_start', 'retain_bgc', 'first_step']
for name in functions:
    a = next(v for v in old.body if isinstance(v, ast.FunctionDef) and v.name == name)
    b = next(v for v in new.body if isinstance(v, ast.FunctionDef) and v.name == name)
    assert dump(a) == dump(b), name
old_asserts = [dump(v) for v in ast.walk(old) if isinstance(v, ast.Assert)]
new_asserts = [dump(v) for v in ast.walk(new) if isinstance(v, ast.Assert)]
assert old_asserts == new_asserts
calls = lambda tree: [v for v in ast.walk(tree) if isinstance(v, ast.Call) and isinstance(v.func, ast.Attribute)
                     and isinstance(v.func.value, ast.Name) and v.func.value.id == 'native' and v.func.attr == 'run']
assert len(calls(new)) == len(calls(old)) == 1 and dump(calls(new)[0]) == dump(calls(old)[0])
assert {k.arg: ast.literal_eval(k.value) for k in calls(new)[0].keywords} == {
    'backend': 'cuda32', 'compare_jax32': False, 'resume': True}
for path in D.glob('*.py'):
    compile(path.read_bytes(), str(path), 'exec')

input_archive = P / 'climatology-cold48-np-audit-input.tar.gz'
assert sha(input_archive) == '36f05c548a5e9dc295078a37d57cca316c6c139b9d1855fda78c2fa307066103'
with tarfile.open(input_archive) as t:
    device_raw = t.extractfile('cold48-evidence.tar.gz').read()
assert digest(device_raw) == device
with tarfile.open(fileobj=io.BytesIO(device_raw)) as t:
    data = {m.name: t.extractfile(m).read() for m in t if m.isfile()}
report = json.loads(data['current/trajectory/batch.json'])
plan = json.loads(data['control/plan.json'])
end = json.loads(data['current/exit.json'])
receipt = json.loads(data['current/receipt.json'])
assert plan['source_manifest_sha256'] == receipt['source_manifest_sha256'] == expected_source
assert plan['candidate_only'] and plan['continuation_allowed'] is False
assert end['passed'] and end['actual_parent_returncode'] == 0
assert end['receipt_sha256'] == digest(data['current/receipt.json'])
assert receipt['report_sha256'] == digest(data['current/trajectory/batch.json'])
assert report['status'] == 'running' and report['steps_completed'] == report['ledger_steps'] == 48
assert report['ledger_segments'] == 1 and report['steps_requested'] == 17520 and report['columns'] == 12
assert report['same_precision_max_absolute'] is None
checkpoint = data['current/trajectory/' + report['checkpoint_file']]
assert digest(checkpoint) == report['checkpoint_sha256'] == '08381d13933e809519ea9ca57471372cf814d1b07605bec3ad56e61013f2fc16'
with zipfile.ZipFile(io.BytesIO(checkpoint)) as z:
    fields = sorted(z.namelist())
assert set(fields) == {f'a{i}.npy' for i in range(16)} | {
    'index.npy', 'initial.npy', 'net.npy', 'bounds.npy', 'maximum.npy', 'stepmax.npy', 'tracermax.npy'}
names = {n for n in manifest if n.startswith('src/noahmp_clm/') and Path(n).suffix in ('.py', '.cu', '.npz')}
names |= {'benchmarks/run_fluxnet_native.py', 'benchmarks/run_fluxnet_column.py',
          'benchmarks/fluxnet_solar.py', 'benchmarks/fluxnet_deposition.py'}
batch_raw = data['current/inputs/batch.json']
rows = json.loads(batch_raw)['cases']
identities = [dict(case=r['case'], forcing_npz_sha256=digest(data['current/inputs/' + r['input']]),
                  forcing_manifest_sha256=digest(data['current/inputs/' + r['input_manifest']]),
                  configuration_sha256=digest(data['current/inputs/' + r['configuration']])) for r in rows]
identity = dict(batch_sha256=digest(batch_raw), cases=identities,
                source_sha256={n: manifest[n] for n in names}, backend='cuda32', compare_jax32=False)
assert report['identity'] == identity
for case, descriptor in report['case_reports'].items():
    prefix = 'current/trajectory/' + case + '/'
    raw = data[prefix + descriptor['file']]
    assert digest(raw) == descriptor['sha256']
    item = json.loads(raw)
    assert item['steps_completed'] == item['ledger_steps'] == 48 and item['ledger_segments'] == 1
    assert item['batch_checkpoint_sha256'] == report['checkpoint_sha256']
    assert digest(data[prefix + item['model_npz']]) == item['model_npz_sha256']

promotion = json.loads((D / 'promotion.template.json').read_text())
assert promotion['allow_np48_to_year'] is False
assert not (D / 'promotion.json').exists()
assert sha(D / 'climatology-cold48-np-pair-evidence.tar.gz') == promotion['np_pair_archive_sha256'] == 'a1a7b9703af3fc10683e2f3da5413426023297198603cbba65ee7dc3cf28be43'
names = sorted(p.name for p in D.iterdir() if p.is_file() and (p.suffix == '.py' or p.name in {
    'EXPECTED_SOURCE_SHA256.json', 'soc-strict-boundary-nk-evidence.tar.gz',
    'climatology-final-cpu-nr-evidence.tar.gz', 'climatology-cold48-np-pair-evidence.tar.gz'}))
controls = {name: sha(D / name) for name in names}
(D / 'CONTROLS_SHA256.json').write_text(json.dumps(controls, indent=2) + '\n')
result = dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), status='prepared_only',
    source_manifest_sha256=expected_source, source_archive_sha256=archive_source, device_archive_sha256=device,
    original_np_plan_sha256=digest(data['control/plan.json']), checkpoint_sha256=report['checkpoint_sha256'],
    archived_np_actual_parent_returncode=0, original_np_continuation_allowed=False,
    static_native_resume_identity_exact=True, identity_has_no_control_directory=True,
    identity_source_files=len(identity['source_sha256']), case_count=12,
    held_archived_steps=48, requested_steps=17520, ledger_steps=48, ledger_segments=1,
    checkpoint_field_names=fields, original_year_observer_functions_ast_exact=functions,
    original_year_asserts_ast_exact=len(old_asserts), original_native_run_call_ast_exact=True,
    original_nm_full_prerequisite_contract_byteexact=True, controls_sha256=controls,
    numerical_execution=False, model_imports=False, gpu_launches=0, pbs_submissions=0,
    collection_executed=False, remote_mutations=False,
    pending_runtime=['complete original MX31 and NF evidence', 'recheck exact NP1586 F0 archive and NR1585 F0 archive',
                     'explicit formal promotion.json', 'still-held48 original bytes and all original NP controls/inputs',
                     'CUDA1 >8GiB and host >32GiB startup guards'],
    scope='Static preparation only. Does not claim current held-state readback, annual success, SOC equilibrium, '
          'observational accuracy, full408 regression, or authorization from original NP candidate-only records.')
(D / 'static-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['status', 'static_native_resume_identity_exact',
    'original_year_observer_functions_ast_exact', 'original_year_asserts_ast_exact',
    'original_native_run_call_ast_exact', 'numerical_execution', 'gpu_launches']}, indent=2))

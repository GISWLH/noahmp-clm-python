"""Diagnostic single-step NumPy references from an actual failed CUDA input."""
from pathlib import Path
from dataclasses import astuple
import gzip,hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-failed-reference-mi';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();device=tmp/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=b/'clm-ballberry-jn-source.tar.gz';assert sha(source)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(source) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());packet=json.loads((b/'climatology-failed-year-mh-export.json').read_text());a=b/packet['archive'];assert sha(a)==packet['sha256']=='f728890bfe81cddae1d85ae2effa69e4eb541b6f1e9ba12b335f90374d098340'
with tarfile.open(a) as tf:tf.extractall(device,filter='data')
snap=json.loads((device/'snapshot.json').read_text());assert snap['actual_year_parent_returncode']==1 and snap['failed_attempt_index']==2657;batch=json.loads((device/'failed/batch.json').read_text());assert batch['status']=='failed' and batch['steps_completed']==batch['failed_step']==2657 and batch['steps_requested']==17520;checkpoint=device/'failed'/batch['checkpoint_file'];assert sha(checkpoint)==batch['checkpoint_sha256'];assert (device/'source/SOURCE_SHA256.json').read_bytes()==(s/'SOURCE_SHA256.json').read_bytes();sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as runner
import test_gpu_clm_bgc_column as reference_module
cases=native.load_batch(device/'inputs/batch.json');assert len(cases)==12 and native.native_state_count(cases)==16 and native.sha(device/'inputs/batch.json')==batch['identity']['batch_sha256'] and batch['identity']['source_sha256']==native.source_hashes()
for case,identity in zip(cases,batch['identity']['cases']):
    assert case['case']==identity['case'] and native.sha(case['paths']['input'])==identity['forcing_npz_sha256'] and native.sha(case['paths']['input_manifest'])==identity['forcing_manifest_sha256'] and native.sha(case['paths']['configuration'])==identity['configuration_sha256']
with np.load(checkpoint,allow_pickle=False) as z:saved=dict(z)
assert int(saved['index'])==2657;arrays=tuple(v.copy() for v in native.checkpoint_arrays(saved,batch['identity']));index=int(saved['index']);dtype=np.float32;forcing=np.asarray([c['data']['forcing'][index] for c in cases],dtype);environment=np.asarray([c['data']['environment'][index] for c in cases],dtype);arrays[4][:,7:10]=environment;e,cal=native.pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype);geometry=np.asarray([astuple(native.MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype);schedules=[native.DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([d.nitrogen_rate for d in schedules],dtype)*forcing[:,0];deposition=np.asarray([d.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,d) in enumerate(zip(cases,schedules))],dtype);hydrology=native.batch_hydrology(cases);leaf=native.LeafParameters(**cases[0]['config']['leaf_parameters']);optics=None
if any(c['config'].get('canopy_optics') is not None for c in cases):
    from noahmp_clm.physics.canopy_optics import CanopyOptics
    from noahmp_clm.gpu.canopy_optics import pack_canopy_optics
    optics=np.stack([pack_canopy_optics(CanopyOptics(**(c['config'].get('canopy_optics') or {})),dtype) for c in cases])
payload={**{'a'+str(k):v for k,v in enumerate(arrays)},'forcing':forcing,'environment':environment,'calendar_values':e,'calendar_flags':cal,'geometry':geometry,'nitrogen':nitrogen,'deposition':deposition}
if optics is not None:payload['canopy_optics']=optics
np.savez_compressed(r/'diagnostic-input.npz',**payload);binding=dict(leaf_parameters=cases[0]['config']['leaf_parameters'],soil_hydrology=cases[0]['config'].get('soil_hydrology'),cases=[dict(case=c['case'],site=c['config']['site'],time_start=str(c['data']['time_start'][index]),time_end=str(c['data']['time_end'][index]),configuration=c['config']) for c in cases],source_manifest_sha256=manifest,failed_checkpoint_sha256=batch['checkpoint_sha256'],diagnostic_input_sha256=sha(r/'diagnostic-input.npz'),scope='Exact failedattempt2657 input only, a4environment replacedasoriginalproducer beforetendency. All16 extensive/statearrays otherwiseunchanged; no yearresume or physical/globalledger reset.');(r/'binding.json').write_text(json.dumps(binding,indent=2)+'\n');original_step=reference_module.step_clm_enthalpy_column
def with_hydrology(*args,**kwargs):
    if hydrology is not None:kwargs['soil_hydrology']=hydrology
    return original_step(*args,**kwargs)
reference_module.step_clm_enthalpy_column=with_hydrology;results=[];started=time.monotonic()
try:
    for k,case in enumerate(cases):
        start=time.monotonic();failure=None;stored=None;budget=None;one_optics=None
        if optics is not None:one_optics=CanopyOptics(**(case['config'].get('canopy_optics') or {}))
        try:
            got,before,after=reference_module.reference(tuple(v[k] for v in arrays),forcing[k],deposition[k],e[k],cal[k],nitrogen[k],1.,most_geometry=native.MOSTGeometry(*map(float,geometry[k])),leaf_parameters=leaf,canopy_optics=one_optics,return_states=True);incoming,residual,bound=runner.audit_step(before,after,runner.Forcing(*map(float,forcing[k])),got['diagnostics'],float(nitrogen[k]));budget=dict(residual_m_h_c_n=residual.tolist(),original_bounds_m_h_c_n=bound.tolist());stored=dict(result=got,before=before,after=after,independent_incoming=incoming,independent_residual=residual,independent_original_bound=bound)
        except Exception as err:failure=type(err).__name__+': '+str(err);(r/('case-'+str(k).zfill(2)+'-traceback.txt')).write_text(traceback.format_exc())
        p=r/('case-'+str(k).zfill(2)+'-reference.pkl.gz')
        if stored is not None:p.write_bytes(gzip.compress(pickle.dumps(stored,protocol=5),mtime=0))
        results.append(dict(column=k,case=case['case'],time_start=str(case['data']['time_start'][index]),failure=failure,passed=failure is None,independent_budget=budget,reference_file=p.name if stored is not None else None,reference_sha256=sha(p) if stored is not None else None,seconds=time.monotonic()-start));print(json.dumps(results[-1]),flush=True)
finally:reference_module.step_clm_enthalpy_column=original_step
unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged;out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=all(x['passed'] for x in results),all12_attempts_completed=len(results)==12,source_unchanged=unchanged,source_manifest_sha256=manifest,failed_year_export_sha256=sha(a),failed_attempt_index=index,original_year_parent_exit=1,diagnostic_input_sha256=sha(r/'diagnostic-input.npz'),binding_sha256=sha(r/'binding.json'),results=results,seconds=time.monotonic()-started,scope='IndependentEHPC originalJN NumPy fullcolumn perrow reference fromexactfailedCUDA2657quantizedinput. Originalstate reconstruction rebuildsonly diagnostic aliases/normalizesrootweights as existingreference; originalextensivearrays andfailedyear unchanged. Eachactualreferenceoutcome andoriginalhardMHCN retained. Diagnosticpoint only, never resume failedyear, annualcompletion/scientific/GPUacceptance or source/gate edit.');(r/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);raise SystemExit(0 if out['passed'] else 1)

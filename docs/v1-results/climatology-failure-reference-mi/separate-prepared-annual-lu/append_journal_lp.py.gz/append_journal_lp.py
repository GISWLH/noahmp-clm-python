"""Verified append-only frames in a pre-existing file; no sidecar allocation."""
from pathlib import Path
import gzip,hashlib,io,json,os,struct,tarfile

HEADER=struct.Struct('>8sQQ32s')
MAGIC=b'NMPJNL1\n'

def bundle(rows):
    target=io.BytesIO()
    with gzip.GzipFile(fileobj=target,mode='wb',mtime=0) as stream:
        with tarfile.open(fileobj=stream,mode='w') as tf:
            for name,raw in sorted(rows.items()):
                assert isinstance(raw,bytes) and not Path(name).is_absolute() and '..' not in Path(name).parts
                member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
    return target.getvalue()

def unbundle(raw):
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
        members=tf.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len({m.name for m in members})==len(members)
        return {m.name:tf.extractfile(m).read() for m in members}

class Journal:
    def __init__(self,path):
        self.path=Path(path);assert self.path.is_file() and not self.path.is_symlink()
        self.index={};self.end=0
        with self.path.open('rb') as stream:
            while True:
                head=stream.read(HEADER.size)
                if not head:break
                assert len(head)==HEADER.size,'Incomplete journal header'
                magic,nlabel,npayload,digest=HEADER.unpack(head)
                assert magic==MAGIC and 0<nlabel<4096 and npayload<2**36
                label=stream.read(nlabel);assert len(label)==nlabel
                label=label.decode('utf-8');assert label not in self.index
                offset=stream.tell();payload=stream.read(npayload)
                assert len(payload)==npayload and hashlib.sha256(payload).digest()==digest,'Incomplete/corrupt journal payload'
                self.index[label]=(offset,npayload,digest.hex());self.end=stream.tell()
        assert self.end==self.path.stat().st_size

    def read_raw(self,label):
        offset,n,digest=self.index[label]
        with self.path.open('rb') as stream:stream.seek(offset);raw=stream.read(n)
        assert len(raw)==n and hashlib.sha256(raw).hexdigest()==digest
        return raw

    def read(self,label):return unbundle(self.read_raw(label))

    def append(self,label,rows):
        payload=bundle(rows);digest=hashlib.sha256(payload).digest()
        if label in self.index:
            assert self.read_raw(label)==payload,'Existing journal identity collision'
            return False
        rawlabel=label.encode('utf-8');assert 0<len(rawlabel)<4096
        header=HEADER.pack(MAGIC,len(rawlabel),len(payload),digest)
        with self.path.open('r+b') as stream:
            stream.seek(0,os.SEEK_END);assert stream.tell()==self.end
            stream.write(header);stream.write(rawlabel);offset=stream.tell();stream.write(payload);stream.flush();os.fsync(stream.fileno())
            stream.seek(self.end);assert stream.read(len(header))==header and stream.read(len(rawlabel))==rawlabel and stream.read(len(payload))==payload
            self.end=stream.tell()
        self.index[label]=(offset,len(payload),digest.hex())
        assert self.path.stat().st_size==self.end and self.read(label)==rows
        return True

def checkpoint_identical(a,b,path='all7'):
    from dataclasses import fields,is_dataclass
    import numpy as np
    assert type(a) is type(b),(path,type(a),type(b))
    if isinstance(a,np.ndarray):assert a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes(),path
    elif is_dataclass(a):
        for f in fields(a):checkpoint_identical(getattr(a,f.name),getattr(b,f.name),path+'.'+f.name)
    elif isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for key in a:checkpoint_identical(a[key],b[key],path+'.'+str(key))
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b),path
        for k,(x,y) in enumerate(zip(a,b)):checkpoint_identical(x,y,path+'.'+str(k))
    elif isinstance(a,float):assert struct.pack('d',a)==struct.pack('d',b),path
    elif isinstance(a,np.generic):assert a.dtype==b.dtype and a.tobytes()==b.tobytes(),path
    else:assert a==b,path

from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-h';source=base/'p6-phase-jacobian-gpu-a'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt=root/'cuda-annual-launch.json';assert not receipt.exists()
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_native import source_hashes
comparison=json.loads((root/'backend-day-comparison.json').read_text());assert not comparison['failures'] and comparison['source_unchanged']
report_path=root/'cuda-day/batch.json';report=json.loads(report_path.read_text());assert report['steps_completed']==48
assert report['identity']['source_sha256']==source_hashes()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
binding=dict(prelaunch_report_sha256=sha(report_path),checkpoint_file=report['checkpoint_file'],checkpoint_sha256=sha(report_path.parent/report['checkpoint_file']),
    first_day_comparison_sha256=sha(root/'backend-day-comparison.json'),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),batch_sha256=sha(root/'batch.json'))
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'benchmarks'),CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--resume']
with (root/'cuda-annual-resume.log').open('w') as log:p=subprocess.Popen(command,cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,steps_requested=17520,start_from_completed=48,
    scope='Validated own explicit-suction first48 continued with unchanged source/config/state identity; first complete climate year still running, not spun up or observed acceptance.',command=command,bindings=binding)
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

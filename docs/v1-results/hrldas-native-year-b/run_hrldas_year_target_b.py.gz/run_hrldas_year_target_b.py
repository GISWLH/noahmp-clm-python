from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();base=root.parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in m.items())
gpu=json.loads((base/'suction-i336-prefix/gpu-SOURCE_SHA256.json').read_text())
assert all(v==gpu[k] for k,v in m.items() if k.startswith('src/'))
files=sorted(str(p) for p in Path('tests').glob('test_hrldas*.py'));begin=time.monotonic()
code=subprocess.run([sys.executable,'-m','pytest','-q',*files,'--junitxml=native-year-target.xml']).returncode
counts={k:sum(int(s.attrib[k]) for s in ET.parse('native-year-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
rejections=[];actual_ledgers=[]
from compare_hrldas_native_year import check_ledgers,check_final_checkpoint
import numpy as np
for site in ['CN-Cng','CN-Qia','CN-Cha','CN-HaM']:
    folder=base/'suction-i336-prefix'/(site+'-suction-climate-cycle');paths=list(folder.glob('report-0000336-*.json'));assert len(paths)==1
    report=json.loads(paths[0].read_text());trace=folder/Path(report['model_npz']).name
    assert report['status']=='running' and report['steps_completed']==336 and report['steps_requested']==17520 and sha(trace)==report['model_npz_sha256']
    with np.load(trace,allow_pickle=False) as z:
        ledger=check_ledgers(z,report);ending=check_final_checkpoint(folder/report['batch_checkpoint_file'],z,report)
    actual_ledgers.append(dict(site=site,scope='Actual original cold-start prefix only, not annual/spinup/scientific acceptance',report_sha256=sha(paths[0]),ledger=ledger,ending_checkpoint=ending))
if code==0:
    for site in ['CN-Qia','CN-Cha','CN-HaM']:
        folder=base/'suction-i336-prefix'/(site+'-suction-climate-cycle');candidates=list(folder.glob('report-0000336-*.json'));assert len(candidates)==1
        report=json.loads(candidates[0].read_text());assert report['status']=='running' and report['steps_completed']==336 and report['steps_requested']==17520
        trace=folder/Path(report['model_npz']).name;assert sha(trace)==report['model_npz_sha256']
        checkpoint=folder/report['batch_checkpoint_file'];assert sha(checkpoint)==report['batch_checkpoint_sha256']
        ref=base/'hrldas-three-climate-b';output=root/(site+'-annual-must-not-exist.json');assert not output.exists()
        command=[sys.executable,str(root/'benchmarks/compare_hrldas_native_year.py'),'--model',str(trace),'--model-manifest',str(candidates[0]),'--checkpoint',str(checkpoint),
            '--reference',str(ref/site/'audit.json'),'--prepared',str(ref/site/'prepared-manifest.json'),'--reference-protocol',str(ref/'protocol.json'),
            '--reference-archive',str(base/'hrldas-three-climate-b-evidence.tar.gz'),'--site',site,'--output',str(output)]
        proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        assert proc.returncode!=0 and 'Incomplete real native run cannot be evaluated as an annual result' in proc.stdout and not output.exists()
        rejections.append(dict(site=site,original_status=report['status'],original_steps_completed=336,original_steps_requested=17520,
            report_sha256=sha(candidates[0]),trace_sha256=sha(trace),checkpoint_sha256=sha(checkpoint),returncode=proc.returncode,output_created=False,last_message=proc.stdout.strip().splitlines()[-1]))
assert all(sha(root/k)==v for k,v in m.items())
(root/'native-year-target-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begin,counts=counts,
    source_files=len(m),source_unchanged=True,runtime_files_identical_current_i=sum(k.startswith('src/') for k in m),
    node=os.uname().nodename,pbs_job=os.environ.get('PBS_JOBID'),files=files,real_incomplete_prefix_rejections=rejections,actual_prefix_ledgers=actual_ledgers,
    scope='Synthetic calendar/integral/ledger tests and rejection of actual incomplete I336 trajectories; no real annual scientific result.'),indent=2)+'\n')
assert code==0 and counts['failures']==counts['errors']==counts['skipped']==0 and len(rejections)==3

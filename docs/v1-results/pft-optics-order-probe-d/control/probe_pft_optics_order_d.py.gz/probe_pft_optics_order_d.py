from pathlib import Path
import hashlib,json,os,sys,time,traceback
import cupy as cp
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-c';r=b/'pft-optics-order-probe-d';r.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src'),str(s/'tests')]
from noahmp_clm.gpu.cuda import canopy_optics as module
import test_gpu_canopy_optics as test
folder=s/'src/noahmp_clm/gpu/cuda';original=(folder/'radiation_kernel.cu').read_text();marker='                if(omega==1.f) {t[j]=1.f-r[j];sd[j]=1.f-bt[j]-su[j];}\n';assert original.count(marker)==1
candidate=original.replace(marker,'');marker='                if(track_absorption) {';assert candidate.count(marker)==1
candidate=candidate.replace(marker,'                if(omega==1.f) {nt=1.f-nr;nd=1.f-nb-nu;}\n'+marker)
(r/'radiation-original.cu').write_text(original);(r/'radiation-candidate.cu').write_text(candidate)
code='\n'.join(candidate if n=='radiation_kernel.cu' else (folder/n).read_text() for n in ['radiation_kernel.cu','snicar_kernel.cu','canopy_snow_kernel.cu'])
compiled=cp.RawModule(code=code,options=('--std=c++14','--fmad=false','--prec-div=false'),name_expressions=('run_canopy_snow_optics',));kernel=compiled.get_function('run_canopy_snow_optics');prior=module._kernel;module._kernel=lambda:kernel
os.environ['NOAHMP_PFT_DIAGNOSTICS']=str(r/'diagnostics');start=time.monotonic();failure=None
try:
    test.test_pft_optics_device_matches_ehpc_reference('32')
    test.test_pft_optics_device_matches_ehpc_reference('64')
    test.test_pft_optics_cuda_all624_raw_same_precision()
    test.test_pft_optics_invalid_geometry_and_passivity()
    test.test_nonabsorbing_leaf_stem_and_mixed_device_limits_all_raw_fields()
except Exception as e:
    failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
finally:module._kernel=prior
import jax
jax.effects_barrier();cp.cuda.runtime.deviceSynchronize();assert all(sha(s/n)==h for n,h in m.items())
record=dict(scope='Controlled CUDA-only correction of exactnonabsorbing/trackabsorption overwrite order to match originalJAX ordering. OriginalC production remainsimmutable; five originaltestfunctions invoked directly,not pytest/canonical credit. All47science andall624 raw1e-6/int/energy gates retained; raw originalC failures retained. Barriercomplete; atexit bypass after durable receipt only.',failure=failure,source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,original_sha256=sha(r/'radiation-original.cu'),candidate_sha256=sha(r/'radiation-candidate.cu'))
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);os._exit(0 if failure is None else 1)

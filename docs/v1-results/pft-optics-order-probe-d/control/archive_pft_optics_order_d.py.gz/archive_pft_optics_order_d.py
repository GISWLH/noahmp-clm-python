from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'pft-optics-order-probe-d';d=json.loads((r/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'];a=b/'pft-optics-order-probe-d-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n in ['pft-optics-order-probe-d','pft-optics-order-probe-launch-d']:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(b).as_posix(),recursive=False)
    for n in ['probe_pft_optics_order_d.py','launch_pft_optics_order_d.py','archive_pft_optics_order_d.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

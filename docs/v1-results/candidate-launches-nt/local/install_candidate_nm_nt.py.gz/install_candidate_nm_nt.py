"""Install seven exact, remotely tested candidate files after closed prerequisites.

This script performs archive/receipt/byte checks only. It never runs physics.
Default is a read-only check; --install additionally writes the seven files.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/v1'
NM = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
NM_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
ML = {
    'src/noahmp_clm/gpu/canopy_surface.py',
    'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu',
    'src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu',
    'src/noahmp_clm/gpu/snow_evolution.py',
}
NF = {
    'tests/test_gpu_surface_root_contraction.py',
    'tests/fixtures/cng_surface_root_contraction.npz',
    'tests/fixtures/cng_surface_root_contraction.json',
}
NK = {'benchmarks/assess_clm_spinup.py', 'tests/test_clm_spinup.py'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def archive(name, digest):
    path = OUT / name
    assert sha(path.read_bytes()) == digest, name
    with tarfile.open(path) as tf:
        assert all(m.isfile() for m in tf.getmembers())
        assert len(tf.getnames()) == len(set(tf.getnames()))
        return {m.name: tf.extractfile(m).read() for m in tf}


def read(files, name):
    return json.loads(files[name])


def source(name, digest, manifest_digest):
    files = archive(name, digest)
    assert sha(files['SOURCE_SHA256.json']) == manifest_digest
    manifest = read(files, 'SOURCE_SHA256.json')
    assert all(sha(files[n]) == h for n, h in manifest.items())
    return {n: files[n] for n in manifest}


def pbs_check(files, job):
    qstat = files['actual-qstat.txt'].decode()
    assert 'Job Id: ' + job in qstat
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
    assert int(files['pbs-exit.txt']) == 0
    receipt = read(files, 'receipt.json')
    assert receipt['pbs_job'] == job and receipt['passed'] is True
    assert receipt['source_unchanged'] and receipt['source_manifest_sha256'] == NM
    return receipt


def check_prerequisites():
    nr = pbs_check(archive('climatology-final-cpu-nr-evidence.tar.gz',
        '6c77ee006ab9a815569039f491a7b1bd69fd118c1886ab178f72cbe0bd58466a'), '1585.manager')
    assert nr['pytest_returncode'] == nr['collection_actual_parent_returncode'] == 0
    assert nr['counts'] == dict(tests=1168, failures=0, errors=0, skipped=0)
    assert nr['exact_executed_node_coverage'] and nr['original1156_retained'] and nr['added12_only_soc_boundary']
    assert nr['source_archive_sha256'] == NM_ARCHIVE
    np = pbs_check(archive('climatology-cold48-np-pair-evidence.tar.gz',
        'a1a7b9703af3fc10683e2f3da5413426023297198603cbba65ee7dc3cf28be43'), '1586.manager')
    assert np['physical_step_pairs'] == 576 and len(np['cases']) == 12
    assert all(row['passed'] and not row['failed_fields'] for row in np['cases'])
    assert np['cold_fields_exact'] == 23 and np['all16state_chains_and_final_checkpoint_exact']
    nf = archive('surface-root-permanent-nf-evidence.tar.gz',
        '012f9cb728eb612db54a532f7f5a0bdda5f704c5e986c15262686f69acaf8489')
    terminal = read(nf, 'exit.json')
    assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
    negative, positive = terminal['records']
    assert negative['actual_parent_returncode'] == 1 and negative['expected_original_physical_failure_observed']
    assert positive['actual_parent_returncode'] == 0 and positive['physical_test_passed']
    for row in [negative, positive]:
        name = row['variant'] + '/receipt.json'
        assert sha(nf[name]) == row['receipt_sha256']
        receipt = read(nf, name)
        assert receipt['worker_exitcode'] == receipt['pytest_returncode'] == row['actual_parent_returncode']
        assert receipt['source_unchanged'] and receipt['node_coverage_exact'] and receipt['errors'] == []
        assert {r['backend']: r['status'] for r in receipt['device_barriers']} == dict(jax='complete', cupy='complete')
    assert read(nf, 'positive/receipt.json')['all_setup_call_teardown_phases_passed']
    package = json.loads((OUT / 'surface-root-regression-mx-package.json').read_text())
    mx = archive(package['archive'], package['sha256'])
    assert set(mx) == set(package['artifact_details'])
    for name, detail in package['artifact_details'].items():
        assert sha(mx[name]) == detail['sha256'] and len(mx[name]) == detail['bytes']
    audit, terminal = read(mx, 'EXPORT_AUDIT.json'), read(mx, 'evidence/exit.json')
    assert audit['passed'] and not audit['issues'] and audit['original_nodes'] == 31
    assert terminal['passed'] and terminal['failure'] is None and terminal['source_unchanged']
    assert terminal['original_nodes_attempted'] == terminal['total_original_nodes'] == 31
    assert len(terminal['records']) == 8 and sum(r['counts']['tests'] for r in terminal['records']) == 31
    assert sha(mx['source/SOURCE_SHA256.json']) == '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
    for n, h in read(mx, 'source/SOURCE_SHA256.json').items():
        assert sha(mx['source/' + n]) == h
    for row in terminal['records']:
        name = 'evidence/' + Path(row['file']).stem + '-receipt.json'
        receipt = read(mx, name)
        assert sha(mx[name]) == row['receipt_sha256']
        assert row['actual_parent_returncode'] == receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0
        assert row['passed'] and receipt['passed'] and receipt['source_unchanged']
        assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed']
        assert receipt['counts'] == dict(tests=row['expected_tests'], failures=0, errors=0, skipped=0)
        assert {r['backend']: r['status'] for r in receipt['device_barriers']} == dict(jax='complete', cupy='complete')
    return package['sha256']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install', action='store_true')
    args = parser.parse_args()
    candidate = source('climatology-final-candidate-nm-source.tar.gz', NM_ARCHIVE, NM)
    jn = source('clm-ballberry-jn-source.tar.gz',
        '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5',
        'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5')
    assert len(candidate) == 584 and len(jn) == 581
    assert set(candidate) - set(jn) == NF and not set(jn) - set(candidate)
    assert {n for n in jn if jn[n] != candidate[n]} == ML | NK
    tracked = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
    expected_before = {n for n in jn if n.startswith(('src/', 'tests/', 'benchmarks/'))}
    assert len(expected_before) == 566
    assert {n for n in tracked if n.startswith(('src/', 'tests/', 'benchmarks/'))} == expected_before
    for name in expected_before:
        assert (ROOT / name).read_bytes() == (candidate[name] if name in NK else jn[name]), name
    assert all(not (ROOT / n).exists() for n in NF)
    changed_docs = [n for n in jn if n not in expected_before and (ROOT / n).read_bytes() != candidate[n]]
    assert set(changed_docs) <= {'README.md', 'ROADMAP.md'}, changed_docs
    mx_sha = check_prerequisites()
    result = dict(installed=False, exact_files=sorted(ML | NF), source_manifest_sha256=NM,
                  source_archive_sha256=NM_ARCHIVE, original_mx_archive_sha256=mx_sha,
                  closed_cpu_job='1585.manager', closed_pair_job='1586.manager',
                  runtime_test_benchmark_files=569, documentation_divergence=sorted(changed_docs),
                  scope='Seven exact tested files; existing NK2 retained. No model execution, new reference, '
                        'year/full-GPU/scientific acceptance credit. README/ROADMAP progress text differs '
                        'from frozen source; all569 runtime/test/benchmark files must match.')
    if args.install:
        receipt_path = OUT / 'candidate-nm-nt-install.json'
        assert not receipt_path.exists()
        for name in sorted(ML | NF):
            (ROOT / name).write_bytes(candidate[name])
        assert all((ROOT / n).read_bytes() == candidate[n] for n in expected_before | NF)
        result['installed'] = True
        with receipt_path.open('x', encoding='utf-8') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

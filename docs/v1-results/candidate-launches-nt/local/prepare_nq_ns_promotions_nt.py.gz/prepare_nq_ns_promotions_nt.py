"""Record root promotion only after exact committed source and closed evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/v1'
COMMIT = '9a67a855c6481c19862d17761f333c8623677ecc'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == COMMIT
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
remote = subprocess.check_output(['git', 'ls-remote', 'origin', 'refs/heads/codex/clm-v1-physics'], cwd=ROOT, text=True)
assert remote.split()[0] == COMMIT
archive = OUT/'climatology-final-candidate-nm-source.tar.gz'
assert sha(archive.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(archive) as tf:
    raw = tf.extractfile('SOURCE_SHA256.json').read()
    assert sha(raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    manifest = json.loads(raw)
    frozen = {name: tf.extractfile(name).read() for name in manifest}
assert len(frozen) == 584 and all(sha(frozen[n]) == h for n,h in manifest.items())
stream = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT,
    input=''.join(COMMIT+':'+name+'\n' for name in frozen).encode(), capture_output=True, check=True).stdout
position = 0
normalized, documents = [], []
for name, expected in frozen.items():
    end = stream.index(b'\n', position)
    header = stream[position:end].decode().split()
    assert len(header) == 3 and header[1] == 'blob', name
    position = end+1
    actual = stream[position:position+int(header[2])]
    position += int(header[2])+1
    if actual == expected:
        continue
    if name in {'README.md','ROADMAP.md'}:
        documents.append(dict(path=name, committed_sha256=sha(actual), frozen_sha256=sha(expected)))
    else:
        assert name.endswith(('.py','.cu','.sh','.md','.json','.toml','.yml','.yaml','.txt','.csv','.tsv')), name
        assert actual.replace(b'\r\n',b'\n') == expected.replace(b'\r\n',b'\n'), name
        if name.endswith('.json'):
            assert json.loads(actual) == json.loads(expected)
        normalized.append(name)
assert position == len(stream)
model = {n for n in frozen if n.startswith(('src/','tests/','benchmarks/'))}
tracked = subprocess.check_output(['git','ls-tree','-r','--name-only',COMMIT],cwd=ROOT,text=True).splitlines()
assert len(model) == 569 and model == {n for n in tracked if n.startswith(('src/','tests/','benchmarks/'))}
install = json.loads((OUT/'candidate-nm-nt-install.json').read_text())
assert install['installed'] and install['source_manifest_sha256'] == sha(raw)
mx = json.loads((OUT/'surface-root-regression-mx-package.json').read_text())
assert sha((OUT/mx['archive']).read_bytes()) == mx['sha256'] == install['original_mx_archive_sha256']
proof = dict(promotion_commit=COMMIT, remote_branch_confirmed=True, frozen_files_checked=584,
             model_test_benchmark_files=569, line_endings_only=normalized, documentation_divergence=documents,
             original_mx_archive_sha256=mx['sha256'], utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Root verified committed and pushed runtime/test/benchmark contents equal frozen NM. '
                   'Text CRLF/LF normalization only; README/ROADMAP progress differs. No main merge, release, '
                   'full GPU, annual, spinup, or observational success claim.')
for template, destination, permission in [
    ('candidate-full-gpu-nq-promotion.template.json','candidate-full-gpu-nq-promotion.json','allow_new_gpu_queue'),
    ('climatology-year-ns-preparation/promotion.template.json','climatology-year-ns-promotion.json','allow_np48_to_year')]:
    value = json.loads((OUT/template).read_text())
    value[permission] = True
    value['promotion_commit'] = COMMIT
    value['committed_source_proof'] = proof
    value['scope'] = ('Root authorizes this exact subsequent experiment after actual MX31/NF, NR1585 and NP1586 '
                      'success plus source commit/push. Frozen original candidate evidence remains unchanged; '
                      'experiment launch retains all live-byte, resource, source, state and scientific gates.')
    path = OUT/destination
    with path.open('x',encoding='utf-8') as handle:
        json.dump(value,handle,indent=2)
        handle.write('\n')
    print(json.dumps(dict(path=str(path),sha256=sha(path.read_bytes()),commit=COMMIT,permission=permission)))

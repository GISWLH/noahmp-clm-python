"""Static staged-blob proof against frozen NM; no Windows model execution."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT, text=True).splitlines()
tracked = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
rows = []
for name in staged:
    if name.startswith('docs/v1-results/') and name.endswith('/manifest.json'):
        path = ROOT / name
        # Read the manifest that will be committed, not a possibly newer worktree copy.
        manifest_raw = subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT)
        for item in json.loads(manifest_raw)['artifacts']:
            rows.append(((path.parent / item['path']).relative_to(ROOT).as_posix(), item))
path = ROOT / 'outputs/v1/climatology-final-candidate-nm-source.tar.gz'
assert sha(path.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(path) as tf:
    raw = tf.extractfile('SOURCE_SHA256.json').read()
    assert sha(raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    manifest = json.loads(raw)
    assert len(manifest) == 584
    frozen = {n: tf.extractfile(n).read() for n in manifest}
    assert all(sha(frozen[n]) == h for n, h in manifest.items())
model = {n: raw for n, raw in frozen.items() if n.startswith(('src/', 'tests/', 'benchmarks/'))}
assert len(model) == 569 and set(model) == {n for n in tracked if n.startswith(('src/', 'tests/', 'benchmarks/'))}
names = [n for n, _ in rows] + list(frozen)
out = subprocess.run(['git', 'cat-file', '--batch'], input=''.join(':' + n + '\n' for n in names).encode(),
                     capture_output=True, cwd=ROOT, check=True).stdout
position = 0
blobs = []
for name in names:
    end = out.index(b'\n', position)
    header = out[position:end].decode().split()
    assert len(header) == 3 and header[1] == 'blob', name
    size = int(header[2])
    position = end + 1
    blobs.append(out[position:position + size])
    position += size
    assert out[position:position + 1] == b'\n'
    position += 1
assert position == len(out)
for (name, item), raw in zip(rows, blobs):
    assert sha(raw) == item['stored_sha256'], name
    original = gzip.decompress(raw) if item['path'] == item['source'] + '.gz' else raw
    assert sha(original) == item['source_sha256'], name
line_endings, documentation = [], []
for (name, expected), raw in zip(frozen.items(), blobs[len(rows):]):
    if raw == expected:
        continue
    if name in {'README.md', 'ROADMAP.md'}:
        documentation.append(dict(path=name, staged_sha256=sha(raw), frozen_sha256=sha(expected)))
        continue
    assert name.endswith(('.py', '.cu', '.sh', '.md', '.json', '.toml', '.yml', '.yaml', '.txt', '.csv', '.tsv')), name
    assert raw.replace(b'\r\n', b'\n') == expected.replace(b'\r\n', b'\n'), name
    if name.endswith('.json'):
        assert json.loads(raw) == json.loads(expected), name
    line_endings.append(name)
print(json.dumps(dict(raw_artifacts_verified_from_git_index=len(rows),
    all_model_test_benchmark_files_verified=569, frozen_files_checked=584,
    git_text_line_ending_only_differences=line_endings, documentation_divergence=documentation,
    source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
    scope='Static proof of all569 staged model/test/benchmark files and13 other source-package files '
          'against frozenNM; README/ROADMAP progress differences explicit. Text CRLF/LF normalization '
          'only, binary and JSON values exact. No numerical execution or full-suite pass claim.')))

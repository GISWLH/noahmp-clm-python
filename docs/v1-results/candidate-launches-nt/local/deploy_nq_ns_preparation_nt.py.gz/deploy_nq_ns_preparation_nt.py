"""Stage reviewed control bytes only; never import launchers or run a model."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import tarfile

BASE = Path('/home/lhwang/work/noahmp-v1')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
packages = {
    'candidate-full-gpu-nq-controls.tar.gz': '9301c3f1601db42e3a86ec1203ff7ee5f7a80626ca7c7a4c377204c8879a5f29',
    'climatology-year-ns-preparation-evidence.tar.gz': '45e4cf585a1102a056fd7b7ee91019de441082c496495ef46cc2387c6bb1c758',
}
contents = {}
for name, digest in packages.items():
    assert sha((BASE / name).read_bytes()) == digest
    with tarfile.open(BASE / name) as tf:
        assert all(m.isfile() and not PurePosixPath(m.name).is_absolute()
                   and '..' not in PurePosixPath(m.name).parts for m in tf.getmembers())
        assert len(tf.getnames()) == len(set(tf.getnames()))
        contents[name] = {m.name: tf.extractfile(m).read() for m in tf}
nq = contents['candidate-full-gpu-nq-controls.tar.gz']
ns = contents['climatology-year-ns-preparation-evidence.tar.gz']
assert len(nq) == 8 and len(ns) == 17
names = ['candidate_gpu_contract_nq.py', 'candidate_gpu_queue_nq.py', 'candidate-full-gpu-nq-spec.json']
targets = {BASE / name: nq[name] for name in names}
folder = BASE / 'climatology-year-ns-preparation'
assert not folder.exists()
for name, raw in ns.items():
    if name.startswith('prepared/'):
        leaf = PurePosixPath(name).relative_to('prepared')
        assert len(leaf.parts) == 1
        targets[folder / str(leaf)] = raw
assert len(targets) == 16 and all(not path.exists() for path in targets)
assert all(not (BASE / name).exists() for name in ['candidate-full-gpu-nq', 'climatology-year-ns'])
assert not Path('/tmp/noahmp-candidate-full-gpu-nq').exists()
assert not Path('/tmp/noahmp-climatology-year-ns').exists()
assert not json.loads(targets[folder / 'promotion.template.json'])['allow_np48_to_year']
assert not json.loads(nq['candidate-full-gpu-nq-promotion.template.json'])['allow_new_gpu_queue']
controls = json.loads(targets[folder / 'CONTROLS_SHA256.json'])
assert all(sha(targets[folder / n]) == h for n, h in controls.items())
receipt = BASE / 'nq-ns-preparation-deployed-nt.json'
assert not receipt.exists()
folder.mkdir()
for path, raw in targets.items():
    with path.open('xb') as stream:
        stream.write(raw)
    assert path.read_bytes() == raw
value = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), archives=packages,
             deployed={str(p): sha(raw) for p, raw in targets.items()}, controls_only=True,
             promotion_supplied=False, launched=False, source_changed=False,
             scope='Reviewed controls staged only. No launcher import, collection, model, cache '
                   'or runtime directory creation. No promotion record exists; MX31 and actual '
                   'Git integration still required. NQ deep reuse audit runs after private '
                   'directory preparation but before any GPU worker.')
with receipt.open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps(value))

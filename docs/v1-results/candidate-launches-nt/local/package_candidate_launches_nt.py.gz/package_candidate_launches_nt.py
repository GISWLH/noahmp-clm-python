"""Static Windows packaging and verification of the independent NT launch snapshot."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
COMMIT = '9a67a855c6481c19862d17761f333c8623677ecc'
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
meta = json.loads((OUT / 'candidate-launches-nt-remote-export.json').read_text())
remote = OUT / 'candidate-launches-nt-remote-export.tar.gz'
assert sha(remote.read_bytes()) == meta['sha256']
contents = {}
with tarfile.open(remote) as tf:
    assert len(tf.getmembers()) == len(meta['artifacts'])
    for member in tf.getmembers():
        assert member.isfile() and member.name in meta['artifacts']
        raw = tf.extractfile(member).read()
        assert dict(sha256=sha(raw), bytes=len(raw)) == meta['artifacts'][member.name]
        contents['remote/' + member.name] = raw
read = lambda name: json.loads(contents['remote/' + name])
summary = read('SNAPSHOT_AUDIT.json')
assert summary == meta['summary'] and summary['promotion_commit'] == COMMIT
proofs = read('source-proofs.json')
assert set(proofs) == {'NQ', 'NS', 'NZ'}
for label, proof in proofs.items():
    manifest_raw = contents['remote/' + label + '/SOURCE_SHA256.json']
    assert sha(manifest_raw) == TARGET and len(json.loads(manifest_raw)) == 584
    assert proof['actual_file_sha256'] == json.loads(manifest_raw)
    assert proof['source_bytes_verified'] and proof['actual_files_checked'] == 584
processes = read('snapshot/processes.json')['processes']
assert len(processes) == 6
for process in processes:
    assert process['alive'] and process['state'] != 'Z' and process['start_ticks'] > 0
    assert process['selected_environment']['CUDA_VISIBLE_DEVICES'] == GPU
    assert process['cwd'] in {v['source'] for v in proofs.values()}
    assert any(text in process['cmdline'] for text in [
        'candidate-full-gpu-nq/candidate_gpu_queue_nq.py',
        'climatology-year-ns/control_year_ns.py', 'climatology-year-ns/run_year_ns.py',
        'hrldas-year-nz/control_year_nz.py', 'hrldas-year-nz/run_year_nz.py'])
assert summary['new_closed_passed_nodes'] == 41 and len(summary['new_closed_modules']) == 9
assert all(v['independently_verified'] and v['actual_parent_returncode'] == 0 for v in summary['new_closed_modules'])
assert summary['reused_nodes'] == 32 and sum(v['tests'] for v in summary['original_reuse']) == 32
for label in ['NS', 'NZ']:
    assert summary['years'][label]['steps_completed'] == summary['years'][label]['ledger_steps'] == 96
    assert summary['years'][label]['ledger_segments'] == 1 and not summary['years'][label]['terminal_present']

local_names = [
    'install_candidate_nm_nt.py', 'verify_nm_index_nt.py', 'prepare_nq_ns_promotions_nt.py',
    'deploy_nq_ns_preparation_nt.py', 'prepare_hrldas_year_nz.py',
    'candidate-nm-nt-install.json', 'nq-ns-preparation-deployed-nt.json',
    'candidate-full-gpu-nq-promotion.json', 'climatology-year-ns-promotion.json', 'hrldas-year-nz-promotion.json',
    'candidate-full-gpu-nq-launch.stdout.txt', 'candidate-full-gpu-nq-launch.stderr.txt',
    'climatology-year-ns-launch.stdout.txt', 'climatology-year-ns-launch.stderr.txt',
    'hrldas-year-nz-launch.stdout.txt', 'hrldas-year-nz-launch.stderr.txt',
    'climatology-year-ns-preparation-package.json', 'hrldas-year-nz-preparation-package.json',
    'candidate-launches-nt-export.stdout.txt', 'candidate-launches-nt-export.stderr.txt',
    'snapshot_candidate_launches_nt.py', 'package_candidate_launches_nt.py',
    'candidate-launches-nt-remote-export.json',
]
for name in local_names:
    contents['local/' + name] = (OUT / name).read_bytes()
for label, name, target in [
    ('NQ', 'candidate-full-gpu-nq-promotion.json', 'NQ/preflight/promotion.json'),
    ('NS', 'climatology-year-ns-promotion.json', 'NS/controls/promotion.json'),
    ('NZ', 'hrldas-year-nz-promotion.json', 'NZ/controls/promotion.json')]:
    assert contents['local/' + name] == contents['remote/' + target]

# Verify committed model/tests/benchmarks independently without modifying Git or importing physics.
archive = OUT / 'climatology-final-candidate-nm-source.tar.gz'
assert sha(archive.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(archive) as tf:
    manifest = json.loads(tf.extractfile('SOURCE_SHA256.json').read())
    frozen = {name: tf.extractfile(name).read() for name in manifest}
assert all(sha(frozen[n]) == h for n, h in manifest.items())
stream = subprocess.run(['git', 'cat-file', '--batch'], cwd=REPO,
    input=''.join(COMMIT + ':' + name + '\n' for name in frozen).encode(),
    capture_output=True, check=True).stdout
position, exact, normalized, documents = 0, [], [], []
for name, expected in frozen.items():
    end = stream.index(b'\n', position)
    header = stream[position:end].decode().split()
    assert len(header) == 3 and header[1] == 'blob'
    position = end + 1
    actual = stream[position:position + int(header[2])]
    position += int(header[2]) + 1
    if actual == expected:
        exact.append(name)
    elif name in {'README.md', 'ROADMAP.md'}:
        documents.append(dict(path=name, frozen_sha256=sha(expected), committed_sha256=sha(actual)))
    else:
        assert name.endswith(('.py', '.cu', '.sh', '.md', '.json', '.toml', '.yml', '.yaml', '.txt', '.csv', '.tsv'))
        assert actual.replace(b'\r\n', b'\n') == expected.replace(b'\r\n', b'\n'), name
        normalized.append(name)
assert position == len(stream)
model = {n for n in frozen if n.startswith(('src/', 'tests/', 'benchmarks/'))}
tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', COMMIT], cwd=REPO, text=True).splitlines()
assert len(model) == 569 and model == {n for n in tracked if n.startswith(('src/', 'tests/', 'benchmarks/'))}
contents['local/committed-source-byte-verification.json'] = dump(dict(commit=COMMIT,
    frozen_manifest_sha256=TARGET, frozen_files_checked=584, model_test_benchmark_files=569,
    exact_files=exact, line_endings_only=normalized, document_divergence=documents,
    scope='Offline committed Git objects compared to original frozen archive. No working-tree mutation or numerical execution.'))
contents['README.md'] = (
    '# Candidate launch evidence NT\n\n'
    'Snapshot 2026-10-25 07:38:35 UTC on xuanze physical CUDA1. '
    'NQ collection actual parent 0: 1576 = 1168 CPU + 408 GPU nodes. '
    'Nine newly executed full modules / 41 nodes have actual parent 0 and independently checked receipts. '
    'MX31 and NF1 keep their original source identities; no old JN140 credit.\n\n'
    'NS and NZ each saved generation 96/17520 with ledger_steps 96, ledger_segments 1, '
    'and 23 fields exact at continuation from independently verified original cold48. '
    'Both annual workers remain running; this is not annual success.\n\n'
    'All three 584-file source trees were hashed before and after export. Fixed plans, '
    'controls, declarations, promotions and closed receipts were checked unchanged; '
    'live progress/log snapshots are expressly excluded from that assertion. '
    'Cold evidence archives and checkpoint arrays have exact path/hash references without duplication.\n\n'
    'Complete original NS/NZ controls and NQ inheritance/collection/closed module evidence are under remote/. '
    'Local NT install, promotion, source-proof, deployment and launch records are under local/. '
    'No processes were launched/stopped, no tests changed, and no physical computation was performed by this audit. '
    'The original GPU resource gates, numerical/science gates, phase and device-barrier conditions remain in the controls. '
    'No full GPU408, year17520, observed science, SOC convergence or release acceptance is claimed.\n'
).encode()
final = OUT / 'candidate-launches-nt-evidence.tar.gz'
assert not final.exists()
with tarfile.open(final, 'w:gz') as tf:
    for name, raw in sorted(contents.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        tf.addfile(info, io.BytesIO(raw))
details = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in sorted(contents.items())}
with tarfile.open(final) as tf:
    assert len(tf.getmembers()) == len(details)
    for member in tf.getmembers():
        raw = tf.extractfile(member).read()
        assert dict(sha256=sha(raw), bytes=len(raw)) == details[member.name]
package = dict(archive=final.name, sha256=sha(final.read_bytes()), bytes=final.stat().st_size,
    artifacts=len(details), artifact_details=details, remote_export_sha256=meta['sha256'],
    summary=summary, local_static_verification_passed=True,
    scope=summary['scope'])
(OUT / 'candidate-launches-nt-package.json').write_bytes(dump(package))
(OUT / 'candidate-launches-nt-local-verification.json').write_bytes(dump(dict(
    passed=True, archive_sha256=package['sha256'], artifacts_checked=len(details),
    all_remote_artifacts_byte_exact=True, source_trees=3, source_files_each=584,
    actual_live_processes=6, commit=COMMIT, actual_collection_parent=0,
    new_passed_nodes=41, original_reused_nodes=32, years_saved_steps=dict(NS=96, NZ=96))))
print(json.dumps({k: package[k] for k in ['archive', 'sha256', 'bytes', 'artifacts']}))

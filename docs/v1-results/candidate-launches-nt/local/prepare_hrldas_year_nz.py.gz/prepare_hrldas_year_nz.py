"""Stdlib-only static preservation checks and one-time NZ preparation packaging."""
import ast
import hashlib
import io
import json
import sys
import tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'hrldas-year-nz-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda node: ast.dump(node, include_attributes=False)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def main():
    assert (ROOT / 'closed-prefix.json').exists() and not (ROOT / 'promotion.json').exists()
    assert json.loads((ROOT/'closed-prefix.template.json').read_text())['ready'] is False
    assert json.loads((ROOT/'promotion.template.json').read_text())['allow_ny48_to_year'] is False
    old_path = BASE/'climatology-year-ns-preparation/run_year_ns.py'
    nm_path = BASE/'climatology-preparation-nm/run_year_nm.py'
    old = ast.parse(old_path.read_text())
    new = ast.parse((ROOT/'run_year_nz.py').read_text())
    nm = ast.parse(nm_path.read_text())
    functions = ['forbidden', 'check_start', 'retain_bgc', 'first_step']
    preserved = {}
    for name in functions:
        values = [next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
                  for tree in [old, new, nm]]
        assert len({dump(n) for n in values}) == 1, name
        preserved[name] = sha(dump(values[0]).encode())
    calls = lambda tree: [dump(n) for n in ast.walk(tree) if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
        and n.func.value.id == 'native' and n.func.attr == 'run']
    assert calls(old) == calls(new) == calls(nm) and len(calls(new)) == 1
    old_asserts = [n for n in ast.walk(old) if isinstance(n, ast.Assert)]
    new_asserts = [n for n in ast.walk(new) if isinstance(n, ast.Assert)]
    assert len(old_asserts) == len(new_asserts) == 10
    changed = [i for i,(a,b) in enumerate(zip(old_asserts,new_asserts)) if dump(a) != dump(b)]
    assert changed == [2,4]
    class ReferenceAdaptation(ast.NodeTransformer):
        def visit_Constant(self, node):
            if node.value == 576: return ast.copy_location(ast.Constant(144), node)
            if node.value == 12: return ast.copy_location(ast.Constant(3), node)
            if isinstance(node.value,str) and node.value.startswith('all48_actual_deposition_inputs_'):
                return ast.copy_location(ast.Constant('all48_actual_deposition_inputs_byteexact_to_original_configuration'),node)
            return node
    assert [dump(ReferenceAdaptation().visit(n)) for n in old_asserts] == [dump(n) for n in new_asserts]
    copies = {
        'climatology_contract_nm.py':BASE/'climatology-year-ns-preparation/climatology_contract_nm.py',
        'EXPECTED_SOURCE_SHA256.json':BASE/'climatology-year-ns-preparation/EXPECTED_SOURCE_SHA256.json',
        'soc-strict-boundary-nk-evidence.tar.gz':BASE/'climatology-year-ns-preparation/soc-strict-boundary-nk-evidence.tar.gz',
        'climatology-final-cpu-nr-evidence.tar.gz':BASE/'climatology-final-cpu-nr-evidence.tar.gz',
    }
    ny = BASE/'hrldas-candidate-cold48-ny-preparation'
    for name in ['hrldas_contract_ny.py','climatology_contract_np.py','reference-reuse.json',
                 'reference-dependency-graph.json','source-dependencies.json']:
        copies[name] = ny/name
    copies['EXPECTED_GPU_CONTROLS_SHA256.json'] = ny/'CONTROLS_SHA256.json'
    for name, source in copies.items(): assert (ROOT/name).read_bytes() == source.read_bytes(), name
    for path in ROOT.glob('*.py'): ast.parse(path.read_text())
    sys.path.insert(0,str(ROOT))
    import hrldas_contract_nz as contract
    nr = contract.verify_nr(ROOT)  # JSON, SHA and original qstat only; no numerical imports.
    closure = contract.closed_prefix()
    pair = contract.verify_pair(ROOT, {'ny_pair_archive_sha256':closure['pair_archive_sha256']})
    assert json.loads(pair['receipt.json'])['pbs_job'] == '1590.manager'
    assert 'numpy' not in sys.modules and 'cupy' not in sys.modules
    assert contract.INPUT == '044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e'
    assert contract.REFERENCE == 'bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416'
    static = dict(prepared_only=True, model_calls=0, gpu_launches=0, pbs_submissions=0,
        four_observer_functions_ast_exact_to_ns_nm=preserved,
        unique_native_run_ast_exact_to_ns_nm=True, original_assert_count=10,
        adapted_assert_indices=changed, all_asserts_exact_after_only_reference_cardinality_and_kg_key_adaptation=True,
        byte_preserved_controls={name:dict(source=str(source),sha256=sha((ROOT/name).read_bytes())) for name,source in copies.items()},
        nr1585_actual_f0_metadata_verified=nr, ny_closure_bound=True,
        ny1590_actual_f0_metadata_verified=closure, root_promotion_bound=False,
        runtime_live48_or_gpu_prerequisites_checked=False,
        original_worker_sha256=sha(old_path.read_bytes()), nm_worker_sha256=sha(nm_path.read_bytes()),
        scope='Static NZ three-station same-NY48 annual continuation preparation only. Actual NY1590F0 closure bound; formal promotion not supplied and live48 not checked here. Original source, model inputs and gates unchanged.')
    write(ROOT/'static-check.json',static)
    controls = {p.name:sha(p.read_bytes()) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    write(ROOT/'CONTROLS_SHA256.json',controls)
    payload = {p.name:p.read_bytes() for p in sorted(ROOT.iterdir()) if p.is_file()}
    inventory = {name:dict(sha256=sha(raw),bytes=len(raw)) for name,raw in payload.items()}
    payload['artifact-inventory.json'] = (json.dumps(inventory,indent=2)+'\n').encode()
    target = BASE/'hrldas-year-nz-preparation-evidence.tar.gz'
    assert not target.exists(), 'Never overwrite a sealed preparation'
    with tarfile.open(target,'w:gz') as tf:
        for name,raw in sorted(payload.items()):
            info = tarfile.TarInfo(name); info.size = len(raw)
            tf.addfile(info,io.BytesIO(raw))
    with tarfile.open(target) as tf:
        assert {m.name:tf.extractfile(m).read() for m in tf} == payload
    package = dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,
        artifacts=len(payload),controls_manifest_sha256=sha((ROOT/'CONTROLS_SHA256.json').read_bytes()),
        prepared_only=True,source_manifest_sha256=contract.TARGET,ny_closure_bound=True,
        root_promotion_bound=False,gpu_launches=0,pbs_submissions=0,scope=static['scope'])
    write(BASE/'hrldas-year-nz-preparation-package.json',package)
    print(json.dumps(package))


if __name__ == '__main__':
    main()

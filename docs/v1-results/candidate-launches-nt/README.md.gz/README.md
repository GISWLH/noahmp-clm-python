# Candidate launch evidence NT

Snapshot 2026-10-25 07:38:35 UTC on xuanze physical CUDA1. NQ collection actual parent 0: 1576 = 1168 CPU + 408 GPU nodes. Nine newly executed full modules / 41 nodes have actual parent 0 and independently checked receipts. MX31 and NF1 keep their original source identities; no old JN140 credit.

NS and NZ each saved generation 96/17520 with ledger_steps 96, ledger_segments 1, and 23 fields exact at continuation from independently verified original cold48. Both annual workers remain running; this is not annual success.

All three 584-file source trees were hashed before and after export. Fixed plans, controls, declarations, promotions and closed receipts were checked unchanged; live progress/log snapshots are expressly excluded from that assertion. Cold evidence archives and checkpoint arrays have exact path/hash references without duplication.

Complete original NS/NZ controls and NQ inheritance/collection/closed module evidence are under remote/. Local NT install, promotion, source-proof, deployment and launch records are under local/. No processes were launched/stopped, no tests changed, and no physical computation was performed by this audit. The original GPU resource gates, numerical/science gates, phase and device-barrier conditions remain in the controls. No full GPU408, year17520, observed science, SOC convergence or release acceptance is claimed.

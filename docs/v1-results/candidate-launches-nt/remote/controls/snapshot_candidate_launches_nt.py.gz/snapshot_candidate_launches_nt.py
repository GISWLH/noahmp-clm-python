"""Read-only xuanze launch audit; writes only a fresh independent /tmp export."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import tarfile

BASE = Path('/home/lhwang/work/noahmp-v1')
DEST = Path('/tmp/noahmp-candidate-launches-nt-export')
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
COMMIT = '9a67a855c6481c19862d17761f333c8623677ecc'
NQ = BASE / 'candidate-full-gpu-nq'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
immutable, references, artifacts = {}, [], {}


def save(name, raw):
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, name
    else:
        path.write_bytes(raw)
    artifacts[name] = dict(sha256=sha(raw), bytes=len(raw))


def write(name, value):
    save(name, (json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def fixed(path, name=None, expected=None):
    path = Path(path)
    raw = path.read_bytes()
    digest = sha(raw)
    if expected is not None:
        assert digest == expected, str(path)
    if str(path) in immutable:
        assert immutable[str(path)] == digest
    immutable[str(path)] = digest
    if name is None:
        references.append(dict(original_path=str(path), sha256=digest, bytes=len(raw)))
    else:
        save(name, raw)
    return raw


def snapshot(path, name):
    raw = Path(path).read_bytes()
    save(name, raw)
    return raw


def source_proof(label, source):
    raw = fixed(source / 'SOURCE_SHA256.json', label + '/SOURCE_SHA256.json', TARGET)
    manifest = json.loads(raw)
    assert len(manifest) == 584
    for name, digest in manifest.items():
        fixed(source / name, expected=digest)
    return dict(source=str(source), source_manifest_sha256=TARGET, actual_files_checked=584,
                actual_file_sha256=manifest, source_bytes_verified=True)


def process(pid):
    path = Path('/proc') / str(pid)
    try:
        stat = (path / 'stat').read_text()
        fields = stat.rsplit(')', 1)[1].split()
        cmd = (path / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace').strip()
        try:
            cwd = str((path / 'cwd').resolve())
        except PermissionError:
            cwd = '<unreadable:PermissionError>'
        # Environment is explicitly whitelisted; never export credentials.
        permitted = {'CUDA_VISIBLE_DEVICES', 'NS_ROOT', 'NS_SOURCE', 'NZ_ROOT', 'NZ_SOURCE',
                     'JAX_COMPILATION_CACHE_DIR', 'CUPY_CACHE_DIR', 'CUDA_CACHE_PATH'}
        env = {}
        for item in (path / 'environ').read_bytes().split(b'\0'):
            key, sep, value = item.partition(b'=')
            if sep and key.decode(errors='replace') in permitted:
                env[key.decode()] = value.decode(errors='replace')
        return dict(pid=pid, alive=True, state=fields[0], ppid=int(fields[1]),
                    start_ticks=int(fields[19]), cmdline=cmd, cwd=cwd, selected_environment=env)
    except (FileNotFoundError, ProcessLookupError):
        return dict(pid=pid, alive=False)


assert os.name == 'posix' and not DEST.exists()
DEST.mkdir()
started = utc()
save('controls/snapshot_candidate_launches_nt.py', Path(__file__).read_bytes())
sys.path.insert(0, str(NQ))
from candidate_gpu_contract_nq import closed_reuse, receipt_check, validate_spec

plan = json.loads(fixed(NQ / 'plan.json', 'NQ/plan.json'))
source = Path(plan['source'])
source_proofs = {'NQ': source_proof('NQ', source)}
for name, digest in plan['controls_sha256'].items():
    fixed(NQ / name, 'NQ/controls/' + name, digest)
spec = json.loads(fixed(NQ / 'candidate-full-gpu-nq-spec.json', 'NQ/candidate-full-gpu-nq-spec.json', plan['spec_sha256']))
validate_spec(spec)
proofs, reused = closed_reuse(source, spec)
assert reused == plan['reused']
assert proofs == load(NQ / 'inheritance-proof.json')
for folder in ['preflight', 'reused']:
    for path in sorted((NQ / folder).rglob('*')):
        if path.is_file():
            fixed(path, 'NQ/' + path.relative_to(NQ).as_posix())
for name in ['launch.json', 'inheritance-proof.json', 'collection.json', 'collection.log', 'collection-actual-exit.json']:
    fixed(NQ / name, 'NQ/' + name)
collection = load(DEST / 'NQ/collection.json')
assert collection['passed'] and collection['returncode'] == 0 and collection['source_unchanged']
assert (collection['total_count'], collection['cpu_count'], collection['gpu_count']) == (1576, 1168, 408)
assert collection['exact_gpu_and_non_nk_node_sets'] and collection['source_manifest_sha256'] == TARGET
assert load(DEST / 'NQ/collection-actual-exit.json')['actual_parent_returncode'] == 0
assert load(DEST / 'NQ/preflight/promotion.json')['promotion_commit'] == COMMIT
progress = json.loads(snapshot(NQ / 'progress.json', 'NQ/snapshot/progress.json'))
snapshot(NQ / 'controller.log', 'NQ/snapshot/controller.log')
closed = []
for name in spec['new_files_in_order']:
    stem = Path(name).stem
    terminal = NQ / (stem + '-exit.json')
    if not terminal.exists():
        continue
    row = json.loads(fixed(terminal, 'NQ/closed/' + terminal.name))
    assert row['file'] == name
    valid = False
    failure = None
    try:
        receipt_check(NQ, stem, row, spec['gpu_nodes_by_file'][name], source, TARGET)
        valid = True
    except Exception as error:
        failure = type(error).__name__ + ': ' + str(error)
    for suffix in ['-receipt.json', '-expected.json', '.xml', '.log']:
        p = NQ / (stem + suffix)
        if p.exists():
            fixed(p, 'NQ/closed/' + p.name)
    for p in sorted((NQ / (stem + '-diagnostics')).rglob('*')):
        if p.is_file():
            fixed(p, 'NQ/closed/' + p.relative_to(NQ).as_posix())
    for p in NQ.glob(str(row['pid']) + '*cache-events.jsonl'):
        fixed(p, 'NQ/closed/' + p.name)
    closed.append(dict(**row, independently_verified=valid, independent_error=failure,
                       executed_source_manifest_sha256=TARGET))

launches = {'NQ': load(DEST / 'NQ/launch.json')}
pids = [launches['NQ']['pid'], progress['pid']]
years = {}
for label, rootname, coldname, prefix in [
    ('NS', 'climatology-year-ns', 'climatology-cold48-np', 'np'),
    ('NZ', 'hrldas-year-nz', 'hrldas-candidate-cold48-ny', 'ny')]:
    root, old = BASE / rootname, BASE / coldname
    folder = old / 'cold48'
    plan = json.loads(fixed(root / 'plan.json', label + '/plan.json'))
    assert plan['source_manifest_sha256'] == TARGET
    source_proofs[label] = source_proof(label, Path(plan['source']))
    for name, digest in plan['controls_sha256'].items():
        fixed(root / name, None if name.endswith('.tar.gz') else label + '/controls/' + name, digest)
    for path, digest in plan['prerequisite_evidence_sha256'].items():
        original = Path(path)
        bound = folder / 'validated-prefix-report.json' if original == folder / 'trajectory/batch.json' else original
        fixed(bound, expected=digest)
    fixed(old / 'plan.json', label + '/original-prefix-plan.json', plan['original_' + prefix + '_plan_sha256'])
    names = ['prefix-verification.json', 'prefix-verification-pbs-exit.txt',
             'prefix-verification-actual-qstat.txt', 'year-prefix-binding.json',
             'validated-prefix-report.json', 'year-start-audit.json', 'year-launch.json', 'year-worker.json']
    for name in names:
        fixed(folder / name, label + '/' + name)
    binding = load(DEST / label / 'year-prefix-binding.json')
    audit = load(DEST / label / 'year-start-audit.json')
    assert audit['saved_fields_exact'] == 23 and audit['source_manifest_sha256'] == TARGET
    assert audit['verified_prefix_checkpoint_sha256'] == audit['current_checkpoint_sha256'] == binding['prefix_checkpoint_sha256']
    fixed(folder / 'validated-prefix-state.npz', expected=binding['prefix_checkpoint_sha256'])
    assert audit['cpu_verification_sha256'] == sha((DEST / label / 'prefix-verification.json').read_bytes())
    assert binding['prefix_batch_report_sha256'] == sha((DEST / label / 'validated-prefix-report.json').read_bytes())
    assert binding['prefix_ledger_steps'] == 48 and binding['prefix_ledger_segments'] == 1
    assert load(root / 'promotion.json')['promotion_commit'] == COMMIT
    launches[label] = load(DEST / label / 'year-launch.json')
    pids.extend([launches[label]['pid'], load(DEST / label / 'year-worker.json')['pid']])
    for name in ['year-model.log', 'year-controller.log']:
        snapshot(folder / name, label + '/snapshot/' + name)
    report = json.loads(snapshot(folder / 'trajectory/batch.json', label + '/snapshot/batch.json'))
    checkpoint = folder / 'trajectory' / report['checkpoint_file']
    checkpoint_raw = checkpoint.read_bytes()
    assert sha(checkpoint_raw) == report['checkpoint_sha256']
    years[label] = dict(snapshot_utc=utc(), status=report['status'], steps_completed=report['steps_completed'],
        steps_requested=report['steps_requested'], ledger_steps=report['ledger_steps'],
        ledger_segments=report['ledger_segments'], checkpoint_file=str(checkpoint),
        checkpoint_sha256=sha(checkpoint_raw), checkpoint_bytes=len(checkpoint_raw),
        saved_generation_at_least_96=report['steps_completed'] >= 96,
        start_fields_exact=23, terminal_present=(folder / 'year-exit.json').exists(),
        scope='Live saved-generation snapshot only; no annual completion or science acceptance claimed.')

identities = [process(pid) for pid in sorted(set(pids))]
for value in identities:
    if value['alive']:
        assert value['selected_environment']['CUDA_VISIBLE_DEVICES'] == GPU
write('snapshot/processes.json', dict(utc=utc(), processes=identities))
ps = subprocess.run(['ps', '-p', ','.join(map(str, pids)), '-o', 'pid,ppid,lstart,etimes,time,pcpu,pmem,rss,stat,args'], capture_output=True)
save('snapshot/ps.txt', ps.stdout)
gpu = subprocess.run(['nvidia-smi', '--id=1', '--query-gpu=index,uuid,memory.used,memory.free,utilization.gpu', '--format=csv'], capture_output=True, check=True)
assert GPU.encode() in gpu.stdout
save('snapshot/gpu.txt', gpu.stdout)
apps = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,used_gpu_memory,process_name', '--format=csv'], capture_output=True, check=True)
save('snapshot/gpu-processes.txt', apps.stdout)
write('source-proofs.json', source_proofs)
write('original-artifact-references.json', references)
assert all(sha(Path(path).read_bytes()) == digest for path, digest in immutable.items())
summary = dict(snapshot_started_utc=started, snapshot_finished_utc=utc(), promotion_commit=COMMIT,
    physical_gpu_uuid=GPU, physical_gpu_index=1, launch_records=launches,
    actual_collection=dict(total=1576, cpu=1168, gpu=408, actual_parent_returncode=0),
    new_closed_modules=closed, new_closed_passed_nodes=sum(v['expected_tests'] for v in closed if v['independently_verified']),
    reused_nodes=32, original_reuse=reused, original_inheritance=proofs,
    current_nq_file=progress['file'], current_nq_pid=progress['pid'], years=years,
    immutable_files_before_after_verified=len(immutable), all_three_sources_files_checked=584,
    live_files_excluded_from_immutable_claim=True,
    scope='Launch and partial-progress evidence only; all original gates preserved. No full GPU408, year17520, observed science, SOC convergence or release acceptance claim.')
write('SNAPSHOT_AUDIT.json', summary)
archive = DEST.with_suffix('.tar.gz')
with tarfile.open(archive, 'w:gz') as tf:
    for name in sorted(artifacts):
        tf.add(DEST / name, arcname=name, recursive=False)
meta = dict(archive=str(archive), sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
            artifacts=artifacts, summary=summary)
DEST.with_suffix('.json').write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(dict(archive=str(archive), sha256=meta['sha256'], bytes=meta['bytes'],
                     artifacts=len(artifacts), new_passed=summary['new_closed_passed_nodes'], years=years)))

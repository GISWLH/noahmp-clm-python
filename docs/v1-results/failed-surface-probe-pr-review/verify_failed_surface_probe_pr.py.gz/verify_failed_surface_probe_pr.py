"""Verify PR raw capture and closure using stdlib/NPY headers/opaque payloads."""
from pathlib import Path
import ast
import hashlib
import io
import json
import math
import re
import struct
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent


def sha(body):
    return hashlib.sha256(body).hexdigest()


def unpack(body):
    with tarfile.open(fileobj=io.BytesIO(body)) as stream:
        members = stream.getmembers()
        assert all(m.isfile() for m in members) and len({m.name for m in members}) == len(members)
        return {m.name:stream.extractfile(m).read() for m in members}


def header(body):
    assert body[:6] == b'\x93NUMPY'
    version = tuple(body[6:8])
    assert version in ((1, 0), (2, 0), (3, 0))
    width = 2 if version == (1, 0) else 4
    size = struct.unpack('<H' if width == 2 else '<I', body[8:8+width])[0]
    metadata = ast.literal_eval(body[8+width:8+width+size].decode('utf-8' if version == (3, 0) else 'latin1').strip())
    assert metadata['fortran_order'] is False and re.fullmatch(r'[<>=|][biuf][1248]', metadata['descr'])
    payload = body[8+width+size:]
    assert len(payload) == math.prod(metadata['shape']) * int(metadata['descr'][2:])
    return dict(dtype=metadata['descr'], shape=list(metadata['shape']), c_order_sha256=sha(payload))


def array_leaves(tree):
    if tree['kind'] == 'array':
        return {tree['key']: {k: tree[k] for k in ('dtype', 'shape', 'c_order_sha256')}}
    if tree['kind'] in ('dict', 'dataclass'):
        children = tree['items' if tree['kind'] == 'dict' else 'fields'].values()
    elif tree['kind'] in ('tuple', 'list'):
        children = tree['items']
    else:
        return {}
    result = {}
    for child in children:
        entries = array_leaves(child)
        assert not set(entries) & set(result)
        result.update(entries)
    return result


def main():
    label = 'failed-surface-probe-pr'
    package = json.loads((BASE / (label + '-package.json')).read_bytes())
    body = (BASE / package['archive']).read_bytes()
    assert sha(body) == package['sha256'] == '9e52badfc6d8fd1f8fd39b118adff3d1777daafc7af6b7d2d8541b863e445db8'
    assert len(body) == package['bytes'] == 166415
    raw = unpack(body)
    assert len(raw) == package['artifacts'] == 72
    index = json.loads(raw['artifact-inventory.json'])
    assert set(raw) == set(index) | {'artifact-inventory.json'}
    assert all(sha(raw[n]) == item['sha256'] and len(raw[n]) == item['bytes'] for n, item in index.items())
    get = lambda n: json.loads(raw[n])
    remote = get('remote-package.json')
    remote_body = (BASE / (label + '-remote.tar.gz')).read_bytes()
    assert sha(remote_body) == remote['sha256'] and len(remote_body) == remote['bytes']
    original_run = unpack(remote_body)
    assert all(raw['run/' + n] == b for n, b in original_run.items())
    original_index = get('run/artifact-inventory.json')
    assert set(original_run) == set(original_index) | {'artifact-inventory.json'}
    assert all(sha(original_run[n]) == item['sha256'] and len(original_run[n]) == item['bytes'] for n, item in original_index.items())
    assert get('deployment/launch.json')['actual_returncode'] == 0
    launch = get('run/launch.json')
    assert get('deployment/launch.stdout') == launch
    controls = get('run/CONTROLS_SHA256.json')
    assert len(controls) == 7 and sha(raw['run/CONTROLS_SHA256.json']) == launch['controls_manifest_sha256'] == '6715681bbe8488cf13c1eb5ec8ec771e5d0a012edb2de0eadf6cb56ae9ca581e'
    assert all(sha(raw['run/' + n]) == h for n, h in controls.items())
    terminal, receipt, closure = get('run/exit.json'), get('run/result/receipt.json'), get('run/closure.json')
    assert terminal['actual_parent_returncode'] == 1 and not terminal['timed_out']
    assert terminal['diagnostic_capture_complete'] and terminal['model_call_passed'] is False
    assert sha(raw['run/result/receipt.json']) == terminal['receipt_sha256']
    assert closure['all_processes_stopped_or_zombie'] and all(not p['exists'] for p in closure['process'].values())
    assert closure['process']['controller']['OS_exit_code'] is None
    assert closure['immutable_files_checked'] == 1252 and not closure['immutable_mismatches']
    assert receipt['before_immutable'] == receipt['after_immutable'] == {'checked_files':1252,'mismatches':[],'unchanged':True}
    assert receipt['actual_batch_step_calls'] == 1 and receipt['actual_column_attempts'] == 3
    assert receipt['actual_batch_step_returns'] == receipt['completed_physical_steps'] == receipt['trajectory_steps_committed'] == 0
    assert receipt['original_failure_reproduced'] and receipt['device_barrier_error'] is None
    assert receipt['original_failure'] == {'type':'RuntimeError','message':'CUDA layered phase surface failed; inspect with raise_on_failure=False'}
    assert len(receipt['calls']) == 1
    call = receipt['calls'][0]
    assert call == get('run/result/surface/call-0001/call.json')
    assert call['call'] == call['caller']['most_iteration'] == call['kernel_launches'] == 1
    assert call['caller']['line'] == 37 and call['caller']['function'] == 'run_most_surface'
    assert call['nonfinite_indices'] == [] and call['final_converged'] == call['canopy_converged'] == [False, True, True]
    assert call['original_exception'] == receipt['original_failure'] and not call['returned']
    assert raw['run/worker.log'].decode().rstrip().endswith('RuntimeError: ' + receipt['original_failure']['message'])

    captures, arrays = {}, {}
    for n, packet in raw.items():
        if not n.endswith('.npz'):
            continue
        metadata = get(n[:-4] + '.json')
        assert metadata['schema'] == 'PR-typed-tree-v1' and sha(packet) == metadata['npz_sha256']
        declared = array_leaves(metadata['tree'])
        assert len(declared) == metadata['array_count']
        with zipfile.ZipFile(io.BytesIO(packet)) as stream:
            assert set(stream.namelist()) == {k + '.npy' for k in declared}
            assert len(stream.namelist()) == len(declared)
            actual = {k:header(stream.read(k + '.npy')) for k in declared}
        assert actual == declared
        arrays[n] = actual
        captures[n] = dict(npz_sha256=sha(packet), json_sha256=sha(raw[n[:-4] + '.json']), arrays=len(actual))
    assert len(captures) == 6
    binding = get('run/BINDINGS.json')
    pq_body = (BASE / 'failed-years-pq-evidence.tar.gz').read_bytes()
    assert sha(pq_body) == binding['parent_PQ_sha256'] == receipt['parent_PQ_sha256']
    pq = unpack(pq_body)
    old_checkpoint = pq[binding['checkpoint_member']]
    assert sha(old_checkpoint) == binding['checkpoint_sha256']
    reconstructed = arrays['run/result/reconstructed-request.npz']
    with zipfile.ZipFile(io.BytesIO(old_checkpoint)) as stream:
        for k in range(16):
            assert header(stream.read('a' + str(k) + '.npy')) == reconstructed['value/state/' + str(k)]
        for k in ('index', 'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax'):
            assert header(stream.read(k + '.npy')) == reconstructed['value/original_global_ledger/' + k]
    input_name = 'run/result/surface/call-0001/input.npz'
    kernel_name = 'run/result/surface/call-0001/kernel-input.npz'
    for k in range(9):
        assert arrays[input_name]['value/args/' + str(k)] == arrays[kernel_name]['value/arguments_without_output/' + str(k)]
    for key, position in (('exchange_extension', 9), ('vic', 10)):
        assert arrays[input_name]['value/kwargs/' + key] == arrays[kernel_name]['value/arguments_without_output/' + str(position)]
    kernel = get(kernel_name[:-4] + '.json')
    assert kernel['metadata']['flags'] == {'extended':True,'vic':True,'stems':False,'profiled':False}
    assert kernel['metadata']['original_argument_count'] == 16
    assert arrays[kernel_name]['value/arguments_without_output/12']['shape'] == [10]
    assert arrays[kernel_name]['value/arguments_without_output/12']['dtype'] == '<f4'
    assert arrays['run/result/surface/call-0001/raw-output.npz']['value/raw741']['shape'] == [3, 741]
    report = dict(passed=True, blocking_findings=[], actual_static_exit=0,
                  archive_sha256=package['sha256'], archive_members=72, original_remote_members=len(original_run),
                  controls_manifest_sha256=launch['controls_manifest_sha256'],
                  launch_parent_exit=0, actual_worker_wait_returncode=1, detached_controller_OS_exit=None,
                  source_evidence_control_before_after_files=1252, actual_batch_step_attempts=1, actual_column_attempts=3,
                  completed_batch_returns=0, trajectory_committed_steps=0,
                  surface_calls=1, MOST_iteration=1, all_raw_finite_as_recorded_on_device=True,
                  final_converged_as_recorded_on_device=[False,True,True], canopy_converged_as_recorded_on_device=[False,True,True],
                  case_order=binding['cases'] and [c['case'] for c in binding['cases']],
                  checkpoint_to_reconstructed_payloads_byteexact=23, input9_plus_extension_and_VIC_kernel_payloads_equal=11,
                  typed_capture_packets=captures, total_NPY_header_payloads_checked=sum(len(a) for a in arrays.values()),
                  kernel_flags=kernel['metadata']['flags'], actual_coefficients_shape=[10], actual_coefficients_dtype='<f4',
                  actual_seconds=receipt['seconds'], model_call_passed=False, diagnostic_capture_complete=True,
                  local_physics_calls=0, local_array_value_decodes=0,
                  scope='Closed original-source GPU diagnostic remains failure. Local verification only raw archive bytes, JSON, NPY headers and opaque payload SHA. Actual device flags are original recorded values. No formula diagnosis, independent NumPy reference, acceptance, old failed-input byteexact or annual continuation claimed.',
                  script_sha256=sha(Path(__file__).read_bytes()))
    path = BASE / (label + '-verification.json')
    path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(passed=True, review_sha256=sha(path.read_bytes()), captures=len(captures),
                         npy_header_payloads=report['total_NPY_header_payloads_checked'], original_checkpoint_fields=23)))


if __name__ == '__main__':
    main()

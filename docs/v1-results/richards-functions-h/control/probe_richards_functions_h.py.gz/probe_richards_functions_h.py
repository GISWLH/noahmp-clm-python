from pathlib import Path
import hashlib,io,json,os,sys,tarfile,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'richards-native-f';r=b/'richards-functions-h';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==543 and all(sha(s/n)==h for n,h in m.items())
with np.load(b/'richards-flow-diagnosis-f/flow-and-systems.npz',allow_pickle=False) as z:
    data=dict(z);old=data['cuda/6/old'];u=data['cuda/6/raw'][4:8];dt=float(data['cuda/6/dt'])
    np.testing.assert_array_equal(u,data['jax/6/raw'][4:8])
with np.load(s/'tests/fixtures/richards_reference.npz',allow_pickle=False) as z:p=z['32/4/hydraulics'][0]
sys.path[:0]=[str(s/'src')]
import cupy as cp
import jax
import jax.numpy as j
from noahmp_clm.gpu.richards import _system,_properties
source=(s/'src/noahmp_clm/gpu/cuda/richards_kernel.cu').read_text()
source+='''
extern "C" __global__ void function_probe(const float* u,const float* old,const float* p,float dt,float* out) {
    if(blockIdx.x||threadIdx.x)return;
    float residual[4],q[3],a[16];richards_system(u,old,p,dt,4,residual,q,a);
    for(int i=0;i<3;++i){out[i]=q[i];out[3+i]=(1000.f*dt)*q[i];}
    out[6]=dt;out[7]=1000.f*dt;
    for(int i=0;i<4;++i){
        float maximum=(1000.f*p[6*i])*p[6*i+1],relative=u[i]/maximum;
        float limited=fmaxf(relative,(.01f*p[6*i+5])/p[6*i+1]),b=p[6*i+4];
        out[8+4*i]=powf(limited,-b);out[8+4*i+1]=expf((-b)*logf(limited));
        out[8+4*i+2]=logf(limited);out[8+4*i+3]=(-b)*logf(limited);
    }
}
'''
(r/'diagnostic-kernel.cu').write_text(source)
module=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('function_probe',))
out=cp.empty(24,cp.float32);module.get_function('function_probe')((1,),(1,),(cp.asarray(u),cp.asarray(old),cp.asarray(p),np.float32(dt),out))
def probe(u,old,p,dt):
    from jax import lax
    stop=lax.optimization_barrier;dt=j.asarray(dt,u.dtype)
    _,q,_=_system(u,old,p,dt);maximum=stop(stop(1000.*p[:,0])*p[:,1])
    relative=u/maximum;limited=j.maximum(relative,stop(.01*p[:,5])/p[:,1]);b=p[:,4]
    math=j.stack((j.power(limited,-b),j.exp(stop((-b)*j.log(limited))),j.log(limited),stop((-b)*j.log(limited))),axis=1)
    return j.concatenate((q,stop(stop(1000.*dt)*q),j.stack((dt,stop(1000.*dt))),math.ravel()))
jo=jax.jit(probe)(j.asarray(u),j.asarray(old),j.asarray(p),j.asarray(dt,j.float32))
np.savez_compressed(r/'functions.npz',cuda=cp.asnumpy(out),jax=np.asarray(jo),original_cuda_transfer=data['cuda/6/raw'][8:11],original_jax_transfer=data['jax/6/raw'][8:11],u=u,p=p,dt=np.asarray(dt))
cp.cuda.runtime.deviceSynchronize();jax.effects_barrier();assert all(sha(s/n)==h for n,h in m.items())
d=dict(scope='GPU-only fixed common finalcoordinate of first rejectedraw call6. Private originalCUDA system and JAX system/typedscalar/pow/exp-log probes; original failed trajectories unmodified. Diagnostic comparisons pending EHPC; no new candidate or acceptance. Atexit bypass after barriers/durable receipt.',source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,payload_sha256=sha(r/'functions.npz'),device_barriers_complete=True)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

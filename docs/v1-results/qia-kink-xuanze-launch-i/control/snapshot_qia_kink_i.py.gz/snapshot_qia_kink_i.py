from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile

mode = sys.argv[1]
files = []
embedded = {}
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Read-only metadata/immutable raw-file snapshot; no login-node model calculation. Actual running/queued status is not annual/fullcanonical/spinup/science acceptance. Original failed1110 trajectories unchanged.')
if mode == 'cpu':
    base = Path('/home/zhangyq/noahmp-v1')
    root = base / 'qia-kink-numpy-year-h'
    name = 'qia-kink-ehpc-progress-i'
    record['qstat'] = subprocess.check_output(['qstat', '-u', 'zhangyq'], text=True)
    raw = (root / 'trajectory/report.json').read_bytes()
    report = json.loads(raw)
    embedded['year/trajectory/report.json'] = raw
    record.update(status=report['status'], steps_completed=report['steps_completed'],
                  steps_requested=report['steps_requested'], report_sha256=hashlib.sha256(raw).hexdigest(),
                  source_manifest_sha256=hashlib.sha256((root / 'SOURCE_SHA256.json').read_bytes()).hexdigest())
    for path in sorted(root.rglob('*')):
        if path.is_file() and path != root / 'trajectory/report.json':
            files.append(('year/' + path.relative_to(root).as_posix(), path))
    files.append(('control/dispatch_qia_kink_numpy_year_h.py', base / 'dispatch_qia_kink_numpy_year_h.py'))
else:
    assert mode == 'gpu'
    base = Path('/home/lhwang/work/noahmp-v1')
    root = base / 'qia-kink-cuda-year-h'
    name = 'qia-kink-xuanze-launch-i'
    for path in sorted(root.rglob('*')):
        if path.is_file():
            files.append(('year/' + path.relative_to(root).as_posix(), path))
    for control in ['run_qia_kink_cuda_year_h.py', 'control_qia_kink_cuda_year_h.py', 'launch_qia_kink_cuda_year_h.py']:
        files.append(('control/' + control, base / control))
    pipeline = []
    for relative in ['pft-optics-final-d/full-by-file-d/progress.json', 'p6-all-phase-final-b/full-by-file-a/progress.json']:
        path = base / relative
        if path.exists():
            raw = path.read_bytes(); embedded['pipelines/' + relative] = raw
            progress = json.loads(raw)
            pipeline.append(dict(path=relative, status=progress['status'],
                                 covered_nodes=progress['covered_nodes'], collected_nodes=progress['collected_nodes'],
                                 active=progress.get('active'), sha256=hashlib.sha256(raw).hexdigest()))
    deferred = base / 'qia1110-final-h/full-controller-h'
    for path in sorted(deferred.rglob('*')):
        if path.is_file():
            files.append(('current-canonical/' + path.name, path))
    record.update(pipelines=pipeline, current_canonical_worker_started=(deferred / 'worker.json').exists(),
                  cuda_year_worker=json.loads((root / 'worker.json').read_text()) if (root / 'worker.json').exists() else None)
archive = base / (name + '-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for arcname, path in files:
        tf.add(path, arcname=arcname, recursive=False)
    tf.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
    embedded['snapshot.json'] = (json.dumps(record, indent=2) + '\n').encode()
    for arcname, raw in embedded.items():
        info = tarfile.TarInfo(arcname); info.size = len(raw); tf.addfile(info, io.BytesIO(raw))
print(json.dumps(dict(archive=archive.name, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), bytes=archive.stat().st_size, snapshot=record)))

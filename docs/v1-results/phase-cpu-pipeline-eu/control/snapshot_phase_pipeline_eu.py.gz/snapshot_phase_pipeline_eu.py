"""Read-only metadata/immutable-generation snapshot; no numerical evaluation."""
from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,sys,tarfile
kind=sys.argv[1];assert kind in ['cpu','gpu'];b=Path('/home/zhangyq/noahmp-v1' if kind=='cpu' else '/home/lhwang/work/noahmp-v1');r=b/('phase-'+kind+'-pipeline-eu');assert not r.exists();r.mkdir();sha=lambda raw:hashlib.sha256(raw).hexdigest();items={};inventory=[]
def add(p,name):
    raw=p.read_bytes();items[name]=raw;inventory.append(dict(source_path=str(p),path=name,sha256=sha(raw),bytes=len(raw)))
if kind=='cpu':
    for label in ['capacity','capacity_optics']:
        root=b/('qia-phase-'+label+'-numpy-year-em')
        for p in sorted(root.rglob('*')):
            if p.is_file() and 'trajectory' not in p.relative_to(root).parts:add(p,root.name+'/'+p.relative_to(root).as_posix())
        add(root/'trajectory/report.json',root.name+'/observed-live-report.json')
        root=b/('qia-phase-'+label+'-year-evaluation-ev')
        for p in sorted(root.rglob('*')):
            if p.is_file():add(p,root.name+'/'+p.relative_to(root).as_posix())
    q=subprocess.run(['qstat','-u','zhangyq'],capture_output=True,text=True);items['qstat.txt']=(q.stdout+q.stderr).encode();controllers=[]
else:
    controllers=[]
    for name in ['phase-cuda-years-en','phase-full-eo-gpu','phase-cold-queue-ej','phase-surface-profile-et','k78-snow-primitives-er']:
        root=b/name
        for p in sorted(root.rglob('*')):
            if p.is_file():add(p,name+'/'+p.relative_to(root).as_posix())
        if (root/'launch.json').exists():
            pid=json.loads((root/'launch.json').read_text())['pid'];proc=Path('/proc')/str(pid);row=dict(root=name,pid=pid,process_exists=proc.exists())
            if proc.exists():
                cmd=(proc/'cmdline').read_bytes();assert b'noahmp-v1' in cmd;items['processes/'+str(pid)+'-status.txt']=(proc/'status').read_bytes();row['cmdline_sha256']=sha(cmd)
            controllers.append(row)
    for label in ['capacity','capacity_optics']:
        root=b/('qia-phase-'+label+'-cuda-year-ej')
        for p in sorted(root.iterdir()):
            if p.is_file():add(p,root.name+'/'+p.name)
        if (root/'trajectory/batch.json').exists():
            raw=(root/'trajectory/batch.json').read_bytes();report=json.loads(raw);items[root.name+'/trajectory/batch.json']=raw;name=report['checkpoint_file'];p=root/'trajectory'/name;assert sha(p.read_bytes())==report['checkpoint_sha256'];add(p,root.name+'/trajectory/'+name)
            for case,desc in report['case_reports'].items():
                p=root/'trajectory'/case/desc['file'];raw=p.read_bytes();assert sha(raw)==desc['sha256'];items[root.name+'/trajectory/'+case+'/'+desc['file']]=raw;data=json.loads(raw);p=p.parent/data['model_npz'];assert sha(p.read_bytes())==data['model_npz_sha256'];add(p,root.name+'/trajectory/'+case+'/'+data['model_npz'])
    q=subprocess.run(['nvidia-smi','--id=1','--query-gpu=index,uuid,utilization.gpu,memory.used,memory.free','--format=csv,noheader'],capture_output=True,text=True);items['physical-gpu1.txt']=(q.stdout+q.stderr).encode()
    for n in ['run_phase_gpu_prefix_ej.py','control_phase_gpu_prefix_ej.py','queue_phase_gpu_prefix_ej.py','launch_phase_gpu_prefix_ej.py','run_phase_cuda_year_en.py','control_phase_cuda_year_en.py','launch_phase_cuda_year_en.py','queue_phase_cuda_years_en.py','launch_phase_cuda_years_en_queue.py']:add(b/n,'base-controls/'+n)
add(Path(__file__),'control/'+Path(__file__).name);record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind=kind,controllers=controllers,free_home_inodes=os.statvfs(b).f_favail,files=inventory,scope='Point-in-time queue/control/liveness metadata and namedimmutable nativegeneration only. CPU refs run independently after own1120/EG48; GPUyear after independentEL48; EO remaining380 after actualnativeyear terminal. Every queue remainsunexecuted/unpassed until ownactualproof. Snapshot not completedyear/full401/science/spinup/release. No numericalmodel or analysis onlogin.');items['snapshot.json']=(json.dumps(record,indent=2)+'\n').encode();a=b/('phase-'+kind+'-pipeline-eu-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in items.items():info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(items),controllers=controllers)),flush=True)

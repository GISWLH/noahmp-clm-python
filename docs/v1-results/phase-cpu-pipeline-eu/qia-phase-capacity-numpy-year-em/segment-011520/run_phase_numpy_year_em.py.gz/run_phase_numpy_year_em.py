from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time,traceback
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];start_index=int(os.environ['START_INDEX']);target=int(os.environ['END_INDEX']);assert label in ['capacity','capacity_optics'] and 48<=start_index<target<=17520
b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-phase-'+label+'-numpy-year-em');segment=r/('segment-'+str(start_index).zfill(6));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=Path(os.environ['TMPDIR'])/'source';s.mkdir();archive=b/'clm-phase-descent-ec-source.tar.gz';assert sha(archive)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items()) and (s/'SOURCE_SHA256.json').read_bytes()==(r/'SOURCE_SHA256.json').read_bytes()
inputs=Path(os.environ['TMPDIR'])/'inputs';inputs.mkdir();archive=b/'qia-phase-cold-ef-inputs.tar.gz';assert sha(archive)=='2325f371ca0fe1a798be898449525bf51b45f46758d772e644644037152046bb'
with tarfile.open(archive) as tf:tf.extractall(inputs,filter='data')
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
cpu=b/'phase-descent-ec-cpu';proof=json.loads((cpu/'full-receipt.json').read_text());assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and proof['returncode']==0 and proof['source_unchanged'] and proof['source_manifest_sha256']==manifest and proof['counts']==dict(tests=1120,failures=0,errors=0,skipped=0)
lineage=json.loads((r/'lineage.json').read_text());prior=r/'trajectory/report.json';old=json.loads(prior.read_text());assert old['status']=='running' and 'failure' not in old and old['steps_completed']==start_index and old['steps_requested']==17520 and sha(r/'config.json')==old['configuration_sha256'] and runner.source_hashes()==old['source_sha256']
if start_index==48:assert sha(prior)==lineage['own48_report_sha256']
else:
    prior_segment=r/('segment-'+str([48,2880,5760,8640,11520,14400][[2880,5760,8640,11520,14400,17520].index(start_index)]).zfill(6))
    previous=json.loads((prior_segment/'receipt.json').read_text());assert (prior_segment/'pbs-exit.txt').read_text().strip()=='0' and previous['failure'] is None and previous['source_unchanged'] and previous['steps_completed']==start_index and previous['report_sha256']==sha(prior)
for n,h in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:assert sha(r/'trajectory'/old[n])==old[h]
(segment/'continued-start-report.json').write_bytes(prior.read_bytes());saved=pickle.loads((r/'trajectory'/old['checkpoint_file']).read_bytes());assert len(saved)==7 and saved[-1]==start_index
(segment/'continued-start-state.pkl').write_bytes((r/'trajectory'/old['checkpoint_file']).read_bytes());original=runner.step_clm_enthalpy_column;checked=False
def first(state,*args,**kwargs):
    global checked
    if not checked:
        assert pickle.dumps(state)==pickle.dumps(saved[0]),'First continued tendency changed the saved physical state'
        (segment/'first-input-audit.json').write_text(json.dumps(dict(saved_state_byteexact_after_unpickle=True,checkpoint_tuple_fields=7,start_index=start_index,source_manifest_sha256=manifest,checkpoint_sha256=old['checkpoint_sha256'],scope='Originalresume carries state/initial/net/bounds/maximum/stepmax/index; no coldreset/failedprefix or ledgerreset. Original7tuple and report preserved before first continued tendency.'),indent=2)+'\n');checked=True
    return original(state,*args,**kwargs)
started=time.monotonic();failure=None
try:
    runner.step_clm_enthalpy_column=first
    report=runner.run(inputs/'CN-Qia.npz',inputs/'CN-Qia.json',r/'config.json',r/'trajectory',resume=True,stop_after=target-start_index)
    assert checked and report['status']==('complete' if target==17520 else 'running') and report['steps_completed']==target and report['steps_requested']==17520 and report['source_unchanged']
except Exception as e:failure=type(e).__name__+': '+str(e);(segment/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:runner.step_clm_enthalpy_column=original
report=json.loads(prior.read_text());d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,case=label,start_index=start_index,target_index=target,failure=failure,first_continued_state_exact=checked,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=manifest,status=report['status'],steps_completed=report['steps_completed'],steps_requested=report['steps_requested'],report_sha256=sha(prior),seconds=time.monotonic()-started,scope='CurrentEC ownsuccessfulEG48 after own1120CPU actualPBS0, continuous independent NumPy original17520 reference. Identicalallsource/forcing/config/cumulativeMHCN, explicitfirststate check and preserved7tuple; afterok segmentchain stops after anyfailure. NumPy reference has no dependency on GPU success; independentEL48 audit remains mandatory before GPUyear. A completedsegment is not a completedyear/spinup/sciencepass.')
(segment/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');(segment/'end-report.json').write_bytes(prior.read_bytes());print(json.dumps(d),flush=True);assert failure is None and d['source_unchanged'] and d['steps_completed']==target

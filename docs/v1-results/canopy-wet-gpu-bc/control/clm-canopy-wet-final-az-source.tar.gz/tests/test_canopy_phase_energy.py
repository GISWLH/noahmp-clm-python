"""Independent simultaneous equations for the layered canopy phase solve."""
from dataclasses import replace
import numpy as np
import pytest
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_radiation import canopy_shortwave,canopy_longwave
from noahmp_clm.physics.photosynthesis import leaf_gas_exchange
from noahmp_clm.physics.soil_uptake import SoilWaterSupply


def cases():
    area=np.full(10,.3);supply=SoilWaterSupply(np.full(4,1e-5),np.full(4,.25),1.5e-5)
    rows=[]
    for name,mass,old_t,fraction,air,humidity,sw,lw in (
            ('liquid',.1,285.,1.,290.,.008,500.,350.),
            ('ice',.2,260.,0.,263.,.001,50.,210.),
            ('melt',.1,270.,0.,280.,.004,300.,300.),
            ('freeze',.02,275.,1.,265.,.001,0.,220.),
            ('dry',0.,295.,1.,295.,.01,600.,350.),
            ('mixture',.2,273.15,.5,273.15,.0035,80.,310.),
            ('thin',1e-5,280.,1.,295.,.003,600.,320.),
            ('dew',0.,280.,1.,280.,.009,0.,260.),
            ('frost',0.,265.,0.,265.,.004,0.,200.)):
        c=CanopyCondensate.from_temperature(np.full(10,mass),old_t,liquid_fraction=fraction)
        e=CanopyExchange(air,humidity,101325.,.02,.003,.03,air-1.,15.)
        kw=dict(soil_supply=supply,root_enthalpy=np.full(4,334000.+4180.*(air-273.15)))
        rows.append((name,area.copy(),sw,lw,e,c,kw))
    name,a,sw,lw,e,c,kw=rows[0]
    rows.append(('stems',a*.7,sw,lw,e,c,{**kw,'stem_area':a*.3,'vegetated_fraction':.65}))
    rows.append(('bare',a,sw,lw,e,CanopyCondensate.empty(),{**kw,'vegetated_fraction':0.}))
    a=np.array([.3,0.,.3,0.,.3,0.,.3,0.,.3,0.]);c=CanopyCondensate.from_temperature(np.where(a>0.,.1,0.),285.)
    rows.append(('inactive_layers',a,sw,lw,e,c,kw))
    from noahmp_clm.physics.snowpack import Snowpack
    for tg in (250.,265.,273.15):
        a=np.full(10,.3);c=CanopyCondensate.from_temperature(np.full(10,.2),min(tg+1.,273.15))
        e=CanopyExchange(tg+2.,.001,101325.,.02,.003,.03,274.,15.)
        kw=dict(soil_supply=supply,root_enthalpy=np.full(4,334000.),fixed_ground_temperature=tg,
            ground_is_ice=True,ground_shares_soil=False,ground_evaporation_limit=1e-6,
            snowpack=Snowpack.from_ice([2.,4.,8.,16.,32.],tg),vegetated_fraction=.7)
        rows.append((f'snow_{tg}',a,350.,240.,e,c,kw))
    return rows


def independent_reference(area,swdown,lwdown,e,old,dt,**kw):
    """Independently assemble mass, phase, air and heat equations for SciPy.

    Reuse only tested radiation and biochemistry. In particular do not call
    production phase/energy/water/air helpers or use production iterates.
    """
    least_squares=pytest.importorskip('scipy.optimize').least_squares
    leaf=np.asarray(area);area=leaf+np.broadcast_to(kw.get('stem_area',0.),leaf.shape);n=len(area)
    fv=kw.get('vegetated_fraction',1.) if area.sum() else 0.;active=fv*area>0.
    radiation=dict(ground_albedo=kw.get('ground_albedo',(.15,.3)),diffuse_fraction=kw.get('diffuse_fraction',.5),cosine_zenith=kw.get('cosine_zenith',.5))
    emissivity=kw.get('ground_emissivity',.97)
    sw=canopy_shortwave(area,swdown,**radiation);mass=old.mass;old_h=old.enthalpy;coupled=None
    if kw.get('snowpack') is not None:
        from noahmp_clm.physics.canopy_snow_radiation import canopy_snow_shortwave
        coupled=canopy_snow_shortwave(area,kw['snowpack'],swdown,vegetated_fraction=fv,**radiation);sw=coupled['canopy']
    supply=kw['soil_supply'];root_h=kw['root_enthalpy'];root_limit=min(kw.get('transpiration_limit',np.inf),supply.roots[supply.weights>0.].sum())
    rho=e.pressure/(287.*e.air_temperature*(1.+.61*e.specific_humidity));mol=e.pressure/(8.314462618*e.air_temperature)
    # Independent equation input from the actual pinned CLM5 namelist.
    capacity=.1*fv*area;fw=np.minimum(.05,np.divide(mass,capacity,out=np.zeros(n),where=capacity>0.)**(2./3.))
    fd=(1.-fw)*np.divide(leaf,area,out=np.zeros(n),where=area>0.)
    released=np.zeros(n,dtype=bool)
    def evaluate(x,details=False):
        heat=mass*4180.*x[:n]
        liq=np.minimum(mass,np.maximum(0.,heat/334000.));ice=mass-liq
        leaf_t=np.full(n,273.15)
        below=(heat<0.)&(mass>0.);above=(heat>334000.*mass)&(mass>0.)
        leaf_t[below]+=heat[below]/(2100.*mass[below]);leaf_t[above]+=(heat[above]-334000.*mass[above])/(4180.*mass[above])
        leaf_t[mass==0.]=273.15+x[:n][mass==0.]
        # Once a reservoir is independently found exhausted, its plateau H
        # coordinate is redundant. Use temperature for that row while keeping
        # the same phase-specific parcel enthalpy and all balance equations.
        leaf_t[released]=273.15+x[:n][released]
        delta=x[:n][released]
        heat[released]=mass[released]*(2100.*np.minimum(delta,0.)+334000.*(delta>0.)+4180.*np.maximum(delta,0.))
        t=np.r_[leaf_t,x[n]];q=x[-1]*.001
        es=611.2*np.exp(17.67*(t-273.15)/(t-29.65));ql=.622*es/(e.pressure-.378*es)
        ei=np.exp(9.550426-5723.265/t+3.53068*np.log(t)-.00728332*t);qi=.622*ei/(e.pressure-.378*ei)
        fraction=np.divide(liq,mass,out=np.asarray(leaf_t>273.15,dtype=float),where=mass>0.)
        qs=qi[:-1]+fraction*(ql[:-1]-qi[:-1])
        gas=leaf_gas_exchange(sw['absorbed_par'],leaf_t,co2_ppm=e.co2_ppm,relative_humidity=q*e.pressure/(.622+.378*q)/es[:-1],
            boundary_conductance=e.leaf_velocity*mol,nitrogen_factor=kw.get('nitrogen_factor',1.)*kw.get('water_stress',1.) if root_limit>0. else 0.,
            water_stress=kw.get('water_stress',1.),parameters=kw.get('leaf_parameters'))
        wanted=rho*fv*area*e.leaf_velocity*np.where(qs>q,fw,1.)*(qs-q)*dt
        loss=np.minimum(np.maximum(wanted,0.),mass);deposit=np.maximum(-wanted,0.)
        wet=(loss-deposit)/dt
        # Independent phase-specific parcel H and final extensive quantities.
        removal=np.divide(loss,mass,out=np.zeros(n),where=mass>0.)*heat
        deposit_h=deposit*((1.-fraction)*2100.*(leaf_t-273.15)+fraction*(334000.+4180.*(leaf_t-273.15)))
        final_m=mass-loss+deposit;final_h=heat-removal+deposit_h;adv=(removal-deposit_h)/dt
        tr=rho*fv*area*e.leaf_velocity*fd*gas['gs_mol']/(e.leaf_velocity*mol+gas['gs_mol'])*np.maximum(ql[:-1]-q,0.)
        if tr.sum()>root_limit:tr*=root_limit/tr.sum()
        rooted=supply.weights>0.;lo=0.;hi=np.max(supply.roots[rooted]/supply.weights[rooted],initial=0.)
        for _ in range(50):
            mid=(lo+hi)/2.;uptake=np.minimum(supply.roots,mid*supply.weights)
            if uptake.sum()<tr.sum():lo=mid
            else:hi=mid
        uptake=np.minimum(supply.roots,(lo+hi)/2.*supply.weights)
        qground=qi[-1] if kw.get('ground_is_ice',False) else ql[-1]
        ge=rho*np.array([fv*(qground-q)/(1./e.ground_velocity+e.ground_resistance),
            (1.-fv)*(qground-e.specific_humidity)/(1./e.water_velocity+e.ground_resistance)])
        pos=np.maximum(ge,0.);neg=np.minimum(ge,0.);limit=kw.get('ground_evaporation_limit',np.inf)
        if kw.get('ground_shares_soil',True):limit=min(limit,max(0.,supply.surface-uptake[0]))
        if pos.sum()>0.:pos*=min(1.,(limit-neg.sum())/pos.sum())
        ge=pos+neg
        weights=np.r_[area*e.leaf_velocity,e.ground_velocity]
        tc=e.heat_temperature+weights@(t-e.heat_temperature)/(weights.sum()+e.atmosphere_velocity) if fv else e.heat_temperature
        sensible=rho*1004.*fv*weights*(t-tc);sensible[-1]+=rho*1004.*(1.-fv)*e.atmosphere_velocity*(t[-1]-e.heat_temperature)
        longwave=canopy_longwave(area,leaf_t,lwdown,t[-1],ground_emissivity=emissivity)
        rn=np.r_[fv*(sw['absorbed']+longwave['net_absorbed']),fv*(sw['ground_absorbed']+longwave['ground_net'])+
            (1.-fv)*(swdown*(1.-.5*sum(radiation['ground_albedo']))+emissivity*(lwdown-5.670374419e-8*t[-1]**4))]
        if coupled is not None:rn[-1]=coupled['snow_absorbed'].sum()+coupled['soil_absorbed']+fv*longwave['ground_net']+(1.-fv)*emissivity*(lwdown-5.670374419e-8*t[-1]**4)
        latent=np.r_[(2834000.-334000.*fraction)*wet+2500000.*tr,(2834000. if kw.get('ground_is_ice',False) else 2500000.)*ge.sum()]
        root_mean=float(uptake@root_h/uptake.sum()) if uptake.sum()>0. else 0.
        extra=tr*(334000.+4180.*(leaf_t-273.15)-root_mean)
        g=e.soil_conductance*(t[-1]-e.soil_temperature)+e.soil_flux_offset
        residual=rn-sensible-latent;residual[:-1]-=(final_h-old_h)/dt+adv+extra
        if kw.get('fixed_ground_temperature') is not None:g=residual[-1]
        residual[-1]-=g
        if kw.get('fixed_ground_temperature') is not None:residual[-1]=kw['fixed_ground_temperature']-t[-1]
        residual[:-1]=np.where(active,residual[:-1],e.air_temperature-leaf_t)
        qres=(wet.sum()+tr.sum()+ge[0]-rho*fv*e.water_velocity*(q-e.specific_humidity))*2500000. if fv else (q-e.specific_humidity)*1e5
        result=np.r_[residual,qres]
        if details:return dict(residual=result,temperature=t,h=sensible.sum(),le=latent.sum(),g=g,gpp=fv*leaf@gas['gross'],mass=final_m,enthalpy=final_h,humidity=q)
        return result
    initial=np.r_[np.divide(old_h,mass*4180.,out=np.full(n,e.air_temperature-273.15),where=mass>0.),kw.get('fixed_ground_temperature',e.air_temperature),e.specific_humidity*1000.]
    lower=np.r_[np.where(mass>0.,(200.-273.15)*2100./4180.,200.-273.15),200.,0.]
    upper=np.r_[np.where(mass>0.,334000./4180.+350.-273.15,350.-273.15),350.,190.]
    ambient=initial.copy()
    ambient[:n]=np.where(mass>0.,2100./4180.*(e.air_temperature-273.15) if e.air_temperature<273.15
        else 334000./4180.+e.air_temperature-273.15,e.air_temperature-273.15)
    # A separate warm-phase start crosses the zero temperature derivative
    # inside a latent plateau. It depends only on the prescribed atmosphere,
    # never on a production iterate or solution; all original residual gates
    # and each optimizer's400-evaluation budget remain unchanged.
    warm=ambient.copy();warm_temperature=max(275.15,min(340.,e.air_temperature+15.))
    warm[:n]=np.where(mass>0.,334000./4180.+warm_temperature-273.15,warm_temperature-273.15)
    candidates=[];candidate_coordinates=[]
    # A reflective trust region can stop on a phase boundary even with large
    # residual. Try the independent rectangular trust region, never seed with
    # production iterates and never accept the optimizer's status by itself.
    for method in ('trf','dogbox'):
        for guess in (initial,ambient,warm):
            fitted=least_squares(evaluate,guess,method=method,bounds=(lower,upper),x_scale='jac',max_nfev=400,xtol=1e-12,ftol=1e-12,gtol=1e-10)
            candidates.append(evaluate(fitted.x,True))
            candidate_coordinates.append(fitted.x.copy())
            if np.max(abs(candidates[-1]['residual']))<1e-6:return candidates[-1]
    best=min(range(len(candidates)),key=lambda k:np.max(abs(candidates[k]['residual'])));result=candidates[best]
    released[:]=(mass>0.)&(result['mass']==0.)
    if released.any():
        start=candidate_coordinates[best].copy();start[:n][released]=result['temperature'][:n][released]-273.15
        new_lower=lower.copy();new_upper=upper.copy();new_lower[:n][released]=200.-273.15;new_upper[:n][released]=350.-273.15
        for method in ('trf','dogbox'):
            fitted=least_squares(evaluate,start,method=method,bounds=(new_lower,new_upper),x_scale='jac',max_nfev=400,xtol=1e-12,ftol=1e-12,gtol=1e-10)
            trial=evaluate(fitted.x,True)
            # The temperature parametrization is valid only while the rows
            # selected by this independent solve really remain exhausted.
            if np.all(trial['mass'][released]==0.) and np.max(abs(trial['residual']))<1e-6:return trial
    assert np.max(abs(result['residual']))<1e-6,(fitted.message,result['residual'])
    return result


@pytest.mark.parametrize('name,area,sw,lw,e,c,kw',cases(),ids=[row[0] for row in cases()])
def test_phase_energy_independent_network(name,area,sw,lw,e,c,kw):
    got=solve_canopy_phase_energy(area,sw,lw,e,c,1800.,**kw)
    ref=independent_reference(area,sw,lw,e,c,1800.,**kw)
    np.testing.assert_allclose(np.r_[got['leaf_temperature'],got['ground_temperature']],ref['temperature'],rtol=0.,atol=1e-4)
    for key in ('h','le','gpp'):np.testing.assert_allclose(got[key],ref[key],rtol=.1,atol=.001)
    np.testing.assert_allclose(got['condensate'].mass,ref['mass'],rtol=.1,atol=1e-7)
    np.testing.assert_allclose(got['condensate'].enthalpy,ref['enthalpy'],rtol=.1,atol=.1)
    np.testing.assert_allclose(got['condensate'].mass+1800.*got['wet_evaporation'],c.mass,rtol=0.,atol=1e-14)
    assert np.all(got['root_uptake']<=kw['soil_supply'].roots+1e-15)
    if name=='melt':assert np.all(got['condensate'].ice==0.)
    if name=='freeze':assert np.all(got['condensate'].liquid==0.)
    if name=='mixture':assert np.any((got['condensate'].ice>0.)&(got['condensate'].liquid>0.))
    assert np.max(abs(got['layer_residual']))<5e-5
    assert abs(got['air_water_residual'])<2.1e-11
    assert abs(got['air_heat_residual'])<1e-9
    total=sw+lw-got['outgoing_shortwave']-got['outgoing_longwave']-got['h']-got['le']-got['ground_heat']
    total-=got['canopy_storage_change_wm2']+got['wet_advected_heat_wm2']+got['transpiration_advected_heat_wm2']-got['root_advected_heat_wm2']
    assert got['transpiration_advected_heat_wm2']==pytest.approx(float(got['transpiration']@(334000.+4180.*(got['leaf_temperature']-273.15))),abs=1e-12)
    assert got['root_advected_heat_wm2']==pytest.approx(float(got['root_uptake']@kw['root_enthalpy']),abs=1e-12)
    assert got['transpiration_net_heat_wm2']==pytest.approx(got['transpiration_advected_heat_wm2']-got['root_advected_heat_wm2'],abs=1e-12)
    assert abs(total)<6e-4
    print(name,dict(iterations=got['iterations'],temperature_error=float(np.max(abs(np.r_[got['leaf_temperature'],got['ground_temperature']]-ref['temperature']))),energy_residual=float(total)))


def test_phase_energy_rejects_unowned_root_heat_and_inactive_water():
    _,a,sw,lw,e,c,kw=cases()[0]
    with pytest.raises(ValueError):solve_canopy_phase_energy(a,sw,lw,e,c,1800.)
    with pytest.raises(ValueError):solve_canopy_phase_energy(a,sw,lw,e,c,1800.,vegetated_fraction=0.,**kw)


def test_plateau_vapor_transfers_both_phases_with_exact_total_heat():
    from noahmp_clm.physics.canopy_phase_energy import _equilibrium_vapor
    old=CanopyCondensate.from_temperature([2.],273.15,liquid_fraction=.5)
    final,p=_equilibrium_vapor(old,np.array([.4]),np.array([273.15]))
    np.testing.assert_allclose([p['ice_kgm2'][0],p['liquid_kgm2'][0]],[.2,.2],rtol=0.,atol=1e-15)
    assert p['latent_energy_jm2'][0]==pytest.approx(1066800.,rel=1e-14)
    assert p['advected_enthalpy_jm2'][0]==pytest.approx(66800.,rel=1e-14)
    assert final.enthalpy[0]==pytest.approx(267200.,rel=1e-14)
    assert final.temperature[0]==273.15


@pytest.mark.parametrize('water_scale',[1.,.01])
def test_phase_evaporation_retention_and_exhaustion_preserve_owned_parcels(water_scale):
    # Retain the actual cold-canopy step14. With the CLM5 exposed-area bound
    # it retains water; a proportional M/H reduction also checks complete
    # exhaustion without changing initial phase temperature or forcing.
    mass=[0.,0.,0.,.00647506555267528,.01710930969501606,.027346464531692684,.03612239454314759,.04392351269441901,.05119005342416928,.05834543445506625]
    heat=[0.,0.,0.,-5.391749907703349,-34.08079016085131,-70.8682358081651,-112.36370366109665,-157.03485902221186,-205.2610373001825,-259.00956965442833]
    c=CanopyCondensate(np.asarray(mass)*water_scale,np.asarray(heat)*water_scale);e=CanopyExchange(266.7877205179804,.001486775896997012,101325.,.02,.003,.03,263.,15.)
    s=SoilWaterSupply(np.full(4,1e-5),np.full(4,.25),1.5e-5)
    args=(np.full(10,.3),473.46506474755284,258.53395590685693,e,c,1800.)
    kw=dict(vegetated_fraction=.8,soil_supply=s,root_enthalpy=np.full(4,334000.+4180.*(263.-273.15)),
        fixed_ground_temperature=263.,ground_is_ice=True,ground_shares_soil=False,ground_evaporation_limit=1e-5)
    r=solve_canopy_phase_energy(*args,**kw);ref=independent_reference(*args,**kw)
    assert np.max(abs(r['layer_residual']))<5e-5
    np.testing.assert_allclose(r['condensate'].mass+1800.*r['wet_evaporation'],c.mass,rtol=0.,atol=1e-14)
    np.testing.assert_allclose(r['condensate'].mass,ref['mass'],rtol=.1,atol=1e-7)
    np.testing.assert_allclose(r['condensate'].enthalpy,ref['enthalpy'],rtol=.1,atol=.1)
    assert abs(r['leaf_temperature']-ref['temperature'][:10]).max()<.05
    if water_scale==1.:assert r['condensate'].mass[3]>0.
    else:assert r['condensate'].mass[3]==0. and r['condensate'].enthalpy[3]==0.
    print('CLM5 cold wetlayer retention/exhaustion',dict(water_scale=water_scale,remaining_fourth_layer_kgm2=float(r['condensate'].mass[3]),maximum_independent_temperature_error_k=float(abs(r['leaf_temperature']-ref['temperature'][:10]).max())),flush=True)


@pytest.mark.parametrize('fixture',['canopy_phase_humidity_bound.json','canopy_phase_humidity_slow.json'])
def test_saved_humidity_recovery_from_prescribed_start(fixture):
    import json
    from pathlib import Path
    from test_gpu_canopy_phase_energy import reference

    saved=json.loads((Path(__file__).parent/'fixtures'/fixture).read_text())
    arrays=tuple(np.asarray(v,np.int32 if k==8 else np.float64) for k,v in enumerate(saved['arrays']))
    original=tuple(a.tobytes() for a in arrays)
    direct=reference(arrays,tolerance=1e-7)
    # A prescribed numerical guess within the original domain. It changes
    # neither old M/H nor forcing/traits, and uses no production solution.
    guess=[120.]*len(arrays[0])+[float(arrays[6][1]),0.]
    recovered=reference(arrays,tolerance=1e-7,initial_guess=guess)
    assert recovered['restarts']>0 and 0.<recovered['canopy_humidity']<.19
    for result in [direct,recovered]:
        assert abs(result['layer_residual']).max()<=1.01e-7
        assert abs(result['solver_residual']).max()<=1e-7
        assert abs(result['canopy_water_residual'])<1e-12
    np.testing.assert_allclose(recovered['leaf_temperature'],direct['leaf_temperature'],rtol=0.,atol=.05)
    np.testing.assert_allclose(recovered['condensate'].mass,direct['condensate'].mass,rtol=.1,atol=1e-7)
    np.testing.assert_allclose(recovered['condensate'].enthalpy,direct['condensate'].enthalpy,rtol=.1,atol=.1)
    assert original==tuple(a.tobytes() for a in arrays)
    print('prescribed humidity recovery',fixture,recovered['restarts'],float(abs(recovered['solver_residual']).max()),
        float(abs(recovered['leaf_temperature']-direct['leaf_temperature']).max()),flush=True)


def test_phase_root_reached_by_last_permitted_update_is_accepted():
    # A root found on the final update needs no extra Newton update. The
    # unrestricted run discovers the necessary budget without changing its
    # physical initial state, tolerances, or independent parcel equations.
    _,area,sw,lw,e,c,kw=cases()[0]
    expected=solve_canopy_phase_energy(area,sw,lw,e,c,1800.,tolerance=1e-7,**kw)
    assert expected['iterations']>1
    result=solve_canopy_phase_energy(area,sw,lw,e,c,1800.,tolerance=1e-7,
        max_iterations=expected['iterations']-1,**kw)
    for key in ('leaf_temperature','solver_residual','layer_residual','wet_evaporation','root_uptake'):
        np.testing.assert_array_equal(result[key],expected[key])
    np.testing.assert_array_equal(result['condensate'].mass,expected['condensate'].mass)
    np.testing.assert_array_equal(result['condensate'].enthalpy,expected['condensate'].enthalpy)
    assert np.max(abs(result['solver_residual']))<=1e-7
    assert np.max(abs(result['layer_residual']))<=1.01e-7
    np.testing.assert_allclose(result['condensate'].mass+1800.*result['wet_evaporation'],c.mass,rtol=0.,atol=1e-14)


def test_exhausted_phase_updates_still_reject_an_unconverged_final_state():
    _,area,sw,lw,e,c,kw=cases()[0]
    with pytest.raises(RuntimeError,match='Canopy phase energy did not converge'):
        solve_canopy_phase_energy(area,sw,lw,e,c,1800.,tolerance=1e-7,max_iterations=1,**kw)


@pytest.mark.parametrize('guess',[np.zeros(11),np.full(12,np.nan),np.r_[np.full(10,1000.),280.,3.]])
def test_phase_guess_rejects_invalid_shape_nonfinite_or_domain(guess):
    _,area,sw,lw,e,c,kw=cases()[0]
    with pytest.raises(ValueError,match='phase guess'):
        solve_canopy_phase_energy(area,sw,lw,e,c,1800.,initial_guess=guess,**kw)


def saved_phase_call(filename):
    import json
    from pathlib import Path
    from noahmp_clm.physics.photosynthesis import LeafParameters
    from noahmp_clm.physics.snowpack import Snowpack
    registry={c.__name__:c for c in (CanopyExchange,CanopyCondensate,SoilWaterSupply,LeafParameters,Snowpack)}
    def decode(value):
        if isinstance(value,list):return [decode(v) for v in value]
        if not isinstance(value,dict):return value
        if '__type__' in value:return registry[value['__type__']](**decode(value['data']))
        if '__array__' in value:
            array=np.asarray(decode(value['__array__']),dtype=value['dtype'])
            return array.reshape(value['shape']) if 'shape' in value else array
        if '__float__' in value:return float(value['__float__'])
        return {k:decode(v) for k,v in value.items()}
    record=json.loads((Path(__file__).parent/'fixtures'/filename).read_text())
    return decode(record['call'])


def test_saved_qia_phase_uses_causal_warm_root_without_changing_old_stores():
    saved=saved_phase_call('qia_163_phase_warm.json');args=saved['args'];kw=saved['kwargs'];old=args[4]
    mass,heat=old.mass.copy(),old.enthalpy.copy()
    got=solve_canopy_phase_energy(*args,**kw,initial_guess=saved['initial_guess'])
    ref=independent_reference(*args,**kw)
    assert got['iterations']<=80
    assert np.max(abs(got['solver_residual']))<=kw['tolerance']
    assert np.max(abs(got['layer_residual']))<=1.01*kw['tolerance']
    np.testing.assert_array_equal(old.mass,mass);np.testing.assert_array_equal(old.enthalpy,heat)
    np.testing.assert_allclose(got['condensate'].mass+args[5]*got['wet_evaporation'],mass,rtol=0.,atol=1e-14)
    np.testing.assert_allclose(np.r_[got['leaf_temperature'],got['ground_temperature']],ref['temperature'],rtol=0.,atol=.05)
    for key in ('h','le','gpp'):np.testing.assert_allclose(got[key],ref[key],rtol=.1,atol=.01 if key=='gpp' else 1.)
    print('saved Qia phase warm root',dict(iterations=got['iterations'],maximum_solver_residual=float(np.max(abs(got['solver_residual']))),
        maximum_temperature_difference_K=float(np.max(abs(np.r_[got['leaf_temperature'],got['ground_temperature']]-ref['temperature']))),
        independent_flux_absolute_differences={k:float(abs(got[k]-ref[k])) for k in ('h','le','gpp')}),flush=True)


def test_new_condensate_phase_edge_reaches_same_root_within_original_budget():
    saved=saved_phase_call('qia_182_phase_edge.json');args=saved['args'];kw=saved['kwargs'];old=args[4]
    mass,heat=old.mass.copy(),old.enthalpy.copy();dt=args[5]
    got=solve_canopy_phase_energy(*args,**kw,initial_guess=saved['initial_guess'])
    reference=solve_canopy_phase_energy(*args,**kw,initial_guess=None)
    assert got['iterations']<=80 and reference['iterations']<=80 and kw['tolerance']==1e-7
    assert np.max(abs(got['solver_residual']))<=kw['tolerance']
    assert np.max(abs(got['layer_residual']))<=1.01*kw['tolerance']
    np.testing.assert_array_equal(old.mass,mass);np.testing.assert_array_equal(old.enthalpy,heat)
    np.testing.assert_allclose(got['condensate'].mass+dt*got['wet_evaporation'],mass,rtol=0.,atol=1e-14)
    np.testing.assert_allclose(got['leaf_temperature'],reference['leaf_temperature'],rtol=0.,atol=.05)
    for key in ('h','le','gpp'):np.testing.assert_allclose(got[key],reference[key],rtol=.1,atol=.01 if key=='gpp' else 1.)
    # Every final leaf here is away from Tf. Reconstruct advected water
    # enthalpy from actual mass and its pure phase, without the solver's
    # parcel-energy or residual helpers.
    t=got['leaf_temperature'];assert np.all(t!=273.15)
    wet_mass=mass-got['condensate'].mass
    wet_heat=(wet_mass*np.where(t<273.15,2100.*(t-273.15),334000.+4180.*(t-273.15))).sum()/dt
    storage=(got['condensate'].enthalpy-heat).sum()/dt
    transp=(got['transpiration']*(334000.+4180.*(t-273.15))).sum()-got['root_uptake']@kw['root_enthalpy']
    energy=got['rnet']-got['h']-got['le']-got['ground_heat']-storage-wet_heat-transp
    assert abs(energy)<=11.*kw['tolerance']
    print('saved Qia fresh phase endpoint',dict(iterations=got['iterations'],reference_iterations=reference['iterations'],
        maximum_solver_residual=float(np.max(abs(got['solver_residual']))),independent_heat_residual_Wm2=float(energy),
        maximum_temperature_difference_K=float(np.max(abs(got['leaf_temperature']-reference['leaf_temperature'])))),flush=True)


def test_existing_wet_phase_edge_closes_saved_qia735_without_changing_stores():
    # The original annual trajectory exhausted80 updates from this causal
    # warm guess. Existing water must be eligible for a phase-edge trial too.
    saved=saved_phase_call('qia_735_phase_oldwet.json');args=saved['args'];kw=saved['kwargs'];old=args[4]
    mass,heat=old.mass.copy(),old.enthalpy.copy();assert np.any(mass>0.) and kw['tolerance']==1e-7
    got=solve_canopy_phase_energy(*args,**kw,initial_guess=saved['initial_guess'])
    ref=independent_reference(*args,**kw)
    assert got['iterations']<=80
    assert np.max(abs(got['solver_residual']))<=kw['tolerance']
    assert np.max(abs(got['layer_residual']))<=1.01*kw['tolerance']
    np.testing.assert_array_equal(old.mass,mass);np.testing.assert_array_equal(old.enthalpy,heat)
    np.testing.assert_allclose(got['condensate'].mass+args[5]*got['wet_evaporation'],mass,rtol=0.,atol=1e-14)
    temperature_error=float(np.max(abs(np.r_[got['leaf_temperature'],got['ground_temperature']]-ref['temperature'])))
    assert temperature_error<=.05
    for key in ('h','le','gpp'):
        absolute,near=(.01,.1) if key=='gpp' else (1.,10.)
        assert abs(got[key]-ref[key])<=(absolute if abs(ref[key])<=near else .1*abs(ref[key]))
    print('saved Qia existing-water phase endpoint',dict(iterations=got['iterations'],
        maximum_solver_residual=float(np.max(abs(got['solver_residual']))),
        independent_temperature_error_K=temperature_error,
        independent_flux_absolute_differences={k:float(abs(got[k]-ref[k])) for k in ('h','le','gpp')}),flush=True)


@pytest.mark.parametrize('seed',['default','old-state','air'])
def test_exact_phase_kink_recovery_closes_qia1110_with_original_equations(seed):
    saved=saved_phase_call('qia_1110_phase_kink.json');args=saved['args'];kw=saved['kwargs']
    leaf,_,_,exchange,old,dt=args;mass=old.mass.copy();heat=old.enthalpy.copy()
    assert kw['tolerance']==1e-7 and kw['max_iterations']==80
    guess=None
    if seed!='default':
        coordinates=np.divide(heat,mass*4180.,out=np.full(10,exchange.air_temperature-273.15),where=mass>0.)
        if seed=='air':
            offset=exchange.air_temperature-273.15
            coordinates=np.where(mass>0.,offset*2100./4180. if offset<0. else 334000./4180.+offset,offset)
        guess=np.r_[coordinates,kw['fixed_ground_temperature'],exchange.specific_humidity*1000.]
    got=solve_canopy_phase_energy(*args,**kw,initial_guess=guess)
    ref=independent_reference(*args,**kw)
    assert got['iterations']<=80 and np.max(abs(got['solver_residual']))<=1e-7
    assert np.max(abs(got['layer_residual']))<=1.01e-7
    np.testing.assert_array_equal(old.mass,mass);np.testing.assert_array_equal(old.enthalpy,heat)
    np.testing.assert_allclose(got['condensate'].mass+dt*got['wet_evaporation'],mass,rtol=0.,atol=1e-14)
    temperature_error=float(np.max(abs(np.r_[got['leaf_temperature'],got['ground_temperature']]-ref['temperature'])))
    assert temperature_error<=.05
    for key in ('h','le','gpp'):
        absolute,near=(.01,.1) if key=='gpp' else (1.,10.)
        assert abs(got[key]-ref[key])<=(absolute if abs(ref[key])<=near else .1*abs(ref[key]))
    # Independently reconstruct advected mixed-phase parcel heat. The final
    # water/enthalpy stores and actual vapor mass are used, without the
    # production vapor-parcel or heat-residual helper.
    fraction=np.clip(got['phase_coordinates']*4180./334000.,0.,1.)
    offset=got['leaf_temperature']-273.15
    specific=(1.-fraction)*2100.*offset+fraction*(334000.+4180.*offset)
    advected=((mass-got['condensate'].mass)*specific).sum()/dt
    storage=(got['condensate'].enthalpy-heat).sum()/dt
    transpiration=got['transpiration']@(334000.+4180.*offset)-got['root_uptake']@kw['root_enthalpy']
    energy=got['rnet']-got['h']-got['le']-got['ground_heat']-storage-advected-transpiration
    assert abs(energy)<=11.*kw['tolerance']
    assert got['leaf_temperature'][0]<273.15 and got['leaf_temperature'][3]==273.15
    print('Qia1110 exact-kink recovery',seed,dict(iterations=got['iterations'],
        maximum_solver_residual=float(np.max(abs(got['solver_residual']))),independent_temperature_error_K=temperature_error,
        independent_energy_residual_Wm2=float(energy),independent_flux_absolute_differences={k:float(abs(got[k]-ref[k])) for k in ('h','le','gpp')}),flush=True)

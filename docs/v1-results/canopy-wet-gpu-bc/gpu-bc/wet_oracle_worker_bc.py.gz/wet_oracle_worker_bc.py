"""Use exact NumPy references calculated on EHPC; do not run forward physics here."""
from pathlib import Path
import copy,hashlib,json,os,pickle,runpy,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-canopy-wet-final-az';r=s/'gpu-bc';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items())
ref=r/'reference-evidence/canopy-wet-final-ba/references';receipt=json.loads((ref/'receipt.json').read_text());assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['keys']==188 and (ref.parent/'references-exit.txt').read_text().strip()=='0'
assert receipt['source_manifest_sha256']=='a60417e5ce8e220e8adf5a8fdf3a03244c3abb39242046de5ce5034743703e29'
assert all(m[n]==h for n,h in receipt['reference_model_and_test_bytes_sha256'].items())
assert sha(ref/'references.pkl')==receipt['reference_pickle_sha256']=='38b31c59baa3266fa08cd21b4cd0b6c5021e15b6a4346824425e10d9e6e2e4c8'
assert sha(r/'wet_reference_key_ap.py')=='1be6831c4f06fb34d6f9c94afee96fddae9656c5e8c1658dfc4f643d56420bd2'
sys.path.insert(0,str(r))
from wet_reference_key_ap import reference_key
cache=pickle.loads((ref/'references.pkl').read_bytes());assert len(cache)==188
file=Path(sys.argv[sys.argv.index('--test-file')+1]).stem
binding=dict(source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cache_sha256=sha(ref/'references.pkl'),reference_receipt_sha256=sha(ref/'receipt.json'),matching_model_and_test_bytes=len(receipt['reference_model_and_test_bytes_sha256']),scope='Exact inputdtype/shape/bytes plus leafparameters/MOSTextension/solvercontrol signature lookup. Missingkey is failure; no forwardphysics fallback. Original pytestnodes/assertions unmodified. Hostpacking and independent budget audits allowed.')
(r/(file+'-oracle-binding.json')).write_text(json.dumps(binding,indent=2)+'\n')
def lookup(family,row,kwargs):
    key=reference_key(family,tuple(row),kwargs);assert key in cache,(family,key)
    with (r/(file+'-oracle-requests.jsonl')).open('a') as stream:stream.write(json.dumps(dict(family=family,key=key))+'\n');stream.flush()
    return copy.deepcopy(cache[key])
def blocked(*args,**kwargs):raise AssertionError('NumPy forward references must execute on EHPC compute nodes')
if file=='test_gpu_canopy_interception':
    import test_gpu_canopy_interception as module
    module.reference=lambda row:lookup('water',row,{})
    module.intercept_precipitation=blocked;module.exchange_vapor=blocked
elif file=='test_gpu_canopy_phase_energy':
    import test_gpu_canopy_phase_energy as module
    module.reference=lambda row,**kwargs:lookup('phase',row,kwargs)
    module.solve_canopy_phase_energy=blocked
else:raise AssertionError(file)
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
runpy.run_path(str(worker),run_name='__main__')

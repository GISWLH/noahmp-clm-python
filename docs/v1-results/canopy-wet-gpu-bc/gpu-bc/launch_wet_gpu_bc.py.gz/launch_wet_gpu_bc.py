from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-canopy-wet-final-az';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-canopy-wet-final-az-source.tar.gz';package=json.loads((b/'clm-canopy-wet-final-az-package.json').read_text());assert sha(a)==package['archive_sha256'];assert not s.exists();s.mkdir()
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and all(sha(s/n)==h for n,h in m.items()) and sha(s/'SOURCE_SHA256.json')==package['manifest_sha256']
prereq=json.loads((b/'canopy-wet-final-ar-full-receipt.json').read_text());assert prereq['returncode']==0 and prereq['source_unchanged'] and prereq['counts']==dict(tests=1091,failures=0,errors=0,skipped=0) and prereq['source_manifest_sha256']=='f7af9317a8f49f20d8469b5a09813cee563ffe4c331099d76dc0f1e24164a324'
r=s/'gpu-bc';r.mkdir();(r/'numpy-first-full-receipt.json').write_bytes((b/'canopy-wet-final-ar-full-receipt.json').read_bytes());archive=b/'canopy-wet-references-bb-evidence.tar.gz';assert sha(archive)=='d485cb8d8f6bc57d177018c12c96f8ac02076c0510d1381e01f9b55de6704556';ref=r/'reference-evidence';ref.mkdir()
with tarfile.open(archive) as tf:tf.extractall(ref,filter='data')
controls={}
for name in ['collect_wet_gpu_bc.py','wet_oracle_worker_bc.py','control_wet_gpu_bc.py','wet_reference_key_ap.py',Path(__file__).name]:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=sha(r/name)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',NOAHMP_QIA1110_DIAGNOSTICS=str(r/'raw300-diagnostics'))
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'control_wet_gpu_bc.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls,scope='xuanze wetarea.05 originalmodule18, correctedoldhumiditydirectexpectation plus actualEHPC382 recoverytarget4 lifecycle; no pass until actualparentterminal. Original years/sourceC untouched. NumPyreferences fromEHPC, GPU0 resources8GiB/host32GiB unchanged.')
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

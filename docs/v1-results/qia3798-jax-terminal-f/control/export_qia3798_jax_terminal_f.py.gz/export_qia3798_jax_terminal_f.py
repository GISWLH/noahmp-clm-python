from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1'); r = b / 'qia-cuda-3798-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
exit = json.loads((r / 'general-edge-jax-exit-f.json').read_text())
ja = json.loads((r / 'general-edge-jax-f/receipt.json').read_text()); cu = json.loads((r / 'general-edge-f/receipt.json').read_text())
assert exit['actual_returncode'] == 0 and exit['receipt_sha256'] == sha(r / 'general-edge-jax-f/receipt.json')
assert ja['failure'] is cu['failure'] is None and ja['source_unchanged'] and ja['device_barrier_complete']
for name in ['output.npz', 'state.npz']:
    assert (r / 'general-edge-jax-f' / name).read_bytes() == (r / 'general-edge-f' / name).read_bytes()
with tarfile.open(b / 'qia3798-jax-launch-f-evidence.tar.gz') as t:
    launch = json.load(t.extractfile('summary.json'))
for name, digest in launch['controls_sha256'].items():
    assert sha(b / name) == digest
a = b / 'qia3798-jax-terminal-f-evidence.tar.gz'; assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for name in ['input.npz', 'binding.json', 'general-edge-jax-launch-f.json', 'general-edge-jax-worker-f.json', 'general-edge-jax-exit-f.json', 'general-edge-jax-f.log', 'general-edge-jax-controller-f.log']:
        t.add(r / name, arcname=name, recursive=False)
    for folder in ['general-edge-jax-f', 'general-edge-f']:
        for p in sorted((r / folder).iterdir()):
            if p.is_file():
                t.add(p, arcname=folder + '/' + p.name, recursive=False)
    for name in [*launch['controls_sha256'], 'export_qia3798_jax_terminal_f.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    record = dict(scope='Actual original3798 all-phase-edge F JAXworker/controller0,explicitbarrier/source/inputguard;every361raw output and19next-state file byte-exact CUDA F. Originalfailedyear untouched,no canonical/current-source/year/science acceptance;independent original MHCN/1e-6 array audits follow on EHPC.',
                  actual_jax_returncode=0, seconds=exit['seconds'], output_npz_byte_exact=True, state_npz_byte_exact=True, output_sha256=ja['result']['output_sha256'], state_sha256=ja['result']['state_sha256'],
                  source_manifest_sha256=ja['source_manifest_sha256'], input_sha256=ja['input_sha256'], original_launch_controls_unchanged=True)
    raw = (json.dumps(record, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

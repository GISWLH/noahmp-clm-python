"""Candidate solver recovery in-process; frozen production files are untouched."""
from pathlib import Path
import json,traceback,hashlib
import numpy as np
import cupy as cp
import run_fluxnet_native as runner
import noahmp_clm.gpu.canopy_most_surface as module
from noahmp_clm.gpu.cuda.clm_bgc_column import step_clm_bgc_columns_cuda
from noahmp_clm.physics.photosynthesis import LeafParameters

root=Path(__file__).resolve().parent
source=Path(module.__file__).read_text()
needle="        next_zeta=xp.where(stable_bracket,.5*(lower+upper),.5*(zeta+feedback['zeta']))"
assert source.count(needle)==1
replacement="""        stalled=stable_bracket&(~done)&(.5*(lower+upper)==zeta)
        stable_bracket=stable_bracket&(~stalled)
        next_zeta=xp.where(stable_bracket,.5*(lower+upper),.5*(zeta+feedback['zeta']))"""
candidate=source.replace(needle,replacement)
(root/'failure-replay/most-restart-candidate-a.py').write_text(candidate)
namespace={};exec(compile(candidate,'most-restart-candidate-a.py','exec'),namespace)
module.run_most_surface=namespace['run_most_surface']
results=[]
for case in ['qia-nominal-uniform','qia-stas4-uniform','qia-nominal-deep-fc','qia-stas4-deep-fc']:
    with np.load(root/'failure-replay'/(case+'-oldstate.npz')) as z:data=dict(z)
    a=tuple(data[f'a{k}'] for k in range(16));f=data['forcing']
    row=dict(case=case)
    try:
        out=runner.Backend('cuda32').host(step_clm_bgc_columns_cuda(*a,f,environment=data['environment'],
            calendar=data['calendar'],most_geometry=data['geometry'],return_surface=True))
        most=out['surface']['most'];row.update(status='complete',h=float(out['diagnostics']['h'][0]),
            le=float(out['diagnostics']['le'][0]),iterations=int(most['iterations'][0]),
            coefficient_residual=float(most['coefficient_residual'][0]),used_zeta=float(most['used_zeta'][0]))
        after=tuple(runner.Backend('cuda32').host(v) for v in runner.next_bgc_arrays(tuple(cp.asarray(v) for v in a),out))
        incoming,residual,bound,tracer=runner.audit_step(a,after,f,np.zeros((1,5)),np.zeros(1),out)
        row.update(residual_m_h_c_n=residual.tolist(),bounds_m_h_c_n=bound.tolist())
    except Exception:row.update(status='failed',failure=traceback.format_exc())
    results.append(row);print(json.dumps(row),flush=True)
runner.atomic_json(root/'failure-replay/most-restart-a.json',dict(candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),cases=results))

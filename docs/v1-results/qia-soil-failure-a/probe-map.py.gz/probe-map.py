"""Read-only parameterized surface evaluations around failed MOST root."""
from pathlib import Path
import json
import numpy as np
import cupy as cp
import run_fluxnet_native as runner
from noahmp_clm.gpu.cuda.canopy_most import run_canopy_most_cuda as coeff
from noahmp_clm.gpu.cuda.canopy_phase_surface import run_canopy_phase_surface_cuda as solve
from noahmp_clm.gpu.vic import column_vic

root=Path(__file__).resolve().parent;case='qia-nominal-deep-fc'
with np.load(root/'failure-replay'/(case+'-surface.npz')) as z: source=dict(z)
with np.load(root/'failure-replay'/(case+'-oldstate.npz')) as z: old=dict(z)
center=np.float32(1.8753669261932373)
zeta=np.r_[np.linspace(0,2,33),np.linspace(1.87,1.885,121),
    center+np.arange(-32,33)*np.spacing(center)].astype(np.float32)
n=len(zeta)
a=tuple(cp.asarray(np.repeat(source[f's{k}'],n,axis=0)) for k in range(9));u=a[5]
g=cp.asarray(np.repeat(source['geometry'],n,axis=0));wind=cp.asarray(np.repeat(source['wind'],n))
state=cp.stack((cp.asarray(zeta),cp.ones(n,cp.float32),cp.full(n,float(source['leaf_dimension'][0]),cp.float32),
               cp.full(n,float(source['plant_area'][0]),cp.float32)),axis=1)
zero=cp.zeros(n,cp.float32);atm=cp.stack((u[:,0],u[:,1],u[:,2],wind,zero,zero,zero+.2),axis=1)
current=coeff(g,atm,state)
trial=cp.concatenate((u[:,:3],cp.stack((current['heat_velocity'],current['ground_velocity'],current['leaf_velocity']),axis=1),u[:,6:]),axis=1)
extra=cp.stack((current['water_velocity'],current['potential_temperature']),axis=1)
vic=column_vic(cp.asarray(np.repeat(old['a3'],n,axis=0)),cp.float32,cp,None)
out=solve(*a[:5],trial,*a[6:],exchange_extension=extra,vic=vic,raise_on_failure=False)
vapor=out['et_kgm2']/a[7][:,0]
atm=cp.stack((u[:,0],u[:,1],u[:,2],wind,out['h'],vapor,current['friction_velocity']),axis=1)
feedback=coeff(g,atm,state)
target_state=cp.stack((feedback['zeta'],feedback['effective_wind'],state[:,2],state[:,3]),axis=1)
target=coeff(g,atm,target_state)
names=('friction_velocity','heat_velocity','water_velocity','leaf_velocity','ground_velocity')
mismatch=cp.max(cp.stack([cp.abs(target[k]-current[k])/current[k] for k in names],axis=1),axis=1)
result=dict(zeta=zeta,target_zeta=cp.asnumpy(feedback['zeta']),h=cp.asnumpy(out['h']),
    le=cp.asnumpy(out['le']),vapor=cp.asnumpy(vapor),coefficient_residual=cp.asnumpy(mismatch),
    converged=cp.asnumpy(out['converged']),max_solver_residual=cp.asnumpy(out['max_solver_residual']),
    leaf_temperature=cp.asnumpy(out['leaf_temperature']))
runner.write_npz(root/'failure-replay/most-map-a.npz',**result)
valid=np.isfinite(result['coefficient_residual'])&(result['converged']>0)
best=np.flatnonzero(valid)[np.argsort(result['coefficient_residual'][valid])[:12]]
summary=dict(points=n,converged=int(valid.sum()),within_original_coefficient_gate=int((valid&(result['coefficient_residual']<=1e-4)).sum()),
    best=[{key:float(value[i]) for key,value in result.items() if value.ndim==1} for i in best])
runner.atomic_json(root/'failure-replay/most-map-a.json',summary);print(json.dumps(summary,indent=2),flush=True)

"""Replay every failed-batch column from its exact last committed state."""
from pathlib import Path
from dataclasses import astuple
import json,traceback,time
import numpy as np
import cupy as cp
import run_fluxnet_native as runner
from noahmp_clm.gpu.cuda.clm_bgc_column import step_clm_bgc_columns_cuda
from noahmp_clm.gpu.clm_bgc_column import pack_bgc_environment
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
from test_gpu_clm_bgc_column import reference
import noahmp_clm.gpu.cuda.canopy_most as cm
import noahmp_clm.gpu.canopy_most_surface as surface
import noahmp_clm.physics.canopy_most as nm

root=Path(__file__).resolve().parent
batch=json.loads((root/'native-run/batch.json').read_text());i=batch['steps_completed']
assert batch['status']=='failed'
cases=runner.load_batch(root/'batch.json')
with np.load(root/'native-run'/batch['checkpoint_file'],allow_pickle=False) as z:
    arrays=tuple(z[f'a{k}'] for k in range(16))
out=root/'failure-replay';out.mkdir(exist_ok=False)
original_coeff=cm.run_canopy_most_cuda;original_surface=surface.run_most_surface
original_stability=nm.flux_stability
results=[]
for k,c in enumerate(cases):
    case=c['case'];print('begin',case,flush=True)
    a=tuple(v[k:k+1].copy() for v in arrays);a[4][:,7:10]=c['data']['environment'][i]
    f=np.asarray(c['data']['forcing'][i:i+1],np.float32)
    e,cal=pack_bgc_environment([runner.calendar(c['stamps'][i],c['metadata'],c['config']['phenology'] is not None)],dtype=np.float32)
    geometry=np.asarray([astuple(MOSTGeometry(**c['config']['most_geometry']))],np.float32)
    record=dict(case=case,step_index=i,time_start=str(c['data']['time_start'][i]),cuda_coefficients=[],numpy_flux_feedback=[])
    def coeff(g,atm,state):
        result=original_coeff(g,atm,state)
        record['cuda_coefficients'].append(dict(atmosphere=cp.asnumpy(atm).tolist(),state=cp.asnumpy(state).tolist(),
            coefficients={key:cp.asnumpy(value).tolist() for key,value in result.items()}))
        return result
    def capture(values,*args,**kwargs):
        runner.write_npz(out/(case+'-surface.npz'),**{f's{k}':cp.asnumpy(v) for k,v in enumerate(values)},
            geometry=geometry,wind=f[:,3],leaf_dimension=cp.asnumpy(args[2]),plant_area=cp.asnumpy(args[3]))
        return original_surface(values,*args,**kwargs)
    def flux(*args,**kwargs):
        result=original_stability(*args,**kwargs)
        record['numpy_flux_feedback'].append(dict(atmosphere=list(map(float,args[:7])),feedback=result))
        return result
    cm.run_canopy_most_cuda=coeff;surface.run_most_surface=capture;nm.flux_stability=flux
    runner.write_npz(out/(case+'-oldstate.npz'),**{f'a{k}':v for k,v in enumerate(a)},forcing=f,environment=e,calendar=cal,geometry=geometry)
    try:
        got=runner.Backend('cuda32').host(step_clm_bgc_columns_cuda(*a,f,environment=e,calendar=cal,
            most_geometry=geometry,return_surface=True,leaf_parameters=LeafParameters(**c['config']['leaf_parameters'])))
        record['cuda']=dict(status='complete',h=float(got['diagnostics']['h'][0]),le=float(got['diagnostics']['le'][0]),
            iterations=int(got['surface']['most']['iterations'][0]),coefficient_residual=float(got['surface']['most']['coefficient_residual'][0]))
    except Exception:record['cuda']=dict(status='failed',error=traceback.format_exc())
    cm.run_canopy_most_cuda=original_coeff;surface.run_most_surface=original_surface
    print('cuda',case,record['cuda'],flush=True)
    try:
        ref=reference(tuple(v[0] for v in a),f[0],np.zeros(5),e[0],cal[0],0.,1.,most_geometry=MOSTGeometry(*map(float,geometry[0])))
        most=ref['diagnostics']['most']
        record['numpy']=dict(status='complete',h=ref['diagnostics']['h'],le=ref['diagnostics']['le'],
            most=most)
    except Exception:record['numpy']=dict(status='failed',error=traceback.format_exc())
    nm.flux_stability=original_stability
    runner.atomic_json(out/(case+'.json'),record);results.append(record)
    print('numpy',case,{key:value for key,value in record['numpy'].items() if key!='most'},flush=True)
runner.atomic_json(out/'summary.json',dict(step_index=i,cases=[dict(case=r['case'],cuda=r['cuda'],numpy={k:v for k,v in r['numpy'].items() if k!='most'}) for r in results]))

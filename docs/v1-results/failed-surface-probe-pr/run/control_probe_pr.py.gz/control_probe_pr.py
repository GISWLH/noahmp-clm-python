"""Bound one isolated child and preserve its actual nonzero failure exit."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from probe_surface_pr import sha, write_json


def main():
    root = Path(__file__).resolve().parent
    plan = json.loads((root / 'PLAN.json').read_text())
    deadline = time.monotonic() + plan['resource_wait_seconds']
    available = None
    while time.monotonic() < deadline:
        fields = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=index,uuid,memory.free',
                                          '--format=csv,noheader,nounits'], text=True).strip().split(',')
        assert fields[0].strip() == '1' and fields[1].strip() == plan['gpu_uuid']
        memory = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
        available = {'gpu_free_mib': int(fields[2]), 'host_available_kib': memory}
        if available['gpu_free_mib'] >= plan['minimum_gpu_free_mib'] and memory >= plan['minimum_host_available_kib']:
            break
        time.sleep(5)
    else:
        write_json(root / 'exit.json', dict(child_started=False, actual_parent_returncode=None,
                   controller_failure='Resource deadline expired', last_available=available, physical_calls=0))
        return 2
    with (root / 'worker.log').open('x') as log:
        child = subprocess.Popen([sys.executable, '-B', '-u', str(root / 'probe_surface_pr.py')],
                                 cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
        write_json(root / 'worker.json', dict(pid=child.pid, controller_pid=os.getpid(),
                   process_start_ticks=Path('/proc/' + str(child.pid) + '/stat').read_text().split(') ', 1)[1].split()[19],
                   available_at_start=available))
        timeout = False
        try:
            code = child.wait(timeout=plan['worker_timeout_seconds'])
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait()
    path = root / 'result/receipt.json'
    receipt = json.loads(path.read_text()) if path.exists() else {}
    captured = bool(code == 1 and not timeout and receipt.get('original_failure_reproduced') and
                    receipt.get('complete_failed_surface_capture') and receipt.get('actual_batch_step_calls') == 1 and
                    receipt.get('completed_physical_steps') == 0 and receipt.get('after_immutable', {}).get('unchanged') and
                    receipt.get('device_barrier_error') is None)
    write_json(root / 'exit.json', dict(child_started=True, actual_parent_returncode=code,
               timed_out=timeout, diagnostic_capture_complete=captured, model_call_passed=False,
               receipt_sha256=sha(path) if path.exists() else None,
               scope='Expected original RuntimeError remains actual child exit1; diagnostic capture is separate from model success.'))
    return 1 if code == 1 else 2  # Never turn the original failing call into an exit0.


if __name__ == '__main__':
    raise SystemExit(main())

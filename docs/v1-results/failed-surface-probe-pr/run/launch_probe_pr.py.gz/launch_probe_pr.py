"""Explicit root-reviewed future launcher; never run during preparation."""
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile
from probe_surface_pr import sha, write_json


def extract_checked(archive, destination):
    with tarfile.open(archive) as stream:
        members = stream.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
        stream.extractall(destination, filter='data')


def main():
    prepared = Path(__file__).resolve().parent
    plan = json.loads((prepared / 'PLAN.json').read_text())
    controls = json.loads((prepared / 'CONTROLS_SHA256.json').read_text())
    assert all(sha(prepared / name) == digest for name, digest in controls.items())
    root, temporary = Path(plan['root']), Path(plan['temporary'])
    assert not root.exists() and not temporary.exists()
    pq = Path(plan['parent_PQ_archive'])
    assert sha(pq) == plan['parent_PQ_sha256']
    root.mkdir()
    temporary.mkdir()
    evidence, source = temporary / 'evidence', temporary / 'source'
    evidence.mkdir()
    extract_checked(pq, evidence)
    inventory = json.loads((evidence / 'INVENTORY.json').read_text())
    assert len(inventory) == 657
    assert all(sha(evidence / name) == item['sha256'] for name, item in inventory.items())
    source_archive = evidence / 'source/candidate-source.tar.gz'
    assert sha(source_archive) == plan['source_archive_sha256']
    source.mkdir()
    extract_checked(source_archive, source)
    assert sha(source / 'SOURCE_SHA256.json') == plan['source_manifest_sha256']
    sources = json.loads((source / 'SOURCE_SHA256.json').read_text())
    assert len(sources) == 584 and all(sha(source / name) == digest for name, digest in sources.items())
    for name in controls:
        shutil.copyfile(prepared / name, root / name)
    shutil.copyfile(prepared / 'CONTROLS_SHA256.json', root / 'CONTROLS_SHA256.json')
    immutable = {str(evidence / name): item['sha256'] for name, item in inventory.items()}
    immutable.update({str(source / name): digest for name, digest in sources.items()})
    immutable.update({str(root / name): digest for name, digest in controls.items()})
    immutable.update({str(pq): plan['parent_PQ_sha256'], str(source / 'SOURCE_SHA256.json'): plan['source_manifest_sha256'],
                      str(evidence / 'INVENTORY.json'): sha(evidence / 'INVENTORY.json'),
                      str(root / 'CONTROLS_SHA256.json'): sha(root / 'CONTROLS_SHA256.json')})
    write_json(root / 'IMMUTABLE_SHA256.json', immutable)
    env = os.environ.copy()
    env.pop('LD_LIBRARY_PATH', None)
    env.update(PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=plan['gpu_uuid'], CUDA_PATH='/usr/local/cuda-12.4',
               PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', CUPY_CACHE_DIR=str(temporary / 'cupy-cache'),
               CUDA_CACHE_PATH=str(temporary / 'cuda-cache'), JAX_COMPILATION_CACHE_DIR=str(temporary / 'unused-jax-cache'),
               JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false')
    env.update({name: '1' for name in plan['single_thread_environment']})
    launch = dict(source=str(source), evidence=str(evidence), parent_PQ_sha256=plan['parent_PQ_sha256'],
                  source_manifest_sha256=plan['source_manifest_sha256'], controls_manifest_sha256=sha(root / 'CONTROLS_SHA256.json'),
                  physical_gpu_index=1, physical_gpu_uuid=plan['gpu_uuid'],
                  scope='Isolated one-call diagnostic only; original NS/NZ/NQ and all original evidence remain untouched.')
    write_json(root / 'launch.json', launch)
    with (root / 'controller.log').open('x') as log:
        child = subprocess.Popen([sys.executable, '-B', '-u', str(root / 'control_probe_pr.py')],
                                 cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
    launch['pid'] = child.pid
    write_json(root / 'launch.json', launch)
    print(json.dumps(launch), flush=True)


if __name__ == '__main__':
    main()

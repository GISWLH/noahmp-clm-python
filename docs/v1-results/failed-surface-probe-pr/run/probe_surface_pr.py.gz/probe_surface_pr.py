"""One isolated original NZ batch call; observe, never resume a trajectory."""
from dataclasses import astuple, fields, is_dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
import time
import traceback


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def construct_request(native, np, cases, saved, identity):
    """Native run setup and index-specific kwargs; no constructor or forward call."""
    dtype = np.float32
    hydrology = native.batch_hydrology(cases)
    state_count = native.native_state_count(cases)
    assert state_count == 16 and identity.get('native_state_arrays', 16) == 16
    leaf = native.LeafParameters(**cases[0]['config']['leaf_parameters'])
    optics = None
    if any(c['config'].get('canopy_optics') is not None for c in cases):
        from noahmp_clm.physics.canopy_optics import CanopyOptics
        from noahmp_clm.gpu.canopy_optics import pack_canopy_optics
        optics = np.stack([pack_canopy_optics(CanopyOptics(**(c['config'].get('canopy_optics') or {})), dtype) for c in cases])
    geometry = np.asarray([astuple(native.MOSTGeometry(**c['config']['most_geometry'])) for c in cases], dtype)
    deposition_schedules = [native.DepositionSchedule(c['config']) for c in cases]
    nrates = np.asarray([d.nitrogen_rate for d in deposition_schedules], dtype)
    index = int(saved['index'])
    assert index == 7275
    a = native.checkpoint_arrays(saved, identity)
    f = np.asarray([c['data']['forcing'][index] for c in cases], dtype)
    env = np.asarray([c['data']['environment'][index] for c in cases], dtype)
    e, cal = native.pack_bgc_environment([native.calendar(c['stamps'][index], c['metadata'], c['config']['phenology'] is not None)
                                        for c in cases], dtype=dtype)
    nitrogen = nrates*f[:, 0]
    deposition = np.asarray([d.aerosol(c['stamps'][index], f[k, 0])
                             for k, (c, d) in enumerate(zip(cases, deposition_schedules))], dtype)
    kwargs = dict(environment=e, calendar=cal, nitrogen_deposition_gn_m2=nitrogen,
                  deposition=deposition, most_geometry=geometry, leaf_parameters=leaf, return_surface=True)
    if optics is not None:
        kwargs['canopy_optics'] = optics
    if hydrology is not None:
        kwargs['soil_hydrology'] = hydrology
    return a, f, env, kwargs


def main():
    root = Path(__file__).resolve().parent
    launch = json.loads((root / 'launch.json').read_text())
    plan = json.loads((root / 'PLAN.json').read_text())
    source, evidence = Path(launch['source']), Path(launch['evidence'])
    output = root / 'result'
    output.mkdir()
    immutable = json.loads((root / 'IMMUTABLE_SHA256.json').read_text())

    def verify_immutable():
        mismatches = [name for name, digest in immutable.items() if sha(name) != digest]
        return {'checked_files': len(immutable), 'mismatches': mismatches, 'unchanged': not mismatches}

    before_proof = verify_immutable()
    assert before_proof['unchanged']
    assert os.environ['CUDA_VISIBLE_DEVICES'] == plan['gpu_uuid']
    assert all(os.environ[name] == '1' for name in plan['single_thread_environment'])
    sys.path[:0] = [str(source), str(source / 'src'), str(source / 'benchmarks')]
    import numpy as np
    import cupy as cp
    import run_fluxnet_native as native
    import noahmp_clm.gpu.cuda.canopy_phase_surface as phase_surface
    assert cp.cuda.runtime.getDeviceCount() == 1
    assert str(Path(native.__file__).resolve()).startswith(str(source.resolve()) + '/')
    assert str(Path(phase_surface.__file__).resolve()).startswith(str(source.resolve()) + '/')
    current = evidence / 'NZ/current'
    report = json.loads((current / 'trajectory/batch.json').read_text())
    identity = report['identity']
    assert report['status'] == 'failed' and report['steps_completed'] == report['failed_step'] == 7275
    assert report['steps_requested'] == 17520 and report['columns'] == 3
    assert identity['backend'] == 'cuda32' and identity['compare_jax32'] is False
    assert native.source_hashes() == identity['source_sha256']
    checkpoint = current / 'trajectory' / report['checkpoint_file']
    assert PurePosixPath(report['checkpoint_file']).name == report['checkpoint_file']
    assert checkpoint.resolve().parent == (current / 'trajectory').resolve()
    assert sha(checkpoint) == report['checkpoint_sha256'] == plan['checkpoint_sha256']
    with np.load(checkpoint, allow_pickle=False) as stream:
        saved = dict(stream)
    assert set(saved) == {f'a{k}' for k in range(16)} | {'index', 'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax'}
    batch = current / 'inputs/batch.json'
    # Refuse absolute or escaping paths before native.load_batch can resolve any.
    for row in json.loads(batch.read_text())['cases']:
        for key in ('input', 'input_manifest', 'configuration'):
            path = PurePosixPath(row[key])
            assert not path.is_absolute() and '..' not in path.parts
            assert (batch.parent / row[key]).resolve().is_relative_to(batch.parent.resolve())
    cases = native.load_batch(batch)
    actual_identity = [dict(case=c['case'], forcing_npz_sha256=sha(c['paths']['input']),
                           forcing_manifest_sha256=sha(c['paths']['input_manifest']),
                           configuration_sha256=sha(c['paths']['configuration'])) for c in cases]
    assert len(cases) == 3 and sha(batch) == identity['batch_sha256']
    assert actual_identity == identity['cases'] and [c['case'] for c in cases] == plan['cases']
    assert all(c['config'].get('canopy_optics') is None for c in cases)
    a, f, env, kwargs = construct_request(native, np, cases, saved, identity)
    engine = native.Backend('cuda32')

    def capture(path, value, metadata=None):
        """Encode every leaf without promoting arrays or executing reference physics."""
        arrays = {}

        def encode(v, key):
            if isinstance(v, cp.ndarray):
                v = cp.asnumpy(v)
            if isinstance(v, (np.ndarray, np.generic)):
                host = np.asarray(v).copy(order='C')
                assert host.dtype.kind != 'O'
                arrays[key] = host
                return {'kind': 'array', 'key': key, 'dtype': host.dtype.str, 'shape': list(host.shape),
                        'c_order_sha256': hashlib.sha256(host.tobytes(order='C')).hexdigest()}
            if is_dataclass(v):
                return {'kind': 'dataclass', 'module': type(v).__module__, 'class': type(v).__name__,
                        'fields': {field.name: encode(getattr(v, field.name), key + '/' + field.name) for field in fields(v)}}
            if isinstance(v, dict):
                return {'kind': 'dict', 'items': {k: encode(item, key + '/' + k) for k, item in v.items()}}
            if isinstance(v, (tuple, list)):
                return {'kind': type(v).__name__, 'items': [encode(item, key + '/' + str(k)) for k, item in enumerate(v)]}
            if v is None or type(v) in (str, bool, int):
                return {'kind': type(v).__name__, 'value': v}
            if type(v) is float:
                return {'kind': 'float', 'hex': v.hex(), 'value': v if np.isfinite(v) else None}
            raise TypeError('Unrecorded diagnostic leaf type: ' + str(type(v)))

        tree = encode(value, 'value')
        path = Path(path)
        assert not path.with_suffix('.npz').exists() and not path.with_suffix('.json').exists()
        np.savez_compressed(path.with_suffix('.npz'), **arrays)
        write_json(path.with_suffix('.json'), dict(schema='PR-typed-tree-v1', tree=tree,
                   array_count=len(arrays), npz_sha256=sha(path.with_suffix('.npz')), metadata=metadata))
        return {'json_sha256': sha(path.with_suffix('.json')), 'npz_sha256': sha(path.with_suffix('.npz'))}

    context = {'origin': 'New PR reconstruction from original failed7275 checkpoint; original failed pre-forward packet did not exist.',
               'cases': plan['cases'], 'input_index_zero_based': 7275,
               'time_start': [str(c['data']['time_start'][7275]) for c in cases],
               'time_end': [str(c['data']['time_end'][7275]) for c in cases],
               'canopy_optics': None, 'canopy_optics_scope': 'All three fixed original configurations have no optics extension.',
               'checkpoint_sha256': sha(checkpoint), 'source_manifest_sha256': plan['source_manifest_sha256']}
    capture(output / 'reconstructed-request', dict(state=a, forcing=f, environment=env, kwargs=kwargs,
             original_global_ledger={k: saved[k] for k in ('index', 'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax')}), context)
    device = tuple(engine.xp.asarray(v) for v in a)
    before_device = engine.update_forcing(device, env)
    capture(output / 'before-engine-step', dict(args=(*before_device, f), kwargs=kwargs, environment=env), context)

    original_solve = phase_surface.run_canopy_phase_surface_cuda
    original_unpack = phase_surface.unpack_phase_surface
    original_kernel = phase_surface._kernel
    records, active = [], None
    expected = plan['expected_exception_message']
    step_attempts = step_returns = 0
    failure = None
    started = time.monotonic()

    def observe_unpack(raw):
        assert active is not None and raw.shape == (3, 741)
        capture(active['folder'] / 'raw-output', dict(raw741=raw), {'surface_call': active['call']})
        result = original_unpack(raw)
        capture(active['folder'] / 'result-flags', {key: result[key] for key in (
            'converged', 'canopy_converged', 'surface_temperature', 'surface_temperature_residual',
            'surface_root_bracket_k', 'surface_evaluations', 'max_solver_residual', 'restarts',
            'thermal_layer_residual', 'thermal_layer_tolerance', 'phase_coordinates')})
        mask = cp.isfinite(raw)
        active['raw_output_captured'] = True
        active['nonfinite_indices'] = cp.asnumpy(cp.argwhere(~mask)).tolist()
        active['final_converged'] = cp.asnumpy(result['converged']).tolist()
        active['canopy_converged'] = cp.asnumpy(result['canopy_converged']).tolist()
        return result

    def observe_kernel(extended=False, vic=False, stems=False, profiled=False):
        kernel = original_kernel(extended, vic, stems, profiled)

        def launch_kernel(grid, block, arguments):
            assert active is not None
            active['kernel_launches'] += 1
            assert active['kernel_launches'] == 1
            assert arguments[-2].shape == (3, 741)
            # Exclude only uninitialized output. Preserve actual encoded inputs,
            # including coefficients and radiation after all original preparation.
            capture(active['folder'] / 'kernel-input', dict(arguments_without_output=(*arguments[:-2], arguments[-1])),
                    {'flags': dict(extended=extended, vic=vic, stems=stems, profiled=profiled),
                     'grid': grid, 'block': block, 'original_argument_count': len(arguments),
                     'original_tail_indices': {'radiation': -5, 'coefficients': -4, 'aging': -3, 'excluded_output': -2, 'n': -1},
                     'base_array_indices': list(range(9)), 'scope': 'Actual kernel arguments; no recast or regenerated coefficients.'})
            return kernel(grid, block, arguments)

        return launch_kernel

    def observe_solve(*args, **kw):
        nonlocal active
        assert active is None and len(args) == 9
        assert kw.get('raise_on_failure', True) is True
        call = len(records) + 1
        assert call <= 51  # Original50 MOST calls plus at most one validation call.
        folder = output / 'surface' / ('call-' + str(call).zfill(4))
        folder.mkdir(parents=True)
        frame = sys._getframe(1)
        caller = {'file': str(Path(frame.f_code.co_filename).relative_to(source)),
                  'line': frame.f_lineno, 'function': frame.f_code.co_name,
                  'most_iteration': frame.f_locals.get('count')}
        assert caller['function'] == 'run_most_surface' and type(caller['most_iteration']) is int
        active = {'call': call, 'folder': folder, 'caller': caller, 'kernel_launches': 0,
                  'raw_output_captured': False, 'original_exception': None, 'returned': False}
        capture(folder / 'input', dict(args=args, kwargs=kw), {**context, 'call': call, 'caller': caller,
                'default_raise_on_failure': True, 'argument_names': ['snow', 'soil', 'soil_parameters', 'options',
                    'leaf_area', 'environment', 'layer_factors', 'boundary', 'condensate']})
        try:
            result = original_solve(*args, **kw)
            active['returned'] = True
            return result
        except BaseException as error:
            active['original_exception'] = {'type': type(error).__name__, 'message': str(error)}
            (folder / 'traceback.txt').write_text(traceback.format_exc())
            raise
        finally:
            item = {k: v for k, v in active.items() if k != 'folder'}
            write_json(folder / 'call.json', item)
            records.append(item)
            active = None

    phase_surface.run_canopy_phase_surface_cuda = observe_solve
    phase_surface.unpack_phase_surface = observe_unpack
    phase_surface._kernel = observe_kernel
    try:
        step_attempts += 1
        result = engine.step(*before_device, f, **kwargs)
        step_returns += 1
        capture(output / 'unexpected-success-output', result)
        raise AssertionError('Original failure did not reproduce; no state or trajectory was advanced')
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
        (output / 'traceback.txt').write_text(traceback.format_exc())
        raise
    finally:
        phase_surface.run_canopy_phase_surface_cuda = original_solve
        phase_surface.unpack_phase_surface = original_unpack
        phase_surface._kernel = original_kernel
        barrier_error = None
        try:
            cp.cuda.runtime.deviceSynchronize()
        except BaseException as error:
            barrier_error = {'type': type(error).__name__, 'message': str(error)}
        after_proof = verify_immutable()
        reproduced = failure == {'type': 'RuntimeError', 'message': expected}
        captured = bool(records and records[-1]['raw_output_captured'] and records[-1]['kernel_launches'] == 1)
        receipt = dict(source_manifest_sha256=plan['source_manifest_sha256'], parent_PQ_sha256=plan['parent_PQ_sha256'],
                       actual_batch_step_calls=step_attempts, actual_batch_step_returns=step_returns,
                       actual_column_attempts=3 * step_attempts, completed_physical_steps=step_returns,
                       column_steps_returned=3 * step_returns, trajectory_steps_committed=0,
                       original_failure_reproduced=reproduced, original_failure=failure,
                       complete_failed_surface_capture=captured, calls=records,
                       before_immutable=before_proof, after_immutable=after_proof, device_barrier_error=barrier_error,
                       seconds=time.monotonic()-started,
                       scope='One reconstructed NZ3 GPU call, original exception re-raised; no native.run, cold initialization, NumPy physics, year continuation or changed gates. Capture is new actual PR input, not an originally saved failed packet.')
        write_json(output / 'receipt.json', receipt)
        print(json.dumps(receipt, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()

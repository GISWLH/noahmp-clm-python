"""Remote stdlib-only closure of the stopped single-call PR diagnostic."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/lhwang/work/noahmp-v1/failed-surface-probe-pr')
OUT = Path('/tmp/noahmp-failed-surface-probe-pr-export')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists()
    launch = json.loads((ROOT / 'launch.json').read_bytes())
    result = json.loads((ROOT / 'exit.json').read_bytes())
    worker_path = ROOT / 'worker.json'
    worker = json.loads(worker_path.read_bytes()) if worker_path.exists() else {}
    process = {}
    for label, pid in (('controller', launch['pid']), ('worker', worker.get('pid'))):
        path = Path('/proc/' + str(pid) + '/stat')
        item = dict(pid=pid, exists=pid is not None and path.exists(), OS_exit_code=None)
        if item['exists']:
            text = path.read_text()
            fields = text.split(') ', 1)[1].split()
            item.update(stat_raw=text, process_state=fields[0], start_ticks=fields[19])
            assert fields[0] == 'Z', (label, 'still active')
            item['OS_exit_code_raw_wait_status'] = int(fields[49])
            item['OS_exit_code'] = int(fields[49]) >> 8
        process[label] = item
    controls = json.loads((ROOT / 'CONTROLS_SHA256.json').read_bytes())
    assert sha((ROOT / 'CONTROLS_SHA256.json').read_bytes()) == launch['controls_manifest_sha256']
    assert all(sha((ROOT / n).read_bytes()) == h for n, h in controls.items())
    immutable = json.loads((ROOT / 'IMMUTABLE_SHA256.json').read_bytes())
    changed = [name for name, digest in immutable.items() if sha(Path(name).read_bytes()) != digest]
    assert not changed
    files = sorted(ROOT.rglob('*'))
    assert all(not p.is_symlink() for p in files)
    raw = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in files if p.is_file()}
    closure = dict(utc=datetime.now(timezone.utc).isoformat(), process=process,
                   actual_worker_wait_returncode=result.get('actual_parent_returncode'),
                   detached_controller_OS_exit_not_claimed_unless_proc_zombie=process['controller']['OS_exit_code'],
                   all_processes_stopped_or_zombie=True, original_exit_json=result,
                   controls_manifest_sha256=launch['controls_manifest_sha256'],
                   immutable_files_checked=len(immutable), immutable_mismatches=changed,
                   parent_PQ_sha256=launch['parent_PQ_sha256'], source_manifest_sha256=launch['source_manifest_sha256'],
                   source=launch['source'], evidence=launch['evidence'],
                   scope='Read-only stopped-result closure, no replay, checkpoint continuation or array decoding. Original child failure remains failure.')
    raw['closure.json'] = (json.dumps(closure, indent=2) + '\n').encode()
    raw['source-manifest.json'] = (Path(launch['source']) / 'SOURCE_SHA256.json').read_bytes()
    raw['artifact-inventory.json'] = (json.dumps({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(raw.items())},indent=2)+'\n').encode()
    OUT.mkdir()
    archive = OUT / 'failed-surface-probe-pr-remote.tar.gz'
    with tarfile.open(archive, 'w:gz') as stream:
        for name, body in sorted(raw.items()):
            item = tarfile.TarInfo(name)
            item.size = len(body)
            item.mtime = 0
            stream.addfile(item, io.BytesIO(body))
    package = dict(archive=str(archive), sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
                   artifacts=len(raw), closure=closure)
    (OUT / 'package.json').write_text(json.dumps(package, indent=2)+'\n')
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()

"""Freeze PR using stdlib AST and raw archives only; never imports its worker."""
import ast
import copy
import difflib
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
PREP = ROOT / 'failed-surface-probe-pr-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        members = stream.getmembers()
        assert all(m.isfile() for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: stream.extractfile(m).read() for m in members}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


class Unqualify(ast.NodeTransformer):
    def visit_Attribute(self, node):
        self.generic_visit(node)
        if isinstance(node.value, ast.Name) and node.value.id == 'native':
            return ast.copy_location(ast.Name(id=node.attr, ctx=node.ctx), node)
        return node


def normalized(node):
    return ast.dump(Unqualify().visit(copy.deepcopy(node)), include_attributes=False)


def assignment(nodes, name):
    found = [node for node in nodes if isinstance(node, ast.Assign)
             and name in [v.id for target in node.targets for v in ast.walk(target) if isinstance(v, ast.Name)]]
    assert len(found) == 1, (name, len(found))
    return found[0]


def main():
    plan = json.loads((PREP / 'PLAN.json').read_text())
    pqraw = (ROOT / 'failed-years-pq-evidence.tar.gz').read_bytes()
    assert sha(pqraw) == plan['parent_PQ_sha256']
    pq = unpack(pqraw)
    inventory = json.loads(pq['INVENTORY.json'])
    assert len(pq) == 658 and set(pq) == set(inventory) | {'INVENTORY.json'}
    for name, item in inventory.items():
        assert sha(pq[name]) == item['sha256'] and len(pq[name]) == item['bytes'], name
    nmraw = pq['source/candidate-source.tar.gz']
    assert sha(nmraw) == plan['source_archive_sha256']
    nm = unpack(nmraw)
    assert sha(nm['SOURCE_SHA256.json']) == plan['source_manifest_sha256']
    sources = json.loads(nm['SOURCE_SHA256.json'])
    assert len(sources) == 584 and set(nm) == set(sources) | {'SOURCE_SHA256.json'}
    assert all(sha(nm[name]) == digest for name, digest in sources.items())
    report = json.loads(pq['NZ/current/trajectory/batch.json'])
    identity = report['identity']
    assert report['status'] == 'failed' and report['failed_step'] == report['steps_completed'] == 7275
    assert report['steps_requested'] == 17520 and report['columns'] == 3
    assert identity['backend'] == 'cuda32' and identity['compare_jax32'] is False
    assert identity.get('native_state_arrays', 16) == 16
    checkpoint_name = report['checkpoint_file']
    assert PurePosixPath(checkpoint_name).name == checkpoint_name
    checkpoint = 'NZ/current/trajectory/' + checkpoint_name
    assert sha(pq[checkpoint]) == report['checkpoint_sha256'] == plan['checkpoint_sha256']
    with zipfile.ZipFile(io.BytesIO(pq[checkpoint])) as stream:
        names = stream.namelist()
        expected = [f'a{k}.npy' for k in range(16)] + [k + '.npy' for k in ('index', 'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax')]
        assert len(names) == 23 and set(names) == set(expected)
    batch_name = 'NZ/current/inputs/batch.json'
    batch = json.loads(pq[batch_name])
    assert sha(pq[batch_name]) == identity['batch_sha256']
    paths = []
    for row, original in zip(batch['cases'], identity['cases'], strict=True):
        assert row['case'] == original['case']
        bindings = {}
        for key, identity_key in (('input', 'forcing_npz_sha256'), ('input_manifest', 'forcing_manifest_sha256'), ('configuration', 'configuration_sha256')):
            path = PurePosixPath(row[key])
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in row[key]
            member = str(PurePosixPath(batch_name).parent / path)
            assert member in pq and sha(pq[member]) == original[identity_key]
            bindings[key] = dict(relative_path=row[key], archive_member=member, sha256=sha(pq[member]), bytes=len(pq[member]))
        config = json.loads(pq[bindings['configuration']['archive_member']])
        assert config.get('canopy_optics') is None and config.get('soil_hydrology') is None
        paths.append(dict(case=row['case'], paths=bindings, canopy_optics=None, soil_hydrology=None))
    assert len(paths) == 3 and [p['case'] for p in paths] == plan['cases']

    native_name = 'benchmarks/run_fluxnet_native.py'
    native_text = nm[native_name].decode()
    worker_text = (PREP / 'probe_surface_pr.py').read_text()
    trees = {p.name: ast.parse(p.read_bytes()) for p in PREP.glob('*.py')}
    native_tree = ast.parse(native_text)
    run = next(n for n in native_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
    worker = next(n for n in trees['probe_surface_pr.py'].body if isinstance(n, ast.FunctionDef) and n.name == 'construct_request')
    main_loop = next(n for n in ast.walk(run) if isinstance(n, ast.While) and ast.unparse(n.test) == 'index < end')
    checks = {}
    for name in ('hydrology', 'state_count', 'leaf', 'optics', 'geometry', 'deposition_schedules', 'nrates'):
        checks[name] = normalized(assignment(run.body, name)) == normalized(assignment(worker.body, name))
    for name in ('f', 'env', 'e', 'nitrogen', 'deposition', 'kwargs'):
        checks[name] = normalized(assignment(main_loop.body, name)) == normalized(assignment(worker.body, name))
    for condition in ('optics is not None', 'hydrology is not None'):
        old = next(n for n in main_loop.body if isinstance(n, ast.If) and ast.unparse(n.test) == condition)
        new = next(n for n in worker.body if isinstance(n, ast.If) and ast.unparse(n.test) == condition)
        checks[condition] = normalized(old) == normalized(new)
    old_optics = next(n for n in run.body if isinstance(n, ast.If) and ast.unparse(n.test).startswith('any('))
    new_optics = next(n for n in worker.body if isinstance(n, ast.If) and ast.unparse(n.test).startswith('any('))
    checks['optics_optional_packing'] = normalized(old_optics) == normalized(new_optics)
    assert all(checks.values()), checks
    calls = [n for n in ast.walk(trees['probe_surface_pr.py']) if isinstance(n, ast.Call)]
    assert sum(ast.unparse(n.func) == 'engine.step' for n in calls) == 1
    assert sum(ast.unparse(n.func) == 'engine.update_forcing' for n in calls) == 1
    assert not any(ast.unparse(n.func) in ('native.run', 'native.build_state', 'native.next_station_arrays') for n in calls)
    assert not any(k.arg == 'raise_on_failure' and isinstance(k.value, ast.Constant) and k.value.value is False for n in calls for k in n.keywords)
    assert worker_text.index("for row in json.loads(batch.read_text())['cases']:") < worker_text.index('cases = native.load_batch(batch)')
    load_batch = next(n for n in native_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'load_batch')
    assert 'path.parent / row[k]' in ast.unparse(load_batch)
    # Key provenance is the original unpack implementation, not guessed raw slots.
    flag_keys = ['converged', 'canopy_converged', 'surface_temperature', 'surface_temperature_residual',
                 'surface_root_bracket_k', 'surface_evaluations', 'max_solver_residual', 'restarts',
                 'thermal_layer_residual', 'thermal_layer_tolerance', 'phase_coordinates']
    base_tree = ast.parse(nm['src/noahmp_clm/gpu/canopy_surface.py'])
    base_fn = next(n for n in base_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'unpack_surface')
    base_keys = {n.arg for n in ast.walk(base_fn) if isinstance(n, ast.keyword)}
    phase_tree = ast.parse(nm['src/noahmp_clm/gpu/canopy_phase_surface.py'])
    phase_fn = next(n for n in phase_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'unpack_phase_surface')
    phase_keys = {n.value for n in ast.walk(phase_fn) if isinstance(n, ast.Constant) and isinstance(n.value, str)}
    assert set(flag_keys) <= base_keys | phase_keys
    phase_energy = ast.parse(nm['src/noahmp_clm/gpu/canopy_phase_energy.py'])
    phase_names = {}
    for node in phase_energy.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('PHASE_LAYERS', 'PHASE_SCALARS'):
            phase_names[node.targets[0].id] = ast.literal_eval(node.value)
    assert {'phase_coordinates', 'restarts', 'max_solver_residual'} <= set(sum(phase_names.values(), ()))
    ranges = [native_text.splitlines(keepends=True)[353:379], native_text.splitlines(keepends=True)[477:488]]
    diff = ''.join(difflib.unified_diff([line for chunk in ranges for line in chunk],
                   worker_text.splitlines(keepends=True)[worker.lineno-1:worker.end_lineno],
                   fromfile='original NM native.run setup354-379 and per-index478-488', tofile='PR construct_request'))
    (PREP / 'NATIVE_REQUEST_DIFF.txt').write_text(diff, encoding='utf-8')
    binding = dict(parent_PQ_sha256=sha(pqraw), source_archive_sha256=sha(nmraw),
                   source_manifest_sha256=sha(nm['SOURCE_SHA256.json']), source_files=584,
                   checkpoint_member=checkpoint, checkpoint_sha256=sha(pq[checkpoint]),
                   checkpoint_npz_members=names, physical_arrays=16, index_and_ledger_arrays=7,
                   batch_member=batch_name, batch_sha256=sha(pq[batch_name]), cases=paths,
                   path_resolution='Original load_batch joins each relative row path to the cloned batch parent. PR rejects absolute/escaping paths before load_batch; all9 paths exist inside immutable PQ clone.',
                   normalized_native_AST_equal=checks,
                   fixed_specialization='Original cuda32 dtype=float32; exact16 state excludes capacity/structure branches. Resume index and arrays come from original failed7275 checkpoint, no cold constructors.',
                   original_load_batch_sha256=sha(ast.get_source_segment(native_text, load_batch).encode()),
                   result_flags=flag_keys, result_flags_declared_in_original_unpack=True,
                   native_file_sha256=sources[native_name],
                   source_paths={n: sources[n] for n in (native_name, 'src/noahmp_clm/gpu/cuda/canopy_phase_surface.py',
                      'src/noahmp_clm/gpu/canopy_phase_surface.py', 'src/noahmp_clm/gpu/canopy_surface.py',
                      'src/noahmp_clm/gpu/canopy_phase_energy.py', 'src/noahmp_clm/gpu/canopy_most_surface.py')},
                   capture_schema='PR-typed-tree-v1', actual_execution=False,
                   static_verifier_sha256=sha(Path(__file__).read_bytes()))
    write(PREP / 'BINDINGS.json', binding)
    controls = {p.name: sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    assert len(controls) == 7
    write(PREP / 'CONTROLS_SHA256.json', controls)
    result = dict(passed=True, blocking_findings=[], controls=7,
                  controls_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()),
                  parent_files_checked=len(inventory), source_files_checked=len(sources),
                  original_path_bindings_checked=9, checkpoint_members=23,
                  normalized_native_AST_checks=len(checks), result_flags_checked=len(flag_keys),
                  scripts_AST_parsed=sorted(trees), GPU_calls=0, physics_calls=0, array_value_decodes=0,
                  scientific_imports_executed=0, scope='Preparation only: stdlib archive/header-free raw hash, JSON and AST verification. No deployment, device execution or original missing packet byteexact claim.')
    write(ROOT / 'failed-surface-probe-pr-static.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

"""Read-only PR status and, only after both processes stop, result closure."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

BASE = Path(__file__).resolve().parent
OUT = BASE / 'failed-surface-probe-pr-deployment'
PYTHON = '/home/lhwang/venvs/noahmp-phase3b/bin/python'
ROOT = '/home/lhwang/work/noahmp-v1/failed-surface-probe-pr'
REMOTE = r'''
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
root=Path('/home/lhwang/work/noahmp-v1/failed-surface-probe-pr')
result={'utc':datetime.now(timezone.utc).isoformat(),'root':str(root)}
for name in ('launch.json','worker.json','exit.json','result/receipt.json'):
    path=root/name
    if path.exists():result[name]=json.loads(path.read_bytes())
for label,name in (('controller','launch.json'),('worker','worker.json')):
    pid=result.get(name,{}).get('pid')
    path=Path('/proc/'+str(pid))
    state={'pid':pid,'exists':pid is not None and path.exists(),'OS_exit_code':None}
    if state['exists']:
        stat=(path/'stat').read_text().split(') ',1)[1].split()
        state.update(process_state=stat[0],start_ticks=stat[19])
        if stat[0]=='Z':state['OS_exit_code_raw_wait_status']=int(stat[49])
    result[label+'_process']=state
for name in ('controller.log','worker.log'):
    path=root/name
    if path.exists():
        body=path.read_bytes()
        result[name]={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'tail':body.decode(errors='replace').splitlines()[-15:]}
result['surface_directories']=sorted(str(p.relative_to(root)) for p in (root/'result/surface').glob('call-*'))
print(json.dumps(result,allow_nan=False))
'''


def main():
    assert sys.argv[1] == 'status'
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
    prefix = OUT / ('status-' + stamp)
    assert not prefix.with_suffix('.json').exists()
    command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'xuanze-neiwang',
               PYTHON + ' -B -c ' + shlex.quote(REMOTE)]
    child = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    prefix.with_suffix('.stdout').write_bytes(child.stdout)
    prefix.with_suffix('.stderr').write_bytes(child.stderr)
    prefix.with_suffix('.json').write_text(json.dumps(dict(actual_returncode=child.returncode,
        stdout_sha256=hashlib.sha256(child.stdout).hexdigest(), stderr_sha256=hashlib.sha256(child.stderr).hexdigest()), indent=2)+'\n')
    assert child.returncode == 0
    result = json.loads(child.stdout)
    print(json.dumps({k:v for k,v in result.items() if k != 'result/receipt.json'},indent=2))
    if 'result/receipt.json' in result:
        receipt = result['result/receipt.json']
        print(json.dumps({'receipt':{k:v for k,v in receipt.items() if k!='calls'},'calls':receipt['calls']},indent=2))


if __name__ == '__main__':
    main()

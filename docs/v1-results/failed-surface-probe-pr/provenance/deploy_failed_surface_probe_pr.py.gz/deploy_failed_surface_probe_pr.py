"""Authorized exact-control upload or one launch; stdlib local operations only."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

BASE = Path(__file__).resolve().parent
PREP = BASE / 'failed-surface-probe-pr-preparation'
OUT = BASE / 'failed-surface-probe-pr-deployment'
REMOTE = '/home/lhwang/work/noahmp-v1/failed-surface-probe-pr-preparation'
PYTHON = '/home/lhwang/venvs/noahmp-phase3b/bin/python'
MANIFEST = '6715681bbe8488cf13c1eb5ec8ec771e5d0a012edb2de0eadf6cb56ae9ca581e'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def execute(label, arguments):
    assert not (OUT / (label + '.json')).exists()
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(arguments, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    receipt = dict(utc=started, arguments=arguments, actual_returncode=result.returncode,
                   stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr))
    (OUT / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt), flush=True)
    assert result.returncode == 0, (label, result.stderr.decode(errors='replace'))
    return result.stdout


def ssh(label, code):
    return execute(label, ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'xuanze-neiwang',
                          PYTHON + ' -B -c ' + shlex.quote(code)])


def main():
    manifest = (PREP / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(manifest) == MANIFEST
    controls = json.loads(manifest)
    assert set(p.name for p in PREP.iterdir()) == set(controls) | {'CONTROLS_SHA256.json'}
    assert all(sha((PREP / n).read_bytes()) == h for n, h in controls.items())
    plan = json.loads((PREP / 'PLAN.json').read_bytes())
    if sys.argv[1] == 'stage':
        OUT.mkdir()
        ssh('preflight', "from pathlib import Path; import hashlib,json; "
            + "assert Path('/home/lhwang/work/noahmp-v1').is_dir(); "
            + 'assert not Path(' + repr(REMOTE) + ').exists(); '
            + 'assert not Path(' + repr(plan['root']) + ').exists(); '
            + 'assert not Path(' + repr(plan['temporary']) + ').exists(); '
            + 'p=Path(' + repr(plan['parent_PQ_archive']) + '); h=hashlib.sha256(p.read_bytes()).hexdigest(); '
            + 'assert h == ' + repr(plan['parent_PQ_sha256']) + '; '
            + "print(json.dumps(dict(PQ_sha256=h,exists=True,all_three_new_paths_absent=True)))")
        execute('upload', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', '-r', str(PREP),
                           'xuanze-neiwang:' + REMOTE])
        ssh('uploaded-hash', "from pathlib import Path; import hashlib,json; p=Path(" + repr(REMOTE) + '); '
            + "r=(p/'CONTROLS_SHA256.json').read_bytes(); assert hashlib.sha256(r).hexdigest()==" + repr(MANIFEST) + '; '
            + 'm=json.loads(r); assert set(x.name for x in p.iterdir())==set(m)|{\'CONTROLS_SHA256.json\'}; '
            + 'assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==h for n,h in m.items()); '
            + "print(json.dumps(dict(controls=len(m),controls_manifest_sha256=hashlib.sha256(r).hexdigest(),all_bytes_equal=True)))")
    elif sys.argv[1] == 'launch':
        staged = json.loads((OUT / 'uploaded-hash.json').read_bytes())
        assert staged['actual_returncode'] == 0
        output = execute('launch', ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'xuanze-neiwang',
                                    PYTHON + ' -B ' + REMOTE + '/launch_probe_pr.py'])
        launch = json.loads(output)
        assert launch['controls_manifest_sha256'] == MANIFEST and launch['physical_gpu_index'] == 1
        print(json.dumps(launch), flush=True)
    else:
        raise ValueError('Only stage or launch')


if __name__ == '__main__':
    main()

import os
os.environ['PYTEST_PLUGINS']='bounded_cache_guard_gd'
from pathlib import Path
import hashlib,json,runpy
b=Path('/home/lhwang/work/noahmp-v1');s=Path('/tmp/noahmp-soil-stress-full-gd/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==579 and sha(s/'SOURCE_SHA256.json')=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==h for n,h in m.items())
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
# Original mixed GPU tests retain their embedded reference calculations.
# No climate integration/CPU test suite is run by this worker; those use EHPC.
runpy.run_path(str(worker),run_name='__main__')

"""Bounded cycle2/3 only after actual successful originalGW full-year parent."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback

base = Path('/home/lhwang/work/noahmp-v1')
root = base / 'climatology-cycles-ho'
source = Path('/tmp/noahmp-climatology-cycles-ho/source')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan = json.loads((root / 'plan.json').read_text())
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 579 and sha(source / 'SOURCE_SHA256.json') == plan['source_manifest_sha256']
assert all(sha(source / name) == digest for name, digest in manifest.items())
records = []
failure = None
begun = time.monotonic()
try:
    parent = base / 'climatology-year-queue-gw'
    pid = json.loads((parent / 'launch.json').read_text())['pid']
    while not (parent / 'exit.json').exists():
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            raise RuntimeError('OriginalGWcontroller absent withoutactualterminal; do not restart or overlap unknownGPUwork')
        (root / 'waiting-gw.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            pid=pid, reason='Originalcurrent17520climatology year mustactuallyfinish0 before any repeatedcycle')) + '\n')
        time.sleep(20.)
    end = json.loads((parent / 'exit.json').read_text())
    assert end['passed'] and end['actual_controller_returncode'] == 0 and end['source_unchanged']
    assert end['source_manifest_sha256'] == plan['source_manifest_sha256']
    (root / 'actual-gw-exit.json').write_bytes((parent / 'exit.json').read_bytes())
    for number in [2, 3]:
        assert all(sha(root / name) == digest for name, digest in plan['controls_sha256'].items())
        assert all(sha(source / name) == digest for name, digest in manifest.items())
        while True:
            free = int(subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
            memory = int(next(row.split()[1] for row in Path('/proc/meminfo').read_text().splitlines() if row.startswith('MemAvailable:')))
            if free > 8192 and memory > 32 * 1024 * 1024:
                break
            (root / 'waiting-resource.json').write_text(json.dumps(dict(cycle=number, gpu_free_mib=free, host_available_kib=memory)) + '\n')
            time.sleep(20.)
        folder = root / ('cycle-' + str(number).zfill(2))
        env = os.environ.copy()
        env.pop('LD_LIBRARY_PATH', None)
        env.update(PYTHONPATH=':'.join(map(str, [source, source / 'src', source / 'benchmarks'])),
            PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',
            CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
            OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
            XLA_PYTHON_CLIENT_PREALLOCATE='false', CUPY_CACHE_DIR='/tmp/noahmp-climatology-cycles-ho-cupy-cache')
        with (folder / 'controller.log').open('x') as log:
            process = subprocess.Popen([sys.executable, '-u', str(root / 'control_climatology_cycle_ho.py'), str(number)],
                cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT)
        (root / 'progress.json').write_text(json.dumps(dict(cycle=number, pid=process.pid, records=records), indent=2) + '\n')
        code = process.wait()
        terminal = json.loads((folder / 'exit.json').read_text()) if (folder / 'exit.json').exists() else {}
        assert code == 0 and terminal.get('passed') and terminal.get('actual_parent_returncode') == 0
        records.append(dict(cycle=number, actual_controller_returncode=code, actual_parent_returncode=0,
            receipt_sha256=terminal['receipt_sha256']))
        print(json.dumps(records[-1]), flush=True)
except Exception as exc:
    failure = type(exc).__name__ + ': ' + str(exc)
    (root / 'traceback.txt').write_text(traceback.format_exc())
    print(traceback.format_exc(), flush=True)
record = dict(passed=failure is None and len(records) == 2, records=records, failure=failure,
    source_manifest_sha256=plan['source_manifest_sha256'],
    source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    seconds=time.monotonic()-begun, scope=plan['scope'])
(root / 'exit.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if record['passed'] and record['source_unchanged'] else 1)

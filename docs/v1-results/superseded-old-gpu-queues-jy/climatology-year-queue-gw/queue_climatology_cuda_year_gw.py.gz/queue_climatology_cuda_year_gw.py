from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'climatology-year-queue-gw';go=b/'climatology-cuda-cold-go';s=Path('/tmp/noahmp-climatology-cold-go/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==h for n,h in m.items());failure=None;code=None;begun=time.monotonic()
try:
    prior=b/'soil-stress-full-gd-gpu';pid=json.loads((prior/'launch.json').read_text())['pid']
    while not (prior/'exit.json').exists():
        try:os.kill(pid,0)
        except ProcessLookupError:raise RuntimeError('OwnGDcontroller vanishedwithoutactualterminal; do notoverlapunknownGPUworkers')
        (r/'waiting-gd.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=pid,reason='Serializephysical1afteractualGDterminal; GDfailuresremainfailed/mergegate, independentphysicalyearcanstilldiagnosecurrentfrozencases.'))+'\n');time.sleep(20.)
    d=json.loads((prior/'exit.json').read_text());assert d['source_unchanged'] and d['source_manifest_sha256']==manifest;(r/'prior-gd-exit.json').write_bytes((prior/'exit.json').read_bytes())
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and memory>32*1024*1024:break
        (r/'waiting-resource.json').write_text(json.dumps(dict(gpu_free_mib=free,host_available_kib=memory))+'\n');time.sleep(20.)
    assert all(sha(s/n)==h for n,h in m.items());launch=json.loads((r/'launch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items());binding=json.loads((go/'year-prefix-binding.json').read_text());assert sha(go/'trajectory/batch.json')==binding['prefix_batch_report_sha256'];env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',CUPY_CACHE_DIR='/tmp/noahmp-climatology-cold-go-cupy-cache');command=[sys.executable,'-u',str(r/'control_climatology_cuda_year_gw.py')]
    with (go/'year-controller.log').open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
    (r/'progress.json').write_text(json.dumps(dict(pid=p.pid,physical_gpu_index=1),indent=2)+'\n');code=p.wait();out=json.loads((go/'year-exit.json').read_text()) if (go/'year-exit.json').exists() else {};passed=bool(code==0 and out.get('passed') and out.get('actual_parent_returncode')==0)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());passed=False
record=dict(passed=passed,actual_controller_returncode=code,failure=failure,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),seconds=time.monotonic()-begun,scope='ActualserializedcurrentFL12climatologyyearrequest; allpreconditions/gates retained, anyGDtestfailureseparatelyremainsfailed. Yearcompletionnotfull404/sameprecision/spinup/observationalpass.');(r/'exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(0 if passed else 1)

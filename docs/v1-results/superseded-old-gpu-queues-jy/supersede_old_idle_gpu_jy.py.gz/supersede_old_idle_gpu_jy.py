"""Retire verified idle old-source controllers, never touch active model parents."""
from pathlib import Path
import datetime,hashlib,json,os,signal,time,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'superseded-old-gpu-queues-jy';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
specs=[('soil-stress-full-gd-gpu','control_soil_stress_full_gd.py'),('climatology-year-queue-gw','queue_climatology_cuda_year_gw.py'),('climatology-cycles-ho','queue_climatology_cycles_ho.py')]
for folder,control in specs:
    q=b/folder;launch=json.loads((q/'launch.json').read_text());pid=launch['pid'];proc=Path('/proc')/str(pid);cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert control in cmd and not(q/'exit.json').exists();assert not(q/'progress.json').exists(),folder
    children=[]
    for one in Path('/proc').iterdir():
        if not one.name.isdigit():continue
        try:
            parent=int(next(x.split()[1] for x in (one/'status').read_text().splitlines() if x.startswith('PPid:')))
            if parent==pid:children.append(int(one.name))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    assert not children,children
    saved=r/folder;saved.mkdir()
    for one in sorted(q.iterdir()):
        if one.is_file() and one.suffix in ['.json','.py','.log']:(saved/one.name).write_bytes(one.read_bytes())
    d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=pid,command=cmd,no_model_worker_started=True,children=[],signal='SIGTERM',actual_numerical_returncode=None,reason='OldFL physicalwaterstress defect corrected underIV/JN. Retire idle404/full12year/cycles2-3 queues rather than spend currentvalidation budget onobsoletephysicalsource. ExistingECyearcontroller/worker andallstates/source/cache/data untouched. NewJO407 andJR/JT currentcold/year pipeline retainactualgates andscientificfailures; cancellation is not numericalpass.')
    (q/'superseded-idle-jy.json').write_text(json.dumps(d,indent=2)+'\n');os.kill(pid,signal.SIGTERM)
    for _ in range(20):
        if not proc.exists():break
        time.sleep(.1)
    d['process_absent_after_signal']=not proc.exists();assert d['process_absent_after_signal'];(q/'superseded-idle-jy.json').write_text(json.dumps(d,indent=2)+'\n');(saved/'superseded-idle-jy.json').write_bytes((q/'superseded-idle-jy.json').read_bytes());records.append(d)
for folder in ['ballberry-iy-full-gpu','k78-corrected-jb']:
    q=b/folder;saved=r/folder;saved.mkdir()
    for name in ['launch.json','superseded-idle.json']:(saved/name).write_bytes((q/name).read_bytes())
for folder in ['ballberry-jo-full-gpu','k78-corrected-js']:
    q=b/folder;saved=r/folder;saved.mkdir()
    for name in ['launch.json','SOURCE_SHA256.json']:(saved/name).write_bytes((q/name).read_bytes())
(r/'receipt.json').write_text(json.dumps(dict(records=records,scope='Actualidle-only supersession. OriginalEC activeyear remains; newJO/JS wait ownJNCPU0/IV37/inheritance. No actualmodel killed or old failure relabeled.'),indent=2)+'\n');(r/Path(__file__).name).write_bytes(Path(__file__).read_bytes());archive=b/'superseded-old-gpu-queues-jy-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
    for q in sorted(r.rglob('*')):
        if q.is_file():n=q.relative_to(r).as_posix();inventory[n]=sha(q);tf.add(q,arcname=n,recursive=False)
with tarfile.open(archive) as tf:
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
p=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),scope='ThreeoldFL andtwoIV idlecontroller retirements actualabsence/nochildren proven; no active model interrupted. NewJO/JS launches only, stillprerequisiteguarded. Fullsource/runtimeandtestgates unchanged, numericalacceptance notimplied.');(b/'superseded-old-gpu-queues-jy-package.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p),flush=True)

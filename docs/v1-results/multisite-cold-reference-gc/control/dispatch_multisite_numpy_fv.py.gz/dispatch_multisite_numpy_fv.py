from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'multisite-numpy-cold-fv';assert not r.exists();r.mkdir();controls={}
for n in ['run_multisite_numpy_cold_fv.py','multisite_numpy_cold_fv.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'multisite_numpy_cold_fv.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='ActualNumPy-first12 originalcold48 prefixes on6PBS CPUs, fullsource1148 first. No completeyear/spinup/science or GPUcredit fromqueue.');(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

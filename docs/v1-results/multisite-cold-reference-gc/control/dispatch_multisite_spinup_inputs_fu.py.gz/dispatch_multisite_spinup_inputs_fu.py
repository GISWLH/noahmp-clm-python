from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'multisite-spinup-inputs-fu';assert not r.exists();r.mkdir();controls={}
for n in ['prepare_multisite_spinup_fu.py','multisite_spinup_inputs_fu.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'multisite_spinup_inputs_fu.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='Predeclared3sites x2deepwaterICs x2explicitBGCpotential mappings, fullfirstcalendarforcingyear and23coldfields preparation onPBScompute; not modelstep/spinup/sciencepass.');(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

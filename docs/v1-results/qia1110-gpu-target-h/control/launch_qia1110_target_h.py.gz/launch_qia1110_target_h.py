from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';assert not s.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'qia1110-final-h-source.tar.gz';package=json.loads((b/'qia1110-final-h-package.json').read_text());assert sha(a)==package['archive_sha256']=='ffa30e87bc515d0694c9135c8b77d14286112e6da2cf7f4ef6467417319132a0'
npd=json.loads((b/'qia1110-numpy-tests-g-receipt.json').read_text());ref=json.loads((b/'qia1110-reference-g-receipt.json').read_text());assert sha(b/'qia1110-numpy-tests-g-receipt.json')==package['np_receipt_sha256'] and npd['results'][1]['returncode']==0 and npd['results'][1]['counts']==dict(tests=29,failures=0,errors=0,skipped=0)
assert sha(b/'qia1110-reference-g-receipt.json')==package['reference_receipt_sha256'] and ref['source_unchanged'] and all(abs(v)<=limit for v,limit in zip(ref['full_original_MHCN_residual'],ref['full_original_MHCN_bound']))
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>6144
mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines());assert int(mem['MemAvailable'].split()[0])>16*1024*1024
s.mkdir()
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and all(sha(s/n)==h for n,h in m.items());r=s/'target-h';r.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
controls={n:sha(b/n) for n in ['launch_qia1110_target_h.py','control_qia1110_target_h.py','collect_qia1110_target_h.py']}
with (r/'controller.log').open('x') as f:p=subprocess.Popen([sys.executable,'-u',str(b/'control_qia1110_target_h.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='519H target14 onxuanzeGPU0 after actualEHPCNP29 andindependentnetwork/wholehardMHCN. OriginalD BGC and511full not stopped; no full/year/science pass.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_gpu_mib=free,source_archive_sha256=sha(a),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls)
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

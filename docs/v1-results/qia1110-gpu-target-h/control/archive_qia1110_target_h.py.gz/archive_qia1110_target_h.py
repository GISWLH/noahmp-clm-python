from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=s/'target-h';d=json.loads((r/'exit.json').read_text());rec=json.loads((r/'receipt.json').read_text());assert d['returncode']==0 and d['passed'] and rec['counts']==dict(tests=14,failures=0,errors=0,skipped=0) and rec['source_unchanged'];a=b/'qia1110-gpu-target-h-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname='target-h/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['launch_qia1110_target_h.py','control_qia1110_target_h.py','collect_qia1110_target_h.py','archive_qia1110_target_h.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

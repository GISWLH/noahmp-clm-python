"""EHPC-only analysis of an actual complete NZ year; never forward integration.

The exporter must provide the documented OD-style archive layout. This reader
does not authorize, run or restart a model, and rejects an incomplete year.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import itertools
import json
import os
import re
import sys
import tarfile
import time
from of_contract import safe_members, verify_device_archive

NM_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
NM_MANIFEST = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
KG_ARCHIVE = '044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e'
KG_MANIFEST = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
NY_ARCHIVE = '674b2f3f01e9ee35fbcdf35ba3221716944c2997b21ce30da60af5803703ed4c'
NY_PAIR = '6bb99c717288797ab4f3d1f8a3a7115343c6d9a520096340d21b0e460ffedbcc'
NY_CHECKPOINT = '6c6211c81f2efac34db4ad2a07b856e83d6b0b277e8489b2a16b762be824df7f'
SITES = ('CN-Qia', 'CN-Cha', 'CN-HaM')
digest = lambda raw: hashlib.sha256(raw).hexdigest()
sha = lambda path: digest(Path(path).read_bytes())
read = lambda path: json.loads(Path(path).read_text())


def checked_archive(path, expected, target):
    assert sha(path) == expected, str(path)
    assert not target.exists()
    target.mkdir()
    with tarfile.open(path) as archive:
        safe_members(archive)
        archive.extractall(target, filter='data')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-archive', 'device-archive', 'device-package',
                 'input-archive', 'cold-archive', 'pair-archive',
                 'reference-root', 'reference-archive', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    assert os.environ.get('PBS_JOBID'), 'Numerical analysis belongs on EHPC PBS'
    assert os.uname().nodename.startswith('compute002')
    tmp = Path(os.environ['TMPDIR']).resolve()
    assert str(tmp).startswith('/tmp/') and args.output.resolve().is_relative_to(tmp)
    controls_root = Path(__file__).resolve().parent
    controls = read(controls_root / 'CONTROLS_SHA256.json')
    assert all(sha(controls_root / name) == value for name, value in controls.items())
    # Inspect the complete canonical namespace and the fixed original NY118
    # mapping again; do not trust an exporter declaration or a partial index.
    package = read(args.device_package)
    verify_device_archive(args.device_archive, package, args.cold_archive,
                          args.pair_archive, args.input_archive)
    started = time.monotonic()
    target = args.output.resolve()
    assert not target.exists()
    target.mkdir()
    scratch = Path(os.environ['TMPDIR']) / 'hrldas-year-of'
    assert not scratch.exists()
    scratch.mkdir()
    source, device, inputs = (scratch / name for name in ('source', 'device', 'inputs'))
    assert package['source_manifest_sha256'] == NM_MANIFEST
    assert package['steps'] == 17520 and package['cases'] == 3
    checked_archive(args.source_archive, NM_ARCHIVE, source)
    checked_archive(args.device_archive, package['sha256'], device)
    checked_archive(args.input_archive, KG_ARCHIVE, inputs)
    assert sha(args.cold_archive) == NY_ARCHIVE and sha(args.pair_archive) == NY_PAIR
    manifest = read(source / 'SOURCE_SHA256.json')
    assert sha(source / 'SOURCE_SHA256.json') == NM_MANIFEST and len(manifest) == 584
    assert all(sha(source / name) == value for name, value in manifest.items())
    assert (device / 'SOURCE_SHA256.json').read_bytes() == (source / 'SOURCE_SHA256.json').read_bytes()
    inventory = read(device / 'ARTIFACT_SHA256.json')
    assert set(inventory) == {p.relative_to(device).as_posix() for p in device.rglob('*') if p.is_file()} - {'ARTIFACT_SHA256.json'}
    assert all(sha(device / name) == value for name, value in inventory.items())
    sys.path[:0] = [str(Path(__file__).resolve().parent),
                   '/home/zhangyq/noahmp-v1/test-deps', str(source),
                   str(source / 'src'), str(source / 'benchmarks')]
    import numpy as np
    import run_fluxnet_native as native
    from compare_hrldas_native_year import compare_native_year, check_final_checkpoint
    from compare_hrldas_suction_prefix import ARCHIVE_SHA, PROTOCOL_SHA, GENERATOR_SHA
    from audit_bgc_stream_of import audit_stream, cold_rows, continued_rows

    current = device / 'current'
    receipt = read(current / 'year-receipt.json')
    parent = read(device / 'year-controller/exit.json')
    assert parent['passed'] and parent['actual_parent_returncode'] == 0 and parent['failure'] is None
    assert parent['receipt_sha256'] == sha(current / 'year-receipt.json')
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
    assert receipt['source_manifest_sha256'] == NM_MANIFEST and receipt['status'] == 'complete'
    assert receipt['steps_completed'] == receipt['steps_requested'] == 17520
    assert receipt['continued_fields_exact'] == 23 and receipt['first_continued_step_captured']
    folder = current / 'trajectory'
    batch, saved, pairs = native.read_generation(folder)
    assert receipt['report_sha256'] == sha(folder / 'batch.json')
    assert batch['status'] == 'complete' and batch['steps_completed'] == batch['steps_requested'] == 17520
    assert batch['ledger_steps'] == 17520 and batch['ledger_segments'] == 1
    assert batch['source_unchanged'] and batch['columns'] == len(pairs) == 3 and len(saved) == 23
    assert batch['identity']['source_sha256'] == native.source_hashes()
    assert batch['identity']['backend'] == 'cuda32' and not batch['identity']['compare_jax32']
    assert batch['same_precision_max_absolute'] is None and batch.get('initial_run') is None
    protocol = read(inputs / 'protocol.json')
    assert sha(inputs / 'protocol.json') == 'cdbcdede1c9415a1a44c2c5de0849dcfcf93b9cb8e8eeaf18cb25c02c6014677'
    assert protocol['source_manifest_sha256'] == KG_MANIFEST and protocol['case_count'] == 3
    assert sha(inputs / 'batch.json') == batch['identity']['batch_sha256']
    loaded = native.load_batch(inputs / 'batch.json')
    assert tuple(case['config']['site'] for case in loaded) == SITES
    for case, identity in zip(loaded, batch['identity']['cases']):
        assert case['case'] == identity['case']
        for key, path in [('forcing_npz_sha256', 'input'), ('forcing_manifest_sha256', 'input_manifest'),
                          ('configuration_sha256', 'configuration')]:
            assert sha(case['paths'][path]) == identity[key]

    # Bind original independently closed NY48 without relabelling its source or flags.
    with tarfile.open(args.pair_archive) as archive:
        qstat = archive.extractfile('actual-qstat.txt').read().decode()
        assert re.search(r'^Job Id: 1590\.manager\s*$', qstat, re.M)
        assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
        assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
        assert archive.extractfile('pbs-exit.txt').read().strip() == b'0'
        original_verification = archive.extractfile('receipt.json').read()
    verification = read(current / 'prefix-verification.json')
    assert (current / 'prefix-verification.json').read_bytes() == original_verification
    assert verification['passed'] and verification['physical_step_pairs'] == 144
    assert verification['source_unchanged'] and all(case['passed'] for case in verification['cases'])
    assert verification['source_manifest_sha256'] == NM_MANIFEST
    assert verification['cold_fields_exact'] == 23 and len(verification['cases']) == 3
    assert verification['all16state_chains_and_final_checkpoint_exact']
    assert verification['returned_fields_per_batched_step'] == 313
    assert sha(current / 'validated-prefix-state.npz') == NY_CHECKPOINT
    prefix = read(current / 'validated-prefix-report.json')
    assert prefix['identity'] == batch['identity'] and prefix['steps_completed'] == 48
    assert prefix['status'] == 'running' and prefix['steps_requested'] == 17520
    with tarfile.open(args.cold_archive) as archive:
        original_prefix = archive.extractfile('current/trajectory/batch.json').read()
        assert (current / 'validated-prefix-report.json').read_bytes() == original_prefix
        for index in range(48):
            name = 'current/steps/call-' + str(index).zfill(5) + '.npz'
            assert (device / name).read_bytes() == archive.extractfile(name).read()
        # The saved annual trace is also evidence: bind every original48 field,
        # including physical fluxes, soil, runoff and ledger traces, to sealed NY.
        for annual_report, annual_trace in pairs:
            case = annual_report['case']
            descriptor = prefix['case_reports'][case]
            report_raw = archive.extractfile('current/trajectory/' + case + '/' + descriptor['file']).read()
            assert digest(report_raw) == descriptor['sha256']
            original_report = json.loads(report_raw)
            assert original_report['case'] == case and original_report['steps_completed'] == 48
            trace_raw = archive.extractfile('current/trajectory/' + case + '/' + original_report['model_npz']).read()
            assert digest(trace_raw) == original_report['model_npz_sha256']
            with np.load(io.BytesIO(trace_raw), allow_pickle=False) as original_trace:
                assert set(annual_trace) == set(original_trace.files)
                for name in original_trace.files:
                    expected = original_trace[name]
                    actual = np.asarray(annual_trace[name])
                    assert expected.ndim > 0 and expected.shape[0] == 48, (case, name)
                    assert actual.shape == (17520,) + expected.shape[1:], (case, name)
                    assert actual.dtype == expected.dtype, (case, name)
                    assert actual[:48].tobytes() == expected.tobytes(), (case, name)
    with np.load(inputs / 'cold-reference.npz', allow_pickle=False) as values:
        cold = dict(values)
    cold_paths = list(folder.glob('state-0000000-*.npz'))
    assert len(cold_paths) == 1 and len(cold) == 23
    with np.load(cold_paths[0], allow_pickle=False) as values:
        assert set(values.files) == set(cold)
        for key in values.files:
            assert values[key].dtype == cold[key].dtype and values[key].shape == cold[key].shape
            assert values[key].tobytes() == cold[key].tobytes()
    assert all(np.all(cold[key] == 0) for key in ('net', 'bounds', 'maximum', 'stepmax', 'tracermax'))

    with np.load(current / 'validated-prefix-state.npz', allow_pickle=False) as values:
        prefix_state = dict(values)
    with np.load(current / 'first-continued-step.npz', allow_pickle=False) as values:
        first = dict(values)
    with np.load(current / 'steps/call-00000.npz', allow_pickle=False) as values:
        schema = {name for name in values.files if name.startswith('output/')}
    assert len(schema) == 313 and {name for name in first if name.startswith('output/')} == schema
    for index in range(16):
        expected = prefix_state['a' + str(index)].copy()
        if index == 4:
            expected[:, 7:10] = np.asarray([case['data']['environment'][48] for case in loaded], expected.dtype)
        actual = first['before' + str(index)]
        assert actual.dtype == expected.dtype and actual.shape == expected.shape
        assert actual.tobytes() == expected.tobytes()
    diagnostics = {}
    for name, value in first.items():
        if name.startswith('output/'):
            parts = name.split('/')[1:]
            cursor = diagnostics
            for part in parts[:-1]:
                cursor = cursor.setdefault(part, {})
            cursor[parts[-1]] = value
    first_audit = native.audit_step(tuple(first['before' + str(k)] for k in range(16)),
                                   tuple(first['after' + str(k)] for k in range(16)),
                                   first['forcing'], first['deposition'], first['nitrogen'], diagnostics)
    for key, value in zip(('incoming', 'residual', 'bound', 'impurity'), first_audit):
        np.testing.assert_allclose(value, first['recorded/' + key], rtol=1e-12, atol=1e-12)
    chunks = receipt['bgc_diagnostic_chunks']
    assert len(chunks) == 364 and receipt['bgc_diagnostic_steps'] == 17472
    for index, chunk in enumerate(chunks):
        begin, end = 48 + 48 * index, 96 + 48 * index
        assert chunk['first'] == begin and chunk['end'] == end
        name = f'year-bgc-diagnostics/steps-{begin:07d}-{end:07d}.npz'
        assert sha(current / name) == chunk['sha256']
    cn = audit_stream(itertools.chain(cold_rows(current), continued_rows(current, 17520)),
                      loaded, cold, saved, [trace for _, trace in pairs], 17520)
    assert cn['physical_column_steps'] == 52560
    (target / 'bgc-stream-audit.json').write_text(json.dumps(cn, indent=2, allow_nan=False) + '\n')

    reference_root = args.reference_root
    assert sha(args.reference_archive) == ARCHIVE_SHA
    assert sha(reference_root / 'protocol.json') == PROTOCOL_SHA
    assert read(reference_root / 'protocol.json')['instrument_sha256'] == GENERATOR_SHA
    summaries = {}
    with tarfile.open(args.reference_archive) as archive:
        assert archive.extractfile('protocol.json').read() == (reference_root / 'protocol.json').read_bytes()
        for (report, trace), case in zip(pairs, loaded):
            site = case['config']['site']
            assert report['configuration'] == case['config'] and report['case'] == case['case']
            assert report['source_sha256'] == native.source_hashes()
            assert report.get('initial_run') is None
            for name in ('prepared-manifest.json', 'audit.json', 'run-receipt.json'):
                assert archive.extractfile(site + '/' + name).read() == (reference_root / site / name).read_bytes()
            prepared = read(reference_root / site / 'prepared-manifest.json')
            reference = read(reference_root / site / 'audit.json')
            assert reference['source_protocol_sha256'] == PROTOCOL_SHA
            assert all(sha(path) == value for path, value in prepared['inputs_sha256'].items())
            original_config, = [Path(path) for path in prepared['inputs_sha256'] if path.endswith('-config.json')]
            assert isinstance(case['paths']['configuration'], Path)
            result = compare_native_year(trace, report, reference, prepared,
                configuration_pair=(original_config.read_bytes(), case['paths']['configuration'].read_bytes(), site))
            assert len(result['daily']) == 365 and len(result['monthly']) == 12
            result['final_checkpoint'] = check_final_checkpoint(folder / batch['checkpoint_file'], trace, report)
            result['source_manifest_sha256'] = NM_MANIFEST
            result['original_input_source_manifest_sha256'] = KG_MANIFEST
            result['independent_cn_scope'] = 'Original cold48 plus all364 BGC blocks, 52560 column steps across3 sites.'
            raw = (json.dumps(result, indent=2, allow_nan=False) + '\n').encode()
            stored = gzip.compress(raw, mtime=0)
            assert gzip.decompress(stored) == raw
            (target / (site + '-comparison.json.gz')).write_bytes(stored)
            summaries[site] = dict(days=365, months=12,
                daily_bias_criteria_met=result['daily_bias_criteria_met'],
                monthly_bias_criteria_met=result['monthly_bias_criteria_met'],
                instantaneous_flux_criteria_met=result['instantaneous_flux_criteria_met'],
                original_json_sha256=digest(raw), stored_sha256=digest(stored))
    assert tuple(summaries) == SITES
    assert all(sha(source / name) == value for name, value in manifest.items())
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
        seconds=time.monotonic() - started, evaluation_delivered=True, source_unchanged=True,
        source_manifest_sha256=NM_MANIFEST, source_archive_sha256=NM_ARCHIVE,
        device_archive_sha256=package['sha256'], input_archive_sha256=KG_ARCHIVE,
        official_archive_sha256=ARCHIVE_SHA, cases=summaries, complete_steps=17520,
        scope='NZ original three complete cold years. All original365day/12month and instantaneous gates, '
              'stored M/H/C/N ledgers, independently summed final extensive storage, complete actual C/N stream. '
              'Full313-return captures exist only for cold48 and first continued step; remaining saved data are '
              'BGC diagnostics and original traces, not every raw thermal tendency. No scientific pass from '
              'analysis exit, no LQ/LU replacement, no spinup/holdout/SOC/fullGPU/release credit.')
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()

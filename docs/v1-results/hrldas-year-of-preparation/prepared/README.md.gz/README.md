# OF three-site annual evaluation preparation

Prepared only: no deployment, exporter, model, PBS submission or numerical annual analysis has been executed by this preparation. Existing NZ, NQ, NS and the independent LQ/LU work continue unchanged.

The three fixed cases are CN-Qia, CN-Cha and CN-HaM with the original KG suction configurations. Entry requires the true NZ17520 terminal receipt, actual parent0, original23-field continuation, one uninterrupted ledger segment, original364 BGC chunks, unchanged NM584 source and completed device barrier. Missing evidence rejects before export destination creation. The unchanged original NY candidate-only flags are preserved; their cold48 success alone cannot authorize or imply a year.

Both exporter and independent EHPC reader read the exact9,577,710-byte original NY118-member archive (SHA674b2f3f...) and the exact1590.manager F0 pair archive (SHA6bb99c71...). They reconstruct the original-member mapping themselves and compare the48 original packets, zero-step state/reports/traces, validated48 report/state and original controls byte-for-byte. The complete118-member original namespace and digests are recorded, without replacing original identities. The annual archive's `ARTIFACT_SHA256.json` must cover exactly every other canonical file member: missing, duplicate, aliased, absolute or unindexed names are rejected. An exporter declaration alone is not sufficient proof.

All15 original KG input files remain byte-exact to both the KG archive and sealed NY inputs; their protocol retains JN provenance. The existing source-dependency graph proves the unchanged NumPy forward closure against the NM manifest. The original official HRLDAS archive/protocol/generator and prepared-input identities remain fixed. The existing `compare_native_year` calls retain exact UTC/local alignment, original suction-only configuration binding,365day/12month and instantaneous criteria, near-zero absolute tolerances, stored-ledger checks and final extensive storage. Scientific failures and unmeasured criteria remain visible; delivery of an evaluation is not scientific acceptance.

The full313-return schema exists for cold48 and the first continued packet only. The remaining17472 steps retain BGC subsets plus original traces/budgets. KM is adapted by only14 integer constants12→3, with every other AST node unchanged. It streams all17520 steps /52,560 column-steps and independently rederives the original C/N bounds, actual inputs, chains and cumulative storage. Full-year M/H checking is of stored residuals/bounds and final storage, not reconstruction of every original thermal tendency. No spinup, century SOC, observation/holdout, fullGPU or release credit is inferred, and OF does not replace LQ/LU.

Future explicit sequence after true terminal success:

1. Copy these small controls to xuanze `/tmp/noahmp-hrldas-year-of-controls/`, preserving `CONTROLS_SHA256.json`. Run `export_hrldas_year_of.py --input-archive /home/lhwang/work/noahmp-v1/hrldas-current-kg-inputs.tar.gz` using the existing Python with `-B`. It only reads the original NZ/NY source and records and writes `/tmp/noahmp-hrldas-year-of-export/{hrldas-year-of-device.tar.gz,device-package.json}`. No waiter or model is created.
2. Explicitly stage the controls, closed device archive/package and the six fixed archives listed below on both EHPC manager and compute002, at `/tmp/noahmp-hrldas-year-of/` (local aliases `ehpc`, `ehpc-c2`). The original NY archive must be the inner raw `cold48-evidence.tar.gz`, renamed for staging without altering bytes; the public outer device package is a different archive and is rejected.
3. Invoke `dispatch_hrldas_analysis_of.py` on the manager to verify all inputs and create `plan.json` only. Copy that exact plan to compute002, then invoke `--submit-existing-plan`. Compute002 independently rechecks every archive and the original-member map before numerical imports. The retained request is12GiB/1hour/1CPU. All source expansion, reference metadata copies and outputs stay in PBS TMPDIR; existing original prepared-input paths are read-only, and their manifests are never rewritten.
4. After actual PBS terminal status, retain qstat F/exit, `pbs-exit.txt`, the wrapper's actual child return, evaluator receipt, failures and all per-site metrics. Download compute002 `result.tar.gz`, `result-package.json`, controller logs, and manager dispatch/qstat. Neither qsub0 nor analysis0 means the original scientific criteria passed.

| Staged immutable file | Exact role |
|---|---|
| `climatology-final-candidate-nm-source.tar.gz` | NM584 frozen source, SHA39fd30dd... |
| `hrldas-current-kg-inputs.tar.gz` | Original15 inputs, SHA04495970... |
| `ny-cold48-evidence.tar.gz` | Original NY inner118-member cold archive, SHA674b2f3f... |
| `hrldas-cold48-ny-pair-evidence.tar.gz` | Original144-pair1590F0, SHA6bb99c71... |
| `hrldas-three-climate-b-evidence.tar.gz` | Original official three-year reference, SHA168131a5... |

The table contains five prerequisite archives; the sixth staged archive is the newly closed `hrldas-year-of-device.tar.gz` itself. Full SHA values are pinned in `of_contract.py`. `static-preparation-proof.json` records source/API and original-member checks. `outputs/v1/prepare_hrldas_year_of.py` only performs byte/AST metadata preparation locally; it never calls a numerical evaluator or submits a job.

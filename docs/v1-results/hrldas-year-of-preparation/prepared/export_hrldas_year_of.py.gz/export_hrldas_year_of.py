"""OD-style NZ export after true17520/parent0; exact original NY member binding."""
from pathlib import Path
import argparse
import io
import json
import tarfile
from of_contract import (TARGET, INPUT, COLD, PAIR, SOURCE_ARCHIVE, INPUT_NAME, DEVICE_NAME,
    PAIR_NAME, controls, load, sha, digest, terminal, original_ny, original_mapping,
    binding_record, unpack_bytes, verify_inputs, verify_device_archive, array_names)

BASE = Path('/home/lhwang/work/noahmp-v1')
OLD = BASE / 'hrldas-candidate-cold48-ny'
MODEL = OLD / 'cold48'
YEAR = BASE / 'hrldas-year-nz'
SOURCE = Path('/tmp/noahmp-hrldas-candidate-cold48-ny/source')
CONTROL = Path(__file__).resolve().parent
DEST = Path('/tmp/noahmp-hrldas-year-of-export')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-archive', type=Path, default=BASE / INPUT_NAME)
args = parser.parse_args()
hashes = controls(CONTROL)
parent, receipt = load(MODEL / 'year-exit.json'), load(MODEL / 'year-receipt.json')
folder = MODEL / 'trajectory'
report_raw = (folder / 'batch.json').read_bytes()
report = json.loads(report_raw)
terminal(parent, receipt, sha(MODEL / 'year-receipt.json'), report)
assert receipt['report_sha256'] == digest(report_raw)
# No output directories or model work before the true terminal gates above.
manifest_raw = (SOURCE / 'SOURCE_SHA256.json').read_bytes()
manifest = json.loads(manifest_raw)
assert digest(manifest_raw) == TARGET and len(manifest) == 584
assert all(sha(SOURCE / n) == h for n, h in manifest.items())
assert all(manifest[n] == h for n, h in report['identity']['source_sha256'].items())
cold_path, pair_path = OLD / 'cold48-evidence.tar.gz', YEAR / PAIR_NAME
cold, pair = original_ny(cold_path, pair_path)
assert manifest_raw == cold['control/EXPECTED_SOURCE_SHA256.json']
input_files = unpack_bytes(args.input_archive, INPUT)
verify_inputs(input_files, cold, manifest)
assert {p.relative_to(MODEL / 'inputs').as_posix() for p in (MODEL / 'inputs').rglob('*') if p.is_file()} == set(input_files)
assert all((MODEL / 'inputs' / n).read_bytes() == raw for n, raw in input_files.items())
plan = load(YEAR / 'plan.json')
assert plan['source_manifest_sha256'] == TARGET and plan['source'] == str(SOURCE)
assert plan['original_ny_plan_sha256'] == sha(OLD / 'plan.json')
assert all(sha(YEAR / n) == h for n, h in plan['controls_sha256'].items())
assert sha(OLD / 'candidate-source.tar.gz') == SOURCE_ARCHIVE
payload, originals = {}, {}


def add(path, name):
    assert name not in payload
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    payload[name] = raw
    originals[str(path)] = digest(raw)
    return raw


for name, original in original_mapping(cold).items():
    if name.startswith('current/'):
        path = MODEL / name.removeprefix('current/')
    else:
        path = OLD / name.removeprefix('original-prefix-control/')
    assert add(path, name) == cold[original], ('Original NY byte mismatch', name)
for name in ['year-receipt.json', 'year-start-audit.json', 'year-prefix-binding.json',
             'prefix-verification.json', 'prefix-verification-pbs-exit.txt',
             'prefix-verification-actual-qstat.txt', 'first-continued-step.npz']:
    add(MODEL / name, 'current/' + name)
for name, original in [('prefix-verification.json', 'receipt.json'),
                       ('prefix-verification-pbs-exit.txt', 'pbs-exit.txt'),
                       ('prefix-verification-actual-qstat.txt', 'actual-qstat.txt')]:
    assert payload['current/' + name] == pair[original]
for original, name in [('year-exit.json', 'exit.json'), ('year-launch.json', 'launch.json'), ('year-worker.json', 'worker.json')]:
    add(MODEL / original, 'year-controller/' + name)
add(YEAR / 'plan.json', 'year-controller/plan.json')
for name, expected in plan['controls_sha256'].items():
    if not name.endswith('.tar.gz'):
        add(YEAR / name, 'year-controller/controls/' + name)
add(SOURCE / 'SOURCE_SHA256.json', 'SOURCE_SHA256.json')
add(folder / 'batch.json', 'current/trajectory/batch.json')
assert sha(folder / report['checkpoint_file']) == report['checkpoint_sha256']
add(folder / report['checkpoint_file'], 'current/trajectory/' + report['checkpoint_file'])
assert len(array_names(payload['current/trajectory/' + report['checkpoint_file']])) == 23
for case, descriptor in report['case_reports'].items():
    sub = folder / case
    path = sub / descriptor['file']
    value = load(path)
    assert sha(path) == descriptor['sha256']
    assert value['status'] == 'complete' and value['source_unchanged']
    assert value['steps_completed'] == value['steps_requested'] == 17520
    assert value['batch_checkpoint_sha256'] == report['checkpoint_sha256']
    assert sha(sub / value['model_npz']) == value['model_npz_sha256']
    for path in [path, sub / value['model_npz']]:
        add(path, 'current/trajectory/' + case + '/' + path.name)
assert len(report['case_reports']) == 3
for i, chunk in enumerate(receipt['bgc_diagnostic_chunks']):
    begin, end = 48 + i * 48, 96 + i * 48
    assert chunk['first'] == begin and chunk['end'] == end
    name = f'year-bgc-diagnostics/steps-{begin:07d}-{end:07d}.npz'
    assert sha(MODEL / name) == chunk['sha256']
    add(MODEL / name, 'current/' + name)
add(args.input_archive, 'frozen-inputs/' + INPUT_NAME)
payload['frozen-inputs/package.json'] = (json.dumps(dict(archive=INPUT_NAME, sha256=INPUT,
    original_input_source_manifest_sha256='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5',
    scope='Reference only to exact existing KG15 archive; original protocol and configuration bytes retained.'), indent=2) + '\n').encode()
for name in list(hashes) + ['CONTROLS_SHA256.json']:
    add(CONTROL / name, 'export-controls/' + name)
payload['NY_ORIGINAL_BINDING.json'] = (json.dumps(binding_record(cold), indent=2) + '\n').encode()
payload['OF_EXPORT_AUDIT.json'] = (json.dumps(dict(source_manifest_sha256=TARGET,
    original_cold_archive_sha256=COLD, original_pair_archive_sha256=PAIR, original_members=118,
    mapped_original_files=len(original_mapping(cold)), original_input_files=15,
    scope='Original sealed NY118 namespace preserved; 48 packets/cold and validated-prefix bytes bound independently. '
          '313 schema is cold48/first continued only; remaining17472 BGC stream and original traces, not full raw thermal tendencies.'), indent=2) + '\n').encode()
inventory = {n: digest(raw) for n, raw in payload.items()}
payload['ARTIFACT_SHA256.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
assert not DEST.exists()
DEST.mkdir()
target = DEST / DEVICE_NAME
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        archive.addfile(info, io.BytesIO(raw))
packet = dict(archive=DEVICE_NAME, sha256=sha(target), bytes=target.stat().st_size,
    artifacts=len(payload), source_manifest_sha256=TARGET, steps=17520, cases=3,
    actual_year_parent_returncode=0, original_cold_archive_sha256=COLD, original_pair_archive_sha256=PAIR,
    scope='Actual closed NZ original three-site trajectory. Export is not official-science acceptance or LQ/LU replacement.')
verify_device_archive(target, packet, cold_path, pair_path, args.input_archive)
assert (folder / 'batch.json').read_bytes() == report_raw
assert all(sha(path) == h for path, h in originals.items())
assert all(sha(SOURCE / n) == h for n, h in manifest.items())
assert sha(cold_path) == COLD and sha(pair_path) == PAIR and sha(args.input_archive) == INPUT
(DEST / 'device-package.json').write_text(json.dumps(packet, indent=2) + '\n')
print(json.dumps(packet), flush=True)

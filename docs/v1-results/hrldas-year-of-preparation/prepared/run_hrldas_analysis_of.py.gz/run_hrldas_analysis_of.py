"""One independent compute002 OF analysis; all new files under PBS /tmp."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tarfile
import traceback
from of_contract import (STAGE, SOURCE_NAME, DEVICE_NAME, INPUT_NAME, COLD_NAME,
                         PAIR_NAME, OFFICIAL_NAME, TARGET, load, sha, digest,
                         stage_plan, official_metadata)

assert os.environ.get('PBS_JOBID') and os.uname().nodename.startswith('compute002')
tmp = Path(os.environ['TMPDIR']).resolve()
assert str(tmp).startswith('/tmp/')
root = tmp / 'result'
assert not root.exists()
root.mkdir()
record = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
    actual_evaluator_parent_returncode=None, passed=False, failure=None, forward_model_runs=0)
try:
    plan = stage_plan(STAGE)
    assert load(STAGE / 'plan.json') == plan
    for name in list(plan['controls_sha256']) + ['CONTROLS_SHA256.json', 'plan.json', 'device-package.json']:
        (root / name).write_bytes((STAGE / name).read_bytes())
    reference = tmp / 'official-reference'
    assert not reference.exists()
    reference.mkdir()
    for name, raw in official_metadata(STAGE / OFFICIAL_NAME).items():
        assert digest(raw) == plan['official_metadata_sha256'][name]
        path = reference / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    command = [sys.executable, '-B', str(STAGE / 'evaluate_hrldas_year_of.py'),
        '--source-archive', str(STAGE / SOURCE_NAME), '--device-archive', str(STAGE / DEVICE_NAME),
        '--device-package', str(STAGE / 'device-package.json'), '--input-archive', str(STAGE / INPUT_NAME),
        '--cold-archive', str(STAGE / COLD_NAME), '--pair-archive', str(STAGE / PAIR_NAME),
        '--reference-root', str(reference), '--reference-archive', str(STAGE / OFFICIAL_NAME),
        '--output', str(root / 'evaluation')]
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    with (root / 'worker.log').open('x') as log:
        code = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    record['actual_evaluator_parent_returncode'] = code
    (root / 'evaluator-exit.txt').write_text(str(code) + '\n')
    result = load(root / 'evaluation/receipt.json')
    assert code == 0 and result['evaluation_delivered'] and result['source_unchanged']
    assert result['source_manifest_sha256'] == TARGET and result['complete_steps'] == 17520 and len(result['cases']) == 3
    assert all(sha(STAGE / n) == h for n, h in plan['controls_sha256'].items())
    record.update(passed=True, receipt_sha256=sha(root / 'evaluation/receipt.json'),
        scope='Independent audit delivered. Original failed/unmeasured official-science criteria remain in per-site outputs.')
except Exception as error:
    record['failure'] = type(error).__name__ + ': ' + str(error)
    (root / 'wrapper-traceback.txt').write_text(traceback.format_exc())
(root / 'worker-actual-exit.json').write_text(json.dumps(record, indent=2) + '\n')
target = STAGE / 'result.tar.gz'
assert not target.exists()
inventory = {}
with tarfile.open(target, 'w:gz') as archive:
    for path in sorted(root.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            name = path.relative_to(root).as_posix()
            inventory[name] = sha(path)
            archive.add(path, arcname=name, recursive=False)
(STAGE / 'result-package.json').write_text(json.dumps(dict(archive=target.name, sha256=sha(target),
    bytes=target.stat().st_size, artifact_sha256=inventory, **record), indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if record['passed'] else 1)

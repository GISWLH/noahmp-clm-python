"""Prepare/submit only after independently verified NZ17520 parent0 export."""
from pathlib import Path
import argparse
import json
import subprocess
from of_contract import STAGE, load, sha, stage_plan

assert Path(__file__).resolve().parent == STAGE
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--submit-existing-plan', action='store_true')
args = parser.parse_args()
plan = stage_plan(STAGE)
assert not (STAGE / 'dispatch.json').exists()
assert not (STAGE / 'result.tar.gz').exists() and not (STAGE / 'pbs-exit.txt').exists()
if not args.submit_existing_plan:
    assert not (STAGE / 'plan.json').exists()
    (STAGE / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps(dict(preflight_passed=True, plan_sha256=sha(STAGE / 'plan.json'),
        action='Explicitly copy this exact plan.json to compute002 same /tmp stage, then --submit-existing-plan.')))
else:
    assert load(STAGE / 'plan.json') == plan
    result = subprocess.run(['qsub', str(STAGE / 'hrldas_analysis_of.pbs')],
                            cwd=STAGE, capture_output=True, text=True)
    (STAGE / 'qsub.stdout.txt').write_text(result.stdout)
    (STAGE / 'qsub.stderr.txt').write_text(result.stderr)
    (STAGE / 'qsub-actual-exit.json').write_text(json.dumps(dict(actual_parent_returncode=result.returncode)) + '\n')
    assert result.returncode == 0, result.stderr
    record = dict(pbs_job=result.stdout.strip(), plan_sha256=sha(STAGE / 'plan.json'),
        controls_sha256=plan['controls_sha256'], device_archive_sha256=plan['device_archive_sha256'],
        scope='OF submitted after closed NZ17520; qsub0 is not analysis or scientific acceptance.')
    (STAGE / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)

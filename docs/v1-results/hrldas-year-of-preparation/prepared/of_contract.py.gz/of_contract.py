"""OF metadata gates for closed NZ, original NY/1590 and immutable KG inputs."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import re
import tarfile
import zipfile

TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
PARENT = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
SOURCE_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
INPUT = '044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e'
INPUT_PROTOCOL = 'cdbcdede1c9415a1a44c2c5de0849dcfcf93b9cb8e8eeaf18cb25c02c6014677'
COLD = '674b2f3f01e9ee35fbcdf35ba3221716944c2997b21ce30da60af5803703ed4c'
PAIR = '6bb99c717288797ab4f3d1f8a3a7115343c6d9a520096340d21b0e460ffedbcc'
PAIR_RECEIPT = 'd5469cf7d7547142e4698facfa0edbbb9773ba1f006e9e659e1544f76e53052d'
CHECKPOINT = '6c6211c81f2efac34db4ad2a07b856e83d6b0b277e8489b2a16b762be824df7f'
NUMPY_REFERENCE = 'bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416'
OFFICIAL = '168131a520bcfa9f6cd5a2a274778beb0e7483d34f80337d22708a22a275c82c'
OFFICIAL_PROTOCOL = 'a13336a71c3aad8ea612a0e85489959df8b7f568f834f866c6f5c3d8f71d3eff'
GENERATOR = '7c4d7963b11526942ca326d105088bfd4d74f23c2b0ecf4ebfa2520fc4fafca6'
SITES = ('CN-Qia', 'CN-Cha', 'CN-HaM')
STAGE = Path('/tmp/noahmp-hrldas-year-of')
DEVICE_NAME = 'hrldas-year-of-device.tar.gz'
COLD_NAME = 'ny-cold48-evidence.tar.gz'
PAIR_NAME = 'hrldas-cold48-ny-pair-evidence.tar.gz'
INPUT_NAME = 'hrldas-current-kg-inputs.tar.gz'
OFFICIAL_NAME = 'hrldas-three-climate-b-evidence.tar.gz'
SOURCE_NAME = 'climatology-final-candidate-nm-source.tar.gz'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
sha = lambda path: digest(Path(path).read_bytes())
load = lambda path: json.loads(Path(path).read_text())


def controls(folder):
    hashes = load(folder / 'CONTROLS_SHA256.json')
    assert all(sha(folder / name) == value for name, value in hashes.items())
    return hashes


def safe_members(archive):
    members = archive.getmembers()
    assert len({m.name for m in members}) == len(members), 'Duplicate archive member'
    for member in members:
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert path.as_posix() == member.name and '\\' not in member.name, 'Noncanonical archive namespace'
    return members


def unpack_bytes(path, expected):
    assert sha(path) == expected, str(path)
    with tarfile.open(path) as archive:
        data = {m.name: archive.extractfile(m).read() for m in safe_members(archive)}
    if 'artifact-inventory.json' in data:
        inventory = json.loads(data['artifact-inventory.json'])
        assert set(inventory) == set(data) - {'artifact-inventory.json'}
        assert all(digest(data[n]) == v['sha256'] and len(data[n]) == v['bytes'] for n, v in inventory.items())
    return data


def array_names(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and all(n.endswith('.npy') for n in names)
        return {n[:-4] for n in names}


def original_ny(cold_path, pair_path):
    cold, pair = unpack_bytes(cold_path, COLD), unpack_bytes(pair_path, PAIR)
    assert len(cold) == 118, 'Full immutable NY namespace required'
    report = json.loads(cold['current/trajectory/batch.json'])
    receipt, parent = (json.loads(cold['current/' + n]) for n in ['receipt.json', 'exit.json'])
    assert parent['passed'] and parent['actual_parent_returncode'] == 0
    assert parent['receipt_sha256'] == digest(cold['current/receipt.json'])
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
    assert receipt['source_manifest_sha256'] == TARGET and receipt['cold_fields_exact'] == 23
    assert receipt['primary_state_arrays'] == 16 and receipt['cases'] == 3 and receipt['captured_step_calls'] == 48
    assert receipt['steps_completed'] == 48 and receipt['steps_requested'] == 17520 and receipt['status'] == 'running'
    assert receipt['report_sha256'] == digest(cold['current/trajectory/batch.json'])
    assert report['checkpoint_sha256'] == CHECKPOINT
    assert digest(cold['current/trajectory/' + report['checkpoint_file']]) == CHECKPOINT
    assert report['ledger_steps'] == 48 and report['ledger_segments'] == 1
    value = json.loads(pair['receipt.json'])
    assert digest(pair['receipt.json']) == PAIR_RECEIPT
    assert value['passed'] and value['source_unchanged'] and value['source_manifest_sha256'] == TARGET
    assert value['cold_fields_exact'] == 23 and value['all16state_chains_and_final_checkpoint_exact']
    assert value['physical_step_pairs'] == 144 and value['returned_fields_per_batched_step'] == 313
    assert len(value['cases']) == 3 and all(c['passed'] for c in value['cases'])
    assert value['device_archive_sha256'] == COLD
    assert value['reference_source_manifest_sha256'] == PARENT and value['reference_archive_sha256'] == NUMPY_REFERENCE
    qstat = pair['actual-qstat.txt'].decode()
    assert re.search(r'^Job Id: 1590\.manager\s*$', qstat, re.M)
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M) and re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
    assert pair['pbs-exit.txt'].strip() == b'0'
    return cold, pair


def original_mapping(cold):
    """Construct mapping from original sealed bytes, never from exporter claims."""
    mapping = {'current/' + n: 'current/' + n for n in ['receipt.json', 'exit.json', 'cold-audit.json', 'prefix-report.json']}
    mapping.update({'current/steps/call-' + str(k).zfill(5) + '.npz': 'current/steps/call-' + str(k).zfill(5) + '.npz' for k in range(48)})
    report = json.loads(cold['current/trajectory/batch.json'])
    mapping['current/validated-prefix-report.json'] = 'current/trajectory/batch.json'
    mapping['current/validated-prefix-state.npz'] = 'current/trajectory/' + report['checkpoint_file']
    initial = [n for n in cold if n.startswith('current/trajectory/state-0000000-') and n.endswith('.npz')]
    assert len(initial) == 1
    mapping[initial[0]] = initial[0]
    generation = Path(initial[0]).stem.removeprefix('state-')
    for case in report['case_reports']:
        for prefix, suffix in [('report-', '.json'), ('trace-', '.npz')]:
            name = 'current/trajectory/' + case + '/' + prefix + generation + suffix
            mapping[name] = name
    for name in ['plan.json', 'launch.json', 'CONTROLS_SHA256.json', 'EXPECTED_SOURCE_SHA256.json',
                 'reference-reuse.json', 'source-dependencies.json', 'reference-dependency-graph.json']:
        mapping['original-prefix-control/' + name] = 'control/' + name
    return mapping


def binding_record(cold):
    return dict(original_archive_sha256=COLD, original_members=118,
        original_member_sha256={n: digest(raw) for n, raw in cold.items()},
        device_to_original_member=original_mapping(cold), pair_archive_sha256=PAIR,
        scope='All original118 members retain their namespace/hash; mapped annual bytes equal fixed sealed NY bytes.')


def verify_inputs(raw_inputs, cold, manifest):
    reuse = json.loads(cold['control/reference-reuse.json'])
    expected = reuse['every_input_file_sha256']
    assert len(expected) == 15 and set(raw_inputs) == set(expected)
    assert reuse['reference_reusable'] and reuse['reference_source_manifest_sha256'] == PARENT
    assert reuse['candidate_source_manifest_sha256'] == TARGET and reuse['candidate_source_archive_sha256'] == SOURCE_ARCHIVE
    assert reuse['input_archive_sha256'] == INPUT and reuse['reference_archive_sha256'] == NUMPY_REFERENCE
    assert all(digest(raw_inputs[n]) == h and raw_inputs[n] == cold['current/inputs/' + n] for n, h in expected.items())
    protocol = json.loads(raw_inputs['protocol.json'])
    assert digest(raw_inputs['protocol.json']) == INPUT_PROTOCOL
    assert protocol['source_manifest_sha256'] == PARENT and protocol['case_count'] == 3
    assert [v['site'] for v in protocol['cases']] == list(SITES)
    assert protocol['cold_fields'] == 23 and protocol['primary_arrays'] == 16 and protocol['requested_steps'] == 17520
    dependency = json.loads(cold['control/source-dependencies.json'])
    graph = json.loads(cold['control/reference-dependency-graph.json'])
    assert dependency['parent_manifest'] == PARENT and dependency['candidate_manifest'] == TARGET and dependency['numpy61_byteexact']
    assert graph['assess_clm_spinup_reachable'] is False and graph['dynamic_evaluation_or_import_calls_in_closure'] == []
    closure = dependency['numpy_forward_closure_byteexact']
    assert closure and all(manifest[n] == graph['source_sha256'][n] for n in closure)
    return protocol


def terminal(parent, receipt, receipt_digest, batch):
    assert parent['passed'] and parent['actual_parent_returncode'] == 0 and parent['failure'] is None
    assert parent['source_manifest_sha256'] == TARGET and parent['receipt_sha256'] == receipt_digest
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['status'] == 'complete' and receipt['steps_completed'] == receipt['steps_requested'] == 17520
    assert receipt['device_barrier_complete'] and receipt['continued_fields_exact'] == 23 and receipt['first_continued_step_captured']
    assert receipt['bgc_diagnostic_steps'] == 17472 and len(receipt['bgc_diagnostic_chunks']) == 364
    assert batch['status'] == 'complete' and batch['steps_completed'] == batch['steps_requested'] == 17520
    assert batch['source_unchanged'] and batch['columns'] == 3 and batch['ledger_steps'] == 17520 and batch['ledger_segments'] == 1
    assert batch['identity']['backend'] == 'cuda32' and batch['identity']['compare_jax32'] is False
    assert batch['identity'].get('native_state_arrays', 16) == 16 and batch['same_precision_max_absolute'] is None
    assert batch.get('initial_run') is None


def verify_device_archive(path, packet, cold_path, pair_path, input_path):
    assert packet['archive'] == DEVICE_NAME and packet['source_manifest_sha256'] == TARGET
    assert packet['steps'] == 17520 and packet['cases'] == 3 and packet['actual_year_parent_returncode'] == 0
    data = unpack_bytes(path, packet['sha256'])
    inventory = json.loads(data['ARTIFACT_SHA256.json'])
    assert set(inventory) == set(data) - {'ARTIFACT_SHA256.json'}, 'Inventory must cover exact complete namespace'
    assert all(digest(data[n]) == h for n, h in inventory.items())
    cold, pair = original_ny(cold_path, pair_path)
    assert json.loads(data['NY_ORIGINAL_BINDING.json']) == binding_record(cold)
    assert all(data[new] == cold[old] for new, old in original_mapping(cold).items())
    assert data['current/prefix-verification.json'] == pair['receipt.json']
    assert data['current/prefix-verification-pbs-exit.txt'] == pair['pbs-exit.txt']
    assert data['current/prefix-verification-actual-qstat.txt'] == pair['actual-qstat.txt']
    assert digest(data['SOURCE_SHA256.json']) == TARGET
    manifest = json.loads(data['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and data['SOURCE_SHA256.json'] == cold['control/EXPECTED_SOURCE_SHA256.json']
    inputs = unpack_bytes(input_path, INPUT)
    verify_inputs(inputs, cold, manifest)
    assert digest(data['frozen-inputs/' + INPUT_NAME]) == INPUT
    assert data['frozen-inputs/' + INPUT_NAME] == Path(input_path).read_bytes()
    receipt = json.loads(data['current/year-receipt.json'])
    batch = json.loads(data['current/trajectory/batch.json'])
    terminal(json.loads(data['year-controller/exit.json']), receipt, digest(data['current/year-receipt.json']), batch)
    assert receipt['report_sha256'] == digest(data['current/trajectory/batch.json'])
    assert digest(data['current/trajectory/' + batch['checkpoint_file']]) == batch['checkpoint_sha256']
    assert len(array_names(data['current/trajectory/' + batch['checkpoint_file']])) == 23
    prefix = json.loads(data['current/validated-prefix-report.json'])
    assert batch['identity'] == prefix['identity']
    assert [c['case'] for c in batch['identity']['cases']] == [site + '-suction-climate-cycle' for site in SITES]
    assert set(batch['case_reports']) == {site + '-suction-climate-cycle' for site in SITES}
    binding = json.loads(data['current/year-prefix-binding.json'])
    assert binding['prefix_batch_report_sha256'] == digest(data['current/validated-prefix-report.json'])
    assert binding['prefix_checkpoint_sha256'] == CHECKPOINT and binding['prefix_ledger_steps'] == 48 and binding['prefix_ledger_segments'] == 1
    assert binding['nz_plan_sha256'] == digest(data['year-controller/plan.json'])
    assert binding['original_ny_plan_sha256'] == digest(data['original-prefix-control/plan.json'])
    assert binding['independent_audit_receipt_sha256'] == PAIR_RECEIPT and binding['source_manifest_sha256'] == TARGET
    audit = json.loads(data['current/year-start-audit.json'])
    assert audit['saved_fields_exact'] == 23 and audit['source_manifest_sha256'] == TARGET
    assert audit['verified_prefix_checkpoint_sha256'] == audit['current_checkpoint_sha256'] == CHECKPOINT
    assert audit['cpu_verification_sha256'] == PAIR_RECEIPT
    schema = {n for n in array_names(cold['current/steps/call-00000.npz']) if n.startswith('output/')}
    assert len(schema) == 313
    assert all({n for n in array_names(data[f'current/steps/call-{k:05d}.npz']) if n.startswith('output/')} == schema for k in range(48))
    assert {n for n in array_names(data['current/first-continued-step.npz']) if n.startswith('output/')} == schema
    for i, chunk in enumerate(receipt['bgc_diagnostic_chunks']):
        first, end = 48 + i * 48, 96 + i * 48
        assert chunk['first'] == first and chunk['end'] == end
        assert digest(data[f'current/year-bgc-diagnostics/steps-{first:07d}-{end:07d}.npz']) == chunk['sha256']
    for case, descriptor in batch['case_reports'].items():
        name = 'current/trajectory/' + case + '/' + descriptor['file']
        assert digest(data[name]) == descriptor['sha256']
        report = json.loads(data[name])
        assert report['status'] == 'complete' and report['source_unchanged']
        assert report['steps_completed'] == report['steps_requested'] == 17520
        assert report['batch_checkpoint_sha256'] == batch['checkpoint_sha256']
        assert digest(data['current/trajectory/' + case + '/' + report['model_npz']]) == report['model_npz_sha256']
    return receipt


def official_metadata(path):
    assert sha(path) == OFFICIAL
    names = ['protocol.json'] + [site + '/' + n for site in SITES for n in ['prepared-manifest.json', 'audit.json', 'run-receipt.json']]
    with tarfile.open(path) as archive:
        members = {m.name: m for m in archive.getmembers()}
        assert len(members) == len(archive.getmembers())
        data = {n: archive.extractfile(members[n]).read() for n in names}
    assert digest(data['protocol.json']) == OFFICIAL_PROTOCOL
    assert json.loads(data['protocol.json'])['instrument_sha256'] == GENERATOR
    for site in SITES:
        assert json.loads(data[site + '/audit.json'])['source_protocol_sha256'] == OFFICIAL_PROTOCOL
    return data


def stage_plan(stage):
    """All inputs are staged explicitly; this function only reads verified bytes."""
    hashes = controls(stage)
    packet = load(stage / 'device-package.json')
    verify_device_archive(stage / DEVICE_NAME, packet, stage / COLD_NAME,
                          stage / PAIR_NAME, stage / INPUT_NAME)
    source = unpack_bytes(stage / SOURCE_NAME, SOURCE_ARCHIVE)
    assert digest(source['SOURCE_SHA256.json']) == TARGET
    manifest = json.loads(source['SOURCE_SHA256.json'])
    assert len(manifest) == 584 and set(source) == set(manifest) | {'SOURCE_SHA256.json'}
    assert all(digest(source[n]) == h for n, h in manifest.items())
    official = official_metadata(stage / OFFICIAL_NAME)
    return dict(device_archive=DEVICE_NAME, device_archive_sha256=packet['sha256'],
        source_archive_sha256=SOURCE_ARCHIVE, source_manifest_sha256=TARGET,
        input_archive_sha256=INPUT, original_input_source_manifest_sha256=PARENT,
        original_cold_archive_sha256=COLD, original_pair_archive_sha256=PAIR,
        original_pair_job='1590.manager', original_pair_actual_state='F', original_pair_actual_exit=0,
        official_archive_sha256=OFFICIAL, official_protocol_sha256=OFFICIAL_PROTOCOL,
        official_generator_sha256=GENERATOR, official_metadata_sha256={n: digest(raw) for n, raw in official.items()},
        controls_sha256=hashes, actual_year_parent_returncode=0, requested_steps=17520,
        cases=3, sites=list(SITES),
        scope='Closed original NZ continuation only; original NY/1590/KG and official HRLDAS identities retained. '
              'No model run, LQ/LU replacement, scientific acceptance or long-term SOC claim.')

"""Independent stdlib-only OF byte/metadata review; never imports numerical modules."""
from pathlib import Path
import ast,hashlib,importlib.util,io,json,tarfile,zipfile
ROOT=Path(__file__).resolve().parent
P=ROOT/'hrldas-year-of-preparation'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
spec=importlib.util.spec_from_file_location('of_review_contract',P/'of_contract.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
assert sha((P/'CONTROLS_SHA256.json').read_bytes())=='076d7bc546cecdd589ba8b39252335fb64103786804316428ad5e1afbd95278d'
controls=c.controls(P)
cold,pair=c.original_ny(ROOT/'hrldas-cold48-ny-download/cold48-evidence.tar.gz',ROOT/c.PAIR_NAME)
mapping=c.original_mapping(cold)
assert len(cold)==118 and len(mapping)==68 and all(n in cold for n in mapping.values())
dep=json.loads(cold['control/source-dependencies.json'])
graph=json.loads(cold['control/reference-dependency-graph.json'])
runtime=['benchmarks/run_fluxnet_native.py','benchmarks/compare_hrldas_native_year.py',
         'benchmarks/compare_hrldas_suction_prefix.py','benchmarks/compare_hrldas_climate_prefix.py',
         'benchmarks/compare_hrldas_column.py']
with tarfile.open(ROOT/c.SOURCE_NAME) as nm,tarfile.open(ROOT/'clm-ballberry-jn-source.tar.gz') as jn:
    manifest=json.load(nm.extractfile('SOURCE_SHA256.json'))
    assert len(manifest)==584 and all(sha(nm.extractfile(n).read())==h for n,h in manifest.items())
    assert sha(nm.extractfile('SOURCE_SHA256.json').read())==c.TARGET
    assert nm.extractfile('SOURCE_SHA256.json').read()==cold['control/EXPECTED_SOURCE_SHA256.json']
    closure=dep['numpy_forward_closure_byteexact']
    assert len(closure)==59
    assert all(nm.extractfile(n).read()==jn.extractfile(n).read() and manifest[n]==graph['source_sha256'][n] for n in closure)
    assert all(nm.extractfile(n).read()==jn.extractfile(n).read() for n in runtime)
inputs=c.unpack_bytes(ROOT/c.INPUT_NAME,c.INPUT)
c.verify_inputs(inputs,cold,manifest)
official=c.official_metadata(ROOT/c.OFFICIAL_NAME)
assert len(official)==10
old=ast.parse((P/'original-audit_bgc_stream_km.py').read_text())
new=ast.parse((P/'audit_bgc_stream_of.py').read_text()); changed=0
for n in ast.walk(old):
    if isinstance(n,ast.Constant) and type(n.value) is int and n.value==12:
        n.value=3;changed+=1
assert changed==14 and ast.dump(old)==ast.dump(new)
raw=(P/'evaluate_hrldas_year_of.py').read_text()
assert "assert set(annual_trace) == set(original_trace.files)" in raw
assert "assert actual.shape == (17520,) + expected.shape[1:]" in raw
assert "assert actual.dtype == expected.dtype" in raw
assert "assert actual[:48].tobytes() == expected.tobytes()" in raw
assert "descriptor = prefix['case_reports'][case]" in raw
assert "assert digest(report_raw) == descriptor['sha256']" in raw
assert "assert digest(trace_raw) == original_report['model_npz_sha256']" in raw
prefix=json.loads(cold['current/trajectory/batch.json']);prefix_fields={}
for case,descriptor in prefix['case_reports'].items():
    rraw=cold['current/trajectory/'+case+'/'+descriptor['file']]
    assert sha(rraw)==descriptor['sha256'];r=json.loads(rraw)
    traw=cold['current/trajectory/'+case+'/'+r['model_npz']]
    assert sha(traw)==r['model_npz_sha256']
    with zipfile.ZipFile(io.BytesIO(traw)) as z:
        fields=z.namelist();assert len(fields)==len(set(fields))
        prefix_fields[case]=[name.removesuffix('.npy') for name in fields]
for name in controls:
    if name.endswith('.py'):ast.parse((P/name).read_bytes())
result=dict(review_mode='stdlib-only byte/archive/JSON/AST and manual source review; no numerical imports, model, export or submission',
    passed=True,blocking_findings=[],
    reviewed_manifest_sha256=sha((P/'CONTROLS_SHA256.json').read_bytes()),reviewed_controls=controls,
    reviewed_builder_sha256=sha((ROOT/'prepare_hrldas_year_of.py').read_bytes()),
    original_finding=dict(issue='Annual complete trace did not compare every first48 field with sealed NY48; C/N4 checks alone did not cover physical fields.',
        resolution='Fixed original prefix case_reports/report/model_npz SHA lookup, equal field sets, dtype, full-year shape and byte-exact first48 for all3 cases.',closed=True),
    executed_static_checks=dict(NY_archive_sha256=c.COLD,NY_actual_members=len(cold),mapped_original_members=len(mapping),
        pair_archive_sha256=c.PAIR,pair_job='1590.manager',pair_actual_state='F',pair_actual_exit=0,pair_original_columns_steps=144,
        KG_input_files=len(inputs),KG_protocol_retains_JN_manifest=c.PARENT,NM_manifest=c.TARGET,NM_verified_files=584,
        actual_numpy_forward_closure_files_byteequal_JN_NM=len(closure),
        original_scientific_runtime_files_byteequal_JN_NM=runtime,
        KM_only_12_to_3_constant_changes=changed,KM_all_other_AST_exact=True,
        official_archive_sha256=c.OFFICIAL,official_metadata_count=len(official),
        original_NY48_trace_field_names_from_ZIP_metadata_only=prefix_fields),
    manual_execution_boundaries=dict(terminal_parent0_17520_364chunks_required=True,
        exporter_and_EHPC_independently_verify_canonical_full_inventory_original_NY_mapping=True,
        source_and_KG15_checked_before_export_destination_creation=True,
        official_time_daily_monthly_nearzero_and_suction_config_scientific_APIs_unchanged=True,
        input_arrays_are_read_only=True,PBS_uses_compute002_TMPDIR_1CPU12GB1hour=True,
        actual_worker_return_logs_and_failure_outputs_preserved=True,
        first_continued16_chain_and313_native_audit_present=True,
        annual_CN_all52560_column_steps_original_bounds=True,
        annual_MH_scope='Original stored residual/bound traces and independently summed final extensive storage; not every thermal tendency reconstructed.',
        original313_output_scope='Cold48 and first continuation only.',
        scientific_failed_or_unmeasured_criteria_not_converted_to_pass=True),
    not_executed=['Annual device export','OF PBS submission','Annual physical arrays or scientific scoring','Actual17520/364chunk runtime validation'],
    OH_separate_status=dict(job='1593.manager',last_observed_job_state='E',worker_exit=0,
        actual_F_not_yet_observed=True,note='Manager SSH timed out on next refresh. OH is separate cold48 helper precheck; no annual credit. Final actualF closure will be packaged separately.'),
    scope='OF prepared-only independent review; no deployment authorization inferred from static checks, no new source/input/QC/gate changes.')
(ROOT/'hrldas-year-of-independent-review-wp.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(passed=True,manifest=result['reviewed_manifest_sha256'],binding_count=len(mapping),NY118=True,KG15=True,closure59=True,trace_fields={k:len(v) for k,v in prefix_fields.items()},remaining_findings=[])))

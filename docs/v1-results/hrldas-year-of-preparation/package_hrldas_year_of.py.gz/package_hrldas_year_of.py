"""Package reviewed OF preparation only; no deploy, export, PBS or numerics."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'hrldas-year-of-preparation'
EXPECTED = '076d7bc546cecdd589ba8b39252335fb64103786804316428ad5e1afbd95278d'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
assert digest(manifest_raw) == EXPECTED
controls = json.loads(manifest_raw)
assert len(controls) == 11
assert all(digest((PREP / n).read_bytes()) == h for n, h in controls.items())
static = json.loads((OUT / 'hrldas-year-of-static-verification.json').read_text())
assert static['passed'] and static['mode'] == 'static_only' and static['manifest_sha256'] == EXPECTED
assert all(static[n] is False for n in ['deployed', 'export_executed', 'PBS_submitted', 'numerical_analysis_executed'])
review = OUT / 'hrldas-year-of-independent-review-wp.json'
assert digest(review.read_bytes()) == 'df4970464eaffa62990a288da0c8157af1bba9ffb1f879e018fa659cf6fda004'
assessment = json.loads(review.read_text())
assert assessment['passed'] and assessment['blocking_findings'] == []
assert assessment['reviewed_manifest_sha256'] == EXPECTED and assessment['reviewed_controls'] == controls
assert assessment['reviewed_builder_sha256'] == digest((OUT / 'prepare_hrldas_year_of.py').read_bytes())
assert assessment['original_finding']['closed']
files = {'prepared/' + n: (PREP / n).read_bytes() for n in controls}
files['prepared/CONTROLS_SHA256.json'] = manifest_raw
for name in ['prepare_hrldas_year_of.py', 'package_hrldas_year_of.py',
             'hrldas-year-of-static-verification.json', 'HRLDAS_YEAR_OF_PREPARATION_SCOPE.md',
             'review_hrldas_year_of_wp.py', review.name]:
    files[name] = (OUT / name).read_bytes()
for name, raw in files.items():
    if name.endswith('.py'):
        ast.parse(raw)
assert EXPECTED in files['HRLDAS_YEAR_OF_PREPARATION_SCOPE.md'].decode()
result = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821',
    str(PREP), str(OUT / 'prepare_hrldas_year_of.py'), str(Path(__file__))], capture_output=True, text=True)
check = dict(mode='static_only', actual_ruff_returncode=result.returncode,
    ruff_stdout=result.stdout, ruff_stderr=result.stderr,
    controls_manifest_sha256=EXPECTED, controls=11, AST_parsed=True,
    deployed=False, export_executed=False, PBS_submitted=False, numerical_analysis_executed=False)
check_raw = (json.dumps(check, indent=2) + '\n').encode()
(OUT / 'hrldas-year-of-packaging-check.json').write_bytes(check_raw)
assert result.returncode == 0, check
files['hrldas-year-of-packaging-check.json'] = check_raw
inventory = {name: dict(sha256=digest(raw), bytes=len(raw)) for name, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = OUT / 'hrldas-year-of-preparation-evidence.tar.gz'
assert not target.exists(), 'Do not replace sealed evidence'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(target) as archive:
    members = archive.getmembers()
    assert len(members) == len(files) and all(m.isfile() for m in members)
    restored = {m.name: archive.extractfile(m).read() for m in members}
    assert restored == files
    assert set(json.loads(restored['artifact-inventory.json'])) == set(restored) - {'artifact-inventory.json'}
package = dict(archive=target.name, sha256=digest(target.read_bytes()), bytes=target.stat().st_size,
    artifacts=len(files), artifact_sha256={n: digest(raw) for n, raw in files.items()},
    controls_manifest_sha256=EXPECTED, control_files=11,
    status='prepared_only_independently_reviewed', deployed=False, export_executed=False,
    PBS_submitted=False, numerical_analysis_executed=False,
    review_file=review.name, review_sha256=digest(review.read_bytes()),
    source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
    original_NY_archive_sha256='674b2f3f01e9ee35fbcdf35ba3221716944c2997b21ce30da60af5803703ed4c',
    original_1590_pair_archive_sha256='6bb99c717288797ab4f3d1f8a3a7115343c6d9a520096340d21b0e460ffedbcc',
    scope='Only future complete original NZ17520/actualparent0 may be exported and audited. '
          'NY118/KG15/1590 identities and all original science gates retained; yearly trace first48 exact check added. '
          'No annual result, deployment, model run, LQ/LU replacement, spinup, scientific acceptance or release credit.')
(OUT / 'hrldas-year-of-preparation-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps({k: package[k] for k in ['archive', 'sha256', 'bytes', 'artifacts', 'controls_manifest_sha256', 'status']}, indent=2))

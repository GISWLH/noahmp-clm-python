"""Seal OF preparation with byte/AST checks only; no numerical model imports."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import io
import json
import tarfile
import tempfile

OUT = Path(__file__).resolve().parent
DEST = OUT / 'hrldas-year-of-preparation'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
original = (DEST / 'original-audit_bgc_stream_km.py').read_bytes()
adapted = (DEST / 'audit_bgc_stream_of.py').read_bytes()
assert digest(original) == '5c461e2b9a50469e34a764b796366e19c0aba9322297f3611ac0d730ebd8f4b2'
assert original == (OUT / 'audit_bgc_stream_km.py').read_bytes()
tree = ast.parse(original)
count = 0
for node in ast.walk(tree):
    if isinstance(node, ast.Constant) and type(node.value) is int and node.value == 12:
        node.value = 3
        count += 1
assert count == 14 and ast.dump(tree, include_attributes=False) == ast.dump(ast.parse(adapted), include_attributes=False)
adaptation = json.loads((DEST / 'bgc-adaptation.json').read_text())
assert adaptation['original_sha256'] == digest(original) and adaptation['adapted_sha256'] == digest(adapted)
# Loading this stdlib-only contract is metadata inspection, not the evaluator.
spec = importlib.util.spec_from_file_location('of_static_contract', DEST / 'of_contract.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)
with tarfile.open(OUT / 'hrldas-cold48-ny-device-evidence.tar.gz') as outer:
    raw = outer.extractfile('original/cold48-evidence.tar.gz').read()
assert digest(raw) == contract.COLD and len(raw) == 9577710
with tempfile.TemporaryDirectory(prefix='noahmp-of-byte-check-') as temporary:
    cold_path = Path(temporary) / contract.COLD_NAME
    cold_path.write_bytes(raw)
    verified_cold, verified_pair = contract.original_ny(cold_path, OUT / contract.PAIR_NAME)
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    cold = {m.name: archive.extractfile(m).read() for m in contract.safe_members(archive)}
assert len(cold) == 118
assert cold == verified_cold
assert all(old in cold for old in contract.original_mapping(cold).values())
binding = contract.binding_record(cold)
assert set(binding['original_member_sha256']) == set(cold)
with tarfile.open(OUT / 'hrldas-cold48-ny-pair-evidence.tar.gz') as archive:
    pair = {m.name: archive.extractfile(m).read() for m in contract.safe_members(archive)}
assert digest((OUT / 'hrldas-cold48-ny-pair-evidence.tar.gz').read_bytes()) == contract.PAIR
inventory = json.loads(pair['artifact-inventory.json'])
assert set(inventory) == set(pair) - {'artifact-inventory.json'}
assert all(digest(pair[n]) == v['sha256'] and len(pair[n]) == v['bytes'] for n,v in inventory.items())
assert pair == verified_pair
pair_receipt = json.loads(pair['receipt.json'])
assert digest(pair['receipt.json']) == contract.PAIR_RECEIPT
assert pair_receipt['device_archive_sha256'] == contract.COLD
assert pair_receipt['passed'] and pair_receipt['returned_fields_per_batched_step'] == 313
inputs = contract.unpack_bytes(OUT / contract.INPUT_NAME, contract.INPUT)
with tarfile.open(OUT / contract.SOURCE_NAME) as archive:
    raw_manifest = archive.extractfile('SOURCE_SHA256.json').read()
    assert digest(raw_manifest) == contract.TARGET
    manifest = json.loads(raw_manifest)
    assert len(manifest) == 584
    assert all(digest(archive.extractfile(n).read()) == h for n,h in manifest.items())
    runtime = {n: archive.extractfile(n).read() for n in ['benchmarks/run_fluxnet_native.py',
        'benchmarks/compare_hrldas_native_year.py', 'benchmarks/compare_hrldas_suction_prefix.py',
        'benchmarks/compare_hrldas_climate_prefix.py', 'benchmarks/compare_hrldas_column.py']}
assert raw_manifest == cold['control/EXPECTED_SOURCE_SHA256.json']
protocol = contract.verify_inputs(inputs, cold, manifest)
with tarfile.open(OUT / 'clm-ballberry-jn-source.tar.gz') as parent:
    assert all(parent.extractfile(n).read() == raw for n,raw in runtime.items())
official = contract.official_metadata(OUT / contract.OFFICIAL_NAME)
assert len(official) == 10
evaluation = ast.parse((DEST / 'evaluate_hrldas_year_of.py').read_text())
calls = [n for n in ast.walk(evaluation) if isinstance(n, ast.Call)]
science_calls = {name: [ast.dump(n, include_attributes=False) for n in calls
    if isinstance(n.func, ast.Name) and n.func.id == name]
    for name in ['compare_native_year', 'check_final_checkpoint', 'audit_stream']}
assert all(len(v) == 1 for v in science_calls.values())
# The actual API produces Path objects; no string.read_bytes call is introduced.
native_tree = ast.parse(runtime['benchmarks/run_fluxnet_native.py'])
load_batch = next(n for n in native_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'load_batch')
assert 'paths = {k: (path.parent/row[k]).resolve()' in ast.get_source_segment(runtime['benchmarks/run_fluxnet_native.py'].decode(), load_batch)
proof = dict(preparation_only=True, deployed=False, export_executed=False, PBS_submitted=False,
    numerical_analysis_executed=False, original_KM_sha256=digest(original), adapted_KM_sha256=digest(adapted),
    KM_only_integer_12_to_3_changes=count, KM_other_AST_exact=True,
    original_NY_archive_sha256=contract.COLD, original_NY_members=118,
    original_member_binding_complete=True, mapped_annual_files=len(contract.original_mapping(cold)),
    original_pair_archive_sha256=contract.PAIR, original_pair_inventory_complete=True,
    original_pair_job=pair_receipt['pbs_job'], original_pair_returned_fields=313,
    original_NY_and_1590_actual_metadata_gates_executed=True,
    KG_input_files=15, KG_input_protocol_sha256=contract.INPUT_PROTOCOL,
    KG_source_identity_retained=contract.PARENT, same_numpy_forward_closure_verified=True,
    unchanged_frozen_scientific_modules={n:digest(raw) for n,raw in runtime.items()},
    original_official_archive_sha256=contract.OFFICIAL, original_official_metadata_sha256={n:digest(raw) for n,raw in official.items()},
    configuration_path_API_verified=True, original_scientific_call_AST=science_calls,
    scope='Byte/AST/JSON/archive metadata only on Windows. No arrays loaded or physical/scoring computation. '
          'Future complete NZ required;313 only cold48+first continued, complete52560 C/N column steps, stored M/H checks.')
(DEST / 'static-preparation-proof.json').write_text(json.dumps(proof, indent=2) + '\n', newline='\n')
names = ['of_contract.py', 'export_hrldas_year_of.py', 'evaluate_hrldas_year_of.py',
         'audit_bgc_stream_of.py', 'original-audit_bgc_stream_km.py', 'bgc-adaptation.json',
         'dispatch_hrldas_analysis_of.py', 'run_hrldas_analysis_of.py', 'hrldas_analysis_of.pbs',
         'static-preparation-proof.json', 'README.md']
for name in names:
    raw = (DEST / name).read_bytes()
    assert b'\r\n' not in raw
    if name.endswith('.py'):
        ast.parse(raw)
hashes = {n:digest((DEST/n).read_bytes()) for n in names}
(DEST / 'CONTROLS_SHA256.json').write_text(json.dumps(hashes, indent=2) + '\n', newline='\n')
result = dict(passed=True, mode='static_only', controls=len(hashes),
    manifest_sha256=digest((DEST/'CONTROLS_SHA256.json').read_bytes()),
    original_members=118, pair_inventory_complete=True, KG15_byteexact=True,
    deployed=False, export_executed=False, PBS_submitted=False, numerical_analysis_executed=False)
(OUT / 'hrldas-year-of-static-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[];records=[]
queue=b/'phase-cold-queue-ej';exit=json.loads((queue/'exit.json').read_text());assert exit['passed'] and exit['failure'] is None and exit['source_unchanged'] and len(exit['records'])==2 and all(q['passed'] and q['actual_parent_returncode']==0 for q in exit['records'])
for label in ['capacity','capacity_optics']:
    r=b/('qia-phase-'+label+'-cuda-year-ej');d=json.loads((r/'prefix-receipt.json').read_text());e=json.loads((r/'prefix-exit.json').read_text());assert e['returncode']==0 and e['passed'] and e['receipt_sha256']==sha(r/'prefix-receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['cold_fields_exact']==30 and d['captured_step_calls']==48 and d['steps_completed']==48 and d['steps_requested']==17520 and d['status']=='running' and sha(r/'trajectory/batch.json')==d['report_sha256'] and len(list((r/'prefix-steps').glob('call-*.npz')))==48 and d['maximum_host_rss_kib']<=4*1024*1024
    assert d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
    records.append(dict(case=label,actual_parent_returncode=0,maximum_host_rss_kib=d['maximum_host_rss_kib'],prefix_seconds=d['seconds']))
    items.extend((p,label+'/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file())
items.extend((p,'queue/'+p.relative_to(queue).as_posix()) for p in sorted(queue.rglob('*')) if p.is_file())
items.extend((b/n,'control/'+n) for n in ['clm-phase-descent-ec-source.tar.gz','clm-phase-descent-ec-package.json','qia-phase-cold-ef-inputs.tar.gz','run_phase_gpu_prefix_ej.py','control_phase_gpu_prefix_ej.py','queue_phase_gpu_prefix_ej.py','launch_phase_gpu_prefix_ej.py',Path(__file__).name])
a=b/'phase-gpu-prefix-ej-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
d=dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),records=records);(b/'phase-gpu-prefix-ej-package.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

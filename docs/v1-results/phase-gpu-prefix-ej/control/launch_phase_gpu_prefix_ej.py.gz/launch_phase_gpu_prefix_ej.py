from pathlib import Path
import datetime,hashlib,json,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-cold-queue-ej';assert not r.exists();r.mkdir();names=['queue_phase_gpu_prefix_ej.py','run_phase_gpu_prefix_ej.py','control_phase_gpu_prefix_ej.py',Path(__file__).name];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in names:assert b'\r\n' not in (b/name).read_bytes()
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'queue_phase_gpu_prefix_ej.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controls_sha256={n:sha(b/n) for n in names},physical_gpu_index=1,scope='Queued ownEC cold48 bothcases after own18 actualparent0. No model launched/pass/annual credit from queue. No failedprefix resume; independentNumPy48 audit before year.');(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

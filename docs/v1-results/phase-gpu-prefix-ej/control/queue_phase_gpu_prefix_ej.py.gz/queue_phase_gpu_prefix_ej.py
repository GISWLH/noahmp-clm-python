from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-cold-queue-ej';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prior=b/'phase-descent-ee-gpu';s=Path('/tmp/noahmp-phase-descent-ec/source');m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and len(m)==571 and all(sha(s/n)==h for n,h in m.items())
records=[];failure=None;start=time.monotonic()
try:
    while not (prior/'exit.json').exists():
        (r/'waiting.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Wait ownEC originalphase14/surface4 actualparent0; queued is not executed/pass'))+'\n');time.sleep(20.)
    small=json.loads((prior/'exit.json').read_text());assert small['passed'] and small['returncode']==0 and small['source_unchanged'] and small['source_manifest_sha256']==manifest and len(small['records'])==2 and all(q['passed'] and q['actual_parent_returncode']==0 for q in small['records'])
    (r/'prior-original18-exit.json').write_bytes((prior/'exit.json').read_bytes())
    cpu=b/'phase-descent-ec-gpu/cpu-full-receipt.json';d=json.loads(cpu.read_text());assert d['returncode']==0 and d['source_unchanged'] and d['source_manifest_sha256']==manifest and d['counts']==dict(tests=1120,failures=0,errors=0,skipped=0)
    package=json.loads((b/'qia-phase-cold-ef-package.json').read_text());a=b/'qia-phase-cold-ef-inputs.tar.gz';assert sha(a)==package['archive_sha256']=='2325f371ca0fe1a798be898449525bf51b45f46758d772e644644037152046bb' and package['source_manifest_sha256']==manifest
    for label in ['capacity','capacity_optics']:
        while True:
            free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
            if free>8192 and mem>16*1024*1024:break
            (r/'waiting-resource.json').write_text(json.dumps(dict(gpu_free_mib=free,host_available_kib=mem))+'\n');time.sleep(20.)
        out=b/('qia-phase-'+label+'-cuda-year-ej');assert not out.exists();out.mkdir()
        with tarfile.open(a) as tf:tf.extractall(out/'inputs',filter='data')
        protocol=json.loads((out/'inputs/protocol.json').read_text());assert protocol['source_unchanged'] and protocol['own_full_numpy_1120_actual0'] and protocol['source_manifest_sha256']==manifest and protocol['cpu_receipt_sha256']==sha(cpu) and all(c['all30_cold_fields_byteexact_to_prior_physical_seed'] for c in protocol['cases'])
        assert all(sha(s/n)==h for n,h in m.items())
        env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',CUPY_CACHE_DIR='/tmp/noahmp-phase-cold-ej-cupy-cache')
        command=[sys.executable,'-u',str(b/'control_phase_gpu_prefix_ej.py'),label]
        with (out/'prefix-controller.log').open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
        (r/'progress.json').write_text(json.dumps(dict(case=label,pid=p.pid,records=records),indent=2)+'\n');code=p.wait();d=json.loads((out/'prefix-exit.json').read_text()) if (out/'prefix-exit.json').exists() else {};passed=bool(code==0 and d.get('passed') and d.get('returncode')==0);records.append(dict(case=label,actual_parent_returncode=code,passed=passed,physical_gpu_index=1,exit_sha256=sha(out/'prefix-exit.json') if d else None))
        if not passed:raise RuntimeError('Own cold48 failed; preserve original and do not continue year: '+label)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
d=dict(passed=failure is None and len(records)==2,records=records,failure=failure,seconds=time.monotonic()-start,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),scope='ActualEC CUDA-only cold48 queue after own original18 actualparent0, physical1. Original16GiBhost/8GiBGPU+4GiBmeasuredpeak pilot guards. IndependentEHPC EG NumPy48 audit stillrequired before anyyear continuation; not full401/annual/sciencepass.')
(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');raise SystemExit(0 if d['passed'] and d['source_unchanged'] else 1)

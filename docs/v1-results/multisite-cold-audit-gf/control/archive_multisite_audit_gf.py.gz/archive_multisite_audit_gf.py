"""Metadata-only snapshot afteractual451/452, including450failedobserver."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'multisite-cuda-cold-fw-evidence.tar.gz';assert sha(a)=='88e564dc2063e819db7f6bf5902d7600b1f46ac0650c4ae896ac196f2ea162c3';items=[]
for name in ['multisite-cold-audit-ga','multisite-cold-audit-ge','multisite-cold-summary-gf']:
    root=b/name;assert (root/'pbs-exit.txt').read_text().strip()==('1' if name.endswith('-ga') else '0');items.extend((p,name+'/'+p.name) for p in sorted(root.iterdir()) if p.is_file())
d=json.loads((b/'multisite-cold-audit-ge/receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and len(d['cases'])==12 and all(q['passed'] for q in d['cases']);inventory=[];out=b/'multisite-cold-audit-gf-evidence.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz') as t:
    with tarfile.open(a) as original:
        for member in original:
            assert member.isfile();raw=original.extractfile(member).read();inventory.append(dict(path=member.name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
            # Full annual preparedforcing keptatfrozenarchive; allcoldNPZ/48stepoutputs/finalstates/configs/controls retainedhere.
            if member.name.startswith('current/inputs/CN-') and member.name.endswith('.npz'):continue
            t.addfile(member,__import__('io').BytesIO(raw))
    for p,n in items:t.add(p,arcname=n,recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    raw=(json.dumps(dict(device_original_archive_sha256=sha(a),all_original_members=inventory,scope='Alloriginalmemberhashes includingfrozenannualforcing; threeforcingNPZmembers omittedonlyfromGitcopy, original6.57MBarchive retainedunchanged. All48batchedstepNPZ/control/cold/finalstates andindependent12caseaudits included.'),indent=2)+'\n').encode();info=tarfile.TarInfo('device-original-inventory.json');info.size=len(raw);t.addfile(info,__import__('io').BytesIO(raw))
print(json.dumps(dict(name='multisite-cold-audit-gf',sha256=sha(out),bytes=out.stat().st_size,scope='Actual12cold48 CUDAparent0+EHPC451independentall576pairpassed+452fullmetrics. Original450misclassifiedsnowcountfailurepreserved. Originalsource/input/physics/gates unchanged; all12factorial retained. No annual/spinup/observationalpass.')),flush=True)

from pathlib import Path
import hashlib,json,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'multisite-cuda-cold-fw';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();failure=None;code=None
try:
    command=[sys.executable,'-u',str(b/'run_multisite_cuda_cold_fw.py')]
    with (r/'model.log').open('x') as log:p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
    (r/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2)+'\n');code=p.wait();path=r/'receipt.json';d=json.loads(path.read_text()) if path.exists() else {};passed=bool(code==0 and d and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['cold_fields_exact']==23 and d['primary_state_arrays']==16 and d['cases']==12 and d['captured_step_calls']==48 and d['steps_completed']==48 and d['steps_requested']==17520 and d['status']=='running')
except Exception as e:passed=False;failure=type(e).__name__+': '+str(e);(r/'controller-traceback.txt').write_text(traceback.format_exc())
out=dict(actual_parent_returncode=code,passed=passed,failure=failure,seconds=time.monotonic()-start,receipt_sha256=sha(r/'receipt.json') if (r/'receipt.json').exists() else None,scope='Actual isolatedCUDA parentexit, no year/spinup/sciencepass.');(r/'exit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);raise SystemExit(0 if passed else 1)

"""Metadata-only immutable handoff afteractual CUDA parentexit."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'multisite-cuda-cold-fw';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text());assert e['passed'] and e['actual_parent_returncode']==0 and e['receipt_sha256']==sha(r/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['cold_fields_exact']==23 and d['captured_step_calls']==48 and d['cases']==12 and d['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69';assert len(list((r/'steps').glob('call-*.npz')))==48 and sha(r/'trajectory/batch.json')==d['report_sha256'];a=b/'multisite-cuda-cold-fw-evidence.tar.gz';assert not a.exists();items=[]
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname='current/'+p.relative_to(r).as_posix(),recursive=False);items.append(p)
    for name in ['run_multisite_cuda_cold_fw.py','control_multisite_cuda_cold_fw.py','launch_multisite_cuda_cold_fw.py',Path(__file__).name]:tf.add(b/name,arcname='control/'+name,recursive=False)
out=dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items)+4,scope='Allcurrent CUDA12cold48 statepackets/trajectories/inputs/prerequisites/controls preserved, originalsource/inputhashes; independentaudit stillrequired, no year/spinup/sciencecredit.');(b/'multisite-cuda-cold-fw-package.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'p6-hrldas-suction-binding-a';score=json.loads((root/'suction-week-comparison.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pairs=[];rows=[]
for site,r in score['results'].items():
    binding=r['configuration_binding'];prepared=json.loads((base/'hrldas-three-climate-b'/site/'prepared-manifest.json').read_text())
    old=next(Path(k) for k in prepared['inputs_sha256'] if k.endswith('-config.json'));new=base/'fluxnet-first-climate-cycle-20261017-h/inputs'/(site+'-config.json')
    assert sha(old)==binding['original_configuration_sha256'] and sha(new)==binding['new_configuration_sha256']
    pairs += [(old,site+'/original-config.json'),(new,site+'/suction-config.json')]
    rows.append(dict(site=site,original_sha256=sha(old),new_sha256=sha(new)))
note=base/'hrldas-suction-configuration-bindings.json';assert not note.exists();note.write_text(json.dumps(dict(scope='Exact old/new configuration byte pairs for reproducing derived binding; no source/output/configuration rewritten.',original_official_protocol_sha256=score['original_official_protocol_sha256'],cases=rows),indent=2)+'\n')
pairs += [(note,note.name),(Path(__file__),Path(__file__).name)]
dest=base/'hrldas-suction-configurations-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(sha256=sha(dest),files=len(pairs))))

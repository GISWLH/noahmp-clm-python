"""Independent continuous flux BVP and exact tissue absorption limits."""
import numpy as np
import pytest
from noahmp_clm.physics.canopy_optics import CanopyOptics,canopy_shortwave_pft,mixed_optical_properties
from noahmp_clm.physics.canopy_radiation import canopy_shortwave


PFT1=CanopyOptics((.07,.35),(.05,.10),(.16,.39),(.001,.001))


def continuous_mixture_reference(leaf,stem,optics,sw,diff,mu,ag):
    # Dense simultaneous boundary solve and matrix exponentials, independent
    # of production mixing, thin slabs, doubling and boundary elimination.
    from scipy.linalg import expm
    n=len(leaf);area=leaf+stem;k=.5/mu;beam0=.5*sw*(1.-diff);sky0=.5*sw*diff
    values=[]
    for band in range(2):
        rho=[];tau=[];fractions=[]
        for l,s in zip(leaf,stem):
            width=l+s
            r=(l*optics.leaf_reflectance[band]+s*optics.stem_reflectance[band])/width if width else 0.
            t=(l*optics.leaf_transmittance[band]+s*optics.stem_transmittance[band])/width if width else 0.
            al=l*(1.-optics.leaf_reflectance[band]-optics.leaf_transmittance[band])
            ast=s*(1.-optics.stem_reflectance[band]-optics.stem_transmittance[band])
            rho.append(r);tau.append(t);fractions.append(al/(al+ast) if al+ast>0. else 0.)
        beam=beam0*np.exp(-k*np.r_[0.,np.cumsum(area)])
        matrix=np.zeros((2*n+2,2*n+2));rhs=np.zeros(2*n+2)
        matrix[0,0]=1.;rhs[0]=sky0
        matrix[1,n]=-ag[band];matrix[1,2*n+1]=1.;rhs[1]=ag[band]*beam[-1]
        beta=(1.+k)/(2.*k)*(1.-mu*np.log((1.+mu)/mu))
        for i,width in enumerate(area):
            omega=rho[i]+tau[i];back=(5.*rho[i]+3.*tau[i])/8.;a=1.-omega+back
            generator=np.array([[-a,back,omega*k*(1.-beta)],[-back,a,-omega*k*beta],[0.,0.,-k]])
            transfer=expm(generator*width)
            for stream in range(2):
                row=2+2*i+stream;matrix[row,i+1+stream*(n+1)]=1.
                matrix[row,i]-=transfer[stream,0];matrix[row,n+1+i]-=transfer[stream,1];rhs[row]=transfer[stream,2]*beam[i]
        solved=np.linalg.solve(matrix,rhs);down,up=solved[:n+1],solved[n+1:]
        absorbed=down[:-1]+up[1:]+beam[:-1]-down[1:]-up[:-1]-beam[1:]
        leaf_abs=absorbed*np.asarray(fractions)
        values.append(dict(absorbed=absorbed,leaf_absorbed=leaf_abs,stem_absorbed=absorbed-leaf_abs,
                           reflected=up[0],ground_absorbed=(1.-ag[band])*(down[-1]+beam[-1])))
    return values


@pytest.mark.parametrize('mu',[.1,.5,1.])
@pytest.mark.parametrize('geometry',['forest','stem-only','leaf-only','varying'])
def test_pft_mixture_against_independent_continuous_reference(mu,geometry):
    leaf=np.full(10,.3);stem=np.full(10,.055)
    if geometry=='stem-only':leaf[:]=0.
    if geometry=='leaf-only':stem[:]=0.
    if geometry=='varying':leaf=np.linspace(0.,.7,10);stem=np.linspace(.12,0.,10)
    got=canopy_shortwave_pft(leaf,stem,700.,PFT1,diffuse_fraction=.6,cosine_zenith=mu)
    ref=continuous_mixture_reference(leaf,stem,PFT1,700.,.6,mu,(.15,.3))
    maximum={}
    for name in ('absorbed','leaf_absorbed','stem_absorbed'):
        expected=np.asarray([one[name] for one in ref])
        actual=np.asarray([b['absorbed'] for b in got['bands']]) if name=='absorbed' else got[name+'_bands']
        np.testing.assert_allclose(actual,expected,rtol=.1,atol=1e-8)
        maximum[name]=float(abs(actual-expected).max())
    for name in ('reflected','ground_absorbed'):
        expected=sum(one[name] for one in ref);np.testing.assert_allclose(got[name],expected,rtol=.1,atol=1e-8);maximum[name]=float(abs(got[name]-expected))
    np.testing.assert_allclose(got['leaf_absorbed']+got['stem_absorbed'],got['absorbed'],rtol=0.,atol=1e-12)
    np.testing.assert_allclose(got['absorbed_par']*leaf/4.6,got['leaf_absorbed_bands'][0],rtol=0.,atol=1e-12)
    assert abs(got['residual'])<1e-10
    print('PFT optics continuous reference',geometry,mu,maximum,flush=True)


def test_equal_tissue_optics_reproduce_generic_radiation_and_leaf_par():
    leaf=np.linspace(0.,.6,10);stem=np.linspace(.1,.02,10)
    got=canopy_shortwave_pft(leaf,stem,600.,CanopyOptics())
    ref=canopy_shortwave(leaf+stem,600.)
    for name in ('absorbed','absorbed_par','ground_absorbed','reflected'):
        # Leaf-free layers have no photosynthetic PAR, even when stems absorb.
        expected=np.where(leaf>0.,ref[name],0.) if name=='absorbed_par' else ref[name]
        np.testing.assert_allclose(got[name],expected,rtol=0.,atol=2e-10)


def test_nonabsorbing_leaves_never_supply_photosynthetic_par():
    p=CanopyOptics((.6,.8),(.4,.2),(.1,.2),(.1,.1))
    got=canopy_shortwave_pft(np.full(10,.3),np.full(10,.1),600.,p)
    np.testing.assert_array_equal(got['absorbed_par'],np.zeros(10))
    np.testing.assert_array_equal(got['leaf_absorbed'],np.zeros(10))
    assert got['stem_absorbed'].sum()>0. and abs(got['residual'])<1e-10


def test_bare_ground_is_finite_and_conservative():
    got=canopy_shortwave_pft(np.zeros(10),0.,600.,PFT1)
    np.testing.assert_array_equal(got['absorbed_par'],np.zeros(10))
    assert np.all(np.isfinite(got['stem_absorbed'])) and abs(got['residual'])<1e-10


@pytest.mark.parametrize('kwargs',[dict(leaf_reflectance=(np.nan,.2)),dict(stem_transmittance=(-.1,.2)),
    dict(leaf_reflectance=(.8,.1),leaf_transmittance=(.3,.2)),dict(stem_reflectance=(.2,.3,.4))])
def test_invalid_tissue_optics_fail_before_radiation(kwargs):
    with pytest.raises(ValueError):CanopyOptics(**kwargs)


def test_invalid_tissue_geometry_is_rejected():
    with pytest.raises(ValueError):mixed_optical_properties([.3,-.1],0.,PFT1)
    with pytest.raises(ValueError):mixed_optical_properties([.3,.1],np.nan,PFT1)

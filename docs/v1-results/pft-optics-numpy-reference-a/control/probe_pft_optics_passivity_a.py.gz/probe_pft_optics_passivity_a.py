from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'pft-optics-passivity-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();a=b/'pft-optics-final-a-source.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(a)=='9756cdd1e82e618da5b836538ccd27ab842e09c669910b173493a502af855d91'
with tarfile.open(a) as t:t.extractall(s,filter='data')
sys.path[:0]=[str(s/'src')]
from noahmp_clm.physics.canopy_optics import CanopyOptics,canopy_shortwave_pft,mixed_optical_properties
properties=CanopyOptics((.8,.8),(.2,.2),(.4,.4),(.6,.6));rng=np.random.default_rng(391821);failures=[];tested=0
for k in range(512):
    leaf=10.**rng.uniform(-5.,1.,10);stem=np.zeros(10) if k%3==0 else (10.**rng.uniform(-5.,1.,10))
    if k%3==1:leaf[:]=0.
    tested+=1
    try:result=canopy_shortwave_pft(leaf,stem,600.,properties,cosine_zenith=.4)
    except ValueError as e:
        _,rho,tau,f=mixed_optical_properties(leaf,stem,properties)
        failures.append(dict(case=k,leaf=leaf.tolist(),stem=stem.tolist(),exception=str(e),rho=rho.tolist(),tau=tau.tolist(),maximum_scattering=float((rho+tau).max())))
    if len(failures)>=3:break
record=dict(scope='EHPC read-only numerical diagnostic of valid perfectlynonabsorbing leaf/stem optical limits,not a test/pass claim or changed inputbounds. FrozenA source unchanged;record actual ValueErrors instead of assuming roundoff behavior.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,archive_sha256=sha(a),tested=tested,failures=failures)
(r/'diagnosis.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(tested=tested,failures=len(failures),first=failures[0] if failures else None)),flush=True)

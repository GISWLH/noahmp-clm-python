from pathlib import Path
import hashlib,json,sys,tarfile
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();mode=sys.argv[1]
if mode=='cpu':
    b=Path('/home/zhangyq/noahmp-v1');name='pft-optics-numpy-reference-a';roots=['pft-optics-numpy-a','pft-optics-numpy-b','pft-optics-reference-a','pft-optics-continuous-a','pft-optics-passivity-a'];extras=['pft-optics-numpy-a-source.tar.gz','pft-optics-numpy-b-source.tar.gz','pft-optics-final-a-source.tar.gz']
    controls=['run_pft_optics_numpy_a.py','run_pft_optics_numpy_b.py','dispatch_pft_optics_numpy_a.py','dispatch_pft_optics_numpy_b.py','generate_pft_optics_reference_a.py','audit_pft_optics_continuous_a.py','probe_pft_optics_passivity_a.py']
    for n in roots:assert (b/n/'pbs-exit.txt').read_text().strip()=='0'
elif mode=='gpu':
    b=Path('/home/lhwang/work/noahmp-v1');name='pft-optics-gpu19-a';roots=['pft-optics-final-a/targets-a'];extras=['pft-optics-final-a-source.tar.gz','pft-optics-cpu-final-a-evidence.tar.gz'];controls=['collect_pft_optics_gpu_a.py','control_pft_optics_gpu_a.py','launch_pft_optics_gpu_a.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']
    d=json.loads((b/roots[0]/'exit.json').read_text());assert d['passed'] and d['source_unchanged'] and len(d['results'])==3 and all(v['returncode']==0 for v in d['results'])
else:raise ValueError(mode)
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n in roots:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(b).as_posix(),recursive=False)
    for n in extras:t.add(b/n,arcname='source-and-prerequisites/'+n,recursive=False)
    for n in controls:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'pft-optics-numpy-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());a=b/'pft-optics-numpy-a-source.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==513 and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s/'src',s/'tests'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
xml=r/'targets.xml';start=time.monotonic()
with (r/'targets.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s','tests/test_canopy_optics.py','tests/test_canopy_radiation.py','--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
tree=ET.parse(xml).getroot();counts={k:sum(int(x.attrib[k]) for x in tree.iter('testsuite')) for k in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==h for n,h in m.items())
d=dict(scope='NumPy-first opticalmixture/reference onEHPC PBS compute node;actual originalpytest counts andall solver/energy/passivity gates retained,no GPU/coupled/year/science acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,counts=counts,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,xml_sha256=sha(xml))
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert code==0 and unchanged and counts['failures']==counts['errors']==counts['skipped']==0

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'pft-optics-numpy-b';r.mkdir(exist_ok=True);names=['run_pft_optics_numpy_b.py','pft_optics_numpy_b.pbs','pft-optics-numpy-b-package.json'];h={}
assert not (r/'dispatch.json').exists() and {p.name for p in r.iterdir()}<=set(names+['package.json'])
for n in names:
    raw=(b/n).read_bytes()
    if n.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if n.endswith('package.json') else n)).write_bytes(raw);h[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/names[1])],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=p.stdout.strip(),controls_sha256=h,scope='NumPy-first independent continuous opticalmixture component/reference,existingmodel511 unchanged,noGPU changes/default fit. Initial preflight rejected CRLF in structured packageJSON before qsub;no model launched. Python/PBS LF enforced,JSON bytes copied unchanged.'),indent=2)+'\n');print(p.stdout.strip())

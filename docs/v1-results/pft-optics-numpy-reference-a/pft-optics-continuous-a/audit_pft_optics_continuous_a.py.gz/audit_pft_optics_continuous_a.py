from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'pft-optics-continuous-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'pft-optics-numpy-b-source.tar.gz';assert sha(a)=='c66d67b0110d1ec176d2fd93b95efe963bf4f6c65b33549d25a85b0e14130530'
with tarfile.open(a) as t:t.extractall(s,filter='data')
sys.path[:0]=[str(s/'src'),str(s/'tests')]
from test_canopy_optics import continuous_mixture_reference
from noahmp_clm.physics.canopy_optics import CanopyOptics
fixture=b/'pft-optics-reference-a/pft_canopy_optics_reference.npz';assert sha(fixture)=='d14b4d302ddfe06f46a10d198919e9faabf1cfd2561c25d0a11742bf07f745cb'
with np.load(fixture,allow_pickle=False) as z:data=dict(z)
fields={};rows=[]
for i in range(len(data['64_a0'])):
    area=data['64_a0'][i];leaf=data['64_leaf'][i];u=data['64_a3'][i];p=CanopyOptics(*data['64_optics'][i].reshape(4,2));ad=data['64_ref_snow_direct_albedo'][i];af=data['64_ref_snow_diffuse_albedo'][i]
    ref=continuous_mixture_reference(leaf,area-leaf,p,u[0],u[2],u[3],af,ad)
    leaf_bands=np.array([v['leaf_absorbed'] for v in ref]);stem_bands=np.array([v['stem_absorbed'] for v in ref]);abs_bands=np.array([v['absorbed'] for v in ref]);par=np.divide(leaf_bands[0]*4.6,leaf,out=np.zeros_like(leaf),where=leaf>0.)
    beam=.5*u[0]*(1.-u[2]);sky=.5*u[0]*u[2];bare_reflected=float((ad*beam+af*sky).sum());reflected=u[1]*sum(v['reflected'] for v in ref)+(1.-u[1])*bare_reflected
    expected=dict(canopy_absorbed=u[1]*abs_bands.sum(0),absorbed_par=par,reflected=np.asarray(reflected),leaf_absorbed_bands=leaf_bands,stem_absorbed_bands=stem_bands)
    metrics={}
    for name,target in expected.items():
        actual=np.asarray(data['64_ref_'+name][i]);target=np.asarray(target);error=abs(actual-target);normal=abs(target)>1.
        relative=float(np.max(error[normal]/abs(target[normal]),initial=0.));absolute=float(np.max(error[~normal],initial=0.))
        assert relative<=.1 and absolute<=.1
        m=dict(maximum_absolute=float(np.max(error,initial=0.)),maximum_relative_percent=100.*relative,maximum_nearzero_absolute=absolute);metrics[name]=m
        one=fields.setdefault(name,{key:0. for key in m})
        for key,v in m.items():one[key]=max(one[key],v)
    ground=u[1]*sum(v['ground_absorbed'] for v in ref)+(1.-u[1])*(u[0]-bare_reflected)
    closure=float(u[0]-reflected-u[1]*abs_bands.sum()-ground);assert abs(closure)<2e-10
    rows.append(dict(case=i,metrics=metrics,independent_continuous_energy_residual_Wm2=closure))
record=dict(scope='EHPC independent dense simultaneous continuous3-stream BVP/matrix-exponential comparison for all47 actualquantized64 fixture cases including snoweffective boundaries anddistincttissue absorption. No production mixing/thinslab/doubling/boundary elimination helpers reused. Canopy-only validation with existingindependentlytestedSNICAR groundalbedos,not measured site/officialmodel scientific acceptance. Report normal>1 relative,nearzero<=1 absolute .1,conservation independenthard2e-10W.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,fixture_sha256=sha(fixture),cases=len(rows),maximum=fields,rows=rows)
(r/'audit.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pbs_job=record['pbs_job'],cases=len(rows),maximum=fields)),flush=True)

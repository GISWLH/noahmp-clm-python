from pathlib import Path
import gzip,hashlib,json,os,pickle,re,subprocess,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-failed-step-audit-mk';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();device=tmp/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==581 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')];package=json.loads((b/'climatology-failed-step-mj-export.json').read_text());archive_path=b/package['archive'];assert sha(archive_path)==package['sha256']
with tarfile.open(archive_path) as tf:tf.extractall(device,filter='data')
for job in ['1537.manager','1538.manager']:
    q=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);(r/(job+'-actual-qstat.txt')).write_text(q)
reference=b/'climatology-failed-reference-mi';ref=json.loads((reference/'receipt.json').read_text());assert ref['passed'] and ref['all12_attempts_completed'] and ref['source_unchanged'] and sha(reference/'diagnostic-input.npz')==sha(device/'diagnostic-input.npz')==ref['diagnostic_input_sha256'] and (reference/'binding.json').read_bytes()==(device/'binding.json').read_bytes();binding=json.loads((device/'binding.json').read_text());exit=json.loads((device/'exit.json').read_text());assert exit['all_diagnostics_complete'] and len(exit['records'])==2;details={};results=[];started=time.monotonic()
def equal(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,np.ndarray):return a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()
    if isinstance(a,dict):return a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    from dataclasses import asdict,is_dataclass
    if is_dataclass(a):return equal(asdict(a),asdict(b))
    return bool(a==b)
def json_safe(value):
    if isinstance(value,list):return [json_safe(v) for v in value]
    if isinstance(value,float) and not np.isfinite(value):return str(value)
    return value
def row_fields(value,k,prefix=''):
    out={}
    for name,item in value.items():
        if isinstance(item,dict):out.update(row_fields(item,k,prefix+name+'/'))
        else:
            item=np.asarray(item)
            if item.dtype.kind in 'biuf' and item.ndim and item.shape[0]==12:out[prefix+name]=json_safe(item[k].tolist())
    return out
for name in ['original-jn','density-md']:
    parent=next(x for x in exit['records'] if x['variant']==name);receipt=json.loads((device/name/'receipt.json').read_text());assert parent['actual_diagnostic_parent_returncode']==0 and parent['diagnostic_passed'] and sha(device/name/'receipt.json')==parent['receipt_sha256'] and receipt['diagnostic_completed'] and receipt['source_unchanged'] and receipt['device_barrier_complete'] and receipt['physical_state_input_arrays_unchanged_after_attempt'];assert not receipt['tendency_succeeded'] and receipt['tendency_failure']=='RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False' and receipt['original_surface_calls']==10 and receipt['captured_failed_surface_calls']==1
    plan=json.loads((device/'plan.json').read_text());assert receipt['source_manifest_sha256']==sha(device/plan['variants'][name]['manifest_file']) and receipt['diagnostic_input_sha256']==ref['diagnostic_input_sha256']
    packet=pickle.loads(gzip.decompress((device/name/'failed-surface-00.pkl.gz').read_bytes()));assert packet['original_call_index']==10;raw=packet['raw_failed_surface'];converged=np.asarray(raw['converged']);assert converged.shape==(12,) and converged.dtype.kind=='b';bad=np.flatnonzero(~converged);nonfinite=[]
    for key,value in raw.items():
        if isinstance(value,dict):continue
        value=np.asarray(value)
        if value.dtype.kind in 'f' and not np.isfinite(value).all():nonfinite.append(key)
    rows=[]
    for k in bad:rows.append(dict(column=int(k),case=binding['cases'][int(k)]['case'],time_start=binding['cases'][int(k)]['time_start'],actual_returned_fields=row_fields(raw,int(k))))
    results.append(dict(variant=name,actual_diagnostic_parent_exit=0,original_tendency_succeeded=False,original_tendency_failure=receipt['tendency_failure'],surface_call_index=10,failed_columns=bad.tolist(),nonfinite_returned_fields=nonfinite,failed_rows=rows,source_manifest_sha256=receipt['source_manifest_sha256']));details[name]=packet
same_args=equal(details['original-jn']['args'],details['density-md']['args']);same_kwargs=equal(details['original-jn']['kwargs'],details['density-md']['kwargs']);same_result=equal(details['original-jn']['raw_failed_surface'],details['density-md']['raw_failed_surface']);assert all(sha(s/n)==h for n,h in m.items());out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,seconds=time.monotonic()-started,source_unchanged=True,independent_reference_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_export_sha256=sha(archive_path),numpy_reference_job='1537.manager',numpy_all12_points_passed=True,reference_input_sha256=ref['diagnostic_input_sha256'],failed_surface_args_bitwise_equal_between_variants=same_args,failed_surface_kwargs_equal_between_variants=same_kwargs,failed_surface_returned_fields_bitwise_equal_between_variants=same_result,results=results,scope='Independentactualfailed2657 replaydiagnostic only. BothoriginalJN/privateMD tendencies stillraise at10thMOSTsurface call, diagnostic0neverphysicalsuccess. All12NumPyreference/hardbudgets actual0 first, sameoriginalinput andunmodified16statearrays verified. Returnedfailedrows/flags preserved forrootcause; no failedyearadvance, source/gate edit or densityfix/year/science acceptance. Raw741reservedslotsnotcapturedbywrapper, onlyoriginalunpackedreturnedfields; fullrawcapturewouldneedseparatefidelity proof.')
(r/'audit.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:out[k] for k in ['pbs_job','failed_surface_args_bitwise_equal_between_variants','failed_surface_kwargs_equal_between_variants','failed_surface_returned_fields_bitwise_equal_between_variants']}),flush=True);print(json.dumps([dict(variant=v['variant'],failed_columns=v['failed_columns'],nonfinite_returned_fields=v['nonfinite_returned_fields']) for v in results]),flush=True)

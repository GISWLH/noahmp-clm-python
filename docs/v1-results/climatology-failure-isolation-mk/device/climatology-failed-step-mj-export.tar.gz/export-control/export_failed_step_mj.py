from pathlib import Path
import hashlib,io,json,tarfile
r=Path('/home/lhwang/work/noahmp-v1/climatology-failed-step-mj');b=r.parent;sha=lambda raw:hashlib.sha256(raw).hexdigest();exit=json.loads((r/'exit.json').read_text());assert exit['all_diagnostics_complete'] and len(exit['records'])==2 and all(x['actual_diagnostic_parent_returncode']==0 and x['diagnostic_passed'] for x in exit['records']);plan=json.loads((r/'plan.json').read_text())
for row in exit['records']:
    name=row['variant'];receipt=json.loads((r/name/'receipt.json').read_text());assert sha((r/name/'receipt.json').read_bytes())==row['receipt_sha256'] and receipt['source_unchanged'] and receipt['device_barrier_complete'] and receipt['diagnostic_completed'];entry=plan['variants'][name];source=Path(entry['source']);m=json.loads((r/entry['manifest_file']).read_text());assert all(sha((source/n).read_bytes())==h for n,h in m.items())
payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()};payload['export-control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/'climatology-failed-step-mj-export.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in sorted(payload.items()):m=tarfile.TarInfo(name);m.size=len(raw);tf.addfile(m,io.BytesIO(raw))
with tarfile.open(a) as tf:
    assert len(tf.getmembers())==len(payload)
    for m in tf:assert tf.extractfile(m).read()==payload[m.name]
d=dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(payload),scope='MJ originalJN andprivateMD densitycandidate diagnosticparent0 only: BOTH actualtendencies raisedoriginalphasesurface RuntimeError atcall10; failedsurface readout saved afteroriginalexception andneverforwarded. Inputarrays/source unchanged, all12NumPyreference andMFactual0 precededGPU. No yearresume or physicalstep/K78production/scientific/releasepass. IndependentMK neededtointerpretactualfailedinputs/flags.');(b/'climatology-failed-step-mj-export.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

"""One diagnostic failed-input tendency, never a year continuation."""
from pathlib import Path
import gzip,hashlib,json,os,pickle,sys,time,traceback
import numpy as np
import cupy as cp
r=Path(__file__).resolve().parent;meta=json.loads((r/'plan.json').read_text());name=sys.argv[1];entry=meta['variants'][name];s=Path(entry['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((r/entry['manifest_file']).read_text());assert name in ['original-jn','density-md'] and all(sha(s/n)==h for n,h in m.items()) and sha(r/'diagnostic-input.npz')==meta['diagnostic_input_sha256'];sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as runner
import noahmp_clm.gpu.cuda.canopy_phase_surface as phase
with np.load(r/'diagnostic-input.npz',allow_pickle=False) as z:data=dict(z)
binding=json.loads((r/'binding.json').read_text());before=tuple(cp.asarray(data['a'+str(k)]) for k in range(16));original_host=tuple(cp.asnumpy(v) for v in before);kwargs=dict(environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=runner.LeafParameters(**binding['leaf_parameters']),return_surface=True)
if 'canopy_optics' in data:kwargs['canopy_optics']=data['canopy_optics']
hydrology=runner.hydrology_configuration(binding['cases'][0]['configuration'])
if hydrology is not None:kwargs['soil_hydrology']=hydrology
outdir=r/name;outdir.mkdir();calls=0;captured=[];original=phase.run_canopy_phase_surface_cuda
def host(v):
    if isinstance(v,cp.ndarray):return cp.asnumpy(v)
    if isinstance(v,dict):return {k:host(x) for k,x in v.items()}
    if isinstance(v,tuple):return tuple(host(x) for x in v)
    if isinstance(v,list):return [host(x) for x in v]
    return v
def observe(*args,**kw):
    global calls
    calls+=1
    try:return original(*args,**kw)
    except RuntimeError:
        diagnostic_kw=dict(kw,raise_on_failure=False);raw=original(*args,**diagnostic_kw);captured.append(dict(original_call_index=calls,args=host(args),kwargs=host(kw),raw_failed_surface=host(raw),scope='Second identicalinput readout onlyafter originalcall raised; no solveriteration/formula/source edits andno failedresult forwarded toMOST.'));raise
started=time.monotonic();tendency_error=None;export_error=None;barrier=False;succeeded=False
try:
    phase.run_canopy_phase_surface_cuda=observe
    try:
        engine=native.Backend('cuda32');result_device=engine.step(*before,data['forcing'],**kwargs);result=engine.host(result_device);after=tuple(engine.host(v) for v in native.next_bgc_arrays(before,result_device));flat={}
        def flatten(d,prefix=''):
            for k,v in d.items():
                if isinstance(v,dict):flatten(v,prefix+k+'/')
                else:flat[prefix+k]=np.asarray(v)
        flatten(result);flat.update({'before'+str(k):v for k,v in enumerate(original_host)});flat.update({'next'+str(k):v for k,v in enumerate(after)});np.savez_compressed(outdir/'output.npz',**flat);succeeded=True
    except Exception as err:tendency_error=type(err).__name__+': '+str(err);(outdir/'tendency-traceback.txt').write_text(traceback.format_exc())
    for k,packet in enumerate(captured):(outdir/('failed-surface-'+str(k).zfill(2)+'.pkl.gz')).write_bytes(gzip.compress(pickle.dumps(packet,protocol=5),mtime=0))
    unchanged_inputs=all(cp.asnumpy(v).tobytes()==h.tobytes() for v,h in zip(before,original_host));assert unchanged_inputs
    cp.cuda.runtime.deviceSynchronize();barrier=True
except Exception as err:export_error=type(err).__name__+': '+str(err);(outdir/'export-traceback.txt').write_text(traceback.format_exc())
finally:phase.run_canopy_phase_surface_cuda=original
unchanged=all(sha(s/n)==h for n,h in m.items());out=dict(variant=name,diagnostic_completed=export_error is None and barrier,tendency_succeeded=succeeded,tendency_failure=tendency_error,export_failure=export_error,source_unchanged=unchanged,source_manifest_sha256=sha(r/entry['manifest_file']),physical_state_input_arrays_unchanged_after_attempt=bool(export_error is None and unchanged_inputs),failed_attempt_index=2657,original_surface_calls=calls,captured_failed_surface_calls=len(captured),device_barrier_complete=barrier,diagnostic_input_sha256=sha(r/'diagnostic-input.npz'),output_sha256=sha(outdir/'output.npz') if succeeded else None,seconds=time.monotonic()-started,scope='Diagnostic-only original12column failed2657 input after all12 independentNumPyreferences0. OriginalJNI/orprivateMDsource explicitlybound. Originaltendency exception retained; repeatedsameinput surface readout onlyafter failure, neverpassed onward. No yearresume or report/status/forcing/source/gate reset, no NumPyforwardphysics/CPUreference onxuanze. Diagnosticparent0 isnot physicalstep/scientific/yearpass; independentMK required.')
(outdir/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if out['diagnostic_completed'] and unchanged else 1)

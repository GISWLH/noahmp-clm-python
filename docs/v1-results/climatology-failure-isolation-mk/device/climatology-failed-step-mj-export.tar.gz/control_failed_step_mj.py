from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for name in ['original-jn','density-md']:
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:break
        time.sleep(20.)
    with (r/(name+'-worker.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'probe_failed_step_mj.py'),name],stdout=log,stderr=subprocess.STDOUT)
    (r/(name+'-worker.json')).write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();path=r/name/'receipt.json';d=json.loads(path.read_text()) if path.exists() else {};row=dict(variant=name,actual_diagnostic_parent_returncode=code,diagnostic_passed=bool(code==0 and d.get('diagnostic_completed') and d.get('source_unchanged') and d.get('device_barrier_complete')),tendency_succeeded=d.get('tendency_succeeded'),receipt_sha256=sha(path) if path.exists() else None);(r/(name+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n');records.append(row)
    if not row['diagnostic_passed']:break
(r/'exit.json').write_text(json.dumps(dict(records=records,all_diagnostics_complete=len(records)==2 and all(x['diagnostic_passed'] for x in records)),indent=2)+'\n')

"""Prepared-only external trace of one unchanged original phase call on EHPC."""
from pathlib import Path
from dataclasses import fields,is_dataclass
import argparse
import copy
import hashlib
import importlib.util
import io
import json
import os
import pickle
import socket
import sys
import tarfile
import time
import traceback

sha=lambda raw:hashlib.sha256(raw).hexdigest()


def archive(path,expected):
    raw=path.read_bytes();assert sha(raw)==expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()]
        names=[m.name.removeprefix('./') for m in members]
        assert len(names)==len(set(names))
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts and '\\' not in n for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--py-result',type=Path,required=True)
    parser.add_argument('--qe-result',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert os.name!='nt' and socket.gethostname().split('.')[0]=='compute002'
    assert os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES')=='' and sys.dont_write_bytecode
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=args.output.resolve();assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists();root.mkdir()
    source_files=archive(args.source,'e83342c1b9634e0f12fe898aafd4e49e8e16477b07403bb20b8b3aa5fcf9af92')
    index=json.loads(source_files.pop('SOURCE_SHA256.json'));assert len(index)==584
    assert {n:sha(raw) for n,raw in source_files.items()}==index
    source=root/'source';source.mkdir()
    for name,raw in source_files.items():
        target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    py=archive(args.py_result,'c899a551629463dc3f4b159756f762df2f1fd91f23a4527091e24bf27a48b61d')
    qe=archive(args.qe_result,'bd6649543219b15ac5300f83a9221acecf8a4d44215194175fc4fe0c84d86135')
    qe_report=json.loads(qe['probe/readout.json'])
    assert qe_report['pbs_job']=='1840.manager' and qe_report['passed'] and qe_report['Qia_saved_first_phase_inputs_exact_to_PW']
    assert len(qe_report['Qia_original_phase_argument_names'])==27 and len(qe_report['Qia_saved_input_comparisons'])==60
    sys.path.insert(0,str(source/'src'))
    import numpy as np
    assert np.__version__=='2.2.6'
    import noahmp_clm.physics.canopy_phase_energy as phase
    kwargs=pickle.loads(py['probe/actual-row-0/first-phase-before.pkl'])
    old_observation=pickle.loads(py['probe/actual-row-0/actual-observation.pkl'])
    expected=old_observation['rescue_records'][0]
    assert expected['reason']=='no_feasible_displacement' and expected['last_iteration']==61
    before_kwargs=copy.deepcopy(kwargs)
    helper_path=root/'run_reference_pt.py'
    helper_path.write_bytes(py['probe/preparation/pt/run_reference_pt.py'])
    spec=importlib.util.spec_from_file_location('unchanged_dump_return_qf',helper_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.dump_return(root/'kwargs-before',kwargs)
    source_before={n:sha((source/n).read_bytes()) for n in index}
    (root/'source-before.json').write_text(json.dumps(source_before,indent=2)+'\n')
    assert source_before==index
    helper_code=phase._dry_lm_rescue.__code__
    code_lines=source_files['src/noahmp_clm/physics/canopy_phase_energy.py'].decode().splitlines()
    allowed=('x','lower','upper','active','phase_active','cap','iteration','used_iterations','max_iterations',
        'refresh','residual','jac','scale','scaled','normal','gradient','damping','matrix','factor','direction',
        'alpha','trial','displacement','norm','linear','predicted','trial_residual','actual','ratio','record')
    anchors={
        'if detail is None:detail=call(x,True)':'iteration_entered',
        'if refresh:':'current_residual_before_J_decision',
        'if damping is None:damping=max(np.finfo(float).eps,1e-3*float(np.max(np.diag(normal))))':'J_scaling_normal_gradient_complete',
        'matrix=normal+damping*np.eye(n+2)':'damping_before_linear_system',
        "record['linear_attempts']+=1":'linear_system_ready',
        'alpha=1./max(1.,float(np.max(abs(direction)/cap)))':'finite_direction_complete',
        'trial=np.clip(x+alpha*direction,lower,upper);displacement=trial-x':'common_alpha_complete',
        'if not np.isfinite(alpha) or alpha<=0. or not np.any(displacement):':'trial_and_displacement_complete',
        "record['rejected']+=1;record['reason']='no_feasible_displacement';return record":'reject_no_feasible_displacement',
        'if not np.isfinite(predicted) or predicted<=0.:':'linear_prediction_complete',
        "record['rejected']+=1;damping*=10.;continue":'reject_nonpositive_prediction',
        "trial_detail=call(trial,True);trial_residual=trial_detail['solver_residual']":'before_original_trial_evaluation',
        'actual=norm-float(trial_residual@trial_residual);ratio=actual/predicted':'original_trial_residual_complete',
        'if actual>0. and np.isfinite(ratio) and ratio>=.1:':'actual_reduction_and_ratio_complete',
        "x=trial;detail=trial_detail;record['x']=x.copy();record['accepted']+=1;refresh=True":'accept_original_strict_descent',
        "record['rejected']+=1;damping*=10.":'reject_original_reduction_or_ratio'
    }
    # Root review can verify all anchors are actual unchanged helper source.
    assert all(sum(line.strip()==text for line in code_lines)==1 for text in anchors)
    trace_events=[];observer_errors=[];helper_returns=[]
    state=dict(helper_calls=0,helper_returns=0,J_iteration=None,direction_iteration=None,prediction_iteration=None,trial_iteration=None)
    def snapshot(frame,event,anchor,arg=None):
        values=frame.f_locals
        iteration=values.get('iteration')
        if anchor=='J_scaling_normal_gradient_complete':state['J_iteration']=iteration
        if anchor=='finite_direction_complete':state['direction_iteration']=iteration
        if anchor=='linear_prediction_complete':state['prediction_iteration']=iteration
        if anchor=='original_trial_residual_complete':state['trial_iteration']=iteration
        record=dict(ordinal=len(trace_events),event=event,anchor=anchor,source_line=frame.f_lineno,
            source_text=code_lines[frame.f_lineno-1],line_event_observed_before_line_executes=(event=='line'),
            iteration=iteration,field_ages=copy.deepcopy(state),
            locals={name:copy.deepcopy(values[name]) for name in allowed if name in values})
        if 'detail' in values and values['detail'] is not None:
            record['already_computed_detail']={name:copy.deepcopy(values['detail'][name]) for name in ('solver_residual','layer_residual') if name in values['detail']}
        if event=='return':record['returned_record']=copy.deepcopy(arg)
        if event=='exception':record['exception_type']=arg[0].__name__;record['exception_message']=str(arg[1])
        trace_events.append(record)
    def trace_lm(frame,event,arg):
        try:
            if frame.f_code is not helper_code:return None
            if event=='call':
                state['helper_calls']+=1;snapshot(frame,event,'original_helper_entry')
            elif event=='line':
                anchor=anchors.get(code_lines[frame.f_lineno-1].strip())
                if anchor:snapshot(frame,event,anchor)
            elif event=='return':
                state['helper_returns']+=1;helper_returns.append(copy.deepcopy(arg));snapshot(frame,event,'original_helper_return',arg)
            elif event=='exception':snapshot(frame,event,'original_helper_exception',arg)
        except BaseException:
            observer_errors.append(traceback.format_exc())
        return trace_lm if frame.f_code is helper_code else None
    before_trace=sys.gettrace();assert before_trace is None
    original_error=None;phase_value=None;calls=0;started=time.monotonic()
    try:
        sys.settrace(trace_lm)
        calls+=1
        phase_value=phase.solve_canopy_phase_energy(**kwargs)
    except BaseException as error:
        original_error=error
        original_traceback=traceback.format_exc()
    finally:
        sys.settrace(before_trace)
    helper.dump_return(root/'kwargs-after',kwargs)
    source_after={n:sha((source/n).read_bytes()) for n in index}
    (root/'source-after.json').write_text(json.dumps(source_after,indent=2)+'\n')
    packet=dict(phase_calls=calls,helper_state=state,events=trace_events,helper_returns=helper_returns,
        observer_errors=observer_errors,original_exception_type=type(original_error).__name__ if original_error else None,
        original_exception_message=str(original_error) if original_error else None,
        original_traceback=original_traceback if original_error else None,unexpected_phase_value=phase_value,
        seconds=time.monotonic()-started,extra_evaluate_calls=0,extra_Jacobian_computations=0)
    # Preserve all computed original locals before any interpretation/check.
    helper.dump_return(root/'raw-observation',packet)
    result=dict(conclusive=False,original_model_returned=False,original_model_exception_preserved=True,
        expected_original_model_exit=1,phase_calls=calls,extra_evaluate_calls=0,extra_Jacobian_computations=0,
        source_unchanged=False,inputs_unchanged=False,original_rescue_record_exact=False,
        source_before_sha256=sha((root/'source-before.json').read_bytes()),
        source_after_sha256=sha((root/'source-after.json').read_bytes()),
        kwargs_before_pickle_sha256=sha((root/'kwargs-before.pkl').read_bytes()),
        kwargs_after_pickle_sha256=sha((root/'kwargs-after.pkl').read_bytes()))
    def exact(left,right):
        if is_dataclass(left) or is_dataclass(right):
            assert type(left) is type(right)
            for f in fields(left):exact(getattr(left,f.name),getattr(right,f.name))
        elif isinstance(left,dict) or isinstance(right,dict):
            assert isinstance(left,dict) and isinstance(right,dict) and set(left)==set(right)
            for key in left:exact(left[key],right[key])
        elif isinstance(left,(tuple,list)) or isinstance(right,(tuple,list)):
            assert type(left) is type(right) and len(left)==len(right)
            for a,b in zip(left,right):exact(a,b)
        elif isinstance(left,(np.ndarray,np.generic)) or isinstance(right,(np.ndarray,np.generic)):
            a,b=np.asarray(left),np.asarray(right)
            assert a.dtype==b.dtype and a.shape==b.shape and a.tobytes(order='C')==b.tobytes(order='C')
        else:assert type(left) is type(right) and left==right
    try:
        assert original_error is not None and type(original_error) is RuntimeError
        expected_message=old_observation['exception'].strip().splitlines()[-1].removeprefix('RuntimeError: ')
        assert str(original_error)==expected_message
        assert calls==state['helper_calls']==state['helper_returns']==len(helper_returns)==1 and not observer_errors
        exact(helper_returns[0],expected);result['original_rescue_record_exact']=True
        exact(kwargs,before_kwargs);result['inputs_unchanged']=True
        assert {n:sha((source/n).read_bytes()) for n in index}==index;result['source_unchanged']=True
        result['conclusive']=True
    except BaseException:
        result['inconclusive_reason']=traceback.format_exc()
    helper.dump_return(root/'replay-identity',result)
    if original_error is not None:raise original_error
    raise RuntimeError('QF replay unexpectedly returned; diagnostic inconclusive, no repair credit')


if __name__=='__main__':main()

"""One frozen original-call trace worker; retain expected physical exception exit."""
from pathlib import Path
import hashlib
import json
import math
import os
import pickle
import shutil
import socket
import subprocess
import sys
import time
import traceback

STAGE=Path('/tmp/noahmp-surface-lm-transparent-trace-qf')
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def scalar_tree(node):
    if node['kind']=='dict':return {k:scalar_tree(v) for k,v in node['items'].items()}
    if node['kind'] in ('tuple','list'):return [scalar_tree(v) for v in node['items']]
    if node['kind']=='float':return float.fromhex(node['hex'])
    if node['kind']=='array':return {k:v for k,v in node.items() if k!='kind'}
    return node.get('value')


def json_safe(value):
    if isinstance(value,float) and not math.isfinite(value):return dict(finite=False,hex=value.hex())
    if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
    if isinstance(value,list):return [json_safe(v) for v in value]
    return value


def main():
    assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=Path(sys.argv[1]).resolve();assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists();root.mkdir()
    started=time.monotonic();index={};status=1
    receipt=dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),actual_children=[],diagnostic_conclusive=False,
        original_physical_failure_preserved=True,physical_model_succeeded=False,original_PY_c_job='1822.manager',
        original_phase_calls_planned=1,extra_evaluate_calls=0,extra_Jacobian_computations=0,GPU_calls=0,
        complete_column_steps=0,annual_or_scientific_acceptance=False)
    try:
        index=json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/n).read_bytes())==h for n,h in index.items())
        for folder in ('preparation','execution'):
            shutil.copytree(STAGE/folder,root/folder)
            controls=json.loads((root/folder/'CONTROLS_SHA256.json').read_bytes())
            assert all(sha((root/folder/n).read_bytes())==h for n,h in controls.items())
        binding=json.loads((root/'preparation/BINDINGS.json').read_bytes())
        for filename,key in (('source.tar.gz','source_archive_sha256'),('py-c-result.tar.gz','PY_c_result_sha256'),('qe-c-result.tar.gz','QE_c_result_sha256')):
            assert sha((STAGE/filename).read_bytes())==binding[key]
        command=[sys.executable,'-B',str(root/'preparation/trace_original_qia_lm_qf.py'),
            '--source',str(STAGE/'source.tar.gz'),'--py-result',str(STAGE/'py-c-result.tar.gz'),
            '--qe-result',str(STAGE/'qe-c-result.tar.gz'),'--output',str(root/'trace')]
        entry=dict(command=command,timeout_seconds=480,timed_out=False,actual_child_returncode=None)
        receipt['actual_children'].append(entry);begin=time.monotonic()
        try:
            child=subprocess.run(command,capture_output=True,timeout=480)
            (root/'original-worker.stdout').write_bytes(child.stdout);(root/'original-worker.stderr').write_bytes(child.stderr)
            entry['actual_child_returncode']=child.returncode
            status=child.returncode if child.returncode>0 else 128-child.returncode if child.returncode<0 else 1
        except subprocess.TimeoutExpired as error:
            entry['timed_out']=True;status=1
            (root/'original-worker.stdout').write_bytes(error.stdout or b'');(root/'original-worker.stderr').write_bytes(error.stderr or b'')
        finally:
            entry['seconds']=time.monotonic()-begin
        identity_path=root/'trace/replay-identity.json'
        if identity_path.exists():
            metadata=json.loads(identity_path.read_bytes());identity=scalar_tree(metadata['tree'])
            receipt['replay_identity']=identity
            assert sha((root/'trace/replay-identity.pkl').read_bytes())==metadata['pickle_sha256']
            assert sha((root/'trace/replay-identity.npz').read_bytes())==metadata['npz_sha256']
            receipt['diagnostic_conclusive']=(identity['conclusive'] and identity['source_unchanged'] and identity['inputs_unchanged']
                and identity['original_rescue_record_exact'] and identity['phase_calls']==1
                and entry['actual_child_returncode']==1 and not entry['timed_out'])
        # Never normalize an expected original model exception to success.
        assert entry['actual_child_returncode']!=0 or entry['timed_out'],'Original worker unexpectedly returned0'
    except BaseException:
        receipt['wrapper_exception']=traceback.format_exc();status=1
    finally:
        after={n:sha((STAGE/n).read_bytes()) for n in index}
        receipt['stage_before_after_exact']=bool(index) and after==index
        copied_exact=True
        for folder in ('preparation','execution'):
            if not (root/folder).exists():copied_exact=False;continue
            copied_exact=copied_exact and all(sha((root/folder/n).read_bytes())==h for n,h in json.loads((root/folder/'CONTROLS_SHA256.json').read_bytes()).items())
        receipt['copied_controls_before_after_exact']=copied_exact
        if not receipt['stage_before_after_exact'] or not copied_exact:
            receipt['diagnostic_conclusive']=False;status=1
        receipt.update(wrapper_actual_exit=status,seconds=time.monotonic()-started,
            scope='One new diagnostic original phase replay, original exception retained; no physical repair or column/year/scientific acceptance.')
        raw_receipt=pickle.dumps(receipt,protocol=5);(root/'receipt.pkl').write_bytes(raw_receipt)
        receipt['raw_receipt_pickle_sha256']=sha(raw_receipt)
        (root/'receipt.json').write_text(json.dumps(json_safe(receipt),indent=2,allow_nan=False)+'\n')
    return status


if __name__=='__main__':sys.exit(main())

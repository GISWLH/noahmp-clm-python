"""Bounded EHPC export lifecycle; child actual exit and all raw logs retained."""
from pathlib import Path
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback
from contract_po import cpu_host,controls,save,sha,HERE,SOURCE_SHA


def main():
    cpu_host()
    stage=Path(sys.argv[1]).resolve();root=Path(sys.argv[2]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir();source=root/'source';source.mkdir()
    receipt=dict(passed=False,pbs_job=os.environ['PBS_JOBID'],child_returncode=None,error=None,
                 GPU_runs=0,coupled_columns=0,field_years=0)
    started=time.monotonic()
    try:
        binding=__import__('json').loads((HERE/'PO_BINDINGS.json').read_bytes())
        archive=stage/'source.tar.gz'
        assert sha(archive.read_bytes())==binding['source_archive_sha256']
        with tarfile.open(archive) as tar:
            entries=tar.getmembers()
            assert len(entries)==585 and len({m.name for m in entries})==585
            for m in entries:
                assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name
                target=source/m.name;target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(tar.extractfile(m).read())
        assert sha((source/'SOURCE_SHA256.json').read_bytes())==SOURCE_SHA
        identity=controls(source);receipt.update(identity)
        env=os.environ.copy();env.pop('PYTHONHOME',None)
        env.update(PYTHONPATH=str(source/'src')+':'+str(HERE)+':/home/zhangyq/noahmp-v1/test-deps',
            PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',JAX_PLATFORMS='cpu',
            OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
        command=[sys.executable,'-B',str(HERE/'export_gold_po.py'),'--source',str(source),'--output',str(root/'gold')]
        save(root/'command.json',command)
        with (root/'checker.stdout.txt').open('wb') as out,(root/'checker.stderr.txt').open('wb') as err:
            checked=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_arrays_po'],env=env,
                cwd=HERE,stdout=out,stderr=err,timeout=60)
        receipt['checker_parent_returncode']=checked.returncode
        log=(root/'checker.stderr.txt').read_text()
        assert checked.returncode==0 and len(re.findall(r'^test_\S+ \([^\n]+\) \.\.\. ok$',log,re.M))==9
        assert re.search(r'^Ran 9 tests in ',log,re.M) and re.search(r'^OK$',log,re.M)
        receipt['actual_checker_tests']=9
        with (root/'export.stdout.txt').open('wb') as stdout,(root/'export.stderr.txt').open('wb') as stderr:
            result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=1000)
        receipt['child_returncode']=result.returncode
        (root/'child-exit.txt').write_text(str(result.returncode)+'\n')
        receipt['source_and_controls_unchanged']=controls(source)==identity
        assert result.returncode==0 and receipt['source_and_controls_unchanged']
        summary=__import__('json').loads((root/'gold/export-summary.json').read_bytes())
        assert summary['passed'] and summary['cases']==20 and summary['actual_full_integrations']==34
        receipt['actual_export_summary']=summary;receipt['passed']=True
    except Exception:
        receipt['error']=traceback.format_exc();(root/'failure.txt').write_text(receipt['error'])
    receipt['seconds']=time.monotonic()-started
    save(root/'export-receipt.json',receipt)
    # Full source identity remains; the immutable 584-file source archive is already
    # fixed separately, so a successful export need not retransmit its unpacked copy.
    if receipt['passed']:
        shutil.copyfile(source/'SOURCE_SHA256.json',root/'SOURCE_SHA256.json')
    return 0 if receipt['passed'] else 1


if __name__=='__main__':raise SystemExit(main())

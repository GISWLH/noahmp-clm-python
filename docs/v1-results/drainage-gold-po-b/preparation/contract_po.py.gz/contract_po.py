"""Stdlib identity checks for the isolated drainage device handoff."""
from pathlib import Path
import hashlib
import json
import os
import socket

HERE = Path(__file__).resolve().parent
GPU = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
SOURCE_SHA = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def checked_index(root, name, expected=None):
    root = Path(root).resolve()
    raw = (root / name).read_bytes()
    if expected is not None:
        assert sha(raw) == expected, (name, 'manifest identity')
    index = json.loads(raw)
    for n, digest in index.items():
        p = (root / n).resolve()
        assert p.is_relative_to(root) and p.is_file() and not p.is_symlink(), n
        assert sha(p.read_bytes()) == digest, n
    return index


def controls(source):
    source = Path(source).resolve()
    index = checked_index(HERE, 'CONTROLS_SHA256.json')
    assert {p.name for p in HERE.iterdir() if p.is_file()} == set(index) | {'CONTROLS_SHA256.json'}
    originals = checked_index(HERE, 'ORIGINAL_K_CONTROLS_SHA256.json')
    bindings = json.loads((HERE / 'PO_BINDINGS.json').read_bytes())
    assert sha((HERE / 'ORIGINAL_K_CONTROLS_SHA256.json').read_bytes()) == bindings['K_manifest_sha256']
    assert len(originals) == 17
    src = checked_index(source, 'SOURCE_SHA256.json', SOURCE_SHA)
    assert len(src) == 584
    assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == set(src) | {'SOURCE_SHA256.json'}
    return dict(controls_manifest_sha256=sha((HERE / 'CONTROLS_SHA256.json').read_bytes()),
                source_manifest_sha256=SOURCE_SHA, source_files=584)


def cpu_host():
    assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''


def gpu_host():
    assert os.name != 'nt' and os.environ.get('CUDA_VISIBLE_DEVICES') == GPU
    assert os.environ.get('JAX_PLATFORMS') == 'cuda'
    assert os.environ.get('JAX_ENABLE_X64', '').lower() == 'true'
    # Cache placement must be private, explicit and outside every active source.
    caches = [Path(os.environ[n]).resolve() for n in
              ('CUPY_CACHE_DIR', 'JAX_COMPILATION_CACHE_DIR', 'CUDA_CACHE_PATH')]
    assert len(set(caches)) == 3 and all(str(p).startswith('/tmp/drainage-po-') for p in caches)


def closed_gold(root, seal):
    """Only a separately closed actual EHPC export is eligible for device work."""
    root = Path(root).resolve()
    seal = json.loads(Path(seal).read_bytes())
    checked_index(root, 'gold-inventory.json', seal['gold_inventory_sha256'])
    qraw = (root / 'export-qstat-final.txt').read_bytes()
    assert sha(qraw) == seal['qstat_final_sha256']
    fields = {}
    for line in qraw.decode().splitlines():
        if ' = ' in line:
            key, value = line.strip().split(' = ', 1)
            fields[key] = value
    assert fields['job_state'] == 'F' and fields['Exit_status'] == '0'
    assert fields['Stageout_status'] == '0'
    assert qraw.decode().splitlines()[0].strip() == 'Job Id: ' + seal['pbs_job']
    assert (root / 'export-parent-exit.txt').read_text().strip() == '0'
    receipt = json.loads((root / 'export-receipt.json').read_bytes())
    assert receipt['passed'] and receipt['pbs_job'] == seal['pbs_job'] and receipt['child_returncode'] == 0
    assert receipt['checker_parent_returncode']==0 and receipt['actual_checker_tests']==9
    assert receipt['source_and_controls_unchanged']
    assert receipt['controls_manifest_sha256'] == sha((HERE / 'CONTROLS_SHA256.json').read_bytes())
    assert receipt['source_manifest_sha256'] == SOURCE_SHA
    return seal

"""Small EHPC-only checker oracles; these tests never call model physics."""
from contract_po import cpu_host
cpu_host()
from pathlib import Path
import tempfile
import unittest
import numpy as np
from arrays_po import descriptor,freeze,read_arrays,same_precision,physical,hard_audit


class ArrayContractTests(unittest.TestCase):
    def test_hard_audit_numpy32_metadata_is_json_serializable(self):
        import json
        c=np.zeros((4,6),np.float32);c[:,4]=1.;c[:,5]=2.
        outputs={}
        for col,label,residual,bound in [(4,'water','water_residual_kg_m2','water_bound_kg_m2'),
                (5,'enthalpy','energy_residual_j_m2','energy_bound_j_m2')]:
            outputs['trial.'+label+'_after']=c[:,col].copy()
            outputs['trial.'+('layer_mass_kg_m2' if col==4 else 'layer_enthalpy_j_m2')]=np.zeros(4,np.float32)
            outputs['trial.'+residual]=np.float32(0.)
            outputs['trial.'+bound]=np.float32(64*np.finfo(np.float32).eps*(8. if col==4 else 16.))
        audit=hard_audit({'cells':c},outputs,'numpy')
        decoded=json.loads(json.dumps(audit,allow_nan=False))
        for label,col,scale,bound in [('water',4,8.,'water_bound_kg_m2'),('heat',5,16.,'energy_bound_j_m2')]:
            self.assertEqual(decoded['trial'][label]['independently_scaled_bound'],float(64*np.finfo(c.dtype).eps*scale))
            self.assertEqual(decoded['trial'][label]['original_bound'],float(outputs['trial.'+bound]))
            self.assertEqual(decoded['trial'][label]['native_residual'],0.)

    def test_plain_arrays_scalar_dtype_shape_bytes_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            values={'cells':np.asarray([[0.,-0.,1.25]],np.float32),'option':np.asarray(2,np.int32)}
            path=Path(d)/'a.npz';freeze(path,values);after=read_arrays(path)
            self.assertEqual({k:descriptor(v) for k,v in values.items()},{k:descriptor(v) for k,v in after.items()})

    def test_changed_npz_rejected_before_deserialization(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'a.npz';freeze(path,{'x':np.asarray([1.],np.float32)})
            path.write_bytes(path.read_bytes()+b'changed')
            with self.assertRaises(AssertionError):read_arrays(path)

    def test_continuous_return_uses_fixed_one_em6_rule(self):
        b={'diagnosis.main_theta_m':np.asarray(1.,np.float32)}
        self.assertTrue(same_precision({'diagnosis.main_theta_m':np.asarray(1.000001,np.float32)},b)['passed'])
        self.assertFalse(same_precision({'diagnosis.main_theta_m':np.asarray(1.00001,np.float32)},b)['passed'])

    def test_discrete_counts_flags_and_donor_exact(self):
        for key,dtype in [('full.accepted_substeps',np.int64),('diagnosis.transition_count',np.float32),
                          ('trial.first_donor',np.float32),('trial.liquid_limited',np.float32)]:
            self.assertFalse(same_precision({key:np.asarray(1,dtype)},{key:np.asarray(0,dtype)})['passed'])
        self.assertFalse(same_precision({'full.production_registered':np.asarray(True)},
                                       {'full.production_registered':np.asarray(False)})['passed'])

    def test_dtype_shape_and_missing_return_rejected(self):
        a={'x':np.asarray([1.],np.float32)}
        for b in [{'x':np.asarray([1.],np.float64)},{'x':np.asarray(1.,np.float32)},{}]:
            with self.assertRaises(AssertionError):same_precision(a,b)

    def test_nonfinite_and_object_arrays_rejected(self):
        for value in [np.asarray([np.nan]),np.asarray([np.inf]),np.asarray(['x'],object)]:
            with self.assertRaises(AssertionError):descriptor(value)

    def test_nearzero_uses_absolute_tolerance_without_percentage(self):
        values={
            'trial.layer_mass_kg_m2':np.asarray([0.]),'trial.layer_enthalpy_j_m2':np.asarray([0.]),
            'trial.front':np.asarray(.5),'trial.water_after':np.asarray([100.]),'trial.enthalpy_after':np.asarray([1.e7])}
        a={k:v.copy() for k,v in values.items()};a['trial.layer_mass_kg_m2'][0]=.0009
        result=physical(a,values,'main');self.assertTrue(result['passed'])
        self.assertEqual(result['fields']['trial.mass']['percent_where_relative_applies'],[None])
        a['trial.layer_mass_kg_m2'][0]=.0011
        self.assertFalse(physical(a,values,'main')['passed'])

    def test_hard_budget_numeric_return_is_not_excluded_from_pair(self):
        a={'full.energy_residual_j_m2':np.asarray(.01,np.float32)}
        b={'full.energy_residual_j_m2':np.asarray(0.,np.float32)}
        result=same_precision(a,b)
        self.assertEqual(set(result['fields']),set(a));self.assertFalse(result['passed'])


if __name__=='__main__':unittest.main()

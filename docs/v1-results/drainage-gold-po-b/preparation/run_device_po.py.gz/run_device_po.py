"""One isolated future JAX32 or CUDA32 worker. This file does not schedule work."""
from pathlib import Path
import argparse
import importlib.metadata
import json
import os
import subprocess
import sys
import time
import traceback
from contract_po import gpu_host, controls, closed_gold, save, sha, GPU


def main():
    p=argparse.ArgumentParser()
    for key in ('source','gold','seal','output'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--backend',choices=('cuda','jax'),required=True)
    args=p.parse_args();gpu_host();identity=controls(args.source);seal=closed_gold(args.gold,args.seal)
    assert not args.output.exists();args.output.mkdir()
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024, 'Original 8GiB/32GiB startup resource gate'
    sys.path.insert(0,str(args.source.resolve()/'src'))
    if args.backend=='jax':
        assert importlib.metadata.version('jax')==importlib.metadata.version('jaxlib')=='0.11.2'
        import jax
        jax.config.update('jax_enable_x64',True)
        assert len(jax.devices())==1 and jax.devices()[0].platform=='gpu'
        devices=str(jax.devices())
    else:
        import cupy as cp
        assert cp.cuda.runtime.getDeviceCount()==1
        cp.cuda.Device(0).use();cp.cuda.runtime.free(0)
        devices=str(cp.cuda.runtime.getDeviceProperties(0)['name'])
    from arrays_po import read_arrays,freeze,run_one,physical,same_precision
    from cases_po import cases
    recipe=json.loads((args.gold/'case-recipes.json').read_bytes());assert recipe==cases()
    receipt=dict(**identity,passed=False,backend=args.backend,precision='float32',pid=os.getpid(),
        gpu_uuid=GPU,devices=devices,started_unix=time.time(),gold_seal_sha256=sha(args.seal.read_bytes()),
        gold_inventory_sha256=seal['gold_inventory_sha256'],resource_start=dict(gpu_free_mib=free,host_available_kib=available),
        cases=[],error=None,coupled_columns=0,field_years=0,production_registered=False)
    receipt['environment']=dict(python=sys.version,python_executable=sys.executable,
        numpy=importlib.metadata.version('numpy'),jax=importlib.metadata.version('jax'),
        jaxlib=importlib.metadata.version('jaxlib'))
    if args.backend=='cuda':receipt['environment']['cupy']=cp.__version__
    try:
        for row in recipe:
            name=row['name'];out=args.output/name;out.mkdir()
            inputs=read_arrays(args.gold/name/'input32.npz')
            # No fixture/reconstruction/quantization executes on xuanze.
            observed=dict(case=name,completed=False)
            try:
                result,run=run_one(inputs,row,args.backend,observed=observed)
                observed['completed']=True
            finally:
                save(out/'observed-calls.json',observed)
            freeze(out/'result.npz',result);save(out/'run.json',run)
            ref=read_arrays(args.gold/name/'numpy64.npz')
            physical_comparison=physical(result,ref,row['kind'])
            # This additional comparison is reported fully; primary device same-
            # precision acceptance is the separately closed CUDA32/JAX32 pair.
            numpy32_difference=same_precision(result,read_arrays(args.gold/name/'numpy32.npz'))
            apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True)
            own=[line.split(',')[1].strip() for line in apps.splitlines() if line.split(',')[0].strip()==str(os.getpid())]
            assert own and set(own)=={GPU}, 'Actual physical UUID for this PID'
            save(out/'gpu-own-process.json',dict(pid=os.getpid(),gpu_uuids=own))
            case=dict(case=name,run=run,physical64=physical_comparison,numpy32_differences=numpy32_difference)
            save(out/'comparison.json',case);receipt['cases'].append(case)
            print('PO_DEVICE_CASE '+json.dumps(case,allow_nan=False),flush=True)
        assert len(receipt['cases'])==20
        assert all(r['physical64']['passed'] for r in receipt['cases'])
        assert controls(args.source)==identity
        closed_gold(args.gold,args.seal)
        receipt['source_controls_gold_unchanged']=True
        receipt['passed']=True
    except Exception:
        receipt['error']=traceback.format_exc()
        (args.output/'failure.txt').write_text(receipt['error'])
    receipt['seconds']=time.time()-receipt['started_unix']
    save(args.output/'device-receipt.json',receipt)
    return 0 if receipt['passed'] else 1


if __name__=='__main__':raise SystemExit(main())

"""Prepared one-worker lifecycle, invoked only at root's future queue handoff."""
from pathlib import Path
import argparse
import os
import subprocess
import sys
import time
import traceback
from contract_po import HERE,GPU,controls,closed_gold,save,sha


def main():
    p=argparse.ArgumentParser()
    for key in ('source','gold','seal','output'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--backend',choices=('cuda','jax'),required=True)
    a=p.parse_args();assert os.name!='nt'
    controls(a.source);closed_gold(a.gold,a.seal)
    root=a.output.resolve()
    assert str(root).startswith('/tmp/drainage-po-') and not root.exists()
    root.mkdir()
    env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('LD_LIBRARY_PATH',None)
    env.update(PYTHONPATH=str(a.source.resolve()/'src')+':'+str(HERE),
        CUDA_VISIBLE_DEVICES=GPU,JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',
        XLA_PYTHON_CLIENT_PREALLOCATE='false',PYTHONDONTWRITEBYTECODE='1',
        OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
        CUPY_CACHE_DIR=str(root/'cupy-cache'),JAX_COMPILATION_CACHE_DIR=str(root/'jax-cache'),
        CUDA_CACHE_PATH=str(root/'cuda-cache'),CUDA_PATH='/usr/local/cuda-12.4')
    command=[sys.executable,'-B',str(HERE/'run_device_po.py'),'--source',str(a.source.resolve()),
        '--gold',str(a.gold.resolve()),'--seal',str(a.seal.resolve()),'--output',str(root/'device'),'--backend',a.backend]
    receipt=dict(backend=a.backend,completed=False,returncode=None,error=None,walltime_limit_seconds=10800,
        command=command,started_unix=time.time(),gpu_uuid=GPU)
    child=None
    try:
        with (root/'device.stdout.txt').open('wb') as out,(root/'device.stderr.txt').open('wb') as err:
            child=subprocess.Popen(command,env=env,stdout=out,stderr=err)
            receipt['pid']=child.pid
            stat=Path('/proc')/str(child.pid)/'stat'
            receipt['proc_stat_at_launch']=stat.read_text() if stat.exists() else None
            save(root/'device-launch.json',receipt)
            receipt['returncode']=child.wait(timeout=10800)
        receipt['completed']=True
    except Exception:
        receipt['error']=traceback.format_exc()
        if child is not None and child.poll() is None:
            child.kill();receipt['returncode']=child.wait()
        receipt['completed']=False
    path=root/'device/device-receipt.json'
    if path.exists():receipt['device_receipt_sha256']=sha(path.read_bytes())
    receipt['seconds']=time.time()-receipt['started_unix']
    save(root/'device-parent-receipt.json',receipt)
    code=0 if receipt['completed'] and receipt['returncode']==0 else 1
    (root/'device-parent-exit.txt').write_text(str(code)+'\n')
    return code


if __name__=='__main__':raise SystemExit(main())

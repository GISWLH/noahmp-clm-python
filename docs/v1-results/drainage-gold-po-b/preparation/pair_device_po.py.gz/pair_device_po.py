"""Remote numerical comparison of two already closed 32-bit device packets."""
from pathlib import Path
import argparse
import json
import os
import sys
from contract_po import controls,closed_gold,sha,save


def main():
    p=argparse.ArgumentParser()
    for key in ('source','gold','seal','cuda','jax','output'):p.add_argument('--'+key,type=Path,required=True)
    a=p.parse_args()
    assert os.name!='nt';identity=controls(a.source);seal=closed_gold(a.gold,a.seal)
    sys.path.insert(0,str(a.source.resolve()/'src'))
    from arrays_po import read_arrays,same_precision
    from cases_po import cases
    receipts=[]
    for backend,root in [('cuda',a.cuda),('jax',a.jax)]:
        assert (root/'device-parent-exit.txt').read_text().strip()=='0'
        parent=json.loads((root/'device-parent-receipt.json').read_bytes())
        assert parent['returncode']==0 and parent['backend']==backend and parent['completed']
        r=json.loads((root/'device/device-receipt.json').read_bytes())
        assert sha((root/'device/device-receipt.json').read_bytes())==parent['device_receipt_sha256']
        assert r['backend']==backend and r['passed'] and r['source_controls_gold_unchanged']
        assert r['controls_manifest_sha256']==identity['controls_manifest_sha256']
        assert r['source_manifest_sha256']==identity['source_manifest_sha256']
        assert r['gold_inventory_sha256']==seal['gold_inventory_sha256']
        assert r['gold_seal_sha256']==sha(a.seal.read_bytes())
        assert [v['case'] for v in r['cases']]==[v['name'] for v in cases()]
        receipts.append(r)
    comparisons={}
    for row in cases():
        name=row['name']
        comparisons[name]=same_precision(read_arrays(a.cuda/'device'/name/'result.npz'),read_arrays(a.jax/'device'/name/'result.npz'))
    result=dict(**identity,passed=all(v['passed'] for v in comparisons.values()),cases=comparisons,
        gold_inventory_sha256=seal['gold_inventory_sha256'],same_exact_float32_inputs=True,
        all_numeric_returns_included=True,discrete_returns_exact=True,rtol=1e-6,atol=1e-6,
        device_receipt_sha256={name:sha((root/'device/device-receipt.json').read_bytes()) for name,root in [('cuda',a.cuda),('jax',a.jax)]},
        coupled_columns=0,field_years=0,production_registered=False)
    save(a.output,result)
    assert controls(a.source)==identity
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())

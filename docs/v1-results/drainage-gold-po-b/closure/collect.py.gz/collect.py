"""Terminal original-byte closeout with stdlib NPZ header/payload verification."""
from pathlib import Path
import ast
import hashlib
import io
import json
import math
import re
import socket
import struct
import subprocess
import sys
import tarfile
import zipfile

ROOT=Path('/tmp/noahmp-drainage-gold-po-b')
JOB='1665.manager'
CONTROL_SHA='82c291347cae1e92e682947c3240e5eb2494b4964c483a4e9a21010488b41d40'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()


def verify_npz(raw,metadata):
    """No numerical import or interpretation: exact NPY metadata and payload bytes."""
    assert sha(raw)==metadata['npz_sha256']
    result={}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        assert set(archive.namelist())=={n+'.npy' for n in metadata['arrays']}
        for name,expected in metadata['arrays'].items():
            data=archive.read(name+'.npy');assert data[:6]==b'\x93NUMPY'
            version=tuple(data[6:8])
            if version==(1,0):size=struct.unpack('<H',data[8:10])[0];start=10
            else:
                assert version in ((2,0),(3,0));size=struct.unpack('<I',data[8:12])[0];start=12
            header=ast.literal_eval(data[start:start+size].decode('utf8' if version==(3,0) else 'latin1').strip())
            assert set(header)=={'descr','fortran_order','shape'} and header['fortran_order'] is False
            assert isinstance(header['descr'],str) and isinstance(header['shape'],tuple)
            assert header['descr']==expected['dtype'] and list(header['shape'])==expected['shape']
            match=re.fullmatch(r'[<>=|][biuf](\d+)',header['descr']);assert match
            payload=data[start+size:]
            assert len(payload)==expected['bytes']==math.prod(header['shape'])*int(match.group(1))
            assert sha(payload)==expected['c_order_sha256']
            result[name]=expected
    return result


def main():
    assert socket.gethostname()=='manager'
    q=subprocess.check_output(['qstat','-xf',JOB])
    fields=dict(line.strip().split(' = ',1) for line in q.decode().splitlines() if ' = ' in line)
    assert q.decode().splitlines()[0]=='Job Id: '+JOB
    assert fields['job_state']=='F' and fields['Stageout_status']=='0'
    code=int(fields['Exit_status'])
    (ROOT/'actual-qstat-final.txt').write_bytes(q)
    for name in ('result.tar.gz','pbs-exit.txt'):
        assert not (ROOT/name).exists()
        digest=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
        subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
        assert sha((ROOT/name).read_bytes())==digest
    assert int((ROOT/'pbs-exit.txt').read_text())==code
    with tarfile.open(ROOT/'result.tar.gz') as tar:
        members=[m for m in tar if m.isfile()]
        assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        raw={m.name.removeprefix('./'):tar.extractfile(m).read() for m in members}
    assert len(raw)==len(members)
    receipt=json.loads(raw['export-receipt.json'])
    assert receipt['pbs_job']==JOB and int(raw['export-parent-exit.txt'])==code
    assert receipt['controls_manifest_sha256']==CONTROL_SHA and receipt['source_and_controls_unchanged']
    assert sha(raw['SOURCE_SHA256.json'])=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert len(json.loads(raw['SOURCE_SHA256.json']))==584
    assert receipt['checker_parent_returncode']==0 and receipt['actual_checker_tests']==9
    checker=raw['checker.stderr.txt'].decode()
    assert len(re.findall(r'^test_\S+ \([^\n]+\) \.\.\. ok$',checker,re.M))==9
    assert re.search(r'^Ran 9 tests in ',checker,re.M) and re.search(r'^OK$',checker,re.M)
    summary=json.loads(raw['gold/export-summary.json'])
    assert summary['actual_trial_executions']==sum(v['actual_trial_calls'] for v in summary['observed_execution_records'])
    assert summary['actual_full_integrations']==sum(v['actual_full_calls'] for v in summary['observed_execution_records'])
    stage=json.loads((ROOT/'stage-inventory.json').read_bytes())
    assert sha((ROOT.parent/'noahmp-drainage-gold-po-b-stage.tar.gz').read_bytes())=='8f6982019b62db3e334a2b3bb725fc4f1f0a1cdfc48e67be10abbe1e0ee09630'
    assert sha((ROOT/'preparation/CONTROLS_SHA256.json').read_bytes())==CONTROL_SHA
    assert all(sha((ROOT/n).read_bytes())==h for n,h in stage.items())
    actual=subprocess.check_output(['ssh','compute002','sha256sum',*[str(ROOT/n) for n in stage]]).decode()
    assert {line.split()[1]:line.split()[0] for line in actual.splitlines()}=={str(ROOT/n):h for n,h in stage.items()}
    (ROOT/'compute-after-file-hashes.txt').write_text(actual)
    result_root=ROOT/'closed-result';assert not result_root.exists();result_root.mkdir()
    for n,b in raw.items():
        p=result_root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    npz={}
    for name,data in raw.items():
        if name.endswith('.npz'):npz[name]=verify_npz(data,json.loads(raw[name+'.json']))
    record=dict(pbs_job=JOB,job_state='F',Exit_status=code,Stageout_status=0,
        raw_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),raw_result_members=len(raw),
        controls_manifest_sha256=CONTROL_SHA,source_manifest_sha256=receipt['source_manifest_sha256'],
        source_and_controls_unchanged=True,manager_compute_stage_after_exact=True,
        actual_checker_tests=9,actual_trial_executions=summary['actual_trial_executions'],
        actual_full_integrations=summary['actual_full_integrations'],complete_cases=summary['cases'],
        actual_observed_inverse_returns=sum(v.get('phase',{}).get('actual_inverse_calls',0) for v in summary['observed_execution_records']),
        npz_files_verified=len(npz),arrays_verified=sum(len(v) for v in npz.values()),
        actual_gold=False,GPU_runs=0,worker_seconds=receipt['seconds'],partial_failures=[v for v in summary['observed_execution_records'] if not v['completed']])
    (ROOT/'npz-byte-verification.json').write_bytes(js(dict(method='stdlib ZIP CRC + NPY header + payload SHA; no numerical import',files=npz)))
    if code==0:
        assert receipt['passed'] and summary['passed'] and summary['cases']==20
        assert summary['actual_trial_executions']==40 and summary['actual_full_integrations']==34
        assert len(npz)==80 and all(v['completed'] for v in summary['observed_execution_records'])
        subprocess.run([sys.executable,'-B',str(ROOT/'preparation/close_gold_po.py'),'--result',str(result_root),
            '--qstat',str(ROOT/'actual-qstat-final.txt'),'--output',str(ROOT/'gold')],check=True)
        record['gold_seal']=json.loads((ROOT/'gold-seal.json').read_bytes());record['actual_gold']=True
        comparisons=[json.loads(raw['gold/'+v['name']+'/export-comparison.json'])
            for v in json.loads(raw['gold/case-recipes.json'])]
        record['maxima']={}
        record['hard_budget_maxima']={}
        record['input_quantization_max_abs']={}
        for c in comparisons:
            assert c['physical32_vs64']['passed']
            for name,field in c['physical32_vs64']['fields'].items():
                slot=record['maxima'].get(name)
                if slot is None or field['maximum_absolute_difference']>slot['maximum_absolute_difference']:
                    record['maxima'][name]=dict(case=c['case'],maximum_absolute_difference=field['maximum_absolute_difference'],
                        absolute_tolerance=field['absolute_tolerance'],relative_fraction=field['relative_fraction'])
            for dtype,run in c['runs'].items():
                for phase,budgets in run['hard_ledgers'].items():
                    for label,account in budgets.items():
                        key=dtype+'.'+phase+'.'+label
                        assert account['passed'] and abs(account['native_residual'])<=account['original_bound']
                        assert abs(account['independent_residual'])<=account['original_bound']
                        slot=record['hard_budget_maxima'].get(key)
                        if slot is None or abs(account['native_residual'])>abs(slot['native_residual']):
                            record['hard_budget_maxima'][key]=dict(case=c['case'],**account)
            quant=json.loads(raw['gold/'+c['case']+'/input-quantization.json'])['difference_32_minus_64']
            for name,values in quant.items():
                flat=[abs(x) for row in values for x in row] if name=='cells' else [abs(x) for x in values]
                peak=max(flat,default=0.)
                slot=record['input_quantization_max_abs'].get(name)
                if slot is None or peak>slot['maximum_absolute_difference']:
                    record['input_quantization_max_abs'][name]=dict(case=c['case'],maximum_absolute_difference=peak)
        old=Path('/tmp/noahmp-drainage-gold-po/result.tar.gz')
        assert sha(old.read_bytes())=='f5845b8125ebf57b2339e179b141c0ad96eabd5bbd37b97bbe45b08d29172fd0'
        with tarfile.open(old) as tar:
            prior={m.name.removeprefix('./'):tar.extractfile(m).read() for m in tar if m.isfile()}
        repeated={}
        for leaf in ('input32.npz.json','input64.npz.json','numpy32.npz.json'):
            key='gold/main-warm-option1/'+leaf
            assert json.loads(prior[key])['arrays']==json.loads(raw[key])['arrays']
            repeated[leaf]=len(json.loads(raw[key])['arrays'])
        record['failed_first_case_repeated_array_payloads_exact']=repeated
    (ROOT/'actual-readout.json').write_bytes(js(record))
    data={}
    if record['actual_gold']:
        for p in (ROOT/'gold').rglob('*'):
            if p.is_file():data['gold/'+p.relative_to(ROOT/'gold').as_posix()]=p.read_bytes()
        data['gold-seal.json']=(ROOT/'gold-seal.json').read_bytes()
    else:
        data.update({'failed-result/'+n:b for n,b in raw.items()})
    for p in (ROOT/'preparation').iterdir():
        if p.is_file():data['preparation/'+p.name]=p.read_bytes()
    for name in ('actual-readout.json','npz-byte-verification.json','actual-qstat-final.txt','dispatch.json','qsub.stdout.txt',
            'qsub.stderr.txt','compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt',
            'compute-after-file-hashes.txt','pbs-exit.txt','stage-inventory.json'):
        data['closure/'+name]=(ROOT/name).read_bytes()
    data['closure/collect.py']=Path(__file__).read_bytes()
    data['execution/dispatch_component_pb.py']=(ROOT/'execution/dispatch_component_pb.py').read_bytes()
    if (ROOT/'pbs-output.log').exists():data['closure/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
    data['closure/raw-result-inventory.json']=js({n:dict(sha256=sha(b),bytes=len(b)) for n,b in raw.items()})
    data['artifact-inventory.json']=js({n:sha(b) for n,b in sorted(data.items())})
    target=ROOT/'drainage-gold-po-b-evidence.tar.gz';assert not target.exists()
    with tarfile.open(target,'w:gz') as tar:
        for name,b in sorted(data.items()):
            item=tarfile.TarInfo(name);item.size=len(b);tar.addfile(item,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==data
    package={k:v for k,v in record.items() if k not in ('maxima',)}
    package.update(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,members=len(data),inventory_members=len(data)-1)
    (ROOT/'drainage-gold-po-b-package.json').write_bytes(js(package));print(json.dumps(package))


if __name__=='__main__':main()

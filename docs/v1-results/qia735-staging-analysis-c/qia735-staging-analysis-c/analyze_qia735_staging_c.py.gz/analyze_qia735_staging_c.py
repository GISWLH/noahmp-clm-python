from pathlib import Path
import hashlib
import json
import os

import numpy as np

assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia735-staging-analysis-c';p=b/'qia735-staging-variants-c.npz'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='d66091ff921e29ef4f91c717e0693158963d60cc0befcbb8f9e2d91d3ac282f5'
with np.load(p,allow_pickle=False) as z:data=dict(z)
cuda=data['cuda_original_raw'];rows={}
for label,x in data.items():
 if x.shape!=(1,300):continue
 assert x.dtype==cuda.dtype==np.dtype('float32') and np.all(np.isfinite(x))
 difference=abs(x.astype(float)-cuda.astype(float));bad=np.flatnonzero((difference>1e-6+1e-6*abs(cuda.astype(float))).reshape(300))
 rows[label]=dict(raw_fields=300,sameprecision_pass=bool(not len(bad)),bitwise_equal=bool(np.array_equal(x,cuda)),maximum_absolute=float(np.max(difference)),
  failed_raw_indices=bad.tolist(),iterations=float(x[0,67]),max_solver_residual=float(x[0,292]))
x,y=data['cuda_original_radiation'],data['jax_tracked_radiation'];assert x.shape==y.shape==(1,584)
rad=dict(raw_fields=584,maximum_absolute=float(np.max(abs(x.astype(float)-y.astype(float)))),sameprecision_pass=bool(np.allclose(x,y,rtol=1e-6,atol=1e-6)),bitwise_equal=bool(np.array_equal(x,y)))
record=dict(scope='EHPC PBS independent everyraw300 original735 comparison for all predeclared JAX parameter/radiation staging variants,plus584tracked radiation. Original failed regression retained;no model/gate/precision/source changes,not acceptance of a variant into production. Comparing actual dynamicargument semantics before any test/implementation edits.',
 pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,original_variants_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rtol=1e-6,atol=1e-6,variants=rows,tracked_radiation=rad)
(r/'analysis.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

from pathlib import Path
import datetime,hashlib,io,json,os,tarfile,time
assert os.environ.get('PBS_JOBID')
root=Path('/home/zhangyq/noahmp-v1/fluxnet-numpy-current-first-year-a');out=root/'snapshots';out.mkdir(exist_ok=True);begun=time.monotonic();sha=lambda b:hashlib.sha256(b).hexdigest()
protocol=json.loads((root/'protocol.json').read_text());launch=json.loads((root/'launch.json').read_text());assert protocol['pbs_job']=='121.manager' and protocol['node']==os.uname().nodename
rows=[];latest={};errors=[];empty=0
for job in launch['jobs']:
    folder=Path(job['output']).resolve();assert folder.is_relative_to(Path('/var/tmp/pbs.121.manager/numpy-current-first-year'))
    rows.append((job,folder))
(out/'preserver-launch.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,scope='Read-only same-node preservation of exact original NumPy checkpoint generations. No model execution/source/input change; snapshot completion is never a terminal process result.',source_pbs='121.manager',cases=[job['case'] for job,_ in rows]),indent=2)+'\n')
while True:
    present=False
    for job,folder in rows:
        pointer=folder/'report.json'
        if not pointer.exists():continue
        present=True
        try:
            raw=pointer.read_bytes();r=json.loads(raw);key=(r['steps_completed'],r['status'],sha(raw))
            if latest.get(job['case'],{}).get('generation_key')==list(key):continue
            assert r['steps_requested']==17520 and r['source_unchanged']
            files=[('report.json',raw)]
            for name,field in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:
                path=folder/r[name];assert path.parent==folder;data=path.read_bytes();assert sha(data)==r[field];files.append((path.name,data))
            target=out/(job['case']+'.tar.gz');temp=target.with_suffix('.gz.tmp')
            with tarfile.open(temp,'w:gz') as t:
                for name,data in files:
                    member=tarfile.TarInfo(name);member.size=len(data);t.addfile(member,io.BytesIO(data))
            os.replace(temp,target);latest[job['case']]=dict(generation_key=list(key),steps=r['steps_completed'],status=r['status'],report_sha256=sha(raw),archive_sha256=sha(target.read_bytes()),path=target.name)
        except (FileNotFoundError,AssertionError,ValueError) as e:errors.append(dict(case=job['case'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=type(e).__name__,scope='Concurrent save/read may race; previous verified snapshot kept, retry next poll.'))
    value=dict(status='observing',source_pbs='121.manager',preserver_pbs=os.environ['PBS_JOBID'],node=os.uname().nodename,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshots=latest,concurrent_read_retries=errors[-20:],seconds=time.monotonic()-begun)
    temp=out/'progress.json.tmp';temp.write_text(json.dumps(value,indent=2)+'\n');os.replace(temp,out/'progress.json')
    if (root/'exit.json').exists():value['status']='source-controller-terminal';break
    empty=0 if present else empty+1
    if empty>=4:value['status']='source-scratch-unavailable';break
    time.sleep(15)
(out/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

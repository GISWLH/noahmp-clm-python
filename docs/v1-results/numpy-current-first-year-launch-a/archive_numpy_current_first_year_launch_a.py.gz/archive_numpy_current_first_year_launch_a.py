from pathlib import Path
import hashlib,io,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'fluxnet-numpy-current-first-year-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=json.loads((root/'protocol.json').read_text());assert protocol['pbs_job']=='121.manager' and protocol['node']=='compute002' and protocol['unchanged_existing_code_test_benchmark_files']==483 and len(protocol['cases'])==4
preserver=json.loads((root/'snapshots/preserver-launch.json').read_text());assert preserver['pbs_job']=='123.manager' and preserver['source_pbs']=='121.manager' and preserver['node']=='compute002'
names=['run_numpy_current_first_year_a.py','numpy_current_first_year_a.pbs','protocol.json','launch.json','progress.json','SOURCE_SHA256.json','preserve_numpy_current_year_snapshots_a.py','numpy_snapshot_preserver_a.pbs','snapshots/preserver-launch.json','snapshots/progress.json'];entries=[(name,(root/name).read_bytes()) for name in names]+[(Path(__file__).name,Path(__file__).read_bytes())]
dest=base/'numpy-current-first-year-launch-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for name,data in entries:
        member=tarfile.TarInfo(name);member.size=len(data);t.addfile(member,io.BytesIO(data))
print(json.dumps(dict(files=len(entries),path=str(dest),sha256=sha(dest),scope='Actual EHPC four original NumPy year launch and same-node exact checkpoint preservation setup only; original17520 each remains required, no full year/spinup/scientific acceptance.')))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=[];receipts={}
for label in ['capacity','capacity_optics']:
    r=b/('qia-richards-'+label+'-firstday-a');d=json.loads((r/'receipt.json').read_text());p=r/'trajectory';report=json.loads((p/'report.json').read_text())
    assert (r/'pbs-exit.txt').read_text().strip()=='1' and d['returncode']==1 and d['source_unchanged'] and d['steps_completed']==5 and report['status']=='failed' and report['steps_completed']==5
    assert sha(p/'report.json')==d['report_sha256'] and sha(p/report['checkpoint_file'])==report['checkpoint_sha256'] and sha(p/report['model_npz'])==report['model_npz_sha256'] and sha(r/'config.json')==report['configuration_sha256']
    roots.append(r);receipts[label]=d
a=b/'qia-richards-firstday-failure-a-evidence.tar.gz';assert not a.exists();source=b/'richards-station-numpy-a-source.tar.gz';assert sha(source)=='a8a91fe4c9f8d672341f83f55eefa31b5b8372f1a5cc1f7ae31116b30cc86048'
with tarfile.open(a,'w:gz') as t:
    for r in roots:
        for p in sorted(r.rglob('*')):
            if p.is_file():t.add(p,arcname=r.name+'/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['run_qia_richards_firstday_a.py','qia_richards_firstday_a.pbs','dispatch_qia_richards_firstday_a.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(source,arcname='source/'+source.name,recursive=False)
    for n in ['CN-Qia.npz','CN-Qia.json','CN-Qia-stem-config.json']:t.add(b/'qia-stem-inputs-a/inputs'/n,arcname='original-input/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,receipts=receipts,scope='ActualPBS332/333 bothfailed sixth thermal trial at5/17520, no first48 metrics/year acceptance. All original5successfulprefix checkpoints/traces and failedreports/config/source/forcing kept; no resume failed trajectory.')))

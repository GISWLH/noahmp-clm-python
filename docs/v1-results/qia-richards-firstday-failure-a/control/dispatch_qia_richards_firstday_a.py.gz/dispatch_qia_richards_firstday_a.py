from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');prior=b/'richards-station-numpy-a';rec=json.loads((prior/'receipt.json').read_text())
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and rec['returncode']==0 and rec['counts']==dict(tests=55,failures=0,errors=0,skipped=0)
for label in ['capacity','capacity_optics']:
    r=b/('qia-richards-'+label+'-firstday-a');assert not r.exists();r.mkdir();controls={}
    for name in ['run_qia_richards_firstday_a.py','qia_richards_firstday_a.pbs']:
        raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
    p=subprocess.run(['qsub','-v','CAPACITY_CASE='+label,str(r/'qia_richards_firstday_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
    record=dict(case=label,pbs_job=p.stdout.strip(),controls_sha256=controls,scope='Prospectively declared closedverticalRichards with originalcapacity andcapacity+originalPFToptics48-step cold prefixes; originalforcing/initial/heights/windows fixed, not results or science acceptance.')
    (r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

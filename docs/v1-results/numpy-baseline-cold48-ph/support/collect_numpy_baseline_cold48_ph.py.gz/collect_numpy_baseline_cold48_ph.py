"""Read only the eight submitted PH jobs and original files; no model imports."""
from pathlib import Path
import base64
import hashlib
import json
import socket
import subprocess
from datetime import datetime, timezone

ROOT = Path('/tmp/noahmp-numpy-baseline-cold48-ph')
JOBS = ['1620.manager', '1621.manager', '1622.manager', '1623.manager',
        '1624.manager', '1625.manager', '1626.manager', '1627.manager']


def main():
    node = socket.gethostname()
    assert node in ('manager', 'compute002')
    rows = []

    def record(name, body, **extra):
        rows.append(dict(name=name, present=True, bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
            base64=base64.b64encode(body).decode(), **extra))

    names = ['dispatch.json', 'compute-extract.stdout', 'compute-extract.stderr'] if node == 'manager' else []
    for i, job in enumerate(JOBS):
        if node == 'manager':
            names.extend('case-' + str(i) + suffix for suffix in ['-qsub.stdout', '-qsub.stderr', '-qsub-exit.txt', '-pbs.log'])
            proc = subprocess.run(['qstat', '-xf', job], capture_output=True)
            record(job + '-qstat.stdout', proc.stdout, actual_exit=proc.returncode)
            record(job + '-qstat.stderr', proc.stderr, actual_exit=proc.returncode)
        else:
            names.append('case-' + str(i) + '-pbs-exit.txt')
            path = ROOT / ('case-' + str(i) + '-result.tar.gz')
            rows.append(dict(name=path.name, present=path.is_file(), raw_archive_reference=True,
                bytes=path.stat().st_size if path.is_file() else None,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None))
    for name in names:
        path = ROOT / name
        if path.is_file():
            record(name, path.read_bytes())
        else:
            rows.append(dict(name=name, present=False))
    print(json.dumps(dict(node=node, sampled_utc=datetime.now(timezone.utc).isoformat(), rows=rows)))


if __name__ == '__main__':
    main()

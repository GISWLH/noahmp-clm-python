"""One flat actual eight-window package, stdlib-only closure of existing bytes."""
from pathlib import Path
import base64
import hashlib
import io
import json
import re
import tarfile

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    data, metadata, originals, rows = {}, {}, [], []
    for node in ('manager', 'compute002'):
        raw = (BASE / 'numpy-baseline-cold48-ph-actual' / (node + '.json')).read_bytes()
        metadata[node] = json.loads(raw)
        assert metadata[node]['node'] == node
        data['actual/' + node + '.json'] = raw
        for row in metadata[node]['rows']:
            if row['present'] and 'base64' in row:
                raw = base64.b64decode(row['base64'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                data['actual/' + node + '/' + row['name']] = raw
    dispatch = json.loads(data['actual/manager/dispatch.json'])
    assert len(dispatch['jobs']) == 8 and dispatch['maximum_total_tendencies'] == 384
    fixed = json.loads((BASE / 'numpy-baseline-cold48-ph-preparation/PH_BINDINGS.json').read_bytes())
    for job in dispatch['jobs']:
        i, identifier = job['index'], job['pbs_job']
        qstat = data['actual/manager/' + identifier + '-qstat.stdout'].decode()
        for key, value in [('job_state', 'F'), ('Exit_status', '0'), ('Stageout_status', '0')]:
            assert re.search(r'^\s*' + key + r' = ' + value + '$', qstat, re.M), (identifier, key)
        assert re.search(r'^Job Id: ' + re.escape(identifier) + '$', qstat, re.M)
        path = BASE / ('numpy-baseline-cold48-ph-case-' + str(i) + '-result.tar.gz')
        actual = next(r for r in metadata['compute002']['rows'] if r['name'] == 'case-' + str(i) + '-result.tar.gz')
        assert path.stat().st_size == actual['bytes'] and sha(path.read_bytes()) == actual['sha256']
        with tarfile.open(path) as archive:
            raw = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in archive if m.isfile()}
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in raw)
        for name, body in raw.items():
            data['cases/' + str(i) + '/' + name] = body
        originals.append(dict(case_index=i, file=path.name, sha256=actual['sha256'],
            members={n: sha(b) for n, b in raw.items()}))
        receipt, audit = json.loads(raw['receipt.json']), json.loads(raw['window-audit.json'])
        report = json.loads(raw['run/trajectory/report.json'])
        assert receipt['passed'] is True and receipt['error'] is None and receipt['pbs_job'] == identifier
        assert raw['worker-exit.txt'].strip() == data['actual/compute002/case-' + str(i) + '-pbs-exit.txt'].strip() == b'0'
        assert receipt['actual_original_tendencies'] == receipt['original_bgc_records'] == 48
        assert receipt['identity'] == fixed['identities'][i] == job['identity'] == audit['identity']
        assert receipt['source_unchanged'] and receipt['source_files'] == 584
        assert receipt['PH_manifest_sha256'] == '15152abfd7ee042583baeac4b6533c9682f2595b6bd6536730b210b95a56be4f'
        assert sha(raw['window-audit.json']) == receipt['window_audit_sha256']
        assert report['status'] == 'running' and report['steps_completed'] == 48 and report['steps_requested'] == 17520
        assert audit['original_complete_bgc_records'] == 48 and audit['endpoint_eligible_for_cycle_or_train2'] is False
        assert audit['actual_own_cold_exact']['max_abs_difference'] == audit['bgc_endpoint_exact']['max_abs_difference'] == 0.
        assert all(abs(r) <= b for r, b in zip(audit['residual_m_h_c_n'], audit['bounds_m_h_c_n']))
        header = json.loads(raw['bgc-stream/BGC_STREAM.json'])
        assert header['first_index'] == 0 and header['stop_index'] == 48
        assert header['successful_original_tendencies_recorded'] == 48 and header['complete_requested_window'] is False
        assert header['original_call_completed_without_exception'] is True and len(header['blocks']) == 1
        assert header['blocks'][0]['count'] == 48 and sha(raw['bgc-stream/' + header['blocks'][0]['file']]) == header['blocks'][0]['sha256']
        rows.append(dict(case_index=i, case=receipt['case'], pbs_job=identifier, seconds=receipt['seconds'],
            maximum_rss_kib=receipt['maximum_rss_kib'], original_tendencies=48, BGC_records=48,
            output_bytes=path.stat().st_size, residual_m_h_c_n=audit['residual_m_h_c_n'],
            bounds_m_h_c_n=audit['bounds_m_h_c_n'], actual_original_status='running48/17520',
            original_zero_and_BGC_endpoint_max_abs_difference=0.))
    prep = BASE / 'numpy-baseline-cold48-ph-preparation'
    manifest_raw = (prep / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(manifest_raw) == '15152abfd7ee042583baeac4b6533c9682f2595b6bd6536730b210b95a56be4f'
    for n in [*json.loads(manifest_raw), 'CONTROLS_SHA256.json']:
        data['controls/' + n] = (prep / n).read_bytes()
    for name in ['prepare_numpy_baseline_cold48_ph.py', 'collect_numpy_baseline_cold48_ph.py',
                 'package_numpy_baseline_cold48_ph.py', 'numpy-baseline-cold48-ph-preparation.json']:
        data['support/' + name] = (BASE / name).read_bytes()
    summary = dict(passed=True, actual_jobs=8, actual_terminal='8 x F0/Stageout0/worker0',
        actual_original_tendencies=384, actual_complete_BGC_records=384, actual_complete_years=0,
        accepted_spinup=False, score_executed=False, GPU_steps=0,
        all_original_M_H_C_N_bounds_met=True, original_zero_and_BGC_endpoint_max_abs_difference=0.,
        source_files=584, candidate='om-baseline', rows=rows,
        scope='Eight genuine own-cold 48/17520 same-year windows. These partial checkpoints are not complete-year/cycle parents. No annual throughput claim.')
    data['WINDOWS.json'] = js(summary)
    lines = ['# PH 基线自己的冷态48步实际结果', '',
        'EHPC compute002 的8个独立NumPy窗口均为真实 F0/Stageout0/worker0，合计384原物理步和384条完整BGC记录。原报告保持 running、48/17520；当前完整年0、已接受spinup0、评分0、GPU步0。', '',
        '原NM584、PA完整年驱动、PF1619自己的名义冷态均保持原身份。原零步状态与各自PF冷态、末步BGC记录与原checkpoint均逐字段bitexact，最大差0。每个原48条BGC满块均实际保存并核时间、序号、原状态端点。所有原水热碳氮逐步/累计数值界保持，没有使用10%容差代替守恒。', '',
        '以下为实际worker秒数、峰RSS和端点残差/原累计界。M单位kg/m2，H单位J/m2，C单位gC/m2，N单位gN/m2。', '',
        '| 原case | 秒数 | RSS KiB | M residual / bound | H residual / bound | C residual / bound | N residual / bound |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        cells = [format(r, '.17g') + ' / ' + format(b, '.17g') for r, b in zip(row['residual_m_h_c_n'], row['bounds_m_h_c_n'])]
        lines.append('| ' + row['case'] + ' | ' + format(row['seconds'], '.6f') + ' | ' + str(row['maximum_rss_kib']) + ' | ' + ' | '.join(cells) + ' |')
    lines += ['', '本批8个job一次提交，没有失败后自动重跑。所有原result文件平铺保留，源/PA/PF大包按完整SHA引用。窗口耗时覆盖各站第一天的48个原半小时间隔，不是全年稳态吞吐或deadline。', '',
        '下一步只可对同一源、同一candidate、同一原case和同一forcing/calendar按原runner resume从第48步接续，保留七元组所有前六对象及原累计账。完整17520步及真实成功父状态闭合前，这些partial窗口不能作为气候cycle或下一训练年的complete parent。', '']
    data['RESULTS.md'] = '\n'.join(lines).encode()
    data['SOURCE_REFERENCES.json'] = js(dict(original_results=originals,
        stage_sha256=dispatch['stage_sha256'], PF_actual_archive_sha256=fixed['PF_actual_archive_sha256'],
        PF_manifest_sha256=fixed['PF_manifest_sha256'],
        source_archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',
        source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
        PA_archive_sha256='a5a6c49284f675d16824c9e7c24e68548840ba4c20b7a490e405923a1d95f7d9'))
    data['INTEGRITY.json'] = js({n: sha(b) for n, b in sorted(data.items())})
    path = BASE / 'numpy-baseline-cold48-ph-evidence.tar.gz'
    assert not path.exists()
    with tarfile.open(path, 'w:gz') as archive:
        for name, raw in sorted(data.items()):
            item = tarfile.TarInfo(name)
            item.size = len(raw)
            archive.addfile(item, io.BytesIO(raw))
    with tarfile.open(path) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive} == data
    package = dict(archive=path.name, sha256=sha(path.read_bytes()), bytes=path.stat().st_size,
        artifacts=len(data), inventory_files=len(data)-1, **summary)
    (BASE / 'numpy-baseline-cold48-ph-package.json').write_bytes(js(package))
    (BASE / 'numpy-baseline-cold48-ph-windows.json').write_bytes(js(summary))
    print(json.dumps({k: v for k, v in package.items() if k != 'rows'}))


if __name__ == '__main__':
    main()

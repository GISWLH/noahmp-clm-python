"""Generate minimal original PB entrypoint adaptation, prove AST, freeze inputs."""
from pathlib import Path
import ast
import copy
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
OUT = BASE / 'numpy-baseline-cold48-ph-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    pf = BASE / 'numpy-own-spinup-pf-preparation'
    pfraw = (pf / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(pfraw) == '32ca64c70a5705f2bd4ae9c78c9c549cc5f553d1a6da153b8a20b041baedf08b'
    pfi = json.loads(pfraw)
    assert all(sha((pf / n).read_bytes()) == h for n, h in pfi.items())
    original_raw = (pf / 'pb/numpy_chain_pb.py').read_bytes()
    original = next(n for n in ast.parse(original_raw).body if isinstance(n, ast.FunctionDef) and n.name == '_run_segment')
    changed = copy.deepcopy(original)
    assert isinstance(changed.body[2], ast.Expr) and 'test_only' in ast.unparse(changed.body[2])
    changed.name = 'run_window'
    changed.body[0] = ast.Expr(value=ast.Constant(value='Actual fixed baseline own cold48; full calendar retained, no annual completion claim.'))
    changed.body[2] = ast.parse("""require(identity == request(identity['candidate'], identity['case'], 'spinup', 1)
        and identity['candidate'] == 'om-baseline' and identity['steps'] == 17520
        and identity['test_only'] is False and stop_after == 48 and resume is False,
        'PH is exactly one original baseline cold48 window, never a test identity or annual launch')""").body[0]
    restored = copy.deepcopy(changed)
    restored.name, restored.body[0], restored.body[2] = original.name, original.body[0], original.body[2]
    assert ast.dump(restored, include_attributes=False) == ast.dump(original, include_attributes=False)
    header = '''"""Generated original PB segment body; only name/docstring/entry gate differ."""
import contextlib
import os
from pathlib import Path
import pickle
import socket
import time
import traceback
import zipfile
from chain_contract_pb import require, request, read_json, json_bytes, sha
from numpy_chain_pb import verify_source, validate_inputs, _generation, _write, _snapshot, _member, assert_content_exact

'''
    (OUT / 'run_window_ph.py').write_text(header + ast.unparse(ast.fix_missing_locations(changed)) + '\n')
    actual = BASE / 'numpy-own-spinup-pf-evidence.tar.gz'
    assert sha(actual.read_bytes()) == 'b220ec27d571f92802527913fd0b630fabe2f48d40c3469050ac5434c032e8b3'
    fixed = json.loads((pf / 'BINDINGS_PF.json').read_bytes())
    identities, own = [], {}
    with tarfile.open(actual) as archive:
        raw = {m.name: archive.extractfile(m).read() for m in archive}
        inventory = json.loads(raw['INTEGRITY.json'])
        assert all(sha(raw[n]) == h for n, h in inventory.items())
        receipt = json.loads(raw['current/receipt.json'])
        assert receipt['passed'] is True and receipt['actual_original_cpu_tendencies'] == 2
        qstat = raw['actual/manager/qstat.stdout.txt']
        assert b'job_state = F' in qstat and b'Exit_status = 0' in qstat and b'Stageout_status = 0' in qstat
        for case in fixed['original_case_order']:
            prefix = 'current/own-init-output/own-cold/om-baseline/' + case + '/'
            seed = json.loads(raw[prefix + 'OWN_COLD_SEED.json'])
            identities.append(seed['identity'])
            own[case] = {n: sha(raw[prefix + n]) for n in ['configuration.json', 'own-cold-state.pkl', 'OWN_COLD_SEED.json']}
    (OUT / 'PH_BINDINGS.json').write_bytes(js(dict(PF_manifest_sha256=sha(pfraw), PF_actual_archive_sha256=sha(actual.read_bytes()),
        identities=identities, own_seed_sha256=own, candidate='om-baseline', roots=8,
        original_calendar_intervals=17520, stop_after=48, total_tendency_cap=384,
        maximum_concurrent_jobs=8, cpus_per_job=1, memory_gib_per_job=2, wall_seconds_per_job=1800,
        no_automatic_retry=True, actual_full_years=0, BGC_stream_required=True,
        scope='Same-year partial original runner checkpoint. Only actual F0 plus original ledger/source/BGC closure permits same-year resume; not a complete-year parent.')))
    (OUT / 'ADAPTATION.json').write_bytes(js(dict(original_PB_module_sha256=sha(original_raw),
        original_function='_run_segment', adapted_function='run_window',
        changed_statements=['docstring', 'test-only entry gate -> fixed canonical original baseline cold48 identity'],
        all_other_function_AST_exact=True, original_model_source_modified=False,
        physical_tendency_or_conservation_expressions_changed=False, code_generation_numeric_execution=False)))
    index = {p.name: sha(p.read_bytes()) for p in OUT.iterdir() if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    for n in index:
        if n.endswith('.py'):
            ast.parse((OUT / n).read_bytes())
    (OUT / 'CONTROLS_SHA256.json').write_bytes(js(index))
    lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(OUT), str(Path(__file__))], capture_output=True, text=True)
    assert lint.returncode == 0, lint.stdout + lint.stderr
    files = {'preparation/' + n: (OUT / n).read_bytes() for n in [*index, 'CONTROLS_SHA256.json']}
    files.update({'pf/' + n: (pf / n).read_bytes() for n in [*pfi, 'CONTROLS_SHA256.json']})
    for name, digest in [('climatology-final-candidate-nm-source.tar.gz', fixed['source_archive_sha256']),
                         ('training-chain-pa-evidence.tar.gz', fixed['PA_archive_sha256']),
                         (actual.name, sha(actual.read_bytes()))]:
        body = (BASE / name).read_bytes()
        assert sha(body) == digest
        files['inputs/' + name] = body
    files['STAGE_SHA256.json'] = js({n: sha(b) for n, b in files.items()})
    stage = BASE / 'numpy-baseline-cold48-ph-stage.tar.gz'
    assert not stage.exists(), 'Preserve every deployed attempt'
    with tarfile.open(stage, 'w:gz') as archive:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            archive.addfile(member, io.BytesIO(raw))
    with tarfile.open(stage) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive} == files
    summary = dict(stage=stage.name, sha256=sha(stage.read_bytes()), bytes=stage.stat().st_size, members=len(files),
        controls=len(index), controls_sha256=sha((OUT / 'CONTROLS_SHA256.json').read_bytes()),
        original_function_restoration_AST_exact=True, ruff_exit=lint.returncode,
        prepared_jobs=8, maximum_tendencies=384, local_numeric_execution=False, submitted=False)
    (BASE / 'numpy-baseline-cold48-ph-preparation.json').write_bytes(js(summary))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()

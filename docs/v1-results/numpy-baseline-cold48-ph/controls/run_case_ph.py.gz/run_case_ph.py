"""One actual baseline CPU cold48 window of the original full first-year calendar."""
from pathlib import Path
import hashlib
import json
import os
import pickle
import resource
import socket
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-numpy-baseline-cold48-ph')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def expand(archive_path, target):
    target.mkdir()
    with tarfile.open(archive_path) as archive:
        members = [m for m in archive if m.isfile()]
        assert len({m.name for m in members}) == len(members)
        for member in members:
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts and '\\' not in member.name
            path = target / member.name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.extractfile(member).read())


def main():
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    index = int(os.environ['PH_CASE_INDEX'])
    assert 0 <= index < 8
    result = Path(os.environ['TMPDIR']) / 'result'
    result.mkdir()
    began = time.monotonic()
    record = dict(pbs_job=os.environ['PBS_JOBID'], case_index=index, node=socket.gethostname(),
        pid=os.getpid(), started_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        passed=False, error=None, source_unchanged=False, requested_original_tendencies=48,
        actual_original_tendencies=None, complete_calendar_years=0, spinup_accepted=False, score_eligible=False, GPU_steps=0)
    try:
        stage_index = json.loads((STAGE / 'STAGE_SHA256.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        fixed = json.loads((STAGE / 'preparation/PH_BINDINGS.json').read_bytes())
        pf_root = STAGE / 'pf'
        assert sha((pf_root / 'CONTROLS_SHA256.json').read_bytes()) == fixed['PF_manifest_sha256']
        sys.path.insert(0, str(pf_root))
        import own_spinup_pf as pf
        from capture_bgc_pf import BGCRecorder, records
        from cpu_trace_budget import audit_cpu_trace
        sys.path.insert(0, str(STAGE / 'preparation'))
        from run_window_ph import run_window
        source = result.parent / 'source-nm584'
        expand(STAGE / 'inputs/climatology-final-candidate-nm-source.tar.gz', source)
        runner, _, _ = pf.runtime(source)
        assembly = pf.read_assembly(STAGE / 'inputs/training-chain-pa-evidence.tar.gz')
        row = pf.candidate_rows('om-baseline')[index]
        case = row['case']
        raw, config, identity = pf.original_configuration(assembly, 'om-baseline', case)
        assert identity == fixed['identities'][index] and identity['steps'] == 17520 and not identity['test_only']
        paths = dict(configuration=result / 'inputs/configuration.json',
                     input=result / 'inputs/forcing.npz', input_manifest=result / 'inputs/forcing.json')
        paths['configuration'].parent.mkdir()
        paths['configuration'].write_bytes(raw)
        for suffix, key in [('npz', 'input'), ('json', 'input_manifest')]:
            paths[key].write_bytes(assembly['year-inputs/' + identity['site'] + '-' + str(identity['year']) + '.' + suffix])
        data, _ = pf.adapter.validate_inputs(runner, paths, identity)
        # Exact actual PF cold inventory, never an endpoint from another candidate.
        with tarfile.open(STAGE / 'inputs/numpy-own-spinup-pf-evidence.tar.gz') as archive:
            prefix = 'current/own-init-output/own-cold/om-baseline/' + case + '/'
            seedroot = result / 'own-cold-seed'
            seedroot.mkdir()
            for name in ('configuration.json', 'own-cold-state.pkl', 'OWN_COLD_SEED.json'):
                body = archive.extractfile(prefix + name).read()
                assert sha(body) == fixed['own_seed_sha256'][case][name]
                (seedroot / name).write_bytes(body)
        proof = pf.verify_own_cold_seed(runner, assembly, 'om-baseline', case, seedroot)
        save(result / 'own-cold-verification.json', proof)
        run = result / 'run'
        with BGCRecorder(runner, identity, data['time_start'], data['time_end'], result / 'bgc-stream'):
            receipt = run_window(runner, source, paths, identity, run, stop_after=48)
        record['actual_original_tendencies'] = receipt['successful_tendency_calls']
        report = pf.contract.read_json(run / 'trajectory/report.json')
        _, saved, trace = pf.adapter._generation(runner, run / 'trajectory', report, complete=False)
        assert report['status'] == 'running' and report['steps_completed'] == 48 and report['steps_requested'] == 17520
        assert receipt['worker_completed'] is True and receipt['failure'] is None and receipt['successful_tendency_calls'] == 48
        zero = run / 'segment-0000000/start-originals'
        zr = pf.contract.read_json(zero / 'report.json')
        comparison = pf.adapter.assert_content_exact(pickle.loads((seedroot / 'own-cold-state.pkl').read_bytes()),
            pickle.loads((zero / zr['checkpoint_file']).read_bytes()), runner.np)
        budget = audit_cpu_trace(runner, dict(saved=saved, trace=trace), run)
        bgc_rows = list(records(result / 'bgc-stream'))
        assert len(bgc_rows) == 48
        for i, bgc in enumerate(bgc_rows):
            assert bgc['identity'] == identity and bgc['index'] == i
            assert bgc['time_start'] == str(data['time_start'][i]) and bgc['time_end'] == str(data['time_end'][i])
        bgc_end = pf.adapter.assert_content_exact(bgc_rows[-1]['after_bgc'], saved[0].bgc_state, runner.np)
        residual = runner.totals(saved[0]) - saved[1] - saved[2]
        assert runner.np.all(abs(residual) <= saved[3])
        save(result / 'window-audit.json', dict(identity=identity, original_tendencies=48,
            original_status='running', calendar_intervals=17520, saved_intervals=48,
            actual_own_cold_exact=comparison, original_trace_budget=budget, bgc_endpoint_exact=bgc_end,
            original_complete_bgc_records=48, residual_m_h_c_n=residual.tolist(), bounds_m_h_c_n=saved[3].tolist(),
            zero_state_sha256=sha((zero / zr['checkpoint_file']).read_bytes()),
            final_state_sha256=report['checkpoint_sha256'], trace_sha256=report['model_npz_sha256'],
            bgc_header_sha256=sha((result / 'bgc-stream/BGC_STREAM.json').read_bytes()),
            endpoint_eligible_for_same_year_resume_after_actual_F0=True,
            endpoint_eligible_for_cycle_or_train2=False, accepted_spinup=False, score_eligible=False))
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        source_index = pf.adapter.verify_source(source)
        (result / 'SOURCE_SHA256.json').write_bytes((source / 'SOURCE_SHA256.json').read_bytes())
        record.update(passed=True, case=case, identity=identity, source_unchanged=True, source_files=len(source_index),
            saved_intervals=48, full_calendar_intervals=17520, actual_original_status='running',
            original_bgc_records=48, own_cold_max_abs_difference=comparison['max_abs_difference'],
            BGC_endpoint_max_abs_difference=bgc_end['max_abs_difference'],
            window_audit_sha256=sha((result / 'window-audit.json').read_bytes()),
            PH_manifest_sha256=sha((STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()),
            PF_manifest_sha256=fixed['PF_manifest_sha256'])
    except Exception as exc:
        record['error'] = type(exc).__name__ + ': ' + str(exc)
        (result / 'traceback.txt').write_text(traceback.format_exc())
    record.update(seconds=time.monotonic() - began, maximum_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    save(result / 'receipt.json', record)
    print(json.dumps(record), flush=True)
    raise SystemExit(0 if record['passed'] else 1)


if __name__ == '__main__':
    main()

"""Deploy a frozen stage and submit exactly eight baseline windows; no retry loop."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-numpy-baseline-cold48-ph')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--extract-only', action='store_true')
    args = parser.parse_args()
    assert socket.gethostname() == ('compute002' if args.extract_only else 'manager')
    assert sha(args.archive.read_bytes()) == args.sha256 and not ROOT.exists()
    with tarfile.open(args.archive) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len(members) == len({m.name for m in members})
        raw = {m.name: archive.extractfile(m).read() for m in members}
    index = json.loads(raw['STAGE_SHA256.json'])
    assert set(index) == set(raw) - {'STAGE_SHA256.json'} and all(sha(raw[n]) == h for n, h in index.items())
    assert sha(Path(__file__).read_bytes()) == index['preparation/dispatch_ph.py']
    ROOT.mkdir()
    for name, body in raw.items():
        path = ROOT / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
    if args.extract_only:
        print(json.dumps(dict(extracted=len(index), stage_archive_sha256=args.sha256)))
        return
    remote_archive, remote_script = '/tmp/numpy-baseline-cold48-ph-stage.tar.gz', '/tmp/dispatch_cold48_ph.py'
    for path in [str(ROOT), remote_archive, remote_script]:
        subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', path])], check=True)
    for path, target in [(args.archive, remote_archive), (Path(__file__), remote_script)]:
        subprocess.run(['scp', str(path), 'compute002:' + target], check=True)
    proc = subprocess.run(['ssh', 'compute002', shlex.join([PYTHON, '-B', remote_script,
        '--archive', remote_archive, '--sha256', args.sha256, '--extract-only'])], capture_output=True)
    (ROOT / 'compute-extract.stdout').write_bytes(proc.stdout)
    (ROOT / 'compute-extract.stderr').write_bytes(proc.stderr)
    assert proc.returncode == 0
    bindings = json.loads(raw['preparation/PH_BINDINGS.json'])
    jobs = []
    for i, identity in enumerate(bindings['identities']):
        proc = subprocess.run(['qsub', '-v', 'PH_CASE_INDEX=' + str(i), '-o', str(ROOT / ('case-' + str(i) + '-pbs.log')),
            str(ROOT / 'preparation/case_ph.pbs')], capture_output=True)
        (ROOT / ('case-' + str(i) + '-qsub.stdout')).write_bytes(proc.stdout)
        (ROOT / ('case-' + str(i) + '-qsub.stderr')).write_bytes(proc.stderr)
        (ROOT / ('case-' + str(i) + '-qsub-exit.txt')).write_text(str(proc.returncode) + '\n')
        assert proc.returncode == 0
        job = proc.stdout.decode().strip()
        assert job.endswith('.manager') and job.split('.')[0].isdigit()
        jobs.append(dict(index=i, identity=identity, pbs_job=job))
        (ROOT / 'dispatch.json').write_text(json.dumps(dict(stage_sha256=args.sha256, jobs=jobs,
            intended_jobs=8, original_tendencies_per_job=48, maximum_total_tendencies=384,
            full_years=0, no_automatic_retries=True), indent=2) + '\n')
    print(json.dumps(dict(jobs=[r['pbs_job'] for r in jobs], stage_sha256=args.sha256)))


if __name__ == '__main__':
    main()

from pathlib import Path
import hashlib,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-paired-audit-b';assert not r.exists();r.mkdir();controls={}
for backend,digest in [('cuda32','9de7e210e99f5354d9e18b7d6e6a6c08a38c3be871fe16ee974c2c9cc50380f1'),('jax32','bcdaca565455b5df336f8fe505dfc2debd4e5b0b38081a4cd55f6dae3c31a843')]:
    a=b/('qia3803-full-'+backend+'-b-evidence.tar.gz');assert hashlib.sha256(a.read_bytes()).hexdigest()==digest
    with tarfile.open(a) as tf:tf.extractall(r/'device'/backend,filter='data')
    assert json.loads((r/'device'/backend/'exit.json').read_text())['passed'];controls[a.name]=digest
for n in ['audit_qia3803_paired_b.py','qia3803_paired_b.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'qia3803_paired_b.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

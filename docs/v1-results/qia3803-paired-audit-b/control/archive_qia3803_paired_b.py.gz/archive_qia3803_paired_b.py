from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-paired-audit-b';d=json.loads((r/'audit.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and len(d['fields'])==380 and d['source_manifest_sha256']=='d9205b75c2baa2eb4afef8f8f26cf961118d396d63b959f0af89435ee997eab6';a=b/'qia3803-paired-audit-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['dispatch_qia3803_paired_b.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    for n in ['full-reference.npz','receipt.json']:t.add(b/'qia3803-whole-reference-a'/n,arcname='numpy-reference/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,maximum_absolute_difference=d['maximum_absolute_difference'],numpy_reference_absolute_differences=d['numpy_reference_absolute_differences'],budgets=d['budgets'])))

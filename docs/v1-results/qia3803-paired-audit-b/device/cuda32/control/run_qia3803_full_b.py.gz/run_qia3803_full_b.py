from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
kind=sys.argv[1];assert kind in ['cuda32','jax32'];b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-b';r=b/('qia3803-full-'+kind+'-b');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as driver
old=b/'qia-cuda-3803-a';binding=json.loads((old/'binding.json').read_text());assert sha(old/'input.npz')==binding['input_sha256']=='881b1cb5163fb3a72d3055b71dd22a268e764a2851e471b63f74a5c3e66cc55d';(r/'input.npz').write_bytes((old/'input.npz').read_bytes());(r/'binding.json').write_bytes((old/'binding.json').read_bytes());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
engine=driver.Backend(kind);xp=engine.xp;before=engine.update_forcing(tuple(xp.asarray(data['a'+str(k)]) for k in range(19)),data['environment']);prior=tuple(engine.host(v) for v in before)
np.savez_compressed(r/'before.npz',**{'a'+str(k):v for k,v in enumerate(prior)})
start=time.monotonic();failure=None;result=None
try:
    value=engine.step(*before,data['forcing'],environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']),return_surface=True)
    host=engine.host(value);after=tuple(engine.host(v) for v in driver.next_station_arrays(before,value));flat={}
    def flatten(value,prefix=''):
        for name,v in value.items():
            if isinstance(v,dict):flatten(v,prefix+name+'/')
            else:flat[prefix+name]=np.asarray(v)
    flatten(host);assert all(np.all(np.isfinite(v)) for v in flat.values())
    np.savez_compressed(r/'output.npz',**flat);np.savez_compressed(r/'after.npz',**{'a'+str(k):v for k,v in enumerate(after)})
    result=dict(raw_fields=len(flat),state_arrays=len(after),output_sha256=sha(r/'output.npz'),state_sha256=sha(r/'after.npz'))
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
if kind=='cuda32':xp.cuda.runtime.deviceSynchronize()
else:
    import jax
    jax.effects_barrier()
unchanged=all(sha(s/n)==h for n,h in m.items());same=all(np.array_equal(v,engine.host(w)) for v,w in zip(prior,before));assert unchanged and same and sha(r/'input.npz')==binding['input_sha256']
record=dict(scope='Uninstrumented frozen563-coordinate-B original3803 native19 full BGC/structure/MOST step; originalsource/input/oldstores/precision/iteration/tolerance gates retained. Rawreturnedfields/19nextarrays exported for independentEHPC single/cumulativeMHCN/impurity/reference/pair audits. No CPUforwardphysics or hardbudget audit on GPUhost, no failedannual advancement or scienceacceptance. Interpreteratexit bypass only after barrier/durable receipt.',backend=kind,failure=failure,result=result,seconds=time.monotonic()-start,source_unchanged=unchanged,input_unchanged=same,device_barrier_complete=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(r/'input.npz'))
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);os._exit(0 if failure is None else 1)

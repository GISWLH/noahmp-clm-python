from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3803-paired-audit-b'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'phase-coordinate-native-b-source.tar.gz'
assert sha(a) == '4ccc9752ab61b6c3ddc3e66c667c0e6da4e8a868b3235000930c1cadb15c1c91'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 563 and all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

terminal = b / 'qia-kink-cuda-year-h-failure-evidence.tar.gz'
assert sha(terminal) == '97a00af253db5c23c5beca9f8bb26da7d805c04775572423318fbf8734862924'
td = Path(os.environ['TMPDIR']) / 'original-terminal'; td.mkdir()
with tarfile.open(terminal) as t:
    t.extractall(td, filter='data')
report = json.loads((td / 'original-run/trajectory/batch.json').read_text())
assert report['status'] == 'failed' and report['steps_completed'] == 3803
checkpoint = td / 'original-run/trajectory' / report['checkpoint_file']
assert sha(checkpoint) == report['checkpoint_sha256']
with np.load(checkpoint, allow_pickle=False) as z:
    saved = dict(z)
device = r / 'device'
binding = json.loads((device / 'cuda32/binding.json').read_text())
receipts = {label: json.loads((device / folder / 'receipt.json').read_text()) for label, folder in [('cuda32','cuda32'),('jax32','jax32')]}
with np.load(device / 'cuda32/input.npz', allow_pickle=False) as z:
    data = dict(z)
before = tuple(data['a' + str(k)] for k in range(19))
for k in range(19):
    np.testing.assert_array_equal(before[k], saved['a' + str(k)])
assert binding['original_checkpoint_sha256'] == report['checkpoint_sha256'] and sha(device / 'cuda32/input.npz') == binding['input_sha256']
with np.load(b/'qia3803-whole-reference-a/full-reference.npz',allow_pickle=False) as z:reference=dict(z)
reference_errors={}
exports, states, budgets = {}, {}, {}
for label, folder in [('cuda32','cuda32'),('jax32','jax32')]:
    receipt = receipts[label]
    assert sha(device/folder/'input.npz')==binding['input_sha256'] and receipt['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
    with np.load(device/folder/'before.npz',allow_pickle=False) as z:actual_before=tuple(z['a'+str(k)] for k in range(19))
    for k in range(19):
        if k!=4:np.testing.assert_array_equal(actual_before[k],before[k])
        else:
            np.testing.assert_array_equal(actual_before[k][:,:7],before[k][:,:7]);np.testing.assert_array_equal(actual_before[k][:,10:],before[k][:,10:]);np.testing.assert_array_equal(actual_before[k][:,7:10],data['environment'])
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
    assert sha(device / folder / 'output.npz') == receipt['result']['output_sha256']
    assert sha(device / folder / 'after.npz') == receipt['result']['state_sha256']
    with np.load(device / folder / 'output.npz', allow_pickle=False) as z:
        flat = dict(z)
    with np.load(device / folder / 'after.npz', allow_pickle=False) as z:
        after = tuple(z['a' + str(k)] for k in range(19))
    out = {}
    for name, value in flat.items():
        parts = name.split('/'); target = out
        for part in parts[:-1]:target = target.setdefault(part, {})
        target[parts[-1]] = value
    incoming, residual, bound, tracer = driver.audit_step(before, after, data['forcing'], data['deposition'], data['nitrogen'], out)
    cumulative = driver.totals(after) - saved['initial'] - (saved['net'] + incoming)
    cbound = saved['bounds'] + bound
    assert np.all(abs(cumulative) <= cbound)
    budgets[label] = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(),
            cumulative_residual=cumulative.tolist(), original_cumulative_bounds=cbound.tolist(), impurity_residual=tracer.tolist())
    differences={}
    for name in ['h','le','gpp_gc_m2','nee_gc_m2']:
        value=np.asarray(out['diagnostics'][name],float).reshape(-1);target=np.asarray(reference[name],float).reshape(-1);absolute,near=(.0001,.001) if name.endswith('gc_m2') else (1.,10.)
        assert np.all(abs(value-target)<=np.where(abs(target)<=near,absolute,.1*abs(target)));differences[name]=float(abs(value-target).max())
    reference_errors[label]=differences
    exports[label] = flat; states[label] = after
assert exports['cuda32'].keys() == exports['jax32'].keys()
rows = []
for name, x in {**exports['cuda32'], **{'next'+str(k):v for k,v in enumerate(states['cuda32'])}}.items():
    y = states['jax32'][int(name[4:])] if name.startswith('next') else exports['jax32'][name]
    assert x.dtype == y.dtype and x.shape == y.shape and np.all(np.isfinite(x)) and np.all(np.isfinite(y)), name
    integer = x.dtype.kind in 'ibu'
    if integer:np.testing.assert_array_equal(x,y)
    else:
        assert x.dtype == np.dtype('float32'), (name,x.dtype)
        np.testing.assert_allclose(x,y,rtol=1e-6,atol=1e-6)
    rows.append(dict(field=name,dtype=str(x.dtype),integer_exact=integer,maximum_absolute=float(np.max(abs(x.astype(float)-y.astype(float)))) if x.size else 0.))
assert len(rows) == 380
record = dict(scope='EHPC compute original519H3803 exact primary19 and unchanged original ledgers; frozen563B both uninstrumented32 fullMOST/BGC steps independent single/cumulativeMHCN/impurity/350sameproductionNumPy science plus all361returned+19next raw1e-6/integer gates. Originalfailedyear unmodified; not fullnative64/canonical/annual/science acceptance.',
              numpy_reference_absolute_differences=reference_errors, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True, budgets=budgets, fields=rows,
              raw_output_fields=361, next_state_arrays=19, maximum_absolute_difference=max(x['maximum_absolute'] for x in rows),
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == h for n, h in m.items()),
              original_checkpoint_sha256=report['checkpoint_sha256'])
(r / 'audit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k:v for k,v in record.items() if k!='fields'},allow_nan=False),flush=True)

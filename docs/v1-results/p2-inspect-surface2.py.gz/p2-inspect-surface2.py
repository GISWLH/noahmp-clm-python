import sys,numpy as np
sys.path.insert(0,'tests')
from test_gpu_canopy_surface import cases,reference
from noahmp_clm.gpu.cuda.canopy_surface import run_canopy_surface_cuda
from noahmp_clm.gpu.cuda.column_heat import run_joint_heat_cuda
import cupy as cp
x=cases(np.float32,6);r=run_canopy_surface_cuda(*x,raise_on_failure=False)
for i in [0,1,2,7]:
 print('ROW',i,'oldsoil',x[1][i], 'p',x[2][i], flush=True)
 for k in ['thermal_temperature_offset','thermal_soil_cells','ground_nonshortwave_heat','soil_cells','converged','leaf_temperature','h','le']:
  print(k,cp.asnumpy(r[k][i]),flush=True)

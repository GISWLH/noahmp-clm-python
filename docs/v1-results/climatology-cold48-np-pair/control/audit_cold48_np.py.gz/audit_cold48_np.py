"""Independent PBS readback of all12 originalcold48 CUDA/NumPy pairs."""
from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
from datetime import datetime
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=Path(os.environ['NP_AUDIT_ROOT']);s=Path(os.environ['TMPDIR'])/'source';s.mkdir();device=Path(os.environ['TMPDIR'])/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();a=Path(os.environ['NP_SOURCE_ARCHIVE']);from climatology_contract_np import source_archive, REFERENCE, PARENT
source_archive(a)
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert manifest=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f' and len(m)==584 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from noahmp_clm.gpu.snow_mass import validate_snow_transfer
from fluxnet_deposition import DepositionSchedule
a=Path(os.environ['NP_DEVICE_ARCHIVE']);assert sha(a)==json.loads((r/'package.json').read_text())['device_archive_sha256']
with tarfile.open(a) as t:t.extractall(device,filter='data')
p=device/'current';d=json.loads((p/'receipt.json').read_text());e=json.loads((p/'exit.json').read_text());assert e['passed'] and e['actual_parent_returncode']==0 and e['receipt_sha256']==sha(p/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['cold_fields_exact']==23 and d['primary_state_arrays']==16 and d['captured_step_calls']==48 and d['cases']==12 and d['source_manifest_sha256']==manifest and sha(p/'trajectory/batch.json')==d['report_sha256'];protocol=json.loads((p/'inputs/protocol.json').read_text());assert protocol['source_manifest_sha256']==PARENT and protocol['case_count']==12
reference_archive=Path(os.environ['NP_REFERENCE_ARCHIVE']);assert sha(reference_archive)==REFERENCE
reference_root=Path(os.environ['TMPDIR'])/'jn-reference';reference_root.mkdir()
with tarfile.open(reference_archive) as t:t.extractall(reference_root,filter='data')
cpu=reference_root/'numpy';cp=json.loads((cpu/'receipt.json').read_text());assert cp['passed'] and cp['source_unchanged'] and cp['source_manifest_sha256']==PARENT and (cpu/'pbs-exit.txt').read_text().strip()=='0' and len(cp['cases'])==12;assert cp==json.loads((p/'ballberry-climatology-numpy-jr-receipt.json').read_text())
assert all((p/'inputs'/v.relative_to(cpu/'inputs')).read_bytes()==v.read_bytes() for v in (cpu/'inputs').rglob('*') if v.is_file())
assert {v.relative_to(p/'inputs').as_posix() for v in (p/'inputs').rglob('*') if v.is_file()}=={v.relative_to(cpu/'inputs').as_posix() for v in (cpu/'inputs').rglob('*') if v.is_file()}
assert sha(cpu/'SOURCE_SHA256.json')==PARENT
report,saved,rows=native.read_generation(p/'trajectory');assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['identity']['source_sha256']==native.source_hashes() and report['identity'].get('native_state_arrays',16)==16 and len(rows)==12
with np.load(p/'inputs/cold-reference.npz',allow_pickle=False) as z:cold=dict(z)
assert sha(p/'inputs/cold-reference.npz')==protocol['cold_reference_sha256'];paths=list((p/'trajectory').glob('state-0000000-*.npz'));assert len(paths)==1 and sha(paths[0])==json.loads((p/'cold-audit.json').read_text())['cold_checkpoint_sha256']
with np.load(paths[0],allow_pickle=False) as z:assert set(z.files)==set(cold) and len(z.files)==23 and all(z[k].dtype==cold[k].dtype and z[k].shape==cold[k].shape and z[k].tobytes()==cold[k].tobytes() for k in cold)
loaded=native.load_batch(p/'inputs/batch.json');schedules=[DepositionSchedule(c['config']) for c in loaded];assert len(loaded)==12 and all(s.monthly and s.nitrogen_rate>0 for s in schedules);applied_aerosol=np.zeros((12,5));applied_nitrogen=np.zeros(12)
initial=cold['initial'];net=np.zeros((12,4));bounds=net.copy();recorded_net=net.copy();maximum=net.copy();cumulative_max=net.copy();gate_max=net.copy();previous=tuple(cold['a'+str(k)] for k in range(16));tracer_max=np.zeros((12,5));field_count=None
for index in range(48):
    with np.load(p/'steps'/('call-'+str(index).zfill(5)+'.npz'),allow_pickle=False) as z:data=dict(z)
    before=tuple(data['before'+str(k)] for k in range(16));after=tuple(data['after'+str(k)] for k in range(16))
    expected_forcing=np.asarray([c['data']['forcing'][index] for c in loaded],np.float32);expected_nitrogen=np.asarray([s.nitrogen_rate for s in schedules],np.float32)*expected_forcing[:,0];expected_deposition=np.asarray([schedule.aerosol(datetime.strptime(str(c['data']['time_start'][index]),'%Y%m%d%H%M'),float(expected_forcing[k,0])) for k,(c,schedule) in enumerate(zip(loaded,schedules))],np.float32);np.testing.assert_array_equal(data['forcing'],expected_forcing);np.testing.assert_array_equal(data['nitrogen'],expected_nitrogen);np.testing.assert_array_equal(data['deposition'],expected_deposition);applied_aerosol+=data['deposition'].astype(float)*data['forcing'][:,0,None].astype(float);applied_nitrogen+=data['nitrogen'].astype(float)
    for x,y in zip(before,previous):assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes()
    for k in [2,6,10,12,14,15]:assert after[k].dtype==cold['a'+str(k)].dtype and after[k].tobytes()==cold['a'+str(k)].tobytes(),('constant',k,index)
    assert after[3].dtype==cold['a3'].dtype;np.testing.assert_array_equal(after[3][:,1:],cold['a3'][:,1:]);validate_snow_transfer(after[0],after[3][:,0],np.zeros(12,np.int32),np.zeros((12,16),after[0].dtype),np)
    out={}
    for name,value in data.items():
        if not name.startswith('output/'):continue
        parts=name.split('/')[1:];target=out
        for part in parts[:-1]:target=target.setdefault(part,{})
        target[parts[-1]]=value
    fields=sum(name.startswith('output/') for name in data);assert field_count is None or field_count==fields;field_count=fields
    incoming,residual,calculated_bound,tracer=native.audit_step(before,after,data['forcing'],data['deposition'],data['nitrogen'],out);bound=data['recorded/bound'];assert np.all(abs(residual)<=bound) and np.all(abs(residual)<=calculated_bound) and np.all(abs(data['recorded/residual'])<=bound);np.testing.assert_allclose(bound,calculated_bound,rtol=1e-12,atol=1e-12);np.testing.assert_allclose(residual,data['recorded/residual'],rtol=1e-12,atol=1e-12);np.testing.assert_allclose(incoming,data['recorded/incoming'],rtol=1e-12,atol=1e-12)
    net+=incoming;recorded_net+=data['recorded/incoming'];bounds+=bound;cumulative=native.totals(after)-initial-net;assert np.all(abs(cumulative)<=bounds);maximum=np.maximum(maximum,abs(residual));cumulative_max=np.maximum(cumulative_max,abs(cumulative));gate_max=np.maximum(gate_max,abs(residual)/bound);tracer_max=np.maximum(tracer_max,tracer);previous=after
for k in range(16):assert previous[k].dtype==saved['a'+str(k)].dtype and previous[k].tobytes()==saved['a'+str(k)].tobytes()
for name,value in [('initial',initial),('net',recorded_net),('bounds',bounds)]:np.testing.assert_array_equal(saved[name],value,err_msg=name)
specs={'h_wm2':(1.,0.,10.,1.),'le_wm2':(1.,0.,10.,1.),'gpp_gc_m2':(48.,0.,1.,.1),'nee_gc_m2':(48.,0.,1.,.1),'autotrophic_respiration_gc_m2':(48.,0.,1.,.1),'heterotrophic_respiration_gc_m2':(48.,0.,1.,.1),'et_mm':(48.,0.,.5,.05),'runoff_mm':(48.,0.,.5,.05),'tsoil_k':(1.,273.15,5.,.5),'smc_m3m3':(1.,0.,.02,.002),'liquid_m3m3':(1.,0.,.02,.002),'swe_m':(1.,0.,.001,.0001),'lai':(1.,0.,.1,.01)}
def compare(actual,expected,floor,absolute):
    actual=np.asarray(actual,float);expected=np.asarray(expected,float);assert actual.shape==expected.shape and np.all(np.isfinite(actual)) and np.all(np.isfinite(expected));difference=abs(actual-expected);limit=np.where(abs(expected)<=floor,absolute,.1*abs(expected));mean=float(expected.mean());corr=float(np.corrcoef(actual.ravel(),expected.ravel())[0,1]) if actual.size>1 and actual.std()>0 and expected.std()>0 else None
    return dict(passed=bool(np.all(difference<=limit)),maximum_absolute_difference=float(difference.max()),maximum_gate_ratio=float((difference/limit).max()),reference_mean=mean,model_mean=float(actual.mean()),signed_relative_bias_percent_reference_magnitude=100.*float((actual-expected).mean())/abs(mean) if abs(mean)>floor else None,instantaneous_correlation=corr,nearzero_threshold=floor,absolute_tolerance=absolute)
cases=[]
for column,(descriptor,trace) in enumerate(rows):
    name=descriptor['case'];record=dict(case=name,column=column);failure=None
    try:
        identity=protocol['cases'][column];assert identity['case']==name;own=next(q for q in cp['cases'] if q['case']==name);refroot=cpu/'runs'/name/'trajectory';reference=json.loads((refroot/'report.json').read_text());assert own['failure'] is None and own['captured_steps']==48 and own['source_unchanged'] and own['configuration_sha256']==identity['configuration_sha256'] and sha(refroot/'report.json')==own['report_sha256'] and reference['status']=='running' and reference['steps_completed']==48 and reference['steps_requested']==17520;refpath=refroot/reference['model_npz'];assert sha(refpath)==reference['model_npz_sha256']
        with np.load(refpath,allow_pickle=False) as z:ref=dict(z)
        for key in ['time_start','time_end']:np.testing.assert_array_equal(trace[key],ref[key])
        metrics={};failed=[]
        for key,(scale,offset,floor,absolute) in specs.items():
            actual=(trace[key].astype(float)-offset)*scale;expected=(ref[key].astype(float)-offset)*scale;q=compare(actual,expected,floor,absolute);q.update(scale=scale,offset=offset)
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and float(np.ptp(expected))>absolute:
                q['instantaneous_r_required']=True;q['passed']=q['passed'] and q['instantaneous_correlation'] is not None and q['instantaneous_correlation']>.85
            if not q['passed']:failed.append('trace/'+key)
            metrics[key]=q
        daily={}
        for key,floor,absolute in [('h_wm2',10.,1.),('le_wm2',10.,1.),('et_mm',.5,.05),('runoff_mm',.5,.05),('gpp_gc_m2',1.,.1),('nee_gc_m2',1.,.1)]:
            actual=float(trace[key].mean() if key.endswith('wm2') else trace[key].sum());expected=float(ref[key].mean() if key.endswith('wm2') else ref[key].sum());daily[key]=compare(actual,expected,floor,absolute)
            if not daily[key]['passed']:failed.append('daily/'+key)
        checkpoint=refroot/reference['checkpoint_file'];assert sha(checkpoint)==reference['checkpoint_sha256'];state,*rest=pickle.loads(checkpoint.read_bytes());assert rest[-1]==48;plant=state.bgc_state.plant;soil=state.bgc_state.soil;plant_ref=np.concatenate((plant.carbon,plant.nitrogen,[plant.reserve_carbon,plant.reserve_nitrogen]));soil_ref=np.concatenate((soil.carbon,soil.nitrogen,[soil.mineral_nitrogen]));pools={};seasonal=state.phenology_state;flags=[0,1,4] if seasonal is None else [int(seasonal.phase),int(seasonal.armed),5];np.testing.assert_array_equal(saved['a9'][column],flags)
        for key,actual,expected,floor,absolute in [('plant_carbon',saved['a11'][column,[0,1,2,6]],plant_ref[[0,1,2,6]],1.,.1),('plant_nitrogen',saved['a11'][column,[3,4,5,7]],plant_ref[[3,4,5,7]],.01,.001),('soil_carbon',saved['a13'][column,:7],soil_ref[:7],1.,.1),('soil_nitrogen',saved['a13'][column,7:],soil_ref[7:],.01,.001)]:
            pools[key]=compare(actual,expected,floor,absolute);pools[key].update(model=np.asarray(actual,float).tolist(),reference=np.asarray(expected,float).tolist())
            if not pools[key]['passed']:failed.append('pools/'+key)
        record.update(passed=not failed,failed_fields=failed,all13physical_trace_metrics=metrics,daily=daily,individual_cn_pools=pools,maximum_independent_step_m_h_c_n=maximum[column].tolist(),maximum_independent_cumulative_m_h_c_n=cumulative_max[column].tolist(),maximum_step_original_gate_ratio=gate_max[column].tolist(),original_cumulative_bounds=bounds[column].tolist(),maximum_impurity_residual=tracer_max[column].tolist(),configuration_sha256=identity['configuration_sha256'],numpy_checkpoint_sha256=sha(checkpoint),all48_actual_deposition_inputs_byteexact_to_declared_climatology=True,actual_firstday_aerosol_input_kgm2=applied_aerosol[column].tolist(),actual_firstday_nitrogen_input_gnm2=float(applied_nitrogen[column]))
    except Exception as error:
        failure=type(error).__name__+': '+str(error);record.update(passed=False,failure=failure);(r/(name+'-traceback.txt')).write_text(traceback.format_exc())
    (r/(name+'-verification.json')).write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');cases.append(record)
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=all(q['passed'] for q in cases),source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),device_archive_sha256=sha(a),reference_source_manifest_sha256=PARENT,reference_archive_sha256=REFERENCE,cold_fields_exact=23,all16state_chains_and_final_checkpoint_exact=True,physical_step_pairs=576,returned_fields_per_batched_step=field_count,cases=cases,seconds=time.monotonic()-start,scope='IndependentNPcandidateOnNM584 CUDA-only12x48 vs byte-proven unchangedJN NumPyreference forofficial2000nonzeroclimatology. All48actualquantizedaerosol/N/weatherinputs byteexact todeclaredmonthly/constant/Gregorianmidpoint schedule, no silentzerofallback. Beforeany fullclimatecycle. CompleteMHCN/impurity, exactcold23/chain16/final checkpoint,13 physicaltraces/dailyfixed10%/nearzeroabsolute/r>.85 when nonflat, eachC/Npool separately. All12factorial retained. Not annual/multiyear/spinup/observationalpass; no sameprecision claimfromCUDA-only.');(r/'receipt.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pbs_job=result['pbs_job'],passed=result['passed'],source_unchanged=result['source_unchanged'],cases=[dict(case=q['case'],passed=q['passed'],failed_fields=q.get('failed_fields'),failure=q.get('failure')) for q in cases],seconds=result['seconds'])),flush=True);assert result['passed'] and result['source_unchanged']

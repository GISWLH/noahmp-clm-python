from pathlib import Path
import hashlib,json,sys,tarfile
kind=sys.argv[1];b=Path('/home/lhwang/work/noahmp-v1');r=b/('qia1110-full-'+kind+'-h');d=json.loads((r/'exit.json').read_text());rec=json.loads((r/'receipt.json').read_text());assert d['returncode']==0 and d['passed'] and rec['failure'] is None and rec['device_barrier_complete'] and rec['source_unchanged'];a=b/('qia1110-full-'+kind+'-h-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['run_qia1110_full_h.py','control_qia1110_full_h.py','launch_qia1110_full_h.py','export_qia1110_full_h.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,json,os,runpy
os.environ['PYTEST_PLUGINS']='bounded_cache_guard_gd'
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-jo-full-gpu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());p=json.loads((r/'package.json').read_text());assert len(m)==581 and sha(s/'SOURCE_SHA256.json')==p['source_manifest_sha256'] and all(sha(s/n)==h for n,h in m.items());worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
# Original mixed GPU tests keep embedded small NumPy references. Full CPU suite
# and all targeted37 references run on EHPC; no station climate run on xuanzeCPU.
runpy.run_path(str(worker),run_name='__main__')

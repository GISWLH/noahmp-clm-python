from pathlib import Path
import datetime,hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();names=['run_qia_pft_optics_station_a.py','qia_pft_optics_station_a.pbs'];protocol=dict(scope='Prospective4-cold48cases before any newmodelrun,source518. FixedoriginalPFT1 fouropticalfractions vs previouslydeclared PFT/11C/NOAAcapacityupper:generic,optics,physiology,combined. Allstates/soil/root/LAI/SAI/CN/heights/met/window fixed;no scoreselection/defaultchange/scientificacceptance. ActualSPDAYL/CO2 anddynamicT/N remainunmatched,sphericalleafangles explicit.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=['generic','optics','physiology','combined'],source_archive_sha256='9756cdd1e82e618da5b836538ccd27ab842e09c669910b173493a502af855d91',controls_sha256={n:sha(b/n) for n in names},results=[])
p=b/'qia-pft-optics-station-a-protocol.json';assert not p.exists();p.write_text(json.dumps(protocol,indent=2)+'\n')
for label in protocol['cases']:
    r=b/('qia-pft-optics-'+label+'-a');assert not r.exists();r.mkdir()
    for n in names:
        raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw)
    (r/'protocol.json').write_bytes(p.read_bytes());job=subprocess.check_output(['qsub','-v','OPTICS_CASE='+label,str(r/names[1])],cwd=r,text=True).strip();rec=dict(case=label,pbs_job=job,protocol_sha256=sha(p));(r/'dispatch.json').write_text(json.dumps(rec,indent=2)+'\n');protocol['results'].append(rec)
print(json.dumps(protocol['results']))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');names=['qia-pft-optics-'+v+'-a' for v in ['generic','optics','physiology','combined','comparison']];a=b/'qia-pft-optics-station-a-evidence.tar.gz';assert not a.exists()
for name in names:assert (b/name/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((b/names[-1]/'comparison.json').read_text());assert d['source_unchanged'] and set(d['cases'])=={'generic','optics','physiology','combined'} and all(len(v['metrics'])==14 for v in d['cases'].values())
with tarfile.open(a,'w:gz') as t:
    for n in names:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(b).as_posix(),recursive=False)
    for n in ['qia-pft-optics-station-a-protocol.json','dispatch_qia_pft_optics_station_a.py','dispatch_qia_pft_optics_comparison_a.py','archive_qia_pft_optics_station_a.py']:
        t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(b/'ctsm-qia-run-r/year-boundary.json',arcname='reference/year-boundary.json',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

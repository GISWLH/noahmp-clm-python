from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-pft-optics-comparison-a';assert not r.exists();r.mkdir();controls={}
for n in ['compare_qia_pft_optics_station_a.py','qia_pft_optics_comparison_a.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
for label in ['generic','optics','physiology','combined']:
    p=b/('qia-pft-optics-'+label+'-a');assert (p/'pbs-exit.txt').read_text().strip()=='0' and json.loads((p/'receipt.json').read_text())['returncode']==0
job=subprocess.check_output(['qsub',str(r/'qia_pft_optics_comparison_a.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,controls_sha256=controls,scope='Only after all4 actual PBS/model0; all14 metrics and allcases, no outcome selection.'),indent=2)+'\n');print(job)

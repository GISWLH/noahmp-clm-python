from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time
assert os.environ.get('PBS_JOBID');label=os.environ['OPTICS_CASE'];assert label in ['generic','optics','physiology','combined']
b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-pft-optics-'+label+'-a');s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'pft-optics-final-a-source.tar.gz';assert sha(a)=='9756cdd1e82e618da5b836538ccd27ab842e09c669910b173493a502af855d91'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==518 and all(sha(s/n)==h for n,h in m.items())
cpu=b/'pft-optics-cpu-final-a';d=json.loads((cpu/'receipt.json').read_text());assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and d['counts']==dict(tests=937,failures=0,errors=0,skipped=0) and d['source_unchanged'] and json.loads((cpu/'SOURCE_SHA256.json').read_text())==m
gpu=json.loads((b/'pft-optics-gpu19-exit-a.json').read_text());assert gpu['passed'] and gpu['source_unchanged'] and gpu['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
original=b/'qia-stem-inputs-a/inputs';assert sha(original/'CN-Qia.npz')=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960' and sha(original/'CN-Qia-stem-config.json')=='339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1'
cfg=json.loads((original/'CN-Qia-stem-config.json').read_text());before=json.loads(json.dumps(cfg));traits=json.loads((b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json').read_text())['traits']
if label in ['optics','combined']:
    cfg['canopy_optics']={name:[traits[v]['values'],traits[n]['values']] for name,v,n in [('leaf_reflectance','rholvis','rholnir'),('leaf_transmittance','taulvis','taulnir'),('stem_reflectance','rhosvis','rhosnir'),('stem_transmittance','tausvis','tausnir')]}
if label in ['physiology','combined']:
    actual=json.loads((b/'ctsm-qia-run-s/physiology-restarts.json').read_text());analysis=json.loads((b/'ctsm-qia-canopy-analysis-w-d/diagnosis.json').read_text());factor=analysis['conditional_capacity_diagnosis']['daylight_factor_max'];vc=actual['equation_maximum_vcmax25_without_daylength']*factor
    cfg['leaf_parameters'].update(ball_berry_slope=actual['original_traits']['mbbopt']['value'],vcmax25=vc,jmax25=(2.59-.035*11.)*vc,tpu25=.167*vc,respiration25=.015*vc,growth_temperature=284.15)
assert all(cfg[n]==v for n,v in before.items() if n not in ['scope','leaf_parameters'])
cfg['scope']='Prospective four-case original-cold48 oncurrent518: generic,onlyfixedoriginalPFT1 opticalfractions,onlypreviousPFT/11C/approximateNOAAdaylightcapacityupper,combined. Allcases retained,no scoreselection/default change/calibration. Sphericalleafangles retained;not exactofficialDAYL/temperaturememory/Nprofile/CO2 matching. AllLAI/SAI/CN/soil/roots/heights/met/window fixed. Not annual/spinup/scientific acceptance.'
(r/'config.json').write_text(json.dumps(cfg,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
cmd=[sys.executable,'-u',str(s/'benchmarks/run_fluxnet_column.py'),'--input',str(original/'CN-Qia.npz'),'--input-manifest',str(original/'CN-Qia.json'),'--config',str(r/'config.json'),'--output',str(r/'trajectory'),'--stop-after','48']
start=time.monotonic();launch=dict(scope=cfg['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,command=cmd,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),configuration_sha256=sha(r/'config.json'),original_configuration_sha256=sha(original/'CN-Qia-stem-config.json'),input_diagnosis_sha256=sha(b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json'),source_archive_sha256=sha(a),cpu_receipt_sha256=sha(cpu/'receipt.json'),gpu19_exit_sha256=sha(b/'pft-optics-gpu19-exit-a.json'))
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
with (r/'model.log').open('x') as log:code=subprocess.run(cmd,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else None
receipt=dict(scope=cfg['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),status=report['status'] if report else None,steps_completed=report['steps_completed'] if report else None,report_sha256=sha(p) if p.exists() else None)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);assert code==0 and receipt['source_unchanged'] and report['status']=='running' and report['steps_completed']==48

"""Static downloaded-byte verification/packaging of existing OA readback evidence."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile


OUT = Path(__file__).resolve().parent
ROOT = OUT / 'ctsm-boundary-fields-oa'
READER = '0fb6bc718615fe0882754af2b3e4e9097013f893abbb8bb9784aae9c310a7cfb'
ENVIRONMENT = '6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
sha = lambda data: hashlib.sha256(data).hexdigest()
jobs = [('oa', 1587, 1), ('oa-b', 1588, 1), ('oa-c', 1589, 0)]
bundle = {}
verification = dict(passed=False, actual_final_pbs_exits={}, stages={}, forward_model_runs=0,
                    scope='Static verification/packaging only; no model or NetCDF imports, no numerical analysis or rerun.')
for host in ['manager', 'compute']:
    before = (ROOT / (host + '-before.sha256')).read_bytes()
    after = (ROOT / (host + '-after.sha256')).read_bytes()
    assert before == after
    entries = {}
    for line in before.decode().splitlines():
        digest, original = line.split('  ', 1)
        relative = original.removeprefix('/tmp/')
        data = (ROOT / host / relative).read_bytes()
        assert sha(data) == digest
        entries[relative] = digest
        bundle[host + '/' + relative] = data
    actual = {p.relative_to(ROOT / host).as_posix() for p in (ROOT / host).rglob('*') if p.is_file()}
    assert actual == set(entries)
    verification[host + '_unchanged_downloaded_files'] = len(entries)
    bundle[host + '-before.sha256'] = before
    bundle[host + '-after.sha256'] = after

result = None
for tag, number, code in jobs:
    stage = 'noahmp-ctsm-boundary-fields-' + tag
    dispatch = json.loads(bundle['manager/' + stage + '/dispatch.json'])
    assert dispatch['pbs_job'] == str(number) + '.manager' and dispatch['qsub_returncode'] == 0
    assert dispatch['forward_model_runs'] == 0
    assert dispatch['control_sha256']['read_ctsm_boundary_fields_oa.py'] == READER
    for name, digest in dispatch['control_sha256'].items():
        assert sha(bundle['manager/' + stage + '/' + name]) == digest
        assert sha(bundle['compute/' + stage + '/' + name]) == digest
    assert int(bundle['compute/' + stage + '/pbs-exit.txt']) == code
    qstat_name = 'ctsm-boundary-oa-independent-' + str(number) + ('-final-qstat.txt' if code == 0 else '-qstat.txt')
    qstat = (OUT / qstat_name).read_bytes()
    qtext = qstat.decode()
    assert re.search(r'^Job Id: ' + str(number) + r'\.manager\s*$', qtext, re.M)
    assert re.search(r'^\s*job_state = F\s*$', qtext, re.M)
    assert re.search(r'^\s*Exit_status = ' + str(code) + r'\s*$', qtext, re.M)
    bundle['qstat/' + qstat_name] = qstat
    verification['actual_final_pbs_exits'][str(number) + '.manager'] = code
    with tarfile.open(fileobj=io.BytesIO(bundle['compute/' + stage + '/result.tar.gz'])) as archive:
        inner = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in archive if m.isfile()}
    assert sha(inner['reader.py']) == READER and int(inner['worker-exit.txt']) == code
    for name, data in inner.items():
        bundle['original-results/' + str(number) + '/' + name] = data
    row = dict(pbs_exit=code, worker_exit=code, original_result_files=len(inner),
               pbs_output_present_on_manager=('manager/' + stage + '/pbs-output.log') in bundle,
               pbs_output_present_on_compute=('compute/' + stage + '/pbs-output.log') in bundle)
    if code:
        log = inner['reader.log'].decode()
        assert "ModuleNotFoundError: No module named 'netCDF4'" in log
        assert 'boundary-fields.json' not in inner and 'receipt.json' not in inner
        row['failure'] = 'netCDF4 import failed before any original NetCDF data read'
    else:
        receipt = json.loads(inner['receipt.json'])
        assert receipt['pbs_job'] == '1589.manager' and receipt['node'] == 'compute002'
        assert receipt['passed'] and receipt['failure'] is None and receipt['forward_model_runs'] == 0
        assert receipt['environment_archive_sha256'] == ENVIRONMENT and receipt['reader_sha256'] == READER
        assert [(s['name'], s['returncode']) for s in receipt['stages']] == [('relocate', 0), ('readback', 0)]
        assert receipt['fields_sha256'] == sha(inner['readback/boundary-fields.json'])
        result = json.loads(inner['readback/boundary-fields.json'])
        assert result['passed'] and result['failure'] is None and result['forward_model_runs'] == 0
        assert result['pbs_job'] == '1589.manager' and result['node'] == 'compute002'
        assert len(result['files']) == 12
        assert result['archives']['r']['sha256'] == '14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0'
        assert result['archives']['s']['sha256'] == '17a9287b46b7926fe6a0c39e180c97b2800fbf0a47f520dcdfb7c22a8075b661'
        assert all(r['unchanged_after_read'] for r in result['archives'].values())
        assert all(not ({'ROOTFR', 'ROOTR', 'ROOTFR_UNF'} & {n.upper() for n in f['variables']}) for f in result['files'])
        history = [f for f in result['files'] if '.clm2.h0.' in f['member']]
        assert len(history) == 3
        assert all({'BCDEP', 'DSTDEP', 'OCDEP'} <= set(f['variables']) for f in history)
        assert all(not ({'BCDEP', 'DSTDEP', 'OCDEP'} & set(f['selected_values'])) for f in history)
        row.update(fields_sha256=receipt['fields_sha256'], original_netcdf_members=12,
                   actual_root_fraction_absent_in_selected_files=True,
                   deposition_flux_metadata_present_values_not_read=True,
                   readback_seconds=receipt['stages'][1]['seconds'])
    verification['stages'][str(number)] = row

assert result is not None
earlier_name = 'ctsm-boundary-oa-independent-1589-qstat.txt'
earlier = (OUT / earlier_name).read_bytes()
assert re.search(r'^\s*job_state = E\s*$', earlier.decode(), re.M)
bundle['qstat/' + earlier_name] = earlier
verification['passed'] = True
verification['numerical_result_recalculated_locally'] = False
verification['scientific_acceptance_credit'] = False
bundle['STATIC_VERIFICATION.json'] = (json.dumps(verification, indent=2) + '\n').encode()
for name in ['CTSM_BOUNDARY_FIELDS_OA.md', 'package_ctsm_boundary_fields_oa.py']:
    bundle[name] = (OUT / name).read_bytes()
destination = OUT / 'ctsm-boundary-fields-oa-evidence.tar.gz'
metadata = OUT / 'ctsm-boundary-fields-oa-package.json'
assert not destination.exists() and not metadata.exists()
with tarfile.open(destination, 'w:gz') as packed:
    for name, data in sorted(bundle.items()):
        member = tarfile.TarInfo(name)
        member.size = len(data)
        packed.addfile(member, io.BytesIO(data))
details = {name: dict(sha256=sha(data), bytes=len(data)) for name, data in bundle.items()}
with tarfile.open(destination) as packed:
    assert len(packed.getmembers()) == len(details) and set(packed.getnames()) == set(details)
    for name, detail in details.items():
        data = packed.extractfile(name).read()
        assert sha(data) == detail['sha256'] and len(data) == detail['bytes']
package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
               artifacts=len(details), artifact_details=details, actual_final_pbs_exits=verification['actual_final_pbs_exits'],
               original_reader_sha256=READER, environment_archive_sha256=ENVIRONMENT,
               forward_model_runs=0, result_readback_passed=True, scientific_acceptance_credit=False,
               scope='Original R/S boundary readback only. Preserve two real import failures, later real F0, '
                     'unchanged reader and stage downloads. Root fractions absent in selected files; '
                     'BCDEP/DSTDEP/OCDEP metadata present but values not read. No model rerun or gate change.')
metadata.write_text(json.dumps(package, indent=2) + '\n', encoding='utf-8', newline='\n')
(ROOT / 'local-verification.json').write_bytes(bundle['STATIC_VERIFICATION.json'])
print(json.dumps({k: v for k, v in package.items() if k != 'artifact_details'}))

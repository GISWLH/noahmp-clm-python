"""EHPC-only readback of existing R/S boundary fields; no forward model."""
import datetime
import hashlib
import json
import os
import re
import sys
import tarfile
import traceback
from pathlib import Path

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
BASE = Path('/home/zhangyq/noahmp-v1')
OUT = Path(sys.argv[1])
OUT.mkdir(exist_ok=False)
ARCHIVES = {
    'r': '14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0',
    's': '17a9287b46b7926fe6a0c39e180c97b2800fbf0a47f520dcdfb7c22a8075b661',
}
NAMES = {
    'WATSAT', 'SUCSAT', 'BSW', 'HKSAT', 'DZSOI', 'ZSOI', 'ROOTFR', 'ROOTR',
    'ROOTFR_UNF', 'WA', 'ZWT', 'ZWT_PERCH', 'H2OSOI', 'H2OSOI_LIQ', 'H2OSOI_ICE',
    'T_SOISNO', 'TSA', 'RAIN', 'SNOW', 'QOVER', 'QDRAI', 'QRGWL', 'QRUNOFF',
    'QINFL', 'QFLX_DRAIN', 'QFLX_QRGWL', 'QCHARGE', 'FRAIN', 'FSNOW',
    'PCT_SAND', 'PCT_CLAY', 'ORGANIC', 'FMAX', 'PCT_NAT_PFT',
    'ROOTA_PAR', 'ROOTB_PAR', 'ROOTPROF_BETA', 'SMPSC', 'SMPSO',
    'MBBOPT', 'SLATOP', 'LEAFCN', 'FLNR', 'FNITR', 'MEDLYNSLOPE', 'MEDLYNINTERCEPT',
    'TLAI', 'TSAI', 'HTOP', 'HBOT', 'ELAI', 'ESAI', 'TIMEMGR_RST_CURR_YMD',
    'TIMEMGR_RST_CURR_TOD', 'TIME', 'TIME_BOUNDS',
}
PATTERN = re.compile(r'root|watsat|sucsat|hksat|aquifer|drain|^zwt|^wa$|bcph|ocph|dst[1-4]|dust|^qflx_.*(rain|snow)', re.I)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def scalar(value):
    return value.tolist() if isinstance(value, (np.ndarray, np.generic)) else value


def describe(variable):
    attributes = {}
    for name in ['units', 'long_name', 'standard_name', 'cell_methods', 'positive', '_FillValue', 'missing_value']:
        if name in variable.ncattrs():
            value = scalar(variable.getncattr(name))
            # Preserve nonfinite metadata explicitly instead of invalid JSON numbers.
            attributes[name] = value if not isinstance(value, float) or np.isfinite(value) else str(value)
    return dict(dimensions=variable.dimensions, shape=variable.shape, dtype=str(variable.dtype), attributes=attributes)


def read_values(variable):
    result = describe(variable)
    value = np.ma.asarray(variable[:])
    if value.dtype.kind not in 'biuf':
        result['status'] = 'metadata_only_nonnumeric'
        return result
    data = np.ma.getdata(value)
    mask = np.ma.getmaskarray(value) | ~np.isfinite(data)
    result.update(status='read_original_values', original_masked_count=int(np.ma.getmaskarray(value).sum()),
                  original_nonfinite_count=int((~np.isfinite(data)).sum()), valid_count=int((~mask).sum()))
    valid = data[~mask]
    result['valid_minimum'] = float(valid.min()) if valid.size else None
    result['valid_maximum'] = float(valid.max()) if valid.size else None
    clean = np.ma.array(data, mask=mask)
    if data.size <= 512:
        result['values'] = clean.tolist()
    elif 'time' in variable.dimensions:
        axis = variable.dimensions.index('time')
        result['first_two_storage_rows'] = np.take(clean, [0, 1] if data.shape[axis] > 1 else [0], axis=axis).tolist()
        result['last_storage_row'] = np.take(clean, [-1], axis=axis).tolist()
        result['storage_rows_are_not_retaged_intervals'] = True
    else:
        result['values_omitted_large_array'] = True
    return result


record = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), passed=False,
              forward_model_runs=0, archives={}, files=[], failure=None,
              scope='Readback only of original frozen official R/S archives. All variables have metadata; '
                    'selected soil/root/aquifer/precipitation/deposition values preserve original masks. '
                    'First/last restart is explicit, not an exhaustive temporal audit or same-condition/scientific pass.')
try:
    for case, expected in ARCHIVES.items():
        path = BASE / ('ctsm-qia-run-' + case) / 'case-configuration-private.tar.gz'
        raw_archive = path.read_bytes()
        assert sha(raw_archive) == expected
        record['archives'][case] = dict(path=str(path), sha256=expected, bytes=len(raw_archive))
        with tarfile.open(path) as archive:
            members = {item.name: item for item in archive if item.isfile()}
            inputs = ['inputdata/CN-Qia.official-interpolated-cold.nc',
                      'inputdata/clm5_params.c171117.nc', 'inputdata/surfdata.CN-Qia.engineering.nc']
            history = sorted(n for n in members if '/run/' in n and '.clm2.h0.' in n and n.endswith('.nc'))
            restarts = sorted(n for n in members if '/run/' in n and '.clm2.r.' in n and n.endswith('.nc'))
            assert len(history) == (2 if case == 'r' else 1)
            assert len(restarts) == (1 if case == 'r' else 48)
            selected = list(dict.fromkeys(inputs + history + [restarts[0], restarts[-1]]))
            for name in selected:
                raw = archive.extractfile(members[name]).read()
                row = dict(case=case, member=name, sha256=sha(raw), bytes=len(raw),
                           restart_selection='first_and_last' if name in restarts else None)
                with Dataset('read-only-memory.nc', mode='r', memory=raw) as dataset:
                    row['dimensions'] = {n: dict(size=len(d), unlimited=d.isunlimited()) for n,d in dataset.dimensions.items()}
                    row['variables'] = {n: describe(v) for n,v in dataset.variables.items()}
                    selected_names = [n for n in dataset.variables if n.upper() in NAMES or PATTERN.search(n)]
                    row['selected_values'] = {n: read_values(dataset[n]) for n in selected_names}
                    row['explicit_absent_requested_names'] = sorted(NAMES - {n.upper() for n in dataset.variables})
                record['files'].append(row)
        assert sha(path.read_bytes()) == expected
        record['archives'][case]['unchanged_after_read'] = True
    assert len(record['files']) == 12
    record['passed'] = True
except Exception as error:
    record['failure'] = type(error).__name__ + ': ' + str(error)
    (OUT / 'traceback.txt').write_text(traceback.format_exc())
(OUT / 'boundary-fields.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k:record[k] for k in ['pbs_job','node','passed','forward_model_runs','failure']}), flush=True)
raise SystemExit(0 if record['passed'] else 1)

"""One unchanged five-second read-only NQ sample; save actual SSH outcomes."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
EXPECTED = 'd5b3d0125e0d5b8df7ef37dc34db87f1e1fd92dc8f4098bf9a190baa584c3011'


def main():
    output = BASE / 'candidate-progress-px.json'
    assert not output.exists()
    assert hashlib.sha256((BASE / 'review_candidate_concurrency_nt.py').read_bytes()).hexdigest() == EXPECTED
    check = subprocess.run(['ssh', 'xuanze-neiwang', 'sha256sum /tmp/review_candidate_concurrency_nt.py'], capture_output=True, timeout=45)
    (BASE / 'candidate-progress-px-sampler-hash.stdout').write_bytes(check.stdout)
    (BASE / 'candidate-progress-px-sampler-hash.stderr').write_bytes(check.stderr)
    assert check.returncode == 0 and check.stdout.decode().split()[0] == EXPECTED
    command = ['ssh', 'xuanze-neiwang', '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/review_candidate_concurrency_nt.py']
    result = subprocess.run(command, capture_output=True, timeout=60)
    output.write_bytes(result.stdout)
    (BASE / 'candidate-progress-px.stderr').write_bytes(result.stderr)
    record = dict(actual_ssh_exit=result.returncode, command=command, sampler_sha256=EXPECTED,
        completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        stdout=output.name, stderr='candidate-progress-px.stderr')
    (BASE / 'candidate-progress-px-exit.json').write_text(json.dumps(record, indent=2) + '\n')
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    value = json.loads(result.stdout)
    print(json.dumps(dict(sample_utc=value['second']['utc'], closed=len(value['closed']),
        file=value['progress']['file'], pid=value['progress']['pid'],
        years={k:dict(status=v['status'],steps=v['steps_completed']) for k,v in value['years'].items()})))


if __name__ == '__main__':
    main()

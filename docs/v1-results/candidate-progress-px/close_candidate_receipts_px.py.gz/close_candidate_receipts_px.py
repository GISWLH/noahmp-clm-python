"""Verify saved PX receipt bytes; explicitly retain the original JAX-only module."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    snapshot_raw = (BASE / 'candidate-progress-px.json').read_bytes()
    snapshot = json.loads(snapshot_raw)
    remote_raw = (BASE / 'candidate-receipts-px.json').read_bytes()
    remote = json.loads(remote_raw)
    assert json.loads((BASE / 'candidate-receipts-px-exit.json').read_bytes())['actual_ssh_exit'] == 0
    assert remote['snapshot_sha256'] == sha(snapshot_raw) and remote['selected_immutable_files_unchanged']
    assert snapshot['closed'] == json.loads((BASE / 'candidate-progress-ps.json').read_bytes())['closed']
    files = {name: base64.b64decode(raw) for name, raw in remote['files'].items()}
    with tarfile.open(BASE / 'climatology-final-candidate-nm-source.tar.gz') as source:
        source_manifest = json.load(source.extractfile('SOURCE_SHA256.json'))
        jax_only = source.extractfile('tests/test_gpu_batch_shape.py').read()
    assert sha(jax_only) == source_manifest['tests/test_gpu_batch_shape.py']
    imports = [ast.unparse(n) for n in ast.walk(ast.parse(jax_only.decode())) if isinstance(n, (ast.Import, ast.ImportFrom))]
    assert any('jax' in text for text in imports) and not any('cupy' in text or '_cuda' in text for text in imports)
    facts = []
    for record in snapshot['closed']:
        stem = Path(record['file']).stem
        parent = json.loads(files[stem + '-exit.json'])
        receipt = json.loads(files[stem + '-receipt.json'])
        expected = json.loads(files[stem + '-expected.json'])
        assert parent == record and parent['actual_parent_returncode'] == 0 and parent['passed']
        assert sha(files[stem + '-receipt.json']) == parent['receipt_sha256']
        assert receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0 and receipt['passed']
        assert receipt['counts'] == dict(tests=record['expected_tests'], failures=0, errors=0, skipped=0)
        assert receipt['nodes'] == expected and len(expected) == len(set(expected)) == record['expected_tests']
        assert sha(files[stem + '-expected.json']) == receipt['expected_nodes_sha256']
        assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed']
        assert receipt['source_unchanged'] and not receipt['errors'] and receipt['source_files'] == 584
        assert receipt['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
        barriers = {r['backend']:r['status'] for r in receipt['device_barriers']}
        required = {'jax':'complete'} if stem == 'test_gpu_batch_shape' else {'jax':'complete','cupy':'complete'}
        assert barriers == required
        facts.append(dict(file=record['file'], nodes=record['expected_tests'], parent0=True, worker0=True,
            receipt_sha256=record['receipt_sha256'], device_barriers=barriers))
    eta = json.loads((BASE / 'GPU_ETA_NQ_PX_REFRESH.json').read_bytes())
    assert len(facts) == 23 and sum(r['nodes'] for r in facts) == 123
    summary = dict(passed=True, sample_utc=eta['sample_utc'], closed_modules=23, new_closed_modules_since_PS=0,
        completed_nodes=155, fresh_nodes=123, inherited_nodes=32, full_closed_receipts_verified=True,
        closed_receipts=facts, running_module=eta['regression']['current_file'], current_pid=eta['regression']['current_pid'],
        current_module_credit=0, processes=eta['processes'], physical_gpu=1, gpu_uuid=eta['gpu_uuid'],
        gpu_samples=eta['gpu_samples'], unknown_gpu_app_pids=eta['gpu_app_pids_outside_sampled_task_family'],
        remaining_hours=eta['regression']['remaining_hours'], formula=eta['regression']['formula'], active_elapsed_subtracted_seconds=0,
        years={k:dict(status=v['status'],completed=v['completed'],eta=v['conditional_remaining_hours']) for k,v in eta['years'].items()},
        host_available_kib=eta['host_available_kib'],
        source_sha256={n:sha((BASE/n).read_bytes()) for n in ('candidate-progress-px.json','candidate-receipts-px.json','GPU_ETA_NQ_PX_REFRESH.json')},
        initial_metadata_check=dict(actual_exit=1, script='verify_candidate_receipts_px.py',
            reason='Initial checker incorrectly required a CuPy barrier for the original JAX-only test_gpu_batch_shape module.',
            raw_remote_result_preserved=True, model_failure=False, corrected_from_original_test_sha256=sha(jax_only)),
        scope='One five-second read-only sample plus fixed closed receipt verification. No new closed modules; no new archive package, numerical execution, or task control.')
    path = BASE / 'candidate-progress-px-verification.json'
    path.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(dict(passed=True, closed_modules=23, new_closed_modules=0, completed_nodes=155,
                         remaining_hours=summary['remaining_hours'], verification_sha256=sha(path.read_bytes()))))


if __name__ == '__main__':
    main()

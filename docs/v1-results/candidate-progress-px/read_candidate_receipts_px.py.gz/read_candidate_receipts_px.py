"""Read immutable receipts for the fixed PX snapshot; no process control."""
import base64
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/lhwang/work/noahmp-v1/candidate-full-gpu-nq')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main(expected_records, snapshot_sha256):
    files, results = {}, []
    spec = json.loads((ROOT / 'candidate-full-gpu-nq-spec.json').read_bytes())
    for expected in expected_records:
        stem = Path(expected['file']).stem
        names = [stem + suffix for suffix in ('-exit.json', '-receipt.json', '-expected.json')]
        raw = {name: (ROOT / name).read_bytes() for name in names}
        parent, receipt, nodes = (json.loads(raw[name]) for name in names)
        errors = []
        checks = dict(parent_matches_snapshot=parent == expected,
            actual_parent0=parent['actual_parent_returncode'] == 0 and parent['passed'] is True,
            receipt_sha_matches=sha(raw[names[1]]) == parent['receipt_sha256'],
            worker_and_pytest0=receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0 and receipt['passed'],
            full_count_no_skips=receipt['counts'] == dict(tests=parent['expected_tests'], failures=0, errors=0, skipped=0),
            exact_nodes=receipt['nodes'] == nodes == spec['gpu_nodes_by_file'][expected['file']],
            expected_sha=sha(raw[names[2]]) == receipt['expected_nodes_sha256'],
            all_phases=receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed'],
            source_identity=receipt['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f' and receipt['source_files'] == 584,
            source_unchanged=receipt['source_unchanged'], no_errors=not receipt['errors'],
            device_barriers={r['backend']: r['status'] for r in receipt['device_barriers']} == {'jax': 'complete', 'cupy': 'complete'})
        errors.extend(name for name, good in checks.items() if not good)
        results.append(dict(file=expected['file'], tests=parent['expected_tests'], passed=not errors,
                            checks=checks, errors=errors, receipt_sha256=sha(raw[names[1]])))
        files.update(raw)
    unchanged = all((ROOT / name).read_bytes() == raw for name, raw in files.items())
    print(json.dumps(dict(snapshot_sha256=snapshot_sha256, passed=unchanged and all(r['passed'] for r in results),
        selected_immutable_files_unchanged=unchanged, selected_closed_modules=len(results),
        selected_closed_nodes=sum(r['tests'] for r in results if r['passed']), results=results,
        files={name: base64.b64encode(raw).decode() for name, raw in files.items()}), indent=2))

"""Preserve the PX sample and correct one stale interpretation; stdlib only."""
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
LABEL = 'candidate-progress-px'
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def main():
    initial_path = BASE / 'GPU_ETA_NQ_PX_REFRESH.json'
    initial_raw = initial_path.read_bytes()
    assert sha(initial_raw) == 'f37062fdc1271a0d59db6ed909f5c922bc005ca7b292104913e78de32124db8a'
    initial = json.loads(initial_raw)
    corrected = copy.deepcopy(initial)
    old = 'A concurrent unattributed GPU app makes the unchanged historical timing formula conditional on shared resources; no measured speed penalty or new deadline is inferred.'
    new = ('No GPU app outside the sampled task family was observed on CUDA1 in this snapshot. '
           'The earlier unknown app\'s later state is unobserved; shared-resource effects remain '
           'a general condition of the historical timing estimate.')
    assert initial['gpu_app_pids_outside_sampled_task_family'] == []
    assert initial['limitations'].count(old) == 1
    index = initial['limitations'].index(old)
    corrected['limitations'][index] = new
    reverted = copy.deepcopy(corrected)
    reverted['limitations'][index] = old
    assert reverted == initial
    corrected_name = 'GPU_ETA_NQ_PX_REFRESH_CORRECTED.json'
    corrected_raw = encode(corrected)
    (BASE / corrected_name).write_bytes(corrected_raw)
    verification = json.loads((BASE / 'candidate-progress-px-verification.json').read_bytes())
    assert verification['passed'] and verification['new_closed_modules_since_PS'] == 0
    assert verification['completed_nodes'] == 155 and verification['closed_modules'] == 23
    assert verification['unknown_gpu_app_pids'] == []
    assert corrected['regression']['remaining_hours'] == [19.253448133711395, 41.34312126076553]
    assert all(v['status'] == 'failed' and v['conditional_remaining_hours'] is None
               for v in corrected['years'].values())
    snapshot = (BASE / 'candidate-progress-px.json').read_bytes()
    ps_raw = (BASE / 'candidate-progress-ps.json').read_bytes()
    assert json.loads(snapshot)['closed'] == json.loads(ps_raw)['closed']
    source_path = BASE / 'climatology-final-candidate-nm-source.tar.gz'
    assert sha(source_path.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    with tarfile.open(source_path) as source:
        manifest_raw = source.extractfile('SOURCE_SHA256.json').read()
        jax_only = source.extractfile('tests/test_gpu_batch_shape.py').read()
    assert sha(manifest_raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert sha(jax_only) == json.loads(manifest_raw)['tests/test_gpu_batch_shape.py']
    correction = dict(passed=True, scope='Interpretation correction only; no resampling, numerical execution, or changed timing formula.',
        original_sha256=sha(initial_raw), corrected_sha256=sha(corrected_raw),
        changed_json_paths=[f'limitations[{index}]'], old=old, new=new,
        original_sample_sha256=sha(snapshot), original_sample_unchanged=True,
        original_verification_sha256=sha((BASE / 'candidate-progress-px-verification.json').read_bytes()),
        unchanged_closed_reference=dict(path='candidate-progress-ps.json', sha256=sha(ps_raw),
            raw_included=False, published='docs/v1-results/nq-column-closures-ps/manifest.json'),
        nm_reference=dict(archive=source_path.name, sha256=sha(source_path.read_bytes()),
            manifest_sha256=sha(manifest_raw), original_jax_only_test_sha256=sha(jax_only)),
        initial_receipt_checker_exit=1, corrected_offline_receipt_checker_passed=True,
        initial_checker_issue='CuPy barrier incorrectly required for the original JAX-only batch-shape test; original output and correction retained.',
        original_verification_scope_note='Its no-new-archive statement describes the earlier verification action, before this compact publication package was requested.')
    correction_name = LABEL + '-correction.json'
    (BASE / correction_name).write_bytes(encode(correction))
    names = (
        'candidate-progress-px.json', 'candidate-progress-px.stderr', 'candidate-progress-px-exit.json',
        'candidate-progress-px-sampler-hash.stdout', 'candidate-progress-px-sampler-hash.stderr',
        'candidate-receipts-px.json', 'candidate-receipts-px.stderr', 'candidate-receipts-px-exit.json',
        'candidate-progress-px-verification.json', 'GPU_ETA_NQ_PX_REFRESH.json', corrected_name,
        'GPU_ETA_NQ.json', correction_name, 'sample_candidate_progress_px.py',
        'review_candidate_concurrency_nt.py', 'read_candidate_receipts_px.py',
        'verify_candidate_receipts_px.py', 'close_candidate_receipts_px.py',
        'refresh_gpu_eta_px.py', Path(__file__).name)
    items = {name: (BASE / name).read_bytes() for name in names}
    items['original-source/tests/test_gpu_batch_shape.py'] = jax_only
    items['inventory.json'] = encode({name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(items.items())})
    target = BASE / (LABEL + '-evidence.tar.gz')
    with target.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(items.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                archive.addfile(entry, io.BytesIO(raw))
    with tarfile.open(target) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive} == items
    assert initial_path.read_bytes() == initial_raw
    assert (BASE / 'candidate-progress-px.json').read_bytes() == snapshot
    package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
        artifacts=len(items), actual_new_tests=0, actual_closed_gpu_nodes=155,
        scope='One original 15:12 UTC PX CUDA1 read-only snapshot, 23 complete module receipts, preserved initial checker issue and corrected verification, unchanged conditional 19.25–41.34 h regression formula, and a one-sentence current-resource interpretation correction. No new closed nodes, no repeated PS module logs, no numerical execution or task control; NS/NZ remain failed7275 with annual ETA null.')
    (BASE / (LABEL + '-package.json')).write_bytes(encode(package))
    print(json.dumps(package, ensure_ascii=False))
    print(json.dumps(dict(corrected_sha256=sha(corrected_raw), correction_sha256=sha(encode(correction)))))


if __name__ == '__main__':
    main()

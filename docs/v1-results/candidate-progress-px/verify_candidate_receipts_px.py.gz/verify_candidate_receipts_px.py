"""Capture fixed PX closed receipt bytes and write compact status; no physics."""
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    snapshot_raw = (BASE / 'candidate-progress-px.json').read_bytes()
    snapshot = json.loads(snapshot_raw)
    before = json.loads((BASE / 'candidate-progress-ps.json').read_bytes())
    assert snapshot['closed'] == before['closed']
    target = BASE / 'candidate-receipts-px.json'
    assert not target.exists()
    script = (BASE / 'read_candidate_receipts_px.py').read_text()
    script += '\nmain(json.loads(' + repr(json.dumps(snapshot['closed'])) + '), ' + repr(sha(snapshot_raw)) + ')\n'
    result = subprocess.run(['ssh', 'xuanze-neiwang', '/home/lhwang/venvs/noahmp-phase3b/bin/python -B -'],
                            input=script.encode(), capture_output=True, timeout=45)
    target.write_bytes(result.stdout)
    (BASE / 'candidate-receipts-px.stderr').write_bytes(result.stderr)
    (BASE / 'candidate-receipts-px-exit.json').write_text(json.dumps(dict(actual_ssh_exit=result.returncode,
        executed_stdin_sha256=sha(script.encode()), snapshot_sha256=sha(snapshot_raw),
        stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr)), indent=2) + '\n')
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    checked = json.loads(result.stdout)
    assert checked['snapshot_sha256'] == sha(snapshot_raw) and checked['passed']
    assert checked['selected_closed_modules'] == 23 and checked['selected_closed_nodes'] == 123
    eta = json.loads((BASE / 'GPU_ETA_NQ_PX_REFRESH.json').read_bytes())
    summary = dict(passed=True, sample_utc=eta['sample_utc'], closed_modules=23, new_closed_modules_since_PS=0,
        completed_nodes=155, fresh_nodes=123, inherited_nodes=32,
        full_closed_receipts_verified=True, receipt_snapshot_sha256=sha(result.stdout),
        running_module=eta['regression']['current_file'], current_pid=eta['regression']['current_pid'],
        current_module_credit=0, processes=eta['processes'], physical_gpu=1, gpu_uuid=eta['gpu_uuid'],
        gpu_samples=eta['gpu_samples'], unknown_gpu_app_pids=eta['gpu_app_pids_outside_sampled_task_family'],
        remaining_hours=eta['regression']['remaining_hours'], formula=eta['regression']['formula'],
        active_elapsed_subtracted_seconds=0,
        years={k:dict(status=v['status'], completed=v['completed'], eta=v['conditional_remaining_hours']) for k,v in eta['years'].items()},
        host_available_kib=eta['host_available_kib'],
        source_sha256={n:sha((BASE / n).read_bytes()) for n in ('candidate-progress-px.json','candidate-receipts-px.json','GPU_ETA_NQ_PX_REFRESH.json')},
        scope='One unchanged five-second read-only sample plus fixed closed receipt verification. No new closed modules; no new archive package or task control.')
    (BASE / 'candidate-progress-px-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(dict(passed=True, closed_modules=23, fresh_nodes=123, inherited_nodes=32,
                         new_closed_modules=0, remaining_hours=summary['remaining_hours'],
                         summary_sha256=sha((BASE / 'candidate-progress-px-verification.json').read_bytes()))))


if __name__ == '__main__':
    main()

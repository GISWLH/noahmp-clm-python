"""Frozen four-site mapping, before any run using these deposition inputs."""
from pathlib import Path
import calendar, hashlib, json
import numpy as np
from scipy.io import netcdf_file
from noahmp_clm.snow_forcing import SnowDepositionClimatology

root=Path('outputs/v1/deposition-inputs-a')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
aero=root/'aerosoldep_monthly_2000_mean_1.9x2.5_c090421.nc'
nitrogen=root/'fndep_clm_hist_simyr1849-2006_1.9x2.5_c100428.nc'
assert sha(aero)=='2e920f2558685c790e904185bd3a9150435f31e3dca2d2ebb1aa1f6b60ae61ff'
assert sha(nitrogen)=='21147673ba607ac405152a11da54513234f975ee595df17eeb13658467910888'
clim=SnowDepositionClimatology.from_netcdf(aero,expected_sha256=sha(aero))
with netcdf_file(nitrogen,mmap=False) as f:
    lat=np.array(f.variables['lat'][:],float);lon=np.array(f.variables['lon'][:],float)
    np.testing.assert_array_equal(lat,clim.latitude);np.testing.assert_array_equal(lon,clim.longitude)
    years=np.array(f.variables['YEAR'][:]);idx=np.flatnonzero(years==2000)
    assert len(idx)==1
    ns={}
    for name in ('NDEP_year','NDEP_NOy_year','NDEP_NHx_year'):
        v=f.variables[name];assert v.units.decode().strip()=='g(N)/m2/yr'
        ns[name]=np.array(v[idx[0]],float)
        assert np.isfinite(ns[name]).all() and (ns[name]>=0).all()
    component_error=float(np.max(abs(ns['NDEP_year']-ns['NDEP_NOy_year']-ns['NDEP_NHx_year'])))
    np.testing.assert_allclose(ns['NDEP_year'],ns['NDEP_NOy_year']+ns['NDEP_NHx_year'],rtol=2e-7,atol=1e-8)
out=root/'sites';out.mkdir(exist_ok=False)
rows=[]
for site in ('CN-Cng','CN-Qia','CN-Cha','CN-HaM'):
    meta_path=Path('outputs/v1')/('multiyear-inputs-b' if site=='CN-Cng' else 'multiyear-inputs-a')/(site+'.json')
    meta=json.loads(meta_path.read_text());y,x=meta['latitude'],meta['longitude']%360
    i,j=int(np.searchsorted(lat,y)-1),int(np.searchsorted(lon,x)-1)
    assert 0<=i<len(lat)-1 and 0<=j<len(lon)-1
    fy=(y-lat[i])/(lat[i+1]-lat[i]);fx=(x-lon[j])/(lon[j+1]-lon[j])
    nodes=[(i,j),(i,j+1),(i+1,j),(i+1,j+1)]
    weights=np.array([(1-fy)*(1-fx),(1-fy)*fx,fy*(1-fx),fy*fx]);assert abs(weights.sum()-1)<1e-15
    values=np.stack([clim.rates[:,ii,jj] for ii,jj in nodes])
    monthly=np.einsum('i,ijk->jk',weights,values)
    # Independently verify the spatial map using the existing published reader
    # at actual Gregorian monthly centers (only the verification uses year 2001).
    ends=np.cumsum([calendar.monthrange(2001,m)[1] for m in range(1,13)])
    centers=ends-.5*np.diff(np.r_[0,ends])
    sampled=np.array([clim.at_site(y,x,t,2001) for t in centers])
    np.testing.assert_allclose(sampled,monthly,rtol=3e-15,atol=0)
    nvals={k:[float(v[ii,jj]) for ii,jj in nodes] for k,v in ns.items()}
    nmap={k:float(np.dot(weights,v)) for k,v in nvals.items()}
    record=dict(site=site,latitude=y,longitude=x,site_manifest_sha256=sha(meta_path),
        scope='Fixed year-2000 coarse model climatology for subsequent runs; not site observations or a historical trend',
        source_files={aero.name:sha(aero),nitrogen.name:sha(nitrogen)},
        source_urls=[
          'https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/atm/cam/chem/trop_mozart_aero/aero/'+aero.name,
          'https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/lnd/clm2/ndepdata/'+nitrogen.name],
        nodes=[dict(latitude=float(lat[ii]),longitude=float(lon[jj]),weight=float(w)) for (ii,jj),w in zip(nodes,weights)],
        node_aerosol_rates_kg_m2_s=values.tolist(),node_nitrogen_gn_m2_yr=nvals,
        aerosol_species=['black_carbon_total','dust01','dust02','dust03','dust04'],
        aerosol_components=[['BCDEPWET','BCPHIDRY','BCPHODRY']]+[[f'DSTX{k:02d}WD',f'DSTX{k:02d}DD'] for k in range(1,5)],
        aerosol_deposition_monthly_kg_m2_s=monthly.tolist(),
        nitrogen_annual_components_gn_m2=nmap,nitrogen_deposition_gn_m2_s=nmap['NDEP_year']/(365*86400),
        nitrogen_time_convention='Constant rate using source noleap year of 365 days; a Gregorian leap year receives 366/365 of this annual amount',
        aerosol_time_convention='Cyclic linear interpolation of calendar-month midpoint rates, actual Gregorian month lengths, evaluated at forcing interval midpoint',
        limitations=[
            'Organic carbon is present in source but not in the five-tracer snow model; excluded, not silently added to BC.',
            'Hydrophilic and hydrophobic BC deposition are summed into the model single BC tracer.',
            'Aerosol filename/date identify 2000, but global case/history includes 1850 labels. Actual arrays differ from the separately downloaded 1850 file; metadata inconsistency is retained.',
            'N is annual offline NOy+NHx deposition, not the newer CLM5 monthly nitrogen dataset.',
            'Positive deposition accumulates total system N in the simplified current BGC model without leaching/denitrification; total-N equilibrium is not claimed.'
        ])
    p=out/(site+'.json');p.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    rows.append(dict(site=site,file=p.name,sha256=sha(p),nitrogen_gn_m2_365days=nmap['NDEP_year'],
        aerosol_monthly_min=monthly.min(0).tolist(),aerosol_monthly_max=monthly.max(0).tolist(),
        spatial_crosscheck_max_absolute=float(abs(sampled-monthly).max())))
report=dict(scope='Input mapping only; no model scores',instrument_sha256=sha(Path(__file__)),
    nitrogen_component_max_absolute_roundoff_gn_m2_yr=component_error,sites=rows)
(root/'site-mapping.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

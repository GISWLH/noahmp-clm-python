from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-portable-smoke-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'smoke.json').read_text());assert r['pbs_job']=='115.manager' and r['all_commands_returned_zero'] and r['c_fortran_python_values_exact'] and len(r['stages'])==19 and all(v['returncode']==0 for v in r['stages']) and (root/'pbs-exit.txt').read_text().strip()=='0'
names=['smoke_ctsm_portable_b.py','ctsm_portable_smoke_b.pbs','smoke.json','smoke.log','node.txt','pbs-exit.txt','smoke-artifacts.tar.gz'];pairs=[(root/n,n) for n in names]+[(Path(__file__),Path(__file__).name)]
archive=base/'ctsm-portable-smoke-b-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(path=str(archive),files=len(pairs),sha256=sha(archive),seconds=r['seconds'])))

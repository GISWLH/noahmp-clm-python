program smoke
use netcdf
implicit none
integer :: n,d,v,code
real(8) :: x(2)
code=nf90_open("c-smoke.nc",nf90_nowrite,n)
if(code/=nf90_noerr) stop 1
code=nf90_inq_varid(n,"value",v)
if(code/=nf90_noerr) stop 2
code=nf90_get_var(n,v,x)
if(code/=nf90_noerr) stop 3
if(any(x/=(/1.25d0,2.5d0/))) stop 4
code=nf90_close(n)
if(code/=nf90_noerr) stop 5
code=nf90_create("fortran-smoke.nc",nf90_clobber,n)
if(code/=nf90_noerr) stop 6
code=nf90_def_dim(n,"n",2,d)
if(code/=nf90_noerr) stop 7
code=nf90_def_var(n,"value",nf90_double,(/d/),v)
if(code/=nf90_noerr) stop 8
code=nf90_enddef(n)
if(code/=nf90_noerr) stop 9
x=(/277.5d0,3.d0/)
code=nf90_put_var(n,v,x)
if(code/=nf90_noerr) stop 10
code=nf90_close(n)
if(code/=nf90_noerr) stop 11
print *,"Fortran netCDF read/write complete"
end program smoke

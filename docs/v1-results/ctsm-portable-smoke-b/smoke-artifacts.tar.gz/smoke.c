#include <netcdf.h>
#include <stdio.h>
int main(void){int n,d,v;double x[2]={1.25,2.5};
if(nc_create("c-smoke.nc",NC_CLOBBER,&n))return 1;
if(nc_def_dim(n,"n",2,&d)||nc_def_var(n,"value",NC_DOUBLE,1,&d,&v)||nc_enddef(n)||nc_put_var_double(n,v,x)||nc_close(n))return 2;
puts("C netCDF write complete");return 0;}

from pathlib import Path
import datetime,hashlib,json,sys,tarfile

mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='audit-v':
    b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-recovery-c-prefix-audit-v';d=json.loads((r/'receipt.json').read_text())
    assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and d['pbs_job']=='357.manager'
    assert d['source_manifest_sha256']=='1bc9065e3c7c568cd71c56cc4b87bb88073bc50bc68bece8851239fd88fb1fc2'
    for c in d['cases']:
        assert c['passed'] and c['cold_fields_exact']==30 and c['physical_step_pairs']==48 and c['all23state_chains_and_final_checkpoint_exact']
        assert len(c['all23physical_trace_metrics'])==24
    items=[(p,p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()]
    items += [(b/n,'control/'+n) for n in ['dispatch_qia_prefix_audit_v.py',Path(__file__).name]]
    refs={'prefix_input_archive_sha256':'8cee7134ee4ad9f51c1c8de03d9f601389df98b39b43ad09a424f061cac8f313','note':'Original all23physical_trace_metrics key contains24 actual trace variables;23 is primary state array count. Preserve original bytes. Both cases and every original recorded guard retained; no annual/observational/JAXsameprecision claim.'}
    name='qia-recovery-c-prefix-audit-v'
elif mode=='boundary-w':
    b=Path('/home/lhwang/work/noahmp-v1');items=[];checks=[]
    for label in ['capacity','capacity_optics']:
        r=b/('qia-richards-'+label+'-cuda-year-c');v=json.loads((r/'prefix-verification.json').read_text());a=json.loads((r/'year-start-audit.json').read_text());p=json.loads((r/'validated-prefix-report.json').read_text())
        assert v['passed'] and v['source_unchanged'] and a['saved_fields_exact']==30 and a['cpu_verification_sha256']==sha(r/'prefix-verification.json')
        assert a['verified_prefix_checkpoint_sha256']==a['current_checkpoint_sha256']==v['prefix_checkpoint_sha256']==sha(r/'validated-prefix-state.npz')
        assert sha(r/'validated-prefix-report.json')==v['prefix_batch_report_sha256'] and p['steps_completed']==48 and p['steps_requested']==17520 and p['status']=='running'
        names=['prefix-verification.json','validated-prefix-state.npz','validated-prefix-report.json','year-start-audit.json','first-continued-step.npz','year-worker.json','year-launch.json','year-resource-check.json']
        for n in names:assert (r/n).is_file();items.append((r/n,label+'/'+n))
        checks.append({'case':label,'immutable_files_sha256':{n:sha(r/n) for n in names}})
    items += [(b/n,'control/'+n) for n in ['run_qia_cuda_year_w.py','control_qia_cuda_year_w.py','launch_qia_cuda_year_w.py',Path(__file__).name]]
    items.append((b/'clm-numerical-recovery-c/SOURCE_SHA256.json','control/SOURCE_SHA256.json'))
    refs={'checks':checks,'prefix_archive_sha256':'8cee7134ee4ad9f51c1c8de03d9f601389df98b39b43ad09a424f061cac8f313','source_archive_sha256':'61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a','scope':'Immutable own successful48 resume boundary and first continued actual device step. Live original17520 years continue untouched. This snapshot contains no terminal annual result.'}
    name='qia-recovery-c-year-boundary-w'
elif mode=='profile-u':
    b=Path('/home/lhwang/work/noahmp-v1');r=b/'recovery-process-profile-u'
    assert (r/'richards-profile-exit.txt').read_text().strip()=='0' and (r/'capacity-profile-exit.txt').read_text().strip()=='0'
    items=[(p,p.relative_to(r).as_posix()) for p in sorted(r.iterdir()) if p.is_file()]
    items.append((b/Path(__file__).name,'control/'+Path(__file__).name))
    refs={'py_spy_binary_sha256':sha(b/'profile-tools-u/bin/py-spy'),'scope':'Read-only py-spy0.4.1 single nonblocking Python stack snapshots, no locals, no model stop/restart or shared environment changes. Native+nonblocking incompatibility is a profiler error, not model failure. Single snapshot cannot classify entire model runtime.'}
    name='recovery-process-profile-u'
else:raise ValueError(mode)
a=b/(name+'-evidence.tar.gz');assert not a.exists();meta=b/(name+'-archive-record.json');assert not meta.exists()
refs.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),artifact_sha256={n:sha(p) for p,n in items})
meta.write_text(json.dumps(refs,indent=2)+'\n')
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
    tf.add(meta,arcname='archive-record.json',recursive=False)
assert all(sha(p)==refs['artifact_sha256'][n] for p,n in items)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

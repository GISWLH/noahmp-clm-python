"""Explicit first-execution inputs; not a matched-soil/scientific reference."""
from pathlib import Path
from datetime import datetime,timedelta
import calendar,hashlib,json,math,sys,tarfile
import numpy as np
from netCDF4 import Dataset
b=Path('/home/zhangyq/noahmp-v1');cwd=Path.cwd();r=b/'ctsm-qia-point-inputs-a';out=cwd/'derived';out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config_path=b/'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json';config=json.loads(config_path.read_text());lat,lon=config['latitude'],config['longitude'];geometry=config['canopy_structure'];pft=1
protocol=json.loads((b/'qia-stem-inputs-a/protocol.json').read_text());assert sha(config_path)==protocol['inputs_sha256'][config_path.name]
source=b/'ctsm-global-surface-a/surfdata_1.9x2.5_hist_16pfts_Irrig_CMIP6_simyr2000_c190304.nc';assert sha(source)=='276a7e886ba8c0b35233d644e300c74a7c15cdd1d3c409334b6297a001c49fde'
half_lat=.005;half_lon=half_lat/math.cos(math.radians(lat));south,north=lat-half_lat,lat+half_lat;west,east=lon-half_lon,lon+half_lon
area=math.radians(east-west)*(math.sin(math.radians(north))-math.sin(math.radians(south)));area_km2=area*6371220.**2/1e6;assert area>0
def clone_variable(parent,v,dimensions=None):
 attrs={k:v.getncattr(k) for k in v.ncattrs()};fill=attrs.pop('_FillValue',None);kw={} if fill is None else dict(fill_value=fill)
 w=parent.createVariable(v.name,v.dtype,v.dimensions if dimensions is None else dimensions,**kw);w.setncatts(attrs);return w
surface=out/'surfdata.CN-Qia.engineering.nc';raw_soil={}
with Dataset(source) as d,Dataset(surface,'w',format='NETCDF3_64BIT_OFFSET') as target:
 y=np.asarray(d['LATIXY'][:],float);x=np.asarray(d['LONGXY'][:],float);assert y.shape==x.shape==(96,144)
 distance=np.sin(np.deg2rad((y-lat)/2))**2+np.cos(np.deg2rad(y))*math.cos(math.radians(lat))*np.sin(np.deg2rad((x-lon)/2))**2
 iy,ix=np.unravel_index(distance.argmin(),distance.shape);ydim,xdim=d['LATIXY'].dimensions
 for name,dim in d.dimensions.items():target.createDimension(name,1 if name in (ydim,xdim) else len(dim))
 target.setncatts({k:d.getncattr(k) for k in d.ncattrs()});target.derived_scope='Nearest original grid cell soil/static fields; explicit pure-PFT1/site crown and constant initial LAI/SAI for first official execution. Soil and initial-state matching not certified.';target.source_sha256=sha(source)
 for name,v in d.variables.items():
  index=tuple(slice(iy,iy+1) if dim==ydim else slice(ix,ix+1) if dim==xdim else slice(None) for dim in v.dimensions);w=clone_variable(target,v);w[...]=v[index] if v.dimensions else v[...]
 for name,value in [('LATIXY',lat),('LONGXY',lon),('AREA',area_km2),('LANDFRAC_PFT',1.),('PFTDATA_MASK',1),('PCT_NATVEG',100.)]:target[name][:]=value
 for name in ['PCT_CROP','PCT_LAKE','PCT_WETLAND','PCT_GLACIER','PCT_URBAN']:target[name][:]=0.
 assert target['PCT_NAT_PFT'].dimensions==('natpft',ydim,xdim) and len(target.dimensions['natpft'])==15
 target['PCT_NAT_PFT'][:]=0.;target['PCT_NAT_PFT'][pft,:,:]=100.
 plant=config['biogeochemistry'];lai=plant['plant_state']['carbon'][0]*plant['plant_parameters']['specific_leaf_area']/config['column']['fveg'];assert abs(lai-config['column']['lai'])<1e-12
 for name,value in [('MONTHLY_LAI',lai),('MONTHLY_SAI',geometry['initial_sai']),('MONTHLY_HEIGHT_TOP',geometry['parameters']['canopy_top_m']),('MONTHLY_HEIGHT_BOT',geometry['parameters']['canopy_bottom_m'])]:
  assert target[name].dimensions==('time','lsmpft',ydim,xdim);target[name][:,pft,:,:]=value
 for name in ['PCT_SAND','PCT_CLAY','ORGANIC','zbedrock','SOIL_COLOR']:raw_soil[name]=np.ma.asarray(target[name][:]).tolist()
 nearest=dict(latitude=float(y[iy,ix]),longitude=float(x[iy,ix]),index=[int(iy),int(ix)])
domain=out/'domain.lnd.CN-Qia.nc'
with Dataset(domain,'w',format='NETCDF3_64BIT_OFFSET') as d:
 for name,n in [('ni',1),('nj',1),('nv',4)]:d.createDimension(name,n)
 for name,value,unit in [('xc',lon,'degrees_east'),('yc',lat,'degrees_north'),('frac',1.,'unitless'),('area',area,'radians2')]:v=d.createVariable(name,'f8',('nj','ni'));v.units=unit;v[:]=value
 v=d.createVariable('mask','i4',('nj','ni'));v[:]=1
 for name,values,unit in [('xv',[west,east,east,west],'degrees_east'),('yv',[south,south,north,north],'degrees_north')]:v=d.createVariable(name,'f8',('nj','ni','nv'));v.units=unit;v[:]=np.asarray(values).reshape(1,1,4)
 d.scope='Declared unit-column spherical cell; geometric area, not an observed tower footprint. Fully land, one independent column.'
def coordinates(d):
 for name,value,unit in [('lat',lat,'degrees_north'),('lon',lon,'degrees_east')]:d.createDimension(name,1);v=d.createVariable(name,'f8',(name,));v.units=unit;v[:]=value
 v=d.createVariable('area','f8',('lat','lon'));v.units='radians2';v[:]=area;d.createVariable('mask','i4',('lat','lon'))[:]=1
with tarfile.open(b/'ctsm-qia-meteorology-a/meteorology-private.tar.gz') as t:
 member=t.getmember('CN-Qia.datm.2003.nc');t.extract(member,cwd,filter='data')
old_met=cwd/'CN-Qia.datm.2003.nc';assert sha(old_met)=='34ed3f0128820575e78a5faa2ed8373912d9bbd6ceae23dd555db8b7df9a8f74';met=out/'CN-Qia.datm.2003.nc'
with Dataset(old_met) as d,Dataset(met,'w',format='NETCDF3_64BIT_OFFSET') as target:
 for name,dim in d.dimensions.items():target.createDimension(name,None if dim.isunlimited() else len(dim))
 target.setncatts({k:d.getncattr(k) for k in d.ncattrs()})
 for v in d.variables.values():clone_variable(target,v)[...]=v[...]
 target.createVariable('area','f8',('lat','lon'))[:]=area;target['area'].units='radians2';target.createVariable('mask','i4',('lat','lon'))[:]=1
 target.derived_scope='Original meteorology/CO2 auxiliary/time values unchanged; area/mask added for complete single-point stream domain. Actual DATM alignment still unvalidated.'
with Dataset(old_met) as d,Dataset(met) as target:
 for name in d.variables:np.testing.assert_array_equal(d[name][:],target[name][:])
 met_first=np.asarray(d['time_bounds'][0]);met_last=np.asarray(d['time_bounds'][-1]);met_units=d['time'].units
aero_source=b/'ctsm-aero-reuse-b/aerosoldep_monthly_2000_mean_1.9x2.5_c090421.nc';assert sha(aero_source)=='2e920f2558685c790e904185bd3a9150435f31e3dca2d2ebb1aa1f6b60ae61ff';contract=json.loads((b/'ctsm-aero-reuse-b/contract.json').read_text());mapping=contract['mapping'];assert len(mapping)==14;monthly={}
with Dataset(aero_source) as d:
 ys=np.asarray(d['lat'][:],float);xs=np.asarray(d['lon'][:],float);iy=int(np.searchsorted(ys,lat)-1);ix=int(np.searchsorted(xs,lon)-1);assert 0<=iy<len(ys)-1 and 0<=ix<len(xs)-1
 fy=(lat-ys[iy])/(ys[iy+1]-ys[iy]);fx=(lon-xs[ix])/(xs[ix+1]-xs[ix]);weights=[(1-fy)*(1-fx),(1-fy)*fx,fy*(1-fx),fy*fx]
 for name,_ in mapping:
  v=d[name];assert v.dimensions==('time','lat','lon') and str(v.units).strip()=='kg/m2/s';monthly[name]=sum(w*np.asarray(v[:,y,x],float) for (y,x),w in zip([(iy,ix),(iy,ix+1),(iy+1,ix),(iy+1,ix+1)],weights));assert monthly[name].shape==(12,) and np.all(monthly[name]>=0)
five=np.column_stack((monthly['BCDEPWET']+monthly['BCPHODRY']+monthly['BCPHIDRY'],*[monthly[f'DSTX{k:02}WD']+monthly[f'DSTX{k:02}DD'] for k in range(1,5)]));expected=np.asarray(config['aerosol_deposition_monthly_kg_m2_s']);np.testing.assert_allclose(five,expected,rtol=64*np.finfo(float).eps,atol=0.)
month_pairs=[(2002,12),*[(2003,k) for k in range(1,13)],(2004,1)];offset=timedelta(hours=config['utc_offset_hours']);centers=[datetime(y,m,1)+timedelta(days=calendar.monthrange(y,m)[1]/2)-offset for y,m in month_pairs];epoch=datetime(2002,1,1);times=np.asarray([(x-epoch).total_seconds()/3600 for x in centers]);aero=out/'CN-Qia.aero.2002-2004.nc'
with Dataset(aero,'w',format='NETCDF3_64BIT_OFFSET') as d:
 coordinates(d);d.createDimension('time',None);v=d.createVariable('time','f8',('time',));v.units='hours since 2002-01-01 00:00:00';v.calendar='noleap';v[:]=times
 for name,_ in mapping:
  values=monthly[name];data=np.r_[values[-1],values,values[0]];v=d.createVariable(name,'f8',('time','lat','lon'));v.units='kg/m2/s';v[:]=data[:,None,None] if not name.startswith('OC') else 0.
 d.source_sha256=sha(aero_source);d.time_rule='Cyclic original monthly climatology placed at actual local month centers then UTC shifted; explicit Dec2002/Jan2004 bracket, no year1/date2000 ambiguity.';d.oc_rule='OC fields explicitly zero for the common five-species BC/dust reference experiment; original OC values retained in provenance, never folded into BC.'
schedule_archive=b/'p6-stem-assessment-b-source.tar.gz';assert sha(schedule_archive)=='8a378a471cd163958ca01cb9184343e79624af5f05e427b9397eaffd17cb2ca0'
with tarfile.open(schedule_archive) as t:
 member=t.getmember('benchmarks/fluxnet_deposition.py');raw=t.extractfile(member).read();(cwd/'fluxnet_deposition.py').write_bytes(raw)
sys.path.insert(0,str(cwd))
from fluxnet_deposition import DepositionSchedule
schedule=DepositionSchedule(config);largest=np.zeros(5)
with np.load(b/'qia-stem-inputs-a/inputs/CN-Qia.npz',allow_pickle=False) as z:
 for start,forcing in zip(z['time_start'],z['forcing']):
  local=datetime.strptime(str(start),'%Y%m%d%H%M');mid=local+timedelta(seconds=float(forcing[0])/2)-offset;query=(mid-epoch).total_seconds()/3600
  actual=np.asarray([np.interp(query,times,np.r_[v[-1],v,v[0]]) for v in five.T]);reference=schedule.aerosol(local,forcing[0]);largest=np.maximum(largest,abs(actual-reference));np.testing.assert_allclose(actual,reference,rtol=128*np.finfo(float).eps,atol=0.)
topo_input=cwd/'inputdata/atm/datm7/topo_forcing/topodata_0.9x1.25_USGS_070110_stream_c151201.nc'
with Dataset(topo_input) as d:
 y,x=np.asarray(d['LATIXY'][:],float),np.asarray(d['LONGXY'][:],float);distance=np.sin(np.deg2rad((y-lat)/2))**2+np.cos(np.deg2rad(y))*math.cos(math.radians(lat))*np.sin(np.deg2rad((x-lon)/2))**2;index=np.unravel_index(distance.argmin(),distance.shape);topo_value=float(d['TOPO'][index]);assert np.isfinite(topo_value)
with Dataset(out/'CN-Qia.topo.nc','w',format='NETCDF3_64BIT_OFFSET') as d:coordinates(d);d.createVariable('TOPO','f8',('lat','lon'))[:]=topo_value;d['TOPO'].units='m'
for source,dest in [(cwd/'inputdata/lnd/clm2/paramdata/clm5_params.c171117.nc',out/'clm5_params.c171117.nc'),(cwd/'inputdata/lnd/clm2/snicardata/snicar_drdt_bst_fit_60_c070416.nc',out/'snicar_drdt_bst_fit_60_c070416.nc'),(cwd/'inputdata/lnd/clm2/snicardata/snicar_optics_5bnd_c090915.nc',out/'snicar_optics_5bnd_c090915.nc'),(cwd/'inputdata/atm/cam/chem/trop_mozart/emis/megan21_emis_factors_78pft_c20161108.nc',out/'megan21_emis_factors_78pft_c20161108.nc')]:dest.write_bytes(source.read_bytes())
with Dataset(surface) as d:
 assert d['PCT_NATVEG'][0,0]==100 and d['PCT_NAT_PFT'][:,0,0].sum()==100 and d['PCT_NAT_PFT'][1,0,0]==100
 for name in ['PCT_SAND','PCT_CLAY','ORGANIC']:assert np.isfinite(d[name][:]).all()
record=dict(scope=__doc__,source_configuration_sha256=sha(config_path),surface_source_sha256='276a7e886ba8c0b35233d644e300c74a7c15cdd1d3c409334b6297a001c49fde',surface_nearest_cell=nearest,raw_nearest_soil=raw_soil,domain_area_radians2=area,domain_area_km2=area_km2,geometry=geometry,prescribed_lai=lai,aerosol_source_sha256=sha(aero_source),original_oc_monthly={n:monthly[n].tolist() for n in monthly if n.startswith('OC')},maximum_all17520_aerosol_schedule_difference_kgm2s=largest.tolist(),aerosol_time_first_last_utc=[centers[0].isoformat(),centers[-1].isoformat()],met_original_fields_roundtrip_max_absolute=0.,met_time_units=met_units,met_first_bounds=met_first.tolist(),met_last_bounds=met_last.tolist(),topography_m=topo_value,files={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in out.iterdir()},pending=['Actual official DATM interval-alignment run','Explicit CO2 stream or disclosed short-run constant','Matched vertical soil/hydraulics/initial stores and SP/BGC canopy conventions','Actual official model output and scientific pair evaluation'])
(r/'derivation.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
with tarfile.open(r/'derived-inputs.tar.gz','w:gz') as t:
 for p in sorted(out.iterdir()):t.add(p,arcname=p.name,recursive=False)
print(json.dumps(dict(files=len(record['files']),nearest=nearest,area_km2=area_km2,aerosol_schedule_maximum=largest.tolist(),archive_sha256=sha(r/'derived-inputs.tar.gz'))))

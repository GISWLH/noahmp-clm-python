from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-point-inputs-b';scratch=Path(os.environ['TMPDIR'])/'point-inputs';scratch.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
for a,digest,dest in [(b/'ctsm-portable-env-b.tar.gz','6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20',scratch/'environment'),(b/'ctsm-static-inputs-a.tar.gz','c821ed102415bddacf0fd55f7cce4e914d57ca8d02e1284437d70bc3b4ee221d',scratch)]:
 assert sha(a)==digest;dest.mkdir(exist_ok=True)
 with tarfile.open(a) as t:t.extractall(dest,filter='data')
prefix=scratch/'environment';env=os.environ.copy()
for key in ['PYTHONPATH','PYTHONHOME','LD_LIBRARY_PATH']:env.pop(key,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');stages=[]
for name,command in [('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]),('derive-point',[str(prefix/'bin/python'),str(r/'derive_ctsm_qia_point_inputs_b.py')])]:
 with (r/(name+'.log')).open('x') as log:code=subprocess.run(command,cwd=scratch,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 stages.append(dict(stage=name,returncode=code));assert code==0,name
(r/'receipt.json').write_text(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,seconds=time.monotonic()-start,archive_sha256=sha(r/'derived-inputs.tar.gz'),derivation_sha256=sha(r/'derivation.json')),indent=2)+'\n')

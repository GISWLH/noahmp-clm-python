from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as ET
b=Path('/home/zhangyq/noahmp-v1');a=b/'ctsm-qia-point-inputs-a';r=b/'ctsm-qia-point-inputs-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert (a/'pbs-exit.txt').read_text().strip()=='1' and (r/'pbs-exit.txt').read_text().strip()=='0' and all(v['returncode']==0 for v in d['stages']);assert sha(r/'derived-inputs.tar.gz')==d['archive_sha256'] and sha(r/'derivation.json')==d['derivation_sha256']
contract=json.loads((b/'ctsm-qia-run-contract-a/contract.json').read_text());clean=dict(scope='Pinned upstream public input option metadata only, not copied physical implementation or a model output.',source_bundle_sha256=contract['source_bundle_sha256'],entries=[dict(source=x['source'],source_sha256=x['source_sha256'],id=x['id'],attributes=ET.fromstring(x['xml']).attrib) for x in contract['entries']],datm_relevant=[x for x in contract['datm_co2_and_time_metadata'] if x['id']=='strm_datvar' and x['attrs'].get('stream')=='co2tseries.20tr' or x['id']=='tintalgo' and x['attrs'].get('stream')=='CLM1PT.CLM_USRDAT'],history_names_found=contract['history_names_found'],literal_history_names_not_located=contract['history_names_not_found']);(r/'runtime-contract-curated.json').write_text(json.dumps(clean,indent=2)+'\n');archive=b/'ctsm-qia-point-inputs-ab-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for folder in [a,r]:
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.name!='derived-inputs.tar.gz':t.add(p,arcname=folder.name+'/'+p.name,recursive=False)
 t.add(b/'inspect_ctsm_runtime_contract_a.py',arcname='control/inspect_ctsm_runtime_contract_a.py',recursive=False);t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,derived_archive_sha256=d['archive_sha256'])))

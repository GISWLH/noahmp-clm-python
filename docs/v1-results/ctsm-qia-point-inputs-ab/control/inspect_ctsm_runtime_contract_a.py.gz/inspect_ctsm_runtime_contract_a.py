from pathlib import Path
import hashlib,json,re,tarfile,xml.etree.ElementTree as ET
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-run-contract-a';r.mkdir();a=b/'ctsm-reference-source-bundle-a.tar.gz';sha=lambda v:hashlib.sha256(v).hexdigest();assert sha(a.read_bytes())=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
ids={'stomatalcond_method','use_luna','use_hydrstress','nlevsno','soil_layerstruct','finidat','co2_type','co2_ppmv','hist_fincl1','hist_nhtfrq','hist_mfilt','stream_fldfilename_urbantv','use_bedrock','urban_hac','snowveg_flag','irrigate','create_crop_landunit','RUN_STARTDATE','START_TOD','ATM_NCPL','DATM_MODE','DATM_PRESAERO','CLM_USRDAT_NAME','DATM_CLMNCEP_YR_START','DATM_CLMNCEP_YR_END','DATM_CLMNCEP_YR_ALIGN'};rows=[];datm=[];history=set();wanted={'TBOT','QBOT','WIND','PSRF','FSDS','FLDS','RAIN','SNOW','ZBOT','H2OSNO','TSOI','H2OSOI','GPP','NEE','FCEV','FCTR','FGEV','FSH','EFLX_LH_TOT','QOVER','QDRAI','TLAI','TSAI','ELAI','FGR','FSA','FIRA','TG'}
with tarfile.open(a) as t:
 for m in t:
  if not m.isfile():continue
  if m.name.endswith('.xml') and any(k in m.name for k in ['namelist_definition','config_component','config_archive']):
   raw=t.extractfile(m).read()
   try:tree=ET.fromstring(raw)
   except ET.ParseError:continue
   for e in tree.iter('entry'):
    if e.get('id') in ids:rows.append(dict(source=m.name,source_sha256=sha(raw),id=e.get('id'),xml=ET.tostring(e,encoding='unicode')))
    if 'datm' in m.name.lower():
     for v in e.iter('value'):
      if 'co2' in (v.get('stream','')+' '+(v.text or '')).lower() or (e.get('id') in ['tintalgo','strm_tintalgo']):datm.append(dict(source=m.name,id=e.get('id'),attrs=v.attrib,text=(v.text or '').strip()))
  if m.name.startswith('CTSM/src/') and m.name.endswith('.F90'):
   text=t.extractfile(m).read().decode(errors='replace');history.update(x for x in re.findall(r"fname\s*=\s*['\"]([A-Za-z0-9_]+)['\"]",text,re.I) if x in wanted)
record=dict(scope='Read-only pinned input option/forcing field/history-name metadata, not copied physical implementation or an actual model execution.',source_bundle_sha256=sha(a.read_bytes()),entries=rows,datm_co2_and_time_metadata=datm,history_names_found=sorted(history),history_names_not_found=sorted(wanted-history));(r/'contract.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(entries=[dict(source=x['source'],id=x['id'],xml=x['xml']) for x in rows if x['id'] in ['stomatalcond_method','soil_layerstruct','co2_type','nlevsno','stream_fldfilename_urbantv']],datm=datm,history_found=sorted(history),history_missing=sorted(wanted-history))))

"""Read only the selected non-personal site and variable groups from original BIF."""
import argparse,gzip,hashlib,json,zipfile
from pathlib import Path
import openpyxl
p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
x=a.directory/'FLX_AA-Flx_BIF_HH_20200501.xlsx';z=a.directory/'FLX_AA-Flx_BIF_ALL_20200501.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(z) as f: assert f.read(x.name)==x.read_bytes()
sites=('CN-Cng','CN-Qia','CN-Cha');groups={};base={'LOCATION_LAT','LOCATION_LONG','IGBP','UTC_OFFSET','HEIGHTC','HEIGHTC_DATE'}
for sheet in openpyxl.load_workbook(x,read_only=True,data_only=True):
 rows=sheet.iter_rows(values_only=True);assert next(rows)==('SITE_ID','GROUP_ID','VARIABLE_GROUP','VARIABLE','DATAVALUE')
 for site,group,kind,var,value in rows:
  if site not in sites:continue
  if kind=='GRP_VAR_INFO' or var in base:
   d=groups.setdefault((site,group),{'variable_group':kind,'values':{}})['values']
   assert var not in d or d[var]==value
   d[var]=value
selected={s:[] for s in sites}
for (site,key),group in groups.items():
 v=group['values'];name=v.get('VAR_INFO_VARNAME','')
 if set(v)&base or name.startswith(('TA','VPD','WS','RH','TS','SWC','H_F_MDS','LE_F_MDS')):
  selected[site].append({'group_id':key,**group})
missing={site:[name for name in ('TA_F','VPD_F','WS_F') if all(g['values'].get('VAR_INFO_VARNAME')!=name or 'VAR_INFO_HEIGHT' not in g['values'] for g in rows)] for site,rows in selected.items()}
report={'scope':'Unmodified FLUXNET2015 BIF values read from a third-party research archive copy; do not infer forcing heights from flux heights',
 'retrieved_utc':'2026-10-16','source_url':'https://zenodo.org/records/22036640',
 'archive_name':'lad_forcing_data.tar','archive_bytes':519178240,'archive_md5':'3e805369789769f22eee8619921654f3',
 'archive_md5_verified_on_download':True,'original_metadata_bundle_sha256':sha(z.read_bytes()),
 'hh_filename':x.name,'hh_bytes':x.stat().st_size,'hh_sha256':sha(x.read_bytes()),
 'hh_equals_metadata_bundle_member':True,'direct_upstream_checksum_verified':False,
 'upstream_download_status':'Official historical-download page HTTP403; metadata copy origin not independently certified by an upstream checksum.',
 'bif_definition':'https://doi.org/10.1038/s41597-020-0534-3',
 'missing_consolidated_forcing_heights':missing,'sites':selected}
a.output.write_bytes(gzip.compress((json.dumps(report,indent=2,ensure_ascii=False)+'\n').encode(),mtime=0))
print(json.dumps({'output':str(a.output),'selected_groups':{s:len(v) for s,v in selected.items()},'missing_heights':missing}))

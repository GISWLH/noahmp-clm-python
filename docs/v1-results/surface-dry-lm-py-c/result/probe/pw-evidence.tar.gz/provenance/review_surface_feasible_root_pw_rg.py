"""Independent static PW review: archive bytes and AST only, never NumPy."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile
import types

BASE = Path(__file__).resolve().parent
PREP = BASE / 'surface-7275-feasible-root-pw-preparation'
EXPECTED = '858566c1b94b1852ed01f38e78e0dfe43456f2eb2efd39b1c81885e363d2441a'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len(members) == len({m.name for m in members})
        return {m.name: archive.extractfile(m).read() for m in members}


def main():
    manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(manifest_raw) == EXPECTED
    manifest = json.loads(manifest_raw)
    assert len(manifest) == 12
    assert {p.relative_to(PREP).as_posix() for p in PREP.rglob('*') if p.is_file()} == set(manifest) | {'CONTROLS_SHA256.json'}
    assert all(sha((PREP / n).read_bytes()) == h for n, h in manifest.items())
    binding = json.loads((PREP / 'BINDINGS.json').read_bytes())
    pu_raw = (BASE / 'surface-7275-frame-trace-pu-evidence.tar.gz').read_bytes()
    assert sha(pu_raw) == binding['PU_archive_sha256']
    pu = unpack(pu_raw)
    index = json.loads(pu['artifact-inventory.json'])
    assert len(pu) == 100 and set(index) == set(pu) - {'artifact-inventory.json'}
    assert all(sha(pu[n]) == r['sha256'] and len(pu[n]) == r['bytes'] for n, r in index.items())
    for name, h in binding['PU_reused_files'].items():
        assert sha(pu['result/model/controls/' + name]) == h
        assert pu['result/model/controls/' + name] == (PREP / 'pu' / name).read_bytes()
    source_raw = (BASE / 'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    assert sha(source_raw) == binding['source_archive_sha256']
    source = unpack(source_raw)
    source_manifest = json.loads(source['SOURCE_SHA256.json'])
    assert sha(source['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
    assert len(source_manifest) == 584 and set(source) == set(source_manifest) | {'SOURCE_SHA256.json'}
    assert all(sha(source[n]) == h for n, h in source_manifest.items())
    phase = source[binding['phase_source_relative_path']]
    assert sha(phase) == binding['phase_source_sha256']
    module_code = compile(phase, binding['phase_source_relative_path'], 'exec')
    solve_code = next(c for c in module_code.co_consts if isinstance(c, types.CodeType) and c.co_name == 'solve_canopy_phase_energy')
    evaluate_code = next(c for c in solve_code.co_consts if isinstance(c, types.CodeType) and c.co_name == 'evaluate')
    assert evaluate_code.co_firstlineno == 134 and len(evaluate_code.co_freevars) == 37
    phase_tree = ast.parse(phase)
    evaluate_tree = next(n for n in ast.walk(phase_tree) if isinstance(n, ast.FunctionDef) and n.name == 'evaluate')
    assert not any(isinstance(n, (ast.Global, ast.Nonlocal)) for n in ast.walk(evaluate_tree))
    assigns = [n for n in ast.walk(evaluate_tree) if isinstance(n, (ast.Assign, ast.AnnAssign, ast.AugAssign))]
    assigned_names = set()
    for node in assigns:
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        for target in targets:
            assigned_names.update(n.id for n in ast.walk(target) if isinstance(n, ast.Name))
    assert not assigned_names.intersection(evaluate_code.co_freevars)
    trees = {}
    for name in ('probe_feasible_root_pw.py', 'diagnose_live_closure_pw.py'):
        trees[name] = ast.parse((PREP / name).read_bytes())
        assert not any(isinstance(n, ast.Call) and ast.unparse(n.func) in ('sys.settrace', 'np.linalg.lstsq', 'numpy.linalg.lstsq') for n in ast.walk(trees[name]))
    wrapper = trees['probe_feasible_root_pw.py']
    core = trees['diagnose_live_closure_pw.py']
    assert sum(isinstance(n, ast.Call) and ast.unparse(n.func) == 'pu.main' for n in ast.walk(wrapper)) == 1
    assert sum(isinstance(n, ast.Call) and ast.unparse(n.func) == 'evaluate' for n in ast.walk(core)) == 1
    assert sum(isinstance(n, ast.Call) and ast.unparse(n.func) == 'least_squares' for n in ast.walk(core)) == 1
    assert any(isinstance(n, ast.Raise) and n.exc is None for n in ast.walk(wrapper))
    policy = json.loads((PREP / 'POLICY.json').read_bytes())
    assert policy['starts'] == ['stalled_x', 'stored_ambient']
    assert policy['maximum_actual_evaluate_calls_per_start'] == 6000 and policy['seconds_per_start'] == 45
    assert policy['max_nfev'] == 200 and policy['maximum_total_additional_evaluate_calls'] == 12000
    assert policy['original_solver_tolerance'] == 1e-7 and policy['original_physical11_tolerance_multiplier'] == 1.01
    report = dict(passed=True, blocking_findings=[], nonblocking_findings=[], controls_manifest_sha256=EXPECTED,
        controls=12, exact_reused_PU_dependencies=7, source_files=584,
        source_manifest_sha256=binding['source_manifest_sha256'],
        phase_source_sha256=sha(phase), original_evaluate_freevars=list(evaluate_code.co_freevars),
        checks=['All 12 frozen controls and seven executed PU dependencies match original bytes.',
                'Original NM584 source and original evaluate source are unchanged; new files are not imported or executed by this review.',
                'One original PU.main call, live traceback closure only, copied two predeclared seeds and original bounds.',
                'Actual evaluate start/return counters include finite differences and final details; each seed has 6000-call and pre-call 45-second caps.',
                'Original 12-equation tolerance 1e-7 and final physical11 tolerance 1.01e-7 are retained; SciPy status alone cannot certify a root.',
                'Source, encoded15 inputs, original model packet, closure, controls and bound archives receive independent post-diagnostic verification.',
                'Original RuntimeError is re-raised on successful diagnostics or diagnostic/write failure; no model repair, continuation, timestep or GPU credit.'],
        limitations=['Static review only: no numerical, SciPy or native scientific import; no job submission.',
                     'The 45-second cap is checked before evaluations; an already-started call or algebra may overrun. The planned PBS hard cap is separate.',
                     'Feasibility uses only the frozen original active mask. No root-cause or scientific model acceptance follows.',
                     'Stored branch matrices and deltas may have different ages; their algebra is explicitly diagnostic, not chronology evidence.',
                     'No execution wrapper or PBS terminal result exists in this reviewed preparation.'],
        local_numerical_executed=False, model_calls=0, gpu_calls=0,
        reviewed_files=manifest, verifier_sha256=sha(Path(__file__).read_bytes()))
    target = BASE / 'surface-7275-feasible-root-pw-independent-review-rg.json'
    target.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(passed=True, controls=12, source_files=584, review_sha256=sha(target.read_bytes()))))


if __name__ == '__main__':
    main()

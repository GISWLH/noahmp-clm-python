# PW1700 actual failure and separate feasible-root diagnosis

PBS F1 / Stageout0, worker1, diagnostic0. The unchanged Qia surface attempt still raises its original iteration30 residual13.75804 exception. The original failure is not normalized to success. It made one original reference attempt with no return or completed physical timestep.

After that failure, the same process retained the original live closure and performed exactly the two declared separate diagnostics. Stalled_x:288 actual extra evaluate calls, maximum original r12 10.769007465341872, physical11 1.7446254742888212: nonroot despite SciPy success. Stored_ambient:301 calls, both maxima9.61564161627848e-13: conditional root within the unchanged original bounds and active mask, under the original 1e-7 and 1.01e-7 gates. Total589 extra physics-function residual evaluations, not column timesteps. No full-column/GPU/year continuation or parameter/initial-state adoption.

All584 source files,15 encoded inputs,605 original model-packet files and live closure are unchanged after diagnosis. Root feasibility does not establish the failure cause or constitute a production repair. Three stored branch matrix/step algebra records may have different ages. Both starts, every returned point/residual, full original detail, exception, policy, actual counts and typed raw arrays are retained. Cost/optimality0d arrays and vector algebra are kept opaque on Windows; existing EHPC JSON scalars alone are reported.

No extra model call, numerical rerun, input adjustment or retry was performed during closure. Expanded source is reconstructable from exact NM bytes within the executed PT input archive; it was excluded from the result tar. The original compressed result and executed stage are preserved unchanged.

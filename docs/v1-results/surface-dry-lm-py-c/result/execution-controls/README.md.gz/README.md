# PY fixed CPU execution controls

One original candidate source584 plus root-reviewed19 preparation controls, exact PR/PT/PW archives; single collect-only then single pytest execution. 1CPU/2GiB/10min compute002. Manager/compute private tmp transfers, hash validation, unique qsub, PBS exit and result retention mechanically reuse PW. New run_validation_py.py adds source/control/input before-after hashing, complete collection/node/phase/XML checks and preserves actual child exits/timeouts. record_pytest_py.py only records collection/reports. Original tests and gates are unchanged. Actual results/collection remain unknown until this one job runs. No Windows numerical execution, GPU job, column timestep, annual or scientific acceptance.

PY-b corrects only the original PY1818 setup assertion: source has584 files plus its manifest, not597 members. Original1818 F1/Stageout0 retained, with no collect or numerical calls. Original candidate source,19 preparation controls, tests, fixture/oracle and all physical gates remain byte exact.

PY-c records real pytest item.path and checks the six new plus42 original nodes by those exact paths, preserving original nodeids, uniqueness and full execution phase/XML coverage. Source,19prep, tests and physical gates remain byte exact;1821 F1/collect0 metadata failure remains preserved.

"""Read and retain the unique PY-c1822 terminal run; no numerical imports."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

BASE = Path(__file__).resolve().parent
OUT = BASE / 'surface-dry-lm-py-c-closure'
sha = lambda b: hashlib.sha256(b).hexdigest()


def run(label, command):
    begin = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=90)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    (OUT / (label + '.json')).write_text(json.dumps(dict(
        actual_exit=result.returncode, seconds=time.monotonic()-begin,
        command=command, stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr)), indent=2)+'\n')
    assert result.returncode == 0, (label, result.stderr.decode(errors='replace'))
    return result.stdout


def main():
    assert not OUT.exists()
    OUT.mkdir()
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12']
    qstat = run('qstat', ssh + ['ehpc', 'qstat -fx 1822.manager']).decode()
    assert all(x in qstat for x in ('Job Id: 1822.manager', 'job_state = F', 'Exit_status = 1', 'Stageout_status = 0'))
    remote = '/tmp/noahmp-surface-dry-lm-py-c'
    expected = run('result-hash', ssh + ['ehpc-c2', 'sha256sum '+remote+'/result.tar.gz']).decode().split()[0]
    result = BASE / 'surface-dry-lm-py-c-result.tar.gz'
    assert not result.exists()
    run('download-result', ['scp', '-O', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12', 'ehpc-c2:'+remote+'/result.tar.gz', str(result)])
    assert sha(result.read_bytes()) == expected
    assert run('pbs-exit', ssh + ['ehpc-c2', 'cat '+remote+'/pbs-exit.txt']).strip() == b'1'
    with tarfile.open(result) as t:
        members = [m for m in t if m.isfile()]
        files = {m.name.removeprefix('./'): t.extractfile(m).read() for m in members}
    assert len(files) == len(members)
    inventory = {n: dict(bytes=len(b), sha256=sha(b)) for n,b in sorted(files.items())}
    (OUT / 'RESULT_INVENTORY.json').write_text(json.dumps(inventory, indent=2)+'\n')
    for name, raw in files.items():
        if name.endswith(('.json','.xml','.stdout','.stderr','.log','.txt')):
            target = OUT / 'readable' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
    print(json.dumps(dict(pbs_job='1822.manager', actual_PBS_exit=1, Stageout_status=0,
        result_sha256=expected, result_bytes=result.stat().st_size, result_files=len(files),
        json_names=[n for n in files if n.endswith('.json')], numerical_imports=0)))


if __name__ == '__main__':
    main()

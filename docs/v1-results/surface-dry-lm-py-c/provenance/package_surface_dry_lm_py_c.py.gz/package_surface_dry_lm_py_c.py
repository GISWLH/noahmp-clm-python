"""Seal actual PY-c1822 one physical failure and 47 passing tests."""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import io
import json
import tarfile
import xml.etree.ElementTree as ET

BASE=Path(__file__).resolve().parent
LABEL='surface-dry-lm-py-c'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()


def scalar_tree(node):
    if node['kind']=='dict':return {k:scalar_tree(v) for k,v in node['items'].items()}
    if node['kind'] in ('list','tuple'):return [scalar_tree(v) for v in node['items']]
    if node['kind']=='float':return float.fromhex(node['hex'])
    if node['kind']=='array':return {k:v for k,v in node.items() if k!='kind'}
    return node.get('value')


def main():
    result=BASE/(LABEL+'-result.tar.gz');raw_result=result.read_bytes()
    assert sha(raw_result)=='c899a551629463dc3f4b159756f762df2f1fd91f23a4527091e24bf27a48b61d'
    with tarfile.open(fileobj=io.BytesIO(raw_result)) as t:
        original={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    assert len(original)==110
    receipt=json.loads(original['probe/receipt.json'])
    assert receipt['pbs_job']=='1822.manager' and not receipt['passed']
    assert receipt['immutable_files']==616 and receipt['immutable_before_after_exact']
    assert receipt['source_members_exact'] and receipt['stage_before_after_exact']
    assert [c['actual_child_returncode'] for c in receipt['actual_children']]==[0,1]
    assert all(not c['timed_out'] for c in receipt['actual_children'])
    assert original['worker-exit.txt'].strip()==original['pbs-command-exit.txt'].strip()==b'1'
    assert original['setup-exit.txt'].strip()==original['stage-after-exit.txt'].strip()==b'0'
    collect=json.loads(original['probe/collect-nodes.json'])
    tests=json.loads(original['probe/tests-nodes.json'])
    expected=json.loads(original['probe/expected-nodes.json'])
    assert len(expected)==48 and len(set(expected))==48
    assert collect['nodes']==tests['nodes']==expected and collect['items']==tests['items']
    assert collect['pytest_exitstatus']==0 and tests['pytest_exitstatus']==1
    assert len(tests['reports'])==144
    for node in expected:
        reports=[r for r in tests['reports'] if r['nodeid']==node]
        assert [r['when'] for r in reports]==['setup','call','teardown']
        assert reports[0]['passed'] and reports[2]['passed']
        assert not any(r['skipped'] for r in reports)
    failures=[r['nodeid'] for r in tests['reports'] if r['failed']]
    assert failures==['::test_actual_pr_surface_and_closed_independent_reference[actual-Qia]']
    paths=Counter(Path(item['path']).name for item in tests['items'])
    assert paths.pop('test_actual_surface_py.py')==6 and sum(paths.values())==42 and len(paths)==5
    suites=ET.fromstring(original['probe/pytest.xml'])
    suite=list(suites)[0]
    assert {k:int(suite.attrib[k]) for k in ('tests','failures','errors','skipped')}==dict(tests=48,failures=1,errors=0,skipped=0)
    assert len(suite.findall('testcase'))==48
    observations=[scalar_tree(json.loads(original[f'probe/actual-row-{k}/actual-observation.json'])['tree']) for k in range(3)]
    qia=observations[0];rescue=qia['rescue_records'][0]
    assert qia['calls']==dict(phase_started=1,phase_returned=0,surface_started=1,surface_returned=0)
    assert not qia['component_checks_passed'] and rescue['reason']=='no_feasible_displacement'
    assert rescue['accepted']==20 and rescue['rejected']==11 and rescue['iterations']==31
    assert rescue['last_iteration']==61 and rescue['maximum_iterations']==80
    assert rescue['evaluate_calls']==rescue['evaluate_returns']==527
    assert rescue['linear_attempts']==31 and rescue['linear_failures']==0 and rescue['trial_evaluations']==22
    for row in observations[1:]:
        assert row['component_checks_passed'] and row['original_PT_full_return_byte_exact'] and row['rescue_calls']==0
    stage=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    assert sha(stage)=='6f902b3a722d68c0414a8631f52614643bf1192e56254eeb1c9903d4a5ac0856'
    with tarfile.open(fileobj=io.BytesIO(stage)) as t:staged={m.name:t.extractfile(m).read() for m in t}
    index=json.loads(staged['stage-inventory.json'])
    assert len(staged)==39 and all(sha(staged[n])==h for n,h in index.items())
    assert json.loads(original['stage-before.json'])['actual']==json.loads(original['stage-after.json'])['actual']==index
    for folder,prefix in [('preparation','probe/preparation'),('execution','probe/execution')]:
        controls=json.loads(staged[folder+'/CONTROLS_SHA256.json'])
        assert all(staged[folder+'/'+n]==original[prefix+'/'+n] and sha(staged[folder+'/'+n])==h for n,h in controls.items())
    readout=dict(pbs_job='1822.manager',job_state='F',PBS_exit=1,Stageout_status=0,run_count=1,
        actual_collect_exit=0,actual_test_exit=1,actual_worker_exit=1,collected=48,passed=47,failed=1,errors=0,skipped=0,
        original_tests_passed=42,new_tests_passed=5,new_tests_failed=1,complete_setup_call_teardown_records=144,
        collection_and_actual_items_exact=True,XML_counts_independently_verified=True,
        source_stage_and_616_immutable_files_before_after_exact=True,result_sha256=sha(raw_result),result_files=len(original),
        original_Newton_stalled_iteration=30,original_Newton_residual_Wm2=13.75804,
        Qia_rescue_record=rescue,Qia_LM_final_residual=None,
        Qia_LM_final_residual_scope='Not recorded by original helper; original13.75804 residual is not its final residual.',
        unchanged_successful_surface_observations=observations[1:],
        candidate_status='Private NumPy LM candidate failed actual Qia; no promotion or device synchronization credit.',
        diagnostic_inference='No feasible common displacement occurred after20 accepted and11 rejected LM attempts. Existing records do not distinguish a zero bound-limited alpha from floating-point no-movement; no full cause claimed.',
        numerical_replays=0,GPU_calls=0,completed_column_time_steps=0,annual_or_scientific_acceptance=False)
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={'original-result.tar.gz':raw_result,'executed-stage.tar.gz':stage,'readout.json':encode(readout),
        'SCOPE.md':b'Actual unique EHPC1822 F1/Stageout0:48 collected,47 passed,1 actual-Qia physical failure,zero errors/skips. Complete144 setup/call/teardown and XML independently checked. LM stopped no_feasible_displacement at total61/80 after20 accepted/11 rejected attempts. Final LM residual was not recorded. Cha/HaM original complete surface returns byte exact;42 prior tests pass. No retry, GPU, full column timestep, annual, promotion or scientific credit.\n'}
    items.update({'result/'+n:b for n,b in original.items()})
    for folder in ('surface-dry-lm-py-c-deployment','surface-dry-lm-py-c-closure'):
        items.update({folder+'/'+p.relative_to(BASE/folder).as_posix():p.read_bytes() for p in (BASE/folder).rglob('*') if p.is_file() and 'readable' not in p.relative_to(BASE/folder).parts})
    for name in ('collect_surface_dry_lm_py_c_closed.py',Path(__file__).name):items['provenance/'+name]=(BASE/name).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope=readout['candidate_status']+' Unique1822 F1/Stageout0,47/48pass,144phase records/XML/source identities verified. Actual complete raw output and failed-Qia LM counters retained; no retry or promotion.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

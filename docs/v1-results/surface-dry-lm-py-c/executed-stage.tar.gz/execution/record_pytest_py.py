"""Record exact collection and setup/call/teardown without altering a test."""
from pathlib import Path
import json
import os

REPORTS=[]


def pytest_runtest_logreport(report):
    REPORTS.append(dict(nodeid=report.nodeid,when=report.when,passed=report.passed,
                        failed=report.failed,skipped=report.skipped))


def pytest_sessionfinish(session,exitstatus):
    Path(os.environ['PY_PYTEST_RECORD']).write_text(json.dumps(dict(
        nodes=[item.nodeid for item in session.items],
        items=[dict(nodeid=item.nodeid,path=str(item.path.resolve())) for item in session.items],reports=REPORTS,
        pytest_exitstatus=int(exitstatus)),indent=2)+'\n')

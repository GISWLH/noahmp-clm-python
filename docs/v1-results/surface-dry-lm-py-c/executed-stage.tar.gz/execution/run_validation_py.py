"""One collect then one fixed CPU validation; all original failures retained."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

STAGE=Path('/tmp/noahmp-surface-dry-lm-py-c')
sha=lambda b:hashlib.sha256(b).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def main():
    assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=Path(sys.argv[1]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    started=time.monotonic();immutable={};index={};record=dict(passed=False,pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),
        actual_children=[],GPU_calls=0,completed_column_time_steps=0,scientific_annual_acceptance=False)
    try:
        index=json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/n).read_bytes())==h for n,h in index.items())
        save(root/'stage-index.json',index)
        for folder in ('preparation','execution'):
            shutil.copytree(STAGE/folder,root/folder)
            controls=json.loads((root/folder/'CONTROLS_SHA256.json').read_bytes())
            assert all(sha((root/folder/n).read_bytes())==h for n,h in controls.items())
            immutable.update({folder+'/'+n:h for n,h in controls.items()})
            immutable[folder+'/CONTROLS_SHA256.json']=sha((root/folder/'CONTROLS_SHA256.json').read_bytes())
        binding=json.loads((root/'preparation/BINDINGS.json').read_bytes())
        assert sha((STAGE/'source.tar.gz').read_bytes())==binding['candidate_source_archive_sha256']
        with tarfile.open(STAGE/'source.tar.gz') as archive:
            members=archive.getmembers()
            assert len(members)==binding['candidate_source_files']+1 and len({m.name for m in members})==binding['candidate_source_files']+1
            assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
            for member in members:
                path=root/'source'/member.name;path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(archive.extractfile(member).read())
        source_manifest=(root/'source/SOURCE_SHA256.json').read_bytes()
        assert sha(source_manifest)==binding['candidate_source_manifest_sha256']
        source_index=json.loads(source_manifest);assert len(source_index)==584
        immutable.update({'source/'+n:h for n,h in source_index.items()})
        immutable['source/SOURCE_SHA256.json']=sha(source_manifest)
        for name,key in [('pr-evidence.tar.gz','PR_archive_sha256'),('pt-evidence.tar.gz','PT_archive_sha256'),('pw-evidence.tar.gz','PW_archive_sha256')]:
            assert sha((STAGE/name).read_bytes())==binding[key]
            shutil.copyfile(STAGE/name,root/name);immutable[name]=binding[key]
        assert all(sha((root/n).read_bytes())==h for n,h in immutable.items())
        save(root/'immutable-before.json',immutable)
        plan=json.loads((root/'preparation/VALIDATION_PLAN.json').read_bytes())
        tests=[str(root/'preparation'/plan['new_test_file']),*[str(root/'source'/n) for n in plan['original_test_files']]]
        env=os.environ.copy()
        env.update(PY_RESULT=str(root),PY_PT=str(root/'pt-evidence.tar.gz'),PY_PW=str(root/'pw-evidence.tar.gz'),
            PYTHONPATH=os.pathsep.join([str(root/'preparation'),str(root/'preparation/pt'),str(root/'execution'),str(root/'source/src'),str(root/'source/tests'),'/home/zhangyq/noahmp-v1/test-deps']))
        common=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','-p','record_pytest_py']
        for mode,extra,limit in [('collect',['--collect-only'],60),('tests',['--junitxml='+str(root/'pytest.xml')],480)]:
            env['PY_PYTEST_RECORD']=str(root/(mode+'-nodes.json'))
            command=common+extra+tests;entry=dict(mode=mode,command=command,timeout_seconds=limit,
                actual_child_returncode=None,timed_out=False)
            begin=time.monotonic()
            with (root/(mode+'.stdout')).open('wb') as out,(root/(mode+'.stderr')).open('wb') as err:
                try:
                    child=subprocess.run(command,cwd=root/'source',env=env,stdout=out,stderr=err,timeout=limit)
                    entry['actual_child_returncode']=child.returncode
                except subprocess.TimeoutExpired:
                    entry['timed_out']=True;entry['exception']=traceback.format_exc()
            entry['seconds']=time.monotonic()-begin;record['actual_children'].append(entry)
            save(root/'partial-receipt.json',record)
            assert entry['actual_child_returncode']==0 and not entry['timed_out'],mode+' child failed'
            observation=json.loads((root/(mode+'-nodes.json')).read_bytes())
            if mode=='collect':
                nodes=observation['nodes'];assert nodes and len(nodes)==len(set(nodes))
                catalog=observation['items'];assert [item['nodeid'] for item in catalog]==nodes
                paths=[item['path'] for item in catalog]
                new_path=str((root/'preparation'/plan['new_test_file']).resolve())
                original_paths={str((root/'source'/name).resolve()) for name in plan['original_test_files']}
                assert paths.count(new_path)==plan['expected_new_nodes']==6
                assert len(paths)-paths.count(new_path)==42 and set(paths)==original_paths|{new_path}
                assert len(nodes)==len(json.loads((STAGE/'prior-1821-collect-nodes.json').read_bytes())['nodes'])==48
                assert not observation['reports']
                (root/'expected-nodes.json').write_text(json.dumps(nodes,indent=2)+'\n')
            else:
                assert observation['nodes']==nodes and observation['items']==catalog
                reports=observation['reports']
                assert len(reports)==3*len(nodes)
                assert {(r['nodeid'],r['when']) for r in reports}=={(n,w) for n in nodes for w in ('setup','call','teardown')}
                assert all(r['passed'] and not r['failed'] and not r['skipped'] for r in reports)
                xml=ET.parse(root/'pytest.xml');cases=xml.findall('.//testcase')
                assert len(cases)==len(nodes) and not xml.findall('.//failure') and not xml.findall('.//error') and not xml.findall('.//skipped')
                record.update(test_nodes=len(nodes),failures=0,errors=0,skipped=0,all_phases_passed=True)
        record['passed']=True
    except BaseException:
        record['exception']=traceback.format_exc()
        (root/'wrapper-traceback.txt').write_text(record['exception'])
    finally:
        after={n:sha((root/n).read_bytes()) for n in immutable}
        save(root/'immutable-after.json',after)
        actual_source_files={p.relative_to(root/'source').as_posix() for p in (root/'source').rglob('*') if p.is_file()}
        expected_source_files={n.removeprefix('source/') for n in immutable if n.startswith('source/')}
        record.update(immutable_files=len(immutable),immutable_before_after_exact=after==immutable,
            source_members_exact=actual_source_files==expected_source_files,
            stage_before_after_exact=all(sha((STAGE/n).read_bytes())==h for n,h in index.items()),
            seconds=time.monotonic()-started,scope='One private NumPy candidate surface/phase validation; no device, complete-column timestep, annual or scientific acceptance.')
        record['passed']=record['passed'] and record['immutable_before_after_exact'] and record['stage_before_after_exact'] and record['source_members_exact']
        save(root/'receipt.json',record)
    return 0 if record['passed'] else 1


if __name__=='__main__':raise SystemExit(main())

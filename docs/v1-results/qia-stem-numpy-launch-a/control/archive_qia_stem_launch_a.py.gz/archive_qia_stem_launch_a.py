from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');i=b/'qia-stem-inputs-a';r=b/'qia-stem-numpy-day-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();protocol=json.loads((i/'protocol.json').read_text());assert (i/'pbs-exit.txt').read_text().strip()=='0' and all(sha(i/'inputs'/n)==v for n,v in protocol['inputs_sha256'].items());launch=json.loads((r/'launch.json').read_text());p=r/'trajectory/report.json';raw=p.read_bytes();d=json.loads(raw);assert d['steps_requested']==17520 and d['steps_completed']<=48 and d['status'] in ['running','failed'];a=b/'qia-stem-numpy-launch-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for path in sorted(i.rglob('*')):
  if path.is_file():t.add(path,arcname='input-preparation/'+path.relative_to(i).as_posix(),recursive=False)
 for name in ['launch.json','SOURCE_SHA256.json','run_qia_stem_numpy_day_a.py','qia_stem_numpy_day_a.pbs']:t.add(r/name,arcname='numpy-launch/'+name,recursive=False)
 for key,hashkey in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:
  path=r/'trajectory'/d[key];assert sha(path)==d[hashkey];t.add(path,arcname='numpy-launch/trajectory/'+path.name,recursive=False)
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 snapshot=dict(scope='Immutable preparation and actual launch/committed-generation snapshot of new Qia explicit SAI assumption. Full17520 request and cold water/heat/C/N/LAI seed retained, first48 NumPy only; current prefix not a complete year,spinup,calibrated/observed result or resumed failed year.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],pbs_status=subprocess.run(['qstat','163.manager'],capture_output=True,text=True).stdout)
 for name,content in [('numpy-launch/captured-report.json',raw),('snapshot.json',(json.dumps(snapshot,indent=2)+'\n').encode()),('numpy-launch/captured-model.log',(r/'model.log').read_bytes())]:
  info=tarfile.TarInfo(name);info.size=len(content);t.addfile(info,io.BytesIO(content))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,snapshot=snapshot)))

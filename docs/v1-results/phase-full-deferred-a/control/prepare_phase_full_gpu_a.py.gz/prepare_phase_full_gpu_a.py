from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'collect_stem_full_gpu_b.py').read_text().replace('p6-stem-full-gpu-b', 'p6-phase-final-check-a').replace('full-by-file-b', 'full-by-file-a').replace('==1239', '==1241')
ast.parse(p)
(r / 'collect_phase_full_gpu_a.py').write_bytes(p.encode())

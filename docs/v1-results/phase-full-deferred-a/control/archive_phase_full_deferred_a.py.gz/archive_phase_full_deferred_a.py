from pathlib import Path
import datetime
import hashlib
import io
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-phase-final-check-a'
r = s / 'full-controller-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
launch = json.loads((r / 'launch.json').read_text())
assert sha(s / 'SOURCE_SHA256.json') == launch['source_manifest_sha256']
for n, v in launch['controls_sha256'].items():
    assert sha(b / n) == v
assert sha(r / 'superseded-pending-b.json') == launch['superseded_record_sha256']
cancel = json.loads((r / 'superseded-pending-b.json').read_text())
assert cancel['original_pid'] == 2387702 and cancel['original_gpu_worker_still_absent']
assert not (b / 'p6-stem-full-gpu-b/full-controller-b/worker.json').exists()
assert str(b / 'wait_phase_full_gpu_a.py').encode() in Path('/proc/' + str(launch['pid']) + '/cmdline').read_bytes().split(b'\0')
old_root = b / 'p6-material-event-b'
old = json.loads((old_root / 'full-by-file-b/progress.json').read_text())
snapshot = dict(scope='Actual current1241 queue snapshot; no current collection/worker completion inferred. Original493 results not credited. Only obsolete B idle coordinator canceled, original models remain untouched.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), launch=launch,
                current_worker_present=(r / 'worker.json').exists(), current_exit_present=(r / 'exit.json').exists(),
                previous493=dict(status=old['status'], covered_nodes=old['covered_nodes'], active=old['active'], actual_exit_present=(old_root / 'full-controller-b/exit.json').exists()), superseded_pending_B=cancel)
a = b / 'phase-full-deferred-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():
            t.add(p, arcname='controller/' + p.name, recursive=False)
    for n in [*launch['controls_sha256'], 'prepare_phase_full_gpu_a.py', 'package_phase_final_check_a.py']:
        t.add(b / n, arcname='control/' + n, recursive=False)
    t.add(s / 'SOURCE_SHA256.json', arcname='SOURCE_SHA256.json', recursive=False)
    raw = (json.dumps(snapshot, indent=2) + '\n').encode()
    info = tarfile.TarInfo('snapshot.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, current_pid=launch['pid'], current_worker_present=snapshot['current_worker_present'], previous493=snapshot['previous493'])))

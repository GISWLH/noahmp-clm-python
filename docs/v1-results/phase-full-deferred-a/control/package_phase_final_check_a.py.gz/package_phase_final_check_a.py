from pathlib import Path
import ast
import hashlib
import io
import json
import tarfile

r = Path(__file__).resolve().parents[2]
o = r / 'outputs/v1'
base = o / 'p6-stem-assessment-b-source.tar.gz'
sha = lambda v: hashlib.sha256(v).hexdigest()
assert sha(base.read_bytes()) == '8a378a471cd163958ca01cb9184343e79624af5f05e427b9397eaffd17cb2ca0'
with tarfile.open(base) as t:
    old = json.loads(t.extractfile('SOURCE_SHA256.json').read())
    data = {n: t.extractfile(n).read() for n in old}
assert len(data) == 506 and all(sha(data[n]) == h for n, h in old.items())
changed = ['src/noahmp_clm/physics/canopy_phase_energy.py', 'tests/test_canopy_phase_energy.py']
for n in changed:
    data[n] = (r / n).read_bytes()
    assert sha(data[n]) != old[n]
for n, v in data.items():
    if n.endswith('.py'):
        ast.parse(v.decode('utf-8-sig'), filename=n)
manifest = {n: sha(v) for n, v in data.items()}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
(o / 'p6-phase-final-check-a-source.json').write_bytes(manifest_bytes)
archive = o / 'p6-phase-final-check-a-source.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, v in [*data.items(), ('SOURCE_SHA256.json', manifest_bytes)]:
        info = tarfile.TarInfo(n)
        info.size = len(v)
        t.addfile(info, io.BytesIO(v))
record = dict(scope='Exact506B frozen package overlay only NumPy phase final-update convergence check and two real nonlinear solver budget regressions. No tolerance/update-budget/equation/conservation or JAX/CUDA byte changes. README/ROADMAP retained from frozenB; this package is not the latest repository docs snapshot.', source_files=506, changed=changed,
              archive_sha256=sha(archive.read_bytes()), manifest_sha256=sha(manifest_bytes), full_cpu_expected=901, full_gpu_expected=340, all_nodes_expected=1241)
(o / 'p6-phase-final-check-a-package.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

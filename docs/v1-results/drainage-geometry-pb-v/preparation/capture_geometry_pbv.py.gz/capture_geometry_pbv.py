"""Four original diagnosis calls and four independent geometry probes on CUDA1."""
import argparse
import importlib.metadata
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

from contract_pbv import GPU,HERE,bound_evidence,controls,save,sha,source_identity

FIELDS=('liquid_divided_1000','ice_divided_917','saturation_numerator',
    'saturation_denominator','saturation','density917_times_thickness',
    'ice_denominator','ice_quotient','ice_fraction')
CUDA_FLAGS=('--std=c++14','--fmad=false','--prec-div=true','--prec-sqrt=true')

def main():
    p=argparse.ArgumentParser()
    for n in ('source','evidence','output'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--backend',choices=('cuda','jax'),required=True);a=p.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='true'
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    caches={k:Path(os.environ[k]).resolve() for k in ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH')}
    assert len(set(caches.values()))==3 and all(str(x).startswith('/tmp/drainage-pb-s-pbv-') for x in caches.values())
    assert not a.output.exists()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());control_sha=controls()
    identity=source_identity(a.source,binding);prior=bound_evidence(a.evidence,binding)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024,'Original 8GiB GPU/32GiB host startup gate'
    a.output.mkdir();compiler=a.output/'compiler';compiler.mkdir()
    sys.path.insert(0,str(a.source.resolve()/'src'))
    import numpy as np  # Frozen input/output encoding only; no NumPy physics.
    if a.backend=='jax':
        assert importlib.metadata.version('jax')==importlib.metadata.version('jaxlib')=='0.11.2'
        import jax
        import jax.numpy as xp
        jax.config.update('jax_enable_x64',True)
        assert len(jax.devices())==1 and jax.devices()[0].platform=='gpu'
        def host(v):
            if hasattr(v,'block_until_ready'):v.block_until_ready()
            return np.asarray(v).copy()
        synchronize=lambda:jax.effects_barrier()
        version=jax.__version__
    else:
        import cupy as xp
        assert xp.cuda.runtime.getDeviceCount()==1
        xp.cuda.Device(0).use();xp.cuda.runtime.free(0)
        host=lambda v:xp.asnumpy(v).copy() if isinstance(v,xp.ndarray) else np.asarray(v).copy()
        synchronize=lambda:xp.cuda.get_current_stream().synchronize()
        version=xp.__version__
    from noahmp_clm.gpu import clm_drainage_primitives as primitives
    from noahmp_clm.gpu import clm_drainage_diagnosis as diagnosis
    forbidden=[]
    def no_cpu(*args,**kw):
        forbidden.append('NumPy physical function reached');raise RuntimeError(forbidden[-1])
    primitives.run_numpy=no_cpu
    original_diagnosis=diagnosis.diagnose_clm_drainage
    record=dict(passed=False,attribution_conclusive=False,backend=a.backend,pid=os.getpid(),gpu_uuid=GPU,
        **identity,controls_manifest_sha256=control_sha,evidence_archive_sha256=sha(a.evidence.read_bytes()),
        original_diagnosis_attempted=0,original_diagnosis_returned=0,geometry_context_attempted=0,geometry_context_returned=0,
        phase_calls=0,adapter_calls=0,CPU_reference_calls=0,forbidden_cpu_reference_calls=forbidden,cases=[],
        setup_gpu_free_mib=free,setup_host_available_kib=available,physical_comparisons_executed=False,
        production_registered=False,scientific_acceptance=False,environment=dict(python=sys.version,backend_version=version,
        CUDA_VISIBLE_DEVICES=os.environ['CUDA_VISIBLE_DEVICES'],XLA_FLAGS=os.environ.get('XLA_FLAGS'),
        cuda_flags=list(CUDA_FLAGS),numpy=np.__version__))
    started=time.monotonic();context_executable=None;module=None;compiler_info={}
    try:
        if a.backend=='jax':
            barrier=jax.lax.optimization_barrier
            def geometry_context(c,parameters):
                liquid_divided=barrier(c[:,0]/1000)
                ice_divided=barrier(c[:,1]/917)
                numerator=barrier(liquid_divided+ice_divided)
                denominator=barrier(c[:,2]*parameters[0])
                saturation=barrier(numerator/denominator)
                density_thickness=barrier(917*c[:,2])
                ice_denominator=barrier(density_thickness*parameters[0])
                ice_quotient=barrier(c[:,1]/ice_denominator)
                ice_fraction=xp.minimum(1,ice_quotient)
                components=xp.stack((liquid_divided,ice_divided,numerator,denominator,saturation,
                    density_thickness,ice_denominator,ice_quotient,ice_fraction),axis=1)
                return primitives._diagnosis(c,parameters,xp,barrier),components
            context_function=jax.jit(jax.vmap(geometry_context))
        else:
            original=(a.source/'src/noahmp_clm/gpu/cuda/clm_drainage_primitives_kernel.cu').read_bytes()
            probe=(HERE/'geometry_probe.cu').read_bytes()
            expanded=original+b'\n'+probe
            (compiler/'probe-expanded.cu').write_bytes(expanded)
            module=xp.RawModule(code=expanded.decode(),options=CUDA_FLAGS,name_expressions=('geometry_probe',))
            compiler_info.update(CUDA_rawmodule_flags=list(CUDA_FLAGS),expanded_source_sha256=sha(expanded),
                original_helper_sha256=sha(original),probe_sha256=sha(probe))
        for name in binding['cases']:
            root=a.output/name;root.mkdir();prefix=a.backend+'/device/'+name+'/'
            meta=json.loads(prior[prefix+'result.json'])
            raw=prior[prefix+'result.npz'];assert sha(raw)==meta['npz_sha256']
            with np.load(io.BytesIO(raw),allow_pickle=False) as data:
                encoded={key:data[key].copy() for key in ('actual.phase_cells_before','actual.encoded_parameters','actual.diagnosis_before')}
            for key,value in encoded.items():
                desc=meta['arrays'][key]
                assert (value.dtype.str,list(value.shape),sha(value.tobytes()))==(desc['dtype'],desc['shape'],desc['c_order_sha256'])
            c,p12=(xp.asarray(encoded[key]) for key in ('actual.phase_cells_before','actual.encoded_parameters'))
            assert c.dtype==p12.dtype==xp.float32 and c.shape==(1,4,6) and p12.shape==(1,12)
            record['original_diagnosis_attempted']+=1
            baseline=original_diagnosis(c,p12,backend=a.backend)
            record['original_diagnosis_returned']+=1;synchronize()
            if a.backend=='jax':
                if context_executable is None:
                    lowered=context_function.lower(c,p12);context_executable=lowered.compile()
                    (compiler/'context-lowered.mlir').write_text(lowered.as_text())
                    optimized=context_executable.as_text();assert isinstance(optimized,str) and optimized
                    (compiler/'context-optimized-hlo.txt').write_text(optimized)
                    old=diagnosis._jax_diagnosis().lower(c,p12).compile().as_text()
                    assert isinstance(old,str) and old
                    (compiler/'original-optimized-hlo.txt').write_text(old)
                    compiler_info['JAX_optimized_HLO_saved']=True
                record['geometry_context_attempted']+=1
                augmented,components=context_executable(c,p12)
            else:
                augmented=xp.empty((1,29),xp.float32);components=xp.empty((1,4,9),xp.float32)
                record['geometry_context_attempted']+=1
                module.get_function('geometry_probe')((1,),(128,),(c,p12,augmented,components,np.int32(1)))
            record['geometry_context_returned']+=1;synchronize()
            arrays={'input.phase_cells':host(c),'input.parameters':host(p12),'original.diagnosis':host(baseline),
                'context.diagnosis':host(augmented),'context.components':host(components)}
            assert all(v.dtype==np.float32 for v in arrays.values())
            actual=arrays['original.diagnosis'];aug=arrays['context.diagnosis'];ops=arrays['context.components']
            assert actual.shape==aug.shape==(1,29) and ops.shape==(1,4,9)
            checks=dict(original29_reproduces_prior=sha(actual.tobytes())==meta['arrays']['actual.diagnosis_before']['c_order_sha256'],
                augmented29_reproduces_original=sha(aug.tobytes())==sha(actual.tobytes()),
                components_saturation_reproduces_original=sha(ops[:,:,4].copy().tobytes())==sha(actual[:,25:29].copy().tobytes()),
                components_ice_reproduces_original=sha(ops[:,:,8].copy().tobytes())==sha(actual[:,21:25].copy().tobytes()),
                source_input_bytes_unchanged=all(sha(arrays[k].tobytes())==sha(encoded[v].tobytes()) for k,v in
                    (('input.phase_cells','actual.phase_cells_before'),('input.parameters','actual.encoded_parameters'))))
            np.savez(root/'result.npz',**arrays)
            descriptors={k:dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes())) for k,v in arrays.items()}
            # Exact IEEE payload encoding, not a host physical comparison.
            bits={k:v.view(np.uint32).tolist() for k,v in arrays.items()}
            apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True)
            own=[line.split(',')[1].strip() for line in apps.splitlines() if line.split(',')[0].strip()==str(os.getpid())]
            assert own and set(own)=={GPU}
            row=dict(case=name,arrays=descriptors,npz_sha256=sha((root/'result.npz').read_bytes()),IEEE_uint32_bits=bits,
                component_fields=FIELDS,checks=checks,attribution_context_valid=all(checks.values()),
                actual_device_barrier_complete=True,own_process_gpu_uuids=own)
            save(root/'result.json',row);record['cases'].append(row)
        if a.backend=='cuda':
            # Save an explicitly supplementary PTX compile; the loaded RawModule
            # retains its original CUBIN/default mode and unchanged options.
            try:
                from cupy.cuda import compiler as cc
                arch=xp.cuda.Device(0).compute_capability
                options=CUDA_FLAGS+(f'-arch=compute_{arch}','--device-as-default-execution-space')
                program=cc._NVRTCProgram(expanded.decode(),name='geometry_probe_supplementary.cu',method='ptx')
                ptx,mapping=program.compile(options)
                (compiler/'supplementary-not-loaded.ptx').write_bytes(ptx)
                compiler_info['supplementary_PTX']=dict(saved=True,loaded=False,options=list(options),sha256=sha(ptx),mapping=mapping)
                compiler_info['cupy_compiler_implementation_sha256']=sha(Path(cc.__file__).read_bytes())
            except Exception:
                compiler_info['supplementary_PTX']=dict(saved=False,loaded=False,error=traceback.format_exc())
            saved=[]
            for cache_name,cache_root in caches.items():
                if not cache_root.exists():continue
                for path in sorted(cache_root.rglob('*')):
                    if path.is_file():
                        target=compiler/'cache-binaries'/cache_name/path.relative_to(cache_root)
                        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
                        saved.append(dict(path=target.relative_to(compiler).as_posix(),bytes=target.stat().st_size,sha256=sha(target.read_bytes())))
            compiler_info['actual_private_cache_files']=saved
        assert record['original_diagnosis_attempted']==record['original_diagnosis_returned']==4
        assert record['geometry_context_attempted']==record['geometry_context_returned']==4
        assert not forbidden
        record['attribution_conclusive']=all(x['attribution_context_valid'] for x in record['cases'])
        record['passed']=record['attribution_conclusive']
    except BaseException:
        record['error']=traceback.format_exc();(a.output/'failure.txt').write_text(record['error'])
    finally:
        save(compiler/'compiler-info.json',compiler_info)
        try:
            assert source_identity(a.source,binding)==identity and controls()==control_sha
            bound_evidence(a.evidence,binding);record['source_controls_prior_unchanged']=True
        except BaseException:
            record['post_run_identity_error']=traceback.format_exc();record['source_controls_prior_unchanged']=False;record['passed']=False
        record['seconds']=time.monotonic()-started;save(a.output/'capture-receipt.json',record)
    return 0 if record['passed'] else 1

if __name__=='__main__':raise SystemExit(main())

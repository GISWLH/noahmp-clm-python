"""Frozen PB-t source and original device packet identities; stdlib only."""
import hashlib
import io
import json
from pathlib import Path,PurePosixPath
import tarfile

HERE=Path(__file__).resolve().parent
GPU='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def files(raw):
    out={}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for m in archive:
            if m.isdir():continue
            n=m.name.removeprefix('./');p=PurePosixPath(n)
            assert m.isfile() and not p.is_absolute() and '..' not in p.parts and '\\' not in n and n not in out
            out[n]=archive.extractfile(m).read()
    return out

def controls():
    raw=(HERE/'CONTROLS_SHA256.json').read_bytes();index=json.loads(raw)
    assert {p.name for p in HERE.iterdir() if p.is_file()}==set(index)|{'CONTROLS_SHA256.json'}
    assert all(sha((HERE/n).read_bytes())==h for n,h in index.items())
    return sha(raw)

def source_identity(root,binding):
    root=Path(root).resolve();raw=(root/'SOURCE_SHA256.json').read_bytes();index=json.loads(raw)
    assert sha(raw)==binding['source_manifest_sha256'] and len(index)==596
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(index)|{'SOURCE_SHA256.json'}
    assert all(sha((root/n).read_bytes())==h for n,h in index.items())
    return dict(source_files=596,source_manifest_sha256=sha(raw))

def bound_evidence(path,binding):
    raw=Path(path).read_bytes();assert sha(raw)==binding['evidence_archive_sha256']
    data=files(raw)
    control=json.loads(data['controller/controller-receipt.json'])
    assert control['completed'] and control['stage_unchanged']
    assert [r['actual_parent_returncode'] for r in control['actual_parents']]==[0,0]
    for backend in ('cuda','jax'):
        capture=json.loads(data[backend+'/device/capture-receipt.json'])
        assert capture['passed'] and capture['actual_model_returns']==capture['actual_model_attempts']==8
        assert capture['source_files']==596 and capture['source_manifest_sha256']==binding['source_manifest_sha256']
        assert capture['source_controls_evidence_unchanged'] and not capture['forbidden_cpu_reference_calls']
        for case in binding['cases']:
            prefix=backend+'/device/'+case+'/'
            record=binding['case_bindings'][backend][case]
            assert sha(data[prefix+'result.json'])==record['metadata_sha256']
            assert sha(data[prefix+'result.npz'])==record['npz_sha256']
    return data

"""Closed PB-v geometry capture and static compiler evidence; no numeric decode."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,packet,sha

BASE=Path(__file__).resolve().parent
LABEL='drainage-geometry-pb-v'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='80ab069de55a875b7533442b535e8b027dca7d97a9aa096552b0f64c9b99b919'
    index=json.loads(stage['stage-inventory.json']);assert len(stage)==17 and set(index)==set(stage)-{'stage-inventory.json'}
    assert all(sha(stage[n])==h for n,h in index.items())
    raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes();gpu=files(raw)
    assert sha(raw)=='f5221539e4ab7371171b1b67e4b488317e5157d62ddec002dd3d6792e0b6c9b9' and len(gpu)==132
    controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and controller['actual_controller_OS_returncode'] is None
    assert [p['actual_parent_returncode'] for p in controller['actual_parents']]==[0,0]
    binding=json.loads(stage['preparation/BINDINGS.json']);captures={};verified=0
    for backend in ('cuda','jax'):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json'])
        capture=json.loads(gpu[backend+'/device/capture-receipt.json'])
        assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
        assert capture['passed'] and capture['attribution_conclusive'] and capture['source_controls_prior_unchanged']
        assert capture['source_manifest_sha256']==binding['source_manifest_sha256'] and capture['source_files']==596
        assert capture['original_diagnosis_attempted']==capture['original_diagnosis_returned']==4
        assert capture['geometry_context_attempted']==capture['geometry_context_returned']==4
        assert not capture['forbidden_cpu_reference_calls'] and capture['CPU_reference_calls']==capture['phase_calls']==capture['adapter_calls']==0
        assert len(capture['cases'])==4
        for case in binding['cases']:
            prefix=backend+'/device/'+case+'/'
            meta=json.loads(gpu[prefix+'result.json'])
            assert meta['attribution_context_valid'] and all(meta['checks'].values())
            assert meta['actual_device_barrier_complete'] and set(meta['own_process_gpu_uuids'])=={binding['GPU_UUID']}
            verified+=packet(gpu[prefix+'result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
        captures[backend]=capture
    info=json.loads(gpu['cuda/device/compiler/compiler-info.json'])
    assert info['supplementary_PTX']['saved'] and info['supplementary_PTX']['loaded'] is False
    assert sha(gpu['cuda/device/compiler/supplementary-not-loaded.ptx'])==info['supplementary_PTX']['sha256']
    for row in info['actual_private_cache_files']:
        payload=gpu['cuda/device/compiler/'+row['path']]
        assert sha(payload)==row['sha256'] and len(payload)==row['bytes']
    original=gpu['jax/device/compiler/original-optimized-hlo.txt'].decode().splitlines()
    context=gpu['jax/device/compiler/context-optimized-hlo.txt'].decode().splitlines()
    ptx=gpu['cuda/device/compiler/supplementary-not-loaded.ptx'].decode().splitlines()
    assert all('multiply' in original[k-1] and '/div' in original[k-1] for k in (548,558))
    assert all('multiply' in context[k-1] and '/div' in context[k-1] for k in (556,566))
    assert all('div.rn.f32' in ptx[k-1] for k in (72,74,78,81))
    compiler_readout=dict(static_compiler_text_only=True,numerical_correct_rounding_reference_executed=False,
        original_JAX_HLO=dict(path='jax/device/compiler/original-optimized-hlo.txt',sha256=sha(gpu['jax/device/compiler/original-optimized-hlo.txt']),
            observations=[dict(line=k,text=original[k-1]) for k in (546,548,556,558)]),
        context_JAX_HLO=dict(path='jax/device/compiler/context-optimized-hlo.txt',sha256=sha(gpu['jax/device/compiler/context-optimized-hlo.txt']),
            observations=[dict(line=k,text=context[k-1]) for k in (554,556,564,566)]),
        supplementary_CUDA_PTX=dict(path='cuda/device/compiler/supplementary-not-loaded.ptx',loaded=False,
            observations=[dict(line=k,text=ptx[k-1]) for k in (72,74,78,81)],options=info['supplementary_PTX']['options']),
        interpretation='Both actual original/context JAX optimized HLO texts fold source constant divisions1000/917 into f32 reciprocal multiplication. Supplementary not-loaded PTX shows div.rn.f32. This does not establish which actual captured operation is correctly rounded; exact rational analysis remains pending on EHPC. Actual loaded private cache binaries are preserved without a disassembly claim.')
    readout=dict(actual_GPU_parent_returncodes=[0,0],actual_GPU_worker_returncodes=[0,0],actual_controller_OS_returncode=None,
        GPU_timeouts=0,controller_seconds=controller['seconds'],overall_context_reproduction_passed=True,
        original_diagnosis_calls=8,augmented_geometry_calls=8,CPU_reference_calls=0,phase_calls=0,adapter_calls=0,
        verified_opaque_arrays=verified,source_files=596,source_controls_prior_unchanged=True,
        worker_seconds={b:r['seconds'] for b,r in captures.items()},
        parent_seconds={r['backend']:r['parent_receipt']['seconds'] for r in controller['actual_parents']},
        contexts=[dict(backend=b,case=c['case'],checks=c['checks'],attribution_context_valid=c['attribution_context_valid']) for b,r in captures.items() for c in r['cases']],
        compiler_readout=compiler_readout,EHPC_exact_analysis_executed=False,production_registered=False,
        scope='Actual same-input geometry diagnostic captures only. Original/augmented29-field and geometry/input payloads reproduce each backend PB-t packet in all8 backend/cases. Original PB-t1e-6 failures are not rerun or retired, and no repair, full-column/year or scientific acceptance is claimed.')
    verification=dict(evidence_verified=True,overall_context_reproduction_passed=True,model_or_scientific_acceptance=False,
        executed_stage_sha256=sha(stage_raw),original_GPU_result_sha256=sha(raw),original_result_files=len(gpu),
        actual_GPU_parent_returncodes=[0,0],verified_opaque_array_headers_and_payload_hashes=verified,
        local_array_numeric_decode=False,local_model_runs=0,EHPC_exact_reference_pending=True)
    items={'executed-stage.tar.gz':stage_raw,'original-gpu-result.tar.gz':raw,
        'original-gpu-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(gpu.items())}),
        'readout.json':encode(readout),'verification.json':encode(verification),'compiler-readout.json':encode(compiler_readout)}
    for n,v in stage.items():
        if n.startswith(('preparation/','execution/')):items[n]=v
    for n,v in gpu.items():
        if '/device/compiler/' in n and n.endswith(('.txt','.mlir','.ptx','.cu','.json')):items['compiler-texts/'+n]=v
    for p in (BASE/(LABEL+'-gpu-closed')).iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for n in (LABEL+'-stage-package.json',LABEL+'-gpu-deployment.json',LABEL+'-prelaunch-metadata.txt',
        'prepare_drainage_geometry_pbv.py','deploy_drainage_geometry_pbv.py','read_drainage_geometry_pbv.py',
        'collect_drainage_geometry_pbv.py','DRAINAGE_CAUSAL_TRACE_PBV_DESIGN.md',Path(__file__).name):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-progress-'):
        for p in BASE.glob(prefix+'*'):
            if p.is_file():items['deployment/'+p.name]=p.read_bytes()
    # The analysis stage is preserved explicitly as unexecuted preparation.
    for n in (LABEL+'-analysis-stage.tar.gz',LABEL+'-analysis-stage-package.json','prepare_drainage_geometry_pbv_analysis.py'):
        items['unexecuted-analysis-preparation/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                member=tarfile.TarInfo(n);member.size=len(v);member.mode=0o644;archive.addfile(member,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual PB-v CUDA/JAX geometry workers0:8 original and8 augmented diagnostic calls, all8 backend/case contexts byte-reproduced, source/prior exact. HLO/not-loaded PTX text observations preserved; EHPC strict Fraction reference only prepared, no repair/full-column/year/scientific credit.')
    for suffix,value in (('readout',readout),('verification',verification),('compiler-readout',compiler_readout),('package',package)):(BASE/(LABEL+'-'+suffix+'.json')).write_bytes(encode(value))
    print(json.dumps(package))

if __name__=='__main__':main()

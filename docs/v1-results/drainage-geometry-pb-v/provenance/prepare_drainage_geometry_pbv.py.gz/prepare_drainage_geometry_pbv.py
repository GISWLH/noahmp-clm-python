"""Build reviewable PB-v controls/stage, stdlib only, without deployment."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'drainage-geometry-pb-v-preparation'
EXEC=BASE/'drainage-geometry-pb-v-execution'
OLD=BASE/'clm-drainage-device-pb-t-execution'
SOURCE='da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d'
PRIOR='69daf37ba4bdef8990de4325ba7bd3d8b38690adc4751fc0ae5f254cef669eea'
CASES=('frozen-float32','perched_stress-float32','option2-float32','two_bands-float32')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    assert not EXEC.exists();EXEC.mkdir()
    source=(BASE/'clm-drainage-header-pb-t-source.tar.gz').read_bytes();assert sha(source)==SOURCE
    prior=(BASE/'clm-drainage-device-pb-t-gpu-closed/gpu-result.tar.gz').read_bytes();assert sha(prior)==PRIOR
    with tarfile.open(fileobj=io.BytesIO(prior)) as archive:
        old_data={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
    case_bindings={}
    for backend in ('cuda','jax'):
        case_bindings[backend]={}
        for name in CASES:
            prefix=backend+'/device/'+name+'/'
            case_bindings[backend][name]=dict(metadata_sha256=sha(old_data[prefix+'result.json']),npz_sha256=sha(old_data[prefix+'result.npz']))
    binding=dict(prepared_only=True,launched=False,source_archive_sha256=SOURCE,
        source_manifest_sha256='1d6031e5d9c9af3c027378c2c559bb17ce80fdeac141bef1862260180b9be661',
        source_files=596,evidence_archive_sha256=PRIOR,evidence_kind='Original PB-t device result, not a CPU physical reference',
        original_pair_validation_passed=False,original_comparison_job='1828.manager',original_comparison_F_exit=1,
        original_comparison_Stageout_status=0,cases=CASES,case_bindings=case_bindings,
        original_diagnosis_calls_per_backend=4,augmented_context_calls_per_backend=4,
        phase_calls=0,adapter_calls=0,CPU_physical_reference_calls=0,
        attribution_requires_original_and_augmented_context_byte_exact=True,backend_order=['cuda','jax'],
        maximum_worker_seconds=900,minimum_GPU_free_mib=8192,minimum_host_available_kib=33554432,
        GPU_UUID='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',CPU_analysis_location='EHPC compute002 only')
    (PREP/'BINDINGS.json').write_bytes(encode(binding))
    for path in PREP.iterdir():
        if path.suffix=='.py':assert b'\0' not in path.read_bytes();compile(ast.parse(path.read_bytes()),path.name,'exec')
    prep_index={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file()}
    (PREP/'CONTROLS_SHA256.json').write_bytes(encode(prep_index))
    diffs=[]
    mapping={'run_device_parent_pbs.py':'run_geometry_parent_pbv.py','control_device_pbs.py':'control_geometry_pbv.py',
        'launch_device_pbs.py':'launch_geometry_pbv.py'}
    for old_name,new_name in mapping.items():
        raw=(OLD/old_name).read_bytes();updated=raw
        for old,new in ((b'contract_pbs',b'contract_pbv'),(b'capture_device_pbs.py',b'capture_geometry_pbv.py'),
            (b'run_device_parent_pbs.py',b'run_geometry_parent_pbv.py'),(b'control_device_pbs.py',b'control_geometry_pbv.py'),
            (b'pbr-evidence.tar.gz',b'prior-device.tar.gz')):updated=updated.replace(old,new)
        if old_name=='run_device_parent_pbs.py':
            updated=updated.replace(b'/tmp/drainage-pb-s-',b'/tmp/drainage-pb-s-pbv-').replace(b'3600',b'900')
        compile(ast.parse(updated),new_name,'exec');(EXEC/new_name).write_bytes(updated)
        diffs.extend(difflib.unified_diff(raw.decode().splitlines(True),updated.decode().splitlines(True),fromfile='PB-t/'+old_name,tofile='PB-v/'+new_name))
    policy=dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),source_archive_sha256=SOURCE,
        source_manifest_sha256=binding['source_manifest_sha256'],evidence_archive_sha256=PRIOR,
        root='/home/lhwang/work/noahmp-v1/clm-drainage-geometry-pb-v',temporary='/tmp/drainage-pb-s-pbv-20261026',
        gpu_uuid=binding['GPU_UUID'],backend_order=['cuda','jax'],maximum_worker_seconds=900,
        single_launch=True,automatic_retry=False,source_modified=False,production_registered=False,
        resources='Physical CUDA1,1thread,8GiB GPU/32GiB host startup gate,900s per worker',
        execution_authorized=False,phase_calls=0,adapter_calls=0)
    (EXEC/'EXECUTION_BINDINGS.json').write_bytes(encode(policy))
    (EXEC/'PB_T_TO_PB_V.diff').write_text(''.join(diffs),encoding='utf-8')
    (EXEC/'README.md').write_text('PB-v prepared-only lifecycle controls. The parent/controller/launcher are mechanically adapted from PB-t with entry/contract/input archive/private paths and900s timeout changes only. No deployment is included or authorized. Root must review this stage before a unique later launch. Actual CUDA1 ownership must be coordinated with QH.\n',encoding='utf-8')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}))
    files={}
    for root,prefix in ((PREP,'preparation'),(EXEC,'execution')):
        for p in root.iterdir():
            if p.is_file():files[prefix+'/'+p.name]=p.read_bytes()
    files['source.tar.gz']=source;files['prior-device.tar.gz']=prior
    files['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(files.items())})
    target=BASE/'drainage-geometry-pb-v-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,raw in sorted(files.items()):
                member=tarfile.TarInfo(n);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==files
    result=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),stage_files=len(files),bytes=target.stat().st_size,
        preparation_manifest_sha256=policy['preparation_manifest_sha256'],execution_manifest_sha256=sha(files['execution/CONTROLS_SHA256.json']),
        source_archive_sha256=SOURCE,original_device_archive_sha256=PRIOR,prepared_only=True,launched=False,numerical_executed=False)
    (BASE/'drainage-geometry-pb-v-stage-package.json').write_bytes(encode(result));print(json.dumps(result))

if __name__=='__main__':main()

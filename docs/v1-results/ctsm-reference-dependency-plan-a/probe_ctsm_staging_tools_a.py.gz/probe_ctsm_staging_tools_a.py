from pathlib import Path
import hashlib,json,os,shutil,subprocess,urllib.request
base=Path('/home/lhwang/work/noahmp-v1');dest=base/'ctsm-staging-tools-a.json';assert not dest.exists();tools={}
for name in ['conda','micromamba','mamba','git','gfortran','cmake','tar','bzip2','curl']:
    path=shutil.which(name);tools[name]=dict(path=path)
    if path:
        try:
            r=subprocess.run([path,'--version'],capture_output=True,text=True,timeout=10);tools[name].update(returncode=r.returncode,version=(r.stdout+r.stderr).splitlines()[:2])
        except Exception as e:tools[name]['error']=type(e).__name__
for name in ['/home/lhwang/anaconda3/bin/conda','/home/lhwang/miniconda3/bin/conda','/opt/conda/bin/conda']:
    if Path(name).is_file():tools[name]=dict(exists=True)
network=[]
for url in ['https://api.github.com/repos/ESCOMP/CTSM/commits/release-clm5.0','https://raw.githubusercontent.com/ESCOMP/CTSM/release-clm5.0/Externals_CLM.cfg','https://conda.anaconda.org/conda-forge/linux-64/repodata.json.zst']:
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Wang-CLM-reference-staging-probe'})
        with urllib.request.urlopen(req,timeout=10) as stream:
            code=stream.status;data=stream.read(32768) if not url.endswith('.zst') else b''
        row=dict(url=url,http_status=code)
        if '/commits/' in url:
            value=json.loads(data);row.update(commit_sha=value['sha'],commit_time=value['commit']['committer']['date'])
        if url.endswith('.cfg'):
            row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest());(base/'ctsm-Externals_CLM-a.cfg').write_bytes(data)
        network.append(row)
    except Exception as e:network.append(dict(url=url,error=type(e).__name__,detail=str(e)[:200]))
value=dict(scope='Non-model source/dependency download staging availability only; actual CPU compilation/physics/tests remain intended for EHPC PBS.',tools=tools,network=network)
dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import datetime,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');root=base/'ctsm-dependency-plan-a'
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);(root/'launch_ctsm_dependency_plan_a.py').write_bytes(Path(__file__).read_bytes())
    command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'launch_ctsm_dependency_plan_a.py'),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    r=dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only conda dependency solve/dry-run for portable EHPC compiler/reference environment. No model simulation/build/install.')
    (root/'launch.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(0)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(CONDA_PKGS_DIRS=str(root/'package-cache'),CONDA_OVERRIDE_GLIBC='2.17',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
specs=['python=3.11','gcc_linux-64=12','gxx_linux-64=12','gfortran_linux-64=12','sysroot_linux-64=2.17','libnetcdf=4.9.2=nompi*','netcdf-fortran=4.6.1','netcdf4','numpy<3','scipy','cmake<4','make','perl','libxml2','git','conda-pack']
command=['/home/lhwang/anaconda3/bin/conda','create','--dry-run','--json','--yes','--solver','libmamba','--override-channels','--strict-channel-priority','--channel','https://conda.anaconda.org/conda-forge','--prefix',str(base/'ctsm-portable-env-a'),*specs]
(root/'protocol.json').write_text(json.dumps(dict(scope='Dry dependency plan; no environment creation or physical reference yet.',target_glibc='2.17',specs=specs,command=command),indent=2)+'\n')
begun=time.monotonic()
with (root/'solve.json').open('w') as out,(root/'solve.stderr.txt').open('w') as err:p=subprocess.Popen(command,env=env,stdout=out,stderr=err)
(root/'progress.json').write_text(json.dumps(dict(status='running',pid=p.pid,command=command),indent=2)+'\n');code=p.wait()
value=dict(returncode=code,seconds=time.monotonic()-begun,environment_created=(base/'ctsm-portable-env-a').exists(),scope='Dependency solver result only, not official CTSM execution or scientific acceptance.')
(root/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(code)

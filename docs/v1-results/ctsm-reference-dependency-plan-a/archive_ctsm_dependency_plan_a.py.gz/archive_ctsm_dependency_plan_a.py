from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'ctsm-dependency-plan-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'exit.json').read_text());s=json.loads((root/'solve.json').read_text());assert r['returncode']==0 and not r['environment_created'] and s['success'] and s['dry_run']
assert len(s['actions']['FETCH'])==len(s['actions']['LINK'])==87
pairs=[(root/n,'dependency-plan/'+n) for n in ['launch_ctsm_dependency_plan_a.py','launch.json','protocol.json','solve.json','solve.stderr.txt','exit.json','controller.log']]
pairs += [(base/n,n) for n in ['ctsm-staging-tools-a.json','ctsm-Externals_CLM-a.cfg','probe_ctsm_staging_tools_a.py']]
for folder,names in [('ctsm-portable-build-a',['launch.json','launch_ctsm_portable_env_a.py','explicit-lock.txt','package-lock.json']),('ctsm-source-stage-a',['launch.json','launch_ctsm_source_a.py'])]:
    for n in names:pairs.append((base/folder/n,folder+'/'+n))
pairs.append((Path(__file__),'archive_ctsm_dependency_plan_a.py'))
dest=base/'ctsm-reference-dependency-plan-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for path,name in pairs:t.add(path,arcname=name,recursive=False)
print(json.dumps(dict(files=len(pairs),sha256=sha(dest),scope='Successful exact87-package dry solve for glibc2.17 and source/environment staging launch receipts only. Not an installed/portable/compiled/official model output or scientific acceptance result.')))

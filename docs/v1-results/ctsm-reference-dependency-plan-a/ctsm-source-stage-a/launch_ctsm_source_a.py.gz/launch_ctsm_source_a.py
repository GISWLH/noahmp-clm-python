from pathlib import Path
import datetime,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');root=base/'ctsm-source-stage-a';source=root/'CTSM';pin='fdfc03a0abec838ec0b66663a6a2f5e619cd2611'
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);(root/'launch_ctsm_source_a.py').write_bytes(Path(__file__).read_bytes())
    command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'launch_ctsm_source_a.py'),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    receipt=dict(pid=p.pid,command=command,pinned_commit=pin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Only unmodified upstream single-point reference source download/pinning; no reference build/physics or Python port code copy.')
    (root/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(0)
env=os.environ.copy();env.update(GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never',PYTHONDONTWRITEBYTECODE='1')
commands=[['git','init',str(source)],['git','-C',str(source),'remote','add','origin','https://github.com/ESCOMP/CTSM.git'],['git','-c','credential.helper=','-C',str(source),'fetch','--depth','1','origin',pin],['git','-C',str(source),'checkout','--detach','FETCH_HEAD'],['git','-c','credential.helper=','-C',str(source),'submodule','update','--init','--recursive','--depth','1']]
rows=[];begun=time.monotonic()
for k,command in enumerate(commands):
    with (root/(str(k)+'-git.log')).open('w') as log:p=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    (root/'progress.json').write_text(json.dumps(dict(status='running',pid=p.pid,command=command),indent=2)+'\n');code=p.wait();rows.append(dict(command=command,returncode=code))
    if code:
        (root/'exit.json').write_text(json.dumps(dict(status='failed',stages=rows),indent=2)+'\n');raise SystemExit(code)
actual=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert actual==pin
configs={p.name:p.read_text() for p in sorted(source.glob('Externals*.cfg'))}
value=dict(status='complete',scope='Pinned upstream root/submodule download only; external dependencies and official build/run still pending.',pinned_commit=pin,actual_commit=actual,stages=rows,seconds=time.monotonic()-begun,external_configurations=configs)
(root/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

b = Path('/home/lhwang/work/noahmp-v1')
s, old, r = b / 'p6-fresh-phase-edge-a', b / 'k78-failure-a', b / 'k78-current-b'
assert not r.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(s / 'SOURCE_SHA256.json') == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in m.items())
assert sha(old / 'input.npz') == '957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
free = subprocess.check_output(['nvidia-smi', '--id=0', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip()
assert int(free) > 4096, 'Do not launch without owned GPU0 memory headroom; no resets/kills'
r.mkdir()
for name in ['input.npz', 'binding.json']:
    shutil.copyfile(old / name, r / name)
    assert sha(old / name) == sha(r / name)
shutil.copyfile(s / 'SOURCE_SHA256.json', r / 'SOURCE_SHA256.json')
controls = {name: sha(b / name) for name in ['replay_k78_current_backend_b.py', 'control_k78_current_b.py', 'launch_k78_current_b.py']}
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1',
           CUDA_VISIBLE_DEVICES='0', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
           XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_COMPILATION_CACHE_DIR=str(b / 'jax-surface-cache'))
with (r / 'controller.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'control_k78_current_b.py')], cwd=s, env=env, stdin=subprocess.DEVNULL,
                         stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
launch = dict(scope='Current510 original K78 isolated16-array whole-step device replay after old strictA finished. Exact original primary/shadow inputs,unchanged1e-6/no source or failed-year advancement. Actual CPU independent acceptance on EHPC follows exports. GPU0 yearD/GPU1 original+deferred full queues untouched.',
              utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=p.pid, device=0,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), input_sha256=sha(r / 'input.npz'), controls_sha256=controls,
              independent_acceptance='pending EHPC PBS', free_gpu0_memory_mib=int(free))
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps(launch))

from pathlib import Path
import dataclasses
import hashlib
import json
import os
import pickle
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-resume-k78-inspection-a'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(a) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in manifest.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
old, new = b / 'qia-fresh-phase-numpy-week-a', b / 'qia-fresh-phase-numpy-year-b'
old_report = json.loads((old / 'trajectory/report.json').read_text())
old_receipt = json.loads((old / 'receipt.json').read_text())
assert (old / 'pbs-exit.txt').read_text().strip() == '0' and old_receipt['returncode'] == 0
assert sha(old / 'trajectory/report.json') == old_receipt['report_sha256'] and old_report['steps_completed'] == 336
checks = []
def equal(x, y, name):
    assert type(x) is type(y), name
    if isinstance(x, np.ndarray):
        assert x.dtype == y.dtype and x.shape == y.shape and x.tobytes() == y.tobytes(), name
        checks.append(dict(path=name, kind='array', dtype=str(x.dtype), shape=x.shape))
    elif dataclasses.is_dataclass(x):
        for field in dataclasses.fields(x):
            equal(getattr(x, field.name), getattr(y, field.name), name + '/' + field.name)
    elif isinstance(x, (tuple, list)):
        assert len(x) == len(y), name
        for i, (v, w) in enumerate(zip(x, y)):
            equal(v, w, name + '/' + str(i))
    elif isinstance(x, dict):
        assert x.keys() == y.keys(), name
        for key in x:
            equal(x[key], y[key], name + '/' + key)
    else:
        if isinstance(x, (float, np.floating)):
            assert np.asarray(x).dtype == np.asarray(y).dtype and np.asarray(x).tobytes() == np.asarray(y).tobytes(), name
        else:
            assert x == y, name
        checks.append(dict(path=name, kind='scalar'))
old_state = old / 'trajectory' / old_report['checkpoint_file']
new_state = new / 'trajectory' / old_report['checkpoint_file']
assert sha(old_state) == old_report['checkpoint_sha256']
equal(pickle.loads(old_state.read_bytes()), pickle.loads(new_state.read_bytes()), 'state-initial-net-bounds-maxima-index')
with np.load(old / 'trajectory' / old_report['model_npz'], allow_pickle=False) as x, np.load(new / 'trajectory' / old_report['model_npz'], allow_pickle=False) as y:
    assert x.files == y.files
    for name in x.files:
        equal(x[name], y[name], 'trace336/' + name)
live = json.loads((new / 'trajectory/report.json').read_text())
for name in ['forcing_npz_sha256', 'forcing_manifest_sha256', 'configuration_sha256', 'source_sha256', 'initial_state', 'steps_requested']:
    assert live[name] == old_report[name], name
device = b / 'k78-current-b/device'
with np.load(device / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
fields = {}
for backend in ['cuda32', 'jax32']:
    with np.load(device / backend / 'output.npz', allow_pickle=False) as z:
        row = dict(z)
    selected = {n: row[n][3].tolist() for n in row if n.startswith('surface/') and any(token in n for token in ['root_uptake', 'ground_vapor', 'thermal_snow_count', 'ground_nonshortwave', 'surface_temperature'])}
    selected['thermal_snow_cells'] = row['surface/thermal_snow_cells'][3].tolist()
    selected['thermal_soil_cells'] = row['surface/thermal_soil_cells'][3].tolist()
    fields[backend] = selected
record = dict(scope='EHPC PBS exact own successful336 continuation-state/ledger/trace audit and original K78 HaM raw input inspection only. No model source/state changes; new year current status separate from continuation equality. No original failed K78 trajectory resumed;1e-6 gate remains failed until fixed.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, resume_checks=checks,
              initial336_all_state_ledgers_and_trace_exact=True, original_week_receipt_sha256=sha(old / 'receipt.json'),
              new_year_snapshot_status=live['status'], new_year_snapshot_steps=live['steps_completed'],
              ham_original_forcing=data['forcing'][3].tolist(), ham_original_snow=data['a0'][3].tolist(),
              ham_original_soil=data['a1'][3].tolist(), ham_original_properties=data['a2'][3].tolist(),
              ham_original_options=data['a3'][3].tolist(), ham_actual_gpu_outputs=fields,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == v for n, v in manifest.items()))
(r / 'inspection.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: record[k] for k in ['pbs_job', 'initial336_all_state_ledgers_and_trace_exact', 'new_year_snapshot_status', 'new_year_snapshot_steps', 'ham_original_forcing', 'ham_original_options', 'ham_actual_gpu_outputs']}), flush=True)

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-reference-dt';assert not r.exists();r.mkdir();controls={}
for name,target in [('build_phase_reference_dt.py','build_phase_reference_dt.py'),('phase_reference_dt.pbs','phase_reference_dt.pbs'),('test_canopy_phase_weak_descent.py','definition.py')]:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/target).write_bytes(raw);controls[target]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'phase_reference_dt.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-reference-dt';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and sha(r/'canopy_phase_weak_descent.npz')==d['fixture_sha256'];a=b/'phase-reference-dt-evidence.tar.gz';assert not a.exists();items=[(p,'reference/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['dispatch_phase_reference_dt.py',Path(__file__).name])
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

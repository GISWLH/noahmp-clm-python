from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'capacity-station-final-c';r=s/'target-c'
ticket=json.loads((r/'cpu-ready.json').read_text());assert ticket['counts']==dict(tests=1009,failures=0,errors=0,skipped=0)
archive=b/'capacity-station-release-f-evidence.tar.gz';assert not archive.exists();data={}
for filename in ['launch.json','cpu-ready.json','wait.log','controller-worker.json','active-worker.json','exit.json','parent-exit.json']:
    if (r/filename).exists():data['target-c/'+filename]=(r/filename).read_bytes()
for name in ['release_capacity_station_cpu_c.py','wait_capacity_station_target_c.py','launch_capacity_station_target_c.py','control_capacity_station_target_c.py','collect_capacity_station_target_c.py']:
    data['control/'+name]=(b/name).read_bytes()
data['control/archive_capacity_station_release_f.py']=Path(__file__).read_bytes()
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual535C completeCPU1009 ticket delivered; stationGPU3 still depends on oldF actualwhole3 exit and resources. Queue/release is not device completion.',
    controller_started=(r/'controller-worker.json').exists(),actual_exit_present=(r/'parent-exit.json').exists(),
    ps=subprocess.run(['ps','-p','3802989,3802990,3850155,3864455','-o','pid,stat,etime,pcpu,rss,args'],capture_output=True,text=True).stdout)
data['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode()
with tarfile.open(archive,'w:gz') as tf:
    for filename,raw in data.items():
        info=tarfile.TarInfo(filename);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,snapshot=snapshot)))

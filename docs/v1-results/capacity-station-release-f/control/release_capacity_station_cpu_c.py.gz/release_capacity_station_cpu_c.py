from pathlib import Path
import datetime,hashlib,json,os,tarfile,xml.etree.ElementTree as ET
b=Path('/home/lhwang/work/noahmp-v1');s=b/'capacity-station-final-c';r=s/'target-c';a=b/'capacity-station-cpu-c-evidence.tar.gz'
sha=lambda raw:hashlib.sha256(raw).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text())
assert sha((s/'SOURCE_SHA256.json').read_bytes())=='609c39cc071899d0d4a3a9102babf8908fe679797337d3f9c01bc3949af03dd9'
assert len(m)==535 and all(sha((s/n).read_bytes())==h for n,h in m.items())
with tarfile.open(a) as tf:
    assert tf.extractfile('pbs-exit.txt').read().strip()==b'0';rec=json.load(tf.extractfile('receipt.json'))
    assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=1009,failures=0,errors=0,skipped=0)
    assert json.load(tf.extractfile('SOURCE_SHA256.json'))==m
    raw=tf.extractfile('cpu-full.xml').read();assert sha(raw)==rec['xml_sha256']
    cases=list(ET.fromstring(raw).iter('testcase'));assert len(cases)==1009
    assert all(all(c.find(k) is None for k in ['failure','error','skipped']) for c in cases)
path=r/'cpu-ready.json';assert not path.exists()
ticket=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='ActualEHPC307 complete1009CPU, PBS/model0 and XML/source guards; enables queued535C GPU station prerequisite only, not device pass.',
    archive_sha256=sha(a.read_bytes()),source_manifest_sha256=rec['source_manifest_sha256'],counts=rec['counts'])
temporary=path.with_suffix('.json.tmp');temporary.write_text(json.dumps(ticket,indent=2)+'\n');os.replace(temporary,path);print(json.dumps(ticket))

from pathlib import Path
import ast,gzip,hashlib,json,runpy
r=Path(__file__).resolve().parents[2];context=runpy.run_path(str(r/'outputs/v1/audit_qia_stem_checkpoint_a.py'));raw=context['raw'];sha=lambda v:hashlib.sha256(v).hexdigest();groups=['ctsm-qia-run-f','ctsm-qia-run-g','qia-stem-numpy-week-launch-a'];count=0
for group in groups:
 folder=r/'docs/v1-results'/group;d=json.loads((folder/'manifest.json').read_text())
 for item in d['artifacts']:
  assert sha((folder/item['path']).read_bytes())==item['stored_sha256'];original=raw(group,item['source']);assert sha(original)==item['source_sha256'];count+=1
  if item['source'].endswith('.py'):ast.parse(original,filename=group+'/'+item['source'])
f=json.loads(raw('ctsm-qia-run-f','configuration.json'));g=json.loads(raw('ctsm-qia-run-g','configuration.json'));week=json.loads(raw('qia-stem-numpy-week-launch-a','observation.json'))
assert f['upstream_original_bytes_unchanged'] and g['upstream_original_bytes_unchanged'] and f['official_model_returncode']==g['official_model_returncode']==233
assert next(s for s in g['stages'] if s['stage']=='topo-time-coordinate')['returncode']==0
assert g['topography_time_metadata_restore']['new_point_sha256']=='1c85bbd3021344b96dd3ddd53a63b0b690467b72de1d59c0cc86fc2a63893a6a'
assert week['steps_committed']==48 and week['original_day_archive_sha256']=='a7dfdd99e9258a626047d9361a63020563961395ef42470c53caeae9a30382b5'
d=dict(scope='Local hash/AST/evidence audit only, no local physics or pytest. F/G actual official init failures preserved, no physical integration/official science pass; own successful NumPy48 prefix continued on EHPC toward336,launch not completion. Previous checkpoint audit rechecks unchanged503 runtime files and183 physical files equal506F.',groups=groups,evidence_artifacts=count,official_f_g_model_returncodes=[233,233],original_topography_values_exactly_unchanged=True,week_launch_committed_steps=48,week_target_steps=336,original_requested_steps=17520)
(r/'docs/v1-results/qia-stem-followup-static-audit-a.json').write_text(json.dumps(d,indent=2)+'\n');(r/'docs/v1-results/qia-stem-followup-static-audit-a.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print(json.dumps(d))

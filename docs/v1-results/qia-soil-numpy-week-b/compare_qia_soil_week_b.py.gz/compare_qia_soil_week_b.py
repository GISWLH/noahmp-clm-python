"""All four exploratory weeks, with explicit solver-version differences."""
from pathlib import Path
import hashlib,json
import numpy as np
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1');gpu=base/'qia-soil-diagnostic-20261017-b';npdir=base/'qia-soil-diagnostic-20261017-a/numpy-runs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];failures=[]
for row in json.loads((gpu/'batch.json').read_text())['cases']:
    case=row['case'];folders=[gpu/'native-run'/case,npdir/case];reports=[json.loads((p/'report.json').read_text()) for p in folders]
    a,b=reports
    assert all(d['status']=='complete' and d['steps_completed']==336 for d in reports)
    for k in ('forcing_npz_sha256','forcing_manifest_sha256','configuration_sha256'):assert a[k]==b[k]
    common={k:v for k,v in b['source_sha256'].items() if k.startswith('src/')}
    diffs={k:dict(cuda=a['source_sha256'][k],numpy=v) for k,v in common.items() if a['source_sha256'][k]!=v}
    assert set(diffs)=={'src/noahmp_clm/gpu/canopy_most_surface.py','src/noahmp_clm/physics/canopy_most.py'},diffs
    paths=[p/d['model_npz'] for p,d in zip(folders,reports)]
    for p,d in zip(paths,reports):assert sha(p)==d['model_npz_sha256']
    with np.load(paths[0]) as z:x=dict(z)
    with np.load(paths[1]) as z:y=dict(z)
    for k in ('time_start','time_end'):np.testing.assert_array_equal(x[k],y[k])
    fields={}
    for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),
        ('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),
        ('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),
        ('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
        aa=x[key].astype(float)*factor+offset;bb=y[key].astype(float)*factor+offset
        if aa.ndim==1:aa=aa[:,None];bb=bb[:,None]
        instant=[compare_series(aa[:,j],bb[:,j],var) for j in range(aa.shape[1])]
        days=[[compare_series(aa[d*48:(d+1)*48,j],bb[d*48:(d+1)*48,j],var) for j in range(aa.shape[1])] for d in range(7)]
        for d,ds in enumerate(days):
            for j,m in enumerate(ds):
                if not m['bias_pass']:failures.append((case,key,d,j,'bias',m['bias']))
        if key in ('h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'):
            for j,m in enumerate(instant):
                if m['correlation_pass'] is False:failures.append((case,key,j,'r',m['r']))
        fields[key]=dict(instantaneous=instant,daily=days)
    rows.append(dict(case=case,scope='Same forcing/config; two disclosed MOST solver-source changes, not exact same-source proof',source_differences=diffs,
        source_files_unchanged=len(common)-len(diffs),metrics=fields,trace_sha256=[sha(p) for p in paths],
        numpy_seconds=b['seconds'],numpy_maximum_cumulative_m_h_c_n=b['maximum_cumulative_residual_m_h_c_n']))
result=dict(scope='Four complete uncalibrated exploratory weeks: CUDA32 with exhausted-bracket recovery vs original converged NumPy64; no observation acceptance or solver-version identity claim',
    instrument_sha256=sha(Path(__file__)),steps_each=336,cases=rows,failures=failures)
(gpu/'results/numpy-week-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
for key in rows[0]['metrics']:
    days=[m for c in rows for d in c['metrics'][key]['daily'] for m in d]
    print(key,dict(max_day_absolute=max(m['absolute_bias'] for m in days),max_day_relative_percent=max([100*abs(m['relative_bias']) for m in days if m['relative_bias'] is not None],default=None),max_instant_absolute=max(m['max_absolute_difference'] for c in rows for m in c['metrics'][key]['instantaneous'])),flush=True)
print('failures',failures,flush=True)
if failures:raise RuntimeError(failures)

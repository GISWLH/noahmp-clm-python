from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-official-latent-afc';scratch=Path(os.environ['TMPDIR'])/'portable';scratch.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'ctsm-portable-env-b.tar.gz';assert sha(a)=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(a) as tf:tf.extractall(scratch,filter='data')
env=os.environ.copy()
for key in ['PYTHONPATH','PYTHONHOME','LD_LIBRARY_PATH']:env.pop(key,None)
env.update(PATH=str(scratch/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(scratch/'lib'),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');stages=[]
for name,cmd in [('relocate',[str(scratch/'bin/python'),str(scratch/'bin/conda-unpack')]),('inspect',[str(scratch/'bin/python'),str(r/'inspect_qia_latent_components_afc.py')])]:
    start=time.monotonic();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,timeout=180);(r/(name+'.stdout.txt')).write_text(p.stdout);(r/(name+'.stderr.txt')).write_text(p.stderr);stages.append(dict(stage=name,returncode=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,p.stderr
record=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,portable_environment_sha256=sha(a),stages=stages,diagnosis_receipt_sha256=sha(r/'receipt.json'),scope='Same originalofficial portable netCDF runtime extracted only under PBS_TMPDIR, no shared/model environment edit. All component read and hard input/hash/bin checks unchanged; originalAF/AFB missingmodule failures retained separately.')
(r/'runtime-receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

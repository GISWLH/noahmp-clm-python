from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-official-latent-af';assert not r.exists();r.mkdir();controls={}
for n in ['inspect_qia_latent_components_af.py','qia_official_latent_af.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
official=b/'ctsm-qia-run-r';inputs={n:hashlib.sha256((official/n).read_bytes()).hexdigest() for n in ['configuration.json','year-boundary.json','official-year-fields.npz','case-configuration-private.tar.gz','pbs-exit.txt']}
p=subprocess.run(['qsub',str(r/'qia_official_latent_af.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,input_sha256=inputs);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,json,os,tarfile,time
import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-official-latent-afb';official=b/'ctsm-qia-run-r';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();dispatch=json.loads((r/'dispatch.json').read_text())
for n,h in dispatch['input_sha256'].items():assert sha(official/n)==h
cfg=json.loads((official/'configuration.json').read_text());assert cfg['failure'] is None and cfg['official_model_returncode']==0 and cfg['upstream_original_bytes_unchanged'] and all(v['returncode']==0 for v in cfg['stages']) and (official/'pbs-exit.txt').read_text().strip()=='0'
audit=json.loads((official/'year-boundary.json').read_text());assert sha(official/'official-year-fields.npz')==audit['fields_sha256']
declared={n:v for n,v in cfg['model_outputs'].items() if '.clm2.h0.' in n and n.endswith('.nc')};assert declared
base=Path(os.environ['TMPDIR'])/'history';base.mkdir();files={}
with tarfile.open(official/'case-configuration-private.tar.gz') as tf:
    for item in tf:
        prefix='output/case/run/'
        if not item.isfile() or not item.name.startswith(prefix) or item.name[len(prefix):] not in declared:continue
        name=item.name[len(prefix):];p=base/name;assert p.parent==base;p.write_bytes(tf.extractfile(item).read());assert sha(p)==declared[name]['sha256'];files[name]=p
assert set(files)==set(declared)
mandatory=['FCEV','FCTR','FGEV','EFLX_LH_TOT','QFLX_EVAP_TOT','FSH','FSA','FIRA','FGR','RAIN','SNOW','TLAI','TSAI','TG']
optional=['QFLX_EVAP_VEG','QFLX_TRAN_VEG','QFLX_EVAP_GRND','QFLX_DEW_GRND','QFLX_DEW_SNOW','QFLX_DEW_VEG','H2OCAN','TV','ELAI','FSUN','BTRAN','BTRAN2','FPSN','LAISUN','LAISHA']
parts={};bounds=[];metadata={};source=[];availability={};available_optional=None
for name,p in sorted(files.items()):
    with Dataset(p) as nc:
        assert nc['time'].units=='days since 2002-12-31 16:00:00';raw=np.asarray(nc['time_bounds'][:],float)*86400.;assert abs(raw-np.rint(raw)).max()<.01;bounds.append(np.rint(raw).astype(np.int64))
        availability[name]={n:n in nc.variables for n in mandatory+optional};assert all(n in nc.variables for n in mandatory)
        available={n for n in optional if n in nc.variables}
        if available_optional is None:available_optional=available
        else:assert available_optional==available
        for n in mandatory+sorted(available):
            v=nc[n];a=np.ma.asarray(v[:]);assert not np.any(np.ma.getmaskarray(a)) and np.isfinite(a).all(),n;parts.setdefault(n,[]).append(np.asarray(a).reshape(len(raw),-1));metadata[n]=dict(units=getattr(v,'units',None),long_name=getattr(v,'long_name',None),dimensions=list(v.dimensions),dtype=str(v.dtype))
    source.append(dict(file=name,sha256=sha(p),samples=len(raw)))
allbounds=np.concatenate(bounds);order=np.argsort(allbounds[:,0],kind='stable');allbounds=allbounds[order];valid=(allbounds[:,0]>=0)&(allbounds[:,1]<=480*1800);expected=np.arange(480)[:,None]*1800+[[0,1800]];assert np.array_equal(allbounds[valid],expected)
values={n:np.concatenate(a)[order][valid] for n,a in parts.items()}
with np.load(official/'official-year-fields.npz',allow_pickle=False) as z:
    common=sorted(set(values).intersection(z.files))
    for n in common:np.testing.assert_array_equal(values[n],z[n][:480],err_msg=n)
np.savez_compressed(r/'official-latent-first480.npz',**values,time_bounds_seconds=expected)
total=values['EFLX_LH_TOT'].astype(float);components=[values[n].astype(float) for n in ['FCEV','FCTR','FGEV']];residual=sum(components)-total;bound=8.*np.finfo(np.float32).eps*np.maximum(abs(total)+sum(abs(x) for x in components),1.)
daily=[]
for day in range(10):
    q=slice(48*day,48*(day+1));row=dict(day=day+1,mean_latent_wm2={n:float(values[n][q].mean(dtype=float)) for n in ['FCEV','FCTR','FGEV','EFLX_LH_TOT']},precipitation_mm=float((values['RAIN'][q].astype(float)+values['SNOW'][q].astype(float)).sum()*1800.),et_mm=float(values['QFLX_EVAP_TOT'][q].astype(float).sum()*1800.))
    row['available_mass_components_mm']={n:float(values[n][q].astype(float).sum()*1800.) for n in ['QFLX_EVAP_VEG','QFLX_TRAN_VEG','QFLX_EVAP_GRND'] if n in values};daily.append(row)
record=dict(diagnosis_complete=True,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,source_history=source,reference_full_fields_sha256=audit['fields_sha256'],reference_fields_common_exact=common,availability=availability,variable_metadata=metadata,output_sha256=sha(r/'official-latent-first480.npz'),component_sum_minus_total_maximum_absolute_wm2=float(abs(residual).max()),component_sum_within_history_rounding=bool(np.all(abs(residual)<=bound)),daily=daily,scope='Read actualoriginalofficialR history, exactpositive first480bins fixed independently from scoring, allFCEV/FCTR/FGEV and available mass components plus rawforcing/stores retained. Verify originaldeclaredNC hashes and everycommonfield exact to priorofficialyear. No inferred unavailablefield, no model/source edit or rerun, no scientific acceptance or causal attribution yet.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True)

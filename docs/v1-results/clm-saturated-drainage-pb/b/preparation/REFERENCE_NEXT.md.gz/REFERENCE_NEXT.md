# Remaining pinned frozen/perched comparison

PB's independent continuous ODE covers homogeneous unfrozen drainage. It is
not a substitute for the following still-unexecuted frozen/perched reference.

The smallest useful next fixture calls the actual pinned official
`ThetaBasedWaterTable`, `PerchedWaterTable`, `PerchedLateralFlow` and
`LateralFlowPowerLaw` from an isolated build at commit
`fdfc03a0abec838ec0b66663a6a2f5e619cd2611`. Do not translate their discrete
algorithm into a second Python implementation and call it independent.
First check whether the existing pinned build exposes a component harness;
otherwise a small caller plus minimal official type allocation is required.
The caller must not modify the official routines or any active case.

Supply matched homogeneous soil geometry, bedrock, retention, slope, Ksat,
actual liquid/ice masses and temperatures. Use PB's decoded phase once to
define the fixture's identical input masses, without asking the official
hydraulic stage to recreate PB's enthalpy equilibrium. Record input hashes,
actual official build/source identity, call order, origflag=0, units, dt,
both diagnosed levels, frost depth, every layer's liquid before/after,
QDRAI and perched outflow. Preserve the ordinary main/perched distinction.

Minimal cases: (1) first-layer crossing above a frost barrier; (2) crossing
inside a deeper layer; (3) uniform ice fraction; (4) sharply contrasting ice
fractions around the front/barrier; (5) available-liquid shortage; (6) no
perched body because main table is above frost; (7) wholly wet prefix and
equal first-pair saturation, recording any official degenerate output.
Use dt=1800, 900, 450 and 225 s for the finite-rate cases. Each isolated call
starts from the same matched stocks: this separates a one-step component
comparison from an unimplemented coupled Richards trajectory.

Report official-vs-PB diagnostic depths, each layer's change and final stock,
and integrated outlet mass. Nonzero quantities use <=10% relative error;
near-zero layer changes need a declared absolute mass/depth tolerance, never
division by zero. First compare raw numbers before declaring an acceptance
tolerance justified. PB's main front and final theta proxy remain separate.

The comparison must quantify these known differences, not hide them in an
aggregate budget: continuous integral Sy versus discrete local Sy; overlap
versus whole-layer and adjacent-layer ice weighting; perched withdrawal
starting layer and local availability semantics; actual enthalpy-carrying
phase re-equilibration versus a hydraulic routine holding ice fixed; all-wet
prefix surface bound versus unguarded extrapolation. In particular, the
pinned perched stage can withdraw from a different layer than PB; its layer
stock error is presently **unmeasured**, even if total flux is small.

If these cases exceed 10%, revise the isolated component semantics or retain
an explicit prototype limitation. No existing annual bias, synthetic hard
budget or geometry-only result authorizes closing the hydrology gap. No new
aquifer WA, side-to-side coupling or station calibration is included.

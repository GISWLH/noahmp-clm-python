"""Flatten two actually closed PB jobs; do not duplicate the unchanged NM source."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname() == 'manager'
BASE = Path('/tmp/noahmp-clm-saturated-drainage-pb-b')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
data, records = {}, []
for label, dirname, job, code in [('a', 'noahmp-clm-saturated-drainage-pb', '1605.manager', 1),
                                 ('b', 'noahmp-clm-saturated-drainage-pb-b', '1606.manager', 0)]:
    root = Path('/tmp') / dirname
    qstat = subprocess.check_output(['qstat', '-xf', job])
    text = qstat.decode()
    assert re.search(r'^\s*job_state = F\s*$', text, re.M)
    assert re.search(r'^\s*Stageout_status = 0\s*$', text, re.M)
    assert int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', text, re.M).group(1)) == code
    for name in ['result.tar.gz', 'pbs-exit.txt']:
        remote_hash = subprocess.check_output(['ssh', 'compute002', 'sha256sum', str(root / name)]).decode().split()[0]
        if not (root / name).exists():
            subprocess.run(['scp', 'compute002:' + str(root / name), str(root / name)], check=True)
        assert sha((root / name).read_bytes()) == remote_hash
    assert int((root / 'pbs-exit.txt').read_text()) == code
    with tarfile.open(root / 'result.tar.gz') as archive:
        members = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in archive if m.isfile()}
    receipt = json.loads(members['receipt.json'])
    assert receipt['pbs_job'] == job and receipt['node'] == 'compute002'
    assert int(members['worker-exit.txt']) == code and receipt['pytest_parent_returncode'] == code
    manifest = json.loads(members['source/SOURCE_SHA256.json'])
    assert len(manifest) == 584
    assert all(sha(members['source/' + n]) == h for n, h in manifest.items())
    assert sha(members['source/SOURCE_SHA256.json']) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    for name, raw in members.items():
        if not name.startswith('source/'):
            data[label + '/' + name] = raw
    data[label + '/original-result-members.json'] = (json.dumps(
        {n: dict(sha256=sha(v), bytes=len(v), included_in_flat_package=not n.startswith('source/'))
         for n, v in members.items()}, indent=2) + '\n').encode()
    for name in ['dispatch.json', 'stage-inventory.json', 'qsub.stdout.txt', 'qsub.stderr.txt',
                 'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt',
                 'pbs-exit.txt']:
        data[label + '/scheduler/' + name] = (root / name).read_bytes()
    output = root / 'pbs-output.log'
    data[label + '/scheduler/pbs-output-status.json'] = (json.dumps(dict(
        exists=output.exists(), note='Actual pytest/controller stdout and stderr retained separately; scheduler may omit an empty output file.'), indent=2) + '\n').encode()
    if output.exists():
        data[label + '/scheduler/pbs-output.log'] = output.read_bytes()
    data[label + '/scheduler/actual-qstat.txt'] = qstat
    diagnostics = []
    for line in members['pytest.stdout.txt'].decode().splitlines():
        if 'PB_DIAGNOSTIC ' in line:
            diagnostics.append(json.loads(line.split('PB_DIAGNOSTIC ', 1)[1]))
    data[label + '/all-printed-diagnostics.json'] = (json.dumps(diagnostics, indent=2) + '\n').encode()
    if label == 'a':
        assert b'No module named pytest' in members['pytest.stderr.txt'] and not receipt['passed']
    else:
        assert receipt['passed'] and receipt['tests'] == 18 and receipt['failures'] == receipt['errors'] == 0
        assert receipt['source_and_controls_unchanged'] and b'18 passed' in members['pytest.stdout.txt']
    records.append(dict(label=label, job=job, actual_job_state='F', actual_exit=code, Stageout_status=0,
        receipt=receipt, complete_raw_result_archive=str(root / 'result.tar.gz'),
        complete_raw_result_sha256=sha((root / 'result.tar.gz').read_bytes()),
        complete_raw_result_members=len(members), omitted_unchanged_source_members=585))
assert data['a/preparation/saturated_drainage_pb.py'] == data['b/preparation/saturated_drainage_pb.py']
assert data['a/preparation/test_saturated_drainage_pb.py'] == data['b/preparation/test_saturated_drainage_pb.py']
data['source-reference.json'] = (json.dumps(dict(
    archive='climatology-final-candidate-nm-source.tar.gz',
    archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',
    source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
    omitted_duplicate_source_bytes_only=True,
    full_source_sha_verified_in_each_original_result=True,
    note='Original complete result archives remain on manager and compute002; per-member exact identity retained. Unchanged NM source is already a separate fixed artifact.'), indent=2) + '\n').encode()
data['closed-runs.json'] = (json.dumps(records, indent=2) + '\n').encode()
data['archive_saturated_drainage_pb.py'] = Path(__file__).read_bytes()
data['artifact-inventory.json'] = (json.dumps({n:dict(sha256=sha(v), bytes=len(v)) for n,v in data.items()}, indent=2) + '\n').encode()
archive = BASE / 'clm-saturated-drainage-pb-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for name, raw in sorted(data.items()):
        item = tarfile.TarInfo(name); item.size = len(raw)
        tar.addfile(item, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert {m.name:tar.extractfile(m).read() for m in tar} == data
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
    artifacts=len(data), actual_jobs=['1605.manager:F1:Stageout0', '1606.manager:F0:Stageout0'],
    tests=18, unchanged_tests_after_environment_failure=True,
    scientific_acceptance=False, official_frozen_perched_reference_passed=False,
    scope='PB isolated NumPy drainage prototype: original pre-test missing-pytest failure and environment-only retry; actual 18 synthetic tests, continuous unfrozen ODE/layer inventories and hard water/heat budgets. Known official ice-weight/donor-layer differences remain to be corrected and compared. No production, station, annual, GPU or complete CLM-physics pass.')
(BASE / 'clm-saturated-drainage-pb-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

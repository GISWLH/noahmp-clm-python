# PB soil-contained saturated and perched drainage — prepared only

This is an isolated NumPy development component. It is **not installed in the
production driver**, is not a replacement for VIC/ARNO, and does not change any
active annual trajectory, cold state, observational data, calibration protocol,
or GPU control. No physical or numerical test has run yet. Root review precedes
an isolated EHPC PBS test. Windows work is restricted to text/AST/hash checks.

The gap being addressed is soil-contained water-table diagnosis and actual
subsurface liquid outflow. There is no independent aquifer WA, cross-column
groundwater exchange, river routing, bottom recharge, irrigation, or new water
source. Current official R has no active aquifer and its observed annual QDRAI
is not a calibration target for this module. An eventual production capability
requires reference validation, JAX/CUDA synchronization and a new trajectory.

## Equations and source provenance

Primary source read on 2026-10-25:

- [CLM5.0 technical note, hydrology](https://escomp.github.io/CTSM/release-clm5.0/tech_note/Hydrology/CLM50_Tech_Note_Hydrology.html),
  sections 2.7.3--2.7.5, equations 2.7.106--110; zero vertical bottom flux is
  distinct from the later removal of subsurface runoff.
- [Pinned official source for semantic/unit checking only](https://raw.githubusercontent.com/ESCOMP/CTSM/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/src/biogeophys/SoilHydrologyMod.F90).
  No Fortran implementation was copied or translated. It clarifies the first
  soil-interface convention, relative saturation threshold, degree-to-radian
  conversion, explicit yield floor, and source-stock units.

Let z be positive depth in metres, b the band bottom, and S_y dimensionless
specific yield. The baseflow rate is

    q = ice_factor * K_baseflow * tan(slope) * (b-z).

PB's K_baseflow is explicitly **mm water / s / m**, q is **kg/m2/s**, numerically
mm water/s. Its default .001 reproduces the numerical convention of the original
R input; it is not a station fit or universally validated parameter. If q were
expressed in m/s, this coefficient would instead be 1e-6 /s. The exponent is 1;
there is no unsupported arbitrary-power unit convention.

The perched rate is

    q = 1000 * k_perch * sin(slope) * mean(ice_factor_i * Ksat_i) * (b-z).

Here k_perch is **1/m**, default 1e-5; Ksat is **m/s** from the existing soil
parameters. The mean is weighted by the physical overlap of each soil layer
with the band. Slope is always radians. The factor 1000 converts water depth
in metres to kg/m2. All parameter values are explicit, independently reviewable
inputs; nothing is fitted to an unfinished annual result.

The public yield relation is

    S_y(z) = max(S_y_min, porosity * [1-(1+z/suction)^(-1/B)]).

Suction is positive metres, B is dimensionless. The default floor .02 follows
the pinned model's numerical convention and avoids a singular z=0 ODE. It is
not additional water. Tests separately cover its active and inactive domains.

For a front moving from z_a to z_b inside one layer, the removal is

    M_i = 1000 * integral[z_a,z_b] S_y(z) dz  [kg/m2].

The integral is evaluated from an independently derived analytic primitive,
split at the floor transition. A bounded inverse finds the new front from the
actual removed mass. Traversal is top to bottom through actual layers; it never
uses liquid-proportional allocation or skips an unavailable front layer to
draw from a deeper layer. At a liquid shortage it reports the unfulfilled
request and stops that front. There is no negative-water repair or borrowing.

## Diagnostic and stock definitions

`diagnose_water_tables(soil, parameters)` consumes the actual existing
`SoilEnthalpyState`. Total-volume saturation is
`(liquid/1000 + ice/917)/(layer_thickness * porosity)`. It is an explicit physical
volume diagnostic, not a change to the existing state's water-equivalent pore
capacity. Raw ratios above one are reported; no stock is clipped. The ice
impedance fraction is bounded at one, as a coefficient only.

The main level is found from the deepest relative-saturation crossing of .9
above the specified bedrock. It preserves the pinned first-layer-interface
convention: an entirely saturated column, or a crossing in the first layer,
uses the first interface. A dry bottom layer gives no saturated thickness.
This is a **theta proxy**, not a zero-pressure hydraulic head. There is no
extra prognostic water-table stock.

Bedrock must coincide with an existing soil-layer interface. Layers beneath
it are untouched, including their water and enthalpy. Partially cut cells are
rejected rather than assigned an invented split. The current state has one
homogeneous `SoilParams` object; heterogeneous per-layer retention is not
claimed by this component.

Frost is the shallowest transition from a layer warmer than 273.15 K to a
layer at or below 273.15 K; its depth is that frozen layer's centre. No invented
ice-fraction threshold is introduced. There is at most one separate perched
band, ending at this frost depth. A main saturated body that already intersects
the frost level suppresses a duplicate perched outlet. Additional transitions
are counted and reported, not silently advertised as multiple perched stores.
The perched crossing interpolates even between the first two layer centres;
it does not inherit the main-table first-interface exception. If the entire
prefix exceeds the threshold, no crossing is bracketed and PB uses the surface
bound, 0 m. This is a declared degenerate-case difference from the pinned
routine's unguarded first-pair extrapolation and awaits official reference
comparison; an equal saturated first pair cannot define a unique extrapolation.

Main ice impedance uses 10^(-6 * overlap-weighted ice-pore fraction). Perched
conductivity averages layerwise impeded Ksat over the band. Only diagnosed
liquid above the explicit .01 kg/m2 per-layer reserve is removable. The reserve
is never added to a dry layer. `withdraw_liquid` is reused unchanged to remove
each parcel's fusion plus sensible enthalpy at the actual donor temperature.
Subsequent phase equilibrium may change ice/liquid partition; that is distinct
from extracting an ice parcel.

`advance_saturated_band` is an explicitly exposed local physics/test API. Its
front argument must not be misrepresented as an independently observed water
table. It retains that front throughout one drainage interval, integrates the
rate with adaptive full-step/two-half-step error estimation, and accepts the
two half steps. A separate remaining-band-storage fraction limit prevents a
full trial and both half trials reaching the same storage cap from falsely
implying zero truncation error. Its absolute allowance is the explicit water
integration tolerance. Temperature changes are bounded by substepping. It returns
the migrating front separately from the soil state.

`drain_saturated_soil` diagnoses its own initial bands, drains perched water
first, rediagnoses main geometry from the actual resulting soil, then applies
main drainage. The returned initial theta level, migrated Sy front and final
rediagnosed theta level are distinct fields. Repeated diagnosis in a future
Richards/surface operator split is **not** assumed to equal continuation of
an isolated migrating front; whole-column splitting convergence remains pending.

Each band returns per-layer actual mass and enthalpy outlets, potential
frozen-rate requests, unavailable-liquid limitations, band-exhaustion
limitations, accepted/rejected substeps and water/heat residuals with bounds.
Requests and limitations sum only accepted trial quadratures; they are not
physical external inputs or an unconstrained counterfactual solution. The final
state is constructed from compensated summed transfers after each accepted
substep, with its difference from the sequential trial state checked against
roundoff bounds; final totals are independently recomputed with `math.fsum`.
The full two-band ledger is independently closed. No 10% tolerance is applied
to conservation.

## Differences and validation limits

This implements the published Sy mass/front relation by integrating Sy across
the travelled depth, rather than freezing Sy at the start of a layer transfer.
It performs adaptive temporal integration, not a literal reproduction of the
official discrete routine. Its ice weighting uses actual band overlap, rather
than the pinned routine's whole-layer/adjacent-layer averaging conventions.
For perched drainage it also uses the Sy-integrated moving front and explicit
liquid limit; the pinned routine's direct liquid-availability allocation and
subsequent water-level update are not claimed to be byte-equivalent.

These are explicit scientific comparison items. Passing a total-flux formula
or a hard budget alone will not close the module. The prepared independent
oracle checks final front position, **each layer's water inventory**, cumulative
outflow and transported heat in an unfrozen homogeneous regime. It uses SciPy
high-accuracy continuous `dz/dt=q/(1000*Sy)` plus independent adaptive quadrature,
and does not call PB rate/yield/migration routines. A constant-yield case has a
closed-form exponential solution. Step-refinement checks are for the explicit
band operator, not a claim about an unimplemented full-column integration.

Frozen/perched validation presently prepares physical-unit, geometry, stock
availability and hard-budget tests. A pinned official discrete/frozen reference
fixture and complete coupled-column <=10% comparison are **not yet available or
passed**. This component cannot close the full CLM hydrology gap before those
comparisons, and its documented differences must be revised if they exceed the
accepted physical-error range. No observational acceptance or new release
credit is implied by synthetic tests.

## Prepared tests and execution boundary

`test_saturated_drainage_pb.py` has 18 test functions: invalid inputs and
geometry; independent theta cases; Sy quadrature/floor/B=1; Decimal rate units;
analytic front/layer heat; continuous ODE front/layer stocks/outflow; timestep
refinement; zero-water and zero-slope identities; proxy versus migrating front;
frost/perched flow; no duplicate perched body; independent ice factor and liquid
limits; a blocked front with deeper water; inactive layers below bedrock; large
dt exhaustion; a negative control against full/half trials falsely agreeing
at a storage cap; immutability and a real substep-budget failure. The file rejects
Windows and non-PBS/non-compute002 execution before importing NumPy.

After root review, a minimal isolated EHPC command is:

```sh
PYTHONPATH="$TMPDIR/source/src:$TMPDIR/controls" \
  /home/zhangyq/venvs/noahmp-closeout/bin/python -m pytest \
  -q -s "$TMPDIR/controls/test_saturated_drainage_pb.py"
```

Source must be unpacked from the fixed NM archive specified in `BINDINGS.json`
and raw hashes verified first. Preparation includes no launcher, PBS submission,
GPU code, model run, source patch or working-state initialization for any site.
The future worker must preserve complete stdout, actual parent status and final
PBS state; numerical diagnostics are printed with `PB_DIAGNOSTIC` labels.

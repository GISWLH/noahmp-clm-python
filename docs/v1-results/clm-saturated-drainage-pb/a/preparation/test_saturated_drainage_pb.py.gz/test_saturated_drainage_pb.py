"""Prepared physics tests. Execute only in an isolated EHPC PBS compute job."""
import os
import socket

if os.name == 'nt' or not os.environ.get('PBS_JOBID') or not socket.gethostname().startswith('compute002'):
    raise RuntimeError('PB numerical tests require the authorized EHPC compute002 PBS job')

from dataclasses import replace
from decimal import Decimal, localcontext
import json
import math

import numpy as np
import pytest
from scipy.integrate import quad, solve_ivp

from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
from noahmp_clm.physics.snowpack import TF, CW, LF
import saturated_drainage_pb as pb


def soil(theta=.45, temperature=290., dz=(.5, .5, .5, .5), **kwargs):
    dz = np.asarray(dz, float)
    p = SoilParams(**kwargs)
    water = np.broadcast_to(np.asarray(theta, float), dz.shape) * 1000. * dz
    t = np.broadcast_to(np.asarray(temperature, float), dz.shape)
    enthalpy = enthalpy_and_capacity(water, t, dz, p)[0]
    return SoilEnthalpyState(water, enthalpy, dz, p)


def emit(name, **values):
    print('PB_DIAGNOSTIC ' + json.dumps(dict(test=name, **values), allow_nan=False), flush=True)


def budgets(d):
    assert abs(d['water_residual_kg_m2']) <= d['water_bound_kg_m2']
    assert abs(d['energy_residual_j_m2']) <= d['energy_bound_j_m2']


def independent_oracle(initial, front, bottom, duration, parameters):
    """Continuous Sy ODE + separate adaptive quadrature for each layer.

    Does not call PB yield, integral, diagnosis, rate, migration or integrator.
    This oracle is restricted to homogeneous unfrozen, unlimited liquid cases.
    """
    p = initial.params
    def sy(z):
        return max(parameters.minimum_specific_yield,
                   p.smcmax * (1. - (1. + z / p.saturated_suction_m) ** (-1. / p.bexp)))
    coefficient = parameters.baseflow_mm_s_per_m * math.tan(parameters.slope_radians)
    def rhs(_, y):
        return [coefficient * max(bottom - y[0], 0.) / (1000. * sy(y[0]))]
    answer = solve_ivp(rhs, (0., duration), [front], method='DOP853', rtol=2.e-12, atol=2.e-13)
    assert answer.success
    z = float(answer.y[0, -1])
    edges = np.r_[0., np.cumsum(initial.dz)]
    mass = []
    for a, b in zip(edges[:-1], edges[1:]):
        lo, hi = max(float(a), front), min(float(b), z, bottom)
        mass.append(0. if hi <= lo else 1000. * quad(sy, lo, hi, epsabs=2.e-13, epsrel=2.e-12)[0])
    return z, np.asarray(mass)


def test_parameter_and_geometry_rejections_are_explicit():
    for args in ({'slope_radians': True}, {'baseflow_mm_s_per_m': float('nan')},
                 {'bedrock_depth_m': -1.}, {'slope_radians': math.pi / 2.},
                 {'minimum_specific_yield': 0.}, {'retained_liquid_kg_m2': -1.}):
        with pytest.raises(ValueError):
            pb.DrainageParameters(**dict(dict(bedrock_depth_m=2., slope_radians=.1), **args))
    s = soil()
    with pytest.raises(ValueError, match='interface'):
        pb.diagnose_water_tables(s, pb.DrainageParameters(1.1, .1))
    with pytest.raises(ValueError):
        pb.drain_saturated_soil(s, 0., pb.DrainageParameters(2., .1))
    with pytest.raises(ValueError):
        pb.diagnose_water_tables(s, pb.DrainageParameters(2., .1, minimum_specific_yield=.5))


def test_theta_proxy_has_independent_piecewise_geometry_cases():
    p = pb.DrainageParameters(2., .1)
    dry = pb.diagnose_water_tables(soil(.2), p)
    wet = pb.diagnose_water_tables(soil(.45), p)
    mixed = pb.diagnose_water_tables(soil(.45 * np.array([.2, .6, 1., 1.])), p)
    assert dry['water_table_m'] == 2.
    assert wet['water_table_m'] == .5  # explicit CLM first-interface convention
    assert mixed['water_table_m'] == pytest.approx(1.125, abs=1.e-13)
    assert mixed['saturated_thickness_m'] == pytest.approx(.875, abs=1.e-13)
    emit('theta_geometry', dry_m=dry['water_table_m'], saturated_m=wet['water_table_m'], mixed_m=mixed['water_table_m'])


def test_yield_integral_matches_independent_quad_including_floor_and_B_one():
    errors = []
    for b in (1., 1.00000001, 4., 5.5, 9.):
        for limits in ((0., .01), (0., .5), (.2, .9), (1., 2.), (2., 40.)):
            expected = quad(lambda z: max(.02, .45 * (1. - (1. + z / .355) ** (-1. / b))),
                            *limits, epsabs=1.e-11, epsrel=1.e-11)[0]
            actual = pb.integrated_yield(*limits, .45, .355, b, .02)
            errors.append(abs(actual - expected))
            assert abs(actual - expected) <= 2.e-9 * max(abs(expected), 1.)
    assert pb.specific_yield(0., .45, .355, 5.5, .02) == .02
    assert pb.integrated_yield(0., .001, .45, .355, 5.5, .02) == pytest.approx(.00002, abs=1.e-17)
    emit('yield_integral', cases=len(errors), max_absolute_m=max(errors))


def test_rate_units_against_decimal_not_a_SI_factor_1000_error():
    s = soil()
    p = pb.DrainageParameters(2., math.atan(.1))
    rate, d = pb.potential_outflow(s, .5, 2., 'saturated', p)
    with localcontext() as ctx:
        ctx.prec = 40
        expected = float(Decimal('.001') * Decimal('.1') * Decimal('1.5'))
    assert rate == pytest.approx(expected, rel=2.e-15)
    assert rate == pytest.approx(1000. * 1.e-6 * .1 * 1.5, rel=2.e-15)
    assert d['ice_factor'] == 1.
    emit('rate_units', actual_kg_m2_s=rate, independent_kg_m2_s=expected)


def test_constant_yield_analytic_exponential_and_layer_enthalpy():
    s = soil(temperature=[285., 289., 293., 297.])
    p = pb.DrainageParameters(2., math.atan(.1), minimum_specific_yield=.44)
    duration, start = 3.e6, .2
    c = pb.IntegrationControls(maximum_step_seconds=100000., relative_tendency_tolerance=.002)
    after, z, d = pb.advance_saturated_band(s, duration, start, 2., 'saturated', p, c)
    exact_z = 2. - (2. - start) * math.exp(-.001 * .1 * duration / (1000. * .44))
    edges = np.r_[0., np.cumsum(s.dz)]
    expected_mass = 440. * np.maximum(0., np.minimum(edges[1:], exact_z) - np.maximum(edges[:-1], start))
    expected_heat = expected_mass * (LF + CW * (np.array([285., 289., 293., 297.]) - TF))
    mass_error = abs(d['layer_mass_kg_m2'] - expected_mass)
    assert abs(z - exact_z) <= .01 * exact_z
    assert np.all(mass_error <= np.maximum(.002, .01 * expected_mass))
    np.testing.assert_allclose(after.temperature, s.temperature, rtol=0., atol=2.e-8)
    assert np.all(abs(d['layer_enthalpy_j_m2'] - expected_heat) <= np.maximum(1., .01 * abs(expected_heat)))
    budgets(d)
    emit('analytic_constant_yield', actual_front_m=z, reference_front_m=exact_z,
         actual_layer_mass=d['layer_mass_kg_m2'].tolist(), reference_layer_mass=expected_mass.tolist(),
         max_mass_error_kg_m2=float(mass_error.max()), water_residual=d['water_residual_kg_m2'],
         water_bound=d['water_bound_kg_m2'], heat_residual=d['energy_residual_j_m2'], heat_bound=d['energy_bound_j_m2'])


def test_variable_yield_ode_checks_water_table_each_layer_and_total():
    s = soil()
    p = pb.DrainageParameters(2., math.atan(.2), baseflow_mm_s_per_m=.003)
    start, duration = .5, 100000.
    reference_z, reference_mass = independent_oracle(s, start, 2., duration, p)
    after, z, d = pb.advance_saturated_band(s, duration, start, 2., 'saturated', p)
    error = abs(d['layer_mass_kg_m2'] - reference_mass)
    assert abs(z - reference_z) <= .01 * reference_z
    assert np.all(error <= np.maximum(.002, .01 * reference_mass))
    np.testing.assert_allclose(after.water, s.water - reference_mass, rtol=.01, atol=.002)
    assert abs(d['drained_kg_m2'] - float(reference_mass.sum())) <= .01 * float(reference_mass.sum())
    budgets(d)
    emit('continuous_ODE', actual_front_m=z, reference_front_m=reference_z,
         actual_layer_mass=d['layer_mass_kg_m2'].tolist(), reference_layer_mass=reference_mass.tolist(),
         actual_soil_water=after.water.tolist(), reference_soil_water=(s.water - reference_mass).tolist(),
         actual_total_kg_m2=d['drained_kg_m2'], reference_total_kg_m2=float(reference_mass.sum()),
         max_layer_error_kg_m2=float(error.max()))


def test_decreasing_time_steps_converge_to_independent_continuous_ODE():
    s = soil()
    p = pb.DrainageParameters(2., math.atan(.1))
    duration, start = 100000., .5
    expected_z, expected_mass = independent_oracle(s, start, 2., duration, p)
    errors, layer_errors = [], []
    for step in (10000., 2500., 625.):
        controls = pb.IntegrationControls(maximum_step_seconds=step, relative_tendency_tolerance=.1,
                    water_absolute_tolerance_kg_m2=1., energy_absolute_tolerance_j_m2=1.e8,
                    front_absolute_tolerance_m=1.)
        _, z, d = pb.advance_saturated_band(s, duration, start, 2., 'saturated', p, controls)
        errors.append(abs(z - expected_z))
        layer_errors.append(float(np.max(abs(d['layer_mass_kg_m2'] - expected_mass))))
        budgets(d)
    assert errors[2] < errors[1] < errors[0]
    assert layer_errors[2] < layer_errors[1] < layer_errors[0]
    assert errors[-1] < .01 * expected_z
    emit('time_convergence', maximum_step_seconds=[10000., 2500., 625.],
         front_errors_m=errors, layer_errors_kg_m2=layer_errors)


def test_dry_column_is_exact_identity_and_does_not_receive_water_floor():
    s = soil(0.)
    after, d = pb.drain_saturated_soil(s, 86400., pb.DrainageParameters(2., .1))
    np.testing.assert_array_equal(after.water, s.water)
    np.testing.assert_array_equal(after.enthalpy, s.enthalpy)
    assert d['drained_kg_m2'] == 0.
    budgets(d)


def test_zero_slope_is_exact_identity_for_wet_column():
    s = soil()
    after, d = pb.drain_saturated_soil(s, 86400., pb.DrainageParameters(2., 0.))
    np.testing.assert_array_equal(after.water, s.water)
    np.testing.assert_array_equal(after.enthalpy, s.enthalpy)
    assert d['drained_kg_m2'] == 0.
    budgets(d)


def test_saturated_column_keeps_theta_proxy_and_migrating_front_distinct():
    s = soil()
    after, d = pb.drain_saturated_soil(s, 1800., pb.DrainageParameters(2., .1))
    assert d['diagnosis_before']['water_table_m'] == .5
    assert d['bands'][0]['migrated_front_m'] > .5
    assert after.water[0] == s.water[0]
    assert d['drained_kg_m2'] > 0.
    assert not d['production_integrated'] and d['no_additional_water_reservoir']
    budgets(d)
    emit('proxy_versus_front', initial_theta_m=d['diagnosis_before']['water_table_m'],
         migrated_m=d['bands'][0]['migrated_front_m'], rediagnosed_theta_m=d['diagnosis_after']['water_table_m'])


def test_frost_perched_outlet_with_actual_liquid_and_per_layer_heat():
    s = soil(theta=[.2, .43, .43, .2], temperature=[280., 280., 270., 280.])
    p = pb.DrainageParameters(2., .2, baseflow_mm_s_per_m=0.)
    diag = pb.diagnose_water_tables(s, p)
    assert diag['frost_table_m'] == 1.25 and diag['frost_layer_index'] == 2
    assert diag['water_table_m'] == 2.
    # Independently derived crossing between the first two unfrozen centres.
    # Unlike main theta diagnosis, perched diagnosis must not snap this to .5.
    expected_perched = .25 + .5 * (.9 * .45 - .2) / (.43 - .2)
    assert diag['perched_water_table_m'] == pytest.approx(expected_perched, abs=2.e-13)
    fully_wet_prefix = soil(theta=[.45, .45, .43, .2], temperature=[280., 280., 270., 280.])
    assert pb.diagnose_water_tables(fully_wet_prefix, p)['perched_water_table_m'] == 0.
    after, d = pb.drain_saturated_soil(s, 86400., p)
    perched = d['bands'][0]
    assert perched['kind'] == 'perched' and perched['drained_kg_m2'] > 0.
    assert d['bands'][-1]['kind'] == 'saturated' and d['bands'][-1]['drained_kg_m2'] == 0.
    assert np.all(perched['layer_mass_kg_m2'] <= s.liquid + 1.e-10)
    assert after.water[-1] == s.water[-1]
    budgets(d)
    emit('frost_perched', layer_mass=d['layer_mass_kg_m2'].tolist(), layer_heat=d['layer_enthalpy_j_m2'].tolist(),
         frost_m=diag['frost_table_m'], perched_m=diag['perched_water_table_m'],
         reference_perched_m=expected_perched,
         water_residual=d['water_residual_kg_m2'], heat_residual=d['energy_residual_j_m2'])


def test_no_frost_or_connected_main_body_does_not_duplicate_perched_outlet():
    p = pb.DrainageParameters(2., .1)
    assert pb.diagnose_water_tables(soil(), p)['perched_water_table_m'] is None
    connected = soil(temperature=[280., 280., 270., 280.])
    d = pb.diagnose_water_tables(connected, p)
    assert d['water_table_m'] < d['frost_table_m']
    assert d['perched_water_table_m'] is None


def test_ice_impedance_is_independent_volume_fraction_and_never_ice_removal():
    s = soil(temperature=270.)
    p = pb.DrainageParameters(2., .1)
    actual, _ = pb.potential_outflow(s, .5, 2., 'saturated', p)
    fraction = min(1., float(s.ice[1]) / (917. * .5 * .45))
    expected = .001 * math.tan(.1) * 1.5 * 10. ** (-6. * fraction)
    assert actual == pytest.approx(expected, rel=2.e-13)
    after, _, d = pb.advance_saturated_band(s, 1800., .5, 2., 'saturated', p)
    assert np.all(d['layer_mass_kg_m2'] <= s.liquid + 1.e-10)
    np.testing.assert_allclose(s.water - after.water, d['layer_mass_kg_m2'], rtol=0., atol=1.e-12)
    budgets(d)
    emit('ice_impedance', fraction=fraction, actual_rate=actual, independent_rate=expected,
         initial_liquid=s.liquid.tolist(), layer_outflow=d['layer_mass_kg_m2'].tolist())


def test_unavailable_front_cannot_skip_to_deeper_liquid_or_create_water():
    s = soil(theta=[.45, 0., .45, .45])
    after, z, d = pb.advance_saturated_band(s, 86400., .5, 2., 'saturated', pb.DrainageParameters(2., .2))
    np.testing.assert_array_equal(after.water, s.water)
    assert z == .5 and d['drained_kg_m2'] == 0.
    assert d['unavailable_liquid_kg_m2'] == pytest.approx(d['potential_requested_kg_m2'])
    assert d['unavailable_liquid_kg_m2'] > 0.
    budgets(d)


def test_bedrock_interface_excludes_deeper_stocks_and_saturated_outlet():
    s = soil()
    after, d = pb.drain_saturated_soil(s, 86400., pb.DrainageParameters(1., .1))
    np.testing.assert_array_equal(after.water[2:], s.water[2:])
    np.testing.assert_array_equal(after.enthalpy[2:], s.enthalpy[2:])
    assert d['diagnosis_before']['active_layer_count'] == 2
    assert np.all(d['layer_mass_kg_m2'][2:] == 0.)
    budgets(d)


def test_large_dt_exhaustion_has_explicit_limited_flux_and_exact_extensive_budget():
    s = soil()
    p = pb.DrainageParameters(2., .2, baseflow_mm_s_per_m=10.)
    controls = pb.IntegrationControls(maximum_step_seconds=1.e6)
    after, z, d = pb.advance_saturated_band(s, 1.e6, .5, 2., 'saturated', p, controls)
    expected = 1000. * quad(lambda depth: max(.02, .45 * (1. - (1. + depth / .355) ** (-1. / 5.5))),
                           .5, 2., epsabs=1.e-11)[0]
    assert z == 2.
    assert d['drained_kg_m2'] == pytest.approx(expected, rel=2.e-10)
    assert d['band_exhaustion_kg_m2'] > 0.
    assert d['unavailable_liquid_kg_m2'] == 0.
    assert np.all(after.water >= 0.)
    assert d['potential_requested_kg_m2'] == pytest.approx(d['drained_kg_m2'] + d['band_exhaustion_kg_m2'])
    budgets(d)
    emit('large_dt', total_kg_m2=d['drained_kg_m2'], reference_kg_m2=expected,
         limited_kg_m2=d['band_exhaustion_kg_m2'], final_front_m=z)


def test_both_trials_reaching_cap_cannot_falsely_accept_an_inaccurate_step():
    s = soil()
    p = pb.DrainageParameters(2., math.atan(.2), baseflow_mm_s_per_m=.22, minimum_specific_yield=.44)
    duration = 40000.  # Four e-folding times; both unrestricted trials hit the cap.
    controls = pb.IntegrationControls(maximum_step_seconds=duration, relative_tendency_tolerance=.005)
    _, z, d = pb.advance_saturated_band(s, duration, .5, 2., 'saturated', p, controls)
    expected_remaining = 1.5 * math.exp(-4.)
    assert 2. - z > 0.
    assert abs((2. - z) / expected_remaining - 1.) <= .1
    assert d['rejected_substeps'] > 0
    budgets(d)
    emit('cap_false_accept_negative_control', actual_remaining_m=2. - z,
         analytic_remaining_m=expected_remaining, rejected_substeps=d['rejected_substeps'])


def test_original_state_is_immutable_and_substep_exhaustion_is_a_real_failure():
    s = soil()
    original = (s.water.tobytes(), s.enthalpy.tobytes(), s.dz.tobytes(), dict(vars(s.params)))
    p = pb.DrainageParameters(2., .2)
    pb.drain_saturated_soil(s, 1800., p)
    assert original == (s.water.tobytes(), s.enthalpy.tobytes(), s.dz.tobytes(), dict(vars(s.params)))
    with pytest.raises(RuntimeError, match='attempt budget'):
        pb.advance_saturated_band(s, 86400., .5, 2., 'saturated', p,
            replace(pb.IntegrationControls(), maximum_attempts=1, maximum_step_seconds=1.))

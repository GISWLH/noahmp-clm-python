from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-all-phase-numpy-year-c';raw=(r/'trajectory/report.json').read_bytes();d=json.loads(raw);m=json.loads((r/'SOURCE_SHA256.json').read_text());assert d['source_unchanged'] and all(m[n]==h for n,h in d['source_sha256'].items());sha=lambda raw:hashlib.sha256(raw).hexdigest();a=b/'pft-optics-ehpc-checkpoint-d-evidence.tar.gz';assert not a.exists()
q=subprocess.run(['qstat','-f','260.manager'],capture_output=True,text=True);record=dict(scope='Read-only live annual metadata snapshot. Model-reported sourcehashes matched frozenfullmanifest,not independentlogin access to computeTMPDIR. Not completedyear/spinup/scientificacceptance. CPU physics/tests remainPBSonly.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],source_unchanged=True,report_sha256=sha(raw),maximum_cumulative_MHCN=d['maximum_cumulative_residual_m_h_c_n'],qstat_returncode=q.returncode)
files=[('annual/report.json',raw),('annual/SOURCE_SHA256.json',(r/'SOURCE_SHA256.json').read_bytes()),('annual/launch.json',(r/'launch.json').read_bytes()),('annual/model.log',(r/'model.log').read_bytes()),('annual/qstat.txt',(q.stdout+q.stderr).encode()),('snapshot.json',(json.dumps(record,indent=2)+'\n').encode())]
with tarfile.open(a,'w:gz') as t:
    for n,raw in files:i=tarfile.TarInfo(n);i.size=len(raw);t.addfile(i,io.BytesIO(raw))
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,snapshot=record)))

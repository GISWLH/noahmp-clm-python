"""Stream stopped PJ closed containers to stdout; no remote filesystem writes."""
from pathlib import Path
import hashlib
import json
import os
import socket
import sys
import tarfile

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')
EXPECTED_PROGRESS = '159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'


class Reader:
    def __init__(self, stream):
        self.stream = stream; self.digest = hashlib.sha256()
    def read(self, count):
        raw = self.stream.read(count); self.digest.update(raw); return raw


class Writer:
    def __init__(self, stream):
        self.stream = stream; self.digest = hashlib.sha256(); self.bytes = 0
    def write(self, raw):
        count = self.stream.write(raw); assert count == len(raw)
        self.digest.update(raw); self.bytes += count; return count
    def flush(self):
        self.stream.flush()


def main():
    assert socket.gethostname() == 'manager' and ROOT.resolve() == ROOT
    raw = (ROOT/'PROGRESS.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_PROGRESS
    progress = json.loads(raw)
    started = json.loads((ROOT/'CONTROLLER_STARTED.json').read_bytes())
    assert not (Path('/proc')/str(started['pid'])).exists()
    fixed = json.loads((ROOT/'preparation/PJ_BINDINGS.json').read_bytes())
    expected = {}
    for case in progress['cases']:
        i = case['case_index']
        assert case['status'] == 'stopped'
        expected[f'closed/case-{i}/stop-0000048.tar.gz'] = fixed['initial_archives'][str(i)]['sha256']
        for row in case['history']:
            expected[f"closed/case-{i}/stop-{row['stop']:07d}.tar.gz"] = row['closed_archive_sha256']
    assert len(expected) == 174
    assert {p.relative_to(ROOT).as_posix() for p in (ROOT/'closed').rglob('*.tar.gz')} == set(expected)
    print(json.dumps(dict(event='stream_started', pid=os.getpid(), files=174,
        bytes=sum((ROOT/n).stat().st_size for n in expected),remote_mutations=0)), file=sys.stderr, flush=True)
    writer = Writer(sys.stdout.buffer)
    with tarfile.open(fileobj=writer, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
        for ordinal, (name, digest) in enumerate(sorted(expected.items()), 1):
            path = ROOT/name
            assert path.resolve().is_relative_to(ROOT/'closed') and not path.is_symlink()
            info = tarfile.TarInfo(name); info.size = path.stat().st_size; info.mode = 0o644
            with path.open('rb') as stream:
                reader = Reader(stream); archive.addfile(info, reader)
            assert reader.digest.hexdigest() == digest, name
            if ordinal % 10 == 0:
                print(json.dumps(dict(event='stream_progress', files=ordinal, bytes=writer.bytes)),file=sys.stderr,flush=True)
    writer.flush()
    assert (ROOT/'PROGRESS.json').read_bytes() == raw
    print(json.dumps(dict(event='stream_complete', files=174, bytes=writer.bytes,
        archive_sha256=writer.digest.hexdigest(), expected=expected,remote_mutations=0)),file=sys.stderr,flush=True)


if __name__ == '__main__':
    main()

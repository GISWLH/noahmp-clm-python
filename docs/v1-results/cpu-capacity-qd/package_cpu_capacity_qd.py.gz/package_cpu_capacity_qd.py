"""Publish existing metadata and receipts; no model, pickle or NPZ decoding."""
from pathlib import Path
import hashlib
import json
import tarfile

OUT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
pj = json.loads((OUT / 'cpu-year-status-20261026-qa/pj-manager.json').read_text())
lq = json.loads((OUT / 'cpu-year-status-20261026-qa/lq-manager.json').read_text())
print('case keys', list(pj['progress']['cases'][0]))
summary = dict(sample_utc=pj['sample_utc'],
    manager_process=pj['manager_process'],
    progress_sha256=pj['PROGRESS_sha256'],
    source_manifest_sha256=pj['progress']['source_manifest_sha256'],
    cases=pj['progress']['cases'],
    old_JN_sites=[dict(site=x['site'], actual_successful_stop=x['actual_successful_stop'],
        latest_success=x['latest_success'], pending_jobs=x['pending_jobs'],
        failure_receipts=x['failure_receipts'],
        latest_saved_report_status=x['latest_saved_report'].get('status')) for x in lq['sites']],
    numerical_execution=False, new_complete_year_credit=False,
    scope='Read-only terminal CPU-chain metadata and backed-up closed-container reclamation; no annual scoring or model execution.')
summary['reclamation'] = []
for host in ('ehpc', 'ehpc-c2'):
    root = OUT / 'pj-closed-reclamation-20261026-qa'
    receipt = json.loads((root / (host + '-exit.json')).read_text())
    record = json.loads((root / (host + '.json')).read_text())
    assert receipt['actual_ssh_exit'] == 0 and record['passed']
    assert sha((root / (host + '.json')).read_bytes()) == receipt['stdout_sha256']
    summary['reclamation'].append(dict(host=record['host'],
        closed_container_copies_removed=len(record['backed_up_containers_removed']),
        free_bytes_before=record['free_bytes_before'], free_bytes_after=record['free_bytes_after'],
        latest_parent_paths_preserved=record['latest_parent_paths_preserved'],
        raw_result_archives_deleted=record['raw_result_archives_deleted'],
        physical_state_or_input_changed=record['physical_state_or_input_changed']))
proof = json.loads((OUT / 'pj-closed-archives-20261026-qa-verified.json').read_text())
summary['backup_proof'] = proof
(OUT / 'cpu-capacity-qd-readout.json').write_text(json.dumps(summary, indent=2) + '\n')
files = [OUT / 'cpu-capacity-qd-readout.json', Path(__file__).resolve()]
for directory in ('cpu-year-status-20261026-qa', 'pj-closed-reclamation-20261026-qa'):
    files.extend(p for p in (OUT / directory).rglob('*') if p.is_file())
for pattern in ('pj-closed-archives-20261026-qa-*.json',
                'pj-archive-backup-20261026-qa*.log',
                'pj-archive-backup-20261026-qa*.json',
                'inactive-pytest-cache-41-20261026-qa*'):
    files.extend(OUT.glob(pattern))
for name in ('collect_cpu_year_status_20261026_qa.py', 'backup_pj_archives_20261026_qa.py',
             'stream_pj_closed_20261026_qa.py', 'receive_pj_closed_20261026_qa.py',
             'reclaim_pj_closed_20261026_qa.py'):
    files.append(OUT / name)
files = sorted(set(files))
assert all(p.is_file() and p.stat().st_size < 10_000_000 for p in files)
archive = OUT / 'cpu-capacity-qd-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for p in files:
        tf.add(p, arcname=p.relative_to(OUT).as_posix())
with tarfile.open(archive) as tf:
    assert len(tf.getmembers()) == len(files)
    for p in files:
        assert tf.extractfile(p.relative_to(OUT).as_posix()).read() == p.read_bytes()
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), artifacts=len(files),
    scope=summary['scope'] + ' Original 34,879,119,360-byte closed-container backup remains local outside Git; all 174 original container hashes and offsets retained.')
(OUT / 'cpu-capacity-qd-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package))

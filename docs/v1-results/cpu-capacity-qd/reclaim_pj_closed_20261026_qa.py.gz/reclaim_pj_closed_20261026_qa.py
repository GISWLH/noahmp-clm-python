"""Reclaim only verified backed-up older PJ containers; preserve all latest seeds."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
proof=json.loads((BASE/'pj-closed-archives-20261026-qa-verified.json').read_bytes())
archive=Path(proof['archive'])
assert proof['passed'] and proof['opaque_containers_verified']==174 and archive.stat().st_size==proof['archive_bytes']
assert proof['archive_sha256']=='e45de1899393b010dcc81691cd9eb86323e5e410c9d4a67ec79c4c4fffd03cf4'
with archive.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==proof['archive_sha256']
snapshot=json.loads((BASE/'cpu-year-status-20261026-qa/pj-manager.json').read_bytes())
keep={f"closed/case-{c['case_index']}/stop-{c['steps']:07d}.tar.gz":c['parent_archive_sha256'] for c in snapshot['progress']['cases']}
assert len(keep)==8 and all(proof['containers'][name]['sha256']==digest for name,digest in keep.items())
expected={name:row['sha256'] for name,row in proof['containers'].items()}
body=r'''
from pathlib import Path,PurePosixPath
import hashlib,json,os,socket
ROOT=Path('/tmp/noahmp-numpy-baseline-resume-pj')
EXPECTED=__EXPECTED__
KEEP=__KEEP__
assert ROOT.resolve()==ROOT and ROOT.is_dir() and socket.gethostname() in ('manager','compute002')
manager=socket.gethostname()=='manager'
if manager:
    assert hashlib.sha256((ROOT/'PROGRESS.json').read_bytes()).hexdigest()=='159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'
    started=json.loads((ROOT/'CONTROLLER_STARTED.json').read_bytes());assert not (Path('/proc')/str(started['pid'])).exists()
paths=list((ROOT/'closed').rglob('*.tar.gz'))
names={p.relative_to(ROOT).as_posix() for p in paths}
assert names<=set(EXPECTED) and (len(names)==174 if manager else len(names)==166)
records=[]
for p in paths:
    name=p.relative_to(ROOT).as_posix();part=PurePosixPath(name)
    assert not part.is_absolute() and '..' not in part.parts and p.resolve().is_relative_to(ROOT/'closed') and not p.is_symlink()
    with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    assert digest==EXPECTED[name]
    if name not in KEEP:records.append(dict(path=name,sha256=digest,bytes=p.stat().st_size))
if manager:assert set(KEEP)<=names
before=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
for row in records:
    path=ROOT/row['path'];assert path.resolve().is_relative_to(ROOT/'closed') and not path.is_symlink();path.unlink()
after=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
left={p.relative_to(ROOT).as_posix() for p in (ROOT/'closed').rglob('*.tar.gz')}
assert left<=set(KEEP)
if manager:assert left==set(KEEP)
print(json.dumps(dict(host=socket.gethostname(),passed=True,backed_up_containers_removed=records,
    latest_parent_paths_preserved=sorted(left),free_bytes_before=before,free_bytes_after=after,
    raw_result_archives_deleted=0,physical_state_or_input_changed=False),indent=2))
'''.replace('__EXPECTED__',repr(expected)).replace('__KEEP__',repr(keep))
out=BASE/'pj-closed-reclamation-20261026-qa';out.mkdir(exist_ok=False)
def run(host):
    child=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12',host,
        '/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'],input=body.encode(),capture_output=True,timeout=300)
    (out/(host+'.json')).write_bytes(child.stdout);(out/(host+'.stderr')).write_bytes(child.stderr)
    (out/(host+'-exit.json')).write_text(json.dumps(dict(actual_ssh_exit=child.returncode,
        script_sha256=hashlib.sha256(body.encode()).hexdigest(),stdout_sha256=hashlib.sha256(child.stdout).hexdigest()),indent=2)+'\n')
    assert child.returncode==0,child.stderr.decode()
    result=json.loads(child.stdout)
    return dict(host=host,actual_ssh_exit=child.returncode,removed=len(result['backed_up_containers_removed']),
        retained_latest=len(result['latest_parent_paths_preserved']),free_gib_before=result['free_bytes_before']/1024**3,
        free_gib_after=result['free_bytes_after']/1024**3,raw_result_archives_deleted=0)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(run,('ehpc','ehpc-c2')):print(json.dumps(result),flush=True)

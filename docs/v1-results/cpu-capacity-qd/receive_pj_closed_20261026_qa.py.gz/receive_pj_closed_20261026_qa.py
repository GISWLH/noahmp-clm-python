"""Opaque SSH archive receipt and local byte verification; no numerical decode."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
label = 'pj-closed-archives-20261026-qa'
partial = BASE/(label+'.tar.partial')
final = BASE/(label+'.tar')
log = BASE/(label+'.stderr')
assert not any(p.exists() for p in (partial, final, log))
script = (BASE/'stream_pj_closed_20261026_qa.py').read_bytes()
with partial.open('wb') as output, log.open('wb') as messages:
    child = subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc',
        '/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'], stdin=subprocess.PIPE, stdout=output, stderr=subprocess.PIPE)
    child.stdin.write(script); child.stdin.close()
    for line in child.stderr:
        messages.write(line); messages.flush()
        # Keep the terminal concise; the final expected hashes stay in the log.
        value = json.loads(line)
        print(json.dumps({k:v for k,v in value.items() if k!='expected'}), flush=True)
    status = child.wait(); output.flush(); os.fsync(output.fileno())
receipt = dict(actual_ssh_exit=status, script_sha256=hashlib.sha256(script).hexdigest(),
               remote_mutations=0, numerical_decoding=False)
(BASE/(label+'-transfer-exit.json')).write_text(json.dumps(receipt,indent=2)+'\n')
assert status == 0, status
complete = json.loads(log.read_text().splitlines()[-1])
assert complete['event'] == 'stream_complete' and partial.stat().st_size == complete['bytes']
with partial.open('rb') as stream:
    actual_sha = hashlib.file_digest(stream,'sha256').hexdigest()
assert actual_sha == complete['archive_sha256']
verified = {}
with tarfile.open(partial,mode='r:') as archive:
    for item in archive:
        assert item.isfile() and item.name in complete['expected'] and item.name not in verified
        with archive.extractfile(item) as stream:
            digest = hashlib.file_digest(stream,'sha256').hexdigest()
        assert digest == complete['expected'][item.name], item.name
        verified[item.name] = dict(bytes=item.size,sha256=digest,tar_payload_offset=item.offset_data)
assert set(verified) == set(complete['expected']) and len(verified) == 174
partial.replace(final)
receipt.update(passed=True, archive=str(final), archive_sha256=actual_sha, archive_bytes=final.stat().st_size,
               opaque_containers_verified=174, containers=verified, source_files_deleted=0)
(BASE/(label+'-verified.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='containers'}),flush=True)

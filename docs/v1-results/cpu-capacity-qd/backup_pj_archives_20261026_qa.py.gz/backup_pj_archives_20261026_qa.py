"""Copy stopped PJ archive containers to one HOME TAR; never deletes sources."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')
BASE = Path('/home/zhangyq/noahmp-v1')
DEST = BASE / 'pj-window-archive-backup-20261026-qa'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    raw = (json.dumps(value, indent=2) + '\n').encode()
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    temporary.replace(path)


class HashedReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
    def read(self, size):
        raw = self.stream.read(size); self.digest.update(raw); return raw


class HashedWriter:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
    def write(self, raw):
        count = self.stream.write(raw)
        assert count == len(raw)
        self.digest.update(raw); return count
    def tell(self):
        return self.stream.tell()
    def flush(self):
        self.stream.flush()


def main():
    assert socket.gethostname() == 'manager'
    assert ROOT.resolve() == ROOT and BASE.resolve() == BASE
    progress_raw = (ROOT / 'PROGRESS.json').read_bytes()
    progress = json.loads(progress_raw)
    started = json.loads((ROOT / 'CONTROLLER_STARTED.json').read_bytes())
    assert not (Path('/proc') / str(started['pid'])).exists()
    assert len(progress['cases']) == 8
    fixed = json.loads((ROOT / 'preparation/PJ_BINDINGS.json').read_bytes())
    expected = {}
    for case in progress['cases']:
        i = case['case_index']
        assert case['status'] == 'stopped' and case['error'].startswith('AssertionError:')
        terminal = subprocess.run(['qstat', '-xf', case['job']], capture_output=True, check=True).stdout
        assert all(re.search(rb'^\s*' + field + rb' = ' + value + rb'\s*$', terminal, re.M)
                   for field, value in ((b'job_state', b'F'), (b'Exit_status', b'0'), (b'Stageout_status', b'0')))
        expected[f'closed/case-{i}/stop-0000048.tar.gz'] = fixed['initial_archives'][str(i)]['sha256']
        for row in case['history']:
            expected[f"closed/case-{i}/stop-{row['stop']:07d}.tar.gz"] = row['closed_archive_sha256']
            expected[f"actual/case-{i}/start-{row['start']:07d}/result.tar.gz"] = row['original_result_archive_sha256']
    assert len(expected) == 340
    actual = {path.relative_to(ROOT).as_posix() for folder in ('actual', 'closed')
              for path in (ROOT / folder).rglob('*.tar.gz')}
    assert actual == set(expected)
    assert not DEST.exists() and DEST.parent == BASE
    assert os.statvfs(BASE).f_bavail * os.statvfs(BASE).f_frsize > 2 * sum((ROOT / name).stat().st_size for name in expected)
    DEST.mkdir()
    save(DEST / 'COPY_STARTED.json', dict(pid=os.getpid(), started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_progress_sha256=sha(progress_raw), files=len(expected), source_root=str(ROOT), destination=str(DEST), deletions=0))
    print(json.dumps(dict(event='copy_started', pid=os.getpid(), files=len(expected), destination=str(DEST), deletions=0)), flush=True)
    partial = DEST / 'archives.tar.partial'
    records = []
    with (DEST / 'copy-progress.jsonl').open('a', encoding='utf-8') as log, partial.open('wb') as output:
        writer = HashedWriter(output)
        with tarfile.open(fileobj=writer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, expected_sha in sorted(expected.items()):
                source = ROOT / name
                assert source.resolve().is_relative_to(ROOT) and not source.is_symlink()
                info = tarfile.TarInfo(name)
                info.size = source.stat().st_size
                info.mode = 0o644
                offset = writer.tell() + 512
                with source.open('rb') as stream:
                    reader = HashedReader(stream)
                    archive.addfile(info, reader)
                assert reader.digest.hexdigest() == expected_sha, name
                output.flush(); os.fsync(output.fileno())
                remaining = info.size; digest = hashlib.sha256()
                with partial.open('rb') as readback:
                    readback.seek(offset)
                    while remaining:
                        raw = readback.read(min(8 * 1024**2, remaining))
                        assert raw
                        digest.update(raw); remaining -= len(raw)
                assert digest.hexdigest() == expected_sha, name
                row = dict(path=name, bytes=info.size, sha256=expected_sha, tar_payload_offset=offset,
                           source_hash_exact=True, destination_readback_hash_exact=True)
                records.append(row)
                log.write(json.dumps(row) + '\n'); log.flush(); os.fsync(log.fileno())
                if len(records) % 10 == 0:
                    print(json.dumps(dict(files_copied=len(records), total_files=len(expected), bytes=sum(r['bytes'] for r in records))), flush=True)
        output.flush(); os.fsync(output.fileno())
        archive_sha = writer.digest.hexdigest()
    assert (ROOT / 'PROGRESS.json').read_bytes() == progress_raw
    final = DEST / 'archives.tar'
    partial.replace(final)
    save(DEST / 'BACKUP_INDEX.json', dict(passed=True, archive=str(final), archive_sha256=archive_sha,
        archive_bytes=final.stat().st_size, source_progress_sha256=sha(progress_raw), files=records,
        source_root=str(ROOT), source_files_deleted=0, original_physics_calls=0,
        finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print(json.dumps(dict(passed=True, files=len(records), archive_sha256=archive_sha, bytes=final.stat().st_size, source_files_deleted=0)), flush=True)


if __name__ == '__main__':
    main()

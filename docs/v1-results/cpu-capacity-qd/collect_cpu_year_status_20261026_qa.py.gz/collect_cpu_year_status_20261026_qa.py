"""One bounded read-only SSH snapshot of existing CPU chains; no submission."""
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
OUT = BASE / 'cpu-year-status-20261026-qa'
sha = lambda b: hashlib.sha256(b).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    pj = (BASE/'read_numpy_resume_pj_next_status_wo.py').read_text()
    begin = pj.index("parts = (folder / 'stat')")
    end = pj.index('\njobs = {}', begin)
    pj = pj[:begin] + '''state = dict(pid=pid, present=folder.exists(), identity_matches=False)
if folder.exists():
    try:
        parts = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
        cmdline = (folder / 'cmdline').read_bytes().replace(b'\\0', b' ').decode().strip()
        state.update(start_ticks=int(parts[19]), state=parts[0], cmdline=cmdline,
            identity_matches=int(parts[19]) == 269100908 and str(ROOT / 'preparation/controller_pj.py') in cmdline)
    except FileNotFoundError:
        state['disappeared_during_sample'] = True
''' + pj[end:]
    lq = (BASE/'read_hrldas_lq_status_wp.py').read_text()
    marker = 'print(json.dumps(result, indent=2, allow_nan=False), flush=True)'
    assert lq.count(marker) == 1
    lq = lq.replace(marker, '''# Latest journal report is a saved snapshot, not a closed-window claim.
for row in result['sites']:
    journal = Journal(ROOT / row['site'] / 'journal.bin')
    labels = [key for key in journal.index if re.fullmatch(r'generation/\\d+/[a-f0-9]{64}', key)]
    latest = max(labels, key=lambda key: int(key.split('/')[1]))
    generation = journal.read(latest)
    raw_report = generation['report.json']
    assert sha(raw_report) == latest.split('/')[-1]
    report = json.loads(raw_report)
    row['latest_saved_report'] = report
    row['latest_saved_report_raw'] = raw_report.decode()
    row['latest_saved_generation'] = latest
    row['latest_saved_generation_frame_sha256'] = journal.index[latest][2]
    row['latest_saved_snapshot_not_F0_credit'] = True
    for item in row['completed_segments']:
        item['Stageout_status'] = states[item['pbs_job']]['values'].get('Stageout_status')
    row['failure_receipts'] = []
    for item in row['pending_jobs']:
        state = states[item['pbs_job']]['values']
        item['Stageout_status'] = state.get('Stageout_status')
        if state.get('Exit_status') not in (None, '0'):
            result['qstat_raw'][item['pbs_job']] = states[item['pbs_job']]['raw']
            label = 'segment/' + str(item['begin'])
            if label in journal.index:
                packet = journal.read(label)
                row['failure_receipts'].append(dict(job=item['pbs_job'],
                    receipt=json.loads(packet['receipt.json']), receipt_sha256=sha(packet['receipt.json'])))
print(json.dumps(result, indent=2, allow_nan=False), flush=True)''')
    specs = {
        'pj-manager': ('ehpc', pj),
        'pj-compute': ('ehpc-c2', (BASE/'read_numpy_resume_pj_compute_status_wo.py').read_text()),
        'lq-manager': ('ehpc', lq),
    }
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    def read_one(name, host, script):
        data = script.encode()
        (OUT/(name+'-reader.py')).write_bytes(data)
        command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12', host,
                   '/home/zhangyq/venvs/noahmp-closeout/bin/python -B -']
        try:
            process = subprocess.run(command, input=data, capture_output=True, timeout=55)
            stdout, stderr, code, timed_out = process.stdout, process.stderr, process.returncode, False
        except subprocess.TimeoutExpired as error:
            stdout, stderr, code, timed_out = error.stdout or b'', error.stderr or b'', None, True
        (OUT/(name+'.json')).write_bytes(stdout)
        (OUT/(name+'.stderr')).write_bytes(stderr)
        row = dict(command=command, actual_SSH_exit=code, timed_out=timed_out,
            reader_sha256=sha(data), stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
            stdout_bytes=len(stdout), stderr_bytes=len(stderr))
        print(json.dumps(dict(name=name, **row)), flush=True)
        return name, row
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(read_one, n, *spec) for n,spec in specs.items()]
        rows = dict(f.result() for f in futures)
    result = dict(snapshot_started_utc=started,
        snapshot_finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        reads=rows, new_physical_calls=0, new_PBS_jobs=0, remote_mutations=0,
        scope='One metadata-only snapshot of existing PJ and original JN LQ/LU. No archived-window requalification or new annual/scientific acceptance.')
    (OUT/'commands.json').write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()

"""Read-only EHPC metadata snapshot. Run through stdin; no remote output files."""
import datetime
import hashlib
import json
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/zhangyq/noahmp-v1/hrldas-current-year-lq')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert ROOT.is_dir()
protocol_raw = (ROOT / 'protocol.json').read_bytes()
protocol = json.loads(protocol_raw)
jobs_raw = (ROOT / 'jobs.json').read_bytes()
jobs = json.loads(jobs_raw)
control = ROOT / 'append_journal_lp.py'
assert sha(control.read_bytes()) == protocol['controls_sha256']['append_journal_lp.py']
sys.path.insert(0, str(ROOT))
from append_journal_lp import Journal


def fields(text):
    result = {}
    current = None
    for line in text.splitlines():
        match = re.match(r'^    ([\w.]+) = (.*)$', line)
        if match:
            current = match.group(1)
            result[current] = match.group(2)
        elif current and line.startswith('\t'):
            result[current] += line.strip()
    return result


def duration(value):
    if value is None:
        return None
    parts = [int(v) for v in value.split(':')]
    return sum(v * 60 ** k for k, v in enumerate(reversed(parts)))


def qstat_for(ids):
    run = subprocess.run(['qstat', '-xf', *ids], capture_output=True, text=True)
    assert run.returncode == 0, run.stderr
    blocks = re.split(r'(?=^Job Id: )', run.stdout, flags=re.M)
    result = {}
    for block in blocks:
        match = re.match(r'Job Id: (\S+)', block)
        if match:
            result[match.group(1)] = dict(raw=block, values=fields(block), sha256=sha(block.encode()))
    assert set(result) == set(ids)
    return result


def assert_f0(text, job):
    assert re.search(r'^Job Id: ' + re.escape(job) + r'\s*$', text, re.M)
    assert re.search(r'^\s*job_state = F\s*$', text, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', text, re.M)


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
states = qstat_for([v['pbs_job'] for v in jobs] + ['1536.manager'])
sites = []
for site in protocol['sites']:
    own = ROOT / site
    for attempt in range(3):
        try:
            journal = Journal(own / 'journal.bin')
            break
        except AssertionError:
            if attempt == 2:
                raise
            time.sleep(1)
    origin = journal.read('origin')
    previous = json.loads(origin['successful-parent-receipt.json'])
    parent_report = json.loads(origin['report.json'])
    assert_f0(origin['actual-successful-parent-qstat.txt'].decode(), previous['pbs_job'])
    assert previous['actual_stop'] == parent_report['steps_completed'] == 384
    assert previous['failure'] is None and previous['source_unchanged']
    assert previous['report_sha256'] == sha(origin['report.json'])
    completed = []
    pending = []
    successful_stop = 384
    for job in [v for v in jobs if v['site'] == site]:
        state = states[job['pbs_job']]
        q = state['values']
        label = 'segment/' + str(job['begin'])
        value = dict(job, job_state=q['job_state'], exit_status=q.get('Exit_status'),
                     elapsed_wall_seconds=duration(q.get('resources_used.walltime')),
                     scheduler_comment=q.get('comment'), dependency=q.get('depend'),
                     exec_host=q.get('exec_host'), session_id=q.get('session_id'),
                     qstat_sha256=state['sha256'])
        closed = q['job_state'] == 'F' and q.get('Exit_status') == '0'
        if closed:
            assert label in journal.index and job['begin'] == successful_stop
            packed = journal.read(label)
            receipt = json.loads(packed['receipt.json'])
            assert receipt['pbs_job'] == job['pbs_job'] and receipt['site'] == site
            assert receipt['begin'] == job['begin'] and receipt['actual_stop'] == receipt['requested_stop'] == job['stop']
            assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['first_tendency_fullstate_exact']
            assert receipt['source_manifest_sha256'] == protocol['source_manifest_sha256']
            assert receipt['all7_seed_fields_carried_sha256'] == parent_report['checkpoint_sha256']
            parent = journal.read('parent-proof/' + str(job['begin']))
            assert json.loads(parent['successful-parent-receipt.json']) == previous
            assert_f0(parent['actual-parent-qstat.txt'].decode(), previous['pbs_job'])
            generation = journal.read(receipt['final_generation_label'])
            report = json.loads(generation['report.json'])
            assert sha(generation['report.json']) == receipt['report_sha256']
            assert report['steps_completed'] == job['stop'] and report['steps_requested'] == 17520
            assert report['source_unchanged'] and report['configuration_sha256'] == protocol['input_sha256'][site + '-config.json']
            for filename, key in [(report['checkpoint_file'], 'checkpoint_sha256'), (report['model_npz'], 'model_npz_sha256')]:
                assert sha(generation[filename]) == report[key]
            value.update(receipt=receipt, receipt_sha256=sha(packed['receipt.json']),
                         segment_frame_sha256=journal.index[label][2],
                         generation_frame_sha256=journal.index[receipt['final_generation_label']][2],
                         actual_completed_steps=job['stop'] - job['begin'])
            completed.append(value)
            successful_stop = job['stop']
            previous, parent_report = receipt, report
        else:
            value['counted_completed_steps'] = 0
            value['journal_receipt_present'] = label in journal.index
            pending.append(value)
    active = [v for v in pending if v['job_state'] == 'R']
    processes = []
    for job in active:
        node = job['exec_host'].split('/')[0]
        sid = job['session_id']
        assert re.fullmatch(r'compute\d+', node) and sid.isdigit()
        command = 'ps -s ' + sid + ' -o pid=,ppid=,sid=,etimes=,stat=,args='
        run = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', node, command],
                             capture_output=True, text=True)
        processes.append(dict(pbs_job=job['pbs_job'], node=node, session_id=sid,
                              command=command, actual_read_exit=run.returncode,
                              stdout=run.stdout, stderr=run.stderr))
    # Each station is an afterok serial chain; rates use only closed full480 segments.
    full = [v for v in completed if v['actual_completed_steps'] == 480]
    sample = full[-3:] or completed[-3:]
    rates = [v['receipt']['seconds'] / v['actual_completed_steps'] for v in sample]
    rate = statistics.median(rates) if rates else None
    first = pending[0] if pending else None
    remaining = 17520 - successful_stop
    ranges = None
    if rate is not None:
        elapsed = (first['elapsed_wall_seconds'] or 0) if first and first['job_state'] == 'R' else 0
        current_steps = first['stop'] - first['begin'] if first else 0
        estimate = lambda speed: max(current_steps * speed - elapsed, 0) + max(remaining - current_steps, 0) * speed
        ranges = dict(seconds_per_step_median=rate, recent_seconds_per_step_min=min(rates),
                      recent_seconds_per_step_max=max(rates), sample_jobs=[v['pbs_job'] for v in sample],
                      point_remaining_compute_seconds=estimate(rate),
                      recent_rate_low_seconds=estimate(min(rates)), recent_rate_high_seconds=estimate(max(rates)),
                      current_segment_elapsed_subtracted_seconds=elapsed,
                      estimate_method='Median/min/max rates from latest up to3 actualF0 full480 segments; subtract running first-segment elapsed only, never credit its steps. Queue/final-audit delays and future nonlinear cost changes excluded.')
    sites.append(dict(site=site, journal_snapshot_bytes=journal.end, journal_frames=len(journal.index),
                      source_manifest_sha256=protocol['source_manifest_sha256'], origin_actual_successful_steps=384,
                      actual_f0_segments=len(completed), actual_successful_stop=successful_stop,
                      actual_successful_days=successful_stop / 48, remaining_steps=remaining,
                      latest_success=completed[-1] if completed else None,
                      completed_segments=[dict(pbs_job=v['pbs_job'], begin=v['begin'], stop=v['stop'],
                          actual_completed_steps=v['actual_completed_steps'], seconds=v['receipt']['seconds'],
                          scheduler_wall_seconds=v['elapsed_wall_seconds'], receipt_sha256=v['receipt_sha256'],
                          segment_frame_sha256=v['segment_frame_sha256'], qstat_sha256=v['qstat_sha256']) for v in completed],
                      pending_jobs=pending, active_process_readbacks=processes, estimate=ranges))
final = states['1536.manager']
raw_jobs = {v['latest_success']['pbs_job'] for v in sites if v['latest_success']}
raw_jobs |= {q['pbs_job'] for v in sites for q in v['pending_jobs'] if q['job_state'] in ['R', 'E']}
result = dict(snapshot_started_utc=started, snapshot_finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              host='EHPC manager', root=str(ROOT), jobs_sha256=sha(jobs_raw), protocol_sha256=sha(protocol_raw),
              journal_control_sha256=sha(control.read_bytes()), jobs_count=len(jobs),
              sites=sites, final_audit_job=dict(pbs_job='1536.manager', **final['values']),
              qstat_raw={job: states[job]['raw'] for job in sorted(raw_jobs)},
              final_audit_qstat_raw=final['raw'],
              numerical_arrays_deserialized=False, numerical_models_executed=False, remote_files_written=False,
              scope='Read-only originalJN LQ job/journal metadata. Only contiguous segments with actualF0 and matching original receipt/report/seed hashes count. Running/H/Q segments receive zero pass credit. ETA is conditional compute extrapolation, not an annual/scientific pass or release date.')
# Latest journal report is a saved snapshot, not a closed-window claim.
for row in result['sites']:
    journal = Journal(ROOT / row['site'] / 'journal.bin')
    labels = [key for key in journal.index if re.fullmatch(r'generation/\d+/[a-f0-9]{64}', key)]
    latest = max(labels, key=lambda key: int(key.split('/')[1]))
    generation = journal.read(latest)
    raw_report = generation['report.json']
    assert sha(raw_report) == latest.split('/')[-1]
    report = json.loads(raw_report)
    row['latest_saved_report'] = report
    row['latest_saved_report_raw'] = raw_report.decode()
    row['latest_saved_generation'] = latest
    row['latest_saved_generation_frame_sha256'] = journal.index[latest][2]
    row['latest_saved_snapshot_not_F0_credit'] = True
    for item in row['completed_segments']:
        item['Stageout_status'] = states[item['pbs_job']]['values'].get('Stageout_status')
    row['failure_receipts'] = []
    for item in row['pending_jobs']:
        state = states[item['pbs_job']]['values']
        item['Stageout_status'] = state.get('Stageout_status')
        if state.get('Exit_status') not in (None, '0'):
            result['qstat_raw'][item['pbs_job']] = states[item['pbs_job']]['raw']
            label = 'segment/' + str(item['begin'])
            if label in journal.index:
                packet = journal.read(label)
                row['failure_receipts'].append(dict(job=item['pbs_job'],
                    receipt=json.loads(packet['receipt.json']), receipt_sha256=sha(packet['receipt.json'])))
print(json.dumps(result, indent=2, allow_nan=False), flush=True)

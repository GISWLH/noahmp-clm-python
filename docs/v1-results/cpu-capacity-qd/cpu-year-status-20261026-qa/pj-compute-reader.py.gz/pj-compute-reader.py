"""Read PJ live processes and saved report text only, no arrays or model imports."""
from pathlib import Path
import datetime
import json
import os
import socket

assert socket.gethostname() == 'compute002'
needle = '/tmp/noahmp-numpy-baseline-resume-pj/preparation/run_window_job_pj.py'
rows = []
for folder in Path('/proc').iterdir():
    if not folder.name.isdigit():
        continue
    try:
        if folder.stat().st_uid != os.getuid():
            continue
        cmd = (folder / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        if needle not in cmd:
            continue
        env = {}
        for item in (folder / 'environ').read_bytes().split(b'\0'):
            k, _, v = item.partition(b'=')
            if k.decode(errors='replace') in ('PBS_JOBID', 'TMPDIR', 'PJ_CASE_INDEX', 'PJ_START'):
                env[k.decode()] = v.decode()
        stat = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
        tmp = Path(env['TMPDIR'])
        report = tmp / 'result/run/trajectory/report.json'
        report_raw = json.loads(report.read_bytes()) if report.exists() else None
        selected = None if report_raw is None else {k: report_raw.get(k) for k in ('status', 'steps_completed', 'steps_requested', 'checkpoint_file', 'model_npz')}
        log = tmp / 'result/run' / ('segment-' + env['PJ_START'].zfill(7)) / 'model.log'
        rows.append(dict(pid=int(folder.name), start_ticks=int(stat[19]), state=stat[0],
            cmdline=cmd.strip(), environment=env, saved_report=selected,
            model_log_tail=log.read_text(errors='replace').splitlines()[-3:] if log.exists() else [],
            completion_credit=False))
    except (FileNotFoundError, ProcessLookupError):
        continue
print(json.dumps(dict(sample_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    live_processes=rows, scope='Actual process identity and saved text only; no terminal or new-step success inferred.'), indent=2))

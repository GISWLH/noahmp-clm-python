"""Small NS/OD-to-OS bridge. No scorer, forward column or job submission."""
from pathlib import Path
import hashlib
import json
import re
import tarfile
import numpy as np
from soc_operator_os import AnnualCase, require, validate_year

TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
SITE_YEARS = {'CN-Cng': 2007, 'CN-Qia': 2003, 'CN-Cha': 2003}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def select_registry(registry):
    """Keep all12 identities; select exactly all8 predeclared training roots."""
    expected = {f'{site}-{year}-{seed}-{mapping}-clim' for site, year in SITE_YEARS.items()
                for seed in ('wilting', 'field-capacity') for mapping in ('hydraulic', 'legacy')}
    names = [c['case'] for c in registry]
    require(len(names) == len(set(names)) == 12 and set(names) == expected, 'Require unchanged all12 registry')
    for c in registry:
        require(c['case'] == c['config']['case'] and c['case'].startswith(c['config']['site'] + '-'), 'Case/site identity mismatch')
    selected = [k for k, c in enumerate(registry) if c['config']['site'] in ('CN-Cng', 'CN-Qia')]
    require(len(selected) == 8, 'Require all8 training roots')
    return selected


def project_row(row, selected):
    require(len(selected) == len(set(selected)) == 8 and all(0 <= i < 12 for i in selected), 'Invalid column selection')
    result = {}
    for name, value in row.items():
        value = np.asarray(value)
        require(value.ndim >= 1 and value.shape[0] == 12, 'BGC row must retain original12-column layout')
        result[name] = np.take(value, selected, axis=0)
    return result


def selected_records(current, receipt, selected):
    """Original cold48 and364 chunks; hash each chunk, then project each row."""
    from audit_bgc_stream_km_original import cold_rows
    current = Path(current)
    require(receipt['steps_completed'] == receipt['steps_requested'] == 17520 and
            receipt['bgc_diagnostic_steps'] == 17472 and len(receipt['bgc_diagnostic_chunks']) == 364, 'Incomplete real year')
    for index, row in cold_rows(current):
        yield index, project_row(row, selected)
    for j, chunk in enumerate(receipt['bgc_diagnostic_chunks']):
        begin, end = 48 + 48*j, 96 + 48*j
        require(chunk['first'] == begin and chunk['end'] == end, 'Gap, repeated or reordered BGC chunk')
        path = current / 'year-bgc-diagnostics' / f'steps-{begin:07d}-{end:07d}.npz'
        require(sha(path) == chunk['sha256'], 'BGC chunk hash mismatch')
        with np.load(path, allow_pickle=False) as archive:
            data = {n: archive[n] for n in archive.files}
        require(all(a.ndim >= 2 and a.shape[:2] == (48, 12) for a in data.values()), 'Invalid48x12 chunk layout')
        for k in range(48):
            yield begin + k, project_row({n: a[k] for n, a in data.items()}, selected)


def require_f0(qstat, job):
    require(re.search(r'^Job Id:\s*' + re.escape(job) + r'\s*$', qstat, re.M) is not None, 'PBS job identity mismatch')
    require(re.search(r'^\s*job_state = F\s*$', qstat, re.M) is not None and
            re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M) is not None, 'Actual PBS F0 required')


def verify_closed_od(*, device_archive, device_packet, od_archive, od_package, dispatch,
                     qstat, pbs_exit, source_root):
    """Opaque OD receipts/scores; trust only exact successful original controls.

    All12 original device bytes are authenticated by unchanged od_contract.
    Full OD receipt/BGC audit bytes are hashed, never parsed for case values.
    Inputs are the future ORIGINAL OD result.tar.gz/result-package.json,
    dispatch.json and independently retrieved actual qstat/pbs-exit evidence.
    """
    from od_contract import verify_device_archive
    bindings = json.loads((Path(__file__).parent / 'BINDINGS.json').read_text())
    source_root = Path(source_root)
    manifest_path = source_root / 'SOURCE_SHA256.json'
    require(sha(manifest_path) == TARGET, 'Exact NM manifest required')
    manifest = json.loads(manifest_path.read_text())
    require(len(manifest) == 584 and all(sha(source_root/n) == h for n, h in manifest.items()), 'NM source byte mismatch')
    receipt = verify_device_archive(Path(device_archive), device_packet)
    require(sha(od_archive) == od_package['sha256'] and str(pbs_exit).strip() == '0', 'OD archive/worker exit mismatch')
    with tarfile.open(od_archive) as archive:
        names = archive.getnames()
        require(len(names) == len(set(names)) and all(m.isfile() for m in archive), 'Invalid OD archive')
        raw = lambda n: archive.extractfile(n).read()
        controls = json.loads(raw('CONTROLS_SHA256.json'))
        require(controls == bindings['original_od_controls_sha256'], 'OD controls not the reviewed original')
        require(all(hashlib.sha256(raw(n)).hexdigest() == h for n, h in controls.items()), 'OD controls bytes changed')
        plan = json.loads(raw('plan.json')); worker = json.loads(raw('worker-actual-exit.json'))
        require(worker['passed'] and worker['failure'] is None and worker['actual_evaluator_parent_returncode'] == 0, 'OD evaluator did not actually succeed')
        require(worker['node'].startswith('compute002') and worker['pbs_job'] == dispatch['pbs_job'], 'OD node/job mismatch')
        require(all(od_package[k] == v for k, v in worker.items()), 'OD actual wrapper/package mismatch')
        require_f0(qstat, worker['pbs_job'])
        require(dispatch['controls_sha256'] == controls == plan['controls_sha256'], 'OD control binding mismatch')
        require(dispatch['plan_sha256'] == hashlib.sha256(raw('plan.json')).hexdigest(), 'OD plan hash mismatch')
        require(plan['source_manifest_sha256'] == dispatch['source_manifest_sha256'] == TARGET, 'OD source mismatch')
        require(plan['device_archive_sha256'] == dispatch['device_archive_sha256'] == device_packet['sha256'], 'OD/device archive mismatch')
        require(plan['requested_steps'] == 17520 and plan['cases'] == 12 and plan['actual_year_parent_returncode'] == 0, 'OD incomplete year')
        require(worker['receipt_sha256'] == hashlib.sha256(raw('receipt.json')).hexdigest(), 'OD receipt hash mismatch')
        bgc_sha = hashlib.sha256(raw('bgc-stream-audit.json')).hexdigest()
    return dict(verified_ns17520_od_f0=True, production_extraction_bound=False,
        source_manifest_sha256=TARGET, source_root=str(source_root),
        od_job=worker['pbs_job'], od_archive_sha256=od_package['sha256'], od_bgc_audit_sha256=bgc_sha,
        device_archive_sha256=device_packet['sha256'], year_receipt=receipt,
        scope='Original all12 OD integrity/ledger credit only. No OD scientific scores decoded; OS numerical analysis selects exactly8 training roots.')


def audit_and_diagnose(*, proof, registry, loaded_training, cold_training, final_training,
                       traces_training, projected_records):
    """Future sealed extraction adapter supplies original training-only data.

    This is a library interface, not a launchable production worker. The
    caller must bind extracted input/trace/cold/final bytes to verified OD
    inventory before entering here. No real-year binding has been fabricated.
    """
    bindings = json.loads((Path(__file__).parent / 'BINDINGS.json').read_text())
    require(bindings.get('production_binding_sealed') is True, 'Production extraction adapter is not sealed in frozen BINDINGS')
    require(proof.get('verified_ns17520_od_f0') is True and proof['source_manifest_sha256'] == TARGET, 'Closed annual proof required')
    require(proof.get('production_extraction_bound') is True, 'Sealed byte-exact training extraction adapter still required')
    from audit_bgc_stream_os8 import audit_stream
    selected = select_registry(registry)
    require([c['case'] for c in loaded_training] == [registry[k]['case'] for k in selected], 'Training registry/order changed')
    require(len(traces_training) == 8, 'All8 training traces required')
    accumulators = []
    for c, trace in zip(loaded_training, traces_training):
        year = SITE_YEARS[c['config']['site']]
        stamps = validate_year(c['data']['time_start'], c['data']['time_end'], year)
        require(np.array_equal(trace['time_start'], c['data']['time_start']) and
                np.array_equal(trace['time_end'], c['data']['time_end']), 'Trace/forcing calendar mismatch')
        accumulators.append(AnnualCase(c['case'], c['config']['biogeochemistry']['decomposition_parameters'], stamps))
    def records():
        count = 0
        for index, row in projected_records:
            require(index == count and count < 17520, 'Record count/order mismatch')
            require(all(np.asarray(v).ndim >= 1 and np.asarray(v).shape[0] == 8 for v in row.values()), 'Only projected8-column rows accepted')
            for k, a in enumerate(accumulators):
                a.add(index, row, k)
            count += 1
            yield index, row
        require(count == 17520, 'Truncated annual stream')
    cn = audit_stream(records(), loaded_training, cold_training, final_training, traces_training, 17520)
    return dict(closure={k: v for k, v in proof.items() if k != 'year_receipt'},
                registry_cases=[c['case'] for c in registry], selected_cases=[c['case'] for c in loaded_training],
                all12_integrity_credit='Original OD actualF0, exact controls and archive binding',
                actual_training_cn_audit=cn, cases=[a.finish() for a in accumulators],
                raw_container_boundary='Original12-column NPZ containers read only for hash/column extraction. Only fixed8 projected columns enter statistics, matrices or C/N audit. No Cha trace/observation/scoring input.',
                actual_model_years_added=0, initializer_exported=False, scientific_acceptance_claim=False)

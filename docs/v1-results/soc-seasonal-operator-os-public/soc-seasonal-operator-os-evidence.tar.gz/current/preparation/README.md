# OS — prepared annual conditional soil-C diagnostic core

Prepared only. No numerical test, actual annual diagnostic, model, GPU or PBS job has run for OS. Windows checks are AST/hash/schema metadata only. The current full annual trajectory has not been supplied as a closed artifact. No terminal hash/job number or usable cold configuration is invented. This directory deliberately has no dispatch, model launcher, publication framework or live checkpoint writer.

The source is NM584, manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f`. Existing NS/OD source, inputs, controls and scientific gates remain unchanged. `BINDINGS.json` stores the original OD control hashes and the byte-exact original KM helper. The OS8 helper changes exactly fourteen integer column dimensions from12 to8; every other AST node is identical. It retains the original float32 budget/residual reconstruction, independent float64 step/cumulative ledger, before/after chain, actual forcing/deposition, final-stock and trace checks. It is a new private eight-column adapter, not mislabeled as the original twelve-column audit.

## Files and interfaces

- `soc_operator_os.py`: normal1800s seven-pool affine map, chronological composition, periodic solve and streaming annual/monthly diagnostics. No production forward call.
- `training_stream_os.py`: original twelve-case registry, fixed eight training indices, NPZ row projection, full nonleap calendar, original cold48＋364×48 continuation-block reader, original OD closure verifier and `audit_and_diagnose` library interface.
- `audit_bgc_stream_km_original.py` / `audit_bgc_stream_os8.py`: original KM and its narrowly scoped count adapter.
- `od_contract.py`: byte-exact original OD archive/NS parent0/source/device-barrier/NP48 payload verifier. The OD scoring main program is never called.
- `test_soc_operator_os.py`: seventeen independent synthetic tests, not yet executed; see cases below.

`select_registry(registry)` requires all twelve original identities, all four dry/wet×hydraulic/legacy roots at Cng2007, Qia2003 and Cha2003. It returns exactly the eight Cng/Qia indices in original order. Raw12-column NPZ containers may be read for hash and column extraction; only the projected eight columns enter statistics, matrices and C/N audit. No Cha/HaM trace is loaded; no observation array, QC selection, prediction score or OD scientific-score JSON is used. Tests poison the four heldout columns and verify they never enter projected analysis. Original twelve metadata identities and original OD all12 integrity credit remain present in the result.

The pending real-year caller first uses:

```python
proof = verify_closed_od(
    device_archive=original_od_device_archive,
    device_packet=original_device_package_json,
    od_archive=original_od_result_tar_gz,
    od_package=original_od_result_package_json,
    dispatch=original_od_dispatch_json,
    qstat=independently_retrieved_actual_qstat_text,
    pbs_exit=actual_od_pbs_exit_text,
    source_root=exact_extracted_nm584_source,
)
```

This checks the exact NM584 files, calls unchanged OD device verification for true NS17520/parent0 and NP48/whole inventory, requires OD actual F0 with matching job, source/device/plan/control hashes, successful original evaluator and wrapper exits, and authenticates the opaque receipt and original all12 BGC audit bytes. OD result `receipt.json` and `bgc-stream-audit.json` are hashed **without decoding case values**; successful exact original controls supply the already-completed all12 integrity credit. It does not infer F0 from a `passed` flag alone and does not parse OD observation outputs.

**The production extraction binding is still pending the actual sealed year.** The future small caller must bind the extracted JR input/config/manifest bytes, selected eight trace bytes, all cold48 packets and initial/final checkpoint bytes to that verified original inventory; check unchanged files before/after; set the frozen source/benchmarks import paths; and then call:

```python
selected = select_registry(original_all12_registry)
records8 = selected_records(authenticated_current_directory,
                            proof['year_receipt'], selected)
result = audit_and_diagnose(
    proof=proof, registry=original_all12_registry,
    loaded_training=authenticated_eight_forcing_configs,
    cold_training=projected_original_cold_a11_a13,
    final_training=projected_original_final_a11_a13,
    traces_training=authenticated_eight_original_traces,
    projected_records=records8,
)
```

The library's injected arrays are not, by themselves, a completed production byte-binding mechanism. `BINDINGS.json` therefore has `production_binding_sealed=false`; `audit_and_diagnose` reads this frozen local gate first and rejects execution even if its caller supplies `production_extraction_bound=true`. This happens before the KM adapter import or array analysis. `verify_closed_od` also returns `production_extraction_bound=false`. Only a future reviewed control revision and byte-authenticated extraction adapter may open both gates. There is no executable real-data CLI. This avoids pretending that future archive paths/SHA already exist. The missing adapter is small: original identity/hash authentication and training-only extraction, not a new model or analysis framework. It must be reviewed before actual data execution. It cannot use `native.load_batch/read_generation` unchanged because those decode all twelve full trace/input payloads; selected eight inputs only need `forcing`, `environment`, `time_start`, `time_end` and original metadata. All12 remaining members are authenticated as opaque bytes.

## Meaning of the output

For each actual1800s interval, with recorded normal rate modifier m, normal turnover times tau, routing R and actual litter amount L:

`f = -expm1(-m*1800/(tau*31536000))`, `A = I-diag(f)+R*diag(f)`, `b=A*L`.

The annual map is composed in original chronological order: `A_year ← A_step*A_year`, `b_year ← A_step*b_year+b_step`. Litter enters before decay and newly transferred C waits to the next interval, matching the original discrete cascade. This uses the actual saved rate multiplier, not an independently recomputed rounded temperature/moisture rate. No decomposition rate is accelerated. The solution to `(I-A_year) C = b_year` reports all seven stocks, eigenvalues/spectral radius, condition number, algebraic residual, relative backward residual and nonnegativity. Singular, nonfinite or negative outcomes remain explicit; there is no clipping, normalization, pseudoinverse or new acceptance threshold.

The map is conditional on fixed historical climate and litter and **no limiting N feedback**. Production N limitation scales selected immobilizing pathways; multiplying the whole matrix by an N factor would be wrong and is not done. Every actual N-limited interval is counted. On intervals with actual factor exactly1, an independent one-step prediction starts from the original saved before C, compares with original after C and is discarded; it never replaces or propagates the recorded state. Raw pool differences are reported without treating the original C/N budget bound as a per-pool accuracy gate.

Each case retains full17520 intervals, exactly twelve complete Gregorian months, GPP/Ra/NPP, seven litter C/N amounts, N deposition and plant demand/uptake, normal-rate/soil-temperature/water-potential ranges, actual decomposition/leaf N-factor ranges and mineral-N range. C quantities are gC m-2 **amounts per interval or stated month/year**; N quantities are gN m-2; temperatures K, potentials MPa, factors dimensionless. NPP is GPP minus autotrophic respiration. There is no interpolation, missing-period imputation or averaging away a seasonal gap. The output always says stable repeated inputs unproven, no initializer export, zero added physical years and no scientific/SOC acceptance.

## Normal C/N replay design — deliberately not invoked yet

A later small optional API can be:

`replay_normal_cn(initial_C_gC_m2, explicit_initial_organic_N_gN_m2, original_mineral_N_gN_m2, actual_training_schedule, frozen_DecompositionParameters)`.

The caller must supply a defensible explicit N-stock sidecar; this tool does not derive usable N stocks from the conditional C solution. Each schedule row supplies actual1800s soil T/water potential, seven litter C/N amounts, external N-deposition amount and actual plant N-demand amount. Use the frozen source `step_decomposition` at normal rates, oxygen1 for these no-wetland configurations, with its original step/cumulative C/N audit. Keep original mineral N; do not set1e6 or otherwise guarantee unlimited N. Report actual limiting factors, minimum mineral N, N uptake/immobilization/mineralization and endpoint changes. A replay with prescribed plant demand is still only a soil-module feasibility diagnostic; a new candidate changes leaf N, NPP and litter and needs subsequent full normal coupled cycles. No function implementing this replay is currently wired into OS, so no accidental candidate-initialization or forward run can occur.

## Pending EHPC synthetic tests

Only after root review, run on a real EHPC compute002 PBS node, with one CPU,2GB and a bounded10-minute wall time:

```sh
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
/home/zhangyq/venvs/noahmp-closeout/bin/python -B -m unittest discover \
  -s /tmp/REVIEWED_OS_CONTROLS -p test_soc_operator_os.py -v
```

`setUpModule` rejects non-PBS/non-compute002 numerical execution. Tests cover independent scalar metabolic decay/respiration, receiving-material delay, litter-before-decay, a two-season scalar periodic solution and ordering, a known coupled system, singular/negative outcomes, invalid rates/dt, N-limited applicability, selected-only heldout poison, missing/duplicate/wrong-family cases, invalid selection, full calendar and gaps/reordering/truncation, incomplete BGC year, actual F0/job identity, refusal of an unsealed extraction adapter, and the exact14-constant KM AST adapter. These synthetic checks do not replace actual whole-year byte binding, original all12 OD closure, original scientific gates or full coupled spinup.

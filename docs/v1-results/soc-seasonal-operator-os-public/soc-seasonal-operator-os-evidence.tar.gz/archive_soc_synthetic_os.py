"""OP-style read-only archive of the actual closed OS synthetic PBS job."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-soc-seasonal-operator-os')
STAGE = Path('/tmp/noahmp-soc-seasonal-operator-os-stage.tar.gz')
STAGE_SHA = 'cc076fe1af431c7cba23818acfde58454f63cbd7db899563b497047a44c9178d'
LABEL = 'soc-seasonal-operator-os'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def contents(raw):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for m in archive.getmembers():
            if m.isdir(): continue
            name = m.name.removeprefix('./')
            assert m.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts and name not in result
            result[name] = archive.extractfile(m).read()
    return result


def main():
    assert socket.gethostname() == 'manager'
    dispatch = json.loads((ROOT/'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == '1601.manager' and dispatch['stage_archive_sha256'] == STAGE_SHA
    query = subprocess.run(['qstat', '-xf', dispatch['pbs_job']], capture_output=True)
    assert query.returncode == 0
    qstat = query.stdout.decode()
    assert re.search(r'^Job Id: 1601.manager\s*$', qstat, re.M) and re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    exit_code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
    stage_raw = STAGE.read_bytes(); assert sha(stage_raw) == STAGE_SHA
    stage = contents(stage_raw); index = json.loads(stage['stage-inventory.json'])
    assert set(index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[n]) == h == sha((ROOT/n).read_bytes()) for n, h in index.items())
    status = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT/'pbs-exit.txt')], capture_output=True)
    assert status.returncode == 0 and int(status.stdout.strip()) == exit_code
    remote = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT/'result.tar.gz')], capture_output=True)
    assert remote.returncode == 0
    result = contents(remote.stdout)
    receipt = json.loads(result['receipt.json'])
    assert int(result['worker-exit.txt'].strip()) == exit_code
    assert receipt['pbs_job'] == '1601.manager' and receipt['node'] == 'compute002'
    assert receipt['model_runs'] == receipt['gpu_runs'] == receipt['annual_payloads_decoded'] == receipt['actual_periodic_solutions'] == 0
    assert receipt['production_binding_sealed'] is False and receipt['synthetic_test_run'] is True
    if exit_code == 0:
        assert receipt['passed'] and receipt['unittest_parent_returncode'] == 0 and receipt['actual_test_count'] == 17
        assert int(result['unittest-parent-exit.txt'].strip()) == 0 and not receipt['unittest_timed_out']
        assert receipt['preparation_manifest_sha256'] == '2b26a5e6fa197221c03af93e73566f77ff5ae45b183c1a0ff7a5322fe382e46f'
        assert receipt['execution_manifest_sha256'] == sha(stage['execution/CONTROLS_SHA256.json'])
        assert receipt['independent_review_sha256'] == sha(stage['independent-review.json'])
        assert receipt['source_files_byte_verified'] == 584 and receipt['preparation_and_source_unchanged']
        assert sha(result['quantified-synthetic-diagnostics.json']) == receipt['quantified_synthetic_diagnostics_sha256']
        assert 'Ran 17 tests' in result['unittest.stderr.txt'].decode() and '\nOK\n' in result['unittest.stderr.txt'].decode()
        for directory in ['preparation', 'execution']:
            manifest = json.loads(stage[directory+'/CONTROLS_SHA256.json'])
            for name in [*manifest, 'CONTROLS_SHA256.json']:
                assert result[directory+'/'+name] == stage[directory+'/'+name]
    artifacts = {'current/'+n: raw for n, raw in result.items()}
    artifacts.update({'original-stage.tar.gz': stage_raw, 'original-result.tar.gz': remote.stdout,
        'actual-pbs-qstat.txt': query.stdout, 'actual-pbs-qstat.stderr.txt': query.stderr,
        'pbs-exit.txt': status.stdout, 'archive_soc_synthetic_os.py': Path(__file__).read_bytes()})
    for name in ['dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'qsub-actual-exit.json',
                 'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt']:
        artifacts['manager/'+name] = (ROOT/name).read_bytes()
    output = ROOT/'pbs-output.log'
    artifacts['manager/pbs-output-presence.json'] = (json.dumps(dict(path=str(output), exists=output.exists(),
        note='Controller and unittest logs are retained regardless of optional PBS stdout presence.'))+'\n').encode()
    if output.exists(): artifacts['manager/pbs-output.log'] = output.read_bytes()
    inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in artifacts.items()}
    artifacts['inventory.json'] = (json.dumps(inventory, indent=2)+'\n').encode()
    dest = ROOT/(LABEL+'-evidence.tar.gz'); assert not dest.exists()
    with tarfile.open(dest, 'w:gz') as archive:
        for name, raw in sorted(artifacts.items()):
            m = tarfile.TarInfo(name); m.size = len(raw); m.mode = 0o644
            archive.addfile(m, io.BytesIO(raw))
    assert contents(dest.read_bytes()) == artifacts
    package = dict(archive=dest.name, sha256=sha(dest.read_bytes()), bytes=dest.stat().st_size,
        artifacts=len(artifacts), pbs_job='1601.manager', actual_pbs_state='F', actual_pbs_exit=exit_code,
        actual_worker_exit=int(result['worker-exit.txt'].strip()), passed=receipt['passed'],
        actual_unittest_count=receipt.get('actual_test_count'), actual_test_seconds=receipt.get('actual_test_seconds'),
        stage_archive_sha256=STAGE_SHA, result_archive_sha256=sha(remote.stdout), model_runs=0,
        production_binding_sealed=False, scope='OS17synthetic matrix/extraction/closure-boundary tests. Exact original NM584 verified as source bytes; no actual annual field data, cold initializer, coupled model, GPU, SOC/spinup or scientific acceptance.')
    (ROOT/(LABEL+'-package.json')).write_text(json.dumps(package, indent=2)+'\n')
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()

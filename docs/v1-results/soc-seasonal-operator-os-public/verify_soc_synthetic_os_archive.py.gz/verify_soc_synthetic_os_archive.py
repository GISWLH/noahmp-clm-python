"""Read-only stdlib verification of OS actual PBS evidence; no numerical run."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parent
sha = lambda value: hashlib.sha256(value).hexdigest()


def unpack(raw):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for item in archive.getmembers():
            if item.isdir():
                continue
            name = item.name.removeprefix('./')
            assert item.isfile() and name not in result
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            result[name] = archive.extractfile(item).read()
    return result


package_raw = (ROOT/'soc-seasonal-operator-os-package.json').read_bytes()
package = json.loads(package_raw)
raw = (ROOT/package['archive']).read_bytes()
assert sha(raw) == package['sha256'] == '9c10ad61e9c5b973d387e4ed202774a249606975d5a9543925018fcbe71e8fee'
assert len(raw) == package['bytes']
items = unpack(raw)
inventory = json.loads(items['inventory.json'])
assert len(items) == package['artifacts'] == 40 and set(inventory) == set(items)-{'inventory.json'}
assert all(sha(items[n]) == row['sha256'] and len(items[n]) == row['bytes'] for n, row in inventory.items())
stage = unpack(items['original-stage.tar.gz'])
assert sha(items['original-stage.tar.gz']) == package['stage_archive_sha256']
stage_inventory = json.loads(stage['stage-inventory.json'])
assert set(stage_inventory) == set(stage)-{'stage-inventory.json'}
assert all(sha(stage[n]) == value for n, value in stage_inventory.items())
result = unpack(items['original-result.tar.gz'])
assert sha(items['original-result.tar.gz']) == package['result_archive_sha256']
assert all(items['current/'+n] == value for n, value in result.items())
receipt = json.loads(result['receipt.json'])
qstat = items['actual-pbs-qstat.txt'].decode()
assert re.search(r'^Job Id: 1601.manager\s*$', qstat, re.M)
assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
assert package['actual_pbs_exit'] == package['actual_worker_exit'] == 0 and package['actual_pbs_state'] == 'F'
assert receipt['pbs_job'] == '1601.manager' and receipt['node'] == 'compute002' and receipt['passed'] is True
assert receipt['unittest_parent_returncode'] == 0 and receipt['actual_test_count'] == 17 and not receipt['unittest_timed_out']
assert all(int(items[name].strip()) == 0 for name in ['pbs-exit.txt', 'current/worker-exit.txt', 'current/unittest-parent-exit.txt'])
assert 'Ran 17 tests' in result['unittest.stderr.txt'].decode() and '\nOK\n' in result['unittest.stderr.txt'].decode()
assert receipt['model_runs'] == receipt['gpu_runs'] == receipt['annual_payloads_decoded'] == receipt['actual_periodic_solutions'] == 0
assert receipt['production_binding_sealed'] is False and receipt['preparation_and_source_unchanged'] is True
for directory in ['preparation', 'execution']:
    manifest_raw = stage[directory+'/CONTROLS_SHA256.json']
    manifest = json.loads(manifest_raw)
    assert sha(manifest_raw) == receipt[directory+'_manifest_sha256']
    assert result[directory+'/CONTROLS_SHA256.json'] == manifest_raw
    assert all(sha(stage[directory+'/'+n]) == value and result[directory+'/'+n] == stage[directory+'/'+n] for n, value in manifest.items())
assert json.loads(result['preparation/BINDINGS.json'])['production_binding_sealed'] is False
assert result['independent-review.json'] == stage['independent-review.json']
assert sha(result['independent-review.json']) == receipt['independent_review_sha256'] == '6e850158cf2654028697c05a23a1d26a896a69d6d8b89ac04ea51d431dd6bacb'
source_raw = stage['inputs/climatology-final-candidate-nm-source.tar.gz']
assert sha(source_raw) == receipt['source_archive_sha256']
source = unpack(source_raw)
assert result['SOURCE_SHA256.json'] == source['SOURCE_SHA256.json']
assert sha(source['SOURCE_SHA256.json']) == receipt['source_manifest_sha256']
source_manifest = json.loads(source['SOURCE_SHA256.json'])
assert len(source_manifest) == receipt['source_files_byte_verified'] == 584 and set(source) == set(source_manifest)|{'SOURCE_SHA256.json'}
assert all(sha(source[name]) == value for name, value in source_manifest.items())
diagnostic_raw = result['quantified-synthetic-diagnostics.json']
assert sha(diagnostic_raw) == receipt['quantified_synthetic_diagnostics_sha256']
diagnostics = json.loads(diagnostic_raw)
assert len(diagnostics['cases']) == 2
print(json.dumps(dict(passed=True, members=len(items), inventory=len(inventory),
    source_files_verified=584, package_sha256=sha(package_raw), receipt=receipt,
    actual_diagnostics=diagnostics), indent=2))

# OS synthetic diagnostic validation — actual EHPC results

`1601.manager` completed on EHPC `compute002` with actual PBS **F / Exit_status 0**, worker exit0 and unittest parent exit0. All **17 tests** ran with no skips in **0.429 s**; the enclosing worker took0.7642206661403179s. Resources were1CPU,2GB,10-minute cap. Earlier E-state snapshots are historical observations, not the terminal receipt. No numerical tests ran on Windows.

| Synthetic case | Independent oracle / computed value | Actual error |
| --- | --- | --- |
| Two-season metabolic scalar; direct chronological `AnnualCase.add` accumulation | Both2009.122289379354gC m-2 | Absolute C0gC m-2; relative C0; multiplier0; accumulated input0gC m-2 |
| Known coupled seven-pool system | Both[2,0,0,0,5,0,0]gC m-2 | Maximum absolute pool error0gC m-2; spectral-radius error0; relative backward residual0 |

These are synthetic oracle differences, not observed annual field accuracy. The tests also exercised litter-before-decay, delayed receiving-pool transfer, singular/negative solutions, N-limited applicability, fixed training-column extraction, poisoned heldout columns, full-calendar/gap rejection, actualF0 identity and rejection of caller-supplied production proof while the frozen local binding remainsfalse. No scientific acceptance threshold was changed.

The final eight preparation controls are bound by manifest `2b26a5e6fa197221c03af93e73566f77ff5ae45b183c1a0ff7a5322fe382e46f`; final independent prelaunch review `6e850158cf2654028697c05a23a1d26a896a69d6d8b89ac04ea51d431dd6bacb` found0blocking issues. Relative to the reviewed85c9 controls, only two existing tests gained direct accumulator/quantified-oracle diagnostics; all original assertions and17test methods remain. The prior full review,85c9 preparation archive, initialdfb manifest and minimal test diff are preserved separately with their original identities. Historical preparation README/STATIC_CHECK statements saying “not executed” remain the original prelaunch snapshot; this result records the later execution.

The worker verified all584 files in the original NM source archive `39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d`, source manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f`, as bytes. Preparation, execution controls and source were unchanged after the run. The complete original40-member/39-inventory evidence archive is `soc-seasonal-operator-os-evidence.tar.gz`, SHA256 `9c10ad61e9c5b973d387e4ed202774a249606975d5a9543925018fcbe71e8fee`; it retains the original stage/result archives, all controls, original NM source, real qstat, dispatch, worker/unittest logs and numerical diagnostics.

`production_binding_sealed=false` remains in force. Actual annual payloads decoded, actual field periodic solutions, coupled-model runs and GPU runs are all0. The tool does not export a cold initializer or prove SOC/spinup convergence. The next real-data step still needs a fully closed NS/OD year and a reviewed byte-bound eight-training-root extraction adapter; normal C/N feedback replay and subsequent full coupled normal-rate convergence remain separate scientific requirements.

"""Small outputs-only wrapper; preserve the original closed OS40 evidence bytes."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
label = 'soc-seasonal-operator-os-public'
original_package_raw = (ROOT/'soc-seasonal-operator-os-package.json').read_bytes()
original_package = json.loads(original_package_raw)
original_raw = (ROOT/original_package['archive']).read_bytes()
assert sha(original_raw) == original_package['sha256'] == '9c10ad61e9c5b973d387e4ed202774a249606975d5a9543925018fcbe71e8fee'
names = [original_package['archive'], 'soc-seasonal-operator-os-package.json',
    'SOC_OPERATOR_OS_RESULTS.md', 'verify_soc_synthetic_os_archive.py',
    'soc-seasonal-operator-os-local-archive-verification.json',
    'soc-seasonal-operator-os-actual-independent-review-rg.json',
    'soc-seasonal-operator-os-independent-review-rg-final.json',
    'soc-seasonal-operator-os-independent-review-rg.json',
    'soc-seasonal-operator-os-initial-controls.json',
    'soc-seasonal-operator-os-review85-preparation.tar.gz',
    'soc-seasonal-operator-os-review85-to-final.diff',
    'soc-seasonal-operator-os-execution-self-review.json',
    'soc-seasonal-operator-os-qstat.snapshot.txt',
    'soc-seasonal-operator-os-qstat.second-snapshot.txt']
artifacts = {name: (ROOT/name).read_bytes() for name in names}
assert sha(artifacts['soc-seasonal-operator-os-actual-independent-review-rg.json']) == 'bec584e0f7e2af94f53a4f28abd41db90562693193bc5084b9d4e9c856c05bdd'
with tarfile.open(fileobj=io.BytesIO(original_raw)) as archive:
    for name in ['actual-pbs-qstat.txt', 'current/receipt.json',
                 'current/quantified-synthetic-diagnostics.json',
                 'current/unittest.stdout.txt', 'current/unittest.stderr.txt']:
        artifacts['actual-readout/'+name] = archive.extractfile(name).read()
artifacts['package_soc_operator_os_public.py'] = Path(__file__).read_bytes()
inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in artifacts.items()}
artifacts['inventory.json'] = (json.dumps(inventory, indent=2)+'\n').encode()
destination = ROOT/(label+'-evidence.tar.gz')
assert not destination.exists()
with tarfile.open(destination, 'w:gz') as archive:
    for name, raw in sorted(artifacts.items()):
        item = tarfile.TarInfo(name); item.size = len(raw); item.mode = 0o644
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(destination) as archive:
    assert {m.name: archive.extractfile(m).read() for m in archive} == artifacts
package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
    artifacts=len(artifacts), publication_label=label, pbs_job='1601.manager', actual_pbs_state='F',
    actual_pbs_exit=0, actual_worker_exit=0, actual_unittest_parent_exit=0, tests=17, test_seconds=0.429,
    closed_evidence_sha256=sha(original_raw), closed_package_sha256=sha(original_package_raw),
    actual_review_sha256=sha(artifacts['soc-seasonal-operator-os-actual-independent-review-rg.json']),
    production_binding_sealed=False, actual_year_runs=0, gpu_runs=0,
    scope='Actual EHPC1601 F0/worker0/parent0, 17 synthetic-only conditional-C operator/extraction-boundary tests. Original40-member evidence archive/package remain byte-exact; concise readouts, independent reviews and original preparation history are added. No actual annual payload analysis, field periodic solution, usable cold initializer, coupled model/GPU run, or SOC/spinup acceptance. Production binding remains false.')
(ROOT/(label+'-package.json')).write_text(json.dumps(package, indent=2)+'\n', encoding='utf-8')
print(json.dumps(package, indent=2))

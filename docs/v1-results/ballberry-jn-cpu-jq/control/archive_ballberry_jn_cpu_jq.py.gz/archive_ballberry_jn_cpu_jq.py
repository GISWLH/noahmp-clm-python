from pathlib import Path
import hashlib,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'ballberry-jn-full';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'dispatch.json').read_text());raw=subprocess.check_output(['qstat','-xf',launch['pbs_job']],text=True);assert re.search(r'^\s*job_state = F\s*$',raw,re.M) and re.search(r'^\s*Exit_status = 0\s*$',raw,re.M) and (r/'pbs-exit.txt').read_text().strip()=='0';(r/'actual-pbs-qstat.txt').write_text(raw);d=json.loads((r/'receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and d['pytest_returncode']==0 and d['counts']==dict(tests=1156,failures=0,errors=0,skipped=0) and sha(r/'junit.xml')==d['xml_sha256'];assert all(sha(r/n)==h for n,h in launch['controls'].items());archive=b/'ballberry-jn-cpu-jq-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():assert not p.is_symlink();n=p.relative_to(r).as_posix();inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
    plan=json.loads((r/'package.json').read_text());p=b/plan['archive'];assert sha(p)==plan['archive_sha256'];n='frozen-source/'+p.name;inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
    p=Path(__file__);n='control/'+p.name;inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),scope='ActualEHPC1183F0 ownJN581 fullCPU1156 originalnodes/source/XML, no failure/error/skip, fullcollection/control/log/XML and independentBrent864roots preflight retained; onlytest_root changed versusIV, allproduction/GPUtests/fixtures/benchmarks identical. No GPU407/canonical1563/year/spinup/observational/release acceptance.');(b/'ballberry-jn-cpu-jq-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

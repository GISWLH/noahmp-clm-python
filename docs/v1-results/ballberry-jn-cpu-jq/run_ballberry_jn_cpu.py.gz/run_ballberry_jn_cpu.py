from pathlib import Path
import hashlib,json,os,pickle,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];assert mode in ['full','references'];r=b/('ballberry-jn-'+mode);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();plan=json.loads((r/'package.json').read_text());s=Path(os.environ['TMPDIR'])/'source';s.mkdir();a=b/plan['archive'];assert sha(a)==plan['archive_sha256']
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest==plan['source_manifest_sha256'] and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks',r])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None);start=time.monotonic();sys.path[:0]=env['PYTHONPATH'].split(':')
files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
selected=files if mode=='full' else ['tests/'+f for f in plan['targets']]
collection=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q',*selected],cwd=s,env=env,capture_output=True,text=True);(r/'collection.log').write_text(collection.stdout+collection.stderr);nodes=[v for v in collection.stdout.splitlines() if v.startswith('tests/') and '::' in v];assert collection.returncode==0 and len(nodes)==len(set(nodes));(r/'nodes.json').write_text(json.dumps(nodes,indent=2)+'\n')
if mode=='full':
    assert len(nodes)==plan['cpu_expected']==1156
    with (r/'brent-preflight.log').open('x') as log:preflight=subprocess.run([sys.executable,'-m','pytest','-q','-s','tests/test_leaf_root.py','--junitxml='+str(r/'brent-preflight.xml')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    precount={k:sum(int(q.attrib[k]) for q in ET.parse(r/'brent-preflight.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};assert preflight==0 and precount==dict(tests=1,failures=0,errors=0,skipped=0)
    with (r/'pytest.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*selected,'--junitxml='+str(r/'junit.xml')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    counts={k:sum(int(q.attrib[k]) for q in ET.parse(r/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};passed=code==0 and counts==dict(tests=1156,failures=0,errors=0,skipped=0)
    d=dict(passed=passed,pytest_returncode=code,counts=counts,xml_sha256=sha(r/'junit.xml'))
else:
    from ballberry_reference_key_iv import key
    import test_gpu_photosynthesis as leaf
    import test_gpu_canopy_energy as canopy
    import test_gpu_canopy_phase_energy as phase
    import test_gpu_clm_enthalpy_column as enthalpy
    import test_gpu_clm_layered_column as layered
    from noahmp_clm.physics.photosynthesis import LeafParameters
    cache={};requests=[];inputs={}
    def evaluate(family,function,*args,**kwargs):
        signature=key(family,args,kwargs);value=function(*args,**kwargs)
        if signature in cache:
            def same(a,b):
                from dataclasses import fields,is_dataclass
                if is_dataclass(a):return type(a)==type(b) and all(same(getattr(a,f.name),getattr(b,f.name)) for f in fields(a))
                if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
                if isinstance(a,(tuple,list)):return type(a)==type(b) and len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
                if a is None:return b is None
                x,y=np.asarray(a),np.asarray(b);return x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes()
            assert same(cache[signature],value),signature
        else:cache[signature]=value
        requests.append(dict(family=family,key=signature));inputs[signature]=dict(args=args,kwargs=kwargs);print('reference',family,len(requests),flush=True)
    for dtype in [np.float32,np.float64]:
        u=leaf.leaf_cases(dtype);evaluate('leaf',leaf.ordinary,u,LeafParameters(tpu25=8.))
        evaluate('leaf',leaf.ordinary,u[u[:,0]==0.],LeafParameters(vcmax25=80.,respiration25=1.,minimum_conductance=.002))
        evaluate('canopy',canopy.numpy_reference,canopy.cases(dtype))
        for row in zip(*phase.batch(dtype)):evaluate('phase',phase.reference,row)
        for family,module in [('enthalpy',enthalpy),('layered',layered)]:
            arrays,forcing,deposition=module.cases(dtype)
            for i,row in enumerate(zip(*arrays)):evaluate(family,module.reference,row,forcing[i],deposition[i])
    for name in ['canopy_phase_humidity_bound.json','canopy_phase_humidity_slow.json']:
        saved=json.loads((s/'tests/fixtures'/name).read_text());row=tuple(np.asarray(v,np.int32 if k==8 else np.float64) for k,v in enumerate(saved['arrays']));evaluate('phase',phase.reference,row,tolerance=1e-7)
    for name in ['qia_479_phase_jacobian.npz','phase_edge_float64_stencil.npz']:
        with np.load(s/'tests/fixtures'/name,allow_pickle=False) as saved:
            arrays=tuple(saved['a'+str(k)] for k in range(9));extension=saved['extension']
        evaluate('phase',phase.reference,arrays,exchange_extension=extension,tolerance=1e-7,max_iterations=80)
    (r/'references.pkl').write_bytes(pickle.dumps(cache,protocol=5));(r/'inputs.pkl').write_bytes(pickle.dumps(inputs,protocol=5));(r/'requests.json').write_text(json.dumps(requests,indent=2)+'\n');passed=True;d=dict(passed=True,keys=len(cache),requests=len(requests),references_sha256=sha(r/'references.pkl'),inputs_sha256=sha(r/'inputs.pkl'),key_helper_sha256=sha(r/'ballberry_reference_key_iv.py'),target_nodes=nodes)
d.update(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),seconds=time.monotonic()-start,mode=mode,scope=plan['scope']);(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);raise SystemExit(0 if d['passed'] and d['source_unchanged'] else 1)

"""Prepare first calibration/init year without accessing held-out flux scores."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
import numpy as np
from run_fluxnet_column import build_state,totals
from noahmp_clm.physics.phenology import critical_gdd

base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-deposition-runner-b'
root=base/'fluxnet-first-climate-cycle-20261017-a';root.mkdir(exist_ok=False)
inputs=root/'inputs';inputs.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[];batch=[]
for site,year in [('CN-Cng',2007),('CN-Qia',2003),('CN-Cha',2003),('CN-HaM',2001)]:
    parent=source/'inputs'/(site+'-config.json');config=json.loads(parent.read_text())
    full=base/'fluxnet-multiyear-inputs-20261017-a'/(site+'.npz');mf=full.with_suffix('.json');meta=json.loads(mf.read_text())
    assert sha(full)==meta['prepared_npz_sha256']
    with np.load(full,allow_pickle=False) as z:data=dict(z)
    mask=np.char.startswith(data['time_start'],str(year));assert mask.sum()==17520
    n=len(mask);values={k:v[mask] if v.ndim>0 and len(v)==n else v for k,v in data.items()}
    p=inputs/(site+'.npz');np.savez_compressed(p,**values)
    meta.update(scope='Full first-year meteorology for initial climate cycle; not spun-up simulation or observational acceptance',
        parent_prepared_npz_sha256=sha(full),parent_manifest_sha256=sha(mf),prepared_npz_sha256=sha(p),steps=17520,
        start=f'{year}-01-01',end_exclusive=f'{year+1}-01-01')
    mp=inputs/(site+'.json');mp.write_text(json.dumps(meta,indent=2)+'\n')
    # Uniform physical seed. No measured shallow SWC is extrapolated to depth
    # and no candidate from the scored July diagnostic is selected.
    ts=float(values['obs_TS_F_MDS_1'][0]);qc=float(values['qc_TS_F_MDS_1'][0])
    observed=bool(np.isfinite(ts) and ts>-9990 and qc==0)
    tk=ts+273.15 if observed else float(values['forcing'][:48,1].mean())
    assert 200<tk<330
    c=config['column'];nl=len(c['dz']);c.update(tsoil=[tk]*nl,ts=tk,smc=[c['soil']['smcref']]*nl,canw=0.,swe=0.)
    b=config['biogeochemistry'];plant=b['plant_state'];before_cn=[sum(plant['carbon'])+plant['reserve_carbon'],sum(plant['nitrogen'])+plant['reserve_nitrogen']]
    if config['phenology'] is not None:
        plant['reserve_carbon']+=plant['carbon'][0];plant['reserve_nitrogen']+=plant['nitrogen'][0]
        plant['carbon'][0]=0.;plant['nitrogen'][0]=0.;c['lai']=0.
        config['phenology']['initial']=dict(gdd=0.,leaf_fraction=0.,remaining_seconds=0.,phase=0,armed=True)
        config['phenology']['parameters']['gdd_threshold']=critical_gdd(float(values['forcing'][:,1].mean()))
    after_cn=[sum(plant['carbon'])+plant['reserve_carbon'],sum(plant['nitrogen'])+plant['reserve_nitrogen']]
    np.testing.assert_allclose(before_cn,after_cn,rtol=2e-15,atol=0)
    config.update(case=site+'-initial-climate-cycle',scope='First complete calibration/init-year climate cycle from explicit cold seed; no spinup or calibration claim',
        parent_configuration_sha256=sha(parent),initialization=dict(
            temperature_source='First interval QC0 shallow soil temperature extended uniformly' if observed else 'First-day mean forcing air temperature, because first shallow soil temperature is missing or not QC0',
            uniform_temperature_k=tk,water_source='Uniform field capacity as an unobserved spinup seed, no July sensitivity winner selected',
            uniform_total_water_m3m3=c['soil']['smcref'],initial_snow_unknown_set_to_zero=True,
            seasonal_leaf_carbon_nitrogen_transferred_to_reserve=config['phenology'] is not None))
    # Older execution-check assumptions do not describe this new initial state.
    config['assumptions']=[
        'Parent soil/plant/roughness/leaf parameters and fixed literature baseline heights retained; not tuned to July or held-out scores.',
        'Initial vertical temperature and water are explicit spinup seeds, not a measured full profile. No initial snow observation is available.',
        'Seasonal leaves begin dormant; their parent seed C/N is moved into reserves without changing plant total C/N.',
        'Seasonal GDD threshold uses the existing critical_gdd formula with mean forcing air temperature of this first non-held-out year.',
        'Fixed year-2000 deposition climatology retains the documented source and missing-N-loss limitations.',
        'HaM gap-filled precipitation credibility remains unresolved; no precipitation rescaling is applied.'
    ]
    state=build_state(config)
    cp=inputs/(site+'-config.json');cp.write_text(json.dumps(config,indent=2,allow_nan=False)+'\n')
    batch.append(dict(case=config['case'],input=str(p),input_manifest=str(mp),configuration=str(cp)))
    records.append(dict(site=site,year=year,configuration_sha256=sha(cp),forcing_sha256=sha(p),
        initial_m_h_c_n=totals(state).tolist(),initialization=config['initialization'],
        lai=state.lai,gdd_threshold=None if config['phenology'] is None else config['phenology']['parameters']['gdd_threshold']))
(root/'batch.json').write_text(json.dumps({'cases':batch},indent=2)+'\n')
protocol=dict(locked_utc=datetime.now(timezone.utc).isoformat(),scope='First complete initialization year, prerequisite for repeated climate spinup; not claiming convergence',
    source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),instrument_sha256=sha(Path(__file__)),
    forcing_selection='First available non-held-out year at each site; 365 days, exact original timestamps/QC',
    evaluation_policy='No pass/fail claim from initial-year flux scores; retain all cases and conservation ledgers. Existing calibration/holdout split stays fixed.',
    subsequent_spinup_assessment=dict(minimum_cycles=2,
        hydro_end_cycle_max_soil_temperature_change_k=.1,hydro_end_cycle_max_soil_water_change_m3m3=.001,
        hydro_end_cycle_swe_change_mm=.5,hydro_require_consecutive_checks=2,
        soil_carbon_relative_drift_per_100_years_max=.05,
        note='Hydrological and soil-carbon convergence reported separately; cycling itself is not convergence. Positive N deposition without modeled N losses prevents a claim of total-N equilibrium.'),
    cases=records)
(root/'protocol.json').write_text(json.dumps(protocol,indent=2,allow_nan=False)+'\n')
print(json.dumps(protocol,indent=2),flush=True)

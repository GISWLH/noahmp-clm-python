"""Validate first day against NumPy, then resume the same native annual run."""
from pathlib import Path
import json,os,subprocess,traceback
from compare_station_backend_day import compare
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-deposition-runner-b';root=base/'fluxnet-first-climate-cycle-20261017-a'
exe='/home/lhwang/venvs/noahmp-phase3b/bin/python';env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:tests:benchmarks',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin')
batch=json.loads((root/'batch.json').read_text());jobs=[]
def launch(command,logname):
    with (root/logname).open('w') as log:
        p=subprocess.Popen([exe,'-u',*command],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    jobs.append((p,logname));return p
try:
    launch(['benchmarks/run_fluxnet_native.py','--batch',str(root/'batch.json'),'--output',str(root/'cuda-year'),'--stop-after','48'],'cuda-first-day.log')
    for row in batch['cases']:
        launch(['benchmarks/run_fluxnet_column.py','--input',row['input'],'--input-manifest',row['input_manifest'],
            '--config',row['configuration'],'--output',str(root/'numpy-day'/row['case']),'--stop-after','48'],row['case']+'-numpy.log')
    (root/'launch.json').write_text(json.dumps([dict(pid=p.pid,log=l) for p,l in jobs],indent=2)+'\n')
    codes=[dict(log=l,returncode=p.wait()) for p,l in jobs]
    (root/'first-day-exit.json').write_text(json.dumps(codes,indent=2)+'\n')
    assert all(row['returncode']==0 for row in codes),codes
    compare(root,'cuda-year','numpy-day')
    p=launch(['benchmarks/run_fluxnet_native.py','--batch',str(root/'batch.json'),'--output',str(root/'cuda-year'),'--resume'],'cuda-annual-resume.log')
    (root/'annual-launch.json').write_text(json.dumps(dict(pid=p.pid,first_day_backend_validation='complete',scope='First annual climate cycle still requires all 17520 steps; not spinup convergence'),indent=2)+'\n')
    print('annual resume',p.pid,flush=True)
except Exception:
    (root/'controller-failure.txt').write_text(traceback.format_exc());raise

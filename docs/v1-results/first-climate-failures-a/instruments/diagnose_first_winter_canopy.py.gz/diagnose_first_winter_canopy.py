"""Read-only failed first-year input replay, retaining inner residual evidence."""
from pathlib import Path
import json,pickle,inspect,traceback
import numpy as np
import noahmp_clm.physics.canopy_phase_energy as ce
from run_fluxnet_column import build_state,calendar
from fluxnet_deposition import DepositionSchedule
from noahmp_clm.column import Forcing
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters

root=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-a');out=root/'winter-diagnosis';out.mkdir(exist_ok=False)
original=ce.solve_canopy_phase_energy
captured={}
def snapshot(local):
    for key in ('x','residual','jac','delta','mass','lower','upper','leaf','root_h'):
        captured[key]=np.asarray(local[key]).copy()
    captured['boundary']=dict(fixed_ground_temperature=local['fixed_ground_temperature'],air_temperature=local['e'].air_temperature,
        specific_humidity=local['e'].specific_humidity,iteration=local['iteration'])
    captured['detail']=local['evaluate'](local['x'],True)
    probes=[]
    for k in np.flatnonzero((local['mass']==0)&(abs(local['x'][:len(local['mass'])])<1e-3)):
        for offset in [-1e-4,-1e-7,0.,1e-7,1e-4]:
            trial=local['x'].copy();trial[k]=offset;d=local['evaluate'](trial,True)
            probes.append(dict(layer=int(k),offset=offset,residual=d['solver_residual'].tolist(),
                leaf_temperature=d['leaf_temperature'].tolist(),wet_evaporation=d['wet_evaporation'].tolist(),
                final_mass=d['condensate'].mass.tolist(),final_enthalpy=d['condensate'].enthalpy.tolist()))
    captured['freezing_probes']=probes
    # Persist only data and callable arguments, no function or frame objects.
    (out/'inner-snapshot.pkl').write_bytes(pickle.dumps(captured))
    simple={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in captured.items() if k!='detail'}
    simple['detail']={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in captured['detail'].items() if isinstance(v,(np.ndarray,float,int))}
    (out/'inner-snapshot.json').write_text(json.dumps(simple,indent=2,allow_nan=False)+'\n')
source=inspect.getsource(original)
needle="            raise RuntimeError(f'Canopy phase Newton stalled"
assert needle in source
source=source.replace(needle,"            _snapshot(locals())\n"+needle)
ns=dict(ce.__dict__);ns['_snapshot']=snapshot;exec(compile(source,'<diagnostic phase solver>','exec'),ns)
instrumented=ns['solve_canopy_phase_energy']
def wrapped(*args,**kwargs):
    try:return instrumented(*args,**kwargs)
    except RuntimeError:
        (out/'inner-arguments.pkl').write_bytes(pickle.dumps((args,kwargs)));raise
ce.solve_canopy_phase_energy=wrapped
cfg=json.loads((root/'inputs/CN-Qia-config.json').read_text());meta=json.loads((root/'inputs/CN-Qia.json').read_text());state=build_state(cfg)
with np.load(root/'inputs/CN-Qia.npz') as z:data=dict(z)
from datetime import datetime
stamp=datetime.strptime(str(data['time_start'][0]),'%Y%m%d%H%M');f=Forcing(*data['forcing'][0]);dep=DepositionSchedule(cfg)
try:
    step_clm_enthalpy_column(state,f,co2_ppm=float(data['environment'][0,0]),cosine_zenith=float(data['environment'][0,1]),diffuse_fraction=float(data['environment'][0,2]),
        leaf_dimension=cfg['leaf_dimension_m'],leaf_parameters=LeafParameters(**cfg['leaf_parameters']),most_geometry=MOSTGeometry(**cfg['most_geometry']),
        phenology_environment=calendar(stamp,meta,cfg['phenology'] is not None),deposition_rates=dep.aerosol(stamp,f.dt),nitrogen_deposition_gn_m2=dep.nitrogen_rate*f.dt)
except RuntimeError:
    (out/'failure.txt').write_text(traceback.format_exc());print(json.dumps(captured['boundary']));print('x',captured['x']);print('residual',captured['residual']);print('wet',captured['detail']['wet_evaporation']);print('probe count',len(captured['freezing_probes']))

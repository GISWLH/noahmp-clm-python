"""In-memory physical candidate: new deposition can be mixed phase at Tf."""
from pathlib import Path
import inspect,pickle,json,traceback
import numpy as np
import noahmp_clm.physics.canopy_phase_energy as ce
root=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-a/winter-diagnosis')
args,kw=pickle.loads((root/'inner-arguments.pkl').read_bytes())
source=inspect.getsource(ce.solve_canopy_phase_energy)
changes={
    '    def evaluate(z,details=False):':'    phase_active=mass>0.\n    activations=0\n\n    def evaluate(z,details=False):',
    'leaf_t,thermal_h=_decode(z[:n],mass)':'leaf_t,thermal_h=_phase_decode(z[:n],mass,phase_active)',
    'out=np.asarray(leaf_t>TF,dtype=float),where=mass>0.)':'out=np.where(phase_active,np.clip(z[:n]*CW/LF,0.,1.),np.asarray(leaf_t>TF,dtype=float)),where=mass>0.)',
    '_equilibrium_vapor(heated,dt*wet_demand,leaf_t)':'_phase_vapor(heated,dt*wet_demand,leaf_t,liquid_area)',
    "        depleted=(mass>0.)&(detail['condensate'].mass==0.)":"        fresh=(~phase_active)&active&(abs(x[:n])<=.05)&(detail['wet_evaporation']<0.)\n        if np.any(fresh):\n            phase_active|=fresh;activations+=int(fresh.sum())\n            x[:n]=np.where(fresh,np.where(x[:n]<0.,x[:n]*CI/CW,LF/CW+x[:n]),x[:n])\n            alternative[:n]=np.where(fresh,np.where(alternative[:n]<0.,alternative[:n]*CI/CW,LF/CW+alternative[:n]),alternative[:n])\n            lower[:n]=np.where(fresh,(200.-TF)*CI/CW,lower[:n]);upper[:n]=np.where(fresh,LF/CW+350.-TF,upper[:n])\n            residual=evaluate(x);detail=evaluate(x,True)\n        depleted=phase_active&(detail['condensate'].mass==0.)",
    "result['restarts']=restarts":"result['restarts']=restarts;result['dry_phase_activations']=activations",
}
for old,new in changes.items():
    assert old in source,old;source=source.replace(old,new)
def decode(z,m,flag):
    t=ce.TF+np.minimum(z,0.)*ce.CW/ce.CI+np.maximum(z-ce.LF/ce.CW,0.)
    return np.where(flag,t,ce.TF+z),m*ce.CW*z
def vapor(state,amount,temperature,fraction):
    mass=state.mass;heat=state.enthalpy
    loss=np.minimum(np.maximum(amount,0.),mass);deposit=np.maximum(-amount,0.)
    remaining=mass-loss;retained=np.divide(remaining,mass,out=np.zeros_like(mass),where=mass>0.)*heat
    liquid=(loss-deposit)*fraction;ice=(loss-deposit)-liquid
    added=deposit*((1.-fraction)*ce.CI*(temperature-ce.TF)+fraction*(ce.LF+ce.CW*(temperature-ce.TF)))
    advected=heat-retained-added
    final=ce.CanopyCondensate(remaining+deposit,retained+added)
    return final,dict(mass_kgm2=loss-deposit,ice_kgm2=ice,liquid_kgm2=liquid,
        advected_enthalpy_jm2=advected,latent_energy_jm2=ce.LV*(loss-deposit)+ce.LF*ice,
        unmet_evaporation_kgm2=np.maximum(amount-loss,0.))
ns=dict(ce.__dict__);ns.update(_phase_decode=decode,_phase_vapor=vapor);exec(compile(source,'<dry-condensation-probe>','exec'),ns)
try:
    result=ns['solve_canopy_phase_energy'](*args,**kw)
    simple={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in result.items() if isinstance(v,(np.ndarray,float,int))}
    simple.update(final_mass=result['condensate'].mass.tolist(),final_enthalpy=result['condensate'].enthalpy.tolist(),final_liquid=result['condensate'].liquid.tolist())
    (root/'candidate-inner-result.json').write_text(json.dumps(simple,indent=2,allow_nan=False)+'\n');print(json.dumps(simple,indent=2),flush=True)
except Exception:
    (root/'candidate-inner-failure.txt').write_text(traceback.format_exc());raise

"""Exact retained N=27 input; no state reset between independent trajectories."""
from pathlib import Path
import json,hashlib
import numpy as np
from dataclasses import astuple
from run_fluxnet_native import Backend,load_batch,calendar,pack_bgc_environment
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-native-fluxnet-b';run=root/'height-paired-a'
outdir=run/'failure-replay';outdir.mkdir(exist_ok=False)
report=json.loads((run/'batch.json').read_text());cases=load_batch(root/'height-batch.json');index=report['steps_completed']
with np.load(run/report['checkpoint_file']) as z:
    a=tuple(z[f'a{k}'] for k in range(16));shadow=tuple(z[f'shadow{k}'] for k in range(16))
for x,y in zip(a,shadow):np.testing.assert_array_equal(x,y)
geometry=np.asarray([astuple(MOSTGeometry(**c['config']['most_geometry'])) for c in cases],np.float32)
f=np.asarray([c['data']['forcing'][index] for c in cases],np.float32)
env=np.asarray([c['data']['environment'][index] for c in cases],np.float32)
e,cal=pack_bgc_environment([calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=np.float32)
kwargs=dict(environment=e,calendar=cal,most_geometry=geometry,leaf_parameters=LeafParameters(**cases[0]['config']['leaf_parameters']),return_surface=True)
inputs={f'a{k}':x for k,x in enumerate(a)};inputs.update(forcing=f,forcing_environment=env,environment=e,calendar=cal,geometry=geometry)
np.savez_compressed(outdir/'inputs.npz',**inputs)
results={}
def flatten(d,prefix=''):
    flat={}
    for k,v in d.items():
        key=prefix+k
        if isinstance(v,dict):flat.update(flatten(v,key+'/'))
        else:flat[key]=np.asarray(v)
    return flat
for name in ('cuda32','jax32'):
    engine=Backend(name);device=tuple(engine.xp.asarray(v) for v in a);before=engine.update_forcing(device,env)
    result=flatten(engine.host(engine.step(*before,f,**kwargs)));results[name]=result
    np.savez_compressed(outdir/(name+'.npz'),**result)
    print(name,dict(h=float(result['diagnostics/h'][24]),le=float(result['diagnostics/le'][24])),flush=True)
rows=[]
for key,a in results['cuda32'].items():
    b=results['jax32'][key]
    if a.dtype.kind in 'iub':bad=a!=b;scale=np.ones(a.shape)
    else:scale=1e-6*(1+abs(b.astype(float)));bad=abs(a.astype(float)-b.astype(float))>scale
    if np.any(bad):
        ids=np.argwhere(bad)
        rows.append(dict(field=key,count=len(ids),max_absolute=float(abs(a.astype(float)-b.astype(float)).max()),
            max_tolerance_ratio=float((abs(a.astype(float)-b.astype(float))/scale).max()),
            values=[dict(index=i.tolist(),cuda=float(a[tuple(i)]),jax=float(b[tuple(i)])) for i in ids[:30]]))
report=dict(scope='Exact step 13 N=27 same-input replay; all sixteen independently carried states were bitwise identical before the failed step',
    source_manifest_sha256=hashlib.sha256((root/'SOURCE_SHA256.json').read_bytes()).hexdigest(),
    step=index,case=cases[24]['case'],stamp=cases[24]['stamps'][index].isoformat(),violations=rows,
    artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in outdir.glob('*.npz')})
(outdir/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps(rows,indent=2),flush=True)

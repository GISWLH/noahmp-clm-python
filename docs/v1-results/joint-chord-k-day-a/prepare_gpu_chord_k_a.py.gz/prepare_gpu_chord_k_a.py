from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-k';root.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for filename,expected,dest in [('first-climate-h-inputs.tar.gz','98c03d7771abb8390b989bebc66f19f8d4e399babd71def053a8f36998bb0143',root),('numpy-current-reference-a-evidence.tar.gz','e3545c0ae01d579df81517864934ac31133d3441cb81b492c2d3275c4a09704c',root/'numpy-reference')]:
    archive=base/filename;assert sha(archive)==expected
    with tarfile.open(archive) as t:
        for m in t:
            p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
            target=dest/m.name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(t.extractfile(m).read())
original=(root/'batch.json').read_bytes();(root/'ehpc-batch.json').write_bytes(original);batch=json.loads(original)
for row in batch['cases']:
    for k in ['input','input_manifest','configuration']:row[k]=str(root/'inputs'/Path(row[k]).name)
(root/'batch.json').write_text(json.dumps(batch,indent=2)+'\n')
source=base/'p6-joint-chord-a';m=json.loads((source/'SOURCE_SHA256.json').read_text());ref=json.loads((root/'numpy-reference/SOURCE_SHA256.json').read_text());diff={n:dict(native=v,numpy=ref[n]) for n,v in m.items() if n.startswith('src/') and v!=ref[n]}
assert set(diff)=={'src/noahmp_clm/gpu/column_heat.py','src/noahmp_clm/gpu/cuda/column_heat_kernel.cu'} and all(sha(source/n)==v for n,v in m.items())
record=dict(scope='Fresh K cold seed from original locked physical configurations/forcing. Current independent NumPy121 references retain their original mixed running progress and 17520 request, with first48 used only for backend comparison. No failed J checkpoint reused; two GPU numerical solver files differ, NumPy physics identical.',source_files=len(m),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),numpy_reference_archive_sha256=sha(base/'numpy-current-reference-a-evidence.tar.gz'),input_archive_sha256=sha(base/'first-climate-h-inputs.tar.gz'),source_differences=diff,ehpc_batch_sha256=hashlib.sha256(original).hexdigest(),gpu_batch_sha256=sha(root/'batch.json'))
(root/'input-import.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

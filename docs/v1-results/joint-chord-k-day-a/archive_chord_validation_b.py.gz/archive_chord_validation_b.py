from pathlib import Path
import datetime,hashlib,io,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-joint-chord-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(m)==489 and all(sha(source/n)==v for n,v in m.items())
full=json.loads((source/'full-by-file-a/summary.json').read_text());assert full['status']=='complete' and full['covered_nodes']==full['collected_nodes']==1129 and full['source_unchanged'] and all(r['returncode']==0 and r['passed'] for r in full['results'])
for name,folder in [('joint-chord-gpu-full-a',source),('joint-chord-k-day-a',base/'fluxnet-first-climate-cycle-20261017-k')]:
    entries=[]
    if name=='joint-chord-gpu-full-a':
        for sub in ['target-a','full-by-file-a','continuation-a']:
            entries += [(p.relative_to(folder).as_posix(),p) for p in sorted((folder/sub).rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
        for n in ['SOURCE_SHA256.json','run_joint_chord_full_gpu_a.py','full-gpu-a-launch.json','full-gpu-a-controller.log','old-controller-supersession-a.json','old-full-c-progress-before.json']:entries.append((n,folder/n))
    else:
        r=json.loads((folder/'backend-day-comparison.json').read_text());g=json.loads((folder/'cuda-day/batch.json').read_text());assert r['failures']==[] and g['steps_completed']==48 and g['status']=='running' and g['identity']['compare_jax32']
        for sub in ['cuda-day','numpy-reference']:entries += [(p.relative_to(folder).as_posix(),p) for p in sorted((folder/sub).rglob('*')) if p.is_file()]
        for n in ['batch.json','ehpc-batch.json','input-import.json','run_gpu_chord_k_day_a.py','cuda-day-launch.json','cuda-day-controller.log','cuda-day.log','cuda-day-exit.json','backend-day-comparison.json']:entries.append((n,folder/n))
        entries.append(('SOURCE_SHA256.json',source/'SOURCE_SHA256.json'));entries.append(('prepare_gpu_chord_k_a.py',base/'prepare_gpu_chord_k_a.py'))
    archive=base/(name+'-evidence.tar.gz');assert not archive.exists()
    with tarfile.open(archive,'w:gz') as t:
        for n,p in entries:assert p.is_file();t.add(p,arcname=n,recursive=False)
        t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
    print(json.dumps(dict(name=name,files=len(entries)+1,sha256=sha(archive),bytes=archive.stat().st_size)))

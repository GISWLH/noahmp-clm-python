from pathlib import Path
import hashlib,json,subprocess,sys,time
import numpy as np
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-k';source=base/'p6-joint-chord-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());ref=json.loads((root/'numpy-reference/SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());begun=time.monotonic()
command=[sys.executable,'-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--stop-after','48','--compare-jax32']
with (root/'cuda-day.log').open('w') as log:code=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
(root/'cuda-day-exit.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun))+'\n');assert code==0
rows=[];failures=[]
for row in json.loads((root/'batch.json').read_text())['cases']:
    folders=[root/'cuda-day'/row['case'],root/'numpy-reference'/row['case']];reports=[json.loads((p/'report.json').read_text()) for p in folders]
    assert all(r['source_unchanged'] and r['status']=='running' and r['steps_requested']==17520 for r in reports) and reports[0]['steps_completed']==48 and reports[1]['steps_completed']>=48
    for key in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert reports[0][key]==reports[1][key]
    assert all(ref[n]==v for n,v in reports[1]['source_sha256'].items()) and all(m[n]==v for n,v in reports[0]['source_sha256'].items())
    data=[]
    for p,r in zip(folders,reports):
        path=p/r['model_npz'];assert sha(path)==r['model_npz_sha256']
        with np.load(path,allow_pickle=False) as z:data.append({n:z[n][:48] for n in z.files})
    for key in ['time_start','time_end']:np.testing.assert_array_equal(data[0][key],data[1][key]);assert len(data[0][key])==48
    fields={}
    for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
        a,b=[d[key].astype(float)*factor+offset for d in data]
        if a.ndim==1:a=a[:,None];b=b[:,None]
        values=[compare_series(a[:,k],b[:,k],var) for k in range(a.shape[1])]
        for k,v in enumerate(values):
            if not v['bias_pass']:failures.append([row['case'],key,k,'bias',v['bias']])
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and v['correlation_pass'] is False:failures.append([row['case'],key,k,'r',v['r']])
        fields[key]=values
    rows.append(dict(case=row['case'],metrics=fields,report_sha256=[sha(p/'report.json') for p in folders],original_report_steps=[r['steps_completed'] for r in reports],maximum_cumulative_m_h_c_n_original_report={name:r['maximum_cumulative_residual_m_h_c_n'] for name,r in zip(['cuda32_first48','numpy64_partial_parent'],reports)}))
assert all(sha(source/n)==v for n,v in m.items());g=json.loads((root/'cuda-day/batch.json').read_text());assert g['identity']['compare_jax32'] and g['steps_completed']==48 and g['source_unchanged']
result=dict(scope='Four fresh K first48 CUDA32 with independent carried JAX32 shadow and original per-column M/H/C/N bounds, versus first48 of actual current NumPy121 mixed-progress traces. Raw NumPy running reports not rewritten as complete48/full year. Backend validation only, no annual/spinup/observation acceptance.',cases=rows,failures=failures,source_differences=json.loads((root/'input-import.json').read_text())['source_differences'],same_precision_max_absolute=g['same_precision_max_absolute'],source_unchanged=True,seconds=time.monotonic()-begun)
(root/'backend-day-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(failures=failures,same_precision_max_absolute=g['same_precision_max_absolute'],cases=len(rows))),flush=True);assert not failures

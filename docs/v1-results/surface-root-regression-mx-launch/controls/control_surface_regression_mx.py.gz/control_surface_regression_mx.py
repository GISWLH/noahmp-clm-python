"""Sequential complete-module workers, original nodes and immutable ML source."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time
import traceback
from surface_regression_contract_mx import DERIVED, FILES, GPU_UUID, selected_nodes, sha, verify_preflight

r = Path(__file__).resolve().parent
plan = json.loads((r / 'plan.json').read_text())
s = Path(plan['source'])
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
verify = lambda: sha(s / 'SOURCE_SHA256.json') == DERIVED and all(sha(s / n) == h for n, h in manifest.items())
records = []
failure = None
started = time.monotonic()
try:
    assert verify() and len(manifest) == 581
    assert os.environ['CUDA_VISIBLE_DEVICES'] == GPU_UUID
    verify_preflight(r / 'preflight')
    nodes = selected_nodes(r / 'original-JO-collection.json')
    assert nodes == plan['nodes'] and sum(map(len, nodes.values())) == plan['total_original_nodes'] == 31
    assert all(sha(r / name) == digest for name, digest in plan['controls_sha256'].items())
    for name, count in FILES.items():
        while True:
            free = int(subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
            available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
            if free > 8192 and available > 32 * 1024 * 1024:
                break
            (r / 'waiting-resource.json').write_text(json.dumps(dict(file=name, gpu1_free_mib=free,
                host_available_kib=available, utc=datetime.datetime.now(datetime.timezone.utc).isoformat())) + '\n')
            time.sleep(20.)
        assert verify()
        stem = Path(name).stem
        expected = r / (stem + '-expected.json')
        expected.write_text(json.dumps(nodes[name], indent=2) + '\n')
        receipt, xml = r / (stem + '-receipt.json'), r / (stem + '.xml')
        env = os.environ.copy()
        diag = r / (stem + '-diagnostics')
        diag.mkdir()
        for key in ['NOAHMP_PHASE_COORDINATE_DIAGNOSTICS', 'NOAHMP_THIN_EVENT_DIAGNOSTICS']:
            env[key] = str(diag)
        begun = time.monotonic()
        with (r / (stem + '.log')).open('x') as log:
            process = subprocess.Popen([sys.executable, '-u', str(r / 'worker_surface_regression_mx.py'),
                '--source', str(s), '--test-file', str(s / 'tests' / name), '--expected', str(expected),
                '--receipt', str(receipt), '--xml', str(xml)], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT)
        (r / 'progress.json').write_text(json.dumps(dict(file=name, pid=process.pid, records=records), indent=2) + '\n')
        code = process.wait()
        evidence = json.loads(receipt.read_text()) if receipt.exists() else {}
        passed = bool(code == evidence.get('worker_exitcode') == evidence.get('pytest_returncode') == 0
            and evidence.get('passed') and evidence.get('source_unchanged')
            and evidence.get('source_manifest_sha256') == DERIVED
            and evidence.get('node_coverage_exact') and evidence.get('all_setup_call_teardown_phases_passed')
            and evidence.get('counts') == dict(tests=count, failures=0, errors=0, skipped=0)
            and evidence.get('expected_nodes_sha256') == sha(expected)
            and evidence.get('test_sha256') == manifest['tests/' + name]
            and xml.is_file() and evidence.get('xml_sha256') == sha(xml)
            and evidence.get('device_barriers') and all(v['status'] == 'complete' for v in evidence['device_barriers']))
        row = dict(file=name, pid=process.pid, expected_tests=count, counts=evidence.get('counts'),
                   actual_parent_returncode=code, passed=passed, seconds=time.monotonic() - begun,
                   receipt_sha256=sha(receipt) if receipt.exists() else None)
        records.append(row)
        (r / (stem + '-exit.json')).write_text(json.dumps(row, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        # Retain failed modules and continue independent modules; no retry or relabel.
except Exception as error:
    failure = type(error).__name__ + ': ' + str(error)
    (r / 'traceback.txt').write_text(traceback.format_exc())
unchanged = verify()
passed = failure is None and unchanged and len(records) == len(FILES) and all(v['passed'] for v in records)
result = dict(passed=passed, failure=failure, records=records, seconds=time.monotonic() - started,
              original_nodes_attempted=sum(v['expected_tests'] for v in records), total_original_nodes=31,
              source_manifest_sha256=DERIVED, source_unchanged=unchanged,
              scope=plan['scope'] + ' Actual parent exits, all phases/barriers/XML and unchanged source required. '
              'Original bounded_cache_guard_gd lifecycle retained; its per-call bound covers wrapped Backend.step, '
              'not every direct component invocation. Independent files continue after scientific failure.')
(r / 'exit.json').write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(0 if passed else 1)

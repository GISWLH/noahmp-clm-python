"""Reuse original pytest completion/async-barrier lifecycle and resource plugin."""
from pathlib import Path
import json
import os
import runpy
from surface_regression_contract_mx import DERIVED, GUARD, WORKER, sha

r = Path(__file__).resolve().parent
plan = json.loads((r / 'plan.json').read_text())
s = Path(plan['source'])
assert sha(s / 'SOURCE_SHA256.json') == plan['derived_manifest_sha256'] == DERIVED
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 581 and all(sha(s / name) == digest for name, digest in manifest.items())
assert sha(r / 'run_pytest_worker_a.py') == WORKER
assert sha(r / 'bounded_cache_guard_gd.py') == GUARD
os.environ['PYTEST_PLUGINS'] = 'bounded_cache_guard_gd'
# Legacy original mixed GPU module tests retain their small embedded NumPy
# comparisons. No new CPU annual/reference job is started on xuanze.
runpy.run_path(str(r / 'run_pytest_worker_a.py'), run_name='__main__')

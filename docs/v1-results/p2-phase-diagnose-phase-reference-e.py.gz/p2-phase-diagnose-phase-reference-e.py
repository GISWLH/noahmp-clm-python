import inspect,json,numpy as np
import test_canopy_phase_energy as ref
from check_canopy_phase_energy_reference import random_cases
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
name,a,sw,lw,e,c,kw=list(random_cases(16))[15]
got=solve_canopy_phase_energy(a,sw,lw,e,c,1800.,**kw)
source=inspect.getsource(ref.independent_reference);start=source.index('    initial=np.r_[')
ns=ref.__dict__.copy();exec(source[:start]+'    return evaluate\n',ns)
evaluate=ns['independent_reference'](a,sw,lw,e,c,1800.,**kw)
state=np.r_[got['phase_coordinates'],got['ground_temperature'],got['canopy_humidity']*1000.]
print('DIAGNOSTIC_ONLY_PRODUCTION_IN_INDEPENDENT_EQUATIONS',evaluate(state).tolist(),flush=True)
source=inspect.getsource(ref.independent_reference).replace("fitted=least_squares(evaluate,guess,bounds=", "fitted=least_squares(evaluate,guess,method='dogbox',bounds=")
exec(source,ns)
answer=ns['independent_reference'](a,sw,lw,e,c,1800.,**kw)
print('DOGBOX_FROM_INDEPENDENT_GUESSES',json.dumps({k:v.tolist() if isinstance(v,np.ndarray) else v for k,v in answer.items()}),flush=True)

from pathlib import Path
import hashlib,json,sys,tarfile

mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='numpy':
    base=Path('/home/zhangyq/noahmp-v1');name='clm-capacity-numpy-cde'
    roots=['clm-capacity-numpy-c','clm-capacity-numpy-d','canopy-capacity-cpu-a','clm-capacity-cpu-d','clm-capacity-reference-e']
    expectations=[(49,2,1),(49,0,0),(969,0,0),(977,0,0),(53,0,0)]
    files=[]
    for relative,(tests,failures,code) in zip(roots,expectations):
        root=base/relative;receipt=json.loads((root/'receipt.json').read_text())
        assert receipt['returncode']==code and receipt['source_unchanged'] and receipt['counts']==dict(tests=tests,failures=failures,errors=0,skipped=0)
        assert (root/'pbs-exit.txt').read_text().strip()==str(code)
        files.extend((p.relative_to(base).as_posix(),p) for p in sorted(root.rglob('*')) if p.is_file())
    reference=json.loads((base/'clm-capacity-reference-e/reference.json').read_text());assert reference['source_unchanged'] and len(reference['whole_audits'])==32
    controls=['dispatch_clm_capacity_numpy_c.py','dispatch_clm_capacity_numpy_d.py','dispatch_canopy_capacity_cpu_a.py','dispatch_clm_capacity_cpu_d.py','dispatch_clm_capacity_reference_e.py']
    sources=['clm-capacity-numpy-c-source.tar.gz','clm-capacity-numpy-d-source.tar.gz','clm-capacity-reference-e-source.tar.gz']
elif mode=='probe':
    base=Path('/home/lhwang/work/noahmp-v1');root=base/'capacity-division-probe-b';name='capacity-division-probe-b'
    receipt=json.loads((root/'receipt.json').read_text());assert receipt['source_unchanged'] and receipt['results']['reciprocal']['maximum_absolute_difference']==0.
    files=[(p.name,p) for p in sorted(root.iterdir()) if p.is_file()]
    files.extend(('source/'+name,base/'canopy-capacity-gpu-a'/name) for name in ['SOURCE_SHA256.json','src/noahmp_clm/gpu/cuda/canopy_capacity_kernel.cu','src/noahmp_clm/gpu/canopy_capacity.py'])
    controls=['probe_capacity_division_b.py'];sources=[]
elif mode=='cpu':
    base=Path('/home/zhangyq/noahmp-v1');root=base/'clm-capacity-cpu-f';name='clm-capacity-cpu-f'
    receipt=json.loads((root/'receipt.json').read_text());assert receipt['returncode']==0 and receipt['source_unchanged'] and receipt['counts']==dict(tests=981,failures=0,errors=0,skipped=0)
    assert (root/'pbs-exit.txt').read_text().strip()=='0'
    files=[(p.relative_to(root).as_posix(),p) for p in sorted(root.rglob('*')) if p.is_file()]
    controls=['dispatch_clm_capacity_cpu_f.py'];sources=['clm-capacity-final-f-source.tar.gz']
else:
    assert mode=='target'
    base=Path('/home/lhwang/work/noahmp-v1');root=base/'clm-capacity-final-f/target-f';name='clm-capacity-target20-f'
    receipt=json.loads((root/'exit.json').read_text());assert receipt['passed'] and receipt['returncode']==0 and receipt['source_unchanged'] and len(receipt['results'])==3
    files=[(p.relative_to(root).as_posix(),p) for p in sorted(root.rglob('*')) if p.is_file()]
    files.append(('SOURCE_SHA256.json',base/'clm-capacity-final-f/SOURCE_SHA256.json'))
    controls=['collect_clm_capacity_target_f.py','control_clm_capacity_target_f.py','launch_clm_capacity_target_f.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']
    sources=['clm-capacity-final-f-package.json']
archive=base/(name+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for name,path in files:tf.add(path,arcname=name,recursive=False)
    for name in controls:tf.add(base/name,arcname='control/'+name,recursive=False)
    for name in sources:tf.add(base/name,arcname='source/'+name,recursive=False)
    tf.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size)))

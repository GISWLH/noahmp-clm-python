from pathlib import Path
import hashlib
import json
import os
import sys
import time
import numpy as np

base=Path('/home/lhwang/work/noahmp-v1');source=base/'canopy-capacity-gpu-a';root=base/'capacity-division-probe-b'
assert not root.exists();root.mkdir();sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(manifest)==527 and all(sha(source/n)==h for n,h in manifest.items())
sys.path[:0]=[str(source/'src')]
import cupy as cp
import jax
import jax.numpy as j
from noahmp_clm.gpu.canopy_capacity import _capacity_compiled
fixture=source/'tests/fixtures/canopy_capacity_reference.npz'
assert sha(fixture)=='b9ef698abed91d10e462ff02c45185f39b2a1981cfce661cc9db79f0b1437f33'
with np.load(fixture,allow_pickle=False) as z:inputs=[z['32/'+k] for k in ['leaf','environment','traits','template']]
start=time.monotonic();expected=_capacity_compiled()(*map(j.asarray,inputs));expected.block_until_ready();target=cp.asarray(np.asarray(expected))
code=(source/'src/noahmp_clm/gpu/cuda/canopy_capacity_kernel.cu').read_text();arrays=tuple(cp.asarray(v) for v in inputs);record={};raw={'jax':np.asarray(expected)}
for label,options in [('original',('--std=c++14','--fmad=false')),('reciprocal',('--std=c++14','--fmad=false','--prec-div=false'))]:
    kernel=cp.RawKernel(code,'canopy_capacity',options=options);actual=cp.empty((32,126),cp.float32)
    kernel((1,),(128,),(*arrays,actual,np.int32(32)));cp.cuda.runtime.deviceSynchronize()
    difference=cp.abs(actual.astype(cp.float64)-target.astype(cp.float64));bound=1e-6+1e-6*cp.abs(target.astype(cp.float64))
    record[label]=dict(options=list(options),maximum_absolute_difference=float(difference.max()),maximum_gate_ratio=float((difference/bound).max()),
                       elements_different=int(cp.count_nonzero(actual!=target)),passed_original_gate=bool(cp.all(difference<=bound)))
    raw[label]=cp.asnumpy(actual)
np.savez_compressed(root/'allraw32.npz',**raw)
jax.effects_barrier();cp.cuda.runtime.deviceSynchronize();unchanged=all(sha(source/n)==h for n,h in manifest.items())
receipt=dict(scope='Controlled isolated GPU arithmetic diagnosis, exact original527A kernel/source and all126x32 raw fields. Original true-division and reciprocal-division options compared to nativeJAX; no production/kernel-source change, no pytest/whole-column/full/science credit. Process atexit bypass after complete barriers/durable receipt.',
             pbs_job=None,pid=os.getpid(),results=record,source_unchanged=unchanged,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),
             seconds=time.monotonic()-start,raw_sha256=sha(root/'allraw32.npz'))
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
sys.stdout.flush();sys.stderr.flush();os._exit(0 if unchanged and all(v['passed_original_gate'] for v in record.values()) else 1)

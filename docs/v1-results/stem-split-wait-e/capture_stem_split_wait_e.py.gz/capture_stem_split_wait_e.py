from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-e';r=s/'target-a'
if (r/'summary.json').exists():print('Target already terminal; read original summary');raise SystemExit(0)
d=json.loads((r/'progress.json').read_text());pid=d['active']['pid'];proc=Path('/proc')/str(pid);cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert str(s) in cmd and d['active']['file'] in cmd
v=dict(scope='Read-only frozen506E native matrix wait observation; active file is not credited before original full phases/device barriers and real worker exit. Interpreter-shutdown scope and earlier float64 input failure remain separate. No process/device/source/gate change.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active=d['active'],completed=[dict(file=x['file'],passed=x['passed'],counts=x['receipt']['counts']) for x in d['results']],wchan=(proc/'wchan').read_text(),ps=subprocess.check_output(['ps','-p',str(pid),'-o','pid,stat,etime,pcpu,wchan:32'],text=True));p=b/'stem-split-wait-e.json';assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n');a=b/'stem-split-wait-e-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:t.add(p,arcname=p.name,recursive=False);t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),observation=v)))

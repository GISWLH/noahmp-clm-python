"""Preserve actual failed current year and diagnostic-only input authority."""
from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-climatology-cuda-jt';trajectory=r/'trajectory';control=b/'climatology-cuda-year-kc';sha=lambda raw:hashlib.sha256(raw).hexdigest();exit=json.loads((control/'exit.json').read_text());assert exit['actual_parent_returncode']==1 and not exit['passed'];batch_raw=(trajectory/'batch.json').read_bytes();batch=json.loads(batch_raw);receipt=json.loads((r/'year-receipt.json').read_text());assert sha((r/'year-receipt.json').read_bytes())==exit['receipt_sha256'] and receipt['failure'] and receipt['source_unchanged'] and receipt['device_barrier_complete'];assert batch['status']=='failed' and batch['steps_completed']==2657 and batch['steps_requested']==17520 and batch['source_unchanged'] and batch['failed_step']==2657;source=Path('/tmp/noahmp-ballberry-climatology-cuda-jt/source');m=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(m)==581 and sha((source/'SOURCE_SHA256.json').read_bytes())=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha((source/n).read_bytes())==h for n,h in m.items());assert not Path('/proc/3150299').exists() and not Path('/proc/3150296').exists();payload={'failed/batch.json':batch_raw,'source/SOURCE_SHA256.json':(source/'SOURCE_SHA256.json').read_bytes()}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and n not in payload;payload[n]=p.read_bytes()
for p in sorted(r.iterdir()):
    if p.is_file():add(p,'model-root/'+p.name)
for p in sorted((r/'inputs').rglob('*')):
    if p.is_file():add(p,'inputs/'+p.relative_to(r/'inputs').as_posix())
cp=trajectory/batch['checkpoint_file'];assert sha(cp.read_bytes())==batch['checkpoint_sha256'];add(cp,'failed/'+cp.name);successful=[]
for case,descriptor in batch['case_reports'].items():
    folder=trajectory/case;p=folder/descriptor['file'];raw=p.read_bytes();assert sha(raw)==descriptor['sha256'];d=json.loads(raw);assert d['status']=='failed' and d['steps_completed']==2657 and d['batch_checkpoint_sha256']==batch['checkpoint_sha256'];add(p,'failed/'+case+'/'+p.name)
    trace=folder/d['model_npz'];assert sha(trace.read_bytes())==d['model_npz_sha256'];add(trace,'failed/'+case+'/'+trace.name)
    prior=list(folder.glob('report-0002640-*.json'));assert len(prior)==1;d=json.loads(prior[0].read_text());assert d['status']=='running' and d['steps_completed']==2640 and d['steps_requested']==17520 and d['source_unchanged'];add(prior[0],'reported2640/'+case+'/'+prior[0].name)
    for name,key in [('model_npz','model_npz_sha256'),('batch_checkpoint_file','batch_checkpoint_sha256')]:
        p=folder/d[name];assert sha(p.read_bytes())==d[key];target='reported2640/'+case+'/'+p.name if name=='model_npz' else 'reported2640/'+p.name
        if target not in payload:add(p,target)
        else:assert payload[target]==p.read_bytes()
    successful.append(dict(case=case,reported_steps=2640,report_sha256=sha(prior[0].read_bytes()),checkpoint_sha256=d['batch_checkpoint_sha256']))
chunks=sorted((r/'year-bgc-diagnostics').glob('steps-*.npz'));assert len(chunks)==54 and chunks[-1].name=='steps-0002592-0002640.npz'
for p in chunks:add(p,'closed-bgc-chunks/'+p.name)
for folder,label in [(control,'actual-year-parent'),(b/'climatology-current-year-export-kk','successful-year-export-refusal')]:
    for p in sorted(folder.iterdir()):
        if p.is_file():add(p,label+'/'+p.name)
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_year_parent_returncode=1,year_model_pid_absent=3150299,year_controller_pid_absent=3150296,source_manifest_sha256=receipt['source_manifest_sha256'],failed_attempt_index=2657,completed_intervals=2657,requested_intervals=17520,reported_successful2640=successful,closed_bgc_chunk_count=54,closed_continued_bgc_steps=2592,closed_bgc_last_index=2640,unpersisted_bgc_buffer_after2640_steps=17,export_controller_refused_as_success=True,scope='ActualcurrentJN12case coldyear parent1 at2657 CUDA layeredphasesurface failure. Failedstate/globalledgers/all12reports/traces, selectedreported2640prefix, allfixedinputs and54closedBGCchunks retained. Last17 BGCdiagnosticrecords were inRAMandnotpersisted; nevercallall2657 BGCrawcomplete. Onlydiagnosticreplay of failedattempt input mayfollowNumPyreference; neverresume failedyear/prefix ormarkcomplete. KKproperlyrefusedsuccessfulexport. Current407/oldECyear independent.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();payload['control/'+Path(__file__).name]=Path(__file__).read_bytes();target=b/'climatology-failed-year-mh-export.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
out=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'climatology-failed-year-mh-export.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

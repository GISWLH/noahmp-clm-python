"""Export actual terminal current JN year artifacts; I/O only, no GPU kernels."""
from pathlib import Path
import hashlib,json,os,tarfile
b=Path('/home/lhwang/work/noahmp-v1');control=Path(__file__).resolve().parent;model=b/'ballberry-climatology-cuda-jt';year=b/'climatology-cuda-year-kc';source=Path('/tmp/noahmp-ballberry-climatology-cuda-jt/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((control/'launch.json').read_text());assert all(sha(control/n)==h for n,h in launch['controls_sha256'].items())
parent=json.loads((year/'exit.json').read_text());receipt=json.loads((model/'year-receipt.json').read_text());manifest=sha(source/'SOURCE_SHA256.json')
assert parent['passed'] and parent['actual_parent_returncode']==0 and parent['failure'] is None and parent['receipt_sha256']==sha(model/'year-receipt.json')
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256']==manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert receipt['status']=='complete' and receipt['steps_completed']==receipt['steps_requested']==17520 and receipt['device_barrier_complete'] and receipt['continued_fields_exact']==23 and receipt['first_continued_step_captured']
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(m)==581 and all(sha(source/n)==h for n,h in m.items())
folder=model/'trajectory';raw=(folder/'batch.json').read_bytes();report=json.loads(raw)
assert sha(folder/'batch.json')==receipt['report_sha256'] and report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520 and report['columns']==12 and report['source_unchanged']
assert report['identity']['backend']=='cuda32' and not report['identity']['compare_jax32'] and report['same_precision_max_absolute'] is None and report['identity'].get('native_state_arrays',16)==16
assert all(m[n]==h for n,h in report['identity']['source_sha256'].items())
assert sha(folder/report['checkpoint_file'])==report['checkpoint_sha256']
pairs=[]
def add(path,name):
    path=Path(path);assert path.is_file() and not path.is_symlink();pairs.append((path,name))
for n in ['year-receipt.json','year-start-audit.json','year-prefix-binding.json','prefix-verification.json','prefix-verification-pbs-exit.txt','prefix-verification-actual-qstat.txt','validated-prefix-state.npz','validated-prefix-report.json','first-continued-step.npz','cold-audit.json','prefix-report.json','receipt.json','exit.json','launch.json']:
    add(model/n,'current/'+n)
for n in ['exit.json','launch.json','worker.json','SOURCE_SHA256.json']:
    add(year/n,'year-controller/'+n)
year_launch=json.loads((year/'launch.json').read_text())
for n,h in year_launch['controls_sha256'].items():assert sha(b/n)==h;add(b/n,'year-controller/'+n)
add(source/'SOURCE_SHA256.json','SOURCE_SHA256.json');add(b/'clm-ballberry-jn-package.json','source-package.json')
add(folder/'batch.json','current/trajectory/batch.json');add(folder/report['checkpoint_file'],'current/trajectory/'+report['checkpoint_file'])
cold=list(folder.glob('state-0000000-*.npz'));assert len(cold)==1;add(cold[0],'current/trajectory/'+cold[0].name);generation=cold[0].stem.removeprefix('state-')
for case,descriptor in report['case_reports'].items():
    sub=folder/case;p=sub/descriptor['file'];d=json.loads(p.read_text());assert sha(p)==descriptor['sha256'] and d['status']=='complete' and d['steps_completed']==d['steps_requested']==17520 and d['batch_checkpoint_sha256']==report['checkpoint_sha256']
    assert sha(sub/d['model_npz'])==d['model_npz_sha256']
    for path in [p,sub/d['model_npz'],sub/('report-'+generation+'.json'),sub/('trace-'+generation+'.npz')]:add(path,'current/trajectory/'+case+'/'+path.name)
assert len(report['case_reports'])==12
for k in range(48):
    n='steps/call-'+str(k).zfill(5)+'.npz';add(model/n,'current/'+n)
chunks=receipt['bgc_diagnostic_chunks'];assert receipt['bgc_diagnostic_steps']==17520-48 and len(chunks)==364
for i,c in enumerate(chunks):
    first,end=48+i*48,96+i*48;assert c['first']==first and c['end']==end
    n='year-bgc-diagnostics/steps-'+str(first).zfill(7)+'-'+str(end).zfill(7)+'.npz';assert sha(model/n)==c['sha256'];add(model/n,'current/'+n)
inputs=json.loads((b/'multisite-climatology-jr-package.json').read_text());assert inputs['source_manifest_sha256']==manifest and sha(b/inputs['archive'])==inputs['archive_sha256']
add(b/inputs['archive'],'frozen-inputs/'+inputs['archive']);add(b/'multisite-climatology-jr-package.json','frozen-inputs/package.json')
for n in launch['controls_sha256']:add(control/n,'export-controls/'+n)
add(control/'launch.json','export-controls/launch.json')
target=b/'climatology-current-year-kk-export.tar.gz';temporary=target.with_suffix('.partial');assert not target.exists() and not temporary.exists();inventory={}
with tarfile.open(temporary,'w:gz') as tf:
    for path,name in pairs:
        assert name not in inventory;inventory[name]=sha(path);tf.add(path,arcname=name,recursive=False);assert sha(path)==inventory[name]
with tarfile.open(temporary) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
assert (folder/'batch.json').read_bytes()==raw and all(sha(source/n)==h for n,h in m.items())
os.replace(temporary,target)
value=dict(archive=target.name,sha256=sha(target),bytes=target.stat().st_size,artifacts=len(inventory),source_manifest_sha256=manifest,steps=17520,cases=12,
    scope='ActualcurrentJN CUDA1 twelve originalcoldyears complete17520 withactualparent0/source/barrier/globalledger continuation, originalcold48 andall364BGCchunks/finalstate/fulltraces/inputandconfig identity exported. Read-onlyI/O, not scientific/observational/spinup/SOC/currentK78/full407/sameprecision/release acceptance; EHPCindependentfullperiod/budgets/stock/observations audits required.')
(b/'climatology-current-year-kk-export.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

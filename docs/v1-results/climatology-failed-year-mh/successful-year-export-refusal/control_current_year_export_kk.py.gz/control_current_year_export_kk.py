from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=Path(__file__).resolve().parent;year=b/'climatology-cuda-year-kc';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();failure=None;code=None
try:
    launch=json.loads((r/'launch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items())
    original=json.loads((year/'launch.json').read_text());assert original['pid']==3150296 and original['source_manifest_sha256']==launch['source_manifest_sha256']
    while not (year/'exit.json').exists():
        p=Path('/proc')/str(original['pid']);assert p.exists(),'Yearcontrollerhandle missing withoutterminal receipt'
        assert b'control_climatology_cuda_year_kc.py' in (p/'cmdline').read_bytes()
        (r/'waiting.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_year_controller_observed_live=original['pid'],scope='Wait actualexistingyear terminal; no restart, source/state modification, extraGPUwork or acceptance.'))+'\n');time.sleep(30.)
    d=json.loads((year/'exit.json').read_text());assert d['passed'] and d['actual_parent_returncode']==0,'Originalyearfailed; do not export as successful'
    with (r/'export.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(r/'export_climatology_year_kk.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
    assert code==0,'Export failed; originalyear untouched'
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
value=dict(actual_export_parent_returncode=code,failure=failure,passed=failure is None,seconds=time.monotonic()-start,scope='Exportcontrolleronly. Never scientific/annualaudit/spinup/SOC/fullGPU/K78 acceptance. Originalmodelyear remainsindependent.');(r/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True);raise SystemExit(0 if failure is None else 1)

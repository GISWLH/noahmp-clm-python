from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'climatology-current-year-export-kk';assert not r.exists();year=b/'climatology-cuda-year-kc';p=json.loads((year/'launch.json').read_text());assert p['pid']==3150296 and Path('/proc',str(p['pid'])).exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();controls={}
for n in ['export_climatology_year_kk.py','control_current_year_export_kk.py',Path(__file__).name]:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=sha(r/n)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
launch=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=p['source_manifest_sha256'],controls_sha256=controls,original_year_controller=p['pid'],scope='I/O-only exportqueued after current12case yearactualterminal0. No newGPUmodelprocess, changes tooriginalsource/trajectory/cache or acceptance.')
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
with (r/'controller.log').open('x') as log:proc=subprocess.Popen([sys.executable,'-u',str(r/'control_current_year_export_kk.py')],cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
out=dict(pid=proc.pid,launch_sha256=sha(r/'launch.json'),scope=launch['scope']);(r/'worker.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

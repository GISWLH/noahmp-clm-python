from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-prefix-audit-el';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and len(d['cases'])==2
for row in d['cases']:
    p=r/row['case']/'verification.json';assert json.loads(p.read_text())==row and row['passed'] and row['physical_step_pairs']==48 and row['cold_fields_exact']==30 and row['all23state_chains_and_final_checkpoint_exact'] and len(row['all23physical_trace_metrics'])==24
items=[(p,'audit/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['dispatch_phase_prefix_audit_el.py',Path(__file__).name]);a=b/'phase-prefix-audit-el-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

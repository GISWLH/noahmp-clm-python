# OY initial-N source review

This is a read-only method/source/configuration review, not an OY numerical replay.
The eight original Cng/Qia training roots retain mineral N=2 gN/m2. Their original
seven organic-N stocks are the first diagnostic prior, not a prohibition on an
explicit independently justified new cold organic-N inventory. Initial inventory
differences cannot be counted as deposition, litter input or a budget correction.

The saved potential plant-N demand is the same plan value actually supplied to
decomposition. Final plant uptake is a separate quantity. These crop-free complete
columns have positive deposition and no N-loss process; total N can grow. That
statement differs from the soil module, where plant uptake is an explicit exit.

The corrected memo and review are preserved at their final fixed SHA256 values.
The initial versions are retained only to document the correction: the original
GPU implementation does return ten-path C/N in/out arrays, and NS records them.
Do not use the initial memo's incorrect omission as the current conclusion.

Source material consists of 14 byte-identical NM files, its full hash manifest,
the original NS/KM recorder files, and eight exact original JR training config
members. JR remains JN-origin; NM source identity is not assigned to JR inputs.
The original full NM/JR archives are identified by SHA256 in the review. No forcing,
observation, held-out prediction or physical-state array is decoded by this work.

Reverification: run the bundled verify_oy_initial_n_prior_wp.py beside the generic
package JSON and evidence tar.gz. It uses Python standard-library bytes, JSON and
fixed source assertions only. It neither imports the scientific source nor runs
models. The small source anchors support the manual trace documented in the memo;
they do not claim actual full-year equality, spinup or scientific acceptance.

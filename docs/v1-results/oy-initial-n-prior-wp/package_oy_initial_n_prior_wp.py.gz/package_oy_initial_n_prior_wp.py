"""Package existing source/config evidence and the corrected OY method note only."""
from pathlib import Path
import io
import json
import tarfile
from verify_oy_initial_n_prior_wp import LABEL, sha, read_tar, verify_artifacts

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[1]


def blob(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def main():
    artifacts = {name: (BASE / name).read_bytes() for name in [
        'OY_INITIAL_N_PRIOR_WP.md', 'oy-initial-n-prior-wp.json',
        'OY_INITIAL_N_PRIOR_WP_initial.md', 'oy-initial-n-prior-wp_initial.json',
        'verify_oy_initial_n_prior_wp.py', 'package_oy_initial_n_prior_wp.py']}
    review = json.loads(artifacts['oy-initial-n-prior-wp.json'])
    source_raw = (BASE / 'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    jr_raw = (BASE / 'multisite-climatology-jr-inputs.tar.gz').read_bytes()
    assert sha(source_raw) == review['source_archive_sha256'] and sha(jr_raw) == review['original_JR_archive_sha256']
    # Tar members are opaque bytes here. Only the two training sites' config JSON is parsed.
    source = read_tar(source_raw)
    selected = dict(review['source_files_same_as_NM'], **review['additional_demand_trace_source_files_same_as_NM'])
    artifacts['source/SOURCE_SHA256.json'] = source['SOURCE_SHA256.json']
    for name, digest in selected.items():
        assert sha(source[name]) == digest and (REPO / name).read_bytes() == source[name]
        artifacts['source/' + name] = source[name]
    with tarfile.open(fileobj=io.BytesIO(jr_raw)) as archive:
        artifacts['original-JR-protocol.json'] = archive.extractfile('protocol.json').read()
        for row in review['original_training_roots']:
            artifacts['original-JR/' + row['member']] = archive.extractfile(row['member']).read()
    for name, digest in review['recorder_files_sha256'].items():
        raw = (REPO / name).read_bytes()
        assert sha(raw) == digest
        artifacts['recorders/' + Path(name).name] = raw
    artifacts['PUBLICATION.md'] = '''# OY initial-N source review

This is a read-only method/source/configuration review, not an OY numerical replay.
The eight original Cng/Qia training roots retain mineral N=2 gN/m2. Their original
seven organic-N stocks are the first diagnostic prior, not a prohibition on an
explicit independently justified new cold organic-N inventory. Initial inventory
differences cannot be counted as deposition, litter input or a budget correction.

The saved potential plant-N demand is the same plan value actually supplied to
decomposition. Final plant uptake is a separate quantity. These crop-free complete
columns have positive deposition and no N-loss process; total N can grow. That
statement differs from the soil module, where plant uptake is an explicit exit.

The corrected memo and review are preserved at their final fixed SHA256 values.
The initial versions are retained only to document the correction: the original
GPU implementation does return ten-path C/N in/out arrays, and NS records them.
Do not use the initial memo's incorrect omission as the current conclusion.

Source material consists of 14 byte-identical NM files, its full hash manifest,
the original NS/KM recorder files, and eight exact original JR training config
members. JR remains JN-origin; NM source identity is not assigned to JR inputs.
The original full NM/JR archives are identified by SHA256 in the review. No forcing,
observation, held-out prediction or physical-state array is decoded by this work.

Reverification: run the bundled verify_oy_initial_n_prior_wp.py beside the generic
package JSON and evidence tar.gz. It uses Python standard-library bytes, JSON and
fixed source assertions only. It neither imports the scientific source nor runs
models. The small source anchors support the manual trace documented in the memo;
they do not claim actual full-year equality, spinup or scientific acceptance.
'''.encode()
    artifacts['actual-readonly-verification.json'] = blob(verify_artifacts(artifacts))
    artifacts['inventory.json'] = blob({name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in artifacts.items()})
    destination = BASE / (LABEL + '-evidence.tar.gz')
    assert not destination.exists()
    with tarfile.open(destination, 'w:gz') as archive:
        for name, raw in sorted(artifacts.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
    assert read_tar(destination.read_bytes()) == artifacts
    package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
        artifacts=len(artifacts), scope='OY initial-N static source/config review: eight original training roots, mineral N=2, original seven N only first diagnostic prior, true potential demand mapping, no complete-column N loss, native ten-path correction retained. No numerical replay, model, candidate initializer, heldout evaluation or scientific acceptance.',
        memo_sha256=sha(artifacts['OY_INITIAL_N_PRIOR_WP.md']), review_sha256=sha(artifacts['oy-initial-n-prior-wp.json']),
        source_manifest_sha256=review['source_manifest_sha256'], original_JR_archive_sha256=review['original_JR_archive_sha256'],
        actual_readonly_verification_passed=True, numerical_execution=False, model_steps=0)
    (BASE / (LABEL + '-package.json')).write_bytes(blob(package))
    print(json.dumps(package))


if __name__ == '__main__':
    main()

"""Read-only stdlib check of the OY initial-N source note; no scientific imports."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import tarfile

LABEL = 'oy-initial-n-prior-wp'
MEMO_SHA = '42cbb7a6aeb87c6433d643ac5fe06228b5dd9fd41b64966e5f02310a627c7317'
REVIEW_SHA = '2966b4f4d95a94a4ccb8ed6ea4717f77723570a5f8dae734db68bed20bd48549'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_tar(raw):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for item in archive.getmembers():
            name = PurePosixPath(item.name)
            assert item.isfile() and not name.is_absolute() and '..' not in name.parts
            assert item.name not in result
            result[item.name] = archive.extractfile(item).read()
    return result


def verify_artifacts(files):
    assert sha(files['OY_INITIAL_N_PRIOR_WP.md']) == MEMO_SHA
    assert sha(files['oy-initial-n-prior-wp.json']) == REVIEW_SHA
    report = json.loads(files['oy-initial-n-prior-wp.json'])
    original = json.loads(files['oy-initial-n-prior-wp_initial.json'])
    assert report['passed'] and report['model_steps'] == 0 and report['production_launch_allowed'] is False
    assert sha(files['OY_INITIAL_N_PRIOR_WP_initial.md']) == report['original_memo_sha256'] == original['memo_sha256']
    assert report['original_mineral_N_retained_gn_m2'] == 2 and report['coarse_wood_prior_ratio'] is None
    assert report['actual_annual_litter_ratio_computed'] is False and report['candidate_initialization_generated'] is False
    manifest = json.loads(files['source/SOURCE_SHA256.json'])
    assert len(manifest) == 584 and sha(files['source/SOURCE_SHA256.json']) == report['source_manifest_sha256']
    selected = dict(report['source_files_same_as_NM'], **report['additional_demand_trace_source_files_same_as_NM'])
    assert len(selected) == 14
    assert all(sha(files['source/' + name]) == digest == manifest[name] for name, digest in selected.items())
    assert all(sha(files['recorders/' + Path(name).name]) == digest for name, digest in report['recorder_files_sha256'].items())
    protocol = json.loads(files['original-JR-protocol.json'])
    assert protocol['source_manifest_sha256'] == report['original_JR_JN_source_manifest_sha256']
    assert protocol['case_count'] == 12 and protocol['source_unchanged']
    roots = report['original_training_roots']
    assert len(roots) == len({row['case'] for row in roots}) == 8
    assert {row['site'] for row in roots} == {'CN-Cng', 'CN-Qia'}
    for row in roots:
        raw = files['original-JR/' + row['member']]
        assert sha(raw) == row['sha256']
        cfg = json.loads(raw)
        assert cfg['case'] == row['case'] and cfg['site'] == row['site']
        bg = cfg['biogeochemistry']
        assert bg['soil_state'] == row['soil_state'] and bg['plant_state'] == row['plant_state']
        assert bg['soil_state']['mineral_nitrogen'] == 2 and bg['soil_state']['carbon'][3] == bg['soil_state']['nitrogen'][3] == 0
        assert bg['decomposition_parameters']['soil_cn'] == [8, 11, 11]
        assert cfg['column']['options']['OptCropModel'] == cfg['column']['options']['OptWetlandModel'] == 0
        assert cfg['nitrogen_deposition_gn_m2_s'] == row['nitrogen_deposition_gn_m2_s'] > 0
    anchors = {
        'source/src/noahmp_clm/gpu/clm_bgc_column.py': ['litter_c,litter_n,nitrogen[:,None],planned[:,23:24]', 'allocation=ad,decomposition=sd'],
        'source/src/noahmp_clm/gpu/cuda/plant_cn_kernel.cu': ['out[29]=plan[23];out[30]=award'],
        'source/src/noahmp_clm/gpu/cuda/decomposition_kernel.cu': ['total=potential+u[19]', 'uptake=u[19]*limitation'],
        'source/src/noahmp_clm/gpu/plant_cn.py': ["'soil_n_demand_gn_m2'", "'soil_n_uptake_gn_m2'", 'output[:,26:33].T'],
        'source/src/noahmp_clm/gpu/decomposition.py': ['carbon_out_gc_m2=output[:,15:25]', 'nitrogen_in_gn_m2=output[:,45:55]'],
        'recorders/run_year_ns.py': ["flatten(out['biogeochemistry'])", 'np.asarray(v).copy()'],
        'source/src/noahmp_clm/clm_bgc_driver.py': ['nr=new_n-state.nitrogen_gn_m2-nitrogen_deposition_gn_m2+export_n-seed_n'],
    }
    for name, tokens in anchors.items():
        text = files[name].decode()
        assert all(token in text for token in tokens), name
    return dict(passed=True, blocking_findings=[], stdlib_only=True, numerical_execution=False,
        model_steps=0, heldout_prediction_or_observation_read=False, original_training_roots=8,
        NM_source_files_byteverified=14, NS_KM_recorder_files_byteverified=2,
        original_mineral_N_gn_m2=2, soil_cn_receiver_indices=[4, 5, 6],
        potential_demand_field_is_actual_decomposition_input=True, uptake_is_distinct=True,
        native_ten_path_CN_fields_present=True, original_error_and_correction_retained=True,
        original_seven_N_is_first_diagnostic_prior_not_prohibition_on_new_cold_N=True,
        positive_deposition_without_N_loss_in_these_complete_columns=True,
        actual_annual_replay_or_candidate_initializer_executed=False,
        memo_sha256=MEMO_SHA, review_sha256=REVIEW_SHA,
        scope='Static assignment/source/config proof only; no actual annual trajectory equality or scientific acceptance.')


def main():
    base = Path(__file__).resolve().parent
    package = json.loads((base / (LABEL + '-package.json')).read_bytes())
    raw = (base / package['archive']).read_bytes()
    assert sha(raw) == package['sha256'] and len(raw) == package['bytes']
    files = read_tar(raw)
    index = json.loads(files['inventory.json'])
    assert len(files) == package['artifacts'] and set(index) == set(files) - {'inventory.json'}
    assert all(sha(files[name]) == item['sha256'] and len(files[name]) == item['bytes'] for name, item in index.items())
    actual = verify_artifacts(files)
    assert actual == json.loads(files['actual-readonly-verification.json'])
    print(json.dumps(dict(passed=True, artifacts=len(files), archive_sha256=sha(raw), verification=actual)))


if __name__ == '__main__':
    main()

# OY 初始氮先验：只读代码与原训练配置核查

本备忘只约束后续正常速率土壤 C/N 重放的方法。没有生成 C*、N*、候选初态或模型结果；没有修改 OM 配置，也没有读取 Cha/HaM 预测或留出观测。八个根为原 JR 中 Cng2007/Qia2003 各两种深层水种子 × 两种 BGC 饱和水势。对应配置 SHA 和九个 NM 源文件的实际字节核对见 `oy-initial-n-prior-wp.json`。

## 已确认的原库存和单位

七池顺序固定为 metabolic_litter、cellulose_litter、lignin_litter、coarse_wood、fast、slow、passive。C 为 gC/m²，N 为 gN/m²，均以整柱地表面积计；不是土层浓度或每单位植被面积。八根共同的 `biogeochemistry.soil_state` 为：

- C：`[50,100,100,0,300,3000,3000]`；
- N：`[1.3333333333333333,2.6666666666666665,2.6666666666666665,0,37.5,272.72727272727275,272.72727272727275]`；
- `mineral_nitrogen=2` gN/m²。

前三池的名义初始 C:N 为 37.5；粗木是 C=N=0，**没有可计算的粗木初始 C:N**。`decomposition_parameters.soil_cn=[8,11,11]` 仅指定接收端索引 4、5、6 的 SOM 转移 C:N，源码为 `carbon_in[k]/soil_cn[j-4] if j>=4 else nitrogen_out[k]`。它既不是七池参数，也不是自动重置任意已有库存 N 的规则。所有这些初库存由原配置明确标作名义先验，不是实测土壤氮。

植物库顺序为叶、聚合茎、细根，另有独立 C/N 储备：

| 原根站点 | 植物 C | 植物 N | 储备 C / N |
|---|---|---|---|
| Cng | `[100,0,150]` | `[4,0,3.5714285714285716]` | `100 / 4` |
| Qia | `[150,8000,300]` | `[6,30.400000000000002,7.142857142857143]` | `100 / 4` |

`plant_parameters.target_cn=[25,263.1578947368421,42]` 是组织需求参数，不能当作土壤/凋落物的统一比值。Cng 茎分配为零，Qia 为 0.4。凋落时叶 N 先按原回收规则转入植物储备；叶和细根剩余 C/N 按 `[.3,.45,.25]` 分到前三池，茎进入粗木。叶、根和木的实际 N:C 可随组织 N 状态变化，不能由固定叶 C:N 单独推断未来全部凋落氮。

## 沉降与植物需求的真实边界

`nitrogen_deposition_gn_m2_s` 是固定的 gN/m²/s 速率。Cng 为 `3.715727879856725e-08`，Qia 为 `3.361380935202328e-08`。配置来源为官方 `fndep_clm_hist_simyr1849-2006_1.9x2.5_c100428.nc` 的固定 2000 年粗网格气候态、原四节点映射；其 SHA 为 `21147673ba607ac405152a11da54513234f975ee595df17eeb13658467910888`。原配置保存的 365 日年量分别为 `1.171791944191617` 和 `1.0600450917254063` gN/m²；这不是本站观测或对应模拟年的趋势。闰年沿相同秒速率获得 366/365 年量，不能重新归一化。

NumPy/native runner 都只在入口乘一次 dt，形成每步沉降量。保存记录的 `nitrogen` 已经是 gN/m²/步；OY 再传给 `mineral_n_input` 时不得重复乘 1800。气溶胶五物种是另一套 kg/m²/s 输入，不能当成 N 沉降。

`plan_plant_allocation` 的土壤 N 需求为已有组织缺额加潜在新生长需求，减植物 N 储备后下限为零。`soil_n_demand_gn_m2` 是本步需求量，`soil_n_uptake_gn_m2` 是实际分配量，二者不能互换。土模块以本步开始的矿质 N 加沉降，共同比例满足固持与植物需求；当步新矿化 N 留到下一步。氮不足只削减需要净固持的路径，不能把整个分解矩阵统一乘 N 因子，也不能强制因子为 1。

八根作物和湿地选项均关闭。当前完整柱无 N 淋失/反硝化出口，植物吸收属于柱内转移，因此：

`ΔN_column = deposition + numerical_residual`。

正沉降下总柱 N 可以增长，不能把总 N 周期相等设为该配置的平衡条件。土模块把植物吸收视作出口：

`Δ(organic_N + mineral_N) = litter_N + deposition - plant_uptake + numerical_residual`。

规定植物需求的土模块重放可能有不同的 N 趋势，不等同于完整柱生理反馈。若追求其周期端点，年度输入与实际吸收的平衡只是必要条件；不能用端点缺额反推补氮来制造平衡。

## 最小可执行先验策略

1. **第一个诊断先验保留原 N。** OY 显式接收原七个 N 和原矿质 N=2；植物 N/储备和参数保持原来源。这不是禁止后续显式选择有独立依据的新 cold 有机 N 总量：新先验必须预先封存每池来源、方法、适用边界和相对原先验的库存差，并以自己的初态执行正常 C/N 重放和完整耦合验证，不能覆盖活动或已冻结状态。假设 C* 与原 C 的差、显式 N 与原 N 的差只能列为初库存差，不能加入沉降、凋落或收支修正。若 C*=0 而对应原 N>0，原 `DecompositionState` 必须拒绝；不能静默清零 N 或补 C。
2. **C* 不能唯一确定 N*。** 不把后三个 `soil_cn` 广播到七池，不从“使 N 不受限”倒算 N，不抬高矿质 N。原 N 下发生限制是诊断结果，不是需要补 N 的错误。条件无限 N 的碳解不能因此被宣布为正常 C/N 可用初态。
3. **如后续需要另一套有机 N 先验，先封存来源侧车，再考虑重放。** 原前三池的 37.5 只能标作已有名义比例；粗木原 0/0 必须为 `null`。实际完整训练年、原全部八根与 C/N 账闭合后，可单独报告各池外部凋落输入的 `sum(litter_N)/sum(litter_C)`。它是该已模拟年份输入的 N:C，不是站点实测或平衡库存 N:C。纤维素/木质素还接收粗木内部转移，外部凋落比不等于其全部入流比；季节次序也不能用年度均值替代。
4. **缺失不填。** 年度 C 或 N 输入为零/来源不完整时，相应有限正 C:N 推导记未定义；保持原先验或返回“该先验构造无解/未定义”。不加 epsilon、不借其他站点、不凭目标 C:N 补 N。零输入本身不普遍证明所有动力学都无解；贫 N 情形应保留真实限制或库存累积，只有经原方程证明的周期无解才标无解。当前没有完整冻结年，尚不能计算这些实际输入比例或新候选库存。

## OY 记录映射与独立测试建议

| OY 参数 | 原封存行字段 | 单位/含义 |
|---|---|---|
| `temperature_k` | `bgc/environment/soil_temperature` | 物理步后表土温度 K |
| `water_potential_mpa` | `bgc/environment/water_potential_mpa` | 负号约定 MPa |
| `litter_carbon_gc_m2` | `bgc/turnover/litter_carbon_gc_m2` | 7 池本步 C 量 |
| `litter_nitrogen_gn_m2` | `bgc/turnover/litter_nitrogen_gn_m2` | 7 池本步 N 量 |
| `mineral_n_input_gn_m2` | `nitrogen` | 已乘 dt 的本步沉降 N |
| `plant_n_demand_gn_m2` | `bgc/allocation/soil_n_demand_gn_m2` | 本步需求，不是实际吸收 |
| 初/末土库存 | `before_soil_cn` / `after_soil_cn` | `[C0:7,N7:14,mineral14]` |

时间仍取原 input/trace 的 `time_start/time_end`；不由步号猜年历。当前无湿地，oxygen=1。保留原 `nitrogen_limitation`、`potential_immobilization_gn_m2`、`immobilization_gn_m2`、`gross_mineralization_gn_m2`、`plant_uptake_gn_m2`、原 C/N residual 与 bound。原 native GPU 的 `unpack_decomposition` 也返回十路径 `carbon_out_gc_m2`、`carbon_in_gc_m2`、`nitrogen_out_gn_m2`、`nitrogen_in_gn_m2`，分别取输出列 `[15:25]`、`[25:35]`、`[35:45]`、`[45:55]`，NS 记录器将其完整保留为 `bgc/decomposition/...`。这些未来可用于区分外部凋落与粗木内部入流；仍须等完整原年及原账审核，不提前生成实际年比值。

### 潜在需求字段的完整来源追踪

结论：保存的 `bgc/allocation/soil_n_demand_gn_m2` 是实际送入分解竞争的同一个潜在植物需求值，**没有按受限后的生长重算**，不需要反推需求或改用最终 uptake。

- CUDA `run_plant_plan` 将潜在需求写入 24 列计划的 `out[23]`；`gpu/clm_bgc_column.py` 将 `planned[:,23:24]` 拼到分解输入 `du[:,19]`。
- CUDA 分解核直接使用 `u[19]`：`total=potential+u[19]`，实际吸收为 `uptake=u[19]*limitation`。分解调用不修改原计划。
- CUDA `run_plant_allocation` 的输入 `plan` 为只读；虽然会按实际 award 缩减生长，诊断仍直接赋值 `out[29]=plan[23]`，而 `out[30]=award`。
- 共享 `_unpack` 把输出 `[26:33]` 的第 4 项映射为 `soil_n_demand_gn_m2`、第 5 项映射为 `soil_n_uptake_gn_m2`。JAX 使用同样的 `diag(...,plan[23],award[0],...)`；NumPy 则直接回传 `plan.soil_n_demand`。
- 原 native runner 的 `engine.host` 递归转主机数组；NS `retain_bgc` 对 `out['biogeochemistry']` 做字典 flatten、`np.asarray(...).copy()` 与逐 48 步 stack/write，没有重新计算或改变 dtype。原冷 48 的 KM 适配也只把 `output/biogeochemistry/` 前缀换成 `bgc/`。

这是固定源码和记录路径的静态赋值证明，不是新执行或对未完成全年作逐值声明。可增加一个独立合成例：计划需求大于实际 award，确认记录需求保留计划值、uptake 等于 award，且需求未被最终 growth/target_cn 反算覆盖。

更正记录：本备忘首版只检查 `DIAGNOSTICS` 标量清单，错误地称 GPU 未返回十路径 C/N。此次补读完整 `unpack_decomposition` 与 CUDA 输出布局后纠正；首版保留为 `OY_INITIAL_N_PRIOR_WP_initial.md`，没有修改任何模型或原证据。

最小独立解析负控：零矿质/零沉降且有净固持及植物需求时不得制造 N；净矿化释放 N 不能在同一步被植物使用；粗木到纤维素/木质素转移保持其供体 N；量/速率误乘 dt 被拒或被独立账发现；C=0,N>0 初库拒绝；初 N 与 baseline 差仅报告不进入累计账；前三池/后三池索引交换与 3 元 soil_cn 广播到 7 元 N 拒绝。这些可用合成小例验证，不需要实际年或观测评分。

源码依据：`physics/decomposition.py`、`physics/plant_cn.py`、`physics/biogeochemistry.py`、`clm_bgc_driver.py`、`gpu/decomposition.py`、`gpu/clm_bgc_column.py`、`benchmarks/fluxnet_deposition.py`、`run_fluxnet_column.py`、`run_fluxnet_native.py`；首次九文件均与固定 NM584 清单字节相同。需求追踪追加核对 GPU plant、CUDA plant/decomposition 包装与两核文件，仍与 NM 相同，另绑定原 NS 和 KM 记录代码。本文事实来自这些方程与原 JSON，没有新增外部文献断言。

from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
from compare_station_backend_day import compare
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-g';source=base/'p6-heat-phase-event-a'
r=json.loads((root/'cuda-year/batch.json').read_text());assert r['steps_completed']==48 and r['status']=='running'
archive=base/'first-climate-day-g-native-evidence.tar.gz';assert not archive.exists()
paths=[root/v for v in ['cuda-year','batch.json','protocol.json','rerun-provenance.json','cuda-first-day.log','cuda-first-day-launch.json']]
with tarfile.open(archive,'w:gz') as t:
    for p in paths:
        for file in p.rglob('*') if p.is_dir() else [p]:
            if file.is_file():t.add(file,arcname=file.relative_to(root).as_posix(),recursive=False)
metadata=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),scope='G first48 native state and all trace generations before annual continuation.')
(root/'first-day-native-archive.json').write_text(json.dumps(metadata,indent=2)+'\n')
dest=root/'first-day-validation';dest.mkdir(exist_ok=False)
cpu=base/'fluxnet-first-climate-cycle-20261017-f/numpy-first-day-f-evidence.tar.gz'
assert hashlib.sha256(cpu.read_bytes()).hexdigest()=='4c9e645098fffd1642fb0553489996f89113b29f90ba8f4e0b5f205298507be7'
for path,prefix in [(archive,None),(cpu,'numpy-first-day/')]:
    with tarfile.open(path) as t:
        for m in t.getmembers():
            p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
            if prefix and not m.name.startswith(prefix):continue
            target=dest/m.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read())
result=compare(dest,'cuda-year','numpy-first-day',allow_gpu_heat_phase_difference=True)
print(json.dumps(metadata),flush=True)

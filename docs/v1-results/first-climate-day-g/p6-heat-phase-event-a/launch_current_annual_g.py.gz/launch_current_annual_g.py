from pathlib import Path
import hashlib,json,subprocess,sys,os
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-heat-phase-event-a';root=base/'fluxnet-first-climate-cycle-20261017-g'
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_native import source_hashes
r=json.loads((root/'cuda-year/batch.json').read_text());assert r['steps_completed']==48 and r['status']=='running'
assert r['identity']['source_sha256']==source_hashes()
comparison=json.loads((root/'first-day-validation/backend-day-comparison.json').read_text());assert not comparison['failures']
metadata=json.loads((root/'first-day-native-archive.json').read_text())
assert hashlib.sha256((base/'first-climate-day-g-native-evidence.tar.gz').read_bytes()).hexdigest()==metadata['archive_sha256']
for case in r['case_reports']:
    actual=root/'cuda-year'/case/'report.json';saved=root/'first-day-validation/cuda-year'/case/'report.json'
    assert actual.read_bytes()==saved.read_bytes()
command=[sys.executable,str(source/'launch_gpu_diagnostic.py'),str(source),str(root),'benchmarks/run_fluxnet_native.py','cuda-annual-resume',
    '--batch',str(root/'batch.json'),'--output',str(root/'cuda-year'),'--resume']
subprocess.run(command,check=True)

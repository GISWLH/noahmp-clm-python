from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics']
b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-richards-'+label+'-firstday-b');s=Path(os.environ['TMPDIR'])/'source';s.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'thin-snow-event-numpy-a-source.tar.gz'
assert sha(a)=='4190d2abef98845573f9881654b6f6fb1848e9ee4d4a36f80c3b1da97c3937e1'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==556 and all(sha(s/n)==h for n,h in m.items())
prior=b/'thin-snow-event-numpy-a';rec=json.loads((prior/'receipt.json').read_text())
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and rec['returncode']==0 and rec['counts']==dict(tests=37,failures=0,errors=0,skipped=0) and rec['source_unchanged']
original=b/'qia-stem-inputs-a/inputs'
assert sha(original/'CN-Qia.npz')=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
old=b/('qia-'+label+'-firstday-d');prior_receipt=json.loads((old/'receipt.json').read_text())
assert (old/'pbs-exit.txt').read_text().strip()=='0' and prior_receipt['returncode']==0 and prior_receipt['source_unchanged'] and prior_receipt['steps_completed']==48
cfg=json.loads((old/'config.json').read_text());before=json.loads(json.dumps(cfg))
assert cfg['column']['options']['OptRunoffSurface']==6 and cfg['column']['options']['OptRunoffSubsurface']==6
cfg['column']['options']['OptRunoffSubsurface']=3
cfg['soil_hydrology']=dict(method='richards_zero_flux',parameters={})
check=json.loads(json.dumps(cfg));del check['soil_hydrology'];check['column']['options']['OptRunoffSubsurface']=6
assert check==before
cfg['scope']='After actualNP337 whole37 and private336 independent2.49e-14K check, exact tiny-snow endpoint equalmerit NumPy fix only. Repeat both failed332/333 from originalcold, not resume; same physical source556, original80/finaltol/hardMHCN. Prospective two original-cold48 paired hydrology diagnostics. Copy actual308/309 capacity configurations exactly except explicit closedvertical Richards replacing legacy gravity/ARNO bottom, matching officialR lowerboundary2. Original VICsurface6 retained. Same forcing/initialsoil/roots/CN/LAI/SAI/heights/CO2/window/optics/physiology. Preserve both cases and all14 metrics and original MHCN, no tuning/default selection/science/year/spinup claim. Complete CTMS aquifer/saturationexcess, heterogeneoussoil, actualofficialDAYL/T10/SP-CN differences remain.'
(r/'config.json').write_text(json.dumps(cfg,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
cmd=[sys.executable,'-u',str(s/'benchmarks/run_fluxnet_column.py'),'--input',str(original/'CN-Qia.npz'),'--input-manifest',str(original/'CN-Qia.json'),
    '--config',str(r/'config.json'),'--output',str(r/'trajectory'),'--stop-after','48']
launch=dict(scope=cfg['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,command=cmd,
    source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_archive_sha256=sha(a),configuration_sha256=sha(r/'config.json'),
    original_configuration_sha256=sha(old/'config.json'),numpy37_receipt_sha256=sha(prior/'receipt.json'),
    physiology_diagnosis_sha256=sha(b/'ctsm-qia-run-s/physiology-restarts.json'),optical_diagnosis_sha256=sha(b/'ctsm-qia-canopy-inputs-w-a/diagnosis.json'))
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');start=time.monotonic()
with (r/'model.log').open('x') as log:code=subprocess.run(cmd,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else None
receipt=dict(scope=cfg['scope'],case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,seconds=time.monotonic()-start,
    source_unchanged=all(sha(s/n)==h for n,h in m.items()),status=report['status'] if report else None,steps_completed=report['steps_completed'] if report else None,report_sha256=sha(p) if p.exists() else None)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert code==0 and receipt['source_unchanged'] and report['status']=='running' and report['steps_completed']==48

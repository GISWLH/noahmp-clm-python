from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-richards-comparison-b';assert not r.exists()
jobs=[json.loads((b/('qia-richards-'+label+'-firstday-b')/'dispatch.json').read_text())['pbs_job'] for label in ['capacity','capacity_optics']]
assert jobs==['339.manager','340.manager'];r.mkdir();controls={}
for n in ['compare_qia_richards_station_b.py','qia_richards_comparison_b.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub','-W','depend=afterok:'+':'.join(jobs),str(r/'qia_richards_comparison_b.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),actual_parent_jobs=jobs,dependency='afterok:339.manager:340.manager',controls_sha256=controls,scope='Queue all14 original officialR metrics on original48 window only after both currentcold48 actualPBS0; queued is no science/model pass.')
(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

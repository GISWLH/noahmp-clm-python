from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();comparison=b/'qia-richards-comparison-b';assert (comparison/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((comparison/'comparison.json').read_text());assert d['source_unchanged'] and set(d['cases'])=={'capacity','capacity_optics'}
roots=[comparison]
for label,row in d['cases'].items():
    r=b/('qia-richards-'+label+'-firstday-b');p=r/'trajectory';receipt=json.loads((r/'receipt.json').read_text());report=json.loads((p/'report.json').read_text())
    assert (r/'pbs-exit.txt').read_text().strip()=='0' and receipt['returncode']==0 and receipt['source_unchanged'] and receipt['steps_completed']==48
    assert report['status']=='running' and report['steps_requested']==17520 and report['steps_completed']==48 and len(row['metrics'])==14
    assert sha(p/'report.json')==receipt['report_sha256']==row['report_sha256'] and sha(p/report['model_npz'])==row['trace_sha256']==report['model_npz_sha256'] and sha(p/report['checkpoint_file'])==report['checkpoint_sha256'] and sha(r/'config.json')==row['configuration_sha256']
    roots.append(r)
official=b/'ctsm-qia-run-r';audit=json.loads((official/'year-boundary.json').read_text());assert sha(official/'year-boundary.json')==d['reference_audit_sha256'] and sha(official/'official-year-fields.npz')==audit['fields_sha256']
source=b/'thin-snow-event-numpy-a-source.tar.gz';assert sha(source)=='4190d2abef98845573f9881654b6f6fb1848e9ee4d4a36f80c3b1da97c3937e1'
a=b/'qia-richards-firstday-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for r in roots:
        for p in sorted(r.rglob('*')):
            if p.is_file():t.add(p,arcname=r.name+'/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['official-year-fields.npz','year-boundary.json','pbs-exit.txt']:t.add(official/n,arcname='official-reference/'+n,recursive=False)
    for n in ['CN-Qia.npz','CN-Qia.json','CN-Qia-stem-config.json']:t.add(b/'qia-stem-inputs-a/inputs'/n,arcname='original-input/'+n,recursive=False)
    for n in ['dispatch_qia_richards_firstday_b.py','dispatch_qia_richards_comparison_b.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='EHPC339/340 originalcold48 and342 all14-metric officialR comparison actual0; originalsource556/input/reference/config/checkpoints/trajectories and allmetrics preserved, all originalMHCN. BothA failed5 retained elsewhere, no failedresume/defaultselection/wholeyear/spinup/multisite/science claim.')))

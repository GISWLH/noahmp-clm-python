from pathlib import Path
import hashlib,json,os,resource,signal,subprocess,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-case-build-e';scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-case-build-e';scratch.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic();stages=[];failure=None;value={}
try:
    for archive,digest,dest in [(base/'ctsm-portable-env-b.tar.gz','6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20',scratch/'toolchain'),(base/'ctsm-reference-source-bundle-a.tar.gz','f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',scratch)]:
        assert sha(archive)==digest;dest.mkdir(exist_ok=True)
        with tarfile.open(archive) as t:t.extractall(dest,filter='data')
    source=scratch/'CTSM';prefix=scratch/'toolchain';case=scratch/'case';inputs=scratch/'inputdata';inputs.mkdir();output=scratch/'output'
    lock=json.loads((scratch/'UPSTREAM_SOURCE_LOCK.json').read_text());verify=lambda:all(sha(scratch/n)==v for n,v in lock['files'].items());assert verify()
    aliases=scratch/'compiler-bin';aliases.mkdir()
    for name,target in [('gcc','gcc'),('g++','g++'),('gfortran','gfortran')]:
        (aliases/name).symlink_to(prefix/'bin'/('x86_64-conda-linux-gnu-'+target))
    env=os.environ.copy()
    for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
    env.update(PATH=str(aliases)+':'+str(prefix/'bin')+':/usr/bin:/bin',CONDA_PREFIX=str(prefix),NETCDF_PATH=str(prefix),NETCDF_C_PATH=str(prefix),NETCDF_FORTRAN_PATH=str(prefix),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    def run(label,args,cwd=source):
        start=time.monotonic()
        child=subprocess.Popen(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
        try:out,err=child.communicate(timeout=1200 if label=='case-build' else 180);code=child.returncode
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:out,err=child.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);out,err=child.communicate()
            code=124;err+='\nOwned subprocess group reached declared stage time bound.'
        (scratch/(label+'.stdout.txt')).write_text(out);(scratch/(label+'.stderr.txt')).write_text(err)
        stages.append(dict(stage=label,command=[str(v) for v in args],returncode=code,seconds=time.monotonic()-start));return code
    py=str(prefix/'bin/python');assert run('relocate',[py,str(prefix/'bin/conda-unpack')])==0
    assert run('machine-query',[py,str(source/'cime/scripts/query_config'),'--machines','centos7-linux','--long'])==0
    command=[py,str(source/'cime/scripts/create_newcase'),'--case',str(case),'--srcroot',str(source),'--compset','2000_DATM%1PT_CLM50%SP_SICE_SOCN_SROF_SGLC_SWAV','--res','1x1_brazil','--machine','centos7-linux','--compiler','gnu','--mpilib','mpi-serial','--pecount','1','--output-root',str(output),'--input-dir',str(inputs),'--handle-preexisting-dirs','a','--run-unsupported']
    assert run('create-case',command)==0
    assert run('xmlchange',[py,str(case/'xmlchange'),'GMAKE_J=1,STOP_OPTION=nsteps,STOP_N=48,DOUT_S=FALSE'],case)==0
    # Adapt only generated case configuration: EHPC has no modulecmd.
    specific=case/'env_mach_specific.xml';tree=ET.parse(specific);node=tree.getroot()
    module=node.find('module_system');assert module is not None
    before=ET.tostring(module,encoding='unicode');module.clear();module.set('type','none')
    for child in list(node):
        if child.tag=='modules':node.remove(child)
    variables=node.find('environment_variables')
    if variables is None:variables=ET.SubElement(node,'environment_variables')
    for name in ['NETCDF_PATH','NETCDF_C_PATH','NETCDF_FORTRAN_PATH','LD_LIBRARY_PATH']:
        for element in node.findall('.//env'):
            if element.get('name')==name:element.text=str(prefix/'lib') if name=='LD_LIBRARY_PATH' else str(prefix)
        if not any(element.get('name')==name for element in node.findall('.//env')):
            element=ET.SubElement(variables,'env',{'name':name});element.text=str(prefix/'lib') if name=='LD_LIBRARY_PATH' else str(prefix)
    resource_caps=[]
    for element in node.findall('.//resource_limits/resource'):
        name=element.get('name');kind=getattr(resource,name);requested=int(element.text)
        soft,hard=resource.getrlimit(kind)
        if hard!=resource.RLIM_INFINITY and (requested==resource.RLIM_INFINITY or requested>hard):
            element.text=str(hard);resource_caps.append(dict(resource=name,requested=requested,allowed_hard=hard))
    (scratch/'resource-adaptation.json').write_text(json.dumps(dict(scope='Generated case limits capped at existing PBS process hard bounds; no OS/shared limit changed.',caps=resource_caps),indent=2)+'\n')
    tree.write(specific,encoding='utf-8',xml_declaration=True)
    (scratch/'machine-adaptation.json').write_text(json.dumps(dict(scope='Generated case environment only, no upstream machine/physics source edits.',original_module_system=before,new_module_system='none',netcdf_root=str(prefix)),indent=2)+'\n')
    assert run('case-setup',[py,str(case/'case.setup')],case)==0
    # Legacy CIME MPI external interfaces predate GNU Fortran10 checking.
    # Only generated case compiler flags change; original upstream source stays exact.
    adaptations=[]
    for name,line in [('Macros.make','FFLAGS += -fallow-argument-mismatch'),('Macros.cmake','string(APPEND FFLAGS " -fallow-argument-mismatch")')]:
        path=case/name
        if not path.exists():continue
        before_sha=sha(path);path.write_text(path.read_text()+'\n# Legacy CIME MPI interfaces with GCC12\n'+line+'\n')
        adaptations.append(dict(path=name,original_sha256=before_sha,adapted_sha256=sha(path),appended=line))
    assert any(v['path']=='Macros.make' for v in adaptations)
    (scratch/'compiler-adaptation.json').write_text(json.dumps(dict(scope='Generated case compiler compatibility only, no source or numerical precision/optimization change.',cause='Actual PBS116 GPTL perf_utils.F90 external MPI_BCAST INTEGER/LOGICAL mismatch under GNU12.',adaptations=adaptations),indent=2)+'\n')

    preview=run('preview-namelists',[py,str(case/'preview_namelists')],case)
    if preview==0:
        run('case-build',[py,str(case/'case.build'),'--skip-provenance-check'],case)
    value['input_file_lists']={p.relative_to(case).as_posix():p.read_text() for p in case.rglob('*input_data_list*') if p.is_file()}
    value['case_configuration_created']=True
    value['upstream_original_bytes_unchanged']=verify();assert verify()
except BaseException as e:failure=type(e).__name__+': '+str(e)
if 'verify' in locals():value['upstream_original_bytes_unchanged']=verify()
value.update(scope='Official single-column SP/stub runoff/glacier configuration/build attempt. Actual stage return codes determine build status; no model run or science result. Original upstream physics unchanged; generated case stays private until its metadata is reviewed.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,failure=failure,seconds=time.monotonic()-begun)
(root/'configuration.json').write_text(json.dumps(value,indent=2)+'\n')
with tarfile.open(root/'case-configuration-private.tar.gz','w:gz') as t:
    for p in sorted(scratch.iterdir()):
        if p.name not in ['CTSM','toolchain','compiler-bin']:t.add(p,arcname=p.name)
print(json.dumps({k:v for k,v in value.items() if k!='input_file_lists'}),flush=True)
raise SystemExit(0 if failure is None and all(s['returncode']==0 for s in stages) else 1)

"""Publication metadata/supplement only; all original evidence archives immutable."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()


def read_archive(name,expected):
    path=BASE/name;assert sha(path.read_bytes())==expected
    with tarfile.open(path) as tar:
        result={m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
    index=json.loads(result['artifact-inventory.json'])
    assert set(result)==set(index)|{'artifact-inventory.json'}
    assert all(sha(result[n])==h for n,h in index.items())
    return result


def main():
    mainsha='6ccfddeff32993f82819c9425774d6b3da7cfbc1e0e17ea14acf24aaa272db51'
    failedsha='edd9d6a834da05927341555827d290c34bff4007d67bbe3bb7c682a82e5d9cb6'
    main=read_archive('drainage-gold-po-b-evidence.tar.gz',mainsha)
    failed=read_archive('drainage-gold-po-failed-evidence.tar.gz',failedsha)
    for filename,count,digest,scope in [
        ('drainage-gold-po-b-package.json',345,mainsha,
         'Actual1665 EHPC NumPy gold:20 recipes,9 checker tests,40 observed primitive returns,34 full integrations; source584/control82c291 and actualF0 seal bound. Original1659 F1 serialization failure retained separately. No GPU, coupled-column or field-year execution.'),
        ('drainage-gold-po-failed-package.json',48,failedsha,
         'Original1659 F1/Stageout0 export failure:8 checker tests passed; observed1 primitive/1 full/13 NumPy32 inverse returns retained. JSON float32 metadata serialization failed; no complete gold. No GPU, coupled column or field year.')]:
        path=BASE/filename;package=json.loads(path.read_bytes())
        assert package['members']==count and package['sha256']==digest
        package['artifacts']=count;package['scope']=scope
        path.write_bytes(js(package))
    files={}
    names=['drainage-gold-po-b-queue-handoff.json','verify_drainage_gold_po_b.py','drainage-gold-po-b-local-verification.json',
        'prepare_drainage_gold_stage_po.py','prepare_drainage_gold_stage_po_b.py','drainage-gold-po-stage-package.json',
        'drainage-gold-po-b-stage-package.json','prepare_drainage_handoff_po_b.py','drainage-handoff-po-to-po-b.diff',
        'drainage-device-handoff-po-b-prepared-package.json',
        'drainage-device-handoff-po-prepared-initial-evidence.tar.gz','drainage-device-handoff-po-prepared-initial-package.json']
    already={}
    # Reference files already byte-for-byte inside the main/failed evidence.
    for local,member,which in [('close_drainage_gold_po_b.py','closure/collect.py','main'),
            ('dispatch_drainage_gold_po_b.py','execution/dispatch_component_pb.py','main'),
            ('dispatch_drainage_gold_po.py','execution/dispatch_component_pb.py','failed')]:
        raw=(BASE/local).read_bytes();source=main if which=='main' else failed
        assert raw==source[member]
        already[local]=dict(archive='drainage-gold-po-b-evidence.tar.gz' if which=='main' else 'drainage-gold-po-failed-evidence.tar.gz',
            archive_sha256=mainsha if which=='main' else failedsha,member=member,sha256=sha(raw))
    for name in names:
        raw=(BASE/name).read_bytes()
        duplicate=[n for n,b in main.items() if b==raw]
        if duplicate:
            already[name]=dict(archive='drainage-gold-po-b-evidence.tar.gz',archive_sha256=mainsha,
                member=duplicate[0],sha256=sha(raw))
        else:files[name]=raw
    initial=(BASE/'drainage-device-handoff-po-prepared-initial-evidence.tar.gz').read_bytes()
    assert sha(initial)=='9e18ce8d8ddb66245bf7752f3b777db70628041bcdb996a90c2addfbdc83857c'
    stages=[]
    for label in ('po','po-b'):
        package=json.loads((BASE/('drainage-gold-'+label+'-stage-package.json')).read_bytes())
        path=BASE/package['archive'];assert sha(path.read_bytes())==package['sha256']
        with tarfile.open(path) as tar:
            stage={m.name:tar.extractfile(m).read() for m in tar}
        index=json.loads(stage['stage-inventory.json'])
        assert set(stage)==set(index)|{'stage-inventory.json'}
        assert all(sha(stage[n])==h for n,h in index.items())
        assert sha(stage['preparation/CONTROLS_SHA256.json'])==package['preparation_manifest_sha256']
        assert sha(stage['source.tar.gz'])==package['source_archive_sha256']
        stages.append(dict(archive=package['archive'],sha256=package['sha256'],members=len(stage),
            indexed_files_exact=True,source_archive_sha256=package['source_archive_sha256'],
            preparation_manifest_sha256=package['preparation_manifest_sha256'],
            dispatcher_sha256=sha(stage['execution/dispatch_component_pb.py'])))
    files['stage-review.json']=js(dict(passed=True,stdlib_only=True,numerical_execution=False,stages=stages))
    files['already-in-original-evidence.json']=js(already)
    files['README.md']=b'''# PO publication supplement

This small supplement adds queue handoff, independent stdlib NPZ-byte verifier
and its actual result, source/stage builders and metadata review, and the exact
PO-to-PO-b observational diff. Files already in the original345/48 evidence are
referenced by archive/member/SHA in already-in-original-evidence.json rather
than duplicated. For the verifier's local import, extract main archive member
closure/collect.py under the local name close_drainage_gold_po_b.py. No NumPy
import or scientific recomputation occurs in that verifier.

The initial unexecuted36-file prepared archive is preserved exactly with SHA
9e18ce8d8ddb66245bf7752f3b777db70628041bcdb996a90c2addfbdc83857c,
renamed locally to drainage-device-handoff-po-prepared-initial-evidence.tar.gz.
Its original package keeps its original historical archive filename, which is
an alias, not the current executed controls. It binds d02afc controls and was
never submitted. An earlier35-file working draft had already been overwritten
before preservation was requested; no preserved original is claimed for it.

Original1659 controls4f8e ran and failed JSON serialization after1 trial/full
and13 inverse returns; the full48-file failed evidence remains F1. Fresh1665
controls82c291 adds only Python-float metadata serialization, its ninth checker,
count checks, independent stage path and description. Original model equations,
inputs, original hard bounds and integrators are unchanged. Both original
archives remain byte-identical. The successful345-file evidence contains the
real20-case NumPy gold, actualF0 seal and all80 NPZ/2372 array-byte checks.

The GPU handoff is prepared only. No CUDA/JAX execution, column integration or
field year is claimed here. Current CUDA1 tasks are untouched.
'''
    files['package_drainage_gold_supplement_po.py']=Path(__file__).read_bytes()
    files['artifact-inventory.json']=js({n:sha(b) for n,b in sorted(files.items())})
    path=BASE/'drainage-gold-po-supplement-evidence.tar.gz'
    with tarfile.open(path,'w:gz') as tar:
        for n,b in sorted(files.items()):
            m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
    with tarfile.open(path) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==files
    package=dict(archive=path.name,sha256=sha(path.read_bytes()),bytes=path.stat().st_size,
        artifacts=len(files),members=len(files),inventory_members=len(files)-1,
        scope='Metadata, actual stdlib verification and prepared GPU handoff supplement. Preserves initial unexecuted36 package and PO-b diff; original345 actualgold and48 failed evidence unchanged. No new numeric execution or GPU.',
        original_gold_archive_sha256=mainsha,original_failed_archive_sha256=failedsha)
    (BASE/'drainage-gold-po-supplement-package.json').write_bytes(js(package))
    assert sha((BASE/'drainage-gold-po-b-evidence.tar.gz').read_bytes())==mainsha
    assert sha((BASE/'drainage-gold-po-failed-evidence.tar.gz').read_bytes())==failedsha
    print(json.dumps(package))


if __name__=='__main__':main()

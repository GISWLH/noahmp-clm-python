"""Independent local stdlib archive/NPY-byte audit; no numeric imports or model."""
from pathlib import Path
import hashlib
import importlib.util
import json
import tarfile

BASE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    spec=importlib.util.spec_from_file_location('po_b_byte_reader',BASE/'close_drainage_gold_po_b.py')
    reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    package=json.loads((BASE/'drainage-gold-po-b-package.json').read_bytes())
    path=BASE/package['archive'];assert sha(path.read_bytes())==package['sha256']
    with tarfile.open(path) as archive:
        members=archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        files={m.name:archive.extractfile(m).read() for m in members}
    assert len(files)==len(members)==345
    index=json.loads(files['artifact-inventory.json'])
    assert set(files)==set(index)|{'artifact-inventory.json'}
    assert all(sha(files[n])==h for n,h in index.items())
    original=json.loads(files['closure/raw-result-inventory.json'])
    assert len(original)==293
    for name,entry in original.items():
        final=name if name.startswith('gold/') else 'gold/'+name
        assert sha(files[final])==entry['sha256'] and len(files[final])==entry['bytes']
    manifest=files['preparation/CONTROLS_SHA256.json']
    assert sha(manifest)=='82c291347cae1e92e682947c3240e5eb2494b4964c483a4e9a21010488b41d40'
    assert all(sha(files['preparation/'+n])==h for n,h in json.loads(manifest).items())
    seal=json.loads(files['gold-seal.json']);gold=json.loads(files['gold/gold-inventory.json'])
    assert sha(files['gold/gold-inventory.json'])==seal['gold_inventory_sha256']
    assert set(n.removeprefix('gold/') for n in files if n.startswith('gold/'))==set(gold)|{'gold-inventory.json'}
    assert all(sha(files['gold/'+n])==h for n,h in gold.items())
    assert sha(files['gold/export-qstat-final.txt'])==seal['qstat_final_sha256']
    fields=dict(line.strip().split(' = ',1) for line in files['gold/export-qstat-final.txt'].decode().splitlines() if ' = ' in line)
    assert fields['job_state']=='F' and fields['Exit_status']==fields['Stageout_status']=='0'
    assert files['gold/export-parent-exit.txt'].strip()==files['gold/child-exit.txt'].strip()==b'0'
    assert sha(files['gold/SOURCE_SHA256.json'])=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    arrays={n:reader.verify_npz(b,json.loads(files[n+'.json'])) for n,b in files.items() if n.endswith('.npz')}
    assert len(arrays)==80 and sum(len(v) for v in arrays.values())==2372
    summary=json.loads(files['gold/export-summary.json'])
    assert summary['passed'] and summary['source_and_controls_unchanged'] and summary['cases']==20
    assert summary['actual_trial_executions']==sum(r['actual_trial_calls'] for r in summary['observed_execution_records'])==40
    assert summary['actual_full_integrations']==sum(r['actual_full_calls'] for r in summary['observed_execution_records'])==34
    assert sum(r['phase'].get('actual_inverse_calls',0) for r in summary['observed_execution_records'])==5768
    result=dict(passed=True,archive_sha256=package['sha256'],members=345,inventory_members=344,
        original_result_members_preserved_byteexact=293,NPZ_headers_payloads_verified=80,arrays_verified=2372,
        controls_manifest_sha256=sha(manifest),gold_seal_sha256=sha(files['gold-seal.json']),
        gold_inventory_sha256=seal['gold_inventory_sha256'],actual_job='1665.manager',actualF=0,Stageout_status=0,
        source584_manifest_verified=True,local_numerical_imports=False,local_model_calls=0,GPU_calls=0,
        prior_failed_job='1659.manager:F1',prior_failed_package_sha256='edd9d6a834da05927341555827d290c34bff4007d67bbe3bb7c682a82e5d9cb6')
    (BASE/'drainage-gold-po-b-local-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()

# PO publication supplement

This small supplement adds queue handoff, independent stdlib NPZ-byte verifier
and its actual result, source/stage builders and metadata review, and the exact
PO-to-PO-b observational diff. Files already in the original345/48 evidence are
referenced by archive/member/SHA in already-in-original-evidence.json rather
than duplicated. For the verifier's local import, extract main archive member
closure/collect.py under the local name close_drainage_gold_po_b.py. No NumPy
import or scientific recomputation occurs in that verifier.

The initial unexecuted36-file prepared archive is preserved exactly with SHA
9e18ce8d8ddb66245bf7752f3b777db70628041bcdb996a90c2addfbdc83857c,
renamed locally to drainage-device-handoff-po-prepared-initial-evidence.tar.gz.
Its original package keeps its original historical archive filename, which is
an alias, not the current executed controls. It binds d02afc controls and was
never submitted. An earlier35-file working draft had already been overwritten
before preservation was requested; no preserved original is claimed for it.

Original1659 controls4f8e ran and failed JSON serialization after1 trial/full
and13 inverse returns; the full48-file failed evidence remains F1. Fresh1665
controls82c291 adds only Python-float metadata serialization, its ninth checker,
count checks, independent stage path and description. Original model equations,
inputs, original hard bounds and integrators are unchanged. Both original
archives remain byte-identical. The successful345-file evidence contains the
real20-case NumPy gold, actualF0 seal and all80 NPZ/2372 array-byte checks.

The GPU handoff is prepared only. No CUDA/JAX execution, column integration or
field year is claimed here. Current CUDA1 tasks are untouched.

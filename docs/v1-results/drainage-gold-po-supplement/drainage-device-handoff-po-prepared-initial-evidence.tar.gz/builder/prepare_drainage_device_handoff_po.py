"""Stdlib-only freeze; no remote deployment, import of numerical code, or launch."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
OUT=BASE/'drainage-device-handoff-po-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()


def packet(name,expected):
    path=BASE/name;assert sha(path.read_bytes())==expected
    with tarfile.open(path) as tar:
        members=tar.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        files={m.name:tar.extractfile(m).read() for m in members}
    assert len(files)==len(members)
    index_name='INTEGRITY.json' if name=='clm-drainage-option2-pm-evidence.tar.gz' else 'artifact-inventory.json'
    index=json.loads(files[index_name])
    assert set(files)==set(index)|{index_name}
    assert all(sha(files[n])==(v if isinstance(v,str) else v['sha256']) for n,v in index.items())
    return files


def main():
    bindings=dict(source_archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',
        source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',source_files=584,
        K_archive_sha256='942a5f9dace5d3ac87a2da8c07266840e5ddd35e499f26ee372fc37e8d3cf3a6',
        K_manifest_sha256='0575d7b0a6b85f318dd41fa0c669a52fcfe683198720b421441cf1abd299d71d',K_actual_job='1649.manager:F0',
        I_archive_sha256='5d520f1615d8ec7b460954a3e3f32c3588528b6839151b8b1198c35cd8cf8bc8',I_actual_job='1641.manager:F0',
        G_archive_sha256='902fc52c7450c1472dba2c3649e67b6ed38a6e57eb0ba1c451a839acf47dcd93',
        F_archive_sha256='566a89313ce6570c0d5f61d269776c2f76a5c1f47228bfe5326dc71414e0ddec',
        PM_archive_sha256='db0fb64e4c639a49fbd6457dbd338b02341c45634ee75de9c966f5c4ffae4dfd',
        prepared_only=True,actual_PO_exports=0,actual_PO_device_runs=0,production_registered=False)
    archives={}
    for label,name in [('K','clm-drainage-perched-pb-k-evidence.tar.gz'),('I','clm-drainage-adaptive-pb-i-evidence.tar.gz'),
            ('G','clm-drainage-adaptive-pb-g-evidence.tar.gz'),('F','clm-drainage-backends-pb-f-evidence.tar.gz'),
            ('PM','clm-drainage-option2-pm-evidence.tar.gz')]:
        archives[label]=packet(name,bindings[label+'_archive_sha256'])
    km=archives['K']['preparation/CONTROLS_SHA256.json'];assert sha(km)==bindings['K_manifest_sha256']
    for label,job in [('K','1649.manager'),('I','1641.manager')]:
        receipt=json.loads(archives[label]['receipt.json'])
        assert receipt['passed'] and receipt['pbs_job']==job and receipt['pytest_parent_returncode']==0
        assert receipt['source_and_controls_unchanged']
        q=archives[label]['scheduler/actual-qstat.txt'].decode()
        fields=dict(line.strip().split(' = ',1) for line in q.splitlines() if ' = ' in line)
        assert fields['job_state']=='F' and fields['Exit_status']==fields['Stageout_status']=='0'
        assert archives[label]['worker-exit.txt'].strip()==b'0'
    for name,digest in json.loads(km).items():
        raw=archives['K']['preparation/'+name];assert sha(raw)==digest
        (OUT/name).write_bytes(raw)
    (OUT/'ORIGINAL_K_CONTROLS_SHA256.json').write_bytes(km)
    original=archives['I']['preparation/test_adaptive_main_pbi.py']
    assert sha(original)=='6b68d8cc4870c8a021ad757de312e6006006286f5a1ff9cca322c10a814c8d11'
    (OUT/'fixture_main_original.py').write_bytes(original)
    bindings['original_I_fixture_file_sha256']=sha(original)
    for name in ('adaptive_main_pbi.py','adaptive_main_pbg.py','phase_numpy32_pbi.py','drainage_primitives_pbf.py','drainage_primitives_pbf.cu','saturated_drainage_pb.py'):
        assert (OUT/name).read_bytes()==archives['I']['preparation/'+name]
    assert (OUT/'adaptive_main_pbg.py').read_bytes()==archives['G']['preparation/adaptive_main_pbg.py']
    (OUT/'PO_BINDINGS.json').write_bytes(js(bindings))
    source=BASE/'climatology-final-candidate-nm-source.tar.gz'
    assert sha(source.read_bytes())==bindings['source_archive_sha256']
    with tarfile.open(source) as tar:
        raw=tar.extractfile('SOURCE_SHA256.json').read();assert sha(raw)==bindings['source_manifest_sha256']
        index=json.loads(raw);assert len(index)==584
        assert {m.name for m in tar}==set(index)|{'SOURCE_SHA256.json'}
        assert all(sha(tar.extractfile(n).read())==h for n,h in index.items())
    for p in OUT.glob('*.py'):ast.parse(p.read_bytes())
    tests=ast.parse((OUT/'test_arrays_po.py').read_bytes())
    assert len([n for n in ast.walk(tests) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')])==8
    r=subprocess.run(['E:/miniconda3/Scripts/ruff.exe','check','--select','F821',str(OUT),str(Path(__file__))],capture_output=True,text=True)
    assert r.returncode==0,r.stdout+r.stderr
    manifest={p.name:sha(p.read_bytes()) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'}
    (OUT/'CONTROLS_SHA256.json').write_bytes(js(manifest))
    record=dict(prepared_only=True,controls=len(manifest),controls_manifest_sha256=sha((OUT/'CONTROLS_SHA256.json').read_bytes()),
        original_K_all17_byteexact=True,original_I_fixture_byteexact=True,source584_byteexact=True,
        original_archives_members={k:len(v) for k,v in archives.items()},python_files_ast_checked=len(list(OUT.glob('*.py'))),
        checker_tests_prepared=8,ruff_exit=r.returncode,local_numerical_execution=False,EHPC_submitted=False,GPU_launched=False)
    (BASE/'drainage-device-handoff-po-static.json').write_bytes(js(record))
    # Small review package only; the 17MB immutable source is a SHA-bound external
    # input, not expanded or duplicated in every component review package.
    files={'preparation/'+p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
    files['builder/prepare_drainage_device_handoff_po.py']=Path(__file__).read_bytes()
    files['static.json']=js(record)
    files['artifact-inventory.json']=js({n:sha(b) for n,b in sorted(files.items())})
    target=BASE/'drainage-device-handoff-po-prepared-evidence.tar.gz'
    with tarfile.open(target,'w:gz') as tar:
        for n,b in sorted(files.items()):
            m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==files
    record.update(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,members=len(files),inventory_members=len(files)-1)
    (BASE/'drainage-device-handoff-po-prepared-package.json').write_bytes(js(record));print(json.dumps(record))


if __name__=='__main__':main()

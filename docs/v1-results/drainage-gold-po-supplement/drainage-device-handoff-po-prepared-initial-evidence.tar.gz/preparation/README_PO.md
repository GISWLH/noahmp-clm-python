# PO exact-input drainage device handoff — preparation only

No PO numerical export, JAX compilation, CUDA compilation, device execution,
coupled-column run or field year has happened. F/G/I/K and PM have their own
closed NumPy evidence; that evidence does not credit future PO device runs.
The original K 17 files and I fixture file are copied byte-for-byte. Original
historical README wording is retained, including I's acknowledged pre-execution
water-quantization prediction; PO uses actual arrays, never that prediction.

## Scope and APIs

This isolated four-layer component handoff uses immutable NM584 source, F main
primitive, I adaptive main and K perched primitive/adaptive path. It does not
register these components in the complete column. Existing phase inversion is
reused, not rewritten. CUDA64 phase is unsupported and is never requested. JAX64
is optional future work and is absent from this finite queue.

Primitive input: cells[N,4,6], parameters[N,12], interval[N,3], explicit float32.
Cells contain liquid, ice, layer thickness, temperature, total water, enthalpy.
F returns diagnosis[N,29] and trial[N,26]; K returns diagnosis[N,29] and
trial[N,29], adding main depth used for Sy, Sy and first donor. Trial stocks
alone are not phase-consistent carry states.

Complete API: advance_main_band / advance_perched_band(cells[4,6], parameters[12],
integer phase option, duration, front, bottom, original IntegrationControls,
backend). Every accepted trial uses the original phase path; final cells,
migrated front and complete ledger are retained.

The fixed recipe has 20 cases: 11 main (warm/frozen × options1/2, crosslayer,
refinement, zero slope, blocked donor, shallow bedrock, rejection, explicit time
quantization), 6 complete perched (microflow, stress/donor switch, zero slope,
blocked, option2, rejection) and 3 perched trial-only limits (capacity, depleted
donor, zero thickness). No old pytest suite is automatically collected.

## Exact inputs and reference

After root's preparation review, a bounded EHPC compute002 PBS export runs the
unchanged original fixture functions. It stores independent original32 and
original64 cells/parameters/interval/option as plain NPZ arrays, with file SHA,
each dtype, shape, size and C-order array-byte SHA. Original32 is explicitly
constructed by typed NumPy32 phase equations; it is never a cast of a 64-bit
inverse. Initial cells, parameters and interval quantization are recorded.

The export performs 40 primitive calls and 34 full integrations, all NumPy.
Eight small checker tests first exercise byte-exact serialization, corruption,
numeric/discrete gates, dtype/shape/field completeness, nonfinite rejection and
near-zero absolute comparison. They perform no model calls and are not yet run.
Original G is the main64 full reference; K's NumPy64 path is the perched64
reference. K64 shares its algorithm with K32 and is not independent official
thermal truth. Original K's official J hydrology used shared NM64 thermal
closure and its historical 1mm diagnostic was false; no new 1mm pass is claimed.
No CTSM executable is rerun in PO. Existing F/G/I/K/PM evidence remains separate.

CUDA32 and JAX32 read the same closed input32 NPZ bytes. They do not import any
fixture generator or run NumPy physics. Actual host-to-device transfer is checked
byte-exact; dtype changes are rejected. Original64 uses the same nominal recipe
with distinct quantization: its physical comparison is not called same-input.

Every continuous returned numeric diagnosis, trial field, final cell and ledger
field uses abs(a-b) <= 1e-6 + 1e-6*abs(reference) in the CUDA32/JAX32 pair. Nothing
is excluded because it disagrees. Flags, donor indices, transition counts and
accepted/rejected counts require exact equality. Raw differences are retained.
Backend label, prose metadata, wall time and observer call statistics are
reported separately. NumPy32 differences are also reported completely but do
not replace the required actual CUDA32/JAX32 pair.

Physical comparison to sealed NumPy64 retains 10% with explicit absolute floors:
mass/liquid/ice .001 kg/m², exported heat .05 J/m² main or .5 J/m² perched,
stored heat .5 J/m². Temperature .001 K and layer thickness 1e-6 m use absolute
limits; main front uses original .001 m, perched front max(1e-6 m,10%). Near-zero
percentages are null with the absolute criterion reported, never divided by zero.
These comparisons do not relax hard conservation: each dtype/backend's original
64*eps scale is reconstructed in original operation order and independently
re-summed in float64. Exact elapsed clock, output dtype, convergence and unchanged
input bytes are checked. All continuous hard-budget returns also remain in the
1e-6 device-pair comparison.

## Future execution and closure

1. Upload reviewed preparation plus original source.tar.gz to a new
   /tmp/noahmp-drainage-gold-po directory on manager and compute002. The PBS file
   is prepared for 1 CPU, 2 GiB, 20 minutes. No task has been submitted.
2. Wait for the actual export parent0, PBS F0 and Stageout0. Preserve original
   stdout/stderr, receipt, parent exit and qstat. close_gold_po.py copies the real
   packets, adds their complete inventory and emits a seal; it cannot create a
   numerical reference. Root reviews the resulting gold before device handoff.
3. When the current CUDA1 queue permits it, invoke run_device_parent_po.py once
   per backend with the same source/gold/seal. Each worker has its own fresh
   /tmp/drainage-po-* directory/caches, >8 GiB GPU and >32 GiB host startup gate,
   1 CPU thread and a 3-hour failure bound. There is no daemon, watcher or qsub
   in this preparation and no automatic wait-then-launch against NQ/NS/NZ.
4. Sequential cuda then jax, not simultaneous; exact physical UUID
   GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452 is required and the worker PID's actual
   nvidia-smi UUID is checked. Use the existing xuanze environment with
   jax=jaxlib0.11.2; never install an old version or claim EHPC JAX CPU coverage.
   Original source remains unchanged. This wrapper's startup memory check is
   not a continuous RSS cap; the finite child wall-time bound is explicit.
5. Only after both real parent0 closures, run pair_device_po.py remotely to
   compare every numeric field. A branch/count or numeric failure is retained,
   not converted into a pass or trimmed from the cases. Output is component
   validation only, not coupled or annual acceptance.

Example commands (templates, not executed):

```
python -B close_gold_po.py --result RESULT --qstat ACTUAL_F0_QSTAT --output GOLD
python -B run_device_parent_po.py --source NM584 --gold GOLD --seal GOLD-seal.json --backend cuda --output /tmp/drainage-po-cuda-ATTEMPT
python -B run_device_parent_po.py --source NM584 --gold GOLD --seal GOLD-seal.json --backend jax --output /tmp/drainage-po-jax-ATTEMPT
python -B pair_device_po.py --source NM584 --gold GOLD --seal GOLD-seal.json --cuda CUDA_PARENT --jax JAX_PARENT --output PAIR.json
```

Prepared source/checks are not executed gold. All input/gold/device receipts and
exit fields stay absent until their actual runs occur. There is no fabricated
passed flag or anticipated zero error in this preparation.

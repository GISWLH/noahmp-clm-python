"""Freeze reviewed PO controls plus immutable source for one EHPC export."""
from pathlib import Path
import ast
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2)+'\n').encode()
CONTROL_SHA='82c291347cae1e92e682947c3240e5eb2494b4964c483a4e9a21010488b41d40'


def main():
    prep=BASE/'drainage-device-handoff-po-b-preparation'
    manifest=(prep/'CONTROLS_SHA256.json').read_bytes();assert sha(manifest)==CONTROL_SHA
    index=json.loads(manifest);assert len(index)==32
    assert {p.name for p in prep.iterdir() if p.is_file()}==set(index)|{'CONTROLS_SHA256.json'}
    assert all(sha((prep/n).read_bytes())==h for n,h in index.items())
    assert sha((BASE/'drainage-device-handoff-po-prepared-initial-evidence.tar.gz').read_bytes())=='9e18ce8d8ddb66245bf7752f3b777db70628041bcdb996a90c2addfbdc83857c'
    original=(BASE/'clm-drainage-option2-pm-execution/dispatch_component_pb.py').read_text()
    code=original.replace('noahmp-clm-drainage-option2-pm','noahmp-drainage-gold-po-b')
    code=code.replace('dispatch_drainage_option2_pm.py','dispatch_drainage_gold_po_b.py')
    code=code.replace("ROOT / 'execution/component_pb.pbs'","ROOT / 'preparation/export_po.pbs'")
    code=code.replace('1CPU/2GB/10min/compute002','1CPU/2GB/20min/compute002')
    code=code.replace('PM two additional full option2 NumPy32 vs original NumPy64 component cases only; no old18 tests, coupled column, field year or GPU.',
        'PO actual exact-input NumPy gold export: 9 checker tests and fixed20 recipes; observed call counters only. No GPU, coupled column or field year.')
    ast.parse(code)
    dispatch=BASE/'dispatch_drainage_gold_po_b.py';dispatch.write_text(code,encoding='utf8',newline='\n')
    source=BASE/'climatology-final-candidate-nm-source.tar.gz'
    assert sha(source.read_bytes())=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    files={'preparation/'+p.name:p.read_bytes() for p in prep.iterdir() if p.is_file()}
    files['execution/dispatch_component_pb.py']=dispatch.read_bytes()
    files['source.tar.gz']=source.read_bytes()
    files['stage-inventory.json']=js({n:sha(b) for n,b in sorted(files.items())})
    target=BASE/'drainage-gold-po-b-stage.tar.gz';assert not target.exists()
    with tarfile.open(target,'w:gz') as tar:
        for n,b in sorted(files.items()):
            m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==files
    record=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,members=len(files),
        preparation_manifest_sha256=CONTROL_SHA,dispatcher_sha256=sha(dispatch.read_bytes()),
        source_archive_sha256=sha(source.read_bytes()),local_numerical_execution=False,submitted=False,
        resources='compute002 / 1CPU / 2GiB / 20min',GPU_tasks=0)
    (BASE/'drainage-gold-po-b-stage-package.json').write_bytes(js(record));print(json.dumps(record))


if __name__=='__main__':main()

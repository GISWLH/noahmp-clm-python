"""Minimum observational serialization fix in a fresh PO-b tree, no physics edit."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
OLD=BASE/'drainage-device-handoff-po-preparation'
NEW=BASE/'drainage-device-handoff-po-b-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda x:(json.dumps(x,indent=2,allow_nan=False)+'\n').encode()


def main():
    oldmanifest=(OLD/'CONTROLS_SHA256.json').read_bytes()
    assert sha(oldmanifest)=='4f8e5271373cf9ad59a3806b19f3e660ce6e7f41cebfda93ea48be34c79e7d85'
    index=json.loads(oldmanifest)
    assert len(index)==32 and all(sha((OLD/n).read_bytes())==h for n,h in index.items())
    assert not (NEW/'CONTROLS_SHA256.json').exists();NEW.mkdir(exist_ok=True)
    assert all(p.is_file() and p.name in index for p in NEW.iterdir())
    for n in index:(NEW/n).write_bytes((OLD/n).read_bytes())
    def change(name,old,new):
        path=NEW/name;text=path.read_text(encoding='utf8');assert text.count(old)==1,(name,old)
        path.write_text(text.replace(old,new),encoding='utf8',newline='\n')
    change('arrays_po.py','independently_scaled_bound=mathematical_bound,','independently_scaled_bound=float(mathematical_bound),')
    change('test_arrays_po.py','from arrays_po import descriptor,freeze,read_arrays,same_precision,physical',
        'from arrays_po import descriptor,freeze,read_arrays,same_precision,physical,hard_audit')
    inserted='''    def test_hard_audit_numpy32_metadata_is_json_serializable(self):
        import json
        c=np.zeros((4,6),np.float32);c[:,4]=1.;c[:,5]=2.
        outputs={}
        for col,label,residual,bound in [(4,'water','water_residual_kg_m2','water_bound_kg_m2'),
                (5,'enthalpy','energy_residual_j_m2','energy_bound_j_m2')]:
            outputs['trial.'+label+'_after']=c[:,col].copy()
            outputs['trial.'+('layer_mass_kg_m2' if col==4 else 'layer_enthalpy_j_m2')]=np.zeros(4,np.float32)
            outputs['trial.'+residual]=np.float32(0.)
            outputs['trial.'+bound]=np.float32(64*np.finfo(np.float32).eps*(8. if col==4 else 16.))
        audit=hard_audit({'cells':c},outputs,'numpy')
        decoded=json.loads(json.dumps(audit,allow_nan=False))
        for label,col,scale,bound in [('water',4,8.,'water_bound_kg_m2'),('heat',5,16.,'energy_bound_j_m2')]:
            self.assertEqual(decoded['trial'][label]['independently_scaled_bound'],float(64*np.finfo(c.dtype).eps*scale))
            self.assertEqual(decoded['trial'][label]['original_bound'],float(outputs['trial.'+bound]))
            self.assertEqual(decoded['trial'][label]['native_residual'],0.)

'''
    change('test_arrays_po.py',"    def test_plain_arrays_scalar_dtype_shape_bytes_roundtrip(self):",inserted+"    def test_plain_arrays_scalar_dtype_shape_bytes_roundtrip(self):")
    change('run_export_parent_po.py',"log,re.M))==8","log,re.M))==9")
    change('run_export_parent_po.py',"r'^Ran 8 tests in '","r'^Ran 9 tests in '")
    change('run_export_parent_po.py',"receipt['actual_checker_tests']=8","receipt['actual_checker_tests']=9")
    change('contract_po.py',"receipt['actual_checker_tests']==8","receipt['actual_checker_tests']==9")
    change('export_po.pbs','stage=/tmp/noahmp-drainage-gold-po','stage=/tmp/noahmp-drainage-gold-po-b')
    change('export_po.pbs','#PBS -N drainage-gold-po','#PBS -N drainage-gold-po-b')
    change('README_PO.md','Eight small checker tests first exercise','Nine small checker tests first exercise')
    with (NEW/'README_PO.md').open('a',encoding='utf8') as f:
        f.write('''\nPO-b is a fresh export attempt following original1659 parent/child1: its eight
checker tests passed, and one NumPy32 trial/full integration plus13 inverse calls
returned before the JSON writer rejected a float32 metadata value. The original
4f8e controls and failed outputs remain unchanged. Only the independently scaled
audit diagnostic is converted to a Python float for JSON; no arithmetic value,
original bound, array, input or integration is modified. A ninth actual checker
serializes a synthetic float32 hard audit and verifies its unchanged numeric
values. PO-b does not resume the failed parent or claim its partial run as gold.
''')
    diffs=[]
    for n in index:
        if (NEW/n).read_bytes()!=(OLD/n).read_bytes():
            diffs.extend(difflib.unified_diff((OLD/n).read_text(encoding='utf8').splitlines(True),(NEW/n).read_text(encoding='utf8').splitlines(True),fromfile='original/'+n,tofile='po-b/'+n))
    (BASE/'drainage-handoff-po-to-po-b.diff').write_text(''.join(diffs),encoding='utf8')
    for p in NEW.glob('*.py'):ast.parse(p.read_bytes())
    assert len([n for n in ast.walk(ast.parse((NEW/'test_arrays_po.py').read_bytes())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')])==9
    manifest={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir()) if p.is_file()}
    assert len(manifest)==32
    (NEW/'CONTROLS_SHA256.json').write_bytes(js(manifest))
    files={'preparation/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()}
    files['original-controls.json']=oldmanifest
    files['po-to-po-b.diff']=''.join(diffs).encode()
    files['builder.py']=Path(__file__).read_bytes()
    files['artifact-inventory.json']=js({n:sha(b) for n,b in sorted(files.items())})
    target=BASE/'drainage-device-handoff-po-b-prepared-evidence.tar.gz'
    with tarfile.open(target,'w:gz') as tar:
        for n,b in sorted(files.items()):
            item=tarfile.TarInfo(n);item.size=len(b);tar.addfile(item,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==files
    record=dict(prepared_only=True,controls=32,controls_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),
        original_controls_manifest_sha256=sha(oldmanifest),original32_unchanged=True,checker_tests_prepared=9,
        changed_controls=[n for n in index if index[n]!=manifest[n]],archive=target.name,sha256=sha(target.read_bytes()),
        members=len(files),bytes=target.stat().st_size,local_numerical_execution=False,submitted=False)
    (BASE/'drainage-device-handoff-po-b-prepared-package.json').write_bytes(js(record));print(json.dumps(record))


if __name__=='__main__':main()

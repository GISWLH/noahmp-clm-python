import numpy as np, cupy as cp, json
import test_gpu_clm_bgc_column as t
from noahmp_clm.gpu import clm_layered_column as jl
from noahmp_clm.gpu.cuda import clm_layered_column as cl
from noahmp_clm.gpu.clm_bgc_column import step_clm_bgc_columns_jax
from noahmp_clm.gpu.cuda.clm_bgc_column import step_clm_bgc_columns_cuda
saved={}
def wrap(fn,name,convert):
 def call(*args,**kwargs):
  saved[name]=[convert(v) for v in args]
  return fn(*args,**kwargs)
 return call
jl.step_clm_layered_columns_jax=wrap(jl.step_clm_layered_columns_jax,'jax',np.asarray)
cl.step_clm_layered_columns_cuda=wrap(cl.step_clm_layered_columns_cuda,'cuda',cp.asnumpy)
a,f,dep,e,c=t.cases(np.float32);n=np.full(len(f),.00001,np.float32)
aa=bb=a
for step in range(2):
 print("STEP",step,flush=True)
 ca=t.host(step_clm_bgc_columns_cuda(*aa,f,environment=e,calendar=c,nitrogen_deposition_gn_m2=n,deposition=dep,return_surface=True),cp.asnumpy)
 ja=t.host(step_clm_bgc_columns_jax(*bb,f,environment=e,calendar=c,nitrogen_deposition_gn_m2=n,deposition=dep,return_surface=True))
 for k,(x,y) in enumerate(zip(saved['cuda'],saved['jax'])):
  if not np.array_equal(x,y):
   ids=np.argwhere(x!=y);print('input',k,'count',len(ids),'max',float(abs(x-y).max()),'samples',[(v.tolist(),float(x[tuple(v)]),float(y[tuple(v)])) for v in ids[:20]],flush=True)
 
 np.savez_compressed(f"probe-step-{step}.npz",cuda_site=saved["cuda"][4],jax_site=saved["jax"][4],**{f"old{k}":v for k,v in enumerate(aa)})
 aa=t.next_bgc_arrays(aa,ca);bb=t.next_bgc_arrays(bb,ja)
def walk(a,b,p=''):
 for k in b:
  if isinstance(b[k],dict):walk(a[k],b[k],p+'/'+k);continue
  x,y=a[k],b[k]
  if not np.array_equal(x,y):
   diff=abs(x-y);bad=diff>1e-6+1e-6*abs(y)
   print('output',p+'/'+k,'max',float(diff.max()),'bad',int(bad.sum()),flush=True)
walk(ca,ja)
np.savez_compressed('probe-inputs.npz',cuda_site=saved['cuda'][4],jax_site=saved['jax'][4],cuda_plant=ca['biogeochemistry']['turnover']['state'],jax_plant=ja['biogeochemistry']['turnover']['state'],plant_parameters=a[12],site=a[4])

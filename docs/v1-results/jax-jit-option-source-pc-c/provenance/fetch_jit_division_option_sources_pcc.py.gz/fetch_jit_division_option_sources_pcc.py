"""Archive pinned official JAX/OpenXLA source only; no runtime compilation."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import urllib.request

BASE=Path(__file__).resolve().parent/'jax-jit-option-source-pc-c'
JAX='32544801e26115ac1794926d027148abf3baf009'
XLA='91888df6ce85102c30220e41d952065925e10886'
sources={
    **{('jax-'+path.rsplit('/',1)[-1]):f'https://raw.githubusercontent.com/jax-ml/jax/{JAX}/{path}' for path in ('jax/_src/api.py','jax/_src/pjit.py','jax/_src/compiler.py')},
    **{('xla-'+path.rsplit('/',1)[-1]):f'https://raw.githubusercontent.com/openxla/xla/{XLA}/{path}' for path in ('xla/pjrt/pjrt_executable.h','xla/pjrt/pjrt_executable.cc','xla/xla.proto','xla/pjrt/pjrt_stream_executor_client.cc','xla/pjrt/gpu/se_gpu_pjrt_client.cc')},
}

def fetch(pair):
    name,url=pair;target=BASE/name;assert not target.exists()
    with urllib.request.urlopen(url,timeout=45) as response:
        assert response.status==200;raw=response.read()
    target.write_bytes(raw)
    return name,dict(url=url,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),actual_HTTP_status=200)

def main():
    assert not BASE.exists();BASE.mkdir()
    with ThreadPoolExecutor(max_workers=4) as pool:result=dict(pool.map(fetch,sources.items()))
    (BASE/'SOURCES.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({name:row['sha256'] for name,row in result.items()}))

if __name__=='__main__':main()

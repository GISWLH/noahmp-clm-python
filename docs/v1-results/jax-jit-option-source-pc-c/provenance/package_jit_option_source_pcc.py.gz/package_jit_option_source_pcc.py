"""Deterministic pinned-source audit package, with no numerical execution."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

base=Path(__file__).resolve().parent
folder=base/'jax-jit-option-source-pc-c'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
sources=json.loads((folder/'SOURCES.json').read_bytes())
assert len(sources)==10
assert all(sha((folder/name).read_bytes())==row['sha256'] and (folder/name).stat().st_size==row['bytes'] for name,row in sources.items())
items={path.name:path.read_bytes() for path in folder.iterdir() if path.is_file()}
for name in ('fetch_jit_division_option_sources_pcc.py','complete_jit_division_option_sources_pcc.py',Path(__file__).name):
    items['provenance/'+name]=(base/name).read_bytes()
items['artifact-inventory.json']=encode({name:dict(sha256=sha(raw),bytes=len(raw)) for name,raw in sorted(items.items())})
target=base/'jax-jit-option-source-pc-c-evidence.tar.gz';assert not target.exists()
with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w') as archive:
        for name,raw in sorted(items.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
assert files(target.read_bytes())==items
report=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
    sources=len(sources),runtime_api_trials=0,numerical_calls=0,scope='Pinned primary JAX/OpenXLA source audit of per-JIT override types and actual GPU compile path; no supported public map override found, no production changes.')
(base/'jax-jit-option-source-pc-c-package.json').write_bytes(encode(report));print(json.dumps(report))

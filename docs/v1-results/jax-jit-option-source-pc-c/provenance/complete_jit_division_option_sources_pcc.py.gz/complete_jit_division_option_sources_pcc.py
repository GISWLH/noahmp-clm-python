"""Complete static source audit after original moved-path HTTP404; no runtime test."""
from pathlib import Path
import hashlib
import json
import urllib.request
from fetch_jit_division_option_sources_pcc import BASE,JAX,XLA,sources

def main():
    original_missing='xla-pjrt_stream_executor_client.cc'
    assert not (BASE/original_missing).exists()
    failed_url=sources.pop(original_missing)
    sources['xla-pjrt_stream_executor_client.cc']=f'https://raw.githubusercontent.com/openxla/xla/{XLA}/xla/pjrt/se/pjrt_stream_executor_client.cc'
    sources['jax-pxla.py']=f'https://raw.githubusercontent.com/jax-ml/jax/{JAX}/jax/_src/interpreters/pxla.py'
    sources['xla-common_pjrt_client.cc']=f'https://raw.githubusercontent.com/openxla/xla/{XLA}/xla/pjrt/common_pjrt_client.cc'
    records={}
    for name,url in sources.items():
        path=BASE/name;fetched_now=False
        if not path.exists():
            with urllib.request.urlopen(url,timeout=45) as response:
                assert response.status==200;raw=response.read()
            path.write_bytes(raw);fetched_now=True
        raw=path.read_bytes();records[name]=dict(url=url,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),new_fetch_in_completion=fetched_now)
    failure=dict(initial_static_source_fetch_failed=True,HTTP_status=404,missing_url=failed_url,
        preserved_existing_files=True,correct_path_discovered_from_actual_GPU_client_include=True,no_numerical_execution=True)
    assert not (BASE/'FETCH_FAILURE.json').exists() and not (BASE/'SOURCES.json').exists()
    (BASE/'FETCH_FAILURE.json').write_text(json.dumps(failure,indent=2)+'\n')
    (BASE/'SOURCES.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records))

if __name__=='__main__':main()

"""Private CUDA instrumentation and bounded local-branch candidate, never a trajectory."""
from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=Path('/tmp/noahmp-bounded-cn-co/source');r=b/'optics-phase-di';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(manifest)==568 and all(sha(s/n)==v for n,v in manifest.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import cupy as cp
import noahmp_clm.gpu.cuda.canopy_phase_surface as surface
fixture=b/'optics-surface-dg/failed-surface-input-output.npz';inputs_hash=sha(fixture)
with np.load(fixture,allow_pickle=False) as z:raw=dict(z)
arrays=tuple(raw['input'+str(k)] for k in range(9));controls={k.split('/',1)[1]:v for k,v in raw.items() if k.startswith('control/')};assert controls['parameters'].shape==(1,10,10) and 'stem_area' in controls and 'exchange_extension' in controls
def host(v):return {k:host(x) for k,x in v.items()} if isinstance(v,dict) else cp.asnumpy(v)
def flat(d,prefix=''):
    result={}
    for k,v in d.items():result.update(flat(v,prefix+k+'/') if isinstance(v,dict) else {prefix+k:v})
    return result
start=time.monotonic();baseline=flat(host(surface.run_canopy_phase_surface_cuda(*arrays,raise_on_failure=False,**controls)))
assert set(baseline)=={k[7:] for k in raw if k.startswith('output/')}
assert all(v.dtype==raw['output/'+k].dtype and v.shape==raw['output/'+k].shape and v.tobytes()==raw['output/'+k].tobytes() for k,v in baseline.items()),'Original repeatedsingle surface differs from capturedfailedcall'
folder=s/'src/noahmp_clm/gpu/cuda';names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu','enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu','snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu');texts={n:(folder/n).read_text() for n in names};original=texts['canopy_phase_energy_kernel.cu'];header='extern "C" { __device__ float di_context[825],di_phase_out[300],di_trace[101*26]; }\n'
needle='phase_evaluate(v,x,r,out);if(phase_max(r,12)<=tolerance)break;';assert original.count(needle)==1
record='''phase_evaluate(v,x,r,out);int di_at=iteration*26;di_trace[di_at]=phase_max(r,12);di_trace[di_at+1]=(float)restarts;for(int k=0;k<12;++k){di_trace[di_at+2+k]=x[k];di_trace[di_at+14+k]=r[k];}if(phase_max(r,12)<=tolerance)break;'''
instrumented=original.replace(needle,record)
needle='    out[291]=restarts;';assert instrumented.count(needle)==1
record='''    out[291]=restarts;
    for(int i=0;i<10;++i){di_context[i]=v.phase_active[i]?1.f:0.f;di_context[34+i]=v.leaf[i];di_context[77+i]=v.soil[i];di_context[811+i]=v.area[i];}
    for(int i=0;i<12;++i){di_context[10+i]=x[i];di_context[22+i]=r[i];}
    for(int i=0;i<23;++i)di_context[44+i]=v.u[i];
    for(int i=0;i<20;++i){di_context[67+i]=v.f[i];di_context[87+i]=v.c[i];}
    for(int i=0;i<9;++i)di_context[107+i]=v.b[i];
    for(int i=0;i<100;++i)di_context[116+i]=v.p[i];
    for(int i=0;i<584;++i)di_context[216+i]=v.rad[i];
    di_context[821]=v.water_velocity;di_context[822]=v.heat_temperature;di_context[823]=(float)iteration;di_context[824]=failed?1.f:0.f;
    for(int i=0;i<300;++i)di_phase_out[i]=out[i];'''
# Array fields use disjoint offsets: leaf34:44,u44:67,f67:87,soil800:810,c87:107,b107:116,p116:216,rad216:800,area811:821.
record=record.replace('di_context[77+i]=v.soil[i]','di_context[800+i]=v.soil[i]')
instrumented=instrumented.replace(needle,record)
begin=instrumented.index('        // Retry a derivative confined');end=instrumented.index('        bool retry=',begin);block=instrumented[begin:end];assert block.count('if(!accepted) {')==1 and block.count('for(int k=0;k<24&&!accepted;++k)')==1 and block.count('if(!accepted&&candidate_norm<norm)')==1
changed=block.replace('if(!accepted) {','if(!accepted||chosen_norm>.999f*norm) {').replace('for(int k=0;k<24&&!accepted;++k)','bool local_accepted=false;for(int k=0;k<24&&!local_accepted;++k)').replace('if(!accepted&&candidate_norm<norm)','if(!local_accepted&&candidate_norm<chosen_norm)').replace('chosen[i]=trial[i];accepted=true;chosen_norm=candidate_norm;','chosen[i]=trial[i];accepted=true;local_accepted=true;chosen_norm=candidate_norm;');assert 'local_accepted=true' in changed
candidate=instrumented[:begin]+changed+instrumented[end:];kernel_name='run_canopy_phase_surface_stems';real=surface._kernel;records=[]
try:
    for label,phase in [('instrumented-original',instrumented),('private-local-branch',candidate)]:
        material={**texts,'canopy_phase_energy_kernel.cu':phase};source='#define CANOPY_LAYER_PARAMETERS\n'+header+'\n'.join(material[n] for n in names);(r/(label+'.cu')).write_text(source);module=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=(kernel_name,));kernel=module.get_function(kernel_name)
        get=lambda n,shape:cp.ndarray(shape,cp.float32,memptr=module.get_global(n));get('di_trace',(101,26)).fill(cp.nan)
        def selected(extended=False,vic=False,stems=False,profiled=False):
            assert extended and stems and profiled;return kernel
        surface._kernel=selected;value=flat(host(surface.run_canopy_phase_surface_cuda(*arrays,raise_on_failure=False,**controls)));cp.cuda.runtime.deviceSynchronize();exact=all(v.dtype==baseline[k].dtype and v.shape==baseline[k].shape and v.tobytes()==baseline[k].tobytes() for k,v in value.items());assert label!='instrumented-original' or exact,'Instrumentation changes returnedfields'
        np.savez_compressed(r/(label+'-output.npz'),**value);np.savez_compressed(r/(label+'-inner.npz'),context=cp.asnumpy(get('di_context',(825,))),phase_output=cp.asnumpy(get('di_phase_out',(300,))),trace=cp.asnumpy(get('di_trace',(101,26))))
        row=dict(label=label,all_original_surface_fields_byteexact=exact,converged=bool(value['converged'][0]),canopy_converged=bool(value['canopy_converged'][0]),all_finite=all(np.all(np.isfinite(v)) for v in value.values()),iterations=value['iterations'].tolist(),restarts=value['restarts'].tolist(),max_solver_residual=value['max_solver_residual'].tolist(),source_sha256=sha(r/(label+'.cu')));records.append(row);print(json.dumps(row),flush=True)
finally:surface._kernel=real
unchanged=all(sha(s/n)==v for n,v in manifest.items());d=dict(records=records,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),raw_input_sha256=inputs_hash,seconds=time.monotonic()-start,scope='Private derivedGPU modules only: firsttrace must preserve all originalsurface outputbytes; candidate tries currentbranchNewton after weakstrictdescent and accepts only lowerbestfullnorm. Original100/.005/physicalconvergence flags kept, source/tests/trajectory unchanged. IndependentNumPyEHPC403 returnedroot first. Candidate is not productionfix, allbackend/wholecolumn/year/science validation pending.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert unchanged;sys.stdout.flush();sys.stderr.flush();os._exit(0)

from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'optics-phase-di';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();controls={}
for name in ['probe_optics_phase_di.py','control_optics_phase_di.py',Path(__file__).name]:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=sha(r/name)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'control_optics_phase_di.py')],env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controls_sha256=controls,physical_device=1,uuid=env['CUDA_VISIBLE_DEVICES'],scope='Private copiedfailedtendency diagnostic, actualparentwait and originalguards. No originalyearresume or completionclaim.');(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

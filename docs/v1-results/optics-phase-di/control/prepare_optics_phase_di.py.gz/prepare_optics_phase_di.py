from pathlib import Path
import ast
o=Path(__file__).parent
for stem in ['launch','control']:
    text=(o/(stem+'_optics_surface_dg.py')).read_text().replace('optics-surface-dg','optics-phase-di').replace('optics_surface_dg','optics_phase_di')
    if stem=='control':
        begin=text.index("good=code==0 and d.get('expected_failure_reproduced')");end=text.index(';row=dict(',begin)
        text=text[:begin]+"good=code==0 and d.get('source_unchanged') and len(d.get('records',[]))==2 and d['records'][0]['all_original_surface_fields_byteexact']"+text[end:]
    ast.parse(text);p=o/(stem+'_optics_phase_di.py');assert not p.exists();p.write_bytes(text.encode())
print('Prepared two private-module controls with original32GiBhost/8GiBGPU guard and actualparentwait.')

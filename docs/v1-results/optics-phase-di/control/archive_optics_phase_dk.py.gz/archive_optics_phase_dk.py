from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'optics-phase-di';d=json.loads((r/'exit.json').read_text());v=json.loads((r/'receipt.json').read_text());assert d['actual_child_returncode']==0 and d['diagnostic_delivered'] and v['source_unchanged'] and len(v['records'])==2 and v['records'][0]['all_original_surface_fields_byteexact'];a=b/'optics-phase-di-evidence.tar.gz';assert not a.exists();items=[(p,'probe/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in [Path(__file__).name,'prepare_optics_phase_di.py']);items.append((b/'optics-surface-dg/failed-surface-input-output.npz','inputs/original-failed-surface.npz'))
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

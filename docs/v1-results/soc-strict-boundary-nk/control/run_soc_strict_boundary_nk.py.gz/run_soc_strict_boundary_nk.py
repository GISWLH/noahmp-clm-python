"""EHPC original-versus-corrected assessment boundary regression."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
root = Path('/tmp/noahmp-soc-strict-boundary-nk')
out = root / 'result'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((root / 'soc-strict-boundary-nk-plan.json').read_text())
base = Path('/home/zhangyq/noahmp-v1')
assert sha(base / plan['original_source_archive']) == plan['original_source_sha256']
assert sha(root / plan['patch_archive']) == plan['patch_sha256']
records = []
failure = None
start = time.monotonic()
try:
    with tarfile.open(root / plan['patch_archive']) as tf:
        patch = {m.name: tf.extractfile(m).read() for m in tf}
    assert set(patch) == set(plan['after_sha256'])
    for variant in ['negative', 'positive']:
        result = out / variant
        result.mkdir()
        source = Path(os.environ['TMPDIR']) / variant
        source.mkdir()
        with tarfile.open(base / plan['original_source_archive']) as tf:
            tf.extractall(source, filter='data')
        assert sha(source / 'SOURCE_SHA256.json') == plan['original_manifest_sha256']
        parent = json.loads((source / 'SOURCE_SHA256.json').read_text())
        assert len(parent) == 581 and all(sha(source / n) == h for n, h in parent.items())
        for name, digest in plan['before_sha256'].items():
            assert parent[name] == digest
        derived = dict(parent)
        changes = [plan['test']] if variant == 'negative' else list(patch)
        for name in changes:
            (source / name).write_bytes(patch[name])
            assert sha(source / name) == plan['after_sha256'][name]
            derived[name] = sha(source / name)
        manifest_raw = (json.dumps(derived, indent=2) + '\n').encode()
        (source / 'SOURCE_SHA256.json').write_bytes(manifest_raw)
        (result / 'SOURCE_SHA256.json').write_bytes(manifest_raw)
        env = os.environ.copy()
        env.update(PYTHONPATH=':'.join(map(str, [base / 'test-deps', source, source / 'src', source / 'tests', source / 'benchmarks'])),
                   PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', CUDA_VISIBLE_DEVICES='', JAX_PLATFORMS='cpu',
                   OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
        env.pop('NOAHMP_REQUIRE_GPU', None)
        env.pop('PYTEST_PLUGINS', None)
        collect = subprocess.run([sys.executable, '-m', 'pytest', '--collect-only', '-q', plan['test']],
                                 cwd=source, env=env, capture_output=True, text=True)
        (result / 'collection.log').write_text(collect.stdout + collect.stderr)
        nodes = [n for n in collect.stdout.splitlines() if n.startswith('tests/') and '::' in n]
        assert collect.returncode == 0 and len(nodes) == len(set(nodes))
        added = [n for n in nodes if '::test_carbon_convergence_is_strictly_below_five_percent[' in n]
        assert len(added) == plan['added_parameterized_cases'] == 12
        if records:
            assert nodes == records[0]['nodes']
        with (result / 'pytest.log').open('x') as log:
            actual = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-s', plan['test'], '--junitxml=' + str(result / 'junit.xml')],
                                    cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
        xml = ET.parse(result / 'junit.xml').getroot()
        counts = {k: sum(int(q.attrib[k]) for q in xml.iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
        failed = [q.attrib['name'] for q in xml.iter('testcase') if q.find('failure') is not None]
        unchanged = all(sha(source / n) == h for n, h in derived.items())
        row = dict(variant=variant, actual_pytest_parent_returncode=actual, counts=counts, nodes=nodes, failed_nodes=failed,
                   source_manifest_sha256=sha(source / 'SOURCE_SHA256.json'), source_unchanged=unchanged,
                   xml_sha256=sha(result / 'junit.xml'), test_sha256=sha(source / plan['test']))
        records.append(row)
        (result / 'actual.json').write_text(json.dumps(row, indent=2) + '\n')
        assert unchanged and counts['tests'] == len(nodes) and counts['errors'] == counts['skipped'] == 0
        if variant == 'negative':
            assert actual == 1 and counts['failures'] == 4 and len(failed) == 4
            assert all('test_carbon_convergence_is_strictly_below_five_percent[' in n and '5.0-False' in n for n in failed)
            assert all('AssertionError' in q.find('failure').text for q in xml.iter('testcase') if q.find('failure') is not None)
        else:
            assert actual == 0 and counts['failures'] == 0
except Exception as error:
    failure = type(error).__name__ + ': ' + str(error)
    (out / 'traceback.txt').write_text(traceback.format_exc())
result = dict(passed=failure is None and len(records) == 2, failure=failure, records=records,
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, seconds=time.monotonic() - start, scope=plan['scope'])
(out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'records'}), flush=True)
raise SystemExit(0 if result['passed'] else 1)

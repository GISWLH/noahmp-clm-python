from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-run-o'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads((r / 'configuration.json').read_text())
audit = json.loads((r / 'year-boundary.json').read_text())
assert (r / 'pbs-exit.txt').read_text().strip() == '0' and d['official_model_returncode'] == 0 and d['upstream_original_bytes_unchanged']
assert all(s['returncode'] == 0 for s in d['stages'])
assert sha(r / 'official-year-fields.npz') == audit['fields_sha256'] and audit['positive_intervals'] == 17520
assert audit['all_direct_met_fields_exact_at_history_dtype'] and audit['input_field_differences']['QBOT']['nonmatching_at_history_dtype'] == 0
assert all(v == 0 for v in audit['first48_M_max_absolute_difference'].values())
for file in audit['source_files']:
    assert d['model_outputs'][file['file']]['sha256'] == file['sha256']
private = r / 'case-configuration-private.tar.gz'
initial = b / 'ctsm-initial-state-a'
receipt = json.loads((initial / 'receipt.json').read_text())
assert (initial / 'pbs-exit.txt').read_text().strip() == '0' and all(s['returncode'] == 0 for s in receipt['stages'])
assert sha(initial / 'inventory.json') == receipt['inventory_sha256'] and sha(initial / 'selected-initial-state.npz') == receipt['selected_arrays_sha256']
a = b / 'ctsm-qia-copyall-o-evidence.tar.gz'
assert not a.exists()
samples, steps = 0, []
with tarfile.open(a, 'w:gz') as t:
    for root in [r, initial]:
        for p in sorted(root.iterdir()):
            if p.is_file() and p.name != 'case-configuration-private.tar.gz':
                t.add(p, arcname=root.name + '/' + p.name, recursive=False)
    with tarfile.open(private) as original:
        for m in original:
            if m.isfile() and (m.name.endswith(('.stdout.txt', '.stderr.txt', '-adaptation.json', '.stream')) or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in', 'drv_in', 'lnd_in'])) or m.name.startswith('case/user_nl_')):
                raw = original.extractfile(m).read()
                info = tarfile.TarInfo(r.name + '/workspace/' + m.name)
                info.size = len(raw)
                t.addfile(info, io.BytesIO(raw))
                if 'lnd.log.' in m.name:
                    text = raw.decode(errors='replace')
                    samples += text.count('Writing current time sample')
                    steps.extend(map(int, re.findall(r'clm: completed timestep\s+(\d+)', text)))
    assert samples == 17521 and max(steps) == 17520
    summary = dict(scope='Actual official O standard COPYALL input experiment,model/PBS0,full original17520 CF intervals. Original2930 source/meteorology fields/native inputs unchanged. All direct meteorology including QBOT and four solar bands match original at history dtype; prior CLMNCEP77q differences removed. First48 shared raw physical arrays exactly replay M. Coarse soil/default cold/SP-CN/deposition timing comparability still unresolved,not science or Python-year acceptance. Separate official N end-year restart/static metadata inventory is not a cold/common seed.',
                   pbs_job=d['pbs_job'], model_and_pbs_returncode=0, official_model_seconds=next(s['seconds'] for s in d['stages'] if s['stage'] == 'official-model'), total_seconds=d['seconds'], upstream_original_bytes_unchanged=True, history_samples=samples, last_nstep=max(steps), configuration_sha256=sha(r / 'configuration.json'), private_workspace_sha256=sha(private), year_boundary_audit=audit, initial_inventory_receipt=receipt)
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, model_and_pbs_returncode=0, original_intervals=17520, qbot_nonmatching=0)))

from pathlib import Path
import hashlib,json,os,resource,signal,subprocess,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-qia-run-o';scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-qia-run-o';scratch.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic();stages=[];failure=None;value={}
try:
    for archive,digest,dest in [(base/'ctsm-portable-env-b.tar.gz','6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20',scratch/'toolchain'),(base/'ctsm-reference-source-bundle-a.tar.gz','f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',scratch)]:
        assert sha(archive)==digest;dest.mkdir(exist_ok=True)
        with tarfile.open(archive) as t:t.extractall(dest,filter='data')
    source=scratch/'CTSM';prefix=scratch/'toolchain';case=scratch/'case';inputs=scratch/'inputdata';inputs.mkdir();output=scratch/'output'
    point=base/'ctsm-qia-point-inputs-b/derived-inputs.tar.gz';assert sha(point)=='2be11561a179d0aa3150d39cd35404d19b0c8d37c6fa862374be6cf3613ba174'
    with tarfile.open(point) as t:t.extractall(inputs,filter='data')
    point_record=json.loads((base/'ctsm-qia-point-inputs-b/derivation.json').read_text());assert all(sha(inputs/n)==v['sha256'] for n,v in point_record['files'].items())
    lock=json.loads((scratch/'UPSTREAM_SOURCE_LOCK.json').read_text());verify=lambda:all(sha(scratch/n)==v for n,v in lock['files'].items());assert verify()
    aliases=scratch/'compiler-bin';aliases.mkdir()
    for name,target in [('gcc','gcc'),('g++','g++'),('gfortran','gfortran')]:
        (aliases/name).symlink_to(prefix/'bin'/('x86_64-conda-linux-gnu-'+target))
    env=os.environ.copy()
    for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
    env.update(PATH=str(aliases)+':'+str(prefix/'bin')+':/usr/bin:/bin',CONDA_PREFIX=str(prefix),NETCDF_PATH=str(prefix),NETCDF_C_PATH=str(prefix),NETCDF_FORTRAN_PATH=str(prefix),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    def run(label,args,cwd=source):
        start=time.monotonic()
        child=subprocess.Popen(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
        try:out,err=child.communicate(timeout=1200 if label=='case-build' else (600 if label=='official-model' else 180));code=child.returncode
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:out,err=child.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);out,err=child.communicate()
            code=124;err+='\nOwned subprocess group reached declared stage time bound.'
        (scratch/(label+'.stdout.txt')).write_text(out);(scratch/(label+'.stderr.txt')).write_text(err)
        stages.append(dict(stage=label,command=[str(v) for v in args],returncode=code,seconds=time.monotonic()-start));return code
    py=str(prefix/'bin/python');assert run('relocate',[py,str(prefix/'bin/conda-unpack')])==0
    assert run('topo-time-coordinate',[py,str(root/'restore_ctsm_topo_time_a.py'),str(inputs/'CN-Qia.topo.nc'),point_record['files']['CN-Qia.topo.nc']['sha256']])==0
    value['topography_time_metadata_restore']=json.loads((scratch/'topo-time-coordinate.stdout.txt').read_text())
    assert run('urban-auxiliary-point',[py,str(root/'make_ctsm_urbantv_point_b.py'),str(root/'urbantv-selection.json'),str(inputs/'CN-Qia.urbantv.1999-2001.nc')])==0
    value['urban_auxiliary_point']=json.loads((scratch/'urban-auxiliary-point.stdout.txt').read_text())
    assert run('common-radiation-input',[py,str(root/'derive_ctsm_qia_common_radiation_a.py'),str(inputs/'CN-Qia.datm.2003.nc'),str(base/'qia-stem-inputs-a/inputs')])==0
    value['common_radiation_derivation']=json.loads((scratch/'common-radiation-input.stdout.txt').read_text())
    assert run('copyall-input',[py,str(root/'derive_ctsm_qia_copyall_a.py'),str(inputs/'CN-Qia.datm.2003.nc'),str(base/'qia-stem-inputs-a/inputs')])==0
    value['copyall_derivation']=json.loads((scratch/'copyall-input.stdout.txt').read_text())
    assert run('machine-query',[py,str(source/'cime/scripts/query_config'),'--machines','centos7-linux','--long'])==0
    command=[py,str(source/'cime/scripts/create_newcase'),'--case',str(case),'--srcroot',str(source),'--compset','2000_DATM%1PT_CLM50%SP_SICE_SOCN_SROF_SGLC_SWAV','--res','CLM_USRDAT','--machine','centos7-linux','--compiler','gnu','--mpilib','mpi-serial','--pecount','1','--output-root',str(output),'--input-dir',str(inputs),'--handle-preexisting-dirs','a','--run-unsupported']
    assert run('create-case',command)==0
    assert run('xmlchange',[py,str(case/'xmlchange'),'GMAKE_J=1,STOP_OPTION=nsteps,STOP_N=17520,DOUT_S=FALSE'],case)==0
    controls='CLM_USRDAT_NAME=1x1_CNQia,ATM_DOMAIN_PATH='+str(inputs)+',ATM_DOMAIN_FILE=domain.lnd.CN-Qia.nc,LND_DOMAIN_PATH='+str(inputs)+',LND_DOMAIN_FILE=domain.lnd.CN-Qia.nc,RUN_STARTDATE=2002-12-31,START_TOD=57600,ATM_NCPL=48,DATM_CLMNCEP_YR_START=2002,DATM_CLMNCEP_YR_END=2003,DATM_CLMNCEP_YR_ALIGN=2002,CLM_CO2_TYPE=diagnostic,CLM_FORCE_COLDSTART=on,CCSM_BGC=CO2A'
    assert run('point-xmlchange',[py,str(case/'xmlchange'),controls],case)==0
    # Adapt only generated case configuration: EHPC has no modulecmd.
    specific=case/'env_mach_specific.xml';tree=ET.parse(specific);node=tree.getroot()
    module=node.find('module_system');assert module is not None
    before=ET.tostring(module,encoding='unicode');module.clear();module.set('type','none')
    for child in list(node):
        if child.tag=='modules':node.remove(child)
    variables=node.find('environment_variables')
    if variables is None:variables=ET.SubElement(node,'environment_variables')
    for name in ['NETCDF_PATH','NETCDF_C_PATH','NETCDF_FORTRAN_PATH','LD_LIBRARY_PATH']:
        for element in node.findall('.//env'):
            if element.get('name')==name:element.text=str(prefix/'lib') if name=='LD_LIBRARY_PATH' else str(prefix)
        if not any(element.get('name')==name for element in node.findall('.//env')):
            element=ET.SubElement(variables,'env',{'name':name});element.text=str(prefix/'lib') if name=='LD_LIBRARY_PATH' else str(prefix)
    resource_caps=[]
    for element in node.findall('.//resource_limits/resource'):
        name=element.get('name');kind=getattr(resource,name);requested=int(element.text)
        soft,hard=resource.getrlimit(kind)
        if hard!=resource.RLIM_INFINITY and (requested==resource.RLIM_INFINITY or requested>hard):
            element.text=str(hard);resource_caps.append(dict(resource=name,requested=requested,allowed_hard=hard))
    (scratch/'resource-adaptation.json').write_text(json.dumps(dict(scope='Generated case limits capped at existing PBS process hard bounds; no OS/shared limit changed.',caps=resource_caps),indent=2)+'\n')
    tree.write(specific,encoding='utf-8',xml_declaration=True)
    (scratch/'machine-adaptation.json').write_text(json.dumps(dict(scope='Generated case environment only, no upstream machine/physics source edits.',original_module_system=before,new_module_system='none',netcdf_root=str(prefix)),indent=2)+'\n')
    assert run('case-setup',[py,str(case/'case.setup')],case)==0
    # Legacy CIME MPI external interfaces predate GNU Fortran10 checking.
    # Only generated case compiler flags change; original upstream source stays exact.
    adaptations=[]
    for name,line in [('Macros.make','FFLAGS += -fallow-argument-mismatch -fallow-invalid-boz'),('Macros.cmake','string(APPEND FFLAGS " -fallow-argument-mismatch -fallow-invalid-boz")')]:
        path=case/name
        if not path.exists():continue
        before_sha=sha(path);path.write_text(path.read_text()+'\n# Legacy CIME MPI interfaces with GCC12\n'+line+'\n')
        adaptations.append(dict(path=name,original_sha256=before_sha,adapted_sha256=sha(path),appended=line))
    assert any(v['path']=='Macros.make' for v in adaptations)
    (scratch/'compiler-adaptation.json').write_text(json.dumps(dict(scope='Generated case compiler compatibility only, no source or numerical precision/optimization change.',cause='Actual PBS116 GPTL external MPI_BCAST type mismatch; PBS117 FireEmisFactorsMod.F90 integer parameter BOZ literal z000053db rejected by GNU12.',adaptations=adaptations),indent=2)+'\n')

    link_adaptations=[]
    assert (prefix/'lib/liblapack.so').exists() and (prefix/'lib/libblas.so').exists()
    assert run('netcdf-link-flags',[str(prefix/'bin/nf-config'),'--flibs'])==0
    libraries=' '+(scratch/'netcdf-link-flags.stdout.txt').read_text().strip()+' -llapack -lblas'
    assert '-lnetcdff' in libraries and '-lnetcdf' in libraries
    for name,line in [('Macros.make','SLIBS +='+libraries),('Macros.cmake','string(APPEND SLIBS "'+libraries+'")')]:
        path=case/name
        if not path.exists():continue
        before_sha=sha(path);path.write_text(path.read_text()+'\n# Actual PBS120 explicit SLIBS suppressed CIME default netCDF fallback; supply complete nf-config flags and LAPACK/BLAS\n'+line+'\n')
        link_adaptations.append(dict(path=name,original_sha256=before_sha,adapted_sha256=sha(path),appended=line))
    (scratch/'link-adaptation.json').write_text(json.dumps(dict(scope='Generated case complete nf-config NetCDF and LAPACK/BLAS linkage from the unchanged portable environment; no upstream source/numerical setting edits.',adaptations=link_adaptations),indent=2)+'\n')
    # Runtime choices align the requested five-snow-layer/Ball-Berry experiment.
    # Soil/initial-state matching and actual DATM alignment remain to be audited.
    nl=["fsurdat = '"+str(inputs/'surfdata.CN-Qia.engineering.nc')+"'",
        
        "paramfile = '"+str(inputs/'clm5_params.c171117.nc')+"'",
        "fsnowaging = '"+str(inputs/'snicar_drdt_bst_fit_60_c070416.nc')+"'",
        "fsnowoptics = '"+str(inputs/'snicar_optics_5bnd_c090915.nc')+"'",
        "nlevsno = 5", "soil_layerstruct = '10SL_3.5m'", "use_bedrock = .false.",
        "use_luna = .false.", "use_hydrstress = .false.", "stomatalcond_method = 'Ball-Berry1987'",
        "create_crop_landunit = .true.", "irrigate = .false.", "run_zero_weight_urban = .false.",
        "stream_fldfilename_urbantv = '"+str(inputs/'CN-Qia.urbantv.1999-2001.nc')+"'", "megan_factors_file = '"+str(inputs/'megan21_emis_factors_78pft_c20161108.nc')+"'", "hist_nhtfrq = 1", "hist_mfilt = 17520",
        "hist_fincl1 = 'TBOT','QBOT','WIND','ZBOT','FSDS','FLDS','RAIN','SNOW','H2OSNO','TSOI','H2OSOI','FPSN','FSH','EFLX_LH_TOT','FCEV','FCTR','FGEV','QOVER','QDRAI','TLAI','TSAI','ELAI','FGR','FSA','FIRA','TG'"]
    value['sp_photosynthesis_history_scope']='Actual H catalog lacks CN-only GPP; request available FPSN photosynthesis diagnostic. Gross/net GPP interpretation still requires source/output audit; SP cannot validate NEE/CN.'
    value['crop_landunit_scope']='Pinned non-FATES CLM requires create_crop_landunit=true;PCT_CROP=0 and use_crop=false, so no active crop physics or area in this forest reference.'
    (case/'user_nl_clm').write_text('\n'.join(nl)+'\n')
    (case/'user_nl_cpl').write_text('histaux_a2x = .true.\nhistaux_l2x = .true.\n')
    preview=run('preview-namelists',[py,str(case/'preview_namelists')],case)
    if preview==0:
        build_code=run('case-build',[py,str(case/'case.build'),'--skip-provenance-check'],case)
        if build_code==0:
            executables=list(output.rglob('cesm.exe'));assert len(executables)==1;executable=executables[0]
            assert run('executable-linkage',['ldd',str(executable)],case)==0
            assert 'not found' not in (scratch/'executable-linkage.stdout.txt').read_text()
            rundir=output/'case/run';assert (rundir/'datm_in').exists() and (rundir/'drv_in').exists()
            def stream(name,file,fields):
                root=ET.Element('file',{'id':'stream','version':'1.0'});ET.SubElement(root,'dataSource').text='GENERIC'
                dom=ET.SubElement(root,'domainInfo');ET.SubElement(dom,'variableNames').text='time time\nxc lon\nyc lat\narea area\nmask mask'
                ET.SubElement(dom,'filePath').text=str(inputs);ET.SubElement(dom,'fileNames').text='domain.lnd.CN-Qia.nc'
                field=ET.SubElement(root,'fieldInfo');ET.SubElement(field,'variableNames').text='\n'.join(a+' '+b for a,b in fields)
                ET.SubElement(field,'filePath').text=str(inputs);ET.SubElement(field,'fileNames').text=file;ET.SubElement(field,'offset').text='0'
                # The pinned Fortran reader scans one tag/data record per line.
                # E aborted before physics: <dataSource> was inline after <file>.
                for element in root.iter():
                    if element.text and element.text.strip():element.text='\n'+element.text.strip()+'\n'
                ET.indent(root,space='  ')
                ET.ElementTree(root).write(rundir/name,encoding='utf-8',xml_declaration=True)
                lines=(rundir/name).read_text().splitlines()
                assert all(any(line.lstrip().startswith('<'+tag+'>') for line in lines) for tag in ['dataSource','domainInfo','fieldInfo','variableNames','filePath','fileNames','offset'])
            met=[('TBOT','tbot'),('QBOT','shum'),('U_COPY','u'),('V_COPY','v'),('PTEM_COPY','ptem'),('DENS_COPY','dens'),('PSRF','pbot'),('PSLV_COPY','pslv'),('FLDS','lwdn'),('ZBOT','z'),('CO2_PPM_AUXILIARY','co2diag')]+[(name+'_COPY',name.lower()) for name in ['SWNDR','SWVDR','SWNDF','SWVDF','RAINC','RAINL','SNOWC','SNOWL']]
            aeros=[('BCDEPWET','bcphiwet'),('BCPHODRY','bcphodry'),('BCPHIDRY','bcphidry'),('OCDEPWET','ocphiwet'),('OCPHIDRY','ocphidry'),('OCPHODRY','ocphodry')]+[(f'DSTX{k:02}{suffix}',f'dst{kind}{k}') for k in range(1,5) for suffix,kind in [('WD','wet'),('DD','dry')]]
            stream('qia.met.stream','CN-Qia.datm.2003.nc',met);stream('qia.aero.stream','CN-Qia.aero.2002-2004.nc',aeros);stream('qia.topo.stream','CN-Qia.topo.nc',[('TOPO','topo')])
            original=(rundir/'datm_in').read_text();(scratch/'datm_in.original').write_text(original)
            # Explicit generated DATM input; fields/options come from pinned
            # upstream contracts, not changes to atmospheric/land source.
            datm="&datm_nml\n decomp='1d'\n factorfn='null'\n force_prognostic_true=.false.\n iradsw=1\n presaero=.true.\n restfilm='undefined'\n restfils='undefined'\n wiso_datm=.false.\n/\n&shr_strdata_nml\n datamode='COPYALL'\n domainfile='"+str(inputs/'domain.lnd.CN-Qia.nc')+"'\n dtlimit=1.5,1.5,1.5\n fillalgo='nn','nn','nn'\n fillmask='nomask','nomask','nomask'\n mapalgo='nn','nn','nn'\n mapmask='nomask','nomask','nomask'\n readmode='single','single','single'\n streams='qia.met.stream 2002 2002 2003','qia.aero.stream 2002 2002 2004','qia.topo.stream 1 1 1'\n taxmode='extend','extend','extend'\n tintalgo='upper','linear','lower'\n vectors='null'\n/\n"
            (rundir/'datm_in').write_text(datm)
            value['runtime_inputs']=dict(point_archive_sha256=sha(point),field_mapping=dict(met),meteorology_time_rule='Original unchanged UTC interval midpoints, upper met interpolation; fixed original Erbs direct/diffuse and common0.5 VIS/NIR inputs; explicit pinned-source hypothesis test for nearest midpoint ties plus driver ordering. Actual positive-bin feed-through requires independent audit; no output retagging or physics/source changes.',soil_scope='Nearest original coarse-grid soil,10SL_3.5m/default official cold stores; not matched to Python four-layer original cold seed.',phenology_scope='SP with constant original funded initial LAI/SAI and site crown; not a prognostic CN reference.',co2_scope='Actual auxiliary CO2 mapped to diagnostic co2diag; runtime feed-through still requires verification.',aerosol_scope='Original BC/dust climate at local month centers shifted to UTC,explicit14 endpoint brackets; OC intentionally zero in common-five-species experiment.',generated_datm_input_sha256=sha(rundir/'datm_in'))
            # Normal CIME case.run creates this owned runtime output directory.
            # Direct executable J reached17 samples then failed its timing checkpoint write.
            (rundir/'timing/checkpoints').mkdir(parents=True,exist_ok=True)
            model_code=run('official-model',[str(executable)],rundir)
            value['official_model_returncode']=model_code
            value['model_outputs']={q.relative_to(rundir).as_posix():dict(bytes=q.stat().st_size,sha256=sha(q)) for q in rundir.iterdir() if q.is_file() and (q.suffix=='.nc' or '.log.' in q.name)}
            if model_code==0:
                assert run('year-boundary-audit',[py,str(root/'audit_ctsm_qia_year_boundary_o_a.py'),str(scratch),str(root)],rundir)==0
                value['year_boundary_audit']=json.loads((root/'year-boundary.json').read_text())
            value['model_outputs']={p.relative_to(rundir).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in rundir.iterdir() if p.is_file() and (p.suffix=='.nc' or '.log.' in p.name)}
            value['executable']=dict(path=str(executable),bytes=executable.stat().st_size,sha256=sha(executable),all_shared_libraries_found=True)

    value['input_file_lists']={p.relative_to(case).as_posix():p.read_text() for p in case.rglob('*input_data_list*') if p.is_file()}
    value['case_configuration_created']=True
    value['upstream_original_bytes_unchanged']=verify();assert verify()
except BaseException as e:failure=type(e).__name__+': '+str(e)
if 'verify' in locals():value['upstream_original_bytes_unchanged']=verify()
value.update(scope='Official pinned single-column Qia SP full17520-step engineering reference,5 snow layers/Ball-Berry/LUNA and hydraulic stress disabled. Common real meteorology/deposition/site crown,coarse soil/default official cold stores not matched to Python. Actual model/output and feed-through require original return codes and subsequent audit; no science/annual acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,failure=failure,seconds=time.monotonic()-begun)
(root/'configuration.json').write_text(json.dumps(value,indent=2)+'\n')
with tarfile.open(root/'case-configuration-private.tar.gz','w:gz') as t:
    for p in sorted(scratch.iterdir()):
        if p.name not in ['CTSM','toolchain','compiler-bin']:t.add(p,arcname=p.name)
print(json.dumps({k:v for k,v in value.items() if k!='input_file_lists'}),flush=True)
raise SystemExit(0 if failure is None and all(s['returncode']==0 for s in stages) else 1)

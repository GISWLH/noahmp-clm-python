from pathlib import Path
import ast
import json

r = Path(__file__).resolve().parent
p = (r / 'run_ctsm_qia_n.py').read_text().replace('ctsm-qia-run-n', 'ctsm-qia-run-o')
marker = "    value['common_radiation_derivation']=json.loads((scratch/'common-radiation-input.stdout.txt').read_text())"
assert p.count(marker) == 1
p = p.replace(marker, marker + "\n    assert run('copyall-input',[py,str(root/'derive_ctsm_qia_copyall_a.py'),str(inputs/'CN-Qia.datm.2003.nc'),str(base/'qia-stem-inputs-a/inputs')])==0\n    value['copyall_derivation']=json.loads((scratch/'copyall-input.stdout.txt').read_text())")
old = "met=[('TBOT','tbot'),('QBOT','shum'),('WIND','wind'),('PSRF','pbot'),('FSDS','swdn'),('SWDNDIR_COMMON','swdndr'),('SWDNDF_COMMON','swdndf'),('FLDS','lwdn'),('PRECTmms','precn'),('ZBOT','z'),('CO2_PPM_AUXILIARY','co2diag')]"
new = "met=[('TBOT','tbot'),('QBOT','shum'),('U_COPY','u'),('V_COPY','v'),('PTEM_COPY','ptem'),('DENS_COPY','dens'),('PSRF','pbot'),('PSLV_COPY','pslv'),('FLDS','lwdn'),('ZBOT','z'),('CO2_PPM_AUXILIARY','co2diag')]+[(name+'_COPY',name.lower()) for name in ['SWNDR','SWVDR','SWNDF','SWVDF','RAINC','RAINL','SNOWC','SNOWL']]"
assert p.count(old) == 1
p = p.replace(old, new)
assert p.count("datamode='CLMNCEP'") == 1
p = p.replace("datamode='CLMNCEP'", "datamode='COPYALL'")
p = p.replace('audit_ctsm_qia_year_boundary_a.py', 'audit_ctsm_qia_year_boundary_o_a.py')
p = p.replace("            if model_code==0:\n                assert run", "            value['model_outputs']={q.relative_to(rundir).as_posix():dict(bytes=q.stat().st_size,sha256=sha(q)) for q in rundir.iterdir() if q.is_file() and (q.suffix=='.nc' or '.log.' in q.name)}\n            if model_code==0:\n                assert run")
ast.parse(p)
(r / 'run_ctsm_qia_o.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_n.pbs').read_text().replace('ctsm-qia-run-n', 'ctsm-qia-run-o').replace('run_ctsm_qia_n.py', 'run_ctsm_qia_o.py').replace('clm-qia-official-n', 'clm-qia-official-o')
(r / 'ctsm_qia_run_o.pbs').write_bytes(p.encode())
p = (r / 'audit_ctsm_qia_year_boundary_c.py').read_text()
marker = 'assert common and all(prefix_exact.values())'
assert p.count(marker) == 1
p = p.replace(marker, "assert common\nprefix_errors = {n: float(np.max(abs(fields[n][:48].astype(float) - zprefix[n].astype(float)))) for n in common}".replace('zprefix', 'prefix_values'))
# Retain extracted prefix values after closing its archive, for raw diagnostics.
p = p.replace("    common = sorted(set(fields).intersection(z.files))", "    common = sorted(set(fields).intersection(z.files))\n    prefix_values = {n: np.asarray(z[n]) for n in common}")
p = p.replace('first48_M_physical_arrays_byte_value_equal=prefix_exact,', 'first48_M_physical_arrays_byte_value_equal=prefix_exact, first48_M_max_absolute_difference=prefix_errors,')
ast.parse(p)
(r / 'audit_ctsm_qia_year_boundary_o_a.py').write_bytes(p.encode())
(r / 'ctsm-qia-run-o-control.json').write_text(json.dumps(dict(scope='N to O changes only generated standard DATM datamode/explicit additional input serialization, original qair bypasses cap, full17520 original interval experiment. Same upstream2930 source,soil/cold state,SP,geometry,CO2/deposition. Prefix physical replay is reported rather than required bitwise because external forcing interface deliberately changed; original input/raw errors retained. No science acceptance.'), indent=2) + '\n')

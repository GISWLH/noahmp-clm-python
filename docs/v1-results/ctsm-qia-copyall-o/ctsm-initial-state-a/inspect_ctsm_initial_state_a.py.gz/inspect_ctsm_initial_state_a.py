from pathlib import Path
import hashlib
import json
import os
import re
import sys

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
workspace, root = map(Path, sys.argv[1:3])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files, arrays = [], {}
selected = re.compile(r'(?:t_soisno|t_veg|h2osoi|h2ocan|h2osno|snow|snl|frac_sno|int_snow|^dz$|^z$|^zi$|mcdate|mcsec|nstep|PCT_SAND|PCT_CLAY|ORGANIC|FMAX|PCT_NAT_PFT|MONTHLY_LAI|MONTHLY_SAI)', re.I)
for p in sorted(workspace.rglob('*.nc')):
    with Dataset(p) as d:
        index = len(files)
        row = dict(file=p.relative_to(workspace).as_posix(), sha256=sha(p), dimensions={n: len(v) for n, v in d.dimensions.items()}, variables={n: dict(dimensions=v.dimensions, units=getattr(v, 'units', None), long_name=getattr(v, 'long_name', None), dtype=str(v.dtype)) for n, v in d.variables.items()}, selected={})
        for name, v in d.variables.items():
            if not selected.search(name):
                continue
            a = np.ma.asarray(v[:])
            if a.size > 2048:
                continue
            raw, mask = np.asarray(np.ma.getdata(a)), np.ma.getmaskarray(a)
            arrays[f'f{index}_{name}'] = raw
            arrays[f'f{index}_{name}_mask'] = mask
            valid = raw[~mask]
            row['selected'][name] = dict(shape=raw.shape, masked=int(mask.sum()), minimum=float(valid.min()) if valid.size else None, maximum=float(valid.max()) if valid.size else None,
                                         values=np.where(mask, None, raw).tolist(), array_key=f'f{index}_{name}')
        files.append(row)
np.savez_compressed(root / 'selected-initial-state.npz', **arrays)
record = dict(scope='Read-only actual official N end-year restart/static-input inventory on EHPC PBS, not an original cold initial state or a generated common seed. Selected raw arrays retain masks separately. Native target cold temperature278.722K/water0.28/LAI3/SAI0.549363 are predeclared,not score-fitted. No state/source changes or scientific acceptance.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, files=files, selected_fields_sha256=sha(root / 'selected-initial-state.npz'))
(root / 'inventory.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps([dict(file=f['file'], dimensions=f['dimensions'], selected=list(f['selected'])) for f in files]), flush=True)

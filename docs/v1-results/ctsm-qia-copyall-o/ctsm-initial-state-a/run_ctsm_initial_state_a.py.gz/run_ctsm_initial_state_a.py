from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile
import time

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-initial-state-a'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
prefix, workspace = scratch / 'toolchain', scratch / 'workspace'
prefix.mkdir()
workspace.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start = time.monotonic()
private = b / 'ctsm-qia-run-n/case-configuration-private.tar.gz'
assert sha(private) == 'ece99750873614fa682add584574d00c0e1d9fdbf12708e913a825efe57c2a0d'
a = b / 'ctsm-portable-env-b.tar.gz'
assert sha(a) == '6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(a) as t:
    t.extractall(prefix, filter='data')
with tarfile.open(private) as t:
    members = [m for m in t if m.isfile() and ('.clm2.r.' in m.name and m.name.endswith('.nc') or m.name == 'inputdata/surfdata.CN-Qia.engineering.nc')]
    assert len(members) == 2
    t.extractall(workspace, members=members, filter='data')
env = os.environ.copy()
env.pop('PYTHONPATH', None)
env.update(PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
stages = []
for name, command in [('relocate', [str(prefix / 'bin/python'), str(prefix / 'bin/conda-unpack')]), ('inventory', [str(prefix / 'bin/python'), str(r / 'inspect_ctsm_initial_state_a.py'), str(workspace), str(r)])]:
    p = subprocess.run(command, cwd=scratch, env=env, capture_output=True, text=True, timeout=180)
    (r / (name + '.stdout.txt')).write_text(p.stdout)
    (r / (name + '.stderr.txt')).write_text(p.stderr)
    stages.append(dict(stage=name, returncode=p.returncode))
    assert p.returncode == 0, p.stderr
receipt = dict(scope='Actual official N unchanged end-year restart and original point-surface inventory only, no common initial seed made and no model/science pass.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, original_private_sha256=sha(private), seconds=time.monotonic() - start, stages=stages, inventory_sha256=sha(r / 'inventory.json'), selected_arrays_sha256=sha(r / 'selected-initial-state.npz'))
(r / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)

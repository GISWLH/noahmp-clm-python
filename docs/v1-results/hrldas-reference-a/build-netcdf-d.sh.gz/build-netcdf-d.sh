#!/bin/bash
set -euo pipefail
cd /home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016
test ! -d netcdf-build-d
mkdir netcdf-build-d netcdf-c-link
ln -s /home/lhwang/anaconda3/lib/libnetcdf.so.19 netcdf-c-link/libnetcdf.so
tar -xzf netcdf-fortran-4.6.1.tar.gz --strip-components=1 -C netcdf-build-d
cd netcdf-build-d
# Expose only netCDF-C to the linker. The shared conda lib directory contains
# an unversioned libgfortran.so -> libgfortran.so.4 from another compiler ABI.
env -u LD_LIBRARY_PATH PATH=/usr/bin:/bin:/home/lhwang/anaconda3/bin \
  CC=/usr/bin/gcc FC=/usr/bin/gfortran F77=/usr/bin/gfortran \
  CPPFLAGS=-I/home/lhwang/anaconda3/include \
  LDFLAGS='-L/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016/netcdf-c-link -Wl,-rpath,/home/lhwang/anaconda3/lib' \
  ./configure --prefix=/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016/netcdf-fortran \
  --disable-shared --enable-static
make -j2
env -u LD_LIBRARY_PATH make check -j2
make install
ldd examples/F90/simple_xy_rd

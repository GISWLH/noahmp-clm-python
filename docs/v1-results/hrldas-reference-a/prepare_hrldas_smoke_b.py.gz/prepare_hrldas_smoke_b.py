"""Prepare an isolated, one-day upstream Bondville execution smoke test."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import os

base = Path('/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016')
up = base / 'upstream/hrldas'
example = up / 'HRLDAS_forcing/run/examples/single_point'
run = base / 'bondville-smoke-b'
run.mkdir(exist_ok=False)
forcing = run / 'forcing'
forcing.mkdir()
(run / 'output').mkdir()
original = (example / 'bondville.dat').read_bytes()
lines = original.decode().splitlines(keepends=True)
first = next(i for i, line in enumerate(lines) if re.match(r'^1998\s', line))
assert first == 54, first
subset = ''.join(lines[:first + 97]).encode()
(forcing / 'bondville.dat').write_bytes(subset)
nml = (up / 'run/examples/single_point/namelist.hrldas.single_point').read_text()
nml = nml.replace('../HRLDAS_forcing/run/examples/single_point/hrldas_setup_single_point.nc', str(forcing / 'hrldas_setup_single_point.nc'))
nml = nml.replace('../HRLDAS_forcing/run/examples/single_point/', str(forcing) + '/')
nml = nml.replace('OUTDIR = "./"', 'OUTDIR = "' + str(run / 'output') + '/"')
nml = nml.replace('START_DAY   = 01', 'START_DAY   = 02').replace('KDAY = 365', 'KDAY = 1')
(run / 'namelist.hrldas').write_text(nml)
links = {}
for source in (up / 'run').iterdir():
    if source.suffix == '.TBL' or source.name.startswith('snicar_'):
        # These seven upstream git mode-120000 entries are materialized as
        # short path text by the Windows checkout. Resolve into this run only;
        # preserve the exact source snapshot and failed A run.
        assert source.stat().st_size < 256, source
        target = (source.parent / source.read_text().strip()).resolve()
        assert target.is_relative_to(base / 'upstream') and target.is_file(), target
        (run / source.name).symlink_to(target)
        links[source.name] = {'git_link_text': source.read_text().strip(),
                              'target_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
(run / 'hrldas.exe').symlink_to(up / 'run/hrldas.exe')
env = dict(os.environ)
env.pop('LD_LIBRARY_PATH', None)
with (run / 'generator.log').open('wb') as log:
    subprocess.run([str(example / 'create_point_data.exe')], cwd=forcing, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
manifest = {
    'purpose': 'Official upstream binary/input/output smoke; not station comparison or science acceptance',
    'original_input_sha256': hashlib.sha256(original).hexdigest(),
    'subset_input_sha256': hashlib.sha256(subset).hexdigest(),
    'forcing_records': 97, 'start': '1998-01-02T00:00:00', 'days': 1,
    'namelist_sha256': hashlib.sha256(nml.encode()).hexdigest(),
    'input_changes': 'First 97 original forcing rows, unmodified values; namelist paths/start day/run length only',
    'resolved_upstream_git_symlinks': links,
    'soil_liquid_note': 'Generator allocates soil_liquid but never writes or uses it; setup carries only total SMOIS, and official driver initializes liquid partition',
}
(run / 'setup-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest), flush=True)
with (run / 'hrldas.log').open('wb') as log:
    result = subprocess.run([str(run / 'hrldas.exe')], cwd=run, env=env, stdout=log, stderr=subprocess.STDOUT)
print(json.dumps({'process_returncode': result.returncode}), flush=True)
raise SystemExit(result.returncode)

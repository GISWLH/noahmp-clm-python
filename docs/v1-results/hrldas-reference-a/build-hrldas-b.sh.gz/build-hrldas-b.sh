#!/bin/bash
set -euo pipefail
cd /home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016
test -f netcdf-fortran/include/netcdf.mod
test -f netcdf-fortran/lib/libnetcdff.a
cd upstream
/home/lhwang/venvs/noahmp-phase3b/bin/python ../../verify_frozen_manifest.py
# This generated configuration belongs to this isolated reference build.
cat > hrldas/user_build_options <<'EOF'
COMPILERF90 = /usr/bin/gfortran
FREESOURCE = -ffree-form -ffree-line-length-none
F90FLAGS = -O2 -g -fconvert=big-endian -fbounds-check -fno-range-check -fallow-argument-mismatch
MODFLAG = -I
LDFLAGS =
CPP = /usr/bin/cpp
CPPFLAGS = -P -traditional -D_GFORTRAN_
LIBS =
LIBJASPER =
INCJASPER =
NETCDFMOD = -I/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016/netcdf-fortran/include -I/home/lhwang/anaconda3/include
NETCDFLIB = -L/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016/netcdf-fortran/lib -lnetcdff -L/home/lhwang/work/noahmp-v1/p6-hrldas-reference-20261016/netcdf-c-link -lnetcdf -Wl,-rpath,/home/lhwang/anaconda3/lib
BZIP2 = NO
RM = rm -f
CC = /usr/bin/gcc
EOF
for directory in hrldas/Utility_routines noahmp/utility noahmp/src noahmp/drivers/hrldas urban/wrf; do
    make -C "$directory" -j1
done
make -C hrldas/IO_code -j1 NoahMP MOD_OPT=-DNoahMP
make -C hrldas/run -j1 NoahMP
/home/lhwang/venvs/noahmp-phase3b/bin/python ../../verify_frozen_manifest.py
sha256sum hrldas/run/hrldas.exe hrldas/user_build_options
ldd hrldas/run/hrldas.exe

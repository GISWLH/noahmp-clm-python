"""Audit the unchanged complete four-site forcing/observation archive and splits."""
from pathlib import Path
from datetime import datetime, timedelta
import calendar
import hashlib
import json
import os
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multiyear-qc-inventory-hk'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner

inputs = Path(os.environ['TMPDIR']) / 'originals'
inputs.mkdir()
archive = base / 'multiyear-originals-fu.tar.gz'
assert sha(archive) == '6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c'
with tarfile.open(archive) as tf:
    tf.extractall(inputs, filter='data')
splits = {
    'CN-Cng': {2007: 'training', 2008: 'training', 2009: 'temporal-holdout', 2010: 'temporal-holdout'},
    'CN-Qia': {2003: 'training', 2004: 'training', 2005: 'temporal-holdout'},
    'CN-Cha': {2003: 'initialization-only', 2004: 'site-holdout', 2005: 'site-holdout'},
    'HaM': {year: 'independent-evaluation' for year in range(2008, 2015)},
}
products = ['H_F_MDS', 'LE_F_MDS', 'H_CORR', 'LE_CORR', 'GPP_NT_VUT_REF', 'GPP_DT_VUT_REF',
            'NEE_VUT_REF', 'TS_F_MDS_1', 'SWC_F_MDS_1']
begun = time.monotonic()
rows = []
identities = []
for site, years in splits.items():
    path = inputs / (site + '.npz')
    meta = json.loads((inputs / (site + '.json')).read_text())
    assert sha(path) == meta['prepared_npz_sha256']
    with np.load(path, allow_pickle=False) as z:
        data = dict(z)
    runner.validate_input(data, meta, path)
    times = np.asarray(data['time_start'], str)
    ends = np.asarray(data['time_end'], str)
    dt = float(data['forcing'][0, 0])
    assert dt in [1800., 3600.] and np.all(data['forcing'][:, 0] == dt)
    actual_years = sorted(set(int(t[:4]) for t in times))
    assert set(actual_years) == set(years), (site, actual_years)
    identities.append(dict(site=site, original_prepared_npz_sha256=sha(path),
        original_manifest_sha256=sha(inputs / (site + '.json')), original_metadata=meta,
        dt_seconds=dt, actual_years=actual_years))
    for year in actual_years:
        for month in range(1, 13):
            label = str(year) + str(month).zfill(2)
            chosen = np.flatnonzero(np.char.startswith(times, label))
            begin = datetime(year, month, 1)
            stop = begin + timedelta(days=calendar.monthrange(year, month)[1])
            expected = int((stop-begin).total_seconds()/dt)
            complete = len(chosen) == expected and str(times[chosen[0]]) == begin.strftime('%Y%m%d%H%M') and str(ends[chosen[-1]]) == stop.strftime('%Y%m%d%H%M')
            record = dict(site=site, year=year, month=month, locked_split=years[year],
                expected_intervals=expected, provided_intervals=len(chosen), calendar_month_complete=complete,
                dt_seconds=dt, products={})
            for field in products:
                observed_key = 'obs_' + field
                qc_field = {'H_CORR': 'H_F_MDS', 'LE_CORR': 'LE_F_MDS'}.get(field, field)
                qc_key = 'qc_' + qc_field
                partitioned = field.startswith('GPP_')
                if observed_key not in data:
                    record['products'][field] = dict(status='unmeasured', reason='Original prepared product unavailable')
                    continue
                values = np.asarray(data[observed_key], float)[chosen]
                qc = np.asarray(data.get(qc_key, np.full(len(times), np.nan)), float)[chosen]
                finite = np.isfinite(values)
                record['products'][field] = dict(finite_reference_intervals=int(finite.sum()),
                    missing_reference_intervals=int((~finite).sum()),
                    full_month_product_available=bool(complete and np.all(finite)),
                    own_qc_source=None if partitioned else qc_field + '_QC',
                    finite_own_qc0_intervals=None if partitioned else int(np.count_nonzero(finite & (qc == 0))),
                    finite_own_qc_nonzero_intervals=None if partitioned else int(np.count_nonzero(finite & np.isfinite(qc) & (qc != 0))),
                    finite_reference_without_qc_intervals=None if partitioned else int(np.count_nonzero(finite & ~np.isfinite(qc))),
                    qc0_with_missing_reference_intervals=None if partitioned else int(np.count_nonzero((~finite) & (qc == 0))),
                    reference_kind='Partitioned product, no independent QC supplied' if partitioned else
                        'Original prepared product; corrected flux uses underlying original raw-flux QC')
            rows.append(record)
        own = [row for row in rows if row['site'] == site and row['year'] == year]
        print(json.dumps(dict(site=site, year=year, split=years[year], months=len(own),
            H_QC0=[r['products']['H_F_MDS'].get('finite_own_qc0_intervals') for r in own],
            LE_QC0=[r['products']['LE_F_MDS'].get('finite_own_qc0_intervals') for r in own])), flush=True)
assert len(rows) == 204 and len(identities) == 4
for site, h, le in [('CN-Cng', 0, 0), ('CN-Cha', 1472, 1374)]:
    year = 2007 if site == 'CN-Cng' else 2003
    row = next(q for q in rows if q['site'] == site and q['year'] == year and q['month'] == 1)
    assert row['products']['H_F_MDS']['finite_own_qc0_intervals'] == h
    assert row['products']['LE_F_MDS']['finite_own_qc0_intervals'] == le
result = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True,
    source_manifest_sha256=source_sha, source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    original_archive_sha256=sha(archive), locked_splits=splits, site_identities=identities,
    site_years=17, site_months=204, products=products, months=rows, seconds=time.monotonic()-begun,
    scope='Unchanged original four-site prepared archive, every17 prespecifiedsite-year/204calendar months, raw/correctedHLE/partitionedGPPNTDT/NEE/soil QCavailability. Originalsplit/met/heights/depths/timestamps/QC/values untouched; no new mask, infill, modelstep/parameter fit, actualmultiyear simulation, independentET/runoff/SWE or scientific/spinup/holdout acceptance claim.')
(root / 'receipt.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
assert result['source_unchanged']

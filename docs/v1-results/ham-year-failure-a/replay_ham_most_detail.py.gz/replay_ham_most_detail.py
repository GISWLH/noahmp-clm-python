import json,pickle,traceback,time,sys
from pathlib import Path
import numpy as np
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
import noahmp_clm.physics.canopy_most as m
state,f,environment,geometry,co2,mu,diffuse=pickle.loads(Path(sys.argv[1]).read_bytes())
original=m.flux_stability;calls=[];started=time.monotonic()
def wrapped(*args,**kwargs):
    d=original(*args,**kwargs)
    calls.append(dict(iteration=len(calls)+1,h=args[4],water=args[5],ustar=args[6],**d))
    print(json.dumps(calls[-1]),flush=True)
    return d
m.flux_stability=wrapped
original_solve=m.solve_surface_most;surface_calls=[]
def wrapped_solve(solve_surface,*args,**kwargs):
    def traced(boundary):
        result=solve_surface(boundary)
        surface_calls.append({'boundary':vars(boundary),'diagnostics':result[-1]})
        return result
    return original_solve(traced,*args,**kwargs,max_iterations=6)
m.solve_surface_most=wrapped_solve
report={'scope':'Read-only exact failed-state replay; original iteration limit and criteria',
        'forcing':vars(f),'geometry':vars(geometry),'lai':state.lai,'calls':calls,'surface_calls':surface_calls}
try:
    new,d=step_clm_enthalpy_column(state,f,co2_ppm=co2,cosine_zenith=mu,diffuse_fraction=diffuse,
        phenology_environment=environment,most_geometry=geometry)
    report['status']='complete';report['most']=d['most']
except Exception:
    report['status']='failed';report['failure']=traceback.format_exc()
report['seconds']=time.monotonic()-started
from dataclasses import is_dataclass,asdict
def encode(v):
    if is_dataclass(v):return asdict(v)
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)
Path(sys.argv[2]).write_text(json.dumps(report,indent=2,default=encode)+'\n')
print(json.dumps({'status':report['status'],'seconds':report['seconds']}),flush=True)

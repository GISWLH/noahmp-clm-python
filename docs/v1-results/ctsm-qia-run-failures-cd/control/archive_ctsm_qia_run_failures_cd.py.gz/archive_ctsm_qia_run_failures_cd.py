from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'ctsm-qia-run-failures-cd-evidence.tar.gz';assert not a.exists();rows=[]
with tarfile.open(a,'w:gz') as t:
 for name in ['ctsm-qia-run-c','ctsm-qia-run-d']:
  r=b/name;d=json.loads((r/'configuration.json').read_text());assert d['upstream_original_bytes_unchanged'] and d['stages'][-1]['stage']=='preview-namelists' and d['stages'][-1]['returncode']==1 and (r/'pbs-exit.txt').read_text().strip()=='1'
  for p in sorted(r.iterdir()):
   if p.is_file() and p.name!='case-configuration-private.tar.gz':t.add(p,arcname=name+'/'+p.name,recursive=False)
  with tarfile.open(r/'case-configuration-private.tar.gz') as private:
   for member in private:
    if member.isfile() and (member.name.endswith(('.stdout.txt','.stderr.txt','-adaptation.json')) or member.name in ['case/user_nl_clm','case/user_nl_cpl','case/user_nl_datm']):
     data=private.extractfile(member).read();info=tarfile.TarInfo(name+'/workspace/'+member.name);info.size=len(data);t.addfile(info,io.BytesIO(data))
  rows.append(dict(name=name,pbs=d['pbs_job'],failure_stage='preview-namelists',returncode=1,upstream_original_bytes_unchanged=True,private_workspace_sha256=sha(r/'case-configuration-private.tar.gz')))
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 info=tarfile.TarInfo('summary.json');data=(json.dumps(dict(scope='Original official Qia case C unsupported non-FATES crop-landunit flag and D contradictory coldstart/finidat failures, both before model compilation/run; no official output or numerical pass.',cases=rows),indent=2)+'\n').encode();info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

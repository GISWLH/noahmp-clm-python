"""Fresh explicit-suction climate seeds and independent NumPy day on PBS.

No old checkpoint is reused; forcing, split, heights, water and physical
temperature seeds remain locked. Old enthalpy is provenance, not decoded.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time
import numpy as np
from run_fluxnet_column import build_state,totals
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-suction-coupled-d';parent=base/'fluxnet-first-climate-cycle-20261017-f'
root=base/'fluxnet-first-climate-cycle-20261017-h';inputs=root/'inputs';inputs.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
records=[];batch=[]
for site in ['CN-Cng','CN-Qia','CN-Cha','CN-HaM']:
    old=parent/'inputs'/(site+'-config.json');config=json.loads(old.read_text())
    p=config['column']['soil'];assert 'saturated_suction_m' not in p
    if site=='CN-HaM':
        assert p['smcmax']==.465 and p['bexp']==8.17
        psi=.263;basis='Confirmed official frozen NoahmpTable.TBL STAS9, not a fit to flux scores'
    else:psi=.355;basis='Nominal loam suction from confirmed official STAS6; other nominal soil parameters remain unchanged'
    p['saturated_suction_m']=psi
    config['case']=site+'-suction-climate-cycle'
    config['parent_configuration_sha256']=sha(old)
    config['physics_revision']=dict(law='CLM5Eq2.6.52 with explicit positive saturated suction head',saturated_suction_m=psi,basis=basis,
        old_checkpoints_reused=False,forcing_water_temperature_carbon_nitrogen_seed_policy_unchanged=True)
    config['scope']='Fresh first climate-year cold seed with explicit suction. Not spun up, calibrated, or accepted against observations.'
    for suffix in ['.npz','.json']:shutil.copyfile(parent/'inputs'/(site+suffix),inputs/(site+suffix))
    metadata=json.loads((inputs/(site+'.json')).read_text());assert sha(inputs/(site+'.npz'))==metadata['prepared_npz_sha256']
    state=build_state(config);old_report=parent/'numpy-day'/(site+'-initial-climate-cycle')/'report.json'
    prior=json.loads(old_report.read_text());old_ground=prior['initial_state']['ground']
    np.testing.assert_array_equal(state.ground.water,np.asarray(old_ground['water']))
    np.testing.assert_array_equal(state.ground.dz,np.asarray(old_ground['dz']))
    np.testing.assert_allclose(state.ground.temperature,config['column']['tsoil'],rtol=0.,atol=1e-9)
    cp=inputs/(site+'-config.json');cp.write_text(json.dumps(config,indent=2,allow_nan=False)+'\n')
    row=dict(case=config['case'],input=str(inputs/(site+'.npz')),input_manifest=str(inputs/(site+'.json')),configuration=str(cp));batch.append(row)
    records.append(dict(site=site,configuration_sha256=sha(cp),parent_configuration_sha256=sha(old),parent_report_sha256=sha(old_report),forcing_sha256=sha(inputs/(site+'.npz')),
        saturated_suction_m=psi,initial_tsoil_k=state.ground.temperature.tolist(),initial_water_kgm2=state.ground.water.tolist(),
        initial_liquid_m3m3=(state.ground.liquid/(1000*state.ground.dz)).tolist(),initial_soil_enthalpy_jm2=state.ground.enthalpy.tolist(),
        previous_soil_enthalpy_jm2=old_ground['enthalpy'],initial_m_h_c_n=totals(state).tolist()))
(root/'batch.json').write_text(json.dumps(dict(cases=batch),indent=2)+'\n')
(root/'protocol.json').write_text(json.dumps(dict(locked_utc=datetime.now(timezone.utc).isoformat(),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,
    scope='Four fresh full first-year inputs17520 each; this job produces a48-step independent NumPy prefix only. No old checkpoint migration or science acceptance.',
    source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),instrument_sha256=sha(Path(__file__)),cases=records),indent=2)+'\n')
jobs=[];begun=time.monotonic()
for row in batch:
    command=[sys.executable,'-u',str(source/'benchmarks/run_fluxnet_column.py'),'--input',row['input'],'--input-manifest',row['input_manifest'],'--config',row['configuration'],
        '--output',str(root/'numpy-day'/row['case']),'--stop-after','48']
    with (root/(row['case']+'.log')).open('w') as log:p=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
    jobs.append((p,row));print(json.dumps(dict(case=row['case'],pid=p.pid,command=command)),flush=True)
(root/'numpy-launch.json').write_text(json.dumps([dict(case=row['case'],pid=p.pid) for p,row in jobs],indent=2)+'\n')
codes=[]
for p,row in jobs:
    code=p.wait();codes.append(dict(case=row['case'],returncode=code));print(json.dumps(codes[-1]),flush=True)
assert all(sha(source/k)==v for k,v in manifest.items())
(root/'numpy-day-exit.json').write_text(json.dumps(dict(seconds=time.monotonic()-begun,source_unchanged=True,cases=codes),indent=2)+'\n')
assert all(row['returncode']==0 for row in codes)

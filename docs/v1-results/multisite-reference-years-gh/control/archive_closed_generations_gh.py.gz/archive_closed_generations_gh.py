"""Lossless closed-generation archival; never modify the active report/state."""
from pathlib import Path
import hashlib,io,json,os,re,tarfile

def archive_closed(trajectory,archive_path):
    trajectory=Path(trajectory).resolve(strict=True);archive_path=Path(archive_path).resolve();assert trajectory.name=='trajectory' and archive_path.parent.name=='generations' and archive_path.parent.parent==trajectory.parent and archive_path.parent.is_dir() and not archive_path.exists() and not archive_path.with_suffix(archive_path.suffix+'.partial').exists();sha=lambda raw:hashlib.sha256(raw).hexdigest();report_path=trajectory/'report.json';raw_report=report_path.read_bytes();report=json.loads(raw_report);assert report['status'] in ['running','complete'] and 'failure' not in report;index=report['steps_completed'];protected={report['checkpoint_file'],report['model_npz']};assert all((trajectory/n).resolve().parent==trajectory and sha((trajectory/n).read_bytes())==report[h] for n,h in [(report['checkpoint_file'],'checkpoint_sha256'),(report['model_npz'],'model_npz_sha256')]);selected=[]
    for p in sorted(trajectory.iterdir()):
        match=re.fullmatch(r'(?:state-([0-9]{7})\.pkl|trace-([0-9]{7})\.npz)',p.name)
        if not match or p.name in protected:continue
        generation=int(match[1] or match[2]);assert p.is_file() and not p.is_symlink() and p.resolve().parent==trajectory and generation<index;selected.append(dict(name=p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size,generation=generation))
    assert selected,'Expected actual closed generation(s), no empty archival claim';inventory=dict(active_report_sha256=sha(raw_report),active_index=index,protected=sorted(protected),members=selected,scope='ExactclosedNumPy state/tracegenerations, everymemberreadbackSHAverified beforeunlink. Activepointer/checkpoint/trace retained; source/forcing/config/physics/cumulativeledgers unchanged. Restorablearchive, never claimedasmodel/sciencepass.');manifest=(json.dumps(inventory,indent=2)+'\n').encode();temporary=archive_path.with_suffix(archive_path.suffix+'.partial')
    with tarfile.open(temporary,'w:gz') as t:
        for row in selected:t.add(trajectory/row['name'],arcname=row['name'],recursive=False)
        info=tarfile.TarInfo('ARCHIVE_MANIFEST.json');info.size=len(manifest);t.addfile(info,io.BytesIO(manifest))
    with tarfile.open(temporary) as t:
        names=t.getnames();assert len(names)==len(set(names))==len(selected)+1 and set(names)=={row['name'] for row in selected}|{'ARCHIVE_MANIFEST.json'} and t.extractfile('ARCHIVE_MANIFEST.json').read()==manifest
        for row in selected:assert sha(t.extractfile(row['name']).read())==row['sha256']
    # Resolve and verify every literal target before unlink. This helper is used
    # only after a segment has returned; no active model writer shares the folder.
    assert report_path.read_bytes()==raw_report
    for row in selected:
        target=trajectory/row['name'];assert target.resolve(strict=True).parent==trajectory and target.name not in protected and sha(target.read_bytes())==row['sha256']
    with temporary.open('rb') as stream:os.fsync(stream.fileno())
    os.replace(temporary,archive_path);archive_hash=sha(archive_path.read_bytes())
    for row in selected:(trajectory/row['name']).unlink()
    assert report_path.read_bytes()==raw_report and all(sha((trajectory/n).read_bytes())==report[h] for n,h in [(report['checkpoint_file'],'checkpoint_sha256'),(report['model_npz'],'model_npz_sha256')]);return dict(archive=archive_path.name,sha256=archive_hash,bytes=archive_path.stat().st_size,manifest_sha256=sha(manifest),closed_files_verified_and_archived=len(selected),active_generation_retained=index,active_report_sha256=sha(raw_report))

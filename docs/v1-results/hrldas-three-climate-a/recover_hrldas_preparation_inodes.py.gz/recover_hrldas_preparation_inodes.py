"""Preserve and compact only this task's newly generated, failed forcing files."""
from pathlib import Path
import hashlib,json,re,shutil,tarfile
base=Path('/home/zhangyq/noahmp-v1').resolve()
root=base/'hrldas-three-climate-a';forcing=root/'CN-Qia/forcing'
assert root.resolve()==Path('/home/zhangyq/noahmp-v1/hrldas-three-climate-a')
assert forcing.resolve()==root/'CN-Qia/forcing'
assert not (root/'protocol.json').exists() and not list((root/'CN-Qia/output').iterdir())
log=base/'hrldas-three-climate-a-prepare.log'
assert 'No space left on device' in log.read_text() and 'clone_nc' in log.read_text()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted(p for p in forcing.iterdir() if re.fullmatch(r'\d{12}\.LDASIN_DOMAIN1',p.name))
assert len(paths)>8000 and all(p.parent.resolve()==forcing and p.is_file() and not p.is_symlink() for p in paths)
hashes={p.relative_to(base).as_posix():sha(p) for p in paths}
temporary=Path('/tmp/noahmp-hrldas-three-climate-a-failed-preparation.tar.gz')
assert not temporary.exists()
with tarfile.open(temporary,'w:gz') as t:
    t.add(root,arcname=root.name,recursive=True)
    t.add(log,arcname=log.name)
    for p in base.glob('clm-hrldas-3yr.o36*'):t.add(p,arcname=p.name)
with tarfile.open(temporary) as t:
    for name,value in hashes.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==value
# Every selected regular forcing file is now recoverable byte-for-byte in the
# verified archive on a different filesystem. Leave setup, tables and logs alone.
for p in paths:
    assert p.parent.resolve()==forcing and sha(p)==hashes[p.relative_to(base).as_posix()]
    p.unlink()
target=base/temporary.name
assert not target.exists();shutil.copyfile(temporary,target);assert sha(target)==sha(temporary)
receipt=dict(scope='PBS36 failed during input IO, before any official physical integration; only newly generated forcing files compacted.',
    archived_inputs=len(paths),archive=str(target),archive_sha256=sha(target),
    removed_regular_files=hashes,setup_tables_logs_preserved=True)
(base/'hrldas-three-climate-a-inode-recovery.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='removed_regular_files'}))

"""Archive actual terminal NR evidence, original inputs and controls from /tmp."""
from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('/tmp/noahmp-climatology-final-cpu-nr')
label = 'climatology-final-cpu-nr'
launch = json.loads((root / 'manager/dispatch.json').read_text())
plan = json.loads((root / (label + '-plan.json')).read_text())
qstat = subprocess.check_output(['qstat', '-xf', launch['pbs_job']], text=True)
assert re.search(r'^\s*job_state = F\s*$', qstat, re.M), 'Need actual terminal PBS F'
actual = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
dest = root / 'compute-result'
assert not dest.exists()
subprocess.run(['scp', '-r', 'compute002:' + str(root / 'result'), str(dest)], check=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert int((dest / 'pbs-exit.txt').read_text()) == actual
receipt = json.loads((dest / 'receipt.json').read_text())
assert receipt['pbs_job'] == launch['pbs_job'] and receipt['node'] == 'compute002'
assert receipt['source_manifest_sha256'] == launch['source_manifest_sha256'] == plan['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert receipt['source_archive_sha256'] == plan['archive_sha256'] == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
assert receipt['source_unchanged'] and receipt['source_files'] == 584
assert sha((dest / 'SOURCE_SHA256.json').read_bytes()) == plan['source_manifest_sha256']
collected = json.loads((dest / 'nodes.json').read_text())
expected = set(plan['original_cpu_nodes']) | set(plan['expected_added_boundary_nodes'])
assert len(collected) == len(set(collected)) == len(expected) == 1168 and set(collected) == expected
proof = json.loads((dest / 'collection-proof.json').read_text())
assert proof['collection_actual_parent_returncode'] == 0 and proof['original1156_retained'] and proof['added12_only_soc_boundary']
assert set(proof['added_nodes']) == set(plan['expected_added_boundary_nodes'])
if receipt['passed']:
    assert actual == receipt['pytest_returncode'] == 0 and receipt['failure'] is None
    assert receipt['counts'] == dict(tests=1168, failures=0, errors=0, skipped=0)
    assert receipt['exact_executed_node_coverage']
    assert sha((dest / 'junit.xml').read_bytes()) == receipt['xml_sha256']
    nodes = []
    for case in ET.parse(dest / 'junit.xml').getroot().iter('testcase'):
        assert all(case.find(name) is None for name in ['failure', 'error', 'skipped'])
        parts = case.attrib['classname'].split('.')
        i, = [j for j, part in enumerate(parts) if part.startswith('test_')]
        nodes.append('/'.join(parts[:i+1]) + '.py::' + '::'.join(parts[i+1:] + [case.attrib['name']]))
    assert len(nodes) == len(set(nodes)) == 1168 and set(nodes) == expected
else:
    assert actual != 0
payload = {p.relative_to(dest).as_posix(): p.read_bytes() for p in dest.rglob('*') if p.is_file() and not p.is_symlink()}
payload['actual-qstat.txt'] = qstat.encode()
for name, digest in launch['controls_sha256'].items():
    raw = (root / name).read_bytes()
    assert sha(raw) == digest
    payload['control/' + name] = raw
assert sha((root / 'manager/job.pbs').read_bytes()) == launch['job_sha256']
for name in ['manager/job.pbs', 'manager/dispatch.json', 'dispatch_final_cpu_nr.py', 'prepare_final_cpu_nr.py', Path(__file__).name]:
    payload['control/' + name] = (root / name).read_bytes()
if (root / 'pbs-output.log').is_file():
    payload['control/pbs-output.log'] = (root / 'pbs-output.log').read_bytes()
inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = root / (label + '-evidence.tar.gz')
assert not target.exists()
with tarfile.open(target, 'w:gz') as tf:
    for name, raw in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tf.addfile(info, io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers()) == len(payload)
    assert all(tf.extractfile(m).read() == payload[m.name] for m in tf)
package = dict(archive=target.name, sha256=sha(target.read_bytes()), bytes=target.stat().st_size, artifacts=len(payload),
               pbs_job=launch['pbs_job'], actual_pbs_exit=actual, passed=receipt['passed'], seconds=receipt['seconds'],
               counts=receipt.get('counts'), source_manifest_sha256=receipt['source_manifest_sha256'],
               source_archive_sha256=receipt['source_archive_sha256'], scope=receipt['scope'])
(root / (label + '-package.json')).write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

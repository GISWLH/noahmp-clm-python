from pathlib import Path
import json
import numpy as np
from netCDF4 import Dataset
root=Path.cwd();lock=json.loads((root/'SOURCE_INPUT_LOCK.json').read_text());rows=[]
for record in lock['results']:
    path=root/'inputdata'/record['path']
    with Dataset(path) as d:
        row=dict(path=record['path'],dimensions={k:len(v) for k,v in d.dimensions.items()},variables={k:dict(dimensions=list(v.dimensions),dtype=str(v.dtype),units=getattr(v,'units',None)) for k,v in d.variables.items()})
        selected={}
        if 'surfdata_' in path.name or 'domain.lnd.' in path.name:
            for k in ['LATIXY','LONGXY','xc','yc','area','PCT_NATVEG','PCT_NAT_PFT','PCT_CROP','PCT_URBAN','PCT_SAND','PCT_CLAY','ORGANIC','MONTHLY_LAI','MONTHLY_SAI']:
                if k in d.variables:
                    a=np.ma.asarray(d.variables[k][:]);selected[k]=dict(shape=list(a.shape),values=a.filled(np.nan).tolist())
        row['selected_single_point_values']=selected;rows.append(row)
(root/'netcdf-inspection.json').write_text(json.dumps(dict(scope='Metadata and selected original single-point input values only, no climate forcing generation or physical model/scientific acceptance.',files=rows),indent=2)+'\n')
print(json.dumps(dict(files=len(rows),all_netcdf_opened=True)))

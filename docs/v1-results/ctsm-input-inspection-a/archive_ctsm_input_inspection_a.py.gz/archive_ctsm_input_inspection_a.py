from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-static-input-inspect-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'inspection.json').read_text());assert r['pbs_job']=='119.manager' and r['all_seven_hashes_unchanged'] and all(v['returncode']==0 for v in r['stages']) and (root/'pbs-exit.txt').read_text().strip()=='0'
inspection=json.loads((root/'netcdf-inspection.json').read_text());assert len(inspection['files'])==7
names=['inspect_ctsm_static_inputs_a.py','ctsm_static_input_inspect_a.pbs','inspection.json','inspection.log','netcdf-inspection.json','inspection-artifacts.tar.gz','node.txt','pbs-exit.txt'];pairs=[(root/n,n) for n in names]+[(Path(__file__),Path(__file__).name)];dest=base/'ctsm-input-inspection-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(path=str(dest),files=len(pairs),sha256=sha(dest),seconds=r['seconds'])))

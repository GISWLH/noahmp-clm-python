from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-static-input-inspect-a';scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-input-inspect';scratch.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic()
for archive,digest,dest in [(base/'ctsm-portable-env-b.tar.gz','6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20',scratch/'environment'),(base/'ctsm-static-inputs-a.tar.gz','c821ed102415bddacf0fd55f7cce4e914d57ca8d02e1284437d70bc3b4ee221d',scratch)]:
    assert sha(archive)==digest;dest.mkdir(exist_ok=True)
    with tarfile.open(archive) as t:t.extractall(dest,filter='data')
prefix=scratch/'environment';lock=json.loads((scratch/'SOURCE_INPUT_LOCK.json').read_text());assert len(lock['results'])==7 and all(sha(scratch/'inputdata'/v['path'])==v['sha256'] for v in lock['results'])
env=os.environ.copy()
for k in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(k,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
script='''from pathlib import Path
import json
import numpy as np
from netCDF4 import Dataset
root=Path.cwd();lock=json.loads((root/'SOURCE_INPUT_LOCK.json').read_text());rows=[]
for record in lock['results']:
    path=root/'inputdata'/record['path']
    with Dataset(path) as d:
        row=dict(path=record['path'],dimensions={k:len(v) for k,v in d.dimensions.items()},variables={k:dict(dimensions=list(v.dimensions),dtype=str(v.dtype),units=getattr(v,'units',None)) for k,v in d.variables.items()})
        selected={}
        if 'surfdata_' in path.name or 'domain.lnd.' in path.name:
            for k in ['LATIXY','LONGXY','xc','yc','area','PCT_NATVEG','PCT_NAT_PFT','PCT_CROP','PCT_URBAN','PCT_SAND','PCT_CLAY','ORGANIC','MONTHLY_LAI','MONTHLY_SAI']:
                if k in d.variables:
                    a=np.ma.asarray(d.variables[k][:]);selected[k]=dict(shape=list(a.shape),values=a.filled(np.nan).tolist())
        row['selected_single_point_values']=selected;rows.append(row)
(root/'netcdf-inspection.json').write_text(json.dumps(dict(scope='Metadata and selected original single-point input values only, no climate forcing generation or physical model/scientific acceptance.',files=rows),indent=2)+'\\n')
print(json.dumps(dict(files=len(rows),all_netcdf_opened=True)))
'''
(scratch/'inspect_netcdf.py').write_text(script);stages=[]
for stage,command in [('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]),('inspect-netcdf',[str(prefix/'bin/python'),str(scratch/'inspect_netcdf.py')])]:
    start=time.monotonic();p=subprocess.run(command,cwd=scratch,env=env,capture_output=True,text=True,timeout=180);(scratch/(stage+'.stdout.txt')).write_text(p.stdout);(scratch/(stage+'.stderr.txt')).write_text(p.stderr);stages.append(dict(stage=stage,returncode=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,p.stderr
value=dict(scope='Seven original static inputs only; not full official inputs or runnable/scientific reference.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,all_seven_hashes_unchanged=True,source_input_lock_sha256=sha(scratch/'SOURCE_INPUT_LOCK.json'),stages=stages,seconds=time.monotonic()-begun)
(root/'inspection.json').write_text(json.dumps(value,indent=2)+'\n');(root/'netcdf-inspection.json').write_bytes((scratch/'netcdf-inspection.json').read_bytes())
with tarfile.open(root/'inspection-artifacts.tar.gz','w:gz') as t:
    for p in sorted(scratch.iterdir()):
        if p.is_file():t.add(p,arcname=p.name,recursive=False)
print(json.dumps(value),flush=True)

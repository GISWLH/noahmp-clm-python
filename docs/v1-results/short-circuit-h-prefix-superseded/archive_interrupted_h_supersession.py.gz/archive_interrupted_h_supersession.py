"""Preserve native failed/KeyboardInterrupt report verbatim after deliberate stop.

The stop helper expected 'running', but the native runner catches BaseException
and commits 'failed' on SIGINT. Keep that actual status and its complete cause.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,sys,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-h';source=base/'p6-phase-jacobian-gpu-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stop=json.loads((root/'superseded-by-i.json').read_text());assert stop['stopped'] and not (Path('/proc')/str(stop['pid'])).exists()
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_native import read_generation
report,state,cases=read_generation(root/'cuda-day');assert report['status']=='failed' and report['failure'].rstrip().endswith('KeyboardInterrupt')
assert report['steps_requested']==17520 and 528<=report['steps_completed']<17520
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
audit=dict(utc=datetime.now(timezone.utc).isoformat(),source_unchanged=True,retained_steps=report['steps_completed'],native_status=report['status'],failure_kind='KeyboardInterrupt from explicit SIGINT supersession, not numerical acceptance failure',scope='Actual native failed report preserved unchanged. BaseException handler saved the last accepted generation on deliberate stop. Earlier archiver asserted running and failed before making archive; recovery only reads and verifies source/report/state/traces.',source_files=len(manifest),stop_receipt_sha256=sha(root/'superseded-by-i.json'))
(root/'supersession-archive-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
folder=root/'cuda-day';raw=(folder/'batch.json').read_bytes();assert json.loads(raw)==report
names=['superseded-by-i.json','supersession-archive-audit.json','cuda-annual-launch.json','cuda-annual-resume.log','batch.json','protocol.json']
pairs=[(root/k,k) for k in names]+[(source/'SOURCE_SHA256.json','SOURCE_SHA256.json'),(folder/report['checkpoint_file'],'cuda-day/'+report['checkpoint_file'])]
for name,descriptor in report['case_reports'].items():
    p=folder/name/descriptor['file'];r=json.loads(p.read_text())
    pairs.extend([(p,'cuda-day/'+name+'/'+p.name),(p.parent/r['model_npz'],'cuda-day/'+name+'/'+r['model_npz'])])
for name in ['supersede_h_after_validated_i.py','archive_interrupted_h_supersession.py']:pairs.append((base/name,name))
dest=base/'short-circuit-h-prefix-superseded-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    info=tarfile.TarInfo('cuda-day/batch.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(archive_sha256=sha(dest),files=len(pairs)+1,retained_steps=report['steps_completed'],native_status=report['status'],reason='Explicit supersession KeyboardInterrupt',maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'])))

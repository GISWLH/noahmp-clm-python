"""Stop only the obsolete self-owned H run after I has independent proof.

No frozen source or checkpoint is changed. Preserve its last committed prefix
with the original running/incomplete report and explicit replacement receipt.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,os,signal,sys,tarfile,time
base=Path('/home/lhwang/work/noahmp-v1');old=base/'fluxnet-first-climate-cycle-20261017-h';new=base/'fluxnet-first-climate-cycle-20261017-i'
source=base/'p6-phase-jacobian-gpu-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((new/'pre-change-h48-comparison.json').read_text());assert proof['bitwise_equal']
launch=json.loads((new/'cuda-annual-launch.json').read_text());assert launch['start_from_completed']==48 and launch['steps_requested']==17520
current_cmd=(Path('/proc')/str(launch['pid'])/'cmdline').read_bytes().replace(b'\x00',b' ').decode();assert str(new/'batch.json') in current_cmd and 'p6-phase-short-circuit-gpu-a' in current_cmd
legacy=json.loads((base/'p6-short-circuit-legacy-replay-a/cuda-replay.json').read_text());assert legacy['status']=='complete' and legacy['pre_change_baseline_bitwise_equal']
target=json.loads((base/'p6-phase-short-circuit-gpu-a/phase-target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=9,failures=0,errors=0,skipped=0)
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in m.items())
receipt=old/'superseded-by-i.json';assert not receipt.exists()
old_launch=json.loads((old/'cuda-annual-launch.json').read_text());pid=old_launch['pid'];proc=Path('/proc')/str(pid)
cmd=(proc/'cmdline').read_bytes().replace(b'\x00',b' ').decode()
assert str(source/'benchmarks/run_fluxnet_native.py') in cmd and str(old/'batch.json') in cmd and str(old/'cuda-day') in cmd
report=json.loads((old/'cuda-day/batch.json').read_text());assert report['status']=='running' and report['steps_requested']==17520
begun=datetime.now(timezone.utc).isoformat();os.kill(pid,signal.SIGINT)
def live():
    if not proc.exists():return False
    try:return (proc/'stat').read_text().split(') ',1)[1].split()[0]!='Z'
    except FileNotFoundError:return False
for _ in range(30):
    if not live():break
    time.sleep(.5)
stopped=not live()
data=dict(action='SIGINT obsolete self-owned H annual after current-source target9, I48+CUDA whole-step proof and own-state annual resume',utc=begun,pid=pid,verified_command=cmd,stopped=stopped,new_pid=launch['pid'],new_launch_sha256=sha(new/'cuda-annual-launch.json'),new_first48_comparison_sha256=sha(new/'pre-change-h48-comparison.json'),extra_jax_whole_step_status=launch['extra_jax_whole_step_status'],scope='H remains an incomplete historical prefix; extra JAX whole-step stays separately pending at launch. No report/source/state identity is rewritten and no scientific completion is claimed.')
receipt.write_text(json.dumps(data,indent=2)+'\n');assert stopped,'H did not stop; no further signal sent'
folder=old/'cuda-day';raw=(folder/'batch.json').read_bytes();report=json.loads(raw);assert report['status']=='running'
pairs=[(folder/report['checkpoint_file'],'cuda-day/'+report['checkpoint_file'])];assert sha(pairs[0][0])==report['checkpoint_sha256']
for case,descriptor in report['case_reports'].items():
    p=folder/case/descriptor['file'];assert p.parent==folder/case and sha(p)==descriptor['sha256']
    r=json.loads(p.read_text());trace=p.parent/r['model_npz'];assert trace.parent==p.parent and sha(trace)==r['model_npz_sha256']
    assert r['steps_completed']==report['steps_completed'] and r['batch_checkpoint_sha256']==report['checkpoint_sha256']
    pairs += [(p,'cuda-day/'+case+'/'+p.name),(trace,'cuda-day/'+case+'/'+trace.name)]
pairs += [(old/n,n) for n in ['superseded-by-i.json','cuda-annual-launch.json','cuda-annual-resume.log','batch.json','protocol.json']]
pairs.append((source/'SOURCE_SHA256.json','SOURCE_SHA256.json'))
archive=base/'short-circuit-h-prefix-superseded-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    info=tarfile.TarInfo('cuda-day/batch.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(stopped_pid=pid,retained_steps=report['steps_completed'],steps_requested=report['steps_requested'],original_status=report['status'],archive_sha256=sha(archive),files=len(pairs)+1)))

"""Metadata-only mechanical QJ-to-QS worker adaptation, no execution."""
import ast
import difflib
from pathlib import Path

from package_surface_reference_pt import files,sha

BASE=Path(__file__).resolve().parent


def main():
    raw=(BASE/'nq-transport-trace-qj-gpu-stage-b.tar.gz').read_bytes();assert sha(raw)=='e005dcb5ee418db9059a565bdc0da1b8b6b959dbc4ca701abd89a6dbfa4575e3'
    stage=files(raw);before=stage['preparation/capture_transport_trace_qj.py'].decode();after=before
    def change(old,new):
        nonlocal after
        assert after.count(old)==1,old[:90];after=after.replace(old,new)
    change('"""One original aggregate advance with transparent observed calls; GPU only."""','"""One original aggregate with copy-only pinned host-step trace; GPU only."""')
    change('import types\n','import types\n\nfrom hidden_step_observer_qs import StepObserver\n')
    after=after.replace('/tmp/nq-transport-trace-qj-','/tmp/nq-hidden-step-trace-qs-')
    change("assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='true'","assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='true'\n    assert not os.environ.get('XLA_FLAGS'),'Original default flags; no precision2 intervention'")
    change("raw_array_bytes=[0];limit_reached=[]","raw_array_bytes=[0];limit_reached=[];control=None")
    change("record=dict(reason=reason,events=sequence[0],raw_array_bytes=raw_array_bytes[0],max_events=MAX_EVENTS,max_raw_array_bytes=MAX_RAW_ARRAY_BYTES)","record=dict(reason=reason,events=sequence[0]+(control.events if control else 0),native_events=sequence[0],control_events=control.events if control else 0,raw_array_bytes=raw_array_bytes[0],max_events=MAX_EVENTS,max_raw_array_bytes=MAX_RAW_ARRAY_BYTES)")
    change("    def observe(module,name,kind):","    control=StepObserver(transport._one,a.source,a.output,snapshot,limit,lambda:sequence[0],MAX_EVENTS)\n    baseline=json.loads((HERE/'BASELINE_SCHEDULES.json').read_bytes())\n    baseline_schedule_exact=None\n    def observe(module,name,kind):")
    change("if sequence[0]>=MAX_EVENTS:limit('observed event hard cap')","if sequence[0]+control.events>=MAX_EVENTS:limit('combined native/control event hard cap')")
    change("original_raised=True;counts[kind]['actual_original_raised']+=1;event_log.write(json.dumps(dict(row,stage='original-raised',exception=traceback.format_exc()))+'\\n');event_log.flush();raise","if control.errors:\n                        counts[kind]['observer_aborted']=counts[kind].get('observer_aborted',0)+1\n                        event_log.write(json.dumps(dict(row,stage='observer-aborted',exception=traceback.format_exc()))+'\\n')\n                    else:\n                        original_raised=True;counts[kind]['actual_original_raised']+=1\n                        event_log.write(json.dumps(dict(row,stage='original-raised',exception=traceback.format_exc()))+'\\n')\n                    event_log.flush();raise")
    change("        model_calls['started']+=1\n        result=original_test.advance(arrays,inputs['forcing'][0],inputs['deposition'][0],'aggregate',a.backend+'32',inputs.get('geometry'))\n        sync();model_calls['returned']+=1", "        control.start()\n        try:\n            model_calls['started']+=1\n            result=original_test.advance(arrays,inputs['forcing'][0],inputs['deposition'][0],'aggregate',a.backend+'32',inputs.get('geometry'))\n            sync();model_calls['returned']+=1\n        finally:control.stop()")
    change("        assert counts['adapter']['actual_original_started']==counts['adapter']['actual_original_returned']==1 and model_calls==dict(started=1,returned=1)","        actual_schedule=[json.loads(line) for line in (a.output/'events.jsonl').read_text().splitlines()]\n        baseline_schedule_exact=actual_schedule==baseline['backend_native_event_rows'][a.backend]\n        assert baseline_schedule_exact,'Original native call/return schedule changed under tracing'\n        assert control.calls==control.returns==1 and control.events>0 and not control.active_frames and not control.errors and control.was_current_when_stopped,'Pinned code-object trace incomplete/nontransparent'\n        assert counts['adapter']['actual_original_started']==counts['adapter']['actual_original_returned']==1 and model_calls==dict(started=1,returned=1)")
    change("        tape.close();event_log.close();after_input=identities(inputs);save(a.output/'original-input-identities-after.json',after_input)","        control.stop();tape.close();event_log.close();after_input=identities(inputs);save(a.output/'original-input-identities-after.json',after_input)\n        control_receipt=control.receipt();save(a.output/'control-trace-receipt.json',control_receipt)")
    change("partial_nontransparent=bool(limit_reached)","partial_nontransparent=bool(limit_reached or control.errors or baseline_schedule_exact is not True)")
    change("all126_same_backend_byte_exact=not limit_reached and transparency is not None", "all126_same_backend_byte_exact=not limit_reached and not control.errors and baseline_schedule_exact is True and transparency is not None")
    change("scope='Transparent original aggregate0 once/backend only; no cause inferred or repair/acceptance claimed on GPU host. Full numerical/event/common-prefix/hard-ledger audit remains EHPC.'", "control_trace=control_receipt,combined_observer_events=sequence[0]+control.events,baseline_QJ_native_schedule_exact=baseline_schedule_exact,control_events_jsonl_sha256=sha((a.output/'control-events.jsonl').read_bytes()),default_XLA_FLAGS=os.environ.get('XLA_FLAGS'),scope='Copy-only original code-object locals trace plus unchanged native hooks once/backend. No new expression/model/phase/flow/reference evaluation, no arithmetic cause or repair inferred. Independent full numerical/common-prefix/hard-ledger analysis remains EHPC.'")
    change("assert source_exact and controls_exact and inputs_exact and not forbidden","assert source_exact and controls_exact and inputs_exact and not forbidden and not control.errors and baseline_schedule_exact is True")
    ast.parse(after);assert '\r' not in after
    (BASE/'capture_hidden_step_trace_qs.py').write_text(after,encoding='utf-8',newline='\n')
    (BASE/'nq-hidden-step-trace-qs-worker.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='actual-QJ-worker',tofile='QS-review-only-worker')),encoding='utf-8',newline='\n')
    print('QS worker prepared from actual frozen QJ bytes;0 execution')


if __name__=='__main__':main()

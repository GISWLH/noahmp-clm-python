"""Read-only metadata observation of the unique sequential QS capture."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
CODE="""import json
from pathlib import Path
r=Path('/home/lhwang/work/noahmp-v1/nq-hidden-step-trace-qs');tmp=Path('/tmp/nq-hidden-step-trace-qs-20261026');d={};pids=[925070]
for leaf,key in [('launch.json','launch'),('controller-progress.json','progress'),('controller-receipt.json','controller')]:
 p=r/leaf
 if p.exists():d[key]=json.loads(p.read_bytes())
for backend in ['cuda','jax']:
 o=tmp/backend;row={}
 for folder,leaf,key in [(o,'device-launch.json','launch'),(o,'device-parent-receipt.json','parent'),(o/'device','capture-receipt.json','capture'),(o/'device','control-trace-receipt.json','control')]:
  p=folder/leaf
  if p.exists():row[key]=json.loads(p.read_bytes())
 if 'launch' in row:
  pids.append(row['launch']['pid']);pids.append(int(row['launch']['proc_stat_at_launch'].split()[3]))
 for leaf,key in [('device.stdout.txt','stdout_tail'),('device.stderr.txt','stderr_tail')]:
  p=o/leaf
  if p.exists():row[key]=p.read_bytes()[-10000:].decode(errors='replace')
 d[backend]=row
d['proc_exists']={str(pid):(Path('/proc')/str(pid)).exists() for pid in pids}
print(json.dumps(d))
"""


def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);a=p.parse_args();stem=BASE/('nq-hidden-step-trace-qs-gpu-poll-'+str(a.index));assert not stem.with_suffix('.json').exists()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -c '+shlex.quote(CODE)]
    started=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=60)
    stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
    data=json.loads(r.stdout) if r.returncode==0 else None;record=dict(actual_exit=r.returncode,observed_UTC=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-started,read_only=True,snapshot=data)
    stem.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if data:
        summary=dict(actual_SSH_exit=0,proc_exists=data['proc_exists'],controller=data.get('controller'),backends={})
        for backend in ('cuda','jax'):
            row=data[backend];capture=row.get('capture',{});control=row.get('control',{})
            summary['backends'][backend]=dict(worker_PID=row.get('launch',{}).get('pid'),parent=row.get('parent'),all126_same_backend_byte_exact=capture.get('all126_same_backend_byte_exact'),baseline_native_schedule_exact=capture.get('baseline_QJ_native_schedule_exact'),aggregate_calls=capture.get('actual_aggregate_calls'),control_events=control.get('events'),one_calls=control.get('original_one_calls'),one_normal_returns=control.get('original_one_returns'),control_errors=control.get('observer_errors'),stderr_tail=row.get('stderr_tail'))
        print(json.dumps(summary))
    else:print(json.dumps(record))
    return r.returncode


if __name__=='__main__':raise SystemExit(main())

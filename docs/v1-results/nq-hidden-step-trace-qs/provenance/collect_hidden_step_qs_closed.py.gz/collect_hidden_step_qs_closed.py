"""Download the actual closed QS raw capture and whitelisted metadata only."""
import base64
import json
from pathlib import Path
import subprocess
import time

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
DEST=BASE/'nq-hidden-step-trace-qs-gpu-closed'
REMOTE='/home/lhwang/work/noahmp-v1/nq-hidden-step-trace-qs'
CODE=b"""import base64,hashlib,json
from pathlib import Path
r=Path('/home/lhwang/work/noahmp-v1/nq-hidden-step-trace-qs');s=Path('/tmp/nq-hidden-step-trace-qs-20261026/source');sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((r/'stage-inventory.json').read_bytes());actual={n:sha((r/n).read_bytes()) for n in index}
source=json.loads((s/'SOURCE_SHA256.json').read_bytes());source_actual={n:sha((s/n).read_bytes()) for n in source}
print(json.dumps(dict(files={n:base64.b64encode((r/n).read_bytes()).decode() for n in ['gpu-result-hash.json','controller-receipt.json','launch.json','controller.log']},stage_expected=index,stage_actual=actual,stage_exact=actual==index,source584_expected=source,source584_actual=source_actual,source584_exact=source_actual==source,proc_exists={str(pid):(Path('/proc')/str(pid)).exists() for pid in [925070,925071,925072,925259,925260]})))
"""


def run(label,command,data=None):
    started=time.monotonic();r=subprocess.run(command,input=data,capture_output=True,timeout=180)
    (DEST/(label+'.stdout')).write_bytes(r.stdout);(DEST/(label+'.stderr')).write_bytes(r.stderr)
    (DEST/(label+'.json')).write_bytes(encode(dict(actual_exit=r.returncode,seconds=time.monotonic()-started,command=command,stdin_sha256=sha(data) if data else None,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr))))
    assert r.returncode==0,(label,r.stderr.decode(errors='replace'));return r.stdout


def main():
    DEST.mkdir(exist_ok=False)
    run('raw-download',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang:'+REMOTE+'/gpu-result.tar.gz',str(DEST/'gpu-result.tar.gz')])
    raw_metadata=run('metadata-download',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -'],CODE)
    metadata=json.loads(raw_metadata);assert metadata['stage_exact'] and metadata['source584_exact'] and len(metadata['source584_expected'])==584 and not any(metadata['proc_exists'].values())
    for name,b in metadata['files'].items():(DEST/name).write_bytes(base64.b64decode(b))
    raw=(DEST/'gpu-result.tar.gz').read_bytes();expected=json.loads((DEST/'gpu-result-hash.json').read_bytes());assert sha(raw)==expected['sha256'] and len(raw)==expected['bytes']
    captured=files(raw);controller=json.loads(captured['controller/controller-receipt.json']);assert captured['controller/controller-receipt.json']==(DEST/'controller-receipt.json').read_bytes()
    assert controller['completed'] and controller['stage_unchanged'] and controller['error'] is None and controller['actual_controller_OS_returncode'] is None and [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0,0]
    summary=dict(actual_download_exit=0,raw_sha256=sha(raw),raw_bytes=len(raw),members=len(captured),actual_GPU_parent_exits=[0,0],actual_detached_controller_OS_exit=None,source584_exact=True,stage_exact=True,all_five_PIDs_absent=True,numerical_or_common_prefix_analysis_performed=False)
    (DEST/'collection.json').write_bytes(encode(summary));print(json.dumps(summary))


if __name__=='__main__':main()

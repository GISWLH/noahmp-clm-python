"""Prepare a release-only copy of the already reviewed metadata inventory."""
import ast
from pathlib import Path

BASE=Path(__file__).resolve().parent
source=(BASE/'check_hidden_step_qs_gpu_readonly.py').read_text()
source=source.replace('qs-gpu-preflight','qs-gpu-release').replace('old=[','old=[925070,925071,925072,925259,925260,',1)
old="assert int(record['query']['queries']['device']['stdout'].strip().split(',')[-1])>8192 and record['query']['host_MemAvailable_kib']>32*1024*1024"
assert source.count(old)==1
source=source.replace(old,'# Release checks termination only; external resource load is recorded and unchanged.')
ast.parse(source)
target=BASE/'check_hidden_step_qs_gpu_release_readonly.py';assert not target.exists()
target.write_text(source,encoding='utf-8',newline='\n')
print('QS release-only metadata script prepared;0 remote commands')

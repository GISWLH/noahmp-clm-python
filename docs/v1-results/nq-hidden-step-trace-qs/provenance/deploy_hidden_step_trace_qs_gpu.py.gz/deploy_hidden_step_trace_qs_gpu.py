"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'nq-hidden-step-trace-qs-gpu-stage.tar.gz'
expected='ecbc522b5c40d15ec857df06c0f9cbcd565c0ec6350d1ad50f34e75c7af19e22'
assert sha(stage.read_bytes())==expected
target=BASE/'nq-hidden-step-trace-qs-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'nq-hidden-step-trace-qs-execution/launch_device_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/nq-hidden-step-trace-qs && test ! -e /tmp/nq-hidden-step-trace-qs-20261026 && test ! -e /tmp/noahmp-nq-hidden-step-trace-qs-stage.tar.gz && test ! -e /tmp/launch_nq_hidden_step_trace_qs.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-nq-hidden-step-trace-qs-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_nq_hidden_step_trace_qs.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_nq_hidden_step_trace_qs.py --stage /tmp/noahmp-nq-hidden-step-trace-qs-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('nq-hidden-step-trace-qs-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('nq-hidden-step-trace-qs-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

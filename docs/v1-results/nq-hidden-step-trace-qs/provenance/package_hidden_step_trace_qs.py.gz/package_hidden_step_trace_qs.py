"""QS receipts/source/opaque arrays only; numerical control analysis is EHPC."""
import gzip
import io
import json
from pathlib import Path
import tarfile
import zipfile

from package_surface_reference_pt import files,sha,encode
from package_nm_richards_reference_qc import opaque_packet
from package_transport_trace_qj import npy_identity,opaque_arrays

BASE=Path(__file__).resolve().parent
LABEL='nq-hidden-step-trace-qs'


def main():
    closed=BASE/(LABEL+'-gpu-closed');raw=(closed/'gpu-result.tar.gz').read_bytes();stage_raw=(BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes()
    assert sha(raw)=='3919278110fe5764b9143d26abe20f4b6f0d0a1f6ca98371703b5dc95f56f20e' and sha(stage_raw)=='ecbc522b5c40d15ec857df06c0f9cbcd565c0ec6350d1ad50f34e75c7af19e22'
    stage=files(stage_raw);gpu=files(raw);index=json.loads(stage['stage-inventory.json']);assert len(stage)==20 and set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    source=files(stage['source.tar.gz']);manifest=json.loads(source['SOURCE_SHA256.json']);assert len(manifest)==584 and all(sha(source[n])==h for n,h in manifest.items())
    binding=json.loads(stage['preparation/BINDINGS.json']);nq=files(stage['nq-evidence.tar.gz']);original=nq[binding['actual_aggregate0_packet_path']]
    assert sha(source['SOURCE_SHA256.json'])==binding['source_manifest_sha256'] and sha(stage['nq-evidence.tar.gz'])==binding['original_NQ_archive_sha256'] and sha(original)==binding['actual_aggregate0_packet_sha256']
    baseline=json.loads(stage['preparation/BASELINE_SCHEDULES.json']);controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and controller['error'] is None and controller['actual_controller_OS_returncode'] is None and [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0,0]
    metadata=json.loads((closed/'metadata-download.stdout').read_bytes());assert metadata['source584_expected']==metadata['source584_actual']==manifest and metadata['stage_expected']==metadata['stage_actual']==index and not any(metadata['proc_exists'].values())
    with zipfile.ZipFile(io.BytesIO(original)) as z:gold={n:npy_identity(z.read(n)) for n in z.namelist()}
    counts={};fortran={};unwrapped={};captures={};controls={}
    for backend in ('cuda','jax'):
        prefix=backend+'/device/';receipt=json.loads(gpu[prefix+'capture-receipt.json']);control=json.loads(gpu[prefix+'control-trace-receipt.json']);captures[backend]=receipt;controls[backend]=control
        parent=json.loads(gpu[backend+'/device-parent-receipt.json']);assert parent['completed'] and parent['returncode']==0 and parent['error'] is None and gpu[backend+'/device-parent-exit.txt'].strip()==b'0'
        assert receipt['actual_aggregate_calls']==dict(started=1,returned=1) and receipt['source584_exact'] and receipt['controls_exact'] and receipt['inputs_unchanged'] and receipt['all126_same_backend_byte_exact'] and receipt['baseline_QJ_native_schedule_exact']
        assert receipt['default_XLA_FLAGS'] is None and not receipt['observation_limit_reached'] and not receipt['partial_nontransparent'] and not receipt['logging_errors'] and not receipt['original_observed_exceptions'] and not receipt['forbidden_attempts'] and receipt['extra_phase_or_reference_replays']==receipt['NumPy_physical_forward_calls']==0
        assert receipt['events']==11 and receipt['observer_limits']==dict(max_events=100000,max_raw_array_bytes=536870912) and 0<receipt['raw_array_payload_bytes']<536870912
        assert control==receipt['control_trace'] and control['events']==34 and control['original_one_calls']==control['original_one_returns']==1 and not control['active_original_frames'] and not control['observer_errors'] and not control['original_abnormal_exits'] and not control['original_exception_events']
        assert control['tracer_started'] and control['tracer_stopped'] and control['was_current_when_stopped'] and control['prior_tracer_was_none'] and receipt['combined_observer_events']==45
        native_rows=[json.loads(x) for x in gpu[prefix+'events.jsonl'].decode().splitlines()];assert native_rows==baseline['backend_native_event_rows'][backend] and sha(gpu[prefix+'events.jsonl'])==receipt['events_jsonl_sha256']
        control_rows=[json.loads(x) for x in gpu[prefix+'control-events.jsonl'].decode().splitlines()];assert len(control_rows)==34 and [x['sequence'] for x in control_rows]==list(range(1,35)) and sha(gpu[prefix+'control-events.jsonl'])==receipt['control_events_jsonl_sha256']
        assert json.loads(gpu[prefix+'original-input-identities-before.json'])==json.loads(gpu[prefix+'original-input-identities-after.json'])
        event_raw=gpu[prefix+'events.tar'];assert sha(event_raw)==receipt['events_tar_sha256'];events=files(event_raw)
        for name,b in events.items():
            unwrapped[backend+'/'+name]=b
            if not name.endswith('.json'):continue
            meta=json.loads(b);stem=name.removesuffix('.json');validated=opaque_packet(events[stem+'.npz'],meta);counts[backend+'/'+stem]=validated[0];fortran[backend+'/'+stem]=validated[1]
        final_raw=gpu[prefix+'complete-final126.npz'];final_meta=json.loads(gpu[prefix+'complete-final126.json']);assert opaque_arrays(final_raw,final_meta)==126
        with zipfile.ZipFile(io.BytesIO(final_raw)) as z:actual={n:npy_identity(z.read(n)) for n in z.namelist()}
        assert len(actual)==126 and all(v==gold[backend+'/'+n] for n,v in actual.items());counts[backend+'/complete-final126']=126
    release=json.loads((BASE/(LABEL+'-gpu-release.json')).read_bytes());assert release['actual_exit']==0 and not any(release['query']['old_proc_exists'].values())
    verification=dict(passed=True,scope='Stdlib archive/hash/metadata/opaque NPY validation only; no numeric array decode or common-prefix/control-value interpretation',stage_sha256=sha(stage_raw),raw_sha256=sha(raw),source584_exact=True,controls_exact=True,per_backend_aggregate_calls=1,per_backend_native_events=11,per_backend_control_events=34,per_backend_combined_events=45,actual_worker_and_parent_exits=[0,0],detached_controller_OS_exit=None,per_backend_final126_opaque_bytes_exact_to_original_NQ=True,per_backend_native_schedule_exact_to_actual_QJ=True,observer_errors=0,limits_unreached=True,opaque_packets=len(counts),opaque_arrays=sum(counts.values()),per_packet_arrays=counts,fortran_members={n:v for n,v in fortran.items() if v},extra_phase_or_reference_replays=0,NumPy_physical_forward_calls=0,GPU_release_verified=True,original1J_failure_retained=True,numerical_analysis_pending_EHPC=True)
    readout=dict(verification=verification,controller=controller,actual_capture_receipts=captures,actual_control_trace_receipts=controls,causal_conclusion=None,scope='Transparent actual copy-only capture. Existing locals require source-line/occurrence/native-event assignment age; presence alone is not a fresh value. Numerical/common-prefix/control and original hard-ledger interpretation remains a separate EHPC job.')
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification));(BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={'actual-gpu/'+n:b for n,b in gpu.items()};items.update({'opaque-unwrapped-events/'+n:b for n,b in unwrapped.items()});items.update({'executed-stage.tar.gz':stage_raw,'raw-gpu-result.tar.gz':raw,'readout.json':encode(readout),'verification.json':encode(verification)})
    for path in sorted(closed.iterdir()):
        if path.is_file() and path.name!='gpu-result.tar.gz':items['observations/closed/'+path.name]=path.read_bytes()
    for pattern in (LABEL+'-gpu-poll-*',LABEL+'-gpu-preflight*',LABEL+'-gpu-release*',LABEL+'-gpu-deploy-*'):
        for path in sorted(BASE.glob(pattern)):
            if path.is_file():items['observations/'+path.name]=path.read_bytes()
    for name in ('hidden_step_observer_qs.py','capture_hidden_step_trace_qs.py','create_hidden_step_worker_qs.py','prepare_hidden_step_trace_qs.py','deploy_hidden_step_trace_qs_gpu.py','check_hidden_step_qs_gpu_readonly.py','check_hidden_step_qs_gpu_release_readonly.py','prepare_qs_release_check.py','poll_hidden_step_qs_gpu.py','collect_hidden_step_qs_closed.py','package_hidden_step_trace_qs.py',LABEL+'-plan.md',LABEL+'-worker.diff',LABEL+'-original-exit.diff',LABEL+'-stage-package.json',LABEL+'-gpu-deployment.json','review_qs_observer_surface_lm.json'):
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['SCOPE.md']=b'''# QS actual transparent hidden-step capture

Actual unique sequential CUDA/JAX aggregate once each, original NM584/source/input unchanged. Actual worker/parent0/0 with no timeout, original11native-event22row schedules exact to QJ and complete126outputs byteexact to original NQ per backend. One original_one call/normal return and34control events each, observer errors0, limits unreached, tracer restored. Read-only source584/stage/PID closure separately verified. Five actual processes ended and project GPUfamily released; external Canglong/Down_GRACE/other-user loads were retained under explicit sharedGPU authorization, so duration is not a performance comparison.

Every explicit existing local snapshot, Python float hex, original source line/event/occurrence/native sequence and absent-local list is retained. No frame/arithmetic/input/source mutation, expression recomputation or extra phase/flow/reference/model call. Normal dict returns and abnormal None exits are separate; original exceptions and observer aborts are distinct. Old4f80unexecuted stage/controls remain locally preserved and were never executed; actual frozen stageecbc is sealed here.

This package only verifies opaque capture/provenance and does not infer the first hidden numerical divergence, instruction cause or repair. Presence of a local is not proof it was assigned this attempt: subsequent EHPC analysis must establish age from original line/occurrence/native-event sequence. Original1J/NQ9failed/scientific/year failures remain retained. Independent full-value/control/common-prefix and original aggregate hard-ledger analysis remains a separately reviewed EHPC task.
'''
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(label=LABEL,archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Actual copy-only QS capture0/0,126same-backend bytes/11native schedule exact,34control events each,0observer errors/no extra replay. GPUprojectfamily released; all numerical/age/common-prefix/hard-ledger interpretation awaits EHPC; original1J remains.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

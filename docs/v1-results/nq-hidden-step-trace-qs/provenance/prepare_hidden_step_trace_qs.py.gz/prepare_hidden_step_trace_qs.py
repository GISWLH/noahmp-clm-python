"""Freeze the root-reviewed QS plan/worker for static review only."""
import ast
import difflib
import gzip
import io
import json
from pathlib import Path
import tarfile

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
PREP=BASE/'nq-hidden-step-trace-qs-preparation'
NEW=BASE/'nq-hidden-step-trace-qs-execution'
OLD=BASE/'nq-transport-trace-qj-execution'


def main():
    qj_stage_raw=(BASE/'nq-transport-trace-qj-gpu-stage-b.tar.gz').read_bytes();assert sha(qj_stage_raw)=='e005dcb5ee418db9059a565bdc0da1b8b6b959dbc4ca701abd89a6dbfa4575e3'
    qj_stage=files(qj_stage_raw);qj_raw=(BASE/'nq-transport-trace-qj-gpu-closed/gpu-result.tar.gz').read_bytes();assert sha(qj_raw)=='f4fd3ea8a662f2ede58370b2c90cb5011690d87f50392841e7ae4da597f0fded';qj=files(qj_raw)
    source_raw=qj_stage['source.tar.gz'];source=files(source_raw);manifest=json.loads(source['SOURCE_SHA256.json'])
    assert sha(source_raw)=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d' and len(manifest)==584 and set(source)==set(manifest)|{'SOURCE_SHA256.json'} and all(sha(source[n])==h for n,h in manifest.items())
    target='src/noahmp_clm/gpu/richards_enthalpy.py';module=ast.parse(source[target]);function=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='_one');assert function.lineno==34
    helper=(BASE/'hidden_step_observer_qs.py').read_bytes();helper_ast=ast.parse(helper)
    selected=next(ast.literal_eval(n.value.args[0]) for n in helper_ast.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='SELECTED_LINES' for x in n.targets))
    assert all(34<=line<=function.end_lineno for line in selected)
    lines=source[target].decode().splitlines();source_lines={str(line):lines[line-1] for line in selected}
    schedules={};callcounts={}
    for backend in ('cuda','jax'):
        prefix=backend+'/device/';receipt=json.loads(qj[prefix+'capture-receipt.json']);assert receipt['source584_exact'] and receipt['controls_exact'] and receipt['all126_same_backend_byte_exact'] and receipt['actual_aggregate_calls']==dict(started=1,returned=1)
        schedules[backend]=[json.loads(line) for line in qj[prefix+'events.jsonl'].decode().splitlines()];assert len(schedules[backend])==22 and receipt['events']==11
        callcounts[backend]=receipt['observed_original_call_counts']
    baseline=dict(actual_QJ_raw_GPU_sha256=sha(qj_raw),actual_QJ_executed_stage_sha256=sha(qj_stage_raw),source_manifest_sha256=sha(source['SOURCE_SHA256.json']),backend_native_event_rows=schedules,backend_actual_call_counts=callcounts)
    binding=json.loads(qj_stage['preparation/BINDINGS.json']);binding.update(prepared_only=True,submitted=False,QJ_baseline_raw_GPU_sha256=sha(qj_raw),QJ_baseline_executed_stage_sha256=sha(qj_stage_raw),control_code_source_path=target,control_code_source_sha256=sha(source[target]),control_code_name='_one',control_code_first_line=34,selected_source_lines=list(selected),expected_actual_one_calls_per_backend=1,observer_max_combined_events=100000,observer_max_raw_array_bytes=512*1024*1024,default_XLA_FLAGS='unset',capture_scope='One original aggregate per backend; copy-only original _one frame locals, no new expression/primitive/reference solve',root_pre_execution_review_pending=True)
    PREP.mkdir(exist_ok=False);NEW.mkdir(exist_ok=False)
    for name in ('capture_hidden_step_trace_qs.py','hidden_step_observer_qs.py'):
        raw=(BASE/name).read_bytes();ast.parse(raw);assert b'\r' not in raw;(PREP/name).write_bytes(raw)
    contract=qj_stage['preparation/transport_contract_qj.py'];ast.parse(contract);(PREP/'hidden_step_contract_qs.py').write_bytes(contract)
    (PREP/'BINDINGS.json').write_bytes(encode(binding));(PREP/'BASELINE_SCHEDULES.json').write_bytes(encode(baseline));(PREP/'CONTROL_SOURCE_LINES.json').write_bytes(encode(dict(source_path=target,source_sha256=sha(source[target]),source_lines=source_lines,Python_line_event_semantics='Before the statement; following line observes a completed assignment.')))
    (PREP/'PLAN.md').write_bytes((BASE/'nq-hidden-step-trace-qs-plan.md').read_bytes());(PREP/'QJ_TO_QS_WORKER.diff').write_bytes((BASE/'nq-hidden-step-trace-qs-worker.diff').read_bytes())
    (PREP/'README.md').write_text('''# QS original aggregate hidden-step trace — prepared only

Root approved this plan for concrete preparation only. The actual frozen QJ worker/native hooks are mechanically reused, adding a copy-only Python tracer restricted by identity to the pinned original_one code object34 and explicit local/line allowlists. All source584 bytes, original NQ aggregate input and complete126 output gold remain unchanged. Source lines, exact actual QJ22-row/11-event native schedules per backend and full original call counts are sealed here. Default XLA flags are explicitly unset, preserving original f32 arithmetic; no precision2 or candidate geometry implementation is involved.

Observe existing device ratio/fraction/change and Python type/hex step/elapsed/duration before/after original min/reject/accept/grow statements, without evaluating another model expression or modifying a frame. Missing locals are explicit. The trace serializes each actual event into the same typed tar plus strict JSONL, and restores prior tracer in finally. Existing tracer, capture errors, incomplete original frame, changed original native schedule or any126byte difference cause a nontransparent failure. Original errors and observer-aborted calls remain separately classified. Combined native/control cap100000 and shared raw ndarray payload cap512MiB explicitly raise ObservationLimit and retain partial evidence; no event filtering by numeric value or silent omission.

Original adapter, phase, profile and flow functions execute only their original calls, original aggregate advance once/backend,0extra phase/flow/reference/model replay. Current original NumPy physical definitions and all actual already-imported aliases stay fail-only guarded. GPU host only transfers/encodes and compares opaque identity. Independent numerical/common-prefix/control and original hard-ledger analysis waits for a separately reviewed EHPC posthoc bound to actual capture hashes; no first arithmetic cause is assumed from earlier compiler evidence.

Lifecycle retains original CUDA1 physicalUUID,8GiB device/32GiB host startup gates, one thread/three private caches, sequential CUDA thenJAX,3600s/backend and no automatic retry. Do not run concurrently withPC-d or another task. Root must read this complete worker/helper/contract/controls and authorize unique deployment; this preparation does not launch, submit, compile, call a model/GPU or alter production/source/fixtures/tests. Original1J/NQ9failure/year/scientific limitations remain retained.
''',encoding='utf-8',newline='\n')
    controls={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir())};(PREP/'CONTROLS_SHA256.json').write_bytes(encode(controls))
    differences=[]
    for name in ('launch_device_pbs.py','control_device_pbs.py','run_device_parent_pbs.py'):
        before=(OLD/name).read_text();after=before
        if name=='run_device_parent_pbs.py':
            after=after.replace('from transport_contract_qj import','from hidden_step_contract_qs import').replace('/tmp/nq-transport-trace-qj-','/tmp/nq-hidden-step-trace-qs-').replace('capture_transport_trace_qj.py','capture_hidden_step_trace_qs.py')
            after=after.replace("env.pop('LD_LIBRARY_PATH',None)","env.pop('LD_LIBRARY_PATH',None);env.pop('XLA_FLAGS',None)")
        ast.parse(after);assert '\r' not in after;(NEW/name).write_text(after,encoding='utf-8',newline='\n');differences.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='QJ/'+name,tofile='QS/'+name))
    policy=json.loads((OLD/'EXECUTION_BINDINGS.json').read_bytes());policy.update(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),root='/home/lhwang/work/noahmp-v1/nq-hidden-step-trace-qs',temporary='/tmp/nq-hidden-step-trace-qs-20261026',change_scope='Copy-only original_one host-frame locals plus transparent actual QJ native hooks, once original aggregate/backend',prepared_only=True,root_pre_execution_review_pending=True,observer_max_events=100000,observer_max_raw_array_bytes=512*1024*1024,default_XLA_FLAGS='unset',actual_pinned_code_object='_one:34')
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(policy));(NEW/'QJ_TO_QS_LIFECYCLE.diff').write_text(''.join(differences),encoding='utf-8',newline='\n');(NEW/'README.md').write_text('Actual QJ/QF/PB-t original lifecycle reused on fresh QS paths. Original3600s/8GiB/32GiB/one-thread/privatecache/physicalCUDA1 gates, CUDA thenJAX, explicit original default XLAunset. Copy-only local tracing does not authorize any further solve. Prepared only; root code review/unique authorization and actual precedingGPU release required.\n',encoding='utf-8',newline='\n')
    execution={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir())};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(execution))
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()});items.update({'source.tar.gz':source_raw,'nq-evidence.tar.gz':qj_stage['nq-evidence.tar.gz']});items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/'nq-hidden-step-trace-qs-gpu-stage.tar.gz';assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(passed=True,stage_sha256=sha(target.read_bytes()),stage_files=len(items),preparation_controls=len(controls),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(execution),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),source584_original_NM_exact=True,actual_QJ_baseline_schedules_bound=True,pinned_original_code='_one:34',planned_original_aggregate_calls_per_backend=1,extra_phase_or_reference_replays=0,root_review_pending=True,launched=False,numerical_executed=False)
    (BASE/'nq-hidden-step-trace-qs-stage-package.json').write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

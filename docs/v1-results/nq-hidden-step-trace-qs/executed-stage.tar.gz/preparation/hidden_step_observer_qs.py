"""Copy-only tracing of one pinned original host _one code object."""
import json
from pathlib import Path
import sys
import traceback


SELECTED_LINES=frozenset((39,40,42,43,44,50,51,52,60,61,62,65,66,67,68,73,74,77,78))
LOCAL_NAMES=(
    'c','p','option','duration','ice_exponent','fraction_limit','temperature_limit','budget',
    'current','phase','accepted','rejected','hydraulic_steps','hydraulic_rejections',
    'elapsed','step','liquid','offset','profile','flow','f','r','net','z','outward','incoming',
    'available','ratio','fraction','specific','carried','water','enthalpy','candidate',
    'next_phase','change','max_temperature','max_fraction','max_hydraulic',
)


class StepObserver:
    def __init__(self,function,source,output,snapshot,limit,native_sequence,max_events):
        self.code=function.__code__;self.source=source.resolve()
        assert self.code.co_name=='_one' and self.code.co_firstlineno==34
        assert Path(self.code.co_filename).resolve()==self.source/'src/noahmp_clm/gpu/richards_enthalpy.py'
        self.source_lines=Path(self.code.co_filename).read_text().splitlines()
        self.snapshot=snapshot;self.limit=limit;self.native_sequence=native_sequence;self.max_events=max_events
        self.events=0;self.calls=0;self.returns=0;self.original_abnormal_exits=[];self.original_exception_events=[];self.errors=[];self.line_counts={};self.frame_ordinals={};self.active_frames=[]
        self.previous=None;self.started=False;self.stopped=False;self.was_current_when_stopped=None
        self.callback=self._trace
        self.log=(output/'control-events.jsonl').open('x',encoding='utf-8')
    def start(self):
        assert not self.started;self.previous=sys.gettrace()
        assert self.previous is None,'Existing tracer forbidden'
        sys.settrace(self.callback);self.started=True
    def stop(self):
        if not self.stopped:
            if self.started:
                self.was_current_when_stopped=sys.gettrace() is self.callback
                sys.settrace(self.previous)
            self.stopped=True;self.log.flush();self.log.close()
    def _trace(self,frame,event,argument):
        if frame.f_code is not self.code:return None
        if event not in ('call','line','return','exception'):return self.callback
        if event=='line' and frame.f_lineno not in SELECTED_LINES:return self.callback
        try:
            if self.events+self.native_sequence()>=self.max_events:self.limit('combined native/control event hard cap')
            self.events+=1;sequence=self.events;identity=id(frame)
            if event=='call':
                assert identity not in self.frame_ordinals;self.calls+=1;self.frame_ordinals[identity]=self.calls;self.active_frames.append(identity)
            assert identity in self.frame_ordinals and self.active_frames and self.active_frames[-1]==identity
            ordinal=self.frame_ordinals[identity];line=frame.f_lineno;key=str(line);self.line_counts[key]=self.line_counts.get(key,0)+1
            current=frame.f_locals
            # Only named existing locals are read. No branch expression, cast,
            # min/max, reciprocal or model function is re-evaluated here.
            present={name:current[name] for name in LOCAL_NAMES if name in current}
            absent=[name for name in LOCAL_NAMES if name not in current]
            row=dict(sequence=sequence,event=event,frame_ordinal=ordinal,source_line=line,
                     source_text=self.source_lines[line-1],line_occurrence=self.line_counts[key],
                     native_event_sequence=self.native_sequence(),present_local_names=list(present),absent_local_names=absent)
            if event=='return':
                # _one's sole normal return is a dict. Python also emits a
                # return(None) trace event when an original exception escapes.
                row['normal_original_return']=isinstance(argument,dict)
                if row['normal_original_return']:self.returns+=1
                else:self.original_abnormal_exits.append(dict(sequence=sequence,line=line,return_type=type(argument).__name__))
                present=dict(locals=present,original_return=argument)
            if event=='exception':
                kind,error,_=argument
                row['original_exception']=dict(type=kind.__module__+'.'+kind.__name__,message=str(error))
                self.original_exception_events.append(dict(sequence=sequence,**row['original_exception']))
            packet=self.snapshot('control/'+str(sequence).zfill(6),present)
            row['snapshot_array_count']=packet['array_count'];row['snapshot_npz_sha256']=packet['npz_sha256']
            self.log.write(json.dumps(row,allow_nan=False)+'\n');self.log.flush()
            if event=='return':assert self.active_frames.pop()==identity
        except BaseException:
            failure=dict(event=event,line=frame.f_lineno,control_events=self.events,native_events=self.native_sequence(),error=traceback.format_exc())
            self.errors.append(failure)
            self.log.write(json.dumps(dict(stage='observer-failure',**failure))+'\n');self.log.flush()
            raise
        return self.callback
    def receipt(self):
        return dict(events=self.events,original_one_calls=self.calls,original_one_returns=self.returns,
                    active_original_frames=len(self.active_frames),original_abnormal_exits=self.original_abnormal_exits,original_exception_events=self.original_exception_events,
                    observer_errors=self.errors,line_counts=self.line_counts,selected_lines=sorted(SELECTED_LINES),
                    named_local_allowlist=list(LOCAL_NAMES),tracer_started=self.started,tracer_stopped=self.stopped,
                    was_current_when_stopped=self.was_current_when_stopped,prior_tracer_was_none=self.previous is None,
                    original_code_name=self.code.co_name,original_code_first_line=self.code.co_firstlineno,
                    original_code_filename=self.code.co_filename,
                    mutation_or_extra_evaluation_policy='Only copy existing named frame locals/original return; no writes or new expression/model/primitive evaluation.')

"""One original aggregate with copy-only pinned host-step trace; GPU only."""
import argparse
from dataclasses import fields,is_dataclass
from enum import Enum
import hashlib
import importlib
import inspect
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
import traceback
import types

from hidden_step_observer_qs import StepObserver

HERE=Path(__file__).resolve().parent
GPU='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
MAX_EVENTS=100000
MAX_RAW_ARRAY_BYTES=512*1024*1024
class ObservationLimit(RuntimeError):
    """Abort rather than omit an original observation at the hard capture cap."""
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def main():
    parser=argparse.ArgumentParser()
    for n in ('source','nq','output'):parser.add_argument('--'+n,type=Path,required=True)
    parser.add_argument('--backend',choices=('cuda','jax'),required=True);a=parser.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='true'
    assert not os.environ.get('XLA_FLAGS'),'Original default flags; no precision2 intervention'
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    caches=[Path(os.environ[n]).resolve() for n in ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH')]
    assert len(set(caches))==3 and all(str(p).startswith('/tmp/nq-hidden-step-trace-qs-') for p in caches)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024,'Original8GiB GPU/32GiB host startup gate'
    assert not a.output.exists();a.output.mkdir()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());control_raw=(HERE/'CONTROLS_SHA256.json').read_bytes();control_index=json.loads(control_raw)
    assert all(sha((HERE/n).read_bytes())==h for n,h in control_index.items())
    manifest_raw=(a.source/'SOURCE_SHA256.json').read_bytes();manifest=json.loads(manifest_raw)
    assert len(manifest)==584 and sha(manifest_raw)==binding['source_manifest_sha256']
    def source_identity():return {n:sha((a.source/n).read_bytes()) for n in manifest}
    assert source_identity()==manifest
    nq_raw=a.nq.read_bytes();assert sha(nq_raw)==binding['original_NQ_archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(nq_raw)) as t:
        members=t.getmembers();assert len({m.name for m in members})==len(members) and all(m.isfile() for m in members)
        nq={m.name:t.extractfile(m).read() for m in members}
    index=json.loads(nq['artifact-inventory.json']);assert set(index)==set(nq)-{'artifact-inventory.json'} and all(sha(nq[n])==v['sha256'] and len(nq[n])==v['bytes'] for n,v in index.items())
    original_raw=nq[binding['actual_aggregate0_packet_path']];assert sha(original_raw)==binding['actual_aggregate0_packet_sha256']
    fixture_raw=(a.source/'tests/fixtures/clm_richards_reference.npz').read_bytes();assert sha(fixture_raw)==binding['original_fixture_sha256']
    sys.path[:0]=[str(a.source.resolve()/'src'),str(a.source.resolve()/'tests')]
    import numpy as np  # Original data decoding and output serialization only; no host physics/analysis.
    if a.backend=='cuda':
        import cupy as xp
        assert xp.cuda.runtime.getDeviceCount()==1;xp.cuda.Device(0).use();xp.cuda.runtime.free(0)
        def host(v):return xp.asnumpy(v) if isinstance(v,xp.ndarray) else np.asarray(v)
        sync=lambda:xp.cuda.get_current_stream().synchronize()
        version=xp.__version__
    else:
        import jax
        assert jax.__version__=='0.11.2';jax.config.update('jax_enable_x64',True)
        assert len(jax.devices())==1 and jax.devices()[0].platform=='gpu'
        import jax.numpy as xp
        def host(v):
            if hasattr(v,'block_until_ready'):v.block_until_ready()
            return np.asarray(v)
        sync=lambda:jax.effects_barrier();version=jax.__version__
    import test_gpu_clm_richards_column as original_test
    from noahmp_clm.gpu import clm_richards_column as adapter
    from noahmp_clm.gpu import richards_enthalpy as transport
    from noahmp_clm import clm_enthalpy_driver as cpu_driver
    from noahmp_clm.physics import richards as cpu_richards
    forbidden=[]
    def no_cpu(*args,**kwargs):forbidden.append('CPU physical forward reached');raise AssertionError(forbidden[-1])
    original_cpu_functions=(cpu_driver.step_clm_enthalpy_column,cpu_richards.redistribute_soil_enthalpy)
    disabled_cpu_aliases=[];original_test_named_alias_presence={}
    # Disable already imported copies, not just the defining module attributes.
    for module in list(sys.modules.values()):
        if not isinstance(module,types.ModuleType):continue
        filename=vars(module).get('__file__')
        if not isinstance(filename,str):continue
        try:in_source=Path(filename).resolve().is_relative_to(a.source.resolve())
        except (OSError,ValueError):continue
        if not in_source:continue
        for name,value in list(vars(module).items()):
            if any(value is original for original in original_cpu_functions):
                disabled_cpu_aliases.append(dict(module=module.__name__,name=name,original_module=getattr(value,'__module__',None),original_name=getattr(value,'__name__',None)))
                setattr(module,name,no_cpu)
    for name in ('reference','step_clm_enthalpy_column','redistribute_soil_enthalpy'):
        present=name in vars(original_test);original_test_named_alias_presence[name]=present
        if present and callable(vars(original_test)[name]):
            setattr(original_test,name,no_cpu)
            disabled_cpu_aliases.append(dict(module=original_test.__name__,name=name,explicit_original_test_alias=True))
    assert cpu_driver.step_clm_enthalpy_column is no_cpu and cpu_richards.redistribute_soil_enthalpy is no_cpu
    assert Path(original_test.advance.__code__.co_filename).resolve()==(a.source/'tests/test_gpu_clm_richards_column.py').resolve()
    with np.load(io.BytesIO(fixture_raw),allow_pickle=False) as z:
        inputs={n[len('32/1/'):]:z[n].copy() for n in z.files if n.startswith('32/1/') and '/expected/' not in n}
    def identities(values):return {n:dict(dtype=v.dtype.str,shape=list(v.shape),c_order_sha256=sha(v.tobytes(order='C'))) for n,v in values.items()}
    before_input=identities(inputs);save(a.output/'original-input-identities-before.json',before_input)
    arrays=tuple(inputs['initial/'+str(i)] for i in range(int(inputs['arrays'])))
    tape=tarfile.open(a.output/'events.tar',mode='w',format=tarfile.PAX_FORMAT)
    event_log=(a.output/'events.jsonl').open('x',encoding='utf-8');sequence=[0];stack=[];ordinal={};counts={};logging_errors=[];original_exceptions=[];raw_array_bytes=[0];limit_reached=[];control=None
    def limit(reason):
        record=dict(reason=reason,events=sequence[0]+(control.events if control else 0),native_events=sequence[0],control_events=control.events if control else 0,raw_array_bytes=raw_array_bytes[0],max_events=MAX_EVENTS,max_raw_array_bytes=MAX_RAW_ARRAY_BYTES)
        limit_reached.append(record);event_log.write(json.dumps(dict(stage='ObservationLimit',**record))+'\n');event_log.flush()
        raise ObservationLimit(json.dumps(record))
    def reserve_array(value):
        size=int(value.nbytes)
        if raw_array_bytes[0]+size>MAX_RAW_ARRAY_BYTES:limit('raw ndarray payload hard cap')
        raw_array_bytes[0]+=size
    def add(name,raw):
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;tape.addfile(info,io.BytesIO(raw))
    def snapshot(stem,value):
        stored={}
        def walk(v,key):
            if isinstance(v,(np.ndarray,np.generic,xp.ndarray)) or hasattr(v,'block_until_ready'):
                reserve_array(v)
                q=host(v);assert q.dtype.kind!='O';stored[key]=q
                return dict(kind='array',key=key,dtype=q.dtype.str,shape=list(q.shape),c_order_sha256=sha(q.tobytes(order='C')))
            if is_dataclass(v):return dict(kind='dataclass',module=type(v).__module__,name=type(v).__name__,fields={f.name:walk(getattr(v,f.name),key+'/'+f.name) for f in fields(v)})
            if isinstance(v,dict):
                assert all(type(n)is str for n in v);return dict(kind='dict',items={n:walk(x,key+'/'+n) for n,x in v.items()})
            if isinstance(v,(tuple,list)):return dict(kind=type(v).__name__,items=[walk(x,key+'/'+str(i)) for i,x in enumerate(v)])
            if isinstance(v,types.ModuleType):return dict(kind='module-context',name=v.__name__)
            if callable(v):return dict(kind='callable-context',module=getattr(v,'__module__',None),qualname=getattr(v,'__qualname__',None),file=getattr(getattr(v,'__code__',None),'co_filename',None))
            if isinstance(v,Enum):return dict(kind='enum',module=type(v).__module__,name=type(v).__name__,value=walk(v.value,key+'/value'))
            if type(v)is float:return dict(kind='float',hex=v.hex())
            if v is None or type(v)in(str,int,bool):return dict(kind=type(v).__name__,value=v)
            raise TypeError('Unsupported original trace value '+str(type(v)))
        tree=walk(value,'value');out=io.BytesIO();np.savez_compressed(out,**stored);raw=out.getvalue();add(stem+'.npz',raw)
        metadata=dict(tree=tree,array_count=len(stored),npz_sha256=sha(raw));add(stem+'.json',(json.dumps(metadata,indent=2,allow_nan=False)+'\n').encode());return metadata
    control=StepObserver(transport._one,a.source,a.output,snapshot,limit,lambda:sequence[0],MAX_EVENTS)
    baseline=json.loads((HERE/'BASELINE_SCHEDULES.json').read_bytes())
    baseline_schedule_exact=None
    def observe(module,name,kind):
        original=getattr(module,name);signature=inspect.signature(original);counts[kind]=dict(entered=0,actual_original_started=0,actual_original_returned=0,actual_original_raised=0)
        def wrapped(*args,**kwargs):
            if sequence[0]+control.events>=MAX_EVENTS:limit('combined native/control event hard cap')
            sequence[0]+=1;event=sequence[0];ordinal[kind]=ordinal.get(kind,0)+1;parent=stack[-1] if stack else None
            row=dict(sequence=event,parent=parent,kind=kind,ordinal=ordinal[kind],backend=a.backend);counts[kind]['entered']+=1;stack.append(event);original_raised=False
            try:
                actual=signature.bind(*args,**kwargs);actual.apply_defaults()
                snapshot('events/'+str(event).zfill(6)+'-input',dict(actual.arguments))
                event_log.write(json.dumps(dict(row,stage='enter'))+'\n');event_log.flush()
                counts[kind]['actual_original_started']+=1
                try:answer=original(*args,**kwargs)
                except BaseException:
                    if control.errors:
                        counts[kind]['observer_aborted']=counts[kind].get('observer_aborted',0)+1
                        event_log.write(json.dumps(dict(row,stage='observer-aborted',exception=traceback.format_exc()))+'\n')
                    else:
                        original_raised=True;counts[kind]['actual_original_raised']+=1
                        event_log.write(json.dumps(dict(row,stage='original-raised',exception=traceback.format_exc()))+'\n')
                    event_log.flush();raise
                counts[kind]['actual_original_returned']+=1;snapshot('events/'+str(event).zfill(6)+'-output',answer)
                event_log.write(json.dumps(dict(row,stage='return'))+'\n');event_log.flush();return answer
            except BaseException:
                (original_exceptions if original_raised else logging_errors).append(dict(sequence=event,exception=traceback.format_exc()));raise
            finally:assert stack.pop()==event
        setattr(module,name,wrapped)
    observe(adapter,'attach_column_richards','adapter')
    observe(transport,'_phase','phase')
    observe(transport,'_profile','profile')
    flow=importlib.import_module('noahmp_clm.gpu.'+('cuda.richards' if a.backend=='cuda' else 'richards'))
    observe(flow,'run_richards_'+a.backend,'redistribute')
    started=time.monotonic();model_calls=dict(started=0,returned=0);transparency=None
    try:
        snapshot('original-aggregate-call',dict(arrays=arrays,forcing=inputs['forcing'][0],deposition=inputs['deposition'][0],kind='aggregate',backend=a.backend+'32',geometry=inputs.get('geometry')))
        control.start()
        try:
            model_calls['started']+=1
            result=original_test.advance(arrays,inputs['forcing'][0],inputs['deposition'][0],'aggregate',a.backend+'32',inputs.get('geometry'))
            sync();model_calls['returned']+=1
        finally:control.stop()
        def flatten(v,prefix=''):
            for key,value in v.items():
                name=prefix+key
                if isinstance(value,dict):yield from flatten(value,name+'/')
                else:yield name,host(value)
        flattened=dict(flatten(result));assert len(flattened)==126
        for value in flattened.values():reserve_array(value)
        np.savez_compressed(a.output/'complete-final126.npz',**flattened);save(a.output/'complete-final126.json',dict(npz_sha256=sha((a.output/'complete-final126.npz').read_bytes()),arrays=identities(flattened)))
        with np.load(io.BytesIO(original_raw),allow_pickle=False) as z:original_fields={n[len(a.backend+'/'):]:z[n].copy() for n in z.files if n.startswith(a.backend+'/')}
        assert set(flattened)==set(original_fields)
        transparency={n:dict(dtype_shape_exact=v.dtype==original_fields[n].dtype and v.shape==original_fields[n].shape,opaque_C_bytes_exact=v.tobytes(order='C')==original_fields[n].tobytes(order='C')) for n,v in flattened.items()}
        save(a.output/'transparency.json',dict(original_fields=126,fields=transparency,all126_byte_exact=all(v['dtype_shape_exact'] and v['opaque_C_bytes_exact'] for v in transparency.values()),original_NQ_1J_same_precision_failure_retained=True))
        assert all(v['dtype_shape_exact'] and v['opaque_C_bytes_exact'] for v in transparency.values()),'Instrumentation was not byte-transparent; no causal conclusion'
        actual_schedule=[json.loads(line) for line in (a.output/'events.jsonl').read_text().splitlines()]
        baseline_schedule_exact=actual_schedule==baseline['backend_native_event_rows'][a.backend]
        assert baseline_schedule_exact,'Original native call/return schedule changed under tracing'
        assert control.calls==control.returns==1 and control.events>0 and not control.active_frames and not control.errors and control.was_current_when_stopped,'Pinned code-object trace incomplete/nontransparent'
        assert counts['adapter']['actual_original_started']==counts['adapter']['actual_original_returned']==1 and model_calls==dict(started=1,returned=1)
        assert all(v['actual_original_started']>0 for v in counts.values()) and not logging_errors,'Observation boundary missing or recorder failed'
    except BaseException:
        (a.output/'failure.txt').write_text(traceback.format_exc());raise
    finally:
        control.stop();tape.close();event_log.close();after_input=identities(inputs);save(a.output/'original-input-identities-after.json',after_input)
        control_receipt=control.receipt();save(a.output/'control-trace-receipt.json',control_receipt)
        source_exact=source_identity()==manifest;controls_exact=all(sha((HERE/n).read_bytes())==h for n,h in control_index.items());inputs_exact=before_input==after_input
        save(a.output/'capture-receipt.json',dict(backend=a.backend,gpu_uuid=GPU,device_library_version=version,source_manifest_sha256=sha(manifest_raw),source584_exact=source_exact,controls_manifest_sha256=sha(control_raw),controls_exact=controls_exact,input_NQ_archive_sha256=sha(nq_raw),input_fixture_sha256=sha(fixture_raw),inputs_unchanged=inputs_exact,actual_aggregate_calls=model_calls,observed_original_call_counts=counts,events=sequence[0],raw_array_payload_bytes=raw_array_bytes[0],observer_limits=dict(max_events=MAX_EVENTS,max_raw_array_bytes=MAX_RAW_ARRAY_BYTES),observation_limit_reached=limit_reached,partial_nontransparent=bool(limit_reached or control.errors or baseline_schedule_exact is not True),logging_errors=logging_errors,original_observed_exceptions=original_exceptions,events_tar_sha256=sha((a.output/'events.tar').read_bytes()),events_jsonl_sha256=sha((a.output/'events.jsonl').read_bytes()),all126_same_backend_byte_exact=not limit_reached and not control.errors and baseline_schedule_exact is True and transparency is not None and all(v['dtype_shape_exact'] and v['opaque_C_bytes_exact'] for v in transparency.values()),extra_phase_or_reference_replays=0,NumPy_physical_forward_calls=0,forbidden_attempts=forbidden,disabled_already_imported_CPU_aliases=disabled_cpu_aliases,actual_original_test_named_alias_presence=original_test_named_alias_presence,seconds=time.monotonic()-started,control_trace=control_receipt,combined_observer_events=sequence[0]+control.events,baseline_QJ_native_schedule_exact=baseline_schedule_exact,control_events_jsonl_sha256=sha((a.output/'control-events.jsonl').read_bytes()),default_XLA_FLAGS=os.environ.get('XLA_FLAGS'),scope='Copy-only original code-object locals trace plus unchanged native hooks once/backend. No new expression/model/phase/flow/reference evaluation, no arithmetic cause or repair inferred. Independent full numerical/common-prefix/hard-ledger analysis remains EHPC.'))
        assert source_exact and controls_exact and inputs_exact and not forbidden and not control.errors and baseline_schedule_exact is True

if __name__=='__main__':main()

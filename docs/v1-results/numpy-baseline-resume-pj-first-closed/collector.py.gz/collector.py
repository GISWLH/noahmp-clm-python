"""Read and flatten only first PJ windows already closed by real F0."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import tarfile

ROOT=Path('/tmp/noahmp-numpy-baseline-resume-pj')
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()


def main():
    assert socket.gethostname()=='manager'
    progress_raw=(ROOT/'PROGRESS.json').read_bytes();progress=json.loads(progress_raw)
    data={'snapshot/PROGRESS.json':progress_raw}
    rows=[]
    for case in progress['cases']:
        if not case['history']:continue
        first=case['history'][0];i=case['case_index'];job=first['job']
        assert first['start']==48 and first['stop']==528
        path=ROOT/'closed'/('case-'+str(i))/'stop-0000528.tar.gz'
        body=path.read_bytes();assert sha(body)==first['closed_archive_sha256']
        with tarfile.open(fileobj=io.BytesIO(body)) as tar:
            members=tar.getmembers();raw={m.name:tar.extractfile(m).read() for m in members}
        assert len(raw)==len(members)
        inventory=json.loads(raw['ARTIFACT_SHA256.json'])
        assert set(raw)==set(inventory)|{'ARTIFACT_SHA256.json'}
        assert all(sha(raw[n])==h for n,h in inventory.items())
        receipt=json.loads(raw['receipt.json']);audit=json.loads(raw['window-audit.json'])
        assert receipt['passed'] and receipt['pbs_job']==job and receipt['source_unchanged'] and receipt['source_files']==584
        assert receipt['original_steps_started']==receipt['original_steps_completed']==480
        assert receipt['saved_intervals']==receipt['full_BGC_records']==528
        assert receipt['controls_manifest_sha256']=='0f044fd60a1c870396075f63e1f87ff724ada6362072fe882fcd43fe1e7c3770'
        assert sha(raw['window-audit.json'])==receipt['window_audit_sha256']
        assert audit['full_seven_tuple_at_original_resume_exact']['max_abs_difference']==0.
        assert len(audit['original_trace_prefix_exact'])==18 and all(v['max_abs_difference']==0. for v in audit['original_trace_prefix_exact'].values())
        assert all(v['max_abs_difference']==0. for v in audit['first_original_input_exact'].values())
        assert audit['full_BGC_chain']['records']==528 and audit['full_BGC_chain']['final_BGC_exact']['max_abs_difference']==0.
        assert all(abs(v)<=b for v,b in zip(audit['residual_m_h_c_n'],audit['bounds_m_h_c_n']))
        terms=json.loads(raw['terminals.json']);assert job in terms
        qstat=raw[terms[job]['qstat']]
        assert re.search(rb'^Job Id: '+re.escape(job.encode())+rb'\s*$',qstat,re.M)
        for key,value in [('job_state','F'),('Exit_status','0'),('Stageout_status','0')]:
            assert re.search(rb'^\s*'+key.encode()+rb' = '+value.encode()+rb'\s*$',qstat,re.M)
        assert raw[terms[job]['parent_exit']].strip()==raw[terms[job]['worker_exit']].strip()==b'0'
        streams=json.loads(raw['BGC_STREAMS.json'])['streams'];assert len(streams)==2
        assert [(s['first_index'],s['stop_index']) for s in streams]==[(0,48),(48,528)]
        stream=streams[-1];headerraw=raw[stream['directory']+'/BGC_STREAM.json']
        assert sha(headerraw)==stream['header_sha256'];header=json.loads(headerraw)
        assert header['successful_original_tendencies_recorded']==480 and header['original_call_completed_without_exception']
        assert sum(block['count'] for block in header['blocks'])==480
        assert all(sha(raw[stream['directory']+'/'+block['file']])==block['sha256'] for block in header['blocks'])
        assert sha(path.read_bytes())==first['closed_archive_sha256']
        data.update({'cases/'+str(i)+'/'+n:b for n,b in raw.items()})
        rows.append(dict(case_index=i,case=case['identity']['case'],pbs_job=job,actual_F0=True,actual_Stageout0=True,
            start=48,stop=528,new_tendencies=480,new_BGC_records=480,total_BGC_records=528,
            seconds=receipt['seconds'],maximum_rss_kib=receipt['maximum_rss_kib'],
            exact_resume_seven_tuple=audit['full_seven_tuple_at_original_resume_exact'],trace_prefix_fields=18,trace_prefix_max_abs_difference=0.,
            first_input_max_abs_difference=0.,BGC_endpoint_max_abs_difference=0.,
            residual_m_h_c_n=audit['residual_m_h_c_n'],bounds_m_h_c_n=audit['bounds_m_h_c_n'],
            original_closed_archive_sha256=first['closed_archive_sha256'],original_result_archive_sha256=first['original_result_archive_sha256'],
            next_window_at_snapshot=dict(job=case.get('job'),status=case['status'],closed_local_steps=case['steps'])))
    assert rows,'No actual first window has closed; do not publish empty success'
    for name in ['CONTROLS_SHA256.json','PJ_BINDINGS.json','ADAPTATION.json']:
        data['controls/'+name]=(ROOT/'preparation'/name).read_bytes()
    for name in ['LAUNCH.json','CONTROLLER_STARTED.json']:
        data['launch/'+name]=(ROOT/name).read_bytes()
    summary=dict(snapshot_utc=progress['snapshot_utc'],actual_first_closed_windows=len(rows),actual_new_tendencies=480*len(rows),
        new_complete_years=0,accepted_spinup=False,scored=False,automatic_cycle2=False,
        source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',source_files=584,
        scope='Actual first48→528 same-year windows only. Later live windows get no additional completion credit. Full original closed packets flattened without numerical re-execution.',rows=rows)
    data['SUMMARY.json']=js(summary)
    data['collector.py']=Path(__file__).read_bytes()
    data['INTEGRITY.json']=js({n:sha(b) for n,b in sorted(data.items())})
    target=Path('/tmp/numpy-baseline-resume-pj-first-closed-evidence.tar.gz');assert not target.exists()
    with tarfile.open(target,'w:gz') as tar:
        for n,b in sorted(data.items()):
            item=tarfile.TarInfo(n);item.size=len(b);tar.addfile(item,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==data
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),inventory_files=len(data)-1,
                 **summary)
    Path('/tmp/numpy-baseline-resume-pj-first-closed-package.json').write_bytes(js(package))
    print(json.dumps({k:v for k,v in package.items() if k!='rows'}))


if __name__=='__main__':main()

from pathlib import Path
import datetime
import hashlib
import io
import json
import shutil
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
old, new = b / 'qia-fresh-phase-numpy-week-a', b / 'qia-fresh-phase-numpy-year-b'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert (old / 'pbs-exit.txt').read_text().strip() == '0' and receipt['returncode'] == 0 and receipt['source_unchanged']
assert receipt['report_sha256'] == sha(old / 'trajectory/report.json')
assert report['source_unchanged'] and report['status'] == 'running' and report['steps_completed'] == 336 and report['steps_requested'] == 17520
assert sha(old / 'SOURCE_SHA256.json') == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
for name, digest in [('model_npz', 'model_npz_sha256'), ('checkpoint_file', 'checkpoint_sha256')]:
    assert sha(old / 'trajectory' / report[name]) == report[digest]
assert not new.exists()
archive = b / 'qia-fresh-phase-numpy-week-a-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in sorted(old.rglob('*')):
        if p.is_file():
            t.add(p, arcname=p.relative_to(old).as_posix(), recursive=False)
    summary = dict(scope='Actual source510 original-cold NumPy week336,EHPC PBS225/controller/model0,original17520 request remains running. All original MHCN/source/80/tolerance gates retained; not a complete year/spinup/scientific pass. Every published generation retained; old509C failed182 not resumed.',
                   pbs_job='225.manager', model_and_pbs_returncode=0, steps_completed=336, original_steps_requested=17520,
                   seconds=receipt['seconds'], report_sha256=sha(old / 'trajectory/report.json'), source_manifest_sha256=sha(old / 'SOURCE_SHA256.json'),
                   maximum_cumulative_residual_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'])
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
(new / 'trajectory').mkdir(parents=True)
shutil.copyfile(old / 'SOURCE_SHA256.json', new / 'SOURCE_SHA256.json')
copies = {}
for name in ['report.json', report['model_npz'], report['checkpoint_file']]:
    source, dest = old / 'trajectory' / name, new / 'trajectory' / name
    shutil.copyfile(source, dest)
    assert sha(source) == sha(dest)
    copies[name] = sha(source)
record = dict(scope='Continue only own physically successful source510 original-cold336 prefix using exact same frozen510 code/input/parameters. Original week root/receipt never mutated. Whole trace,authoritative state,initial stores/net/cumulative/step bounds copied byte-exactly; original17520 request unchanged. No failed/source-changed trajectory resumed,not a science/year completion claim.',
              utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), parent_pbs_job='225.manager', parent_pbs_returncode=0,
              source_manifest_sha256=sha(new / 'SOURCE_SHA256.json'), parent_archive_sha256=sha(archive),
              copied_generation_sha256=copies, initial_resume_steps=336, steps_requested=17520)
(new / 'continuation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(archive=archive.name, archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
                      new_root=new.name, continuation_sha256=sha(new / 'continuation.json'), resume_steps=336)))

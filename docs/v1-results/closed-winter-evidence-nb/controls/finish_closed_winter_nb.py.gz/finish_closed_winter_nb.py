"""Finish the partial NB archival; preserve the real initial missing-path failure."""
from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, tarfile

b = Path('/home/zhangyq/noahmp-v1').resolve()
t = Path('/tmp/noahmp-closed-winter-nb')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert t.is_dir() and not (t/'receipt.json').exists()
mw = b/'winter-causality-mw'
previous = json.loads((mw/'ARCHIVE_LOCATION.json').read_text())
assert sorted(p.name for p in mw.iterdir()) == ['ARCHIVE_LOCATION.json']
assert sha(Path(previous['archive'])) == previous['archive_sha256']
assert all(sha(t/previous['label']/x['path']) == x['sha256'] for x in previous['entries'])
(t/'initial-attempt-failure.json').write_text(json.dumps(dict(
    actual_parent_returncode=1,
    error='FileNotFoundError: HOME surface-root-fixture-mz-evidence.tar.gz does not exist; actual archive was in /tmp',
    completed_root_before_failure='winter-causality-mw',
    original_control_sha256=sha(Path('/tmp/compact_closed_winter_nb.py'))), indent=2)+'\n')
label='surface-root-fixture-mz'
r=(b/label).resolve()
assert r.parent==b and r.is_dir() and not r.is_symlink()
q=subprocess.check_output(['qstat','-xf','1545.manager'],text=True)
assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M)
a=Path('/tmp/surface-root-fixture-mz-evidence.tar.gz')
digest='9d69dc0f9f726bc54c4f5e95f2d39f352fae4adbd6b771a76ed82a930e322bee'
assert sha(a)==digest
restored=t/label
restored.mkdir()
with tarfile.open(a) as tf: tf.extractall(restored,filter='data')
files=[p for p in r.rglob('*') if p.is_file()]
entries=[]
for p in files:
    assert r in p.resolve().parents and not p.is_symlink()
    name=p.relative_to(r).as_posix()
    assert p.read_bytes()==(restored/name).read_bytes()
    entries.append(dict(path=name,sha256=sha(p),bytes=p.stat().st_size))
# Full archive already independently published on Windows; exact complete TMP
# restore and two original archives exist before any duplicate file is removed.
for p,e in zip(files,entries):
    assert sha(p)==e['sha256']
    p.unlink()
for p in sorted([p for p in r.rglob('*') if p.is_dir()],key=lambda x:len(x.parts),reverse=True):
    assert r in p.resolve().parents and not p.is_symlink()
    p.rmdir()
durable=b/a.name
assert not durable.exists()
shutil.copyfile(a,durable)
assert sha(durable)==digest
record=dict(label=label,actual_pbs_job='1545.manager',actual_pbs_exit=0,
    archive=str(durable),archive_sha256=digest,files_removed_after_full_restore=len(entries),
    entries=entries,scope='Closed MZ evidence only. Complete original archive and TMP restore verified before removing duplicates. HOME archive retained; original MI/MP/current model states/source/inputs/journals unchanged.')
(r/'ARCHIVE_LOCATION.json').write_text(json.dumps(record,indent=2)+'\n')
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    initial_attempt_actual_parent_returncode=1, records=[previous,record],
    actual_df_inode_snapshot=subprocess.check_output(['df','-i',str(b)],text=True))
(t/'receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(closed_duplicate_files_removed=sum(x['files_removed_after_full_restore'] for x in out['records']),
    actual_df_inode_snapshot=out['actual_df_inode_snapshot'])),flush=True)

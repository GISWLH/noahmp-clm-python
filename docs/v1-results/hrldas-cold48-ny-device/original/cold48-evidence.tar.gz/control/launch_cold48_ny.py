"""Future private candidate CUDA1 cold48 only; no resume/year/cycle CLI."""
import argparse
import datetime
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

from hrldas_contract_ny import (GPU, INPUT, PARENT, REFERENCE, TARGET, load,
    prerequisites, sha, source_archive, verify_inputs, verify_reference, verify_source)

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE/'hrldas-candidate-cold48-ny'
TMP = Path('/tmp/noahmp-hrldas-candidate-cold48-ny')
HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-archive', type=Path, required=True)
    parser.add_argument('--input-archive', type=Path, required=True)
    parser.add_argument('--reference-archive', type=Path, required=True)
    args = parser.parse_args()
    assert os.name == 'posix' and Path('/proc/meminfo').exists()
    assert not ROOT.exists() and not TMP.exists(), 'Fresh immutable candidate attempt only'
    controls = load(HERE/'CONTROLS_SHA256.json')
    assert all(sha(HERE/n) == h for n,h in controls.items())
    proof = prerequisites(BASE)
    source_archive(args.source_archive)
    assert sha(args.input_archive) == INPUT
    reference = verify_reference(args.reference_archive)
    reuse = load(HERE/'reference-reuse.json')
    assert reuse['reference_reusable'] and reuse['reference_archive_sha256'] == REFERENCE
    assert reuse['input_archive_sha256'] == INPUT
    gpu = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=uuid,memory.free',
                                   '--format=csv,noheader,nounits'], text=True).strip().split(',')
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:')))
    assert gpu[0].strip() == GPU and int(gpu[1]) > 8192 and available > 32*1024*1024
    ROOT.mkdir()
    (TMP/'source').mkdir(parents=True)
    (ROOT/'cold48/inputs').mkdir(parents=True)
    with tarfile.open(args.source_archive) as archive:
        archive.extractall(TMP/'source', filter='data')
    (ROOT/'candidate-source.tar.gz').write_bytes(args.source_archive.read_bytes())
    with tarfile.open(args.input_archive) as archive:
        archive.extractall(ROOT/'cold48/inputs', filter='data')
    verify_source(TMP/'source')
    verify_inputs(ROOT/'cold48/inputs', reuse)
    for name in [*controls, 'CONTROLS_SHA256.json']:
        target = ROOT/name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((HERE/name).read_bytes())
    (ROOT/'cold48/original-kg-numpy-receipt.json').write_text(json.dumps(reference,indent=2)+'\n')
    plan = dict(source_manifest_sha256=TARGET, reference_source_manifest_sha256=PARENT,
        source_archive_sha256=sha(args.source_archive), reference_archive_sha256=REFERENCE,
        input_archive_sha256=INPUT, controls_sha256=controls,
        candidate_only=True, continuation_allowed=False, maximum_forward_steps=48,
        prerequisites=proof, original_reference_pbs_job='1188.manager', original_reference_steps=1008,
        selected_reference_first_steps_per_case=48, selected_reference_physical_pairs=144,
        scope='Private NM584 candidate3x48 using unchanged original KG configurations/weather/cold23. '
              'NR1585F0, NF negative1/positive0/all345sameprecision0, MX at least6closedmodules/23originalnodes '
              'and no currently recorded failure, plus inherited NP prerequisites. Original JN LE first48 '
              'reference reused by proven dependency equality. No production promotion, official/annual/spinup '
              'acceptance or automatic continuation. Root reviews before manually invoking this launcher.')
    (ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    env = os.environ.copy()
    for key in ['LD_LIBRARY_PATH','PYTEST_PLUGINS']:
        env.pop(key,None)
    source = TMP/'source'
    env.update(NY_ROOT=str(ROOT), NY_SOURCE=str(source), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU,
        PYTHONPATH=':'.join(map(str,[ROOT,source,source/'src',source/'benchmarks'])),
        CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
        XLA_PYTHON_CLIENT_PREALLOCATE='false', CUPY_CACHE_DIR=str(TMP/'cupy-cache'),
        CUDA_CACHE_PATH=str(TMP/'cuda-cache'), JAX_COMPILATION_CACHE_DIR=str(TMP/'jax-cache'))
    with (ROOT/'cold48/controller.log').open('x') as log:
        process = subprocess.Popen([sys.executable,'-u',str(ROOT/'control_cold48_ny.py')], cwd=source,
            env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=process.pid, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_manifest_sha256=TARGET, physical_gpu_index=1, physical_gpu_uuid=GPU,
        private_cache=str(TMP), candidate_only=True, continuation_allowed=False)
    (ROOT/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)


if __name__ == '__main__':
    main()

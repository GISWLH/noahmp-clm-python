# Closed NY CUDA1 original cold48 data

The complete original 9,577,710-byte archive (118 members) and original package are
nested unchanged. All inner and outer hashes were checked. No numerical array was
decoded, recomputed, reconstructed or extracted to disk. Original logs, receipts,
candidate flags and all other members remain intact. The readable controls are
copies of these closed original members and match all 18 frozen preparation files.
The identical NM584 source is already public under the NR evidence package.

The actual CUDA parent exited 0 after 3 x 48 steps on physical CUDA1. Independent
EHPC audit 1590.manager reached actual F0 and is separately preserved in its full
38-member pair package. results.md only formats its existing receipt fields; the
complete original receipt is included with no new statistics. This remains a
candidate cold48 result, not an official HRLDAS scientific, annual, same-precision,
full-regression or promotion result. It does not authorize a year continuation.

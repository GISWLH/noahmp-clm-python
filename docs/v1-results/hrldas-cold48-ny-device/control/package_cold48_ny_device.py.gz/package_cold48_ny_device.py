"""Stdlib envelope of the closed NY device archive; no array decoding or model execution."""
import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

BASE = Path(__file__).resolve().parent
RAW = BASE/'hrldas-cold48-ny-download'
LABEL = 'hrldas-cold48-ny-device'
DEVICE = '674b2f3f01e9ee35fbcdf35ba3221716944c2997b21ce30da60af5803703ed4c'
SOURCE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
PAIR = '6bb99c717288797ab4f3d1f8a3a7115343c6d9a520096340d21b0e460ffedbcc'
PREP = 'd6cc1b84929c65e399c9102ead1969dfa79632d70db6468fe84986a105a2fa6f'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda value: (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()


def read_archive(raw):
    data = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as tf:
        for member in tf:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in data
            data[member.name] = tf.extractfile(member).read()
    if 'artifact-inventory.json' in data:
        inventory = json.loads(data['artifact-inventory.json'])
        assert set(inventory) == set(data)-{'artifact-inventory.json'}
        for name,value in inventory.items():
            assert sha(data[name]) == value['sha256'] and len(data[name]) == value['bytes']
    return data


def result_markdown(receipt):
    def number(value):
        return 'null' if value is None else repr(value)
    lines = ['# NY 三站冷48：原1590审计数字索引', '',
        '以下数字直接复制实际 EHPC 1590.manager F0 的 receipt.json；未重新计算模型、数组或统计量。完整原 receipt 同字节保存在 hrldas-cold48-ny-results.json，包含所有 mean、scale、offset、门及每个 C/N 库的实际／参考库存。', '',
        '范围：原 KG 三站各48个半小时，与原 LE NumPy 首48配对。不是官方 HRLDAS 观测评分、全年、同精度或全GPU回归验收。313为完整返回结构保存；数值对照仍是原13轨迹、6日项及逐C/N库。', '',
        '门：逐元素 abs(reference) <= nearzero_threshold 时使用 absolute_tolerance；其余10%相对门。表中“门比”是原审计计算的最大差／相应容差，不是百分数。bias为原审计带符号百分数，相对于参考均值绝对值；nearzero或零参考时保留null，不以相对误差评价。r=null保留原平坦／不足样本状态，不补成0或1。', '',
        '瞬时表 GPP/NEE/呼吸/ET/径流使用原 scale=48 的日等效速率；日表为半小时质量总和，H/LE为日平均 W/m²。tsoil_k 的均值和bias以摄氏温标评价（offset=273.15），温差仍为K；其余scale/offset原值见JSON。C、N库存单位g C/m²、g N/m²。M/H/C/N残差单位依次kg/m²、J/m²、g C/m²、g N/m²。', '']
    for case in receipt['cases']:
        lines.extend(['## '+case['case'], '', '实际 passed='+str(case['passed'])+'；failed_fields='+json.dumps(case['failed_fields']), '',
            '| 瞬时字段 | 最大绝差 | 最大门比 | bias % | r | 要求r>.85 | 近零阈值 | 绝对容差 |',
            '|---|---:|---:|---:|---:|---|---:|---:|'])
        for key,value in case['all13physical_trace_metrics'].items():
            fields = [key, number(value['maximum_absolute_difference']),number(value['maximum_gate_ratio']),
                number(value['signed_relative_bias_percent_reference_magnitude']),number(value['instantaneous_correlation']),
                str(value.get('instantaneous_r_required',False)),number(value['nearzero_threshold']),number(value['absolute_tolerance'])]
            lines.append('| '+' | '.join(fields)+' |')
        lines.extend(['', '| 日字段 | 最大绝差 | 最大门比 | 参考值 | CUDA值 | bias % | 近零阈值 | 绝对容差 |',
            '|---|---:|---:|---:|---:|---:|---:|---:|'])
        for key,value in case['daily'].items():
            fields = [key]+[number(value[k]) for k in ['maximum_absolute_difference','maximum_gate_ratio',
                'reference_mean','model_mean','signed_relative_bias_percent_reference_magnitude','nearzero_threshold','absolute_tolerance']]
            lines.append('| '+' | '.join(fields)+' |')
        lines.extend(['', '| C/N库组 | 最大绝差 | 最大门比 | bias % | 近零阈值 | 绝对容差 |',
            '|---|---:|---:|---:|---:|---:|'])
        for key,value in case['individual_cn_pools'].items():
            fields = [key]+[number(value[k]) for k in ['maximum_absolute_difference','maximum_gate_ratio',
                'signed_relative_bias_percent_reference_magnitude','nearzero_threshold','absolute_tolerance']]
            lines.append('| '+' | '.join(fields)+' |')
        lines.extend(['', '逐库保留原审计数组次序（索引从0开始；不从聚合均值推断逐库偏差）：', '',
            '| 库组/索引 | 原NumPy库存 | CUDA库存 |', '|---|---:|---:|'])
        for key,value in case['individual_cn_pools'].items():
            for index,(reference,model) in enumerate(zip(value['reference'],value['model'])):
                lines.append('| '+key+'/'+str(index)+' | '+number(reference)+' | '+number(model)+' |')
        lines.extend(['', '| 原硬守恒分量 | 最大单步绝残差 | 最大单步门比 | 最大累计绝残差 | 最终累计bound |',
            '|---|---:|---:|---:|---:|'])
        for index,name in enumerate(['M','H','C','N']):
            values=[number(case[key][index]) for key in ['maximum_independent_step_m_h_c_n',
                'maximum_step_original_gate_ratio','maximum_independent_cumulative_m_h_c_n','original_cumulative_bounds']]
            lines.append('| '+name+' | '+' | '.join(values)+' |')
        lines.extend(['', '各步累计残差均由原审计对当步累计bound核验；表内最大累计值与最终累计bound不保证同一步，不能将它们相除当作最大逐步门比。', '',
            '五种杂质最大绝残差 kg/m²（原数组次序）：`'+json.dumps(case['maximum_impurity_residual'])+'`。', '',
            '原NumPy48参考读回：'+json.dumps(case['original_numpy_first48_audit'],ensure_ascii=False)+'', ''])
    return ('\n'.join(lines)+'\n').encode()


def main():
    device = (RAW/'cold48-evidence.tar.gz').read_bytes()
    original_package = (RAW/'cold48-package.json').read_bytes()
    original = json.loads(original_package)
    assert sha(device) == original['device_archive_sha256'] == DEVICE and len(device) == 9577710
    assert original['source_manifest_sha256'] == TARGET and original['candidate_only'] and not original['continuation_allowed']
    inner = read_archive(device); assert len(inner) == 118
    receipt,end,plan,launch = (json.loads(inner[n]) for n in ['current/receipt.json','current/exit.json','control/plan.json','control/launch.json'])
    assert end['passed'] and end['actual_parent_returncode'] == 0 and end['failure'] is None
    assert end['receipt_sha256'] == sha(inner['current/receipt.json'])
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
    assert receipt['source_manifest_sha256'] == TARGET and receipt['cases'] == 3
    assert receipt['captured_step_calls'] == receipt['steps_completed'] == 48 and receipt['steps_requested'] == 17520
    assert receipt['cold_fields_exact'] == 23 and receipt['primary_state_arrays'] == 16 and receipt['status'] == 'running'
    assert receipt['report_sha256'] == sha(inner['current/trajectory/batch.json'])
    assert sum(n.startswith('current/steps/call-') and n.endswith('.npz') for n in inner) == 48
    assert plan['source_archive_sha256'] == SOURCE and plan['source_manifest_sha256'] == TARGET
    assert launch['physical_gpu_index'] == 1 and launch['physical_gpu_uuid'] == 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
    prep_raw = (BASE/'hrldas-candidate-cold48-ny-preparation-evidence.tar.gz').read_bytes()
    assert sha(prep_raw) == PREP
    prep = read_archive(prep_raw)
    controls = json.loads(inner['control/CONTROLS_SHA256.json'])
    assert controls == plan['controls_sha256'] and len(controls) == 18
    assert inner['control/CONTROLS_SHA256.json'] == prep['CONTROLS_SHA256.json']
    for name,value in controls.items(): assert sha(inner['control/'+name]) == value and inner['control/'+name] == prep[name]
    pair_raw = (BASE/'hrldas-cold48-ny-pair-evidence.tar.gz').read_bytes(); assert sha(pair_raw) == PAIR
    pair = read_archive(pair_raw); paired = json.loads(pair['receipt.json'])
    assert paired['passed'] and paired['pbs_job'] == '1590.manager' and paired['physical_step_pairs'] == 144
    assert paired['device_archive_sha256'] == DEVICE and paired['source_manifest_sha256'] == TARGET
    assert re.search(r'^\s*job_state = F\s*$',pair['actual-qstat.txt'].decode(),re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$',pair['actual-qstat.txt'].decode(),re.M) and pair['pbs-exit.txt'].strip() == b'0'
    public = BASE.parents[1]/'docs/v1-results/climatology-final-cpu-nr'
    public_manifest = json.loads((public/'manifest.json').read_text())
    entry = next(v for v in public_manifest['artifacts'] if v['source']=='control/climatology-final-candidate-nm-source.tar.gz')
    public_source = (public/entry['path']).read_bytes()
    assert sha(public_source) == entry['stored_sha256'] == entry['source_sha256'] == SOURCE
    assert public_source == (BASE/'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    source = read_archive(public_source); manifest = source['SOURCE_SHA256.json']
    assert sha(manifest) == TARGET and len(json.loads(manifest)) == 584
    assert gzip.decompress((public/'SOURCE_SHA256.json.gz').read_bytes()) == manifest
    payload={'original/cold48-evidence.tar.gz':device,'original/cold48-package.json':original_package}
    for name in ['plan.json','launch.json','CONTROLS_SHA256.json','run_cold48_ny.py','control_cold48_ny.py',
        'launch_cold48_ny.py','archive_cold48_ny.py','hrldas_contract_ny.py','climatology_contract_np.py','surface_regression_contract_mx.py']:
        payload['control/'+name] = inner['control/'+name]
    for name in ['receipt.json','exit.json','cold-audit.json','start-prerequisites.json']:
        payload['readable/'+name] = inner['current/'+name]
    payload['source-binding.json'] = encode(dict(source_manifest_sha256=TARGET,source_files=584,source_archive_sha256=SOURCE,
        public_source_path='docs/v1-results/climatology-final-cpu-nr/'+entry['path'],
        public_nr_archive_sha256=public_manifest['archive_sha256'],byte_equal_to_original_ny_source=True,
        note='Identity relation only; original closed NY records remain candidate-only. Later promotion does not relabel this run.'))
    payload['runtime-controls-sha256.json'] = encode(dict(controls=controls,all_match_actual_plan=True,
        all_match_original_preparation=True,preparation_archive_sha256=PREP,
        provenance='Copied directly from the root-downloaded complete closed NY archive; no live or annual directory read.'))
    payload['inner-artifact-inventory.json'] = encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in inner.items()})
    payload['independent-audit/receipt.json'] = pair['receipt.json']
    payload['independent-audit/actual-qstat.txt'] = pair['actual-qstat.txt']
    payload['independent-audit/binding.json'] = encode(dict(archive='hrldas-cold48-ny-pair-evidence.tar.gz',sha256=PAIR,
        receipt_sha256=sha(pair['receipt.json']),pbs_job='1590.manager',actual_state='F',actual_exit=0,
        scientific_claim='Only independent original-gate paired cold48 readback, not official-reference scientific acceptance.'))
    payload['results.md'] = result_markdown(paired)
    (BASE/'hrldas-cold48-ny-results.json').write_bytes(pair['receipt.json'])
    (BASE/'hrldas-cold48-ny-results.md').write_bytes(payload['results.md'])
    payload['verification.json'] = encode(dict(original_archive_bytes_preserved=True,original_package_bytes_preserved=True,
        inner_artifacts=118,inner_member_hashes_verified=True,actual_gpu_parent_returncode=0,
        physical_gpu_index=1,cases=3,steps=48,cold_fields_exact=23,primary_state_arrays=16,
        receipt_sha256=sha(inner['current/receipt.json']),candidate_only=True,continuation_allowed=False,
        model_execution=False,arrays_deserialized=False,model_files_extracted_to_disk=False,
        failure_records_omitted=False,scope='Every original member and log retained, including any failure information present. No additional failure or success record invented.'))
    payload['README.md'] = ('''# Closed NY CUDA1 original cold48 data

The complete original 9,577,710-byte archive (118 members) and original package are
nested unchanged. All inner and outer hashes were checked. No numerical array was
decoded, recomputed, reconstructed or extracted to disk. Original logs, receipts,
candidate flags and all other members remain intact. The readable controls are
copies of these closed original members and match all 18 frozen preparation files.
The identical NM584 source is already public under the NR evidence package.

The actual CUDA parent exited 0 after 3 x 48 steps on physical CUDA1. Independent
EHPC audit 1590.manager reached actual F0 and is separately preserved in its full
38-member pair package. results.md only formats its existing receipt fields; the
complete original receipt is included with no new statistics. This remains a
candidate cold48 result, not an official HRLDAS scientific, annual, same-precision,
full-regression or promotion result. It does not authorize a year continuation.
''').encode()
    payload['control/package_cold48_ny_device.py'] = Path(__file__).read_bytes()
    payload['artifact-inventory.json'] = encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in payload.items()})
    archive = BASE/(LABEL+'-evidence.tar.gz'); assert not archive.exists()
    with tarfile.open(archive,'w:gz') as tf:
        for name,raw in sorted(payload.items()):
            info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
    restored=read_archive(archive.read_bytes());assert restored==payload
    assert restored['original/cold48-evidence.tar.gz']==device and read_archive(restored['original/cold48-evidence.tar.gz'])==inner
    result=dict(archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,artifacts=len(payload),
        inner_artifacts=118,original_device_archive_sha256=DEVICE,original_device_bytes=len(device),
        source_manifest_sha256=TARGET,actual_gpu_parent_exit=0,physical_gpu_index=1,cases=3,steps=48,
        independent_pair_archive_sha256=PAIR,inner_and_outer_hashes_verified=True,candidate_only=True,continuation_allowed=False,
        scope='Complete unchanged original118-member NY CUDA1 candidate3x48 data, actual parent0, exact controls/source and inner/outer hashes. Independent1590F0 original paired numbers retained. No official-science, year, same-precision, full-regression or promotion claim.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(result));print(json.dumps(result))


if __name__=='__main__':main()

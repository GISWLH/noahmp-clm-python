"""Close only the private NY cold48 attempt; never starts another stage."""
import json
import tarfile
from pathlib import Path

from hrldas_contract_ny import TARGET, load, sha, verify_inputs, verify_source

root = Path('/home/lhwang/work/noahmp-v1/hrldas-candidate-cold48-ny')
folder = root / 'cold48'
plan = load(root/'plan.json')
controls = load(root/'CONTROLS_SHA256.json')
assert plan['controls_sha256'] == controls
assert all(sha(root/name) == expected for name,expected in controls.items())
assert plan['candidate_only'] and plan['continuation_allowed'] is False and plan['maximum_forward_steps'] == 48
end = load(folder / 'exit.json')
receipt = load(folder / 'receipt.json')
assert end['passed'] and end['actual_parent_returncode'] == 0 and end['receipt_sha256'] == sha(folder / 'receipt.json')
assert end['candidate_only'] and end['continuation_allowed'] is False
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
assert receipt['device_barrier_complete'] and receipt['cold_fields_exact'] == 23 and receipt['primary_state_arrays'] == 16
assert receipt['cases'] == 3 and receipt['captured_step_calls'] == receipt['steps_completed'] == 48
assert receipt['steps_requested'] == 17520 and receipt['status'] == 'running'
assert receipt['report_sha256'] == sha(folder / 'trajectory/batch.json')
assert len(list((folder / 'steps').glob('call-*.npz'))) == 48
verify_source(Path('/tmp/noahmp-hrldas-candidate-cold48-ny/source'))
verify_inputs(folder / 'inputs', load(root / 'reference-reuse.json'))
path = root / 'cold48-evidence.tar.gz'
assert not path.exists()
with tarfile.open(path, 'w:gz') as tf:
    for file in sorted(folder.rglob('*')):
        if file.is_file():
            assert not file.is_symlink()
            tf.add(file, arcname='current/' + file.relative_to(folder).as_posix(), recursive=False)
    for name in ['plan.json', 'launch.json', 'CONTROLS_SHA256.json', *load(root / 'CONTROLS_SHA256.json')]:
        tf.add(root / name, arcname='control/' + name, recursive=False)
package = dict(archive=path.name, device_archive_sha256=sha(path), source_manifest_sha256=TARGET,
               candidate_only=True, continuation_allowed=False,
               scope='Private candidate3x48 only. Independent144pair audit required; no year or full-regression credit.')
(root / 'cold48-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package))

from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in manifest.items())
begun=time.monotonic();files=['tests/test_gpu_phase_jacobian_boundary.py','tests/test_gpu_canopy_phase_energy.py']
code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml=phase-target.xml']).returncode
assert all(sha(root/k)==v for k,v in manifest.items())
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'phase-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
(root/'phase-target-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun,counts=counts,source_files=len(manifest),source_unchanged=True,node=os.uname().nodename,files=files),indent=2)+'\n')
assert code==0 and all(counts[k]==0 for k in ['failures','errors','skipped'])

# Preserve and compare the production kernels against the measured pre-change
# baseline, in addition to the independent physical tests above.
import numpy as np
import cupy as cp
from test_gpu_canopy_phase_energy import batch
from test_gpu_phase_jacobian_boundary import cuda_result,jax_result
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.gpu.cuda.canopy_phase_energy import _kernel
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as rad_kernel
from noahmp_clm.gpu.cuda.snicar import _tables
profile=root.parent/'p6-phase-short-circuit-profile-b/profile_output'
arrays=tuple(cp.ascontiguousarray(cp.asarray(v)) for v in batch(np.float32))
a,u,f,soil,stem,c,b,snow,n=arrays;count=len(a);rad=cp.empty((count,584),cp.float32)
rad_kernel(True)((1,),(32,),(cp.ascontiguousarray(a+stem),snow,n,cp.ascontiguousarray(radiation_inputs(a+stem,u,cp)),*_tables(),rad,np.int32(count)))
out=cp.empty((count,300),cp.float32)
_kernel()((1,),(32,),(a,u,f,soil,stem,c,b,rad,cp.asarray(pack_leaf_parameters(dtype=np.float32)),out,np.int32(count),np.int32(100),np.float32(.005)))
original=cp.asnumpy(out);actual=cuda_result();jax32=jax_result(np.float32)
proof=[]
for name,value in [('original23',original),('actual_g614',actual[None,:])]:
    path=profile/(name+'.npz')
    with np.load(path,allow_pickle=False) as z:baseline=z['baseline'];candidate=z['candidate']
    np.testing.assert_array_equal(value,baseline);np.testing.assert_array_equal(value,candidate)
    proof.append(dict(case=name,baseline_npz_sha256=sha(path),shape=list(value.shape),all300_bitwise_equal=True,maximum_absolute=0.))
np.testing.assert_allclose(actual,jax32,rtol=1e-6,atol=1e-6)
np.savez_compressed(root/'production-baseline-comparison.npz',original23=original,actual_g614=actual,jax_g614=jax32)
assert all(sha(root/k)==v for k,v in manifest.items())
(root/'production-baseline-comparison.json').write_text(json.dumps(dict(cases=proof,cuda_jax_g614_maximum_absolute=float(abs(actual.astype(float)-jax32.astype(float)).max()),source_unchanged=True),indent=2)+'\n')
print('production/baseline comparison',proof,flush=True)

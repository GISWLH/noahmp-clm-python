from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,signal,time
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-phase-short-circuit-gpu-a';dest=root/'supersession-most-b.json';assert not dest.exists()
a=json.loads((root/'supersession-most-a.json').read_text());parent=a['before']['parent'];child=a['before']['child'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def live(pid):
    p=Path(f'/proc/{pid}/stat');return p.exists() and p.read_text().split(') ',1)[1].split()[0] not in ('Z','X')
assert not live(parent)
sent=False
if live(child):
    args=Path(f'/proc/{child}/cmdline').read_bytes().rstrip(b'\0').split(b'\0')
    assert child==3906587 and args[1:3]==[b'-m',b'pytest'] and str(root/'full-by-file-a').encode() in b' '.join(args)
    assert Path(f'/proc/{child}/cwd').resolve()==root and os.getpgid(child)==parent
    os.kill(child,signal.SIGTERM);sent=True
    for _ in range(20):
        if not live(child):break
        time.sleep(.1)
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in m.items())
value=dict(scope='Follow-up after I controller accepted SIGINT but its active native/JAX child remained live. Verified exact own child PID/cwd/argv/group, sent SIGTERM only to it; original progress and partial logs kept. A premature dependent launcher saw absent receipt and started no model/test process; final launcher waits for this observed terminal state.',
    observed_utc=datetime.now(timezone.utc).isoformat(),parent=parent,child=child,parent_live_after=live(parent),child_live_after=live(child),sent_sigterm=sent,source_unchanged=True,prior_receipt_sha256=sha(root/'supersession-most-a.json'))
dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));assert not live(parent) and not live(child)

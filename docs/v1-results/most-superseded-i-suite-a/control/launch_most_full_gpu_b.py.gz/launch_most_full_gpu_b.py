from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-most-oscillation-a';receipt=root/'full-by-file-launch.json';assert not receipt.exists()
preflight=json.loads((root/'full-preflight-ab-summary.json').read_text());assert preflight['source_unchanged'] and preflight['counts']['collected_nodes']==1105
old=json.loads((base/'p6-phase-short-circuit-gpu-a/supersession-most-a.json').read_text());assert not old['parent_live_after'] and not old['child_live_after'] and old['source_unchanged']
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:tests:benchmarks',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'))
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_most_full_gpu_b.py')]
with (root/'full-by-file-controller.log').open('w') as stream:
    proc=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
value=dict(pid=proc.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=1,command=command,runner_sha256=hashlib.sha256((root/'run_most_full_gpu_b.py').read_bytes()).hexdigest(),scope='Current1105 exact-node distributed suite: same-source EHPC PBS95 CPU780 plus every current325 device test on xuanze across62 files. Prior frozen I suite explicitly superseded and kept separately. Completion pending; independent target remains on GPU0.')
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,signal,time
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-phase-short-circuit-gpu-a';dest=root/'supersession-most-a.json'
assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in source.items())
launch=json.loads((root/'full-by-file-launch.json').read_text());progress=json.loads((root/'full-by-file-a/progress.json').read_text())
selection=json.loads((root/'full-by-file-a/selection.json').read_text());assert sha(root/'run_short_circuit_full_gpu.py')==selection['tool_sha256']
parent=launch['pid'];child=progress['active']['pid'];assert parent==3746318 and os.getpgid(parent)==parent and os.getpgid(child)==parent
def cmdline(pid):return Path(f'/proc/{pid}/cmdline').read_bytes().rstrip(b'\0').split(b'\0')
assert cmdline(parent)==[b'/home/lhwang/venvs/noahmp-phase3b/bin/python',b'-u',str(root/'run_short_circuit_full_gpu.py').encode()]
assert cmdline(child)[1:3]==[b'-m',b'pytest'] and str(root/'full-by-file-a').encode() in b' '.join(cmdline(child))
assert Path(f'/proc/{child}/cwd').resolve()==root
def live(pid):
    p=Path(f'/proc/{pid}/stat')
    return p.exists() and p.read_text().split(') ',1)[1].split()[0] not in ('Z','X')
before=dict(parent=parent,child=child,active_file=progress['active']['file'],completed_gpu_files=progress['gpu_files_completed'],covered_nodes=progress['covered_nodes'],collected_nodes=progress['collected_nodes'],
    source_files=len(source),source_manifest_sha256=sha(root/'SOURCE_SHA256.json'),progress_sha256=sha(root/'full-by-file-a/progress.json'))
os.killpg(parent,signal.SIGINT)
for _ in range(40):
    if not live(parent) and not live(child):break
    time.sleep(.25)
value=dict(scope='Explicitly superseded this task own frozen I suite after the current MOST revision and EHPC780 pass; this is not numerical failure or a complete old/current suite. Raw prior progress/status retained. Process-group identity and source hashes checked before SIGINT; no other job touched.',
    requested_utc=datetime.now(timezone.utc).isoformat(),before=before,parent_live_after=live(parent),child_live_after=live(child),source_unchanged=all(sha(root/n)==v for n,v in source.items()))
dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

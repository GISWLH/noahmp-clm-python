"""Observe the fixed warm baseline; physical inputs, return values and guards stay original."""
from pathlib import Path
import gzip,hashlib,json,os,pickle,subprocess,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-warm-diagnostic-fa';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-phase-descent-ec-source.tar.gz';assert sha(a)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items());cpu=b/'phase-descent-ec-cpu';proof=json.loads((cpu/'full-receipt.json').read_text());assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and proof['returncode']==0 and proof['source_unchanged'] and proof['source_manifest_sha256']==manifest and proof['counts']==dict(tests=1120,failures=0,errors=0,skipped=0)
inputs=Path(os.environ['TMPDIR'])/'inputs';inputs.mkdir();a=b/'height-inputs-a.tar.gz';assert sha(a)=='197e248451825eb7a0b1e8ee6bf9a27a8a7fb712329c80af6f25f6b646f7eb56'
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
cases=json.loads((inputs/'configs/cases.json').read_text());assert cases['protocol_sha256']=='d58c7c3151a258e13aa67ac50892e76781a1662ca9b78f49de535b5fde83b3a0';chosen=[q for q in cases['cases'] if q['site']=='CN-Qia' and q['baseline']];assert len(chosen)==1;case=chosen[0];cfg=inputs/'configs'/case['configuration'];assert case['case']=='CN-Qia-tq39.6-w39.6' and sha(cfg)==case['configuration_sha256']=='e203ec68860933d0c57b92dd5fd4f719313c1237905d40cefd0e9393cd0b174c';(r/'config.json').write_bytes(cfg.read_bytes());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
import noahmp_clm.clm_enthalpy_driver as physical
from noahmp_clm.physics.canopy_interception import MAXIMUM_LEAF_WETTED_FRACTION
assert MAXIMUM_LEAF_WETTED_FRACTION==.05
with np.load(inputs/'CN-Qia.npz',allow_pickle=False) as z:stamps=z['time_start'].copy();ends=z['time_end'].copy()
assert len(stamps)==336;protocol=dict(source_manifest_sha256=manifest,input_archive_sha256=sha(a),configuration_sha256=sha(cfg),original_case=case,original_protocol_sha256=cases['protocol_sha256'],time_start=str(stamps[0]),time_end=str(ends[-1]),original_requested_steps=336,capture_first_steps=48,scope='Prospectivelyfixed originalQia warmheight baseline, complete336 with first48 fulltrustedinput/output captures and all336 directcomponent/stress summaries. Sameforcing/height/config/coldsoil/PFT/VIC, no selection/fit/counterfactualinput or source/gate change. CurrentEC own1120 actual0; oldBO trace compared with originalidentity retained. Not site/year/spinup/holdout/scienceacceptance.');(r/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
capture=r/'captured-first48';capture.mkdir();original=runner.step_clm_enthalpy_column;original_surface=physical.surface_step;surface_input=None;rows=[];captured=0;start=time.monotonic();failure=None;trace_comparison=None
def surface_observer(*args,**kwargs):
    global surface_input
    result=original_surface(*args,**kwargs)
    surface_input=dict(args=args,kwargs={k:v for k,v in kwargs.items() if k!='_phase_cache'})
    return result
def observe(state,forcing,**kwargs):
    global surface_input,captured
    surface_input=None;after,d=original(state,forcing,**kwargs);assert surface_input is not None;dt=forcing.dt;bgc=d['biogeochemistry'];wet=float(np.asarray(d['vapor_parcels']['latent_energy_jm2'],float).sum()/dt);trans=2.5e6*float(np.asarray(d['transpiration'],float).sum());ground=float(d['ground_latent_energy_jm2']/dt);wet_mass=float(np.asarray(d['wet_evaporation'],float).sum()*dt);trans_mass=float(np.asarray(d['transpiration'],float).sum()*dt);ground_mass=float(d['ground_vapor_mass_kgm2']);total_et=float(d['et_kgm2'])
    rows.append([float(d['le']),wet,trans,ground,total_et,wet_mass,trans_mass,ground_mass,float(surface_input['kwargs']['water_stress']),float(bgc['nitrogen_factor_used']),float(bgc['lai_used']),float(d['gpp_gc_m2']),float(d['nee_gc_m2']),float(d['h']),wet+trans+ground-float(d['le']),wet_mass+trans_mass+ground_mass-total_et])
    if captured<48:(capture/('call-'+str(captured).zfill(5)+'.pkl.gz')).write_bytes(gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,physical_kwargs=kwargs,surface_input=surface_input,after=after,diagnostics=d),protocol=5),mtime=0))
    captured+=1
    return after,d
try:
    runner.step_clm_enthalpy_column=observe;physical.surface_step=surface_observer
    report=runner.run(inputs/'CN-Qia.npz',inputs/'CN-Qia.json',r/'config.json',r/'trajectory');assert report['status']=='complete' and report['steps_completed']==report['steps_requested']==captured==336 and report['source_unchanged'];np.savez_compressed(r/'components.npz',time_start=stamps,time_end=ends,values=np.asarray(rows))
    prior=b/'height-matrix-bx/height-runs'/case['case'];old=json.loads((prior/'report.json').read_text());assert old['status']=='complete' and old['steps_completed']==old['steps_requested']==336 and old['configuration_sha256']==sha(cfg) and sha(prior/old['model_npz'])==old['model_npz_sha256'] and sha(r/'trajectory'/report['model_npz'])==report['model_npz_sha256']
    with np.load(prior/old['model_npz'],allow_pickle=False) as x,np.load(r/'trajectory'/report['model_npz'],allow_pickle=False) as y:
        assert set(x.files)==set(y.files);trace_comparison={k:dict(dtype_equal=x[k].dtype==y[k].dtype,shape_equal=x[k].shape==y[k].shape,byteexact=x[k].dtype==y[k].dtype and x[k].shape==y[k].shape and x[k].tobytes()==y[k].tobytes()) for k in x.files}
    operator=b/'height-observations-ea/CN-Qia-soil-operator.json';assert sha(operator)=='49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095';(r/'soil-operator.json').write_bytes(operator.read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    with (r/'observations.log').open('x') as log:code=subprocess.run([sys.executable,str(s/'benchmarks/evaluate_fluxnet_series.py'),'--model',str(r/'trajectory'/report['model_npz']),'--model-manifest',str(r/'trajectory/report.json'),'--observations',str(inputs/'CN-Qia.npz'),'--observation-manifest',str(inputs/'CN-Qia.json'),'--soil-operator',str(r/'soil-operator.json'),'--output',str(r/'observations.json')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    assert code==0,'Observermodel completed, observationalanalysis execution failed'
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:runner.step_clm_enthalpy_column=original;physical.surface_step=original_surface
if rows:np.savez_compressed(r/'observed-components.npz',time_start=stamps[:len(rows)],time_end=ends[:len(rows)],values=np.asarray(rows))
columns=['total_LE_Wm2','wet_LE_Wm2_DIRECT','transpiration_LE_Wm2_DIRECT','ground_LE_Wm2_DIRECT','et_mm','wet_mass_mm','transpiration_mass_mm','ground_mass_mm','actual_water_stress','actual_leaf_N_factor','actual_LAI_used','gpp_gc_m2_interval','nee_gc_m2_interval','H_Wm2','component_LE_join_Wm2','component_ET_join_mm'];p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else {};d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),calls=captured,first48_capture_files=len(list(capture.glob('call-*.pkl.gz'))),component_columns=columns,all_originalBO_trace_fields=trace_comparison,report_sha256=sha(p) if p.exists() else None,seconds=time.monotonic()-start,scope=protocol['scope']);(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert failure is None and d['source_unchanged']

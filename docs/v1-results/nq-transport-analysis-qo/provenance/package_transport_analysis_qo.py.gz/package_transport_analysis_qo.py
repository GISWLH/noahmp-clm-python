"""Seal actual QO1855 diagnostic completion and original1J failure unchanged."""
import base64
import gzip
import io
import json
from pathlib import Path
import re
import tarfile

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
LABEL='nq-transport-analysis-qo'


def main():
    raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes();stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    assert sha(raw)=='e7e170a51c4a9edfa8d888095153e2249517647db03ccfb84ab715f24e2d1f00' and sha(stage_raw)=='2d15db39c0556bfd5e35df60f64b4d36f6210649d55da440459dde622eb7cb7e'
    original=files(raw,directories=True);stage=files(stage_raw);index=json.loads(stage['stage-inventory.json'])
    assert set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    assert original['stage-inventory.json']==stage['stage-inventory.json']
    for name in ('stage-before.json','stage-after.json'):
        d=json.loads(original[name]);assert d['passed'] and d['expected']==d['actual']==index and not d['mismatches']
    assert original['worker-exit.txt'].strip()==original['pbs-command-exit.txt'].strip()==b'1'
    assert original['setup-exit.txt'].strip()==original['stage-after-exit.txt'].strip()==b'0'
    receipt=json.loads(original['analysis/receipt.json']);analysis=json.loads(original['analysis/analysis.json'])
    assert receipt['pbs_job']=='1855.manager' and receipt['source584_exact'] and receipt['controls_exact'] and receipt['evidence_exact'] and receipt['error'] is None
    assert receipt['NumPy_physical_forward_calls']==receipt['GPU_calls']==receipt['extra_phase_or_reference_replays']==0 and not receipt['forbidden_attempts']
    assert receipt['actual_original_audit_calls']==['cuda','jax'] and receipt['diagnostic_conclusive'] and not receipt['original_same_precision_pass']
    assert analysis['schedule_common_prefix_events']==11 and analysis['first_schedule_divergence'] is None
    assert analysis['original_same_precision']['failed_fields']==['soil_hydrology/phase_reconstruction_residual_j_m2'] and len(analysis['original_same_precision']['fields'])==126
    assert all(all(v.values()) for v in analysis['all126_same_backend_byte_transparency'].values())
    assert all(v['original_hard_audit_pass'] for v in analysis['original_independent_hard_audits'].values())
    events=analysis['common_prefix_event_comparisons'];assert events[0]['input']['physical_typed_inputs_or_outputs_byte_exact']
    assert analysis['first_differing_physical_entry']==dict(sequence=9,parent=1,kind='redistribute',ordinal=3)
    dt=events[8]['input']['arrays']['value/dt']
    inner_same_input_different_output=[{n:r[n] for n in ('sequence','parent','kind','ordinal')} for r in events if r['kind']!='adapter' and r['input']['physical_typed_inputs_or_outputs_byte_exact'] and not r['output']['physical_typed_inputs_or_outputs_byte_exact']]
    assert not inner_same_input_different_output
    closure=BASE/(LABEL+'-closure');qstat=(closure/'poll-0.stdout').read_text()
    assert 'Job Id: 1855.manager' in qstat and re.search(r'job_state = F\b',qstat) and 'Exit_status = 1' in qstat and 'Stageout_status = 0' in qstat and 'run_count = 1' in qstat
    items={'actual-result/'+n:b for n,b in original.items()}
    for host in ('manager','compute'):
        remote=json.loads((closure/(host+'.stdout')).read_bytes());assert remote['all_stage_immutable'] and remote['stage_files_before']==remote['stage_files_after']==index
        assert json.loads((closure/(host+'.json')).read_bytes())['actual_exit']==0
        if host=='compute':assert remote['result_archive_sha256']==sha(raw) and base64.b64decode(remote['files']['pbs-exit.txt']).strip()==b'1'
        for name,b in remote['files'].items():items['closed-'+host+'/'+name]=base64.b64decode(b)
    readout=dict(pbs_job='1855.manager',job_state='F',PBS_exit=1,Stageout_status=0,run_count=1,actual_worker_exit=1,diagnostic_conclusive=True,worker_seconds=receipt['seconds'],
                 original_audit_calls=['cuda','jax'],NumPy_physical_forward_calls=0,GPU_calls=0,extra_phase_or_reference_replays=0,source584_exact=True,controls_exact=True,QJ_actual_evidence_exact=True,
                 schedule_common_prefix_events=11,first_schedule_divergence=None,adapter_entry_physical_typed_values_byte_exact=True,
                 first_differing_physical_entry=analysis['first_differing_physical_entry'],first_differing_input='value/dt',actual_dt_comparison=dt,
                 original_first_same_input_different_output_by_entry_sequence=analysis['first_identical_physical_input_different_output'],inner_profile_phase_redistribute_identical_input_different_output_observed=inner_same_input_different_output,
                 per_event=[dict(sequence=r['sequence'],kind=r['kind'],ordinal=r['ordinal'],input_exact=r['input']['physical_typed_inputs_or_outputs_byte_exact'],output_exact=r['output']['physical_typed_inputs_or_outputs_byte_exact'],input_changed_array_paths=r['input']['differing_array_paths'],input_changed_scalar_paths=r['input']['nonarray_typed_differences']) for r in events],
                 original_same_precision=dict(fields=126,rtol=1e-6,atol=1e-6,integer_exact=True,failed_fields=analysis['original_same_precision']['failed_fields'],passed=False),original_hard_audits=analysis['original_independent_hard_audits'],
                 original_phase_1J_failure=analysis['original_same_precision']['fields']['soil_hydrology/phase_reconstruction_residual_j_m2'],
                 interpretation='First two flow calls and every captured profile agree; third flow receives a different f32 duration. This trace locates the difference before that flow call, not inside the flow operator. The outer adapter has same input/different final output but is not a localized causal arithmetic line. Hidden step/fraction/elapsed evolution was not observed. No cause or repair is inferred.',
                 original_NQ399_of408_and9failed_records_retained=True,model_repaired=False,scientific_acceptance=False)
    verification=dict(passed=True,scope='Stdlib sealed archive/hash/status and already-computed EHPC JSON verification only; no numerical rerun',result_sha256=sha(raw),stage_sha256=sha(stage_raw),actual_job='1855.manager',actual_PBS_exit=1,actual_Stageout_status=0,original_result_files=len(original),source584_exact=True,controls_exact=True,diagnostic_conclusive=True,original_same_precision_pass=False)
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    items.update({'readout.json':encode(readout),'verification.json':encode(verification),'original-result.tar.gz':raw,'executed-stage.tar.gz':stage_raw})
    for directory in [closure,BASE/(LABEL+'-deployment')]:
        for path in sorted(directory.rglob('*')):
            if path.is_file():items['observations/'+directory.name+'/'+path.relative_to(directory).as_posix()]=path.read_bytes()
    for name in ['analyze_transport_trace_qo.py','prepare_transport_analysis_qo.py','deploy_transport_analysis_qo.py','check_transport_analysis_qo_pbs_readonly.py','read_transport_analysis_qo_closed.py','collect_transport_analysis_qo_closed.py','package_transport_analysis_qo.py',LABEL+'-stage-package.json',LABEL+'-scalar-report.diff',LABEL+'-pbs-preflight.json']:
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['SCOPE.md']=(readout['interpretation']+'\n\nActual QO1855 F1/Stageout0, run1, diagnostic_conclusive true. Original1J phase residual is still the only failed original1e-6/int field; no failed model gate is normalized. Both actual M/H/impurity hard ledgers pass unchanged; aggregate has no C/N pools and makes no C/N claim. All126 same-backend original NQ fields remain byte-identical. Eleven original observed event schedules match; physical array/scalar/geometry/control differences are preserved, with explicit backend module/callback/selector contexts only excluded for operator input comparison. No new forward/phase/reference/GPU calls or source/input changes occurred. Complete EHPC numerical JSON and sealed raw actual QJ/source/input package are retained. No yearly/scientific acceptance or production repair.\n').encode()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for name,b in sorted(items.items()):
            m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(label=LABEL,archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Actual QO1855 F1/Stageout0 original1J gate retained; complete sealed QJ11-event common-prefix and2 independent original hard-ledger audits,0 forward/GPU/replay. Third flow dt differs first, no causal arithmetic attribution or repair.',verification=verification)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

"""Metadata-only, review-only EHPC posthoc stage; no submit or model call."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
OLD=BASE/'nq-most-reference-qi-execution'
PREP=BASE/'nq-transport-analysis-qo-preparation'
NEW=BASE/'nq-transport-analysis-qo-execution'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
def members(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:return {m.name:t.extractfile(m).read() for m in t if m.isfile()}


def main():
    PREP.mkdir(exist_ok=False);NEW.mkdir(exist_ok=False)
    evidence=(BASE/'nq-transport-trace-qj-evidence.tar.gz').read_bytes();assert sha(evidence)=='57d69de7dbdd0069547ce1b6da4414c2b98b17759d0cbc9f1412b3a49222bba3'
    files=members(evidence);stage=members(files['executed-stage.tar.gz']);source=members(stage['source.tar.gz']);nq=members(stage['nq-evidence.tar.gz'])
    path='nq/test_gpu_clm_richards_column-diagnostics/aggregate-0.npz'
    binding=dict(QJ_evidence_archive_sha256=sha(evidence),QJ_executed_stage_sha256=sha(files['executed-stage.tar.gz']),QJ_raw_GPU_archive_sha256=sha(files['raw-gpu-result.tar.gz']),
                 source_archive_sha256=sha(stage['source.tar.gz']),source_manifest_sha256=sha(source['SOURCE_SHA256.json']),source_files=584,original_test_sha256=sha(source['tests/test_gpu_clm_richards_column.py']),
                 original_NQ_packet_path=path,original_NQ_packet_sha256=sha(nq[path]),original_fixture_sha256=sha(source['tests/fixtures/clm_richards_reference.npz']),
                 per_backend_original_events=dict(adapter=1,phase=4,profile=3,redistribute=3),original_fields=126,physical_forward_calls=0,phase_or_reference_replays=0,original_audit_calls=2,
                 same_precision=dict(rtol=1e-6,atol=1e-6,integer_exact=True),hard_ledger_source='Unchanged original tests/test_gpu_clm_richards_column.py::audit',
                 resources='EHPC PBS compute002/1CPU/2GiB/5min',root_pre_execution_review_pending=True)
    raw=(BASE/'analyze_transport_trace_qo.py').read_bytes();ast.parse(raw);assert b'\r' not in raw;(PREP/'analyze_transport_trace_qo.py').write_bytes(raw)
    (PREP/'BINDINGS.json').write_bytes(encode(binding));(PREP/'QJ_CAPTURE_READOUT.json').write_bytes((BASE/'nq-transport-trace-qj-readout.json').read_bytes())
    (PREP/'README.md').write_text('''# QO QJ actual trace posthoc — review only, no execution

One bounded EHPC compute0021CPU/2GiB/5min job reads only the actual sealed QJ57d69… evidence archive, original NM584 source, actual original NQ aggregate0 packet and actual capture rawf4fd… archive. Original GPU/NumPy/phase/reference forward calls are0. Source is extracted only to import the original independent audit; all584 source bytes and execution controls remain exact. No fixture, input, source or tolerance is changed. This stage does not launch a GPU.

Validate all outer evidence/stage/source inventories and exact raw GPU-to-unpacked correspondence, source584 and original audit source identity, actual unique aggregate once/backend, full126 same-backend byte reproduction, caps unreached/observer error0 and input identity. Each actual11-event schedule has strict global sequence, parent stack, per-function ordinal, matching return identity and exact counts adapter1/phase4/profile3/redistribute3. Compare CUDA/JAX only through the exact common schedule prefix; report its first divergence and stop pairing there.

For each aligned input/output packet, retain every original typed descriptor and raw value; compare opaque byte/dtype/shape identity and numeric differences under the original1e-6/1e-6 and exact-integer rules. The only input-context exclusions are explicitly recorded backend selector at adapter root and module/callback context tokens. No physical array, scalar, control, geometry or duration is excluded. Report first differing physical entry and first identical-physical-input/different-output boundary. If the adapter entry is already different, this trace cannot prove transport generated the upstream difference. Every raw snapshot remains sealed and available; nonfinite values are represented by explicit hex, never replaced with0.

Independently re-invoke the unchanged original audit exactly once/backend on actual captured arrays/forcing/deposition/full126 returns and the original fixture's EHPC precipitation-phase ledger terms. No physical model is called. Preserve every original M/H/impurity inequality and additionally report complete residual and bound arrays from the same expressions. Original aggregate case has no C/N pools, so C/N is explicitly not applicable here. This does not claim a new C/N audit for BGC columns.

Diagnostic completion and original gate are separate fields. All126 actual CUDA/JAX fields are checked under original tolerances. If the known1J phase residual remains an original1e-6 failure, worker and PBS retain exit1 even when diagnostic_conclusive is true and both hard ledgers pass. No zeroing/acceptance or scientific repair is implied. Original NQ399/408 and all9failed records remain. Actual F/Stageout, worker/parent exit and numerical residuals must be collected before claiming any new result. Preparation below contains no submit/launch.
''',encoding='utf-8',newline='\n')
    controls={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir())};(PREP/'CONTROLS_SHA256.json').write_bytes(encode(controls))
    differences=[]
    names=[('check_stage_qi.py','check_stage_qo.py'),('dispatch_most_reference_qi.py','dispatch_transport_analysis_qo.py'),('reference_qi.pbs','analysis_qo.pbs')]
    for old,new in names:
        before=(OLD/old).read_text();after=before.replace('most-reference-qi','transport-analysis-qo').replace('check_stage_qi','check_stage_qo').replace('dispatch_most_reference_qi','dispatch_transport_analysis_qo').replace('reference_qi.pbs','analysis_qo.pbs').replace('qi-result','qo-result')
        if old.endswith('.pbs'):
            command='"$py" -B "$stage/preparation/capture_most_reference_qi.py" --source "$stage/source.tar.gz" --output "$root/reference"'
            assert command in after;after=after.replace(command,'"$py" -B "$stage/preparation/analyze_transport_trace_qo.py" --evidence "$stage/qj-evidence.tar.gz" --output "$root/analysis"')
            after=after.replace("--exclude='./reference/source'","--exclude='./analysis/source'")
            after=after.replace('echo "$?" > "$root/stage-after-exit.txt"\n    status=$worker_status','after_status=$?\n    echo "$after_status" > "$root/stage-after-exit.txt"\n    status=$worker_status\n    if test "$after_status" -ne 0; then status=$after_status; fi')
            assert after.startswith('#!/bin/bash\n') and '\r' not in after
        else:
            after=after.replace('planned_reference_calls=2, full_column_calls=2, GPU_calls=0','planned_reference_calls=0, full_column_calls=0, GPU_calls=0, original_audit_calls=2')
            ast.parse(after)
        (NEW/new).write_text(after,encoding='utf-8',newline='\n');differences.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='QI/'+old,tofile='QO/'+new))
    (NEW/'QI_TO_QO.diff').write_text(''.join(differences),encoding='utf-8',newline='\n')
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),QJ_evidence_archive_sha256=sha(evidence),resources='1CPU/2GiB/5min/compute002',planned_reference_calls=0,physical_forward_calls=0,GPU_calls=0,original_audit_calls=2,root_authorization_pending=True,single_submission=True,automatic_retry=False)))
    (NEW/'README.md').write_text('Mechanical actual QI/PW PBS manager/compute002 transfer and controls lifecycle on fresh QO paths. Stage-after nonzero also propagates. Exactly0 physical/phase/reference/GPU calls;2 original pure audit calls. Original1J parity gate remains worker/PBS1 if reproduced, while diagnostic delivery is separately recorded. Review-only: no submit.\n',encoding='utf-8',newline='\n')
    execution={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir())};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(execution))
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()});items['qj-evidence.tar.gz']=evidence;items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/'nq-transport-analysis-qo-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    result=dict(passed=True,stage_sha256=sha(target.read_bytes()),stage_files=len(items),preparation_controls=len(controls),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(execution),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),source584_and_actual_QJ_bound=True,LF_shebang_valid=True,physical_forward_calls=0,GPU_calls=0,original_audit_calls=2,root_review_pending=True,submitted=False,numerical_executed=False)
    (BASE/'nq-transport-analysis-qo-stage-package.json').write_bytes(encode(result));print(json.dumps(result))


if __name__=='__main__':main()

"""Wait only for submitted QC1827, then preserve raw metadata and result."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE=Path(__file__).resolve().parent
DEST=BASE/'nq-transport-analysis-qo-closure'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def run(label,cmd,data=None):
    started=time.monotonic();r=subprocess.run(cmd,input=data,capture_output=True,timeout=60)
    (DEST/(label+'.stdout')).write_bytes(r.stdout);(DEST/(label+'.stderr')).write_bytes(r.stderr)
    (DEST/(label+'.json')).write_text(json.dumps(dict(command=cmd,actual_exit=r.returncode,seconds=time.monotonic()-started,stdin_sha256=sha(data) if data else None,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)),indent=2)+'\n')
    assert r.returncode==0,(label,r.stderr.decode(errors='replace'))
    return r.stdout

def main():
    DEST.mkdir(exist_ok=False)
    started=time.monotonic();counter=0
    while True:
        raw=run('poll-'+str(counter),['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -xf 1855.manager'])
        if b'job_state = F' in raw:break
        assert time.monotonic()-started<900
        counter+=1;time.sleep(10)
    reader=(BASE/'read_transport_analysis_qo_closed.py').read_bytes()
    for label,host in [('manager','ehpc'),('compute','ehpc-c2')]:
        run(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12',host,'/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'],reader)
    manager=json.loads((DEST/'manager.stdout').read_bytes());compute=json.loads((DEST/'compute.stdout').read_bytes())
    assert manager['all_stage_immutable'] and compute['all_stage_immutable']
    run('result-download',['scp','-O','ehpc-c2:/tmp/noahmp-transport-analysis-qo/result.tar.gz',str(BASE/'nq-transport-analysis-qo-result.tar.gz')])
    result=BASE/'nq-transport-analysis-qo-result.tar.gz'
    assert sha(result.read_bytes())==compute['result_archive_sha256']
    status=base64.b64decode(compute['files']['pbs-exit.txt']).decode().strip()
    print(json.dumps(dict(pbs_job='1855.manager',actual_collection_exit=0,pbs_command_exit=int(status),stage_exact=True,result_sha256=sha(result.read_bytes()),seconds=time.monotonic()-started)))

if __name__=='__main__':main()

from pathlib import Path
import hashlib
import inspect
import json
import os
import pickle
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'most-physical-check-b'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
s = scratch / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-most-physical-b-source.tar.gz'
assert sha(a) == '862634414b9c1deaec50f94dca23576a9110f63de54d9c39ea27fe9199923df3'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 509 and all(sha(s / n) == h for n, h in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s), str(s / 'src'), str(s / 'benchmarks')]
import numpy as np
import run_fluxnet_column as original
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-stem-numpy-week-a'
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert receipt['returncode'] == 1 and receipt['source_unchanged'] and report['steps_completed'] == report['failed_index'] == 163
assert sha(old / 'trajectory/report.json') == receipt['report_sha256']
assert sha(old / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
old_manifest = json.loads((old / 'SOURCE_SHA256.json').read_text())
assert sorted(n for n in manifest if n.startswith('src/') and old_manifest.get(n) != manifest[n]) == ['src/noahmp_clm/clm_enthalpy_driver.py', 'src/noahmp_clm/gpu/canopy_most_surface.py', 'src/noahmp_clm/physics/canopy_column.py', 'src/noahmp_clm/physics/canopy_most.py', 'src/noahmp_clm/physics/canopy_phase_energy.py', 'src/noahmp_clm/physics/most_physical_check.py']
state, initial, net, bounds, maximum, stepmax, index = pickle.loads((old / 'trajectory' / report['checkpoint_file']).read_bytes())
assert index == 163
inputs = b / 'qia-stem-inputs-a/inputs'
protocol = json.loads((inputs.parent / 'protocol.json').read_text())
assert all(sha(inputs / n) == h for n, h in protocol['inputs_sha256'].items())
config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
metadata = json.loads((inputs / 'CN-Qia.json').read_text())
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    data = dict(z)
stamps = original.validate_input(data, metadata, inputs / 'CN-Qia.npz')
f = original.Forcing(*data['forcing'][index])
co2, mu, diffuse = data['environment'][index]
environment = original.calendar(stamps[index], metadata, config['phenology'] is not None)
schedule = original.DepositionSchedule(config)
dep = schedule.aerosol(stamps[index], f.dt)
nitrogen = schedule.nitrogen_rate * f.dt
geometry = original.MOSTGeometry(**config['most_geometry'])
leaf = original.LeafParameters(**config['leaf_parameters'])
start = time.monotonic()
failure, result = None, None
try:
    after, d = original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
    incoming, residual, bound = original.audit_step(state, after, f, d, nitrogen)
    cumulative = original.totals(after) - initial - (net + incoming)
    assert np.all(abs(residual)<=bound) and np.all(abs(cumulative)<=bounds+bound)
    (r / 'diagnostic-step164.pkl').write_bytes(pickle.dumps((state, after, f, d)))
    result = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=(bounds+bound).tolist(), diagnostics={k:float(d[v]) for k,v in original.TRACE.items()}, diagnostic_state_sha256=sha(r/'diagnostic-step164.pkl'))
except Exception as e:
    failure = type(e).__name__+': '+str(e)
    (r/'traceback.txt').write_text(traceback.format_exc())
assert all(sha(s/n)==v for n,v in manifest.items())
record=dict(scope='Uninstrumented production warm-start implementation replay of original failed163; original old M/H/C/N state and independent ledger bounds retained. No climate acceptance or continuation into the original failed year.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,result=result,source_unchanged=True,source_files=509,original_failed_checkpoint_sha256=report['checkpoint_sha256'],seconds=time.monotonic()-start)
(r/'probe.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps(record,allow_nan=False),flush=True)
assert failure is None

from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'phase-warm-check-a'
scratch = Path(os.environ['TMPDIR'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'p6-phase-warm-a-source.tar.gz'
assert sha(a)=='6ea8037b6a48b3756a1c2bf87f259381bb1d7f41bb9c78a3bb27286dff3aed1c'
new=scratch/'candidate';new.mkdir()
with tarfile.open(a) as t:t.extractall(new,filter='data')
m=json.loads((new/'SOURCE_SHA256.json').read_text())
assert len(m)==507 and all(sha(new/n)==v for n,v in m.items())
(r/'SOURCE_SHA256.json').write_bytes((new/'SOURCE_SHA256.json').read_bytes())

def run(label, s, manifest, files, expected, expected_failure=False):
    env = os.environ.copy()
    env.update(PYTHONPATH=':'.join(map(str, [b / 'test-deps', s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    env.pop('NOAHMP_REQUIRE_GPU', None)
    start = time.monotonic()
    xml = r / (label + '.xml')
    with (r / (label + '.log')).open('x') as log:
        code = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-s', *files, '--junitxml=' + str(xml)], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    tree = ET.parse(xml).getroot()
    counts = {k: sum(int(v.attrib[k]) for v in tree.iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
    failures = [v.attrib['name'] for v in tree.iter('testcase') if v.find('failure') is not None]
    unchanged = all(sha(s / n) == v for n, v in manifest.items())
    record = dict(scope='Causal same-step warm-root regression, independent SciPy phase equations, and full CPU suite on EHPC PBS. Original tolerances, update limits, equations and MHCN unchanged; no climate/scientific/GPU acceptance.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, label=label, returncode=code, expected_failure=expected_failure, counts=counts, failures=failures, source_unchanged=unchanged, source_files=507, seconds=time.monotonic() - start, xml_sha256=sha(xml))
    (r / (label + '-receipt.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if expected_failure:
        return code == 1 and unchanged and counts == dict(tests=2, failures=1, errors=0, skipped=0) and failures == ['test_phase_root_reached_by_last_permitted_update_is_accepted']
    return code == 0 and unchanged and counts == dict(tests=expected, failures=0, errors=0, skipped=0)

assert run('phase-regression',new,m,['tests/test_canopy_phase_energy.py'],24)
files=sorted(p.relative_to(new).as_posix() for p in (new/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
assert run('cpu-full',new,m,files,905)

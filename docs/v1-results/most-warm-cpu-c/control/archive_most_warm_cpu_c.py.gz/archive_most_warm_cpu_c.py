from pathlib import Path
import hashlib
import json
import tarfile

b=Path('/home/zhangyq/noahmp-v1');r=b/'most-physical-check-c';a=b/'most-warm-cpu-c-evidence.tar.gz';assert not a.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'cpu-full-receipt.json').read_text())
assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=909,failures=0,errors=0,skipped=0) and (r/'pbs-exit.txt').read_text().strip()=='0'
assert sha(r/'cpu-full.xml')==d['xml_sha256']
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for name in ['phase-warm-check-a','most-physical-check-a','most-physical-check-b']:
        old=b/name;assert (old/'pbs-exit.txt').read_text().strip()=='1'
        for p in sorted(old.rglob('*')):
            if p.is_file():t.add(p,arcname='prior/'+name+'/'+p.relative_to(old).as_posix(),recursive=False)
    with tarfile.open(b/'p6-most-physical-c-source.tar.gz') as source:
        manifest=json.loads(source.extractfile('SOURCE_SHA256.json').read())
        assert len(manifest)==509 and manifest==json.loads((r/'SOURCE_SHA256.json').read_text())
        names=['src/noahmp_clm/clm_enthalpy_driver.py','src/noahmp_clm/physics/canopy_column.py','src/noahmp_clm/physics/canopy_phase_energy.py','src/noahmp_clm/physics/canopy_most.py','src/noahmp_clm/physics/most_physical_check.py','src/noahmp_clm/gpu/canopy_most_surface.py','tests/test_canopy_phase_energy.py','tests/test_most_physical_check.py','tests/test_most_stagnation.py','tests/fixtures/qia_163_phase_warm.json']
        for n in names:
            raw=source.extractfile(n).read();assert hashlib.sha256(raw).hexdigest()==manifest[n]
            info=tarfile.TarInfo('source/'+n);info.size=len(raw)
            t.addfile(info,__import__('io').BytesIO(raw))
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Exact509 C CPU909,14MOST+24phase targets and uninstrumented163 replay,actual PBS2090. All prior206/207/208 failures and actual1 preserved. No climate/GPU/full-canonical acceptance.')))

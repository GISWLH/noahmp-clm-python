"""Create explicitly separate static interpretation copies; originals unchanged."""
from pathlib import Path
import hashlib
import json
import struct

BASE=Path(__file__).resolve().parent
ORIGINAL=BASE/'drainage-geometry-pb-v-loaded-cuda-disassembly'
OUT=BASE/'drainage-elf-zero-copy-pb-y'
sha=lambda r:hashlib.sha256(r).hexdigest()

def main():
    assert not OUT.exists();OUT.mkdir();rows=[]
    for name in ('original-diagnosis','geometry-probe'):
        path=ORIGINAL/(name+'.cubin');raw=path.read_bytes();new=raw+b'\0'
        header=struct.unpack_from('<16sHHIQQQIHHHHHH',raw)
        phoff,phsize,phnum=header[5],header[9],header[10]
        assert phsize==56 and phnum==4 and phoff+phsize*phnum==len(new)
        target=OUT/(name+'-DIAGNOSTIC-PLUS-ONE-ZERO.cubin');target.write_bytes(new)
        assert target.read_bytes()[:-1]==raw and target.read_bytes()[-1:]==b'\0'
        assert path.read_bytes()==raw
        align_offset=phoff+(phnum-1)*56+48
        align=struct.unpack_from('<Q',new,align_offset)[0];assert align==8
        rows.append(dict(original_file=str(path),original_sha256=sha(raw),original_bytes=len(raw),
            diagnostic_copy=target.name,diagnostic_copy_sha256=sha(new),diagnostic_copy_bytes=len(new),
            appended_bytes_hex='00',entire_original_prefix_byte_exact=True,original_unmodified=True,
            program_header3_p_align_offset=align_offset,diagnostic_copy_p_align=align,
            all_original_section_and_code_bytes_unchanged=True,never_loaded=True,never_compiled=True))
    result=dict(diagnostic_static_copies_only=True,original_disk_ELF_modified=False,GPU_calls=0,recompiled=False,files=rows,
        explanation='A separate single-zero suffix copy tests the structural consequence of the missing program-header byte. It is not the original disk cache, a new load, or a new compilation. Python bytes buffers have an extra uncounted terminating NUL; consistency with that fact does not identify the upstream origin of the missing stored byte.',
        Python_C_API_source='https://docs.python.org/3/c-api/bytes.html')
    (OUT/'DIAGNOSTIC_COPY_PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':main()

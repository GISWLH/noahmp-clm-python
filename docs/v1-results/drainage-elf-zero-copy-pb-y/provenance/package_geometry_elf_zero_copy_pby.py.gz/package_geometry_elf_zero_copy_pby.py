"""Successful static interpretation of explicitly labeled one-zero suffix copies."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
ROOT=BASE/'drainage-elf-zero-copy-pb-y'
LABEL='drainage-elf-zero-copy-pb-y'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    raw=(ROOT/'copy-disassembly-result.tar.gz').read_bytes();original=files(raw)
    assert sha(raw)=='ebcaf44c3a724b16046ac77ae9a7ead9ffa33c3ab9dbf6e211ec1f89e1cf8952'
    receipt=json.loads(original['COPY_DISASSEMBLY_RECEIPT.json']);proof=json.loads(original['DIAGNOSTIC_COPY_PROOF.json'])
    assert len(receipt['commands'])==6 and all(x['actual_exit']==0 for x in receipt['commands'])
    assert not receipt['loaded'] and not receipt['recompiled'] and receipt['GPU_calls']==0
    assert receipt['copy_hashes_unchanged'] and proof['original_disk_ELF_modified'] is False
    for row in proof['files']:
        old=Path(row['original_file']).read_bytes();copy=original[row['diagnostic_copy']]
        assert sha(old)==row['original_sha256'] and sha(copy)==row['diagnostic_copy_sha256']
        assert copy==old+b'\0' and row['diagnostic_copy_p_align']==8
    readout=dict(diagnostic_copy_interpretation_completed=True,source_disk_ELF_unmodified=True,
        copy_only=True,ever_loaded=False,recompiled=False,GPU_calls=0,
        static_tool_returncodes=[x['actual_exit'] for x in receipt['commands']],
        output_sizes=[dict(command=x['command'],stdout_bytes=x['stdout_bytes'],stderr_bytes=x['stderr_bytes']) for x in receipt['commands']],
        files=proof['files'],
        conclusion='Appending exactly one0 only to separately named diagnostic copies completes the missing last p_align byte. Both existing12.4 tools then disassemble code successfully; no embedded PTX is present. Every original prefix/code/section byte and the original disk ELF remain unchanged. This demonstrates the structural condition causing the static tool rejection; it does not identify where an upstream byte disappeared or claim the copies were original cache bytes, loaded modules or new compilations.',
        Python_C_API_source='https://docs.python.org/3/c-api/bytes.html',
        Python_buffer_inference='An uncounted terminating NUL in Python bytes is consistent with successful memory loading versus the stored-file tail, but no runtime pointer read or upstream removal cause was demonstrated.')
    items={'original-diagnostic-copy-attempt.tar.gz':raw,'readout.json':encode(readout),
        'original-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(original.items())})}
    for p in ROOT.iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for n,v in original.items():
        if n.endswith(('.stdout.txt','.stderr.txt')) or n=='COPY_DISASSEMBLY_RECEIPT.json':items['static-copy-output/'+n]=v
    for n in ('prepare_geometry_elf_zero_copy_pby.py','disassemble_geometry_zero_copy_pby.py',Path(__file__).name):items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,v in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;archive.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Explicitly labeled single-zero suffix static copies only;6 existing cuobjdump/nvdisasm commands0, SASS present/PTX empty. Original disk ELF/code unchanged, no load/compile/GPU/physics or numerical correctness credit.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

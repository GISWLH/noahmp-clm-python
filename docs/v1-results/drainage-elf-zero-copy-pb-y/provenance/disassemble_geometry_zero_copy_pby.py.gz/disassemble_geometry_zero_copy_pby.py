"""Static disassembly of labeled suffix copies only; no compilation or loading."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

ROOT=Path('/tmp/noahmp-geometry-pby-diagnostic-copy')
sha=lambda r:hashlib.sha256(r).hexdigest()
proof=json.loads((ROOT/'DIAGNOSTIC_COPY_PROOF.json').read_bytes());rows=[]
for r in proof['files']:
    path=ROOT/r['diagnostic_copy'];assert sha(path.read_bytes())==r['diagnostic_copy_sha256']
    for kind,command in (('cuobjdump-sass',['/usr/local/cuda-12.4/bin/cuobjdump','--dump-sass',str(path)]),
            ('cuobjdump-ptx',['/usr/local/cuda-12.4/bin/cuobjdump','--dump-ptx',str(path)]),
            ('nvdisasm',['/usr/local/cuda-12.4/bin/nvdisasm',str(path)])):
        label=path.stem+'-'+kind;run=subprocess.run(command,capture_output=True,timeout=120)
        (ROOT/(label+'.stdout.txt')).write_bytes(run.stdout);(ROOT/(label+'.stderr.txt')).write_bytes(run.stderr)
        rows.append(dict(command=command,actual_exit=run.returncode,stdout_sha256=sha(run.stdout),stdout_bytes=len(run.stdout),
            stderr_sha256=sha(run.stderr),stderr_bytes=len(run.stderr),copy_only=True))
assert all(sha((ROOT/r['diagnostic_copy']).read_bytes())==r['diagnostic_copy_sha256'] for r in proof['files'])
receipt=dict(diagnostic_copies_only=True,GPU_calls=0,recompiled=False,loaded=False,commands=rows,copy_hashes_unchanged=True)
(ROOT/'COPY_DISASSEMBLY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
target=ROOT/'copy-disassembly-result.tar.gz';assert not target.exists();paths=sorted(p for p in ROOT.iterdir() if p.is_file())
with tarfile.open(target,'w:gz') as tar:
    for p in paths:tar.add(p,arcname=p.name,recursive=False)
print(json.dumps(dict(archive_sha256=sha(target.read_bytes()),bytes=target.stat().st_size,receipt=receipt)))

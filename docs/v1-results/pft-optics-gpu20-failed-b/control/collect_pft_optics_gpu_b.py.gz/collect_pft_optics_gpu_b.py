from pathlib import Path
import hashlib,json,os,sys
import pytest
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-b';r=s/'targets-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==518 and all(sha(s/n)==h for n,h in m.items());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(v.nodeid for v in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));assert code==0 and len(nodes)==len(set(nodes))==1291
gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];assert len(gpu)==351 and len(nodes)-len(gpu)==940
groups={}
for file,count in [('test_gpu_canopy_optics.py',5),('test_gpu_canopy_snow_radiation.py',4),('test_gpu_canopy_phase_energy.py',11),('test_gpu_clm_optics_column.py',3)]:
    found=[n.split('/',1)[1] for n in gpu if Path(n.split('::')[0]).name==file];assert len(found)==count;groups[file]=found
barriers=[]
if 'jax' in sys.modules:sys.modules['jax'].effects_barrier();barriers.append('jax-complete')
if 'cupy' in sys.modules:sys.modules['cupy'].cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
assert all(sha(s/n)==h for n,h in m.items())
d=dict(scope='Actualcurrent518 canonical1291 collect-only940CPU351GPU,notexecution/sciencepass. Atexitbypass onlyafter actualpytest collectionreturn/barriers/sourcechecks anddurable receipt.',returncode=code,nodes=nodes,groups=groups,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,device_barriers=barriers)
with (r/'collection.json').open('x') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
sys.stdout.flush();sys.stderr.flush();os._exit(0)

from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-b';assert not s.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'pft-optics-final-b-source.tar.gz';package=json.loads((b/'pft-optics-final-b-package.json').read_text());assert sha(a)==package['archive_sha256']=='023dea711f66cba571f4e868a4298606c84ac562b2b531c48b58e726a8ddfe12'
cpu=b/'pft-optics-cpu-final-b-evidence.tar.gz';assert cpu.exists()
with tarfile.open(cpu) as t:
    rec=json.load(t.extractfile('receipt.json'));m=json.load(t.extractfile('SOURCE_SHA256.json'))
    assert t.extractfile('pbs-exit.txt').read().strip()==b'0' and rec['counts']==dict(tests=940,failures=0,errors=0,skipped=0) and rec['returncode']==0 and rec['source_unchanged'] and rec['source_manifest_sha256']==package['manifest_sha256']
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>6144
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());assert int(mem['MemAvailable'].split()[0])>12*1024*1024
s.mkdir()
with tarfile.open(a) as t:t.extractall(s,filter='data')
assert json.loads((s/'SOURCE_SHA256.json').read_text())==m and all(sha(s/n)==h for n,h in m.items());r=s/'targets-b';r.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
controls={n:sha(b/n) for n in ['launch_pft_optics_gpu_b.py','control_pft_optics_gpu_b.py','collect_pft_optics_gpu_b.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_pft_optics_gpu_b.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='Frozen518B after actualsame-sourceEHPC940 including nonabsorbing limit. Actual collect1291/targets20 all624 raw1e-6/ints/science/hardgates; no oldA credit/full/year/science acceptance. Original A BGC and old506 models left running.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_memory_mib=free,source_archive_sha256=sha(a),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cpu_archive_sha256=sha(cpu),controls_sha256=controls)
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import os,sys,json,hashlib
import numpy as np
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'phase-edge-fixture-a'
sys.path[:0]=[str(source/'src'),str(source/'tests')]
import noahmp_clm.physics.canopy_phase_energy as phase
import test_gpu_canopy_phase_surface as test
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
class Captured(Exception):pass
saved=None
def capture(*a,**kw):
 global saved
 saved=(a,kw);raise Captured
original=phase.solve_canopy_phase_energy;phase.solve_canopy_phase_energy=capture
try:
 data=json.loads((source/'tests/fixtures/canopy_phase_surface_regression.json').read_text())
 row=tuple(np.asarray(x,np.int32 if k==3 else float) for k,x in enumerate(data))
 from clm_soil_oracle import fixture_suction
 row=(*row[:2],fixture_suction(row[2],.355),*row[3:]);test.reference(row)
except Captured:pass
finally:phase.solve_canopy_phase_energy=original
assert saved is not None
a,kw=saved;leaf,sw,lw,e,condensate,dt=a
arrays=pack_canopy_phase(leaf,sw,lw,e,condensate,dt,dtype=np.float64,**kw)
p=root/'phase_edge_float64_stencil.npz';np.savez_compressed(p,**{'a'+str(k):v for k,v in enumerate(arrays)},extension=np.asarray([e.water_velocity,e.heat_temperature]),leaf_parameters=pack_leaf_parameters(kw.get('leaf_parameters'),np.float64))
assert all(sha(source/n)==v for n,v in manifest.items())
record=dict(scope='Packing only: existing conservative-surface regression initial fixed boundary, exactly the CPU138 failing call; no solver/model step executed or state advanced.',source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),original_fixture_sha256=sha(source/'tests/fixtures/canopy_phase_surface_regression.json'),fixed_ground_temperature=kw['fixed_ground_temperature'],fixture_sha256=sha(p),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename)
(root/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

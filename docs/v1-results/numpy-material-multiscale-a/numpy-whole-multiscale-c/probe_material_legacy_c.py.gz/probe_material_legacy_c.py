from pathlib import Path
import os,sys,types,json,time,traceback,hashlib
import numpy as np
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'numpy-whole-multiscale-c'
sys.path[:0]=[str(source/'src'),str(source/'tests')]
import noahmp_clm.physics.canopy_phase_energy as phase
def module(path):
 m=types.ModuleType('noahmp_clm.physics._diagnostic_multiscale');m.__package__='noahmp_clm.physics'
 exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
candidate=module(root/'surface-material-a.py');fine=module(root/'phase-multiscale-c.py')
import test_gpu_canopy_phase_surface as test
old_phase=phase.solve_canopy_phase_energy;old_surface=test.surface_step
begun=time.monotonic();failure=None;result=None
try:
 phase.solve_canopy_phase_energy=fine.solve_canopy_phase_energy;test.surface_step=candidate.surface_step
 data=json.loads((source/'tests/fixtures/canopy_phase_surface_regression.json').read_text())
 row=tuple(np.asarray(x,np.int32 if k==3 else float) for k,x in enumerate(data))
 from clm_soil_oracle import fixture_suction
 row=(*row[:2],fixture_suction(row[2],.355),*row[3:]);d=test.reference(row)
 assert abs(d['energy_residual_jm2'])<.01 and abs(d['water_residual_kgm2'])<2e-10 and np.max(abs(d['layer_residual']))<1.05e-7
 result=dict(heat=d['energy_residual_jm2'],water=d['water_residual_kgm2'],residual=float(np.max(abs(d['layer_residual']))))
except BaseException as e:failure=type(e).__name__+': '+str(e);(root/'legacy-traceback.txt').write_text(traceback.format_exc())
finally:phase.solve_canopy_phase_energy=old_phase;test.surface_step=old_surface
value=dict(failure=failure,result=result,seconds=time.monotonic()-begun,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,scope='Counterfactual existing phase-edge fixture, original budgets and convergence retained; not an annual result.')
(root/'legacy.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

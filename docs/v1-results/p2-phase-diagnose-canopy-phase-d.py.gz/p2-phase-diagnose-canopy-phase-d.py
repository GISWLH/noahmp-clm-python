import inspect,json
import noahmp_clm.physics.canopy_phase_energy as module
from check_canopy_phase_energy_reference import random_cases
source=inspect.getsource(module.solve_canopy_phase_energy)
source=source.replace('        residual=evaluate(x)\n','        residual=evaluate(x)\n        print(json.dumps(dict(iteration=iteration,coordinates=x.tolist(),residual=residual.tolist())),flush=True)\n')
ns=module.__dict__.copy();ns['json']=json;exec(source,ns)
name,a,sw,lw,e,c,kw=list(random_cases(13))[12]
print(json.dumps(dict(name=name,air=e.air_temperature,sw=sw,lw=lw,old_mass=c.mass.tolist(),old_h=c.enthalpy.tolist())),flush=True)
ns['solve_canopy_phase_energy'](a,sw,lw,e,c,1800.,**kw)

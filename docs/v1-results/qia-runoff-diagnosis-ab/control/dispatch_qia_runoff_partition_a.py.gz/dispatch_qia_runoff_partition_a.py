from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-runoff-partition-a';assert not r.exists();r.mkdir();controls={}
for name in ['run_qia_runoff_partition_a.py','qia_runoff_partition_a.pbs']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'qia_runoff_partition_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
record=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='Read-only tendency instrumentation of unchanged successful308 cold48; originalalltracebyteequality/MHCN and independentARNO checked on PBScompute. Queuing not diagnosis completion.')
(r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

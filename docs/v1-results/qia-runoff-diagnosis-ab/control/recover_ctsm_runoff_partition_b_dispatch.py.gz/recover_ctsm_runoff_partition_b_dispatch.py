from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-runoff-partition-b'
assert r.is_dir() and not (r/'dispatch.json').exists() and not (r/'node.txt').exists()
names=['run_ctsm_runoff_partition_b.py','audit_ctsm_runoff_partition_b.py','ctsm_runoff_partition_b.pbs']
assert {p.name for p in r.iterdir()}==set(names)
controls={}
for name in names:
    raw=(r/name).read_bytes();assert raw==(b/name).read_bytes();controls[name]=hashlib.sha256(raw).hexdigest()
(r/'first-dispatch-failure.json').write_text(json.dumps(dict(scope='Original generated dispatch named nonexistent A PBSfile inside newB folder. qsub actual1: script file No such file or directory. No job/model was submitted; original copied controls retained.',old_dispatch_sha256=hashlib.sha256((b/'dispatch_ctsm_runoff_partition_b.py').read_bytes()).hexdigest()),indent=2)+'\n')
p=subprocess.run(['qsub',str(r/'ctsm_runoff_partition_b.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
record=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='Metadata-only recovery of proven unsubmittedB directory after wrong PBSfilename. Official numericalaudit still only PBScompute, portable originalenv; no actual job stopped/restarted.')
(r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

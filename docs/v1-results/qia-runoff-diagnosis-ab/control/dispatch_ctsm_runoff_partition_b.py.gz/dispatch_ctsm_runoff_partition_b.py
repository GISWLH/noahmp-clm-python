from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-runoff-partition-b';assert not r.exists();r.mkdir();controls={}
for name in ['run_ctsm_runoff_partition_b.py','audit_ctsm_runoff_partition_b.py','ctsm_runoff_partition_b.pbs']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'ctsm_runoff_partition_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
record=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='OfficialR actual history/initial/surface partition audit on PBS compute; literal archive/no model change, missing/masked data remain unmeasured.')
(r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

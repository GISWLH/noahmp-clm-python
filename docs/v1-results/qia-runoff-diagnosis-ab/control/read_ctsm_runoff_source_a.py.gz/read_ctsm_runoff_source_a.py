"""Pinned source/namelist text only; no model or NetCDF numerical work."""
from pathlib import Path
import hashlib,json,re,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-runoff-source-a';assert not r.exists();r.mkdir()
a=b/'ctsm-reference-source-bundle-a.tar.gz';sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert sha(a.read_bytes())=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
rows=[];selected={}
with tarfile.open(a) as tf:
    for member in tf:
        if not member.isfile() or not member.name.startswith('CTSM/src/') or not member.name.endswith('.F90'):continue
        if not any(name in member.name for name in ['SoilHydrology','SoilWaterMovement','HydrologyDrainage','WaterTable','DrainageMod','HydrologyMod']):continue
        raw=tf.extractfile(member).read();lines=raw.decode().splitlines();hits=[]
        for i,line in enumerate(lines):
            if re.search(r'\b(use_vichydro|qdrai|qdrai_perch|qover|qcharge|fbaseflow|baseflow_scalar|zwt|hkdepth|slope)\b',line,re.I):hits.append(i)
        rows.append(dict(path=member.name,sha256=sha(raw),lines=len(lines),matches=[dict(line=i+1,text=lines[i]) for i in hits]))
        selected[Path(member.name).name]=raw
case=b/'ctsm-qia-run-r/case-configuration-private.tar.gz'
with tarfile.open(case) as tf:
    member=tf.getmember('output/case/run/lnd_in');raw=tf.extractfile(member).read()
    (r/'lnd_in.original.txt').write_bytes(raw)
    namelist=dict(archive_sha256=sha(case.read_bytes()),member=member.name,sha256=sha(raw),hydrology_lines=[line for line in raw.decode().splitlines() if re.search('vic|hydro|water|baseflow|fmax|runoff|soil_layer|bedrock',line,re.I)])
for name,raw in selected.items():(r/name).write_bytes(raw)
record=dict(scope='Pinned original officialR hydrology source and actual generated lnd_in read for understanding only; source is not copied into project physics and no model/input/numerical execution here.',source_archive_sha256=sha(a.read_bytes()),namelist=namelist,rows=rows)
(r/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(files=[v['path'] for v in rows],namelist=namelist),indent=2))

"""Actual officialR output/initial-state numerical audit, PBS compute only."""
from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
from netCDF4 import Dataset
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-runoff-partition-b';sha=lambda raw:hashlib.sha256(raw).hexdigest()
root=b/'ctsm-qia-run-r';archive=root/'case-configuration-private.tar.gz'
assert sha(archive.read_bytes())=='14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0'
raw_arrays={};records={};selected={}
with tarfile.open(archive) as tf:
    for label,member in [('history','output/case/run/case.clm2.h0.2002-12-31-57600.nc'),
                         ('initial','inputdata/CN-Qia.official-interpolated-cold.nc'),
                         ('surface','inputdata/surfdata.CN-Qia.engineering.nc')]:
        raw=tf.extractfile(member).read();selected[label]=dict(member=member,sha256=sha(raw),bytes=len(raw))
        with Dataset('memory.nc',memory=raw) as nc:
            records[label]={};names=(['QRUNOFF','QOVER','QDRAI','QDRAI_PERCH','QH2OSFC','ZWT','ZWT_PERCH','WA','FSAT','FROST_TABLE','H2OSOI','RAIN','SNOW'] if label=='history' else
                ['zwt','zwt_perched','wa','h2osoi_liq','h2osoi_ice','watsat','hksat','sucsat','bsw','watmin','eff_porosity','fff','wtfact','topo_slope'] if label=='initial' else
                ['PCT_SAND','PCT_CLAY','ORGANIC','FMAX','SLOPE','STD_ELEV','SOIL_COLOR'])
            if label=='history':
                bounds=np.asarray(nc['time_bounds'][:],float)*86400.;assert np.max(abs(bounds-np.rint(bounds)))<=.01;bounds=np.rint(bounds).astype(np.int64)
                mask=(bounds[:,0]>=0)&(bounds[:,1]<=86400);assert mask.sum()==48
                np.testing.assert_array_equal(bounds[mask],np.arange(48)[:,None]*1800+[[0,1800]])
                raw_arrays['time_bounds_seconds']=bounds[mask]
            for name in names:
                if name not in nc.variables:records[label][name]=dict(status='unmeasured: absent actual field');continue
                var=nc[name];values=np.ma.asarray(var[:]);values=values[mask] if label=='history' else values
                masked=int(np.ma.getmaskarray(values).sum());finite=bool(np.isfinite(values.compressed()).all())
                entry=dict(status='measured' if masked==0 and finite else 'masked/nonfinite retained, not accepted',units=str(getattr(var,'units','unspecified')),
                    dimensions=list(var.dimensions),shape=list(values.shape),masked=masked,finite=finite)
                raw_arrays[label+'/'+name]=np.asarray(values.data);raw_arrays[label+'/'+name+'_mask']=np.ma.getmaskarray(values)
                if masked==0 and finite:
                    array=np.asarray(values,float)
                    entry.update(minimum=float(array.min()),maximum=float(array.max()),mean=float(array.mean()))
                    if array.size<=30:entry['values']=array.tolist()
                    if label=='history' and name in ('QRUNOFF','QOVER','QDRAI','QDRAI_PERCH','QH2OSFC','RAIN','SNOW'):
                        entry['first_day_integral_mm']=float(array.reshape(48,-1).mean(1).sum()*1800.)
                records[label][name]=entry
np.savez_compressed(r/'official-partition.npz',**raw_arrays)
scope='Pinned unchanged officialR actualfirst48 runoff split, groundwater/initial soil and originalsurface texture; originalmasks/absence/units retained. Archive/CFbins exact; no official or Python state/physics/forcing/parameter changes, no calibration/science acceptance.'
record=dict(scope=scope,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,case_archive_sha256=sha(archive.read_bytes()),
    reference_year_audit_sha256=sha((root/'year-boundary.json').read_bytes()),sources=selected,fields=records,partition_sha256=sha((r/'official-partition.npz').read_bytes()))
(r/'diagnosis.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(pbs_job=record['pbs_job'],history=records['history'],initial=records['initial'],surface=records['surface'])),flush=True)

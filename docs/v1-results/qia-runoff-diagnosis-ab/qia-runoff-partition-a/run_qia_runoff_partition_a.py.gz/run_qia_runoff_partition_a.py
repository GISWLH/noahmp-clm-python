"""Read-only tendency instrumentation of the unchanged successful535C cold48."""
from pathlib import Path
from dataclasses import asdict
from decimal import Decimal,localcontext
import hashlib,json,os,subprocess,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-runoff-partition-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();archive=b/'capacity-station-final-c-source.tar.gz'
assert sha(archive)=='7341089ec7d992674e0976272dd0b4940e082f9baa7b887649ee1d130a3b4fe5'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
manifest=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(manifest)==535 and all(sha(s/n)==h for n,h in manifest.items())
sys.path[:0]=[str(b/'test-deps'),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as station
import noahmp_clm.clm_enthalpy_driver as driver
original=b/'qia-capacity-firstday-d';prior=json.loads((original/'receipt.json').read_text())
assert (original/'pbs-exit.txt').read_text().strip()=='0' and prior['returncode']==0 and prior['source_unchanged'] and prior['steps_completed']==48
config=original/'config.json';assert sha(config)==json.loads((original/'launch.json').read_text())['configuration_sha256']
drains=[];steps=[];raw={};call_drain=driver.drain_soil;call_step=station.step_clm_enthalpy_column
def capture_drain(state,dt,**kwargs):
    # These copies only observe the original operator. No state/return field
    # is rewritten, and all original station traces must reproduce exactly.
    observed=dict(water_before=state.water.copy(),enthalpy_before=state.enthalpy.copy(),liquid_before=state.liquid.copy(),
        temperature_before=state.temperature.copy(),dz=state.dz.copy(),dt=float(dt),soil=asdict(state.params),
        permeability=kwargs.get('permeability_option',1),parameters=asdict(kwargs['bottom_parameters']) if kwargs.get('bottom_parameters') is not None else None)
    after,ledger=call_drain(state,dt,**kwargs)
    observed.update(water_after=after.water.copy(),enthalpy_after=after.enthalpy.copy(),**ledger);drains.append(observed)
    return after,ledger
def capture_step(state,forcing,**kwargs):
    before=len(drains);after,d=call_step(state,forcing,**kwargs);assert len(drains)==before+1
    steps.append({n:float(d[n]) for n in ['runoff_mm','runoff_surface_mm','runoff_deep_mm','bottom_outflow_kgm2',
        'bottom_outflow_enthalpy_jm2','runoff_enthalpy_jm2','et_mm','prcp_mm','water_residual_kgm2','energy_residual_jm2']})
    return after,d
driver.drain_soil=capture_drain;station.step_clm_enthalpy_column=capture_step
started=time.monotonic();input_root=b/'qia-stem-inputs-a/inputs'
report=station.run(input_root/'CN-Qia.npz',input_root/'CN-Qia.json',config,r/'trajectory',stop_after=48)
assert report['status']=='running' and report['steps_completed']==48 and len(steps)==len(drains)==48
prior_report=json.loads((original/'trajectory/report.json').read_text())
with np.load(original/'trajectory'/prior_report['model_npz'],allow_pickle=False) as a,np.load(r/'trajectory'/report['model_npz'],allow_pickle=False) as z:
    assert set(a.files)==set(z.files)
    for name in a.files:
        assert a[name].dtype==z[name].dtype and a[name].shape==z[name].shape and a[name].tobytes()==z[name].tobytes(),name
for index,(one,drain) in enumerate(zip(steps,drains)):
    assert one['bottom_outflow_kgm2']==drain['bottom_mass_kgm2']==one['runoff_deep_mm']
    assert abs(one['runoff_surface_mm']+one['runoff_deep_mm']-one['runoff_mm'])<1e-14
    p=drain['parameters'];assert p is not None
    # Independent Decimal evaluation from observed liquid, actual thickness,
    # frozen coefficient and explicit traits; never call arno_baseflow here.
    with localcontext() as ctx:
        ctx.prec=65
        D=lambda v:Decimal.from_float(float(v))
        liquid=D(drain['liquid_before'][-1]);water=D(drain['water_before'][-1]);capacity=D(1000.)*D(drain['soil']['smcmax'])*D(drain['dz'][-1])
        residual=D(p['residual_pore_fraction'])*capacity;available=max(Decimal(0),liquid-residual);wet=available/(capacity-residual)
        slope=D(p['baseflow_fraction'])/D(p['baseflow_threshold']);fraction=slope*wet
        if wet>D(p['baseflow_threshold']):fraction+=(1-slope)*((wet-D(p['baseflow_threshold']))/(1-D(p['baseflow_threshold'])))**D(p['baseflow_exponent'])
        expected=min(available,D(p['maximum_baseflow_mm_day'])*D(drain['dt'])/Decimal(86400)*fraction)
        if drain['permeability']==2:expected*=(-Decimal(7)*(water-liquid)/capacity).exp()
    one['independent_baseflow_mm']=float(expected);one['baseflow_error_mm']=abs(one['bottom_outflow_kgm2']-float(expected))
    assert one['baseflow_error_mm']<1e-12
    for name,value in drain.items():
        if isinstance(value,np.ndarray):raw.setdefault(name,[]).append(value)
    for name,value in one.items():raw.setdefault(name,[]).append(value)
np.savez_compressed(r/'partition.npz',**{n:np.asarray(v) for n,v in raw.items()})
total=lambda name:float(sum(v[name] for v in steps))
record=dict(scope='Unchanged535C capacity-only originalcold48, original forcing/config/stores/height/window; wrappers observe one actual drainage operator perstep and return original objects. Every original trace field dtype/shape/bytes exactly reproduces prior308. Independent Decimal baseflow check, originalMHCN station guards, no parameter/physics/gate changes; not newscience acceptance.',
    pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-started,source_unchanged=all(sha(s/n)==h for n,h in manifest.items()),
    source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),configuration_sha256=sha(config),prior_receipt_sha256=sha(original/'receipt.json'),
    original_traces_exact=True,steps=48,totals={n:total(n) for n in ['runoff_mm','runoff_surface_mm','runoff_deep_mm','bottom_outflow_kgm2','et_mm','prcp_mm','runoff_enthalpy_jm2']},
    actual_vic_parameters=drains[0]['parameters'],maximum_independent_arno_error_mm=max(v['baseflow_error_mm'] for v in steps),
    maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],partition_sha256=sha(r/'partition.npz'))
assert record['source_unchanged'];(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());station.atomic_json(r/'diagnosis.json',record)
print(json.dumps(record,default=station.encode),flush=True)

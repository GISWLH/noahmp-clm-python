from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-a';assert not s.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'pft-optics-final-a-source.tar.gz';package=json.loads((b/'pft-optics-final-a-package.json').read_text());assert sha(a)==package['archive_sha256']=='9756cdd1e82e618da5b836538ccd27ab842e09c669910b173493a502af855d91'
npref=json.loads((b/'pft-optics-numpy-b-receipt.json').read_text());assert npref['returncode']==0 and npref['counts']==dict(tests=103,failures=0,errors=0,skipped=0) and npref['source_unchanged'];assert sha(b/'pft-optics-numpy-b-receipt.json')==package['numpy_receipt_sha256']
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>6144
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());assert int(mem['MemAvailable'].split()[0])>12*1024*1024
s.mkdir()
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==518 and all(sha(s/n)==h for n,h in m.items());r=s/'targets-a';r.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
controls={n:sha(b/n) for n in ['launch_pft_optics_gpu_a.py','control_pft_optics_gpu_a.py','collect_pft_optics_gpu_a.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_pft_optics_gpu_a.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='Current518 native opticscomponent4 and originallegacy4/11 onGPU0;NumPy103/referencefixture preverified. Existing oldfullGPU1 and originalB annualF GPU0 retained,notkilled/reset. No fullGPU/year/science acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_memory_mib=free,source_archive_sha256=sha(a),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls,numpy_receipt_sha256=sha(b/'pft-optics-numpy-b-receipt.json'))
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

"""Independent partial-pressure reference; run only on an EHPC compute node."""
from pathlib import Path
import itertools,hashlib,json,math,os,time
import numpy as np
from scipy.optimize import brentq
from noahmp_clm.physics.photosynthesis import LeafParameters,farquhar_rates,leaf_gas_exchange
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'leaf-pressure-units-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
p=LeafParameters();pressures=[30000.,55000.,70000.,101325.,110000.]
protocol=dict(scope='Independent Pa-form equation check of existing mole-fraction equations; not field validation, new physics, or a claim that canopy pressure has no physical effect.',
    pressures_pa=pressures,coefficients='Bernacchi mole-fraction Kc/Ko/Gamma converted with the same ambient pressure as Ci and oxygen; existing default Gamma/O2 calibration held unchanged. No upstream code copied.',
    held_fixed='Molar conductance, mixing ratios, leaf temperature and capacities; actual canopy conductance/air density/humidity continue to depend on pressure.',
    original_model_source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),probe_sha256=sha(Path(__file__)),references=['https://onlinelibrary.wiley.com/doi/10.1111/j.1365-3040.2001.00668.x','https://raw.githubusercontent.com/ESCOMP/CTSM/release-clm5.0/src/biogeophys/PhotosynthesisMod.F90'],
    limitations='Official oxygen-specific Gamma uses reference mixing ratio0.209, while this model default is0.210 with fixedGamma25=42.75. This check isolates pressure/units and does not validate arbitrary oxygen changes.')
path=root/'protocol.json';assert not path.exists();path.write_text(json.dumps(protocol,indent=2)+'\n');start=time.monotonic()
def biochemical(ci_pa,par,t,pressure,nitrogen=1.):
    # Scalar equations in Pa, independent of production coefficient helpers.
    def activation(e):return math.exp(e/8.314462618*(1./298.15-1./t))
    def inhibition(e,h,s):return activation(e)*(1.+math.exp((298.15*s-h)/(8.314462618*298.15)))/(1.+math.exp((t*s-h)/(8.314462618*t)))
    vc=p.vcmax25*nitrogen*inhibition(72000.,200000.,668.39-1.07*25.)
    jm=p.jmax25*nitrogen*inhibition(50000.,200000.,659.70-.75*25.)
    tp=3.*p.tpu25*nitrogen*inhibition(72000.,200000.,668.39-1.07*25.)
    rd=p.respiration25*inhibition(46390.,150650.,490.)
    kc=404.9e-6*pressure*activation(79430.);ko=.2784*pressure*activation(36380.)
    gamma=42.75e-6*pressure*activation(37830.);oxygen=p.oxygen_ppm*1e-6*pressure
    incident=.5*p.quantum_yield_psii*par
    j=0. if incident==0. or jm==0. else 2.*incident*jm/(incident+jm+math.sqrt((incident+jm)**2-4.*p.curvature*incident*jm))
    difference=max(ci_pa-gamma,0.)
    ac=vc*difference/(ci_pa+kc*(1.+oxygen/ko));aj=j*difference/(4.*ci_pa+8.*gamma)
    return dict(net=min(ac,aj,tp)-rd,gross=min(ac,aj,tp),rubisco=ac,rubp=aj,tpu=tp,respiration=rd,electron_transport=j)
max_abs={k:0. for k in ['gross','net','rubisco','rubp','tpu','respiration','electron_transport']};cases=0;rows=[]
for pressure,t,ci,par,nitrogen in itertools.product(pressures,[268.,285.,298.15,315.],[20.,42.75,80.,280.,600.,1200.],[0.,25.,500.,1800.],[0.,.3,1.]):
    independent=biochemical(ci*pressure*1e-6,par,t,pressure,nitrogen)
    actual=farquhar_rates(ci,par,t,p,nitrogen_factor=nitrogen)
    for key in max_abs:
        error=abs(float(actual[key])-independent[key]);max_abs[key]=max(max_abs[key],error)
        assert error<=max(1e-10,1e-10*abs(independent[key]))
    cases+=1
    if t==298.15 and ci==280. and par==500. and nitrogen==1.:rows.append(dict(pressure_pa=pressure,pa_form=independent,production_net=float(actual['net'])))
coupled_errors={k:0. for k in ['net','ci_ppm','gs_mol','surface_relative_humidity']};coupled_cases=0
for pressure,t,ca,par,gb,rh,nitrogen,stress in itertools.product([30000.,70000.,110000.],[268.,298.15,315.],[280.,420.,800.],[0.,50.,1800.],[.1,2.],[.4,.8],[.3,1.],[.5,1.]):
    ca_pa=ca*pressure*1e-6
    def evaluate(ci_pa):
        rates=biochemical(ci_pa,par,t,pressure,nitrogen);a=rates['net']
        cs_pa=max(ca_pa-1.4*a*1e-6*pressure/gb,1e-9*pressure*1e-6)
        x=p.ball_berry_slope*max(a,0.)*1e-6*pressure*stress/cs_pa
        coefficients=[1.,gb-p.minimum_conductance-x,-gb*(p.minimum_conductance+x*min(rh,1.))]
        roots=np.roots(coefficients);gs=float(max(roots))
        residual=a-(ca_pa-ci_pa)/pressure*1e6/(1.4/gb+1.6/gs)
        return a,gs,(gb*min(rh,1.)+gs)/(gb+gs),residual
    rd=biochemical(ca_pa,par,t,pressure,nitrogen)['respiration']
    upper=(ca+rd*(1.4/gb+1.6/p.minimum_conductance)+1.)*pressure*1e-6
    ci_pa=brentq(lambda v:evaluate(v)[-1],0.,upper,xtol=1e-13,rtol=1e-14)
    a,gs,humidity,residual=evaluate(ci_pa)
    actual=leaf_gas_exchange(par,t,co2_ppm=ca,relative_humidity=rh,boundary_conductance=gb,parameters=p,nitrogen_factor=nitrogen,water_stress=stress)
    reference=dict(net=a,ci_ppm=ci_pa/pressure*1e6,gs_mol=gs,surface_relative_humidity=humidity)
    for key in coupled_errors:
        delta=abs(float(actual[key])-reference[key]);coupled_errors[key]=max(coupled_errors[key],delta)
        assert delta<=max(1e-8,1e-10*abs(reference[key]))
    coupled_cases+=1
assert all(sha(source/n)==v for n,v in m.items())
value=dict(protocol=protocol,biochemical_cases=cases,biochemical_max_absolute_differences=max_abs,coupled_cases=coupled_cases,coupled_max_absolute_differences=coupled_errors,fixed_molar_boundary_examples=rows,
    pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,source_files=len(m),source_unchanged=True,extra_pressure_factor_required=False,production_changed=False,scientific_acceptance_claim=False)
dest=root/'diagnostic.json';assert not dest.exists();dest.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in value.items() if k not in ['protocol','fixed_molar_boundary_examples']}),flush=True)

"""Read-only compute-node prerequisites for an official one-column reference."""
from pathlib import Path
import datetime,json,os,platform,shutil,subprocess,time,urllib.request
assert os.environ.get('PBS_JOBID');root=Path('/home/zhangyq/noahmp-v1/ctsm-reference-preflight-a');start=time.monotonic();rows=[]
for command in [['df','-h','/home/zhangyq/noahmp-v1','/tmp'],['df','-i','/home/zhangyq/noahmp-v1','/tmp'],['gcc','--version'],['gfortran','--version'],['g++','--version'],['cmake','--version'],['git','--version'],['make','--version'],['nc-config','--all'],['nf-config','--all'],['perl','-e','print "$^V\n"'],['bash','-lc','module -t avail 2>&1']]:
    try:
        p=subprocess.run(command,capture_output=True,text=True,timeout=10);rows.append(dict(command=command,returncode=p.returncode,output=(p.stdout+p.stderr)[:10000]))
    except (OSError,subprocess.TimeoutExpired) as e:rows.append(dict(command=command,error=type(e).__name__))
network=[]
for url in ['https://api.github.com/repos/ESCOMP/CTSM/commits/release-clm5.0','https://raw.githubusercontent.com/ESCOMP/CTSM/release-clm5.0/Externals_CLM.cfg','https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/lnd/clm2/']:
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Wang-CLM-single-column-reference-preflight'})
        with urllib.request.urlopen(req,timeout=10) as stream:data=stream.read(65536);code=stream.status
        name='upstream-commit.json' if '/commits/' in url else ('Externals_CLM.cfg' if url.endswith('.cfg') else 'inputdata-index.html')
        (root/name).write_bytes(data);network.append(dict(url=url,http_status=code,bytes=len(data),file=name))
    except Exception as e:network.append(dict(url=url,error=type(e).__name__,detail=str(e)[:240]))
value=dict(scope='Prerequisites/network metadata only for an independent official CTSM single-point reference; no model/build/whole-system coupling development or acceptance claim. Future build/run is intended for PBS node-local scratch.',pbs_job=os.environ['PBS_JOBID'],node=platform.node(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,commands=rows,network=network,
    available_tools={v:shutil.which(v) for v in ['mpif90','mpifort','nc-config','nf-config','ncdump','ncks','m4','autoconf','pkg-config','svn','curl','wget']},node_temp_directory=os.environ.get('TMPDIR'))
dest=root/'preflight.json';assert not dest.exists();dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
pressure=base/'leaf-pressure-units-a';r=json.loads((pressure/'diagnostic.json').read_text());assert r['pbs_job']=='105.manager' and r['source_unchanged'] and (pressure/'pbs-exit.txt').read_text().strip()=='0'
preflight=base/'ctsm-reference-preflight-a';p=json.loads((preflight/'preflight.json').read_text());assert p['pbs_job']=='106.manager' and (preflight/'pbs-exit.txt').read_text().strip()=='0'
pairs=[(pressure/n,'pressure/'+n) for n in ['probe_leaf_pressure_units_a.py','leaf_pressure_units_a.pbs','protocol.json','diagnostic.json','diagnostic.log','node.txt','pbs-exit.txt']]
pairs += [(preflight/n,'ctsm-preflight/'+n) for n in ['preflight_ctsm_reference_a.py','ctsm_reference_preflight_a.pbs','preflight.json','preflight.log','node.txt','pbs-exit.txt']]
pairs += [(source/'SOURCE_SHA256.json','SOURCE_SHA256.json'),(Path(__file__),'archive_leaf_pressure_preflight_a.py')]
archive=base/'leaf-pressure-ctsm-preflight-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for path,name in pairs:t.add(path,arcname=name,recursive=False)
print(json.dumps(dict(files=len(pairs),sha256=sha(archive),scope='EHPC PBS105 independent Pa/mole-fraction checks and PBS106 official reference prerequisite failures; no production/source change or official output/scientific acceptance claim.')))

from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'canopy-wet-references-ap';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-canopy-wet-native-am-source.tar.gz';assert sha(a)=='8bcc4cf54dcfc778e8d79b31ccb1dd5f1022e174a5b04695a6f2ba1a41b61663';start=time.monotonic()
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and all(sha(s/n)==h for n,h in m.items());prereq=b/'canopy-wet-numpy-akd';d=json.loads((prereq/'target-receipt.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=72,failures=0,errors=0,skipped=0)
old=json.loads((prereq/'SOURCE_SHA256.json').read_text());different={n for n in m if m[n]!=old[n]};assert different=={'src/noahmp_clm/gpu/canopy_interception.py','src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_interception_kernel.cu','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu'}
sys.path[:0]=[str(r),str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
from wet_reference_key_ap import reference_key
import test_gpu_canopy_interception as water
import test_gpu_canopy_phase_energy as phase
from noahmp_clm.physics.photosynthesis import LeafParameters
cache={};records=[];failure=None
def add(family,row,kwargs,label):
    key=reference_key(family,row,kwargs)
    if key in cache:records.append(dict(label=label,key=key,duplicate=True));return cache[key]
    result=water.reference(row) if family=='water' else phase.reference(row,**kwargs);frozen=copy.deepcopy(result)
    if family=='phase':
        state=result['condensate'];frozen['condensate']=SimpleNamespace(mass=state.mass.copy(),enthalpy=state.enthalpy.copy(),temperature=state.temperature.copy(),ice=state.ice.copy(),liquid=state.liquid.copy())
    cache[key]=frozen;records.append(dict(label=label,key=key,duplicate=False));return frozen
def encode(value):
    if isinstance(value,np.ndarray):return dict(__array__=encode(value.tolist()),dtype=str(value.dtype),shape=list(value.shape))
    if isinstance(value,np.generic):return encode(value.item())
    if isinstance(value,(tuple,list)):return [encode(x) for x in value]
    if isinstance(value,dict):return {k:encode(v) for k,v in value.items()}
    if isinstance(value,float) and not np.isfinite(value):return dict(__float__=repr(value))
    return value
try:
    for dtype in [np.float32,np.float64]:
        for family,module in [('water',water),('phase',phase)]:
            arrays=module.cases(dtype) if family=='water' else module.batch(dtype)
            for k,row in enumerate(zip(*arrays)):add(family,tuple(row),{},family+str(np.dtype(dtype))+':'+str(k))
    for name in ['canopy_phase_humidity_bound.json','canopy_phase_humidity_slow.json']:
        v=json.loads((s/'tests/fixtures'/name).read_text());row=tuple(np.asarray(x,np.int32 if k==8 else np.float64) for k,x in enumerate(v['arrays']));add('phase',row,dict(tolerance=1e-7),'humidity:'+name)
    for name in ['qia_479_phase_jacobian.npz','phase_edge_float64_stencil.npz']:
        with np.load(s/'tests/fixtures'/name,allow_pickle=False) as z:row=tuple(z['a'+str(k)] for k in range(9));extension=z['extension']
        add('phase',row,dict(exchange_extension=extension,tolerance=1e-7,max_iterations=80),'float64-jacobian:'+name)
    updated=r/'updated-fixtures';updated.mkdir();updates=[]
    for name in ['qia_735_phase_oldwet.json','qia_1110_phase_kink.json']:
        path=s/'tests/fixtures'/name;document=json.loads(path.read_text());history={}
        for precision in ['32','64']:
            case=phase.oldwet_case(precision,name);kwargs=dict(exchange_extension=case['extension'],leaf_parameters=LeafParameters(*np.asarray(case['parameters'],float)),tolerance=1e-7,max_iterations=80);result=add('phase',tuple(case['arrays']),kwargs,'saved-existing:'+name+':'+precision);q=document['quantized'][precision];history[precision]={k:copy.deepcopy(q[k]) for k in ['reference','reference_mass','reference_enthalpy']}
            q['reference']=encode({key:result[key] for key in case['reference']});q['reference_mass']=encode(result['condensate'].mass);q['reference_enthalpy']=encode(result['condensate'].enthalpy)
        document['wet_area_reference_update']=dict(maximum_leaf_wetted_fraction=.05,original_fixture_sha256=sha(path),reference_generation_source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),historical_cap1_reference=history,scope='Only reference outputs refreshed for actualCLM5 wetarea.05; original rejected input arrays/parameters/MOSTextension bytevalues and original physical/numerical gates unchanged. Originalcap1 values retained here and in oldsource. NumPy reference solved onlyEHPC.')
        target=updated/name;target.write_text(json.dumps(document,indent=2,allow_nan=False)+'\n');updates.append(dict(file=name,original_sha256=sha(path),updated_sha256=sha(target)))
except Exception as err:
    failure=type(err).__name__+': '+str(err);(r/'traceback.txt').write_text(traceback.format_exc())
(r/'references.pkl').write_bytes(pickle.dumps(cache,protocol=5));record=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),reference_model_and_test_bytes_sha256={n:h for n,h in m.items() if n.startswith('src/') or n in ['tests/test_gpu_canopy_interception.py','tests/test_gpu_canopy_phase_energy.py','tests/test_canopy_phase_energy.py','tests/test_gpu_snicar.py']},keys=len(cache),requested_records=records,reference_pickle_sha256=sha(r/'references.pkl'),updated_fixtures=updates if failure is None else None,seconds=time.monotonic()-start,scope='CPUcompute originalunmodifiedNumPy wetarea.05 reference solves, ALL typedwater/phase batches and originalhumidity/jacobian/existingwater cases; exact input/control signatures, original residual gates. Own trustedpickle only after SHA binding, frozenreferencecontainers avoid NumPyforward onGPUhost. Refresh cachedfixture expectedoutputs only, retain originalcap1 expectedvalues and alloriginalinputs. No GPU or canonical/year/science acceptance.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(failure=failure,keys=len(cache),seconds=record['seconds'])),flush=True);assert failure is None and record['source_unchanged']

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-numpy-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'receipt.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=28,failures=0,errors=0,skipped=0)
assert (r/'pbs-exit.txt').read_text().strip()=='0' and sha(r/'tests.xml')==d['xml_sha256'] and sha(r/'SOURCE_SHA256.json')==d['source_manifest_sha256']
s=b/'richards-numpy-c-source.tar.gz';assert sha(s)=='ae2cbfb94669326fcb0efa0d5ea9ce30a128214813112fafd59f8741a6f08a9b'
a=b/'richards-numpy-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['dispatch_richards_numpy_c.py',Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(s,arcname='source/'+s.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

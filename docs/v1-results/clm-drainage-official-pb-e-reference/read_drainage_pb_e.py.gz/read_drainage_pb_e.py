"""Stdlib-only excerpt of actual PB-e PBS readout; no numerical execution."""
import json
import socket
import subprocess
import tarfile
from pathlib import Path
assert socket.gethostname()=='manager'
root=Path('/tmp/noahmp-clm-drainage-official-pb-e')
if not (root/'result.tar.gz').exists():
    subprocess.run(['scp','compute002:'+str(root/'result.tar.gz'),str(root/'result.tar.gz')],check=True)
with tarfile.open(root/'result.tar.gz') as tar:
    d=json.load(tar.extractfile('comparison/comparisons.json'))
out={k:d[k] for k in ('main_refinement_vs_reused_pb_d','perched_refinement_vs_unchanged_pb_c','pb_perched')}
(root/'refinement-readout.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

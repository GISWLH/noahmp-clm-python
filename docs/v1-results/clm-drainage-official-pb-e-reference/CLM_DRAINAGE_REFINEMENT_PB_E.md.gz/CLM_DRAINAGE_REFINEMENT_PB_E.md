# PB-e unchanged-physics refinement

Actual EHPC 1616.manager worker completed with parent exit 0 in 31.74144559 s;
the numerical comparison subprocess took 4.71930746 s. Final packaging requires
real F0/Stageout0. Six new original caller processes executed 596 drainage steps.
The same frozen PB-c module performed one perched integration and one frozen-rate
trial. The prior actual PB-d main integration is reused by exact archive/member
identity, and the original three small official profiles were not rerun.

For the two-day connected unfrozen main front, original 64/256-step third-layer
exports are 1.069849678 / 0.906665594 kg/m2 versus the reused PB value
0.874887723. The respective relative differences are -18.2233036% / -3.5049164%.
At 256 steps the second-layer difference is +0.0808452%, total outflow difference
+0.00435191%, and migrated-front absolute difference 0.000328300 m. All four
layer exports meet the existing 10% or .001 kg/m2 absolute comparison there.
Zero exports retain null relative differences. Coarse 64-step failure is retained;
this is convergence evidence, not parameter fitting or a redefined criterion.

The perched fixture remains the explicitly extreme 10 m/s conductivity stress
case. Unchanged PB-c exports [0,8.249848429,13.385717194,0] kg/m2, total
21.635565622. The original caller totals at 1/4/16/64/192 steps are
277.760544290 / 118.571875701 / 38.647722742 / 25.413724507 / 21.334863463.
At 192 steps its second/third donor exports are 9.542278072 / 11.792585391;
PB differences are -13.5442463% / +13.5096058%. **These layer comparisons remain
unclosed** even though the total differs by only +1.4094403%. The 192-step choice
preserves exact integer 450 s steps over the same 86400 s interval.

Three mechanisms are now distinguishable:

- A single frozen-rate PB trial requests 474.287424521 kg/m2 but its geometric
  capacity limits removal to 106.431259495. This is not the actual adaptive run.
- The adaptive run accepts 105 substeps, rejects 4, has zero geometric-cap or
  unavailable-liquid limitation, and ends at migrated front 0.602666673 m.
  Its second and third donors switch as the retained front crosses an interface.
- PB transports donor enthalpy and re-equilibrates phase. Third-layer T changes
  270 to 267.755206525 K and ice 137.219455710 to 129.770703014 kg/m2. The original
  hydrology-only calls retain supplied T and ice. Thus the remaining comparison
  combines temporal/spatial drainage differences with different thermal boundary
  conditions; it cannot alone justify changing the donor rule.

PB's actual water residual is 8.88178420e-15 against 2.01794137e-11 kg/m2;
heat residual 4.65661287e-9 against 6.07506063e-6 J/m2. No artificial water,
constant-temperature heat source or ice overwrite was imposed. Its final theta
diagnosis reports no perched saturated band, while its retained interval front
is separately reported. The original final diagnosis also gives perched=frost
1.25 m. These diagnostics are not substituted for the prognostic interval front.

The next minimal hydraulic diagnostic can retain immutable initial T/ice only
inside an explicitly separate test harness, with no claim of a closed thermal
system. Alternatively original public calls need the same inter-step phase
update and actual donor heat accounting before a full coupled comparison.
The current 13.5% residual remains visible; no supply rule was tuned to the
coarse original step. Backend preparation may use the verified diagnosis,
constitutive stencils and connected-main scope while that boundary is resolved.

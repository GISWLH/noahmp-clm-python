"""EHPC-only original-library boundary readback. Differences are evidence, not failures."""
from pathlib import Path
import json
import hashlib
import math
import os
import socket
import subprocess
import sys

assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
from noahmp_clm.physics.snowpack import LF,CW,TF
import saturated_drainage_pb as pb


def save(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')


def real_state(theta,temperature,satdk=1.e-5):
    p=SoilParams(satdk=satdk);dz=np.full(4,.5);w=np.array(theta)*1000.*dz
    return SoilEnthalpyState(w,enthalpy_and_capacity(w,np.array(temperature),dz,p)[0],dz,p)


def records(raw):
    result=[]; rediag=None
    for line in raw.decode().splitlines():
        if not line.startswith('PB_OFFICIAL_'):continue
        words=line.split();key=words[0].removeprefix('PB_OFFICIAL_')
        if key=='STEP':
            result.append(dict(step=int(words[1]),clock_step=int(words[2])))
        elif key=='FINAL_REDIAG':rediag=[float(v) for v in words[1:]]
        else:
            assert result and key not in result[-1]
            result[-1][key]=[float(v) for v in words[1:]]
    assert rediag is not None
    return result,rediag


root,exe=Path(sys.argv[1]),Path(sys.argv[2]);root.mkdir(exist_ok=False)
prior_path=Path(__file__).resolve().parent/'reference-pb-d-comparisons.json'
binding=json.loads((prior_path.parent/'REFERENCE_BINDINGS.json').read_text())
assert hashlib.sha256(prior_path.read_bytes()).hexdigest()==binding['original_member_sha256']
prior=json.loads(prior_path.read_bytes())
profiles=[]
for nsteps in (64,256):
    original=next(r['spec'] for r in prior['profiles'] if r['name']=='main_crosslayer_1')
    profiles.append(dict(original,name='main_crosslayer_'+str(nsteps),dt=172800//nsteps,nsteps=nsteps))
for nsteps in (4,16,64,192):
    original=next(r['spec'] for r in prior['profiles'] if r['name']=='perched_cross_donors_exhausted')
    assert 86400 % nsteps == 0
    profiles.append(dict(original,name='perched_cross_donors_'+str(nsteps),dt=86400//nsteps,nsteps=nsteps))
rows=[]
for spec in profiles:
    here=root/spec['name'];here.mkdir()
    if 'theta' in spec:
        state=real_state(spec['theta'],spec['temperature'],spec['satdk'])
        liquid,ice,temperature=state.liquid,state.ice,state.temperature
    else:
        liquid,ice,temperature=[np.array(spec[k],float) for k in ('liquid','ice','temperature')]
    dt=spec['dt'];slope=.2
    lines=[f"{dt} {math.degrees(slope):.17g} {spec['baseflow']:.17g} {spec['nsteps']}"]
    for j in range(4):
        lines.append(' '.join(format(float(v),'.17g') for v in
            (.5,.45,5.5,355.,spec['satdk']*1000.,liquid[j],ice[j],temperature[j])))
    fixture=here/'fixture.txt';fixture.write_text('\n'.join(lines)+'\n')
    save(here/'profile.json',spec)
    result=subprocess.run([str(exe),str(fixture)],cwd=here,capture_output=True,timeout=30)
    (here/'official.stdout.txt').write_bytes(result.stdout);(here/'official.stderr.txt').write_bytes(result.stderr)
    save(here/'official-exit.json',dict(actual_parent_returncode=result.returncode))
    assert result.returncode==0,result.stderr.decode(errors='replace')
    steps,rediag=records(result.stdout)
    assert len(steps)==spec['nsteps']
    np.testing.assert_array_equal(steps[0]['INITIAL_LIQ'],liquid)
    np.testing.assert_array_equal(steps[0]['INITIAL_ICE'],ice)
    independent=[]
    for i,one in enumerate(steps):
        assert one['step']==i+1
        assert all(math.isfinite(x) for k,v in one.items() if isinstance(v,list) for x in v)
        np.testing.assert_array_equal(one['TEMPERATURE'],temperature)
        if i:
            assert one['clock_step']==steps[i-1]['clock_step']+1
            for initial,final in [('INITIAL_LIQ','FINAL_LIQ'),('INITIAL_ICE','FINAL_ICE')]:
                np.testing.assert_array_equal(one[initial],steps[i-1][final])
            np.testing.assert_array_equal(one['INITIAL_OTHER'],steps[i-1]['OTHER'][:3])
        # q_drain already includes q_rsub_sat: never count it twice.
        # qcharge is printed as an internal diagnostic, not an external flux.
        initial=[*one['INITIAL_LIQ'],*one['INITIAL_ICE'],*one['INITIAL_OTHER'][:2]]
        final=[*one['FINAL_LIQ'],*one['FINAL_ICE'],*one['OTHER'][:2]]
        outlet=dt*(one['PERCHED'][0]+one['MAIN'][0]+one['OTHER'][4]+one['OTHER'][5])
        residual=math.fsum([*final,*(-v for v in initial),outlet])
        bound=128.*np.finfo(float).eps*max(math.fsum(abs(v) for v in initial+final)+abs(outlet),1.)
        assert abs(residual)<=bound,(spec['name'],residual,bound)
        perch=np.array(one['INITIAL_LIQ'])-one['AFTER_PERCH_LIQ']
        main_change=np.array(one['AFTER_PERCH_LIQ'])-one['FINAL_LIQ']
        correction_active=(one['INITIAL_OTHER']!=one['OTHER'][:3] or any(x!=0. for x in one['OTHER'][3:])
            or one['INITIAL_ICE']!=one['FINAL_ICE'])
        independent.append(dict(step=i+1,water_residual_kg_m2=residual,water_bound_kg_m2=bound,
            reported_perched_outlet_kg_m2=dt*one['PERCHED'][0],reported_drain_kg_m2=dt*one['MAIN'][0],
            rsub_sat_included_in_drain_kg_m2=dt*one['OTHER'][3],ice_outlet_kg_m2=dt*one['OTHER'][4],
            qrgwl_outlet_kg_m2=dt*one['OTHER'][5],surface_stock_change_kg_m2=one['OTHER'][0]-one['INITIAL_OTHER'][0],
            WA_stock_change_kg_m2=one['OTHER'][1]-one['INITIAL_OTHER'][1],qcharge_before_after=[one['INITIAL_OTHER'][2],one['OTHER'][2]],
            actual_perched_layer_export_kg_m2=perch.tolist(),
            independent_perched_donor_heat_j_m2=(perch*(LF+CW*(temperature-TF))).tolist(),
            post_perch_to_final_net_liquid_change_kg_m2=main_change.tolist(),
            main_change_not_asserted_export_when_corrected=bool(correction_active),correction_channels_active=bool(correction_active),
            negative_drain_is_correction_compensation_not_aquifer_supply=bool(one['MAIN'][0]<0.)))
    row=dict(name=spec['name'],spec=spec,official_parent_returncode=0,steps=steps,independent_water_ledger=independent,
        total_reported_perched_kg_m2=math.fsum(x['reported_perched_outlet_kg_m2'] for x in independent),
        total_reported_drain_kg_m2=math.fsum(x['reported_drain_kg_m2'] for x in independent),
        final_liquid_kg_m2=steps[-1]['FINAL_LIQ'],final_ice_kg_m2=steps[-1]['FINAL_ICE'],
        final_reported_migrating_main_front_m=steps[-1]['MAIN'][1],final_reported_migrating_perched_front_m=steps[-1]['PERCHED'][1],
        final_rediagnosed_theta_main_perched_frost_m=rediag,
        heat_scope='Only actual pre/post-perch donor mass times fixed supplied donor T; original hydrology has no energy equation. Corrected main layer changes are not labelled donor heat.')
    save(here/'readout.json',row);rows.append(row)

# Reuse the actual original PB-d main integration, including its raw stocks.
main_reference=prior['unfrozen_discrete_step_comparison'][0]
main=[]
for row in rows[:2]:
    original_final=np.array(row['final_liquid_kg_m2'])+row['final_ice_kg_m2']
    pb_final=np.array(main_reference['pb_final_water'])
    original_mass=225.-original_final
    pb_mass=225.-pb_final
    error=pb_mass-original_mass
    main.append(dict(official_steps=row['spec']['nsteps'],official_dt=row['spec']['dt'],
        original_official_front_m=row['final_reported_migrating_main_front_m'],
        pb_front_m=main_reference['pb_front_m'],
        front_absolute_difference_m=abs(row['final_reported_migrating_main_front_m']-main_reference['pb_front_m']),
        original_official_layer_export_kg_m2=original_mass.tolist(),
        pb_layer_export_from_original_stock_kg_m2=pb_mass.tolist(),layer_export_difference_kg_m2=error.tolist(),
        layer_export_relative_difference=[None if abs(v)<.01 else float(e/v) for e,v in zip(error,original_mass)],
        layer_export_within_10pct_or_abs_001=[bool(abs(e)<=max(.001,.1*abs(v))) for e,v in zip(error,original_mass)],
        original_official_total_kg_m2=row['total_reported_drain_kg_m2'],pb_total_kg_m2=main_reference['pb_total_kg_m2'],
        total_relative_difference=main_reference['pb_total_kg_m2']/row['total_reported_drain_kg_m2']-1.))

# Pair the very same frozen PB-c implementation with the already observed
# perched stress initial profile. No coefficient, cap or donor code changes.
original=next(r for r in prior['profiles'] if r['name']=='perched_cross_donors_exhausted')
spec=original['spec'];s=real_state(spec['theta'],spec['temperature'],spec['satdk'])
np.testing.assert_array_equal(s.liquid,original['steps'][0]['INITIAL_LIQ'])
np.testing.assert_array_equal(s.ice,original['steps'][0]['INITIAL_ICE'])
parameters=pb.DrainageParameters(2.,.2,baseflow_mm_s_per_m=0.)
diag=pb.diagnose_water_tables(s,parameters);front=diag['perched_water_table_m'];bottom=diag['frost_table_m']
q,geometry=pb.potential_outflow(s,front,bottom,'perched',parameters)
sy=pb.specific_yield(diag['water_table_m'],s.params.smcmax,s.params.saturated_suction_m,s.params.bexp,.02)
frozen,frozen_z,trial=pb._perched_transfer(s,front,bottom,86400.,parameters)
after,z,ledger=pb.advance_saturated_band(s,86400.,front,bottom,'perched',parameters)
assert abs(ledger['water_residual_kg_m2'])<=ledger['water_bound_kg_m2']
assert abs(ledger['energy_residual_j_m2'])<=ledger['energy_bound_j_m2']
perched=[]
for row in [original,*rows[2:]]:
    original_mass=np.array(row['steps'][0]['INITIAL_LIQ'])-np.array(row['final_liquid_kg_m2'])
    error=ledger['layer_mass_kg_m2']-original_mass
    perched.append(dict(official_steps=row['spec']['nsteps'],official_dt=row['spec']['dt'],
        original_official_layer_export_kg_m2=original_mass.tolist(),pb_actual_layer_export_kg_m2=ledger['layer_mass_kg_m2'].tolist(),
        layer_export_difference_kg_m2=error.tolist(),
        layer_export_relative_difference=[None if abs(v)<.01 else float(e/v) for e,v in zip(error,original_mass)],
        original_official_total_kg_m2=row['total_reported_perched_kg_m2'],pb_actual_total_kg_m2=ledger['drained_kg_m2'],
        total_relative_difference=ledger['drained_kg_m2']/row['total_reported_perched_kg_m2']-1.,
        original_official_migrated_front_m=row['final_reported_migrating_perched_front_m'],pb_migrated_front_m=z,
        original_final_rediagnosed_main_perched_frost_m=row['final_rediagnosed_theta_main_perched_frost_m']))

def plain(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,(np.integer,np.floating,np.bool_)):return v.item()
    if isinstance(v,dict):return {k:plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    return v
result=dict(execution_succeeded=True,profiles=rows,main_refinement_vs_reused_pb_d=main,
    perched_refinement_vs_unchanged_pb_c=perched,
    pb_perched=dict(initial_diagnosis=plain(diag),initial_rate_kg_m2_s=q,initial_rate_geometry=plain(geometry),
        Sy_at_main_depth=sy,initial_geometric_capacity_kg_m2=1000.*sy*(bottom-front),
        initial_available_per_layer_kg_m2=np.maximum(s.liquid-.01,0.).tolist(),
        initial_liquid=s.liquid.tolist(),initial_ice=s.ice.tolist(),initial_temperature_k=s.temperature.tolist(),
        frozen_rate_trial=plain(trial),frozen_rate_final_front_m=frozen_z,
        adaptive_ledger=plain(ledger),final_water=after.water.tolist(),final_liquid=after.liquid.tolist(),
        final_ice=after.ice.tolist(),final_temperature_k=after.temperature.tolist(),
        final_diagnosis=plain(pb.diagnose_water_tables(after,parameters))),
    original_reference_archive_sha256=binding['original_reference_archive_sha256'],
    unchanged_pb_c_sha256=binding['unchanged_pb_c_sha256'],official_processes=6,official_drainage_steps=596,
    numpy_component_integrations=1,numpy_frozen_rate_trials=1,coupled_column_runs=0,physical_acceptance=False,
    scope='Fixed extreme-Ks mechanism stress; official hydrology retains supplied temperature and phase per drainage step, whereas PB transports enthalpy and re-equilibrates. Disclose this before assigning residual differences to drainage code. No new parameter fit or full-column acceptance.')
save(root/'comparisons.json',result)
print(json.dumps(dict(execution_succeeded=True,profiles=6,official_drainage_steps=596,numpy_component_integrations=1,numpy_frozen_rate_trials=1)))

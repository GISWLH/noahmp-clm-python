# PB-e fixed-profile refinement and perched pairing

Only six new original-library calls: main two-day profile at 64/256 steps;
the original extreme-Ks one-day perched profile at 4/16/64/192 steps. The last
count keeps the actual original integer clock step at 450 seconds; 86400/256
would not be an integer and is not silently rounded. No original three-profile
case, PB-d one-step case or prior PB main integration is rerun.

Unchanged PB-c is run once for the perched interval and once as a frozen-rate
trial. The latter exposes the geometric-cap and initial donor response without
editing the implementation. Each output includes actual stocks, phase,
temperature, per-layer donor mass/heat, fronts, limitations and hard budgets.
The original library's every-step channel audit, raw caller outputs and real
clock remain as in PB-d; only the bounded step-count limit increases.

The perched conductivity of 10 m/s is a deliberate mechanism stress input,
not a common soil parameter or scientific acceptance target. A frozen-rate
official hydrology call does not run its thermal model; its supplied T and ice
remain unchanged. PB advects actual donor enthalpy and re-equilibrates phase.
These states must be reported separately before attributing residual differences
to cap/donor logic. No virtual watmin water/heat or excess-pore state enters PB.

The prior PB-d source archive, raw comparison member, and frozen PB-c module
are hash-bound. Real comparison failures remain results, not pytest failures
or suppressed rows. Near-zero outflows retain the .001 kg/m2 absolute allowance
and null relative diagnostics below .01 kg/m2. No GPU/production/annual change.

from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,time,xml.etree.ElementTree as ET
import numpy as np
root=Path.cwd();base=root.parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in m.items())
old=base/'p6-hrldas-native-year-b';oldm=json.loads((old/'SOURCE_SHA256.json').read_text())
diff=[k for k in m if k.startswith('src/') and oldm.get(k)!=m[k]]
assert diff==['src/noahmp_clm/__init__.py','src/noahmp_clm/driver.py']
def legacy_body(path):
    text=Path(path).read_text();return text[text.index('    if state.options.OptDynamicVeg!=4:'):text.index('    return s, diag')+len('    return s, diag')]
assert legacy_body(old/'src/noahmp_clm/driver.py')==legacy_body(root/'src/noahmp_clm/driver.py')
begin=time.monotonic();files=['tests/test_public_clm_driver.py','tests/test_column.py']
code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml=public-target.xml']).returncode
counts={k:sum(int(s.attrib[k]) for s in ET.parse('public-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
summary=None
if code==0:
    state,forcing,ds,final=runpy.run_path(str(root/'examples/run_clm_column.py'))['example']()
    inputs=np.array([sum(f.prcp*f.dt*1000.-d['et_mm']-d['runoff_mm'] for f,d in zip(forcing,ds)),
        sum(d['precipitation_enthalpy_jm2']+(f.swdown+f.lwdown-d['outgoing_shortwave']-d['outgoing_longwave']-d['h']-d['le'])*f.dt-d['advected_enthalpy_jm2']-d['runoff_enthalpy_jm2'] for f,d in zip(forcing,ds)),
        -sum(d['nee_gc_m2'] for d in ds),len(ds)*1e-5])
    totals=lambda s:np.array([s.water_kgm2,s.enthalpy_jm2,s.carbon_gc_m2,s.nitrogen_gn_m2])
    residual=totals(final)-totals(state)-inputs
    limits=np.array([1e-9,.02,sum(d['biogeochemistry']['carbon_bound_gc_m2'] for d in ds),sum(d['biogeochemistry']['nitrogen_bound_gn_m2'] for d in ds)])
    assert np.isfinite(residual).all() and np.all(abs(residual)<=limits)
    summary=dict(scope='Explicit illustrative cold-start 3-step public CLM example, not scientific acceptance',steps=len(ds),et_mm=sum(d['et_mm'] for d in ds),gpp_gc_m2=sum(d['gpp_gc_m2'] for d in ds),nee_gc_m2=sum(d['nee_gc_m2'] for d in ds),lai=final.lai,
        residual_m_h_c_n=residual.tolist(),bounds_m_h_c_n=limits.tolist(),rain_snow_option=final.options.OptRainSnowPartition,runoff_surface_option=final.options.OptRunoffSurface,most_feedback=True)
assert all(sha(root/k)==v for k,v in m.items())
(root/'public-target-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begin,counts=counts,source_files=len(m),source_unchanged=True,node=os.uname().nodename,pbs_job=os.environ['PBS_JOBID'],runtime_source_differences=diff,legacy_physics_body_byte_equivalent=True,all_other_172_runtime_files_identical=True,files=files,example=summary),indent=2)+'\n')
assert code==0 and counts['failures']==counts['errors']==counts['skipped']==0 and summary is not None

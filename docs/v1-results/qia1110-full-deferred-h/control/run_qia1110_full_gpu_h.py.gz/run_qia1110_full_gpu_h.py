from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'qia1110-final-h'
r = s / 'full-by-file-h'
r.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
begun = time.monotonic()

def verify():
    assert len(m) == 519 and all(sha(s / n) == v for n, v in m.items())

def nodes(raw):
    result = []
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(k) is None for k in ['failure', 'error', 'skipped'])
        parts = c.attrib['classname'].split('.')
        where = [i for i, n in enumerate(parts) if n.startswith('test_')]
        assert len(where) == 1
        i = where[0]
        result.append('tests/' + parts[i] + '.py::' + '::'.join(parts[i+1:] + [c.attrib['name']]))
    assert len(result) == len(set(result))
    return set(result)

verify()
with (r / 'collection.log').open('x') as log:
    code = subprocess.run([sys.executable, '-u', str(b / 'collect_qia1110_full_gpu_h.py')], cwd=s, stdout=log, stderr=subprocess.STDOUT).returncode
assert code == 0
collection = json.loads((r / 'collection.json').read_text())
allnodes = set(collection['nodes'])
assert len(allnodes) == 1297 and collection['source_unchanged'] and collection['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json')
gpu = {n for n in allnodes if Path(n.split('::')[0]).name.startswith(('test_gpu', 'test_jax', 'test_cuda'))}
cpu = allnodes - gpu
assert len(cpu) == 943 and len(gpu) == 354

archives = {}
for label, digest in [('qia1110-cpu-final-h', '5ec4f1160f94f7264077437bc1cb9a5e1aaeec6967ea99654742283ffd4ed491'), ('qia1110-gpu-target-h', '304a499b61f5f7ca87adc671a71849980127743f994e34ad06c2f251a7927814')]:
    path = b / (label + '-evidence.tar.gz')
    assert sha(path) == digest
    with tarfile.open(path) as t:
        archives[label] = {v.name: t.extractfile(v).read() for v in t if v.isfile()}
a, g = archives['qia1110-cpu-final-h'], archives['qia1110-gpu-target-h']
g={n.split('/',1)[1] if n.startswith('target-h/') else n:raw for n,raw in g.items()}
assert json.loads(a['SOURCE_SHA256.json']) == json.loads(g['SOURCE_SHA256.json']) == m
cpu_receipt = json.loads(a['receipt.json'])
assert cpu_receipt['returncode'] == 0 and cpu_receipt['source_unchanged'] and cpu_receipt['counts'] == dict(tests=943, failures=0, errors=0, skipped=0)
assert nodes(a['cpu-full.xml']) == cpu and hashlib.sha256(a['cpu-full.xml']).hexdigest() == cpu_receipt['xml_sha256']
rec = json.loads(g['receipt.json'])
exit_record = json.loads(g['exit.json'])
prefix = nodes(g['targets.xml'])
file = 'tests/test_gpu_canopy_phase_energy.py'
assert prefix == {n for n in gpu if n.split('::')[0] == file} and len(prefix) == 14
assert exit_record['passed'] and exit_record['returncode'] == rec['worker_exitcode'] == rec['pytest_returncode'] == 0 and hashlib.sha256(g['receipt.json']).hexdigest() == exit_record['receipt_sha256']
assert rec['passed'] and rec['source_unchanged'] and rec['all_setup_call_teardown_phases_passed'] and rec['node_coverage_exact'] and rec['counts'] == dict(tests=14, failures=0, errors=0, skipped=0)
assert rec['test_sha256'] == m[file] and rec['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and hashlib.sha256(g['targets.xml']).hexdigest() == rec['xml_sha256']
covered = cpu | prefix
worker = b / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
assert sha(worker) == '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
pending = sorted({n.split('::')[0] for n in gpu} - {file}, key=lambda n: ('_column' in n or 'surface' in n, n))
scope = 'Frozen519H exactcanonical1297: EHPC943/currentphase14, remaining340GPU after actualpredecessor exits. Originalsetup/call/teardown/barriers/raw1e-6/int/MHCN/atexit disclosure retained. No oldD/511/506 test credit; not year/spinup/science acceptance.'
(r / 'selection.json').write_text(json.dumps(dict(scope=scope, collected_nodes=sorted(allnodes), cpu_nodes=943, gpu_nodes=354, same_source_gpu_prefix_nodes=sorted(prefix), pending_files=pending, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json')), indent=2) + '\n')
results = []

def save(active=None):
    d = dict(scope=scope, status='running', covered_nodes=len(covered), covered_gpu_nodes=len(covered) - 943, collected_nodes=1297, active=active, results=results, seconds=time.monotonic() - begun)
    tmp = r / 'progress.json.tmp'
    tmp.write_text(json.dumps(d, indent=2) + '\n')
    os.replace(tmp, r / 'progress.json')

save()
for file in pending:
    verify()
    name = Path(file).stem
    expected = {n for n in gpu if n.split('::')[0] == file}
    expected_path = r / (name + '-expected.json')
    expected_path.write_text(json.dumps(sorted(Path(n.split('::')[0]).name + '::' + n.split('::', 1)[1] for n in expected), indent=2) + '\n')
    receipt_path, xml = r / (name + '-receipt.json'), r / (name + '.xml')
    start = time.monotonic()
    with (r / (name + '.log')).open('x') as log:
        p = subprocess.Popen([sys.executable, '-u', str(worker), '--source', str(s), '--test-file', str(s / file), '--expected', str(expected_path), '--receipt', str(receipt_path), '--xml', str(xml)], cwd=s, stdout=log, stderr=subprocess.STDOUT)
        save(dict(file=file, pid=p.pid))
        code = p.wait()
    row = dict(file=file, pid=p.pid, returncode=code, seconds=time.monotonic() - start, passed=False)
    if receipt_path.exists():
        rec = json.loads(receipt_path.read_text())
        row['receipt'] = rec
        if code == rec['worker_exitcode'] == rec['pytest_returncode'] == 0 and rec['passed'] and rec['source_unchanged'] and rec['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and rec['test_sha256'] == m[file] and rec['xml_sha256'] == sha(xml) and nodes(xml.read_bytes()) == expected:
            row['passed'] = True
            covered.update(expected)
    results.append(row)
    save()
    print(json.dumps({k: v for k, v in row.items() if k != 'receipt'}), flush=True)
verify()
complete = covered == allnodes and all(x['passed'] for x in results)
(r / 'summary.json').write_text(json.dumps(dict(scope=scope, status='complete' if complete else 'failed', source_unchanged=True, collected_nodes=1297, covered_nodes=len(covered), all_node_coverage_exact=covered == allnodes, results=results, same_source_gpu_prefix_nodes=sorted(prefix), seconds=time.monotonic() - begun), indent=2) + '\n')
raise SystemExit(0 if complete else 1)

from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=s/'full-controller-h';launch=json.loads((r/'launch.json').read_text());old=b/'pft-optics-final-d/full-controller-e/exit.json';jax=b/'qia1110-full-jax32-h/exit.json'
while not old.exists() or not jax.exists():
    if not old.exists():assert Path('/proc/3585561').exists(),'Original D controller missing without actualexit'
    if not jax.exists():assert Path('/proc/3649672').exists(),'Original JAX1110 controller missing without actualexit'
    time.sleep(30)
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines())
    if free>6144 and int(mem['MemAvailable'].split()[0])>12*1024*1024:break
    time.sleep(30)
for n,h in launch['controls_sha256'].items():assert hashlib.sha256((b/n).read_bytes()).hexdigest()==h
with (r/'full.log').open('x') as f:p=subprocess.Popen([sys.executable,'-u',str(b/'run_qia1110_full_gpu_h.py')],cwd=s,stdout=f,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=0,predecessor_exit=json.loads(old.read_text()),jax1110_exit=json.loads(jax.read_text()),scope='Actual fullcurrent519H execution, collected943CPU354GPU with same-source943/14prereqs;not scientific acceptance.'),indent=2)+'\n')
code=p.wait();(r/'exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(code)

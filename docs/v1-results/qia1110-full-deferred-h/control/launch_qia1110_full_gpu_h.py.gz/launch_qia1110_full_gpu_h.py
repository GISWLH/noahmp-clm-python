from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=s/'full-controller-h';assert not r.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and all(sha(s/n)==h for n,h in m.items())
for label,digest in [('qia1110-cpu-final-h','5ec4f1160f94f7264077437bc1cb9a5e1aaeec6967ea99654742283ffd4ed491'),('qia1110-gpu-target-h','304a499b61f5f7ca87adc671a71849980127743f994e34ad06c2f251a7927814')]:
    a=b/(label+'-evidence.tar.gz');assert sha(a)==digest
    with tarfile.open(a) as t:
        assert json.load(t.extractfile('SOURCE_SHA256.json'))==m
        if 'cpu' in label:
            rec=json.load(t.extractfile('receipt.json'));assert rec['returncode']==0 and rec['counts']==dict(tests=943,failures=0,errors=0,skipped=0) and rec['source_unchanged']
        else:assert json.load(t.extractfile('target-h/exit.json'))['passed']
controls={n:sha(b/n) for n in ['launch_qia1110_full_gpu_h.py','wait_qia1110_full_gpu_h.py','run_qia1110_full_gpu_h.py','collect_qia1110_full_gpu_h.py']};r.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
d=dict(scope='Deferredcurrent519H canonical1297=943CPU354GPU: same-source943CPU/14GPU prerequisites actual0, remaining340GPU after actualD full andJAX1110 exits. No existing coordinator/model/worker signaled. Queueing not fullcollection/completion/year/science pass.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=0,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls,wait_for_actual_exits=[str(b/'pft-optics-final-d/full-controller-e/exit.json'),str(b/'qia1110-full-jax32-h/exit.json')]);(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n')
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'wait_qia1110_full_gpu_h.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d['pid']=p.pid;(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import datetime,hashlib,io,json,os,sys,tarfile
mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='cpu':
    b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-kink-numpy-year-h';names=['launch.json','SOURCE_SHA256.json','dispatch.json','node.txt','controller.log','model.log','run_qia_kink_numpy_year_h.py','qia_kink_numpy_year_h.pbs'];control=['dispatch_qia_kink_numpy_year_h.py'];name='qia-kink-numpy-year-launch-h';files=[('year/'+n,r/n) for n in names if (r/n).exists()]
    if (r/'trajectory/report.json').exists():files.append(('year/report.json',r/'trajectory/report.json'))
    record=dict(scope='Live originalcold519H NumPy295 launch snapshot, no failed1110 state resumed. Queue/running report not full17520/spinup/sciencepass; sourcechecks performedinsidePBS,not loginreadingcomputeTMPDIR.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pbs_job=json.loads((r/'dispatch.json').read_text())['pbs_job'])
else:
    assert mode=='gpu';b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=s/'full-controller-h';files=[];name='qia1110-full-deferred-h'
    for root in [r,b/'qia1110-full-jax32-h']:
        for p in sorted(root.rglob('*')):
            if p.is_file():files.append((p.relative_to(b).as_posix(),p))
    files.append(('SOURCE_SHA256.json',s/'SOURCE_SHA256.json'));control=['launch_qia1110_full_gpu_h.py','wait_qia1110_full_gpu_h.py','run_qia1110_full_gpu_h.py','collect_qia1110_full_gpu_h.py','run_qia1110_full_h.py','control_qia1110_full_h.py','launch_qia1110_full_h.py']
    record=dict(scope='Actual519H canonical1297 queued after originalD actualfull/JAX1110 exits, original943CPU/phase14 prerequisites. JAX1110 state captured aslive, not completed/pairpass. No oldmodel/worker stopped, no fullcanonical/year/science acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),canonical_worker_started=(r/'worker.json').exists(),jax_actual_exit_present=(b/'qia1110-full-jax32-h/exit.json').exists())
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n,p in files:t.add(p,arcname=n,recursive=False)
    for n in control:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    raw=(json.dumps(record,indent=2)+'\n').encode();i=tarfile.TarInfo('snapshot.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,snapshot=record)))

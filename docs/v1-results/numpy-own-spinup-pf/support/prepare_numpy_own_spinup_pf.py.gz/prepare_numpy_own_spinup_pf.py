"""Freeze PF adapters and existing authorities with stdlib only; no model import."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

BASE = Path(__file__).resolve().parent
OUT = BASE / 'numpy-own-spinup-pf-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    pb = BASE / 'numpy-training-chain-pb-preparation'
    raw = (pb / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(raw) == '165913db4fd39f10c47d174b74c42f8f877216c347fe46535489c5ecc013e7be'
    (OUT / 'pb').mkdir(exist_ok=True)
    for name in [*json.loads(raw), 'CONTROLS_SHA256.json']:
        body = (pb / name).read_bytes()
        if name != 'CONTROLS_SHA256.json':
            assert sha(body) == json.loads(raw)[name]
        (OUT / 'pb' / name).write_bytes(body)
    source = BASE / 'climatology-final-candidate-nm-source.tar.gz'
    assert sha(source.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    with tarfile.open(source) as archive:
        manifest = json.loads(archive.extractfile('SOURCE_SHA256.json').read())
        assert len(manifest) == 584 and all(sha(archive.extractfile(n).read()) == h for n, h in manifest.items())
        original = archive.extractfile('benchmarks/assess_clm_spinup.py').read()
    node = next(n.value for n in ast.parse(original).body if isinstance(n, ast.Assign)
                and any(isinstance(x, ast.Name) and x.id == 'LIMITS' for x in n.targets))
    limits = {k.arg: ast.literal_eval(k.value) for k in node.keywords}
    op = BASE / 'spinup-seed-comparison-op-preparation'
    op_binding = json.loads((op / 'BINDINGS.json').read_bytes())
    op_index = json.loads((op / 'CONTROLS_SHA256.json').read_bytes())
    op_code = (op / 'seed_pairs_op.py').read_bytes()
    assert sha(op_code) == op_index['seed_pairs_op.py']
    (OUT / 'seed_pairs_op.py').write_bytes(op_code)
    budget = (BASE / 'numpy-score-adapter-preparation/cpu_trace_budget.py').read_bytes()
    assert sha(budget) == '7563c0cfc98ce77aa04e51eb27ba1143c7976648f439193533273725bbcc3a57'
    (OUT / 'cpu_trace_budget.py').write_bytes(budget)
    pa = BASE / 'training-chain-pa-evidence.tar.gz'
    assert sha(pa.read_bytes()) == 'a5a6c49284f675d16824c9e7c24e68548840ba4c20b7a490e405923a1d95f7d9'
    with tarfile.open(pa) as archive:
        assembled = {n.removeprefix('current/assembly/'): archive.extractfile(n).read()
                     for n in archive.getnames() if n.startswith('current/assembly/') and archive.getmember(n).isfile()}
    assert len(assembled) == 245
    plan = json.loads(assembled['CHAIN_PLAN.json'])
    registry = json.loads((pb / 'IDENTITIES.json').read_bytes())
    for row in registry['configurations']:
        name = 'configs/' + row['candidate'] + '/' + row['case'] + '.json'
        assert sha(assembled[name]) == row['configuration_sha256']
    fixed = dict(PB_preparation_manifest_sha256=sha(raw),
        PB_actual_closed_package_sha256=sha((BASE / 'numpy-training-chain-pb-evidence.tar.gz').read_bytes()),
        source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
        source_archive_sha256=sha(source.read_bytes()), PA_archive_sha256=sha(pa.read_bytes()),
        PA_assembly_files_sha256={n: sha(b) for n, b in assembled.items()},
        original_case_order=plan['original_case_order'], original_limits=limits,
        training_pairs=[p for p in op_binding['pairs'] if p['site'] in ('CN-Cng', 'CN-Qia')],
        original_assessor_sha256=sha(original), original_OP_seed_pairs_sha256=sha(op_code),
        shared_cpu_trace_budget_sha256=sha(budget), initialization_kind='original_OM_nominal_cold',
        bounded_execution_plan=dict(
            preparation=dict(own_nominal_zero_states=184, new_physical_short_steps=2, maximum_wall_seconds=600,
                             cpus=1, memory_gib=2, gpu_steps=0),
            next_baseline_resource_probe=dict(candidate='om-baseline', roots=8, maximum_intervals_per_root=48,
                total_tendency_cap=384, maximum_concurrent_jobs=8, cpus_per_job=1, memory_gib_per_job=2,
                maximum_wall_seconds_per_job=1800, automatic_retry_count=0),
            next_own_initialization_driver=dict(candidate='om-baseline', roots=8, full_first_year_intervals=17520,
                total_tendency_cap=140160, maximum_concurrent_jobs=8, cpus_per_job=1, memory_gib_per_job=2,
                maximum_wall_seconds_per_job=259200, automatic_retry_count=0,
                prerequisite='Exact explicitly selected source/config/init identities plus the original successful short resource and recording checks; no observational-score gate.',
                normal_bgc_stream_required=True, states_of_other_parameters_get_no_credit=True),
            eventual_recipe=dict(candidates=23, roots_per_candidate=8,
                maximum_initialization_cycles=20, maximum_spinup_cycles_before_train1=20,
                complete_training_years=2, column_year_cap=4048, original_halfhour_tendency_cap=70929792,
                extra_initialization_branches_not_free=True, automatically_scheduled=False),
            scope='Finite phase limits, not an ETA or authorization token. No user approval flag. Exact source/init adoption and scientific feedback evidence remain actual work. All retries/failures consume budget; no automatic expansion.'),
        unresolved_scientific_and_budget_requirements=[
            'Candidate-specific normal coupled SOC/plant/seasonal-feedback validation window and criterion are not yet fixed or observed.',
            'Annualized SOC drift is diagnostic; original assessor does not certify long-term equilibrium from it.',
            'Any adopted SOC-derived initial inventory or new physical source requires an explicit new source/config/initialization identity contract.'])
    (OUT / 'BINDINGS_PF.json').write_text(json.dumps(fixed, indent=2) + '\n')
    controls = {p.relative_to(OUT).as_posix(): sha(p.read_bytes()) for p in sorted(OUT.rglob('*'))
                if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    controls['pb/CONTROLS_SHA256.json'] = sha(raw)
    for name in controls:
        if name.endswith('.py'):
            ast.parse((OUT / name).read_bytes())
    (OUT / 'CONTROLS_SHA256.json').write_text(json.dumps(controls, indent=2) + '\n')
    tests = [n.name for n in ast.walk(ast.parse((OUT / 'test_own_spinup_pf.py').read_bytes()))
             if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    result = dict(passed=True, controls=len(controls), controls_manifest_sha256=sha((OUT / 'CONTROLS_SHA256.json').read_bytes()),
                  source_files=584, PA_assembly_files=245, own_configuration_identities=184,
                  test_methods=len(tests), tests=tests, local_numpy_imported=False, physical_tendencies=0,
                  original_functions_used=['assess_clm_spinup.compare_endpoints', 'assess_clm_spinup.observed_carbon_century', 'seed_pairs_op.compare_seed_endpoints'])
    (BASE / 'numpy-own-spinup-pf-static.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

"""Freeze one bounded PF stage; stdlib metadata only, no test/model imports."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE / 'numpy-own-spinup-pf-preparation'
EXEC = BASE / 'numpy-own-spinup-pf-execution'
EXPECTED = '32ca64c70a5705f2bd4ae9c78c9c549cc5f553d1a6da153b8a20b041baedf08b'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def main():
    prep_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(prep_raw) == EXPECTED
    prep = json.loads(prep_raw)
    assert len(prep) == 16 and all(sha((PREP / n).read_bytes()) == h for n, h in prep.items())
    fixed = json.loads((PREP / 'BINDINGS_PF.json').read_bytes())
    dump(EXEC / 'RUN_BINDINGS.json', dict(expected_tests=13, expected_original_tendencies=2,
        expected_nominal_cold_states=184, preparation_manifest_sha256=EXPECTED,
        source_manifest_sha256=fixed['source_manifest_sha256'], source_archive_sha256=fixed['source_archive_sha256'],
        scope='Root authorized EHPC short tests/own state construction, not an annual candidate or accepted spinup.'))
    controls = {name: sha((EXEC / name).read_bytes()) for name in
                ['run_tests_pf.py', 'dispatch_tests_pf.py', 'tests_pf.pbs', 'RUN_BINDINGS.json']}
    dump(EXEC / 'CONTROLS_SHA256.json', controls)
    for name in controls:
        if name.endswith('.py'):
            ast.parse((EXEC / name).read_bytes())
    lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(EXEC), str(Path(__file__))],
                          capture_output=True, text=True)
    assert lint.returncode == 0, lint.stdout + lint.stderr
    files = {'preparation/' + n: (PREP / n).read_bytes() for n in [*prep, 'CONTROLS_SHA256.json']}
    files.update({'execution/' + n: (EXEC / n).read_bytes() for n in [*controls, 'CONTROLS_SHA256.json']})
    for name, digest in [('climatology-final-candidate-nm-source.tar.gz', fixed['source_archive_sha256']),
                         ('training-chain-pa-evidence.tar.gz', fixed['PA_archive_sha256']),
                         ('numpy-training-chain-pb-evidence.tar.gz', fixed['PB_actual_closed_package_sha256'])]:
        raw = (BASE / name).read_bytes()
        assert sha(raw) == digest
        files['inputs/' + name] = raw
    files['preparation-static.json'] = (BASE / 'numpy-own-spinup-pf-static.json').read_bytes()
    index = {n: sha(raw) for n, raw in files.items()}
    files['stage-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
    target = BASE / 'numpy-own-spinup-pf-stage.tar.gz'
    assert not target.exists(), 'Do not replace a deployed attempt'
    with tarfile.open(target, 'w:gz') as archive:
        for name, raw in sorted(files.items()):
            item = tarfile.TarInfo(name)
            item.size = len(raw)
            archive.addfile(item, io.BytesIO(raw))
    with tarfile.open(target) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive} == files
    record = dict(stage_archive=target.name, stage_archive_sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
        members=len(files), preparation_manifest_sha256=EXPECTED,
        execution_manifest_sha256=sha((EXEC / 'CONTROLS_SHA256.json').read_bytes()), stage_inventory=index,
        resource_request='1CPU/2GiB/10min/compute002', AST_passed=True, actual_ruff_exit=lint.returncode,
        model_executed=False, tests_executed=False, submitted=False,
        scope='Prepared short-test stage; actual result is separate; no annual candidate execution.')
    dump(BASE / 'numpy-own-spinup-pf-execution-preparation.json', record)
    print(json.dumps({k: record[k] for k in ('stage_archive', 'stage_archive_sha256', 'bytes', 'members', 'execution_manifest_sha256')}))


if __name__ == '__main__':
    main()

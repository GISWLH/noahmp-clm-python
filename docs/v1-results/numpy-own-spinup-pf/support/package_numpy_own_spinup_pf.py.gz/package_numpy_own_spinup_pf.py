"""Flat PF evidence and original actual F0; stdlib only, never read pickle/NPZ."""
from pathlib import Path
import ast
import base64
import hashlib
import io
import json
import re
import tarfile

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    data = {}
    result_path = BASE / 'numpy-own-spinup-pf-result-1619.tar.gz'
    with tarfile.open(result_path) as archive:
        members = [m for m in archive if m.isfile()]
        assert len({m.name for m in members}) == len(members)
        for member in members:
            name = member.name.removeprefix('./')
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            data['current/' + name] = archive.extractfile(member).read()
    result_members = {n.removeprefix('current/'): sha(b) for n, b in data.items()}
    for node in ('manager', 'compute002'):
        raw = (BASE / 'numpy-own-spinup-pf-actual' / (node + '.json')).read_bytes()
        record = json.loads(raw)
        assert record['node'] == node
        data['actual/' + node + '-metadata.json'] = raw
        for row in record['rows']:
            if row['present']:
                raw = base64.b64decode(row['base64'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                data['actual/' + node + '/' + row['name']] = raw
    qstat = data['actual/manager/qstat.stdout.txt'].decode()
    assert re.search(r'^Job Id: 1619\.manager$', qstat, re.M)
    for key, value in [('job_state', 'F'), ('Exit_status', '0'), ('Stageout_status', '0')]:
        assert re.search(r'^\s*' + key + r' = ' + value + '$', qstat, re.M)
    assert data['actual/compute002/pbs-exit.txt'].strip() == data['current/worker-exit.txt'].strip() == b'0'
    receipt = json.loads(data['current/receipt.json'])
    assert receipt['passed'] is True and receipt['error'] is None and receipt['test_parent_returncode'] == 0
    assert receipt['actual_test_count'] == 13 and receipt['actual_original_cpu_tendencies'] == 2
    assert receipt['actual_nominal_cold_seeds'] == 184 and receipt['source_before_after_584_exact']
    assert receipt['preparation_manifest_sha256'] == '32ca64c70a5705f2bd4ae9c78c9c549cc5f553d1a6da153b8a20b041baedf08b'
    prep_raw = data['current/preparation/CONTROLS_SHA256.json']
    assert sha(prep_raw) == receipt['preparation_manifest_sha256']
    assert all(sha(data['current/preparation/' + n]) == h for n, h in json.loads(prep_raw).items())
    names = [n.name for n in ast.walk(ast.parse(data['current/preparation/test_own_spinup_pf.py']))
             if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    statuses = re.findall(r'^(test\w+) \([^\n]+\) \.\.\. (.+)$', data['current/unittest.stderr.txt'].decode(), re.M)
    assert len(statuses) == 13 and {n for n, _ in statuses} == set(names) and all(s == 'ok' for _, s in statuses)
    cold = json.loads(data['current/own-init-output/own-cold-inventory.json'])
    assert len(cold) == 184 and len({(r['candidate'], r['case']) for r in cold}) == 184
    for row in cold:
        folder = 'current/own-init-output/own-cold/' + row['candidate'] + '/' + row['case'] + '/'
        assert sha(data[folder + 'own-cold-state.pkl']) == row['proof']['checkpoint_sha256']
        assert sha(data[folder + 'OWN_COLD_SEED.json']) == row['proof']['sidecar_sha256']
        assert sha(data[folder + 'configuration.json']) == row['seed']['configuration_sha256']
        assert row['proof']['comparison']['max_abs_difference'] == 0. and row['proof']['score_eligible'] is False
    capture = json.loads(data['current/own-init-output/bgc-capture-comparison.json'])
    assert sha(data['current/own-init-output/bgc-capture-comparison.json']) == receipt['capture_comparison_sha256']
    assert capture['actual_new_original_tendencies'] == capture['complete_bgc_records'] == 2
    assert capture['actual_reference_reruns'] == capture['original_bgc_and_kwargs_max_abs_difference'] == 0
    assert len(capture['trace']) == 18 and capture['state']['max_abs_difference'] == 0.
    assert all(r['max_abs_difference'] == 0. for r in capture['trace'].values())
    for name in ['prepare_numpy_own_spinup_pf.py', 'prepare_numpy_own_spinup_pf_execution.py',
                 'collect_numpy_own_spinup_pf_metadata.py', 'package_numpy_own_spinup_pf.py',
                 'numpy-own-spinup-pf-static.json', 'numpy-own-spinup-pf-execution-preparation.json']:
        data['support/' + name] = (BASE / name).read_bytes()
    with tarfile.open(BASE / 'numpy-own-spinup-pf-stage.tar.gz') as archive:
        stage_index = json.loads(archive.extractfile('stage-inventory.json').read())
        assert all(sha(archive.extractfile(n).read()) == h for n, h in stage_index.items())
        data['stage-inventory.json'] = archive.extractfile('stage-inventory.json').read()
    data['SOURCE_REFERENCES.json'] = js(dict(
        raw_result=dict(file=result_path.name, sha256=sha(result_path.read_bytes()), members=result_members),
        raw_stage=dict(file='numpy-own-spinup-pf-stage.tar.gz', sha256='3599ffd31280974f707a54d0410449a2d8bc098046f48cedc41d7568e7f5ee79'),
        published_input_archives={n: h for n, h in stage_index.items() if n.startswith('inputs/')},
        scope='All original result files flat and byteexact. Unchanged NM/PA/PB source/input packages remain full-SHA references.'))
    data['RESULTS.md'] = ('# PF 实际结果\n\n'
        'EHPC compute002，1619.manager 实际 F0/Stageout0，worker0、unittest 子进程0。13项全部 ok、零skip，18.145 s；worker18.657780073 s，子峰RSS81716 KiB。\n\n'
        '184个候选×原case的名义冷态实际构造并各自独立重建，保持原配置、矿质氮2 gN/m2和零累计账。总构造386次包含独立检查与synthetic fixture；这些构造没有物理时间推进。所有184状态逐类型/字段/数组位/标量位/alias相同，最大差0。\n\n'
        '仅新增原NumPy物理2步。BGC记录器完整保留2步before/after、原诊断和kwargs，与原PB档案比较最大差0；整七元状态及18原trace逐字段完全相同，最大差0，无参考重跑。潜在N需求与实际吸收分别留存，沉降保持原interval量。\n\n'
        '16个完整日历packet是显式constant-state parser fixtures，其receipt/call计数和scheduler文本为synthetic，不是实际年。原PB1607继续是F1；1612只读闭合不能替代真实父成功。当前实际全年0、被接受spinup0、评分0、GPU步0。NM584与全部冻结源/输入前后原样。\n\n'
        '有限排期上限为20初始化年+2训练年，23×8根条件上限4048柱年/70929792半小时步。不是运行完成、年度速度估计或守恒/SOC豁免；新增初始化分支和失败重试另记真实预算，不自动扩展。\n').encode()
    data['INTEGRITY.json'] = js({n: sha(b) for n, b in sorted(data.items())})
    path = BASE / 'numpy-own-spinup-pf-evidence.tar.gz'
    assert not path.exists()
    with tarfile.open(path, 'w:gz') as archive:
        for name, raw in sorted(data.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            archive.addfile(member, io.BytesIO(raw))
    with tarfile.open(path) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive} == data
    package = dict(archive=path.name, sha256=sha(path.read_bytes()), bytes=path.stat().st_size,
        artifacts=len(data), inventory_files=len(data)-1, passed=True, pbs_job='1619.manager',
        pbs_state='F', pbs_exit=0, stageout=0, worker_exit=0, child_exit=0,
        actual_tests=13, skipped=0, actual_test_seconds=18.145, own_nominal_cold_states=184,
        independent_cold_state_comparisons=184, all_constructor_calls=386,
        new_original_tendencies=2, reference_reruns=0, complete_bgc_records=2,
        exact_trace_fields=18, max_abs_state_trace_bgc_difference=0.,
        synthetic_full_calendar_packets=16, actual_field_years=0, accepted_spinup=False, GPU_steps=0,
        preparation_manifest_sha256=receipt['preparation_manifest_sha256'],
        scope='Actual own nominal state construction and two-step capture test; no annual/accepted spinup/candidate score.')
    (BASE / 'numpy-own-spinup-pf-package.json').write_bytes(js(package))
    print(json.dumps(package))


if __name__ == '__main__':
    main()

# PF 实际结果

EHPC compute002，1619.manager 实际 F0/Stageout0，worker0、unittest 子进程0。13项全部 ok、零skip，18.145 s；worker18.657780073 s，子峰RSS81716 KiB。

184个候选×原case的名义冷态实际构造并各自独立重建，保持原配置、矿质氮2 gN/m2和零累计账。总构造386次包含独立检查与synthetic fixture；这些构造没有物理时间推进。所有184状态逐类型/字段/数组位/标量位/alias相同，最大差0。

仅新增原NumPy物理2步。BGC记录器完整保留2步before/after、原诊断和kwargs，与原PB档案比较最大差0；整七元状态及18原trace逐字段完全相同，最大差0，无参考重跑。潜在N需求与实际吸收分别留存，沉降保持原interval量。

16个完整日历packet是显式constant-state parser fixtures，其receipt/call计数和scheduler文本为synthetic，不是实际年。原PB1607继续是F1；1612只读闭合不能替代真实父成功。当前实际全年0、被接受spinup0、评分0、GPU步0。NM584与全部冻结源/输入前后原样。

有限排期上限为20初始化年+2训练年，23×8根条件上限4048柱年/70929792半小时步。不是运行完成、年度速度估计或守恒/SOC豁免；新增初始化分支和失败重试另记真实预算，不自动扩展。

"""Own nominal CPU cold seeds and complete-cycle lineage; no physical scheduler."""
from pathlib import Path
import importlib.util
import io
import json
import pickle
import re
import sys
import tarfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'pb'))
import chain_contract_pb as contract
import numpy_chain_pb as adapter

require, sha = contract.require, contract.sha


def bindings():
    return json.loads((HERE / 'BINDINGS_PF.json').read_bytes())


def verify_controls():
    manifest = json.loads((HERE / 'CONTROLS_SHA256.json').read_bytes())
    require(all(sha((HERE / n).read_bytes()) == h for n, h in manifest.items()), 'PF controls changed')
    fixed = bindings()
    require(sha((HERE / 'pb/CONTROLS_SHA256.json').read_bytes()) == fixed['PB_preparation_manifest_sha256'],
            'Original validated PB adapter identity changed')
    require(Path(adapter.__file__).resolve() == HERE / 'pb/numpy_chain_pb.py', 'Different PB already imported')
    return sha((HERE / 'CONTROLS_SHA256.json').read_bytes())


def runtime(source):
    verify_controls()
    runner = adapter.load_runtime(source)
    path = Path(source).resolve() / 'benchmarks/assess_clm_spinup.py'
    spec = importlib.util.spec_from_file_location('_pf_original_assessor', path)
    assessor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(assessor)
    spec = importlib.util.spec_from_file_location('_pf_original_pairs', HERE / 'seed_pairs_op.py')
    pairs = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pairs)
    require(assessor.LIMITS == bindings()['original_limits'], 'Original convergence expressions/limits changed')
    return runner, assessor, pairs


def candidate_rows(candidate):
    registry = contract.registry()
    require(type(candidate) is str and candidate in registry['candidate_order'], 'Unknown candidate')
    rows = {r['case']: r for r in registry['configurations'] if r['candidate'] == candidate}
    order = bindings()['original_case_order']
    require(len(rows) == 8 and set(rows) == set(order), 'All eight original roots are mandatory')
    return [rows[name] for name in order]


def read_assembly(archive):
    """Reuse sealed PA245 exact files; never regenerate or normalize OM configs."""
    fixed = bindings()
    require(sha(Path(archive).read_bytes()) == fixed['PA_archive_sha256'], 'Original PA1603 archive changed')
    with tarfile.open(archive) as tar:
        result = {n.removeprefix('current/assembly/'): tar.extractfile(n).read()
                  for n in tar.getnames() if n.startswith('current/assembly/') and tar.getmember(n).isfile()}
    require({n: sha(b) for n, b in result.items()} == fixed['PA_assembly_files_sha256'], 'Original assembly bytes changed')
    return result


def original_configuration(assembly, candidate, case):
    identity = contract.request(candidate, case, 'spinup', 1)
    raw = assembly['configs/' + candidate + '/' + case + '.json']
    return raw, contract.validate_configuration(raw, identity), identity


def _save(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def make_own_cold_seed(runner, assembly, candidate, case, destination):
    """Materialize an explicit new nominal zero state; never inherit a parent."""
    raw, config, identity = original_configuration(assembly, candidate, case)
    state = runner.build_state(config)
    np = runner.np
    saved = (state, runner.totals(state), np.zeros(4), np.zeros(4), np.zeros(4), np.zeros(4), 0)
    seed = pickle.dumps(saved)  # same default protocol as unchanged original runner
    destination = Path(destination)
    require(not destination.exists(), 'Preserve existing cold seeds')
    destination.mkdir(parents=True)
    _save(destination / 'configuration.json', raw)
    _save(destination / 'own-cold-state.pkl', seed)
    record = dict(initialization_kind='original_OM_nominal_cold', identity=identity,
        source_manifest_sha256=identity['source_manifest_sha256'], configuration_sha256=sha(raw),
        checkpoint_sha256=sha(seed), initial_totals_m_h_c_n=saved[1].tolist(),
        local_index=0, global_ledger_steps=0, inherited_parent=None,
        inventory_adjustment_flux=False, original_mineral_nitrogen=config['biogeochemistry']['soil_state']['mineral_nitrogen'],
        actual_physical_steps=0, spinup_accepted=False, score_eligible=False,
        description='New original-constructor state; not an original runner report, elapsed year, SOC solution or inherited endpoint.')
    _save(destination / 'OWN_COLD_SEED.json', contract.json_bytes(record))
    return record


def verify_own_cold_seed(runner, assembly, candidate, case, directory):
    raw, config, identity = original_configuration(assembly, candidate, case)
    root = Path(directory)
    record = contract.read_json(root / 'OWN_COLD_SEED.json')
    require(record['identity'] == identity and record['initialization_kind'] == 'original_OM_nominal_cold',
            'Cold seed is not this candidate/original case')
    require((root / 'configuration.json').read_bytes() == raw and record['configuration_sha256'] == sha(raw),
            'Cold configuration differs from original OM')
    require(record['inherited_parent'] is None and type(record['local_index']) is type(record['global_ledger_steps']) is int
            and record['local_index'] == record['global_ledger_steps'] == 0
            and record['inventory_adjustment_flux'] is False and record['spinup_accepted'] is False
            and record['score_eligible'] is False and type(record['actual_physical_steps']) is int
            and record['actual_physical_steps'] == 0 and record['source_manifest_sha256'] == identity['source_manifest_sha256']
            and record['original_mineral_nitrogen'] == config['biogeochemistry']['soil_state']['mineral_nitrogen'],
            'Nominal zero seed cannot claim carried ledger or spinup')
    payload = (root / 'own-cold-state.pkl').read_bytes()
    require(sha(payload) == record['checkpoint_sha256'], 'Cold checkpoint changed')
    saved = pickle.loads(payload)
    require(type(saved) is tuple and len(saved) == 7 and type(saved[-1]) is int and saved[-1] == 0,
            'Original seven-tuple zero checkpoint required')
    expected_state = runner.build_state(config)
    np = runner.np
    expected = (expected_state, runner.totals(expected_state), np.zeros(4), np.zeros(4), np.zeros(4), np.zeros(4), 0)
    comparison = adapter.assert_content_exact(saved, expected, np)
    require(saved[1].tolist() == record['initial_totals_m_h_c_n'], 'Cold extensive inventory mismatch')
    return dict(identity=identity, own_nominal_initialization_verified=True,
                checkpoint_sha256=sha(payload), sidecar_sha256=sha((root / 'OWN_COLD_SEED.json').read_bytes()),
                comparison=comparison, spinup_accepted=False, score_eligible=False)


def frame(state):
    """Original NumPy state properties: no GPU packing or altered decoder."""
    result = dict(soil_temperature_k=state.ground.temperature,
        soil_water_m3m3=state.ground.water / (1000. * state.ground.dz),
        swe_m=state.snow.swe, soil_carbon_gc_m2=state.bgc_state.soil.carbon)
    if state.canopy_structure_parameters is not None:
        result['canopy_sai_m2m2'] = state.sai
    return result


def closed_packet(descriptor):
    """A complete export plus actual scheduler bytes, not caller passed flags."""
    require(set(descriptor) == {'directory', 'inventory_sha256', 'run', 'terminals'}, 'Closed cycle descriptor schema differs')
    root = Path(descriptor['directory']).resolve()
    inventory_raw = (root / 'ARTIFACT_SHA256.json').read_bytes()
    require(sha(inventory_raw) == descriptor['inventory_sha256'], 'Closed inventory identity changed')
    index = json.loads(inventory_raw)
    require(type(index) is dict and bool(index), 'Complete inventory required')
    actual = {}
    for path in root.rglob('*'):
        require(not path.is_symlink(), 'Closed packet must not contain symlinks')
        if path.is_file() and path != root / 'ARTIFACT_SHA256.json':
            actual[path.relative_to(root).as_posix()] = sha(path.read_bytes())
    require(actual == index, 'Closed packet inventory does not match every byte')

    def child(name):
        require(type(name) is str and name and '\\' not in name and not Path(name).is_absolute()
                and '..' not in Path(name).parts, 'Unsafe packet path')
        target = (root / name).resolve()
        require(target.is_relative_to(root), 'Packet path leaves root')
        return target

    run = child(descriptor['run'])
    terminals = json.loads(child(descriptor['terminals']).read_bytes())
    require(type(terminals) is dict and terminals, 'Actual scheduler outputs required')
    parsed = {}
    for job, row in terminals.items():
        require(re.fullmatch(r'\d+\.manager', job) and set(row) == {'qstat', 'parent_exit', 'worker_exit'},
                'Real PBS identity and original three terminal files required')
        raw = {key: child(path).read_bytes() for key, path in row.items()}
        proof = contract.terminal(raw['qstat'], raw['parent_exit'], raw['worker_exit'], job)
        require(re.search(rb'^\s*Stageout_status = 0\s*$', raw['qstat'], re.M), 'Actual Stageout0 required')
        parsed[job] = dict(job=job, **raw, proof=proof)
    return root, run, index, parsed


def verify_cycle(runner, descriptor, assembly, candidate, case, cycle):
    from cpu_trace_budget import audit_cpu_trace
    root, run, index, terminals = closed_packet(descriptor)
    identity = contract.request(candidate, case, 'spinup', cycle)
    receipt = contract.read_json(run / 'receipt.json')
    require(receipt['pbs_job'] in terminals, 'Final worker has no actual complete terminal')
    terminal = {key: terminals[receipt['pbs_job']][key] for key in ('job', 'qstat', 'parent_exit', 'worker_exit')}
    result = adapter.verify_parent(runner, run, identity, terminal)
    result['trace_budget'] = audit_cpu_trace(runner, result, run)
    require(result['report']['configuration_sha256'] == identity['configuration_sha256'], 'Wrong candidate year')
    _, config, _ = original_configuration(assembly, candidate, case)
    require(result['report']['configuration'] == config, 'Report configuration differs from frozen own OM values')
    annual = 'year-inputs/' + identity['site'] + '-' + str(identity['year']) + '.npz'
    with runner.np.load(io.BytesIO(assembly[annual]), allow_pickle=False) as original_input:
        for key in ('time_start', 'time_end'):
            adapter.assert_content_exact(result['trace'][key], original_input[key], runner.np)
    endpoint = frame(result['saved'][0])
    for trace_key, frame_key in [('tsoil_k', 'soil_temperature_k'), ('smc_m3m3', 'soil_water_m3m3')]:
        adapter.assert_content_exact(result['trace'][trace_key][-1], endpoint[frame_key], runner.np)
    require(float(result['trace']['swe_m'][-1]) == endpoint['swe_m'], 'Final snow state/trace mismatch')
    calls, segments = 0, []
    for segment in sorted(run.glob('segment-*')):
        rec = contract.read_json(segment / 'receipt.json')
        require(rec['pbs_job'] in terminals and rec['identity'] == identity and rec['failure'] is None
                and rec['worker_completed'] is True and rec['source_unchanged'] is True,
                'Every original segment must close successfully for its own candidate')
        require(type(rec['successful_tendency_calls']) is int and rec['successful_tendency_calls'] > 0,
                'Successful original tendency count required')
        require(rec['start_index'] == calls and rec['stop_index'] == calls + rec['successful_tendency_calls'],
                'Original segment sequence has a gap or overlap')
        calls = rec['stop_index']
        for name, digest in contract.read_json(segment / 'capture-SHA256.json').items():
            require(sha((segment / name).read_bytes()) == digest, 'Original segment capture changed')
        before = pickle.loads((segment / 'first-call-input.pkl').read_bytes())
        packet = pickle.loads((segment / 'first-call.pkl').read_bytes())
        require(set(packet) == {'before', 'forcing', 'kwargs', 'after', 'diagnostics'}, 'Complete first original call required')
        adapter.assert_content_exact(before, {key: packet[key] for key in before}, runner.np)
        segments.append(dict(path=segment.relative_to(root).as_posix(), job=rec['pbs_job'],
                             receipt_sha256=sha((segment / 'receipt.json').read_bytes()), calls=rec['successful_tendency_calls']))
    require(calls == identity['steps'], 'Full cycle original call count required')
    require(set(terminals) == {r['job'] for r in segments}, 'Missing or unrelated terminal record')
    result.update(run=run, packet_root=root, packet_inventory=index, segments=segments,
                  descriptor=descriptor, endpoint=endpoint)
    return result


def audit_own_cycles(source, assembly_archive, candidate, cases):
    """Read all eight complete own-cold chains; expose facts for the CPU scheduler."""
    runner, assessor, pairs_module = runtime(source)
    fixed = bindings()
    assembly = read_assembly(assembly_archive)
    rows = candidate_rows(candidate)
    require(type(cases) is dict and set(cases) == {r['case'] for r in rows}, 'All eight own roots are required')
    lengths = {len(cases[row['case']]) for row in rows}
    require(len(lengths) == 1 and 1 <= next(iter(lengths)) <= 20,
            'All roots must reach the same complete cycle, within original20 limit')
    cycles = next(iter(lengths))
    histories, final, frames = {}, {}, {}
    for row in rows:
        case = row['case']
        old, previous_frame, carbon_history, history, count, structure_count = None, None, [], [], 0, 0
        for number, descriptor in enumerate(cases[case], 1):
            result = verify_cycle(runner, descriptor, assembly, candidate, case, number)
            context = contract.read_json(result['run'] / 'start-context.json')
            if old is None:
                require(context['mode'] == 'cold', 'Full own-cold lineage required')
                zero = result['run'] / 'segment-0000000/start-originals'
                zr = contract.read_json(zero / 'report.json')
                previous_frame = frame(pickle.loads((zero / zr['checkpoint_file']).read_bytes())[0])
                carbon_history.append(previous_frame['soil_carbon_gc_m2'].copy())
            else:
                require(context['mode'] == 'cycle', 'Spinup uses own repeated first-year climate')
                retained = result['run'] / 'parent-originals'
                for name, expected in [('parent-state.pkl', old['state_raw']), ('parent-report.json', old['report_raw']),
                                       ('parent-chain-state.json', old['chain_raw']), ('parent-receipt.json', old['receipt_raw'])]:
                    require((retained / name).read_bytes() == expected, 'Actual previous cycle is not retained byteexact')
            require(result['chain']['ledger_steps'] == number * 17520 and result['chain']['ledger_segments'] == number,
                    'Global own-cycle step/segment count mismatch')
            comparison = assessor.compare_endpoints(previous_frame, result['endpoint'])
            count = count + 1 if comparison['water_heat_criteria_met'] else 0
            structure = comparison.get('canopy_structure_criterion_met')
            structure_count = structure_count + 1 if structure else 0
            comparison.update(cycle=number, consecutive_water_heat_checks=count,
                water_heat_converged=number >= assessor.LIMITS['minimum_cycles'] and count >= assessor.LIMITS['consecutive_endpoint_checks'],
                canopy_structure_converged=None if structure is None else number >= assessor.LIMITS['minimum_cycles']
                    and structure_count >= assessor.LIMITS['consecutive_endpoint_checks'])
            comparison['stored_original_trace_budget'] = result['trace_budget']
            history.append(comparison)
            previous_frame = result['endpoint']
            carbon_history.append(previous_frame['soil_carbon_gc_m2'].copy())
            old = result
        histories[case] = dict(cycles=history,
            observed_century=assessor.observed_carbon_century([[v] for v in carbon_history], [case]))
        final[case] = dict(identity=old['chain']['identity'], descriptor=old['descriptor'],
            report_sha256=sha(old['report_raw']), checkpoint_sha256=sha(old['state_raw']),
            chain_sha256=sha(old['chain_raw']), receipt_sha256=sha(old['receipt_raw']),
            ledger_steps=old['chain']['ledger_steps'], ledger_segments=old['chain']['ledger_segments'])
        frames[case] = old['endpoint']
    pair_results = []
    for pair in fixed['training_pairs']:
        result = pairs_module.compare_seed_endpoints(frames[pair['dry']['case']], frames[pair['wet']['case']], assessor.LIMITS)
        result.update(site=pair['site'], mapping=pair['bgc_potential_mapping'], dry=pair['dry']['case'], wet=pair['wet']['case'])
        pair_results.append(result)
    # A reader can establish own lineage and original hydro/SAI conditions now.
    # It cannot fill the scientifically undefined normal-feedback/SOC window or
    # normal feedback evidence with caller flags or annualized rates.
    output = dict(candidate=candidate, backend='numpy64', complete_cycles=cycles,
        own_nominal_cold_lineages_verified=True, roots=histories, final_cycles=final, cross_seed=pair_results,
        all_roots_water_heat_converged=all(v['cycles'][-1]['water_heat_converged'] for v in histories.values()),
        all_roots_canopy_structure_converged=all(v['cycles'][-1]['canopy_structure_converged'] is not False for v in histories.values()),
        all_four_cross_seed_water_heat_criteria_met=all(v['cross_seed_water_heat_criteria_met'] for v in pair_results),
        source_manifest_sha256=fixed['source_manifest_sha256'], controls_manifest_sha256=verify_controls(),
        original_limits=assessor.LIMITS, actual_new_physical_steps=0,
        soil_c_long_term_equilibrium_claim=False, nitrogen_equilibrium_claim=False,
        score_eligible=False, unresolved_requirements=fixed['unresolved_scientific_and_budget_requirements'])
    output['bounded_execution_plan'] = fixed['bounded_execution_plan']
    adapter.verify_source(source)
    for case in cases:
        for descriptor in cases[case]:
            closed_packet(descriptor)
    return output


def verify_train1_parent(assessment, candidate, case, train1_run):
    """Bind a train1 retained parent to the exact audited cycle, never grant eligibility."""
    require(assessment['candidate'] == candidate and case in assessment['final_cycles'], 'Different own spinup result')
    expected = assessment['final_cycles'][case]
    root = Path(train1_run)
    context = contract.read_json(root / 'start-context.json')
    identity = contract.request(candidate, case, 'train1')
    require(context['identity'] == identity and context['mode'] == 'cycle', 'Train1 is not own fixed climate cycle')
    for file, key in [('parent-report.json', 'report_sha256'), ('parent-state.pkl', 'checkpoint_sha256'),
                      ('parent-chain-state.json', 'chain_sha256'), ('parent-receipt.json', 'receipt_sha256')]:
        require(sha((root / 'parent-originals' / file).read_bytes()) == expected[key], 'Train1 parent differs from audited final own cycle')
    require(context['previous_ledger_steps'] == expected['ledger_steps']
            and context['ledger_segments'] == expected['ledger_segments'] + 1, 'Train1 cumulative counts reset')
    return dict(parent_identity_exact=True, final_cycle_checkpoint_sha256=expected['checkpoint_sha256'],
                score_eligible=False, missing=assessment['unresolved_requirements'])

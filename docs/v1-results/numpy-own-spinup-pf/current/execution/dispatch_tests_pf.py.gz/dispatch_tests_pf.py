"""One fresh manager/compute002 /tmp stage and one bounded PF PBS job."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shlex
import socket
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/noahmp-numpy-own-spinup-pf')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unpack(path, expected):
    assert sha(path.read_bytes()) == expected and not ROOT.exists()
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
                   and '\\' not in m.name for m in members)
        assert len({m.name for m in members}) == len(members)
        raw = {m.name: archive.extractfile(m).read() for m in members}
    index = json.loads(raw['stage-inventory.json'])
    assert set(index) == set(raw) - {'stage-inventory.json'} and all(sha(raw[n]) == h for n, h in index.items())
    run = json.loads(raw['execution/RUN_BINDINGS.json'])
    assert run['expected_tests'] == 13 and run['expected_original_tendencies'] == 2
    assert sha(raw['preparation/CONTROLS_SHA256.json']) == run['preparation_manifest_sha256']
    ROOT.mkdir()
    for name, value in raw.items():
        dest = ROOT / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(value)
    return index


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--extract-only', action='store_true')
    args = parser.parse_args()
    assert sys.version_info >= (3, 10)
    assert socket.gethostname() == ('compute002' if args.extract_only else 'manager')
    index = unpack(args.archive, args.sha256)
    assert sha(Path(__file__).read_bytes()) == index['execution/dispatch_tests_pf.py']
    if args.extract_only:
        print(json.dumps(dict(stage_archive_sha256=args.sha256, members=len(index))), flush=True)
        return
    remote_archive = '/tmp/noahmp-numpy-own-spinup-pf-stage.tar.gz'
    remote_dispatcher = '/tmp/dispatch_numpy_own_spinup_pf.py'
    subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', str(ROOT)])], check=True)
    for local, remote in [(args.archive, remote_archive), (Path(__file__), remote_dispatcher)]:
        subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', remote])], check=True)
        subprocess.run(['scp', str(local), 'compute002:' + remote], check=True)
    extract = subprocess.run(['ssh', 'compute002', shlex.join([
        PYTHON, '-B', remote_dispatcher, '--archive', remote_archive, '--sha256', args.sha256, '--extract-only'])],
        capture_output=True, text=True)
    (ROOT / 'compute-extract.stdout.txt').write_text(extract.stdout)
    (ROOT / 'compute-extract.stderr.txt').write_text(extract.stderr)
    assert extract.returncode == 0, extract.stderr
    checked = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', *[str(ROOT / n) for n in index]])],
                             capture_output=True, text=True)
    (ROOT / 'compute-file-hashes.txt').write_text(checked.stdout)
    assert checked.returncode == 0, checked.stderr
    assert {line.split()[1]: line.split()[0] for line in checked.stdout.splitlines()} == {str(ROOT / n): h for n, h in index.items()}
    result = subprocess.run(['qsub', '-o', str(ROOT / 'pbs-output.log'), str(ROOT / 'execution/tests_pf.pbs')],
                            capture_output=True, text=True)
    (ROOT / 'qsub.stdout.txt').write_text(result.stdout)
    (ROOT / 'qsub.stderr.txt').write_text(result.stderr)
    (ROOT / 'qsub-actual-exit.json').write_text(json.dumps(dict(actual_parent_returncode=result.returncode)) + '\n')
    assert result.returncode == 0, result.stderr
    job = result.stdout.strip()
    assert job.endswith('.manager') and job.split('.')[0].isdigit()
    run = json.loads((ROOT / 'execution/RUN_BINDINGS.json').read_bytes())
    record = dict(pbs_job=job, stage_archive_sha256=args.sha256, source_stage_members=index,
        preparation_manifest_sha256=run['preparation_manifest_sha256'],
        requested_resources='1CPU/2GiB/10min/compute002', python=PYTHON, controller_pid=os.getpid(),
        expected_tests=13, expected_original_tendencies=2, expected_nominal_cold_states=184,
        actual_field_years=0, GPU_steps=0, scope='PF own nominal states, bounded BGC observer; no annual spinup.')
    (ROOT / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(pbs_job=job, stage_archive_sha256=args.sha256, controller_pid=os.getpid())), flush=True)


if __name__ == '__main__':
    main()

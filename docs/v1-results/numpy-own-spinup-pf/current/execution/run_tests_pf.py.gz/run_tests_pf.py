"""Bounded EHPC tests: genuine nominal cold states plus two original tendencies."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import os
import re
import resource
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-numpy-own-spinup-pf')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def process_identity(pid):
    root = Path('/proc') / str(pid)
    raw = (root / 'stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    return dict(pid=pid, start_ticks=int(fields[19]), ppid=int(fields[1]),
                cmdline=(root / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace'))


def main():
    assert sys.version_info >= (3, 10)
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    result = Path(sys.argv[1]).resolve()
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not result.exists()
    result.mkdir()
    began = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
        executable=sys.executable, numpy_version=importlib.metadata.version('numpy'),
        actual_worker=process_identity(os.getpid()), passed=False, error=None,
        test_parent_returncode=None, test_timed_out=False, actual_field_years=0,
        actual_spinup=False, GPU_steps=0, expected_original_cpu_tendencies=2,
        actual_original_cpu_tendencies=None, actual_nominal_cold_seeds=None)
    try:
        inventory = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in inventory.items())
        run = json.loads((STAGE / 'execution/RUN_BINDINGS.json').read_bytes())
        prep_raw = (STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()
        prep = json.loads(prep_raw)
        assert sha(prep_raw) == run['preparation_manifest_sha256'] and len(prep) == 16
        assert all(sha((STAGE / 'preparation' / n).read_bytes()) == h for n, h in prep.items())
        fixed = json.loads((STAGE / 'preparation/BINDINGS_PF.json').read_bytes())
        source_path = STAGE / 'inputs/climatology-final-candidate-nm-source.tar.gz'
        assert sha(source_path.read_bytes()) == fixed['source_archive_sha256']
        with tarfile.open(source_path) as archive:
            members = archive.getmembers()
            assert all(m.isfile() for m in members) and len({m.name for m in members}) == 585
            source_raw = archive.extractfile('SOURCE_SHA256.json').read()
            assert sha(source_raw) == fixed['source_manifest_sha256']
            source = json.loads(source_raw)
            assert len(source) == 584 and {m.name for m in members} == set(source) | {'SOURCE_SHA256.json'}
            assert all(sha(archive.extractfile(n).read()) == h for n, h in source.items())
            source_root = result.parent / 'source-nm584'
            source_root.mkdir()
            for name in [*source, 'SOURCE_SHA256.json']:
                assert not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name
                path = source_root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.extractfile(name).read())
        execution_raw = (STAGE / 'execution/CONTROLS_SHA256.json').read_bytes()
        execution = json.loads(execution_raw)
        for folder, index in [('preparation', prep), ('execution', execution)]:
            for name in [*index, 'CONTROLS_SHA256.json']:
                target = result / folder / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(STAGE / folder / name, target)
        (result / 'SOURCE_SHA256.json').write_bytes(source_raw)
        work = result / 'preparation'
        tree = ast.parse((work / 'test_own_spinup_pf.py').read_bytes())
        tests = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
        assert len(tests) == len(set(tests)) == run['expected_tests'] == 13
        env = os.environ.copy()
        env.pop('PYTHONPATH', None)
        env.pop('PYTHONHOME', None)
        env.update(PF_SOURCE=str(source_root), PF_OUTPUT=str(result / 'own-init-output'),
            PF_PA_ARCHIVE=str(STAGE / 'inputs/training-chain-pa-evidence.tar.gz'),
            PF_PB_ARCHIVE=str(STAGE / 'inputs/numpy-training-chain-pb-evidence.tar.gz'),
            PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
            MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
        assert sha(Path(env['PF_PA_ARCHIVE']).read_bytes()) == fixed['PA_archive_sha256']
        assert sha(Path(env['PF_PB_ARCHIVE']).read_bytes()) == fixed['PB_actual_closed_package_sha256']
        command = [sys.executable, '-B', '-m', 'unittest', '-v', 'test_own_spinup_pf']
        save(result / 'test-command.json', dict(argv=command, cwd=str(work), tests=tests))
        with (result / 'unittest.stdout.txt').open('w') as out, (result / 'unittest.stderr.txt').open('w') as err:
            child = subprocess.Popen(command, cwd=work, env=env, stdout=out, stderr=err)
            receipt['actual_test_process'] = process_identity(child.pid)
            save(result / 'actual-test-process.json', receipt['actual_test_process'])
            try:
                code = child.wait(timeout=480)
            except subprocess.TimeoutExpired:
                receipt['test_timed_out'] = True
                child.kill()  # Only this bounded job's own test child.
                code = child.wait()
        receipt['test_parent_returncode'] = code
        (result / 'unittest-parent-exit.txt').write_text(str(code) + '\n')
        stderr = (result / 'unittest.stderr.txt').read_text()
        count = re.search(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
        statuses = re.findall(r'^(test\w+) \([^\n]+\) \.\.\. (.+)$', stderr, re.M)
        assert code == 0 and not receipt['test_timed_out'], stderr
        assert count and int(count.group(1)) == 13 and re.search(r'^OK$', stderr, re.M)
        assert len(statuses) == 13 and {n for n, _ in statuses} == set(tests) and all(s == 'ok' for _, s in statuses)
        output = result / 'own-init-output'
        counts = json.loads((output / 'execution-counts.json').read_bytes())
        assert counts['own_nominal_seeds'] == counts['independent_constructor_comparisons'] == 184
        assert counts['actual_new_physical_steps'] == 2 and counts['forward_attempts'] == 0
        assert counts['actual_model_years'] == 0 and counts['actual_spinup'] is False
        assert counts['synthetic_complete_calendar_packets'] == 16 and counts['synthetic_packet_receipts_have_no_physical_credit'] is True
        captured = json.loads((output / 'bgc-capture-comparison.json').read_bytes())
        assert captured['actual_new_original_tendencies'] == captured['complete_bgc_records'] == 2
        assert captured['actual_reference_reruns'] == 0 and captured['original_bgc_and_kwargs_max_abs_difference'] == 0.
        assert captured['state']['max_abs_difference'] == 0. and len(captured['trace']) == 18
        assert all(v['max_abs_difference'] == 0. for v in captured['trace'].values())
        assert all(sha((source_root / n).read_bytes()) == h for n, h in source.items())
        assert all(sha((work / n).read_bytes()) == h for n, h in prep.items())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in inventory.items())
        receipt.update(passed=True, actual_test_count=13, actual_test_seconds=float(count.group(2)),
            actual_original_cpu_tendencies=2, actual_nominal_cold_seeds=184,
            source_before_after_584_exact=True, preparation_inputs_unchanged=True,
            preparation_manifest_sha256=sha(prep_raw), execution_manifest_sha256=sha(execution_raw),
            source_manifest_sha256=sha(source_raw), test_names=tests,
            capture_comparison_sha256=sha((output / 'bgc-capture-comparison.json').read_bytes()),
            counts=counts)
    except Exception as exc:
        receipt['error'] = type(exc).__name__ + ': ' + str(exc)
        (result / 'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic() - began
    receipt['maximum_controller_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    receipt['maximum_child_rss_kib'] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    save(result / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

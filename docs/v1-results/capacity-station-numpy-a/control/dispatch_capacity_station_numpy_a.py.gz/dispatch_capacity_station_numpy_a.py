from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'capacity-station-numpy-a';assert not r.exists();r.mkdir();controls={}
for name in ['run_capacity_station_numpy_a.py','capacity_station_numpy_a.pbs','capacity-station-numpy-a-package.json']:
    raw=(b/name).read_bytes()
    if name.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if name.endswith('package.json') else name)).write_bytes(raw)
    controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'capacity_station_numpy_a.pbs')],cwd=r,text=True,capture_output=True)
assert p.returncode==0,p.stderr
(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=p.stdout.strip(),controls_sha256=controls),indent=2)+'\n')
print(p.stdout.strip())

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'capacity-station-numpy-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());a=b/'capacity-station-numpy-a-source.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==533 and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
files=['tests/test_fluxnet_capacity_runner.py','tests/test_fluxnet_stem_runner.py','tests/test_fluxnet_native_runner.py','tests/test_clm_capacity_column.py','tests/test_clm_spinup.py','tests/test_hrldas_native_year.py'];env['NOAHMP_CAPACITY_STATION_REFERENCE']=str(r/'references');xml=r/'numpy-target.xml';start=time.monotonic()
with (r/'numpy-target.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
tree=ET.parse(xml).getroot();counts={k:sum(int(x.attrib[k]) for x in tree.iter('testsuite')) for k in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==h for n,h in m.items())
d=dict(scope='Frozen533A NumPy-first actual station cross-year causal temperature memory and full split/restart equality, existing checkpoint/budget/spinup/HRLDAS consumers. No device or scientific acceptance claim',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,returncode=code,counts=counts,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,xml_sha256=sha(xml))
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert code==0 and unchanged and counts['tests']>28 and all(counts[k]==0 for k in ['failures','errors','skipped'])

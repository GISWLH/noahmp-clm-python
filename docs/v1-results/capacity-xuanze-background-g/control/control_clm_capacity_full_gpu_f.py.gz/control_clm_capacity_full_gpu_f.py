from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'clm-capacity-final-f'
r = s / 'full-bgc-f'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 532 and all(sha(s / n) == v for n, v in manifest.items())
worker = b / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
assert sha(worker) == '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
start = time.monotonic()
command = [sys.executable, '-u', str(worker), '--source', str(s), '--test-file', str(s / 'tests/test_gpu_clm_capacity_column.py'), '--expected', str(r / 'expected.json'), '--receipt', str(r / 'receipt.json'), '--xml', str(r / 'targets.xml')]
with (r / 'targets.log').open('x') as log:
    p = subprocess.Popen(command, cwd=s, stdout=log, stderr=subprocess.STDOUT)
(r / 'worker.json').write_text(json.dumps(dict(pid=p.pid, command=command)) + '\n')
code = p.wait()
receipt = json.loads((r / 'receipt.json').read_text()) if (r / 'receipt.json').exists() else None
passed = bool(receipt and code == receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0 and receipt['passed'] and receipt['source_unchanged'] and receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed'] and receipt['counts'] == dict(tests=3, failures=0, errors=0, skipped=0) and receipt['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and receipt['test_sha256'] == manifest['tests/test_gpu_clm_capacity_column.py'] and receipt['xml_sha256'] == sha(r / 'targets.xml'))
record = dict(scope='Frozen532F actual3 whole20/23-array capacity C-N/MOST tests, bothprecisions versusquantizedEHPC continuousreference/originalMHCN, allreturnedrawCUDA32/JAX32 fields/allcarriedarrays andintegerflags exact. Actual same-sourceCPU981 and targets20 prerequisites. Original worker phases/barriers/atexit bypass disclosure; not full363/1344/station/year/science', returncode=code, passed=passed, seconds=time.monotonic() - start, receipt_sha256=sha(r / 'receipt.json') if receipt else None)
(r / 'exit.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if passed else 1)

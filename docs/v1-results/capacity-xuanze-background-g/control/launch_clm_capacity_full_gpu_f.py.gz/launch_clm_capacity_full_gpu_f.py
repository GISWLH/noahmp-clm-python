from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-capacity-final-f';r=s/'full-bgc-f';assert not r.exists();digest=sys.argv[1];assert len(digest)==64;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==532 and all(sha(s/n)==h for n,h in m.items())
a=b/'clm-capacity-cpu-f-evidence.tar.gz';assert sha(a)==digest
with tarfile.open(a) as t:
    assert json.loads(t.extractfile('SOURCE_SHA256.json').read())==m;cpu=json.loads(t.extractfile('receipt.json').read());assert cpu['returncode']==0 and cpu['counts']==dict(tests=981,failures=0,errors=0,skipped=0) and cpu['source_unchanged']
prefix=json.loads((s/'target-f/exit.json').read_text());assert prefix['passed'] and prefix['source_unchanged'] and len(prefix['results'])==3 and all(v['passed'] and v['returncode']==0 for v in prefix['results'])
collection=json.loads((s/'target-f/collection.json').read_text());expected=collection['groups']['test_gpu_clm_capacity_column.py'];assert len(expected)==3
free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>8192
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());assert int(mem['MemAvailable'].split()[0])>16*1024*1024
r.mkdir();(r/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',NOAHMP_CAPACITY_COLUMN_DIAGNOSTICS=str(r/'diagnostics'))
controls={n:sha(b/n) for n in ['launch_clm_capacity_full_gpu_f.py','control_clm_capacity_full_gpu_f.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_clm_capacity_full_gpu_f.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='Frozen532F whole20/23-array C-N/traits/T10/MOST3 after actualsame-source981CPU and component/layer/legacy20. Per-precision quantizedEHPC53 reference and originalMHCN plus allreturnedfields/allcarriedarrays at original1e-6/int. Actual prior workers retained. Full363/1344/station/year/science pending',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=1,free_memory_mib=free,cpu_evidence_sha256=sha(a),prefix_exit_sha256=sha(s/'target-f/exit.json'),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls)
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

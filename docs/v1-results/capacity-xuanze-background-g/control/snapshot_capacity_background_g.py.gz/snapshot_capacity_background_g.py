from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,sys,tarfile

mode=sys.argv[1];files=[];embedded={};record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only live metadata/raw snapshots, not full/year/spinup/science acceptance. Currentcapacity532F and original-cold year519H remain distinct; no failed/source-changed trajectory resumed or actual predecessor worker stopped.')
if mode=='cpu':
    base=Path('/home/zhangyq/noahmp-v1');root=base/'qia-kink-numpy-year-h';name='capacity-ehpc-background-g'
    record['qstat']=subprocess.check_output(['qstat','-u','zhangyq'],text=True)
    raw=(root/'trajectory/report.json').read_bytes();embedded['year/trajectory/report.json']=raw;report=json.loads(raw)
    record.update(year_status=report['status'],steps_completed=report['steps_completed'],steps_requested=report['steps_requested'])
    for path in sorted(root.rglob('*')):
        if path.is_file() and path!=root/'trajectory/report.json':files.append(('year/'+path.relative_to(root).as_posix(),path))
else:
    assert mode=='gpu';base=Path('/home/lhwang/work/noahmp-v1');name='capacity-xuanze-background-g'
    root=base/'clm-capacity-final-f/full-bgc-f'
    for filename in ['launch.json','worker.json','controller.log','expected.json','targets.log','receipt.json','exit.json']:
        if (root/filename).exists():files.append(('whole532F/'+filename,root/filename))
    worker=json.loads((root/'worker.json').read_text());pid=worker['pid']
    record['whole_worker']=worker
    record['ps']=subprocess.run(['ps','-p',str(pid),'-o','pid,stat,etime,args'],text=True,capture_output=True).stdout
    record['whole_actual_exit_present']=(root/'exit.json').exists()
    year=base/'qia-kink-cuda-year-h'
    for filename in ['launch.json','worker.json','controller.log','model.log','receipt.json','exit.json']:
        if (year/filename).exists():files.append(('year519H/'+filename,year/filename))
    raw=(year/'trajectory/batch.json').read_bytes();embedded['year519H/batch.json']=raw;report=json.loads(raw)
    record.update(year_status=report['status'],steps_completed=report['steps_completed'],steps_requested=report['steps_requested'])
    record['pipelines']=[]
    for relative in ['p6-all-phase-final-b/full-by-file-a/progress.json','pft-optics-final-d/full-by-file-d/progress.json']:
        path=base/relative;raw=path.read_bytes();embedded['pipelines/'+relative]=raw;progress=json.loads(raw)
        active=progress.get('active');status=None
        if active:status=subprocess.run(['ps','-p',str(active['pid']),'-o','pid,stat,etime,args'],text=True,capture_output=True).stdout
        record['pipelines'].append(dict(path=relative,covered_nodes=progress['covered_nodes'],collected_nodes=progress['collected_nodes'],active=active,ps=status))
    deferred=base/'qia1110-final-h/full-controller-h'
    for filename in ['launch.json','worker.json','controller.log','exit.json']:
        if (deferred/filename).exists():files.append(('prior519H-canonical/'+filename,deferred/filename))
    record['prior519H_full_worker_started']=(deferred/'worker.json').exists()
    controls=['launch_clm_capacity_full_gpu_f.py','control_clm_capacity_full_gpu_f.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']
    files.extend(('control/'+control,base/control) for control in controls)
archive=base/(name+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for filename,path in files:tf.add(path,arcname=filename,recursive=False)
    tf.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    embedded['snapshot.json']=(json.dumps(record,indent=2)+'\n').encode()
    for filename,raw in embedded.items():info=tarfile.TarInfo(filename);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,snapshot=record)))

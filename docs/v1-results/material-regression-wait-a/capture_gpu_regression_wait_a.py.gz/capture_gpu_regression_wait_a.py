from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-material-event-b';r=s/'full-by-file-b';p=json.loads((r/'progress.json').read_text());pid=p['active']['pid'];proc=Path('/proc')/str(pid);command=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert str(s) in command and p['active']['file'] in command
d=dict(scope='Read-only own-process wait observation; no process killed/restarted, device reset, source or gate changed. OS wait channel is an observation, not a proven diagnosis of GPU failure. Frozen493 only, current506 coverage separate.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),covered=p['covered_nodes'],active=p['active'],command=command,wchan=(proc/'wchan').read_text(),ps=subprocess.check_output(['ps','-p',str(pid),'-o','pid,stat,etime,pcpu,wchan:32'],text=True));out=b/'material-regression-wait-a.json';assert not out.exists();out.write_text(json.dumps(d,indent=2)+'\n');a=b/'material-regression-wait-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 t.add(out,arcname=out.name,recursive=False);t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),observation=d)))

from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-i';source=base/'p6-phase-short-circuit-gpu-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=root/'cuda-annual-launch.json';assert not receipt.exists()
legacy_root=base/'p6-short-circuit-legacy-replay-a'
legacy=json.loads((legacy_root/'cuda-replay.json').read_text());assert legacy['status']=='complete' and legacy['pre_change_baseline_bitwise_equal']
target=json.loads((source/'phase-target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=9,failures=0,errors=0,skipped=0)
shadow_path=legacy_root/'jax-replay.json';shadow=json.loads(shadow_path.read_text()) if shadow_path.exists() else None
assert shadow is None or shadow['status']=='complete'
proof=json.loads((root/'pre-change-h48-comparison.json').read_text());comparison=json.loads((root/'backend-day-comparison.json').read_text());assert proof['bitwise_equal'] and not comparison['failures']
archive=base/'short-circuit-climate-i-day-evidence.tar.gz';assert archive.is_file()
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_native import source_hashes,read_generation
report,state,cases=read_generation(root/'cuda-day');assert report['steps_completed']==48 and report['steps_requested']==17520 and report['identity']['source_sha256']==source_hashes()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
binding=dict(prelaunch_report_sha256=sha(root/'cuda-day/batch.json'),checkpoint_file=report['checkpoint_file'],checkpoint_sha256=report['checkpoint_sha256'],first_day_comparison_sha256=sha(root/'backend-day-comparison.json'),pre_change_comparison_sha256=sha(root/'pre-change-h48-comparison.json'),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),batch_sha256=sha(root/'batch.json'),immutable_first48_archive_sha256=sha(archive))
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'benchmarks'),CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--resume']
with (root/'cuda-annual-resume.log').open('w') as log:p=subprocess.Popen(command,cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,steps_requested=17520,start_from_completed=48,command=command,bindings=binding,extra_jax_whole_step_status='pending' if shadow is None else shadow['status'],scope='Current source I continues its own independently validated and archived48 state. Target9 includes independent JAX32/64 and same-precision gates; CUDA whole-step exact. Extra JAX whole-step shadow can run concurrently and remains separately pending. No H checkpoint, source-hash rewrite or shorter annual request. Completion/spinup/science pending.')
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

import json,sys
from pathlib import Path
import numpy as np
import cupy as cp
sys.path.insert(0,str(Path.cwd()/'tests'))
import test_gpu_soil_transport as check
from noahmp_clm.gpu.soil_transport import pack_soil_transport,run_soil_transport_jax
from noahmp_clm.gpu.cuda.soil_transport import run_soil_transport_cuda
rows=[]
for texture in ('sand','loam','clay'):
 for t in (250.,273.14,280.):
  for specific in (0.,-42000.,342360.):
   s=check.soil_state(np.float32,texture,t,.4)
   rows.append(pack_soil_transport(s,0,mass=.02,enthalpy=.02*specific,dtype=np.float32))
a=tuple(np.stack([r[k] for r in rows]) for k in range(4));out={}
for name,run in (('jax32',run_soil_transport_jax),('cuda32',run_soil_transport_cuda)):
 r=run(*a);r={k:cp.asnumpy(v) if isinstance(v,cp.ndarray) else np.asarray(v) for k,v in r.items()};out[name]=r
 errors={'temperature_k':0.,'water_kgm2':0.,'enthalpy_jm2':0.}
 for i,row in enumerate(zip(*a)):
  ref=check.reference(*row);check.science({k:v[i] for k,v in r.items()},ref,np.float32,1800.)
  errors['temperature_k']=max(errors['temperature_k'],float(np.max(abs(r['temperature_k'][i]-ref['temperature_k']))))
  errors['water_kgm2']=max(errors['water_kgm2'],float(np.max(abs(r['cells'][i,:,0]-ref['cells'][:,0]))))
  errors['enthalpy_jm2']=max(errors['enthalpy_jm2'],float(np.max(abs(r['cells'][i,:,1]-ref['cells'][:,1]))))
 print(name,'cases',len(rows),'errors',errors,'budget',check.budgets(a[0],r).tolist(),flush=True)
for key in out['jax32']:
 np.testing.assert_allclose(out['jax32'][key],out['cuda32'][key],rtol=1e-6,atol=1e-6)
print('same precision maximum',max(float(np.max(abs(v-out['cuda32'][k]))) for k,v in out['jax32'].items() if k!='valid'),flush=True)

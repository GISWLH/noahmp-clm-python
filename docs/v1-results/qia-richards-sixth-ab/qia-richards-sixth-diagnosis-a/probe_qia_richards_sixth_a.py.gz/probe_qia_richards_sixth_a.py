from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-richards-sixth-diagnosis-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'richards-station-numpy-a-source.tar.gz';assert sha(a)=='a8a91fe4c9f8d672341f83f55eefa31b5b8372f1a5cc1f7ae31116b30cc86048'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
from noahmp_clm.column import Forcing
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_most import MOSTGeometry
from fluxnet_deposition import DepositionSchedule
import noahmp_clm.physics.canopy_column as canopy
old=b/'qia-richards-capacity-firstday-a';folder=old/'trajectory';receipt=json.loads((old/'receipt.json').read_text());report=json.loads((folder/'report.json').read_text());config=json.loads((old/'config.json').read_text())
assert (old/'pbs-exit.txt').read_text().strip()=='1' and receipt['returncode']==1 and report['status']=='failed' and report['steps_completed']==5 and sha(folder/'report.json')==receipt['report_sha256']
assert sha(folder/report['checkpoint_file'])==report['checkpoint_sha256']
saved=pickle.loads((folder/report['checkpoint_file']).read_bytes());state=saved[0];index=saved[-1];assert index==5
inputs=b/'qia-stem-inputs-a/inputs';assert sha(inputs/'CN-Qia.npz')==report['forcing_npz_sha256'] and sha(old/'config.json')==report['configuration_sha256']
with np.load(inputs/'CN-Qia.npz',allow_pickle=False) as z:data=dict(z)
metadata=json.loads((inputs/'CN-Qia.json').read_text());stamps=runner.validate_input(data,metadata,inputs/'CN-Qia.npz')
f=Forcing(*data['forcing'][index]);co2,mu,diffuse=data['environment'][index];deposition=DepositionSchedule(config)
original=canopy.coupled_heat_step;captures=[];calls=0
def capture(*args,**kw):
    global calls
    calls+=1
    try:return original(*args,**kw)
    except Exception as error:
        captures.append((args,kw));(r/'thermal-failure.pkl').write_bytes(pickle.dumps((args,kw)))
        raise error
canopy.coupled_heat_step=capture;started=time.monotonic();failure=None
try:
    runner.step_clm_enthalpy_column(state,f,co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),most_geometry=MOSTGeometry(**config['most_geometry']),phenology_environment=runner.calendar(stamps[index],metadata,config['phenology'] is not None),deposition_rates=deposition.aerosol(stamps[index],f.dt),nitrogen_deposition_gn_m2=deposition.nitrogen_rate*f.dt,capacity_environment=runner.capacity_environment(stamps[index],metadata,True),soil_hydrology=runner.hydrology_configuration(config))
except Exception as error:
    failure=type(error).__name__+': '+str(error);(r/'replay-traceback.txt').write_text(traceback.format_exc())
assert captures and failure and '145252.741' in failure
canopy.coupled_heat_step=original;rows=[];lines=Path(original.__code__.co_filename).read_text().splitlines();at=next(i+1 for i,line in enumerate(lines) if 'if norm<=tol: break' in line)
def trace(frame,event,arg):
    if event=='line' and frame.f_code is original.__code__ and frame.f_lineno==at:
        v=frame.f_locals;rows.append({k:np.asarray(v[k]).copy().tolist() for k in ['iteration','h','residual','norm','t','derivative','tol']})
    return trace
sys.settrace(trace)
thermal_failure=None
try:original(*captures[-1][0],**captures[-1][1])
except Exception as error:thermal_failure=type(error).__name__+': '+str(error)
finally:sys.settrace(None)
snow,soil,dt,top=captures[-1][0];kw=captures[-1][1]
np.savez_compressed(r/'thermal-input.npz',snow_mass=snow.mass,snow_enthalpy=snow.enthalpy,snow_thickness=snow.thickness,snow_density=snow.density,snow_radius=snow.radius_um,snow_impurity=snow.impurities,soil_water=soil.water,soil_enthalpy=soil.enthalpy,soil_dz=soil.dz,dt=dt,top_flux=top,**{k:np.asarray(v) for k,v in kw.items() if v is not None})
d=dict(scope='Exact sixthstep diagnostic from successful saved5 prefix of actual553R-A failedcold48; not resumed/accepted model trajectory. Original source/controls and solver80/physical tolerance unchanged. Coupled thermal trial captured then original solver traced independently.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),original_report_sha256=receipt['report_sha256'],original_checkpoint_sha256=report['checkpoint_sha256'],time=str(data['time_start'][index]),forcing=data['forcing'][index].tolist(),replay_failure=failure,thermal_failure=thermal_failure,thermal_calls_before_failure=calls,thermal_rows=rows,input_sha256=sha(r/'thermal-input.npz'),pickle_sha256=sha(r/'thermal-failure.pkl'),soil_parameters=vars(soil.params),soil_freezing_option=soil.freezing_option,seconds=time.monotonic()-started)
(r/'diagnosis.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps(d),flush=True)

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=['qia-richards-sixth-diagnosis-a','qia-richards-sixth-phase-event-b']
for n in roots:
    r=b/n;d=json.loads((r/'diagnosis.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged']
a=b/'qia-richards-sixth-ab-evidence.tar.gz';assert not a.exists();source=b/'richards-station-numpy-a-source.tar.gz';assert sha(source)=='a8a91fe4c9f8d672341f83f55eefa31b5b8372f1a5cc1f7ae31116b30cc86048'
with tarfile.open(a,'w:gz') as t:
    for n in roots:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=n+'/'+p.relative_to(b/n).as_posix(),recursive=False)
    for n in ['dispatch_qia_richards_sixth_a.py','dispatch_qia_richards_sixth_b.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-richards-sixth-diagnosis-a';assert r.exists() and not list(r.iterdir());controls={}
for n in ['probe_qia_richards_sixth_a.py','qia_richards_sixth_a.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'qia_richards_sixth_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
d=dict(prior_submission_returncode=1,prior_submission_error='Missing generated analyze_qia_richards_sixth_a.py before qsub; empty root verified; no prior PBS job existed',pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-richards-sixth-phase-event-b';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda raw:hashlib.sha256(raw).hexdigest()
a=b/'richards-station-numpy-a-source.tar.gz';assert sha(a.read_bytes())=='a8a91fe4c9f8d672341f83f55eefa31b5b8372f1a5cc1f7ae31116b30cc86048'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha((s/n).read_bytes())==h for n,h in m.items());sys.path[:0]=[str(s/'src')]
import noahmp_clm.physics.column_heat as heat
prior=b/'qia-richards-sixth-diagnosis-a';d=json.loads((prior/'diagnosis.json').read_text());assert (prior/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged']
raw=(prior/'thermal-failure.pkl').read_bytes();assert sha(raw)==d['pickle_sha256'];args,kwargs=pickle.loads(raw)
text=(s/'src/noahmp_clm/physics/column_heat.py').read_text();old='if np.max(np.abs(value))<norm:'
new='''candidate_norm=np.max(np.abs(value))
            phase_event=any(scale==fraction and candidate[j]==boundary and h[j]!=boundary for fraction,j,boundary in events)
            if candidate_norm<norm or (phase_event and candidate_norm==norm):'''
assert text.count(old)==1;text=text.replace(old,new);(r/'private-column-heat.py').write_text(text)
namespace=dict(heat.__dict__);exec(compile(text,'<private-column-heat-phase-event>','exec'),namespace)
start=time.monotonic();failure=None;out=None
try:out=namespace['coupled_heat_step'](*args,**kwargs)
except Exception as error:failure=type(error).__name__+': '+str(error);(r/'traceback.txt').write_text(traceback.format_exc())
result=None
if out is not None:
    snow,soil,dt,top=args;new_snow,new_soil,ledger=out;ns=len(snow.mass)
    # A separate temperature-coordinate linear system is exact on the
    # verified all-liquid endpoint, including vanishing snow heat capacity.
    dz=np.r_[snow.thickness,soil.dz]
    k=np.r_[heat.snow_conductivity(snow),heat.soil_conductivity(soil.water/(1000.*soil.dz),soil.params)]
    face=1./(.5*dz[:-1]/k[:-1]+.5*dz[1:]/k[1:])
    cap=np.r_[heat.CW*snow.mass,(1.-soil.params.smcmax)*2e6*soil.dz+heat.CW*soil.water]
    fusion=heat.LF*np.r_[snow.mass,soil.water];old_h=np.r_[snow.enthalpy,soil.enthalpy]
    matrix=np.diag(cap/dt);rhs=(old_h-fusion)/dt+np.r_[kwargs.get('snow_absorbed',np.zeros(ns)),kwargs.get('soil_absorbed',np.zeros(len(soil.water)))];rhs[0]+=top
    for i,g in enumerate(face):matrix[i,i]+=g;matrix[i+1,i+1]+=g;matrix[i,i+1]-=g;matrix[i+1,i]-=g
    gc=kwargs.get('top_conductance',0.);matrix[0,0]+=gc
    if kwargs.get('top_temperature') is not None:rhs[0]+=gc*(kwargs['top_temperature']-heat.TF)
    offset=np.linalg.solve(matrix,rhs);assert np.all(offset>0.)
    expected_h=fusion+cap*offset;actual_h=np.r_[new_snow.enthalpy,new_soil.enthalpy]
    actual_t=np.r_[new_snow.temperature,new_soil.temperature]-heat.TF
    assert np.max(abs(actual_t-offset))<1e-8 and np.max(abs(actual_h-expected_h))<ledger['convergence_tolerance_jm2']
    assert np.max(abs(ledger['layer_residual_jm2']))<=ledger['convergence_tolerance_jm2']
    result=dict(snow_mass_kg_m2=snow.mass.tolist(),independent_temperature_offset_k=offset.tolist(),actual_temperature_offset_k=actual_t.tolist(),
        maximum_temperature_error_k=float(np.max(abs(actual_t-offset))),maximum_enthalpy_error_j_m2=float(np.max(abs(actual_h-expected_h))),
        iterations=ledger['iterations'],original_tolerance_j_m2=ledger['convergence_tolerance_jm2'],layer_residual_j_m2=ledger['layer_residual_jm2'].tolist(),total_energy_residual_j_m2=ledger['residual_jm2'])
record=dict(scope='Private NumPy experiment only, exact retained failed thermal trial. Allow nondecreasing merit only for an exact new snow latent endpoint with exactly equal original maxnorm; original80/tolerance/final layer checks unchanged. Independent all-liquid linear temperature system; not production/GPU/complete-column fix or scientific acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,original_capture_sha256=sha((prior/'diagnosis.json').read_bytes()),source_unchanged=all(sha((s/n).read_bytes())==h for n,h in m.items()),source_manifest_sha256=sha((s/'SOURCE_SHA256.json').read_bytes()),private_source_sha256=sha(text.encode()),failure=failure,result=result,seconds=time.monotonic()-start)
(r/'diagnosis.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert failure is None

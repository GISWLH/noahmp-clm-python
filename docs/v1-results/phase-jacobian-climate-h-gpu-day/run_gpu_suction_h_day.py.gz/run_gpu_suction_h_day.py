from pathlib import Path
import hashlib,json,os,subprocess,sys,time
import numpy as np
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-phase-jacobian-gpu-a';root=base/'fluxnet-first-climate-cycle-20261017-h';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
reference_manifest=json.loads((root/'numpy-source-manifest.json').read_text())
differences={k:dict(native=v,numpy=reference_manifest[k]) for k,v in manifest.items() if k.startswith('src/') and v!=reference_manifest[k]}
assert set(differences)=={'src/noahmp_clm/physics/canopy_phase_energy.py','src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu'}
begun=time.monotonic()
with (root/'cuda-day.log').open('w') as log:
    code=subprocess.run([sys.executable,'-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--stop-after','48'],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
(root/'cuda-day-exit.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun))+'\n');assert code==0
rows=[];failures=[]
for row in json.loads((root/'batch.json').read_text())['cases']:
    folders=[root/'cuda-day'/row['case'],root/'numpy-day'/row['case']];reports=[json.loads((p/'report.json').read_text()) for p in folders]
    assert all(r['source_unchanged'] and r['status']=='running' and r['steps_requested']==17520 and r['steps_completed']==48 for r in reports)
    for field in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert reports[0][field]==reports[1][field]
    assert all(v==reference_manifest[k] for k,v in reports[1]['source_sha256'].items())
    assert all(sha(source/k)==v for k,v in reports[0]['source_sha256'].items())
    data=[]
    for p,r in zip(folders,reports):
        path=p/r['model_npz'];assert sha(path)==r['model_npz_sha256']
        with np.load(path,allow_pickle=False) as z:data.append(dict(z))
    for key in ['time_start','time_end']:np.testing.assert_array_equal(data[0][key],data[1][key]);assert len(data[0][key])==48
    fields={}
    for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
        a,b=[d[key].astype(float)*factor+offset for d in data]
        if a.ndim==1:a=a[:,None];b=b[:,None]
        values=[compare_series(a[:,k],b[:,k],var) for k in range(a.shape[1])]
        for k,value in enumerate(values):
            if not value['bias_pass']:failures.append([row['case'],key,k,'bias',value['bias']])
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and value['correlation_pass'] is False:failures.append([row['case'],key,k,'r',value['r']])
        fields[key]=values
    rows.append(dict(case=row['case'],metrics=fields,reports_sha256=[sha(p/'report.json') for p in folders],
        maximum_cumulative_m_h_c_n={name:r['maximum_cumulative_residual_m_h_c_n'] for name,r in zip(['cuda32','numpy64'],reports)}))
assert all(sha(source/k)==v for k,v in manifest.items())
result=dict(scope='Four fresh explicit-suction first48 CUDA32 versus independent NumPy64. Disclosed three phase solver source differences, identical physical equations; not annual/spinup/observed acceptance or a JAX trajectory.',cases=rows,failures=failures,source_differences=differences,instrument_sha256=sha(Path(__file__)),source_unchanged=True)
(root/'backend-day-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(failures=failures,source_unchanged=True,cases=len(rows))),flush=True)
assert not failures,failures

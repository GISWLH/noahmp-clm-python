from pathlib import Path
import datetime,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-joint-chord-a';r=b/'k78-failure-a';assert not (r/'launch.json').exists();env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'));rows=[]
for name in ['cuda32','jax32']:
 with (r/(name+'-replay.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'replay_k78_backend_a.py'),name],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 rows.append(dict(backend=name,pid=p.pid))
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=rows,scope='Independent one-step diagnostics of original failed K78 only on GPU1, no failed trajectory resume, source/precisions/gates unchanged; L scientific CUDA and current493 full regression stay untouched.')
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

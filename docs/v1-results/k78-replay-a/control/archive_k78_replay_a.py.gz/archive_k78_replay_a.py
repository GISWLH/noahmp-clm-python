from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-failure-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison=json.loads((r/'comparison.json').read_text());assert len(comparison['fields'])==329 and len(comparison['failed'])==1
for name in ['cuda32','jax32']:
 d=json.loads((r/name/'receipt.json').read_text());assert d['failure'] is None and d['source_unchanged'] and sha(r/name/'output.npz')==d['result']['output_sha256']
a=b/'k78-replay-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.rglob('*')):
  if p.is_file():t.add(p,arcname='k78-failure-a/'+p.relative_to(r).as_posix(),recursive=False)
 for n in ['export_k78_failure_a.py','replay_k78_backend_a.py','launch_k78_replay_a.py','compare_k78_replay_a.py','archive_k78_replay_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

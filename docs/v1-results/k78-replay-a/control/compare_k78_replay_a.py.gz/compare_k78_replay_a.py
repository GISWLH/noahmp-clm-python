from pathlib import Path
import hashlib,json
import numpy as np
r=Path('/home/lhwang/work/noahmp-v1/k78-failure-a');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cuda32','jax32']:
 receipt=json.loads((r/name/'receipt.json').read_text());assert receipt['failure'] is None and receipt['source_unchanged'] and sha(r/name/'output.npz')==receipt['result']['output_sha256']
rows=[];failed=[]
with np.load(r/'cuda32/output.npz',allow_pickle=False) as a,np.load(r/'jax32/output.npz',allow_pickle=False) as b:
 assert a.files==b.files
 for name in a.files:
  x,y=a[name],b[name];delta=np.abs(x.astype(float)-y.astype(float));maximum=float(delta.max()) if delta.size else 0.
  equal=bool(np.array_equal(x,y));passed=bool(np.allclose(x,y,rtol=1e-6,atol=1e-6)) if x.dtype.kind not in 'ibu' else equal
  row=dict(field=name,maximum_absolute=maximum,bitwise_equal=equal,passed=passed)
  if maximum:
   index=np.unravel_index(np.argmax(delta),delta.shape);row.update(index=list(map(int,index)),cuda=float(x[index]),jax=float(y[index]))
  rows.append(row)
  if not passed:failed.append(row)
 top={name:dict(cuda=a['surface/'+name].tolist(),jax=b['surface/'+name].tolist()) for name in ['ground_nonshortwave_heat','ground_heat','thermal_temperature_offset','thermal_layer_residual']}
d=dict(scope='All actual original K78 whole-step fields and next16 arrays compared under unmodified rtol=atol1e-6; independent per-backend original MHCN audits completed. Counterfactual only, no original failed trajectory advancement, no gate relaxation.',fields=rows,failed=failed,selected_thermal=top,next_arrays_bitwise_equal=all(v['bitwise_equal'] for v in rows if v['field'].startswith('next')))
(r/'comparison.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(field_count=len(rows),nonzero=[v for v in rows if v['maximum_absolute']],failed=failed,next_arrays_bitwise_equal=d['next_arrays_bitwise_equal'],ground_fluxes=top['ground_nonshortwave_heat'])))

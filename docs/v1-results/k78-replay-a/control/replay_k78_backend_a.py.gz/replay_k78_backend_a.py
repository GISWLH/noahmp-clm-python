from pathlib import Path
import hashlib,json,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-joint-chord-a';r=b/'k78-failure-a';name=sys.argv[1];out=r/name;out.mkdir(exist_ok=False);sys.path[:0]=[str(s/'src'),str(s/'benchmarks')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());binding=json.loads((r/'binding.json').read_text());assert sha(r/'input.npz')==binding['input_sha256']
import run_fluxnet_native as driver
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
backend=driver.Backend(name);prefix='a' if name=='cuda32' else 'shadow';before=tuple(np.ascontiguousarray(data[prefix+str(k)]) for k in range(16));devices=tuple(backend.xp.asarray(v) for v in before);devices=backend.update_forcing(devices,data['environment']);before=tuple(backend.host(v) for v in devices)
kwargs=dict(environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']),return_surface=True)
begun=time.monotonic();failure=None;record=None
try:
 result_device=backend.step(*devices,data['forcing'],**kwargs);result=backend.host(result_device);after=tuple(backend.host(v) for v in driver.next_bgc_arrays(devices,result_device))
 flat={}
 def flatten(value,path=''):
  for key,v in value.items():
   if isinstance(v,dict):flatten(v,path+key+'/')
   else:flat[path+key]=np.asarray(v)
 flatten(result);flat.update({'next'+str(k):v for k,v in enumerate(after)});np.savez_compressed(out/'output.npz',**flat)
 incoming,residual,bound,tracer=driver.audit_step(before,after,data['forcing'],data['deposition'],data['nitrogen'],result)
 if name=='cuda32':backend.xp.cuda.runtime.deviceSynchronize()
 else:
  import jax
  jax.effects_barrier()
 record=dict(output_sha256=sha(out/'output.npz'),residual_m_h_c_n=residual.tolist(),original_bounds=bound.tolist(),thermal_residual=np.asarray(result['surface']['thermal_layer_residual']).tolist())
except Exception as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
unchanged=all(sha(s/n)==v for n,v in m.items());value=dict(scope='Counterfactual exact original K78 backend whole-step replay only. Original primary or independent shadow prestate, no trajectory advancement/relabel. Original raising, MHCN and1e-6 comparison gates not relaxed.',backend=name,failure=failure,result=record,seconds=time.monotonic()-begun,source_unchanged=unchanged);(out/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(dict(backend=name,failure=failure,seconds=value['seconds'])),flush=True)
sys.stdout.flush();sys.stderr.flush()
import os
os._exit(0 if failure is None and unchanged else 1)

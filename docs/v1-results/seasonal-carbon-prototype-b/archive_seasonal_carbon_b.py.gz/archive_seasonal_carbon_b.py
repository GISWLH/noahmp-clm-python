from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'p6-spinup-assessment-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in m.items())
assert (root/'seasonal-fixed-point-a-exit.txt').read_text().strip()=='1'
assert "TypeError: bad operand type for abs(): 'list'" in (root/'seasonal-fixed-point-a.log').read_text()
assert (root/'seasonal-fixed-point-b-exit.txt').read_text().strip()=='0'
r=json.loads((root/'seasonal-fixed-point-b.json').read_text())
assert r['pbs_job']=='102.manager' and r['source_unchanged'] and not r['scientific_acceptance_claim'] and len(r['cases'])==2
assert sha(root/'probe_seasonal_carbon_fixed_point_b.py')==r['probe_sha256']
for c in r['cases']:
    assert c['minimum_n_limitation_unlimited_case']==1 and c['limited_n_negative_control']['minimum_n_limitation']<1 and not c['limited_n_negative_control']['linear_applicability']
names=['SOURCE_SHA256.json','probe_seasonal_carbon_fixed_point_a.py','probe_seasonal_carbon_fixed_point_b.py',
       'seasonal_fixed_point_a.pbs','seasonal_fixed_point_b.pbs','seasonal-fixed-point-a.log','seasonal-fixed-point-a-exit.txt',
       'seasonal-fixed-point-b.log','seasonal-fixed-point-b-exit.txt','seasonal-fixed-point-b.json',
       'src/noahmp_clm/physics/decomposition.py']
archive=base/'seasonal-carbon-prototype-b-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for n in names:t.add(root/n,arcname=n,recursive=False)
    t.add(Path(__file__),arcname='archive_seasonal_carbon_b.py',recursive=False)
print(json.dumps(dict(files=len(names)+1,archive_sha256=sha(archive),scope=r['scope'],pbs_job=r['pbs_job'],node=r['node'])))

from pathlib import Path
import hashlib,json,math,os,time
import numpy as np
from scipy.linalg import expm
from noahmp_clm.physics.decomposition import DecompositionState,DecompositionParameters,step_decomposition,POOLS
assert os.environ.get('PBS_JOBID');root=Path.cwd();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in m.items());begun=time.monotonic()
output=root/'seasonal-fixed-point-b.json';assert not output.exists();p=DecompositionParameters();day=86400.;year=365.*day
# Independent carbon routing coefficients from the published CENTURY table,
# not the production cascade/basis-step helper. All rates remain standard.
route=np.zeros((7,7));route[4,0]=.45;route[4,1]=.5;route[5,2]=.5
route[1,3]=p.wood_cellulose_fraction;route[2,3]=1.-p.wood_cellulose_fraction
route[5,4]=1.-(.17+.68*p.sand_fraction)-.004;route[6,4]=.004
route[4,5]=.42;route[6,5]=.03;route[4,6]=.45
rows=[]
for name,mean,amplitude,wood in [('temperate-wood',285.,10.,.08),('cold-grass',275.,20.,0.)]:
    phase=2.*np.pi*np.arange(365)/365.;temperature=mean+amplitude*np.sin(phase)
    potential=-.2-1.4*(.5+.5*np.cos(phase+.4));source=[];discrete=[];continuous=[]
    for k,(t,psi) in enumerate(zip(temperature,potential)):
        effective=min(float(psi),-334000.*max(273.15-float(t),0.)/(1000.*float(t)))
        moisture=0. if effective<=-2.5 else (1. if effective>=-.002 else math.log(-2.5/effective)/math.log(1250.))
        modifier=1.5**((float(t)-298.15)/10.)*moisture
        rate=modifier/(np.asarray(p.turnover_years)*year);loss=-np.expm1(-rate*day)
        a=np.eye(7)-np.diag(loss)+route@np.diag(loss)
        exact=expm((route-np.eye(7))@np.diag(rate)*day)
        amount=1.2*(.35+.65*max(float(np.sin(phase[k])),0.))+.1
        ci=np.r_[amount*np.array([.3,.45,.25]),wood,0.,0.,0.];source.append(ci)
        def affine(matrix):
            v=np.eye(8);v[:7,:7]=matrix;v[:7,7]=matrix@ci;return v
        discrete.append(affine(a));continuous.append(affine(exact))
    def annual(maps):
        result=np.eye(8)
        for v in maps:result=v@result
        return result
    annual_discrete=annual(discrete);annual_continuous=annual(continuous)
    eq=np.linalg.solve(np.eye(7)-annual_discrete[:7,:7],annual_discrete[:7,7])
    reference=np.linalg.solve(np.eye(7)-annual_continuous[:7,:7],annual_continuous[:7,7]);assert np.all(eq>=0) and np.all(reference>=0)
    nonzero=reference>1.;difference=abs(eq-reference);relative=np.divide(difference,reference,out=np.zeros(7),where=nonzero)
    assert np.all(relative[nonzero]<=.1) and np.all(difference[~nonzero]<=.1)
    rho=float(max(abs(np.linalg.eigvals(annual_discrete[:7,:7]))));assert 0.<rho<1.
    cycles=int(np.ceil(np.log(1e-12)/np.log(rho)))+1;assert cycles<1000000
    iterated=(np.linalg.matrix_power(annual_discrete,cycles)@np.r_[np.zeros(7),1.])[:7]
    power_error=abs(iterated-eq);assert np.all(power_error<=np.maximum(.000001,1e-8*eq))
    start=DecompositionState(eq,eq/np.array([25.,25.,25.,500.,8.,11.,11.]),1e6);state=start
    trajectory=[];respiration=0.;cumulative_bounds=np.zeros(2);minimum_limitation=1.;max_step=np.zeros(2);prediction=eq.copy()
    for k in range(365):
        state,d=step_decomposition(state,float(temperature[k]),float(potential[k]),day,carbon_input=source[k],nitrogen_input=source[k]/25.,parameters=p)
        minimum_limitation=min(minimum_limitation,d['nitrogen_limitation']);assert d['nitrogen_limitation']==1.
        prediction=(discrete[k]@np.r_[prediction,1.])[:7]
        trajectory.append(float(abs(state.carbon-prediction).max()));respiration+=d['heterotrophic_respiration_gc_m2']
        max_step=np.maximum(max_step,np.abs([d['carbon_residual_gc_m2'],d['nitrogen_residual_gn_m2']]))
        cumulative_bounds+=np.array([d['carbon_bound_gc_m2'],d['nitrogen_bound_gn_m2']])
    cr=float(state.carbon.sum()-start.carbon.sum()-np.asarray(source).sum()+respiration)
    nr=float(state.nitrogen.sum()+state.mineral_nitrogen-start.nitrogen.sum()-start.mineral_nitrogen-np.asarray(source).sum()/25.)
    assert np.all(np.abs([cr,nr])<=cumulative_bounds)
    assert max(trajectory)<1e-7
    poor=DecompositionState(eq,eq/100.,0.);poor_prediction=eq.copy();minimum_poor=1.
    for k in range(365):
        poor,d=step_decomposition(poor,float(temperature[k]),float(potential[k]),day,carbon_input=source[k],nitrogen_input=source[k]/1000.,parameters=p)
        minimum_poor=min(minimum_poor,d['nitrogen_limitation']);poor_prediction=(discrete[k]@np.r_[poor_prediction,1.])[:7]
    assert minimum_poor<1.
    rows.append(dict(case=name,pool_names=POOLS,normal_discrete_periodic_pools_gc_m2=eq.tolist(),independent_continuous_periodic_pools_gc_m2=reference.tolist(),
        maximum_non_near_zero_reference_relative_difference=float(relative[nonzero].max()),maximum_near_zero_reference_absolute_difference_gc_m2=float(difference[~nonzero].max(initial=0.)),
        annual_spectral_radius=rho,conditional_carbon_map_repetitions=cycles,maximum_repeated_operator_fixed_point_difference_gc_m2=float(power_error.max()),
        maximum_production_cycle_operator_difference_gc_m2=max(trajectory),production_carbon_endpoint_change_gc_m2=(state.carbon-start.carbon).tolist(),
        maximum_step_carbon_nitrogen_residual=max_step.tolist(),cumulative_carbon_nitrogen_residual=[cr,nr],cumulative_carbon_nitrogen_bounds=cumulative_bounds.tolist(),
        minimum_n_limitation_unlimited_case=minimum_limitation,limited_n_negative_control=dict(minimum_n_limitation=minimum_poor,maximum_carbon_map_disagreement_gc_m2=float(abs(poor.carbon-poor_prediction).max()),linear_applicability=False),
        caveat='Prescribed synthetic seasonal climate and litter only; abundant N is a diagnostic condition. Operator powers advance conditional carbon algebra, not an actual coupled C/N/water/heat trajectory or observed spinup. No field seed or production parameter is changed.'))
assert all(sha(root/n)==v for n,v in m.items())
result=dict(scope='Bounded independent seasonal-carbon periodic-state prototype; original normal rates and physical source untouched. No adoption, field initialization, actual coupled spinup, observed validation or performance claim.',
    cases=rows,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-begun,source_files=len(m),source_unchanged=True,probe_sha256=sha(__file__),scientific_acceptance_claim=False)
output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result),flush=True)

from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-physical-cuda-year-c';s=b/'p6-most-physical-c';a=b/'qia-physical-cuda-launch-c-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=(r/'trajectory/batch.json').read_bytes();report=json.loads(raw);assert report['status']=='running' and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['identity']['compare_jax32'] is False
with tarfile.open(a,'w:gz') as t:
    for n in ['launch.json','worker.json','controller.log','SOURCE_SHA256.json','protocol.json','strict-cold-reference.npz']:
        p=r/n;t.add(p,arcname=n,recursive=False)
    info=tarfile.TarInfo('batch-snapshot.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    p=r/'trajectory'/report['checkpoint_file'];assert sha(p)==report['checkpoint_sha256'];t.add(p,arcname='trajectory/'+p.name,recursive=False)
    for case,descriptor in report['case_reports'].items():
        p=r/'trajectory'/case/descriptor['file'];assert sha(p)==descriptor['sha256'];d=json.loads(p.read_text());t.add(p,arcname='trajectory/'+case+'/'+p.name,recursive=False)
        p=p.parent/d['model_npz'];assert sha(p)==d['model_npz_sha256'];t.add(p,arcname='trajectory/'+case+'/'+p.name,recursive=False)
    for n in ['run_qia_physical_cuda_year_c.py','control_qia_physical_cuda_year_c.py','launch_qia_physical_cuda_year_c.py','archive_qia_physical_cuda_launch_c.py']:
        t.add(b/n,arcname='control/'+n,recursive=False)
    for n in ['cuda32-exit.json','jax32-exit.json','exit.json']:
        t.add(s/'production1519-controller-c'/n,arcname='prerequisite1519/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,steps_completed=report['steps_completed'],steps_requested=17520,scope='Actual new509C original-cold CUDA-only launch and immutable generation snapshot after CPU909/final1519 raw361 maxdiff0. New own48 will be validated before own-prefix continuation. No original failed trajectory resumed,no JAX shadow/science/full-canonical/year completion.')))

from pathlib import Path
import hashlib
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-numpy-cuda-week-a'
d = json.loads((r / 'comparison.json').read_text())
assert (r / 'pbs-exit.txt').read_text().strip() == '0' and d['pbs_job'] == '245.manager'
assert d['steps'] == 336 and d['exact_time_and_input_identities'] and d['all_gpu_production_files_equal']
assert d['bias_failures'] == [] and d['measured_correlation_failures'] == [] and len(d['cases']) == 8
a = b / 'qia-numpy-cuda-week-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():
            t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=hashlib.sha256(a.read_bytes()).hexdigest(), bytes=a.stat().st_size)))

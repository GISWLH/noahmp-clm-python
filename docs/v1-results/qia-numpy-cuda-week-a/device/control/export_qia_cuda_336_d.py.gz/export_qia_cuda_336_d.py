from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
year = b / 'qia-physical-cuda-year-d'
root = year / 'trajectory'
key = 'CN-Qia-stem-first-cycle'
p = root / key / 'report-0000336-52ba48d48c48464e8f5cbfe8d4aa0884.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads(p.read_text())
assert d['status'] == 'running' and d['steps_completed'] == 336 and d['steps_requested'] == 17520 and d['source_unchanged']
trace = p.parent / d['model_npz']; state = (p.parent / d['batch_checkpoint_file']).resolve()
assert state.parent == root and sha(trace) == d['model_npz_sha256'] and sha(state) == d['batch_checkpoint_sha256']
terminal = json.loads((root / 'batch.json').read_text())
assert terminal['status'] == 'failed' and terminal['steps_completed'] == 3798
a = b / 'qia-cuda336-owned-prefix-d-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for f, name in [(p, 'report.json'), (trace, trace.name), (state, state.name), (year / 'launch.json', 'original-launch.json')]:
        t.add(f, arcname=name, recursive=False)
    summary = dict(scope='Original509C CUDA-yearD immutable physically successful336 generation retained after later terminal3798 failure. Full original19-state and ledger plus336trace; no failed-year continuation or completeyear/science claim. Intended original-calendar336 engineering comparison to current510 NumPy originalcold336 on EHPC only,whole source differs but all GPU production files unchanged.',
                   report_sha256=sha(p), trace_sha256=sha(trace), state_sha256=sha(state), later_terminal_steps=3798,
                   source_manifest_sha256='1c68b4f6f18c6b89610a1a53a4f2ba864dc0beb39e6c7f7dc4dc36a5a111f74a')
    raw = (json.dumps(summary, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

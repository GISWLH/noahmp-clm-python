from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-numpy-cuda-week-a'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
new = b / 'p6-fresh-phase-edge-a-source.tar.gz'
old = b / 'p6-most-physical-c-source.tar.gz'
assert sha(new) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
assert sha(old) == 'bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(new) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
with tarfile.open(old) as t:
    old_m = json.load(t.extractfile('SOURCE_SHA256.json'))
assert all(old_m[n] == v for n, v in m.items() if n.startswith('src/noahmp_clm/gpu/'))
assert all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
from noahmp_clm.validation import compare_series

week = b / 'qia-fresh-phase-numpy-week-a'
nd = json.loads((week / 'trajectory/report.json').read_text())
nr = json.loads((week / 'receipt.json').read_text())
assert (week / 'pbs-exit.txt').read_text().strip() == '0' and nr['returncode'] == 0 and nr['source_unchanged']
assert sha(week / 'trajectory/report.json') == nr['report_sha256'] and nd['steps_completed'] == 336 and nd['status'] == 'running'
native = r / 'device'
cd = json.loads((native / 'report.json').read_text())
bind = json.loads((native / 'summary.json').read_text())
assert cd['steps_completed'] == 336 and cd['status'] == 'running' and cd['source_unchanged']
assert sha(native / 'report.json') == bind['report_sha256']
assert cd['model_npz_sha256'] == sha(native / cd['model_npz']) and nd['model_npz_sha256'] == sha(week / 'trajectory' / nd['model_npz'])
for name in ['forcing_npz_sha256', 'forcing_manifest_sha256', 'configuration_sha256']:
    assert cd[name] == nd[name], name
with np.load(native / cd['model_npz'], allow_pickle=False) as z:
    cuda = dict(z)
with np.load(week / 'trajectory' / nd['model_npz'], allow_pickle=False) as z:
    reference = dict(z)
for name in ['time_start', 'time_end']:
    assert np.array_equal(cuda[name], reference[name]) and len(cuda[name]) == 336
assert str(cuda['time_start'][0]) == '200301010000' and str(cuda['time_end'][-1]) == '200301080000'
scalars = [('h_wm2', 'h_wm2', 1.), ('le_wm2', 'le_wm2', 1.), ('et_mm', 'et_mm_day', 48.),
           ('runoff_mm', 'runoff_mm_day', 48.), ('gpp_gc_m2', 'gpp_gc_day', 48.), ('nee_gc_m2', 'nee_gc_day', 48.), ('swe_m', 'swe_m', 1.)]
cases = {}
for label, sl in [('all-original336', slice(0, 336))] + [('day' + str(k + 1), slice(k * 48, (k + 1) * 48)) for k in range(7)]:
    count = len(np.arange(336)[sl]); metrics = {}
    for name, unit, factor in scalars:
        actual = np.asarray(cuda[name], float).reshape(336)[sl] * factor
        expected = np.asarray(reference[name], float).reshape(336)[sl] * factor
        metrics[name] = compare_series(actual, expected, unit, weights=np.full(count, 1800.))
    for name, unit, offset in [('tsoil_k', 'tsoil_c', 273.15), ('smc_m3m3', 'smc', 0.)]:
        actual = np.asarray(cuda[name], float).reshape(336, 4)[sl] - offset
        expected = np.asarray(reference[name], float).reshape(336, 4)[sl] - offset
        for layer in range(4):
            metrics[name + '/' + str(layer)] = compare_series(actual[:, layer], expected[:, layer], unit, weights=np.full(count, 1800.))
    cases[label] = metrics
record = dict(scope='EHPC PBS engineering comparison only: original continuous cold336 NumPy510 vs immutable original CUDA509C own336,all original7days and everyvariable/layer preserved. Whole source identities differ by NumPy endpoint regression/test fixture;all GPU productionfiles exactly same. Later CUDA3798 failure explicit,not completeyear/spinup/official/observational acceptance or raw32parity. Celsius/declarednearzero/allrawtraces unrounded.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, steps=336, exact_time_and_input_identities=True,
              numpy_report_sha256=sha(week / 'trajectory/report.json'), cuda_report_sha256=sha(native / 'report.json'),
              source_manifest_numpy_sha256=sha(s / 'SOURCE_SHA256.json'), source_manifest_cuda_sha256=bind['source_manifest_sha256'],
              all_gpu_production_files_equal=True, differing_source_entries=[n for n, h in m.items() if old_m.get(n) != h], later_cuda_failed_steps=3798,
              numpy_maximum_cumulative_m_h_c_n=nd['maximum_cumulative_residual_m_h_c_n'], cuda_maximum_cumulative_m_h_c_n=cd['maximum_cumulative_residual_m_h_c_n'],
              cases=cases, bias_failures=[label + '/' + name for label, metrics in cases.items() for name, value in metrics.items() if value['bias_pass'] is False],
              measured_correlation_failures=[label + '/' + name for label, metrics in cases.items() for name, value in metrics.items() if value['correlation_pass'] is False],
              correlations_unmeasured=[label + '/' + name for label, metrics in cases.items() for name, value in metrics.items() if value['correlation_pass'] is None])
(r / 'comparison.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'cases'}, allow_nan=False), flush=True)
print(json.dumps(dict(all336=cases['all-original336']), allow_nan=False), flush=True)

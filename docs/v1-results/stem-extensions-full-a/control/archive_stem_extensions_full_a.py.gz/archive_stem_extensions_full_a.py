from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-extensions-numpy-a';a=b/'stem-extensions-full-a-evidence.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'cpu-full-receipt.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=864,failures=0,errors=0,skipped=0) and (r/'pbs-exit.txt').read_text().strip()=='0';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname=p.name,recursive=False)
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib
import json
import tarfile

b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-stem-cuda-1519-a'
a=b/'qia1519-probes-a-evidence.tar.gz';assert not a.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=r.name+'/'+p.relative_to(r).as_posix(),recursive=False)
    controls=['export_qia_cuda_1519_a.py','trace_qia_cuda_1519_a.py','launch_qia_cuda_1519_trace_a.py','probe_qia_cuda_1519_physical_a.py','launch_qia_cuda_1519_physical_a.py','probe_qia_1519_physical_jax_a.py','launch_qia_1519_physical_jax_a.py','probe_qia1519_target_a.py','launch_qia1519_target_a.py','archive_qia1519_probes_a.py']
    for n in controls:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(b/'p6-stem-split-f/SOURCE_SHA256.json',arcname='original-source-manifest.json',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Immutable original1519 trace plus isolated CUDA/JAX physical counterfactual and one updated-target comparison. Production not changed,original failed year not advanced. Original standalone probes have no parent actual-exit receipt; final receipts/device synchronization and observed process absence retained,not fabricated exits.')))

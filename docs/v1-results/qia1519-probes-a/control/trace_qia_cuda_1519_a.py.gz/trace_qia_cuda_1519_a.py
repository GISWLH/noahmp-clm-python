from pathlib import Path
from collections import deque
import hashlib,inspect,json,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-f';r=b/'qia-stem-cuda-1519-a';out=r/'most-trace-a';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as driver
import noahmp_clm.gpu.canopy_most_surface as module
binding=json.loads((r/'binding.json').read_text());assert sha(r/'input.npz')==binding['input_sha256']
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
backend=driver.Backend('cuda32');xp=backend.xp;before=tuple(xp.asarray(np.ascontiguousarray(data['a'+str(k)])) for k in range(19));before=backend.update_forcing(before,data['environment']);old=tuple(backend.host(v) for v in before);history=[];earlier_calls=[];last=deque(maxlen=2)
def capture(local):
 if local['count']==1 and history:earlier_calls.append(history.copy());history.clear();last.clear()
 record={key:backend.host(local[key]).tolist() if hasattr(local[key],'shape') else local[key] for key in ['count','zeta','effective','done','relaxation','stable_bracket','lower','upper','mismatch']}
 surface=local['surface'];previous=local['previous'];record.update(h=backend.host(surface['h']).tolist(),le=backend.host(surface['le']).tolist())
 if previous is not None:
  record.update(heat_change=backend.host(abs(surface['h']-previous[0])).tolist(),vapor_change=backend.host(abs(local['vapor']-previous[1])).tolist(),leaf_temperature_change=backend.host(xp.max(abs(surface['leaf_temperature']-previous[2]),axis=1)).tolist())
 history.append(record);flat={}
 for key,value in surface.items():
  if not isinstance(value,dict):flat['surface/'+key]=backend.host(value)
 for key,value in local['current'].items():flat['current/'+key]=backend.host(value)
 last.append((local['count'],flat))
original=module.run_most_surface;source=inspect.getsource(original);marker='        if previous is not None:\n';assert source.count(marker)==1;instrumented=source.replace(marker,'        capture(locals())\n'+marker);namespace=dict(original.__globals__,capture=capture);exec(compile(instrumented,'<readonly Qia1519 MOST trace>','exec'),namespace);module.run_most_surface=namespace['run_most_surface'];begun=time.monotonic();failure=None
try:
 backend.step(*before,data['forcing'],environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']),return_surface=True)
except Exception as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:module.run_most_surface=original
xp.cuda.runtime.deviceSynchronize();unchanged=all(sha(s/n)==v for n,v in m.items());input_unchanged=all(np.array_equal(v,backend.host(w)) for v,w in zip(old,before));assert unchanged and input_unchanged
(out/'history.json').write_text(json.dumps(history,indent=2)+'\n');flat={str(count)+'/'+key:value for count,values in last for key,value in values.items()};np.savez_compressed(out/'last-surfaces.npz',**flat)
value=dict(scope='Counterfactual CUDA32 original Qia1519 failed step with read-only host capture inside original50 MOST loop, no source files or accepted trajectory changed. No uninstrumented full-output equivalence claim, no gate/iteration relaxation.',failure=failure,iterations=len(history),source_unchanged=unchanged,input_unchanged=input_unchanged,input_sha256=sha(r/'input.npz'),instrumented_function_sha256=hashlib.sha256(instrumented.encode()).hexdigest(),original_function_sha256=hashlib.sha256(source.encode()).hexdigest(),seconds=time.monotonic()-begun,earlier_completed_most_calls=len(earlier_calls),last_original_flux_tests_pass=bool(history[-1]['heat_change'][0]<=.05 and history[-1]['vapor_change'][0]<=2e-8 and history[-1]['leaf_temperature_change'][0]<=.01),last_original_coefficient_test_pass=bool(history[-1]['mismatch'][0]<=1e-4),last_original_values=history[-1],history_sha256=sha(out/'history.json'),surfaces_sha256=sha(out/'last-surfaces.npz'));(out/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True);assert len(history)==50 and failure=='RuntimeError: Native MOST flux feedback did not converge in 50 iterations'

from pathlib import Path
from dataclasses import astuple
import hashlib
import json
import sys
import tarfile

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-stem-split-f'
old = b / 'qia-stem-cuda-year-c'
r = b / 'qia-stem-cuda-1519-a'
r.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 506 and all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

exit_record = json.loads((old / 'exit.json').read_text())
receipt = json.loads((old / 'receipt.json').read_text())
assert exit_record['returncode'] == 1 and not exit_record['passed']
report, saved, _ = driver.read_generation(old / 'trajectory')
assert report['status'] == 'failed' and report['steps_completed'] == 1519 and report['steps_requested'] == 17520
assert receipt['source_unchanged'] and receipt['failure'] == 'RuntimeError: Native MOST flux feedback did not converge in 50 iterations'
cases = driver.load_batch(old / 'inputs/batch.json')
assert len(cases) == 1 and driver.native_state_count(cases) == 19 and not report['identity']['compare_jax32']
index = report['steps_completed']
forcing = np.asarray([c['data']['forcing'][index] for c in cases], np.float32)
environment = np.asarray([c['data']['environment'][index] for c in cases], np.float32)
calendar_values, calendar_flags = driver.pack_bgc_environment([driver.calendar(c['stamps'][index], c['metadata'], c['config']['phenology'] is not None) for c in cases], dtype=np.float32)
schedules = [driver.DepositionSchedule(c['config']) for c in cases]
nitrogen = np.asarray([v.nitrogen_rate for v in schedules], np.float32) * forcing[:, 0]
deposition = np.asarray([d.aerosol(c['stamps'][index], forcing[k, 0]) for k, (c, d) in enumerate(zip(cases, schedules))], np.float32)
geometry = np.asarray([astuple(driver.MOSTGeometry(**c['config']['most_geometry'])) for c in cases], np.float32)
payload = {'a' + str(k): value for k, value in enumerate(driver.checkpoint_arrays(saved, report['identity']))}
payload.update(forcing=forcing, environment=environment, calendar_values=calendar_values, calendar_flags=calendar_flags, nitrogen=nitrogen, deposition=deposition, geometry=geometry)
np.savez_compressed(r / 'input.npz', **payload)
binding = dict(scope='Original failed CUDA-only1519 primary19 plus7 ledger checkpoint; pack exact next forcing/calendar/deposition/geometry for diagnosis only on xuanze. No GPU physics executes during export, no failed state accepted or annual resume. Original native MOST50 and all MHCN/1e-6 gates retained.', index=index, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), input_sha256=sha(r / 'input.npz'), native_state_arrays=19, original_checkpoint_sha256=report['checkpoint_sha256'], leaf_parameters=cases[0]['config']['leaf_parameters'], time_start=str(cases[0]['data']['time_start'][index]), original_failure=report['failure'], maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'])
(r / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
(r / 'SOURCE_SHA256.json').write_bytes((s / 'SOURCE_SHA256.json').read_bytes())
a = b / 'qia-stem-cuda-year-terminal-c-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for name in ['launch.json', 'worker.json', 'receipt.json', 'exit.json', 'model.log', 'traceback.txt']:
        t.add(old / name, arcname=name, recursive=False)
    for name in ['batch.json', report['checkpoint_file']]:
        t.add(old / 'trajectory' / name, arcname='trajectory/' + name, recursive=False)
    for case, desc in report['case_reports'].items():
        p = old / 'trajectory' / case / desc['file']
        d = json.loads(p.read_text())
        assert sha(p) == desc['sha256'] and sha(p.parent / d['model_npz']) == d['model_npz_sha256']
        t.add(p, arcname='trajectory/' + case + '/' + p.name, recursive=False)
        t.add(p.parent / d['model_npz'], arcname='trajectory/' + case + '/' + d['model_npz'], recursive=False)
    for p in sorted(r.iterdir()):
        t.add(p, arcname='diagnostic-input/' + p.name, recursive=False)
    for name in ['run_qia_stem_cuda_year_c.py', 'control_qia_stem_cuda_year_c.py', 'launch_qia_stem_cuda_year_c.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
assert all(sha(s / n) == v for n, v in m.items())
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, binding=binding)))

"""Counterfactual final-surface audit, never an accepted annual step."""
from pathlib import Path
import hashlib
import inspect
import json
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-stem-split-f'
r = b / 'qia-stem-cuda-1519-a'
out = r / 'target-probe-a'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 506 and all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver
import noahmp_clm.gpu.canopy_most_surface as module

binding = json.loads((r / 'binding.json').read_text())
assert sha(r / 'input.npz') == binding['input_sha256']
with np.load(r / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
original_report, original_saved, _ = driver.read_generation(b / 'qia-stem-cuda-year-c/trajectory')
assert original_report['status'] == 'failed' and original_report['steps_completed'] == 1519
assert original_report['checkpoint_sha256'] == binding['original_checkpoint_sha256']
engine = driver.Backend('cuda32')
xp = engine.xp
original_arrays = tuple(data['a' + str(k)] for k in range(19))
before = engine.update_forcing(tuple(xp.asarray(v) for v in original_arrays), data['environment'])
device_before_host = tuple(engine.host(v) for v in before)
last, alternatives = {}, []

def capture(local):
    last.clear()
    last.update(local)

real = module.run_most_surface
source = inspect.getsource(real)
marker = '        if previous is not None:\n'
assert source.count(marker) == 1
instrumented = source.replace(marker, '        capture(locals())\n' + marker)
namespace = dict(real.__globals__, capture=capture)
exec(compile(instrumented, '<Qia1519 read-only capture>', 'exec'), namespace)
observed = namespace['run_most_surface']

def candidate(*args, **kwargs):
    last.clear()
    try:
        return observed(*args, **kwargs)
    except RuntimeError as e:
        if str(e) != 'Native MOST flux feedback did not converge in 50 iterations':
            raise
        v = last
        assert v['count'] == 50 and v['previous'] is not None
        surface = v['surface']
        dh = xp.abs(surface['h'] - v['previous'][0])
        de = xp.abs(v['vapor'] - v['previous'][1])
        dt = xp.max(xp.abs(surface['leaf_temperature'] - v['previous'][2]), axis=1)
        # A diagnostic hypothesis fixed before execution: original physical
        # flux/T checks plus the task's10% coefficient scale. No production
        # criterion is changed and original residuals remain fully reported.
        eligible = (dh <= .05) & (de <= 2e-8) & (dt <= .01) & (v['mismatch'] <= .1)
        assert bool(xp.all(eligible)), 'Original physical checks or diagnostic10% coefficient bound not satisfied'
        target=v['target'];u=v['u'];arrays=v['arrays']
        trial=xp.concatenate((u[:,:3],xp.stack((target['heat_velocity'],target['ground_velocity'],target['leaf_velocity']),axis=1),u[:,6:]),axis=1)
        extension=xp.stack((target['water_velocity'],target['potential_temperature']),axis=1)
        checked=v['solve'](*arrays[:5],trial,*arrays[6:],parameters=v['parameters'],exchange_extension=extension,vic=v['vic'],**v['stem_options'])
        comparisons={}
        for key in ('h','le','gpp','et_kgm2','runoff_kgm2','leaf_temperature','ground_temperature','canopy_temperature','canopy_humidity','surface_temperature','soil_cells','snow_cells','condensate','energy_residual_jm2','water_residual_kgm2'):
            if key in surface and key in checked:
                a,b=engine.host(surface[key]),engine.host(checked[key])
                comparisons[key]=dict(maximum_absolute_difference=float(np.max(abs(a-b))),last=a.tolist(),target=b.tolist())
        np.savez_compressed(out/'target-surface.npz',**{k:engine.host(value) for k,value in checked.items() if not isinstance(value,dict)})
        (out/'target-comparison.json').write_text(json.dumps(comparisons,indent=2,allow_nan=False)+'\n')
        record = dict(count=50, coefficient_residual=engine.host(v['mismatch']).tolist(), heat_change_Wm2=engine.host(dh).tolist(), water_vapor_change_kgm2s=engine.host(de).tolist(), leaf_temperature_change_K=engine.host(dt).tolist(), original_coefficient_gate_pass=engine.host(v['mismatch'] <= 1e-4).tolist(), original_physical_gates_pass=engine.host((dh <= .05) & (de <= 2e-8) & (dt <= .01)).tolist())
        alternatives.append(record)
        surface['most'] = {**v['current'], **{k: v['feedback'][k] for k in ('zeta', 'raw_zeta', 'buoyancy', 'convective_wind', 'effective_wind')},
                           'used_zeta': v['zeta'], 'used_effective_wind': v['effective'], 'iterations': xp.full(len(dh), 50, xp.int32),
                           'bisection_restarts': v['bisection_restarts'], 'coefficient_residual': v['mismatch'],
                           'heat_change_wm2': dh, 'vapor_change_kgm2s': de, 'leaf_temperature_change_k': dt}
        return surface

module.run_most_surface = candidate
start = time.monotonic()
failure, result = None, None
try:
    device = engine.step(*before, data['forcing'], environment=data['calendar_values'], calendar=data['calendar_flags'], nitrogen_deposition_gn_m2=data['nitrogen'], deposition=data['deposition'], most_geometry=data['geometry'], leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']), return_surface=True)
    host = engine.host(device)
    after = tuple(engine.host(v) for v in driver.next_station_arrays(before, device))
    incoming, residual, bound, tracer = driver.audit_step(original_arrays, after, data['forcing'], data['deposition'], data['nitrogen'], host)
    cumulative = driver.totals(after) - original_saved['initial'] - (original_saved['net'] + incoming)
    bounds = original_saved['bounds'] + bound
    assert np.all(abs(residual) <= bound) and np.all(abs(cumulative) <= bounds)
    flat = {}
    def flatten(value, prefix=''):
        for k, v in value.items():
            if isinstance(v, dict):
                flatten(v, prefix + k + '/')
            else:
                flat[prefix + k] = np.asarray(v)
    flatten(host)
    np.savez_compressed(out / 'diagnostic-output.npz', **flat)
    np.savez_compressed(out / 'diagnostic-state.npz', **{'a' + str(k): v for k, v in enumerate(after)})
    result = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=bounds.tolist(), tracer_residual=tracer, diagnostics={k: np.asarray(v).tolist() for k, v in host['diagnostics'].items()}, output_fields=len(flat))
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (out / 'traceback.txt').write_text(traceback.format_exc())
finally:
    module.run_most_surface = real
xp.cuda.runtime.deviceSynchronize()
unchanged = all(sha(s / n) == v for n, v in m.items())
input_unchanged = all(np.array_equal(v, engine.host(w)) for v, w in zip(device_before_host, before))
assert unchanged and input_unchanged
record = dict(scope='Counterfactual diagnostic only: original50 physical-stable candidate compared to ONE independent inner surface solve at the fully updated feedback-target exchange coefficients, from identical old stores. Last original surface only is audited, target is never committed. No production acceptance change. Original1e-4 coefficient failure retained. Complete step and original independent MHCN audit computed only in this isolated process; never accepted into original failed1519 year, no production source/gate change or science/same-precision pass.', failure=failure, result=result, alternatives=alternatives, source_unchanged=unchanged, input_unchanged=input_unchanged, original_input_sha256=binding['input_sha256'], original_checkpoint_sha256=binding['original_checkpoint_sha256'], seconds=time.monotonic() - start)
(out / 'receipt.json').write_text(json.dumps(record, indent=2, default=lambda v: v.tolist() if hasattr(v, 'tolist') else str(v), allow_nan=False) + '\n')
print(json.dumps(record, default=lambda v: v.tolist() if hasattr(v, 'tolist') else str(v), allow_nan=False), flush=True)
assert failure is None and alternatives

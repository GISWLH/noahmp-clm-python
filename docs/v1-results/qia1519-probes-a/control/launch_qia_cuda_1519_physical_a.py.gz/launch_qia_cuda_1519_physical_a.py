from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-stem-split-f'
r = b / 'qia-stem-cuda-1519-a'
assert not (r / 'physical-launch-a.json').exists()
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='0', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', XLA_PYTHON_CLIENT_PREALLOCATE='false')
with (r / 'physical-a.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'probe_qia_cuda_1519_physical_a.py')], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
d = dict(scope='Diagnostic isolated MOST physical-gate hypothesis on xuanze GPU0; no production source or original failed trajectory change. All original MHCN bounds remain required.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=p.pid)
(r / 'physical-launch-a.json').write_text(json.dumps(d, indent=2) + '\n')
print(json.dumps(d))

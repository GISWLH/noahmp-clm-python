"""Independent extensive heat accounting of the fixed24 Jan3 diagnostic replays."""
from pathlib import Path
import gzip
import hashlib
import json
import math
import os
import pickle
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-winter-summary-hg'
prior = base / 'multisite-winter-energy-he'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert (prior / 'pbs-exit.txt').read_text().strip() == '0'
receipt = json.loads((prior / 'receipt.json').read_text())
assert receipt['passed'] and receipt['source_unchanged'] and len(receipt['cases']) == 24
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 579 and sha(source / 'SOURCE_SHA256.json') == receipt['source_manifest_sha256']
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
begun = time.monotonic()
rows = []
for case in receipt['cases']:
    assert case['failure'] is None and case['captured_steps'] == 48
    assert all(case['full_original_trace_fields_byteexact'].values())
    folder = prior / case['case']
    archive = folder / 'steps.tar.gz'
    assert sha(archive) == case['step_packet_archive_sha256']
    with tarfile.open(archive) as tf:
        assert len(tf.getmembers()) == 48
        packets = [pickle.loads(gzip.decompress(tf.extractfile('call-' + str(k).zfill(5) + '.pkl.gz').read())) for k in range(48)]
    before = packets[0]['before']
    after = packets[-1]['after']
    duration = math.fsum(q['forcing'].dt for q in packets)
    assert duration == 86400.
    def mean_d(name):
        return math.fsum(float(q['diagnostics'][name]) * q['forcing'].dt for q in packets) / duration
    def rate_d(name):
        return math.fsum(float(q['diagnostics'].get(name, 0.)) for q in packets) / duration
    def mean_f(name):
        return math.fsum(float(getattr(q['forcing'], name)) * q['forcing'].dt for q in packets) / duration
    delta_heat = after.enthalpy_jm2 - before.enthalpy_jm2
    ground_change = float(after.ground.enthalpy.sum() - before.ground.enthalpy.sum())
    snow_change = float(after.snow.enthalpy.sum() - before.snow.enthalpy.sum())
    canopy_change = after.canopy_enthalpy_jm2 - before.canopy_enthalpy_jm2
    rhs = duration * (rate_d('precipitation_enthalpy_jm2') + rate_d('irrigation_enthalpy_jm2') +
        rate_d('atmospheric_energy_jm2') - rate_d('advected_enthalpy_jm2') - rate_d('runoff_enthalpy_jm2'))
    diag = dict(rnet=mean_d('rnet'), H=mean_d('h'), LE=mean_d('le'), G=mean_d('ground_heat'),
        swdown=mean_f('swdown'), lwdown=mean_f('lwdown'), air_temperature_k=mean_f('tair'), wind_ms=mean_f('wind'),
        whole_column_storage=delta_heat/duration, ground_storage=ground_change/duration,
        snow_storage=snow_change/duration, canopy_storage=canopy_change/duration,
        atmospheric_heat_input=rate_d('atmospheric_energy_jm2'),
        precipitation_heat_input=rate_d('precipitation_enthalpy_jm2'),
        advected_heat_output=rate_d('advected_enthalpy_jm2'), runoff_heat_output=rate_d('runoff_enthalpy_jm2'),
        independent_whole_column_heat_residual=(delta_heat-rhs)/duration)
    row = dict(case=case['case'], cohort=case['cohort'], date_rule='OriginalJan3, index96to144',
        day_means_or_energy_rates_wm2=diag,
        initial_swe_m=before.swe, final_swe_m=after.swe, initial_lai=before.lai, final_lai=after.lai,
        initial_soil_temperature_k=before.tsoil.tolist(), final_soil_temperature_k=after.tsoil.tolist(),
        original_max_cumulative_residual_m_h_c_n=np.asarray(json.loads((folder / 'trajectory/report.json').read_text())['maximum_cumulative_residual_m_h_c_n']).tolist(),
        original_trace_field_count=len(case['full_original_trace_fields_byteexact']),
        extensive_storage_partition_join_jm2=delta_heat-ground_change-snow_change-canopy_change)
    rows.append(row)
    print(json.dumps(row), flush=True)
result = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=len(rows) == 24,
    cases=rows, source_manifest_sha256=receipt['source_manifest_sha256'],
    source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    original_replay_receipt_sha256=sha(prior / 'receipt.json'), seconds=time.monotonic()-begun,
    scope='All24 originalJan3 replay inputs/outputs, fulltracebyteidentity and originalMHCNguards prerequisite; independently telescope extensive soil/snow/canopy heat and originalexternal fluxintegrals. No causalclaim beyond measured decomposition, no tunedinput/parameters or observational/fullmonth/fullcycle/spinup acceptance.')
(root / 'receipt.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
assert result['passed'] and result['source_unchanged']

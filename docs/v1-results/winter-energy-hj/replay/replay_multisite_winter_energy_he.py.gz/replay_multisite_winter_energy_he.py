"""All24 fixed Jan3 diagnostic replays from successful96 physical checkpoints."""
from pathlib import Path
from copy import deepcopy
from dataclasses import asdict
import gzip
import hashlib
import io
import json
import multiprocessing as mp
import os
import pickle
import sys
import tarfile
import time
import traceback
import zipfile
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-winter-energy-he'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
file_sha = lambda p: sha(Path(p).read_bytes())
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert file_sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = file_sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(file_sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner

plan = json.loads((root / 'plan.json').read_text())
assert all(file_sha(root / name) == digest for name, digest in plan['controls_sha256'].items())
originals = base / 'multisite-observations-ha'
original_receipt = json.loads((originals / 'receipt.json').read_text())
assert (originals / 'pbs-exit.txt').read_text().strip() == '0'
assert original_receipt['evaluation_delivered'] and original_receipt['source_unchanged'] and len(original_receipt['cases']) == 24
cohorts = json.loads((originals / 'plan.json').read_text())['cohorts']
capsules = {}
for label, filename, expected in [
    ('zero-deposition-control', 'multisite-reference-years-gh-evidence.tar.gz', '0d1560f7329c9583146214e42d4a8fb0047e2db5c3a6b694fb4079a5dc3f6b17'),
    ('official-climatology', 'climatology-year-readiness-gz-evidence.tar.gz', 'c13748eb4ecdf22184f0398fb53bd2a06373f514d1335cf1b4872a6b6f55a264')]:
    archive = base / filename
    assert file_sha(archive) == expected
    with tarfile.open(archive) as tf:
        capsules[label] = {member.name: tf.extractfile(member).read() for member in tf}
for cohort in cohorts:
    inputs = Path(os.environ['TMPDIR']) / cohort['name']
    inputs.mkdir()
    archive = base / cohort['input_archive']
    assert file_sha(archive) == cohort['input_archive_sha256']
    with tarfile.open(archive) as tf:
        tf.extractall(inputs, filter='data')


def seed_bytes(case):
    label = case['cohort']
    name = case['case']
    files = capsules[label]
    if label == 'zero-deposition-control':
        prefix = 'cases/' + name + '/'
        assert files[prefix + 'segment-000048-pbs-exit.txt'].strip() == b'0'
        pilot = json.loads(files[prefix + 'segment-000048-receipt.json'])
        saved = {n: files[prefix + 'generation96-after-original-resume/' + n]
                 for n in ['state-0000096.pkl', 'trace-0000096.npz']}
        original_report = None
    else:
        prefix = 'cpu-pilots/cases/' + name + '/'
        assert files[prefix + 'segment-000048-pbs-exit.txt'].strip() == b'0'
        pilot = json.loads(files[prefix + 'segment-000048-receipt.json'])
        with zipfile.ZipFile(io.BytesIO(files[prefix + 'pilot-snapshots-projection.zip'])) as z:
            row = json.loads(z.read('snapshots/' + pilot['report_sha256'] + '.json'))
            assert row['index'] == 96
            saved = {n: z.read(member) for n, member in row['members'].items()}
            assert all(sha(saved[n]) == row['sha256'][n] for n in saved)
            original_report = saved.pop('report.json')
    assert pilot['failure'] is None and pilot['source_unchanged'] and pilot['model_completed_segment']
    assert pilot['first_continued_state_exact'] and pilot['steps_completed'] == 96 and pilot['steps_requested'] == 17520
    assert pilot['source_manifest_sha256'] == source_sha
    return saved, original_report, pilot


def run_case(case):
    folder = root / case['case']
    folder.mkdir()
    trajectory = folder / 'trajectory'
    trajectory.mkdir()
    original_folder = originals / case['cohort'] / case['case']
    template_raw = (original_folder / 'model-report.json').read_bytes()
    assert sha(template_raw) == case['original_report_sha256']
    template = json.loads(template_raw)
    assert template['status'] == 'running' and template['steps_completed'] >= 144
    saved, pilot_report_raw, pilot = seed_bytes(case)
    state_raw = saved['state-0000096.pkl']
    state = pickle.loads(state_raw)
    assert len(state) == 7 and state[-1] == 96
    for name, raw in saved.items():
        (trajectory / name).write_bytes(raw)
    report = deepcopy(template)
    report.update(status='running', steps_completed=96, seconds=0., checkpoint_file='state-0000096.pkl',
        checkpoint_sha256=sha(state_raw), model_npz='trace-0000096.npz',
        model_npz_sha256=sha(saved['trace-0000096.npz']),
        diagnostic_seed_metadata='Explicitly derived metadata for Jan3 replay only; copied original successful96 seven-tuple/state/trace unchanged. Template original later report saved separately. Timing zero is diagnostic timing only, never originalparent identity or a reset of physical cumulative ledgers.')
    (folder / 'original-later-model-report.json').write_bytes(template_raw)
    if pilot_report_raw is not None:
        (folder / 'original-pilot96-report.json').write_bytes(pilot_report_raw)
    (folder / 'successful-pilot-receipt.json').write_text(json.dumps(pilot, indent=2) + '\n')
    runner.atomic_json(trajectory / 'report.json', report)
    (folder / 'derived-diagnostic-seed-report.json').write_bytes((trajectory / 'report.json').read_bytes())
    cohort = next(q for q in cohorts if q['name'] == case['cohort'])
    inputs = Path(os.environ['TMPDIR']) / cohort['name']
    batch = json.loads((inputs / 'batch.json').read_text())
    item = next(q for q in batch['cases'] if q['case'] == case['case'])
    assert file_sha(inputs / item['configuration']) == template['configuration_sha256']
    with np.load(inputs / item['input'], allow_pickle=False) as z:
        assert str(z['time_start'][96]).endswith('01030000')
    packets = folder / 'steps.tar.gz'
    original = runner.step_clm_enthalpy_column
    count = 0
    first_exact = False
    energy = []
    failure = None
    begun = time.monotonic()
    stream = tarfile.open(packets, 'w:gz')

    def capture(before, forcing, **kwargs):
        nonlocal count, first_exact
        if count == 0:
            assert pickle.dumps(before, protocol=5) == pickle.dumps(state[0], protocol=5)
            first_exact = True
        after, diagnostics = original(before, forcing, **kwargs)
        raw = gzip.compress(pickle.dumps(dict(before=before, forcing=forcing, kwargs=kwargs,
            after=after, diagnostics=diagnostics), protocol=5), mtime=0)
        member = tarfile.TarInfo('call-' + str(count).zfill(5) + '.pkl.gz')
        member.size = len(raw)
        stream.addfile(member, io.BytesIO(raw))
        scalars = {key: float(value) for key, value in diagnostics.items()
                   if isinstance(value, (float, int, np.floating, np.integer)) and not isinstance(value, (bool, np.bool_))}
        energy.append(dict(forcing=asdict(forcing), diagnostics=scalars,
            diagnostic_fields=sorted(diagnostics), before_swe_m=before.swe,
            after_swe_m=after.swe, lai_before=before.lai, lai_after=after.lai,
            soil_temperature_before_k=before.tsoil.tolist(), soil_temperature_after_k=after.tsoil.tolist(),
            liquid_before_m3m3=(before.ground.liquid/(1000.*before.ground.dz)).tolist(),
            leaf_absorbed_shortwave_wm2=np.asarray(diagnostics.get('absorbed_shortwave', []), float).tolist(),
            snow_absorbed_shortwave_wm2=np.asarray(diagnostics.get('snow_absorbed_shortwave', []), float).tolist()))
        count += 1
        return after, diagnostics

    exact = {}
    try:
        runner.step_clm_enthalpy_column = capture
        result = runner.run(inputs / item['input'], inputs / item['input_manifest'],
            inputs / item['configuration'], trajectory, resume=True, stop_after=48)
        assert count == 48 and first_exact and result['status'] == 'running'
        assert result['steps_completed'] == 144 and result['steps_requested'] == 17520 and result['source_unchanged']
        assert file_sha(original_folder / 'model-trace.npz') == case['original_trace_sha256']
        with np.load(original_folder / 'model-trace.npz', allow_pickle=False) as a, np.load(trajectory / result['model_npz'], allow_pickle=False) as b:
            assert set(a.files) == set(b.files)
            for name in a.files:
                expected = a[name][:144]
                actual = b[name]
                exact[name] = expected.dtype == actual.dtype and expected.shape == actual.shape and expected.tobytes() == actual.tobytes()
        assert all(exact.values()), 'Diagnostic replay differs from actual original published Jan3 trace'
    except Exception as exc:
        failure = type(exc).__name__ + ': ' + str(exc)
        (folder / 'traceback.txt').write_text(traceback.format_exc())
        print(traceback.format_exc(), flush=True)
    finally:
        runner.step_clm_enthalpy_column = original
        stream.close()
    (folder / 'direct-energy-components.json').write_text(json.dumps(energy, indent=2, allow_nan=False) + '\n')
    record = dict(case=case['case'], cohort=case['cohort'], failure=failure, captured_steps=count,
        first_continued_physical_state_byteexact=first_exact, seed_seven_tuple_sha256=sha(state_raw),
        original_pilot_actual_success=True, full_original_trace_fields_byteexact=exact,
        step_packet_archive_sha256=file_sha(packets), seconds=time.monotonic() - begun,
        source_manifest_sha256=source_sha, source_unchanged=all(file_sha(source / name) == digest for name, digest in manifest.items()),
        scope=plan['scope'])
    (folder / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    return record


begun = time.monotonic()
with mp.get_context('fork').Pool(6) as pool:
    records = pool.map(run_case, original_receipt['cases'])
passed = len(records) == 24 and all(q['failure'] is None and q['captured_steps'] == 48 and
    q['first_continued_physical_state_byteexact'] and q['source_unchanged'] and
    all(q['full_original_trace_fields_byteexact'].values()) for q in records)
receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=passed, cases=records,
    source_manifest_sha256=source_sha, source_unchanged=all(file_sha(source / name) == digest for name, digest in manifest.items()),
    seconds=time.monotonic() - begun, scope=plan['scope'])
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
assert passed and receipt['source_unchanged']

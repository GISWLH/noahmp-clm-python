from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-full-gpu-b';r=s/'full-by-file-b';r.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());begun=time.monotonic()
def verify():assert len(m)==506 and all(sha(s/n)==v for n,v in m.items())
def nodes(raw):
 result=[]
 for c in ET.fromstring(raw).iter('testcase'):
  assert all(c.find(k) is None for k in ['failure','error','skipped']);parts=c.attrib['classname'].split('.');where=[i for i,n in enumerate(parts) if n.startswith('test_')];assert len(where)==1;i=where[0];result.append('tests/'+parts[i]+'.py::'+'::'.join(parts[i+1:]+[c.attrib['name']]))
 assert len(result)==len(set(result));return set(result)
verify()
with (r/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(b/'collect_stem_full_gpu_b.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0;collection=json.loads((r/'collection.json').read_text());allnodes=set(collection['nodes']);assert len(allnodes)==1239 and collection['source_unchanged'] and collection['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
gpu={n for n in allnodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))};cpu=allnodes-gpu;assert len(gpu)==340 and len(cpu)==899
archives={}
for name,digest in [('stem-assessment-full-a','c5a28b7222de9910f75fbb591bb73b773192f402fba3770e9d8bf7d1a6d6bffc'),('stem-assessment-targets-b','aa5611bea033b074fa19879c31926294e8e54b12932644142b7f0a1b3f8632da'),('stem-split-terminal-ef','a7c13afef72e40594b217cc30bfdba562077ede4073fc1bd8296b3cde6e83822')]:
 p=b/(name+'-evidence.tar.gz');assert sha(p)==digest
 with tarfile.open(p) as t:archives[name]={v.name:t.extractfile(v).read() for v in t if v.isfile()}
a=archives['stem-assessment-full-a'];c=archives['stem-assessment-targets-b'];ma=json.loads(a['SOURCE_SHA256.json']);mb=json.loads(c['SOURCE_SHA256.json']);assert mb==m and [n for n in m if ma[n]!=m[n]]==['benchmarks/assess_clm_spinup.py','tests/test_clm_spinup.py']
full=nodes(a['cpu-full.xml']);oldtarget=nodes(a['targets.xml']);target=nodes(c['targets.xml']);assert len(full)==899 and len(target)==69 and target==oldtarget and full==cpu and target<=full
for archive,key,count in [(a,'cpu-full',899),(c,'targets',69)]:
 rec=json.loads(archive[key+'-receipt.json']);assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=count,failures=0,errors=0,skipped=0)
for name in ['benchmarks/assess_clm_spinup.py','tests/test_clm_spinup.py']:
 assert a[name].decode().replace('\r\n','\n').replace('all_columns_state_converged','all_columns_water_heat_sai_converged')==c[name].decode().replace('\r\n','\n')
ef=archives['stem-split-terminal-ef'];me=json.loads(ef['e/SOURCE_SHA256.json']);mf=json.loads(ef['f/SOURCE_SHA256.json']);allowed=['README.md','ROADMAP.md','benchmarks/assess_clm_spinup.py','benchmarks/compare_hrldas_native_year.py','tests/test_clm_spinup.py','tests/test_hrldas_native_year.py'];assert [n for n in m if mf[n]!=m[n]]==allowed and [n for n in mf if me[n]!=mf[n]]==['tests/test_gpu_stem_column_precision.py'];assert all(mf[n]==m[n] for n in m if n.startswith('src/'))
e=json.loads(ef['e/summary.json']);f=json.loads(ef['f/summary.json']);assert e['status']=='failed' and f['status']=='complete';covered=set(cpu);prefix=[];seen=set()
for origin,rows,source in [('e',e['results'][1:],me),('f',f['results'],mf)]:
 for row in rows:
  file=row['file'] if row['file'].startswith('tests/') else 'tests/'+row['file'];receipt=row['receipt'];xml=ef[origin+'/'+Path(file).stem+'.xml'];expected={n for n in gpu if n.split('::')[0]==file};actual=nodes(xml)
  assert row['passed'] and row['returncode']==receipt['worker_exitcode']==receipt['pytest_returncode']==0 and receipt['passed'] and receipt['source_unchanged'] and receipt['all_setup_call_teardown_phases_passed'] and receipt['node_coverage_exact'] and receipt['source_manifest_sha256']==hashlib.sha256(ef[origin+'/SOURCE_SHA256.json']).hexdigest() and source[file]==m[file]==receipt['test_sha256'] and hashlib.sha256(xml).hexdigest()==receipt['xml_sha256'] and actual==expected and not covered&actual
  assert receipt['counts']==dict(tests=len(expected),failures=0,errors=0,skipped=0);covered.update(actual);seen.add(file);prefix.append(dict(origin=origin,file=file,nodes=sorted(actual),original_result=row))
assert len(covered)-899==22
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';files={n.split('::')[0] for n in gpu};pending=sorted(files-seen,key=lambda n:('_column' in n or 'surface' in n,n));scope='Current frozen506B canonical1239: exact EHPC A899/B69 CPU union and physical/test-identical E19/F3 GPU22 prefix, every remaining318 GPU node actually rerun. Previous493 GPU327 is not credited. Original setup/call/teardown/device barriers/worker exits/source/1e-6/conservation gates retained. Interpreter shutdown bypass disclosed,not science/year/spinup acceptance.'
(r/'selection.json').write_text(json.dumps(dict(scope=scope,collected_nodes=sorted(allnodes),cpu_nodes=899,gpu_nodes=340,verified_gpu_prefix_nodes=22,prefix=prefix,pending_files=pending,source_manifest_sha256=sha(s/'SOURCE_SHA256.json')),indent=2)+'\n');results=[]
def save(active=None):
 d=dict(scope=scope,status='running',covered_nodes=len(covered),covered_gpu_nodes=len(covered)-899,collected_nodes=1239,active=active,results=results,seconds=time.monotonic()-begun);tmp=r/'progress.json.tmp';tmp.write_text(json.dumps(d,indent=2)+'\n');os.replace(tmp,r/'progress.json')
save()
for file in pending:
 verify();name=Path(file).stem;expected={n for n in gpu if n.split('::')[0]==file};expected_path=r/(name+'-expected.json');expected_path.write_text(json.dumps(sorted(Path(n.split('::')[0]).name+'::'+n.split('::',1)[1] for n in expected),indent=2)+'\n');receipt_path=r/(name+'-receipt.json');xml=r/(name+'.xml');start=time.monotonic()
 with (r/(name+'.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(worker),'--source',str(s),'--test-file',str(s/file),'--expected',str(expected_path),'--receipt',str(receipt_path),'--xml',str(xml)],cwd=s,stdout=log,stderr=subprocess.STDOUT);save(dict(file=file,pid=p.pid));code=p.wait()
 row=dict(file=file,pid=p.pid,returncode=code,seconds=time.monotonic()-start,passed=False)
 if receipt_path.exists():
  rec=json.loads(receipt_path.read_text());row['receipt']=rec
  if code==rec['worker_exitcode']==rec['pytest_returncode']==0 and rec['passed'] and rec['source_unchanged'] and rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and rec['test_sha256']==m[file] and rec['xml_sha256']==sha(xml) and nodes(xml.read_bytes())==expected:row['passed']=True;covered.update(expected)
 results.append(row);save();print(json.dumps({k:v for k,v in row.items() if k!='receipt'}),flush=True)
verify();complete=covered==allnodes and all(x['passed'] for x in results);(r/'summary.json').write_text(json.dumps(dict(scope=scope,status='complete' if complete else 'failed',source_unchanged=True,collected_nodes=1239,covered_nodes=len(covered),all_node_coverage_exact=covered==allnodes,results=results,prefix=prefix,seconds=time.monotonic()-begun),indent=2)+'\n');raise SystemExit(0 if complete else 1)

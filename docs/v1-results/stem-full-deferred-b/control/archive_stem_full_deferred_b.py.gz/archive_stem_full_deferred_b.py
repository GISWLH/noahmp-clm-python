from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-full-gpu-b';r=s/'full-controller-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'launch.json').read_text());pid=launch['pid'];assert Path('/proc',str(pid),'cmdline').exists();assert b'wait_stem_full_gpu_b.py' in Path('/proc',str(pid),'cmdline').read_bytes();assert launch['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
for name,digest in launch['controls_sha256'].items():assert sha(b/name)==digest
old=b/'p6-material-event-b/full-by-file-b/progress.json';raw=old.read_bytes();d=json.loads(raw);actual=subprocess.check_output(['ps','-p',str(pid)+',597245','-o','pid,ppid,stat,etime,pcpu,args'],text=True);obs=dict(scope='Actual current506B full1239 deferred controller live; waiting old493 resource owner,not completed current GPU regression. Original493 progress and source identity remain separate; no current physics process started before actual old exit. If worker starts later its own original receipts decide completion.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),ps=actual,old493_covered_nodes=d['covered_nodes'],old493_active=d['active'],current_full_worker_started=(r/'worker.json').exists())
a=b/'stem-full-deferred-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [s/'SOURCE_SHA256.json',r/'launch.json',*[b/n for n in launch['controls_sha256']]]:t.add(p,arcname=p.name,recursive=False)
 for name,data in [('observation.json',(json.dumps(obs,indent=2)+'\n').encode()),('captured-old493-progress.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),observation=obs)))

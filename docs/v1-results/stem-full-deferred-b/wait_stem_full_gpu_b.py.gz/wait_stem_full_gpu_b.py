from pathlib import Path
import datetime,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-full-gpu-b';r=s/'full-controller-b';old=b/'p6-material-event-b/full-controller-b/exit.json';missing=None
while not old.exists():
 if not Path('/proc/597245').exists():
  if missing is None:missing=time.monotonic()
  if time.monotonic()-missing>120:raise RuntimeError('Original493 worker missing without actual parent exit receipt; no current GPU test worker launched')
 else:missing=None
 time.sleep(30)
previous=json.loads(old.read_text())
while True:
 free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
 if free>2048:break
 time.sleep(30)
with (r/'full.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'run_stem_full_gpu_b.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original493_actual_exit=previous,device=1,free_memory_mib=free,scope='Fresh current506B full canonical1239 runner starts after actual previous493 parent exit; none of493 GPU results credited. Target899CPU/340GPU with independently checked22 GPU prefix. Running is not pass.'),indent=2)+'\n')
code=p.wait();(r/'exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(code)

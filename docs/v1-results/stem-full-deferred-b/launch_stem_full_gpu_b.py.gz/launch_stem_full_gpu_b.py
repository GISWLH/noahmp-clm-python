from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-full-gpu-b';assert not s.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'p6-stem-assessment-b-source.tar.gz';assert sha(a)=='8a378a471cd163958ca01cb9184343e79624af5f05e427b9397eaffd17cb2ca0'
for name,digest in [('stem-assessment-full-a','c5a28b7222de9910f75fbb591bb73b773192f402fba3770e9d8bf7d1a6d6bffc'),('stem-assessment-targets-b','aa5611bea033b074fa19879c31926294e8e54b12932644142b7f0a1b3f8632da'),('stem-split-terminal-ef','a7c13afef72e40594b217cc30bfdba562077ede4073fc1bd8296b3cde6e83822')]:assert sha(b/(name+'-evidence.tar.gz'))==digest
old=b/'p6-material-event-b/full-controller-b/exit.json'
if not old.exists():assert b'run_material_full_gpu_b.py' in Path('/proc/597245/cmdline').read_bytes()
s.mkdir()
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items());r=s/'full-controller-b';r.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
controls={n:sha(b/n) for n in ['collect_stem_full_gpu_b.py','run_stem_full_gpu_b.py','wait_stem_full_gpu_b.py','launch_stem_full_gpu_b.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'wait_stem_full_gpu_b.py')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=1,source_files=506,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls,scope='Deferred current-source canonical1239 validation: prior CPU899 and same-production/test E19/F3 GPU22 require exact node proof, then remaining318 GPU tests. Wait for actual old493 parent exit; no old493 GPU results credited. Pending launch is not test completion or science acceptance.')
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-capacity-comparison-d';assert not r.exists();r.mkdir();controls={}
for name in ['compare_qia_capacity_station_d.py','qia_capacity_comparison_d.pbs']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
prior=[json.loads((b/('qia-'+label+'-firstday-d')/'dispatch.json').read_text()) for label in ['capacity','capacity_optics']]
jobs=[v['pbs_job'] for v in prior];assert jobs==['308.manager','309.manager']
p=subprocess.run(['qsub','-W','depend=afterok:'+':'.join(jobs),str(r/'qia_capacity_comparison_d.pbs')],cwd=r,text=True,capture_output=True)
assert p.returncode==0,p.stderr
record=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,dependencies=jobs,scope='Deferred comparison on PBS compute only after actualboth cold48 parentPBS0, guards also require both model0/unchanged48. Bothcases/all14 metrics retained, no scoring/default selection; queued not result.')
(r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

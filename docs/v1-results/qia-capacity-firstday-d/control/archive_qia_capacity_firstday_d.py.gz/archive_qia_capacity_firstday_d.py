from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison=b/'qia-capacity-comparison-d';assert (comparison/'pbs-exit.txt').read_text().strip()=='0'
record=json.loads((comparison/'comparison.json').read_text());assert record['source_unchanged'] and set(record['cases'])=={'capacity','capacity_optics'}
for label,case in record['cases'].items():
    root=b/('qia-'+label+'-firstday-d');receipt=json.loads((root/'receipt.json').read_text())
    assert (root/'pbs-exit.txt').read_text().strip()=='0' and receipt['returncode']==0 and receipt['source_unchanged'] and receipt['steps_completed']==48
    report=json.loads((root/'trajectory/report.json').read_text())
    assert sha(root/'trajectory/report.json')==case['report_sha256']==receipt['report_sha256']
    assert len(case['metrics'])==14 and report['status']=='running' and report['steps_requested']==17520 and report['steps_completed']==48
    assert sha(root/'trajectory'/report['model_npz'])==case['trace_sha256'] and sha(root/'config.json')==case['configuration_sha256']
official=b/'ctsm-qia-run-r';audit=json.loads((official/'year-boundary.json').read_text())
assert sha(official/'official-year-fields.npz')==audit['fields_sha256'] and sha(official/'year-boundary.json')==record['reference_audit_sha256']
archive=b/'qia-capacity-firstday-d-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for folder in ['qia-capacity-firstday-d','qia-capacity_optics-firstday-d','qia-capacity-comparison-d']:
        for p in sorted((b/folder).rglob('*')):
            if p.is_file():tf.add(p,arcname=folder+'/'+p.relative_to(b/folder).as_posix(),recursive=False)
    for name in ['official-year-fields.npz','year-boundary.json','pbs-exit.txt']:tf.add(official/name,arcname='official-reference/'+name,recursive=False)
    for name in ['archive_qia_capacity_firstday_d.py','dispatch_qia_capacity_firstday_d.py','dispatch_qia_capacity_comparison_d.py']:tf.add(b/name,arcname='control/'+name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,cases=list(record['cases']),scope='ActualPBS308/309 cold48 and310 all14-metric comparisons0, literal officialR data/reference audit and model checkpoints preserved. Unfinished17520-step requests remain running prefixes, not year/science acceptance.')))

"""Parse already measured original GPU reference errors on a PBS compute node."""
from pathlib import Path
import ast,hashlib,json,os,re,tarfile
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'soil-stress-gpu-summary-fx';a=b/'soil-stress-coupled-fq-complete-evidence.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());assert sha(a)==package['archive_sha256'];d=r/'device';d.mkdir()
with tarfile.open(a) as tf:tf.extractall(d,filter='data')
root=d/'current';done=json.loads((root/'exit.json').read_text());assert done['passed'] and done['source_unchanged'];families={};total=0
for family,file,prefix,expected in [('enthalpy','test_gpu_clm_enthalpy_column','extensive column',16),('layered','test_gpu_clm_layered_column','layered full column',16)]:
    rows=[];rawmax=[]
    for line in (root/(file+'.log')).read_text().splitlines():
        match=re.match(r'^'+re.escape(prefix)+r" <class 'numpy\.float(32|64)'> (\d+) (\{.*\})$",line)
        if match:
            literal=re.sub(r'np\.float(?:32|64)\(([+\-0-9.eE]+)\)',r'\1',match[3]);rows.append(dict(dtype='float'+match[1],index=int(match[2]),errors=ast.literal_eval(literal)))
        for label in ['extensive CUDA/JAX32','layered full same precision']:
            if line.startswith(label+' '):rawmax.append(dict(label=label,maximum_absolute=float(line[len(label)+1:]),scope='Maximum over mixedunit raw fields, not a single variable/unit; originalrtol/atol1e-6 andexactintegers checked byactualtest.'))
    by_dtype={}
    for dtype in ['float32','float64']:
        selected=[q for q in rows if q['dtype']==dtype];assert len(selected)==expected and {q['index'] for q in selected}==set(range(expected));keys=set(selected[0]['errors']);assert all(set(q['errors'])==keys for q in selected)
        by_dtype[dtype]={k:np.max(np.asarray([q['errors'][k] for q in selected]),axis=0).tolist() for k in keys}
    receipt=json.loads((root/(file+'-receipt.json')).read_text());assert receipt['passed'] and receipt['source_unchanged'];total+=receipt['counts']['tests'];families[family]=dict(reference_cases=rows,maxima_by_field_and_dtype=by_dtype,raw_sameprecision_maximum=rawmax)
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=done['source_manifest_sha256'],device_archive_sha256=sha(a),delivered=True,all_target12_actualpassed=done['passed'],wholecolumn_original_tests=total,families=families,scope='Read-back of actualsame-sourceGPU12 logs/receipts. All16cases per dtype/family retained, no test/physics/precisiongate edits or new model simulation. Component3 reportedseparately; whole9 here. This doesnot provefull404/1552/year/FLUXNET/spinup.');(r/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pbs_job=result['pbs_job'],families={name:dict(maxima=q['maxima_by_field_and_dtype'],sameprecision=q['raw_sameprecision_maximum']) for name,q in families.items()})),flush=True)

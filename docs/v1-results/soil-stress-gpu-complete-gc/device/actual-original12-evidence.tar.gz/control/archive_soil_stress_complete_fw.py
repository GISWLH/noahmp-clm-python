"""Archive actual same-source12 complete original GPU nodes; no numerical work."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'soil-stress-coupled-fq-gpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();done=json.loads((r/'exit.json').read_text());assert done['passed'] and done['source_unchanged'] and done['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and len(done['records'])==3
total=0
for row in done['records']:
    stem=Path(row['file']).stem;receipt=json.loads((r/(stem+'-receipt.json')).read_text());assert row['passed'] and row['actual_parent_returncode']==0 and sha(r/(stem+'-receipt.json'))==row['receipt_sha256'];assert receipt['passed'] and receipt['source_unchanged'] and receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed'] and receipt['source_manifest_sha256']==done['source_manifest_sha256'] and receipt['counts']['failures']==receipt['counts']['errors']==receipt['counts']['skipped']==0 and sha(r/(stem+'.xml'))==receipt['xml_sha256'];total+=receipt['counts']['tests']
assert total==12;a=b/'soil-stress-coupled-fq-complete-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.iterdir()):
        if p.is_file():tf.add(p,arcname='current/'+p.name,recursive=False)
    tf.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,tests=total,seconds=done['seconds'],records=done['records'])),flush=True)

from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'run_qia_fresh_phase_numpy_week_a.py').read_text().replace('qia-fresh-phase-numpy-week-a', 'qia-all-phase-numpy-year-c').replace('p6-fresh-phase-edge-a-source.tar.gz', 'p6-all-phase-final-a-source.tar.gz').replace('04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0', 'd59772b4a77b101e92ede8f926f5e90e4f4bc327f1b63f263164ab563c0bbcc5')
p = p.replace('fresh-phase-edge-cpu-b', 'all-phase-cpu-final-a').replace('tests=910', 'tests=911')
p = p.replace(", '--stop-after', '336'", '').replace(",'--stop-after','336'", '')
p = p.replace("d['status']=='running' and d['steps_completed']==336", "d['status']=='complete' and d['steps_completed']==17520")
start = p.index("scope='New frozen510"); end = p.index("',pbs_job=", start)
p = p[:start] + "scope='New original-cold source511 NumPy full17520 trajectory after exact-source fullCPU911 and original735 production-step hard audit. Full equations/stores/80/tol1e-7 unchanged,only all-phase strict-descent event trial. Original failed735/3798 immutable,no failed or source-changed trajectory resumed. Current GPU matrix10of11 with original735 raw1e-6 failure is explicitly unaccepted;this CPU climate work does not waive it or claim backend/fullcanonical/spinup/scientific acceptance" + p[end:]
assert "'--stop-after'" not in p and 'cpu-full-receipt.json' in p
ast.parse(p)
(r / 'run_qia_all_phase_numpy_year_c.py').write_bytes(p.encode())
p = (r / 'qia_fresh_phase_numpy_year_b.pbs').read_text().replace('qia-fresh-phase-numpy-year-b', 'qia-all-phase-numpy-year-c').replace('run_qia_fresh_phase_numpy_year_b.py', 'run_qia_all_phase_numpy_year_c.py').replace('clm-qia-fresh-phase-year-b', 'clm-qia-all-phase-year-c')
(r / 'qia_all_phase_numpy_year_c.pbs').write_bytes(p.encode())

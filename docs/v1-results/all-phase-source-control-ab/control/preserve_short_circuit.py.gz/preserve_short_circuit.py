from pathlib import Path,PurePosixPath
import gzip,hashlib,json,sys,tarfile
root=Path(__file__).resolve().parents[2];name,expected,scope=sys.argv[1:4];sha=lambda b:hashlib.sha256(b).hexdigest()
archive=root/'outputs/v1'/(name+'-evidence.tar.gz');assert sha(archive.read_bytes())==expected
dest=root/'docs/v1-results'/name;items=[]
with tarfile.open(archive) as t:
    for m in t:
        p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
        raw=t.extractfile(m).read();compress=p.suffix in ['.py','.cu','.log','.json','.pbs','.xml','.txt','.sh','.md'] or '.log.' in p.name
        data=gzip.compress(raw,mtime=0) if compress else raw;target=dest/(m.name+'.gz' if compress else m.name)
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==data
        else:target.write_bytes(data)
        items.append(dict(source=m.name,path=target.relative_to(dest).as_posix(),source_sha256=sha(raw),stored_sha256=sha(data)))
(dest/'manifest.json').write_bytes((json.dumps(dict(scope=scope,archive_sha256=expected,artifacts=items),indent=2)+'\n').encode())
print(json.dumps(dict(name=name,artifacts=len(items))))

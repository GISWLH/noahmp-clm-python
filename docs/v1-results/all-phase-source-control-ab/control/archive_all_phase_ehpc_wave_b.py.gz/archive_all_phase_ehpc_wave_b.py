from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();results=[]
def archive(name,files,summary):
    a=b/(name+'-evidence.tar.gz');assert not a.exists()
    with tarfile.open(a,'w:gz') as t:
        for name,raw in files:
            member=tarfile.TarInfo(name);member.size=len(raw);t.addfile(member,io.BytesIO(raw))
        raw=(json.dumps(summary,indent=2)+'\n').encode();member=tarfile.TarInfo('summary.json');member.size=len(raw);t.addfile(member,io.BytesIO(raw))
        t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    results.append(dict(name=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size))
r=b/'all-phase-cpu-final-b';assert (r/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((r/'cpu-full-receipt.json').read_text());assert d['counts']==dict(tests=911,failures=0,errors=0,skipped=0) and d['source_unchanged']
assert d['source_manifest_sha256']=='37187bea427930cdf1772c5db1d07b679c7dda15d8033e85e5a013a06089517f'
assert json.loads((r/'point735-probe.json').read_text())['failure'] is None
archive('all-phase-cpu-final-b',[(p.relative_to(r).as_posix(),p.read_bytes()) for p in sorted(r.rglob('*')) if p.is_file()],dict(scope='EHPC262 exact frozen B511 fullCPU911 actual0,0fail/skip and uninstrumented real735 whole step under original hard budgets. No fullGPU/year/scientific acceptance.',receipt=d))
r=b/'qia-all-phase-numpy-year-c';launch=json.loads((r/'launch.json').read_text());assert launch['pbs_job']=='260.manager'
files=[('controller/'+p.name,p.read_bytes()) for p in sorted(r.iterdir()) if p.is_file()]
f=r/'trajectory'
raw=(f/'report.json').read_bytes();d=json.loads(raw);assert d['steps_requested']==17520 and d['source_unchanged']
files.append(('trajectory/report.json',raw))
for key,h in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
    p=f/d[key];data=p.read_bytes();assert sha(data)==d[h] and p.parent==f;files.append(('trajectory/'+p.name,data))
q=subprocess.run(['qstat','-f','260.manager'],text=True,capture_output=True)
files.append(('qstat.txt',(q.stdout+q.stderr).encode()))
archive('qia-all-phase-numpy-year-launch-c',files,dict(scope='Read-only immutable live generation of new original-cold A511 NumPy year; all production bytes identical B511,only GPUtest binding differs. Snapshot is not process completion/year acceptance; original launch discloses A device target failure before corrected B actual11. No source-changed trajectory resumed.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pbs_qstat_returncode=q.returncode,status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],report_sha256=sha(raw),maximum_cumulative_residual_m_h_c_n=d['maximum_cumulative_residual_m_h_c_n']))
print(json.dumps(results))

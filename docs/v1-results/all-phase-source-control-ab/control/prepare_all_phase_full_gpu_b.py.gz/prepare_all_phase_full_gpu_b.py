from pathlib import Path
import ast
r=Path(__file__).resolve().parent
pairs=[('p6-fresh-phase-edge-a','p6-all-phase-final-b'),('fresh-phase-edge-cpu-b','all-phase-cpu-final-b'),('e623d1aaac00aedf2f8f2dd0f8b761c4ab1824fab2f5b88fb41cfb9b6f977c25','d883698681d114e5822982614190c0565551a45ac98fdff6460dfc322cfcc38b'),('fresh-phase-edge-gpu-b','all-phase-gpu-target-b'),('315d548602aac759dcc684346ae7fa75f3ea493585c5d83048a86be4d9e7a2df','057d5819299b118f61b557fcacdf2cf33e29a968a74a6ae6d4cfd753f21d6f0b'),('== 510','== 511'),('source_files=510','source_files=511'),('1250','1254'),('910','911'),('340','343'),('len(prefix) == 8','len(prefix) == 11'),('tests=8','tests=11')]
names={prefix+'fresh_phase_full_gpu_a.py':prefix+'all_phase_full_gpu_b.py' for prefix in ('collect_','run_','wait_','launch_')}
for old,new in names.items():
    p=(r/old).read_text()
    for a,b in [*pairs,*names.items()]:p=p.replace(a,b)
    if old.startswith('run_'):
        start=p.index("scope = '");end=p.index('\n(r /',start)
        p=p[:start]+"scope = 'Current frozen511 all-phase-edge B canonical1254: exact EHPC911 plus actual xuanzephase11,remaining332GPU run only after predecessor actualexit. No prior506/509/510 or failed A targets credited. Original phases/barriers/exits/raw1e-6/MHCN/atexit disclosure retained;not science/year/spinup acceptance.'"+p[end:]
    if old.startswith('launch_'):
        p=p.replace("old_b = b / 'p6-most-physical-c/full-controller-c'","old_b = b / 'p6-fresh-phase-edge-a/full-controller-a'").replace('2634162','2750196').replace('wait_most_full_gpu_c.py','wait_fresh_phase_full_gpu_a.py')
        p=p.replace('pending-c','pending-510').replace('obsolete509C','obsolete510').replace('idle C','idle 510').replace('original C','original 510').replace('Original C','Original 510').replace('Original B','Original 510').replace('Obsolete B','Obsolete510')
        p=p.replace('911CPU/8GPU','911CPU/11GPU').replace('911CPU plus8GPU','911CPU plus11GPU')
    if old.startswith('wait_'):p=p.replace('911CPU+8GPU','911CPU+11GPU')
    ast.parse(p);(r/new).write_bytes(p.encode())
print('Prepared four frozen B511 controls; no runtime or collection performed locally.')

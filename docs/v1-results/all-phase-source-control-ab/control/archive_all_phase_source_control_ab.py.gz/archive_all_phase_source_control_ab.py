from pathlib import Path
import ast,gzip,hashlib,io,json,re,tarfile,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[2];o=root/'outputs/v1';d=root/'docs/v1-results';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(group,path):
    m=json.loads((d/group/'manifest.json').read_text());v=next(i for i in m['artifacts'] if i['source']==path);raw=(d/group/v['path']).read_bytes();assert sha(raw)==v['stored_sha256']
    if v['path']==v['source']+'.gz':raw=gzip.decompress(raw)
    assert sha(raw)==v['source_sha256'];return raw
packages={};manifests={};sources={}
for letter,h in [('a','d59772b4a77b101e92ede8f926f5e90e4f4bc327f1b63f263164ab563c0bbcc5'),('b','1456f86a97f1a744da13d0a1805d3dfa815ef810d4c386799f47ac233b6ffef4')]:
    archive=o/('p6-all-phase-final-'+letter+'-source.tar.gz');assert sha(archive.read_bytes())==h
    with tarfile.open(archive) as t:
        raw=t.extractfile('SOURCE_SHA256.json').read();m=json.loads(raw);data={n:t.extractfile(n).read() for n in m}
    assert len(m)==511 and all(sha(data[n])==v for n,v in m.items())
    manifests[letter]=raw;sources[letter]=data;packages[letter]=json.loads((o/('p6-all-phase-final-'+letter+'-package.json')).read_text())
    assert packages[letter]['manifest_sha256']==sha(raw) and packages[letter]['archive_sha256']==h
changed=[n for n in sources['b'] if sources['b'][n]!=sources['a'][n]];assert changed==['tests/test_gpu_canopy_phase_energy.py']
runtime={n:raw for n,raw in sources['b'].items() if n.startswith(('src/','tests/','benchmarks/'))};assert len(runtime)==498
for n,raw in runtime.items():
    assert (root/n).read_bytes()==raw,n
    if n.endswith('.py'):ast.parse(raw.decode('utf-8-sig'),filename=n)
def function(raw,name):return ast.dump(next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
assert function(runtime['src/noahmp_clm/physics/canopy_phase_energy.py'],'solve_canopy_phase_energy')==function(read('qia3798-local-candidates-f','qia3798-numpy-f/solver-candidate.py'),'solve_canopy_phase_energy')
assert function(runtime['src/noahmp_clm/gpu/canopy_phase_energy.py'],'phase_energy_kernel_jax')==function(read('qia3798-jax-launch-f','candidate/phase-candidate.py'),'phase_energy_kernel_jax')
with tarfile.open(fileobj=io.BytesIO(read('qia3798-local-candidates-f','device-candidates/qia3798-candidates-b-f-evidence.tar.gz'))) as t:reference=t.extractfile('general-edge-f/phase-candidate.cu').read().decode()
tokens=lambda text:''.join(re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S).split())
assert tokens(reference)==tokens(runtime['src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu'].decode())
def nodes(raw):
    result=[]
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(n) is None for n in ['failure','error','skipped']);parts=c.attrib['classname'].split('.');i=next(i for i,n in enumerate(parts) if n.startswith('test_'))
        result.append('tests/'+parts[i]+'.py::'+'::'.join(parts[i+1:]+[c.attrib['name']]))
    assert len(result)==len(set(result));return set(result)
collection=json.loads(read('all-phase-full-deferred-b','collection-preflight-a/collection.json'));allnodes=set(collection['nodes']);cpu=nodes(read('all-phase-cpu-final-b','cpu-full.xml'));gpu=nodes(read('all-phase-gpu-target-b','target-a/targets.xml'))
assert len(allnodes)==1254 and len(cpu)==911 and len(gpu)==11 and cpu.isdisjoint(gpu) and cpu|gpu<=allnodes
expectedcpu={n for n in allnodes if not Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))};assert cpu==expectedcpu
assert gpu=={n for n in allnodes if n.split('::')[0]=='tests/test_gpu_canopy_phase_energy.py'}
record=dict(scope='Local metadata/AST/XML/hash audit only,no model/NumPy/JAX/scientific arithmetic. Current498runtime bytes exactly frozen B; A/B onlynewGPUtestbinding differs; whole NumPy/JAX functions and complete CUDA tokens match independently tested F. Actual current1254collection matched to exact CPU911+GPUphase11 XML,no oldsource credit;remaining332 not executed.',runtime_files=498,source_files=511,production_AST_and_CUDA_tokens_match_F=True,changed_A_to_B=changed,canonical_nodes=1254,completed_same_source_nodes=922,remaining_gpu_nodes=332,source_manifest_sha256=sha(manifests['b']))
archive=o/'all-phase-source-control-ab-evidence.tar.gz';assert not archive.exists();files=[]
for n in ['prepare_all_phase_final_a.py','prepare_all_phase_final_b.py','prepare_all_phase_full_gpu_b.py','prepare_all_phase_cuda_year_e.py','prepare_all_phase_numpy_year_c.py','archive_all_phase_ehpc_wave_a.py','archive_all_phase_ehpc_wave_b.py','archive_all_phase_xuanze_wave_a.py','archive_all_phase_deferred_and_year_e.py','preserve_all_phase_wave_a.py','preserve_short_circuit.py','archive_all_phase_source_control_ab.py']:
    p=o/n;raw=p.read_bytes();ast.parse(raw.decode('utf-8-sig'));files.append(('control/'+n,raw))
for letter in ['a','b']:files.extend([('source-'+letter+'/SOURCE_SHA256.json',manifests[letter]),('source-'+letter+'/package.json',(json.dumps(packages[letter],indent=2)+'\n').encode())])
files.append(('audit.json',(json.dumps(record,indent=2)+'\n').encode()))
with tarfile.open(archive,'w:gz') as t:
    for n,raw in files:
        item=tarfile.TarInfo(n);item.size=len(raw);t.addfile(item,io.BytesIO(raw))
print(json.dumps(dict(archive=archive.name,sha256=sha(archive.read_bytes()),artifacts=len(files),audit=record)))

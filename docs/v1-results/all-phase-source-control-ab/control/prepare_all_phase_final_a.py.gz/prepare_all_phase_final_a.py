from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import re
import tarfile

root = Path(__file__).resolve().parents[2]; o = root / 'outputs/v1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
cpu = json.loads((o / 'all-phase-numpy-target-receipt-a.json').read_text())
assert cpu['returncode'] == 0 and cpu['source_unchanged'] and cpu['counts'] == dict(tests=26, failures=0, errors=0, skipped=0)
baseline = o / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(baseline.read_bytes()) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(baseline) as t:
    old = json.load(t.extractfile('SOURCE_SHA256.json')); data = {n: t.extractfile(n).read() for n in old}
changed = ['src/noahmp_clm/physics/canopy_phase_energy.py', 'src/noahmp_clm/gpu/canopy_phase_energy.py',
           'src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu', 'tests/test_canopy_phase_energy.py',
           'tests/test_gpu_canopy_phase_energy.py', 'tests/fixtures/qia_735_phase_oldwet.json']
for name in changed:
    data[name] = (root / name).read_bytes().replace(b'\r\n', b'\n')
with tarfile.open(o / 'p6-all-phase-numpy-a-source.tar.gz') as t:
    for name in ['src/noahmp_clm/physics/canopy_phase_energy.py', 'tests/test_canopy_phase_energy.py', 'tests/fixtures/qia_735_phase_oldwet.json']:
        assert t.extractfile(name).read() == data[name]
for name, raw in data.items():
    if name.endswith('.py'):
        ast.parse(raw.decode('utf-8-sig'), filename=name)
def function(raw, name):
    return ast.dump(next(n for n in ast.parse(raw) .body if isinstance(n, ast.FunctionDef) and n.name == name), include_attributes=False)
stored = root / 'docs/v1-results'
reference_numpy = gzip.decompress((stored / 'qia3798-local-candidates-f/qia3798-numpy-f/solver-candidate.py.gz').read_bytes())
reference_jax = gzip.decompress((stored / 'qia3798-jax-launch-f/candidate/phase-candidate.py.gz').read_bytes())
assert function(data[changed[0]], 'solve_canopy_phase_energy') == function(reference_numpy, 'solve_canopy_phase_energy')
assert function(data[changed[1]], 'phase_energy_kernel_jax') == function(reference_jax, 'phase_energy_kernel_jax')
packet = stored / 'qia3798-local-candidates-f/device-candidates/qia3798-candidates-b-f-evidence.tar.gz'
with tarfile.open(packet) as t:
    reference_cuda = t.extractfile('general-edge-f/phase-candidate.cu').read().decode()
tokens = lambda text: ''.join(re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S).split())
assert tokens(reference_cuda) == tokens(data[changed[2]].decode())
manifest = {n: sha(raw) for n, raw in data.items()}; assert len(manifest) == 511
assert sorted(n for n, h in manifest.items() if old.get(n) != h) == sorted(changed)
mb = (json.dumps(manifest, indent=2) + '\n').encode()
a = o / 'p6-all-phase-final-a-source.tar.gz'; assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for name, raw in [*data.items(), ('SOURCE_SHA256.json', mb)]:
        item = tarfile.TarInfo(name); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
package = dict(scope='Final three-backend all-phase-edge production candidate after actual NumPy26 target and independent735 equations plus original3798 NumPy/CUDA/JAX isolated whole-step evidence. Original physics/oldstores/tol/budgets unchanged. Production NumPy/JAX function AST and complete CUDA tokens match frozen independently tested F candidates. Packaged docs older than current repository. No fullcanonical/year/science completion claimed.',
               source_files=511, archive_sha256=sha(a.read_bytes()), manifest_sha256=sha(mb), changed=changed,
               production_numpy_jax_AST_matches_F=True, production_cuda_tokens_match_F=True, cpu_expected=911, gpu_expected=343, canonical_expected=1254,
               numpy_target_receipt_sha256=sha((o / 'all-phase-numpy-target-receipt-a.json').read_bytes()))
(o / 'p6-all-phase-final-a-package.json').write_bytes((json.dumps(package, indent=2) + '\n').encode())
print(json.dumps(package))

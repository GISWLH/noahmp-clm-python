from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
def archive(name,roots,extras,scope):
    a=b/(name+'-evidence.tar.gz');assert not a.exists()
    with tarfile.open(a,'w:gz') as t:
        for r in roots:
            for p in sorted(r.rglob('*')):
                if p.is_file():t.add(p,arcname=r.name+'/'+p.relative_to(r).as_posix(),recursive=False)
        for p,n in extras:t.add(p,arcname=n,recursive=False)
        raw=(json.dumps(dict(scope=scope),indent=2)+'\n').encode();info=tarfile.TarInfo('summary.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
        t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    results.append(dict(name=a.name,sha256=sha(a),bytes=a.stat().st_size))
changed=['src/noahmp_clm/physics/canopy_phase_energy.py','src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu','tests/test_canopy_phase_energy.py','tests/test_gpu_canopy_phase_energy.py','tests/fixtures/qia_735_phase_oldwet.json']
for letter,code,count in [('a',1,1),('b',0,0)]:
    s=b/('p6-all-phase-final-'+letter);r=s/'target-a';e=json.loads((r/'exit.json').read_text());rec=json.loads((r/'receipt.json').read_text());m=json.loads((s/'SOURCE_SHA256.json').read_text())
    assert e['returncode']==code and rec['counts']==dict(tests=11,failures=count,errors=0,skipped=0) and rec['source_unchanged']
    assert all(sha(s/n)==v for n,v in m.items()) and sha(r/'receipt.json')==e['receipt_sha256']
    archive('all-phase-gpu-target-'+letter,[r],[(s/'SOURCE_SHA256.json','SOURCE_SHA256.json')]+[(s/n,n) for n in changed]+[(b/('control_all_phase_gpu_target_'+letter+'.py'),'control/control_all_phase_gpu_target_'+letter+'.py'),(b/('launch_all_phase_gpu_target_'+letter+'.py'),'control/launch_all_phase_gpu_target_'+letter+'.py')], 'Actual frozen'+letter.upper()+'511 original11tests actualexit'+str(code)+'. A retains original57/300 raw failure,max.18237305J,10pass1fail; B test-only dynamic leaf/MOST argument binding matches production,all11pass,all300raw0. All original solver/precision/physical gates unchanged;full343/canonical1254/year/science not inferred. Original interpreter-atexit bypass disclosed in phase/barrier receipt.')
roots=[b/'qia735-device-capture-a',b/'qia735-device-capture-b',b/'qia735-argument-staging-c']
assert sha(roots[1]/'input-and-raw.npz')=='90a4858239e9593d73a80d6c815b5b783f305b97c52d8bb28498444d8a911275'
assert sha(roots[2]/'variants.npz')=='d66091ff921e29ef4f91c717e0693158963d60cc0befcbb8f9e2d91d3ac282f5'
extras=[]
for p in sorted(b.iterdir()):
    if p.is_file() and ('735' in p.name) and (p.suffix in ('.py','.log','.json')):extras.append((p,'control/'+p.name))
archive('qia735-device-staging-abc',roots,extras,'Read-only frozen A diagnostics. CaptureA originalassert retained,extra radiation shapeerror retained. B retains original300raw/input identity; its separate default-untracked radiation must not be used as original trackedpath proof. C reproduces original constant path bytewise,then controlled dynamic device arguments/internal-or-explicit radiation,all original inputs/precision/gates. EHPC261 independently audits300fields and584trackedradiation. Diagnostic status is not pytest/controller/year acceptance.')
print(json.dumps(results))

from pathlib import Path
import ast
import hashlib
import io
import json
import tarfile

root=Path(__file__).resolve().parents[2];o=root/'outputs/v1';sha=lambda raw:hashlib.sha256(raw).hexdigest()
a=o/'p6-all-phase-final-a-source.tar.gz';assert sha(a.read_bytes())=='d59772b4a77b101e92ede8f926f5e90e4f4bc327f1b63f263164ab563c0bbcc5'
with tarfile.open(a) as t:
 old=json.load(t.extractfile('SOURCE_SHA256.json'));data={n:t.extractfile(n).read() for n in old}
test='tests/test_gpu_canopy_phase_energy.py';data[test]=(root/test).read_bytes().replace(b'\r\n',b'\n')
for n,raw in data.items():
 if n.endswith('.py'):ast.parse(raw.decode('utf-8-sig'),filename=n)
m={n:sha(raw) for n,raw in data.items()};assert [n for n,h in m.items() if old[n]!=h]==[test]
assert all(old[n]==h for n,h in m.items() if n.startswith(('src/','benchmarks/')))
mb=(json.dumps(m,indent=2)+'\n').encode();dest=o/'p6-all-phase-final-b-source.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
 for n,raw in [*data.items(),('SOURCE_SHA256.json',mb)]:
  info=tarfile.TarInfo(n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
record=dict(scope='FinalB changes only new735 device regression argument binding: LeafParameters/MOST extension passed as dynamic device arrays exactly like production,not captured constants. EHPC261 original constant57failures vs dynamic300bitwise equal and584radiationbitwise equal retained. All production/CPUtest/fixture bytes exactly A,original1e-6/300fields/solver/budget/science checks unchanged. Not a physical/precision/gate change or erased A failure. Packaged docs older than repository.',
 source_files=511,archive_sha256=sha(dest.read_bytes()),manifest_sha256=sha(mb),changed_from_A=[test],all_production_bytes_identical_A=True,cpu_expected=911,gpu_expected=343,canonical_expected=1254)
(o/'p6-all-phase-final-b-package.json').write_bytes((json.dumps(record,indent=2)+'\n').encode());print(json.dumps(record))

from pathlib import Path
import ast
r=Path(__file__).resolve().parent
names={prefix+'qia_physical_cuda_year_c.py':prefix+'qia_all_phase_cuda_year_e.py' for prefix in ('run_','control_','launch_')}
for old,new in names.items():
    p=(r/old).read_text()
    for a,b in [('p6-most-physical-c','p6-all-phase-final-b'),('qia-physical-cuda-year-c','qia-all-phase-cuda-year-e'),('len(m)==509','len(m)==511'),('frozen509C','frozen511B'),('cold509C','cold511B'),('most-warm-cpu-c','all-phase-cpu-final-b'),('15d44099440f09798fe88f766de4854fe7dfc565a6e9d3dd54084b209e685391','d883698681d114e5822982614190c0565551a45ac98fdff6460dfc322cfcc38b'),('tests=909','tests=911'),*names.items()]:p=p.replace(a,b)
    if old.startswith('launch_'):
        a=p.index("assert json.loads((s/'production1519-controller-c");z=p.index("inputs=b/",a)
        p=p[:a]+"""phase=json.loads((s/'target-a/exit.json').read_text());rec=json.loads((s/'target-a/receipt.json').read_text())
assert phase['returncode']==0 and phase['passed'] and rec['counts']==dict(tests=11,failures=0,errors=0,skipped=0) and rec['source_unchanged'] and rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
assert rec['all_setup_call_teardown_phases_passed'] and rec['node_coverage_exact']
assert sha(s/'target-a/receipt.json')==phase['receipt_sha256']
audit=b/'qia3798-paired-audit-g-evidence.tar.gz';assert sha(audit)=='1822130d22192fddbc91a84e0593ec7525e75c9c3f9009a601eb88e2f45ff795'
with tarfile.open(audit) as t:
    d=json.loads(t.extractfile('qia3798-paired-audit-g/audit.json').read());assert d['passed'] and len(d['fields'])==380 and d['maximum_absolute_difference']==0.
"""+p[z:]
        p=p.replace('CPU909 and final actual1519 raw361 validation','CPU911 and actual finalphase11 plus isolated3798 raw380 validation')
        p=p.replace('full1249 separately queued','full1254 separately queued')
        p=p.replace("cpu_evidence_sha256=sha(archive),", "cpu_evidence_sha256=sha(archive),phase_receipt_sha256=sha(s/'target-a/receipt.json'),paired3798_evidence_sha256=sha(audit),")
    if old.startswith('run_'):
        p=p.replace('CPU909 and actual final1519 CUDA/JAX361 prerequisites; full canonical1249 separately pending','CPU911 and actual finalphase11 plus isolated3798 CUDA/JAX380 prerequisites; full canonical1254 separately pending')
        p=p.replace('Original failed163/1519 and strictA unchanged','Original failed163/1519/735/3798 and strictA unchanged')
    ast.parse(p);(r/new).write_bytes(p.encode())
p=(r/'collect_all_phase_full_gpu_b.py').read_text().replace("r=s/'full-by-file-a';", "r=s/'collection-preflight-a';r.mkdir();")
ast.parse(p);(r/'collect_all_phase_preflight_b.py').write_bytes(p.encode())
print('Prepared frozen CUDA-only new-year controls and independent collection preflight; no local science execution.')

"""Explore A-ci calibration identifiability without selecting on light-curve outcomes."""
from pathlib import Path
import hashlib,itertools,json,time
import numpy as np
from scipy.optimize import least_squares
import evaluate_leafweb as evaluator
started=time.monotonic();out=Path('leafweb-multistart.json')
starts=list(itertools.product((20.,60.,180.),(40.,120.,360.),(2.,10.,30.)))
traces=[]
def fit(residual,x0,**kwargs):
 records=[];fits=[]
 for index,start in enumerate(starts):
  f=least_squares(residual,start,**kwargs);fits.append(f)
  records.append({'start':start,'success':bool(f.success),'cost':float(f.cost),'parameters':f.x.tolist(),
                  'rank':int(np.linalg.matrix_rank(f.jac)),'nfev':int(f.nfev),'optimality':float(f.optimality)})
 good=[i for i,f in enumerate(fits) if f.success and np.isfinite(f.cost)]
 assert good
 chosen=min(good,key=lambda i:fits[i].cost)
 traces.append({'trials':records,'selected_index':chosen,'selection':'minimum A-ci squared residual only'})
 print(json.dumps({'file_number':len(traces),'chosen':chosen,'cost':records[chosen]['cost'],'rank':records[chosen]['rank']}),flush=True)
 return fits[chosen]
report={'scope':'Exploratory diagnosis of single-start A-ci fit; no production equations changed; light-response measurements never used in objective or start selection',
 'starts':starts,'budget':'27 fixed starts x max_nfev=2000 per file; select successful fit with minimum A-ci cost',
 'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(evaluator.__file__),Path('src/noahmp_clm/physics/photosynthesis.py'))}}
# Save the old result independently before replacing just the optimizer adapter.
report['baseline']=evaluator.evaluate('tests/fixtures/leafweb_c3_grass.zip')
evaluator.least_squares=fit
report['multistart']=evaluator.evaluate('tests/fixtures/leafweb_c3_grass.zip');report['optimization_traces']=traces
report['seconds']=time.monotonic()-started
out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'status':'complete','seconds':report['seconds'],'light_results':[{k:x.get(k) for k in ('file','relative_mean_bias','normalized_rmse','r','calibration_rmse','calibration_jacobian_rank')} for x in report['multistart']['files']]}),flush=True)

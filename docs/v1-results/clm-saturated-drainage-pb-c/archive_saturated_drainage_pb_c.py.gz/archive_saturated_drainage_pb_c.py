"""Flat actual-closed PB-c component evidence; unchanged NM payload referenced."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname() == 'manager'
ROOT = Path('/tmp/noahmp-clm-saturated-drainage-pb-c')
JOB = '1614.manager'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
data = {}
qstat = subprocess.check_output(['qstat','-xf',JOB])
status = qstat.decode()
assert re.search(r'^\s*job_state = F\s*$',status,re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$',status,re.M)
code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M).group(1))
for name in ('result.tar.gz','pbs-exit.txt'):
    digest = subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
    if not (ROOT/name).exists():
        subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
    assert sha((ROOT/name).read_bytes()) == digest
assert int((ROOT/'pbs-exit.txt').read_text()) == code
with tarfile.open(ROOT/'result.tar.gz') as tar:
    members = {m.name.removeprefix('./'):tar.extractfile(m).read() for m in tar if m.isfile()}
receipt = json.loads(members['receipt.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002'
assert receipt['pytest_parent_returncode']==code and int(members['worker-exit.txt'])==code
manifest = json.loads(members['source/SOURCE_SHA256.json'])
assert len(manifest)==584 and sha(members['source/SOURCE_SHA256.json'])=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert all(sha(members['source/'+n])==h for n,h in manifest.items())
for folder in ('preparation','execution'):
    controls = json.loads(members[folder+'/CONTROLS_SHA256.json'])
    assert all(sha(members[folder+'/'+n])==h for n,h in controls.items())
data.update({n:v for n,v in members.items() if not n.startswith('source/')})
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt',
             'compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt'):
    data['scheduler/'+name]=(ROOT/name).read_bytes()
data['scheduler/actual-qstat.txt']=qstat
if (ROOT/'pbs-output.log').exists(): data['scheduler/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
diagnostics = [json.loads(line.split('PB_DIAGNOSTIC ',1)[1]) for line in members['pytest.stdout.txt'].decode().splitlines() if 'PB_DIAGNOSTIC ' in line]
assert diagnostics == json.loads(members['diagnostics.json'])
if code==0:
    assert receipt['passed'] and receipt['tests']==22 and receipt['failures']==receipt['errors']==0
    assert receipt['source_and_controls_unchanged'] and receipt['official_fixture_regression_passed']
    assert receipt['coupled_column_runs']==receipt['official_calls_executed']==receipt['GPU_tasks']==0
    assert sum(d['test'].startswith('official_reuse_') for d in diagnostics)==3
    assert b'22 passed' in members['pytest.stdout.txt']
else:
    assert not receipt['passed']
data['original-result-members.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v),included=not n.startswith('source/')) for n,v in members.items()},indent=2)+'\n').encode()
data['closed-run.json']=(json.dumps(dict(job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,
    receipt=receipt,raw_result_archive=str(ROOT/'result.tar.gz'),raw_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),
    original_members=len(members),omitted_unchanged_source_members=585,
    source_archive='climatology-final-candidate-nm-source.tar.gz',source_archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'),indent=2)+'\n').encode()
data['archive_saturated_drainage_pb_c.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
archive=ROOT/'clm-saturated-drainage-pb-c-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for name,raw in sorted(data.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as tar: assert {m.name:tar.extractfile(m).read() for m in tar}==data
package=dict(archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,tests=receipt['tests'],
    diagnostic_records=len(diagnostics),original_18_tests_AST_unchanged=True,
    official_reference_archive_sha256='e8b67dae4d2e912f031fd16b9da2c62ab640ca6b2323e2696e62db97e341271a',
    coupled_column_runs=0,new_official_calls=0,GPU_runs=0,complete_hydrology_acceptance=False,
    scope='PB-c isolated NumPy component physics: whole-layer main ice impedance, adjacent-layer perched impedance and next-layer donors; reuse three original 1610 official profiles, original unfrozen ODE and hard water/heat ledgers. No current annual/production changes, no new official calls or GPU. Exhausted/cross-layer perched and coupled-column cases remain separate development boundaries.')
(ROOT/'clm-saturated-drainage-pb-c-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

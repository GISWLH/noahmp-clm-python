# PB-c isolated semantic revision

PB-b and its actual 1605 failure / 1606 18-test success remain unchanged. This
new NumPy component is not imported by production, any annual run or GPU code.
It reuses the original NM SoilEnthalpyState and withdraw_liquid unchanged.
No new reservoir, independent WA, lateral column coupling or parameter fit is
introduced. Parameters and original three comparison profiles are unchanged.

The scientific basis is the CLM5 Hydrology technical note equations
2.7.106--110 and read-only semantic inspection of pinned CTSM
fdfc03a0abec838ec0b66663a6a2f5e619cd2611 SoilHydrologyMod. The independent
implementation uses published equations; no official Fortran physics is copied.
The official reference is the already completed 1610.manager F0 direct caller
of original libclm.a, not a rewrite of its equations and not a new official run.
All seven reference members are exact copies from its sealed evidence archive.

## Changed spatial semantics

The main ice factor uses complete layer thicknesses, starting one layer above
the layer containing the water table, bounded by the first layer, through all
soil layers. At an exact lower interface the shallower cell is selected. This
empirical stencil is distinct from the actual geometrical saturated length;
it can include a below-bedrock layer in the coefficient, while below-bedrock
water and enthalpy remain unavailable for removal.

The perched conductivity uses complete layer thicknesses from the crossing
cell through the frost cell. Each layer's impedance uses the mean ice pore
fraction of it and its following layer. The last layer repeats itself when
there is no following layer. Actual donors start at the layer **after** the
crossing cell, ending at the frost cell. No eligible donor means zero outflow.
Perched Sy is evaluated at the diagnosed **main** theta water-table depth,
not the perched depth. All these stencils are checked independently against
the actual frozen/perched original reference, including donor identities.

Units remain metres, radians, kg water/m2 and J/m2. Baseflow .001 is
mm/s/m (the original R input convention, not CTSM's .01 default); perched
scale 1e-5 is 1/m; Ksat is m/s. Ice pore fraction uses ice/(917*dz*porosity),
capped only as a coefficient. Sy is dimensionless, with floor .02 and positive
Campbell suction in metres. No liquid or ice stock is clipped or created.
The .01 kg/m2 liquid reserve is never added to a depleted layer. Exported
heat is actual liquid mass times [Lf+cw*(donor T-273.15)]. Original official
hydrology has no heat output: its donor mass defines an independently
calculated heat reference, not an official energy measurement.

## Integration, conserved stocks and remaining scope

Connected-front migration retains the original integral 1000*integral(Sy dz),
independent SciPy ODE/quadrature checks, adaptive step doubling, cap guard,
actual-liquid limits and compensated water/enthalpy ledger. The main theta
proxy, migrated front and rediagnosed theta level remain separate outputs.
The perched front advances by actual removed mass/(1000*Sy(main depth)), with
an explicit band-storage cap and actual per-layer donor availability. Main
drainage is diagnosed after the perched export. Every accepted export carries
its actual donor enthalpy; hard budgets retain the original rounding bounds.

PB-c still uses adaptive temporal integration instead of the official frozen
single-step update. The three original profiles do not exhaust a donor, cross
multiple layer boundaries or activate official watmin/excess corrections.
Their WA, qcharge, surface water, ice and extra correction outlets are explicitly
checked unchanged before using final layer differences as export truth.
Large depleted perched fronts, unbracketed all-wet perched diagnosis, variable
layer retention, and full column operator splitting require further independent
profiles. A liquid-cap invariant is not claimed as reference equivalence for
these regimes. These remain active development items, not accepted completion
of the single-column hydrology gap. No official floor/add-water repair is added.

## Verification boundary

Twenty-two test functions retain all 18 original tests and add four groups:
three actual official profiles (level, per-layer stock, outflow, donor heat),
independent dimensionless whole-layer main ice stencil, adjacent-layer perched
stencil/main-depth Sy/next-layer donor, and unavailable/ineligible donor controls.
The physical reference comparisons use 10% with explicit absolute allowances
of .001 kg/m2 water (one micrometre), .5 J/m2 heat and .001 m migrated level;
diagnostic geometry uses 1e-6 m. Relative tiny-flux differences below .01 kg/m2
are null. Dimensionless constitutive-factor comparisons use 1e-6 relative
tolerance solely as a structural regression; this is not a renewed field-level
precision gate. Exact zero donor identity is checked separately.

Only EHPC compute002 PBS may execute the tests. Windows work is stdlib AST,
raw hashes and archive operations. A successful component test does not imply
whole-column, observational, annual, GPU or release acceptance. The original
three official calls are reused and not rerun. Actual execution, failures,
durations and diagnostic numbers belong in the later receipt, not this plan.

Primary references:

- https://escomp.github.io/CTSM/release-clm5.0/tech_note/Hydrology/CLM50_Tech_Note_Hydrology.html
- https://raw.githubusercontent.com/ESCOMP/CTSM/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/src/biogeophys/SoilHydrologyMod.F90

# NM phase Newton：7275 失败后的窄静态对照

仅只读源码、stdlib 原始字节/hash 和 Python AST；本机没有科学导入、数组值解码、物理计算、提交或候选修改。下列八文件逐字节等于 NM584（manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f`）。PR 的实际事实仍仅为：首次 MOST 调用、三行 raw741 全有限、Qia 的 canopy/final 标志 false，Cha/HaM true；不能从静态差异认定根因，也不能套用旧 M1/ML 结论。

**先拆最后的三项，而不是先改 Newton。** CUDA `phase_solve` 最后第242行及 JAX `phase_energy_kernel_jax` 第326–327行的 phase `out[68]` 都是 `!failed && max(abs(r[12]))<=tolerance && max(abs(physical[11]))<=tolerance*1.05`。实际 CUDA surface 调用固定 `100,.005f`，故门为原 float32 表示的 `.005` 与 `.005*1.05`（约 `.00525` W/m²）。`r` 的前10项是活跃层热方程（非活跃层改温度约束），第10项在固定地温时为温度约束，第11项是按潜热缩放的空气水分方程；不能把全部12项都称同一种热通量。独立 `physical` 从最终蒸发/凝结后的库存和携焓重建，和求解时热增量式分别验算。原 raw741 的 `[509]` 是该 phase 标志，`[733]` 是最终 `max(abs(r))`，`[496:507]` 是11项 physical，`[508]` 是计数，`[732]` 是恢复计数；`failed` 及完整12项 r **未保存**。raw `[362]` 还同时要求输运有效、初始热反演和联合热求解成功，`[433]` 再受表面根与 finish admission 约束，因此单独 `[433]=false` 不能证明相变 Newton 原因。PR 已保存 raw，先由 EHPC 读这些现成量。

**计数与终止。** CUDA `iteration` 和 JAX `it` 从0起，每次完整 Newton 更新/恢复/失败尝试加1；返回 `out[67]=it+1`。初猜已满足门时返回1；100次更新后返回101，即使最后一次更新已经达标仍可成功。没有“达到 max_iterations 必然 false”的额外条件，只有最后三项；反过来 `failed=true` 会否决最后状态，即使某项残差偶然小。`restarts` 统计事件：湿度恢复、逐层端点改变、localJac、备用初猜等一次更新可以多次累计；不是独立重跑次数。NumPy `for iteration in range(1,max_iterations+1)` 默认80，最后允许的更新后另重查 residual，返回的 iteration 最大80；其 stalled 和超迭代分别抛异常，没有同一个 `failed` 数值返回。NumPy 最终 parcel 门为 `tolerance*1.01`；`physics/canopy_column.py:66–76` 的实际 surface 入口传 `tolerance=1e-7`，不能把独立 NumPy surface 成败误解释成 GPU `.005` 门的同算法判决。

**初猜与相坐标。** 三者用旧凝结水焓/(旧质量×4180)作湿层坐标，干层用空气温度偏移；另算 ambient 分支，以完整12项残差平方和严格较小者为首猜，另一个仅保留一次 fallback。空气温度恰等于冰点时保留旧相比例。JAX 给冷 ambient 的减、乘、除加 barrier；CUDA 是相同分步 float32 运算，NumPy 是 float64。fresh 规则都只把近冰点 `.05 K` 内正在沉积的干活跃层转成相坐标，不加质量/焓；depleted 规则把已耗尽且仍困在潜热平台内的坐标移至按热残差符号选的端点。NumPy 额外接受 `initial_guess`，原 surface 在同一旧状态的后续地温试探中复用 `phase_cache` 的数值坐标；CUDA/JAX surface 每次相求解都重新选 old/ambient，没有这个缓存参数。首次 MOST 的一个 surface kernel 内也可能有多次地温试探，因此“首次 MOST”不等于“只发生一次 phase_solve”。

**主步与恢复不完全相同。** 三者都限制 Newton 方向最大分量（叶坐标20、地温/湿度坐标5），最多24次二分回溯，接受第一个严格降低全残差平方和的试步；再尝试沿原方向最先遇到的精确潜热端点。弱进展条件是未接受或 `chosen_norm>.999*norm`，湿度恢复在原0–190坐标区间做32次二分，只接受全残差下降。NumPy 在已接受弱下降且湿度未改善时直接继续下一轮；只有不接受才进 localJac，后续才试一次备用初猜及最后的宽 stencil。CUDA/JAX 还有逐层贪心的0/plateau端点恢复（NumPy没有这段逐层循环），并且 **float32** 在已接受但仍弱下降时也做 localJac，对比已获得的最佳 merit；CUDA/JAX在湿度后重算当前 merit，再决定逐层端点是否有必要。JAX64 的 localJac 仅在未接受时进入，仍用 fine stencil，并有 NumPy 式的最终宽 stencil；CUDA没有该 float64-only 分支。都是静态路径区别，是否被 Qia 实际触发尚未知。

**Jacobian、pivot 和 finite。** NumPy fine 差分叶/地温为 `1e-6`、湿度 `1e-7`，最后 wide 为 `1e-4/1e-5`；JAX64 同量级，JAX32/CUDA 为 `.02/.002`。localJac 在相端点按原方向选单侧，在冷/平台/暖分支内截断差分，完整式除以实际 `hi[k]-lo[k]`。NumPy 用 `np.linalg.lstsq(...,rcond=None)`，设备用12×12部分主元高斯消元和回代；后者没有小主元门、正则化或秩退化备用解，原 CUDA/JAX 都不应偷偷加这些机制。有限值且无 NaN 时两者主元平局取最先项。设备没有独立逐 Newton 步的 `isfinite(J/delta)` 失败标志；CUDA `phase_max`/scale 用 `fmaxf`，JAX用 `max/maximum`，遇到 NaN 的传播语义不能视为相同。最终 raw 全有限 **不排除** 某次被拒试步或 Jacobian 曾非有限；同样，静态存在这个可能性不证明实际发生。须观察，不先换解法或阈值。

最小后续观察按需要分两层，均保持原更新/异常/门：

1. **先零新增 GPU 运行读 PR 原 raw。** 每行保留 `[341,362,433,508,509,732,733]`、`physical[11]`、表面地温/残差/根区间/评估次数与原界；同时对照实际输入。若需要区分三项，单凭最终 raw 不能复原 `failed` 或完整12项 r，不能凭猜测填它们。
2. **只有实际证据要求时，局部透明终端 trace。** 每个 Qia 地温试探记录原 `temp`、试探序号、最终 `failed`、12项 r、11项 physical、三个判据布尔、更新数、restarts、chosen/alternative 初猜及各自 norm/choose/available。原 phase `out300` 是当前地温试探结果；raw741只保留最后所选试探，不能把某个旁路 bracket 试探的 trace 当最终结果。trace需可绑定具体地温试探及最终所选结果。
3. **若终端证据指向停滞，再记录有界每轮摘要。** 在已有 locals 产生处保存 iteration/x、phase_active/fresh/depleted 位图、norm/selected norm、主/局部 Jacobian 的各列实际差分宽度、消元主元序列/对角、J和delta有限标志、方向scale、首个接受回溯编号、first-edge layer/alpha、湿度/逐层端点/local/备用初猜各自触发与接受。原始 J12×12只在首次失败/异常轮保存足够；不要为日志再次 evaluate 或重新求解。NumPy相应使用只读观察已有 frame locals，并保留原异常。CUDA/JAX若需调试缓冲，只添加独立输出旁路，不替换输入/输出、不开 `raise_on_failure=False` 推进、也不重跑年份；调试构建有寄存器/优化扰动风险，应先对同一捕获输入确认原741全部值与PR一致，才能把其轨迹归因于原失败。

本轮无实现、无申请新运行。最小安全顺序是现有PR分量事实 → EHPC实际effective32输入的独立NumPy返回或原异常 → 必要时仅 terminal phase trace → 仍不能区分时才取最后失败轮 J/方向。未知项包括实际哪个最终判据失败、是否耗尽100次更新、是否有 tiny pivot/非有限中间量、哪个恢复分支消耗预算，全部保持未知。

原 NM 源 SHA256（本轮 stdlib 逐文件字节核对0；Python文件AST解析0）：

```text
physics/canopy_phase_energy.py        8d23b61e1268983514ef75a6f08dba09bf97f75f5bdef5a0c68a54431ed77e3f
gpu/canopy_phase_energy.py            82bdbe68b653c17d4bbf003d140cb6d6634b43d81a91bebbe54f6d8f8f75d97f
gpu/cuda/canopy_phase_energy_kernel.cu 6510c55ee20e5d3a38e6f6b79fcb25bd74ca0957b4e1f532214b5463e2aee484
gpu/canopy_energy.py                  e5f758b11df73374804d0bab8d2d595fe885665ca8fc6313c642292bad5090d6
gpu/canopy_surface.py                 4836ed4306c4d13c91e3c4860b738fc671a41293a70a1e6815459211cdf0f92a
gpu/cuda/canopy_phase_surface_kernel.cu 01e6a691fb6e7f45493371958706f8447f1f8d2d9f54145e3fc7324a7e471263
gpu/cuda/canopy_surface_kernel.cu      a21741d4a4225cd7f4b132cb327da3f575e413d76e983970db000aa5aff06139
physics/canopy_column.py              fd4dbd7f78c2885b78fe0b0bd44355c5d42717d20dab6b80abdb8d672710aaff
```

"""Independent stdlib/AST source review; no scientific module imports."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PREP = ROOT / 'surface-7275-numpy-reference-preparation'
sha = lambda b: hashlib.sha256(b).hexdigest()
controls = json.loads((PREP / 'CONTROLS_SHA256.json').read_bytes())
assert all(sha((PREP / n).read_bytes()) == h for n, h in controls.items())
code = (PREP / 'surface_reference.py').read_bytes()
assert sha(code) == '30563e5a89a5cb30dc68e05c9195d5548ab0ca5a395e4d2c4d6de1c13357b125'
tree = ast.parse(code)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
assert set(functions) == {'bind_source', 'array_identity', 'reference_one', 'inspect_raw_output', 'compare_row'}
for name in ('reference_one', 'inspect_raw_output', 'compare_row'):
    body = functions[name].body[1:]
    assert isinstance(body[0], (ast.Assign, ast.Expr))
    assert isinstance(body[0].value, ast.Call) and body[0].value.func.id == 'bind_source'
with tarfile.open(ROOT / 'climatology-final-candidate-nm-source.tar.gz') as t:
    manifest_raw = t.extractfile('SOURCE_SHA256.json').read()
    assert sha(manifest_raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    manifest = json.loads(manifest_raw)
    paths = ('tests/test_gpu_canopy_phase_surface.py', 'tests/test_gpu_canopy_surface.py', 'tests/test_gpu_snicar.py',
        'src/noahmp_clm/gpu/canopy_phase_surface.py', 'src/noahmp_clm/gpu/canopy_surface.py',
        'src/noahmp_clm/gpu/cuda/canopy_phase_surface.py', 'src/noahmp_clm/gpu/photosynthesis.py',
        'src/noahmp_clm/gpu/vic.py', 'src/noahmp_clm/physics/canopy_column.py',
        'src/noahmp_clm/physics/canopy_energy.py', 'src/noahmp_clm/physics/photosynthesis.py',
        'src/noahmp_clm/physics/canopy_optics.py', 'src/noahmp_clm/physics/vic.py')
    sources = {}
    for name in paths:
        raw = t.extractfile(name).read()
        assert sha(raw) == manifest[name] and (REPO / name).read_bytes() == raw
        sources[name] = dict(sha256=sha(raw), NM_byteexact=True)
text = code.decode()
assert 'saturated_suction_m=p[6]' in text and 'root_weights=v[3:]' in text
assert 'LeafParameters.from_layer_rows(coefficients[row_index])' in text
assert 'CanopyExchange(*u[:11], *extra)' in text
assert 'failed_cuda_row_retained=not facts[row_index]' in text
assert 'after != before' in text and "'Reference mutated an actual captured input'" in text
report = dict(actual_static_exit=0, blocking_findings=[], reference_sha256=sha(code),
    controls_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()),
    original_source_manifest_sha256=sha(manifest_raw), original_sources=sources,
    findings=dict(
        actual_encoded_coefficients='Requires literal float32 10 or Bx10x10 arrays and actual observed profile flag; validates without changing dtype/shape/bytes; no nominal default substitution.',
        boundary_inputs='All seven soil parameters incl p6 suction, original phase option, four unnormalized roots, five snow impurity species and ten mass/enthalpy condensate rows retained.',
        extensions='Captured exchange2, stem10, VIC8 and optional optics8 decoded by original schema; VIC surface flag alone drives this surface operation, bottom flag retained in identities rather than adding bottom transport.',
        packed_supply_aliases='u14 wetness and u15/u17 supply are superseded by actual condensate/soil supply in the unchanged phase surface solver, matching the original reference; no missing externally imposed tendency.',
        input_and_source_immutability='Float32 values lifted exactly to float64 copies; original inputs checked after surface call even on failure; NM584 checked before imports and after call.',
        failure_retention='Every raw741 finite position and original341/362/433/509 flags reported. Original wrapper row failure is retained independently of common-field science checks; comparison returns no overall pass replacing it.',
        original_checks='Original science, condensate and independent M/H/tracer budget functions reused, including original nearzero floors and absolute temperature tolerance; caught exceptions become explicit failed checks.'),
    nonblocking_scope_notes=[
        'Common numeric difference table is a compatible dtype/shape intersection, not all741 equivalence. Shape-mismatched/nonnumeric items are not compared there; raw741 and full reference diagnostics must remain in the eventual caller archive.',
        'The module itself does not authenticate an external capture archive or serialize reference exceptions; the later wrapper must bind the actual closed PR archive and preserve each selected call/row plus all diagnostics/tracebacks as README requires.',
        'Original GPP nearzero floor is broad; report actual values/differences and never infer FLUXNET GPP acceptance.',
        'Current capture contract fixes optics None; optional optics decode is prepared only, not an executed optics validation.',
        'This is one fixed-MOST surface comparison, not a whole-column/year, new solver, same-precision or failure repair result.'],
    numerical_imports=0, numerical_runs=0, GPU_calls=0, files_modified_by_review=False)
(ROOT / 'surface-7275-numpy-reference-independent-review-wp.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(actual_static_exit=0, blocking_findings=[], reference_sha256=sha(code),
    source_files_verified=len(sources), review_sha256=sha((ROOT / 'surface-7275-numpy-reference-independent-review-wp.json').read_bytes()))))

"""Root stdlib verification of preserved PT; no array or pickle value decode."""
from pathlib import Path
import hashlib
import json
import runpy

r = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
helper = runpy.run_path(str(r / 'package_surface_reference_pt.py'))
package = json.loads((r / 'surface-7275-numpy-reference-pt-package.json').read_bytes())
body = (r / package['archive']).read_bytes()
assert sha(body) == package['sha256'] == 'e039cc8d055612ef427719f2b0cd93076831f5983c18bde133f388c17c59cbc2'
raw = helper['files'](body)
assert len(raw) == package['artifacts'] == 111
inventory = json.loads(raw['artifact-inventory.json'])
assert set(inventory) == set(raw) - {'artifact-inventory.json'}
assert all(sha(raw[n]) == item['sha256'] and len(raw[n]) == item['bytes'] for n, item in inventory.items())
stage = helper['files'](raw['executed-stage.tar.gz'])
controls = json.loads(stage['controls/CONTROLS_SHA256.json'])
assert sha(stage['controls/CONTROLS_SHA256.json']) == '15b4eab4bfa501bd09ea9d3e7bb693ae3802c15f8ad51c5d775644afba98d317'
assert all(sha(stage['controls/' + n]) == h for n, h in controls.items())
source = helper['files'](stage['source.tar.gz'])
manifest = json.loads(source['SOURCE_SHA256.json'])
assert len(manifest) == 584 and all(sha(source[n]) == h for n, h in manifest.items())
assert json.loads(raw['result/source-before.json']) == json.loads(raw['result/source-after.json']) == manifest
assert all(raw['result/controls/' + n] == stage['controls/' + n] for n in [*controls, 'CONTROLS_SHA256.json'])
receipt = json.loads(raw['result/receipt.json'])
assert not receipt['passed'] and [row['actual_child_returncode'] for row in receipt['actual_children']] == [1, 0, 0]
assert all(not row['timed_out'] for row in receipt['actual_children'])
assert receipt['GPU_calls'] == receipt['full_column_calls'] == 0
assert raw['result/worker-exit.txt'].strip() == b'1'
packets = fields = 0
for name, value in raw.items():
    if name.startswith('result/') and name.endswith('.json'):
        j = json.loads(value)
        if j.get('schema') in ('PT-lossless-return-v1', 'PR-typed-tree-v1'):
            fields += helper['typed_packet'](raw[name[:-5] + '.npz'], j)
            packets += 1
            if 'pickle_sha256' in j:
                assert sha(raw[name[:-5] + '.pkl']) == j['pickle_sha256']
assert packets == 10 and fields == 294
readout = json.loads(raw['readout.json'])
assert readout['job_state'] == 'F' and readout['exit_status'] == 1 and readout['Stageout_status'] == 0
assert readout['actual_surface_calls_started'] == 3 and readout['actual_surface_calls_returned'] == 2
assert 'Newton stalled at iteration 30: residual=13.75804 W/m2' in readout['rows'][0]['exception_traceback']
for k in (1, 2):
    row = readout['rows'][k]
    assert row['full_surface_return_saved'] and row['complete_return_saved'] and row['comparison_saved']
    assert all(row['original_checks'].values())
review = dict(actual_static_exit=0, blocking_findings=[], archive_sha256=package['sha256'],
              artifacts=111, original_PBS_F1=True, Stageout_status=0, children=[1, 0, 0],
              source_files=584, source_controls_before_after_exact=True, typed_packets=10,
              opaque_NPY_payloads=294, pickle_hashes_verified=True, local_array_value_decodes=0,
              scope='Root stdlib preservation review only; Qia reference remains failed and two returned references do not certify the GPU/year.')
(r / 'surface-7275-numpy-reference-pt-root-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(review))

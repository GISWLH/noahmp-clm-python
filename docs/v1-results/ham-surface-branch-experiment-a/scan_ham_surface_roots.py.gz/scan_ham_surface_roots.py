"""Pure fixed-boundary residual scan; never accept or advance a trial state."""
from pathlib import Path
from datetime import datetime
import ast,inspect,json,pickle,time,traceback
import numpy as np
from noahmp_clm.column import Forcing
import noahmp_clm.clm_enthalpy_driver as driver
import noahmp_clm.physics.canopy_column as surface_module
import noahmp_clm.physics.canopy_most as most
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.photosynthesis import LeafParameters
from run_fluxnet_column import calendar

r=Path('/home/zhangyq/noahmp-v1/ham-most-6121-replay-a')
report=json.loads((r/'failed-run/report.json').read_text());config=report['configuration']
state,*_,index=pickle.loads((r/'failed-run'/report['checkpoint_file']).read_bytes());assert index==6121
with np.load(r/'inputs/fluxnet-ham-2002-prepared.npz',allow_pickle=False) as z:data=dict(z)
f=Forcing(*data['forcing'][index]);co2,mu,diffuse=map(float,data['environment'][index])
metadata=json.loads((r/'inputs/fluxnet-ham-2002-prepared.json').read_text())
environment=calendar(datetime.strptime(str(data['time_start'][index]),'%Y%m%d%H%M'),metadata,True)
trace=json.loads((r/'current-b-replay.json').read_text())
boundary=CanopyExchange(**trace['surfaces'][48]['boundary'])
# Return the existing pure evaluator before the original root-search section.
# All mass transfer, thermal equations, parameters and trial arithmetic remain
# those of the frozen implementation; only its search is replaced by a scan.
tree=ast.parse(inspect.getsource(surface_module.surface_step));function=tree.body[0]
cuts=[i for i,node in enumerate(function.body) if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='initial' for x in node.targets)]
assert len(cuts)==1
function.name='diagnostic_surface_evaluator'
function.body=function.body[:cuts[0]]+[ast.Return(value=ast.Name(id='evaluate',ctx=ast.Load()))]
ast.fix_missing_locations(tree);namespace=dict(vars(surface_module))
exec(compile(tree,'<frozen-surface-evaluator>','exec'),namespace)
driver.surface_step=namespace['diagnostic_surface_evaluator']
rows=[]
class ScanComplete(Exception):pass
def scan(solve_surface,*args,**kwargs):
    evaluate=solve_surface(boundary)
    for temperature in np.arange(273.15,282.150001,.05):
        value,d=evaluate(float(temperature));result=d['result'];snow=d['snow']
        row=dict(temperature=float(temperature),residual=value,actual=temperature+value,
            h=result['h'],ground_mass=d['ground_mass'],thermal_snow_mass=snow.mass.sum(),
            thermal_snow_ice=snow.ice.sum(),thermal_snow_enthalpy=snow.enthalpy.sum())
        rows.append(row);print(json.dumps(row),flush=True)
    raise ScanComplete
most.solve_surface_most=scan;started=time.monotonic()
try:
    driver.step_clm_enthalpy_column(state,f,co2_ppm=co2,cosine_zenith=mu,diffuse_fraction=diffuse,
        leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),
        most_geometry=most.MOSTGeometry(**config['most_geometry']),phenology_environment=environment,
        deposition_rates=np.array(config['aerosol_deposition_kg_m2_s']),nitrogen_deposition_gn_m2=0.)
except ScanComplete:failure=None
except Exception:failure=traceback.format_exc()
crossings=[(a,b) for a,b in zip(rows[:-1],rows[1:]) if a['residual']*b['residual']<=0]
out=dict(scope='Pure residual scan at retained MOST iteration49 boundary; no accepted trial, state advance or relaxed gate.',
    boundary=vars(boundary),rows=rows,sign_changes=crossings,failure=failure,seconds=time.monotonic()-started)
(r/'surface-root-scan.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print('sign_changes',json.dumps(crossings),flush=True)

"""Isolated NumPy bracket experiment, not a production change or annual resume."""
from pathlib import Path
from datetime import datetime
import ast,hashlib,inspect,json,pickle,time,traceback
import numpy as np
from scipy.optimize import brentq
from noahmp_clm.column import Forcing
import noahmp_clm.clm_enthalpy_driver as driver
import noahmp_clm.physics.canopy_column as surface_module
import noahmp_clm.physics.canopy_most as most
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.photosynthesis import LeafParameters
from run_fluxnet_column import calendar,audit_step

r=Path('/home/zhangyq/noahmp-v1/ham-most-6121-replay-a')
report=json.loads((r/'failed-run/report.json').read_text());config=report['configuration']
state,*_,index=pickle.loads((r/'failed-run'/report['checkpoint_file']).read_bytes());assert index==6121
with np.load(r/'inputs/fluxnet-ham-2002-prepared.npz',allow_pickle=False) as z:data=dict(z)
f=Forcing(*data['forcing'][index]);co2,mu,diffuse=map(float,data['environment'][index])
metadata=json.loads((r/'inputs/fluxnet-ham-2002-prepared.json').read_text())
environment=calendar(datetime.strptime(str(data['time_start'][index]),'%Y%m%d%H%M'),metadata,True)
boundary=CanopyExchange(**json.loads((r/'current-b-replay.json').read_text())['surfaces'][48]['boundary'])
original_source=inspect.getsource(surface_module.surface_step)
insertion='''        # Experimental bracketing within the original snow-vapour topology.
        if ns and fc>0. and fl>=0. and fr<=0.:
            unused,endpoint=evaluate(right)
            if len(endpoint['snow'].mass)<ns:
                event_left=center;event_right=right
                for event_iteration in range(60):
                    if event_right-event_left<=temperature_tolerance:break
                    event_trial=event_left+.5*(event_right-event_left)
                    event_value,event_details=evaluate(event_trial)
                    if len(event_details['snow'].mass)==ns:
                        if event_value<=0.:
                            right,fr=event_trial,event_value
                            event_actions.append(dict(temperature=event_trial,residual=event_value,search_iterations=event_iteration+1))
                            break
                        event_left=event_trial
                    else:event_right=event_trial
'''
needle='        for iteration in range(60):'
assert original_source.count(needle)==1
experimental_source=original_source.replace(needle,insertion+needle)
actions=[];namespace=dict(vars(surface_module));namespace['event_actions']=actions
exec(compile(experimental_source,'<experimental-topology-bracket>','exec'),namespace)
experimental=namespace['surface_step'];driver.surface_step=experimental
# The independent scipy reference uses the frozen evaluator, without the
# experimental search, on the continuous lower interval identified by the scan.
tree=ast.parse(original_source);function=tree.body[0]
cut=next(i for i,node in enumerate(function.body) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='initial' for t in node.targets))
function.name='frozen_evaluator';function.body=function.body[:cut]+[ast.Return(ast.Name(id='evaluate',ctx=ast.Load()))]
ast.fix_missing_locations(tree);factory_namespace=dict(vars(surface_module));exec(compile(tree,'<frozen-evaluator>','exec'),factory_namespace)
original_most=most.solve_surface_most;reference={}
def traced(solve_surface,*args,**kwargs):
    driver.surface_step=factory_namespace['frozen_evaluator']
    try:evaluate=solve_surface(boundary)
    finally:driver.surface_step=experimental
    root=brentq(lambda t:evaluate(t)[0],277.15,277.20,xtol=1e-10)
    value,details=evaluate(root);fixed=solve_surface(boundary)[-1]
    reference.update(scipy_root=root,scipy_residual=value,experimental_root=fixed['surface_temperature'],
        experimental_h=fixed['h'],scipy_h=details['result']['h'])
    assert abs(root-fixed['surface_temperature'])<=2e-7
    assert abs(fixed['h']-details['result']['h'])<=1e-4
    return original_most(solve_surface,*args,**kwargs)
most.solve_surface_most=traced
out=dict(scope='Isolated NumPy experiment: bracket the continuous snow-vapour topology before secant. Original physics, 50 MOST limit and acceptance retained. Not production or a completed annual run.',
    experimental_source_sha256=hashlib.sha256(experimental_source.encode()).hexdigest(),event_actions=actions,reference=reference)
started=time.monotonic()
try:
    after,d=driver.step_clm_enthalpy_column(state,f,co2_ppm=co2,cosine_zenith=mu,diffuse_fraction=diffuse,
        leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),
        most_geometry=most.MOSTGeometry(**config['most_geometry']),phenology_environment=environment,
        deposition_rates=np.array(config['aerosol_deposition_kg_m2_s']),nitrogen_deposition_gn_m2=0.)
    incoming,residual,bound=audit_step(state,after,f,d,0.)
    out.update(status='complete',most=d['most'],h=d['h'],le=d['le'],budget_residual=residual,budget_bound=bound)
except Exception:out.update(status='failed',failure=traceback.format_exc())
out['seconds']=time.monotonic()-started
def encode(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
(r/'surface-branch-experiment.json').write_text(json.dumps(out,indent=2,default=encode,allow_nan=False)+'\n')
print(json.dumps(out,default=encode),flush=True)

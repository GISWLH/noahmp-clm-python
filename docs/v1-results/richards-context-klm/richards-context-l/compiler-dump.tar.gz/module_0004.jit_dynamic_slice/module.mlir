#loc1 = loc("args[0]")
#loc2 = loc("args[1]")
module @jit_dynamic_slice attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<14xf32> loc("args[0]"), %arg1: tensor<i64> loc("args[1]")) -> (tensor<4xf32> {jax.result_info = "result"}) {
    %0 = stablehlo.dynamic_slice %arg0, %arg1, sizes = [4] : (tensor<14xf32>, tensor<i64>) -> tensor<4xf32> loc(#loc5)
    return %0 : tensor<4xf32> loc(#loc6)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc3 = loc("/home/lhwang/work/noahmp-v1/probe_richards_context_l.py":19:25 to :32)
#loc4 = loc("<module>"(#loc3))
#loc5 = loc("jit(dynamic_slice)/dynamic_slice"(#loc4))
#loc6 = loc("jit(dynamic_slice)"(#loc4))

from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='phase':
    name='qia3803-trace-bc';r=b/'qia3803-trace-device-c';d=json.loads((r/'receipt.json').read_text());e=json.loads((r/'exit.json').read_text())
    assert e['returncode']==0 and sha(r/'receipt.json')==e['receipt_sha256'] and d['original_raw_byte_exact'] and d['instrumented_raw_byte_exact'] and d['source_unchanged'] and sha(r/'trace-and-raw.npz')==d['payload_sha256']
    folders=['qia3803-trace-device-b','qia3803-trace-device-c'];controls=['trace_qia3803_device_b.py','launch_qia3803_trace_b.py','trace_qia3803_device_c.py','control_qia3803_trace_c.py','launch_qia3803_trace_c.py'];source=b/'qia1110-final-h-source.tar.gz'
else:
    assert mode=='flow';name='richards-flow-diagnosis-f';r=b/name;d=json.loads((r/'receipt.json').read_text())
    assert d['source_unchanged'] and all(d['final_outputs_byte_exact'].values()) and sha(r/'flow-and-systems.npz')==d['payload_sha256']
    folders=[name];controls=['probe_richards_native_flow_f.py','launch_richards_flow_f.py'];source=b/'richards-native-e-source.tar.gz'
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for folder in folders:
        for p in sorted((b/folder).rglob('*')):
            if p.is_file():tf.add(p,arcname=folder+'/'+p.relative_to(b/folder).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

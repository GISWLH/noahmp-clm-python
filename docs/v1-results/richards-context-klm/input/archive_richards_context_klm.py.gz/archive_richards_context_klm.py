from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label in ['k','l','m']:
    r=b/('richards-context-'+label);e=json.loads((r/'exit.json').read_text());assert e['returncode']==(1 if label=='k' else 0)
    if label!='k':
        d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and d['device_barriers_complete'] and sha(r/'context.npz')==d['payload_sha256'] and e['receipt_sha256']==sha(r/'receipt.json')
        if label=='m':assert all(x['cuda_original_byte_exact'] and x['jax_original_byte_exact'] for x in d['comparison'])
    dump=r/'xla-dump'
    if dump.exists():
        paths=sorted(p for p in dump.rglob('*') if p.is_file());manifest={p.relative_to(dump).as_posix():sha(p) for p in paths};(r/'dump-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n');a=r/'compiler-dump.tar.gz';assert not a.exists()
        with tarfile.open(a,'w:gz') as t:
            for p in paths:t.add(p,arcname=p.relative_to(dump).as_posix(),recursive=False)
            t.add(r/'dump-SHA256.json',arcname='dump-SHA256.json',recursive=False)
a=b/'richards-context-klm-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for label in ['k','l','m']:
        r=b/('richards-context-'+label)
        for p in sorted(r.iterdir()):
            if p.is_file():t.add(p,arcname=r.name+'/'+p.name,recursive=False)
        for prefix in ['probe','control','launch']:t.add(b/(prefix+'_richards_context_'+label+'.py'),arcname='control/'+prefix+'_richards_context_'+label+'.py',recursive=False)
    for n in ['richards-native-e-source.tar.gz','phase-coordinate-native-a-source.tar.gz','richards-flow-diagnosis-f-evidence.tar.gz',Path(__file__).name]:t.add(b/n,arcname='input/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

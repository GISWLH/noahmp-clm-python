from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'richards-context-m';start=time.monotonic();cmd=[sys.executable,'-u',str(b/'probe_richards_context_m.py')]
with (r/'worker.log').open('x') as log:p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=cmd),indent=2)+'\n');code=p.wait();d=json.loads((r/'receipt.json').read_text()) if (r/'receipt.json').exists() else None
good=bool(code==0 and d and d['source_unchanged'] and d['device_barriers_complete']);out=dict(returncode=code,passed=good,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256((r/'receipt.json').read_bytes()).hexdigest() if d else None)
(r/'exit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);raise SystemExit(0 if good else 1)

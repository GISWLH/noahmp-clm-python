from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-a';r=b/'richards-context-k';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src')]
import jax
import jax.numpy as j
import cupy as cp
from noahmp_clm.gpu.richards import implicit_step_jax,_system
from noahmp_clm.gpu.cuda.richards import _step
original=b/'richards-flow-diagnosis-f';meta=json.loads((original/'receipt.json').read_text());assert meta['source_unchanged'] and sha(original/'flow-and-systems.npz')==meta['payload_sha256']
with np.load(original/'flow-and-systems.npz',allow_pickle=False) as z:data=dict(z)
with np.load(s/'tests/fixtures/richards_reference.npz',allow_pickle=False) as z:p=z['32/4/hydraulics'][0]
results={};compiled=None;system_compiled=None;start=time.monotonic();comparison=[]
for index in [0,6,7]:
    old=data['cuda/'+str(index)+'/old'];guess=data['cuda/'+str(index)+'/guess'];dt=data['cuda/'+str(index)+'/dt'];assert old.tobytes()==data['jax/'+str(index)+'/old'].tobytes() and guess.tobytes()==data['jax/'+str(index)+'/guess'].tobytes()
    args=tuple(j.asarray(x,j.float32) for x in (old,guess,p,dt));cu=_step(cp.asarray(old),cp.asarray(guess),cp.asarray(p),cp.asarray(dt,cp.float32))
    if compiled is None:
        lowered=jax.jit(implicit_step_jax).lower(*args);(r/'implicit-stablehlo.txt').write_text(str(lowered.compiler_ir(dialect='stablehlo')));compiled=lowered.compile();(r/'implicit-optimized-hlo.txt').write_text(compiled.as_text())
    jo=compiled(*args);u=jo[4:8]
    sa=(u,args[0],args[2],args[3])
    if system_compiled is None:
        lowered=jax.jit(_system).lower(*sa);(r/'system-stablehlo.txt').write_text(str(lowered.compiler_ir(dialect='stablehlo')));system_compiled=lowered.compile();(r/'system-optimized-hlo.txt').write_text(system_compiled.as_text())
    residual,q,a=system_compiled(*sa)
    for key,value in [('cuda',cp.asnumpy(cu)),('jax',np.asarray(jo)),('system_residual',np.asarray(residual)),('system_q',np.asarray(q)),('system_matrix',np.asarray(a)),('old',old),('guess',guess),('p',p),('dt',dt),('original_cuda',data['cuda/'+str(index)+'/raw']),('original_jax',data['jax/'+str(index)+'/raw'])]:results[str(index)+'/'+key]=value
    comparison.append(dict(call=index,cuda_original_byte_exact=results[str(index)+'/cuda'].tobytes()==results[str(index)+'/original_cuda'].tobytes(),jax_original_byte_exact=results[str(index)+'/jax'].tobytes()==results[str(index)+'/original_jax'].tobytes()))
np.savez_compressed(r/'context.npz',**results);cp.cuda.runtime.deviceSynchronize();jax.effects_barrier();unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged
d=dict(scope='GPU-only original Richards call0/6/7 replay plus same-finalcoordinate separately compiled system, with actual XLA optimized HLO/PTX dumps. No model/precision/tolerance/solver change or accepted trajectory; byte reproduction reported honestly, independent numeric analysis pending EHPC. Atexit bypass after barriers/durable receipt.',source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=unchanged,device_barriers_complete=True,seconds=time.monotonic()-start,payload_sha256=sha(r/'context.npz'),original_payload_sha256=meta['payload_sha256'],comparison=comparison,jax_version=jax.__version__)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

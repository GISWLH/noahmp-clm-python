#loc1 = loc("args[0]")
module @jit_convert_element_type attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<f32> loc("args[0]")) -> (tensor<f32> {jax.result_info = "result"}) {
    return %arg0 : tensor<f32> loc(#loc7)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/lhwang/work/noahmp-v1/probe_richards_context_k.py":16:15 to :37)
#loc3 = loc("/home/lhwang/work/noahmp-v1/probe_richards_context_k.py":16:9 to :64)
#loc4 = loc("<genexpr>"(#loc2))
#loc5 = loc("<module>"(#loc3))
#loc6 = loc(callsite(#loc4 at #loc5))
#loc7 = loc("jit(convert_element_type)"(#loc6))

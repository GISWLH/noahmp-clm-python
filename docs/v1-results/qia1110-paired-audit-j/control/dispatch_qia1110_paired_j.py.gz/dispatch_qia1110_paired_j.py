from pathlib import Path
import hashlib,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia1110-paired-audit-j';assert not r.exists();r.mkdir();archives={}
for kind in ['cuda32','jax32']:
    a=b/('qia1110-full-'+kind+'-h-evidence.tar.gz');archives[kind]=hashlib.sha256(a.read_bytes()).hexdigest()
    with tarfile.open(a) as t:t.extractall(r/'device'/kind,filter='data')
    assert json.loads((r/'device'/kind/'exit.json').read_text())['passed']
controls={}
for n in ['audit_qia1110_paired_j.py','qia1110_paired_j.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia1110_paired_j.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,archives_sha256=archives,controls_sha256=controls),indent=2)+'\n');print(job)

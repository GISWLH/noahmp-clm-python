from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia1110-paired-audit-i'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'qia1110-final-h-source.tar.gz'
assert sha(a) == 'ffa30e87bc515d0694c9135c8b77d14286112e6da2cf7f4ef6467417319132a0'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 519 and all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

terminal = b / 'qia-all-phase-cuda-year-terminal-f-evidence.tar.gz'
assert sha(terminal) == '675da2ef9a64d2cc7d4734d869d49f494fd2dc146ff37660bf20fa10d80609f3'
td = Path(os.environ['TMPDIR']) / 'original-terminal'; td.mkdir()
with tarfile.open(terminal) as t:
    t.extractall(td, filter='data')
report = json.loads((td / 'trajectory/batch.json').read_text())
assert report['status'] == 'failed' and report['steps_completed'] == 1110
checkpoint = td / 'trajectory' / report['checkpoint_file']
assert sha(checkpoint) == report['checkpoint_sha256']
with np.load(checkpoint, allow_pickle=False) as z:
    saved = dict(z)
device = r / 'device'
binding = json.loads((device / 'cuda32/binding.json').read_text())
receipts = {label: json.loads((device / folder / 'receipt.json').read_text()) for label, folder in [('cuda32','cuda32'),('jax32','jax32')]}
with np.load(device / 'cuda32/input.npz', allow_pickle=False) as z:
    data = dict(z)
before = tuple(data['a' + str(k)] for k in range(19))
for k in range(19):
    np.testing.assert_array_equal(before[k], saved['a' + str(k)])
assert binding['original_checkpoint_sha256'] == report['checkpoint_sha256'] and sha(device / 'cuda32/input.npz') == binding['input_sha256']
exports, states, budgets = {}, {}, {}
for label, folder in [('cuda32','cuda32'),('jax32','jax32')]:
    receipt = receipts[label]
    assert sha(device/folder/'input.npz')==binding['input_sha256'] and receipt['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
    with np.load(device/folder/'before.npz',allow_pickle=False) as z:actual_before=tuple(z['a'+str(k)] for k in range(19))
    for k in range(19):
        if k!=4:np.testing.assert_array_equal(actual_before[k],before[k])
        else:
            np.testing.assert_array_equal(actual_before[k][:,:7],before[k][:,:7]);np.testing.assert_array_equal(actual_before[k][:,10:],before[k][:,10:]);np.testing.assert_array_equal(actual_before[k][:,7:10],data['environment'])
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
    assert sha(device / folder / 'output.npz') == receipt['result']['output_sha256']
    assert sha(device / folder / 'after.npz') == receipt['result']['state_sha256']
    with np.load(device / folder / 'output.npz', allow_pickle=False) as z:
        flat = dict(z)
    with np.load(device / folder / 'after.npz', allow_pickle=False) as z:
        after = tuple(z['a' + str(k)] for k in range(19))
    out = {}
    for name, value in flat.items():
        parts = name.split('/'); target = out
        for part in parts[:-1]:target = target.setdefault(part, {})
        target[parts[-1]] = value
    incoming, residual, bound, tracer = driver.audit_step(before, after, data['forcing'], data['deposition'], data['nitrogen'], out)
    cumulative = driver.totals(after) - saved['initial'] - (saved['net'] + incoming)
    cbound = saved['bounds'] + bound
    assert np.all(abs(cumulative) <= cbound)
    budgets[label] = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(),
            cumulative_residual=cumulative.tolist(), original_cumulative_bounds=cbound.tolist(), impurity_residual=tracer.tolist())
    exports[label] = flat; states[label] = after
assert exports['cuda32'].keys() == exports['jax32'].keys()
rows = []
for name, x in {**exports['cuda32'], **{'next'+str(k):v for k,v in enumerate(states['cuda32'])}}.items():
    y = states['jax32'][int(name[4:])] if name.startswith('next') else exports['jax32'][name]
    assert x.dtype == y.dtype and x.shape == y.shape and np.all(np.isfinite(x)) and np.all(np.isfinite(y)), name
    integer = x.dtype.kind in 'ibu'
    if integer:np.testing.assert_array_equal(x,y)
    else:
        assert x.dtype == np.dtype('float32'), (name,x.dtype)
        np.testing.assert_allclose(x,y,rtol=1e-6,atol=1e-6)
    rows.append(dict(field=name,dtype=str(x.dtype),integer_exact=integer,maximum_absolute=float(np.max(abs(x.astype(float)-y.astype(float)))) if x.size else 0.))
assert len(rows) == 380
record = dict(scope='EHPC PBS original511B independent production MHCN/impurity and original allraw1e-6/int-exact audits of both uninstrumented519H whole1110 steps. Originalfailed19state/initial/ledgers verified independently. All361output+19next fields float32 or exactinteger with no hidden/rounded fields. No originalfailedyear continuation,canonical/currentfull/science pass.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True, budgets=budgets, fields=rows,
              raw_output_fields=361, next_state_arrays=19, maximum_absolute_difference=max(x['maximum_absolute'] for x in rows),
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == h for n, h in m.items()),
              original_checkpoint_sha256=report['checkpoint_sha256'])
(r / 'audit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k:v for k,v in record.items() if k!='fields'},allow_nan=False),flush=True)

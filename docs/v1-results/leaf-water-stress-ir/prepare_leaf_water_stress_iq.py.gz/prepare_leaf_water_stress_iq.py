from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'leaf-water-stress-iq';assert not r.exists();r.mkdir();controls={}
for name in ['audit_leaf_water_stress_iq.py','leaf_water_stress_iq.pbs']:
 raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
plan=dict(upstream_commit='fdfc03a0abec838ec0b66663a6a2f5e619cd2611',upstream_url='https://github.com/ESCOMP/CTSM/blob/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/src/biogeophys/PhotosynthesisMod.F90',
 reference_contract='CLM5soil-beta: g0=max(g0opt*beta,1umolH2Om-2s-1), BallBerryslope unchanged; Vcmax/Rd multipliedbybeta, Jmax/TPU not additionallyscaled. At25C temperaturefactors1. Userrequiresminimumof3photosynthesislimitations, not officialsmoothedcolimitation. OwnDecimal80positivequadratic/256stepCIbisection, no Fortrancode copied.',
 source_archive_sha256='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e',source_manifest_sha256='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69',
 bb_assimilation_umol=[-1.,0.,1.,10.,20.],absorbed_par=[0.,50.,400.,1500.],co2_ppm=[200.,420.,800.],relative_humidity=[.3,.7,1.2],boundary_conductance_mol=[.05,.5,2.],water_stress=[0.,.01,.1,.5,1.],
 diagnostic_tolerance='Nonnearzero relative10percent; gs<=1e-4mol uses1e-6molabs, ci<=1ppm uses.1ppmabs, carbonrates<=.1umol uses.01umolabs. These are componentdiagnostic conventions fixedbeforerun, not changedobservationgates.',controls_sha256=controls,
 scope='Predeterminedcompletegridprechangephysicsaudit only; no fit or source/production/state/QC/gate changes.')
(r/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
p=subprocess.run(['qsub',str(r/'leaf_water_stress_iq.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,plan_sha256=hashlib.sha256((r/'plan.json').read_bytes()).hexdigest());(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

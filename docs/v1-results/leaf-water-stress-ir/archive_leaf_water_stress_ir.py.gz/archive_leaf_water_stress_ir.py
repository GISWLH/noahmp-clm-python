from pathlib import Path
import hashlib,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'leaf-water-stress-iq';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
launch=json.loads((r/'dispatch.json').read_text());raw=subprocess.check_output(['qstat','-xf',launch['pbs_job']],text=True)
assert re.search(r'^\s*job_state = F\s*$',raw,re.M) and re.search(r'^\s*Exit_status = 0\s*$',raw,re.M) and (r/'pbs-exit.txt').read_text().strip()=='0'
(r/'actual-pbs-qstat.txt').write_text(raw);d=json.loads((r/'receipt.json').read_text());assert d['analysis_delivered'] and d['source_unchanged']
assert d['summary']['bb_cases']==675 and d['summary']['leaf_cases']==540 and d['summary']['bb_exceeding_original_diagnostic_tolerances']==530 and d['summary']['unstressed_leaf_cases']==108
assert sha(r/'comparison.json')==d['comparison_sha256'] and sha(r/'decimal80-reference.json')==d['decimal_reference_sha256']
assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items())
archive=b/'leaf-water-stress-ir-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(r.rglob('*')):
  if p.is_file():
   assert not p.is_symlink();n='current/'+p.relative_to(r).as_posix();inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
 for n in ['prepare_leaf_water_stress_iq.py',Path(__file__).name]:inventory[n]=sha(b/n);tf.add(b/n,arcname=n,recursive=False)
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(inventory)
 for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(archive=archive.name,sha256=sha(archive),artifacts=len(inventory),bytes=archive.stat().st_size,actual_pbs=launch['pbs_job'],actual_pbs_exit=0,summary=d['summary'],scope=d['scope'])
(b/'leaf-water-stress-ir-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
from decimal import Decimal,localcontext
import hashlib,itertools,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'leaf-water-stress-iq';plan=json.loads((r/'plan.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=Path(os.environ['TMPDIR'])/'source';s.mkdir();archive=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(archive)==plan['source_archive_sha256']=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==579 and sha(s/'SOURCE_SHA256.json')==plan['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==h for n,h in m.items())
phase=(s/'src/noahmp_clm/physics/canopy_phase_energy.py').read_text();assert 'nitrogen_factor=nitrogen_factor*biochemical' in phase and 'biochemical=water_stress if tr_limit>0.' in phase
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
from noahmp_clm.physics.photosynthesis import LeafParameters,ball_berry_conductance,leaf_gas_exchange
p=LeafParameters();assert p.vcmax25==60. and p.jmax25==100. and p.tpu25==10. and p.respiration25==.9 and p.ball_berry_slope==9. and p.minimum_conductance==.01 and p.quantum_yield_psii==.85 and p.curvature==.7
D=lambda x:Decimal(str(x))
def reference_bb(an,cs,rh,gb,beta):
    # Own algebra of gs=g0+m*An*hs/Cs, hs=(gb*RH+gs)/(gb+gs).
    g0=max(D('.01')*beta,D('1e-6'));x=D(9)*max(an,D(0))/cs
    linear=gb-g0-x;constant=gb*(g0+x*min(rh,D(1)));root=(linear*linear+D(4)*constant).sqrt()
    return D(2)*constant/(linear+root) if linear>=0 else (root-linear)/D(2)
def reference_leaf(par,ca,rh,gb,beta):
    light=D('.5')*D('.85')*par;jmax=D(100);total=light+jmax
    electron=D(0) if light==0 else D(2)*light*jmax/(total+(total*total-D(4)*D('.7')*light*jmax).sqrt())
    michaelis=D('404.9')*(D(1)+D(210000)/D(278400));gamma=D('42.75');rd=D('.9')*beta
    def evaluate(ci):
        carbon=max(ci-gamma,D(0));ac=D(60)*beta*carbon/(ci+michaelis);aj=electron*carbon/(D(4)*ci+D(8)*gamma);ap=D(30)
        gross=min(ac,aj,ap);net=gross-rd;cs=max(ca-D('1.4')*net/gb,D('1e-9'))
        gs=reference_bb(net,cs,rh,gb,beta);residual=net-(ca-ci)/(D('1.4')/gb+D('1.6')/gs)
        return dict(ci_ppm=ci,gs_mol=gs,gross=gross,net=net,respiration=rd,rubisco=ac,rubp=aj,tpu=ap,diffusion_residual=residual)
    g0=max(D('.01')*beta,D('1e-6'));lo=D(0);hi=ca+rd*(D('1.4')/gb+D('1.6')/g0)+D(1)
    assert evaluate(lo)['diffusion_residual']<=0 and evaluate(hi)['diffusion_residual']>=0
    for _ in range(256):
        mid=(lo+hi)/D(2)
        if evaluate(mid)['diffusion_residual']<0:lo=mid
        else:hi=mid
    return evaluate((lo+hi)/D(2))
fields=['ci_ppm','gs_mol','gross','net','respiration','rubisco','rubp','tpu','diffusion_residual']
thresholds={name:(1e-4,1e-6) if name=='gs_mol' else ((1.,.1) if name=='ci_ppm' else (.1,.01)) for name in fields if name!='diffusion_residual'}
rows_bb=[];rows_leaf=[];raw_reference=[];start=time.monotonic()
with localcontext() as ctx:
    ctx.prec=80
    for an,cs,rh,gb,beta in itertools.product(plan['bb_assimilation_umol'],plan['co2_ppm'],plan['relative_humidity'],plan['boundary_conductance_mol'],plan['water_stress']):
        expected=reference_bb(*map(D,[an,cs,rh,gb,beta]));actual=float(ball_berry_conductance(an,cs,rh,gb,p,water_stress=beta));value=float(expected);difference=abs(actual-value)
        near=value<=1e-4;passed=difference<=1e-6 if near else difference<=.1*abs(value)
        rows_bb.append(dict(net=an,cs=cs,rh=rh,gb=gb,beta=beta,actual_gs=actual,reference_gs=value,reference_decimal=str(expected),absolute_difference=difference,relative_difference=difference/abs(value) if not near else None,within_10_percent_or_nearzero_absolute=passed))
    for par,ca,rh,gb,beta in itertools.product(plan['absorbed_par'],plan['co2_ppm'],plan['relative_humidity'],plan['boundary_conductance_mol'],plan['water_stress']):
        expected=reference_leaf(*map(D,[par,ca,rh,gb,beta]));actual=leaf_gas_exchange(par,298.15,co2_ppm=ca,relative_humidity=rh,boundary_conductance=gb,parameters=p,nitrogen_factor=beta,water_stress=beta)
        reference={name:float(expected[name]) for name in fields};values={name:float(actual[name]) for name in fields};errors={}
        for name,(near_limit,absolute) in thresholds.items():
            difference=abs(values[name]-reference[name]);near=abs(reference[name])<=near_limit
            errors[name]=dict(absolute_difference=difference,relative_difference=difference/abs(reference[name]) if not near else None,within_10_percent_or_nearzero_absolute=bool(difference<=absolute if near else difference<=.1*abs(reference[name])))
        rows_leaf.append(dict(par=par,ca=ca,rh=rh,gb=gb,beta=beta,current_caller_nitrogen_factor=beta,current_caller_water_stress=beta,actual=values,reference=reference,errors=errors))
        raw_reference.append(dict(par=par,ca=ca,rh=rh,gb=gb,beta=beta,decimal80={name:str(expected[name]) for name in fields}))
unit=[q for q in rows_leaf if q['beta']==1];assert len(unit)==108
unit_max={name:max(v['errors'][name]['absolute_difference'] for v in unit) for name in thresholds}
assert unit_max['ci_ppm']<1e-8 and unit_max['gs_mol']<1e-11 and all(unit_max[n]<1e-9 for n in thresholds if n not in ['ci_ppm','gs_mol'])
summary=dict(bb_cases=len(rows_bb),bb_exceeding_original_diagnostic_tolerances=sum(not q['within_10_percent_or_nearzero_absolute'] for q in rows_bb),
 leaf_cases=len(rows_leaf),leaf_exceedance_counts={name:sum(not q['errors'][name]['within_10_percent_or_nearzero_absolute'] for q in rows_leaf) for name in thresholds},
 unstressed_leaf_cases=len(unit),unstressed_max_absolute=unit_max,
 current_max_absolute_diffusion_residual=max(abs(q['actual']['diffusion_residual']) for q in rows_leaf),
 reference_max_absolute_diffusion_residual=max(abs(q['reference']['diffusion_residual']) for q in rows_leaf))
(r/'comparison.json').write_text(json.dumps(dict(plan=plan,summary=summary,ball_berry=rows_bb,leaf=rows_leaf),indent=2,allow_nan=False)+'\n')
(r/'decimal80-reference.json').write_text(json.dumps(raw_reference,indent=2)+'\n')
value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,analysis_delivered=True,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=plan['source_manifest_sha256'],
 summary=summary,comparison_sha256=sha(r/'comparison.json'),decimal_reference_sha256=sha(r/'decimal80-reference.json'),seconds=time.monotonic()-start,
 scope='Prechange independentDecimal80 publishedCLM5 soil-beta placement audit at25C, ownalgebra and userrequestedminimumof3limitations, no upstreamimplementationcopied. Currentrootavailable phase caller NF=beta/W=beta is explicitlychecked in frozen579source. All675BB and540leafgridcases retained, beta1tightagreement validates sameunstressedbiochemistry. Process0means auditdelivered,not currentphysicswithintolerance; no model/state/forcing/gate/calibration/ongoingyear changes.')
(r/'receipt.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps(value),flush=True);assert value['source_unchanged']

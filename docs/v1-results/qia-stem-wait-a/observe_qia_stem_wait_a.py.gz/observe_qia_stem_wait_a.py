from pathlib import Path
import datetime,hashlib,io,json,shlex,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-stem-numpy-day-a';launch=json.loads((r/'launch.json').read_text());target=next(x for x in launch['command'] if x.endswith('/run_fluxnet_column.py'));q=subprocess.run(['qstat','163.manager'],capture_output=True,text=True);assert q.returncode==0
code="""from pathlib import Path
import json,subprocess
target=TARGET;rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:args=(p/'cmdline').read_bytes().split(b'\\0')
 except (OSError,PermissionError):continue
 if target.encode() in args:
  rows.append(dict(pid=int(p.name),ps=subprocess.check_output(['ps','-p',p.name,'-o','pid,ppid,stat,etime,pcpu,wchan:32'],text=True)))
print(json.dumps(rows))
""".replace('TARGET',repr(target));command=shlex.join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-c',code]);observed=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','compute002',command],capture_output=True,text=True,timeout=30);assert observed.returncode==0,observed.stderr;workers=json.loads(observed.stdout);assert workers
p=r/'trajectory/report.json';raw=p.read_bytes();d=json.loads(raw);assert d['status']=='running' and d['steps_completed']<48
value=dict(scope='Own active PBS163/compute002 worker observation after30 minutes,original full17520 request and first48 stop retained. Committed pointer is not an iteration counter or a stopping diagnosis. No model/source/solver/gate change or restart; continue official CTSM preparation while preserving this run.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),job='163.manager',qstat=q.stdout,workers=workers,committed_steps=d['steps_completed'],requested_steps=d['steps_requested']);a=b/'qia-stem-wait-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
 for name,data in [('observation.json',(json.dumps(value,indent=2)+'\n').encode()),('captured-report.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),observation=value)))

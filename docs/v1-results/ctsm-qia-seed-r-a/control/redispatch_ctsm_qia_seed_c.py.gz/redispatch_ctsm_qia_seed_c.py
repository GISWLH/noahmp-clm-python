from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-seed-firstday-c'
assert not (r / 'dispatch.json').exists()
assert (b / 'ctsm-qia-run-r/pbs-exit.txt').read_text().strip() == '0'
parent = subprocess.check_output(['qstat', '-xf', '231.manager'], text=True)
assert 'Exit_status = 0' in parent
held = subprocess.check_output(['qstat', '-xf', '233.manager'], text=True)
assert 'job_state = H' in held and 'afterok:231.manager' in held and 'resources_used.' not in held
assert not (r / 'comparison.log').exists() and not (r / 'pbs-exit.txt').exists()
names = ['compare_ctsm_qia_seed_firstday_c.py', 'ctsm_qia_seed_firstday_c.pbs', 'ctsm-qia-seed-firstday-c-protocol.json']
hashes = {n: hashlib.sha256((r / n).read_bytes()).hexdigest() for n in names}
cancel = subprocess.run(['qdel', '233.manager'], text=True, capture_output=True)
(r / 'cancel-held233.stdout.txt').write_text(cancel.stdout)
(r / 'cancel-held233.stderr.txt').write_text(cancel.stderr)
assert cancel.returncode == 0
finished = subprocess.run(['qstat', '-xf', '233.manager'], text=True, capture_output=True)
(r / 'cancel-held233-qstat.txt').write_text(finished.stdout + finished.stderr)
submit = subprocess.run(['qsub', 'ctsm_qia_seed_firstday_c.pbs'], cwd=r, text=True, capture_output=True)
(r / 'submit.stdout.txt').write_text(submit.stdout)
(r / 'submit.stderr.txt').write_text(submit.stderr)
assert submit.returncode == 0 and re.fullmatch(r'\d+\.manager\n?', submit.stdout)
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Only own unstarted233 held on historical-success dependency canceled after actual parent2310 was independently verified. No worker/log/execution existed. Identical immutable C analysis resubmitted without stale scheduler dependency; early actual-parent guard and all numerical gates retained. qalter empty-dependency syntax rejection retained separately. No model/year/other jobs signaled.',
              canceled_unstarted_pbs='233.manager', cancel_returncode=cancel.returncode, canceled_qstat_returncode=finished.returncode,
              actual_completed_parent='231.manager', actual_parent_exit=0, pbs_job=submit.stdout.strip(), controls_sha256=hashes)
(r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

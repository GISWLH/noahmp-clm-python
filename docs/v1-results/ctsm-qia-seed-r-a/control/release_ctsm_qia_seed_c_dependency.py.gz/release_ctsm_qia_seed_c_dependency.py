from pathlib import Path
import datetime
import json
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-seed-firstday-c'
assert not (r / 'dependency-resolution.json').exists()
assert (b / 'ctsm-qia-run-r/pbs-exit.txt').read_text().strip() == '0'
parent = subprocess.check_output(['qstat', '-xf', '231.manager'], text=True)
assert 'Exit_status = 0' in parent
before = subprocess.check_output(['qstat', '-xf', '233.manager'], text=True)
assert 'job_state = H' in before and 'afterok:231.manager' in before and 'resources_used.' not in before
(r / 'dependency-before.txt').write_text(before)
(r / 'completed-parent-qstat.txt').write_text(parent)
p = subprocess.run(['qalter', '-W', 'depend=', '233.manager'], text=True, capture_output=True)
(r / 'dependency-qalter.stdout.txt').write_text(p.stdout)
(r / 'dependency-qalter.stderr.txt').write_text(p.stderr)
after = subprocess.check_output(['qstat', '-xf', '233.manager'], text=True)
(r / 'dependency-after.txt').write_text(after)
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='PBS historical successful parent dependency stayed held after submission. Actual parent231 PBS file and qstat Exit_status0 independently confirmed; remove only stale scheduler dependency, immutable analysis early parent guard and all numerical gates unchanged. No model task signaled or controls changed.',
              pbs_job='233.manager', actual_parent_exit=0, command=['qalter', '-W', 'depend=', '233.manager'], returncode=p.returncode)
(r / 'dependency-resolution.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
assert p.returncode == 0

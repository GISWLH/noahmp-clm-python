from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r = b / 'ctsm-qia-run-r'
d = json.loads((r / 'configuration.json').read_text())
assert (r / 'pbs-exit.txt').read_text().strip() == '0' and d['official_model_returncode'] == 0
assert d['upstream_original_bytes_unchanged'] and all(s['returncode'] == 0 for s in d['stages'])
audit = json.loads((r / 'year-boundary.json').read_text())
seed = json.loads((r / 'canopy-seed-audit.json').read_text())
assert audit['positive_intervals'] == 17520 and audit['all_direct_met_fields_exact_at_history_dtype']
assert sha(r / 'official-year-fields.npz') == audit['fields_sha256'] and all(v == 0. for v in seed['maximum_absolute_errors'].values())
bad, good = [b / n for n in ['ctsm-qia-seed-firstday-b', 'ctsm-qia-seed-firstday-c']]
assert (bad / 'pbs-exit.txt').read_text().strip() == '1' and 'FileNotFoundError' in (bad / 'comparison.log').read_text()
assert (good / 'pbs-exit.txt').read_text().strip() == '0'
diagnosis = json.loads((good / 'diagnosis.json').read_text())
dispatch = json.loads((good / 'dispatch.json').read_text())
assert diagnosis['pbs_job'] == dispatch['pbs_job'] == '234.manager' and dispatch['canceled_unstarted_pbs'] == '233.manager'
assert sha(good / 'native-trace-snapshot.npz') == diagnosis['native_trace_snapshot_sha256']
assert sha(good / 'native-report-snapshot.json') == diagnosis['native_report_snapshot_sha256']
assert diagnosis['cases']['R']['official_fields_sha256'] == audit['fields_sha256'] and not diagnosis['scientific_acceptance']
canopy = diagnosis['cases']['R']['actual_canopy']
assert canopy['TLAI']['first48_min'] == canopy['TLAI']['first48_max'] == canopy['TLAI']['year_min'] == canopy['TLAI']['year_max'] == 3.
assert canopy['TSAI']['first48_min'] == canopy['TSAI']['first48_max'] == canopy['TSAI']['year_min'] == canopy['TSAI']['year_max']
old = json.loads((b / 'ctsm-qia-seed-firstday-a/diagnosis.json').read_text())
assert all(diagnosis['cases'][key]['metrics'] == old['cases'][key]['metrics'] for key in ['O', 'Q'])
a = b / 'ctsm-qia-seed-r-a-evidence.tar.gz'
assert not a.exists()
samples, steps, raw_history = 0, [], []
with tarfile.open(a, 'w:gz') as t:
    for root in [r, bad, good]:
        for f in sorted(root.iterdir()):
            if f.is_file() and f.name != 'case-configuration-private.tar.gz':
                t.add(f, arcname=root.name + '/' + f.name, recursive=False)
    with tarfile.open(r / 'case-configuration-private.tar.gz') as source:
        for m in source:
            if not m.isfile():
                continue
            is_history = m.name.startswith('output/case/run/') and '.clm2.h0.' in m.name and m.name.endswith('.nc')
            keep = is_history or m.name.endswith(('.stdout.txt', '.stderr.txt', '-adaptation.json', '.stream')) or m.name.startswith('case/user_nl_') or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in', 'drv_in', 'lnd_in'])) or m.name in ['inputdata/CN-Qia.partial-hydrothermal-init.nc', 'inputdata/CN-Qia.official-interpolated-cold.nc']
            if not keep:
                continue
            raw = source.extractfile(m).read()
            info = tarfile.TarInfo(r.name + '/workspace/' + m.name)
            info.size = len(raw)
            t.addfile(info, io.BytesIO(raw))
            if is_history:
                digest = hashlib.sha256(raw).hexdigest()
                assert d['model_outputs'][Path(m.name).name]['sha256'] == digest
                raw_history.append(dict(member=m.name, sha256=digest, bytes=len(raw)))
            if 'lnd.log.' in m.name:
                text = raw.decode(errors='replace')
                samples += text.count('Writing current time sample')
                steps.extend(map(int, re.findall(r'clm: completed timestep\s+(\d+)', text)))
    assert samples == 17521 and max(steps) == 17520 and len(raw_history) == 2
    summary = dict(scope='Actual official R full17520-bin additional original-native LAI/SAI/crown/flag initial prescription,model/PBS0,unchanged source/met/soil. All declared hydrothermal/canopy readbacks0; TLAI3/SAI constant from first positive bin through full year. Every original O/Q bin/result retained, C exactly reproduces original O/Q metrics with identical immutable native96 prefix/first48. B early parent-exit race and C held233/qalter2/cancel-unstarted/redispatch234 retained; no model tasks stopped. Soil/depth/aquifer/root/stress/SP-CN and other fresh cold defaults remain,not science/Python-year/spinup acceptance.',
                   pbs_job=d['pbs_job'], official_model_and_pbs_returncode=0,
                   model_seconds=next(s['seconds'] for s in d['stages'] if s['stage'] == 'official-model'), total_seconds=d['seconds'],
                   history_samples=samples, last_nstep=max(steps), original_private_sha256=sha(r / 'case-configuration-private.tar.gz'),
                   source_bundle_sha256='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',
                   raw_history=raw_history, year_fields_sha256=audit['fields_sha256'], canopy_seed_audit_sha256=sha(r / 'canopy-seed-audit.json'),
                   diagnosis_sha256=sha(good / 'diagnosis.json'), comparison_pbs_job='234.manager')
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    for name in ['release_ctsm_qia_seed_c_dependency.py', 'redispatch_ctsm_qia_seed_c.py', 'archive_ctsm_qia_seed_r_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, official_model_and_pbs_returncode=0,
                      positive_bins=17520, raw_history_files=len(raw_history), model_seconds=summary['model_seconds'], total_seconds=summary['total_seconds'])))

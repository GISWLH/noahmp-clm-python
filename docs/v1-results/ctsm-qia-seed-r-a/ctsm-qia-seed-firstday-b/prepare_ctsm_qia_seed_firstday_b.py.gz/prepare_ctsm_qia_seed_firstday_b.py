from pathlib import Path
import ast
import json

r = Path(__file__).resolve().parent
p = (r / 'compare_ctsm_qia_seed_firstday_a.py').read_text().replace("r = b / 'ctsm-qia-seed-firstday-a'", "r = b / 'ctsm-qia-seed-firstday-b'")
p = p.replace("raw_report = (native / 'trajectory/report.json').read_bytes()", "raw_report = (b / 'ctsm-qia-seed-firstday-a/native-report-snapshot.json').read_bytes()")
p = p.replace("trace = native / 'trajectory' / report['model_npz']", "trace = b / 'ctsm-qia-seed-firstday-a/native-trace-snapshot.npz'")
p = p.replace("for key in ['o', 'q']:", "for key in ['o', 'q', 'r']:")
p = p.replace("if key == 'q' else None)", "if key in ['q', 'r'] else None, initial_canopy_audit_sha256=sha(official / 'canopy-seed-audit.json') if key == 'r' else None)")
p = p.replace('vs official O default cold and Q predeclared hydrothermal initialization.', 'vs official O default cold, Q predeclared hydrothermal initialization, R additional original declared LAI/SAI/crown/vegetation flag. Exact same immutable native96 prefix from prior A,not a score-selected time window.')
marker = "record = dict(scope="
assert p.count(marker) == 1
p = p.replace(marker, "previous=json.loads((b/'ctsm-qia-seed-firstday-a/diagnosis.json').read_text())\nassert hashlib.sha256(raw_report).hexdigest()==previous['native_report_snapshot_sha256'] and hashlib.sha256(trace_raw).hexdigest()==previous['native_trace_snapshot_sha256']\nassert all(cases[k]['metrics']==previous['cases'][k]['metrics'] for k in ['O','Q'])\n" + marker)
ast.parse(p)
(r / 'compare_ctsm_qia_seed_firstday_b.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_seed_firstday_a.pbs').read_text().replace('clm-qia-seed-firstday-a', 'clm-qia-seed-firstday-b').replace('ctsm-qia-seed-firstday-a', 'ctsm-qia-seed-firstday-b').replace('compare_ctsm_qia_seed_firstday_a.py', 'compare_ctsm_qia_seed_firstday_b.py')
(r / 'ctsm_qia_seed_firstday_b.pbs').write_bytes(p.encode())
protocol = dict(scope='Prospective extra R comparison after declared initial-canopy prescription. Same immutable source510 NumPy96 snapshot,first48 bins and metric helper; original O/Q metrics must reproduce exactly. No time exclusion or fit. Science acceptance remains false until backgrounds,spinup and complete validation are met.',
                cases=['O', 'Q', 'R'], samples=48, baseline='ctsm-qia-seed-firstday-a immutable96 snapshot',
                nee='unmeasured: official SP has no prognostic CN/NEE')
(r / 'ctsm-qia-seed-firstday-b-protocol.json').write_bytes((json.dumps(protocol, indent=2) + '\n').encode())
print('Prepared O/Q/R same-prefix comparison B')

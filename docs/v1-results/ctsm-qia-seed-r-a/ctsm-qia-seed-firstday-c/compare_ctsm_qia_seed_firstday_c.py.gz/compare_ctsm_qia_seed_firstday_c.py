"""Additional declared initial-state experiment; all numerical work requires PBS."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-seed-firstday-c'
native = b / 'qia-fresh-phase-numpy-week-a'
assert (b/'ctsm-qia-run-r/pbs-exit.txt').read_text().strip()=='0'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
raw_report = (b / 'ctsm-qia-seed-firstday-a/native-report-snapshot.json').read_bytes()
report = json.loads(raw_report)
assert report['source_unchanged'] and report['steps_completed'] >= 48 and report['steps_requested'] == 17520
assert report['status'] in ['running', 'complete']
trace = b / 'ctsm-qia-seed-firstday-a/native-trace-snapshot.npz'
trace_raw = trace.read_bytes()
assert hashlib.sha256(trace_raw).hexdigest() == report['model_npz_sha256']
(r / 'native-report-snapshot.json').write_bytes(raw_report)
(r / 'native-trace-snapshot.npz').write_bytes(trace_raw)
with np.load(trace, allow_pickle=False) as z:
    model = {n: np.asarray(v)[:48] if np.asarray(v).ndim else np.asarray(v) for n, v in z.items()}
assert str(model['time_start'][0]) == '200301010000' and str(model['time_end'][-1]) == '200301020000'
archive = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(archive) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(archive) as t:
    source_raw = t.extractfile('SOURCE_SHA256.json').read()
    manifest = json.loads(source_raw)
    code = t.extractfile('src/noahmp_clm/validation.py').read()
assert hashlib.sha256(source_raw).hexdigest() == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
assert hashlib.sha256(code).hexdigest() == manifest['src/noahmp_clm/validation.py']
assert all(manifest[n] == digest for n, digest in report['source_sha256'].items())
helper = Path(os.environ['TMPDIR']) / 'fixed_validation_seed_a.py'
helper.write_bytes(code)
spec = importlib.util.spec_from_file_location('fixed_validation_seed_a', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
compare = module.compare_series
config = json.loads((b / 'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json').read_text())
target_dz = np.asarray(config['column']['dz'], float)
te = np.r_[0., np.cumsum(target_dz)]
cases = {}
for key in ['o', 'q', 'r']:
    official = b / ('ctsm-qia-run-' + key)
    case = json.loads((official / 'configuration.json').read_text())
    assert (official / 'pbs-exit.txt').read_text().strip() == '0' and case['official_model_returncode'] == 0
    assert case['upstream_original_bytes_unchanged'] and all(s['returncode'] == 0 for s in case['stages'])
    audit = json.loads((official / 'year-boundary.json').read_text())
    assert audit['all_direct_met_fields_exact_at_history_dtype'] and audit['positive_intervals'] == 17520
    assert sha(official / 'official-year-fields.npz') == audit['fields_sha256']
    with np.load(official / 'official-year-fields.npz', allow_pickle=False) as z:
        reference = dict(z)
    assert np.array_equal(reference['time_bounds_seconds'][:48], np.arange(48)[:, None] * 1800 + [[0, 1800]])
    metrics = {}
    for out, source, factor, metric_key in [
        ('h_wm2', 'FSH', 1., 'h_wm2'), ('le_wm2', 'EFLX_LH_TOT', 1., 'le_wm2'),
        ('et_mm', 'QFLX_EVAP_TOT', 86400., 'et_mm_day'), ('runoff_mm', 'QRUNOFF', 86400., 'runoff_mm_day'),
        ('gpp_gc_m2', 'FPSN', 12.0107e-6 * 86400., 'gpp_gc_day'), ('swe_m', 'H2OSNO', .001, 'swe_m')]:
        actual = np.asarray(model[out], float)
        if out in ['et_mm', 'runoff_mm', 'gpp_gc_m2']:
            actual = actual * 48.
        expected = np.asarray(reference[source][:48], float).reshape(48) * factor
        metrics[out] = compare(actual, expected, metric_key, weights=np.full(48, 1800.))
    dz = np.asarray(reference['DZSOI'], float).reshape(-1)
    assert target_dz.shape == (4,) and dz.size == 15 and np.all(dz > 0)
    se = np.r_[0., np.cumsum(dz)]
    weights = np.maximum(0., np.minimum(te[1:, None], se[None, 1:]) - np.maximum(te[:-1, None], se[None, :-1])) / target_dz[:, None]
    assert np.max(abs(weights.sum(1) - 1.)) < 1e-14 and np.all(weights[:, 10:] == 0.)
    tsoil = np.asarray(reference['TSOI'][:48], float).reshape(48, 15) @ weights.T
    theta = np.asarray(reference['H2OSOI'][:48], float).reshape(48, 10) @ weights[:, :10].T
    for field, expected, metric_key, offset in [('tsoil_k', tsoil, 'tsoil_c', 273.15), ('smc_m3m3', theta, 'smc', 0.)]:
        assert model[field].shape == (48, 4)
        for layer in range(4):
            metrics[field + '/' + str(layer)] = compare(model[field][:, layer] - offset, expected[:, layer] - offset, metric_key, weights=np.full(48, 1800.))
    canopy = {name: dict(first48_min=float(np.min(reference[name][:48])), first48_max=float(np.max(reference[name][:48])),
                         year_min=float(np.min(reference[name])), year_max=float(np.max(reference[name]))) for name in ['TLAI', 'TSAI']}
    cases[key.upper()] = dict(official_configuration_sha256=sha(official / 'configuration.json'), official_fields_sha256=audit['fields_sha256'],
                             model_and_pbs_returncode=0, metrics=metrics, actual_canopy=canopy,
                             soil_operator=dict(target_interfaces_m=te.tolist(), official_interfaces_m=se.tolist(), overlap_weights=weights.tolist()),
                             initial_seed_audit_sha256=sha(official / 'partial-seed-audit.json') if key in ['q', 'r'] else None, initial_canopy_audit_sha256=sha(official / 'canopy-seed-audit.json') if key == 'r' else None)
previous=json.loads((b/'ctsm-qia-seed-firstday-a/diagnosis.json').read_text())
assert hashlib.sha256(raw_report).hexdigest()==previous['native_report_snapshot_sha256'] and hashlib.sha256(trace_raw).hexdigest()==previous['native_trace_snapshot_sha256']
assert all(cases[k]['metrics']==previous['cases'][k]['metrics'] for k in ['O','Q'])
record = dict(scope='Prospective first48 original-calendar diagnostic: unchanged current510 NumPy cold prefix vs official O default cold, Q predeclared hydrothermal initialization, R additional original declared LAI/SAI/crown/vegetation flag. Exact same immutable native96 prefix from prior A,not a score-selected time window. No fit/score-based seed choice. Both official references retain coarse soil/depth/aquifer/SP-CN and fresh default rolling states; not all-conditions scientific acceptance. Firstday only is not full Python year/spinup/FLUXNET.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, samples=48, cases=cases,
              native_report_snapshot_sha256=hashlib.sha256(raw_report).hexdigest(), native_trace_snapshot_sha256=hashlib.sha256(trace_raw).hexdigest(),
              original_native_steps_completed=report['steps_completed'], original_native_status=report['status'], native_source_manifest_sha256=hashlib.sha256(source_raw).hexdigest(),
              fixed_metric_helper_sha256=hashlib.sha256(code).hexdigest(), scientific_acceptance=False,
              nee='unmeasured: official SP has no prognostic CN/NEE', temperature_error_reference='Celsius',
              gpp_operator='Pinned-source FPSN gross canopy assimilation,12.0107gC/mol; not An or NEE.')
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

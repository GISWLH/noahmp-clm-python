from pathlib import Path
import ast
import json

p = Path(__file__).resolve().parent
s = (p / 'compare_ctsm_qia_seed_firstday_b.py').read_text()
s = s.replace("r = b / 'ctsm-qia-seed-firstday-b'", "r = b / 'ctsm-qia-seed-firstday-c'")
s = s.replace("native = b / 'qia-fresh-phase-numpy-week-a'", "native = b / 'qia-fresh-phase-numpy-week-a'\nassert (b/'ctsm-qia-run-r/pbs-exit.txt').read_text().strip()=='0'")
ast.parse(s)
(p / 'compare_ctsm_qia_seed_firstday_c.py').write_bytes(s.encode())
s = (p / 'ctsm_qia_seed_firstday_b.pbs').read_text().replace('clm-qia-seed-firstday-b', 'clm-qia-seed-firstday-c').replace('ctsm-qia-seed-firstday-b', 'ctsm-qia-seed-firstday-c').replace('compare_ctsm_qia_seed_firstday_b.py', 'compare_ctsm_qia_seed_firstday_c.py')
(p / 'ctsm_qia_seed_firstday_c.pbs').write_bytes(s.encode())
d = json.loads((p / 'ctsm-qia-seed-firstday-b-protocol.json').read_text())
d['prior_B_failure'] = 'PBS232 started after model/seed results but before parent231 archive/PBS-exit existed; original FileNotFoundError retained. C submitted only after actual parent0,adds explicit early prerequisite guard. Same immutable native96/first48,official outputs and fixed metric helper,no numerical change.'
(p / 'ctsm-qia-seed-firstday-c-protocol.json').write_bytes((json.dumps(d, indent=2) + '\n').encode())
print('Prepared C explicit completed-parent guard; B unchanged')

from pathlib import Path
import ast
import json

r = Path(__file__).resolve().parent
p = (r / 'run_ctsm_qia_q.py').read_text().replace('ctsm-qia-run-q', 'ctsm-qia-run-r')
marker = "    value['partial_seed']=json.loads((root/'partial-seed.json').read_text())"
assert p.count(marker) == 1
p = p.replace(marker, "    assert run('initial-canopy-seed',[py,str(root/'set_ctsm_qia_canopy_seed_a.py'),'make',str(inputs),str(root)])==0\n" + marker)
marker = "                value['partial_seed_audit']=json.loads((root/'partial-seed-audit.json').read_text())"
assert p.count(marker) == 1
p = p.replace(marker, marker + "\n                assert run('initial-canopy-audit',[py,str(root/'set_ctsm_qia_canopy_seed_a.py'),'audit',str(inputs),str(root)])==0\n                value['canopy_seed_audit']=json.loads((root/'canopy-seed-audit.json').read_text())")
ast.parse(p)
(r / 'run_ctsm_qia_r.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_q.pbs').read_text().replace('ctsm-qia-run-q', 'ctsm-qia-run-r').replace('run_ctsm_qia_q.py', 'run_ctsm_qia_r.py').replace('clm-qia-official-q', 'clm-qia-official-r')
(r / 'ctsm_qia_run_r.pbs').write_bytes(p.encode())
d = json.loads((r / 'ctsm-qia-run-q-protocol.json').read_text())
d['scope'] = d['scope'].replace('official Q ', 'official R ')
d['additional_initial_canopy'] = dict(lai=3., sai=.549363332802184, crown_top_m=11., crown_bottom_m=5.5, vegetation_flag=1,
                                    basis='Original pre-score native configuration339310f...; actual O/Q first positive bin canopy0 and official late-driver SP update confirmed. Preserve O/Q and every bin, no score-fitted values or source edits. Other fresh radiation/rolling/soil/aquifer/SP-CN differences remain.')
(r / 'ctsm-qia-run-r-protocol.json').write_bytes((json.dumps(d, indent=2) + '\n').encode())
print('Prepared R additional declared canopy initial fields; P/Q unchanged')

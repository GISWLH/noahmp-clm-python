from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

r = Path('/home/zhangyq/noahmp-v1') / ('ctsm-qia-run-' + sys.argv[1])
job = sys.argv[2]
assert not (r / 'launch.json').exists()
files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(r.iterdir()) if p.suffix in ['.py', '.pbs', '.json']}
qstat = subprocess.run(['qstat', '-xf', job], text=True, capture_output=True)
(r / 'launch-qstat.txt').write_text(qstat.stdout)
(r / 'launch-qstat.stderr.txt').write_text(qstat.stderr)
assert qstat.returncode == 0
value = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pbs_job=job,
             scope='Actual submitted official initial-state experiment; retained qstat may already be historical, not a fabricated launch or completion. No science pass inferred. Original O/upstream and Python/GPU jobs unchanged.',
             controls_sha256=files, pbs_node='compute002' if 'compute002' in qstat.stdout else None)
(r / 'launch.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(dict(root=r.name, pbs_job=job, controls=len(files), node=value['pbs_node'])))

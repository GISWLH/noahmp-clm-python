from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,subprocess,sys,time,urllib.request
base=Path('/home/lhwang/work/noahmp-v1');root=base/'ctsm-input-heads-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes());(root/'original-116-configuration.json').write_bytes((base/'ctsm-case-build-d-configuration.json').read_bytes())
    command=[sys.executable,'-u',str(root/Path(__file__).name),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    value=dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only HEAD availability/size inspection of actual PBS116 official static input paths. No dataset download, generated forcing or physical model execution.')
    (root/'launch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(0)
source=root/'original-116-configuration.json';configuration=json.loads(source.read_text());assert configuration['pbs_job']=='116.manager' and configuration['upstream_original_bytes_unchanged']
paths=set();unresolved=[]
for name,text in configuration['input_file_lists'].items():
    for line in text.splitlines():
        key,path=line.split('=',1);path=path.strip()
        if '/inputdata/' not in path:unresolved.append(dict(list=name,key=key.strip(),value=path));continue
        relative=path.split('/inputdata/',1)[1];p=PurePosixPath(relative);assert not p.is_absolute() and '..' not in p.parts;paths.add(relative)
rows=[];begun=time.monotonic()
for path in sorted(paths):
    url='https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/'+path;row=dict(path=path,url=url);start=time.monotonic()
    try:
        request=urllib.request.Request(url,method='HEAD',headers={'User-Agent':'noahmp-clm-reference-preparation/1'})
        with urllib.request.urlopen(request,timeout=20) as response:row.update(status=response.status,final_url=response.url,headers={k:response.headers.get(k) for k in ['Content-Length','Content-Type','ETag','Last-Modified']})
    except Exception as e:row.update(error=type(e).__name__+': '+str(e))
    row['seconds']=time.monotonic()-start;rows.append(row);(root/'progress.json').write_text(json.dumps(dict(status='running',results=rows),indent=2)+'\n')
value=dict(scope='HEAD metadata only, not downloaded or validated NetCDF input data; unresolved meteorology retained, no runnable case or scientific acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_configuration_sha256=sha(source),unresolved=unresolved,results=rows,seconds=time.monotonic()-begun)
(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

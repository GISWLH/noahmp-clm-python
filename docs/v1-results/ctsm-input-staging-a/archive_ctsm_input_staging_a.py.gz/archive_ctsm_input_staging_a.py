from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pairs=[]
for folder,names in [('ctsm-input-heads-a',['launch_ctsm_input_heads_a.py','launch.json','controller.log','progress.json','summary.json','original-116-configuration.json']),('ctsm-static-inputs-a',['launch_ctsm_static_inputs_a.py','launch.json','controller.log','progress.json','summary.json','SOURCE_INPUT_LOCK.json'])]:
    for name in names:pairs.append((base/folder/name,folder+'/'+name))
r=json.loads((base/'ctsm-static-inputs-a/summary.json').read_text());assert len(r['results'])==7 and sum(v['bytes'] for v in r['results'])==2738092 and r['archive_sha256']==sha(base/'ctsm-static-inputs-a.tar.gz')=='c821ed102415bddacf0fd55f7cce4e914d57ca8d02e1284437d70bc3b4ee221d'
pairs.append((Path(__file__),Path(__file__).name));dest=base/'ctsm-input-staging-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for p,name in pairs:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(path=str(dest),files=len(pairs),sha256=sha(dest),scope='Actual URL HEAD/size metadata and seven original public NetCDF byte/hash staging receipts only. No raw datasets in public evidence; meteorology/three larger files unresolved, no runnable case or scientific acceptance.')))

from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,subprocess,sys,tarfile,time,urllib.request
base=Path('/home/lhwang/work/noahmp-v1');root=base/'ctsm-static-inputs-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes());command=[sys.executable,'-u',str(root/Path(__file__).name),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    value=dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Download original official static files individually <=10MiB from actual PBS116 input lists with HEAD binding/size/signature/SHA256 checks; no forcing generation or model run.')
    (root/'launch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(0)
head_path=base/'ctsm-input-heads-a/summary.json';heads=json.loads(head_path.read_text());selected=[];deferred=[]
for row in heads['results']:
    assert row['status']==200
    size=int(row['headers']['Content-Length'])
    (selected if size<=10*1024**2 else deferred).append(row)
assert len(selected)==7 and len(deferred)==3
begun=time.monotonic();results=[];inputs=root/'inputdata';inputs.mkdir()
for row in selected:
    p=PurePosixPath(row['path']);assert not p.is_absolute() and '..' not in p.parts
    path=inputs/str(p);path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();headers={'User-Agent':'noahmp-clm-reference-preparation/1'}
    if row['headers'].get('ETag'):headers['If-Match']=row['headers']['ETag']
    start=time.monotonic();request=urllib.request.Request(row['url'],headers=headers)
    with urllib.request.urlopen(request,timeout=45) as response:
        assert response.status==200
        with path.open('xb') as f:
            while True:
                chunk=response.read(1024**2)
                if not chunk:break
                f.write(chunk);assert f.tell()<=10*1024**2
    assert path.stat().st_size==int(row['headers']['Content-Length'])
    with path.open('rb') as f:signature=f.read(8)
    assert signature[:3]==b'CDF' or signature==b'\x89HDF\r\n\x1a\n'
    results.append(dict(path=row['path'],url=row['url'],head_etag=row['headers'].get('ETag'),bytes=path.stat().st_size,sha256=sha(path),netcdf_signature_hex=signature.hex(),seconds=time.monotonic()-start))
    (root/'progress.json').write_text(json.dumps(dict(status='running',results=results),indent=2)+'\n')
value=dict(scope='Original public input bytes staged only. NetCDF variables/model compatibility not inspected yet; three larger static inputs and null meteorology unresolved, no runnable case/scientific result.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_summary_sha256=sha(head_path),results=results,deferred=[dict(path=v['path'],bytes=int(v['headers']['Content-Length'])) for v in deferred],unresolved=heads['unresolved'],seconds=time.monotonic()-begun)
lock=root/'SOURCE_INPUT_LOCK.json';lock.write_text(json.dumps(value,indent=2)+'\n');archive=base/'ctsm-static-inputs-a.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for row in results:t.add(inputs/row['path'],arcname='inputdata/'+row['path'],recursive=False)
    t.add(lock,arcname=lock.name,recursive=False)
(root/'summary.json').write_text(json.dumps(dict(**value,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size),indent=2)+'\n');print(json.dumps(dict(files=len(results),bytes=sum(v['bytes'] for v in results),archive=str(archive),archive_sha256=sha(archive))))

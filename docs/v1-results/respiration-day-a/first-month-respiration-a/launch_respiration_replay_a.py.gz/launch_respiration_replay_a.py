from pathlib import Path
import json,os,subprocess,hashlib
base=Path('/home/lhwang/work/noahmp-v1');root=base/'first-month-respiration-a';source=base/'p6-phase-short-circuit-gpu-a';receipt=root/'launch.json';assert not receipt.exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
    OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'))
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'diagnose_clm_respiration.py'),'--batch',str(base/'fluxnet-first-climate-cycle-20261017-i/batch.json'),
    '--model-root',str(base/'fluxnet-first-climate-cycle-20261017-i/cuda-day'),'--output',str(root/'result')]
with (root/'replay.log').open('w') as log:proc=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
value=dict(pid=proc.pid,gpu=0,command=command,instrument_sha256=hashlib.sha256((root/'diagnose_clm_respiration.py').read_bytes()).hexdigest(),scope='Fixed Jan15 original I replay, no physical source or parameter change; original year continues independently.')
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

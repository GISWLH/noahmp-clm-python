from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-reference-e';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prerequisite=json.loads((b/'richards-numpy-c/receipt.json').read_text())
assert (b/'richards-numpy-c/pbs-exit.txt').read_text().strip()=='0' and prerequisite['counts']==dict(tests=28,failures=0,errors=0,skipped=0) and prerequisite['source_unchanged']
a=b/'richards-numpy-c-source.tar.gz';assert sha(a)=='ae2cbfb94669326fcb0efa0d5ea9ce30a128214813112fafd59f8741a6f08a9b'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==538 and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s/'src'),str(s/'tests')]
from noahmp_clm.physics.richards import HydraulicProfile,redistribute_liquid,soil_hydraulic_profile
from test_richards import profile,initial_soil
start=time.monotonic();cases=[]
def add(label,p,theta,duration):cases.append((label,p,np.asarray(theta)*1000.*p.dz_m,duration))
for i,(theta,dt,n) in enumerate([([.35,.24,.28,.25],1800.,4),([.1,.15,.2,.25],21600.,4),([.4,.39,.25,.2],7200.,4),([.28]*4,86400.,4),([.32,.25,.3,.2],86400.,4),([.28]*10,21600.,10)]):add('transient'+str(i),profile(n),theta,dt)
for i,theta in enumerate([[0.,.3,.25,.28],[.3,0.,.25,.28],[.3,0.,0.,.28]]):add('dry'+str(i),profile(),theta,1800.)
add('all-dry',profile(),[0.]*4,86400.)
for blocked in [False,True]:
    por=np.zeros(4) if blocked else np.array([.45,0.,.45,.45]);p=HydraulicProfile(profile().dz_m,por,np.where(por>0.,1e-5,0.),.355,5.5,.45)
    add('ice-barrier-'+str(blocked),p,np.zeros(4) if blocked else [.3,0.,.35,.2],1800.)
add('saturated-binary-pore',HydraulicProfile([.125,.25,.5,1.],.5,1e-5,.355,5.5),[.5]*4,86400.)
for n in [4,10]:
    p=profile(n);theta=p.porosity*(p.saturated_suction_m/(p.midpoint_m[-1]+2.-p.midpoint_m))**(1./p.retention_exponent)
    add('hydrostatic'+str(n),p,theta,86400.)
for option in [1,2]:
    state=initial_soil([.3,.31,.29,.35],[271.,274.,272.,276.],option=option)
    cases.append(('frozen'+str(option),soil_hydraulic_profile(state),state.liquid,21600.))
assert len(cases)==17
data={};records=[]
for precision,dtype in [('32',np.float32),('64',np.float64)]:
    for index,(label,p,water,duration) in enumerate(cases):
        h=np.column_stack([getattr(p,n) for n in p.__dataclass_fields__]).astype(dtype)
        old=water.astype(dtype);dt=np.array([duration],dtype)
        decoded=HydraulicProfile(**{name:h[:,i].astype(float) for i,name in enumerate(p.__dataclass_fields__)})
        answer=redistribute_liquid(old.astype(float),decoded,float(dt[0]))
        prefix=precision+'/'+str(index)+'/'
        data.update({prefix+'water':old[None,:],prefix+'hydraulics':h[None,:,:],prefix+'dt':dt})
        data.update({prefix+'expected/'+key:np.asarray(value)[None,...] for key,value in answer.items()})
        records.append(dict(precision=precision,index=index,label=label,layers=len(water),mass_residual_kg_m2=answer['mass_residual_kg_m2']))
np.savez_compressed(r/'richards_reference.npz',**data)
d=dict(scope='EHPC compute-only NumPy538R-C reference of all17 explicit native input cases at each quantized32/64 input; no GPU/reference backend runs here. Original6 transients plus dry/barrier/saturated/analytic/frozen. Not native/column acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,
    source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),reference_sha256=sha(r/'richards_reference.npz'),cases=records,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

"""Execute every original CPU node on EHPC against the NF-positive frozen source."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
root = Path('/tmp/noahmp-surface-root-cpu-ni')
out = root / 'result'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((root / 'surface-root-cpu-ni-plan.json').read_text())
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = root / plan['archive']
assert sha(archive) == plan['archive_sha256']
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert sha(source / 'SOURCE_SHA256.json') == plan['source_manifest_sha256']
verify = lambda: len(manifest) == 584 and all(sha(source / n) == h for n, h in manifest.items())
assert verify()
(out / 'SOURCE_SHA256.json').write_bytes((source / 'SOURCE_SHA256.json').read_bytes())
env = os.environ.copy()
env.update(PYTHONPATH=':'.join(map(str, [Path('/home/zhangyq/noahmp-v1/test-deps'), source, source / 'src', source / 'tests', source / 'benchmarks', root])),
           PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           CUDA_VISIBLE_DEVICES='', JAX_PLATFORMS='cpu')
env.pop('NOAHMP_REQUIRE_GPU', None)
env.pop('PYTEST_PLUGINS', None)
files = sorted(p.relative_to(source).as_posix() for p in (source / 'tests').glob('test_*.py')
               if not p.name.startswith(('test_gpu', 'test_jax', 'test_cuda')))
start = time.monotonic()
failure = None
result = {}
try:
    collected = subprocess.run([sys.executable, '-m', 'pytest', '--collect-only', '-q', *files],
                               cwd=source, env=env, capture_output=True, text=True)
    (out / 'collection.log').write_text(collected.stdout + collected.stderr)
    nodes = [n for n in collected.stdout.splitlines() if n.startswith('tests/') and '::' in n]
    assert collected.returncode == 0 and len(nodes) == len(set(nodes)) == plan['cpu_expected']
    assert set(nodes) == set(plan['original_cpu_nodes'])
    (out / 'nodes.json').write_text(json.dumps(nodes, indent=2) + '\n')
    with (out / 'pytest.log').open('x') as log:
        code = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-s', *files, '--junitxml=' + str(out / 'junit.xml')],
                              cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    counts = {k: sum(int(q.attrib[k]) for q in ET.parse(out / 'junit.xml').getroot().iter('testsuite'))
              for k in ['tests', 'failures', 'errors', 'skipped']}
    result.update(pytest_returncode=code, counts=counts, xml_sha256=sha(out / 'junit.xml'),
                  exact_original_cpu_nodes=True, collection_actual_parent_returncode=collected.returncode)
except Exception as error:
    failure = type(error).__name__ + ': ' + str(error)
    (out / 'traceback.txt').write_text(traceback.format_exc())
unchanged = verify()
passed = (failure is None and unchanged and result.get('pytest_returncode') == 0
          and result.get('counts') == dict(tests=1156, failures=0, errors=0, skipped=0))
result.update(passed=passed, failure=failure, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              source_manifest_sha256=plan['source_manifest_sha256'], source_files=584, source_unchanged=unchanged,
              seconds=time.monotonic() - start, scope=plan['scope'])
(out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if passed else 1)

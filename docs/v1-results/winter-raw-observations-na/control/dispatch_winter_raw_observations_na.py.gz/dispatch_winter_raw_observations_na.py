from pathlib import Path
import hashlib
import json
import subprocess

b = Path('/tmp/noahmp-winter-raw-observations-na')
r = b / 'result'
assert not r.exists()
r.mkdir()
n = 'inspect_winter_raw_observations_na.py'
raw = (b / n).read_bytes()
assert b'\r\n' not in raw
(r / n).write_bytes(raw)
script = '''#!/bin/bash
#PBS -N clm-winter-raw-na
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=2gb:host=compute002
#PBS -l walltime=00:10:00
#PBS -j oe
#PBS -o /tmp/noahmp-winter-raw-observations-na/pbs-output.log
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p ROOTPATH
cd ROOTPATH
/home/zhangyq/venvs/noahmp-closeout/bin/python -u /tmp/noahmp-winter-raw-observations-na/inspect_winter_raw_observations_na.py >worker.log 2>&1
code=$?
printf '%s\n' "$code" >pbs-exit.txt
exit "$code"
'''.replace('ROOTPATH', str(r))
(r / 'job.pbs').write_text(script)
q = subprocess.run(['qsub', str(r/'job.pbs')], cwd=r, capture_output=True, text=True)
assert q.returncode == 0, q.stderr
out = dict(pbs_job=q.stdout.strip(), controls_sha256={n:hashlib.sha256(raw).hexdigest(), 'job.pbs':hashlib.sha256(script.encode()).hexdigest()})
out['storage'] = 'Raw inputs, controls, result and PBS output use manager/compute002 /tmp only; original shared HOME prepared archive is read-only. PBS allocation remains required.'
(r/'dispatch.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out), flush=True)

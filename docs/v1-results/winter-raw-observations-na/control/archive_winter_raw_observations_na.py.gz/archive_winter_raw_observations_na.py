from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

b = Path('/tmp/noahmp-winter-raw-observations-na')
label = 'winter-raw-observations-na'
r = b / 'result'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
launch = json.loads((r / 'dispatch.json').read_text())
q = subprocess.check_output(['qstat', '-xf', launch['pbs_job']], text=True)
assert re.search(r'^\s*job_state = F\s*$', q, re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', q, re.M)
assert (r / 'pbs-exit.txt').read_text().strip() == '0'
d = json.loads((r / 'receipt.json').read_text())
assert d['diagnostic_delivered'] and len(d['sites']) == 3
assert d['controls_sha256']['inspect_winter_raw_observations_na.py'] == launch['controls_sha256']['inspect_winter_raw_observations_na.py']
for row in d['sites']:
    assert row['intervals'] == 1488 and row['exact_contiguous_half_hour_axis']
    for f in ['H_F_MDS', 'LE_F_MDS']:
        assert row['products'][f]['all1488_values_and_own_qc_equal_original_prepared']
assert all(sha((r / n).read_bytes()) == digest for n, digest in launch['controls_sha256'].items())
payload = {p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()}
payload['actual-qstat.txt'] = q.encode()
payload['control/' + Path(__file__).name] = Path(__file__).read_bytes()
for n in ['dispatch_winter_raw_observations_na.py', 'winter-raw-observations-na-inputs.json']:
    payload['control/' + n] = (b / n).read_bytes()
inventory = {n:dict(sha256=sha(raw), bytes=len(raw)) for n, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
a = b / (label + '-evidence.tar.gz')
assert not a.exists()
with tarfile.open(a, 'w:gz') as tf:
    for n, raw in sorted(payload.items()):
        info = tarfile.TarInfo(n); info.size = len(raw)
        tf.addfile(info, io.BytesIO(raw))
with tarfile.open(a) as tf:
    assert len(tf.getmembers()) == len(payload)
    for m in tf:
        assert tf.extractfile(m).read() == payload[m.name]
out = dict(archive=a.name, sha256=sha(a.read_bytes()), bytes=a.stat().st_size,
           artifacts=len(payload), scope=d['scope'], pbs_job=launch['pbs_job'], actual_pbs_exit=0)
(b / (label + '-package.json')).write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out), flush=True)

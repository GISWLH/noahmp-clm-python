"""Compute fixed January raw observational statistics only on an EHPC PBS node."""
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter
import csv
import hashlib
import io
import json
import math
import os
import tarfile
import time
import zipfile
import numpy as np

assert os.environ.get('PBS_JOBID') and os.uname().nodename != 'manager'
started = time.monotonic()
b = Path('/home/zhangyq/noahmp-v1')
stage = Path('/tmp/noahmp-winter-raw-observations-na')
r = stage / 'result'
tmp = Path(os.environ['TMPDIR']) / 'winter-raw-observations-na'
tmp.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
im = json.loads((stage / 'winter-raw-observations-na-inputs.json').read_text())
archive = stage / im['archive']
assert sha(archive.read_bytes()) == im['sha256']
with tarfile.open(archive) as tf:
    tf.extractall(tmp, filter='data')
protocol = json.loads((tmp / 'protocol.json').read_text())
assert sha((tmp / 'protocol.json').read_bytes()) == im['protocol_sha256']
old = b / 'multiyear-originals-fu.tar.gz'
old_sha = '6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c'
assert sha(old.read_bytes()) == old_sha
prepared = tmp / 'original-prepared'
prepared.mkdir()
with tarfile.open(old) as tf:
    selected = [m for m in tf.getmembers() if m.name in [q['site'] + ext for q in protocol['sites'] for ext in ('.npz', '.json')]]
    assert len(selected) == 6
    tf.extractall(prepared, members=selected, filter='data')
fields = ['NETRAD', 'G_F_MDS', 'H_F_MDS', 'LE_F_MDS', 'SW_IN_F', 'LW_IN_F', 'SW_OUT', 'LW_OUT']
rows = []
for setting in protocol['sites']:
    site, year = setting['site'], setting['year']
    assert sha((tmp / (site + '-original-prepared-metadata.json')).read_bytes()) == setting['original_metadata_sha256']
    raw_zip = (tmp / setting['archive']).read_bytes()
    assert sha(raw_zip) == setting['archive_sha256']
    with zipfile.ZipFile(io.BytesIO(raw_zip)) as z:
        raw = z.read(setting['member'])
    assert sha(raw) == setting['member_sha256']
    stream = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    header = stream.fieldnames
    chosen = [row for row in stream if row['TIMESTAMP_START'].startswith(str(year) + '01')]
    begin, end = datetime(year, 1, 1), datetime(year, 2, 1)
    starts = [(begin + timedelta(seconds=1800*i)).strftime('%Y%m%d%H%M') for i in range(1488)]
    ends = [(begin + timedelta(seconds=1800*(i+1))).strftime('%Y%m%d%H%M') for i in range(1488)]
    assert len(chosen) == 1488 and [q['TIMESTAMP_START'] for q in chosen] == starts
    assert [q['TIMESTAMP_END'] for q in chosen] == ends and ends[-1] == end.strftime('%Y%m%d%H%M')
    metadata = json.loads((prepared / (site + '.json')).read_text())
    assert metadata['archive_sha256'] == setting['archive_sha256'] and metadata['member_sha256'] == setting['member_sha256']
    npz = prepared / (site + '.npz')
    assert sha(npz.read_bytes()) == metadata['prepared_npz_sha256']
    with np.load(npz, allow_pickle=False) as z:
        original = dict(z)
    selected = np.flatnonzero(np.char.startswith(np.asarray(original['time_start'], str), str(year) + '01'))
    assert len(selected) == 1488
    assert list(np.asarray(original['time_start'], str)[selected]) == starts
    assert list(np.asarray(original['time_end'], str)[selected]) == ends
    def val(token):
        value = float(token)
        return value if math.isfinite(value) and value != -9999. else None
    def stats(values):
        good = [q for q in values if q is not None]
        return dict(valid_intervals=len(good), missing_intervals=len(values)-len(good),
                    valid_fraction=len(good)/len(values),
                    available_interval_mean_wm2=math.fsum(good)/len(good) if good else None,
                    full_month_mean_wm2=math.fsum(good)/1488 if len(good)==1488 else None,
                    full_month_product_available=len(good)==1488,
                    minimum_wm2=min(good) if good else None, maximum_wm2=max(good) if good else None)
    products = {}
    for field in fields:
        qc_name = field + '_QC'
        if field not in header:
            products[field] = dict(header_present=False, status='unavailable; original HH header lacks variable')
            continue
        values = [val(q[field]) for q in chosen]
        record = dict(header_present=True, units='W m-2', sign='Raw stored values, unchanged; no inversion or energy-closure inference', **stats(values))
        record['qc_header_present'] = qc_name in header
        record['qc_field'] = qc_name if qc_name in header else None
        if qc_name in header:
            qc = [val(q[qc_name]) for q in chosen]
            record['raw_qc_token_counts'] = dict(Counter(q[qc_name] for q in chosen))
            record['valid_value_counts_by_qc'] = dict(Counter(str(q) for v,q in zip(values,qc) if v is not None))
            own0 = [v for v,q in zip(values,qc) if v is not None and q==0]
            record['own_qc0_measured_intervals'] = len(own0)
            record['own_qc0_available_interval_mean_wm2'] = math.fsum(own0)/len(own0) if own0 else None
            record['own_qc0_is_not_full_month_mean'] = len(own0)!=1488
        else:
            record['qc_interpretation'] = 'HH NETRAD/SW_OUT/LW_OUT QC not provided/defined; raw availability only. Do not relabel absent QC as QC0 or manufacture a quality mask.'
        record['daily_available_intervals'] = {str(day):sum(val(q[field]) is not None for q in chosen if int(q['TIMESTAMP_START'][6:8])==day) for day in range(1,32)}
        if field in ['H_F_MDS', 'LE_F_MDS']:
            expected = np.array([np.nan if q is None else q for q in values])
            assert np.array_equal(original['obs_'+field][selected], expected, equal_nan=True)
            assert np.array_equal(original['qc_'+field][selected], np.array([np.nan if q is None else q for q in qc]), equal_nan=True)
            record['all1488_values_and_own_qc_equal_original_prepared'] = True
        products[field] = record
    record = dict(site=site, year=year, month=1, fixed_start=starts[0], fixed_end_exclusive=ends[-1],
                  timezone=protocol['timezone'], intervals=1488, exact_contiguous_half_hour_axis=True,
                  archive_sha256=setting['archive_sha256'], member=setting['member'], member_sha256=sha(raw),
                  header=header, header_line_sha256=sha(raw.splitlines(keepends=True)[0]),
                  original_prepared_npz_sha256=metadata['prepared_npz_sha256'],
                  selected_timestamp_pairs_sha256=sha(json.dumps(list(zip(starts,ends)), separators=(',',':')).encode()),
                  products=products)
    rows.append(record)
    print(json.dumps(dict(site=site, products={f:{k:v for k,v in p.items() if k in ['header_present','valid_intervals','full_month_mean_wm2','own_qc0_measured_intervals','raw_qc_token_counts']} for f,p in products.items()})), flush=True)
assert sha(archive.read_bytes()) == im['sha256'] and sha(old.read_bytes()) == old_sha
out = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, diagnostic_delivered=True,
           raw_inputs_and_original_prepared_archive_unchanged=True,
           original_prepared_archive_sha256=old_sha, raw_input_archive_sha256=im['sha256'],
           controls_sha256={Path(__file__).name:sha(Path(__file__).read_bytes())},
           protocol=protocol, sites=rows, seconds=time.monotonic()-started,
           scope=protocol['scope']+' All1488 original H/LE values and own QC per site verified against unchanged original prepared NPZ. Raw month completeness is independent of value availability. Available-sample means are never called complete-month means. No NETRAD-QC=0 claim, no energy-balance residual or new observed acceptance.')
(r / 'receipt.json').write_text(json.dumps(out, indent=2, allow_nan=False) + '\n')

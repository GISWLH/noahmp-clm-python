"""Flat closure of real PB-f failure 1628 and tests-only correction 1629."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile
import xml.etree.ElementTree as ET

assert socket.gethostname()=='manager'
sha=lambda b:hashlib.sha256(b).hexdigest()
data={};records=[];outputs=[]
for label,job,expected in [('pb-f','1628.manager',1),('pb-f2','1629.manager',0)]:
    root=Path('/tmp/noahmp-clm-drainage-backends-'+label)
    qstat=subprocess.check_output(['qstat','-xf',job]);status=qstat.decode()
    assert re.search(r'^\s*job_state = F\s*$',status,re.M)
    assert re.search(r'^\s*Stageout_status = 0\s*$',status,re.M)
    code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M).group(1));assert code==expected
    for name in ('result.tar.gz','pbs-exit.txt'):
        remote=subprocess.check_output(['ssh','compute002','sha256sum',str(root/name)]).decode().split()[0]
        if not (root/name).exists():subprocess.run(['scp','compute002:'+str(root/name),str(root/name)],check=True)
        assert sha((root/name).read_bytes())==remote
    assert int((root/'pbs-exit.txt').read_text())==code
    with tarfile.open(root/'result.tar.gz') as t:
        members={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    receipt=json.loads(members['receipt.json']);outputs.append(members)
    assert receipt['pbs_job']==job and receipt['node']=='compute002'
    assert receipt['pytest_parent_returncode']==code and int(members['worker-exit.txt'])==code
    assert receipt['passed']==(code==0) and receipt['source_and_controls_unchanged']
    assert receipt['coupled_column_runs']==receipt['GPU_tasks']==receipt['site_inputs_read']==0
    source=json.loads(members['source/SOURCE_SHA256.json']);assert len(source)==584
    assert sha(members['source/SOURCE_SHA256.json'])=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert all(sha(members['source/'+n])==h for n,h in source.items())
    for folder in ('preparation','execution'):
        controls=json.loads(members[folder+'/CONTROLS_SHA256.json'])
        assert all(sha(members[folder+'/'+n])==h for n,h in controls.items())
    cases=list(ET.fromstring(members['pytest.xml']).iter('testcase'));assert len(cases)==receipt['tests']==22
    failures=sum(c.find('failure') is not None for c in cases);errors=sum(c.find('error') is not None for c in cases)
    assert failures==receipt['failures']==(2 if code else 0) and errors==receipt['errors']==0
    diagnostics=[json.loads(line.split('PB_F_DIAGNOSTIC ',1)[1]) for line in members['pytest.stdout.txt'].decode().splitlines() if 'PB_F_DIAGNOSTIC ' in line]
    assert diagnostics==json.loads(members['diagnostics.json'])
    if not code:
        assert receipt['official_fixture_regression_passed'] and receipt['official_calls_executed']==0
        assert len(diagnostics)==10 and sum(d['test'].startswith('reference_diagnosis_') for d in diagnostics)==3
        assert b'22 passed' in members['pytest.stdout.txt']
    for n,v in members.items():
        if not n.startswith('source/'):data[label+'/'+n]=v
    for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt',
                 'compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt'):
        data[label+'/scheduler/'+name]=(root/name).read_bytes()
    data[label+'/scheduler/actual-qstat.txt']=qstat
    if (root/'pbs-output.log').exists():data[label+'/scheduler/pbs-output.log']=(root/'pbs-output.log').read_bytes()
    data[label+'/original-result-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v),included=not n.startswith('source/')) for n,v in members.items()},indent=2)+'\n').encode()
    record=dict(job=job,actual_state='F',actual_exit=code,Stageout_status=0,receipt=receipt,
        raw_archive=str(root/'result.tar.gz'),raw_archive_sha256=sha((root/'result.tar.gz').read_bytes()),
        original_members=len(members),omitted_unchanged_NM_source_members=585)
    records.append(record)
    data[label+'/closed-run.json']=(json.dumps(record,indent=2)+'\n').encode()
for name in ('drainage_primitives_pbf.py','drainage_primitives_pbf.cu','saturated_drainage_pb.py'):
    assert outputs[0]['preparation/'+name]==outputs[1]['preparation/'+name]
good=json.loads(outputs[1]['diagnostics.json']);main=[d for d in good if d['test']=='main_trial']
readout=dict(actual_jobs=[{'job':r['job'],'state':'F','exit':r['actual_exit'],'Stageout_status':0} for r in records],
    final_tests=22,final_diagnostics=10,pytest_seconds=records[1]['receipt']['pytest_seconds'],
    worker_seconds=records[1]['receipt']['seconds'],
    main_trial_max_abs_water_residual_kg_m2=max(abs(d['water_residual']) for d in main),
    main_trial_water_bound_kg_m2=max(d['water_bound'] for d in main),
    main_trial_max_abs_heat_residual_j_m2=max(abs(d['heat_residual']) for d in main),
    main_trial_heat_bound_j_m2=max(d['heat_bound'] for d in main),
    actual_diagnostics=good,source_and_thresholds_unchanged=True,
    JAX_CPU_executed=False,CUDA_compiled_or_executed=False,
    same_precision_zero_is_NumPy_self_comparison_not_device_credit=True,
    full_adaptive_device_module_tested=False,complete_hydrology_acceptance=False)
data['actual-readout.json']=(json.dumps(readout,indent=2)+'\n').encode()
data['archive_drainage_backends_pbf.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
target=Path('/tmp/noahmp-clm-drainage-backends-pb-f2/clm-drainage-backends-pb-f-evidence.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:
    for n,v in sorted(data.items()):
        m=tarfile.TarInfo(n);m.size=len(v);t.addfile(m,io.BytesIO(v))
with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    actual_jobs=readout['actual_jobs'],actual_exit=0,tests=22,diagnostic_records=10,
    coupled_column_runs=0,GPU_runs=0,JAX_CPU_tests=0,new_official_calls=0,
    scope='Actual EHPC NumPy array main-trial/diagnosis tests: 1628 F1 with two erroneous test oracles retained, 1629 F0 after tests-only fixes, 22 actual cases and 10 diagnostics. Frozen PB-c and original 1610 profiles reused; hard extensive M/H. JAX/CUDA primitives prepared but unexecuted, NumPy self-comparison zeros give no device credit. No full adaptive device/coupled-column/annual acceptance; no source/threshold/production changes.')
target.with_name('clm-drainage-backends-pb-f-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package));print(json.dumps({k:v for k,v in readout.items() if k!='actual_diagnostics'}))

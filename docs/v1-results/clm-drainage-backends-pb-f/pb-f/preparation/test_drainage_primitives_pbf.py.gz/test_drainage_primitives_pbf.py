"""Numerical tests are prepared only; no implicit GPU discovery or execution."""
import os
import socket

if os.name == 'nt':
    raise RuntimeError('PB-f numerical tests must not run on Windows')
BACKEND=os.environ.get('PB_F_BACKEND','numpy')
if BACKEND not in ('numpy','jax_cpu','jax_cuda','cuda'):
    raise RuntimeError('An explicit supported PB_F_BACKEND is required')
if BACKEND in ('numpy','jax_cpu'):
    if not os.environ.get('PBS_JOBID') or not socket.gethostname().startswith('compute002'):
        raise RuntimeError('CPU tests require isolated EHPC compute002 PBS')
else:
    # Root must bind a future exact physical CUDA1 UUID. No default or ordinal fallback.
    expected=os.environ.get('PB_F_AUTHORIZED_CUDA1_UUID')
    if not expected or not expected.startswith('GPU-') or os.environ.get('CUDA_VISIBLE_DEVICES')!=expected:
        raise RuntimeError('Future GPU run requires root-bound physical CUDA1 UUID')

from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pytest
from scipy.integrate import quad
import noahmp_clm
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
import saturated_drainage_pb as pb
import drainage_primitives_pbf as candidate

HERE=Path(__file__).resolve().parent


def soil(theta=.45,temperature=290.,**kwargs):
    dz=np.full(4,.5);p=SoilParams(**kwargs)
    water=1000*dz*np.broadcast_to(theta,(4,));t=np.broadcast_to(temperature,(4,))
    return SoilEnthalpyState(water,enthalpy_and_capacity(water,t,dz,p)[0],dz,p)


def selected(arrays):
    if BACKEND=='numpy':return candidate.run_numpy(*arrays)
    if BACKEND.startswith('jax'):
        import jax
        jax.config.update('jax_enable_x64',True)
        want='cpu' if BACKEND=='jax_cpu' else 'gpu'
        if any(d.platform!=want for d in jax.devices()):
            raise RuntimeError('JAX actual device platform differs from authorized test backend')
        return tuple(np.asarray(x) for x in candidate.run_jax(*arrays))
    import cupy as cp
    return tuple(cp.asnumpy(x) for x in candidate.run_cuda(*arrays))


def batch(state=None,p=None,duration=1800.,front=.5,bottom=2.,dtype=np.float64):
    state=soil() if state is None else state
    p=pb.DrainageParameters(2.,.2) if p is None else p
    return tuple(a[None] for a in candidate.pack(state,p,duration,front,bottom,dtype))


def budgets(t):
    assert np.all(np.isfinite(t))
    assert np.all(abs(t[:,6])<=t[:,8]) and np.all(abs(t[:,7])<=t[:,9])


def emit(name,**kw):
    print('PB_F_DIAGNOSTIC '+json.dumps(dict(test=name,backend=BACKEND,**kw),allow_nan=False),flush=True)


def test_frozen_source_and_reference_bytes():
    b=json.loads((HERE/'BINDINGS.json').read_text())
    source=Path(noahmp_clm.__file__).resolve().parents[2]
    raw=(source/'SOURCE_SHA256.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==b['source_manifest_sha256']
    inventory=json.loads(raw);assert len(inventory)==584
    for name,expected in inventory.items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==expected
    assert hashlib.sha256((HERE/'saturated_drainage_pb.py').read_bytes()).hexdigest()==b['pb_c_module_sha256']
    for n,h in b['reference_members'].items():
        assert hashlib.sha256((HERE/n).read_bytes()).hexdigest()==h


@pytest.mark.parametrize('name,theta,temp',[
    ('warm',[.45]*4,[285.,289.,293.,297.]),
    ('ice',[.4]*4,[280.,270.,270.,270.]),
    ('perched',[.2,.43,.4,.2],[280.,280.,270.,280.])])
def test_diagnostics_against_frozen_numpy_and_actual_official_reference(name,theta,temp):
    state=soil(theta,temp);p=pb.DrainageParameters(2.,.2)
    d,_=selected(batch(state,p));d=d[0];r=pb.diagnose_water_tables(state,p)
    assert abs(d[0]-r['water_table_m'])<=1e-6
    assert d[3]==(r['frost_table_m'] is not None) and d[4]==(r['perched_water_table_m'] is not None)
    for i,key in ((1,'frost_table_m'),(2,'perched_water_table_m')):
        assert abs(d[i]-(r[key] or 0.))<=1e-6
    q,coeff=pb.potential_outflow(state,r['water_table_m'],2.,'saturated',p)
    assert abs(d[7]-q)<=max(1e-12,1e-6*abs(q))
    np.testing.assert_allclose(d[13:17],coeff['impedance_layer_weights_m'],rtol=0,atol=1e-12)
    np.testing.assert_allclose(d[21:25],r['ice_pore_fraction'],rtol=1e-6,atol=1e-12)
    rows=json.loads((HERE/'reference-comparisons.json').read_text())['profiles']
    names={'warm':'unfrozen_connected','ice':'ice_contrast_connected','perched':'frost_perched_donor'}
    row=next(x for x in rows if x['name']==names[name]);official=row['official']
    assert row['official_parent_returncode']==0 and abs(d[0]-official['DIAG'][0])<=1e-6
    if name=='perched':
        assert abs(d[2]-official['DIAG'][1])<=1e-6
        expected=official['PERCHED'][0]/(1000*1e-5*math.sin(.2)*state.params.satdk*(official['DIAG'][2]-official['DIAG'][1]))
        assert abs(d[10]/expected-1)<=1e-6
    else:
        expected=official['MAIN'][0]/(.001*math.tan(.2)*(2.-official['DIAG'][0]))
        assert abs(d[9]/expected-1)<=1e-6
    emit('reference_diagnosis_'+name,values=d.tolist(),original_job='1610.manager:F0')


@pytest.mark.parametrize('front,duration',[(.5,1800.),(.5,172800.),(1.,3600.),(1.0001,3600.),(2.,3600.)])
def test_main_trial_matches_original_front_donors_and_actual_heat(front,duration):
    state=soil();p=pb.DrainageParameters(2.,.2)
    _,out=selected(batch(state,p,duration,front));t=out[0]
    after,z,r=pb._euler_transfer(state,front,2.,'saturated',duration,p)
    np.testing.assert_allclose(t[10:14],r['layer_mass_kg_m2'],rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(t[14:18],r['layer_enthalpy_j_m2'],rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(t[18:22],after.water,rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(t[22:26],after.enthalpy,rtol=1e-6,atol=1e-6)
    assert abs(t[0]-z)<=1e-6;budgets(out)
    emit('main_trial',front=front,duration=duration,layer_mass=t[10:14].tolist(),
         water_residual=t[6],water_bound=t[8],heat_residual=t[7],heat_bound=t[9])


@pytest.mark.parametrize('bexp',[1.,5.5])
def test_sy_integral_against_independent_quadrature(bexp):
    state=soil(bexp=bexp);p=pb.DrainageParameters(2.,.2)
    arrays=batch(state,p);pars=arrays[1][0]
    for lo,hi in ((0.,1e-5),(0.,2.),(.5,2.),(1.999,2.)):
        expected=quad(lambda z:max(.02,.45*(1-(1+z/.355)**(-1/bexp))),lo,hi,epsabs=1e-13,epsrel=1e-12,points=[lo,hi])[0]
        actual=candidate._integral(np.float64(lo),np.float64(hi),pars,np,lambda x:x)
        assert abs(actual-expected)<=max(2e-11,1e-8*abs(expected))


def test_dry_front_stops_in_place_without_mining_deeper_liquid():
    state=soil([.45,0.,.45,.45]);p=pb.DrainageParameters(2.,.2)
    _,t=selected(batch(state,p,86400.,.5));budgets(t)
    assert t[0,0]==.5 and t[0,2]==0 and t[0,3]>0 and t[0,5]==1
    np.testing.assert_array_equal(t[0,10:14],np.zeros(4))
    np.testing.assert_array_equal(t[0,18:22],state.water)


def test_zero_slope_and_band_exhaustion_have_explicit_distinct_ledgers():
    _,zero=selected(batch(p=pb.DrainageParameters(2.,0.)))
    assert zero[0,1]==zero[0,2]==zero[0,3]==zero[0,4]==0
    p=pb.DrainageParameters(2.,.2,baseflow_mm_s_per_m=100.)
    _,large=selected(batch(p=p,duration=86400.));budgets(large)
    assert large[0,0]==2. and large[0,4]>0 and large[0,3]==large[0,5]==0


def test_bedrock_at_existing_interface_limits_donors_but_preserves_full_ice_stencil():
    state=soil(.4,[280.,280.,280.,270.]);p=pb.DrainageParameters(1.5,.2)
    d,t=selected(batch(state,p,86400.,.5,1.5));budgets(t)
    assert d[0,6]==3 and t[0,13]==0
    # Original main empirical impedance still samples the fourth whole soil cell.
    assert np.all(d[0,13:17]==.5) and d[0,9]<1


@pytest.mark.parametrize('dtype',[np.float32,np.float64])
def test_selected_backend_same_precision_state_and_primitives_gate(dtype):
    cases=[batch(dtype=dtype),batch(soil(.4,[280.,270.,270.,270.]),dtype=dtype),
           batch(soil([.2,.43,.4,.2],[280.,280.,270.,280.]),dtype=dtype),
           batch(front=1.,duration=172800.,dtype=dtype)]
    arrays=tuple(np.concatenate([x[k] for x in cases]) for k in range(3))
    before=[x.tobytes() for x in arrays]
    reference=candidate.run_numpy(*arrays);actual=selected(arrays)
    np.testing.assert_allclose(actual[0],reference[0],rtol=1e-6,atol=1e-6)
    fields=list(range(6))+list(range(10,26))
    np.testing.assert_allclose(actual[1][:,fields],reference[1][:,fields],rtol=1e-6,atol=1e-6)
    budgets(actual[1]);assert before==[x.tobytes() for x in arrays]
    # Rounded cancellation residuals are checked against each precision's hard
    # ledger bound, not interpreted as physical output relative errors near zero.
    emit('same_precision',dtype=str(np.dtype(dtype)),maximum_diagnostic_abs=float(np.max(abs(actual[0]-reference[0]))),
         maximum_physical_output_abs=float(np.max(abs(actual[1][:,fields]-reference[1][:,fields]))))


@pytest.mark.parametrize('mutation',['nan','negative_water','phase_partition','interior_bedrock','negative_dt','unknown_shape'])
def test_invalid_inputs_fail_without_repair(mutation):
    arrays=[x.copy() for x in batch()]
    if mutation=='nan':arrays[0][0,0,3]=np.nan
    elif mutation=='negative_water':arrays[0][0,0,0]=-1
    elif mutation=='phase_partition':arrays[0][0,0,1]=100
    elif mutation=='interior_bedrock':arrays[1][0,4]=1.6
    elif mutation=='negative_dt':arrays[2][0,0]=-1
    else:arrays[0]=arrays[0][:,:3]
    with pytest.raises(ValueError):candidate.validate(*arrays,np)

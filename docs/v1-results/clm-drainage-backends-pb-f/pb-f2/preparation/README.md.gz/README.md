# PB-f: prepared device primitives, not a completed device drainage module

This directory is isolated from production. No numerical tests, CUDA compilation,
device launch, coupled column, annual run, or parameter calibration has run for
these files. Existing NQ/NS/NZ are untouched. PB-c remains the frozen NumPy
component; PB-e (1616 actual F0) is the latest independent official reference.

The prepared NumPy array adapter, JAX kernel and separate CUDA template implement:

- The four-layer main theta proxy and frost/perched diagnosis, including distinct
  main/perched first-layer conventions and explicit absent flags.
- Main whole-layer ice impedance and perched adjacent-layer impedance. Perched
  rate/diagnosis are present; perched transfer and its temporal evolution are not.
- A main connected-band frozen-rate trial with analytic Sy storage, 64 bisection
  iterations, ordered donor withdrawal, no mining beyond a depleted front,
  actual liquid sensible/fusion enthalpy, and extensive water/heat budgets.

This is a single trial, **not the adaptive time integrator**. It returns new water
and enthalpy; phase fractions and temperatures in the input describe the initial
state only. A following trial must first use the original enthalpy inversion.
No fixed-temperature reinitialization or hidden heat source is introduced. Device
phase inversion, two-half-step error controls, cumulative Kahan bookkeeping and
full adaptive driver still need to be connected and tested before claiming a
JAX/CUDA main-drainage module. No production entry point is registered.

`pack` accepts the existing `SoilEnthalpyState` and frozen PB-c parameters. Batched
cells `(N,4,6)` are liquid kg/m², ice kg/m², thickness m, temperature K, total water
kg/m², enthalpy J/m². Parameters `(N,12)` are named by `PARAMETER_FIELDS`; interval
`(N,3)` is duration s, migrating front m, bottom m. Bedrock must match an existing
interface, four cells are mandatory, and no invalid stock is repaired. A migrating
front is distinct from the theta proxy. Output diagnosis `(N,29)` contains the
13 named `DIAGNOSTIC_FIELDS`, four main weights m, four perched weights m, four
ice-pore fractions and four saturation ratios. Trial `(N,26)` contains ten named
`TRIAL_FIELDS`, four exported masses, four exported enthalpies, four final water
stocks and four final enthalpy stocks. The original standalone reservoir is not
extended; no WA, watmin virtual water, excess-water correction or ice extraction
is added. Positive floor `.02` and reserve `.01 kg/m²` remain PB-c choices.

Numerical tests must run remotely. For an isolated EHPC PBS allocation, set
`PB_F_BACKEND=numpy` or `PB_F_BACKEND=jax_cpu JAX_PLATFORMS=cpu` and run
`python -m pytest -q -s test_drainage_primitives_pbf.py`. Both source paths must be
on PYTHONPATH: this directory and the exact NM source `src`. Existing dependencies
are `/home/zhangyq/noahmp-v1/test-deps`; do not install or replace environments.
GPU variants `jax_cuda`/`cuda` are prepared only and reject a missing explicit
`PB_F_AUTHORIZED_CUDA1_UUID`; `CUDA_VISIBLE_DEVICES` must equal that same full UUID.
This guard is not authorization to run: root must schedule future tests after
checking concurrent tasks and bind physical CUDA1. No automatic device fallback.

Tests use immutable PB-c source and three existing actual 1610 official profiles,
without rerunning the official library. They compare diagnostic water levels,
dimensionless ice stencils, actual ordered donor masses/heat and stocks, plus
independent Sy quadrature, dry-front/no-mining, zero slope, finite capacity,
bedrock, invalid input, and float32/float64 cross-backend equality. Device physical
outputs retain `rtol=1e-6, atol=1e-6` same-precision gates. Roundoff cancellation
residuals are each checked with the original `64*eps*extensive_scale` hard budget,
not relative errors of near-zero residuals. Official physics gates are separate;
the present file is not another 1e-4 scientific acceptance gate.

PB-e main 256-step reference has third-layer export error −3.50491644% and total
+0.0043519148%, with all main layer exports within the original 10%/absolute
tolerances. That result belongs to the **NumPy adaptive PB-c** component, not
these unexecuted primitives. PB-e perched donor discrepancies remain −13.5442%
and +13.5096%; PB-c third-layer temperature changes 270→267.7552065 K and ice
137.2194557→129.7707030 kg/m², while the official hydrology-only steps retain
initial T/ice. Do not alter donors to fit this unmatched boundary. A subsequent
clearly labelled hydraulic-coefficient isolation or matched thermal-boundary
experiment is needed; no perched acceptance is claimed here.

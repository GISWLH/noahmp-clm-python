"""EHPC-only quantified scorer/oracle diagnostics; all predictions synthetic."""
from pathlib import Path
import json
import math
import sys

preparation, archive, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(preparation))
import numpy as np
from authority_oo import FAMILIES, ON_SHA
from oracle_oo import synthetic_cell_oracle
from reference_oo import freeze_reference
from score_math_oo import FLOORS, _cell_loss
from scorer_oo import _score_four_math

rows = []
for product in ['H_F_MDS', 'LE_F_MDS', 'NEE_VUT_REF']:
    observed = np.array([2., -3., 7., 4., 9.])
    qc = np.array([0., 0., 1., 0., np.nan])
    seconds = np.array([900., 1800., 3600., 1200., 300.])
    rate = np.array([5., -4., 8., 10., -1e6])
    predicted = rate * seconds * 12.0107e-6 if product == 'NEE_VUT_REF' else rate
    value = _cell_loss(product, observed, qc, predicted, seconds, 1.0, 3.7, 3)
    oracle = synthetic_cell_oracle(observed.tolist(), qc.tolist(), predicted.tolist(), seconds.tolist(),
                                  carbon=product == 'NEE_VUT_REF', std=3.7, floor=FLOORS[product])
    difference = abs(value['normalized_rmse'] - oracle)
    assert difference <= 1e-12
    rows.append(dict(product=product, actual_normalized_rmse=value['normalized_rmse'],
                     independent_decimal_oracle=oracle, absolute_difference=difference,
                     reference_n=value['reference_n'], true_interval_seconds=seconds.tolist()))

reference = freeze_reference(archive)
predictions = {}
for cell in reference.cells:
    predictions[(cell.site, cell.year)] = dict(time_start=cell.starts, time_end=cell.ends,
        h_wm2=np.zeros(len(cell.starts)), le_wm2=np.zeros(len(cell.starts)), nee_gc_m2=np.zeros(len(cell.starts)))
result = _score_four_math(reference, {name: predictions for name in FAMILIES})
comparison = []
one_family = result['families'][FAMILIES[0]]
for cell in one_family['cells']:
    expected = math.hypot(cell['reference_mean'], cell['reference_population_std']) / cell['denominator']
    difference = abs(expected - cell['normalized_rmse'])
    assert difference <= 1e-12
    comparison.append(dict(site=cell['site'], year=cell['year'], product=cell['product'], n=cell['reference_n'],
        frozen_reference_mean=cell['reference_mean'], frozen_reference_population_std=cell['reference_population_std'],
        floor=cell['normalization_floor'], synthetic_zero_prediction_normalized_rmse=cell['normalized_rmse'],
        independent_population_moment_identity=expected, absolute_difference=difference))
oracle_aggregate = math.fsum(row['independent_population_moment_identity'] for row in comparison) / 12
assert abs(result['loss'] - oracle_aggregate) <= 1e-12
record = dict(test_only=True, predictions='All-zero or explicitly hand-specified synthetic arrays, never physical model predictions.',
    physical_candidate_evidence=False, physical_candidate_scores=0, production_scoring_enabled=False,
    on_reference_sha256=ON_SHA, independent_decimal_checks=rows,
    maximum_decimal_oracle_absolute_difference=max(row['absolute_difference'] for row in rows),
    original_ON_twelve_cell_comparison=comparison,
    maximum_ON_population_identity_absolute_difference=max(row['absolute_difference'] for row in comparison),
    synthetic_four_family_objective=result['loss'], independent_synthetic_objective=oracle_aggregate,
    objective_absolute_difference=abs(result['loss'] - oracle_aggregate), family_weights=result['family_weights'],
    family_cell_counts={name: len(value['cells']) for name, value in result['families'].items()},
    original_months_per_family=144, coverage_caveat=result['coverage_caveat'],
    tolerance_scope='1e-12 numerical scorer/oracle consistency only; not a physical model or observational acceptance tolerance.')
output.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({key: record[key] for key in ['test_only', 'maximum_decimal_oracle_absolute_difference',
    'maximum_ON_population_identity_absolute_difference', 'objective_absolute_difference', 'physical_candidate_scores']}), flush=True)

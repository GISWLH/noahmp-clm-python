"""Read-only closed OO1599 export; no model, queue mutation or active-tree edits."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import re
import shlex
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-fluxnet-calibration-score-oo')
EXPORT = Path('/tmp/noahmp-fluxnet-calibration-score-oo-export')
assert socket.gethostname() == 'manager' and not EXPORT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dispatch = json.loads((ROOT / 'dispatch.json').read_bytes())
assert dispatch['pbs_job'] == '1599.manager'
result = subprocess.run(['qstat', '-xf', dispatch['pbs_job']], capture_output=True, text=True)
assert result.returncode == 0, result.stderr
assert re.search(r'^\s*job_state = F\s*$', result.stdout, re.M), 'Wait for actual F, not E'
actual_exit = int(re.search(r'^\s*Exit_status = (\d+)\s*$', result.stdout, re.M).group(1))
EXPORT.mkdir()
(EXPORT / 'actual-pbs-qstat.txt').write_text(result.stdout)
(EXPORT / 'actual-pbs-qstat.stderr.txt').write_text(result.stderr)
for name in ['result.tar.gz', 'pbs-exit.txt']:
    subprocess.run(['scp', 'compute002:' + str(ROOT / name), str(EXPORT / name)], check=True)
remote = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', str(ROOT / 'result.tar.gz'), str(ROOT / 'pbs-exit.txt')])],
                        capture_output=True, text=True)
assert remote.returncode == 0, remote.stderr
(EXPORT / 'compute-original-hashes.txt').write_text(remote.stdout)
remote_hashes = {line.split()[1]: line.split()[0] for line in remote.stdout.splitlines()}
assert all(remote_hashes[str(ROOT / name)] == sha((EXPORT / name).read_bytes()) for name in ['result.tar.gz', 'pbs-exit.txt'])
files = {name: (EXPORT / name).read_bytes() for name in
         ['actual-pbs-qstat.txt', 'actual-pbs-qstat.stderr.txt', 'result.tar.gz', 'pbs-exit.txt', 'compute-original-hashes.txt']}
with tarfile.open(EXPORT / 'result.tar.gz') as archive:
    for member in archive:
        assert member.isfile() or member.isdir()
        if not member.isfile():
            continue
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        name = 'result/' + str(path)
        assert name not in files
        files[name] = archive.extractfile(member).read()
for name in ['dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'compute-extract.stdout.txt',
             'compute-extract.stderr.txt', 'compute-file-hashes.txt', 'stage-inventory.json', 'independent-review.json', 'root-final-review.json',
             ]:
    files['manager/' + name] = (ROOT / name).read_bytes()
pbs_output = ROOT / 'pbs-output.log'
if pbs_output.is_file():
    files['manager/pbs-output.log'] = pbs_output.read_bytes()
files['manager/pbs-output-presence.json'] = (json.dumps(dict(
    path=str(pbs_output), present=pbs_output.is_file(),
    note='PBS wrapper redirected its worker stdout/stderr into result/controller.log. '
         'A missing optional scheduler output file is recorded as missing, not fabricated empty.'), indent=2) + '\n').encode()
worker = json.loads(files['result/receipt.json']) if 'result/receipt.json' in files else None
assert int(files['result/worker-exit.txt'].strip()) == actual_exit
assert int(files['pbs-exit.txt'].strip()) == actual_exit
assert 'result/controller.log' in files
if worker is not None:
    assert worker['pbs_job'] == '1599.manager' and worker['model_runs'] == worker['GPU_runs'] == 0
if actual_exit == 0:
    assert worker is not None and worker['passed'] is True and worker['error'] is None
    assert worker['unittest_parent_returncode'] == worker['diagnostic_parent_returncode'] == 0
    assert worker['actual_test_count'] == 28 and worker['production_scoring_enabled'] is False
    assert worker['real_original_observation_archive_read_by_integration'] is True
    assert worker['physical_candidate_scores'] == 0 and worker['reference_cells'] == 12
    for name in ['unittest.stdout.txt', 'unittest.stderr.txt', 'unittest-parent-exit.txt',
                 'diagnostic.stdout.txt', 'diagnostic.stderr.txt', 'diagnostic-parent-exit.txt',
                 'quantified-synthetic-diagnostics.json', 'unittest-command.json']:
        assert 'result/' + name in files, name
    assert files['result/unittest-parent-exit.txt'].strip() == files['result/diagnostic-parent-exit.txt'].strip() == b'0'
    diagnostic_raw = files['result/quantified-synthetic-diagnostics.json']
    diagnostic = json.loads(diagnostic_raw)
    assert sha(diagnostic_raw) == worker['quantified_diagnostics_sha256']
    assert diagnostic['test_only'] is True and diagnostic['physical_candidate_scores'] == 0
    assert diagnostic['production_scoring_enabled'] is False
    assert len(diagnostic['original_ON_twelve_cell_comparison']) == 12
    assert worker['preparation_manifest_sha256'] == '6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52'
    prep_raw = files['result/preparation/CONTROLS_SHA256.json']
    assert sha(prep_raw) == worker['preparation_manifest_sha256']
    assert all(sha(files['result/preparation/' + name]) == value for name, value in json.loads(prep_raw).items())
files['export_fluxnet_calibration_score_oo.py'] = Path(__file__).read_bytes()
inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = EXPORT / 'closed-export.tar.gz'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive}
assert restored == files
record = dict(archive_sha256=sha(target.read_bytes()), bytes=target.stat().st_size, artifacts=len(files),
              actual_job=dispatch['pbs_job'], actual_state='F', actual_exit=actual_exit,
              result_archive_sha256=sha(files['result.tar.gz']), receipt=worker, every_exported_byte_reverified=True,
              scope='Closed OO scorer tests and original ON integration with explicitly synthetic numerical diagnostics. Production scoring disabled; no model/GPU/candidate/spinup/calibration.')
(EXPORT / 'closed-export-package.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

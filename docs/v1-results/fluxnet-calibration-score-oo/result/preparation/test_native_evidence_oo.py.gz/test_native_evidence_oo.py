"""Independent synthetic native metadata/state packets; never model execution."""
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np

from authority_oo import EvidenceError, HERE, digest, load_json
from evidence_oo import (Packet, verify_configuration, verify_parent_exit, verify_native_generation,
                         verify_carry, _pbs_terminal)
from scorer_oo import score_candidate


def raw_json(value):
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


class SyntheticNativePacket:
    """Hand-built original native schema with tiny traces, labeled synthetic only.

    These toy state values test identity/structure, never conservation or model
    validity. The writer does not import the native runner or adapter helpers.
    """
    def __init__(self):
        self.raw = {}
        self.case = 'CN-Cng2007-synthetic-only'
        self.generation_tag = '0000002-' + '1' * 32
        self.state_file = 'state-' + self.generation_tag + '.npz'
        self.report_file = 'report-' + self.generation_tag + '.json'
        self.trace_file = 'trace-' + self.generation_tag + '.npz'
        self.source = {'synthetic/not-a-model.py': 'a' * 64}
        self.config = {'case': self.case, 'site': 'CN-Cng', 'synthetic_only': True}
        self.config_sha = digest(raw_json(self.config))
        self.forcing = ('b' * 64, 'c' * 64)
        self.state = {f'a{i}': np.full((1, 2), float(i), dtype=np.float32) for i in range(16)}
        self.state['a4'] = np.arange(12, dtype=np.float32).reshape(1, 12)
        self.state.update({name: np.zeros((1, 5 if name == 'tracermax' else 4))
                           for name in ['initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax']})
        self.state['index'] = np.array(2)
        self.environment = np.array([[410., 0.4, 0.6]], dtype=np.float64)
        self.write_generation('previous', None, 0)
        previous = load_json(self.raw['previous/batch.json'])
        link = dict(mode='continue', batch_report_sha256=digest(self.raw['previous/batch.json']),
                    checkpoint_sha256=previous['checkpoint_sha256'], previous_ledger_steps=2, previous_segments=1)
        self.write_generation('current', link, 2)
        current = load_json(self.raw['current/batch.json'])
        zero = copy.deepcopy(current)
        zero.update(status='running', steps_completed=0, ledger_steps=2)
        start = {name: value.copy() for name, value in self.state.items()}
        start['index'] = np.array(0)
        self.put_arrays('zero/state.npz', start)
        zero.update(checkpoint_file='state.npz', checkpoint_sha256=digest(self.raw['zero/state.npz']))
        self.raw['zero/batch.json'] = raw_json(zero)
        before = {'before' + str(i): self.state['a' + str(i)].copy() for i in range(16)}
        before['before4'][:, 7:10] = self.environment.astype(np.float32)
        self.put_arrays('first-device.npz', before)
        self.raw['parent-exit.txt'] = b'0\n'
        self.raw['SYNTHETIC_ONLY.json'] = raw_json({'test_only': True, 'physical_model_executed': False})

    def put_arrays(self, name, values):
        stream = io.BytesIO()
        np.savez(stream, **values)
        self.raw[name] = stream.getvalue()

    def get_arrays(self, name):
        with np.load(io.BytesIO(self.raw[name]), allow_pickle=False) as archive:
            return dict(archive)

    def write_generation(self, folder, link, offset):
        case = dict(case=self.case, configuration_sha256=self.config_sha,
                    forcing_npz_sha256=self.forcing[0], forcing_manifest_sha256=self.forcing[1])
        identity = dict(cases=[case], source_sha256=self.source, backend='cuda32', compare_jax32=False,
                        batch_sha256='d' * 64)
        if link is not None:
            identity['initial_run'] = link
        self.put_arrays(folder + '/' + self.state_file, self.state)
        stamps = ['200701010000', '200701010030', '200701010100', '200701010130', '200701010200']
        trace = dict(time_start=np.array(stamps[offset:offset + 2], dtype='<U12'),
                     time_end=np.array(stamps[offset + 1:offset + 3], dtype='<U12'),
                     h_wm2=np.array([1., 2.]), le_wm2=np.array([3., 4.]), nee_gc_m2=np.array([.01, -.02]),
                     step_residual_m_h_c_n=np.zeros((2, 4)), step_bound_m_h_c_n=np.zeros((2, 4)),
                     cumulative_residual_m_h_c_n=np.zeros((2, 4)))
        trace_name = folder + '/' + self.case + '/' + self.trace_file
        self.put_arrays(trace_name, trace)
        report = dict(**case, source_sha256=self.source, backend='cuda32', batch_column=0,
                      configuration=self.config, site='CN-Cng', time_convention='local standard time', utc_offset_hours=8,
                      status='complete', source_unchanged=True, steps_completed=2, steps_requested=2,
                      batch_checkpoint_file='../' + self.state_file, batch_checkpoint_sha256=digest(self.raw[folder + '/' + self.state_file]),
                      ledger_steps=offset + 2, ledger_segments=1 if link is None else 2, initial_run=link,
                      model_npz=self.trace_file, model_npz_sha256=digest(self.raw[trace_name]))
        report_name = folder + '/' + self.case + '/' + self.report_file
        self.raw[report_name] = raw_json(report)
        batch = dict(status='complete', source_unchanged=True, identity=identity, columns=1,
                     steps_completed=2, steps_requested=2, ledger_steps=offset + 2,
                     ledger_segments=1 if link is None else 2, checkpoint_file=self.state_file,
                     checkpoint_sha256=digest(self.raw[folder + '/' + self.state_file]),
                     case_reports={self.case: {'file': self.report_file, 'sha256': digest(self.raw[report_name])}})
        self.raw[folder + '/batch.json'] = raw_json(batch)

    def change_report(self, folder, edit):
        name = folder + '/' + self.case + '/' + self.report_file
        report = load_json(self.raw[name])
        edit(report)
        self.raw[name] = raw_json(report)
        batch_name = folder + '/batch.json'
        batch = load_json(self.raw[batch_name])
        batch['case_reports'][self.case]['sha256'] = digest(self.raw[name])
        self.raw[batch_name] = raw_json(batch)

    def materialize(self, root):
        for name, value in self.raw.items():
            path = Path(root) / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(value)
        (Path(root) / 'ARTIFACT_SHA256.json').write_bytes(raw_json({name: digest(raw) for name, raw in self.raw.items()}))
        return Packet(root)

    def generation(self, packet, folder):
        return verify_native_generation(packet, folder + '/batch.json', self.case, self.source,
                                        self.config_sha, self.forcing, expected_configuration=self.config)

    def check(self, root):
        packet = self.materialize(root)
        verify_parent_exit(packet.raw('parent-exit.txt'))
        previous, current = [self.generation(packet, folder) for folder in ['previous', 'current']]
        return verify_carry(packet, previous, current, 'zero/batch.json', 'zero/state.npz',
                            'first-device.npz', 'continue', self.environment)


class NativeEvidenceTests(unittest.TestCase):
    def test_independent_valid_synthetic_native_packet_and_actual_state_chain(self):
        fixture = SyntheticNativePacket()
        with tempfile.TemporaryDirectory() as root:
            result = fixture.check(root)
        self.assertEqual(result['nonindex_checkpoint_fields_checked'], 22)
        self.assertEqual(result['device_arrays_checked'], 16)

    def test_actual_parent1_is_rejected_despite_complete_reports(self):
        fixture = SyntheticNativePacket()
        fixture.raw['parent-exit.txt'] = b'1\n'
        with tempfile.TemporaryDirectory() as root, self.assertRaises(EvidenceError):
            fixture.check(root)

    def test_config_identity_cannot_be_rehashed_or_aliased(self):
        for key, value in [('configuration_sha256', 'e' * 64), ('case', 'renamed'), ('batch_column', 1)]:
            fixture = SyntheticNativePacket()
            fixture.change_report('current', lambda row: row.update({key: value}))
            with self.subTest(key=key), tempfile.TemporaryDirectory() as root, self.assertRaises(EvidenceError):
                fixture.check(root)

    def test_missing_and_nonfinite_checkpoints_rejected_after_inventory_rehash(self):
        for missing in [True, False]:
            fixture = SyntheticNativePacket()
            state = fixture.get_arrays('current/' + fixture.state_file)
            if missing:
                state.pop('a15')
            else:
                state['a15'][0, 0] = np.nan
            fixture.put_arrays('current/' + fixture.state_file, state)
            new_sha = digest(fixture.raw['current/' + fixture.state_file])
            fixture.change_report('current', lambda row: row.update(batch_checkpoint_sha256=new_sha))
            batch = load_json(fixture.raw['current/batch.json'])
            batch['checkpoint_sha256'] = new_sha
            fixture.raw['current/batch.json'] = raw_json(batch)
            with tempfile.TemporaryDirectory() as root, self.assertRaises(EvidenceError):
                fixture.check(root)

    def test_continuation_time_gap_and_wrong_parent_are_rejected(self):
        fixture = SyntheticNativePacket()
        name = 'current/' + fixture.case + '/' + fixture.trace_file
        trace = fixture.get_arrays(name)
        trace['time_start'][0] = '200701010200'
        fixture.put_arrays(name, trace)
        fixture.change_report('current', lambda row: row.update(model_npz_sha256=digest(fixture.raw[name])))
        with tempfile.TemporaryDirectory() as root, self.assertRaises(EvidenceError):
            fixture.check(root)
        fixture = SyntheticNativePacket()
        for name in ['current/batch.json', 'zero/batch.json']:
            record = load_json(fixture.raw[name])
            record['identity']['initial_run']['checkpoint_sha256'] = 'f' * 64
            fixture.raw[name] = raw_json(record)
        fixture.change_report('current', lambda row: row['initial_run'].update(checkpoint_sha256='f' * 64))
        with tempfile.TemporaryDirectory() as root, self.assertRaises(EvidenceError):
            fixture.check(root)

    def test_first_device_environment_and_nonindex_ledger_cannot_change(self):
        for name, field in [('first-device.npz', 'before4'), ('first-device.npz', 'before15'), ('zero/state.npz', 'net')]:
            fixture = SyntheticNativePacket()
            arrays = fixture.get_arrays(name)
            column = 7 if field == 'before4' else 0
            arrays[field][0, column] += 1.0
            fixture.put_arrays(name, arrays)
            if name == 'zero/state.npz':
                zero = load_json(fixture.raw['zero/batch.json'])
                zero['checkpoint_sha256'] = digest(fixture.raw[name])
                fixture.raw['zero/batch.json'] = raw_json(zero)
            with self.subTest(field=field), tempfile.TemporaryDirectory() as root, self.assertRaises(EvidenceError):
                fixture.check(root)

    def test_inventory_changed_bytes_extra_files_and_nonterminal_audit_are_rejected(self):
        fixture = SyntheticNativePacket()
        with tempfile.TemporaryDirectory() as root:
            packet = fixture.materialize(root)
            (Path(root) / 'parent-exit.txt').write_bytes(b'1\n')
            with self.assertRaises(EvidenceError):
                packet.raw('parent-exit.txt')
            with self.assertRaises(EvidenceError):
                Packet(root)
        with tempfile.TemporaryDirectory() as root:
            fixture.materialize(root)
            (Path(root) / 'unregistered-extra.json').write_bytes(b'{}')
            with self.assertRaises(EvidenceError):
                Packet(root)
        for status in ['E', 'R']:
            with self.assertRaises(EvidenceError):
                _pbs_terminal(('Job Id: 999.manager\n job_state = ' + status + '\n Exit_status = 0\n').encode(), '999.manager')
        _pbs_terminal(b'Job Id: 999.manager\n job_state = F\n Exit_status = 0\n', '999.manager')

    def test_configuration_exact_four_paths_no_state_time_reference_temperature_changes(self):
        original = (HERE / 'ORIGINAL_CONFIG.json').read_bytes()
        baseline = load_json(original)
        candidate = {'values': {'b_s': 12.0, 'mr_b': 4.5e-6, 'q10': 3.0}}
        derived = copy.deepcopy(baseline)
        derived['leaf_parameters']['ball_berry_slope'] = 12.0
        derived['biogeochemistry']['plant_parameters'].update(maintenance_base=4.5e-6, maintenance_q10=3.0)
        derived['biogeochemistry']['decomposition_parameters']['q10'] = 3.0
        self.assertEqual(verify_configuration(original, raw_json(derived), candidate), derived)
        for path, value in [(('column', 'smc'), [0.5] * 4), (('case',), 'alias'),
                            (('biogeochemistry', 'decomposition_parameters', 'reference_temperature'), 293.15)]:
            changed = copy.deepcopy(derived)
            parent = changed
            for part in path[:-1]:
                parent = parent[part]
            parent[path[-1]] = value
            with self.assertRaises(EvidenceError):
                verify_configuration(original, raw_json(changed), candidate)

    def test_production_is_disabled_not_a_positive_physics_validation_claim(self):
        for contract in [None, {'passed': True, 'spun_up': True, 'parent_exit': 0}]:
            with tempfile.TemporaryDirectory() as root:
                path = Path(root) / 'self-declared.json'
                path.write_bytes(raw_json(contract))
                result = score_candidate(None, root, path if contract else None,
                                         digest(path.read_bytes()) if contract else None)
                self.assertFalse(result['production_scoring_enabled'])
                self.assertFalse(result['candidate_valid'])
                self.assertIsNone(result['loss'])
                self.assertIn('not enabled', result['reasons'][0])


if __name__ == '__main__':
    unittest.main()

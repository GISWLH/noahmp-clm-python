"""EHPC numerical scorer tests and original ON integration; no model import/run."""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-fluxnet-calibration-score-oo')
PREPARATION_SHA = '6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52'
REVIEW_SHA = '6877e7c6b96e1eb31f8f6ba342592caa60be85da1b94e82cdb1973109b0c5391'
OBSERVATIONS = Path('/home/zhangyq/noahmp-v1/multiyear-originals-fu.tar.gz')
OBSERVATION_SHA = '6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c'
NM_SHA = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify_source(path, binding):
    assert file_sha(path) == NM_SHA == binding['model_source_archive_sha256']
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(item.isfile() for item in members) and len({item.name for item in members}) == 585
        raw = archive.extractfile('SOURCE_SHA256.json').read()
        assert sha(raw) == binding['model_source_manifest_sha256']
        identity = json.loads(raw)
        assert identity == binding['model_source_sha256'] and len(identity) == 584
        assert {item.name for item in members} == set(identity) | {'SOURCE_SHA256.json'}
        assert all(sha(archive.extractfile(name).read()) == value for name, value in identity.items())
    # Archive is inspected as bytes; its physical model modules are not imported.


def main():
    result = Path(sys.argv[1]).resolve()
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
    assert sys.version_info >= (3, 10)
    result.mkdir()
    started = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
                   python_executable=sys.executable, passed=False, error=None, model_runs=0,
                   GPU_runs=0, physical_candidate_scores=0, production_scoring_enabled=False,
                   unittest_parent_returncode=None, unittest_timed_out=False,
                   scope='Numerical scorer/oracle tests and real ON reference integration with synthetic predictions only; no physical candidate, spinup, calibration or scientific acceptance.')
    try:
        execution_raw = (STAGE / 'execution/CONTROLS_SHA256.json').read_bytes()
        execution = json.loads(execution_raw)
        assert all(sha((STAGE / 'execution' / name).read_bytes()) == value for name, value in execution.items())
        prep_raw = (STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()
        assert sha(prep_raw) == PREPARATION_SHA
        preparation = json.loads(prep_raw)
        assert len(preparation) == 22
        assert all(sha((STAGE / 'preparation' / name).read_bytes()) == value for name, value in preparation.items())
        review_raw = (STAGE / 'independent-review.json').read_bytes()
        review = json.loads(review_raw)
        assert sha(review_raw) == REVIEW_SHA and review['passed'] is True and review['blocking_findings'] == []
        assert review['manifest_sha256'] == PREPARATION_SHA and review['controls'] == 22
        work = result / 'preparation'
        work.mkdir()
        for name in [*preparation, 'CONTROLS_SHA256.json']:
            shutil.copyfile(STAGE / 'preparation' / name, work / name)
        controls = result / 'execution'
        controls.mkdir()
        for name in [*execution, 'CONTROLS_SHA256.json']:
            shutil.copyfile(STAGE / 'execution' / name, controls / name)
        shutil.copyfile(STAGE / 'independent-review.json', result / 'independent-review.json')
        binding = json.loads((work / 'SOURCE_BINDINGS.json').read_bytes())
        source = STAGE / 'inputs/climatology-final-candidate-nm-source.tar.gz'
        verify_source(source, binding)
        assert file_sha(OBSERVATIONS) == OBSERVATION_SHA
        original_copy = Path(os.environ['TMPDIR']) / 'original-on-observations.tar.gz'
        assert not original_copy.exists()
        shutil.copyfile(OBSERVATIONS, original_copy)
        assert file_sha(original_copy) == OBSERVATION_SHA
        tests = []
        for name in ['test_score_math_oo.py', 'test_native_evidence_oo.py', 'test_reference_integration_oo.py']:
            tree = ast.parse((work / name).read_bytes())
            tests.extend(name + ':' + node.name for node in ast.walk(tree)
                         if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'))
        assert len(tests) == len(set(tests)) == 28
        env = os.environ.copy()
        env.pop('PYTHONPATH', None)
        env.pop('PYTHONHOME', None)
        env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='',
                   OO_OBSERVATION_ARCHIVE=str(original_copy))
        command = [sys.executable, '-B', '-m', 'unittest', '-v', 'test_score_math_oo',
                   'test_native_evidence_oo', 'test_reference_integration_oo']
        save(result / 'unittest-command.json', dict(argv=command, cwd=str(work), tests=tests,
             original_archive_sha256=OBSERVATION_SHA, archive_path=str(original_copy),
             scope='Actual EHPC test command; no candidate physics.'))
        with (result / 'unittest.stdout.txt').open('w') as stdout, (result / 'unittest.stderr.txt').open('w') as stderr:
            process = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            receipt['actual_unittest_pid'] = process.pid
            try:
                code = process.wait(timeout=420)
            except subprocess.TimeoutExpired:
                receipt['unittest_timed_out'] = True
                process.kill()
                code = process.wait()
        receipt['unittest_parent_returncode'] = code
        (result / 'unittest-parent-exit.txt').write_text(str(code) + '\n')
        error_output = (result / 'unittest.stderr.txt').read_text()
        assert code == 0 and not receipt['unittest_timed_out'], error_output
        count = re.search(r'^Ran (\d+) tests in ([0-9.]+)s$', error_output, re.M)
        assert count and int(count.group(1)) == 28 and re.search(r'^OK$', error_output, re.M)
        assert 'skipped=' not in error_output and 'skipped ' not in error_output
        receipt['actual_test_count'] = int(count.group(1))
        receipt['actual_test_seconds'] = float(count.group(2))
        receipt['test_names'] = tests
        diagnostic_command = [sys.executable, '-B', str(STAGE / 'execution/diagnostics_oo.py'),
                              str(work), str(original_copy), str(result / 'quantified-synthetic-diagnostics.json')]
        with (result / 'diagnostic.stdout.txt').open('w') as stdout, (result / 'diagnostic.stderr.txt').open('w') as stderr:
            process = subprocess.Popen(diagnostic_command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            receipt['actual_diagnostic_pid'] = process.pid
            try:
                diagnostic_code = process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                receipt['diagnostic_timed_out'] = True
                process.kill()
                diagnostic_code = process.wait()
        receipt['diagnostic_parent_returncode'] = diagnostic_code
        (result / 'diagnostic-parent-exit.txt').write_text(str(diagnostic_code) + '\n')
        assert diagnostic_code == 0 and not receipt.get('diagnostic_timed_out', False)
        diagnostic = json.loads((result / 'quantified-synthetic-diagnostics.json').read_bytes())
        assert diagnostic['test_only'] is True and diagnostic['physical_candidate_scores'] == 0
        receipt['quantified_diagnostics_sha256'] = file_sha(result / 'quantified-synthetic-diagnostics.json')
        receipt['maximum_decimal_oracle_absolute_difference'] = diagnostic['maximum_decimal_oracle_absolute_difference']
        receipt['maximum_ON_population_identity_absolute_difference'] = diagnostic['maximum_ON_population_identity_absolute_difference']
        receipt['synthetic_objective_absolute_difference'] = diagnostic['objective_absolute_difference']
        assert all(sha((work / name).read_bytes()) == value for name, value in preparation.items())
        assert all(sha((STAGE / 'preparation' / name).read_bytes()) == value for name, value in preparation.items())
        assert all(sha((STAGE / 'execution' / name).read_bytes()) == value for name, value in execution.items())
        verify_source(source, binding)
        assert file_sha(OBSERVATIONS) == file_sha(original_copy) == OBSERVATION_SHA
        receipt.update(passed=True, preparation_manifest_sha256=PREPARATION_SHA,
                       execution_manifest_sha256=sha(execution_raw), independent_review_sha256=REVIEW_SHA,
                       source_files_verified_before_after=584, original_archive_sha256=OBSERVATION_SHA,
                       original_archive_bytes=OBSERVATIONS.stat().st_size,
                       original_ON_reference_sha256=binding['on_reference_sha256'],
                       original_OM_plan_sha256=binding['candidate_plan_sha256'],
                       real_original_observation_archive_read_by_integration=True,
                       reference_cells=12, original_reference_months=144, family_weights=[0.25] * 4,
                       actual_candidate_scores_produced=False, production_entry_disabled_verified=True,
                       native_adapter_scope='Independent synthetic packets only, including positive 23 checkpoint / 22 nonindex / 16 device carry parsing. No physical chain or audit delivered.',
                       preparation_source_and_originals_unchanged=True)
    except BaseException as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        (result / 'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic() - started
    save(result / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

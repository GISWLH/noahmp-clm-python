# OO scorer validation — actual EHPC tests, no physical calibration

Job **1599.manager** ran on **compute002** with 1 CPU, 2 GB and a 10-minute limit. Actual terminal state is **F / Exit_status 0**. All **28 tests** passed in **25.883 s**; the full worker, including separate quantified diagnostics, took **38.931536310119554 s**. The unittest and diagnostic parent processes each returned 0. PBS reported 39 seconds wall time and 76,040 KB memory.

These tests validate the fixed training objective, its immutable original ON reference reader, and an independently constructed synthetic native evidence parser. They did not run the physical model, use a GPU, spin up a candidate, calibrate parameters or produce any real candidate score. Production scoring remains explicitly disabled until its initialization, own-parameter spinup, total budget and complete real delivery implementation are separately frozen.

Measured numerical checks:

| Check | Maximum absolute difference |
| --- | ---: |
| Synthetic H/LE/NEE normalized RMSE versus independent Decimal oracle | 0 |
| All 12 original ON cells with zero synthetic predictions versus independent population-moment identity | 2.220446049250313e-16 |
| Four-family synthetic objective versus independent aggregate | 0 |

The 1e-12 consistency assertion in these checks applies to scorer arithmetic, not model accuracy or scientific acceptance. The saved diagnostic JSON identifies every prediction as synthetic. Its zero-prediction objective is not a model performance score.

The reader actually opened the original 39,964,262-byte observation archive with SHA256 `6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c`. Only Cng/Qia's original 35,088-row training prefixes were decoded. All twelve cells and all 144 original monthly coverage records were retained. Cng2007 January–April has no QC0 support for H, LE or NEE; the annual objective does not represent those seasons. QC0 does not establish independent observations. Held-out observations were not decoded for fitting.

The objective fixes four equally weighted families (1/4 each), each containing twelve equally weighted site-year-product cells. Missing or invalid cells/families cannot be dropped or renormalized. Model NEE conversion uses actual interval seconds and 12.0107e-6, positive toward the atmosphere. The original scientific daily/monthly, correlation, absolute-nearzero, GPP-OR and hard-budget evaluations remain separate.

The native parser tests include an independently constructed positive 23-field checkpoint packet, its exact 22 non-index and 16 first-device carry checks, plus parent/configuration/time/checkpoint/state corruptions. These toy states are synthetic and provide no conservation or SOC evidence. The empty production registry rejection is separately tested and is not a successful physical state-chain validation.

The final preparation has 22 controls plus its manifest, SHA256 `6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52`. Independent colleague and root reviews both apply to these exact bytes. The earlier `45520941...` preparation and its reviews remain preserved separately, with byte-restoration provenance; they are not relabeled as reviews of the revised files. Both original NM584 source and preparation bytes were checked before and after EHPC execution. The physical model source was not imported by the tests.

The closed evidence includes full test/controller/diagnostic logs, actual parent exits, receipt, immutable source stage, all controls and reviews, raw qstat terminal evidence and an exhaustive artifact inventory. Optional `pbs-output.log` presence is recorded as observed; a missing scheduler log is not fabricated as empty. Required controller/test logs are retained even when they have zero bytes.

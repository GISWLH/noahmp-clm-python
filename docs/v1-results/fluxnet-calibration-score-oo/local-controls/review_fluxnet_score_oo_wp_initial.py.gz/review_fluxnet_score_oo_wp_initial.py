"""OO independent frozen preparation review: stdlib AST/hash/JSON/tar only."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parent
HERE = ROOT / 'fluxnet-calibration-score-oo-preparation'
EXPECTED = '45520941de480ef215eb5594c2c28f1e30c9b07c8b70dff4b831ce987fa2e57f'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def archive(path, expected):
    assert sha(path.read_bytes()) == expected
    with tarfile.open(path) as data:
        members = [m for m in data.getmembers() if m.isfile()]
        assert len({m.name for m in members}) == len(members)
        return {m.name: data.extractfile(m).read() for m in members}


def main():
    raw_manifest = (HERE / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(raw_manifest) == EXPECTED
    index = json.loads(raw_manifest)
    assert len(index) == 22
    assert {p.name for p in HERE.iterdir() if p.is_file()} == set(index) | {'CONTROLS_SHA256.json'}
    files = {name: (HERE / name).read_bytes() for name in index}
    assert all(sha(files[name]) == value for name, value in index.items())
    trees = {name: ast.parse(raw, filename=name) for name, raw in files.items() if name.endswith('.py')}
    tests = {name: [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
             for name, tree in trees.items() if name.startswith('test_')}
    assert {name: len(values) for name, values in tests.items()} == {
        'test_score_math_oo.py': 12, 'test_native_evidence_oo.py': 9, 'test_reference_integration_oo.py': 7}
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom)) and
                   ('noahmp_clm' in getattr(n, 'module', '') if getattr(n, 'module', None) else
                    any(a.name.startswith('noahmp_clm') for a in getattr(n, 'names', [])))
                   for tree in trees.values() for n in ast.walk(tree))
    source = json.loads(files['SOURCE_BINDINGS.json'])
    nm = archive(ROOT / 'climatology-final-candidate-nm-source.tar.gz', source['model_source_archive_sha256'])
    assert sha(nm['SOURCE_SHA256.json']) == source['model_source_manifest_sha256']
    model_index = json.loads(nm['SOURCE_SHA256.json'])
    assert len(model_index) == 584 and model_index == source['model_source_sha256']
    assert set(nm) == set(model_index) | {'SOURCE_SHA256.json'}
    assert all(sha(nm[name]) == value for name, value in model_index.items())
    dependencies = source['original_native_dependency_sha256']
    assert len(dependencies) == 202 and all(model_index[name] == value for name, value in dependencies.items())
    native = nm['benchmarks/run_fluxnet_native.py'].decode()
    assert 'site[:, 7:10] = self.xp.asarray(environment, site.dtype)' in native
    assert "for key in ('case', 'configuration_sha256')" in native
    assert "'step_residual_m_h_c_n', 'step_bound_m_h_c_n', 'cumulative_residual_m_h_c_n'" in native
    om = archive(ROOT / 'fluxnet-calibration-om-evidence.tar.gz', source['om_executed_metadata_archive_sha256'])
    assert files['OM_PLAN.json'] == om['result/candidate-plan.json']
    on = archive(ROOT / 'fluxnet-training-reference-on-public-evidence.tar.gz', source['on_executed_reference_archive_sha256'])
    assert files['ON_RECEIPT.json'] == on['result/receipt.json']
    assert files['ON_QSTAT_FINAL.txt'] == on['actual-qstat.txt']
    assert files['ON_REFERENCE.json'] == (ROOT / 'fluxnet-training-reference-on.json').read_bytes()
    assert sha(files['ON_REFERENCE.json']) == source['on_reference_sha256']
    assert sha(files['ORIGINAL_GIT_PROOF.tar.gz']) == source['original_git_proof_sha256']
    assert sha(files['ORIGINAL_CONFIG.json']) == source['original_config_sha256']
    om_source = json.loads((ROOT / 'fluxnet-calibration-om-preparation/SOURCE_BINDINGS.json').read_bytes())
    assert source['original_om_config_registry'] == om_source['allowed_original_configurations']
    assert len(source['original_om_config_registry']) == 12
    objective = json.loads(files['OBJECTIVE.json'])
    assert set(objective['family_weights'].values()) == {0.25} and len(objective['family_weights']) == 4
    assert objective['nee_conversion'] == 'nee_gc_m2 / (actual interval seconds * 12.0107e-6)'
    assert objective['nee_positive'] == 'toward atmosphere'
    registry = json.loads(files['RUN_CONTRACT_REGISTRY.json'])
    assert registry['contracts'] == {}
    scorer = trees['scorer_oo.py']
    production = next(n for n in scorer.body if isinstance(n, ast.FunctionDef) and n.name == 'score_candidate')
    returns = [n for n in ast.walk(production) if isinstance(n, ast.Return)]
    assert len(returns) == 1 and isinstance(returns[0].value, ast.Name) and returns[0].value.id == 'invalid'
    integration = files['test_reference_integration_oo.py'].decode()
    assert 'OO_OBSERVATION_ARCHIVE' in integration and 'raise RuntimeError' in integration
    assert 'SkipTest' not in integration and '@unittest.skip' not in integration
    reference = files['reference_oo.py'].decode()
    assert "for site in ['CN-Cng', 'CN-Qia']" in reference
    assert 'spec[\'container_steps\'], 35088' in reference
    assert "mask = np.isfinite(self.observed) & (self.qc == 0)" in reference
    assert all(sha((HERE / name).read_bytes()) == value for name, value in index.items())
    report = dict(passed=True, blocking_findings=[], controls=22, total_preparation_files=23,
        manifest_sha256=EXPECTED, source_files_verified=584, native_dependency_files=202, original_configuration_registry=12,
        test_methods={name: len(values) for name, values in tests.items()}, synthetic_or_integration_tests_executed=False,
        model_steps=0, PBS_submitted=False, actual_candidate_score_produced=False,
        static_manual_checks=[
            'All12 ON cells/144month records, fixed ownQC0 masks and population scales; only two35088-row training prefixes decoded at runtime.',
            'NEE uses actualdt*12.0107e-6, positive atmosphere; no86400 or sign flip; model full-year finite validation precedes observation masking.',
            'Exactly12 equal cell weights and all4 family weights1/4; missing/invalid cell/family gives no partial loss.',
            'Native immutable batch/report/trace/checkpoint/source/config/forcing identity matches frozen native schema;23 checkpoint fields and22 nonindex/16 first-device carry checks retained.',
            'Only site array slots7:10 change for prescribed first forcing environment; candidate original config identity is not renamed.',
            'Independent Decimal synthetic math oracle and hand-built positive native packet; parent1/config/time/checkpoint/carry negative paths present.',
            'Seven ON integration tests require actual original observation archive and do not skip missing data; zero-prediction moment identity is independent of numeric scorer.',
            'Production score always invalid/null and registry empty. Actual barrier/hard-budget/source/whole-candidate physical delivery integration is explicitly not implemented or validated.'
        ],
        nonblocking_findings=[
            'README currently describes both private family/four helpers as returning test_only/physical_candidate_evidence; only four-family output contains these flags. No production path is enabled.',
            'Some negative test names mention statistic/count tampering or extra files without those exact mutations in their bodies. Corresponding implementation checks exist; current tests cover other mutations. Optional name/coverage tightening.'
        ],
        scope='Independent frozen preparation review using only stdlib AST/hash/archive/JSON and manual source inspection; no NumPy import or local numerical execution. Runtime28tests and real physical delivery remain untested.')
    (ROOT / 'fluxnet-calibration-score-oo-independent-review-wp.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()

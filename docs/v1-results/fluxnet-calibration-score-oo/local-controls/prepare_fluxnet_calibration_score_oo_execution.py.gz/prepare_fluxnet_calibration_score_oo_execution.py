"""Freeze reviewed OO execution controls and stage, without deploying/submitting."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'fluxnet-calibration-score-oo-preparation'
EXEC = OUT / 'fluxnet-calibration-score-oo-execution'
EXPECTED = '6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
assert sha(manifest_raw) == EXPECTED
prep = json.loads(manifest_raw)
assert len(prep) == 22 and all(sha((PREP / name).read_bytes()) == value for name, value in prep.items())
review_raw = (OUT / 'fluxnet-calibration-score-oo-independent-review-wp.json').read_bytes()
assert sha(review_raw) == '6877e7c6b96e1eb31f8f6ba342592caa60be85da1b94e82cdb1973109b0c5391'
review = json.loads(review_raw)
assert review['passed'] is True and review['blocking_findings'] == [] and review['manifest_sha256'] == EXPECTED
root_review_raw = (OUT / 'fluxnet-calibration-score-oo-root-final-review.json').read_bytes()
root_review = json.loads(root_review_raw)
assert root_review['passed'] is True and root_review['blocking_findings'] == [] and root_review['manifest_sha256'] == EXPECTED
controls = {name: sha((EXEC / name).read_bytes()) for name in
            ['run_tests_oo.py', 'diagnostics_oo.py', 'tests_oo.pbs', 'dispatch_tests_oo.py']}
controls_raw = (json.dumps(controls, indent=2) + '\n').encode()
(EXEC / 'CONTROLS_SHA256.json').write_bytes(controls_raw)
for name in controls:
    if name.endswith('.py'):
        ast.parse((EXEC / name).read_bytes())
lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(EXEC), str(Path(__file__))],
                      capture_output=True, text=True)
assert lint.returncode == 0, lint.stdout + lint.stderr
files = {'preparation/' + name: (PREP / name).read_bytes() for name in prep}
files['preparation/CONTROLS_SHA256.json'] = manifest_raw
files.update({'execution/' + name: (EXEC / name).read_bytes() for name in controls})
files['execution/CONTROLS_SHA256.json'] = controls_raw
files['independent-review.json'] = review_raw
files['root-final-review.json'] = root_review_raw
source_name = 'climatology-final-candidate-nm-source.tar.gz'
source_raw = (OUT / source_name).read_bytes()
assert sha(source_raw) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
files['inputs/' + source_name] = source_raw
index = {name: sha(raw) for name, raw in files.items()}
files['stage-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
target = OUT / 'fluxnet-calibration-score-oo-stage.tar.gz'
assert not target.exists(), 'Do not replace a frozen stage; preserve actual failed attempts'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(target) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive}
assert restored == files
record = dict(stage_archive=target.name, stage_archive_sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
              artifacts=len(files), preparation_manifest_sha256=EXPECTED, execution_manifest_sha256=sha(controls_raw),
              review_sha256=sha(review_raw), root_review_sha256=sha(root_review_raw), stage_inventory=index,
              actual_ruff_returncode=lint.returncode, AST_parsed=True, numerical_tests_executed=False,
              deployed=False, PBS_submitted=False, resource_request='1CPU/2GB/10min/compute002',
              original_observation_archive='/home/zhangyq/noahmp-v1/multiyear-originals-fu.tar.gz',
              original_observation_archive_sha256='6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c',
              original_observation_copy='Read-only original copied into actual PBS TMPDIR, hashes before/after.',
              python='/home/zhangyq/venvs/noahmp-closeout/bin/python',
              scope='Prepared 28 numerical/oracle/synthetic native tests plus true original ON integration and quantified synthetic diagnostics. No model, GPU, physical candidate, spinup or calibration; production entry disabled.',
              required_result_files=['controller.log', 'unittest.stdout.txt', 'unittest.stderr.txt', 'unittest-parent-exit.txt',
                  'diagnostic.stdout.txt', 'diagnostic.stderr.txt', 'diagnostic-parent-exit.txt',
                  'quantified-synthetic-diagnostics.json', 'receipt.json', 'worker-exit.txt'],
              optional_scheduler_log='pbs-output.log may not exist when the PBS wrapper redirects all output; record actual presence without inventing an empty log.')
(OUT / 'fluxnet-calibration-score-oo-execution-preparation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['stage_archive', 'stage_archive_sha256', 'bytes', 'artifacts',
    'preparation_manifest_sha256', 'execution_manifest_sha256', 'actual_ruff_returncode', 'deployed', 'PBS_submitted']}, indent=2))

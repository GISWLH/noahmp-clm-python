"""Root's independent static review of frozen OO; no numerical imports/runs."""
from pathlib import Path
import ast
import hashlib
import json

root = Path(__file__).resolve().parent
folder = root / 'fluxnet-calibration-score-oo-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
manifest_raw = (folder / 'CONTROLS_SHA256.json').read_bytes()
assert sha(manifest_raw) == '6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52'
manifest = json.loads(manifest_raw)
assert len(manifest) == 22
assert {path.name for path in folder.iterdir()} == set(manifest) | {'CONTROLS_SHA256.json'}
assert all(sha((folder / name).read_bytes()) == digest for name, digest in manifest.items())
counts = {}
for name in manifest:
    if name.endswith('.py'):
        tree = ast.parse((folder / name).read_bytes())
        imports = [node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        assert not any(name and name.startswith('noahmp_clm') for name in imports)
        count = sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_') for node in ast.walk(tree))
        if count:
            counts[name] = count
assert counts == {'test_score_math_oo.py': 12, 'test_native_evidence_oo.py': 9,
                  'test_reference_integration_oo.py': 7}
objective = json.loads((folder / 'OBJECTIVE.json').read_bytes())
assert objective['family_weights'] == {name: 0.25 for name in
    ('wilting-hydraulic', 'wilting-legacy', 'field-capacity-hydraulic', 'field-capacity-legacy')}
assert objective['training_site_years'] == [['CN-Cng', 2007], ['CN-Cng', 2008], ['CN-Qia', 2003], ['CN-Qia', 2004]]
assert objective['products'] == ['H_F_MDS', 'LE_F_MDS', 'NEE_VUT_REF']
assert json.loads((folder / 'RUN_CONTRACT_REGISTRY.json').read_bytes())['contracts'] == {}
result = dict(passed=True, blocking_findings=[], controls=22, manifest_sha256=sha(manifest_raw),
              objective_sha256=sha((folder / 'OBJECTIVE.json').read_bytes()),
              tests_prepared=counts, tests_executed=False, numerical_execution=False,
              model_source_changed=False, production_scoring_enabled=False,
              review_mode='Independent root source/AST/hash review, no NumPy import or tests locally.',
              manual_review=[
                  'Fixed own-QC0 finite-observation masks and original ON population scales; no prediction-dependent selection.',
                  'Full model year finite before masking; exact local-standard calendar including leap years.',
                  'NEE grams C per interval converted with actual seconds and 12.0107e-6, positive to atmosphere.',
                  'All twelve cells per family, all four families weighted equally; no missing-cell or family renormalization.',
                  'Independent Decimal unit/weight oracle and actual-ON zero-prediction population-moment identity.',
                  'Synthetic native positive and corrupted packet tests are separate from disabled production scoring.',
                  'Immutable native generation/report/checkpoint cross-links and full 22/16 carry identity checks inspected.',
                  'Observed-data coverage caveats and original scientific acceptance remain separate.',
              ],
              next_action='Isolated EHPC28 tests and original-ON integration, after independent colleague review; no physical candidate or GPU run.')
output = root / 'fluxnet-calibration-score-oo-root-final-review.json'
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))

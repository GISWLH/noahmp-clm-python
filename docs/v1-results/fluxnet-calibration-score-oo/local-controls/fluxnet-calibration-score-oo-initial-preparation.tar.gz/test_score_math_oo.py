"""Synthetic numerical tests for EHPC only; no physical model or real candidate."""
import copy
import unittest
import numpy as np

from authority_oo import FAMILIES
from oracle_oo import synthetic_cell_oracle, synthetic_equal_twelve_oracle, synthetic_four_family_oracle
from score_math_oo import PRODUCTS, YEARS, InvalidScore, _cell_loss, _equal_cell_loss, _equal_family_loss


def cell(product='H_F_MDS', obs=None, qc=None, pred=None, seconds=None, std=2.0, mean=0.0):
    obs = [1.0, -1.0, 2.0, -2.0] if obs is None else obs
    qc = [0.0] * len(obs) if qc is None else qc
    pred = obs if pred is None else pred
    seconds = [1800.0] * len(obs) if seconds is None else seconds
    n = sum(np.isfinite(v) and q == 0 for v, q in zip(obs, qc))
    return _cell_loss(product, np.array(obs, dtype=float), np.array(qc, dtype=float),
                      np.array(pred, dtype=float), np.array(seconds, dtype=float), mean, std, int(n))


def twelve():
    return [dict(site=site, year=year, product=product, normalized_rmse=float(index + 1), reference_n=(index + 1) * 100)
            for index, (site, year, product) in enumerate((s, y, p) for s, y in YEARS for p in PRODUCTS)]


class LossMathematicsTests(unittest.TestCase):
    def test_perfect_prediction_and_independent_decimal_oracle(self):
        for product in ['H_F_MDS', 'LE_F_MDS']:
            self.assertEqual(cell(product)['rmse'], 0.0)
            obs, pred, qc, dt = [2., -3., 7., 4.], [5., -4., 8., 10.], [0., 0., 1., 0.], [900., 1800., 3600., 1200.]
            actual = cell(product, obs, qc, pred, dt, std=3.7)['normalized_rmse']
            oracle = synthetic_cell_oracle(obs, qc, pred, dt, carbon=False, std=3.7, floor=1.0)
            self.assertAlmostEqual(actual, oracle, places=14)

    def test_nee_true_interval_seconds_carbon_mass_and_positive_atmosphere(self):
        obs = [-2., 1., 3., -4.]
        dt = [300., 900., 1800., 3600.]
        grams = [rate * seconds * 0.0000120107 for rate, seconds in zip(obs, dt)]
        actual = cell('NEE_VUT_REF', obs=obs, pred=grams, seconds=dt, std=0.5)
        self.assertLess(actual['normalized_rmse'], 1e-14)
        reversed_sign = cell('NEE_VUT_REF', obs=obs, pred=[-x for x in grams], seconds=dt, std=0.5)
        self.assertGreater(reversed_sign['normalized_rmse'], 1.0)
        oracle = synthetic_cell_oracle(obs, [0.] * 4, [-x for x in grams], dt, carbon=True, std=0.5, floor=0.1)
        self.assertAlmostEqual(reversed_sign['normalized_rmse'], oracle, places=13)
        wrong_units = cell('NEE_VUT_REF', obs=obs, pred=obs, seconds=dt, std=0.5)
        self.assertGreater(wrong_units['normalized_rmse'], 1.0)

    def test_nearzero_mean_and_std_floor_are_absolute_scales_not_relative_bias(self):
        heat = cell(obs=[0., 0.], pred=[1., -1.], std=0., mean=0.)
        self.assertEqual(heat['denominator'], 1.0)
        self.assertEqual(heat['normalized_rmse'], 1.0)
        carbon = cell('NEE_VUT_REF', obs=[0., 0.], pred=[0.1 * 1800 * 0.0000120107] * 2, std=0.)
        self.assertEqual(carbon['denominator'], 0.1)
        self.assertAlmostEqual(carbon['normalized_rmse'], 1.0, places=14)
        altered_mean = cell(obs=[0., 0.], pred=[1., -1.], std=0., mean=1000000.)
        self.assertEqual(altered_mean['normalized_rmse'], heat['normalized_rmse'])

    def test_observation_own_qc_mask_and_missing_reference_are_prediction_independent(self):
        obs, qc, pred = [1., 3., 100., float('nan'), 12.], [0., 0., 2., 0., float('nan')], [2., 4., -1e6, 9., -2e6]
        actual = cell(obs=obs, qc=qc, pred=pred, std=2.)
        self.assertEqual(actual['reference_n'], 2)
        self.assertEqual(actual['normalized_rmse'], 0.5)
        pred[2], pred[3], pred[4] = 8., 7., 6.
        self.assertEqual(cell(obs=obs, qc=qc, pred=pred, std=2.)['normalized_rmse'], 0.5)

    def test_invalid_model_outside_selected_mask_invalidates_whole_cell(self):
        for value in [float('nan'), float('inf'), -float('inf')]:
            with self.subTest(value=value), self.assertRaises(InvalidScore):
                cell(obs=[1., 3., 9.], qc=[0., 0., 3.], pred=[1., 3., value])
            with self.subTest(missing_observation=value), self.assertRaises(InvalidScore):
                cell(obs=[1., 3., float('nan')], pred=[1., 3., value])

    def test_minimum_count_invalid_std_and_intervals_are_not_silently_repaired(self):
        for obs, qc in [([1., 3.], [0., 2.]), ([1., 3.], [1., 2.])]:
            with self.assertRaises(InvalidScore):
                cell(obs=obs, qc=qc)
        for std in [float('nan'), float('inf'), -0.1, True]:
            with self.subTest(std=std), self.assertRaises(InvalidScore):
                cell(std=std)
        for interval in [0., -1., float('nan'), float('inf')]:
            with self.subTest(dt=interval), self.assertRaises(InvalidScore):
                cell(seconds=[1800., 1800., interval, 1800.])

    def test_bool_object_integer_2d_and_wrong_length_predictions_are_rejected(self):
        for pred in [np.array([True, False]), np.array([1., 2.], dtype=object), np.array([1, 2]),
                     np.array([[1., 2.]]), np.array([1.]), [1., 2.],
                     np.ma.array([1., np.nan], mask=[False, True]), np.ma.array([1., 2.], mask=False)]:
            with self.subTest(dtype=getattr(pred, 'dtype', None)), self.assertRaises(InvalidScore):
                _cell_loss('H_F_MDS', np.array([1., 2.]), np.zeros(2), pred, np.full(2, 1800.), 1.5, 0.5, 2)

    def test_equal_twelve_cells_not_weighted_by_observation_sample_count(self):
        rows = twelve()
        self.assertEqual(_equal_cell_loss(rows), 6.5)
        self.assertEqual(_equal_cell_loss(rows), synthetic_equal_twelve_oracle(list(range(1, 13))))
        rows[0]['reference_n'] = 999999999
        self.assertEqual(_equal_cell_loss(rows[::-1]), 6.5)

    def test_missing_year_product_duplicate_and_holdout_never_get_partial_loss(self):
        with self.assertRaises(InvalidScore):
            _equal_cell_loss(twelve()[:-1])
        for mutation in [('year', 2009), ('year', 2007.0), ('year', True), ('site', 'CN-HaM'), ('product', 'GPP_NT_VUT_REF')]:
            rows = twelve()
            rows[0][mutation[0]] = mutation[1]
            with self.subTest(mutation=mutation), self.assertRaises(InvalidScore):
                _equal_cell_loss(rows)
        rows = twelve()
        rows[1] = copy.deepcopy(rows[0])
        with self.assertRaises(InvalidScore):
            _equal_cell_loss(rows)

    def test_overflow_and_nonfinite_aggregate_do_not_become_good_scores(self):
        with self.assertRaises(InvalidScore):
            cell(obs=[-1e308, -1e308], pred=[1e308, 1e308])
        for value in [float('nan'), float('inf'), -1., True]:
            rows = twelve()
            rows[0]['normalized_rmse'] = value
            with self.subTest(value=value), self.assertRaises(InvalidScore):
                _equal_cell_loss(rows)


class FamilyAggregationTests(unittest.TestCase):
    def test_four_families_equal_weight_no_best_selection_or_count_weight(self):
        families, oracle = {}, []
        for factor, name in enumerate(FAMILIES, 1):
            rows = twelve()
            for row in rows:
                row['normalized_rmse'] *= factor
                row['reference_n'] *= factor ** 4
            families[name] = dict(cells=rows, loss=_equal_cell_loss(rows))
            oracle.append([row['normalized_rmse'] for row in rows])
        self.assertEqual(_equal_family_loss(families), 16.25)
        self.assertEqual(_equal_family_loss(families), synthetic_four_family_oracle(oracle))
        self.assertNotEqual(_equal_family_loss(families), min(row['loss'] for row in families.values()))

    def test_missing_invalid_aliased_family_and_false_recorded_loss_are_rejected(self):
        base = {name: dict(cells=twelve(), loss=_equal_cell_loss(twelve())) for name in FAMILIES}
        missing = copy.deepcopy(base)
        del missing[FAMILIES[-1]]
        alias = copy.deepcopy(base)
        alias['best-family'] = alias.pop(FAMILIES[-1])
        incomplete = copy.deepcopy(base)
        incomplete[FAMILIES[0]]['cells'].pop()
        false_loss = copy.deepcopy(base)
        false_loss[FAMILIES[0]]['loss'] = 0.0
        for item in [missing, alias, incomplete, false_loss]:
            with self.assertRaises(InvalidScore):
                _equal_family_loss(item)


if __name__ == '__main__':
    unittest.main()

"""Immutable OO authority and strict JSON/hash helpers; no model imports."""
import hashlib
import json
import math
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
ON_SHA = '2e113b7bc76fb294c3cc0ee29c701a15755ac6b0ddb44295e800b0b0e965d4be'
OM_PLAN_SHA = 'fc2b5866e9368dc80ec9ca6e9dfe1e91dbac139908db79abc11bc4d70180f8c3'
SOURCE_MANIFEST_SHA = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
SOURCE_ARCHIVE_SHA = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
OBSERVATION_ARCHIVE_SHA = '6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c'
GIT_PROOF_SHA = '9b2e8a4adb23ab984f37bbb8e4e568fe5864f63692aae218e1d992544a950948'
FAMILIES = ('wilting-hydraulic', 'wilting-legacy', 'field-capacity-hydraulic', 'field-capacity-legacy')


class EvidenceError(ValueError):
    pass


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def file_digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def _pairs(rows):
    result = {}
    for key, value in rows:
        if key in result:
            raise EvidenceError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def _reject(value):
    raise EvidenceError('Nonfinite JSON constant: ' + value)


def _finite_json(value):
    if value is None or type(value) in (bool, str, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    if type(value) is list:
        for item in value:
            _finite_json(item)
        return
    if type(value) is dict and all(type(key) is str for key in value):
        for item in value.values():
            _finite_json(item)
        return
    raise EvidenceError('Unsupported or nonfinite JSON value')


def load_json(raw):
    result = json.loads(raw.decode('utf-8'), object_pairs_hook=_pairs, parse_constant=_reject)
    _finite_json(result)
    return result


def canonical(value):
    _finite_json(value)
    return json.dumps(value, allow_nan=False, sort_keys=True, separators=(',', ':')).encode()


def relative_name(name):
    if type(name) is not str or not name or '\\' in name:
        raise EvidenceError('Invalid artifact name')
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or str(path) != name or name == '.':
        raise EvidenceError('Artifact names must be unique canonical relative paths')
    return name


def check_hash(value):
    if type(value) is not str or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
        raise EvidenceError('Invalid SHA256 identity')
    return value


def authorities():
    on_raw = (HERE / 'ON_REFERENCE.json').read_bytes()
    om_raw = (HERE / 'OM_PLAN.json').read_bytes()
    if digest(on_raw) != ON_SHA or digest(om_raw) != OM_PLAN_SHA:
        raise EvidenceError('Immutable OM/ON authority changed')
    on, om = load_json(on_raw), load_json(om_raw)
    if om['active_dims'] != ['b_s', 'mr_b', 'q10'] or om['candidate_count'] != 23:
        raise EvidenceError('Use the complete actual three-dimension OM recipe')
    candidates = om['first_batch'] + om['second_batch']
    if len(candidates) != 23 or len({row['id'] for row in candidates}) != 23:
        raise EvidenceError('Incomplete OM candidate recipe')
    source = load_json((HERE / 'SOURCE_BINDINGS.json').read_bytes())
    manifest = load_json((HERE / 'CONTROLS_SHA256.json').read_bytes())
    for name, expected in manifest.items():
        relative_name(name)
        if file_digest(HERE / name) != check_hash(expected):
            raise EvidenceError('OO preparation bytes changed: ' + name)
    if source['model_source_manifest_sha256'] != SOURCE_MANIFEST_SHA:
        raise EvidenceError('Wrong model source identity')
    return on, om, source

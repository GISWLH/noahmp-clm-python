"""Independent stdlib Decimal oracle for synthetic loss tests; no scorer imports."""
from decimal import Decimal, localcontext
import math


def synthetic_cell_oracle(observations, qc, predictions, seconds, *, carbon, std, floor):
    """Hand-specified test inputs only; never a production model-evidence API."""
    if not (len(observations) == len(qc) == len(predictions) == len(seconds)):
        raise ValueError('Length mismatch')
    if any(not math.isfinite(value) for value in predictions):
        raise ValueError('Invalid prediction even outside observation selection')
    if any(not math.isfinite(value) or value <= 0 for value in seconds):
        raise ValueError('Invalid interval')
    with localcontext() as context:
        context.prec = 60
        terms = []
        for observed, quality, model, interval in zip(observations, qc, predictions, seconds):
            if math.isfinite(observed) and quality == 0:
                prediction = Decimal(str(model))
                if carbon:
                    prediction /= Decimal(str(interval)) * Decimal('0.0000120107')
                terms.append((prediction - Decimal(str(observed))) ** 2)
        if len(terms) < 2:
            raise ValueError('At least two observations required')
        rms = (sum(terms, Decimal(0)) / Decimal(len(terms))).sqrt()
        scale = max(Decimal(str(std)), Decimal(str(floor)))
        return float(rms / scale)


def synthetic_equal_twelve_oracle(contributions):
    if len(contributions) != 12:
        raise ValueError('Twelve equally weighted contributions required')
    return math.fsum(contributions) / 12


def synthetic_four_family_oracle(contributions):
    """Independent Decimal reduction over four full twelve-cell lists."""
    if len(contributions) != 4 or any(len(row) != 12 for row in contributions):
        raise ValueError('Four complete synthetic families required')
    with localcontext() as context:
        context.prec = 60
        values = [sum(Decimal(str(v)) for v in row) / Decimal(12) for row in contributions]
        return float(sum(values) / Decimal(4))

"""Standard-library-only OO metadata freeze and AST inspection; no scoring/tests."""
import ast
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
V1 = HERE.parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def checked(path, expected):
    raw = path.read_bytes()
    assert sha(raw) == expected, path
    return raw


def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n', encoding='utf-8', newline='\n')


def main():
    nm_name = 'climatology-final-candidate-nm-source.tar.gz'
    nm_sha = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    checked(V1 / nm_name, nm_sha)
    with tarfile.open(V1 / nm_name) as archive:
        names = archive.getnames()
        assert len(names) == len(set(names)) == 585 and all(m.isfile() for m in archive)
        raw_manifest = archive.extractfile('SOURCE_SHA256.json').read()
        assert sha(raw_manifest) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
        sources = json.loads(raw_manifest)
        assert len(sources) == 584 and set(names) == set(sources) | {'SOURCE_SHA256.json'}
        assert all(sha(archive.extractfile(name).read()) == value for name, value in sources.items())
    native_dependencies = {name: value for name, value in sources.items()
                           if (name.startswith('src/noahmp_clm/') and Path(name).suffix in ['.py', '.cu', '.npz']) or
                           name in ['benchmarks/run_fluxnet_native.py', 'benchmarks/run_fluxnet_column.py',
                                    'benchmarks/fluxnet_solar.py', 'benchmarks/fluxnet_deposition.py']}
    on_raw = checked(V1 / 'fluxnet-training-reference-on.json',
                     '2e113b7bc76fb294c3cc0ee29c701a15755ac6b0ddb44295e800b0b0e965d4be')
    (HERE / 'ON_REFERENCE.json').write_bytes(on_raw)
    om_archive = V1 / 'fluxnet-calibration-om-evidence.tar.gz'
    checked(om_archive, '1581110dab18462127cb4baf54eef327de9bfd15eb3da72d3dc01670512ba7ac')
    with tarfile.open(om_archive) as archive:
        raw = archive.extractfile('result/candidate-plan.json').read()
    assert sha(raw) == 'fc2b5866e9368dc80ec9ca6e9dfe1e91dbac139908db79abc11bc4d70180f8c3'
    (HERE / 'OM_PLAN.json').write_bytes(raw)
    om_plan = json.loads(raw)
    assert om_plan['active_dims'] == ['b_s', 'mr_b', 'q10'] and om_plan['candidate_count'] == 23
    original_config = checked(V1 / 'fluxnet-calibration-om-preparation/original-cng-config.json',
                              '927ec061bcc6dad7cce47945549b56bb7908687c01c64ebe4ef4da4604533f7a')
    (HERE / 'ORIGINAL_CONFIG.json').write_bytes(original_config)
    git_raw = checked(V1 / 'nm-commit-proof-og-evidence.tar.gz',
                      '9b2e8a4adb23ab984f37bbb8e4e568fe5864f63692aae218e1d992544a950948')
    (HERE / 'ORIGINAL_GIT_PROOF.tar.gz').write_bytes(git_raw)
    on_archive = V1 / 'fluxnet-training-reference-on-public-evidence.tar.gz'
    checked(on_archive, '6a29805fbdf2cb1205d98813d17f45ef2845e9fb556a1c2478e9fd6d350f6c0f')
    with tarfile.open(on_archive) as archive:
        for old, new in [('result/receipt.json', 'ON_RECEIPT.json'), ('actual-qstat.txt', 'ON_QSTAT_FINAL.txt')]:
            (HERE / new).write_bytes(archive.extractfile(old).read())
    binding = json.loads((V1 / 'fluxnet-training-reference-on-preparation/INPUT_BINDINGS.json').read_bytes())
    om_binding = json.loads((V1 / 'fluxnet-calibration-om-preparation/SOURCE_BINDINGS.json').read_bytes())
    write_json('SOURCE_BINDINGS.json', dict(
        scope='Original OM/ON and NM byte authorities only; no physical candidate or final spinup/budget protocol.',
        model_source_manifest_sha256=sha(raw_manifest), model_source_archive_sha256=nm_sha,
        model_source_sha256=sources, original_native_dependency_sha256=native_dependencies,
        original_training_inputs=binding, original_om_preparation_source_bindings_sha256=sha((V1 / 'fluxnet-calibration-om-preparation/SOURCE_BINDINGS.json').read_bytes()),
        original_om_config_registry=om_binding['allowed_original_configurations'],
        om_executed_metadata_archive_sha256=sha(om_archive.read_bytes()),
        on_executed_reference_archive_sha256=sha(on_archive.read_bytes()), original_git_proof_sha256=sha(git_raw),
        original_config_sha256=sha(original_config), on_reference_sha256=sha(on_raw),
        candidate_plan_sha256=sha((HERE / 'OM_PLAN.json').read_bytes()),
        on_receipt_sha256=sha((HERE / 'ON_RECEIPT.json').read_bytes()), on_qstat_sha256=sha((HERE / 'ON_QSTAT_FINAL.txt').read_bytes())))
    families = ['wilting-hydraulic', 'wilting-legacy', 'field-capacity-hydraulic', 'field-capacity-legacy']
    write_json('OBJECTIVE.json', dict(
        schema='oo-objective-v1', scope='Fixed optimization objective; not scientific acceptance or complete physical run protocol.',
        on_reference_sha256=sha(on_raw), om_plan_sha256=sha((HERE / 'OM_PLAN.json').read_bytes()),
        training_site_years=[['CN-Cng', 2007], ['CN-Cng', 2008], ['CN-Qia', 2003], ['CN-Qia', 2004]],
        products=['H_F_MDS', 'LE_F_MDS', 'NEE_VUT_REF'], reference_selection='isfinite(original observation) & (own QC == 0)',
        minimum_reference_count_per_cell=2, denominator='max(original ON population standard deviation, fixed product floor)',
        product_floors={'H_F_MDS': 1.0, 'LE_F_MDS': 1.0, 'NEE_VUT_REF': 0.1},
        cell_weights='Exactly twelve equal weights per family, independent of n; no missing-cell renormalization.',
        family_weights={name: 0.25 for name in families}, family_aggregation='All four family losses required; arithmetic mean. No best/min selection.',
        family_weight_decision='Root decision before any candidate physical prediction/result; 2026-10-25 session.',
        family_uncertainty='If distinct initial states converge to equal trajectories, retained equal duplicate contributions do not change candidate preference. Families are still reported separately.',
        model_fields={'H_F_MDS': 'h_wm2', 'LE_F_MDS': 'le_wm2', 'NEE_VUT_REF': 'nee_gc_m2'},
        nee_conversion='nee_gc_m2 / (actual interval seconds * 12.0107e-6)', nee_positive='toward atmosphere',
        prediction_requirement='Exact full original calendar and all required full-year values finite before reference masking; no clipping or bad-model-point omission.',
        coverage='Every original month remains reported, including Cng2007 Jan-Apr zero QC0 support. QC0 does not establish independent observations.',
        recipe=dict(candidate_count=23, active_dims=['b_s', 'mr_b', 'q10'], baseline_plus_endpoints=7, lhs=16, seed=20261025),
        physical_execution='Not enabled. Own-parameter initialization/spinup, complete run evidence and total budget still require their separately frozen implementation.',
        native_transport='23 candidates x 8 original site-family cases retained; no config.case rewrite or candidate transport label normalization. Proposed 19-group batching adapter is not implemented here.',
        scientific_acceptance='Original daily/monthly/correlation/nearzero/GPP-OR/budget evaluators remain independent and unchanged.'))
    write_json('RUN_CONTRACT_REGISTRY.json', dict(schema='oo-run-registry-preparation-v1', contracts={},
        reason='Physical initialization, own-parameter spinup, total budget and genuine delivery schema are not frozen; production scorer is disabled.',
        boundary='An empty registry rejection is not a positive test of a physical chain. Native parser tests use independent synthetic packets explicitly.'))
    static = {}
    for path in sorted(HERE.glob('*.py')):
        tree = ast.parse(path.read_text(encoding='utf-8'), filename=path.name)
        static[path.name] = dict(sha256=sha(path.read_bytes()), tests=[node.name for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')],
            imports=sorted({node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)} |
                           {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names}))
    write_json('STATIC_REVIEW.json', dict(scope='AST/hash/archive metadata only. No planner, scorer, tests, NumPy import or physics executed locally.',
        files=static, test_methods=sum(len(row['tests']) for row in static.values()), model_source_files_verified=584,
        original_native_dependencies=len(native_dependencies), tests_executed=False))
    controls = {path.name: sha(path.read_bytes()) for path in sorted(HERE.iterdir())
                if path.is_file() and path.name != 'CONTROLS_SHA256.json'}
    write_json('CONTROLS_SHA256.json', controls)
    print(json.dumps(dict(controls=len(controls), manifest_sha256=sha((HERE / 'CONTROLS_SHA256.json').read_bytes()),
                         tests_prepared=sum(len(row['tests']) for row in static.values()), tests_executed=False)))


if __name__ == '__main__':
    main()

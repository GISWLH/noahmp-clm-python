"""Read closed candidate artifacts and native generation identities; never launch physics."""
from pathlib import Path
import io
import re
import numpy as np

from authority_oo import (EvidenceError, canonical,
                         check_hash, digest, file_digest, load_json, relative_name)
from reference_oo import complete_calendar

PARAMETER_PATHS = {
    'b_s': [('leaf_parameters', 'ball_berry_slope')],
    'mr_b': [('biogeochemistry', 'plant_parameters', 'maintenance_base')],
    'q10': [('biogeochemistry', 'plant_parameters', 'maintenance_q10'),
            ('biogeochemistry', 'decomposition_parameters', 'q10')],
}
LEDGERS = {'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax'}


class Packet:
    """Require a closed complete inventory; mutable aliases get no special trust."""
    def __init__(self, root):
        self.root = Path(root).resolve()
        index_path = self.root / 'ARTIFACT_SHA256.json'
        self.index_raw = index_path.read_bytes()
        self.index = load_json(self.index_raw)
        if type(self.index) is not dict or not self.index:
            raise EvidenceError('Closed artifact inventory is missing')
        actual = set()
        for path in self.root.rglob('*'):
            if path.is_symlink():
                raise EvidenceError('Closed evidence cannot include links')
            if path.is_file():
                actual.add(path.relative_to(self.root).as_posix())
        if actual != set(self.index) | {'ARTIFACT_SHA256.json'}:
            raise EvidenceError('Closed inventory must cover every artifact exactly')
        for name, expected in self.index.items():
            relative_name(name)
            if file_digest(self.root / name) != check_hash(expected):
                raise EvidenceError('Closed artifact bytes differ: ' + name)

    def raw(self, name, expected=None):
        relative_name(name)
        if name not in self.index:
            raise EvidenceError('Required artifact missing: ' + name)
        raw = (self.root / name).read_bytes()
        if digest(raw) != self.index[name] or (expected is not None and digest(raw) != check_hash(expected)):
            raise EvidenceError('Artifact changed or has wrong identity: ' + name)
        return raw

    def json(self, name, expected=None):
        return load_json(self.raw(name, expected))

    def arrays(self, name, expected=None):
        with np.load(io.BytesIO(self.raw(name, expected)), allow_pickle=False) as archive:
            if len(archive.files) != len(set(archive.files)):
                raise EvidenceError('Duplicate NPZ members')
            return dict(archive)


def _true(value, label):
    if value is not True:
        raise EvidenceError(label + ' must be actually true')


def _int(value, label, minimum=0):
    if type(value) is not int or value < minimum:
        raise EvidenceError(label + ' must be an integer, not a coerced bool/float')
    return value


def _child(parent, child):
    if type(child) is not str or Path(child).name != child or '\\' in child or child in ('', '.', '..'):
        raise EvidenceError('Native generation members must be plain filenames')
    return str(Path(parent).parent / child).replace('\\', '/')


def _arrays_equal(left, right, label):
    if left.dtype != right.dtype or left.shape != right.shape or left.tobytes() != right.tobytes():
        raise EvidenceError('State identity mismatch: ' + label)


def verify_configuration(original, derived, candidate):
    """The original bytes are externally frozen by the run contract, never self-registered."""
    old, new = load_json(original), load_json(derived)
    expected = load_json(canonical(old))
    if set(candidate['values']) != set(PARAMETER_PATHS):
        raise EvidenceError('All three original shared parameter dimensions are required')
    for dimension, paths in PARAMETER_PATHS.items():
        value = candidate['values'][dimension]
        if type(value) not in (int, float) or not np.isfinite(value):
            raise EvidenceError('Non-numeric candidate parameter')
        low, high = {'b_s': (5.0, 12.0), 'mr_b': (1.5e-6, 4.5e-6), 'q10': (1.1, 3.0)}[dimension]
        if not low <= value <= high:
            raise EvidenceError('Parameter lies outside its fixed original range')
        for path in paths:
            parent = expected
            for part in path[:-1]:
                if type(parent) is not dict or part not in parent:
                    raise EvidenceError('Missing original parameter path')
                parent = parent[part]
            if path[-1] not in parent:
                raise EvidenceError('Missing explicit baseline parameter')
            baseline = {'b_s': 9, 'mr_b': 2.525e-6, 'q10': 1.5}[dimension]
            if type(parent[path[-1]]) not in (int, float) or parent[path[-1]] != baseline:
                raise EvidenceError('Original configuration does not have the fixed baseline')
            parent[path[-1]] = value
    if canonical(new) != canonical(expected):
        raise EvidenceError('Candidate config changed something outside the four exact parameter paths')
    if old['biogeochemistry']['decomposition_parameters']['reference_temperature'] != 298.15:
        raise EvidenceError('Wrong original decomposition reference temperature')
    return new


def verify_parent_exit(raw):
    """Verify the stored actual parent status, never a report's passed flag."""
    if raw.strip() != b'0':
        raise EvidenceError('Actual completed outer parent exit 0 required')


def _case_label(value):
    if type(value) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', value):
        raise EvidenceError('Native case must be its original plain case label')
    return value


def _pbs_terminal(raw, job):
    text = raw.decode('utf-8')
    if type(job) is not str or not re.fullmatch(r'\d+\.manager', job):
        raise EvidenceError('Missing actual audit PBS job identity')
    if not re.search(r'^Job Id:\s*' + re.escape(job) + r'\s*$', text, re.M):
        raise EvidenceError('Audit qstat job identity mismatch')
    if not re.search(r'^\s*job_state = F\s*$', text, re.M) or not re.search(r'^\s*Exit_status = 0\s*$', text, re.M):
        raise EvidenceError('Actual complete PBS F0 required')


def verify_native_generation(packet, batch_name, case_name, expected_source, expected_config, expected_forcing,
                             *, site=None, year=None, expected_configuration=None):
    _case_label(case_name)
    batch = packet.json(batch_name)
    for name in ['steps_completed', 'steps_requested', 'ledger_steps', 'ledger_segments', 'columns']:
        _int(batch[name], name, minimum=1)
    if batch['status'] != 'complete' or batch['steps_completed'] != batch['steps_requested']:
        raise EvidenceError('Partial or failed native generation')
    _true(batch['source_unchanged'], 'Unchanged native source')
    identity = batch['identity']
    if identity['source_sha256'] != expected_source or identity['backend'] != 'cuda32' or identity['compare_jax32'] is not False:
        raise EvidenceError('Native runtime source/backend differs from frozen contract')
    count = identity.get('native_state_arrays', 16)
    if type(count) is not int or count != 16:
        raise EvidenceError('This frozen BGC calibration contract expects the original sixteen arrays')
    identities = identity['cases']
    for item in identities:
        _case_label(item['case'])
    if len(identities) != batch['columns'] or len({row['case'] for row in identities}) != len(identities):
        raise EvidenceError('Repeated/missing native case identity')
    if set(batch['case_reports']) != {row['case'] for row in identities}:
        raise EvidenceError('Native batch does not declare every case report')
    matches = [row for row in identities if row['case'] == case_name]
    if len(matches) != 1:
        raise EvidenceError('Requested case not uniquely present in native generation')
    case = matches[0]
    if case['configuration_sha256'] != expected_config:
        raise EvidenceError('Candidate config identity changed or belongs to another parameter')
    if (case['forcing_npz_sha256'], case['forcing_manifest_sha256']) != expected_forcing:
        raise EvidenceError('Native forcing identity differs from fixed year input')
    checkpoint_name = _child(batch_name, batch['checkpoint_file'])
    match = re.fullmatch(r'state-(\d{7}-[0-9a-f]{32})\.npz', batch['checkpoint_file'])
    if match is None or int(match.group(1).split('-')[0]) != batch['steps_completed']:
        raise EvidenceError('Immutable native checkpoint generation is missing')
    generation = match.group(1)
    state = packet.arrays(checkpoint_name, batch['checkpoint_sha256'])
    expected_fields = {f'a{k}' for k in range(16)} | LEDGERS | {'index'}
    if set(state) != expected_fields or state['index'].shape != () or state['index'].dtype.kind not in 'iu':
        raise EvidenceError('Incomplete original 23-field native checkpoint')
    if int(state['index']) != batch['steps_completed']:
        raise EvidenceError('Checkpoint and batch generation differ')
    for name, value in state.items():
        if value.dtype.kind not in 'fiu' or not np.all(np.isfinite(value)):
            raise EvidenceError('Invalid/nonfinite checkpoint field: ' + name)
        if name.startswith('a') and (value.ndim < 1 or value.shape[0] != batch['columns']):
            raise EvidenceError('Native state column dimension mismatch')
    for name in LEDGERS:
        if state[name].shape != (batch['columns'], 5 if name == 'tracermax' else 4):
            raise EvidenceError('Complete cumulative ledger shape mismatch')
    descriptor = batch['case_reports'][case_name]
    if descriptor['file'] != 'report-' + generation + '.json':
        raise EvidenceError('Case descriptor must select the immutable report for this generation')
    report_name = str(Path(batch_name).parent / case_name / descriptor['file']).replace('\\', '/')
    if Path(descriptor['file']).name != descriptor['file']:
        raise EvidenceError('Immutable case report must be a plain filename')
    report = packet.json(report_name, descriptor['sha256'])
    if report['backend'] != identity['backend'] or _int(report['batch_column'], 'batch_column') != identities.index(case):
        raise EvidenceError('Case backend or native column alias mismatch')
    if expected_configuration is not None and canonical(report['configuration']) != canonical(expected_configuration):
        raise EvidenceError('Report configuration differs from the frozen candidate bytes')
    for name in ['case', 'configuration_sha256', 'forcing_npz_sha256', 'forcing_manifest_sha256']:
        if report[name] != case[name]:
            raise EvidenceError('Case report relabeling or identity mismatch')
    if (report['status'] != 'complete' or report['steps_completed'] != batch['steps_completed'] or
            report['steps_requested'] != batch['steps_requested'] or report['batch_checkpoint_sha256'] != batch['checkpoint_sha256'] or
            report['source_sha256'] != expected_source or report['ledger_steps'] != batch['ledger_steps'] or
            report['ledger_segments'] != batch['ledger_segments'] or report['initial_run'] != identity.get('initial_run')):
        raise EvidenceError('Immutable native report/generation/ledger linkage mismatch')
    for name in ['steps_completed', 'steps_requested', 'ledger_steps', 'ledger_segments']:
        _int(report[name], 'case ' + name, minimum=1)
    if report['batch_checkpoint_file'] != '../' + batch['checkpoint_file']:
        raise EvidenceError('Native report checkpoint path mismatch')
    _true(report['source_unchanged'], 'Case source unchanged')
    trace_name = _child(report_name, report['model_npz'])
    if report['model_npz'] != 'trace-' + generation + '.npz':
        raise EvidenceError('Trace must belong to the same immutable generation')
    trace = packet.arrays(trace_name, report['model_npz_sha256'])
    required = {'time_start', 'time_end', 'h_wm2', 'le_wm2', 'nee_gc_m2',
                'step_residual_m_h_c_n', 'step_bound_m_h_c_n', 'cumulative_residual_m_h_c_n'}
    if not required <= set(trace):
        raise EvidenceError('Required model trace fields missing')
    for name, value in trace.items():
        if value.ndim < 1 or len(value) != batch['steps_completed']:
            raise EvidenceError('Incomplete whole-year trace field: ' + name)
        if name not in ('time_start', 'time_end') and (value.dtype.kind != 'f' or not np.all(np.isfinite(value))):
            raise EvidenceError('Nonfinite/nonfloating full trace field: ' + name)
    for name in ['h_wm2', 'le_wm2', 'nee_gc_m2']:
        if trace[name].shape != (batch['steps_completed'],):
            raise EvidenceError('Model field must be scalar per interval')
    if site is not None:
        if report['site'] != site or report['time_convention'] != 'local standard time' or report['utc_offset_hours'] != 8:
            raise EvidenceError('Site/local-standard-time identity mismatch')
        complete_calendar(site, year, trace['time_start'], trace['time_end'])
    return dict(batch=batch, report=report, trace=trace, state=state, batch_name=batch_name,
                report_name=report_name, trace_name=trace_name, checkpoint_name=checkpoint_name,
                batch_sha256=packet.index[batch_name], report_sha256=packet.index[report_name],
                trace_sha256=packet.index[trace_name], checkpoint_sha256=packet.index[checkpoint_name])


def verify_carry(packet, previous, current, zero_batch_name, zero_checkpoint_name, first_packet_name, mode,
                 expected_first_environment):
    if mode not in ('continue', 'cycle'):
        raise EvidenceError('Unknown original native carry mode')
    link = current['batch']['identity'].get('initial_run')
    expected = dict(mode=mode, batch_report_sha256=previous['batch_sha256'],
                    checkpoint_sha256=previous['checkpoint_sha256'],
                    previous_ledger_steps=previous['batch']['ledger_steps'], previous_segments=previous['batch']['ledger_segments'])
    if link != expected:
        raise EvidenceError('Wrong parameter/parent checkpoint or ledger reset in state chain')
    previous_identity, current_identity = previous['batch']['identity'], current['batch']['identity']
    for key in ['source_sha256', 'backend', 'compare_jax32']:
        if previous_identity[key] != current_identity[key]:
            raise EvidenceError('Source/backend changed in carried state')
    before_cases, after_cases = previous_identity['cases'], current_identity['cases']
    if len(before_cases) != len(after_cases):
        raise EvidenceError('Native batch column count changed in carried state')
    for before_case, after_case in zip(before_cases, after_cases):
        for key in ['case', 'configuration_sha256']:
            if before_case[key] != after_case[key]:
                raise EvidenceError('Case/configuration normalization is not allowed')
        if mode == 'cycle' and before_case != after_case:
            raise EvidenceError('A native cycle must use the identical original forcing')
    if current['batch']['ledger_steps'] != previous['batch']['ledger_steps'] + current['batch']['steps_completed']:
        raise EvidenceError('Cumulative ledger steps did not carry')
    if current['batch']['ledger_segments'] != previous['batch']['ledger_segments'] + 1:
        raise EvidenceError('Cumulative segment count did not carry')
    if mode == 'continue' and current['trace']['time_start'][0] != previous['trace']['time_end'][-1]:
        raise EvidenceError('Continuation year is not contiguous')
    zero = packet.json(zero_batch_name)
    if _child(zero_batch_name, zero['checkpoint_file']) != zero_checkpoint_name:
        raise EvidenceError('Zero-step checkpoint path differs')
    start = packet.arrays(zero_checkpoint_name, zero['checkpoint_sha256'])
    if (zero['status'] != 'running' or zero['steps_completed'] != 0 or
            zero['identity'] != current['batch']['identity'] or
            zero['ledger_steps'] != previous['batch']['ledger_steps'] or
            zero['ledger_segments'] != current['batch']['ledger_segments'] or
            set(start) != set(previous['state']) or start['index'].shape != () or
            start['index'].dtype.kind not in 'iu' or int(start['index']) != 0):
        raise EvidenceError('Missing exact complete zero-step carry generation')
    for name in set(start) - {'index'}:
        _arrays_equal(start[name], previous['state'][name], name)
    first = packet.arrays(first_packet_name)
    for index in range(16):
        key = 'before' + str(index)
        if key not in first:
            raise EvidenceError('First actual device packet missing original state array')
        actual, old = first[key], previous['state']['a' + str(index)]
        if index != 4:
            _arrays_equal(actual, old, key)
        else:
            if (old.ndim != 2 or old.shape[1] < 10 or not isinstance(expected_first_environment, np.ndarray) or
                    expected_first_environment.shape != (old.shape[0], 3) or
                    expected_first_environment.dtype.kind != 'f' or not np.all(np.isfinite(expected_first_environment))):
                raise EvidenceError('Missing original input environment for first device state')
            # Explicitly prescribed by original Backend.update_forcing; no other
            # state byte is changed. Caller must derive this from frozen inputs.
            expected_state = old.copy()
            expected_state[:, 7:10] = expected_first_environment.astype(old.dtype)
            _arrays_equal(actual, expected_state, 'before4 including original forcing environment')
    return dict(nonindex_checkpoint_fields_checked=22, device_arrays_checked=16,
                parent_batch_sha256=previous['batch_sha256'], parent_checkpoint_sha256=previous['checkpoint_sha256'])

# OO independent optimization objective — preparation only

The fixed objective retains all four dry/wet × BGC configuration families. Each family has twelve equally weighted training cells (Cng2007/2008, Qia2003/2004 × H/LE/NEE); their four losses receive weights 1/4. The original ON own-QC0 mask, reference population standard deviation, monthly coverage and exact calendar are fixed before predictions. H/LE floors are 1 W/m² and the NEE floor is 0.1 umol CO2/m²/s. These are optimization scales, not scientific acceptance tolerances.

`reference_oo.freeze_reference(path)` reads the original archive and decodes only the two 35,088-row training prefixes. It verifies original ON full-container, prefix, cell, mask and monthly hashes, original counts and complete calendar. Original ON statistics remain the frozen values; they are not refit using predictions. The original source tar must be supplied on EHPC through `OO_OBSERVATION_ARCHIVE`; the integration suite fails if it is absent. Cng2007 January–April zero-QC0 support stays visible for all three products. QC0 is not a claim of independent observations.

`score_math_oo.py` implements the numerical kernel. `scorer_oo._score_family_math` and `_score_four_math` are private analysis helpers; their synthetic outputs explicitly have `test_only=true` and `physical_candidate_evidence=false`. Actual NEE interval gC is divided by actual interval seconds × 12.0107e-6, positive to atmosphere. Entire model years must be finite and exactly aligned before masking. Missing cells/families never produce partial or renormalized loss.

`score_candidate(...)` is the deliberately disabled production entry: it returns invalid/null while initialization, own-parameter spinup, total budget and a genuine complete physical delivery contract are unresolved. The empty registry rejection does **not** test a real complete state chain. `evidence_oo.py` separately parses complete inventoried native generations, immutable report/trace/checkpoint links, original case/configuration/source identities, 23-field checkpoints, exact 22 non-index carry fields and 16 first-device arrays with the prescribed forcing-only environment update. Its direct tests have an independently constructed valid synthetic packet and targeted corrupted packets; these toy states never claim conservation or physical execution. Actual parent status and terminal PBS checks are parser tests, not real audit receipts.

The future production integration must bind actual frozen source/Git, forcing/configuration baseline and OM legal candidate identities, all initialization/spinup/continued years for the same candidate, actual parent 0/barrier and original independent hard-budget delivery. No wrapper/audit schema is invented now. Conservative 23 × 8 case identity is preserved; proposed 19-group transport-label batching is outside this implementation.

`test_score_math_oo.py` uses an independent Decimal oracle for units, masking, floors and fixed equal weights. `test_native_evidence_oo.py` tests native structure/state identities and rejection. `test_reference_integration_oo.py` must read the actual original ON archive, retains all 144 coverage months and compares zero synthetic predictions against the independent population-moment identity. No test executes the model or reads held-out observations as fit input. The original scientific evaluation remains separate and unchanged.

Local preparation is only standard-library AST/hash/archive metadata inspection:

```text
python -B prepare_oo.py
```

The following test command is for an isolated EHPC `/tmp` directory using the closeout Python after root's static review. It has not run as part of this preparation:

```text
OO_OBSERVATION_ARCHIVE=/home/zhangyq/noahmp-v1/multiyear-originals-fu.tar.gz \
PYTHONDONTWRITEBYTECODE=1 /home/zhangyq/venvs/noahmp-closeout/bin/python -B -m unittest -v \
  test_score_math_oo test_native_evidence_oo test_reference_integration_oo
```

No model, deployment, PBS submission, numerical test or candidate ranking is performed by the preparation builder. `CONTROLS_SHA256.json` covers every prepared control and copied authority. Full runtime source hashes are verified from the original NM584 archive; the included Git proof retains its actual historical commit/source scope and is not a current physical-run proof.

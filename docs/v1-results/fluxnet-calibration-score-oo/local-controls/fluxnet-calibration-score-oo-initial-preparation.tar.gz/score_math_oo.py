"""OO loss mathematics only; production evidence validation is a separate caller.

These helpers do not claim that arrays came from a model or that spinup,
conservation, observations or a candidate passed scientific acceptance.
"""
import math
import numpy as np
from authority_oo import FAMILIES

PRODUCTS = ('H_F_MDS', 'LE_F_MDS', 'NEE_VUT_REF')
YEARS = (('CN-Cng', 2007), ('CN-Cng', 2008), ('CN-Qia', 2003), ('CN-Qia', 2004))
FLOORS = {'H_F_MDS': 1.0, 'LE_F_MDS': 1.0, 'NEE_VUT_REF': 0.1}
MODEL_FIELDS = {'H_F_MDS': 'h_wm2', 'LE_F_MDS': 'le_wm2', 'NEE_VUT_REF': 'nee_gc_m2'}
CARBON_MASS_PER_UMOL = 12.0107e-6


class InvalidScore(ValueError):
    """Fail the whole requested score; never remove a model point or cell."""


def _real_vector(value, name, length=None, finite=False):
    if type(value) is not np.ndarray or value.dtype.kind != 'f' or value.ndim != 1:
        raise InvalidScore(name + ' must be a one-dimensional floating ndarray')
    if length is not None and value.shape != (length,):
        raise InvalidScore(name + ' length mismatch')
    if finite and not np.all(np.isfinite(value)):
        raise InvalidScore(name + ' has nonfinite values over the complete supplied interval')
    return value


def _finite_scalar(value, name, minimum=None):
    try:
        valid = type(value) in (float, int) and math.isfinite(value)
    except OverflowError:
        valid = False
    if not valid:
        raise InvalidScore(name + ' must be a finite real scalar, not bool')
    if minimum is not None and value < minimum:
        raise InvalidScore(name + ' below its valid minimum')
    return value


def _cell_loss(product, observed, own_qc, predicted, dt_seconds, reference_mean,
               reference_population_std, expected_n):
    """Private numeric kernel: immutable reference authority is checked upstream."""
    if product not in PRODUCTS:
        raise InvalidScore('Unknown fitting product')
    observed = _real_vector(observed, 'observation')
    length = observed.size
    own_qc = _real_vector(own_qc, 'own QC', length)
    predicted = _real_vector(predicted, 'prediction', length, finite=True)
    dt_seconds = _real_vector(dt_seconds, 'actual interval seconds', length, finite=True)
    if not np.all(dt_seconds > 0):
        raise InvalidScore('Every actual interval must have positive duration')
    _finite_scalar(reference_mean, 'original reference mean')
    std = _finite_scalar(reference_population_std, 'original population standard deviation', 0.0)
    if type(expected_n) is not int or expected_n < 2:
        raise InvalidScore('At least two original available observations per cell are required')
    mask = np.isfinite(observed) & (own_qc == 0)
    if int(np.count_nonzero(mask)) != expected_n:
        raise InvalidScore('Original reference sample count mismatch')
    rate = predicted.astype(np.float64, copy=False)
    if product == 'NEE_VUT_REF':
        with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
            rate = rate / (dt_seconds.astype(np.float64, copy=False) * CARBON_MASS_PER_UMOL)
        if not np.all(np.isfinite(rate)):
            raise InvalidScore('Converted full-year NEE is nonfinite')
    with np.errstate(over='ignore', invalid='ignore'):
        errors = rate[mask] - observed[mask]
        squared = np.square(errors, dtype=np.float64)
        rmse = float(np.sqrt(np.mean(squared, dtype=np.float64)))
    if not math.isfinite(rmse):
        raise InvalidScore('Nonfinite residual or RMSE; no clipping is allowed')
    floor = FLOORS[product]
    denominator = max(float(std), floor)
    normalized = rmse / denominator
    if not math.isfinite(normalized):
        raise InvalidScore('Normalized error is nonfinite')
    return dict(product=product, reference_n=expected_n, reference_mean=reference_mean,
                reference_population_std=std, normalization_floor=floor, denominator=denominator,
                rmse=rmse, normalized_rmse=normalized,
                units='umol CO2 m-2 s-1' if product == 'NEE_VUT_REF' else 'W m-2')


def _equal_cell_loss(cells):
    """Exactly the twelve predefined cells; no sample-count weighting or omission."""
    required = {(site, year, product) for site, year in YEARS for product in PRODUCTS}
    if type(cells) is not list or len(cells) != 12:
        raise InvalidScore('Exactly twelve complete training cells are required')
    keys = []
    for row in cells:
        if type(row) is not dict or type(row.get('site')) is not str or type(row.get('year')) is not int:
            raise InvalidScore('Invalid site/year identity')
        if type(row.get('product')) is not str:
            raise InvalidScore('Invalid product identity')
        keys.append((row['site'], row['year'], row['product']))
        _finite_scalar(row.get('normalized_rmse'), 'normalized RMSE', 0.0)
    if len(set(keys)) != 12 or set(keys) != required:
        raise InvalidScore('Missing, duplicate, unknown or held-out cell')
    # Fixed ordering avoids input order changing the last-bit summation result.
    ordered = sorted(cells, key=lambda row: (row['site'], row['year'], row['product']))
    loss = math.fsum(row['normalized_rmse'] / 12.0 for row in ordered)
    if not math.isfinite(loss):
        raise InvalidScore('Aggregate loss is nonfinite')
    return loss


def _equal_family_loss(families):
    """Frozen four-family mean; never select best/min or reweight missing cases."""
    if type(families) is not dict or set(families) != set(FAMILIES):
        raise InvalidScore('All four original configuration families are required')
    values = []
    for family in FAMILIES:
        record = families[family]
        if type(record) is not dict or set(record) != {'cells', 'loss'}:
            raise InvalidScore('Each family must retain all twelve cells and their loss')
        calculated = _equal_cell_loss(record['cells'])
        recorded = _finite_scalar(record['loss'], 'family loss', 0.0)
        if calculated != recorded:
            raise InvalidScore('Recorded family loss differs from its complete cells')
        values.append(calculated / 4.0)
    loss = math.fsum(values)
    if not math.isfinite(loss):
        raise InvalidScore('Four-family loss is nonfinite')
    return loss

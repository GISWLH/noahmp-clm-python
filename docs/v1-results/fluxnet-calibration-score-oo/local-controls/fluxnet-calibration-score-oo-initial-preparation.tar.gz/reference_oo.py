"""Fixed ON reference reader: training prefixes only, no model or heldout decoding."""
import ast
import calendar
from dataclasses import dataclass
from datetime import datetime, timedelta
import io
import struct
import tarfile
import zipfile
import numpy as np

from authority_oo import (EvidenceError, OBSERVATION_ARCHIVE_SHA, ON_SHA, OM_PLAN_SHA,
                         authorities, canonical, digest, file_digest, load_json)
from score_math_oo import PRODUCTS, YEARS


def complete_calendar(site, year, starts, ends):
    if type(site) is not str or type(year) is not int or (site, year) not in YEARS:
        raise EvidenceError('Unknown or held-out training site/year')
    n = (366 if calendar.isleap(year) else 365) * 48
    for name, array in [('time_start', starts), ('time_end', ends)]:
        if type(array) is not np.ndarray or array.dtype.str != '<U12' or array.shape != (n,):
            raise EvidenceError(name + ' must have complete original <U12 interval shape')
    first = datetime(year, 1, 1)
    for index in range(n):
        begin = first + timedelta(seconds=index * 1800)
        finish = begin + timedelta(seconds=1800)
        if starts[index] != begin.strftime('%Y%m%d%H%M') or ends[index] != finish.strftime('%Y%m%d%H%M'):
            raise EvidenceError('Complete local-standard calendar/times do not match exactly')
    return np.frombuffer(np.full(n, 1800.0, dtype='<f8').tobytes(), dtype='<f8')


def prefix_array(raw_npz, name, expected_dtype, full_steps, training_steps):
    with zipfile.ZipFile(io.BytesIO(raw_npz)) as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise EvidenceError('Duplicate npz members')
        with archive.open(name + '.npy') as member:
            if member.read(6) != b'\x93NUMPY':
                raise EvidenceError('Wrong NPY magic')
            version = tuple(member.read(2))
            if version not in [(1, 0), (2, 0)]:
                raise EvidenceError('Unexpected original NPY version')
            width = 2 if version[0] == 1 else 4
            length = struct.unpack('<H' if width == 2 else '<I', member.read(width))[0]
            header = ast.literal_eval(member.read(length).decode('latin1'))
            if header != {'descr': expected_dtype, 'fortran_order': False, 'shape': (full_steps,)}:
                raise EvidenceError('Original prefix array descriptor changed')
            dtype = np.dtype(expected_dtype)
            raw = member.read(training_steps * dtype.itemsize)
            if len(raw) != training_steps * dtype.itemsize:
                raise EvidenceError('Incomplete original training prefix')
    # Bytes-owned arrays are immutable; later held-out rows are never decoded.
    return np.frombuffer(raw, dtype=dtype), digest(raw)


@dataclass(frozen=True)
class FrozenCell:
    site: str
    year: int
    product: str
    starts: np.ndarray
    ends: np.ndarray
    observed: np.ndarray
    qc: np.ndarray
    dt: np.ndarray
    original_record_json: bytes

    def checked_record(self):
        row = load_json(self.original_record_json)
        if (self.site, self.year, self.product) != (row['site'], row['year'], row['product']):
            raise EvidenceError('Reference cell labels differ from the fixed record')
        for array in [self.observed, self.qc, self.dt]:
            if type(array) is not np.ndarray or array.dtype.str != '<f8' or array.shape != self.starts.shape:
                raise EvidenceError('Original reference arrays must be unmasked original float64 vectors')
        checks = [('time_start_payload_sha256', self.starts.tobytes()),
                  ('original_observation_payload_sha256', self.observed.tobytes()),
                  ('original_qc_payload_sha256', self.qc.tobytes())]
        if any(digest(raw) != row[key] for key, raw in checks):
            raise EvidenceError('Reference arrays differ from immutable ON cell identity')
        mask = np.isfinite(self.observed) & (self.qc == 0)
        if digest(mask.astype(np.uint8).tobytes()) != row['finite_own_qc0_mask_sha256']:
            raise EvidenceError('Reference observation mask changed')
        if int(np.count_nonzero(mask)) != row['finite_own_qc0_samples'] or row['finite_own_qc0_samples'] < 2:
            raise EvidenceError('Wrong or insufficient original reference count')
        if not np.array_equal(self.dt, complete_calendar(self.site, self.year, self.starts, self.ends)):
            raise EvidenceError('Reference interval duration changed')
        for key in ['mean', 'population_std']:
            value = row['statistics'][key]
            if type(value) not in (int, float) or not np.isfinite(value):
                raise EvidenceError('Invalid original reference statistic')
        if row['statistics']['population_std'] < 0:
            raise EvidenceError('Invalid reference population standard deviation')
        if len(row['months']) != 12 or [m['month'] for m in row['months']] != list(range(1, 13)):
            raise EvidenceError('All original calendar months must remain represented')
        for month in row['months']:
            selected = np.char.startswith(self.starts, str(self.year) + f"{month['month']:02d}")
            actual = mask[selected]
            if (int(actual.size) != month['total_samples'] or
                    int(np.count_nonzero(actual)) != month['finite_own_qc0_samples'] or
                    digest(actual.astype(np.uint8).tobytes()) != month['finite_own_qc0_mask_sha256']):
                raise EvidenceError('Original monthly coverage or mask changed')
        return row


@dataclass(frozen=True)
class FrozenReference:
    cells: tuple
    reference_sha256: str
    candidate_plan_sha256: str

    def validate(self):
        if self.reference_sha256 != ON_SHA or self.candidate_plan_sha256 != OM_PLAN_SHA:
            raise EvidenceError('Wrong scoring authority')
        expected, _, _ = authorities()
        identities = {(c['site'], c['year'], c['product']): canonical(c) for c in expected['cells']}
        keys = [(cell.site, cell.year, cell.product) for cell in self.cells]
        if len(keys) != 12 or len(set(keys)) != 12 or set(keys) != set(identities):
            raise EvidenceError('Missing/duplicate/held-out reference cell')
        for cell in self.cells:
            if cell.original_record_json != identities[(cell.site, cell.year, cell.product)]:
                raise EvidenceError('Reference metadata differs from the fixed ON result')
            cell.checked_record()


def freeze_reference(original_archive):
    on, _, binding = authorities()
    if file_digest(original_archive) != OBSERVATION_ARCHIVE_SHA:
        raise EvidenceError('Original four-site archive identity mismatch')
    if len(on['cells']) != 12:
        raise EvidenceError('Original ON cell count changed')
    cells = []
    with tarfile.open(original_archive) as archive:
        names = archive.getnames()
        if len(names) != len(set(names)) or len(names) != 8 or not all(m.isfile() for m in archive):
            raise EvidenceError('Unexpected original observation archive members')
        for site in ['CN-Cng', 'CN-Qia']:
            identity = next(row for row in on['input_identities'] if row['site'] == site)
            metadata_raw = archive.extractfile(site + '.json').read()
            npz_raw = archive.extractfile(site + '.npz').read()
            if digest(metadata_raw) != identity['manifest_sha256'] or digest(npz_raw) != identity['npz_sha256']:
                raise EvidenceError('Original site input identity mismatch')
            metadata = load_json(metadata_raw)
            spec = binding['original_training_inputs']['training_sites'][site]
            if metadata['dt_seconds'] != 1800.0 or metadata['utc_offset_hours'] != 8:
                raise EvidenceError('Original time interpretation changed')
            arrays = {}
            for name in ['time_start', 'time_end', *[prefix + product for product in PRODUCTS for prefix in ['obs_', 'qc_']]]:
                dtype = '<U12' if name.startswith('time_') else '<f8'
                array, actual_sha = prefix_array(npz_raw, name, dtype, spec['container_steps'], 35088)
                if actual_sha != identity['decoded_npy_prefix_payload_sha256'][name]:
                    raise EvidenceError('Original training prefix bytes changed')
                arrays[name] = array
            for row in [value for value in on['cells'] if value['site'] == site]:
                start, stop = row['original_record_start_inclusive'], row['original_record_stop_exclusive']
                selected = slice(start, stop)
                starts, ends = arrays['time_start'][selected], arrays['time_end'][selected]
                cell = FrozenCell(site, row['year'], row['product'], starts, ends,
                                  arrays['obs_' + row['product']][selected], arrays['qc_' + row['product']][selected],
                                  complete_calendar(site, row['year'], starts, ends), canonical(row))
                cell.checked_record()
                cells.append(cell)
    if file_digest(original_archive) != OBSERVATION_ARCHIVE_SHA:
        raise EvidenceError('Original archive changed during read')
    reference = FrozenReference(tuple(cells), ON_SHA, OM_PLAN_SHA)
    reference.validate()
    return reference

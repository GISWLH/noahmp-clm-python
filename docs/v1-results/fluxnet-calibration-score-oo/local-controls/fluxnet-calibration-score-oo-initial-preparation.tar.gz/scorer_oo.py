"""OO objective entry points. Physical candidate scoring is not enabled yet."""
from pathlib import Path
import numpy as np

from authority_oo import (EvidenceError, FAMILIES, HERE, OM_PLAN_SHA, ON_SHA, authorities,
                         canonical, check_hash, digest, load_json)
from score_math_oo import (InvalidScore, MODEL_FIELDS, YEARS, _cell_loss,
                          _equal_cell_loss, _equal_family_loss)


def _score_family_math(reference, predictions):
    """Private math only: callers cannot promote these arrays to physical evidence."""
    reference.validate()
    if type(predictions) is not dict or set(predictions) != set(YEARS):
        raise InvalidScore('Exactly the four fixed training site-years are required')
    if any(type(key) is not tuple or len(key) != 2 or type(key[0]) is not str or type(key[1]) is not int
           for key in predictions):
        raise InvalidScore('Year/site identity cannot be normalized from another type')
    cells = []
    for cell in reference.cells:
        model = predictions[(cell.site, cell.year)]
        if type(model) is not dict or not {'time_start', 'time_end', *MODEL_FIELDS.values()} <= set(model):
            raise InvalidScore('Missing full-year model fields or timestamps')
        for key, expected in [('time_start', cell.starts), ('time_end', cell.ends)]:
            actual = model[key]
            if (type(actual) is not np.ndarray or actual.dtype != expected.dtype or
                    actual.shape != expected.shape or actual.tobytes() != expected.tobytes()):
                raise InvalidScore('Prediction calendar and original reference do not align exactly')
        original = cell.checked_record()
        value = _cell_loss(cell.product, cell.observed, cell.qc, model[MODEL_FIELDS[cell.product]], cell.dt,
                           original['statistics']['mean'], original['statistics']['population_std'],
                           original['finite_own_qc0_samples'])
        value.update(site=cell.site, year=cell.year, coverage_months=original['months'],
                     original_reference_record_sha256=digest(cell.original_record_json),
                     original_reference_mask_sha256=original['finite_own_qc0_mask_sha256'])
        cells.append(value)
    return dict(cells=cells, loss=_equal_cell_loss(cells))


def _score_four_math(reference, predictions_by_family):
    if type(predictions_by_family) is not dict or set(predictions_by_family) != set(FAMILIES):
        raise InvalidScore('Every original family is mandatory')
    families = {name: _score_family_math(reference, predictions_by_family[name]) for name in FAMILIES}
    objective_raw = (HERE / 'OBJECTIVE.json').read_bytes()
    return dict(test_only=True, physical_candidate_evidence=False,
                on_reference_sha256=ON_SHA, om_plan_sha256=OM_PLAN_SHA,
                objective_sha256=digest(objective_raw), families=families,
                family_weights={name: 0.25 for name in FAMILIES}, loss=_equal_family_loss(families),
                coverage_caveat='CN-Cng2007 H/LE/NEE have zero QC0 support in January-April; annual objective does not represent those seasons. QC0 does not establish observational independence.',
                scientific_acceptance='Not assessed by this optimization objective')


def score_candidate(reference_bundle, candidate_package, run_contract=None,
                    expected_run_contract_sha256=None):
    """Fail closed until initialization/spinup/budget and delivery are truly frozen.

    No physical runner or future receipt schema is fabricated by this preparation.
    The current empty registry is a recorded implementation boundary, not a tested
    positive physical chain validator or an additional user approval requirement.
    """
    invalid = dict(candidate_valid=False, production_scoring_enabled=False, loss=None,
                   families={name: None for name in FAMILIES}, reasons=[])
    try:
        authorities()
        registry = load_json((HERE / 'RUN_CONTRACT_REGISTRY.json').read_bytes())
        if registry['contracts'] != {}:
            raise EvidenceError('This preparation has no reviewed physical delivery adapter; registering a hash alone cannot enable it')
        if run_contract is not None:
            raw = Path(run_contract).read_bytes()
            if expected_run_contract_sha256 is None or digest(raw) != check_hash(expected_run_contract_sha256):
                raise EvidenceError('Run contract has no matching externally frozen identity')
            contract = load_json(raw)
            canonical(contract)
        raise EvidenceError('Production scoring is not enabled: candidate initialization, own-parameter spinup, total budget and genuine complete delivery contract are not yet frozen')
    except (EvidenceError, OSError, KeyError, TypeError, ValueError) as error:
        invalid['reasons'].append(str(error))
        return invalid

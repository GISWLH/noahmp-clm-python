"""Package actual closed OO scorer tests; never claim model calibration credit."""
from pathlib import Path
import ast
import hashlib
import io
import json
import re
import tarfile

OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
package_raw = (OUT / 'fluxnet-calibration-score-oo-closed-export-package.json').read_bytes()
closed_package = json.loads(package_raw)
download = OUT / 'fluxnet-calibration-score-oo-closed-export.tar.gz'
assert sha(download.read_bytes()) == closed_package['archive_sha256']
assert closed_package['actual_job'] == '1599.manager'
assert closed_package['actual_state'] == 'F' and closed_package['actual_exit'] == 0
with tarfile.open(download) as archive:
    members = archive.getmembers()
    assert all(member.isfile() for member in members) and len({member.name for member in members}) == len(members)
    closed = {member.name: archive.extractfile(member).read() for member in members}
inventory = json.loads(closed.pop('artifact-inventory.json'))
assert set(inventory) == set(closed)
assert all(sha(closed[name]) == row['sha256'] and len(closed[name]) == row['bytes'] for name, row in inventory.items())
assert re.search(r'^\s*job_state = F\s*$', closed['actual-pbs-qstat.txt'].decode(), re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', closed['actual-pbs-qstat.txt'].decode(), re.M)
receipt = json.loads(closed['result/receipt.json'])
assert receipt == closed_package['receipt'] and receipt['passed'] is True and receipt['error'] is None
assert receipt['unittest_parent_returncode'] == receipt['diagnostic_parent_returncode'] == 0
assert receipt['actual_test_count'] == 28 and receipt['model_runs'] == receipt['GPU_runs'] == receipt['physical_candidate_scores'] == 0
assert receipt['production_scoring_enabled'] is False and receipt['real_original_observation_archive_read_by_integration'] is True
for name in ['result/worker-exit.txt', 'pbs-exit.txt', 'result/unittest-parent-exit.txt', 'result/diagnostic-parent-exit.txt']:
    assert closed[name].strip() == b'0'
diagnostic = json.loads(closed['result/quantified-synthetic-diagnostics.json'])
assert sha(closed['result/quantified-synthetic-diagnostics.json']) == receipt['quantified_diagnostics_sha256']
assert diagnostic['test_only'] is True and diagnostic['physical_candidate_evidence'] is False
assert diagnostic['physical_candidate_scores'] == 0 and len(diagnostic['original_ON_twelve_cell_comparison']) == 12
files = dict(closed)
files['closed-export-package.json'] = package_raw
local_names = [
    'prepare_fluxnet_calibration_score_oo_execution.py', 'package_fluxnet_calibration_score_oo.py',
    'review_fluxnet_score_oo_wp.py', 'fluxnet-calibration-score-oo-independent-review-wp.json',
    'review_fluxnet_score_oo_wp_initial.py', 'fluxnet-calibration-score-oo-independent-review-wp-initial.json',
    'review_calibration_score_oo_root.py', 'fluxnet-calibration-score-oo-root-review.json',
    'review_calibration_score_oo_root_final.py', 'fluxnet-calibration-score-oo-root-final-review.json',
    'fluxnet-calibration-score-oo-initial-preparation.tar.gz', 'fluxnet-calibration-score-oo-initial-preparation-provenance.json',
    'fluxnet-calibration-score-oo-execution-preparation.json', 'FLUXNET_CALIBRATION_SCORE_OO_SCOPE.md',
    'fluxnet-calibration-score-oo-dispatch.stdout.txt', 'fluxnet-calibration-score-oo-dispatch.stderr.txt',
    'fluxnet-calibration-score-oo-export.stdout.txt', 'fluxnet-calibration-score-oo-export.stderr.txt',
    'fluxnet-calibration-score-oo-qstat.snapshot.txt', 'fluxnet-calibration-score-oo-qstat.snapshot.stderr.txt',
    'fluxnet-calibration-score-oo-qstat.second-snapshot.txt', 'fluxnet-calibration-score-oo-qstat.second-snapshot.stderr.txt',
    'fluxnet-calibration-score-oo-receipt-e-snapshot.json', 'fluxnet-calibration-score-oo-receipt-e-snapshot.stderr.txt',
]
for name in local_names:
    files['local-controls/' + name] = (OUT / name).read_bytes()
for path in sorted(OUT.glob('fluxnet-calibration-score-oo-qstat.*final*')):
    files['local-controls/' + path.name] = path.read_bytes()
stage_raw = (OUT / 'fluxnet-calibration-score-oo-stage.tar.gz').read_bytes()
assert sha(stage_raw) == '4c269540ba683e5e0e520b65952d82a72f4f13efec3e1f3933836ba4fe9598f5'
files['original-stage.tar.gz'] = stage_raw
with tarfile.open(fileobj=io.BytesIO(stage_raw)) as archive:
    staged = {member.name: archive.extractfile(member).read() for member in archive}
staged_index = json.loads(staged['stage-inventory.json'])
assert set(staged_index) == set(staged) - {'stage-inventory.json'}
assert all(sha(staged[name]) == value for name, value in staged_index.items())
for prefix in ['preparation/', 'execution/']:
    for name, raw in staged.items():
        if name.startswith(prefix):
            assert raw == closed['result/' + name]
assert sha(staged['preparation/CONTROLS_SHA256.json']) == '6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52'
assert sha(staged['independent-review.json']) == '6877e7c6b96e1eb31f8f6ba342592caa60be85da1b94e82cdb1973109b0c5391'
assert staged['root-final-review.json'] == files['local-controls/fluxnet-calibration-score-oo-root-final-review.json']
for name, raw in files.items():
    if name.endswith('.py'):
        ast.parse(raw)
index = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
target = OUT / 'fluxnet-calibration-score-oo-evidence.tar.gz'
manifest = OUT / 'fluxnet-calibration-score-oo-package.json'
assert not target.exists() and not manifest.exists(), 'Never overwrite completed evidence'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive}
assert restored == files
record = dict(label='fluxnet-calibration-score-oo', archive=target.name, sha256=sha(target.read_bytes()),
    bytes=target.stat().st_size, artifacts=len(files), artifact_sha256={name: sha(raw) for name, raw in files.items()},
    actual_job='1599.manager', actual_state='F', actual_parent_returncode=0, tests=28,
    unittest_parent_returncode=0, diagnostic_parent_returncode=0, actual_test_seconds=receipt['actual_test_seconds'],
    actual_worker_seconds=receipt['seconds'],
    maximum_decimal_oracle_absolute_difference=diagnostic['maximum_decimal_oracle_absolute_difference'],
    maximum_ON_population_identity_absolute_difference=diagnostic['maximum_ON_population_identity_absolute_difference'],
    synthetic_objective_absolute_difference=diagnostic['objective_absolute_difference'],
    real_original_ON_archive_read=True, reference_cells=12, original_reference_months=144,
    objective_family_weights=diagnostic['family_weights'], preparation_manifest_sha256=receipt['preparation_manifest_sha256'],
    execution_manifest_sha256=receipt['execution_manifest_sha256'], production_scoring_enabled=False,
    model_executed=False, GPU_executed=False, actual_candidate_score_produced=False,
    own_parameter_spinup_executed=False, calibrated=False,
    scope='Actual EHPC scorer mathematics/oracle/synthetic native packet tests and true original ON observation integration. All diagnostic predictions are synthetic. Final physical run/delivery, initialization, own-parameter spinup and total execution budget remain separate; no candidate, calibration, station acceptance or release claim.')
manifest.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['label', 'sha256', 'bytes', 'artifacts', 'actual_job', 'tests',
    'maximum_decimal_oracle_absolute_difference', 'maximum_ON_population_identity_absolute_difference',
    'synthetic_objective_absolute_difference', 'production_scoring_enabled']}, indent=2))

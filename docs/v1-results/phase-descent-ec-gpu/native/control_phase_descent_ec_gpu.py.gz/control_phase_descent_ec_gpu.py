from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-descent-ec-gpu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());m=json.loads((s/'SOURCE_SHA256.json').read_text())
while True:
    receipt=b/'phase-descent-ec-full-receipt.json';terminal=b/'phase-descent-ec-pbs-exit.txt'
    if receipt.exists() and terminal.exists():
        d=json.loads(receipt.read_text());assert terminal.read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1120,failures=0,errors=0,skipped=0) and d['source_manifest_sha256']==meta['manifest_sha256'];(r/'cpu-full-receipt.json').write_bytes(receipt.read_bytes());(r/'cpu-pbs-exit.txt').write_bytes(terminal.read_bytes());break
    (r/'waiting-cpu.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='DU ownsource1120 actualPBS0 required before GPUcollection/execution'))+'\n');time.sleep(20.)
def available():
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:return
        (r/'waiting-resource.json').write_text(json.dumps(dict(gpu_free_mib=free,host_available_kib=mem,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n');time.sleep(20.)
available();start=time.monotonic()
with (r/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(r/'collect_phase_descent_ec_gpu.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0;collection=json.loads((r/'collection.json').read_text());assert collection['passed'] and collection['source_unchanged'];records=[]
for name in ['test_gpu_canopy_phase_weak_descent.py']:
    available();nodes=[Path(n.split('::')[0]).name+'::'+n.split('::',1)[1] for n in collection['nodes'] if n.split('::')[0]=='tests/'+name];assert nodes
    if name=='test_gpu_canopy_phase_weak_descent.py':assert len(nodes)==3
    stem=Path(name).stem;expected=r/(stem+'-expected.json');expected.write_text(json.dumps(nodes,indent=2)+'\n');cmd=[sys.executable,'-u',str(r/'phase_descent_ec_worker.py'),'--source',str(s),'--test-file',str(s/'tests'/name),'--expected',str(expected),'--receipt',str(r/(stem+'-receipt.json')),'--xml',str(r/(stem+'.xml'))];begun=time.monotonic()
    with (r/(stem+'.log')).open('x') as log:p=subprocess.Popen(cmd,cwd=s,stdout=log,stderr=subprocess.STDOUT)
    (r/'progress.json').write_text(json.dumps(dict(active_file=name,pid=p.pid,records=records),indent=2)+'\n');code=p.wait();path=r/(stem+'-receipt.json');d=json.loads(path.read_text()) if path.exists() else {};passed=bool(code==0 and d.get('passed') and d.get('source_unchanged') and d.get('node_coverage_exact') and d.get('all_setup_call_teardown_phases_passed') and d.get('counts')==dict(tests=len(nodes),failures=0,errors=0,skipped=0) and all(v['status']=='complete' for v in d.get('device_barriers',[])));row=dict(file=name,pid=p.pid,passed=passed,actual_parent_returncode=code,seconds=time.monotonic()-begun,receipt_sha256=sha(path) if path.exists() else None);records.append(row);print(json.dumps(row),flush=True)
    if not passed:break
good=len(records)==1 and all(q['passed'] for q in records);unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(returncode=0 if good and unchanged else 1,passed=good and unchanged,records=records,seconds=time.monotonic()-start,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),scope='ActualDU newnativephase3 after ownsource1120actualPBS0, preferredphysical1. Originalpytest/node/allphases/XML/barriers/source/1e-6/int/science/parcelgates. Canonical1521 collectiononly; originalphase/surface/full401/annual/spinup/scienceacceptance pending.');(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');raise SystemExit(d['returncode'])

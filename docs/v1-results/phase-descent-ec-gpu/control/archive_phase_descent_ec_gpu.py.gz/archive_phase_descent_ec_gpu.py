from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-descent-ec-gpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'exit.json').read_text());receipt=json.loads((r/'test_gpu_canopy_phase_weak_descent-receipt.json').read_text());s=Path(json.loads((r/'source-location.json').read_text())['source']);m=json.loads((s/'SOURCE_SHA256.json').read_text())
assert d['returncode']==0 and d['passed'] and d['source_unchanged'] and len(d['records'])==1 and d['records'][0]['actual_parent_returncode']==0
assert receipt['counts']==dict(tests=3,failures=0,errors=0,skipped=0) and receipt['source_unchanged'] and receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed']
assert receipt['source_manifest_sha256']==d['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
assert len(m)==571 and all(sha(s/n)==h for n,h in m.items()) and sha(r/'test_gpu_canopy_phase_weak_descent.xml')==receipt['xml_sha256']
assert sha(r/'test_gpu_canopy_phase_weak_descent-receipt.json')==d['records'][0]['receipt_sha256']
items=[(p,'native/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()]
for name in ['phase-descent-ec-full-receipt.json','phase-descent-ec-pbs-exit.txt',Path(__file__).name]:items.append((b/name,'control/'+name))
a=b/'phase-descent-ec-gpu-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
r, s = b / 'qia-stem-device-day-a', b / 'p6-stem-split-f'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads((r / 'receipt.json').read_text())
exit = json.loads((r / 'exit.json').read_text())
report = json.loads((r / 'trajectory/batch.json').read_text())
assert exit['returncode'] == 0 and exit['passed'] and sha(r / 'receipt.json') == exit['receipt_sha256']
assert d['failure'] is None and d['source_unchanged'] and d['device_barriers'] == ['jax-complete', 'cupy-complete']
assert d['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') == 'f03e43577ba6c0a2c38f3f19f292f868e5075cf14af94b917c48c5ebe304610e'
assert report['steps_completed'] == 48 and report['steps_requested'] == 17520 and report['status'] == 'running'
assert d['result']['actual_steps'] == 48 and d['result']['same_precision_maximum_absolute'] == 3.637978807091713e-12
assert all(v['bias_pass'] for v in d['result']['metrics'].values()) and d['result']['instantaneous_flux_criteria_met']
assert sha(r / 'trajectory/batch.json') == d['result']['device_report_sha256']
assert sha(r / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
for case, desc in report['case_reports'].items():
    p = r / 'trajectory' / case / desc['file']
    assert sha(p) == desc['sha256']
    c = json.loads(p.read_text())
    assert sha(p.parent / c['model_npz']) == c['model_npz_sha256']
a = b / 'qia-stem-device-day-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file() and p.relative_to(r).parts[0] != 'numpy-reference':
            t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    for name in ['run_qia_stem_device_day_a.py', 'control_qia_stem_device_day_a.py', 'launch_qia_stem_device_day_a.py', 'archive_qia_stem_device_day_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    t.add(s / 'SOURCE_SHA256.json', arcname='SOURCE_SHA256.json', recursive=False)
    summary = dict(scope='Actual original frozen506F independent CUDA32/JAX32 Qia first48 completed,allraw per-step1e-6 and original independent primary/shadow MHCN checks,EHPC NumPy48 comparison. Both barriers,controller/worker0,normal interpreter atexit unvalidated. Original17520 request remains,firstday only. Does not credit current510 canonical1250 or newer509C/510 full-year precision/science/spinup.',
                   source_manifest_sha256=d['source_manifest_sha256'], actual_controller_and_worker_returncode=0,
                   receipt_sha256=sha(r / 'receipt.json'), original_requested_steps=17520, actual_steps=48,
                   seconds=d['seconds'], same_precision_max_absolute=d['result']['same_precision_maximum_absolute'],
                   maximum_cumulative_m_h_c_n=d['result']['maximum_cumulative_m_h_c_n'], metrics=d['result']['metrics'],
                   numpy_reference_archive_sha256='a7dfdd99e9258a626047d9361a63020563961395ef42470c53caeae9a30382b5')
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, seconds=d['seconds'],
                      same_precision_max_absolute=summary['same_precision_max_absolute'],
                      main_metrics={k: {n: v[n] for n in ['relative_bias', 'absolute_bias', 'r', 'bias_pass']} for k, v in d['result']['metrics'].items() if k in ['h_wm2', 'le_wm2', 'et_mm']})))

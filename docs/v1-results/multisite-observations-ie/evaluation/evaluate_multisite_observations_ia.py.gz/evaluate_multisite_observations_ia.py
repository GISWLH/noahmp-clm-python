"""Read-only FLUXNET evaluation of every declared current-source reference case."""
from pathlib import Path
from datetime import datetime
import hashlib
import io
import json
import math
import os
import sys
import tarfile
import time
import traceback
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-observations-ia'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
file_sha = lambda p: sha(Path(p).read_bytes())
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert file_sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = file_sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(file_sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner
from evaluate_fluxnet_series import evaluate, PRODUCTS, CARBON_G_PER_UMOL
from fluxnet_soil_operator import initial_soil_from_manifest, soil_products
from noahmp_clm.validation import compare_series

full = json.loads((base / 'soil-stress-coupled-fl-cpu/full-receipt.json').read_text())
assert full['returncode'] == 0 and full['source_unchanged'] and full['source_manifest_sha256'] == source_sha
assert full['counts'] == dict(tests=1148, failures=0, errors=0, skipped=0)
audit = base / 'climatology-cold-audit-gp'
assert (audit / 'pbs-exit.txt').read_text().strip() == '0'
assert json.loads((audit / 'receipt.json').read_text())['passed']
plan = json.loads((root / 'plan.json').read_text())
assert plan['source_manifest_sha256'] == source_sha and len(plan['cohorts']) == 2
begun = time.monotonic()
failure = None
rows = []


def snapshot(folder):
    """Copy one atomically published trace without blocking or changing a writer."""
    for attempt in range(4):
        try:
            raw = (folder / 'report.json').read_bytes()
            report = json.loads(raw)
            path = folder / report['model_npz']
            assert path.resolve().parent == folder.resolve() and not path.is_symlink()
            trace = path.read_bytes()
            if (folder / 'report.json').read_bytes() != raw or sha(trace) != report['model_npz_sha256']:
                time.sleep(.05)
                continue
            return raw, report, trace
        except FileNotFoundError:
            if attempt == 3:
                raise
            time.sleep(.05)
    raise RuntimeError('No stable published snapshot in four read-only attempts')


def independent_period_checks(result, model, observed, dt):
    """Check integrals from raw interval data, including all filled references."""
    count = 0
    labels = np.asarray(model['time_start'], str)
    for frequency, width in [('daily', 8), ('monthly', 6)]:
        for date, records in result[frequency].items():
            key = date.replace('-', '')
            selected = np.flatnonzero(np.asarray([x[:width] == key for x in labels]))
            for field, (name, _, carbon) in PRODUCTS.items():
                record = records[field]
                if 'model_integral' not in record:
                    continue
                actual = np.asarray(model[name], float)[selected]
                expected = np.asarray(observed['obs_' + field], float)[selected]
                actual_sum = math.fsum(map(float, actual)) * (1. if carbon else dt)
                expected_sum = math.fsum(map(float, expected)) * dt * (CARBON_G_PER_UMOL if carbon else 1.)
                assert math.isclose(actual_sum, record['model_integral'], rel_tol=1e-12, abs_tol=1e-9)
                assert math.isclose(expected_sum, record['reference_integral'], rel_tol=1e-12, abs_tol=1e-9)
                count += 1
    return count


try:
    for cohort in plan['cohorts']:
        inputs = Path(os.environ['TMPDIR']) / cohort['name']
        inputs.mkdir()
        package = base / cohort['input_archive']
        assert file_sha(package) == cohort['input_archive_sha256']
        with tarfile.open(package) as tf:
            tf.extractall(inputs, filter='data')
        year_root = base / cohort['year_root']
        year_plan_raw = (year_root / 'plan.json').read_bytes()
        year_plan = json.loads(year_plan_raw)
        assert year_plan['source_manifest_sha256'] == source_sha and len(year_plan['cases']) == 12
        target = root / cohort['name']
        target.mkdir()
        (target / 'reference-plan.json').write_bytes(year_plan_raw)
        for case in year_plan['cases']:
            name = case['case']
            raw, report, trace = snapshot(year_root / name / 'trajectory')
            assert report['source_unchanged'] and report['source_sha256'] == runner.source_hashes()
            assert report['status'] in ['running', 'complete', 'failed'] and report['steps_requested'] == 17520
            assert report['configuration_sha256'] == case['configuration_sha256'] == file_sha(inputs / case['configuration'])
            assert report['configuration'] == json.loads((inputs / case['configuration']).read_text())
            original = inputs / case['input']
            observed_manifest = json.loads((inputs / case['input_manifest']).read_text())
            assert file_sha(original) == report['forcing_npz_sha256'] == observed_manifest['prepared_npz_sha256']
            assert file_sha(inputs / case['input_manifest']) == report['forcing_manifest_sha256']
            assert report['utc_offset_hours'] == observed_manifest['utc_offset_hours']
            folder = target / name
            folder.mkdir()
            (folder / 'model-report.json').write_bytes(raw)
            (folder / 'model-trace.npz').write_bytes(trace)
            (folder / 'observation-manifest.json').write_bytes((inputs / case['input_manifest']).read_bytes())
            operator_path = base / 'height-observations-ea' / (report['site'] + '-soil-operator.json')
            operator_raw = operator_path.read_bytes()
            assert sha(operator_raw) == plan['soil_operator_sha256'][report['site']]
            (folder / 'soil-operator.json').write_bytes(operator_raw)
            row = dict(cohort=cohort['name'], case=name, site=report['site'], status=report['status'],
                       steps_completed=report['steps_completed'], steps_requested=17520,
                       original_report_sha256=sha(raw), original_trace_sha256=sha(trace))
            if report['status'] == 'failed':
                row.update(evaluation_delivered=False, reason='Actual failed trajectory preserved; no failed-prefix continuation or acceptance')
                rows.append(row)
                continue
            with np.load(io.BytesIO(trace), allow_pickle=False) as z:
                model = dict(z)
            with np.load(original, allow_pickle=False) as z:
                observed = dict(z)
            runner.validate_input(observed, observed_manifest, original)
            n = report['steps_completed']
            assert n == len(model['time_start']) and n % 48 == 0
            observed = {key: value[:n] for key, value in observed.items()}
            initial = initial_soil_from_manifest(report)
            operator = json.loads(operator_raw)
            assert operator['site'] == report['site']
            result = evaluate(model, observed, utc_offset_hours=report['utc_offset_hours'],
                              soil_operator=operator, initial_soil=initial)
            checks = independent_period_checks(result, model, observed, result['dt_seconds'])
            year = str(model['time_start'][0])[:4]
            assert str(model['time_start'][0]) == year + '01010000'
            for month in range(1, 13):
                key = year + '-' + str(month).zfill(2)
                if key not in result['monthly']:
                    result['monthly'][key] = {field: dict(metrics=dict(status='unmeasured', bias_pass=None,
                        correlation_pass=None, reason='Future model intervals unavailable at this frozen snapshot'))
                        for field in result['instantaneous']}
            annual = {}
            if report['status'] == 'complete' and n == 17520:
                prepared = {}
                for field, (key, unit, carbon) in PRODUCTS.items():
                    a = model[key] * (86400. / result['dt_seconds'] if carbon else 1.)
                    b = observed['obs_' + field] * (CARBON_G_PER_UMOL * 86400. if carbon else 1.)
                    prepared[field] = (a, b, None, unit, None)
                prepared.update(soil_products(model, observed, initial, operator)[0])
                for field, (a, b, _, unit, _) in prepared.items():
                    annual[field] = compare_series(a, b, unit) if np.all(np.isfinite(b)) else dict(
                        status='unmeasured', bias_pass=None, correlation_pass=None, reason='Missing reference intervals')
            else:
                annual = dict(status='unmeasured', bias_pass=None, correlation_pass=None,
                              reason='Original 17520-step year request not complete')
            result.update(annual=annual, original_report_status=report['status'], original_steps_requested=17520,
                          snapshot_steps=n, source_manifest_sha256=source_sha,
                          original_report_sha256=sha(raw), original_trace_sha256=sha(trace),
                          forcing_sha256=report['forcing_npz_sha256'], configuration_sha256=report['configuration_sha256'],
                          independent_raw_integral_checks=checks, scope=plan['scope'])
            text = (json.dumps(result, indent=2, allow_nan=False) + '\n').encode()
            (folder / 'observations.json').write_bytes(text)
            row.update(evaluation_delivered=True, observations_sha256=sha(text),
                       complete_days=sum(all(q.get('calendar_period_complete', False) for q in values.values())
                                         for values in result['daily'].values()),
                       complete_months=sum(all(q.get('calendar_period_complete', False) for q in values.values())
                                           for values in result['monthly'].values()),
                       independent_raw_integral_checks=checks)
            rows.append(row)
except Exception as exc:
    failure = type(exc).__name__ + ': ' + str(exc)
    (root / 'traceback.txt').write_text(traceback.format_exc())
    print(traceback.format_exc(), flush=True)

receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
               evaluation_delivered=failure is None and len(rows) == 24, failure=failure, cases=rows,
               source_manifest_sha256=source_sha,
               source_unchanged=all(file_sha(source / name) == digest for name, digest in manifest.items()),
               seconds=time.monotonic() - begun, scope=plan['scope'])
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
print(json.dumps(receipt), flush=True)
assert receipt['evaluation_delivered'] and receipt['source_unchanged']

from pathlib import Path
import hashlib,json,re,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'multisite-observations-summary-ib'
prior=b/'multisite-observations-ia'
status=subprocess.check_output(['qstat','-xf','1170.manager'],text=True)
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and json.loads((prior/'receipt.json').read_text())['evaluation_delivered']
assert not r.exists();r.mkdir();controls={}
for name in ['summarize_multisite_observations_ib.py','multisite_observations_summary_ib.pbs']:
 raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
(r/'parent-actual-qstat.txt').write_text(status)
p=subprocess.run(['qsub',str(r/'multisite_observations_summary_ib.pbs')],cwd=r,capture_output=True,text=True)
assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),parent_actual_pbs='1170.manager',parent_actual_exit=0,controls_sha256=controls,scope='All24 immutable publishedIA reference snapshots, allcompletecalendar months and originalrawintegrals, no model/default/QC/split/source/gate changes.')
(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))

"""Monthly instantaneous QC0 correlations on exactly the same complete months."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-monthly-qc-ic'
ha = base / 'multisite-observations-ia'
hb = base / 'multisite-observations-summary-ib'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert (ha / 'pbs-exit.txt').read_text().strip() == (hb / 'pbs-exit.txt').read_text().strip() == '0'
summary = json.loads((hb / 'summary.json').read_text())
receipt = json.loads((hb / 'receipt.json').read_text())
assert receipt['passed'] and sha(hb / 'summary.json') == receipt['summary_sha256']
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == summary['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
from evaluate_fluxnet_series import evaluate
from fluxnet_soil_operator import initial_soil_from_manifest

original_plan=json.loads((ha/'plan.json').read_text())
input_folders={}
for cohort in original_plan['cohorts']:
    inputs=Path(os.environ['TMPDIR'])/cohort['name']
    inputs.mkdir()
    archive=base/cohort['input_archive']
    assert sha(archive)==cohort['input_archive_sha256']
    with tarfile.open(archive) as tf:tf.extractall(inputs,filter='data')
    input_folders[cohort['name']]=inputs
begun = time.monotonic()
rows = []
for case in summary['cases']:
    inputs=input_folders[case['cohort']]
    folder = ha / case['cohort'] / case['case']
    report = json.loads((folder / 'model-report.json').read_text())
    assert sha(folder / 'model-trace.npz') == report['model_npz_sha256']
    assert sha(inputs / (case['site'] + '.npz')) == report['forcing_npz_sha256']
    with np.load(folder / 'model-trace.npz', allow_pickle=False) as z:
        model = dict(z)
    with np.load(inputs / (case['site'] + '.npz'), allow_pickle=False) as z:
        observed = dict(z)
    operator = json.loads((folder / 'soil-operator.json').read_text())
    for date, old in case['complete_calendar_months'].items():
        selected = np.flatnonzero(np.char.startswith(np.asarray(model['time_start'], str), date.replace('-', '')))
        initial = initial_soil_from_manifest(report)
        if selected[0] > 0:
            for key in ['tsoil_k', 'smc_m3m3', 'liquid_m3m3']:
                initial[key] = model[key][selected[0] - 1]
        data = evaluate({k: v[selected] for k, v in model.items()},
            {k: v[selected] for k, v in observed.items()}, utc_offset_hours=report['utc_offset_hours'],
            soil_operator=operator, initial_soil=initial)
        assert list(data['monthly']) == [date]
        assert all(p['calendar_period_complete'] for p in data['monthly'][date].values())
        assert all(data['monthly'][date][name]['metrics'] == product['metrics'] for name, product in old.items())
        rows.append(dict(cohort=case['cohort'], case=case['case'], month=date, intervals=len(selected),
            instantaneous_own_qc0=data['instantaneous'], daily=data['daily'], monthly=data['monthly']))
        print(json.dumps(dict(case=case['case'], month=date,
            metrics={name: data['instantaneous'][name]['metrics'] for name in ['H_F_MDS', 'LE_F_MDS', 'GPP_NT_VUT_REF', 'NEE_VUT_REF']})), flush=True)
result = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True,
    source_manifest_sha256=source_sha, source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    original_summary_sha256=sha(hb / 'summary.json'), complete_case_months=len(rows), case_months=rows,
    seconds=time.monotonic() - begun,
    scope='Exactsamecompletecalendar month meanbias uses originalallfinitefilled products; instantaneous correlation separately uses ownQC0 on exactlythatmonth, GPPallfinitepartitioned product has no inventedQC. Allavailablecase-months retained, no bestcase/date selection or incompleteyear/spinup/observationalacceptance claim. Older monthlymetricsr includedfilled data and was not the separateQC0 instantaneous acceptance statistic.')
(root / 'receipt.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
assert result['source_unchanged']

from pathlib import Path
import hashlib
import json
import subprocess
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-monthly-qc-ic'
assert not root.exists()
root.mkdir()
controls = {}
for name in ['monthly_qc_observations_ic.py', 'monthly_qc_observations_ic.pbs']:
    raw = (base / name).read_bytes()
    assert b'\r\n' not in raw
    (root / name).write_bytes(raw)
    controls[name] = hashlib.sha256(raw).hexdigest()
p = subprocess.run(['qsub', str(root / 'monthly_qc_observations_ic.pbs')], cwd=root, capture_output=True, text=True)
assert p.returncode == 0, p.stderr
record = dict(pbs_job=p.stdout.strip(), controls_sha256=controls,
    scope='Read-only originalIA/IB samecompletecalendar months, originalQC0 instantaneous vs allfinitefilled periodbias separated, no modelsteps or source/gate changes.')
(root / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

from pathlib import Path
import hashlib,json,re,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'multisite-monthly-summary-id';prior=b/'multisite-monthly-qc-ic'
status=subprocess.check_output(['qstat','-xf','1172.manager'],text=True)
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and json.loads((prior/'receipt.json').read_text())['passed']
assert not r.exists();r.mkdir();controls={}
for name in ['summarize_monthly_observations_id.py','multisite_monthly_summary_id.pbs']:
 raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
(r/'parent-actual-qstat.txt').write_text(status)
p=subprocess.run(['qsub',str(r/'multisite_monthly_summary_id.pbs')],cwd=r,capture_output=True,text=True)
assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),parent_actual_pbs='1172.manager',parent_actual_exit=0,controls_sha256=controls)
(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

"""Metadata-only setup of every January-start reference snapshot, no model edits."""
from pathlib import Path
import hashlib
import json
import subprocess

base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-observations-ia'
assert not root.exists()
root.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
controls = {}
for name in ['evaluate_multisite_observations_ia.py', 'multisite_observations_ia.pbs']:
    raw = (base / name).read_bytes()
    assert b'\r\n' not in raw
    (root / name).write_bytes(raw)
    controls[name] = sha(root / name)
cohorts = [dict(name='zero-deposition-control', year_root='multisite-numpy-years-gh',
                input_archive='multisite-spinup-fu-inputs.tar.gz',
                input_archive_sha256='deb7deb3f64b67dde12765be9779414ff444607bfa9dabc8345863c4f41a5775'),
           dict(name='official-climatology', year_root='climatology-numpy-years-gt',
                input_archive='multisite-climatology-gm-inputs.tar.gz',
                input_archive_sha256='b33fba4f80f7cde8a7e127d27694dc7c2e370e7cd8a6b2142db211c86dccba0e')]
scope = ('All24 prespecified IC/BGCmapping/deposition cases, three sites, read-only published NumPyyear snapshots; '
         'sourceFL579 and ownoriginal17520request unchanged. OriginalFLUXNET raw/corrected H/LE, GPPNT/DT/NEE, '
         'ownQC and fixeddepth trapezoidsoiloperators preserved. Every complete day/month reported, missing/partial '
         'months explicitly unmeasured, annual unmeasured until actualfull17520 complete. No bestcase/date selection, '
         'parameter fitting, initialstate reset, model continuation, GPUwork, spinup/holdout/sciencepass or release claim.')
plan = dict(source_manifest_sha256='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69',
            cohorts=cohorts, soil_operator_sha256={site: sha(base / 'height-observations-ea' / (site + '-soil-operator.json'))
                                                for site in ['CN-Cng', 'CN-Qia', 'CN-Cha']},
            controls_sha256=controls, scope=scope)
(root / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
p = subprocess.run(['qsub', str(root / 'multisite_observations_ia.pbs')], cwd=root, capture_output=True, text=True)
assert p.returncode == 0, p.stderr
dispatch = dict(pbs_job=p.stdout.strip(), controls_sha256=controls, plan_sha256=sha(root / 'plan.json'), scope=scope)
(root / 'dispatch.json').write_text(json.dumps(dispatch, indent=2) + '\n')
print(json.dumps(dispatch), flush=True)

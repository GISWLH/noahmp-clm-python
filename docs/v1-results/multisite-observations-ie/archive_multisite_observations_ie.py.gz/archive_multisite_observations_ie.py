from pathlib import Path
import hashlib,json,re,subprocess,tarfile,datetime
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
roots=[('multisite-observations-ia','evaluation','1170.manager'),('multisite-observations-summary-ib','summary','1171.manager'),('multisite-monthly-qc-ic','monthly-own-qc','1172.manager'),('multisite-monthly-summary-id','monthly-summary','1173.manager')]
proof=[]
for name,prefix,job in roots:
 r=b/name;assert (r/'pbs-exit.txt').read_text().strip()=='0'
 raw=subprocess.check_output(['qstat','-xf',job],text=True)
 assert re.search(r'^\s*job_state = F\s*$',raw,re.M) and re.search(r'^\s*Exit_status = 0\s*$',raw,re.M)
 (r/'actual-pbs-qstat.txt').write_text(raw)
 d=json.loads((r/'receipt.json').read_text());assert d.get('passed',d.get('evaluation_delivered'))
 launch=json.loads((r/'dispatch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items())
 proof.append(dict(root=name,pbs_job=job,actual_pbs_exit=0,receipt_sha256=sha(r/'receipt.json')))
ia=b/roots[0][0];ib=b/roots[1][0];ic=b/roots[2][0];identifier=b/roots[3][0]
d=json.loads((ia/'receipt.json').read_text());s=json.loads((ib/'summary.json').read_text());qc=json.loads((ic/'receipt.json').read_text());group=json.loads((identifier/'summary.json').read_text())
assert len(d['cases'])==len(s['cases'])==24 and sum(q['complete_months'] for q in d['cases'])==qc['complete_case_months']==40
assert len(group['groups'])==10 and group['case_months']==40 and group['raw_interval_integral_checks']==10053
for case in d['cases']:
 r=ia/case['cohort']/case['case'];assert sha(r/'model-report.json')==case['original_report_sha256'] and sha(r/'model-trace.npz')==case['original_trace_sha256'] and sha(r/'observations.json')==case['observations_sha256']
 assert case['steps_completed']<case['steps_requested']==17520
archive=b/'multisite-observations-ie-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
 for name,prefix,job in roots:
  for p in sorted((b/name).rglob('*')):
   if p.is_file():
    assert not p.is_symlink();member=prefix+'/'+p.relative_to(b/name).as_posix();inventory[member]=sha(p);tf.add(p,arcname=member,recursive=False)
 for name in ['prepare_multisite_observations_ia.py','prepare_multisite_observations_ib.py','prepare_monthly_qc_ic.py','prepare_multisite_monthly_summary_id.py',Path(__file__).name]:
  inventory[name]=sha(b/name);tf.add(b/name,arcname=name,recursive=False)
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(inventory)
 for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=archive.name,sha256=sha(archive),artifacts=len(inventory),bytes=archive.stat().st_size,actual_completed_jobs=proof,
 source_manifest_sha256=d['source_manifest_sha256'],case_months=40,raw_interval_integral_checks=10053,
 scope='Actual1170-1173F0 all24immutable publishedprefix snapshots and every40completecase-month, bothoriginalcohorts, allproducts/QC0 and statisticalfailures retained. Originalmonths/yearrequests/forcing/config/source/gates unchanged, all24years incomplete, no spinup/observedscience/holdout/calibration/main/tag/release claim.')
(b/'multisite-observations-ie-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
for row in group['groups']:
 compact={}
 for n in ['H_F_MDS','LE_F_MDS','GPP_NT_VUT_REF','NEE_VUT_REF']:
  v=row['fields'][n];compact[n]=dict(rel=v['complete_period_relative_bias_range'],absolute=v['complete_period_absolute_bias_range'],r=v['instantaneous_own_qc0_r_range'],n=v['instantaneous_own_qc0_sample_count_range'],bias_pass=v['complete_period_bias_pass_count'])
 print(json.dumps(dict(cohort=row['cohort'],site=row['site'],month=row['month'],values=compact)))

from pathlib import Path
import collections,hashlib,json,os,time
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'multisite-monthly-summary-id';ic=b/'multisite-monthly-qc-ic';ib=b/'multisite-observations-summary-ib'
assert (ic/'pbs-exit.txt').read_text().strip()=='0'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads((ic/'receipt.json').read_text());summary=json.loads((ib/'summary.json').read_text())
assert d['passed'] and d['source_unchanged'] and d['complete_case_months']==len(d['case_months'])==40
assert sha(ib/'summary.json')==d['original_summary_sha256']
start=time.monotonic();groups=collections.defaultdict(list)
site={q['case']:q['site'] for q in summary['cases']}
for q in d['case_months']:groups[(q['cohort'],site[q['case']],q['month'])].append(q)
def interval(values):
 values=[x for x in values if x is not None]
 return [min(values),max(values)] if values else None
out=[]
for (cohort,station,month),cases in sorted(groups.items()):
 assert len(cases)==4 and len({q['case'] for q in cases})==4
 fields={}
 names=list(cases[0]['monthly'][month])
 assert all(list(q['monthly'][month])==names for q in cases)
 for name in names:
  values=[q['monthly'][month][name]['metrics'] for q in cases]
  instant=[q['instantaneous_own_qc0'][name]['metrics'] for q in cases]
  fields[name]=dict(original_cases=[q['case'] for q in cases],
   complete_period_model_mean_range=interval([q.get('model_mean') for q in values]),
   complete_period_reference_mean_range=interval([q.get('reference_mean') for q in values]),
   complete_period_relative_bias_range=interval([q.get('relative_bias') for q in values]),
   complete_period_absolute_bias_range=interval([q.get('absolute_bias') for q in values]),
   complete_period_near_zero=[q.get('near_zero') for q in values],
   complete_period_bias_pass_count=sum(q.get('bias_pass') is True for q in values),
   complete_period_measured_count=sum(q['status']=='measured' for q in values),
   instantaneous_own_qc0_sample_count_range=interval([q.get('n') for q in instant]),
   instantaneous_own_qc0_r_range=interval([q.get('r') for q in instant]),
   instantaneous_own_qc0_correlation_pass_count=sum(q.get('correlation_pass') is True for q in instant),
   instantaneous_unmeasured_count=sum(q['status']=='unmeasured' for q in instant))
 out.append(dict(cohort=cohort,site=station,month=month,cases=4,fields=fields))
value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,groups=out,case_months=40,
 all_original_cases=24,source_manifest_sha256=d['source_manifest_sha256'],original_qc_receipt_sha256=sha(ic/'receipt.json'),
 original_summary_sha256=sha(ib/'summary.json'),raw_interval_integral_checks=summary['original_raw_interval_integral_checks'],
 seconds=time.monotonic()-start,scope='Every one of40 actuallycomplete case-months, grouped only across four fixedIC/BGCmapping cases at identical fullcalendarmonth/cohort/site. All products retained, periodbias on originalfilled products distinct from ownQC0 instantaneousr; no scores/parameters/dates/QC/split/forcings selected or changed. EightQia prefixes have no completemonth; all24 originalyearrequests remain incomplete, no spinup/wholeyear/sciencepass claim.')
(r/'summary.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
(r/'receipt.json').write_text(json.dumps(dict(pbs_job=value['pbs_job'],node=value['node'],passed=True,summary_sha256=sha(r/'summary.json'),source_manifest_sha256=value['source_manifest_sha256'],case_months=40,groups=len(out)),indent=2)+'\n')
for q in out:
 print(json.dumps(dict(cohort=q['cohort'],site=q['site'],month=q['month'],fields={name:q['fields'][name] for name in ['H_F_MDS','LE_F_MDS','GPP_NT_VUT_REF','NEE_VUT_REF']})),flush=True)

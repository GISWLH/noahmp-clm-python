from pathlib import Path
import dataclasses
import hashlib
import inspect
import json
import os
import pickle
import sys
import tarfile
import time
import traceback

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia735-numpy-probe-a'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(a) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == h for n, h in manifest.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'tests'), str(s / 'benchmarks')]
import run_fluxnet_column as driver
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-fresh-phase-numpy-year-b'
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert (old / 'pbs-exit.txt').read_text().strip() == '1' and receipt['returncode'] == 1 and receipt['source_unchanged']
assert report['status'] == 'failed' and report['steps_completed'] == report['failed_index'] == 735
assert sha(old / 'trajectory/report.json') == receipt['report_sha256']
checkpoint = old / 'trajectory' / report['checkpoint_file']
assert sha(checkpoint) == report['checkpoint_sha256']
assert json.loads((old / 'SOURCE_SHA256.json').read_text()) == manifest
inputs = b / 'qia-stem-inputs-a/inputs'
config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
metadata = json.loads((inputs / 'CN-Qia.json').read_text())
assert sha(inputs / 'CN-Qia.npz') == report['forcing_npz_sha256'] and sha(inputs / 'CN-Qia-stem-config.json') == report['configuration_sha256']
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    data = dict(z)
stamps = driver.validate_input(data, metadata, inputs / 'CN-Qia.npz')
f = driver.Forcing(*data['forcing'][735]); co2, mu, diffuse = data['environment'][735]
schedule = driver.DepositionSchedule(config)
dep = schedule.aerosol(stamps[735], f.dt); nitrogen = schedule.nitrogen_rate * f.dt
geometry = driver.MOSTGeometry(**config['most_geometry']); leaf = driver.LeafParameters(**config['leaf_parameters'])
original = phase.solve_canopy_phase_energy
source = inspect.getsource(original)
marker = 'if phase_active[k] and mass[k]==0. and delta[k]!=0.:'
assert source.count(marker) == 1
candidate = source.replace(marker, 'if phase_active[k] and delta[k]!=0.:')
namespace = dict(original.__globals__); exec(compile(candidate, '<isolated NumPy general-phase-edge F on735>', 'exec'), namespace)
(r / 'solver-candidate.py').write_text(candidate)


def encode(value):
    if dataclasses.is_dataclass(value):
        return dict(__type__=type(value).__name__, data={field.name: encode(getattr(value, field.name)) for field in dataclasses.fields(value)})
    if isinstance(value, np.ndarray):
        return dict(__array__=encode(value.tolist()), dtype=str(value.dtype))
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    if isinstance(value, (float, np.floating)) and not np.isfinite(value):
        return dict(__float__=str(value))
    if isinstance(value, np.generic):
        return value.item()
    return value


records = []
for label, solver in [('original', original), ('general-edge-F', namespace['solve_canopy_phase_energy'])]:
    folder = r / label; folder.mkdir()
    state, initial, net, bounds, maximum, stepmax, index = pickle.loads(checkpoint.read_bytes())
    assert index == 735
    calls, last = [], {}
    def observe(*args, **kwargs):
        last.clear(); last.update(args=args, kwargs={k: v for k, v in kwargs.items() if k != 'initial_guess'}, initial_guess=kwargs.get('initial_guess'))
        try:
            value = solver(*args, **kwargs)
        except Exception:
            (folder / 'rejected-phase-call.json').write_text(json.dumps(dict(scope='Exact last phase call before unchanged production735 failure;typed original arrays/stores/solver guess and controls,no fictitious accepted state.', call=encode(last)), indent=2, allow_nan=False) + '\n')
            raise
        calls.append(dict(iterations=value['iterations'], residual=float(np.max(abs(value['solver_residual'])))))
        return value
    phase.solve_canopy_phase_energy = observe
    start, failure, result = time.monotonic(), None, None
    try:
        after, out = driver.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse),
              leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry,
              phenology_environment=driver.calendar(stamps[735], metadata, config['phenology'] is not None), deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
        incoming, residual, bound = driver.audit_step(state, after, f, out, nitrogen)
        cumulative = driver.totals(after) - initial - (net + incoming)
        assert np.all(abs(cumulative) <= bounds + bound)
        (folder / 'diagnostic-step736.pkl').write_bytes(pickle.dumps((state, after, f, out)))
        result = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bound=bound.tolist(), cumulative_residual=cumulative.tolist(), original_cumulative_bound=(bounds + bound).tolist(),
                      diagnostics={k: float(out[v]) for k, v in driver.TRACE.items()})
    except Exception as e:
        failure = type(e).__name__ + ': ' + str(e); (folder / 'traceback.txt').write_text(traceback.format_exc())
    finally:
        phase.solve_canopy_phase_energy = original
    records.append(dict(label=label, failure=failure, result=result, completed_phase_calls=calls, seconds=time.monotonic() - start))
record = dict(scope='Actual EHPC PBS exact original735 failed NumPy full-step replay,original510 source/80/tol1e-7 and independent MHCN guards. Original and isolated F general-phase-edge comparison only;no production source or failedyear continuation. Every outcome retained.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, original_failed_checkpoint_sha256=sha(checkpoint), original_report_sha256=sha(old / 'trajectory/report.json'),
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == h for n, h in manifest.items()), records=records)
(r / 'comparison.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({**record, 'records': [{k: v for k, v in row.items() if k != 'completed_phase_calls'} for row in records]}, allow_nan=False), flush=True)

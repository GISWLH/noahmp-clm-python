from pathlib import Path
import hashlib
import inspect
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia735-reference-fixture-a'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
archive = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(archive) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(archive) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'tests')]
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.physics import canopy_phase_energy as phase
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters

original = phase.solve_canopy_phase_energy
code = inspect.getsource(original)
marker = 'if phase_active[k] and mass[k]==0. and delta[k]!=0.:'
assert code.count(marker) == 1
candidate = code.replace(marker, 'if phase_active[k] and delta[k]!=0.:')
namespace = dict(original.__globals__); exec(compile(candidate, '<isolated NumPy all-phase-edge reference>', 'exec'), namespace)
phase.solve_canopy_phase_energy = namespace['solve_canopy_phase_energy']
from test_canopy_phase_energy import independent_reference
from test_gpu_canopy_phase_energy import reference as quantized_reference

registry = {c.__name__: c for c in [CanopyExchange, CanopyCondensate, SoilWaterSupply, LeafParameters, Snowpack]}


def decode(value):
    if isinstance(value, list):
        return [decode(v) for v in value]
    if not isinstance(value, dict):
        return value
    if '__type__' in value:
        return registry[value['__type__']](**decode(value['data']))
    if '__array__' in value:
        return np.asarray(decode(value['__array__']), dtype=value['dtype'])
    if '__float__' in value:
        return float(value['__float__'])
    return {k: decode(v) for k, v in value.items()}


def encode(value):
    if isinstance(value, np.ndarray):
        return dict(__array__=encode(value.tolist()), dtype=str(value.dtype))
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (float, np.floating)) and not np.isfinite(value):
        return dict(__float__=str(value))
    if isinstance(value, np.generic):
        return value.item()
    return value


p = b / 'qia735-numpy-probe-a/original/rejected-phase-call.json'
raw = json.loads(p.read_text()); saved = decode(raw['call'])
args, kw = saved['args'], saved['kwargs']
assert kw['tolerance'] == 1e-7 and 'max_iterations' not in kw
solve = phase.solve_canopy_phase_energy
got = solve(*args, **kw, initial_guess=saved['initial_guess'])
independent = independent_reference(*args, **kw)
differences = {}
for name in ['h', 'le', 'gpp']:
    differences[name] = float(abs(got[name] - independent[name]))
    absolute, near = (.01, .1) if name == 'gpp' else (1., 10.)
    assert differences[name] <= (absolute if abs(independent[name]) <= near else .1 * abs(independent[name]))
temperature = float(np.max(abs(np.r_[got['leaf_temperature'], got['ground_temperature']] - independent['temperature'])))
assert temperature <= .05
assert np.max(abs(got['solver_residual'])) <= 1e-7 and np.max(abs(got['layer_residual'])) <= 1.01e-7
np.testing.assert_allclose(got['condensate'].mass + args[5] * got['wet_evaporation'], args[4].mass, rtol=0., atol=1e-14)
assert vars(kw['leaf_parameters']) == vars(LeafParameters()), 'Quantized reference helper uses explicit original generic traits only'
pack_kw = {k: v for k, v in kw.items() if k not in ['tolerance', 'max_iterations', 'leaf_parameters']}
quantized = {}
for name, dtype in [('32', np.float32), ('64', np.float64)]:
    arrays = pack_canopy_phase(*args, **pack_kw, dtype=dtype)
    extension = np.asarray([args[3].water_velocity, args[3].heat_temperature], dtype)
    target = quantized_reference(arrays, exchange_extension=extension, tolerance=1e-7, max_iterations=80)
    quantized[name] = dict(arrays=encode(arrays), extension=encode(extension), parameters=encode(pack_leaf_parameters(kw['leaf_parameters'], dtype)),
                         reference={key: encode(target[key]) for key in ['leaf_temperature', 'ground_temperature', 'canopy_temperature', 'h', 'le', 'gpp', 'ground_heat']},
                         reference_mass=encode(target['condensate'].mass), reference_enthalpy=encode(target['condensate'].enthalpy))
record = dict(scope='Actual original735 rejected phase call,original warm guess/stores/controls,reference computed on EHPC PBS only. Original510 full-step failure retained;isolated all-phase-edge F closes original1e-7/80 and independent SciPy equations within declared10percent/nearzero/.05K. Quantized32/64 inputs and NumPy references use explicit MOST water/potential-temperature extension,no GPU or local numerical execution.',
              original_rejected_call_sha256=sha(p), call=raw['call'], source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              independent_reference={key: encode(independent[key]) for key in ['temperature', 'h', 'le', 'gpp', 'residual']},
              independent_temperature_difference_K=temperature, independent_flux_absolute_differences=differences,
              actual_reference_iterations=got['iterations'], actual_reference_max_residual=float(np.max(abs(got['solver_residual']))), quantized=quantized)
path = r / 'qia_735_phase_oldwet.json'
path.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
assert all(sha(s / n) == h for n, h in m.items())
(r / 'receipt.json').write_text(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, fixture_sha256=sha(path), source_unchanged=True,
        independent_temperature_difference_K=temperature, independent_flux_absolute_differences=differences, reference_iterations=got['iterations']), indent=2) + '\n')
print((r / 'receipt.json').read_text(), flush=True)

"""Exactly QK's27 known-source caches: read-only guard and binary tar stdout."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

EXPECTED=None
BASE=Path('/home/zhangyq/noahmp-v1')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def safe(p):
    p=Path(p);assert p.is_absolute() and p.is_relative_to(BASE) and p.resolve(strict=True)==p
    for q in [p,*p.parents]:
        if not q.is_relative_to(BASE):break
        assert not q.is_symlink()
    return p
def processes(roots):
    refs=[];unreadable=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            if os.getuid()!=0 and p.stat().st_uid!=os.getuid():continue
            links=[p/'cwd']
            try:links.extend((p/'fd').iterdir())
            except OSError:unreadable.append(int(p.name))
            for link in links:
                try:t=Path(os.readlink(str(link)).removesuffix(' (deleted)'))
                except OSError:continue
                if any(t==r or r in t.parents for r in roots):refs.append(dict(pid=int(p.name),handle=str(link.relative_to(p)),target=str(t)))
        except OSError:continue
    return dict(references=refs,unreadable_processes=unreadable,all_UIDs_if_root=os.getuid()==0)
def guard():
    assert len(EXPECTED['caches'])==27 and EXPECTED['regular_files']==117 and EXPECTED['directories']==81
    assert all(c['all_known_manifests_exclude_cache'] for c in EXPECTED['caches'])
    roots=[safe(c['source_root']) for c in EXPECTED['caches']];proc=processes(roots);assert not proc['references'],proc
    records={};members=[]
    for c in EXPECTED['caches']:
        root=safe(c['path']);assert root.name=='.pytest_cache' and root.parent.name!='p6-soil-freezing-numpy-a' and c['source_root']==str(root.parent)
        actual=[]
        for r,ds,fs in os.walk(str(root),followlinks=False):
            assert all(not (Path(r)/n).is_symlink() for n in ds)
            actual.extend([Path(r),*[Path(r)/n for n in fs]])
        assert {str(p.relative_to(BASE)) for p in actual}=={m['path'] for m in c['members']}
        for m in c['members']:
            p=safe(BASE/m['path']);s=p.lstat();kind='file' if stat.S_ISREG(s.st_mode) else ('directory' if stat.S_ISDIR(s.st_mode) else 'other')
            assert kind==m['kind'] and (s.st_ino,s.st_nlink,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode),s.st_mtime_ns)==(m['inode'],m['nlink'],m['uid'],m['gid'],m['mode'],m['mtime_ns'])
            if kind=='file':assert s.st_nlink==1 and s.st_size==m['bytes'] and sha(p.read_bytes())==m['sha256']
            attrs={n:base64.b64encode(os.getxattr(str(p),n,follow_symlinks=False)).decode() for n in os.listxattr(str(p),follow_symlinks=False)}
            members.append(dict(m,xattrs_base64=attrs))
        assert len(c['manifest_checks'])==1;manifest_path=safe(c['manifest_checks'][0]['path']);raw=manifest_path.read_bytes();assert sha(raw)==c['manifest_checks'][0]['sha256']
        manifest=json.loads(raw);assert '.pytest_cache' not in json.dumps(manifest)
        missing=[];existing={}
        for name,expected in manifest.items():
            p=root.parent/name;assert p.is_relative_to(BASE) and '..' not in Path(name).parts
            if not p.is_file() or p.is_symlink():missing.append(name)
            else:existing[name]=dict(sha256=sha(p.read_bytes()),manifest_sha256=expected)
        records[c['source_root']]=dict(manifest_path=str(manifest_path),manifest_sha256=sha(raw),manifest_base64=base64.b64encode(raw).decode(),source_missing_entries=missing,source_existing_hashes=existing,full_source_matches_original=not missing and all(v['sha256']==v['manifest_sha256'] for v in existing.values()),cache_explicitly_not_in_manifest=True)
    return dict(cache_members=members,sources=records,readable_process_snapshot=proc)
def main():
    checked=guard();content=io.BytesIO()
    with tarfile.open(fileobj=content,mode='w',format=tarfile.PAX_FORMAT) as t:
        for m in checked['cache_members']:
            raw=(BASE/m['path']).read_bytes() if m['kind']=='file' else b''
            if m['kind']=='file':assert sha(raw)==m['sha256']
            info=tarfile.TarInfo(m['path']);info.type=tarfile.DIRTYPE if m['kind']=='directory' else tarfile.REGTYPE;info.size=len(raw);info.mode=m['mode'];info.uid=m['uid'];info.gid=m['gid'];info.mtime=m['mtime_ns']//1000000000;info.pax_headers['mtime']=str(m['mtime_ns']//1000000000)+'.'+str(m['mtime_ns']%1000000000).zfill(9);t.addfile(info,io.BytesIO(raw) if m['kind']=='file' else None)
        payload=(json.dumps(dict(authorized_exact27_selection=EXPECTED,guards=checked,remote_mutations=0,source_or_results_deleted=0),indent=2)+'\n').encode();info=tarfile.TarInfo('BACKUP_BINDINGS.json');info.size=len(payload);info.mode=0o644;t.addfile(info,io.BytesIO(payload))
    after=guard();assert after['cache_members']==checked['cache_members'] and after['sources']==checked['sources']
    raw=content.getvalue();sys.stdout.buffer.write(raw);sys.stdout.buffer.flush();sys.stderr.write(json.dumps(dict(sha256=sha(raw),bytes=len(raw),regular_files=117,directories=81,remote_mutations=0))+'\n')

if __name__=='__main__':main()

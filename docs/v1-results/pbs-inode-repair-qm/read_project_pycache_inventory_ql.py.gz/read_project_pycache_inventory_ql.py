"""Project-only read-only PEP3147 cache inventory; no runtime/artifact cleanup."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time

BASE=Path('/home/zhangyq/noahmp-v1')
SKIP={'test-deps','.git','.venv','venv','envs','node_modules','.ssh','credentials','.credentials','fixtures','inputs','forcing','data'}
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def blocked(name):return name in SKIP or any(s in name.lower() for s in ('artifact','evidence','archive','-closed','-result','-raw','runtime','site-packages'))
def nearest_manifest(cache):
    for parent in [cache.parent,*cache.parent.parents]:
        if not parent.is_relative_to(BASE):break
        path=parent/'SOURCE_SHA256.json'
        if path.is_file() and not path.is_symlink():return parent,path
    return None,None
def main():
    started=time.monotonic();assert BASE.resolve()==BASE
    groups={};unknown=[];excluded=[];caches=[]
    for r,ds,fs in os.walk(str(BASE),followlinks=False):
        path=Path(r);ds[:]=[n for n in ds if not blocked(n) and not (path/n).is_symlink()]
        if path.name!='__pycache__':continue
        ds[:]=[];pycs=[n for n in fs if n.endswith('.pyc')]
        source_root,manifest_path=nearest_manifest(path)
        if source_root is None:
            unknown.append(dict(path=str(path),pyc_files=len(pycs),reason='No eligible ancestor SOURCE manifest'));continue
        if source_root not in groups:
            raw=manifest_path.read_bytes();manifest=json.loads(raw)
            if not isinstance(manifest,dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in manifest.items()):
                excluded.append(dict(path=str(path),reason='SOURCE schema not path/hash mapping'));continue
            source_paths={};missing=[];mismatch=[]
            for name,expected in manifest.items():
                p=source_root/name
                if not p.is_relative_to(BASE) or '..' in Path(name).parts:raise AssertionError('Source entry outside project')
                if not p.is_file() or p.is_symlink():missing.append(name);continue
                value=p.read_bytes();actual=sha(value);source_paths[name]=dict(bytes=len(value),sha256=actual,manifest_sha256=expected)
                if actual!=expected:mismatch.append(name)
            exits=[]
            for n in ('pbs-exit.txt','exit.txt','pytest-exit.txt','exit-code.txt'):
                p=source_root/n
                if p.is_file() and not p.is_symlink():
                    raw_exit=p.read_bytes();exits.append(dict(path=str(p),raw_base64=base64.b64encode(raw_exit).decode(),sha256=sha(raw_exit),terminal_zero=raw_exit.strip()==b'0'))
            groups[source_root]=dict(root=str(source_root),manifest_path=str(manifest_path),manifest_sha256=sha(raw),manifest_bytes_base64=base64.b64encode(raw).decode(),manifest_entries=len(manifest),manifest_explicitly_excludes_pycache=not any('__pycache__' in n or n.endswith('.pyc') for n in manifest),currently_existing_source_hashes=source_paths,missing_source_entries=missing,source_mismatches=mismatch,full_source_matches_manifest=not missing and not mismatch,original_terminal_exit_files=exits,cache_directories=[],pyc_files=[],source_bytes={})
        group=groups[source_root];members=[]
        for name in pycs:
            p=path/name;s=p.lstat();match=re.fullmatch(r'(.+)\.cpython-[0-9]+(?:\.opt-[0-9]+)?\.pyc',name)
            if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1 or not match:
                excluded.append(dict(path=str(p),reason='Nonregular/symlink/hardlink/unknown PEP3147 cache name'));continue
            original=path.parent/(match.group(1)+'.py')
            if not original.is_file() or original.is_symlink():
                excluded.append(dict(path=str(p),expected_source=str(original),reason='Matching source .py missing or symlink'));continue
            rel=str(original.relative_to(source_root));source_doc=group['currently_existing_source_hashes'].get(rel)
            if source_doc is None or source_doc['sha256']!=source_doc['manifest_sha256']:
                excluded.append(dict(path=str(p),source=str(original),reason='Matched .py is absent from SOURCE or differs'));continue
            raw=p.read_bytes();source_raw=original.read_bytes();assert sha(source_raw)==source_doc['sha256']
            group['source_bytes'][rel]=dict(path=str(original),sha256=sha(source_raw),bytes=len(source_raw),raw_base64=base64.b64encode(source_raw).decode())
            d=dict(path=str(p),kind='file',bytes=len(raw),sha256=sha(raw),mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid,inode=s.st_ino,nlink=s.st_nlink,source_path=str(original),source_relative_to_manifest=rel,source_sha256=sha(source_raw),source_bytes=len(source_raw),source_listed_and_current_bytes_match=True)
            group['pyc_files'].append(d);members.append(d)
        s=path.lstat();group['cache_directories'].append(dict(path=str(path),files=len(pycs),eligible_pyc_files=len(members),all_actual_children_eligible_pyc=len(members)==len(fs),mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid,inode=s.st_ino,nlink=s.st_nlink))
        caches.append(dict(path=str(path),eligible_pyc_files=len(members),actual_pyc_files=len(pycs),source_root=str(source_root)))
    # Only readable same-UID process handles, no command lines or other HOME trees.
    live=[];unreadable=[];own=0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:
            if proc.stat().st_uid!=os.getuid():continue
            own+=1;links=[proc/'cwd']
            try:links.extend((proc/'fd').iterdir())
            except OSError as exc:unreadable.append(dict(pid=int(proc.name),kind='fd',error=repr(exc)))
            for link in links:
                try:target=Path(os.readlink(str(link)).removesuffix(' (deleted)'))
                except OSError:continue
                for root in groups:
                    if target==root or root in target.parents:live.append(dict(source_root=str(root),pid=int(proc.name),handle=str(link.relative_to(proc)),path=str(target)))
        except OSError as exc:unreadable.append(dict(pid=int(proc.name),kind='transient',error=repr(exc)))
    records=[]
    for root,group in groups.items():
        refs=[r for r in live if r['source_root']==str(root)];group['current_readable_source_or_cache_process_references']=refs
        terminal=any(r['terminal_zero'] for r in group['original_terminal_exit_files'])
        group['eligible_for_backup_proposal']=terminal and group['manifest_explicitly_excludes_pycache'] and not refs and bool(group['pyc_files'])
        group['terminal_evidence_available']=terminal
        if not terminal:group['not_selected_reason']='No exact retained terminal-zero marker; cannot assume inactive means accepted terminal'
        if refs:group['not_selected_reason']='Current readable source/cache process reference'
        records.append(group)
    selected=[g for g in records if g['eligible_for_backup_proposal']]
    print(json.dumps(dict(read_only=True,base=str(BASE),remote_mutations=0,cache_directories_seen=len(caches),eligible_original_source_pyc_files=sum(len(g['pyc_files']) for g in records),terminal_zero_candidate_source_roots=len(selected),terminal_zero_candidate_pyc_files=sum(len(g['pyc_files']) for g in selected),terminal_zero_candidate_bytes=sum(m['bytes'] for g in selected for m in g['pyc_files']),candidate_source_roots=records,unknown_caches=unknown,excluded_entries=excluded,process_visibility=dict(own_processes_seen=own,inaccessible_or_transient=unreadable,other_UID_visibility_not_claimed=True),seconds=time.monotonic()-started,limits='Source layout may be sparse; missing entries explicitly recorded. Only matched current .py bytes equal to an explicitly cache-excluding SOURCE entry and retained terminal0/no readable live references are backup candidates. No deletion or full-source pass inferred; test-deps/runtime/artifact/unknown excluded.')))

if __name__=='__main__':main()

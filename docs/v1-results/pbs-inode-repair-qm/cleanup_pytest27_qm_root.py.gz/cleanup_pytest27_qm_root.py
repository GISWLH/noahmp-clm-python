"""Root-only exact backed-up117 files/81 dirs reclamation; no service changes."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

TRUSTED_PROOF_SHA='bb56ebf82b12dd94469fbe6075259eb90024c9a239dc1113840fd15b662de0f5'
TRUSTED_HELPER_SHA='1ee539d2148f647809a6d2c1d8d68261ec6708bcd9e13f627df6968b61d1115e'
TRUSTED_ARCHIVE_SHA='cc3eb321ac8c9d6be8a6647a8e47395a3c5c9c217b73c13499484146a23319fc'
BASE=Path('/home/zhangyq/noahmp-v1')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def fs():
    out={}
    for p in (str(BASE),'/opt/pbshome'):
        s=os.statvfs(p);out[p]=dict(files=s.f_files,free_inodes=s.f_ffree,available_inodes=s.f_favail,available_bytes=s.f_bavail*s.f_frsize)
    return out
def pbs():
    try:
        r=subprocess.run(['qstat','-Bf'],capture_output=True,text=True,timeout=15)
        return dict(actual_exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
    except Exception as e:return dict(error=repr(e))
def main():
    p=argparse.ArgumentParser()
    for n in ('proof','helper','archive','output'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();assert os.name!='nt' and os.geteuid()==0 and sys.dont_write_bytecode
    assert a.output.resolve().is_relative_to(Path('/tmp')) and not a.output.exists()
    raw=a.proof.read_bytes();assert sha(raw)==TRUSTED_PROOF_SHA
    proof=json.loads(raw);assert proof['passed'] and proof['all_bytes_and_metadata_verified'] and proof['local_file_fsynced'] and proof['remote_mutations']==0
    assert sha(a.archive.read_bytes())==proof['archive_sha256']==TRUSTED_ARCHIVE_SHA and sha(a.helper.read_bytes())==TRUSTED_HELPER_SHA
    spec=importlib.util.spec_from_file_location('qm_readonly_guards',a.helper);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.EXPECTED=proof['backup_bindings']['authorized_exact27_selection'];fresh=helper.guard();original=proof['backup_bindings']['guards']
    assert fresh['cache_members']==original['cache_members'] and fresh['sources']==original['sources'] and not fresh['readable_process_snapshot']['references']
    assert len(fresh['cache_members'])==198
    files=[m for m in fresh['cache_members'] if m['kind']=='file'];dirs=[m for m in fresh['cache_members'] if m['kind']=='directory'];assert len(files)==117 and len(dirs)==81
    result=dict(started_unix=time.time(),root_authorized_exact27=True,backup_sha256=TRUSTED_ARCHIVE_SHA,fresh_root_visible_process_guard=fresh['readable_process_snapshot'],before_filesystem=fs(),before_PBS=pbs(),deleted_cache_files=[],removed_empty_cache_directories=[],source_or_scientific_results_deleted=0,original_job41_and_unknown_caches_untouched=True)
    def save():
        a.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    save();code=1
    try:
        for m in files:
            q=helper.safe(BASE/m['path']);s=q.lstat()
            assert (s.st_ino,s.st_nlink,s.st_uid,s.st_gid,s.st_mtime_ns)==(m['inode'],1,m['uid'],m['gid'],m['mtime_ns']) and sha(q.read_bytes())==m['sha256']
            q.unlink();result['deleted_cache_files'].append(m['path']);save()
        for m in sorted(dirs,key=lambda m:len(Path(m['path']).parts),reverse=True):
            q=helper.safe(BASE/m['path']);assert q.is_dir();q.rmdir();result['removed_empty_cache_directories'].append(m['path']);save()
        assert len(result['deleted_cache_files'])==117 and len(result['removed_empty_cache_directories'])==81
        for root,record in fresh['sources'].items():
            assert sha(Path(record['manifest_path']).read_bytes())==record['manifest_sha256']
            for name,v in record['source_existing_hashes'].items():assert sha((Path(root)/name).read_bytes())==v['sha256']
        result['all_original_manifest_and_existing_source_bytes_unchanged']=True;result['completed']=True;code=0
    except BaseException:result['exception']=traceback.format_exc();result['completed']=False
    finally:
        result['actual_exit']=code;result['after_filesystem']=fs();result['after_PBS']=pbs();result['finished_unix']=time.time();save()
    print(json.dumps(dict(actual_exit=code,completed=result['completed'],deleted_cache_files=len(result['deleted_cache_files']),removed_cache_directories=len(result['removed_empty_cache_directories']),before_filesystem=result['before_filesystem'],after_filesystem=result['after_filesystem'],source_or_scientific_results_deleted=0,result_path=str(a.output))))
    return code

if __name__=='__main__':sys.exit(main())

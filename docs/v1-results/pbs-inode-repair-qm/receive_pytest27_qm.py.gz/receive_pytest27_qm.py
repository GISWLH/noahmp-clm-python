"""Receive/fsync/verify exact27 known-source cache backup, no remote mutations."""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def main():
    old=json.loads((BASE/'pbs-cache-qk.json').read_bytes());caches=[c for c in old['caches'] if c['all_known_manifests_exclude_cache']]
    assert len(caches)==27
    selection=dict(caches=caches,regular_files=sum(c['files'] for c in caches),directories=sum(c['directories'] for c in caches),bytes=sum(c['bytes'] for c in caches),root_authorized_known27_sparse_SOURCE_policy=True)
    assert selection['regular_files']==117 and selection['directories']==81 and selection['bytes']==746609
    (BASE/'pytest27-qm-selection.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8')
    reader=(BASE/'backup_pytest27_qm_remote.py').read_bytes();payload=reader.replace(b'EXPECTED=None',b'EXPECTED=json.loads(base64.b64decode('+repr(base64.b64encode(json.dumps(selection).encode())).encode()+b'))');assert payload!=reader
    target=BASE/'pytest27-qm-backup.tar';partial=BASE/'pytest27-qm-backup.tar.part';assert not target.exists() and not partial.exists()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'];started=time.monotonic()
    with partial.open('xb') as out,(BASE/'pytest27-qm-backup.stderr').open('xb') as err:
        r=subprocess.run(command,input=payload,stdout=out,stderr=err,timeout=120);out.flush();os.fsync(out.fileno())
    (BASE/'pytest27-qm-backup-exit.json').write_text(json.dumps(dict(actual_exit=r.returncode,seconds=time.monotonic()-started,reader_sha256=sha(payload),command=command),indent=2)+'\n',encoding='utf-8')
    assert r.returncode==0,(BASE/'pytest27-qm-backup.stderr').read_text()
    raw=partial.read_bytes();remote=json.loads((BASE/'pytest27-qm-backup.stderr').read_bytes());assert sha(raw)==remote['sha256'] and len(raw)==remote['bytes'] and remote['remote_mutations']==0
    with tarfile.open(partial) as t:
        members={}
        for m in t:
            name=m.name.rstrip('/');assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts and (m.isfile() or m.isdir());members[name]=(m,t.extractfile(m).read() if m.isfile() else b'')
    assert len(members)==199
    metadata=json.loads(members['BACKUP_BINDINGS.json'][1]);assert metadata['authorized_exact27_selection']==selection and metadata['remote_mutations']==0 and not metadata['guards']['readable_process_snapshot']['references']
    for c in caches:
        for expected in c['members']:
            m,value=members[expected['path']];assert (m.mode,m.uid,m.gid)==(expected['mode'],expected['uid'],expected['gid'])
            assert m.pax_headers['mtime']==str(expected['mtime_ns']//1000000000)+'.'+str(expected['mtime_ns']%1000000000).zfill(9)
            if expected['kind']=='file':assert m.isfile() and len(value)==expected['bytes'] and sha(value)==expected['sha256']
            else:assert m.isdir() and not value
    os.replace(partial,target)
    verification=dict(passed=True,archive=target.name,archive_sha256=sha(raw),archive_bytes=len(raw),selection_sha256=sha((BASE/'pytest27-qm-selection.json').read_bytes()),regular_files=117,directories=81,cache_bytes=746609,potential_entries=198,all_bytes_and_metadata_verified=True,local_file_fsynced=True,remote_mutations=0,source_or_results_deleted=0,backup_bindings=metadata)
    (BASE/'pytest27-qm-backup-verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:verification[k] for k in ('passed','archive','archive_sha256','archive_bytes','regular_files','directories','cache_bytes','potential_entries','local_file_fsynced','remote_mutations')}))

if __name__=='__main__':main()

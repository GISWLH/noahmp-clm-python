from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='richards':
    name='richards-numpy-a';root=b/name;receipt=json.loads((root/'receipt.json').read_text())
    assert (root/'pbs-exit.txt').read_text().strip()=='0' and receipt['returncode']==0 and receipt['source_unchanged'] and receipt['counts']==dict(tests=15,failures=0,errors=0,skipped=0)
    assert receipt['xml_sha256']==sha(root/'tests.xml') and receipt['source_manifest_sha256']==sha(root/'SOURCE_SHA256.json')
    folders=[name];controls=['dispatch_richards_numpy_a.py'];source=b/'richards-numpy-a-source.tar.gz'
    assert sha(source)=='ec389d466f912b69cb98ac5575947ad8526815e86aa0b8a5609f2fa46f280c93'
else:
    assert mode=='diagnosis';name='qia-runoff-diagnosis-ab';root=b/'qia-runoff-partition-a'
    d=json.loads((root/'diagnosis.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged'] and d['original_traces_exact'] and d['steps']==48
    assert (b/'ctsm-runoff-partition-a/pbs-exit.txt').read_text().strip()=='1'
    assert (b/'ctsm-runoff-partition-b/pbs-exit.txt').read_text().strip()=='0'
    rec=json.loads((b/'ctsm-runoff-partition-b/receipt.json').read_text());assert all(v['returncode']==0 for v in rec['stages'])
    assert rec['diagnosis_sha256']==sha(b/'ctsm-runoff-partition-b/diagnosis.json')
    folders=['qia-runoff-partition-a','ctsm-runoff-partition-a','ctsm-runoff-partition-b']
    controls=['dispatch_qia_runoff_partition_a.py','dispatch_ctsm_runoff_partition_a.py','dispatch_ctsm_runoff_partition_b.py','recover_ctsm_runoff_partition_b_dispatch.py','read_ctsm_runoff_source_a.py']
    source=None
archive=b/(name+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for folder in folders:
        for p in sorted((b/folder).rglob('*')):
            if p.is_file():tf.add(p,arcname=(p.relative_to(b/folder).as_posix() if mode=='richards' else folder+'/'+p.relative_to(b/folder).as_posix()),recursive=False)
    for control in [*controls,'archive_runoff_richards_a.py']:tf.add(b/control,arcname='control/'+control,recursive=False)
    if source:tf.add(source,arcname='source/'+source.name,recursive=False)
    if mode=='diagnosis':
        for name in ['source.json','lnd_in.original.txt']:tf.add(b/'qia-runoff-source-a'/name,arcname='official-source-readback/'+name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size)))

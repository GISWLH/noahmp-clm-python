from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-numpy-a';assert not r.exists();r.mkdir();controls={}
for name in ['run_richards_numpy_a.py','richards_numpy_a.pbs','richards-numpy-a-package.json']:
    raw=(b/name).read_bytes()
    if name.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if name.endswith('package.json') else name)).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'richards_numpy_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
record=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='NewNumPyonlyverticalRichards independent15 on compute; originalcolumn/ongoingworkers unchanged. Queuing not physics/native pass.')
(r/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

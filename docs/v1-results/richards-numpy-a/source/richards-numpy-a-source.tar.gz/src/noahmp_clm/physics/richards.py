"""NumPy development reference for closed-column vertical liquid redistribution.

Mixed pressure-head Richards equations, Campbell retention and harmonic face
conductivity. Downward flux is positive. This water-only component is not yet
wired into the physical column: frozen-pore/enthalpy coupling, runoff boundary
operators and native backends must be validated before that integration.
No upstream implementation is copied. See docs/CLM_RICHARDS.md.
"""
from dataclasses import dataclass
import math
import numpy as np


@dataclass(frozen=True)
class HydraulicProfile:
    dz_m: np.ndarray
    porosity: np.ndarray
    saturated_conductivity_m_s: np.ndarray
    saturated_suction_m: np.ndarray
    retention_exponent: np.ndarray

    def __post_init__(self):
        dz=np.asarray(self.dz_m,float)
        if dz.ndim!=1 or not len(dz) or not np.all(np.isfinite(dz)) or np.any(dz<=0.):
            raise ValueError('Richards requires positive finite layer thicknesses')
        for name in self.__dataclass_fields__:
            try:value=np.broadcast_to(np.asarray(getattr(self,name),float),dz.shape).copy()
            except ValueError:raise ValueError('Hydraulic profile fields must match the soil layers') from None
            if not np.all(np.isfinite(value)):raise ValueError('Nonfinite hydraulic profile')
            if name=='porosity' and np.any((value<=0.)|(value>=1.)):raise ValueError('Invalid liquid pore volume')
            if name=='saturated_conductivity_m_s' and np.any(value<0.):raise ValueError('Negative hydraulic conductivity')
            if name in ('saturated_suction_m','retention_exponent') and np.any(value<=0.):raise ValueError('Positive retention parameters required')
            value.setflags(write=False);object.__setattr__(self,name,value)

    @property
    def midpoint_m(self):return np.cumsum(self.dz_m)-.5*self.dz_m


def hydraulic_properties(head_m,profile):
    """Liquid volume fraction, dtheta/dhead, conductivity and its derivative.

    Positive pressure above air entry retains saturated pore water while
    pressure gradients still transmit water through saturated cells.
    """
    h=np.asarray(head_m,float);p=profile
    if h.shape!=p.dz_m.shape or not np.all(np.isfinite(h)):raise ValueError('Invalid pressure-head vector')
    suction=np.maximum(-h,p.saturated_suction_m)
    theta=p.porosity*(p.saturated_suction_m/suction)**(1./p.retention_exponent)
    capacity=np.where(h < -p.saturated_suction_m,theta/(p.retention_exponent*suction),0.)
    power=2.*p.retention_exponent+3.
    conductivity=p.saturated_conductivity_m_s*(theta/p.porosity)**power
    derivative=power*conductivity*capacity/theta
    return theta,capacity,conductivity,derivative


def _faces(head,p):
    theta,capacity,k,dk=hydraulic_properties(head,p)
    distance=np.diff(p.midpoint_m);total=k[:-1]+k[1:]
    # A zero-conductivity layer blocks its two faces, without a numerical leak.
    valid=total>0.;denominator=np.where(valid,total,1.)
    face=np.where(valid,2.*k[:-1]*k[1:]/denominator,0.)
    gradient=1.-np.diff(head)/distance
    left=np.where(valid,2.*(k[1:]/denominator)**2*dk[:-1],0.)*gradient+face/distance
    right=np.where(valid,2.*(k[:-1]/denominator)**2*dk[1:],0.)*gradient-face/distance
    return theta,capacity,face*gradient,left,right


def _residual(head,old,p,dt,jacobian=False):
    theta,capacity,q,left,right=_faces(head,p)
    faces=np.r_[0.,q,0.]
    residual=1000.*p.dz_m*theta-old+1000.*dt*np.diff(faces)
    if not jacobian:return residual,q
    matrix=np.diag(1000.*p.dz_m*capacity)
    for j in range(len(q)):
        matrix[j,j]+=1000.*dt*left[j];matrix[j,j+1]+=1000.*dt*right[j]
        matrix[j+1,j]-=1000.*dt*left[j];matrix[j+1,j+1]-=1000.*dt*right[j]
    return residual,q,matrix


def _implicit_step(old,guess,p,dt):
    head=guess.copy();total_capacity=float(np.sum(1000.*p.dz_m*p.porosity))
    for iteration in range(45):
        residual,q,matrix=_residual(head,old,p,dt,True)
        norm=float(np.max(abs(residual)))
        if norm<=1e-10:
            transfer=1000.*dt*q
            # The finite-volume update from the solved flux is authoritative.
            # It telescopes exactly; no residual mass is invented or discarded.
            water=old+np.r_[0.,transfer]-np.r_[transfer,0.]
            maximum=1000.*p.dz_m*p.porosity
            if np.any(water<=0.) or np.any(water>maximum+1e-9):raise RuntimeError('Richards solved flux violates pore bounds')
            return water,head,transfer,norm,iteration+1
        try:direction=np.linalg.solve(matrix,-residual)
        except np.linalg.LinAlgError:raise RuntimeError('Singular mixed Richards pressure solve') from None
        scale=1.;accepted=False
        for _ in range(35):
            candidate=head+scale*direction
            if np.all(np.isfinite(candidate)):
                theta=hydraulic_properties(candidate,p)[0]
                all_saturated=np.all(candidate>=-p.saturated_suction_m)
                if not (all_saturated and float(old.sum())<total_capacity-1e-8):
                    trial,_=_residual(candidate,old,p,dt)
                    if np.max(abs(trial))<norm:
                        head=candidate;accepted=True;break
            scale*=.5
        if not accepted:raise RuntimeError('Richards pressure line search did not decrease the full water residual')
    raise RuntimeError('Richards nonlinear water solve did not converge')


def redistribute_liquid(water_kg_m2,profile,dt_seconds,*,absolute_tolerance_kg_m2=.002,
                        relative_tendency_tolerance=.01,max_substeps=4096):
    """Conservative adaptive redistribution, with zero flux at both boundaries.

    The complete change is carried by signed integrated face transfers. A
    backward-Euler full step and two half steps control temporal error; the
    accepted solution uses the two half steps. Strictly positive liquid is the
    current development domain. No ice, energy, surface input, aquifer or
    lateral groundwater tendency is hidden in this component.
    """
    if not isinstance(profile,HydraulicProfile):raise TypeError('Expected HydraulicProfile')
    p=profile;old=np.asarray(water_kg_m2,float);maximum=1000.*p.dz_m*p.porosity
    if old.shape!=p.dz_m.shape or not np.all(np.isfinite(old)) or np.any(old<=0.) or np.any(old>maximum):
        raise ValueError('Richards reference requires positive liquid within explicit pore capacity')
    if (not math.isfinite(dt_seconds) or dt_seconds<=0. or not math.isfinite(absolute_tolerance_kg_m2)
            or absolute_tolerance_kg_m2<=0. or not math.isfinite(relative_tendency_tolerance)
            or not 0.<relative_tendency_tolerance<=.1 or type(max_substeps) is not int or max_substeps<1):
        raise ValueError('Invalid Richards timestep or temporal controls')
    theta=old/(1000.*p.dz_m)
    head=-p.saturated_suction_m*(p.porosity/theta)**p.retention_exponent
    # Closed, fully saturated columns have an undetermined pressure offset.
    # Select a hydrostatic gauge; water and interface transfers remain exact.
    if np.all(old==maximum):
        head=p.midpoint_m+float(np.max(-p.saturated_suction_m-p.midpoint_m))
        return dict(water_kg_m2=old.copy(),pressure_head_m=head,interface_transfer_kg_m2=np.zeros(len(old)-1),
                    mass_residual_kg_m2=0.,mass_bound_kg_m2=32.*np.finfo(float).eps*max(float(2.*old.sum()),1.),
                    accepted_substeps=0,rejected_substeps=0,maximum_nonlinear_residual_kg_m2=0.,maximum_temporal_error_kg_m2=0.)
    current=old.copy();elapsed=0.;step=min(float(dt_seconds),3600.);accepted=rejected=0;max_residual=max_error=0.
    transfers=[[] for _ in range(len(old)-1)]
    while elapsed<dt_seconds:
        if accepted+rejected>=max_substeps:raise RuntimeError('Richards adaptive substep budget exhausted')
        step=min(step,dt_seconds-elapsed)
        try:
            coarse,_,_,_,_=_implicit_step(current,head,p,step)
            half,half_head,first,r1,_=_implicit_step(current,head,p,.5*step)
            fine,next_head,second,r2,_=_implicit_step(half,half_head,p,.5*step)
            error=abs(fine-coarse);tendency=np.maximum(abs(fine-current),abs(coarse-current))
            ratio=float(np.max(error/(absolute_tolerance_kg_m2+relative_tendency_tolerance*tendency)))
        except RuntimeError:
            rejected+=1;step*=.5
            if step<1e-7:raise
            continue
        if ratio>1.:
            rejected+=1;step*=max(.2,.8/math.sqrt(ratio));continue
        for face,value in enumerate(first+second):transfers[face].append(float(value))
        current=fine;head=next_head;elapsed+=step;accepted+=1
        max_residual=max(max_residual,r1,r2);max_error=max(max_error,float(error.max()))
        step*=min(2.,max(.5,.8/math.sqrt(max(ratio,1e-12))))
    integrated=np.asarray([math.fsum(v) for v in transfers])
    water=old+np.r_[0.,integrated]-np.r_[integrated,0.]
    residual=float(math.fsum(water)-math.fsum(old));bound=32.*np.finfo(float).eps*max(float(abs(water).sum()+abs(old).sum()),1.)
    if abs(residual)>bound:raise RuntimeError('Richards extensive water budget failed')
    return dict(water_kg_m2=water,pressure_head_m=head,interface_transfer_kg_m2=integrated,
        mass_residual_kg_m2=residual,mass_bound_kg_m2=bound,accepted_substeps=accepted,rejected_substeps=rejected,
        maximum_nonlinear_residual_kg_m2=max_residual,maximum_temporal_error_kg_m2=max_error)

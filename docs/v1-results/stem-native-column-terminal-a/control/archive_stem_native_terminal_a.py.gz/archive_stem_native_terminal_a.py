from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-native-column-a';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'summary.json').read_text());assert d['status']=='failed' and d['collected_nodes']==19 and d['source_unchanged'];a=b/'stem-native-column-terminal-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname=p.name,recursive=False)
 t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
 for n in ['run_stem_native_column_a.py','launch_stem_native_column_a.py','archive_stem_native_terminal_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

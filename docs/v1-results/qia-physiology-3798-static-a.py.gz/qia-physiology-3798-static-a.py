from pathlib import Path
import ast
import gzip
import hashlib
import json

root = Path(__file__).resolve().parents[2]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
initial = ast.parse((root / 'outputs/v1/preserve_qia_1320_a.py').read_text())
groups = {row[0]: row[1] for row in ast.literal_eval(next(n.value for n in initial.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'groups' for t in n.targets)))}
groups.update({
    'qia-numpy-cuda-week-a': 'abb3f970c465d3585d26b57126077b655454b73a0deb43f1a9019a45d5eb4468',
    'qia-trait-firstday-a': '0caecac1374344982b63848f224f8a39ce652fa0baaff9cff563f72564605c64',
    'qia3798-local-candidates-f': 'ece1764e6ca3b800b5662cf594d1f7da5976268be71c33c1c431efd5577d1fb7',
    'qia3798-jax-launch-f': '36c9f7c58b931bb693bfe7287103f79e516d31010a007c16553af7b4181bc4a8',
})
counts, python_files, nc_files = {}, 0, []


def read(group, name):
    data = (root / 'docs/v1-results' / group / name).read_bytes()
    return gzip.decompress(data) if name.endswith('.gz') else data


def record(group, name):
    return json.loads(read(group, name))


for group, expected in groups.items():
    assert sha((root / 'outputs/v1' / (group + '-evidence.tar.gz')).read_bytes()) == expected
    m = record(group, 'manifest.json'); assert m['archive_sha256'] == expected
    for item in m['artifacts']:
        stored = (root / 'docs/v1-results' / group / item['path']).read_bytes()
        assert sha(stored) == item['stored_sha256']
        raw = gzip.decompress(stored) if item['path'] == item['source'] + '.gz' else stored
        assert sha(raw) == item['source_sha256']
        if item['source'].endswith('.py'):
            ast.parse(raw.decode('utf-8-sig')); python_files += 1
        if item['source'].endswith('.nc'):
            nc_files.append(dict(group=group, path=item['path'], sha256=sha(raw), bytes=len(raw)))
    counts[group] = len(m['artifacts'])

manifest_raw = read('qia-fresh-phase-numpy-week-a', 'SOURCE_SHA256.json.gz')
assert sha(manifest_raw) == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
manifest = json.loads(manifest_raw); checked = []
for name, digest in manifest.items():
    if not name.startswith(('src/', 'tests/', 'benchmarks/')):
        continue
    raw = (root / name).read_bytes()
    assert digest in {sha(raw), sha(raw.replace(b'\r\n', b'\n'))}, name
    checked.append(name)
assert len(checked) == 497
week = record('qia-fresh-phase-numpy-week-a', 'receipt.json.gz')
assert week['returncode'] == 0 and week['source_unchanged'] and week['steps_completed'] == 336
resume = record('k78-current-b-audit-a', 'qia-resume-k78-inspection-a/inspection.json.gz')
assert resume['initial336_all_state_ledgers_and_trace_exact'] and resume['source_unchanged']
k78 = record('k78-current-b-audit-a', 'k78-current-b/audit.json.gz')
assert not k78['passed'] and len(k78['failed']) == 1 and all(x['passed'] for x in k78['budgets'].values())
assert k78['failed'][0]['field'] == 'surface/thermal_layer_residual' and k78['failed'][0]['maximum_absolute'] == 1.52587890625e-5
s = record('ctsm-qia-physiology-s-b', 'ctsm-qia-run-s/physiology-restarts.json.gz')
assert len(s['restarts']) == 48 and len(s['shared_first48_raw_fields_exact']) == 27 and all(s['shared_first48_raw_fields_exact'].values())
pair = record('qia-numpy-cuda-week-a', 'comparison.json.gz')
assert not pair['bias_failures'] and not pair['measured_correlation_failures'] and len(pair['correlations_unmeasured']) == 3
traits = record('qia-trait-firstday-a', 'qia-trait-firstday-comparison-b/comparison.json.gz')
assert traits['original_baseline_all_metrics_exact'] and set(traits['cases']) == {'original-generic', 'bb-only', 'pft-upper'} and not traits['scientific_acceptance']
f = record('qia3798-local-candidates-f', 'qia3798-device-audit-f/audit.json.gz')
assert f['passed'] and f['source_unchanged'] and f['raw_fields'] == 361 and f['next_state_arrays'] == 19
launch = record('qia3798-jax-launch-f', 'summary.json.gz')
for name, digest in launch['controls_sha256'].items():
    assert sha(read('qia3798-jax-launch-f', 'control/' + name + '.gz')) == digest
result = dict(scope='Local metadata/hash/AST audit only. No model,pytest,NumPy/scientific arrays/calibration executed locally;all numerical work EHPC PBS,GPU xuanze. Original/currentfailed outputs and everycandidate/missing diagnostic retained. No production runtime changes;current510 full1250/GPU remainder and year/spinup/science incomplete.',
              groups=counts, artifacts=sum(counts.values()), python_artifacts_ast_checked=python_files,
              original_netcdf_files=nc_files, runtime_files_matching_frozen510=len(checked), source_manifest_sha256=sha(manifest_raw),
              k78_sameprecision_failed_fields=k78['failed'], k78_raw_model_and_next_fields=k78['raw_model_and_next_fields'],
              week_engineering_bias_comparisons=sum(len(v) for v in pair['cases'].values()), own336_state_ledgers_trace_exact=True,
              official_S_shared_raw_fields=27, original_S_restarts=48, current_full_canonical_nodes=1250,
              JAX_F_pending_at_launch_snapshot=True, audit_control_sha256=sha(Path(__file__).read_bytes()))
(root / 'docs/v1-results/qia-physiology-3798-static-a.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(root / 'docs/v1-results/qia-physiology-3798-static-a.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in result.items() if k not in ['original_netcdf_files', 'k78_sameprecision_failed_fields']}))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-all-phase-numpy-year-c';d=json.loads((r/'receipt.json').read_text());report=json.loads((r/'trajectory/report.json').read_text());assert d['returncode']==1 and d['source_unchanged'] and d['status']=='failed' and d['steps_completed']==1110 and report['failed_index']==1110 and (r/'pbs-exit.txt').read_text().strip()=='1';a=b/'qia-all-phase-numpy-year-terminal-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,scope='Original NumPy511A yearC actualfailed1110/17520/PBS1, unchangedsource and all generations/oldstate/ledger/traceback retained. No source-changed or failedtrajectory continuation. H diagnostic and newcoldyear separate.')))

from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'thin-snow-event-reference-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=b/'thin-snow-event-numpy-a';d=json.loads((prior/'receipt.json').read_text());assert (prior/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=37,failures=0,errors=0,skipped=0)
package=json.loads((r/'package.json').read_text());a=b/'thin-snow-event-numpy-a-source.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==556 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s/'src'),str(s/'tests')]
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.gpu.column_heat import pack_joint_heat_case
from test_gpu_column_heat import numpy_reference
packet=json.loads((s/'tests/fixtures/vanishing_snow_event.json').read_text());base=Snowpack(**packet['snow']);soil=dict(packet['soil']);props=soil.pop('params');ground=SoilEnthalpyState(**soil,params=SoilParams(**props));arrays={};records=[];start=time.monotonic()
for precision,dtype in [('32',np.float32),('64',np.float64)]:
    rows=[];href=[];tref=[]
    for scale in [1.,1e3,1e6,1e9]:
        snow=Snowpack(base.mass*scale,base.enthalpy*scale,base.thickness*scale)
        row=pack_joint_heat_case(snow,ground,packet['dt'],packet['top_flux'],**packet['kwargs'],dtype=dtype)
        h,t,d=numpy_reference(*row);assert d['iterations']<=6 and np.max(abs(d['layer_residual_jm2']))<=d['convergence_tolerance_jm2']
        rows.append(row);href.append(h);tref.append(t);records.append(dict(precision=precision,mass_scale=scale,temperature_k=t.tolist(),iterations=d['iterations'],energy_residual_j_m2=d['residual_jm2'],original_tolerance_j_m2=d['convergence_tolerance_jm2']))
    arrays.update({precision+'/'+key:np.stack([row[i] for row in rows]) for i,key in enumerate(['cells','props','options','boundary'])})
    arrays[precision+'/enthalpy_jm2']=np.stack(href);arrays[precision+'/temperature_k']=np.stack(tref)
assert len(records)==8;np.savez_compressed(r/'vanishing_snow_event_reference.npz',**arrays)
receipt=dict(scope='Frozen556 NP reference after actual337 original10heat/12column/15station tests. Four actualmass scales xbothquantizedprecisions, alloriginal80/thermal guards. No GPU physics computed, new native4/full1068 not credited.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),reference_sha256=sha(r/'vanishing_snow_event_reference.npz'),records=records,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

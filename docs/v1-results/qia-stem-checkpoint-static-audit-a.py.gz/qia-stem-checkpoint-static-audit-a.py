from pathlib import Path
import ast,gzip,hashlib,json

r=Path(__file__).resolve().parents[2];sha=lambda data:hashlib.sha256(data).hexdigest()
groups=['qia-stem-wait-a','qia-stem-numpy-day-a','stem-split-terminal-ef','ctsm-qia-point-inputs-ab','ctsm-qia-run-failures-ab','ctsm-qia-run-failures-cd','ctsm-qia-run-e','qia-stem-device-wait-a']
count=0
def raw(group,name):
 p=r/'docs/v1-results'/group;d=json.loads((p/'manifest.json').read_text());item=next(x for x in d['artifacts'] if x['source']==name);data=(p/item['path']).read_bytes()
 return gzip.decompress(data) if item['path'].endswith('.gz') and not name.endswith('.gz') else data
for group in groups:
 p=r/'docs/v1-results'/group;d=json.loads((p/'manifest.json').read_text())
 for item in d['artifacts']:
  data=(p/item['path']).read_bytes();assert sha(data)==item['stored_sha256'];original=raw(group,item['source']);assert sha(original)==item['source_sha256'];count+=1
  if item['source'].endswith('.py'):ast.parse(original,filename=group+'/'+item['source'])
f=json.loads((r/'outputs/v1/p6-stem-split-f-source.json').read_text());b=json.loads((r/'outputs/v1/p6-stem-assessment-b-source.json').read_text())
physical=[n for n in b if n.startswith('src/') or n in ['benchmarks/run_fluxnet_column.py','benchmarks/run_fluxnet_native.py','benchmarks/fluxnet_solar.py','benchmarks/fluxnet_deposition.py']]
assert len(physical)==183 and all(sha((r/n).read_bytes())==b[n]==f[n] for n in physical)
runtime=[n for n in b if n.startswith(('src/','tests/','benchmarks/','examples/'))];assert len(runtime)==503 and all(sha((r/n).read_bytes())==b[n] for n in runtime)
canonical=json.loads(raw('stem-split-terminal-ef','e/canonical-ef.json'));assert canonical['canonical_nodes']==22 and canonical['e_other_passed']==19 and canonical['f_regression_passed']==3
receipt=json.loads(raw('qia-stem-numpy-day-a','receipt.json'));assert receipt['returncode']==0 and receipt['source_unchanged'] and receipt['steps_completed']==48 and receipt['steps_requested']==17520 and receipt['status']=='running'
official=json.loads(raw('ctsm-qia-run-e','configuration.json'));assert official['upstream_original_bytes_unchanged'] and official['official_model_returncode']==233 and next(x for x in official['stages'] if x['stage']=='case-build')['returncode']==0
value=dict(scope='Local AST/source/evidence-hash audit only; no local model or pytest. Canonical SAI22 means E19+test-input-only F3, not one E22 pass/fullGPU340. Real Qia EHPC NumPy48 prefix completed, device day remains pending. Official Qia point inputs complete but E execution aborted in DATM stream parsing before physics, no scientific/annual/spinup acceptance.',groups=groups,evidence_artifacts=count,canonical_sai_gpu_nodes=22,current_runtime_files_unchanged_from_assessment_b=len(runtime),physical_files_identical_to_506F=len(physical),numpy_actual_steps=48,numpy_original_requested_steps=17520,official_model_returncode=233)
(r/'docs/v1-results/qia-stem-checkpoint-static-audit-a.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import datetime,hashlib,io,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'fluxnet-numpy-current-first-year-a';sha=lambda b:hashlib.sha256(b).hexdigest();manifest=(base/'p6-spinup-assessment-c/SOURCE_SHA256.json').read_bytes();m=json.loads(manifest);entries=[('SOURCE_SHA256.json',manifest)];rows=[]
protocol=json.loads((root/'protocol.json').read_text());assert protocol['pbs_job']=='121.manager'
for row in protocol['cases']:
    name=row['case'];snapshot=(root/'snapshots'/(name+'.tar.gz')).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(snapshot)) as t:
        raw=t.extractfile('report.json').read();r=json.loads(raw);trace=t.extractfile(r['model_npz']).read()
    assert r['status']=='running' and r['steps_completed']>=48 and r['steps_requested']==17520 and r['source_unchanged'] and sha(trace)==r['model_npz_sha256'] and all(m[k]==v for k,v in r['source_sha256'].items())
    for key,field in [('input','forcing_npz_sha256'),('input_manifest','forcing_manifest_sha256'),('configuration','configuration_sha256')]:assert r[field]==row['hashes'][key]
    entries.extend([(name+'/report.json',raw),(name+'/'+r['model_npz'],trace)]);rows.append(dict(case=name,steps_completed=r['steps_completed'],report_sha256=sha(raw),trace_sha256=sha(trace),source_snapshot_sha256=sha(snapshot)))
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Unmodified actual running NumPy121 reports/traces, each at least48 of original17520; mixed current progress retained, no fabricated48-complete or annual report. Only first48 intervals may be compared for the fresh native day.',cases=rows,source_manifest_sha256=sha(manifest));entries.append(('export-binding.json',(json.dumps(value,indent=2)+'\n').encode()));entries.append((Path(__file__).name,Path(__file__).read_bytes()))
archive=base/'numpy-current-reference-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for name,data in entries:
        p=tarfile.TarInfo(name);p.size=len(data);t.addfile(p,io.BytesIO(data))
print(json.dumps(dict(path=str(archive),sha256=sha(archive.read_bytes()),files=len(entries),cases=rows)))

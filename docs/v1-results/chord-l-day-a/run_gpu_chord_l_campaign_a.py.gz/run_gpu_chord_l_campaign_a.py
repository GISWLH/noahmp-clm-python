from pathlib import Path
import hashlib,json,subprocess,sys,time
import numpy as np
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261018-l';source=base/'p6-joint-chord-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());ref=json.loads((root/'numpy-reference/SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items());begun=time.monotonic()
command=[sys.executable,'-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--stop-after','48']
with (root/'cuda-day.log').open('w') as log:code=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
(root/'cuda-day-exit.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun))+'\n');assert code==0
rows=[];failures=[]
for row in json.loads((root/'batch.json').read_text())['cases']:
    folders=[root/'cuda-day'/row['case'],root/'numpy-reference'/row['case']];reports=[json.loads((p/'report.json').read_text()) for p in folders]
    assert all(r['source_unchanged'] and r['status']=='running' and r['steps_requested']==17520 for r in reports) and reports[0]['steps_completed']==48 and reports[1]['steps_completed']>=48
    for key in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert reports[0][key]==reports[1][key]
    assert all(ref[n]==v for n,v in reports[1]['source_sha256'].items()) and all(m[n]==v for n,v in reports[0]['source_sha256'].items())
    data=[]
    for p,r in zip(folders,reports):
        path=p/r['model_npz'];assert sha(path)==r['model_npz_sha256']
        with np.load(path,allow_pickle=False) as z:data.append({n:z[n][:48] for n in z.files})
    for key in ['time_start','time_end']:np.testing.assert_array_equal(data[0][key],data[1][key]);assert len(data[0][key])==48
    fields={}
    for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
        a,b=[d[key].astype(float)*factor+offset for d in data]
        if a.ndim==1:a=a[:,None];b=b[:,None]
        values=[compare_series(a[:,k],b[:,k],var) for k in range(a.shape[1])]
        for k,v in enumerate(values):
            if not v['bias_pass']:failures.append([row['case'],key,k,'bias',v['bias']])
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and v['correlation_pass'] is False:failures.append([row['case'],key,k,'r',v['r']])
        fields[key]=values
    rows.append(dict(case=row['case'],metrics=fields,report_sha256=[sha(p/'report.json') for p in folders],original_report_steps=[r['steps_completed'] for r in reports],maximum_cumulative_m_h_c_n_original_report={name:r['maximum_cumulative_residual_m_h_c_n'] for name,r in zip(['cuda32_first48','numpy64_partial_parent'],reports)}))
assert all(sha(source/n)==v for n,v in m.items());g=json.loads((root/'cuda-day/batch.json').read_text());assert not g['identity']['compare_jax32'] and g['steps_completed']==48 and g['source_unchanged']
result=dict(scope='Four fresh L first48 CUDA32-only and original per-column M/H/C/N bounds; independent JAX32 shadow remains in separate original K campaign, versus first48 of actual current NumPy121 mixed-progress traces. Raw NumPy running reports not rewritten as complete48/full year. Backend validation only, no annual/spinup/observation acceptance.',cases=rows,failures=failures,source_differences=json.loads((root/'input-import.json').read_text())['source_differences'],same_precision_max_absolute=g['same_precision_max_absolute'],source_unchanged=True,seconds=time.monotonic()-begun)
(root/'backend-day-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(failures=failures,same_precision_max_absolute=g['same_precision_max_absolute'],cases=len(rows))),flush=True);assert not failures

import io,tarfile,datetime
from run_fluxnet_native import read_generation
archive=base/'joint-chord-k-day-a-evidence.tar.gz';assert sha(archive)=='bd5cc01b7ee03ec756cfb12f40f6035e392005394f92cd11b3f53c677a67d95c'
global_report,state,cases=read_generation(root/'cuda-day');proof=[]
def equality(old,new):
    assert old.keys()==new.keys()
    return {key:bool(old[key].shape==new[key].shape and old[key].dtype==new[key].dtype and old[key].tobytes()==new[key].tobytes()) for key in old}
with tarfile.open(archive) as t:
    baseline=json.load(t.extractfile('cuda-day/batch.json'));assert baseline['steps_completed']==48 and baseline['identity']['compare_jax32']
    for (report,data),identity in zip(cases,global_report['identity']['cases']):
        case=identity['case'];desc=baseline['case_reports'][case];r=json.load(t.extractfile('cuda-day/'+case+'/'+desc['file']))
        for key in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert report[key]==r[key]
        raw=t.extractfile('cuda-day/'+case+'/'+r['model_npz']).read();assert hashlib.sha256(raw).hexdigest()==r['model_npz_sha256']
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:fields=equality(dict(z),data)
        proof.append(dict(case=case,fields=fields));assert all(fields.values())
    for label,old_raw,new in [('48',t.extractfile('cuda-day/'+baseline['checkpoint_file']).read(),state)]:
        with np.load(io.BytesIO(old_raw),allow_pickle=False) as z:fields=equality({k:z[k] for k in z.files if not k.startswith('shadow')},new)
        proof.append(dict(state=label,fields=fields));assert all(fields.values())
    original_initial=[v for v in t.getmembers() if v.name.startswith('cuda-day/state-0000000-') and v.isfile()];own_initial=list((root/'cuda-day').glob('state-0000000-*.npz'));assert len(original_initial)==len(own_initial)==1
    with np.load(io.BytesIO(t.extractfile(original_initial[0]).read()),allow_pickle=False) as a,np.load(own_initial[0],allow_pickle=False) as b:fields=equality({k:a[k] for k in a.files if not k.startswith('shadow')},dict(b));proof.append(dict(state='cold0',fields=fields));assert all(fields.values())
value=dict(scope='Fresh independent CUDA-only L cold0 and primary48 arrays/all trajectory fields bitwise equal immutable K0/K48. K shadow stays separate and running; no state reused. Both NumPy first48 and original MHCN checks above remain required. This is not annual/spinup/observation acceptance.',baseline_archive_sha256=sha(archive),all_fields_bitwise_equal=True,proof=proof)
(root/'k-primary-prefix-comparison.json').write_text(json.dumps(value,indent=2)+'\n')
prefix=base/'chord-l-day-a-evidence.tar.gz';assert not prefix.exists()
with tarfile.open(prefix,'w:gz') as t:
    for folder in [root/'cuda-day',root/'numpy-reference']:
        for p in sorted(folder.rglob('*')):
            if p.is_file():t.add(p,arcname=p.relative_to(root).as_posix(),recursive=False)
    for name in ['batch.json','input-import.json','backend-day-comparison.json','k-primary-prefix-comparison.json','cuda-day-exit.json','cuda-day.log','run_gpu_chord_l_campaign_a.py','launch.json']:t.add(root/name,arcname=name,recursive=False)
    t.add(source/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
(root/'prefix-export.json').write_text(json.dumps(dict(archive=str(prefix),sha256=sha(prefix),utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n');print(json.dumps(dict(first48_complete=True,k_primary_bitwise_equal=True,prefix_archive_sha256=sha(prefix))),flush=True)
begun=time.monotonic();command=[sys.executable,'-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--resume']
with (root/'annual.log').open('w') as log:p=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT);(root/'annual-worker.json').write_text(json.dumps(dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),prefix_archive_sha256=sha(prefix),scope='L resumes only its own unchanged489 CUDA-only48 state and cumulative ledgers after actual independent NumPy/bitwise K primary prefix validation. K remains independent shadow campaign. Full17520 requested, no annual completion claim.'))+'\n');code=p.wait()
r=json.loads((root/'cuda-day/batch.json').read_text());value=dict(returncode=code,status=r['status'],steps_completed=r['steps_completed'],steps_requested=r['steps_requested'],source_unchanged=r['source_unchanged'],seconds=time.monotonic()-begun,report_sha256=sha(root/'cuda-day/batch.json'));(root/'annual-exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True);raise SystemExit(code)

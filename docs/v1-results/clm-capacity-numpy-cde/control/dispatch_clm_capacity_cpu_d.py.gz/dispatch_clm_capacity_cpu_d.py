from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'clm-capacity-cpu-d';assert not r.exists();assert (b/'clm-capacity-numpy-d/pbs-exit.txt').read_text().strip()=='0';npd=json.loads((b/'clm-capacity-numpy-d/receipt.json').read_text());assert npd['returncode']==0 and npd['counts']==dict(tests=49,failures=0,errors=0,skipped=0) and npd['source_unchanged'];r.mkdir();h={}
for n in ['run_clm_capacity_cpu_d.py','clm_capacity_cpu_d.pbs','clm-capacity-numpy-d-package.json']:
    raw=(b/n).read_bytes()
    if n.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if n.endswith('package.json') else n)).write_bytes(raw);h[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'clm_capacity_cpu_d.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=p.stdout.strip(),controls_sha256=h,scope='Frozen528D complete977CPU after actualsame-source49 NP; currentnative/full/year/science pending.'),indent=2)+'\n');print(p.stdout.strip())

from pathlib import Path
import hashlib
import json
import subprocess

base = Path('/home/zhangyq/noahmp-v1'); root = base / 'clm-capacity-reference-e'
assert not root.exists(); root.mkdir()
controls = {}
for name in ['generate_clm_capacity_reference_e.py','run_clm_capacity_reference_e.py', 'clm_capacity_reference_e.pbs', 'clm-capacity-reference-e-package.json']:
    raw = (base / name).read_bytes()
    if name.endswith(('.py', '.pbs')): assert b'\r\n' not in raw
    (root / ('package.json' if name.endswith('-package.json') else name)).write_bytes(raw)
    controls[name] = hashlib.sha256(raw).hexdigest()
job = subprocess.check_output(['qsub', str(root / 'clm_capacity_reference_e.pbs')], cwd=root, text=True).strip()
(root / 'dispatch.json').write_text(json.dumps(dict(pbs_job=job, controls_sha256=controls), indent=2) + '\n')
print(job)

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'canopy-capacity-cpu-a';assert not r.exists();r.mkdir();h={}
for n in ['run_canopy_capacity_cpu_a.py','canopy_capacity_cpu_a.pbs','canopy-capacity-gpu-a-package.json']:
    raw=(b/n).read_bytes()
    if n.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if n.endswith('package.json') else n)).write_bytes(raw);h[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'canopy_capacity_cpu_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=p.stdout.strip(),controls_sha256=h,scope='Frozen527A complete CPU expected969; independentNumPy41 and capacityGPU3 alreadyactual0; no coupled capacity/currentfull/year/science inference.'),indent=2)+'\n');print(p.stdout.strip())

from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1'); root = base / 'clm-capacity-reference-e'
source = Path(os.environ['TMPDIR']) / 'source'; source.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
package = json.loads((root / 'package.json').read_text())
archive = base / 'clm-capacity-reference-e-source.tar.gz'; assert sha(archive) == package['archive_sha256']
with tarfile.open(archive) as tf: tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 531 and sha(source / 'SOURCE_SHA256.json') == package['manifest_sha256']
assert all(sha(source / name) == h for name, h in manifest.items())
environment = os.environ.copy()
environment.update(PYTHONPATH=':'.join(map(str, [base / 'test-deps', source, source / 'src', source / 'tests', source / 'benchmarks'])),
                   PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
start = time.monotonic()
command = [sys.executable, '-m', 'pytest', '-q', '-s', 'tests/test_canopy_capacity.py', 'tests/test_photosynthesis.py', 'tests/test_clm_capacity_column.py',
           '--junitxml=' + str(root / 'tests.xml')]
with (root / 'tests.log').open('x') as log:
    code = subprocess.run(command, cwd=source, env=environment, stdout=log, stderr=subprocess.STDOUT).returncode
cases = list(ET.parse(root / 'tests.xml').iter('testcase'))
counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
              errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
unchanged = all(sha(source / name) == h for name, h in manifest.items())
receipt = dict(scope=package['scope'], pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
               returncode=code, counts=counts, source_unchanged=unchanged,
               source_manifest_sha256=sha(source / 'SOURCE_SHA256.json'), archive_sha256=sha(archive),
               seconds=time.monotonic()-start, command=command)
(root / 'SOURCE_SHA256.json').write_bytes((source / 'SOURCE_SHA256.json').read_bytes())
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
assert code == 0 and unchanged and counts == dict(tests=53,failures=0,errors=0,skipped=0)

exec(compile((root/'generate_clm_capacity_reference_e.py').read_bytes(),str(root/'generate_clm_capacity_reference_e.py'),'exec'))

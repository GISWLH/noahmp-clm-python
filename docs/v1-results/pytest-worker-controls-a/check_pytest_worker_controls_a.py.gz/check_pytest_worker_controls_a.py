from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,tempfile,time
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'pytest-worker-controls-a'
scratch=Path(tempfile.mkdtemp(prefix='pytest-worker-controls-',dir=os.environ['TMPDIR']));worker=root/'run_pytest_worker_a.py';begun=time.monotonic();rows=[]
cases=[('pass',"def test_control():\n    assert True\n",0),('call-failure',"def test_control():\n    assert False, 'deliberate worker negative control'\n",1),
    ('skip',"import pytest\ndef test_control():\n    pytest.skip('deliberate skip negative control')\n",70),
    ('teardown-failure',"import pytest\n@pytest.fixture(autouse=True)\ndef fixture():\n    yield\n    raise RuntimeError('deliberate teardown negative control')\ndef test_control():\n    assert True\n",1),
    ('barrier-failure',"import sys,types\ndef test_control():\n    def fail():\n        raise RuntimeError('deliberate asynchronous barrier negative control')\n    sys.modules['jax']=types.SimpleNamespace(effects_barrier=fail)\n",70),
    ('coverage-mismatch',"def test_control():\n    assert True\n",70),
    ('test-file-change',"from pathlib import Path\ndef test_control():\n    p=Path(__file__)\n    p.write_text(p.read_text()+'# deliberate isolated test-file change\\n')\n",70)]
for label,text,expected_code in cases:
    dest=scratch/label;dest.mkdir();test=dest/'test_control.py';test.write_text(text)
    expected=dest/'expected.json';expected.write_text(json.dumps(['test_control.py::'+('missing' if label=='coverage-mismatch' else 'test_control')]))
    command=[sys.executable,'-u',str(worker),'--source',str(source),'--test-file',str(test),'--expected',str(expected),'--receipt',str(dest/'receipt.json'),'--xml',str(dest/'junit.xml')]
    start=time.monotonic()
    with (dest/'worker.log').open('w') as log:p=subprocess.run(command,cwd=dest,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    receipt=json.loads((dest/'receipt.json').read_text());assert p.returncode==expected_code==receipt['worker_exitcode'],(label,p.returncode)
    assert receipt['passed']==(label=='pass')
    if label=='barrier-failure':assert receipt['pytest_returncode']==0 and receipt['device_barriers'][0]['status']=='failed'
    if label=='coverage-mismatch':assert not receipt['node_coverage_exact']
    if label=='test-file-change':assert not receipt['source_unchanged']
    rows.append(dict(control=label,expected_returncode=expected_code,actual_returncode=p.returncode,seconds=time.monotonic()-start,receipt=receipt))
value=dict(scope='Isolated EHPC lifecycle-only controls, no model physics/GPU test or full-suite acceptance credit. Failure, skipped item, teardown error, simulated async barrier error, missing coverage and test-byte change all must stay nonzero.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,controls=len(rows),all_expected_outcomes=True,results=rows,seconds=time.monotonic()-begun,worker_sha256=hashlib.sha256(worker.read_bytes()).hexdigest())
dest=root/'controls.json';assert not dest.exists();dest.write_text(json.dumps(value,indent=2)+'\n')
archive=root/'control-artifacts.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(scratch.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(scratch).as_posix(),recursive=False)
print(json.dumps({k:v for k,v in value.items() if k!='results'}),flush=True)

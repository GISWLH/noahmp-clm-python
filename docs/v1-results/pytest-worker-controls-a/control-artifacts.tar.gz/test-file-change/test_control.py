from pathlib import Path
def test_control():
    p=Path(__file__)
    p.write_text(p.read_text()+'# deliberate isolated test-file change\n')
# deliberate isolated test-file change

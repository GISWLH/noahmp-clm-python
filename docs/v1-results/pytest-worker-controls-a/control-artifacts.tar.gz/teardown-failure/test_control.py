import pytest
@pytest.fixture(autouse=True)
def fixture():
    yield
    raise RuntimeError('deliberate teardown negative control')
def test_control():
    assert True

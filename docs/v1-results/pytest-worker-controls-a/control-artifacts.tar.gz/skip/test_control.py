import pytest
def test_control():
    pytest.skip('deliberate skip negative control')

def test_control():
    assert False, 'deliberate worker negative control'

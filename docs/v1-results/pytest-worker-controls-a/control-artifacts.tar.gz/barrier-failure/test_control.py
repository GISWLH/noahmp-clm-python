import sys,types
def test_control():
    def fail():
        raise RuntimeError('deliberate asynchronous barrier negative control')
    sys.modules['jax']=types.SimpleNamespace(effects_barrier=fail)

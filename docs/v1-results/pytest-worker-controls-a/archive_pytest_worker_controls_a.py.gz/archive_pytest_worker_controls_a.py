from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'pytest-worker-controls-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'controls.json').read_text());assert r['pbs_job']=='107.manager' and r['controls']==7 and r['all_expected_outcomes'] and (root/'pbs-exit.txt').read_text().strip()=='0'
assert sha(root/'run_pytest_worker_a.py')==r['worker_sha256']
assert [v['actual_returncode'] for v in r['results']]==[0,1,70,1,70,70,70]
names=['run_pytest_worker_a.py','check_pytest_worker_controls_a.py','pytest_worker_controls_a.pbs','controls.json','controls.log','node.txt','pbs-exit.txt','control-artifacts.tar.gz']
dest=base/'pytest-worker-controls-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for n in names:t.add(root/n,arcname=n,recursive=False)
    t.add(Path(__file__),arcname='archive_pytest_worker_controls_a.py',recursive=False)
print(json.dumps(dict(files=len(names)+1,sha256=sha(dest),scope='Seven isolated lifecycle controls in EHPC PBS107, all intended outcomes observed; negative cases remain nonzero. No physical/GPU/full-suite completion credit.')))

"""Backend-neutral exact-input cache signatures; no numerical evaluations."""
from dataclasses import fields,is_dataclass
import hashlib,json
import numpy as np
def key(family,args,kwargs):
    h=hashlib.sha256()
    def add(v):
        if is_dataclass(v):
            h.update(type(v).__name__.encode())
            for f in fields(v):h.update(f.name.encode());add(getattr(v,f.name))
        elif isinstance(v,dict):
            h.update(b'dict')
            for k in sorted(v):add(k);add(v[k])
        elif isinstance(v,(list,tuple)):
            h.update(type(v).__name__.encode());h.update(str(len(v)).encode())
            for x in v:add(x)
        elif isinstance(v,str):h.update(b'str');h.update(v.encode())
        elif v is None:h.update(b'None')
        else:
            a=np.asarray(v);assert a.dtype.kind!='O'
            h.update(a.dtype.str.encode());h.update(json.dumps(a.shape).encode());h.update(np.ascontiguousarray(a).tobytes())
    add(family);add(args);add(kwargs);return h.hexdigest()

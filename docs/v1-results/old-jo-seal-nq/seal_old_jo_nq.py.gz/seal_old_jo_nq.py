"""Prepare-only tool: inspect JO, or explicitly seal then retire exact JO PIDs.

No process-name matching, process-group signals, source deletion, or shared-cache
changes. `inspect` is read-only. Root alone decides when to invoke `stop` after
reviewing a fresh snapshot. Stop success means cancellation, never physics pass.
"""
from pathlib import Path
import argparse
import ctypes
import datetime
import hashlib
import json
import os
import platform
import re
import signal
import tarfile
import time
import traceback

BASE = Path('/home/lhwang/work/noahmp-v1')
OLD = BASE / 'ballberry-jo-full-gpu'
SOURCE = Path('/tmp/noahmp-ballberry-jo-full/source')
DEST = BASE / 'old-jo-seal-nq'
CONTROLLER = 3092100
CONTROLLER_START = 4084668462
MANIFEST = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
OPEN_PIDFD = None
SEND_PIDFD_SIGNAL = None


def pidfd_setup_and_probe():
    """Use native APIs or the verified Linux x86_64 ABI; probe only self/signal0."""
    global OPEN_PIDFD, SEND_PIDFD_SIGNAL
    native_open = getattr(os, 'pidfd_open', None)
    native_send = getattr(signal, 'pidfd_send_signal', None)
    if callable(native_open) and callable(native_send):
        OPEN_PIDFD = native_open
        SEND_PIDFD_SIGNAL = lambda fd, sig: native_send(fd, sig, None, 0)
        backend = dict(backend='python-native-pidfd')
    else:
        assert platform.system() == 'Linux' and platform.machine() == 'x86_64'
        assert ctypes.sizeof(ctypes.c_long) == ctypes.sizeof(ctypes.c_void_p) == 8
        header = Path('/usr/include/asm/unistd_64.h')
        text = header.read_text()
        numbers = {}
        for name, expected in [('pidfd_send_signal', 424), ('pidfd_open', 434)]:
            matches = re.findall(r'^#define\s+__NR_' + name + r'\s+(\d+)\s*$', text, re.M)
            assert matches == [str(expected)], 'Unexpected local syscall ABI: ' + name
            numbers[name] = expected
        libc = ctypes.CDLL(None, use_errno=True)
        syscall = libc.syscall
        # syscall(long number, ...) is variadic: only its fixed argument belongs
        # in argtypes; every variadic argument below has an explicit C ABI type.
        syscall.argtypes = [ctypes.c_long]
        syscall.restype = ctypes.c_long

        def checked(number, *arguments):
            ctypes.set_errno(0)
            result = syscall(ctypes.c_long(number), *arguments)
            if result == -1:
                error = ctypes.get_errno()
                raise OSError(error, os.strerror(error))
            return int(result)

        def fallback_open(pid):
            assert 0 < pid <= 2147483647
            return checked(numbers['pidfd_open'], ctypes.c_int(pid), ctypes.c_uint(0))

        def fallback_send(fd, sig):
            assert 0 <= fd <= 2147483647 and 0 <= int(sig) < int(signal.NSIG)
            return checked(numbers['pidfd_send_signal'], ctypes.c_int(fd), ctypes.c_int(int(sig)),
                           ctypes.c_void_p(None), ctypes.c_uint(0))

        OPEN_PIDFD, SEND_PIDFD_SIGNAL = fallback_open, fallback_send
        backend = dict(backend='ctypes-libc-syscall-pidfd', machine=platform.machine(),
                       header=str(header), header_sha256=sha(header), syscall_numbers=numbers,
                       syscall_restype='c_long', syscall_fixed_argtypes=['c_long'],
                       pidfd_open_variadic_types=['c_int', 'c_uint'],
                       pidfd_send_signal_variadic_types=['c_int', 'c_int', 'c_void_p', 'c_uint'])
    fd = OPEN_PIDFD(os.getpid())
    try:
        SEND_PIDFD_SIGNAL(fd, 0)
    finally:
        os.close(fd)
    backend.update(self_pid=os.getpid(), self_signal_zero_probe_passed=True,
                   scope='Only own pidfd opened, signal0 permission/liveness probe, descriptor closed. No process stopped or terminated.')
    return backend


def read(path):
    return json.loads(path.read_text())


def write(path, data):
    temp = path.with_name(path.name + '.tmp')
    with temp.open('w') as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def identity(pid):
    path = Path('/proc') / str(pid)
    try:
        values = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        try:
            cwd = str((path / 'cwd').resolve())
        except PermissionError:
            cwd = '<unreadable:PermissionError>'
        return dict(pid=pid, state=values[0], ppid=int(values[1]), pgid=int(values[2]), sid=int(values[3]),
                    start_ticks=int(values[19]), cmdline=(path / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace').strip(),
                    cwd=cwd)
    except (FileNotFoundError, ProcessLookupError):
        return None


def inventory():
    rows = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            if path.stat().st_uid == os.getuid():
                value = identity(int(path.name))
                if value:
                    rows[value['pid']] = value
        except (FileNotFoundError, ProcessLookupError):
            continue
    return rows


def snapshot():
    launch, progress = read(OLD / 'launch.json'), read(OLD / 'progress.json')
    assert launch['pid'] == CONTROLLER and launch['source_manifest_sha256'] == MANIFEST
    assert read(OLD / 'source-location.json')['source'] == str(SOURCE)
    rows = inventory()
    controller = rows[CONTROLLER]
    assert controller['start_ticks'] == CONTROLLER_START and controller['pgid'] == controller['sid'] == CONTROLLER
    assert controller['cmdline'] == '/home/lhwang/venvs/noahmp-phase3b/bin/python -u ' + str(OLD / 'control_ballberry_jo_full.py')
    assert controller['cwd'] == str(SOURCE)
    selected = {CONTROLLER}
    while True:
        expanded = selected | {p for p, v in rows.items() if v['ppid'] in selected}
        if expanded == selected:
            break
        selected = expanded
    bound = {p for p, v in rows.items() if str(OLD) in v['cmdline'] or str(SOURCE) in v['cmdline'] or v['cwd'].startswith(str(SOURCE))}
    assert bound <= selected, 'Unexpected bound process outside JO tree; inspect before cancellation'
    for pid in selected:
        assert rows[pid]['pgid'] == rows[pid]['sid'] == CONTROLLER
    return dict(root=str(OLD), source=str(SOURCE), source_manifest_sha256=MANIFEST,
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), controller=controller,
                processes=[rows[p] for p in sorted(selected)], current_file=progress['file'],
                current_worker_pid=progress['pid'], progress=progress,
                scope='Read-only identity snapshot; source identities and interrupted work are never relabeled successful.')


def open_checked(value):
    before = identity(value['pid'])
    assert before and before['start_ticks'] == value['start_ticks'] and before['cmdline'] == value['cmdline']
    fd = OPEN_PIDFD(value['pid'])
    after = identity(value['pid'])
    assert after and after['start_ticks'] == value['start_ticks'] and after['cmdline'] == value['cmdline']
    return fd


def wait_stopped(value, timeout=5.):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        now = identity(value['pid'])
        if now is None or now['start_ticks'] != value['start_ticks'] or now['state'] in ['T', 't', 'Z']:
            return
        time.sleep(.05)
    raise RuntimeError('PID did not stop: ' + str(value['pid']))


def present(value):
    now = identity(value['pid'])
    return bool(now and now['start_ticks'] == value['start_ticks'] and now['state'] != 'Z')


def stop(expected_worker, expected_start):
    pidfd_backend = pidfd_setup_and_probe()
    assert not DEST.exists(), 'Immutable attempt; never overwrite sealed evidence'
    first = snapshot()
    assert first['current_worker_pid'] == expected_worker
    worker = next(v for v in first['processes'] if v['pid'] == expected_worker)
    assert worker['start_ticks'] == expected_start and worker['ppid'] == CONTROLLER
    assert worker['cwd'] == str(SOURCE), 'Selected JO worker cwd must be readable and exact'
    assert 'ballberry_jo_full_worker.py --source ' + str(SOURCE) in worker['cmdline']
    assert str(SOURCE / 'tests' / first['current_file']) in worker['cmdline']
    DEST.mkdir()
    handles, values, sent = {}, {}, []
    termination_started = False
    try:
        controller = first['controller']
        handles[CONTROLLER], values[CONTROLLER] = open_checked(controller), controller
        SEND_PIDFD_SIGNAL(handles[CONTROLLER], signal.SIGSTOP)
        wait_stopped(controller)
        # Once the sole launcher is stopped, capture/freeze the actual descendant
        # tree. Repeat until no compiler children appeared during this short window.
        for _ in range(10):
            frozen = snapshot()
            assert frozen['current_worker_pid'] == expected_worker, 'Worker advanced before freeze; resume and inspect again'
            pending = [v for v in frozen['processes'] if v['pid'] not in handles]
            if not pending:
                break
            for value in pending:
                fd = open_checked(value)
                handles[value['pid']], values[value['pid']] = fd, value
                SEND_PIDFD_SIGNAL(fd, signal.SIGSTOP)
            for value in pending:
                wait_stopped(value)
        else:
            raise RuntimeError('JO descendant tree did not stabilize')
        frozen = snapshot()
        assert all(v['state'] in ['T', 't', 'Z'] for v in frozen['processes'])
        assert sha(SOURCE / 'SOURCE_SHA256.json') == MANIFEST
        manifest = read(SOURCE / 'SOURCE_SHA256.json')
        assert len(manifest) == 581 and all(sha(SOURCE / n) == h for n, h in manifest.items())
        progress = frozen['progress']
        retained = []
        for row in progress['records']:
            stem = Path(row['file']).stem
            receipt, xml = OLD / (stem + '-receipt.json'), OLD / (stem + '.xml')
            value = read(receipt)
            assert row['actual_parent_returncode'] == value['worker_exitcode'] == value['pytest_returncode'] == 0
            assert row['passed'] and value['passed'] and value['source_unchanged']
            assert value['source_manifest_sha256'] == MANIFEST
            assert sha(receipt) == row['receipt_sha256'] and sha(xml) == value['xml_sha256']
            retained.append(dict(file=row['file'], tests=row['expected_tests'], source_manifest_sha256=MANIFEST,
                                 actual_parent_returncode=0, receipt_sha256=sha(receipt)))
        inherited = []
        for row in progress['reused']:
            folder = OLD / 'reused' / Path(row['file']).stem
            receipt = folder / (Path(row['file']).stem + '-receipt.json')
            value = read(receipt)
            assert row['passed'] and row['actual_parent_returncode'] == value['worker_exitcode'] == value['pytest_returncode'] == 0
            assert value['source_manifest_sha256'] == row['source_manifest_sha256'] and sha(receipt) == row['receipt_sha256']
            inherited.append(row)
        frozen.update(retained_completed_records=retained, retained_inherited_records=inherited,
                      retained_complete_nodes=sum(v['tests'] for v in retained + inherited),
                      interrupted_module=dict(file=first['current_file'], pid=expected_worker, start_ticks=expected_start,
                                              status='interrupted_not_credited', counted_as_passed=False,
                                              scope='No complete actual-parent record at queue sealing; even a late standalone receipt is not credited.'))
        write(DEST / 'old-jo-snapshot.json', frozen)
        files = sorted(p for p in OLD.rglob('*') if p.is_file())
        assert all(not p.is_symlink() for p in files)
        hashes = {p.relative_to(OLD).as_posix(): dict(sha256=sha(p), bytes=p.stat().st_size) for p in files}
        archive = DEST / 'old-jo-sealed.tar.gz'
        with tarfile.open(archive, 'w:gz') as tf:
            for path in files:
                tf.add(path, arcname=path.relative_to(OLD).as_posix(), recursive=False)
        with tarfile.open(archive) as tf:
            assert set(tf.getnames()) == set(hashes)
            for name, item in hashes.items():
                raw = tf.extractfile(name).read()
                assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
        assert all(sha(OLD / n) == v['sha256'] for n, v in hashes.items())
        write(DEST / 'archive.json', dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
              artifacts=len(hashes), artifact_details=hashes, source_unchanged=True))
        # Seal is durable and verified before any termination. Kill the exact
        # stopped launcher first so it cannot spawn the next old-source module.
        termination_started = True
        SEND_PIDFD_SIGNAL(handles[CONTROLLER], signal.SIGKILL)
        sent.append(dict(pid=CONTROLLER, signal='SIGKILL', purpose='Retire stopped old-source launcher after verified seal'))
        for pid, fd in handles.items():
            if pid == CONTROLLER or not present(values[pid]):
                continue
            SEND_PIDFD_SIGNAL(fd, signal.SIGTERM)
            SEND_PIDFD_SIGNAL(fd, signal.SIGCONT)
            sent.append(dict(pid=pid, signal='SIGTERM+SIGCONT', purpose='Cancel exact frozen JO descendant'))
        deadline = time.monotonic() + 20.
        while time.monotonic() < deadline and any(present(v) for v in values.values()):
            time.sleep(.2)
        for pid, value in values.items():
            if present(value):
                SEND_PIDFD_SIGNAL(handles[pid], signal.SIGKILL)
                sent.append(dict(pid=pid, signal='SIGKILL', purpose='Exact remaining JO descendant after bounded grace'))
        deadline = time.monotonic() + 10.
        while time.monotonic() < deadline and any(present(v) for v in values.values()):
            time.sleep(.2)
        assert not any(present(v) for v in values.values())
        remaining = [v for v in inventory().values() if v['state'] != 'Z' and
                     (str(OLD) in v['cmdline'] or str(SOURCE) in v['cmdline'] or v['cwd'].startswith(str(SOURCE)))]
        assert remaining == []
        result = dict(queue_cancelled_without_crediting_incomplete_module=True,
                      pidfd_backend=pidfd_backend,
                      snapshot_sha256=sha(DEST / 'old-jo-snapshot.json'), identities=list(values.values()),
                      signals_sent=sent, matching_live_processes_after=[], archive_sha256=sha(archive),
                      retained_complete_nodes=frozen['retained_complete_nodes'], interrupted_module=frozen['interrupted_module'],
                      scope='Explicit cancellation of old JN queue only. No invented pytest/parent success for interrupted work. '
                            'Original source, inputs, caches and evidence remain in place. MX/EC untouched.')
        write(DEST / 'old-jo-stop.json', result)
        print(json.dumps(result), flush=True)
    except BaseException:
        # Before termination, failure to seal must not leave a silently stopped
        # live queue. After termination begins, clean up only already-held PIDs.
        cleanup = []
        for pid in sorted(handles, key=lambda p: p == CONTROLLER):
            try:
                if present(values[pid]):
                    sig = signal.SIGKILL if termination_started else signal.SIGCONT
                    SEND_PIDFD_SIGNAL(handles[pid], sig)
                    cleanup.append(dict(pid=pid, signal=sig.name))
            except ProcessLookupError:
                pass
        write(DEST / 'failure.json', dict(termination_started=termination_started, signals_sent=sent, pidfd_backend=pidfd_backend,
              cleanup=cleanup, traceback=traceback.format_exc(), passed=False))
        raise
    finally:
        for fd in handles.values():
            os.close(fd)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['inspect', 'pidfd-preflight', 'stop'])
    parser.add_argument('--expected-worker', type=int)
    parser.add_argument('--expected-worker-start', type=int)
    args = parser.parse_args()
    os.chdir(BASE)
    if args.mode == 'inspect':
        print(json.dumps(snapshot(), indent=2), flush=True)
    elif args.mode == 'pidfd-preflight':
        print(json.dumps(pidfd_setup_and_probe(), indent=2), flush=True)
    else:
        assert args.expected_worker is not None and args.expected_worker_start is not None
        stop(args.expected_worker, args.expected_worker_start)

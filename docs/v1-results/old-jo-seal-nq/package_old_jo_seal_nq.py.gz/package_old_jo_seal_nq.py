"""Local static sealing-package verification; no numerical or remote execution."""
from pathlib import Path
import hashlib
import json
import os
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'old-jo-seal-nq'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
archive = ROOT / 'old-jo-sealed.tar.gz'
details, stopped, snapshot = read(ROOT / 'archive.json'), read(ROOT / 'old-jo-stop.json'), read(ROOT / 'old-jo-snapshot.json')
assert sha(archive) == details['sha256'] == stopped['archive_sha256'] == '8458b7a991ee74c37336ae172757f56790f92f84bb4761f274d52299e0ed367f'
assert sha(ROOT / 'old-jo-snapshot.json') == stopped['snapshot_sha256'] == '4af2932dd25efc375d45634088727af37c4fb760b38fb80746780b6ce213515f'
with tarfile.open(archive) as tf:
    assert len(tf.getnames()) == details['artifacts'] == 205
    assert set(tf.getnames()) == set(details['artifact_details'])
    for name, item in details['artifact_details'].items():
        data = tf.extractfile(name).read()
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
assert stopped['queue_cancelled_without_crediting_incomplete_module'] and not stopped['matching_live_processes_after']
assert stopped['retained_complete_nodes'] == snapshot['retained_complete_nodes'] == 140
assert sum(v['tests'] for v in snapshot['retained_completed_records']) == 103
assert sum(v['tests'] for v in snapshot['retained_inherited_records']) == 37
assert stopped['interrupted_module']['counted_as_passed'] is False
assert stopped['interrupted_module']['status'] == 'interrupted_not_credited'
assert sha(ROOT / 'seal_old_jo_nq.py') == sha(BASE / 'seal_old_jo_nq.py') == 'ef902de2dd070e36c4b44bb77949e8102ff4c9266b1f68142da0118cc73188b3'
names = [
    'old-jo-pre-stop-inspection.json', 'old-jo-pre-stop-inspection-first.stderr',
    'old-jo-pre-stop-inspection-first-provenance.json', 'old-jo-pre-stop-inspection-fixed.json',
    'old-jo-pre-stop-inspection-fixed.stderr', 'old-jo-stop-execution.log',
    'old-jo-stop-execution-second.log', 'old-jo-pidfd-preflight.json', 'old-jo-pidfd-preflight.stderr',
    'GPU_ETA_NO.md', 'GPU_ETA_NO.json', 'GPU_ETA_NQ.md', 'GPU_ETA_NQ.json',
]
for name in names:
    (ROOT / name).write_bytes((BASE / name).read_bytes())
assert 'PermissionError' in (ROOT / 'old-jo-pre-stop-inspection-first.stderr').read_text()
assert "module 'os' has no attribute 'pidfd_open'" in (ROOT / 'old-jo-stop-execution.log').read_text()
assert read(ROOT / 'old-jo-stop-execution-second.log') == stopped
assert read(ROOT / 'old-jo-pidfd-preflight.json')['self_signal_zero_probe_passed']
workloads = read(ROOT / 'other-workloads-after.json')
assert workloads['mx']['completed_tests'] == 9
assert all(str(pid) in workloads['ps'] for pid in [3042732, 3450108, 3581312, 3588377, 3588380])
assert '3092100' not in workloads['ps'] and '3536611' not in workloads['ps']
verification = dict(verified=True, inner_archive_sha256=sha(archive), inner_artifacts_verified=205,
    successful_control_sha256=sha(ROOT / 'seal_old_jo_nq.py'), retained_jn_nodes=103, retained_iv_nodes=37,
    interrupted_module=stopped['interrupted_module'], independent_other_workloads_snapshot_sha256=sha(ROOT / 'other-workloads-after.json'),
    eta_documents_sha256={n: sha(ROOT / n) for n in ['GPU_ETA_NO.md', 'GPU_ETA_NO.json', 'GPU_ETA_NQ.md', 'GPU_ETA_NQ.json']},
    eta_scope='NO20-45h is the pre-cancellation historical estimate. NQ25-50h is conditional from its first worker; NQ remains unstarted and old140 is not its credit.',
    attempts=[dict(stage='initial inspect', actual_exit=1, signals_sent=False,
                   evidence='old-jo-pre-stop-inspection-first.stderr', evidence_type='Transcript of original tool-visible stderr; provenance sidecar retained, not redirected SSH log'),
              dict(stage='first stop', actual_exit=1, signals_sent=False, evidence='old-jo-stop-execution.log'),
              dict(stage='fixed inspect', actual_exit=0, signals_sent=False, evidence='old-jo-pre-stop-inspection-fixed.json'),
              dict(stage='self pidfd probe', actual_exit=0, signals_sent='Own process signal0 only', evidence='old-jo-pidfd-preflight.json'),
              dict(stage='successful exact queue retirement', actual_exit=0, signals_sent=stopped['signals_sent'], evidence='old-jo-stop-execution-second.log')],
    scope='Local static byte/hash/receipt verification only. Root performed remote cancellation. '
          '140 historical completed nodes keep JN/IV source identity; active phenology has no pass credit. '
          'MX, EC and NP liveness separately observed afterwards; no NQ collect or physics launched.')
(ROOT / 'local-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
(ROOT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
files = sorted(p for p in ROOT.iterdir() if p.is_file())
hashes = {p.name: dict(sha256=sha(p), bytes=p.stat().st_size) for p in files}
outer = BASE / 'old-jo-seal-nq-evidence.tar.gz'
prior = None
if outer.exists():
    # Root requested four ETA artifacts before publication. Replace only this
    # exact unpublished staging package; never overwrite a later closed package.
    prior = sha(outer)
    assert prior == read(BASE / 'old-jo-seal-nq-package.json')['sha256'] == '41e20ed2e724078aa9b0dcafa405a511cb5a85eae106284704a378f9f1506ff8'
temporary = outer.with_name(outer.name + '.tmp')
assert not temporary.exists()
with tarfile.open(temporary, 'w:gz') as tf:
    for path in files:
        tf.add(path, arcname=path.name, recursive=False)
with tarfile.open(temporary) as tf:
    assert set(tf.getnames()) == set(hashes)
    for name, item in hashes.items():
        raw = tf.extractfile(name).read()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
os.replace(temporary, outer)
package = dict(archive=outer.name, sha256=sha(outer), bytes=outer.stat().st_size,
               artifacts=len(hashes), artifact_details=hashes, inner_archived_artifacts=205,
               superseded_unpublished_pre_eta_package_sha256=prior, scope=verification['scope'])
(BASE / 'old-jo-seal-nq-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps({k: v for k, v in package.items() if k != 'artifact_details'}, indent=2))

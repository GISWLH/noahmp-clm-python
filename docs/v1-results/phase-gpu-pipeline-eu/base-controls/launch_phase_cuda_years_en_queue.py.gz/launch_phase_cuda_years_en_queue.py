from pathlib import Path
import datetime,hashlib,json,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-cuda-years-en';assert not r.exists();r.mkdir();names=['run_phase_cuda_year_en.py','control_phase_cuda_year_en.py','launch_phase_cuda_year_en.py','queue_phase_cuda_years_en.py',Path(__file__).name];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in names:assert b'\r\n' not in (b/n).read_bytes()
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'queue_phase_cuda_years_en.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controls_sha256={n:sha(b/n) for n in names},physical_gpu_index=1,scope='Queue EC ownsuccessfulEJ48 to original17520 onlyafteractualEHPC EL independently validated48. No model launch/pass/yearcredit fromqueue. Two cases sequentialphysical1, allfailedprefixes retained and never resumed.');(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

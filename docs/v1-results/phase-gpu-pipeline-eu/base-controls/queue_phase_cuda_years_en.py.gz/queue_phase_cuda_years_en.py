from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-cuda-years-en';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=Path('/tmp/noahmp-phase-descent-ec/source');m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and len(m)==571 and all(sha(s/n)==h for n,h in m.items());records=[];failure=None;begun=time.monotonic()
try:
    prerequisite=b/'phase-prefix-el-receipt.json';actual_exit=b/'phase-prefix-el-pbs-exit.txt'
    while not (prerequisite.exists() and actual_exit.exists()):
        (r/'waiting-audit.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Wait actualEHPC EL independentcurrentEC48 audit and actualPBSexit; no trajectory starts from queued intent'))+'\n');time.sleep(20.)
    audit=json.loads(prerequisite.read_text());assert actual_exit.read_text().strip()=='0' and audit['passed'] and audit['source_unchanged'] and audit['source_manifest_sha256']==manifest and len(audit['cases'])==2 and all(q['passed'] and q['all23state_chains_and_final_checkpoint_exact'] for q in audit['cases'])
    (r/'independent-receipt.json').write_bytes(prerequisite.read_bytes());(r/'independent-pbs-exit.txt').write_bytes(actual_exit.read_bytes());cold=json.loads((b/'phase-cold-queue-ej/exit.json').read_text());assert cold['passed'] and cold['failure'] is None and cold['source_manifest_sha256']==manifest
    for label in ['capacity','capacity_optics']:
        verification=b/('phase-prefix-el-'+label+'-verification.json');v=json.loads(verification.read_text());assert v==next(q for q in audit['cases'] if q['case']==label)
        while True:
            free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
            if free>8192 and memory>16*1024*1024:break
            (r/'waiting-resource.json').write_text(json.dumps(dict(case=label,gpu_free_mib=free,host_available_kib=memory))+'\n');time.sleep(20.)
        command=[sys.executable,'-u',str(b/'launch_phase_cuda_year_en.py'),label]
        with (r/(label+'-launch.log')).open('x') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
        assert code==0,'Year preparation failed before parent wait; original log retained'
        root=b/('qia-phase-'+label+'-cuda-year-ej');launch=json.loads((root/'year-launch.json').read_text());pid=launch['pid'];(r/'progress.json').write_text(json.dumps(dict(case=label,pid=pid,records=records),indent=2)+'\n')
        while not (root/'year-exit.json').exists():
            try:os.kill(pid,0)
            except ProcessLookupError:raise RuntimeError('Year controller missing without durable parentexit, incomplete; never automatically restart')
            time.sleep(20.)
        e=json.loads((root/'year-exit.json').read_text());receipt=root/'year-receipt.json';d=json.loads(receipt.read_text());assert sha(receipt)==e['receipt_sha256'] and d['source_manifest_sha256']==manifest and d['source_unchanged']
        row=dict(case=label,actual_parent_returncode=e['returncode'],passed=e['passed'],status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],receipt_sha256=sha(receipt));records.append(row);print(json.dumps(row),flush=True)
        # The two fixed cases are independent: a numerical failure in one is
        # preserved, and the other's own successful48 is still exercised.
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
d=dict(passed=failure is None and len(records)==2 and all(q['passed'] for q in records),records=records,failure=failure,seconds=time.monotonic()-begun,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),scope='ActualEC two17520nativeCUDA years sequentialphysical1 after independentEHPC EL own48 audit. Own30state/ledgers and firstcontinued23state capture; originalguards/gates retained, no failedprefix resume/NumPyforward/JAXshadow. Full401/observedscience/spinup not proven by year completion.')
(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');raise SystemExit(0 if d['passed'] and d['source_unchanged'] else 1)

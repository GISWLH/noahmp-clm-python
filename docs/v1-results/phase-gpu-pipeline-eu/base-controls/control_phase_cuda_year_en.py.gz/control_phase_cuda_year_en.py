from pathlib import Path
import hashlib,json,subprocess,sys,time
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');r=b/('qia-phase-'+label+'-cuda-year-ej');start=time.monotonic();cmd=[sys.executable,'-u',str(b/'run_phase_cuda_year_en.py'),label]
with (r/'year-model.log').open('x') as log:p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
(r/'year-worker.json').write_text(json.dumps(dict(pid=p.pid,command=cmd),indent=2)+'\n');code=p.wait();path=r/'year-receipt.json';d=json.loads(path.read_text()) if path.exists() else {};passed=bool(code==0 and d and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['status']=='complete' and d['steps_completed']==d['steps_requested']==17520)
record=dict(returncode=code if code else (0 if passed else 1),passed=passed,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest() if d else None,scope='Actual CUDA-only original17520 year parent terminal. No false completion from prefix/queue or oldsource tests; no JAXpair/observation/spinup acceptance.')
(r/'year-exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['returncode'])

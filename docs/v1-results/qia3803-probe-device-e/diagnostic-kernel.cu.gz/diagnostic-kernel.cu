// Original C3 Farquhar / Ball--Berry implementation. See CLM_PHOTOSYNTHESIS.md.
// One independent leaf per thread; AoS input (n,7), output (n,12).
// NVRTC provides device math builtins without a host math.h include path.

__device__ float arrhenius(float t, float activation) {
    return expf((activation / (float)(8.314462618 * 298.15)) * (1.f - 298.15f / t));
}

__device__ float peaked(float t, float activation, float deactivation, float entropy) {
    float numerator = 1.f + expf((298.15f * entropy - deactivation) / (float)(8.314462618 * 298.15));
    float denominator = 1.f + expf((t * entropy - deactivation) / (8.314462618f * t));
    return arrhenius(t, activation) * numerator / denominator;
}

struct LeafEnvironment {
    float ca, rh, gb, stress, vcmax, product, rd, kc, ko, gamma, transport;
};

__device__ void evaluate(float ci, const LeafEnvironment& e, const float* p, float* v) {
    float carbon = fmaxf(ci-e.gamma, 0.f);
    float ac = e.vcmax*carbon/(ci+e.kc*(1.f+p[9]/e.ko));
    float aj = e.transport*carbon/(4.f*ci+8.f*e.gamma);
    float gross = fminf(fminf(ac, aj), e.product);
    float net = gross-e.rd;
    float cs = fmaxf(e.ca-1.4f*net/e.gb, 1e-9f);
    float x = p[6]*fmaxf(net, 0.f)*e.stress/cs;
    float b = e.gb-p[7]-x;
    float c = e.gb*(p[7]+x*fminf(e.rh, 1.f));
    float root = sqrtf(b*b+4.f*c);
    float gs = b >= 0.f ? 2.f*c/fmaxf(b+root, 1e-30f) : .5f*(root-b);
    v[0]=gross; v[1]=net; v[2]=ac; v[3]=aj; v[4]=cs; v[5]=gs;
    v[6]=net-(e.ca-ci)/(1.4f/e.gb+1.6f/gs);
}

__device__ void leaf_gas_exchange_device(const float* v, const float* p, float* out) {
        float par=v[0], t=v[1], nitrogen=v[5];
        float growth=fminf(fmaxf(p[8]-273.15f, 11.f), 35.f);
        LeafEnvironment e;
        e.ca=v[2]; e.rh=v[3]; e.gb=v[4]; e.stress=v[6];
        float vc_factor=peaked(t, 72000.f, 200000.f, 668.39f-1.07f*growth);
        e.vcmax=p[0]*nitrogen*vc_factor;
        float jmax=p[1]*nitrogen*peaked(t, 50000.f, 200000.f, 659.70f-.75f*growth);
        e.product=3.f*p[2]*nitrogen*vc_factor;
        e.rd=p[3]*peaked(t, 46390.f, 150650.f, 490.f);
        e.kc=404.9f*arrhenius(t, 79430.f);
        e.ko=278400.f*arrhenius(t, 36380.f);
        e.gamma=42.75f*arrhenius(t, 37830.f);
        float light=.5f*p[4]*par;
        float total=light+jmax;
        float den=total+sqrtf(fmaxf(total*total-4.f*p[5]*light*jmax, 0.f));
        e.transport=den>0.f ? 2.f*light*jmax/fmaxf(den, 1e-30f) : 0.f;
        float lo=0.f, hi=e.ca+e.rd*(1.4f/e.gb+1.6f/p[7])+1.f;
        float rates[7];
        for (int iter=0; iter<48; ++iter) {
            float mid=.5f*(lo+hi);
            evaluate(mid, e, p, rates);
            if (rates[6]<0.f) lo=mid;
            else hi=mid;
        }
        float ci=.5f*(lo+hi);
        evaluate(ci, e, p, rates);
        out[0]=rates[0]; out[1]=rates[1]; out[2]=rates[2]; out[3]=rates[3];
        out[4]=e.product; out[5]=e.rd; out[6]=e.transport; out[7]=ci;
        out[8]=rates[4]; out[9]=rates[5];
        out[10]=(e.gb*fminf(e.rh, 1.f)+rates[5])/(e.gb+rates[5]);
        out[11]=rates[6];
}

extern "C" __global__ void run_leaves(const float* u, const float* p, float* output, int n) {
    for (int row=blockIdx.x*blockDim.x+threadIdx.x; row<n; row+=blockDim.x*gridDim.x)
        leaf_gas_exchange_device(u+7*row,p,output+12*row);
}

// Ten-layer two-stream component, independent of the NumPy and JAX code.
// NVRTC device math is built in; no system includes are needed.
__device__ void shortwave_device_albedos(const float* lai, const float* u,
                                         float direct_albedo,bool separate_albedo,float* out,bool track_absorption=false,
                                         const float* layer_reflectance=nullptr,const float* layer_transmittance=nullptr) {
        float beam0=u[0], diffuse0=u[1], ag=u[2], mu=u[3], refl=u[4], tran=u[5];
        float k=.5f/mu, omega=refl+tran, back=.625f*refl+.375f*tran;
        // Explicit .5/k == mu avoids a second, separately rounded reciprocal.
        float beta=(1.f+k)*mu*(1.f-mu*logf(1.f+1.f/mu));
        float a=1.f-omega+back;
        float r[10],t[10],su[10],sd[10],bt[10],beam[11],da[10],ba[10];
        for(int j=0;j<10;++j) {
            if(layer_reflectance) {
                refl=layer_reflectance[j];tran=layer_transmittance[j];
                omega=refl+tran;back=.625f*refl+.375f*tran;a=1.f-omega+back;
            }
            float width=lai[j]/1024.f;
            t[j]=1.f/(1.f+a*width);
            r[j]=back*width*t[j];
            float intercepted=-expm1f(-k*width);
            bt[j]=1.f-intercepted;
            su[j]=omega*beta*intercepted;
            sd[j]=omega*(1.f-beta)*intercepted;
            da[j]=(1.f-omega)*width*t[j];ba[j]=(1.f-omega)*intercepted;
            for(int iter=0;iter<10;++iter) {
                float den=1.f-r[j]*r[j];
                float nr=r[j]+t[j]*t[j]*r[j]/den;
                float nt=t[j]*t[j]/den;
                float nu=su[j]+t[j]*(r[j]*sd[j]+su[j]*bt[j])/den;
                float nd=sd[j]*bt[j]+t[j]*(sd[j]+r[j]*su[j]*bt[j])/den;
                float nb=bt[j]*bt[j];
                if(omega==1.f) {nt=1.f-nr;nd=1.f-nb-nu;}
                if(track_absorption) {
                    float nda=da[j]*(1.f+t[j]/(1.f-r[j]));
                    float nba=ba[j]*(1.f+bt[j])+da[j]*(sd[j]+su[j]*bt[j])/(1.f-r[j]);
                    intercepted=intercepted*(2.f-intercepted);
                    nt=(1.f-nr)-nda;nb=1.f-intercepted;nd=(intercepted-nu)-nba;
                    da[j]=nda;ba[j]=nba;
                }
                r[j]=nr;t[j]=nt;su[j]=nu;sd[j]=nd;bt[j]=nb;
            }
        }
        beam[0]=beam0;
        for(int j=0;j<10;++j) {
            beam[j+1]=beam[j]*bt[j];
            su[j]*=beam[j];sd[j]*=beam[j];
        }
        float re[11],so[11],down[11],up[11],absorbed[10];
        re[10]=ag;so[10]=direct_albedo*beam[10];
        for(int j=9;j>=0;--j) {
            float den=1.f-r[j]*re[j+1];
            re[j]=r[j]+t[j]*t[j]*re[j+1]/den;
            so[j]=su[j]+t[j]*(so[j+1]+re[j+1]*sd[j])/den;
        }
        down[0]=diffuse0;
        for(int j=0;j<10;++j) {
            down[j+1]=(t[j]*down[j]+r[j]*so[j+1]+sd[j])/(1.f-r[j]*re[j+1]);
        }
        for(int j=0;j<11;++j)up[j]=re[j]*down[j]+so[j];
        float total=0.f;
        for(int j=0;j<10;++j) {
            absorbed[j]=beam[j]+down[j]+up[j+1]-beam[j+1]-down[j+1]-up[j];
            if(track_absorption)absorbed[j]=da[j]*(down[j]+up[j+1])+ba[j]*beam[j];
            total+=absorbed[j];
        }
        float ground=separate_albedo?(1.f-direct_albedo)*beam[10]+(1.f-ag)*down[10]:(1.f-ag)*(beam[10]+down[10]);
        float residual=beam0+diffuse0-up[0]-total-ground;
        for(int j=0;j<10;++j)out[j]=absorbed[j];
        for(int j=0;j<11;++j) {out[10+j]=beam[j];out[21+j]=down[j];out[32+j]=up[j];}
        out[43]=up[0];out[44]=ground;out[45]=residual;
}

__device__ void shortwave_device(const float* lai,const float* u,float* out) {
    shortwave_device_albedos(lai,u,u[2],false,out);
}

extern "C" __global__ void run_shortwave(const float* leaf, const float* inputs,
                                         float* output, int n) {
    for (int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        shortwave_device(leaf+10*row,inputs+6*row,output+46*row);
}

extern "C" __global__ void run_longwave(const float* leaf, const float* temperature,
                                        const float* inputs,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x) {
        const float* lai=leaf+10*row;
        const float* temp=temperature+10*row;
        const float* u=inputs+3*row;
        float transmission[10],emission[10],down[11],up[11];
        for(int j=0;j<10;++j) {
            transmission[j]=expf(-lai[j]);
            float square=temp[j]*temp[j];
            emission[j]=(1.f-transmission[j])*5.670374419e-8f*(square*square);
        }
        down[0]=u[0];
        for(int j=0;j<10;++j)down[j+1]=transmission[j]*down[j]+emission[j];
        float ground_square=u[1]*u[1];
        up[10]=(1.f-u[2])*down[10]+u[2]*5.670374419e-8f*(ground_square*ground_square);
        for(int j=9;j>=0;--j)up[j]=transmission[j]*up[j+1]+emission[j];
        float total=0.f;
        float* out=output+35*row;
        for(int j=0;j<10;++j) {
            out[j]=down[j]+up[j+1]-down[j+1]-up[j];
            total+=out[j];
        }
        for(int j=0;j<11;++j){out[10+j]=down[j];out[21+j]=up[j];}
        out[32]=down[10]-up[10];out[33]=up[0];out[34]=u[0]-up[0]-total-out[32];
    }
}

// Ten leaf temperatures + ground, one diagnostic air box, four root layers.
// Compiled with leaf_kernel.cu and radiation_kernel.cu in the same translation unit.
__device__ float ca_sum(const float* v,int n) {
    float s=0.f;for(int j=0;j<n;++j)s+=v[j];return s;
}
__device__ float ca_dot(const float* a,const float* b,int n) {
    float s=0.f;for(int j=0;j<n;++j)s+=a[j]*b[j];return s;
}
__device__ float ca_root_capacity(const float* soil) {
    float total=0.f;for(int j=0;j<4;++j)total+=soil[5+j]>0.f?soil[1+j]:0.f;return total;
}
__device__ void ca_allocate(float demand,const float* soil,float* take) {
    float target=fminf(demand,ca_root_capacity(soil));
    for(int j=0;j<4;++j)take[j]=0.f;
    for(int iter=0;iter<4;++iter) {
        float remaining=fmaxf(0.f,target-ca_sum(take,4)),active[4];
        for(int j=0;j<4;++j)active[j]=take[j]<soil[1+j]?soil[5+j]:0.f;
        float denom=ca_sum(active,4);
        for(int j=0;j<4;++j)take[j]+=fminf(remaining*active[j]/fmaxf(denom,1e-30f),soil[1+j]-take[j]);
    }
}
__device__ float ca_scale(const float* v,int n,float limit) {
    float pos=0.f,neg=0.f;
    for(int j=0;j<n;++j) {pos+=fmaxf(v[j],0.f);neg+=fminf(v[j],0.f);}
    return pos>0.f?fminf(1.f,(limit-neg)/fmaxf(pos,1e-30f)):1.f;
}
struct CanopyWater {
    float wet[10],tr[10],kleaf[10],eg,eb,kunder,kbare,residual,uptake[4];
};
__device__ void ca_water(float q,const float* qs,const float* gs,const float* area,
                         float fv,float rho,const float* u,const float* soil,CanopyWater& w,bool shares=true) {
    float kw[10],kt[10],raw_wet[10],raw_tr[10];
    for(int j=0;j<10;++j) {
        float boundary=rho*fv*area[j]*u[5];
        bool drying=qs[j]>q;
        kw[j]=boundary*(drying?u[14]:1.f);
        kt[j]=boundary*(drying?1.f-u[14]:0.f)*gs[j]/(u[5]+gs[j]);
        raw_wet[j]=kw[j]*(qs[j]-q);
        raw_tr[j]=kt[j]*(qs[j]-q);
    }
    float wet_scale=ca_scale(raw_wet,10,u[15]);
    float tr_limit=soil[0]>0.f?fminf(u[16],ca_root_capacity(soil)):u[16];
    float tr_scale=ca_scale(raw_tr,10,tr_limit);
    for(int j=0;j<10;++j) {
        kw[j]*=raw_wet[j]>0.f?wet_scale:1.f;
        kt[j]*=tr_scale;
        w.tr[j]=kt[j]*(qs[j]-q);
    }
    ca_allocate(ca_sum(w.tr,10),soil,w.uptake);
    if(soil[0]==0.f)for(int j=0;j<4;++j)w.uptake[j]=0.f;
    float glimit=soil[0]>0.f&&shares?fminf(u[17],fmaxf(0.f,soil[9]-w.uptake[0])):u[17];
    float under=rho*fv/(1.f/u[4]+u[9]),bare=rho*(1.f-fv)/(1.f/u[3]+u[9]);
    float ground[2]={under*(qs[10]-q),bare*(qs[10]-u[1])};
    float ground_scale=ca_scale(ground,2,glimit);
    under*=ground[0]>0.f?ground_scale:1.f;
    bare*=ground[1]>0.f?ground_scale:1.f;
    for(int j=0;j<10;++j){w.wet[j]=kw[j]*(qs[j]-q);w.kleaf[j]=kw[j]+kt[j];}
    w.eg=under*(qs[10]-q);w.eb=bare*(qs[10]-u[1]);w.kunder=under;w.kbare=bare;
    w.residual=ca_sum(w.wet,10)+ca_sum(w.tr,10)+w.eg-rho*fv*u[3]*(q-u[1]);
}
__device__ void ca_longwave(const float* area,float eps,float fv,float* matrix) {
    float down[132],up[132],t[10];
    for(int j=0;j<132;++j){down[j]=0.f;up[j]=0.f;}
    down[11]=1.f;
    for(int j=0;j<10;++j) {
        t[j]=expf(-area[j]);
        for(int k=0;k<12;++k)down[(j+1)*12+k]=t[j]*down[j*12+k];
        down[(j+1)*12+j]+=1.f-t[j];
    }
    for(int k=0;k<12;++k)up[120+k]=(1.f-eps)*down[120+k];
    up[130]+=eps;
    for(int j=9;j>=0;--j) {
        for(int k=0;k<12;++k)up[j*12+k]=t[j]*up[(j+1)*12+k];
        up[j*12+j]+=1.f-t[j];
    }
    for(int j=0;j<10;++j)for(int k=0;k<12;++k)
        matrix[j*12+k]=fv*(down[j*12+k]+up[(j+1)*12+k]-down[(j+1)*12+k]-up[j*12+k]);
    for(int k=0;k<12;++k)matrix[120+k]=fv*(down[120+k]-up[120+k]);
    matrix[130]+=-(1.f-fv)*eps;matrix[131]+=(1.f-fv)*eps;
}
__device__ void ca_linear_solve(float* a,float* b,float* x) {
    for(int k=0;k<11;++k) {
        int pivot=k;
        for(int j=k+1;j<11;++j)if(fabsf(a[j*11+k])>fabsf(a[pivot*11+k]))pivot=j;
        for(int j=0;j<11;++j){float old=a[k*11+j];a[k*11+j]=a[pivot*11+j];a[pivot*11+j]=old;}
        float old=b[k];b[k]=b[pivot];b[pivot]=old;
        for(int j=k+1;j<11;++j) {
            float factor=a[j*11+k]/a[k*11+k];
            for(int i=k+1;i<11;++i)a[j*11+i]-=factor*a[k*11+i];
            b[j]-=factor*b[k];
        }
    }
    for(int j=10;j>=0;--j) {
        float value=b[j];for(int k=j+1;k<11;++k)value-=a[j*11+k]*x[k];
        x[j]=value/a[j*11+j];
    }
}
__device__ void canopy_energy_device(const float* area,const float* u,const float* f,
    const float* soil,const float* initial,const float* p,float* out,
    int max_iterations,float tolerance,float q_tolerance,const float* boundary=nullptr,const float* radiation=nullptr) {
        float fv=ca_sum(area,10)>0.f?u[13]:0.f;
        bool active[10];for(int j=0;j<10;++j)active[j]=fv*area[j]>0.f;
        float bands[2][46];
        for(int i=0;i<2;++i) {
            float optics[6]={u[11]*.5f*(1.f-u[21]),u[11]*.5f*u[21],u[19+i],u[22],
                i==0?.1f:.45f,i==0?.05f:.25f};
            shortwave_device(area,optics,bands[i]);
        }
        float bare_sw=u[11]*(1.f-.5f*(u[19]+u[20]));
        float sw[11],par[10],lw[132];
        for(int j=0;j<10;++j) {
            sw[j]=fv*(bands[0][j]+bands[1][j]);
            par[j]=area[j]>0.f?bands[0][j]*4.6f/fmaxf(area[j],1e-30f):0.f;
        }
        sw[10]=fv*(bands[0][44]+bands[1][44])+(1.f-fv)*bare_sw;
        float outgoing_sw=fv*(bands[0][43]+bands[1][43])+(1.f-fv)*(u[11]-bare_sw);
        float latent[11],weights[10];
        for(int j=0;j<11;++j)latent[j]=2.5e6f;
        for(int j=0;j<10;++j)weights[j]=area[j]/fmaxf(ca_sum(area,10),1e-30f);
        if(boundary) {
            for(int j=0;j<10;++j){sw[j]=radiation[j];par[j]=radiation[10+j];}
            sw[10]=ca_sum(radiation+20,5)+radiation[25];outgoing_sw=radiation[26];
            if(boundary[1]>0.f)latent[10]+=334000.f;
        }
        ca_longwave(area,u[18],fv,lw);
        float rho=u[2]/(287.f*u[0]*(1.f+.61f*u[1]));
        float hcan[11],hjac[121];
        for(int j=0;j<10;++j)hcan[j]=rho*1004.f*(fv*area[j]*u[5]);
        hcan[10]=rho*1004.f*(fv*u[4]);
        float hatm=rho*1004.f*fv*u[3],hbare=rho*1004.f*(1.f-fv)*u[3];
        float hden=ca_sum(hcan,11)+hatm;
        for(int j=0;j<11;++j)for(int k=0;k<11;++k)
            hjac[j*11+k]=(j==k?hcan[j]:0.f)-(hden>0.f?hcan[j]*hcan[k]/fmaxf(hden,1e-30f):0.f);
        hjac[120]+=hbare;
        float mol_density=u[2]/(8.314462618f*u[0]),temp[11],qcan=u[1];
        for(int j=0;j<11;++j)temp[j]=(j<10&&!active[j])?u[0]:initial[j];
        if(boundary)temp[10]=boundary[0];
        bool dry=u[16]==0.f||(soil[0]>0.f&&ca_root_capacity(soil)==0.f);
        for(int count=0;count<max_iterations;++count) {
            float qs[11],dq[11],es[11],gas[120],gs[10];
            for(int j=0;j<11;++j) {
                float tc=temp[j]-273.15f;
                es[j]=611.2f*expf(17.67f*tc/(tc+243.5f));
                float den=u[2]-.378f*es[j];
                qs[j]=.622f*es[j]/den;
                dq[j]=.622f*u[2]*es[j]*17.67f*243.5f/(den*den*(tc+243.5f)*(tc+243.5f));
            }
            if(boundary&&boundary[1]>0.f) {
                float t=temp[10];
                es[10]=expf(9.550426f-5723.265f/t+3.53068f*logf(t)-.00728332f*t);
                float slope=5723.265f/(t*t)+3.53068f/t-.00728332f,den=u[2]-.378f*es[10];
                qs[10]=.622f*es[10]/den;dq[10]=.622f*u[2]*es[10]*slope/(den*den);
            }
            float vapor=qcan*u[2]/(.622f+.378f*qcan);
            for(int j=0;j<10;++j) {
                float leaf[7]={par[j],temp[j],u[8],vapor/es[j],u[5]*mol_density,
                    f[j*2]*(dry?0.f:f[j*2+1]),f[j*2+1]};
                leaf_gas_exchange_device(leaf,p,gas+j*12);
                gs[j]=gas[j*12+9]/mol_density;
            }
            float left=u[1],right=u[1];
            for(int j=0;j<11;++j){left=fminf(left,qs[j]);right=fmaxf(right,qs[j]);}
            CanopyWater water;
            for(int iter=0;iter<42;++iter) {
                float middle=.5f*(left+right);
                ca_water(middle,qs,gs,area,fv,rho,u,soil,water,boundary?boundary[2]>0.f:true);
                if(water.residual>0.f)left=middle;else right=middle;
            }
            float qnew=fv>0.f?.5f*(left+right):u[1];
            ca_water(qnew,qs,gs,area,fv,rho,u,soil,water,boundary?boundary[2]>0.f:true);
            float relative_temp[11];for(int j=0;j<11;++j)relative_temp[j]=temp[j]-u[0];
            float air_offset=hden>0.f?ca_dot(hcan,relative_temp,11)/fmaxf(hden,1e-30f):0.f;
            float tair=u[0]+air_offset;
            float sensible[11],evaporation[11],net[11],blackbody[12],residual[11];
            for(int j=0;j<11;++j) {
                sensible[j]=hcan[j]*((temp[j]-u[0])-air_offset);
                float square=temp[j]*temp[j];blackbody[j]=5.670374419e-8f*(square*square);
            }
            blackbody[11]=u[12];sensible[10]+=hbare*(temp[10]-u[0]);
            for(int j=0;j<10;++j)evaporation[j]=water.wet[j]+water.tr[j];
            evaporation[10]=water.eg+water.eb;
            float ground=u[7]*(temp[10]-u[6])+u[10];
            for(int j=0;j<11;++j) {
                net[j]=sw[j]+ca_dot(lw+j*12,blackbody,12);
                residual[j]=net[j]-sensible[j]-2.5e6f*evaporation[j];
            }
            residual[10]+=-ground;
            bool enabled=boundary&&boundary[3]>0.f;
            float mass=0.f,enthalpy=0.f,storage=0.f,wet_adv=0.f,tr_adv=0.f;
            if(boundary) {
                for(int j=0;j<11;++j)residual[j]=net[j]-sensible[j]-latent[j]*evaporation[j];
                ground=residual[10];residual[10]=0.f;
                if(enabled) {
                    mass=fmaxf(0.f,boundary[4]-boundary[6]*ca_sum(water.wet,10));
                    float heat[10];for(int j=0;j<10;++j)heat[j]=334000.f+4180.f*(temp[j]-273.15f);
                    enthalpy=mass*ca_dot(weights,heat,10);storage=(enthalpy-boundary[5])/boundary[6];
                    float uptake=ca_sum(water.uptake,4);
                    float root_mean=uptake>0.f?ca_dot(water.uptake,boundary+7,4)/fmaxf(uptake,1e-30f):0.f;
                    wet_adv=ca_dot(water.wet,heat,10);tr_adv=ca_dot(water.tr,heat,10);
                    for(int j=0;j<10;++j)residual[j]-=weights[j]*storage+water.wet[j]*heat[j]+water.tr[j]*(heat[j]-root_mean);
                }
            }
            float maxres=0.f;for(int j=0;j<11;++j)maxres=fmaxf(maxres,fabsf(residual[j]));
            float qerror=fabsf(qnew-qcan);
            bool energy_balanced=maxres<=tolerance;
            bool converged=energy_balanced&&qerror<=q_tolerance;
            float h=ca_sum(sensible,11),evap=ca_sum(evaporation,11),gross[10],resp[10],netlw[11];
            for(int j=0;j<10;++j){gross[j]=active[j]?gas[j*12]:0.f;resp[j]=active[j]?gas[j*12+5]:0.f;}
            for(int j=0;j<11;++j){out[j]=temp[j];netlw[j]=net[j]-sw[j];}
            out[11]=tair;out[12]=qnew;out[13]=fv*ca_dot(area,gross,10);out[14]=fv*ca_dot(area,resp,10);
            for(int j=0;j<10;++j){out[15+j]=sensible[j];out[30+j]=water.wet[j];out[40+j]=water.tr[j];}
            out[25]=sensible[10];out[26]=h;out[27]=2.5e6f*evap;out[28]=ground;out[29]=ca_sum(net,11);
            out[50]=water.eg+water.eb;for(int j=0;j<4;++j)out[51+j]=water.uptake[j];
            for(int j=0;j<11;++j)out[55+j]=residual[j];
            out[66]=ca_sum(residual,11);out[67]=(float)(count+1);out[68]=converged?1.f:0.f;
            out[69]=water.residual;out[70]=qerror;
            out[71]=h-(hatm*air_offset+hbare*(temp[10]-u[0]));
            out[72]=evap-(rho*fv*u[3]*(qnew-u[1])+water.eb);
            out[73]=outgoing_sw;out[74]=u[12]-ca_sum(netlw,11);
            for(int j=0;j<120;++j)out[75+j]=gas[j];
            if(boundary) {
                out[27]=ca_dot(latent,evaporation,11);out[195]=ground-sw[10];
                for(int j=0;j<6;++j)out[196+j]=radiation[20+j];
                out[202]=latent[10];out[203]=storage;out[204]=mass;out[205]=enthalpy;out[206]=wet_adv;out[207]=tr_adv;
            }
            if(converged)break;
            if(energy_balanced){qcan=qnew;continue;}
            float kcan[11],kd[11],jac[121],rhs[11],delta[11];
            for(int j=0;j<10;++j)kcan[j]=water.kleaf[j];kcan[10]=water.kunder;
            for(int j=0;j<11;++j)kd[j]=kcan[j]*dq[j];
            float kden=ca_sum(kcan,11)+rho*fv*u[3];
            for(int j=0;j<11;++j)for(int k=0;k<11;++k) {
                float ejac=(j==k?kd[j]:0.f)-(kden>0.f?kcan[j]*kd[k]/fmaxf(kden,1e-30f):0.f);
                if(j==10&&k==10)ejac+=water.kbare*dq[10];
                jac[j*11+k]=lw[j*12+k]*((float)(4.*5.670374419e-8)*(temp[k]*temp[k]*temp[k]))-hjac[j*11+k]-2.5e6f*ejac;
                if(j==10&&k==10)jac[j*11+k]+=-u[7];
                if(boundary) {
                    jac[j*11+k]=lw[j*12+k]*((float)(4.*5.670374419e-8)*(temp[k]*temp[k]*temp[k]))-hjac[j*11+k]-latent[j]*ejac;
                    if(enabled&&j<10&&k<10)jac[j*11+k]-=4180.f*mass/boundary[6]*(weights[j]*weights[k]);
                    if(enabled&&j<10&&j==k)jac[j*11+k]-=4180.f*(water.wet[j]+water.tr[j]);
                }
                if(j<10&&!active[j])jac[j*11+k]=j==k?-1.f:0.f;
            }
            for(int j=0;j<11;++j)rhs[j]=-((j<10&&!active[j])?u[0]-temp[j]:residual[j]);
            if(boundary) {for(int k=0;k<11;++k)jac[110+k]=k==10?-1.f:0.f;rhs[10]=0.f;}
            ca_linear_solve(jac,rhs,delta);
            for(int j=0;j<11;++j)temp[j]=fminf(350.f,fmaxf(200.f,temp[j]+.8f*fminf(5.f,fmaxf(-5.f,delta[j]))));
            qcan=qnew;
        }
}

extern "C" __global__ void run_canopy_energy(const float* areas,const float* inputs,
    const float* factors,const float* soils,const float* initials,const float* p,float* outputs,
    int n,int max_iterations,float tolerance,float q_tolerance) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        canopy_energy_device(areas+row*10,inputs+row*23,factors+row*20,soils+row*10,initials+row*11,p,outputs+row*195,
            max_iterations,tolerance,q_tolerance);
}
extern "C" __global__ void run_canopy_boundary(const float* areas,const float* inputs,
    const float* factors,const float* soils,const float* initials,const float* boundaries,const float* radiation,
    const float* p,float* outputs,int n,int max_iterations,float tolerance,float q_tolerance) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        canopy_energy_device(areas+row*10,inputs+row*23,factors+row*20,soils+row*10,initials+row*11,p,outputs+row*208,
            max_iterations,tolerance,q_tolerance,boundaries+row*11,radiation+row*584);
}

// Coupled extensive canopy phase state. Every Newton operation runs on GPU.
// Uses the validated leaf and radiation kernels, with deterministic reductions.
extern "C" __device__ float physical_probe[13776];
struct PhaseContext {
    const float *leaf,*u,*f,*soil,*c,*b,*p,*rad;
    float area[10],fw[10],dry[10],vc[10],weights[11],sw[11],lw[132];
    float fv,rho,mol,atm,bare,hden,trlimit,lg,water_velocity,heat_temperature;
    bool phase_active[10];
};
__device__ void phase_prepare(const float* leaf,const float* u,const float* f,const float* soil,
    const float* stem,const float* c,const float* b,const float* p,const float* rad,PhaseContext& v) {
    v.leaf=leaf;v.u=u;v.f=f;v.soil=soil;v.c=c;v.b=b;v.p=p;v.rad=rad;
    v.water_velocity=u[3];v.heat_temperature=u[0];
    for(int i=0;i<10;++i)v.area[i]=leaf[i]+stem[i];
    v.fv=ca_sum(v.area,10)>0.f?u[13]:0.f;v.rho=u[2]/((287.f*u[0])*(1.f+.61f*u[1]));v.mol=u[2]/(8.314462618f*u[0]);
    v.atm=((v.rho*1004.f)*v.fv)*u[3];v.bare=((v.rho*1004.f)*(1.f-v.fv))*u[3];
    for(int i=0;i<10;++i) {
        v.phase_active[i]=c[2*i]>0.f;
        v.weights[i]=(v.rho*1004.f)*((v.fv*v.area[i])*u[5]);v.vc[i]=((v.rho*v.fv)*v.area[i])*u[5];
        float cap=(.1f*v.fv)*v.area[i];v.fw[i]=cap>0.f?fminf(1.f,powf(c[2*i]/cap,2.f/3.f)):0.f;
        v.dry[i]=(1.f-v.fw[i])*(leaf[i]/(v.area[i]>0.f?v.area[i]:1.f));v.sw[i]=rad[i];
    }
    v.weights[10]=(v.rho*1004.f)*(v.fv*u[4]);v.hden=ca_sum(v.weights,11)+v.atm;
    v.sw[10]=ca_sum(rad+20,5)+rad[25];ca_longwave(v.area,u[18],v.fv,v.lw);
    v.trlimit=soil[0]>0.f?fminf(u[16],ca_root_capacity(soil)):0.f;v.lg=2.5e6f+(b[2]>0.f?334000.f:0.f);
}

__device__ __noinline__ void phase_evaluate(const PhaseContext& v,const float* z,float* residual,float* out) {
    const float *u=v.u,*b=v.b,*c=v.c;float t[11],thermal[10],qs[11],qi[11],es[11],gas[120];
    float mass[10],heat[10],adv[10],vapor[10],iv[10],liq[10],wetle[10],unmet[10],wet[10],tr[10],take[4];
    const float plateau=79.90430622009569f;float q=z[11]*.001f;
    for(int i=0;i<10;++i) {
        t[i]=v.phase_active[i]?273.15f+((fminf(z[i],0.f)*4180.f/2100.f)+fmaxf(z[i]-plateau,0.f)):273.15f+z[i];
        thermal[i]=(c[2*i]*4180.f)*z[i];
    }
    t[10]=z[10];
    for(int i=0;i<11;++i) {
        float tc=t[i]-273.15f;es[i]=611.2f*expf((17.67f*tc)/(tc+243.5f));qs[i]=(.622f*es[i])/(u[2]-.378f*es[i]);
        float esi=expf(((9.550426f-5723.265f/t[i])+3.53068f*logf(t[i]))-.00728332f*t[i]);qi[i]=(.622f*esi)/(u[2]-.378f*esi);
    }
    for(int i=0;i<10;++i) {
        float dry_fraction=v.phase_active[i]?fminf(1.f,fmaxf(0.f,(z[i]*4180.f)/334000.f)):(t[i]>273.15f?1.f:0.f);
        float m=c[2*i],frac=m>0.f?fminf(m,fmaxf(0.f,thermal[i]/334000.f))/m:dry_fraction;
        float sat=frac*qs[i]+(1.f-frac)*qi[i],rh=((q*u[2])/(.622f+.378f*q))/es[i];
        float input[7]={v.rad[10+i],t[i],u[8],rh,u[5]*v.mol,v.f[2*i]*(v.trlimit>0.f?v.f[2*i+1]:0.f),v.f[2*i+1]};
        leaf_gas_exchange_device(input,v.p,gas+12*i);
        float amount=b[4]*((v.vc[i]*(sat>q?v.fw[i]:1.f))*(sat-q));
        float loss=fminf(fmaxf(amount,0.f),m),deposit=fmaxf(-amount,0.f),remaining=m-loss;
        float retained=(remaining/(m>0.f?m:1.f))*thermal[i];
        float added=deposit*((1.f-frac)*(2100.f*(t[i]-273.15f))+frac*(334000.f+4180.f*(t[i]-273.15f)));
        mass[i]=remaining+deposit;heat[i]=retained+added;adv[i]=(thermal[i]-retained)-added;
        vapor[i]=loss-deposit;liq[i]=vapor[i]*frac;iv[i]=vapor[i]-liq[i];wetle[i]=2.5e6f*vapor[i]+334000.f*iv[i];
        wet[i]=vapor[i]/b[4];unmet[i]=fmaxf(amount-loss,0.f);
        tr[i]=(((v.vc[i]*v.dry[i])*gas[12*i+9])/(u[5]*v.mol+gas[12*i+9]))*fmaxf(qs[i]-q,0.f);
    }
    float total=ca_sum(tr,10),scale=total>0.f?fminf(1.f,v.trlimit/fmaxf(total,1e-30f)):1.f;
    for(int i=0;i<10;++i)tr[i]*=scale;
    ca_allocate(ca_sum(tr,10),v.soil,take);if(v.soil[0]==0.f)for(int i=0;i<4;++i)take[i]=0.f;
    float limit=v.soil[0]>0.f&&b[3]>0.f?fminf(u[17],fmaxf(0.f,v.soil[9]-take[0])):u[17];
    float gqs=b[2]>0.f?qi[10]:qs[10];
    float ge[2]={(v.rho*(v.fv*(gqs-q)))/(1.f/u[4]+u[9]),(v.rho*((1.f-v.fv)*(gqs-u[1])))/(1.f/v.water_velocity+u[9])};
    scale=ca_scale(ge,2,limit);for(int i=0;i<2;++i)ge[i]=fminf(ge[i],0.f)+fmaxf(ge[i],0.f)*scale;
    float offset=0.f;for(int i=0;i<11;++i)offset+=v.weights[i]*(t[i]-v.heat_temperature);offset=v.hden>0.f?offset/fmaxf(v.hden,1e-30f):0.f;
    float sensible[11],emission[12],rn[11],latent[11],raw[11],storage[10],trheat[10],physical[11];
    float taken=ca_sum(take,4),root=taken>0.f?ca_dot(take,b+5,4)/fmaxf(taken,1e-30f):0.f;
    for(int i=0;i<11;++i){sensible[i]=v.weights[i]*((t[i]-v.heat_temperature)-offset);emission[i]=5.670374419e-8f*((t[i]*t[i])*(t[i]*t[i]));}
    sensible[10]+=v.bare*(t[10]-v.heat_temperature);emission[11]=u[12];
    for(int i=0;i<11;++i) {
        rn[i]=v.sw[i]+ca_dot(v.lw+12*i,emission,12);
        latent[i]=i<10?wetle[i]/b[4]+2.5e6f*tr[i]:v.lg*ca_sum(ge,2);
        raw[i]=(rn[i]-sensible[i])-latent[i];
    }
    float gh=b[0]>0.f?raw[10]:u[7]*(t[10]-u[6])+u[10];
    for(int i=0;i<10;++i) {
        trheat[i]=tr[i]*((334000.f+4180.f*(t[i]-273.15f))-root);storage[i]=(heat[i]-c[2*i+1])/b[4];
        physical[i]=raw[i]-((storage[i]+adv[i]/b[4])+trheat[i]);
        residual[i]=v.fv*v.area[i]>0.f?raw[i]-((thermal[i]-c[2*i+1])/b[4]+trheat[i]):u[0]-t[i];
    }
    physical[10]=raw[10]-gh;residual[10]=b[0]>0.f?b[1]-t[10]:raw[10]-gh;
    float airwater=((ca_sum(wet,10)+ca_sum(tr,10))+ge[0])-((v.rho*v.fv)*v.water_velocity)*(q-u[1]);
    residual[11]=v.fv>0.f?airwater*2.5e6f:(q-u[1])*1e5f;
    if(!out)return;
    for(int i=0;i<300;++i)out[i]=0.f;
    for(int i=0;i<10;++i) {
        out[i]=t[i];out[15+i]=sensible[i];out[30+i]=wet[i];out[40+i]=tr[i];
        out[195+i]=mass[i];out[205+i]=heat[i];out[215+i]=thermal[i];out[225+i]=iv[i];out[235+i]=liq[i];
        out[245+i]=adv[i];out[255+i]=wetle[i];out[265+i]=unmet[i];out[275+i]=z[i];
        out[13]+=v.leaf[i]*(v.fv*v.area[i]>0.f?gas[12*i]:0.f);out[14]+=v.leaf[i]*(v.fv*v.area[i]>0.f?gas[12*i+5]:0.f);
        out[69]+=(mass[i]-c[2*i])+vapor[i];
    }
    out[13]*=v.fv;out[14]*=v.fv;out[10]=t[10];out[11]=v.heat_temperature+offset;out[12]=q;out[25]=sensible[10];
    out[26]=ca_sum(sensible,11);out[27]=ca_sum(latent,11);out[28]=gh;out[29]=ca_sum(rn,11);out[50]=ca_sum(ge,2);
    for(int i=0;i<4;++i)out[51+i]=take[i];for(int i=0;i<11;++i)out[55+i]=physical[i];out[66]=ca_sum(physical,11);
    out[71]=(ca_sum(sensible,11)-v.atm*offset)-v.bare*(t[10]-v.heat_temperature);out[72]=airwater;out[73]=v.rad[26];
    float lwtotal=0.f;for(int i=0;i<11;++i)lwtotal+=rn[i]-v.sw[i];out[74]=u[12]-lwtotal;
    for(int i=0;i<120;++i)out[75+i]=gas[i];
    out[285]=ca_sum(storage,10);out[286]=ca_sum(adv,10)/b[4];
    for(int i=0;i<10;++i)out[287]+=tr[i]*(334000.f+4180.f*(t[i]-273.15f));out[288]=gh-v.sw[10];
    out[289]=v.rad[25];out[290]=v.lg;for(int i=0;i<12;++i)out[292]=fmaxf(out[292],fabsf(residual[i]));
    for(int i=0;i<5;++i)out[293+i]=v.rad[20+i];
    out[298]=ca_dot(take,b+5,4);out[299]=ca_sum(trheat,10);
}

__device__ void phase_linear(float* a,float* b,float* x) {
    for(int k=0;k<12;++k) {
        int pivot=k;for(int i=k+1;i<12;++i)if(fabsf(a[i*12+k])>fabsf(a[pivot*12+k]))pivot=i;
        for(int i=0;i<12;++i){float old=a[k*12+i];a[k*12+i]=a[pivot*12+i];a[pivot*12+i]=old;}
        float old=b[k];b[k]=b[pivot];b[pivot]=old;
        for(int i=k+1;i<12;++i) {
            float factor=a[i*12+k]/a[k*12+k];for(int j=k+1;j<12;++j)a[i*12+j]-=factor*a[k*12+j];b[i]-=factor*b[k];
        }
    }
    for(int i=11;i>=0;--i){float value=b[i];for(int k=i+1;k<12;++k)value-=a[i*12+k]*x[k];x[i]=value/a[i*12+i];}
}
__device__ float phase_max(const float* v,int n){float x=0.f;for(int i=0;i<n;++i)x=fmaxf(x,fabsf(v[i]));return x;}

__device__ void phase_solve(PhaseContext& v,float* out,int max_iterations,float tolerance) {
    float x[12],ambient[12],alternative[12],lower[12],upper[12],r[12],ra[12];const float plateau=79.90430622009569f;
    for(int i=0;i<10;++i) {
        float mass=v.c[2*i];x[i]=mass>0.f?v.c[2*i+1]/(mass*4180.f):v.u[0]-273.15f;
        ambient[i]=mass>0.f?(v.u[0]<273.15f?(v.u[0]-273.15f)*2100.f/4180.f:plateau+(v.u[0]-273.15f)):v.u[0]-273.15f;
        if(v.u[0]==273.15f)ambient[i]=x[i];
        lower[i]=mass>0.f?-36.75f:-73.15f;upper[i]=mass>0.f?(plateau+350.f)-273.15f:76.85f;
    }
    x[10]=v.b[0]>0.f?v.b[1]:v.u[0];x[11]=v.u[1]*1000.f;ambient[10]=x[10];ambient[11]=x[11];
    lower[10]=200.f;lower[11]=0.f;upper[10]=350.f;upper[11]=190.f;
    phase_evaluate(v,x,r,nullptr);phase_evaluate(v,ambient,ra,nullptr);bool choose=ca_dot(ra,ra,12)<ca_dot(r,r,12),available=false;
    for(int i=0;i<12;++i){alternative[i]=choose?x[i]:ambient[i];x[i]=choose?ambient[i]:x[i];available|=x[i]!=alternative[i];}
    int iteration=0,restarts=0;bool failed=false;
    while(iteration<max_iterations&&!failed) {
        phase_evaluate(v,x,r,out);if(phase_max(r,12)<=tolerance)break;
        for(int i=0;i<10;++i)if(!v.phase_active[i]&&v.fv*v.area[i]>0.f&&fabsf(x[i])<=.05f&&out[30+i]<0.f){
            v.phase_active[i]=true;
            x[i]=x[i]<0.f?(x[i]*2100.f)/4180.f:plateau+x[i];
            alternative[i]=alternative[i]<0.f?(alternative[i]*2100.f)/4180.f:plateau+alternative[i];
            lower[i]=-36.75f;upper[i]=(plateau+350.f)-273.15f;
        }
        phase_evaluate(v,x,r,out);
        for(int i=0;i<10;++i)if(v.phase_active[i]&&out[195+i]==0.f&&x[i]>0.f&&x[i]<plateau&&fabsf(r[i])>tolerance)x[i]=r[i]>0.f?plateau:0.f;
        phase_evaluate(v,x,r,nullptr);float jac[144],delta[12],rhs[12];
        for(int k=0;k<12;++k) {
            float lo[12],hi[12],rl[12],rh[12],step=k==11?.002f:.02f;
            for(int i=0;i<12;++i){lo[i]=x[i];hi[i]=x[i];}
            lo[k]=fmaxf(lower[k],x[k]-step);hi[k]=fminf(upper[k],x[k]+step);
            phase_evaluate(v,lo,rl,nullptr);phase_evaluate(v,hi,rh,nullptr);
            for(int i=0;i<12;++i)jac[i*12+k]=(rh[i]-rl[i])/(hi[k]-lo[k]);
        }
        for(int i=0;i<12;++i)rhs[i]=-r[i];phase_linear(jac,rhs,delta);
        float scale=1.f;for(int i=0;i<12;++i)scale=fmaxf(scale,fabsf(delta[i])/(i<10?20.f:5.f));
        for(int i=0;i<12;++i)delta[i]/=scale;
        float norm=ca_dot(r,r,12),chosen_norm=norm,chosen[12];bool accepted=false;
        for(int i=0;i<12;++i)chosen[i]=x[i];
        // The first strict descent is final, as in the NumPy reference.
        for(int k=0;k<24&&!accepted;++k) {
            float trial[12],rr[12];for(int i=0;i<12;++i)trial[i]=fminf(upper[i],fmaxf(lower[i],x[i]+delta[i]*ldexpf(1.f,-k)));
            phase_evaluate(v,trial,rr,nullptr);
            float trial_norm=ca_dot(rr,rr,12);
            if(!accepted&&trial_norm<norm){for(int i=0;i<12;++i)chosen[i]=trial[i];accepted=true;chosen_norm=trial_norm;}
        }
        // Try the first exact phase edge without replacing old parcel stores.
        float edge_alpha=2.f,edge_value=0.f;int edge_layer=-1;
        for(int i=0;i<10;++i)if(v.phase_active[i]&&delta[i]!=0.f){
            for(int side=0;side<2;++side){
                float edge=side?plateau:0.f,alpha=(edge-x[i])/delta[i];
                if(alpha>0.f&&alpha<=1.f&&alpha<edge_alpha){edge_alpha=alpha;edge_layer=i;edge_value=edge;}
            }
        }
        if(edge_layer>=0){
            float trial[12],rr[12];
            for(int i=0;i<12;++i)trial[i]=fminf(upper[i],fmaxf(lower[i],x[i]+edge_alpha*delta[i]));
            trial[edge_layer]=edge_value;phase_evaluate(v,trial,rr,nullptr);
            float event_norm=ca_dot(rr,rr,12);
            if(event_norm<chosen_norm){for(int i=0;i<12;++i)chosen[i]=trial[i];accepted=true;chosen_norm=event_norm;}
        }
        if(!accepted||chosen_norm>.999f*norm) {
            float low[12],high[12],mid[12],rl[12],rh[12],rr[12];
            for(int i=0;i<12;++i){low[i]=chosen[i];high[i]=chosen[i];}
            low[11]=lower[11];high[11]=upper[11];phase_evaluate(v,low,rl,nullptr);phase_evaluate(v,high,rh,nullptr);
            if(rl[11]>=0.f&&rh[11]<=0.f) {
                for(int k=0;k<32;++k){
                    for(int i=0;i<12;++i)mid[i]=.5f*(low[i]+high[i]);phase_evaluate(v,mid,rr,nullptr);
                    for(int i=0;i<12;++i){if(rr[11]>0.f)low[i]=mid[i];else high[i]=mid[i];}
                }
                for(int i=0;i<12;++i)mid[i]=.5f*(low[i]+high[i]);phase_evaluate(v,mid,rr,nullptr);
                if(ca_dot(rr,rr,12)<chosen_norm){for(int i=0;i<12;++i)chosen[i]=mid[i];accepted=true;++restarts;}
            }
        }
        // Retry a derivative confined to the current smooth phase branch
        // only when the original Newton and humidity steps cannot descend.
        if(!accepted) {
            float local_jac[144],local_rhs[12],local_delta[12];
            for(int k=0;k<12;++k) {
                float lo[12],hi[12],rl[12],rh[12],step=k==11?.002f:.02f;
                for(int i=0;i<12;++i){lo[i]=x[i];hi[i]=x[i];}
                lo[k]=fmaxf(lower[k],x[k]-step);hi[k]=fminf(upper[k],x[k]+step);
                if(k<10&&v.phase_active[k]) {
                    if(x[k]==0.f||x[k]==plateau) {
                        if(delta[k]>=0.f)lo[k]=x[k];else hi[k]=x[k];
                    }
                    if(x[k]<0.f)hi[k]=fminf(hi[k],0.f);
                    else if(x[k]>0.f&&x[k]<plateau){lo[k]=fmaxf(lo[k],0.f);hi[k]=fminf(hi[k],plateau);}
                    else if(x[k]>plateau)lo[k]=fmaxf(lo[k],plateau);
                }
                phase_evaluate(v,lo,rl,nullptr);phase_evaluate(v,hi,rh,nullptr);
                for(int i=0;i<12;++i)local_jac[i*12+k]=(rh[i]-rl[i])/(hi[k]-lo[k]);
            }
            for(int i=0;i<12;++i)local_rhs[i]=-r[i];phase_linear(local_jac,local_rhs,local_delta);
            float local_scale=1.f;for(int i=0;i<12;++i)local_scale=fmaxf(local_scale,fabsf(local_delta[i])/(i<10?20.f:5.f));
            for(int i=0;i<12;++i)local_delta[i]/=local_scale;
            for(int k=0;k<24&&!accepted;++k){
                float trial[12],rr[12];for(int i=0;i<12;++i)trial[i]=fminf(upper[i],fmaxf(lower[i],x[i]+local_delta[i]*ldexpf(1.f,-k)));
                phase_evaluate(v,trial,rr,nullptr);float candidate_norm=ca_dot(rr,rr,12);
                if(!accepted&&candidate_norm<norm){for(int i=0;i<12;++i)chosen[i]=trial[i];accepted=true;chosen_norm=candidate_norm;++restarts;}
            }
        }
        bool retry=!accepted&&available;
        for(int i=0;i<12;++i)x[i]=retry?alternative[i]:chosen[i];
        if(retry){available=false;++restarts;}failed=!(accepted||retry);++iteration;
    }
    phase_evaluate(v,x,r,out);out[67]=iteration+1;out[68]=!failed&&phase_max(r,12)<=tolerance&&phase_max(out+55,11)<=tolerance*1.05f;
    out[291]=restarts;
    const float offsets[16]={-1.f,-.25f,-.1f,-.05f,-.02f,-.005f,0.f,.005f,.02f,.05f,.1f,.25f,1.f,4.f,8.f,-8.f};
    for(int row=0;row<41;++row){
        float trial[12],rr[12],detail[300];for(int k=0;k<12;++k)trial[k]=x[k];
        if(row>=1&&row<=20){int layer=(row-1)/2,side=(row-1)%2;if(v.phase_active[layer])trial[layer]=side?plateau:0.f;}
        else if(row>=21&&row<=36)trial[4]+=offsets[row-21];
        else if(row>=37){const float dq[4]={-.001f,-.0001f,.0001f,.001f};trial[11]+=dq[row-37];}
        phase_evaluate(v,trial,rr,detail);
        for(int k=0;k<12;++k){physical_probe[row*336+k]=trial[k];physical_probe[row*336+12+k]=rr[k];}
        for(int k=0;k<300;++k)physical_probe[row*336+24+k]=detail[k];
        float t=detail[4],tc=t-273.15f,es=611.2f*expf((17.67f*tc)/(tc+243.5f));
        float ql=(.622f*es)/(v.u[2]-.378f*es);
        float esi=expf(((9.550426f-5723.265f/t)+3.53068f*logf(t))-.00728332f*t);
        float qi=(.622f*esi)/(v.u[2]-.378f*esi),m=v.c[8];
        float thermal=(m*4180.f)*trial[4];
        float frac=m>0.f?fminf(m,fmaxf(0.f,thermal/334000.f))/m:fminf(1.f,fmaxf(0.f,(trial[4]*4180.f)/334000.f));
        float sat=frac*ql+(1.f-frac)*qi,q=trial[11]*.001f;
        float fraction=sat>q?v.fw[4]:1.f,amount=v.b[4]*((v.vc[4]*fraction)*(sat-q));
        float vapor=fminf(fmaxf(amount,0.f),m)-fmaxf(-amount,0.f);
        float dqs=(ql-qi)*(4180.f/334000.f);
        float dv=amount<0.f?v.b[4]*(v.vc[4]*dqs):(amount<m?v.b[4]*((v.vc[4]*v.fw[4])*dqs):0.f);
        float deriv=-(((2.5e6f+334000.f*(1.f-frac))*dv-334000.f*vapor*(4180.f/334000.f))/v.b[4])-(m*4180.f)/v.b[4];
        float aux[12]={ql,qi,frac,sat,q,fraction,amount,dv,deriv,(2.5e6f*dv)/v.b[4],m,ca_dot(rr,rr,12)};
        for(int k=0;k<12;++k)physical_probe[row*336+324+k]=aux[k];
    }
}
extern "C" __global__ void run_canopy_phase(const float* leaf,const float* u,const float* f,const float* soil,
    const float* stem,const float* c,const float* b,const float* radiation,const float* p,float* out,int n,int max_iterations,float tolerance) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x) {
        PhaseContext v;phase_prepare(leaf+row*10,u+row*23,f+row*20,soil+row*10,stem+row*10,c+row*20,b+row*9,p,radiation+row*584,v);
        phase_solve(v,out+row*300,max_iterations,tolerance);
    }
}

// Native CUDA extensive soil thermodynamics; physical T is TF + offset.
// This is independent of the released AHC/Thomas temperature solver.
__device__ void cap_partials(float total,float potential,float &v,float &ds,float &dp) {
    float width=fmaxf(.04f*total,1e-12f),dw=.04f*total>1e-12f?.04f:0.f;
    float diff=total-potential,sign=diff>0.f?1.f:(diff<0.f?-1.f:0.f);
    float rounded=fmaxf(width-fabsf(diff),0.f);
    v=fminf(total,potential)-rounded*rounded/(4.f*width);
    ds=(diff<0.f?1.f:(diff>0.f?0.f:.5f))-rounded*(dw-sign)/(2.f*width);
    ds+=rounded*rounded*dw/(4.f*width*width);
    dp=(diff>0.f?1.f:(diff<0.f?0.f:.5f))-rounded*sign/(2.f*width);
    if(v<=0.f) {v=0.f;ds=0.f;dp=0.f;}
}

__device__ void soil_thermodynamics(float water,float offset,float dz,float por,float b,float psi,int option,
                                   float &h,float &c,float &liquid) {
    float temperature=273.15f+offset,theta=water/(1000.f*dz);
    float coefficient=334000.f/(9.80616f*psi);
    float raw=(coefficient*fmaxf(-offset,0.f))/temperature,ratio=fmaxf(raw,1e-12f);
    float potential=expf(fminf(logf(por)-logf(ratio)/b,logf(2.f*por)));
    float denominator=((b*temperature)*temperature)*ratio;
    float dp=raw>1e-12f?((potential*coefficient)*273.15f)/denominator:0.f;
    float unused,dpot;cap_partials(theta,potential,liquid,unused,dpot);
    float derivative=dpot*dp;
    if(option==2) for(int j=0;j<3;++j) {
        float limited,ds,dl;cap_partials(liquid,potential,limited,ds,dl);
        float slope=ds*derivative+dl*dp;
        if(limited>=theta) slope=0.f;
        liquid=.5f*(liquid+fminf(theta,limited));derivative=.5f*(derivative+slope);
    }
    liquid=offset>=0.f?water:fminf(water,fmaxf(0.f,liquid*(1000.f*dz)));
    derivative=(offset>=0.f?0.f:derivative)*(1000.f*dz);
    float dry=((1.f-por)*2e6f)*dz;
    float sensible=(dry+2100.f*water)+2080.f*liquid;
    h=sensible*offset+334000.f*liquid;
    c=sensible+(2080.f*offset+334000.f)*derivative;
}

__device__ bool invert_soil_enthalpy(float water,float target,float dz,float por,float b,float psi,int option,
                                    float &t,float &h,float &c,float &liquid,float &count) {
    float lo=-123.15f,hi=126.85f,hlo,hhi;
    soil_thermodynamics(water,lo,dz,por,b,psi,option,hlo,c,liquid);
    soil_thermodynamics(water,hi,dz,por,b,psi,option,hhi,c,liquid);
    bool valid=target>=hlo&&target<=hhi;
    float dry=((1.f-por)*2e6f)*dz;
    t=fminf(hi,fmaxf(lo,(target-334000.f*water)/(dry+4180.f*water)));
    count=0.f;
    for(int iteration=0;iteration<64;++iteration) {
        soil_thermodynamics(water,t,dz,por,b,psi,option,h,c,liquid);count+=1.f;
        float err=h-target;
        float tol=fmaxf(2e-8f,8.f*1.1920928955078125e-7f*fmaxf(1.f,fmaxf(fabsf(target),fabsf(334000.f*liquid))));
        if(fabsf(err)<=tol) return valid;
        if(err<0.f)lo=t;else if(err>0.f)hi=t;
        float trial=t-err/c;
        if(!(trial>lo&&trial<hi)) trial=.5f*(lo+hi);
        t=trial;
    }
    soil_thermodynamics(water,t,dz,por,b,psi,option,h,c,liquid);
    float tol=fmaxf(2e-8f,8.f*1.1920928955078125e-7f*fmaxf(1.f,fmaxf(fabsf(target),fabsf(334000.f*liquid))));
    return valid&&fabsf(h-target)<=tol;
}

extern "C" __global__ void run_soil_thermodynamics(const float* inputs,const int* option,
                                                  float* output,int inverse,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x) {
        const float* u=inputs+6*row;float* out=output+9*row;
        float t=u[1],h,c,liq,count=0.f;bool ok=true;
        if(inverse) ok=invert_soil_enthalpy(u[0],u[1],u[2],u[3],u[4],u[5],option[row],t,h,c,liq,count);
        else soil_thermodynamics(u[0],t,u[2],u[3],u[4],u[5],option[row],h,c,liq);
        out[0]=t;out[1]=t+273.15f;out[2]=liq;out[3]=u[0]-liq;
        out[4]=h;out[5]=c;out[6]=inverse?h-u[1]:0.f;out[7]=count;out[8]=ok?1.f:0.f;
    }
}

// Included after enthalpy_kernel.cu; one thread advances one independent column.
__device__ bool heat_evaluate(const float* h,const float* old,const float* mass,const float* z,
                             const float* solar,const float* conduct,int ns,const float* props,const float* bc,
                             int phase,float* residual,float* t,float* derivative,float* liquid,float* flux,float &top,float* rounding) {
    bool valid=true;
    for(int i=0;i<9;++i) {
        t[i]=0.f;derivative[i]=0.f;liquid[i]=0.f;rounding[i]=0.f;
        if(i<ns) {
            float upper=334000.f*mass[i];
            if(h[i]<0.f) {t[i]=h[i]/(2100.f*mass[i]);derivative[i]=1.f/(2100.f*mass[i]);}
            else if(h[i]>upper) {t[i]=(h[i]-upper)/(4180.f*mass[i]);derivative[i]=1.f/(4180.f*mass[i]);}
            liquid[i]=fminf(mass[i],fmaxf(0.f,h[i]/334000.f));
            rounding[i]=(1.1920928955078125e-7f*(fabsf(h[i])+(h[i]>upper?upper:0.f)))*derivative[i]+
                (2.f*1.1920928955078125e-7f)*fabsf(t[i]);
        } else if(i<ns+4) {
            float reconstructed,capacity,count;
            bool ok=invert_soil_enthalpy(mass[i],h[i],z[i],props[0],props[1],props[3],phase,t[i],reconstructed,capacity,liquid[i],count);
            derivative[i]=1.f/capacity;valid=valid&&ok;
            rounding[i]=fabsf(reconstructed-h[i])/capacity+(2.f*1.1920928955078125e-7f)*fabsf(t[i]);
        }
    }
    for(int i=0;i<8;++i) flux[i]=conduct[i]*(t[i]-t[i+1]);
    top=bc[1]+bc[3]*(bc[2]-t[0]);
    for(int i=0;i<9;++i) {
        float from=i==0?top:flux[i-1],to=i==8?0.f:flux[i];
        residual[i]=i<ns+4?(h[i]-old[i])-bc[0]*((solar[i]+from)-to):0.f;
    }
    return valid;
}

__device__ float heat_tolerance(int i,const float* h,const float* tol,const float* rounding,const float* conduct,const float* bc) {
    float up=i==0?0.f:conduct[i-1],down=i==8?0.f:conduct[i];
    float err=up*(rounding[i]+(i==0?0.f:rounding[i-1]))+down*(rounding[i]+(i==8?0.f:rounding[i+1]));
    err+=i==0?bc[3]*rounding[i]:0.f;
    return fmaxf(tol[i],8.f*1.1920928955078125e-7f*fabsf(h[i]))+(2.f*bc[0])*err;
}

__device__ float heat_norm(const float* r,const float* h,const float* tol,const float* rounding,const float* conduct,const float* bc) {
    float v=0.f;for(int i=0;i<9;++i)v=fmaxf(v,fabsf(r[i])/heat_tolerance(i,h,tol,rounding,conduct,bc));return v;
}

__device__ void heat_linear(const float* d,const float* r,const float* conduct,const float* bc,float* delta) {
    float diag[9],upper[9],lower[9],rhs[9];
    for(int i=0;i<9;++i) {
        float up=i==0?0.f:conduct[i-1],down=i==8?0.f:conduct[i];
        diag[i]=1.f+(bc[0]*((up+down)+(i==0?bc[3]:0.f)))*d[i];
        lower[i]=-(bc[0]*up)*(i==0?0.f:d[i-1]);
        upper[i]=-(bc[0]*down)*(i==8?0.f:d[i+1]);rhs[i]=-r[i];
    }
    for(int i=1;i<9;++i) {
        float ratio=lower[i]/diag[i-1];diag[i]-=ratio*upper[i-1];rhs[i]-=ratio*rhs[i-1];
    }
    delta[8]=rhs[8]/diag[8];
    for(int i=7;i>=0;--i) delta[i]=(rhs[i]-upper[i]*delta[i+1])/diag[i];
}

__device__ void joint_heat_device(const float* cells,const float* props,const int* options,const float* bc,float* out) {
    int ns=options[0],phase=options[1];float por=props[0],quartz=props[2];
    float mass[9],old[9],h[9],z[9],solar[9],k[9],conduct[8],upperH[9];
    float tolerance[9],max_tolerance=0.f;
    for(int i=0;i<9;++i) {
        mass[i]=cells[5*i];old[i]=h[i]=cells[5*i+1];z[i]=cells[5*i+2];solar[i]=cells[5*i+4];
        upperH[i]=334000.f*mass[i];k[i]=cells[5*i+3];
        if(k[i]==0.f) {
            if(i<ns) {
                float rho=fminf(mass[i]/z[i],917.f);
                k[i]=.023f+((7.75e-5f*rho)+(1.105e-6f*rho)*rho)*(float)(2.29-.023);
            } else {
                float saturation=fminf(1.f,fmaxf(0.f,mass[i]/((1000.f*z[i])*por)));
                float kersten=saturation>.1f?fminf(1.f,fmaxf(0.f,logf(fmaxf(saturation,1e-6f))*(float).4342944819032518+1.f)):0.f;
                k[i]=.2f+((.6f+1.6f*quartz)-.2f)*kersten;
            }
        }
        float scale=fmaxf(fabsf(h[i]),fmaxf(fabsf(bc[0]*(solar[i]+(i==0?bc[1]:0.f))),1.f));
        tolerance[i]=fmaxf(2e-7f,8.f*1.1920928955078125e-7f*scale);max_tolerance=fmaxf(max_tolerance,tolerance[i]);
    }
    for(int i=0;i<8;++i) conduct[i]=i<ns+3?1.f/((.5f*z[i])/k[i]+(.5f*z[i+1])/k[i+1]):0.f;
    float residual[9],t[9],d[9],liq[9],flux[8],top,rounding[9];
    bool valid=heat_evaluate(h,old,mass,z,solar,conduct,ns,props,bc,phase,residual,t,d,liq,flux,top,rounding);
    bool done=heat_norm(residual,h,tolerance,rounding,conduct,bc)<=1.f;int count=0;
    float previous_h[9],previous_r[9];
    for(int i=0;i<9;++i){previous_h[i]=h[i];previous_r[i]=residual[i];}
    while(count<80&&!done&&valid) {
        float merit=0.f,weights[9],delta[9],f0[9],f1[9];
        bool at0[9],at1[9],ev0[9],ev1[9];
        for(int i=0;i<9;++i) {
            // Hold merit weights fixed across a phase-event line search.
            weights[i]=heat_tolerance(i,h,tolerance,rounding,conduct,bc);
            merit+=fabsf(residual[i])/weights[i];
            at0[i]=i<ns&&h[i]==0.f;at1[i]=i<ns&&h[i]==upperH[i];
        }
        int dominant=0;float peak_dominant=-1.f;
        for(int i=0;i<ns+4;++i){float ratio=fabsf(residual[i])/weights[i];if(ratio>peak_dominant){peak_dominant=ratio;dominant=i;}}
        bool stalled=count>0&&h[dominant]==previous_h[dominant]&&fabsf(residual[dominant])>=fabsf(previous_r[dominant]);
        for(int i=0;i<9;++i){previous_h[i]=h[i];previous_r[i]=residual[i];}
        for(int a=0;a<12;++a) {
            heat_linear(d,residual,conduct,bc,delta);
            for(int i=0;i<ns;++i) {
                if(at0[i]) d[i]=delta[i]<0.f?1.f/(2100.f*mass[i]):0.f;
                if(at1[i]) d[i]=delta[i]>0.f?1.f/(4180.f*mass[i]):0.f;
            }
        }
        heat_linear(d,residual,conduct,bc,delta);
        // A tiny accepted change in another reservoir can conceal a stuck
        // dominant equation at the soil freezing cap. Rebuild this direction
        // from represented T(H) chords without relaxing any residual bound.
        if(stalled)for(int chord=0;chord<4;++chord){
            float trial[9],r2[9],t2[9],d2[9],l2[9],f2[8],top2,round2[9];
            for(int i=0;i<9;++i)trial[i]=h[i]+delta[i];
            bool good=heat_evaluate(trial,old,mass,z,solar,conduct,ns,props,bc,phase,r2,t2,d2,l2,f2,top2,round2);
            if(!good)break;
            for(int i=0;i<ns+4;++i){
                float change=trial[i]-h[i];
                if(change!=0.f){float slope=(t2[i]-t[i])/change;if(isfinite(slope)&&slope>=0.f)d[i]=slope;}
            }
            heat_linear(d,residual,conduct,bc,delta);
        }
        float step=1.f;
        for(int i=0;i<9;++i) {
            f0[i]=-h[i]/(delta[i]!=0.f?delta[i]:1.f);f1[i]=(upperH[i]-h[i])/(delta[i]!=0.f?delta[i]:1.f);
            ev0[i]=i<ns&&!at0[i]&&delta[i]!=0.f&&f0[i]>0.f&&f0[i]<=1.f;
            ev1[i]=i<ns&&!at1[i]&&delta[i]!=0.f&&f1[i]>0.f&&f1[i]<=1.f;
            if(ev0[i])step=fminf(step,f0[i]);if(ev1[i])step=fminf(step,f1[i]);
        }
        float candidate[9],trial_r[9],trial_t[9],trial_d[9],trial_liq[9],trial_f[8],trial_top,trial_rounding[9];
        bool accepted=false;
        for(int search=0;search<40&&!accepted;++search) {
            for(int i=0;i<9;++i) {
                candidate[i]=h[i]+step*delta[i];
                if(ev0[i]&&step==f0[i])candidate[i]=0.f;
                else if(ev1[i]&&step==f1[i])candidate[i]=upperH[i];
            }
            bool good=heat_evaluate(candidate,old,mass,z,solar,conduct,ns,props,bc,phase,
                trial_r,trial_t,trial_d,trial_liq,trial_f,trial_top,trial_rounding);
            float trial_merit=0.f;for(int i=0;i<9;++i)trial_merit+=fabsf(trial_r[i])/weights[i];
            // A tiny exact phase-event move can round to the same merit.
            // Admit that represented endpoint; the final bound still holds.
            bool exact_event=false;
            for(int i=0;i<ns;++i)exact_event=exact_event||(ev0[i]&&step==f0[i])||(ev1[i]&&step==f1[i]);
            accepted=good&&(trial_merit<merit||(exact_event&&trial_merit==merit)||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);
            if(accepted)for(int i=0;i<9;++i)h[i]=candidate[i];
            step*=.5f;
        }
        if(!accepted) {
            // A rounded neighbouring store can block the coupled Newton
            // direction. Retain every original merit and convergence test.
            int worst=0;float peak=-1.f;
            for(int i=0;i<ns+4;++i){float ratio=fabsf(residual[i])/weights[i];if(ratio>peak){peak=ratio;worst=i;}}
            float derivative=d[worst];
            if(at0[worst])derivative=residual[worst]>0.f?1.f/(2100.f*mass[worst]):0.f;
            if(at1[worst])derivative=residual[worst]<0.f?1.f/(4180.f*mass[worst]):0.f;
            float up=worst==0?0.f:conduct[worst-1],down=worst==8?0.f:conduct[worst];
            float diagonal=1.f+(bc[0]*((up+down)+(worst==0?bc[3]:0.f)))*derivative;
            float correction=-residual[worst]/diagonal;
            float scalar_step=1.f;
            float e0=-h[worst]/(correction!=0.f?correction:1.f),e1=(upperH[worst]-h[worst])/(correction!=0.f?correction:1.f);
            bool land0=worst<ns&&!at0[worst]&&correction!=0.f&&e0>0.f&&e0<=1.f;
            bool land1=worst<ns&&!at1[worst]&&correction!=0.f&&e1>0.f&&e1<=1.f;
            if(land0)scalar_step=fminf(scalar_step,e0);if(land1)scalar_step=fminf(scalar_step,e1);
            for(int search=0;search<40&&!accepted;++search) {
                for(int i=0;i<9;++i)candidate[i]=h[i];
                candidate[worst]=h[worst]+scalar_step*correction;
                if(land0&&scalar_step==e0)candidate[worst]=0.f;
                else if(land1&&scalar_step==e1)candidate[worst]=upperH[worst];
                bool good=heat_evaluate(candidate,old,mass,z,solar,conduct,ns,props,bc,phase,
                    trial_r,trial_t,trial_d,trial_liq,trial_f,trial_top,trial_rounding);
                float trial_merit=0.f;for(int i=0;i<9;++i)trial_merit+=fabsf(trial_r[i])/weights[i];
                bool exact_event=(land0&&scalar_step==e0)||(land1&&scalar_step==e1);
                accepted=good&&(trial_merit<merit||(exact_event&&trial_merit==merit)||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);
                if(accepted)for(int i=0;i<9;++i)h[i]=candidate[i];
                scalar_step*=.5f;
            }
        }
        bool good=heat_evaluate(h,old,mass,z,solar,conduct,ns,props,bc,phase,residual,t,d,liq,flux,top,rounding);
        done=heat_norm(residual,h,tolerance,rounding,conduct,bc)<=1.f;valid=good&&(accepted||done);count++;
    }
    float sum_sw=0.f,change=0.f;
    for(int i=0;i<9;++i) {
        sum_sw+=i<ns+4?solar[i]:0.f;change+=h[i]-old[i];
        out[i]=h[i];out[9+i]=i<ns+4?t[i]+273.15f:0.f;out[18+i]=t[i];
        out[27+i]=liq[i];out[36+i]=mass[i]-liq[i];out[45+i]=residual[i];
        out[62+i]=heat_tolerance(i,h,tolerance,rounding,conduct,bc);max_tolerance=fmaxf(max_tolerance,out[62+i]);
    }
    for(int i=0;i<8;++i)out[54+i]=flux[i];
    float incoming=bc[0]*(top+sum_sw);
    out[71]=incoming;out[72]=change-incoming;out[73]=top;out[74]=(float)(count+1);
    out[75]=done&&valid?1.f:0.f;out[76]=max_tolerance;
}

extern "C" __global__ void run_joint_heat(const float* cells,const float* props,const int* options,
                                          const float* boundary,float* out,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        joint_heat_device(cells+45*row,props+4*row,options+2*row,boundary+4*row,out+77*row);
}

// Extensive snow transfer, fixed five-cell output and six-cell insertion.
__device__ void snow_mass_phase(float m,float h,float& offset,float& ice,float& liquid) {
    liquid=fminf(m,fmaxf(0.f,h/334000.f));ice=m-liquid;
    float safe=fmaxf(m,1e-30f);
    offset=h<0.f?h/(2100.f*safe):(h>334000.f*m?(h-334000.f*m)/(4180.f*safe):0.f);
}

__device__ int snow_mass_regrid(const float* cells,float* out) {
    float old[7]={0.f},edges[6]={0.f},z[5]={0.f};
    for(int i=0;i<6;++i)old[i+1]=old[i]+cells[9*i+2];
    float depth=old[6];int n=0;
    if(depth<=.03f)z[0]=depth;
    else if(depth<=.04f)z[0]=z[1]=depth/2.f;
    else if(depth<=.07f){z[0]=.02f;z[1]=depth-.02f;}
    else if(depth<=.12f){z[0]=.02f;z[1]=z[2]=(depth-.02f)/2.f;}
    else if(depth<=.18f){z[0]=.02f;z[1]=.05f;z[2]=depth-.07f;}
    else if(depth<=.29f){z[0]=.02f;z[1]=.05f;z[2]=z[3]=(depth-.07f)/2.f;}
    else if(depth<=.41f){z[0]=.02f;z[1]=.05f;z[2]=.11f;z[3]=depth-.18f;}
    else if(depth<=.64f){z[0]=.02f;z[1]=.05f;z[2]=.11f;z[3]=z[4]=(depth-.18f)/2.f;}
    else {z[0]=.02f;z[1]=.05f;z[2]=.11f;z[3]=.23f;z[4]=depth-.41f;}
    for(int i=0;i<5;++i){n+=z[i]>0.f;edges[i+1]=edges[i]+z[i];}
    edges[n]=depth;
    for(int p=0;p<45;++p)out[p]=0.f;
    for(int k=0;k<6;++k) {
        const float* v=cells+9*k;float span[5],total=0.f;int last=-1,containing=0;
        for(int i=0;i<5;++i) {
            span[i]=i<n?fmaxf(0.f,fminf(edges[i+1],old[k+1])-fmaxf(edges[i],old[k])):0.f;
            total+=span[i];if(span[i]>0.f)last=i;if(i<n&&edges[i+1]<=old[k])++containing;
        }
        if(last<0)last=min(containing,max(n-1,0));
        float content[9],remaining[9];
        for(int p=0;p<9;++p)content[p]=v[p];
        content[2]=0.f;content[3]=v[0]/fmaxf(v[3],1e-30f);
        for(int p=0;p<9;++p)remaining[p]=content[p];
        for(int i=0;i<5;++i)for(int p=0;p<9;++p) {
            float part=i==last?remaining[p]:(span[i]>0.f&&i<last?content[p]*(span[i]/fmaxf(total,1e-30f)):0.f);
            if(v[0]<=0.f)part=0.f;
            out[9*i+p]+=part;remaining[p]-=part;
        }
    }
    for(int i=0;i<5;++i){out[9*i+2]=z[i];out[9*i+3]=i<n?out[9*i]/fmaxf(out[9*i+3],1e-30f):54.5f;}
    return n;
}

__device__ float snow_receiver_volume(const float* v,float amount,float specific) {
    float offset,ice,liquid;snow_mass_phase(v[0]+amount,v[1]+amount*specific,offset,ice,liquid);
    return ice/917.f+liquid/1000.f;
}

__device__ void snow_transfer_device(const float* input,int n,int mode,const float* u,float* out) {
    float cells[54]={0.f},ledger[28]={0.f};
    for(int i=0;i<45;++i)cells[i]=input[i];
    bool remap=mode!=2;
    if(mode==1) {
        if(u[0]>0.f) {
            for(int i=44;i>=0;--i)cells[i+9]=cells[i];
            cells[0]=u[0];cells[1]=(u[0]*2100.f)*u[1];cells[2]=u[0]/u[2];cells[3]=u[3];
            ledger[0]=cells[0];ledger[1]=cells[1];
            for(int i=0;i<5;++i)cells[4+i]=ledger[2+i]=u[11+i];
        } else remap=false;
    } else if(mode==2) {
        float heat=u[0]*(334000.f+4180.f*u[1]);
        cells[0]+=u[0];cells[1]+=heat;ledger[0]=u[0];ledger[1]=heat;
    } else if(mode==3) {
        float water=0.f,heat=0.f,tracer[5]={0.f};
        for(int k=0;k<n;++k) {
            float* v=cells+9*k;v[0]+=water;v[1]+=heat;
            for(int p=0;p<5;++p)v[4+p]+=tracer[p];
            float offset,ice,liquid;snow_mass_phase(v[0],v[1],offset,ice,liquid);
            v[2]=fmaxf(v[2],ice/917.f);
            float pore=fmaxf(0.f,1.f-ice/(917.f*fmaxf(v[2],1e-30f)));
            float cap=((u[4]*pore)*v[2])*1000.f;
            float potential=ice==0.f?liquid:(pore>=u[5]?fmaxf(0.f,liquid-cap):0.f);
            float specific=334000.f+4180.f*offset;water=potential;
            if(k+1<n&&potential>0.f) {
                const float* next=cells+9*(k+1);float nt,ni,nl;
                snow_mass_phase(next[0],next[1],nt,ni,nl);
                if(1.f-ni/(917.f*fmaxf(next[2],1e-30f))<u[5])water=0.f;
                else if(snow_receiver_volume(next,potential,specific)>next[2]) {
                    float low=0.f,high=potential;
                    for(int j=0;j<48;++j) {
                        float mid=(low+high)*.5f;
                        if(snow_receiver_volume(next,mid,specific)<=next[2])low=mid;else high=mid;
                    }
                    water=low;
                }
            }
            float left=liquid-water,occupied=ice/917.f+left/1000.f;
            float overflow=ice==0.f?left:(occupied>v[2]?fmaxf(0.f,left-(v[2]-ice/917.f)*1000.f):0.f);
            float total=ice==0.f?liquid:water+overflow;heat=water*specific;
            for(int p=0;p<5;++p) {
                float fraction=fminf(1.f,(u[6+p]*total)/fmaxf(v[0],1e-30f));
                float exported=total==v[0]?v[4+p]:v[4+p]*fraction;
                float split=fminf(1.f,fmaxf(0.f,water/fmaxf(total,1e-30f)));
                tracer[p]=water==total?exported:(total>0.f?exported*split:0.f);
                ledger[16+p]+=exported-tracer[p];v[4+p]-=exported;
            }
            ledger[14]+=overflow;ledger[15]+=overflow*specific;
            v[0]-=total;v[1]-=total*specific;
            if(v[0]==0.f){v[1]=0.f;v[2]=0.f;}
        }
        ledger[7]=water;ledger[8]=heat;for(int p=0;p<5;++p)ledger[9+p]=tracer[p];
    } else if(mode==4) {
        float remaining=u[0],actual=0.f,energy=0.f,residue[5]={0.f};
        for(int k=0;k<n;++k) {
            float* v=cells+9*k;float offset,ice,liquid;
            snow_mass_phase(v[0],v[1],offset,ice,liquid);
            float loss=fminf(remaining,ice),heat=(loss*2100.f)*offset,mass=v[0]-loss;
            v[2]*=mass/fmaxf(v[0],1e-30f);v[0]=mass;v[1]=mass==0.f?0.f:v[1]-heat;
            for(int p=0;p<5;++p) {
                float a=v[4+p]+residue[p];residue[p]=mass==0.f?a:0.f;v[4+p]=mass==0.f?0.f:a;
            }
            remaining-=loss;actual+=loss;energy+=heat;
        }
        ledger[21]=actual;ledger[22]=energy;for(int p=0;p<5;++p)ledger[23+p]=residue[p];
    }
    if(remap)n=snow_mass_regrid(cells,out);
    else for(int i=0;i<45;++i)out[i]=cells[i];
    out[45]=(float)n;for(int i=0;i<28;++i)out[46+i]=ledger[i];
}

extern "C" __global__ void run_snow_transfer(const float* cells,const int* counts,const int* modes,
                                              const float* inputs,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        snow_transfer_device(cells+row*45,counts[row],modes[row],inputs+row*16,output+row*74);
}

// Requires snow_mass_kernel.cu: phase diagnosis and conservative remapping.
__device__ void snow_vapor_device(const float* c,int n,const float* u,float* out) {
    float cells[54]={0.f};for(int i=0;i<45;++i)cells[i]=c[i];
    float amount=0.f,ice=0.f,liquid=0.f,heat=0.f,residue[5]={0.f};
    if(u[0]>0.f) {
        float supply=c[0],bound=(64.f*1.1920928955078125e-7f)*fmaxf(u[0],supply);
        amount=fabsf(u[0]-supply)<=bound?supply:u[0];bool full=amount==supply;
        float fraction=full?1.f:amount/fmaxf(supply,1e-30f),offset,liquid0;
        snow_mass_phase(supply,c[1],offset,ice,liquid0);
        ice=full?ice:(amount*ice)/fmaxf(supply,1e-30f);liquid=amount-ice;heat=fraction*c[1];
        cells[0]=supply-amount;cells[1]=c[1]-heat;cells[2]=c[2]*(1.f-fraction);
        if(full) {
            for(int p=0;p<5;++p) {if(n>1)cells[13+p]+=cells[4+p];else residue[p]=cells[4+p];}
            --n;
            for(int i=0;i<5;++i)for(int p=0;p<9;++p)
                cells[9*i+p]=i<n?cells[9*(i+1)+p]:(p==3?54.5f:0.f);
        }
    } else if(u[0]<0.f) {
        amount=u[0];ice=u[1]<0.f?amount:0.f;liquid=amount-ice;
        heat=(ice*2100.f)*u[1]+liquid*(334000.f+4180.f*u[1]);
        cells[0]=c[0]-amount;cells[1]=c[1]-heat;float offset,frozen,melt;
        snow_mass_phase(cells[0],cells[1],offset,frozen,melt);
        cells[2]=fmaxf(c[2]-ice/200.f,frozen/917.f);n=max(n,1);
    }
    if(u[2]>0.f&&u[0]!=0.f&&n>0)n=snow_mass_regrid(cells,out);
    else for(int i=0;i<45;++i)out[i]=cells[i];
    out[45]=(float)n;out[46]=amount;out[47]=heat;
    for(int p=0;p<5;++p)out[48+p]=residue[p];
    out[53]=ice;out[54]=liquid;out[55]=2.5e6f*amount+334000.f*ice;
}

extern "C" __global__ void run_snow_vapor(const float* cells,const int* counts,const float* inputs,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        snow_vapor_device(cells+row*45,counts[row],inputs+row*3,output+row*56);
}

// Native compaction, trilinear aging table, dry/wet growth and deposition.
__device__ void snow_aging_parameters(float offset,float gradient,float density,const float* table,float* result) {
    float coord[3]={(fminf(0.f,fmaxf(-50.f,offset))+50.f)/5.f,
        fminf(300.f,fmaxf(0.f,gradient))/10.f,(fminf(400.f,fmaxf(50.f,density))-50.f)/50.f};
    float physical[3]={273.15f+offset,gradient,density},spacing[3]={5.f,10.f,50.f};
    for(int d=0;d<3;++d) {
        float tolerance=((8.f*1.1920928955078125e-7f)*fmaxf(fabsf(physical[d]),1.f))/spacing[d],nearest=nearbyintf(coord[d]);
        if(fabsf(coord[d]-nearest)<=tolerance)coord[d]=nearest;
    }
    int low[3]={min((int)floorf(coord[0]),9),min((int)floorf(coord[1]),29),min((int)floorf(coord[2]),6)};
    float f[3];for(int d=0;d<3;++d)f[d]=coord[d]-(float)low[d];
    for(int p=0;p<3;++p)result[p]=0.f;
    for(int corner=0;corner<8;++corner) {
        int hi[3]={corner&1,(corner>>1)&1,(corner>>2)&1};float w[3];
        for(int d=0;d<3;++d)w[d]=hi[d]?f[d]:1.f-f[d];
        float weight=(w[0]*w[1])*w[2];int index=((low[0]+hi[0])*31+low[1]+hi[1])*8+low[2]+hi[2];
        for(int p=0;p<3;++p)result[p]+=weight*table[p*2728+index];
    }
}

__device__ float snow_dry_growth(float radius,float dt,const float* parameters) {
    if(dt==0.f)return radius;
    float tau=parameters[0],kappa=parameters[1],rate=parameters[2];
    float y=(radius-54.5f)+tau,p=1.f+1.f/kappa,hours=dt/7200.f;
    float inc=(logf(fmaxf((p*rate)*hours,1e-30f))-logf(y))+logf(tau/y)/kappa;
    float soft=fmaxf(inc,0.f)+log1pf(expf(-fabsf(inc)));
    return radius+y*expm1f(soft/p);
}

__device__ void snow_fresh_properties(float offset,float wind,float* out) {
    float thermal=offset>-15.f?50.f+1.7f*powf(fmaxf(fminf(offset,2.f)+15.f,0.f),1.5f):
        (-3.833f*offset)-(.0333f*offset)*offset;
    float loading=wind>.1f?266.861f*powf((1.f+tanhf(wind/5.f))/2.f,8.8f):0.f;
    out[0]=fminf(917.f,fmaxf(30.f,thermal+loading));
    out[1]=54.5f+5.f*fminf(30.f,fmaxf(0.f,offset+30.f));
}

__device__ void snow_evolution_device(const float* c,const int* o,const float* u,const float* table,float* out) {
    int n=o[0],mode=o[1];bool do_age=mode==1||mode==3;
    float cells[54]={0.f},overburden=0.f;
    for(int i=0;i<45;++i)cells[i]=c[i];
    for(int i=46;i<73;++i)out[i]=0.f;
    for(int k=0;k<n;++k) {
        const float* v=c+9*k;float m=v[0],h=v[1],z=fmaxf(v[2],1e-30f),offset,ice,liquid;
        snow_mass_phase(m,h,offset,ice,liquid);float rho=m/z,safe=fmaxf(m,1e-30f);
        overburden+=m;
        if(mode==0||mode==3) {
            float c1=expf(-.046f*fmaxf(ice/z-175.f,0.f)),c2=liquid/z>.01f?2.f:1.f;
            float destructive=((2.777e-6f*c1)*c2)*expf(.04f*offset);
            float over=overburden-.5f*m;
            float viscosity=((4.f*7.62237e6f)*(rho/450.f))*expf((-.1f*offset)+.023f*rho)/(1.f+(60.f*liquid)/(1000.f*z));
            float rate=destructive+over/fmaxf(viscosity,1e-30f),volume=ice/917.f+liquid/1000.f;
            bool allowed=1.f-volume/z>.001f&&ice>.1f;
            float factor=expf(-u[0]*(allowed?rate:0.f));
            float melt=u[6+k]>0.f?ice/fmaxf(u[6+k],1e-30f):1.f;
            factor*=o[2]&&allowed?fminf(1.f,melt):1.f;
            cells[9*k+2]=fmaxf(v[2]*factor,volume);
        }
        float aging_density=m/fmaxf(cells[9*k+2],1e-30f);
        if(do_age) {
            float* parameters=out+51+3*k;snow_aging_parameters(offset,u[1+k],fmaxf(aging_density,1.f),table,parameters);
            float radius=snow_dry_growth(fmaxf(v[3],54.5f),u[0],parameters);
            float fraction=fminf(.1f,liquid/safe),wet=((422000.f*fraction)*fraction)*fraction/12.56637061435917295385f;
            radius=cbrtf((radius*radius)*radius+(3.f*wet)*u[0]);
            radius=snow_dry_growth(radius,u[0],parameters);
            if(o[3]){float frozen=fminf(u[11+k],ice)/safe;radius=1.f/((1.f-frozen)/radius+frozen/1000.f);}
            cells[9*k+3]=fminf(1500.f,fmaxf(30.f,radius));
            out[68+k]=offset<-50.f||offset>0.f||u[1+k]>300.f||aging_density<50.f||aging_density>400.f?1.f:0.f;
        }
    }
    if(mode==2)for(int p=0;p<5;++p) {
        float addition=u[16+p]*u[0];if(n>0)cells[4+p]+=addition;else out[46+p]=addition;
    }
    if(o[4]&&(mode==0||mode==3)&&n>0)n=snow_mass_regrid(cells,out);
    else for(int i=0;i<45;++i)out[i]=cells[i];
    out[45]=(float)n;snow_fresh_properties(u[21],u[22],out+66);
}

extern "C" __global__ void run_snow_evolution(const float* cells,const int* options,const float* inputs,
                                               const float* table,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        snow_evolution_device(cells+row*45,options+row*5,inputs+row*23,table,output+row*73);
}

// Four liquid-equivalent soil reservoirs; H remains authoritative.
// Compiled after enthalpy_kernel.cu, independent of the released soil scheme.
// Keep the transfer call boundary when reused in the fused nonlinear surface.
// NVRTC's inlined version corrupts local soil masses in that caller (the
// standalone transfer is unaffected); full-field regression covers both.
__device__ float vic_admission(float incoming,float water,float capacity,float shape) {
    float deficit=fmaxf(0.f,capacity-water);
    if(deficit==0.f)return 0.f;
    if(shape==0.f)return fminf(incoming,deficit);
    float exponent=1.f+shape,log_x=logf(deficit/capacity)/exponent;
    float limit=(exponent*capacity)*expf(log_x);
    float value=incoming>=limit?deficit:-deficit*expm1f(exponent*log1pf(-incoming/limit));
    return fminf(incoming,fmaxf(0.f,value));
}

__device__ float vic_baseflow(float liquid,float capacity,float dt,const float* v) {
    float residual=v[7]*capacity,available=fmaxf(0.f,liquid-residual);
    float wet=available/(capacity-residual),linear=v[3]/v[5];
    float excess=fmaxf(0.f,wet-v[5])/(1.f-v[5]);
    float fraction=linear*wet+(1.f-linear)*powf(excess,v[6]);
    return fminf(available,(v[4]*(dt/86400.f))*fraction);
}

__device__ __noinline__ void soil_transport_device(const float* cells,const float* p,const int* option,
                                      const float* u,float* out,const float* vic=nullptr) {
    float water[4],heat[4],z[4],offset[4],liquid[4];bool valid=true;
    float por=p[0],b=p[1],field=p[2],satdk=p[3],psi=p[4];int mode=option[0],phase=option[1],permeability=option[2];
    for(int j=0;j<47;++j)out[j]=0.f;
    for(int j=0;j<4;++j) {
        water[j]=cells[j*3];heat[j]=cells[j*3+1];z[j]=cells[j*3+2];
        float h,c,count;
        valid=invert_soil_enthalpy(water[j],heat[j],z[j],por,b,psi,phase,offset[j],h,c,liquid[j],count)&&valid;
    }
    if(mode==0) {
        float specific=u[1]/(u[0]>0.f?u[0]:1.f),left=u[0],surface=0.f;
        if(vic&&vic[0]>0.f) {
            float capacity=(1000.f*por)*(z[0]+z[1]),upper_water=fminf(capacity,water[0]+water[1]);
            left=vic_admission(u[0],upper_water,capacity,vic[2]);surface=u[0]-left;
        }
        out[24]=u[0];out[25]=u[1];
        for(int j=0;j<4;++j) {
            float accepted=fminf(left,fmaxf(0.f,(1000.f*por)*z[j]-water[j]));
            water[j]+=accepted;heat[j]+=accepted*specific;left-=accepted;
        }
        left+=surface;out[26]=left;out[27]=left*specific;
    } else if(mode==1) {
        for(int j=0;j<4;++j) {
            float demand=u[3+j],rounding=8.f*1.1920928955078125e-7f*fmaxf(water[j],1.f);
            valid=valid&&demand<=liquid[j]+rounding&&demand<=water[j];
            float carried=demand*(334000.f+4180.f*offset[j]);
            water[j]-=demand;heat[j]-=carried;out[28+j]=demand;out[32+j]=carried;
        }
    } else {
        for(int j=0;j<4;++j) {
            float offset,h,c,liquid,count;
            valid=invert_soil_enthalpy(water[j],heat[j],z[j],por,b,psi,phase,offset,h,c,liquid,count)&&valid;
            float ice=water[j]-liquid,capacity=(1000.f*por)*z[j];
            float wet=fminf(1.f,fmaxf(0.f,water[j]/capacity));
            float frozen=permeability==1?1.f:expf((-7.f*ice)/capacity);
            float hydraulic=(((1000.f*u[2])*satdk)*frozen)*powf(wet,2.f*b+3.f);
            float excess=fmaxf(0.f,water[j]-(1000.f*field)*z[j]);
            float moved=fminf(fminf(hydraulic,excess),liquid);
            if(j==3&&vic&&vic[1]>0.f)moved=vic_baseflow(liquid,capacity,u[2],vic)*frozen;
            if(j<3)moved=fminf(moved,fmaxf(0.f,(1000.f*por)*z[j+1]-water[j+1]));
            float carried=moved*(334000.f+4180.f*offset);
            water[j]-=moved;heat[j]-=carried;
            if(j<3){water[j+1]+=moved;heat[j+1]+=carried;}
            out[36+j]=moved;out[40+j]=carried;
        }
        out[44]=out[39];out[45]=out[43];
    }
    for(int j=0;j<4;++j) {
        float h,c,count;
        valid=invert_soil_enthalpy(water[j],heat[j],z[j],por,b,psi,phase,offset[j],h,c,liquid[j],count)&&valid;
        valid=valid&&water[j]>=0.f;
        out[j*3]=water[j];out[j*3+1]=heat[j];out[j*3+2]=z[j];
        out[12+j]=offset[j];out[16+j]=liquid[j];out[20+j]=water[j]-liquid[j];
    }
    out[46]=valid?1.f:0.f;
}

__device__ void column_soil_transport_device(const float* cells,const float* full,const int* options,
        const float* inputs,float* output,const float* vic=nullptr) {
    float compact[5]={full[0],full[1],full[2],full[3],full[6]};
    soil_transport_device(cells,compact,options,inputs,output,vic);
}

extern "C" __global__ void run_vic_transport(const float* cells,const float* p,const int* options,
                                             const float* inputs,const float* vic,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        soil_transport_device(cells+row*12,p+row*5,options+row*3,inputs+row*7,output+row*47,vic+row*8);
}

extern "C" __global__ void run_soil_transport(const float* cells,const float* p,const int* options,
                                             const float* inputs,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        soil_transport_device(cells+row*12,p+row*5,options+row*3,inputs+row*7,output+row*47);
}

// Shared extensive surface coupling. The solver adapter preserves each canopy ABI.
struct LiquidSurfaceCanopy {
    static const int output_size=441;
    const float *a,*f,*leaf,*radiation,*v;
    __device__ void solve(float temp,const float* u,const float* supply,const float* root_h,int n,float* out) const {
        float initial[11],boundary[11]={temp,temp<273.15f?1.f:0.f,n==0?1.f:0.f,1.f,v[1],v[2],v[0]};
        for(int i=0;i<11;++i)initial[i]=u[0];for(int i=0;i<4;++i)boundary[7+i]=root_h[i];
        canopy_energy_device(a,u,f,supply,initial,leaf,out+58,100,.005f,1e-8f,boundary,radiation);
    }
    __device__ float latent(const float* out) const {
        return 2500000.f*(ca_sum(out+98,10)+ca_sum(out+88,10))+out[350];
    }
};
template<class Solver> __device__ void surface_evaluate(const float* c,const float* g,const float* p,int n,int phase,
    const float* a,const float* u,const float* f,const float* v,const float* radiation,const float* leaf,
    const float* supply,const float* root_h,bool inverse_ok,float temp,float* out,const Solver& solver) {
    float dt=v[0];solver.solve(temp,u,supply,root_h,n,out);
    float* canopy=out+58;
    float roots[4],carried[4],demand[7]={0.f,0.f,dt},tr[47];int operation[3]={1,phase,1};
    float gm=canopy[50]*dt,wet=ca_sum(canopy+30,10)*dt;
    for(int i=0;i<4;++i){roots[i]=canopy[51+i]*dt;carried[i]=roots[i]*root_h[i];demand[3+i]=roots[i];}
    if(n==0&&gm>0.f)demand[3]+=gm;
    column_soil_transport_device(g,p,operation,demand,tr);
    float ground[12];for(int i=0;i<12;++i)ground[i]=tr[i];
    float gh=ca_sum(tr+32,4)-ca_sum(carried,4),latent,runoff=0.f,runoff_h=0.f,residue[5]={0.f};
    float sw[5],soil_sw=canopy[201];for(int i=0;i<5;++i)sw[i]=canopy[196+i];
    int nn=n;bool valid=tr[46]>0.f;
    if(n>0) {
        float vapor[56],args[3]={gm,temp-273.15f,0.f};snow_vapor_device(c,n,args,vapor);
        nn=(int)vapor[45];for(int i=0;i<45;++i)out[i]=vapor[i];
        gm=vapor[46];gh=vapor[47];latent=vapor[55]/dt;
        for(int i=0;i<5;++i)residue[i]=vapor[48+i];
        if(nn<n){float removed=sw[0];for(int i=0;i<4;++i)sw[i]=sw[i+1];sw[4]=0.f;if(nn>0)sw[0]+=removed;else soil_sw+=removed;}
    } else {
        for(int i=0;i<45;++i)out[i]=c[i];
        float offset=temp-273.15f;
        if(gm<0.f)gh=gm*(temp<273.15f?2100.f*offset:334000.f+4180.f*offset);
        latent=((gm<0.f&&temp<273.15f)?2834000.f:2500000.f)*gm/dt;
        float args[7]={fmaxf(-gm,0.f),gm<0.f?-gh:0.f,dt,0.f,0.f,0.f,0.f};operation[0]=0;
        column_soil_transport_device(ground,p,operation,args,tr);valid=valid&&tr[46]>0.f;
        for(int i=0;i<12;++i)ground[i]=tr[i];runoff=tr[26];runoff_h=tr[27];
    }
    out[45]=(float)nn;
    for(int i=0;i<5;++i){float t,liquid;snow_mass_phase(out[9*i],out[9*i+1],t,out[343+i],liquid);}
    float top=(canopy[195]+canopy[202]*canopy[50])-latent;
    float cells[45]={0.f},props[4]={p[0],p[1],p[4],p[6]},bc[4]={dt,top,0.f,0.f};int options[2]={nn,phase};
    for(int k=0;k<9;++k) {
        if(k<nn){cells[k*5]=out[k*9];cells[k*5+1]=out[k*9+1];cells[k*5+2]=out[k*9+2];cells[k*5+4]=sw[k];}
        else if(k<nn+4){int j=k-nn;for(int i=0;i<3;++i)cells[k*5+i]=ground[j*3+i];if(j==0)cells[k*5+4]=soil_sw;}
        else {cells[k*5+2]=1.f;cells[k*5+3]=1.f;}
    }
    float* heat=out+266;joint_heat_device(cells,props,options,bc,heat);
    for(int k=0;k<5;++k)out[k*9+1]=k<nn?heat[k]:0.f;
    for(int k=0;k<4;++k)ground[k*3+1]=heat[nn+k];for(int i=0;i<12;++i)out[46+i]=ground[i];
    out[348]=gm;out[349]=gh;out[350]=latent;out[351]=wet;out[352]=ca_sum(roots,4);
    out[353]=runoff;out[354]=runoff_h;for(int i=0;i<5;++i)out[355+i]=residue[i];
    out[360]=temp;out[361]=heat[18]-(temp-273.15f);
    out[362]=valid&&canopy[68]>0.f&&heat[75]>0.f&&inverse_ok?1.f:0.f;
}

template<class Solver> __device__ void surface_finish(const float* old_snow,const float* old_soil,const float* v,
    float* out,int count,bool converged,const float* aging,const float* p,int phase,const Solver& solver,const float* vic=nullptr) {
    const float* d=out;const float* canopy=d+58;const float* heat=d+266;int n=(int)d[45];float dt=v[0];
    float z[6],centers[6],temperatures[6],args[23]={0.f};args[0]=dt;
    for(int i=0;i<6;++i){z[i]=i<n?d[9*i+2]:d[48];temperatures[i]=i<n?heat[18+i]:heat[18+n];}
    for(int i=0;i<6;++i){float sum=0.f;for(int k=0;k<6;++k)sum+=k<=i?z[k]:0.f;centers[i]=sum-.5f*z[i];}
    for(int i=0;i<5;++i) {
        int prev=max(i-1,0);float h1=i==0?1.f:centers[i]-centers[prev],h2=centers[i+1]-centers[i];
        float left=(temperatures[i]-temperatures[prev])/h1,right=(temperatures[i+1]-temperatures[i])/h2;
        args[1+i]=i<n?fabsf(i==0?right:(h2*left+h1*right)/(h1+h2)):0.f;
        args[6+i]=d[343+i];float offset,ice,liquid;snow_mass_phase(d[i*9],d[i*9+1],offset,ice,liquid);
        args[11+i]=fmaxf(0.f,ice-d[343+i]);
    }
    int opt[5]={n,3,1,1,0};float evolved[73];snow_evolution_device(d,opt,args,aging,evolved);
    float drainargs[16]={0.f,0.f,100.f,54.5f,.033f,.05f,.2f,.02f,.02f,.01f,.01f,0.f,0.f,0.f,0.f,0.f},drain[74];
    snow_transfer_device(evolved,n,3,drainargs,drain);
    for(int i=0;i<45;++i)out[363+i]=drain[i];out[408]=drain[45];
    float admitargs[7]={drain[53],drain[54],dt,0.f,0.f,0.f,0.f},admission[47];int so[3]={0,phase,1};
    column_soil_transport_device(d+46,p,so,admitargs,admission,vic);for(int i=0;i<12;++i)out[409+i]=admission[i];
    float runoff=(d[353]+drain[60])+admission[26],runoff_h=(d[354]+drain[61])+admission[27];
    float advected=d[349]+dt*(canopy[206]+canopy[207]),et=(d[352]+d[348])+d[351];
    float le=solver.latent(out);
    float atmospheric=((canopy[29]-canopy[26])-le)*dt;
    float old_hs=0.f,new_hs=0.f,old_hg=0.f,new_hg=0.f,old_ms=0.f,new_ms=0.f,old_mg=0.f,new_mg=0.f;
    for(int i=0;i<5;++i){old_hs+=old_snow[i*9+1];new_hs+=drain[i*9+1];old_ms+=old_snow[i*9];new_ms+=drain[i*9];}
    for(int i=0;i<4;++i){old_hg+=old_soil[i*3+1];new_hg+=admission[i*3+1];old_mg+=old_soil[i*3];new_mg+=admission[i*3];}
    float old_h=(old_hs+old_hg)+v[2],new_h=(new_hs+new_hg)+canopy[205];
    float old_m=(old_ms+old_mg)+v[1],new_m=(new_ms+new_mg)+canopy[204];
    out[421]=et;out[422]=runoff;out[423]=runoff_h;out[424]=advected;out[425]=atmospheric;
    out[426]=(((new_h-old_h)-atmospheric)+advected)+runoff_h;out[427]=((new_m-old_m)+et)+runoff;
    out[428]=drain[53];out[429]=drain[54];out[430]=le;out[431]=heat[71]/dt;out[432]=(float)count;
    out[433]=converged&&admission[46]>0.f?1.f:0.f;
    for(int i=0;i<5;++i)out[434+i]=(d[355+i]+drain[62+i])+drain[55+i];
    if(d[348]!=0.f)out[260]=(d[350]*dt)/d[348];
}

template<class Solver> __device__ void surface_device(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* input,const float* f,const float* v,const float* radiation,
    const float* leaf,const float* aging,float* out,const Solver& solver,const float* vic=nullptr) {
    int n=o[0],phase=o[1];float u[23],supply[10],root_h[4],offset0=0.f;bool inverse_ok=true;
    for(int i=0;i<23;++i)u[i]=input[i];u[15]=v[1]/v[0];u[17]=n>0?c[0]/v[0]:__int_as_float(0x7f800000);supply[0]=1.f;
    for(int i=0;i<4;++i) {
        float offset,h,cap,liquid,count;inverse_ok=invert_soil_enthalpy(g[i*3],g[i*3+1],g[i*3+2],p[0],p[1],p[6],phase,offset,h,cap,liquid,count)&&inverse_ok;
        root_h[i]=334000.f+4180.f*offset;supply[1+i]=fmaxf(0.f,liquid-(p[5]*1000.f)*g[i*3+2])/v[0];supply[5+i]=v[3+i];
        if(i==0){supply[9]=liquid/v[0];offset0=offset;}
    }
    if(n>0){float ice,liq;snow_mass_phase(c[0],c[1],offset0,ice,liq);}
    float center=fminf(350.f,fmaxf(200.f,offset0+273.15f));
    surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,center,out,solver);
    const float tol=2.f*1.1920928955078125e-7f*273.15f;
    int count=1;float left=center,right=center,fl=out[361],fr=fl,width=2.f,unused[Solver::output_size];
    if(fabsf(out[361])>tol)for(int k=0;k<8;++k) {
        if(fl<0.f&&left>200.f){left=fmaxf(200.f,center-width);surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,left,unused,solver);fl=unused[361];++count;}
        if(fr>0.f&&right<350.f){right=fminf(350.f,center+width);surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,right,unused,solver);fr=unused[361];++count;}
        width*=2.f;
    }
    bool bracketed=fl>=0.f&&fr<=0.f;
    // Stay on the continuous branch connected to the initial snow surface
    // when the expanding bracket crosses removal of its vapour-supply cell.
    if(n>0&&(int)out[45]==n&&out[361]>0.f&&bracketed) {
        surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,right,unused,solver);++count;
        if((int)unused[45]<n) {
            float event_left=center,event_right=right;
            for(int k=0;k<60&&(event_right-event_left)>tol;++k) {
                float trial=event_left+.5f*(event_right-event_left);
                surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,trial,unused,solver);++count;
                if((int)unused[45]==n) {
                    if(unused[361]<=0.f){right=trial;fr=unused[361];break;}
                    event_left=trial;
                }else event_right=trial;
            }
        }
    }
    for(int k=0;k<60&&fabsf(out[361])>tol&&bracketed&&(right-left)>tol;++k) {
        float span=right-left,trial=left-(fl*span)/(fr!=fl?fr-fl:1.f);
        trial=fminf(right-.05f*span,fmaxf(left+.05f*span,trial));
        // A percentage margin may round back to the endpoint. Contract it.
        if(trial<=left||trial>=right)trial=left+.5f*span;
        surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,trial,out,solver);++count;
        if(out[361]>0.f){left=trial;fl=out[361];}else{right=trial;fr=out[361];}
    }
    if(out[45]>0.f&&out[284]==0.f&&out[360]!=273.15f) {
        surface_evaluate(c,g,p,n,phase,a,u,f,v,radiation,leaf,supply,root_h,inverse_ok,273.15f,unused,solver);++count;
        if(fabsf(unused[361])<=tol)for(int i=0;i<363;++i)out[i]=unused[i];
        if(fabsf(unused[361])<=tol)for(int i=441;i<Solver::output_size;++i)out[i]=unused[i];
    }
    bool converged=(fabsf(out[361])<=tol||(bracketed&&(right-left)<=tol))&&out[362]>0.f;
    surface_finish(c,g,v,out,count,converged,aging,p,phase,solver,vic);
    out[439]=left;out[440]=right;
}

__device__ void canopy_surface_device(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* input,const float* f,const float* v,const float* radiation,
    const float* leaf,const float* aging,float* out) {
    LiquidSurfaceCanopy solver{a,f,leaf,radiation,v};
    surface_device(c,g,p,o,a,input,f,v,radiation,leaf,aging,out,solver);
}

extern "C" __global__ void run_canopy_surface(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* u,const float* f,const float* v,const float* radiation,
    const float* leaf,const float* aging,float* out,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        canopy_surface_device(c+45*row,g+12*row,p+7*row,o+2*row,a+10*row,u+23*row,f+20*row,v+7*row,
            radiation+584*row,leaf,aging,out+441*row);
}

// Layered phase canopy adapter for the shared extensive surface solver.
struct PhaseSurfaceCanopy {
    static const int output_size=741;
    const float *a,*f,*leaf,*radiation,*v,*condensate;
    const float *extension=nullptr;
    const float *stem_area=nullptr;
    __device__ void solve(float temp,const float* u,const float* supply,const float* root_h,int n,float* out) const {
        float stem[10]={0.f},b[9]={1.f,temp,temp<273.15f?1.f:0.f,n==0?1.f:0.f,v[0]};
        for(int i=0;i<4;++i)b[5+i]=root_h[i];
        PhaseContext context;phase_prepare(a,u,f,supply,stem_area?stem_area:stem,condensate,b,leaf,radiation,context);
        if(extension){context.water_velocity=extension[0];context.heat_temperature=extension[1];}
        float* full=out+441;phase_solve(context,full,100,.005f);
        float* canopy=out+58;
        for(int i=0;i<195;++i)canopy[i]=full[i];
        canopy[195]=full[288];for(int i=0;i<5;++i)canopy[196+i]=full[293+i];
        canopy[201]=full[289];canopy[202]=full[290];canopy[203]=full[285];
        canopy[204]=ca_sum(full+195,10);canopy[205]=ca_sum(full+205,10);
        canopy[206]=full[286];canopy[207]=full[287];
    }
    __device__ float latent(const float* out) const {
        return (ca_sum(out+696,10)/v[0]+2500000.f*ca_sum(out+98,10))+out[350];
    }
};

extern "C" __global__ void run_canopy_phase_surface_stems(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* u,const float* f,const float* input,const float* condensate,const float* stem,
    const float* extension,const float* vic,const float* radiation,const float* leaf,const float* aging,float* out,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x){
        float v[7];for(int i=0;i<7;++i)v[i]=input[7*row+i];v[1]=0.f;v[2]=0.f;
        for(int i=0;i<10;++i){v[1]+=condensate[20*row+2*i];v[2]+=condensate[20*row+2*i+1];}
        PhaseSurfaceCanopy solver{a+10*row,f+20*row,leaf,radiation+584*row,v,condensate+20*row,
            extension?extension+2*row:nullptr,stem+10*row};
        surface_device(c+45*row,g+12*row,p+7*row,o+2*row,a+10*row,u+23*row,f+20*row,v,
            radiation+584*row,leaf,aging,out+741*row,solver,vic?vic+8*row:nullptr);
    }
}

__device__ void canopy_phase_surface_device(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* u,const float* f,const float* input,const float* condensate,
    const float* radiation,const float* leaf,const float* aging,float* out) {
    float v[7];for(int i=0;i<7;++i)v[i]=input[i];v[1]=0.f;v[2]=0.f;
    for(int i=0;i<10;++i){v[1]+=condensate[2*i];v[2]+=condensate[2*i+1];}
    PhaseSurfaceCanopy solver{a,f,leaf,radiation,v,condensate};
    surface_device(c,g,p,o,a,u,f,v,radiation,leaf,aging,out,solver);
}

extern "C" __global__ void run_canopy_phase_surface_extended(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* u,const float* f,const float* input,const float* condensate,const float* extension,
    const float* radiation,const float* leaf,const float* aging,float* out,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x){
        float v[7];for(int i=0;i<7;++i)v[i]=input[7*row+i];v[1]=0.f;v[2]=0.f;
        for(int i=0;i<10;++i){v[1]+=condensate[20*row+2*i];v[2]+=condensate[20*row+2*i+1];}
        PhaseSurfaceCanopy solver{a+10*row,f+20*row,leaf,radiation+584*row,v,condensate+20*row,extension+2*row};
        surface_device(c+45*row,g+12*row,p+7*row,o+2*row,a+10*row,u+23*row,f+20*row,v,
            radiation+584*row,leaf,aging,out+741*row,solver);
    }
}

extern "C" __global__ void run_canopy_phase_surface(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* u,const float* f,const float* v,const float* condensate,const float* radiation,
    const float* leaf,const float* aging,float* out,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        canopy_phase_surface_device(c+45*row,g+12*row,p+7*row,o+2*row,a+10*row,u+23*row,f+20*row,v+7*row,
            condensate+20*row,radiation+584*row,leaf,aging,out+741*row);
}

extern "C" __global__ void run_canopy_phase_surface_vic(const float* c,const float* g,const float* p,const int* o,
    const float* a,const float* u,const float* f,const float* input,const float* condensate,const float* extension,
    const float* vic,const float* radiation,const float* leaf,const float* aging,float* out,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x){
        float v[7];for(int i=0;i<7;++i)v[i]=input[7*row+i];v[1]=0.f;v[2]=0.f;
        for(int i=0;i<10;++i){v[1]+=condensate[20*row+2*i];v[2]+=condensate[20*row+2*i+1];}
        PhaseSurfaceCanopy solver{a+10*row,f+20*row,leaf,radiation+584*row,v,condensate+20*row,
            extension?extension+2*row:nullptr};
        surface_device(c+45*row,g+12*row,p+7*row,o+2*row,a+10*row,u+23*row,f+20*row,v,
            radiation+584*row,leaf,aging,out+741*row,solver,vic+8*row);
    }
}

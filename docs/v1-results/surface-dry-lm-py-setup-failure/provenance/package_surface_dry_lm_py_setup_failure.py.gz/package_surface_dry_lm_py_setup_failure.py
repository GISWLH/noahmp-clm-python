"""Seal the original PY1818 setup failure without numerical interpretation."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-dry-lm-py-setup-failure'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()


def main():
    report=json.loads((BASE/'surface-dry-lm-py-setup-failure.json').read_bytes())
    assert report['job_state']=='F' and report['PBS_exit']==1 and report['Stageout_status']==0
    assert report['numerical_model_calls']==report['collected_nodes']==0 and report['actual_children']==[]
    stage=(BASE/'surface-dry-lm-py-stage.tar.gz').read_bytes()
    assert sha(stage)=='30ebe9dd04b8354b5672045b08e22710b64f6e1cb42590d2755d6269ddeb3b4e'
    result=(BASE/'surface-dry-lm-py-result.tar.gz').read_bytes();assert sha(result)==report['result_sha256']
    with tarfile.open(fileobj=io.BytesIO(result)) as t:
        originals={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    assert len(originals)==51
    with tarfile.open(fileobj=io.BytesIO(stage)) as t:staged={m.name:t.extractfile(m).read() for m in t}
    index=json.loads(staged['stage-inventory.json'])
    assert len(staged)==33 and all(sha(staged[n])==h for n,h in index.items())
    receipt=json.loads(originals['probe/receipt.json'])
    before=json.loads(originals['stage-before.json']);after=json.loads(originals['stage-after.json'])
    assert receipt['actual_children']==[] and receipt['immutable_files']==28 and receipt['immutable_before_after_exact']
    assert before['passed'] and after['passed'] and before['actual']==after['actual']==index
    for folder,prefix in [('preparation','probe/preparation'),('execution','probe/execution')]:
        controls=json.loads(staged[folder+'/CONTROLS_SHA256.json'])
        assert all(staged[folder+'/'+n]==originals[prefix+'/'+n] and sha(staged[folder+'/'+n])==h for n,h in controls.items())
    items={'executed-stage.tar.gz':stage,'original-result.tar.gz':result,
        'readout.json':(BASE/'surface-dry-lm-py-setup-failure.json').read_bytes(),
        'SCOPE.md':b'Original1818 actual F1/Stageout0, wrapper archive-member assertion before source expansion, collect and numerical model calls. No physical failure or successful validation is claimed; original source/tests/inputs/gates unchanged.\n'}
    items.update({'result/'+n:b for n,b in originals.items()})
    for folder in ('surface-dry-lm-py-deployment','surface-dry-lm-py-closure'):
        items.update({folder+'/'+p.relative_to(BASE/folder).as_posix():p.read_bytes() for p in (BASE/folder).rglob('*') if p.is_file()})
    for name in ('deploy_surface_dry_lm_py.py','collect_surface_dry_lm_py_closed.py',Path(__file__).name):
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Original PY1818 F1/Stageout0: execution metadata assertion before source expansion or collection; zero numerical calls. Original immutable source/preparation/input controls retained, no physical validation/failure or retry credit.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

"""Close original PY1818 metadata failure; no numerical imports or replay."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'surface-dry-lm-py-closure'
sha=lambda b:hashlib.sha256(b).hexdigest()


def run(label,command):
    begin=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=60)
    (OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr)
    (OUT/(label+'.json')).write_text(json.dumps(dict(actual_exit=r.returncode,seconds=time.monotonic()-begin,
        command=command,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)),indent=2)+'\n')
    assert r.returncode==0,(label,r.stderr.decode(errors='replace'))
    return r.stdout


def main():
    assert not OUT.exists();OUT.mkdir()
    ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10']
    q=run('qstat',ssh+['ehpc','qstat -fx 1818.manager']).decode()
    assert all(x in q for x in ('Job Id: 1818.manager','job_state = F','Exit_status = 1','Stageout_status = 0'))
    remote='/tmp/noahmp-surface-dry-lm-py'
    hash_output=run('result-hash',ssh+['ehpc-c2','sha256sum '+remote+'/result.tar.gz']).decode()
    expected=hash_output.split()[0]
    result=BASE/'surface-dry-lm-py-result.tar.gz';assert not result.exists()
    run('download-result',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc-c2:'+remote+'/result.tar.gz',str(result)])
    assert sha(result.read_bytes())==expected
    pbs=run('pbs-exit',ssh+['ehpc-c2','cat '+remote+'/pbs-exit.txt']);assert pbs.strip()==b'1'
    with tarfile.open(result) as t:
        members=[m for m in t if m.isfile()]
        files={m.name.removeprefix('./'):t.extractfile(m).read() for m in members}
    assert len(files)==len(members)
    receipt=json.loads(files['probe/receipt.json'])
    assert receipt['pbs_job']=='1818.manager' and receipt['actual_children']==[] and not receipt['passed']
    assert receipt['immutable_files']==28 and receipt['immutable_before_after_exact'] and receipt['stage_before_after_exact']
    assert 'len(members)==597' in receipt['exception']
    assert files['worker-exit.txt'].strip()==b'1' and files['setup-exit.txt'].strip()==files['stage-after-exit.txt'].strip()==b'0'
    report=dict(pbs_job='1818.manager',job_state='F',PBS_exit=1,Stageout_status=0,actual_worker_exit=1,
        result_sha256=expected,result_files=len(files),immutable_files=28,immutable_before_after_exact=True,
        collected_nodes=0,numerical_model_calls=0,actual_children=[],
        failure_kind='Execution wrapper archive-member metadata assertion, before source expansion/collection/numerics',
        actual_source_file_count=584,actual_source_members=585,incorrect_asserted_source_members=597,
        model_failure=False,retry_performed=False)
    (BASE/'surface-dry-lm-py-setup-failure.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))


if __name__=='__main__':main()

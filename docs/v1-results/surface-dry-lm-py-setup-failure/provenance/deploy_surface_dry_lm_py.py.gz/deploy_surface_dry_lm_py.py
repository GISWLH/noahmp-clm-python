"""Deploy the one root-authorized frozen PY stage; actual outcomes only."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
LOG=BASE/'surface-dry-lm-py-deployment'
STAGE=BASE/'surface-dry-lm-py-stage.tar.gz'
DISPATCH=BASE/'surface-dry-lm-py-execution/dispatch_surface_py.py'
EXPECTED='30ebe9dd04b8354b5672045b08e22710b64f6e1cb42590d2755d6269ddeb3b4e'
sha=lambda b:hashlib.sha256(b).hexdigest()


def run(label,command):
    started=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=120)
    (LOG/(label+'.stdout')).write_bytes(result.stdout)
    (LOG/(label+'.stderr')).write_bytes(result.stderr)
    (LOG/(label+'.json')).write_text(json.dumps(dict(command=command,actual_exit=result.returncode,
        seconds=time.monotonic()-started,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)),indent=2)+'\n')
    assert result.returncode==0,(label,result.stderr.decode(errors='replace'))
    return result.stdout


def main():
    assert sha(STAGE.read_bytes())==EXPECTED and not LOG.exists()
    LOG.mkdir();ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc']
    scp=['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10']
    for label,path in [('root','/tmp/noahmp-surface-dry-lm-py'),('stage','/tmp/noahmp-surface-dry-lm-py-stage.tar.gz'),('dispatch','/tmp/dispatch_surface_py.py')]:
        run('preflight-'+label,[*ssh,'test ! -e '+path])
    run('upload-stage',[*scp,str(STAGE),'ehpc:/tmp/noahmp-surface-dry-lm-py-stage.tar.gz'])
    run('upload-dispatch',[*scp,str(DISPATCH),'ehpc:/tmp/dispatch_surface_py.py'])
    hashes=run('uploaded-hashes',[*ssh,'sha256sum /tmp/noahmp-surface-dry-lm-py-stage.tar.gz /tmp/dispatch_surface_py.py'])
    assert {line.split()[1]:line.split()[0] for line in hashes.decode().splitlines()}=={
        '/tmp/noahmp-surface-dry-lm-py-stage.tar.gz':EXPECTED,'/tmp/dispatch_surface_py.py':sha(DISPATCH.read_bytes())}
    output=run('dispatch',[*ssh,'/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_surface_py.py --archive /tmp/noahmp-surface-dry-lm-py-stage.tar.gz --sha256 '+EXPECTED])
    record=json.loads(output);assert record['stage_sha256']==EXPECTED
    print(json.dumps(dict(pbs_job=record['pbs_job'],stage_sha256=EXPECTED,actual_dispatch_exit=0)))


if __name__=='__main__':main()

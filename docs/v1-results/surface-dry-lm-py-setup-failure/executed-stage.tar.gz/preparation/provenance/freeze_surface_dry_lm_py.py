"""Freeze and statically authenticate PY controls; never imports numerical code."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE / 'surface-dry-lm-py-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def unpack(path):
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        return {m.name: archive.extractfile(m).read() for m in members}


def main():
    assert not (PREP / 'CONTROLS_SHA256.json').exists()
    binding = json.loads((PREP / 'BINDINGS.json').read_bytes())
    original = unpack(BASE / 'climatology-final-candidate-nm-source.tar.gz')
    source_path = BASE / 'surface-dry-lm-py-source.tar.gz'
    assert sha(source_path.read_bytes()) == binding['candidate_source_archive_sha256']
    candidate = unpack(source_path)
    original_index = json.loads(original['SOURCE_SHA256.json'])
    candidate_index = json.loads(candidate['SOURCE_SHA256.json'])
    assert sha(original['SOURCE_SHA256.json']) == binding['original_source_manifest_sha256']
    assert sha(candidate['SOURCE_SHA256.json']) == binding['candidate_source_manifest_sha256']
    assert len(original_index) == len(candidate_index) == 584 and set(original_index) == set(candidate_index)
    assert all(sha(candidate[n]) == h for n,h in candidate_index.items())
    assert [n for n in original_index if original[n] != candidate[n]] == [binding['changed_file']]
    plan = json.loads((PREP / 'VALIDATION_PLAN.json').read_bytes())
    original_tests = {n: sha(candidate[n]) for n in plan['original_test_files']}
    assert all(original_tests[n] == original_index[n] for n in original_tests)
    requirements = {
        'surface-7275-numpy-reference-pt-evidence.tar.gz': ('PT_archive_sha256',111),
        'surface-7275-feasible-root-pw-evidence.tar.gz': ('PW_archive_sha256',144),
        'failed-surface-probe-pr-evidence.tar.gz': ('PR_archive_sha256',72)}
    authenticated = {}
    for name,(key,count) in requirements.items():
        path = BASE / name
        assert sha(path.read_bytes()) == binding[key]
        files = unpack(path)
        inventory = json.loads(files['artifact-inventory.json'])
        assert len(files) == count and set(inventory) == set(files)-{'artifact-inventory.json'}
        assert all(sha(files[n]) == r['sha256'] and len(files[n]) == r['bytes'] for n,r in inventory.items())
        authenticated[name] = dict(sha256=sha(path.read_bytes()), members=len(files))
        if key == 'PT_archive_sha256':
            for row in (1,2):
                assert all('result/row-'+str(row)+'/'+n in files for n in
                    ('original-return.pkl','original-surface-step-return.pkl'))
        if key == 'PW_archive_sha256':
            assert all('result/probe/'+n in files for n in
                ('diagnostic/stored_ambient-diagnostic.pkl','original-model/phase-final-frame.pkl'))
    syntax = []
    for path in sorted(PREP.rglob('*.py')):
        raw = path.read_bytes()
        assert b'\0' not in raw
        compile(raw,path.as_posix(),'exec')
        syntax.append(path.relative_to(PREP).as_posix())
    tests = ast.parse((PREP / 'test_actual_surface_py.py').read_bytes())
    test_functions = [n.name for n in tests.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    assert len(test_functions) == 3 and plan['expected_new_nodes'] == 6
    ruff = Path('E:/miniconda3/Scripts/ruff.exe')
    assert ruff.exists()
    checked = subprocess.run([str(ruff),'check','--select','F821',*[str(PREP/n) for n in syntax]],capture_output=True)
    (BASE/'surface-dry-lm-py-ruff.stdout').write_bytes(checked.stdout)
    (BASE/'surface-dry-lm-py-ruff.stderr').write_bytes(checked.stderr)
    assert checked.returncode == 0,checked.stdout.decode(errors='replace')
    provenance = PREP / 'provenance'
    provenance.mkdir(exist_ok=True)
    for name in ('finish_surface_dry_lm_py.py','finish_surface_dry_lm_py.initial.py',
                 'surface-dry-lm-py-interrupted-draft.json',Path(__file__).name):
        (provenance/name).write_bytes((BASE/name).read_bytes())
    static = dict(passed=True,source_files=584,other_original_files_byte_exact=583,
        candidate_source_archive_sha256=sha(source_path.read_bytes()),
        candidate_source_manifest_sha256=sha(candidate['SOURCE_SHA256.json']),
        compiled_only_files=syntax,ruff_F821_exit=checked.returncode,
        original_test_files_sha256=original_tests,authenticated_closed_archives=authenticated,
        expected_new_test_nodes=6,actual_collected_nodes=0,actual_numerical_calls=0,submitted=False,
        interrupted_draft_preserved_sha256=binding['interrupted_draft_archive_sha256'],
        first_builder_metadata_exit=1,
        first_builder_issue='Standalone helper draft had already received counters while archived phase source had not; exact prior bytes preserved, reconstruction uses authenticated archived phase.',
        scope='Static archive/hash/AST/compile-only/F821 preparation proof. No import of numerical source, tests, pickle or arrays; no physical pass.')
    (PREP/'STATIC_CHECKS.json').write_bytes(encode(static))
    controls = {p.relative_to(PREP).as_posix():sha(p.read_bytes()) for p in sorted(PREP.rglob('*')) if p.is_file()}
    assert 'CONTROLS_SHA256.json' not in controls
    manifest = encode(controls)
    (PREP/'CONTROLS_SHA256.json').write_bytes(manifest)
    print(json.dumps(dict(controls=len(controls),controls_manifest_sha256=sha(manifest),
        source_archive_sha256=sha(source_path.read_bytes()),expected_new_test_nodes=6,
        actual_collected_nodes=0,numerical_executed=False,submitted=False)))


if __name__ == '__main__':
    main()

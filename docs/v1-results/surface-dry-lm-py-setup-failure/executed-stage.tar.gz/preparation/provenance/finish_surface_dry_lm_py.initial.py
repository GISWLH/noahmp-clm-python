"""Finish a private PY candidate using authenticated bytes; no numerical imports."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE / 'surface-dry-lm-py-preparation'
SOURCE = BASE / 'surface-dry-lm-py-source.tar.gz'
ORIGINAL = BASE / 'climatology-final-candidate-nm-source.tar.gz'
PHASE = 'src/noahmp_clm/physics/canopy_phase_energy.py'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as handle:
        entries = handle.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in entries)
        assert len({m.name for m in entries}) == len(entries)
        return {m.name: handle.extractfile(m).read() for m in entries}


def pack(path, entries):
    with path.open('wb') as target, gzip.GzipFile(fileobj=target, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as handle:
            for name, raw in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.mode, item.size = 0o644, len(raw)
                handle.addfile(item, io.BytesIO(raw))
    assert unpack(path.read_bytes()) == entries


def change(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)


def main():
    # Preserve exactly what was present after interruption, before any edits.
    backup = BASE / 'surface-dry-lm-py-before-counter-fix.tar.gz'
    assert not backup.exists()
    draft = {p.relative_to(PREP).as_posix(): p.read_bytes() for p in PREP.rglob('*') if p.is_file()}
    draft['draft-source.tar.gz'] = SOURCE.read_bytes()
    pack(backup, draft)
    observed = dict(archive_sha256=sha(backup.read_bytes()),
        files={n: dict(bytes=len(b), sha256=sha(b), contains_NUL=(b'\0' in b) if not n.endswith('.tar.gz') else None)
               for n, b in draft.items()}, numerical_executed=False, scope='Unexecuted interrupted draft bytes as found; not a prior frozen control set.')
    (BASE / 'surface-dry-lm-py-interrupted-draft.json').write_bytes(encode(observed))
    old_binding = json.loads(draft['BINDINGS.json'])
    old_candidate = unpack(draft['draft-source.tar.gz'])
    assert sha(draft['draft-source.tar.gz']) == old_binding['candidate_source_archive_sha256']
    assert old_candidate[PHASE] == draft['canopy_phase_energy.candidate.py']
    original_raw = ORIGINAL.read_bytes()
    assert sha(original_raw) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    original = unpack(original_raw)
    original_index_raw = original['SOURCE_SHA256.json']
    assert sha(original_index_raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    index = json.loads(original_index_raw)
    assert len(index) == 584 and set(original) == set(index) | {'SOURCE_SHA256.json'}
    assert all(sha(original[n]) == h for n, h in index.items())
    assert {n: old_candidate[n] for n in index if n != PHASE} == {n: original[n] for n in index if n != PHASE}
    base = original[PHASE].decode()
    helper = draft['dry_lm_helper_py.txt'].decode().replace('\r\n', '\n').rstrip() + '\n'
    assert '\0' not in helper
    helper = change(helper, "record=dict(converged=False,x=x,last_iteration=used_iterations,\n        iterations=0,accepted=0,rejected=0,linear_failures=0,",
        "record=dict(entered=False,converged=False,x=x,last_iteration=used_iterations,\n        original_stalled_iteration=used_iterations,initial_used_iterations=used_iterations,\n        maximum_iterations=max_iterations,iterations=0,accepted=0,rejected=0,linear_failures=0,\n        linear_attempts=0,trial_evaluations=0,")
    helper = change(helper, "    cap=np.r_[np.full(n,20.),5.,5.]", "    record['entered']=True\n    cap=np.r_[np.full(n,20.),5.,5.]")
    helper = change(helper, '        try:\n            factor=np.linalg.cholesky(matrix)', "        record['linear_attempts']+=1\n        try:\n            factor=np.linalg.cholesky(matrix)")
    helper = change(helper, '        trial_detail=call(trial,True);trial_residual=trial_detail[\'solver_residual\']',
        "        record['trial_evaluations']+=1\n        trial_detail=call(trial,True);trial_residual=trial_detail['solver_residual']")
    marker = '\ndef solve_canopy_phase_energy('
    assert base.count(marker) == 1
    insertion = '\n' + helper + '\n'
    candidate = base.replace(marker, insertion + marker)
    loop = '    dry_lm_record=None\n'
    loop_marker = '    for iteration in range(1,max_iterations+1):\n'
    candidate = change(candidate, loop_marker, loop + loop_marker)
    stalled = "            raise RuntimeError(f'Canopy phase Newton stalled at iteration {iteration}: residual={np.max(abs(residual)):.8g} W/m2')"
    rescue = """            if np.all(mass==0.) and not np.any(phase_active) and iteration<max_iterations:
                original_stalled_iteration=iteration;restarts+=1
                dry_lm_record=_dry_lm_rescue(evaluate,ambient,lower,upper,active,phase_active,
                    tolerance,iteration,max_iterations)
                iteration=dry_lm_record['last_iteration']
                if dry_lm_record['converged']:
                    x=dry_lm_record['x']
                    break
                raise RuntimeError(f'Canopy phase dry LM recovery failed: {dry_lm_record["reason"]}; '
                    f'total iteration {iteration}/{max_iterations}, original Newton stalled at '
                    f'{original_stalled_iteration}; original residual={np.max(abs(residual)):.8g} W/m2')
"""
    candidate = change(candidate, stalled, rescue + stalled)
    result = "    if dry_lm_record is not None:result['dry_lm_rescue']={k:v for k,v in dry_lm_record.items() if k!='x'}\n"
    result_marker = "    result=evaluate(x,True);result['iterations']=iteration;result['restarts']=restarts\n"
    candidate = change(candidate, result_marker, result_marker + result)
    reverse = candidate.replace(insertion, '', 1).replace(loop, '', 1).replace(rescue, '', 1).replace(result, '', 1)
    assert reverse.encode() == original[PHASE]
    ast.parse(candidate)
    (PREP / 'dry_lm_helper_py.txt').write_text(helper, encoding='utf-8', newline='\n')
    (PREP / 'canopy_phase_energy.candidate.py').write_text(candidate, encoding='utf-8', newline='\n')
    diff = ''.join(difflib.unified_diff(base.splitlines(True), candidate.splitlines(True), fromfile='NM/'+PHASE, tofile='PY/'+PHASE))
    (PREP / 'source.diff').write_text(diff, encoding='utf-8', newline='\n')
    contents = {n: original[n] for n in index}
    contents[PHASE] = candidate.encode()
    new_index = {n: sha(b) for n, b in contents.items()}
    contents['SOURCE_SHA256.json'] = encode(new_index)
    pack(SOURCE, contents)
    pt_dir = PREP / 'pt'
    pt_dir.mkdir(exist_ok=True)
    original_helpers = BASE / 'surface-7275-frame-trace-pu-preparation/pt'
    helper_files = {n: (original_helpers / n).read_bytes() for n in ('run_reference_pt.py', 'surface_reference.py', 'BINDINGS.json')}
    expected_helper = '30563e5a89a5cb30dc68e05c9195d5548ab0ca5a395e4d2c4d6de1c13357b125'
    assert sha(helper_files['surface_reference.py']) == expected_helper
    for n, raw in helper_files.items():
        assert b'\0' not in raw
        (pt_dir / n).write_bytes(raw)
    ref = helper_files['surface_reference.py'].decode()
    changed_ref = change(ref, "MANIFEST_SHA256 = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'",
        "MANIFEST_SHA256 = '" + sha(contents['SOURCE_SHA256.json']) + "'")
    (PREP / 'surface_reference_py.py').write_text(changed_ref, encoding='utf-8', newline='\n')
    test = draft['test_actual_surface_py.py'].decode().replace('\r\n', '\n')
    assert '\0' not in test
    test = change(test, "reference,_=pickle.loads(PT['result/row-'+str(row)+'/original-return.pkl'])", "reference=pickle.loads(PT['result/row-'+str(row)+'/original-return.pkl'])")
    test = change(test, "maximum_absolute_difference=float(np.max(abs(x-y),initial=0.))", "maximum_absolute_difference=float(np.max(abs(x.astype(float)-y.astype(float)),initial=0.))")
    test = change(test, "        record['surface_budgets']={k:float(got[k]) for k in ('water_residual_kgm2','energy_residual_jm2')}", """        record['surface_budgets']={k:float(got[k]) for k in ('water_residual_kgm2','energy_residual_jm2')}
        # The original test_canopy_column hard ledger gates, unchanged.
        assert abs(got['water_residual_kgm2'])<2e-10
        assert abs(got['energy_residual_jm2'])<.01""")
    # Original PT full surface tuples are preserved separately from augmented d.
    test = change(test, "    original_solve=column.solve_canopy_phase_energy\n", "    original_solve=column.solve_canopy_phase_energy\n    original_surface=column.surface_step\n    surface_returns=[]\n")
    test = change(test, "    monkeypatch.setattr(column,'solve_canopy_phase_energy',observed_phase)", """    def observed_surface(*args,**kwargs):
        calls['surface_started']+=1
        value=original_surface(*args,**kwargs)
        calls['surface_returned']+=1
        surface_returns.append(copy.deepcopy(value))
        pt.dump_return(output/'complete-surface-return',value)
        return value
    monkeypatch.setattr(column,'surface_step',observed_surface)
    monkeypatch.setattr(column,'solve_canopy_phase_energy',observed_phase)""")
    test = change(test, "        calls['surface_started']+=1\n        got,identity=ref.reference_one", "        got,identity=ref.reference_one")
    test = change(test, "        calls['surface_returned']+=1\n        pt.dump_return", "        pt.dump_return")
    test = change(test, "            exact(got,reference)\n", "            exact(got,reference)\n            exact(surface_returns[0],pickle.loads(PT['result/row-'+str(row)+'/original-surface-step-return.pkl']))\n")
    test = test.replace('scientific_pass', 'component_checks_passed')
    (PREP / 'test_actual_surface_py.py').write_text(test, encoding='utf-8', newline='\n')
    binding = dict(old_binding,
        candidate_source_archive_sha256=sha(SOURCE.read_bytes()),
        candidate_source_manifest_sha256=sha(contents['SOURCE_SHA256.json']),
        candidate_phase_sha256=sha(contents[PHASE]),
        original_helper_sha256=expected_helper, candidate_reference_helper_sha256=sha(changed_ref.encode()),
        reference_helper_delta='Only MANIFEST_SHA256 literal; original decode/equations/calls unchanged',
        interrupted_draft_archive_sha256=sha(backup.read_bytes()),
        original_controls={n: sha(raw) for n, raw in helper_files.items()})
    (PREP / 'BINDINGS.json').write_bytes(encode(binding))
    def function_tree(text, name):
        return next(n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == name)
    original_evaluate = ast.dump(function_tree(base, 'evaluate'), include_attributes=False)
    candidate_evaluate = ast.dump(function_tree(candidate, 'evaluate'), include_attributes=False)
    assert original_evaluate == candidate_evaluate
    proof = dict(passed=True, original_source_files=584, changed_files=[PHASE], other_source_files_byte_exact=583,
        original_source_manifest_sha256=sha(original_index_raw), candidate_source_manifest_sha256=sha(contents['SOURCE_SHA256.json']),
        fast_path_reverse_byte_exact=True, original_evaluate_AST_exact=True,
        root_and_parcel_tolerances_unchanged=True, original_maximum_iterations_unchanged=True,
        counter_failure_fix='Actual last iteration and reason in recovery failure; restart records entry; evaluate/linear/trial counters distinct',
        original_reference_helper_reverse_exact=changed_ref.replace(sha(contents['SOURCE_SHA256.json']), sha(original_index_raw), 1).encode()==helper_files['surface_reference.py'],
        local_numerical_imports=False, numerical_executed=False, submitted=False)
    assert proof['original_reference_helper_reverse_exact']
    (PREP / 'DIFF_PROOF.json').write_bytes(encode(proof))
    print(json.dumps(dict(source_archive_sha256=sha(SOURCE.read_bytes()), source_manifest_sha256=sha(contents['SOURCE_SHA256.json']), phase_sha256=sha(contents[PHASE]), proof=proof)))


if __name__ == '__main__':
    main()

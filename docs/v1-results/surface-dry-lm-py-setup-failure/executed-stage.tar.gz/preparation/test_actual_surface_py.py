"""Actual PR rows and independent closed PW root; EHPC PBS only."""
import copy
from dataclasses import fields,is_dataclass
import inspect
import json
import os
from pathlib import Path
import pickle
import socket
import sys
import traceback

assert os.name!='nt' and os.environ.get('PBS_JOBID')
assert socket.gethostname().split('.')[0]=='compute002'
assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==''
assert all(os.environ.get(name)=='1' for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))

import numpy as np
import pytest
import run_reference_pt as pt
import surface_reference_py as ref

ROOT=Path(os.environ['PY_RESULT'])
SOURCE=ROOT/'source'
BINDING=json.loads((Path(__file__).parent/'BINDINGS.json').read_bytes())
ref.bind_source(SOURCE)
PT=pt.archive_files(Path(os.environ['PY_PT']),BINDING['PT_archive_sha256'])
PW=pt.archive_files(Path(os.environ['PY_PW']),BINDING['PW_archive_sha256'])
PR,CONTEXT=pt.authenticate_pr(ROOT/'pr-evidence.tar.gz',json.loads((Path(__file__).parent/'pt/BINDINGS.json').read_bytes()))
ARGS,_,_=pt.captured_inputs(PR,json.loads((Path(__file__).parent/'pt/BINDINGS.json').read_bytes()))


def leaves(value,prefix=''):
    """Complete numeric tree for reporting and unchanged-path byte comparison."""
    if is_dataclass(value):
        result={}
        for field in fields(value):result.update(leaves(getattr(value,field.name),prefix+'/'+field.name))
        return result
    if isinstance(value,dict):
        result={}
        for key,item in value.items():result.update(leaves(item,prefix+'/'+str(key)))
        return result
    if isinstance(value,(tuple,list)):
        result={}
        for k,item in enumerate(value):result.update(leaves(item,prefix+'/'+str(k)))
        return result
    return {prefix:value}


def exact(left,right):
    a,b=leaves(left),leaves(right)
    assert set(a)==set(b)
    for key in a:
        if isinstance(a[key],(np.ndarray,np.generic)) or isinstance(b[key],(np.ndarray,np.generic)):
            x,y=np.asarray(a[key]),np.asarray(b[key])
            assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes(order='C')==y.tobytes(order='C'),key
        else:assert type(a[key]) is type(b[key]) and a[key]==b[key],key


@pytest.mark.parametrize('row',[0,1,2],ids=['actual-Qia','actual-Cha','actual-HaM'])
def test_actual_pr_surface_and_closed_independent_reference(row,monkeypatch):
    import noahmp_clm.physics.canopy_column as column
    import noahmp_clm.physics.canopy_phase_energy as phase
    original_solve=phase.solve_canopy_phase_energy
    original_surface=column.surface_step
    surface_returns=[]
    original_rescue=phase._dry_lm_rescue
    output=ROOT/('actual-row-'+str(row));output.mkdir(exist_ok=False)
    first={};rescues=[];calls=dict(phase_started=0,phase_returned=0,surface_started=0,surface_returned=0)
    def observed_phase(*args,**kwargs):
        ordinal=calls['phase_started'];calls['phase_started']+=1
        if ordinal==0:
            bound=inspect.signature(original_solve).bind(*args,**kwargs);bound.apply_defaults()
            first['input']=copy.deepcopy(dict(bound.arguments))
            pt.dump_return(output/'first-phase-before',first['input'])
        value=original_solve(*args,**kwargs)
        calls['phase_returned']+=1
        if ordinal==0:
            first['value']=copy.deepcopy(value);pt.dump_return(output/'first-phase-after',value)
        return value
    def observed_rescue(*args,**kwargs):
        try:
            result=original_rescue(*args,**kwargs)
        except BaseException as error:
            current=error.__traceback__
            while current is not None:
                if current.tb_frame.f_code is original_rescue.__code__:
                    rescues.append(copy.deepcopy(current.tb_frame.f_locals.get('record',{})))
                current=current.tb_next
            raise
        rescues.append(copy.deepcopy(result))
        return result
    def observed_surface(*args,**kwargs):
        calls['surface_started']+=1
        value=original_surface(*args,**kwargs)
        calls['surface_returned']+=1
        surface_returns.append(copy.deepcopy(value))
        pt.dump_return(output/'complete-surface-return',value)
        return value
    monkeypatch.setattr(column,'surface_step',observed_surface)
    monkeypatch.setattr(phase,'solve_canopy_phase_energy',observed_phase)
    monkeypatch.setattr(phase,'_dry_lm_rescue',observed_rescue)
    record=dict(row=row,case=CONTEXT['cases'][row],calls=calls,component_checks_passed=False)
    try:
        got,identity=ref.reference_one(SOURCE,ARGS[:9],row,coefficients=ARGS[12],profiled=False,
            exchange_extension=ARGS[9],vic=ARGS[10],stem_area=None,canopy_optics=None)
        pt.dump_return(output/'original-candidate-return',(got,identity))
        assert got['surface_root_converged']
        assert np.max(abs(got['solver_residual']))<=1e-7
        record['surface_budgets']={k:float(got[k]) for k in ('water_residual_kgm2','energy_residual_jm2')}
        # The original test_canopy_column hard ledger gates, unchanged.
        assert abs(got['water_residual_kgm2'])<2e-10
        assert abs(got['energy_residual_jm2'])<.01
        if row==0:
            # Load the independent OUTPUT only after the candidate has run.
            # It cannot become the initial guess, source state or input.
            reference=pickle.loads(PW['result/probe/diagnostic/stored_ambient-diagnostic.pkl'])['original_detail']
            original_frame=pickle.loads(PW['result/probe/original-model/phase-final-frame.pkl'])['frames'][0]['locals']
            exact(first['input'],{k:original_frame[k] for k in first['input']})
            assert rescues and first['value']['dry_lm_rescue']['converged']
            actual=first['value'];a,b=leaves(actual),leaves(reference)
            assert set(b)<=set(a)
            differences={}
            for key in b:
                if isinstance(b[key],(np.ndarray,np.generic,float,int)):
                    x,y=np.asarray(a[key]),np.asarray(b[key])
                    assert x.shape==y.shape and np.all(np.isfinite(x)) and np.all(np.isfinite(y))
                    differences[key]=dict(shape=list(x.shape),maximum_absolute_difference=float(np.max(abs(x.astype(float)-y.astype(float)),initial=0.)),
                        reference_maximum_absolute=float(np.max(abs(y),initial=0.)))
                else:assert a[key]==b[key]
            # Reuse the existing independent-network field tolerances and
            # parcel check from original test_canopy_phase_energy, unchanged.
            np.testing.assert_allclose(np.r_[actual['leaf_temperature'],actual['ground_temperature']],
                np.r_[reference['leaf_temperature'],reference['ground_temperature']],rtol=0.,atol=1e-4)
            for key in ('h','le','gpp'):np.testing.assert_allclose(actual[key],reference[key],rtol=.1,atol=.001)
            np.testing.assert_allclose(actual['condensate'].mass,reference['condensate'].mass,rtol=.1,atol=1e-7)
            np.testing.assert_allclose(actual['condensate'].enthalpy,reference['condensate'].enthalpy,rtol=.1,atol=.1)
            before=first['input'];np.testing.assert_allclose(actual['condensate'].mass+before['dt']*actual['wet_evaporation'],before['condensate'].mass,rtol=0.,atol=1e-14)
            assert np.max(abs(actual['solver_residual']))<=1e-7 and np.max(abs(actual['layer_residual']))<=1.01e-7
            record.update(first_phase_inputs_exact_to_PW=True,phase_field_differences=differences,
                phase_r12_max=float(np.max(abs(actual['solver_residual']))),phase_physical11_max=float(np.max(abs(actual['layer_residual']))))
        else:
            reference=pickle.loads(PT['result/row-'+str(row)+'/original-return.pkl'])
            exact(got,reference)
            exact(surface_returns[0],pickle.loads(PT['result/row-'+str(row)+'/original-surface-step-return.pkl']))
            assert not rescues
            record.update(original_PT_full_return_byte_exact=True,rescue_calls=0)
        for item in rescues:
            assert item['last_iteration']<=item['maximum_iterations']==80
            assert item['iterations']==item['last_iteration']-item['initial_used_iterations']
            assert item['evaluate_calls']==item['evaluate_returns']
        record['component_checks_passed']=True
    except BaseException:
        record['exception']=traceback.format_exc()
        (output/'traceback.txt').write_text(record['exception'])
        raise
    finally:
        record['rescue_records']=rescues
        pt.dump_return(output/'actual-observation',record)


def test_rescue_budget_and_phase_rejection_have_no_hidden_updates():
    from types import SimpleNamespace
    from noahmp_clm.physics.canopy_phase_energy import _dry_lm_rescue
    ambient=np.array([10.,280.,5.]);lower=np.array([-73.15,200.,0.]);upper=np.array([76.85,350.,190.])
    active=np.array([True]);mask=np.array([False]);called=[]
    def linear(z,details=False):
        called.append(z.copy());r=z-np.array([5.,280.,5.])
        return dict(solver_residual=r,wet_evaporation=np.zeros(1),condensate=SimpleNamespace(mass=np.zeros(1))) if details else r
    exhausted=_dry_lm_rescue(linear,ambient,lower,upper,active,mask,1e-7,80,80)
    assert not exhausted['converged'] and exhausted['iterations']==0 and not called
    one=_dry_lm_rescue(linear,ambient,lower,upper,active,mask,1e-7,79,80)
    assert not one['converged'] and one['last_iteration']==80 and one['iterations']==1
    assert one['evaluate_calls']==one['evaluate_returns']==len(called)
    before=len(called)
    forbidden=_dry_lm_rescue(linear,ambient,lower,upper,active,np.array([True]),1e-7,30,80)
    assert not forbidden['converged'] and len(called)==before and forbidden['iterations']==0
    def fresh(z,details=False):
        return dict(solver_residual=np.ones(3),wet_evaporation=-np.ones(1),condensate=SimpleNamespace(mass=np.zeros(1)))
    boundary=_dry_lm_rescue(fresh,np.array([0.,280.,5.]),lower,upper,active,mask,1e-7,30,80)
    assert not boundary['converged'] and boundary['reason']=='phase_coordinate_change' and boundary['evaluate_calls']==1
    assert not mask[0]
    pt.dump_return(ROOT/'budget-phase-contract',dict(exhausted=exhausted,one_remaining=one,ineligible=forbidden,fresh=boundary))


@pytest.mark.parametrize('mode',['nonfinite','nonzero_stationary'])
def test_recovery_cannot_accept_nonfinite_or_nonzero_stationary_state(mode):
    from types import SimpleNamespace
    from noahmp_clm.physics.canopy_phase_energy import _dry_lm_rescue
    ambient=np.array([10.,280.,5.]);lower=np.array([-73.15,200.,0.]);upper=np.array([76.85,350.,190.])
    seen=[]
    def original_residual(z,details=False):
        seen.append(z.copy())
        r=np.full(3,np.nan if mode=='nonfinite' else 1.)
        return dict(solver_residual=r,wet_evaporation=np.zeros(1),condensate=SimpleNamespace(mass=np.zeros(1))) if details else r
    result=_dry_lm_rescue(original_residual,ambient,lower,upper,np.array([True]),np.array([False]),1e-7,30,80)
    assert not result['converged'] and result['last_iteration']<=80
    assert result['evaluate_calls']==result['evaluate_returns']==len(seen)
    assert result['accepted']==0
    if mode=='nonfinite':assert result['reason']=='nonfinite_residual' and result['linear_attempts']==0
    else:assert result['reason']=='no_feasible_displacement' and result['trial_evaluations']==0
    pt.dump_return(ROOT/('rejected-'+mode),result)

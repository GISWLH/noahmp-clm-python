from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'richards-heat-native-a';assert not s.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'richards-heat-native-a-source.tar.gz';package=json.loads((b/'richards-heat-native-a-package.json').read_text());assert sha(a)==package['archive_sha256']
for n,key in [('richards-numpy-c-receipt.json','numpy_receipt_sha256'),('richards-reference-e-receipt.json','reference_receipt_sha256')]:assert sha(b/n)==package[key]
d=json.loads((b/'richards-numpy-c-receipt.json').read_text());ref=json.loads((b/'richards-reference-e-receipt.json').read_text());assert d['returncode']==0 and d['counts']==dict(tests=28,failures=0,errors=0,skipped=0) and d['source_unchanged'] and ref['source_unchanged'] and len(ref['cases'])==34
assert sha(b/'richards-heat-reference-a-receipt.json')==package['heat_reference_receipt_sha256']
heat=json.loads((b/'richards-heat-reference-a-receipt.json').read_text());assert heat['source_unchanged'] and len(heat['cases'])==14
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>8192
mem=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')));assert mem>16*1024*1024
s.mkdir()
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==547 and sha(s/'SOURCE_SHA256.json')==package['manifest_sha256'] and all(sha(s/n)==v for n,v in m.items())
r=s/'target-a';r.mkdir();env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_richards_heat_a.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(scope=package['scope'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_gpu_mib=free,source_archive_sha256=sha(a),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256={n:sha(b/n) for n in ['collect_richards_heat_a.py','control_richards_heat_a.py',Path(__file__).name]})
(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

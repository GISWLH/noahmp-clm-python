from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-portable-smoke-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'smoke.json').read_text());assert r['pbs_job']=='108.manager' and r['node']=='compute002' and r['all_commands_returned_zero'] and r['c_fortran_python_values_exact']
assert (root/'pbs-exit.txt').read_text().strip()=='0' and all(s['returncode']==0 for s in r['stages'])
assert sha(base/'ctsm-portable-env-a.tar.gz')==r['archive_sha256']
names=['smoke_ctsm_portable_a.py','ctsm_portable_smoke_a.pbs','smoke.json','smoke.log','node.txt','pbs-exit.txt','smoke-artifacts.tar.gz']
dest=base/'ctsm-portable-smoke-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for n in names:t.add(root/n,arcname=n,recursive=False)
    t.add(Path(__file__),arcname='archive_ctsm_portable_smoke_a.py',recursive=False)
print(json.dumps(dict(files=len(names)+1,sha256=sha(dest),scope='EHPC PBS108 actual relocated native compiler/NetCDF-C/Fortran/Python cross-read smoke, values exact. Not an official CTSM source build/model output or scientific acceptance.')))

from pathlib import Path
import hashlib,json,os,shlex,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-portable-smoke-a';archive=base/'ctsm-portable-env-a.tar.gz';expected='8f1d5ba12ed58a68e18293c182991d84cacbccd53f7dd8c86e06f687ea719769'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(archive)==expected
scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-portable-smoke';scratch.mkdir(exist_ok=False);prefix=scratch/'environment';prefix.mkdir();begun=time.monotonic()
with tarfile.open(archive) as t:t.extractall(prefix,filter='data')
env=os.environ.copy()
for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',CONDA_PREFIX=str(prefix),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
stages=[]
def run(label,command):
    start=time.monotonic();p=subprocess.run(command,cwd=scratch,env=env,capture_output=True,text=True,timeout=180)
    (scratch/(label+'.stdout.txt')).write_text(p.stdout);(scratch/(label+'.stderr.txt')).write_text(p.stderr)
    stages.append(dict(stage=label,command=[str(v) for v in command],returncode=p.returncode,seconds=time.monotonic()-start))
    assert p.returncode==0,(label,p.returncode,p.stderr[:300]);return p.stdout
run('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')])
cc=str(prefix/'bin/x86_64-conda-linux-gnu-gcc');fc=str(prefix/'bin/x86_64-conda-linux-gnu-gfortran')
versions={}
for label,cmd in [('gcc',[cc,'--version']),('gfortran',[fc,'--version']),('python',[str(prefix/'bin/python'),'--version']),('git',[str(prefix/'bin/git'),'--version']),('cmake',[str(prefix/'bin/cmake'),'--version']),('nc-config',[str(prefix/'bin/nc-config'),'--all']),('nf-config',[str(prefix/'bin/nf-config'),'--all'])]:versions[label]=run(label,cmd)
c='''#include <netcdf.h>
#include <stdio.h>
int main(void){int n,d,v;double x[2]={1.25,2.5};
if(nc_create("c-smoke.nc",NC_CLOBBER,&n))return 1;
if(nc_def_dim(n,"n",2,&d)||nc_def_var(n,"value",NC_DOUBLE,1,&d,&v)||nc_enddef(n)||nc_put_var_double(n,v,x)||nc_close(n))return 2;
puts("C netCDF write complete");return 0;}
'''
f='''program smoke
use netcdf
implicit none
integer :: n,d,v,code
real(8) :: x(2)
code=nf90_open("c-smoke.nc",nf90_nowrite,n)
if(code/=nf90_noerr) stop 1
code=nf90_inq_varid(n,"value",v)
if(code/=nf90_noerr) stop 2
code=nf90_get_var(n,v,x)
if(code/=nf90_noerr) stop 3
if(any(x/=(/1.25d0,2.5d0/))) stop 4
code=nf90_close(n)
if(code/=nf90_noerr) stop 5
code=nf90_create("fortran-smoke.nc",nf90_clobber,n)
if(code/=nf90_noerr) stop 6
code=nf90_def_dim(n,"n",2,d)
if(code/=nf90_noerr) stop 7
code=nf90_def_var(n,"value",nf90_double,(/d/),v)
if(code/=nf90_noerr) stop 8
code=nf90_enddef(n)
if(code/=nf90_noerr) stop 9
x=(/277.5d0,3.d0/)
code=nf90_put_var(n,v,x)
if(code/=nf90_noerr) stop 10
code=nf90_close(n)
if(code/=nf90_noerr) stop 11
print *,"Fortran netCDF read/write complete"
end program smoke
'''
(scratch/'smoke.c').write_text(c);(scratch/'smoke.f90').write_text(f)
nc=lambda flag:shlex.split(run('nc-'+flag.removeprefix('--'),[str(prefix/'bin/nc-config'),flag]).strip())
nf=lambda flag:shlex.split(run('nf-'+flag.removeprefix('--'),[str(prefix/'bin/nf-config'),flag]).strip())
run('compile-c',[cc,*nc('--cflags'),str(scratch/'smoke.c'),'-o',str(scratch/'c-smoke'),*nc('--libs'),'-Wl,-rpath,'+str(prefix/'lib')])
run('run-c',[str(scratch/'c-smoke')])
run('compile-fortran',[fc,*nf('--fflags'),str(scratch/'smoke.f90'),'-o',str(scratch/'fortran-smoke'),*nf('--flibs'),'-Wl,-rpath,'+str(prefix/'lib')])
run('run-fortran',[str(scratch/'fortran-smoke')])
run('python-netcdf',[str(prefix/'bin/python'),'-c',"from netCDF4 import Dataset; import numpy as np; a=Dataset('c-smoke.nc'); b=Dataset('fortran-smoke.nc'); assert np.array_equal(a.variables['value'][:],[1.25,2.5]); assert np.array_equal(b.variables['value'][:],[277.5,3.]); a.close();b.close();print('C/Fortran/Python netCDF values exact')"])
run('runtime-linkage',['ldd',str(scratch/'fortran-smoke')])
value=dict(scope='EHPC portable dependency smoke only: relocated environment, native C/Fortran netCDF compile/run and Python cross-read. No CTSM source build/model output or scientific acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,archive_sha256=expected,versions=versions,stages=stages,seconds=time.monotonic()-begun,all_commands_returned_zero=True,c_fortran_python_values_exact=True)
out=root/'smoke.json';assert not out.exists();out.write_text(json.dumps(value,indent=2)+'\n')
with tarfile.open(root/'smoke-artifacts.tar.gz','w:gz') as t:
    for p in sorted(scratch.iterdir()):
        if p.is_file():t.add(p,arcname=p.name,recursive=False)
print(json.dumps({k:v for k,v in value.items() if k!='versions'}),flush=True)

from pathlib import Path
import hashlib,io,json,os,subprocess,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'material-numpy-day-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu=json.loads((base/'material-event-cpu-b/receipt.json').read_text());matrix=json.loads((base/'material-event-cpu-b/matrix-receipt.json').read_text())
assert cpu['returncode']==0 and cpu['counts']==dict(tests=808,failures=0,errors=0,skipped=0) and matrix['passed']
source=Path(os.environ['TMPDIR']).resolve()/'source';source.mkdir(exist_ok=False)
archive=base/'p6-material-event-b-source.tar.gz';assert sha(archive)=='a93f09848cb1fd5b14cd025d3e689f8873789c9c4c4e4a282a46d7f23fd3e801'
with tarfile.open(archive) as t:t.extractall(source,filter='data')
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert len(m)==493 and all(sha(source/n)==v for n,v in m.items())
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from noahmp_clm.validation import compare_series
inputs=base/'fluxnet-first-climate-cycle-20261017-h';batch=json.loads((inputs/'batch.json').read_text())['cases'];assert len(batch)==4
reference=base/'joint-chord-k-day-a-evidence.tar.gz';assert sha(reference)=='bd5cc01b7ee03ec756cfb12f40f6035e392005394f92cd11b3f53c677a67d95c'
scratch=Path(os.environ['TMPDIR']).resolve()/'model';scratch.mkdir(exist_ok=False)
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[base/'test-deps',source,source/'src',source/'tests',source/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');env.pop('NOAHMP_REQUIRE_GPU',None)
begun=time.monotonic();jobs=[]
for row in batch:
 command=[sys.executable,'-u',str(source/'benchmarks/run_fluxnet_column.py'),'--input',row['input'],'--input-manifest',row['input_manifest'],'--config',row['configuration'],'--output',str(scratch/row['case']),'--stop-after','48']
 with (root/(row['case']+'.log')).open('w') as log:p=subprocess.Popen(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 jobs.append((p,row));print(json.dumps(dict(case=row['case'],pid=p.pid,command=command)),flush=True)
protocol=dict(scope='Fresh source493 NumPy64 cold48 after actual complete CPU808 and existing GPU-reference matrix. Original locked four physical seeds/forcing/configurations, full17520 request retained as running prefix. No failed annual state reuse, no spinup/scientific acceptance. Compare independent original source489 CUDA K48, not its JAX shadow.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_archive_sha256=sha(archive),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),reference_archive_sha256=sha(reference))
(root/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(root/'SOURCE_SHA256.json').write_bytes((source/'SOURCE_SHA256.json').read_bytes())
while any(p.poll() is None for p,_ in jobs):
 rows=[]
 for p,row in jobs:
  path=scratch/row['case']/'report.json';d=json.loads(path.read_text()) if path.exists() else {}
  rows.append(dict(case=row['case'],returncode=p.poll(),steps_completed=d.get('steps_completed'),status=d.get('status')))
 temp=root/'progress.tmp';temp.write_text(json.dumps(dict(rows=rows,seconds=time.monotonic()-begun),indent=2)+'\n');os.replace(temp,root/'progress.json');time.sleep(15)
results=[];failures=[]
# Preserve every terminal prefix before checking any success condition, so
# a failed case also survives PBS temporary-directory cleanup unchanged.
for p,row in jobs:
 folder=scratch/row['case'];dest=root/(row['case']+'-prefix.tar.gz')
 with tarfile.open(dest,'w:gz') as output:
  for path in sorted(folder.rglob('*')):
   if path.is_file():output.add(path,arcname=path.relative_to(folder),recursive=False)
with tarfile.open(reference) as t:
 baseline=json.load(t.extractfile('cuda-day/batch.json'));assert baseline['steps_completed']==48 and baseline['identity']['compare_jax32']
 for p,row in jobs:
  case=row['case'];folder=scratch/case;report=json.loads((folder/'report.json').read_text());code=p.wait()
  if not (code==0 and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['source_unchanged']):
   failures.append([case,'model_prefix',code,report['status'],report['steps_completed']]);results.append(dict(case=case,returncode=code,status=report['status'],steps_completed=report['steps_completed'],failure=report.get('failure'),prefix_archive=case+'-prefix.tar.gz',prefix_archive_sha256=sha(root/(case+'-prefix.tar.gz'))));continue
  desc=baseline['case_reports'][case];native=json.load(t.extractfile('cuda-day/'+case+'/'+desc['file']))
  for key in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert report[key]==native[key]
  raw=t.extractfile('cuda-day/'+case+'/'+native['model_npz']).read();assert hashlib.sha256(raw).hexdigest()==native['model_npz_sha256']
  path=folder/report['model_npz'];assert sha(path)==report['model_npz_sha256']
  with np.load(path,allow_pickle=False) as z, np.load(io.BytesIO(raw),allow_pickle=False) as other:
   for key in ['time_start','time_end']:np.testing.assert_array_equal(z[key],other[key])
   fields={}
   for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
    a=z[key].astype(float)*factor+offset;b=other[key].astype(float)*factor+offset
    if a.ndim==1:a=a[:,None];b=b[:,None]
    values=[compare_series(a[:,k],b[:,k],var) for k in range(a.shape[1])];fields[key]=values
    for k,v in enumerate(values):
     if not v['bias_pass']:failures.append([case,key,k,'bias',v['bias']])
     if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and v['correlation_pass'] is False:failures.append([case,key,k,'r',v['r']])
  dest=root/(case+'-prefix.tar.gz')
  results.append(dict(case=case,returncode=code,steps_completed=report['steps_completed'],steps_requested=report['steps_requested'],status=report['status'],metrics=fields,maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],prefix_archive=dest.name,prefix_archive_sha256=sha(dest)))
unchanged=all(sha(source/n)==v for n,v in m.items());passed=unchanged and not failures
r=dict(**protocol,prefix_validation_passed=passed,cases=results,failures=failures,source_unchanged=unchanged,seconds=time.monotonic()-begun)
(root/'exit.json').write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(passed=passed,failures=failures,seconds=r['seconds'])),flush=True);raise SystemExit(0 if passed else 1)

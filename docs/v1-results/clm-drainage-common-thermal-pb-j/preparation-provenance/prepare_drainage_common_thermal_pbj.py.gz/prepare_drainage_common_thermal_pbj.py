"""Prepare a single original-hydrology/shared-NM64-thermal split experiment."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import tarfile

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'clm-drainage-hydraulic-pb-h-reference'
DEST=ROOT/'clm-drainage-common-thermal-pb-j-reference'
sha=lambda b:hashlib.sha256(b).hexdigest()

READ_FRAME='''  read(input_unit,*,iostat=ierr) ipc_step
  if (ierr /= 0 .or. ipc_step /= istep) stop 11
  do j=1,n
     read(input_unit,*,iostat=ierr) shared_water(j), shared_enthalpy(j), &
          t%t_soisno_col(1,j), w%h2osoi_liq_col(1,j), w%h2osoi_ice_col(1,j)
     if (ierr /= 0) stop 12
  enddo
  ! Only boundary state import; no thermodynamic or hydrologic implementation.
  s%eff_porosity_col=s%watsat_col-w%h2osoi_ice_col/(917._r8*col%dz)
  call ThetaBasedWaterTable(bounds, 1, hydro_filter, 0, urban_filter, h, s, w, f)
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_SHARED_WATER', shared_water
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_SHARED_ENTHALPY', shared_enthalpy
  write(*,'(a,1(1x,es25.17))') 'PB_OFFICIAL_INITIAL_SNOW', w%h2osno_col(1)
'''

FINAL_FRAME='''  ! Receive/echo the final external phase state before diagnostic-only readback.
  read(input_unit,*,iostat=ierr) ipc_step
  if (ierr /= 0 .or. ipc_step /= nsteps+1) stop 13
  do j=1,n
     read(input_unit,*,iostat=ierr) shared_water(j), shared_enthalpy(j), &
          t%t_soisno_col(1,j), w%h2osoi_liq_col(1,j), w%h2osoi_ice_col(1,j)
     if (ierr /= 0) stop 14
  enddo
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_FINAL_SHARED_WATER', shared_water
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_FINAL_SHARED_ENTHALPY', shared_enthalpy
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_FINAL_SHARED_TEMPERATURE', t%t_soisno_col(1,:)
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_FINAL_SHARED_LIQ', w%h2osoi_liq_col(1,:)
  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_FINAL_SHARED_ICE', w%h2osoi_ice_col(1,:)
  s%eff_porosity_col=s%watsat_col-w%h2osoi_ice_col/(917._r8*col%dz)
'''


def main():
    DEST.mkdir(exist_ok=True)
    source=(OLD/'drainage_caller.f90').read_text(encoding='utf8')
    text=source.replace('  use shr_kind_mod, only: r8 => shr_kind_r8','  use iso_fortran_env, only: input_unit, output_unit\n  use shr_kind_mod, only: r8 => shr_kind_r8')
    text=text.replace('integer :: ierr, unit, j, dt, nsteps, istep','integer :: ierr, unit, j, dt, nsteps, istep, ipc_step')
    text=text.replace('real(r8) :: slope, baseflow','real(r8) :: slope, baseflow, shared_water(n), shared_enthalpy(n)')
    text=text.replace('if (nsteps < 1 .or. nsteps > 1024) stop 4','if (nsteps /= 960 .or. dt /= 90 .or. baseflow /= 0._r8) stop 4')
    text=text.replace('  do istep=1,nsteps\n',"  write(*,'(a)') 'PB_IPC_READY'\n  flush(output_unit)\n  do istep=1,nsteps\n"+READ_FRAME)
    text=text.replace('  call advance_timestep()\n  enddo\n','  call advance_timestep()\n'+
        "  write(*,'(a,2(1x,i8))') 'PB_OFFICIAL_ENDSTEP', istep, get_nstep()\n  flush(output_unit)\n  enddo\n"+FINAL_FRAME)
    text=text.replace('  call advance_timestep()\n',
        "  write(*,'(a,1(1x,es25.17))') 'PB_OFFICIAL_FINAL_SNOW', w%h2osno_col(1)\n"+
        "  write(*,'(a,4(1x,es25.17))') 'PB_OFFICIAL_AUX_FLUXES', f%qflx_snwcp_liq_col(1), &\n"+
        "       f%qflx_dew_grnd_col(1), f%qflx_dew_snow_col(1), f%qflx_sub_snow_col(1)\n"+
        '  call advance_timestep()\n')
    # No repeated PerchedWaterTable within the loop: the official migrating front
    # and initial frost geometry survive all imported phase states.
    assert text.count('call PerchedLateralFlow(')==source.count('call PerchedLateralFlow(')==1
    assert text.count('call LateralFlowPowerLaw(')==source.count('call LateralFlowPowerLaw(')==1
    assert text.count('call PerchedWaterTable(')==source.count('call PerchedWaterTable(')==2
    loop=text.split('  do istep=1,nsteps\n')[1].split('  ! Receive/echo')[0]
    assert 'call PerchedWaterTable(' not in loop
    (DEST/'drainage_caller.f90').write_text(text,encoding='utf8',newline='\n')
    (DEST/'caller-original-to-ipc.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='frozen_E_H_caller',tofile='PB_j_IPC_caller')),encoding='utf8',newline='\n')
    for name in ('reference-pb-d-comparisons.json','reference-pb-e-comparisons.json','saturated_drainage_pb.py'):
        (DEST/name).write_bytes((OLD/name).read_bytes())
    binding=json.loads((OLD/'REFERENCE_BINDINGS.json').read_bytes())
    binding.update(new_reference_steps=[960],dt_seconds=90,reused_main_pb_c_integration=False,
        experiment='Original public hydrology plus explicit shared NM64 liquid-parcel heat and phase inverse',
        original_caller_sha256=sha((OLD/'drainage_caller.f90').read_bytes()),prepared_only=True,submitted=False,
        numpy_diagnostic_scope='960 actual external heat/phase steps; no frozen coefficient, no PB forward rerun; original 1616 dynamic PB reused',
        shared_thermal_operator='NM584 SoilEnthalpyState; shared, not an independent official heat reference',
        official_source_url='https://raw.githubusercontent.com/ESCOMP/CTSM/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/src/biogeophys/SoilHydrologyMod.F90')
    (DEST/'REFERENCE_BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf8',newline='\n')
    for name in ('run_reference_pb.py','reference_pb.pbs','dispatch_reference_pb.py'):
        code=(OLD/name).read_text(encoding='utf8').replace('noahmp-clm-drainage-hydraulic-pb-h','noahmp-clm-drainage-common-thermal-pb-j')
        code=code.replace('dispatch_drainage_hydraulic_pbh.py','dispatch_drainage_common_thermal_pbj.py')
        code=code.replace('six refinement profiles','one shared-thermal split profile')
        code=code.replace('six-profile refinement comparison','one-profile shared-NM64-thermal split comparison')
        code=code.replace("len(comparison['profiles'])==2","len(comparison['profiles'])==1")
        code=code.replace('profiles=2,component_physics_runs=1346,official_processes=2,official_drainage_steps=1344,numpy_component_integrations=2,numpy_frozen_rate_trials=0',
            'profiles=1,component_physics_runs=1920,official_processes=1,official_drainage_steps=960,numpy_shared_thermal_steps=960,numpy_component_integrations=0,numpy_frozen_rate_trials=0')
        code=code.replace("str(root/'comparison'),str(exe)],150,compare_env)","str(root/'comparison'),str(exe)],270,compare_env)")
        (DEST/name).write_text(code,encoding='utf8',newline='\n')
    (DEST/'README.md').write_text('''# PB-j common thermal closure, prepared only

One existing extreme-Ks donor-depletion profile, exactly 960 real official clock
steps of 90 s. Reuse the pinned original public library and all original channel
outputs. The small caller diff adds only a 17-digit IPC boundary, state echo,
and step acknowledgement. No official physics is copied, replaced or stubbed.
Original three fixtures, fixed-ice H cases and dynamic PB-c 1616 are not rerun.

For every step the original public routines independently determine actual
donor withdrawals and migrating front. The external Python harness applies
the explicit liquid parcel energy M_i*(Lf+CW*(T_i-TF)) to authoritative H and
re-equilibrates the actual W/H using shared frozen NM64 SoilEnthalpyState.
Actual T/liquid/ice are returned for the next official step, not frozen or
overwritten. The shared phase closure is not an official or independent heat
truth. The independent reference is official hydrology under this declared
thermal closure; full CTSM coupled thermal validation is not claimed.

IPC uses .17g Python input and es25.17 Fortran output. All W/H/T/liquid/ice
round trips are exact bytes; phase sums and official post-water versus the
canonical Kahan W use original floating budgets. Every step verifies the
main diagnostic used by Sy remains 2 m, original frost band is unchanged,
and official migrating perched front continues without re-diagnosis/reset.
Only final diagnostic readback is separately labelled. Every output channel,
WA, qcharge, surfacewater and ice is saved. Watmin, negative drainage, main
redistribution or any non-pure outlet triggers an explicit recorded stop,
not a fabricated heat source or a clipped mass.

The original 1616 dynamic PB result is the comparison, with 10% or near-zero
absolute 0.001 kg/m2 donor gates and 0.001 m front gate. A remaining discrepancy
is reported rather than tuned. This one fixed split step can expose thermal
boundary effects; it is not an order-of-convergence experiment. Root must
review frozen controls before any EHPC submission; no GPU or active year is
touched. Existing build/portable/source only; /tmp, PBS1CPU2GB10min.
''',encoding='utf8',newline='\n')
    for f in DEST.glob('*.py'):ast.parse(f.read_text(encoding='utf8'))
    assert (DEST/'compare_official_pb.py').is_file()
    inv={p.name:sha(p.read_bytes()) for p in sorted(DEST.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'}
    (DEST/'CONTROLS_SHA256.json').write_text(json.dumps(inv,indent=2)+'\n',encoding='utf8',newline='\n')
    raw=(ROOT/'climatology-final-candidate-nm-source.tar.gz').read_bytes();assert sha(raw)=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    data={'source.tar.gz':raw,**{'controls/'+p.name:p.read_bytes() for p in DEST.iterdir()}}
    data['stage-inventory.json']=(json.dumps({n:sha(v) for n,v in data.items()},indent=2)+'\n').encode()
    target=ROOT/'clm-drainage-common-thermal-pb-j-stage.tar.gz'
    with tarfile.open(target,'w:gz') as t:
        for n,v in sorted(data.items()):
            m=tarfile.TarInfo(n);m.size=len(v);t.addfile(m,io.BytesIO(v))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==data
    proof=dict(actual_static_exit=0,controls_manifest_sha256=sha((DEST/'CONTROLS_SHA256.json').read_bytes()),
        controls=len(inv),stage_archive=target.name,stage_archive_sha256=sha(target.read_bytes()),stage_members=len(data),
        requested_official_steps=960,requested_shared_NM64_phase_steps=960,prepared_only=True,submitted=False,numerical_execution=False,
        original_physics_calls_retained=True,no_perched_front_reset_within_loop=True,official_thermal_truth=False)
    (ROOT/'clm-drainage-common-thermal-pb-j-static-preparation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8',newline='\n')
    print(json.dumps(proof))


if __name__=='__main__':main()

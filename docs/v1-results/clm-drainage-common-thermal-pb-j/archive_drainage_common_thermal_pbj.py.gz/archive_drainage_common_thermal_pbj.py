"""Archive the actual closed single original-hydrology/shared-thermal run."""
from pathlib import Path
import hashlib
import io
import json
import math
import re
import socket
import subprocess
import tarfile

assert socket.gethostname()=='manager'
ROOT=Path('/tmp/noahmp-clm-drainage-common-thermal-pb-j');JOB='1647.manager'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
qstat=subprocess.check_output(['qstat','-xf',JOB]);state=qstat.decode()
assert re.search(r'^\s*job_state = F\s*$',state,re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$',state,re.M)
code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',state,re.M).group(1))
for name in ('result.tar.gz','pbs-exit.txt','controller.log'):
    remote=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
    if not (ROOT/name).exists():subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
    assert sha((ROOT/name).read_bytes())==remote
assert int((ROOT/'pbs-exit.txt').read_text())==code
with tarfile.open(ROOT/'result.tar.gz') as tar:
    members={m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
receipt=json.loads(members['receipt.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002' and receipt['passed']==(code==0)
assert receipt['coupled_column_runs']==receipt['GPU_tasks']==0
assert not receipt['official_implementation_changed'] and not receipt['official_stubs']
controls=json.loads(members['controls/CONTROLS_SHA256.json'])
assert len(controls)==11 and sha(members['controls/CONTROLS_SHA256.json'])=='bc7958ea6e910faf8c68db1b4ca0f5aaa2c24da37fbddb607d4c6206c993ced1'
assert all(sha(members['controls/'+n])==h for n,h in controls.items())
prefix='comparison/perched_common_thermal_960/'
readout=dict(actual_job=JOB,actual_state='F',actual_exit=code,Stageout_status=0,receipt=receipt,
    official_thermal_truth=False,scientific_acceptance=False)
if code==0:
    assert receipt['profiles']==1 and receipt['official_drainage_steps']==960 and receipt['numpy_shared_thermal_steps']==960
    assert receipt['numpy_component_integrations']==0
    assert all(s['actual_parent_returncode']==0 for s in receipt['stages'])
    assert receipt['source_and_controls_unchanged'] and receipt['original_official_objects_unchanged']
    result=json.loads(members['comparison/comparisons.json'])
    assert result['execution_succeeded'] and len(result['profiles'])==1
    records=[json.loads(line) for line in members[prefix+'step-ledgers.jsonl'].decode().splitlines()]
    assert len(records)==960 and [r['step'] for r in records]==list(range(1,961))
    raw=members[prefix+'official.stdout.txt'].decode()
    assert sum(line.startswith('PB_OFFICIAL_ENDSTEP ') for line in raw.splitlines())==960
    assert sum(line.startswith('PB_OFFICIAL_STEP ') for line in raw.splitlines())==960
    assert len(members[prefix+'ipc-input.txt'].decode().splitlines())==961*5
    ex=json.loads(members[prefix+'official-exit.json'])
    assert ex['actual_parent_returncode']==0 and ex['completed'] and ex['actual_completed_official_steps']==960
    for r in records:
        assert not r['nonpure_channel_active'] and r['main_Sy_depth_m']==2. and r['frost_band_m']==1.25
        for residual,bound in [('water_residual','water_bound'),('energy_residual','energy_bound'),
                ('step_water_residual','water_bound'),('step_energy_residual','energy_bound'),
                ('official_water_residual','official_water_bound')]:assert abs(r[residual])<=r[bound]
    keys=['water_residual','energy_residual','step_water_residual','step_energy_residual','official_water_residual']
    extremes={k:{n:max(records,key=lambda r:abs(r[k]))[n] for n in
        ['step',k,'water_bound','energy_bound','official_water_bound']} for k in keys}
    readout.update(actual_official_steps=960,actual_shared_thermal_steps=960,actual_IPC_frames=961,
        exact_checked_fields=['W','H','T','liquid','ice'],signed_budget_extremes=extremes,
        elapsed_seconds=math.fsum(r['dt_seconds'] for r in records),
        comparison=result['profiles'][0]['comparison'],final_state=result['profiles'][0]['final_shared_phase'],
        original_initial_front_difference=result['profiles'][0]['initial_pb_minus_official_front_m'],
        all_channels_pure=True,physical_gate_results_separate_from_process_exit=True)
    comparison=readout['comparison']
    front_reference=comparison['official_migrating_front_m']
    assert abs(front_reference)>.01  # This actual 0.6046 m front is not near zero.
    front_percent=100*comparison['front_difference_m']/abs(front_reference)
    readout['P0_component_mass_and_front']=dict(
        layer_mass_percent_difference=comparison['percent_difference'],
        layer_mass_10pct_or_absolute_nearzero=comparison['within_10pct_or_abs_001'],
        front_percent_difference=front_percent,front_within_10_percent=abs(front_percent)<=10,
        original_1mm_diagnostic_flag=comparison['front_within_abs_001'],
        original_1mm_flag_unchanged=True,
        interpretation='The actual non-near-zero front and layer masses satisfy user P0 10% for this isolated reference case. The extra original 1 mm diagnostic remains false. Device and coupled-column validation are incomplete; no complete-module acceptance.')

data={n:v for n,v in members.items() if n!='drainage_caller'}
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt',
        'compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt','controller.log'):
    data['scheduler/'+name]=(ROOT/name).read_bytes()
data['scheduler/actual-qstat.txt']=qstat
if (ROOT/'pbs-output.log').exists():data['scheduler/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
data['common-thermal-readout.json']=(json.dumps(readout,indent=2,allow_nan=False)+'\n').encode()
data['complete-result-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v),included=n!='drainage_caller') for n,v in members.items()},indent=2)+'\n').encode()
data['closed-run.json']=(json.dumps(dict(pbs_job=JOB,actual_state='F',actual_exit=code,Stageout_status=0,
    original_result_archive=str(ROOT/'result.tar.gz'),original_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),
    original_result_members=len(members),omitted_executable_sha256=sha(members['drainage_caller']) if 'drainage_caller' in members else None,
    source_and_original_build_archives_separately_bound_in_receipt=True),indent=2)+'\n').encode()
for name in ('prepare_drainage_common_thermal_pbj.py','clm-drainage-common-thermal-pb-j-static-preparation.json',
        'clm-drainage-common-thermal-pb-j-final-porosity-review.json','clm-drainage-common-thermal-pb-j-static-before-final-porosity.json'):
    data['preparation-provenance/'+name]=(ROOT/name).read_bytes()
data['archive_drainage_common_thermal_pbj.py']=Path(__file__).read_bytes()
data['SCOPE.md']=b'''# Scope of the actual PB-j experiment

Only the public hydrology routines of the pinned official library provide the
independent reference. The explicitly shared NM64 thermal closure applies
actual donor mass times liquid specific enthalpy, keeps authoritative W/H, and
re-equilibrates phase before the next real official step. This is not official
thermal truth, a complete coupled CTSM column, or a field-calibrated soil.

Raw 17-digit IPC input, original stdout, signed per-step/cumulative M/H ledgers,
every stock/correction channel, actual phase state, clocks and exit statuses are
retained. No original small profile or sealed 1616 dynamic PB integration was
rerun. The initial 1.34e-7 m diagnostic rounding difference is retained. The
final migration front is distinct from diagnostic-only final re-diagnosis.

The unexecuted initial stage is preserved separately; its final effective
porosity refresh was corrected before submission, with the exact one-line
static proof included. Process exit zero is not a scientific gate result.
All actual differences and unresolved gates are in common-thermal-readout.json.
The original 1 mm front diagnostic remains false. The measured front is not
near zero and its relative difference is below P0 10%; the outer readout reports
both without rewriting the original flag. This does not close device or
coupled-column requirements and is not complete-module acceptance.
'''
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
target=ROOT/'clm-drainage-common-thermal-pb-j-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tar:
    for n,v in sorted(data.items()):
        item=tarfile.TarInfo(n);item.size=len(v);tar.addfile(item,io.BytesIO(v))
with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_state='F',actual_exit=code,Stageout_status=0,
    official_drainage_steps=receipt.get('official_drainage_steps',0),shared_NM64_thermal_steps=receipt.get('numpy_shared_thermal_steps',0),
    coupled_column_runs=0,GPU_runs=0,scientific_acceptance=False,complete_module_acceptance=False,official_thermal_truth=False,
    scope='One original-public-library hydrology profile with 960 actual 90-second steps and explicit shared NM64 liquid-parcel heat/phase closure. Full raw IPC, signed water/energy ledgers and correction channels retained. Original1616 dynamic PB result reused, scientific gates separate from process success. No new GPU, full-column, annual or production acceptance.')
(ROOT/'clm-drainage-common-thermal-pb-j-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

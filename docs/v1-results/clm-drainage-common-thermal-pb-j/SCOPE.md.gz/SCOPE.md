# Scope of the actual PB-j experiment

Only the public hydrology routines of the pinned official library provide the
independent reference. The explicitly shared NM64 thermal closure applies
actual donor mass times liquid specific enthalpy, keeps authoritative W/H, and
re-equilibrates phase before the next real official step. This is not official
thermal truth, a complete coupled CTSM column, or a field-calibrated soil.

Raw 17-digit IPC input, original stdout, signed per-step/cumulative M/H ledgers,
every stock/correction channel, actual phase state, clocks and exit statuses are
retained. No original small profile or sealed 1616 dynamic PB integration was
rerun. The initial 1.34e-7 m diagnostic rounding difference is retained. The
final migration front is distinct from diagnostic-only final re-diagnosis.

The unexecuted initial stage is preserved separately; its final effective
porosity refresh was corrected before submission, with the exact one-line
static proof included. Process exit zero is not a scientific gate result.
All actual differences and unresolved gates are in common-thermal-readout.json.
The original 1 mm front diagnostic remains false. The measured front is not
near zero and its relative difference is below P0 10%; the outer readout reports
both without rewriting the original flag. This does not close device or
coupled-column requirements and is not complete-module acceptance.

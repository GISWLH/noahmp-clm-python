# PB-j common thermal closure, prepared only

One existing extreme-Ks donor-depletion profile, exactly 960 real official clock
steps of 90 s. Reuse the pinned original public library and all original channel
outputs. The small caller diff adds only a 17-digit IPC boundary, state echo,
and step acknowledgement. No official physics is copied, replaced or stubbed.
Original three fixtures, fixed-ice H cases and dynamic PB-c 1616 are not rerun.

For every step the original public routines independently determine actual
donor withdrawals and migrating front. The external Python harness applies
the explicit liquid parcel energy M_i*(Lf+CW*(T_i-TF)) to authoritative H and
re-equilibrates the actual W/H using shared frozen NM64 SoilEnthalpyState.
Actual T/liquid/ice are returned for the next official step, not frozen or
overwritten. The shared phase closure is not an official or independent heat
truth. The independent reference is official hydrology under this declared
thermal closure; full CTSM coupled thermal validation is not claimed.

IPC uses .17g Python input and es25.17 Fortran output. All W/H/T/liquid/ice
round trips are exact bytes; phase sums and official post-water versus the
canonical Kahan W use original floating budgets. Every step verifies the
main diagnostic used by Sy remains 2 m, original frost band is unchanged,
and official migrating perched front continues without re-diagnosis/reset.
Only final diagnostic readback is separately labelled. Every output channel,
WA, qcharge, surfacewater and ice is saved. Watmin, negative drainage, main
redistribution or any non-pure outlet triggers an explicit recorded stop,
not a fabricated heat source or a clipped mass.

The original 1616 dynamic PB result is the comparison, with 10% or near-zero
absolute 0.001 kg/m2 donor gates and 0.001 m front gate. A remaining discrepancy
is reported rather than tuned. This one fixed split step can expose thermal
boundary effects; it is not an order-of-convergence experiment. Root must
review frozen controls before any EHPC submission; no GPU or active year is
touched. Existing build/portable/source only; /tmp, PBS1CPU2GB10min.

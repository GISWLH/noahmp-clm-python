"""Single original public hydrology run with explicitly shared NM64 thermal split."""
from pathlib import Path
import hashlib
import json
import math
import os
import signal
import socket
import subprocess
import sys

assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID')
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState,enthalpy_and_capacity
from noahmp_clm.physics.snowpack import LF,CW,TF
import saturated_drainage_pb as pb


def save(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')


def plain(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,(np.integer,np.floating,np.bool_)):return value.item()
    if isinstance(value,dict):return {k:plain(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [plain(v) for v in value]
    return value


def exact(actual,expected):
    a=np.asarray(actual,dtype=np.float64);b=np.asarray(expected,dtype=np.float64)
    assert a.shape==b.shape and a.tobytes()==b.tobytes(),(a,b)


def kahan(total,compensation,increment):
    y=increment-compensation;updated=total+y
    return updated,(updated-total)-y


def stock_payload(state):
    return np.column_stack((state.water,state.enthalpy,state.temperature,state.liquid,state.ice))


def phase_check(state):
    assert state.water.dtype==state.enthalpy.dtype==np.float64
    probe=SoilEnthalpyState(state.water.copy(),state.enthalpy.copy(),state.dz.copy(),state.params,state.freezing_option)
    exact(stock_payload(state),stock_payload(probe))
    balance=state.liquid+state.ice-state.water
    assert np.all(abs(balance)<=64*np.finfo(float).eps*np.maximum(state.water,1))


def alarm_handler(_signum,_frame):raise TimeoutError('Bounded original caller/shared-phase IPC expired')


root,exe=Path(sys.argv[1]),Path(sys.argv[2]);root.mkdir(exist_ok=False)
here=root/'perched_common_thermal_960';here.mkdir()
control=Path(__file__).resolve().parent
binding=json.loads((control/'REFERENCE_BINDINGS.json').read_bytes())
prior_raw=(control/'reference-pb-d-comparisons.json').read_bytes()
history_raw=(control/'reference-pb-e-comparisons.json').read_bytes()
assert hashlib.sha256(prior_raw).hexdigest()==binding['original_member_sha256']
assert hashlib.sha256(history_raw).hexdigest()==binding['pb_e_comparisons_sha256']
prior=json.loads(prior_raw);history=json.loads(history_raw)
old=next(r for r in prior['profiles'] if r['name']=='perched_cross_donors_exhausted')
spec=dict(old['spec'],name='perched_common_thermal_960',dt=90,nsteps=960)
params=SoilParams(satdk=spec['satdk']);dz=np.full(4,.5)
water=np.array(spec['theta'])*1000*dz
initial=SoilEnthalpyState(water,enthalpy_and_capacity(water,np.array(spec['temperature']),dz,params)[0],dz,params)
exact(initial.liquid,old['steps'][0]['INITIAL_LIQ']);exact(initial.ice,old['steps'][0]['INITIAL_ICE'])
exact(initial.temperature,old['steps'][0]['TEMPERATURE'])
drainage=pb.DrainageParameters(2.,.2,baseflow_mm_s_per_m=0.)
diagnosis=pb.diagnose_water_tables(initial,drainage)
assert diagnosis['water_table_m']==2. and diagnosis['frost_table_m']==1.25
pb_initial_front=diagnosis['perched_water_table_m']
front=old['steps'][0]['DIAG'][1];bottom=diagnosis['frost_table_m']
# Preserve the actual official diagnostic, including its original threshold
# rounding. The sealed original differs from PB by 1.34e-7 m, not a new fit.
assert abs(front-pb_initial_front)<=1e-6
lines=[f"90 {math.degrees(.2):.17g} 0 960"]
for j in range(4):
    lines.append(' '.join(format(float(v),'.17g') for v in
        (.5,.45,5.5,355.,spec['satdk']*1000.,initial.liquid[j],initial.ice[j],initial.temperature[j])))
fixture=here/'fixture.txt';fixture.write_text('\n'.join(lines)+'\n')
save(here/'profile.json',spec)

current=initial;mass=np.zeros(4);heat=np.zeros(4);mc=np.zeros(4);hc=np.zeros(4)
step_records=[];previous_clock=None;first_clock=None;previous_other=None
final_readback={};process=None;actual_returncode=None;completed=False
scope='Original public hydrology is independent; NM64 heat/phase closure is explicitly shared, not official thermal truth.'
signal.signal(signal.SIGALRM,alarm_handler);signal.alarm(240)
try:
    with (here/'official.stderr.txt').open('wb') as err,(here/'official.stdout.txt').open('w') as log, \
         (here/'ipc-input.txt').open('w') as sent,(here/'step-ledgers.jsonl').open('w') as ledger_file:
        process=subprocess.Popen([str(exe),str(fixture)],cwd=here,stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,start_new_session=True)

        def read_until(marker):
            parsed={}
            while True:
                line=process.stdout.readline()
                if not line:raise RuntimeError('Original caller closed before '+marker)
                log.write(line);log.flush()
                words=line.split()
                if words and words[0].startswith('PB_OFFICIAL_'):
                    key=words[0].removeprefix('PB_OFFICIAL_')
                    assert key not in parsed
                    values=[float(v) for v in words[1:]]
                    assert all(math.isfinite(v) for v in values)
                    parsed[key]=values
                if words and words[0]==marker:return parsed

        def send_frame(index,state):
            phase_check(state)
            payload=stock_payload(state)
            frame=str(index)+'\n'+'\n'.join(' '.join(format(float(v),'.17g') for v in row) for row in payload)+'\n'
            # Verify Python serialization before transmission, without repairing data.
            decoded=np.array([[float(v) for v in row.split()] for row in frame.splitlines()[1:]])
            exact(decoded,payload)
            sent.write(frame);sent.flush();process.stdin.write(frame);process.stdin.flush()

        read_until('PB_IPC_READY')
        for i in range(1,961):
            before=current;send_frame(i,before)
            row=read_until('PB_OFFICIAL_ENDSTEP')
            assert row['STEP'][0]==row['ENDSTEP'][0]==i
            clock=int(row['STEP'][1]);assert row['ENDSTEP'][1]==clock+1
            if previous_clock is not None:assert clock==previous_clock+1
            else:first_clock=clock
            previous_clock=clock
            exact(row['SHARED_WATER'],before.water);exact(row['SHARED_ENTHALPY'],before.enthalpy)
            exact(row['INITIAL_LIQ'],before.liquid);exact(row['INITIAL_ICE'],before.ice);exact(row['TEMPERATURE'],before.temperature)
            assert row['DIAG'][0]==2. and row['DIAG'][2]==bottom
            assert abs(row['DIAG'][1]-front)<=1e-14
            assert pb.diagnose_water_tables(before,drainage)['water_table_m']==2.
            if previous_other is not None:exact(row['INITIAL_OTHER'],previous_other)
            previous_other=row['OTHER'][:3]
            stocks_before=[*row['INITIAL_LIQ'],*row['INITIAL_ICE'],*row['INITIAL_OTHER'][:2],*row['INITIAL_SNOW']]
            stocks_after=[*row['FINAL_LIQ'],*row['FINAL_ICE'],*row['OTHER'][:2],*row['FINAL_SNOW']]
            outlet=90*(row['PERCHED'][0]+row['MAIN'][0]+row['OTHER'][4]+row['OTHER'][5])
            official_mr=math.fsum([*stocks_after,*(-v for v in stocks_before),outlet])
            official_mb=128*np.finfo(float).eps*max(math.fsum(abs(v) for v in stocks_before+stocks_after)+abs(outlet),1.)
            assert abs(official_mr)<=official_mb
            correction=(row['INITIAL_OTHER']!=row['AFTER_PERCH_OTHER'] or row['INITIAL_OTHER']!=row['OTHER'][:3]
                or row['INITIAL_ICE']!=row['AFTER_PERCH_ICE'] or row['INITIAL_ICE']!=row['FINAL_ICE']
                or row['AFTER_PERCH_LIQ']!=row['FINAL_LIQ'] or row['MAIN'][0]!=0. or any(v!=0. for v in row['OTHER'][3:])
                or row['INITIAL_SNOW']!=row['FINAL_SNOW'] or any(v!=0. for v in row['AUX_FLUXES']))
            if correction:
                save(here/'nonpure-channel-stop.json',dict(step=i,official_record=row,pure_outflow_interpretation=False,
                    scope='Stop before any heat attribution; no virtual water/enthalpy or donor repair applied.'))
                raise RuntimeError('Official correction or non-pure outlet activated; pure-export interpretation stopped')
            exported=before.liquid-np.array(row['AFTER_PERCH_LIQ'])
            assert np.all(exported>=0) and np.all(exported<=before.liquid)
            assert abs(math.fsum(exported)-90*row['PERCHED'][0])<=official_mb
            parcel_heat=exported*(LF+CW*(before.temperature-TF))
            mass,mc=kahan(mass,mc,exported);heat,hc=kahan(heat,hc,parcel_heat)
            current=SoilEnthalpyState(initial.water-mass,initial.enthalpy-heat,dz,params)
            phase_check(current)
            # Canonical accumulated stocks and original post-hydrology stocks
            # must agree to the original floating roundoff, not a physics tolerance.
            mb=64*np.finfo(float).eps*max(float(np.sum(abs(initial.water)+abs(current.water)+abs(mass))),1.)
            hb=64*np.finfo(float).eps*max(float(np.sum(abs(initial.enthalpy)+abs(current.enthalpy)+abs(heat))),1.)
            mr=float(np.sum((current.water-initial.water)+mass));hr=float(np.sum((current.enthalpy-initial.enthalpy)+heat))
            assert abs(mr)<=mb and abs(hr)<=hb
            assert np.max(abs(current.water-np.array(row['FINAL_LIQ'])-np.array(row['FINAL_ICE'])))<=mb
            step_mr=math.fsum(current.water-before.water+exported)
            step_hr=math.fsum(current.enthalpy-before.enthalpy+parcel_heat)
            assert abs(step_mr)<=mb and abs(step_hr)<=hb
            newfront=row['PERCHED'][1];assert front<=newfront<=bottom
            front=newfront
            record=dict(step=i,clock_step=clock,dt_seconds=90,official=row,
                exported_layer_water_kg_m2=exported.tolist(),derived_layer_heat_j_m2=parcel_heat.tolist(),
                cumulative_export_kg_m2=mass.tolist(),cumulative_heat_j_m2=heat.tolist(),
                after_shared_phase=stock_payload(current).tolist(),front_m=front,
                official_water_residual=official_mr,official_water_bound=official_mb,
                water_residual=mr,water_bound=mb,energy_residual=hr,energy_bound=hb,
                step_water_residual=step_mr,step_energy_residual=step_hr,
                main_Sy_depth_m=2.,frost_band_m=bottom,nonpure_channel_active=False,external_heat_input_j_m2=0.)
            step_records.append(record);ledger_file.write(json.dumps(record,allow_nan=False)+'\n');ledger_file.flush()
        send_frame(961,current);process.stdin.close()
        final_readback=read_until('PB_OFFICIAL_FINAL_REDIAG')
        remainder=process.stdout.read();log.write(remainder);log.flush()
        actual_returncode=process.wait(timeout=20);assert actual_returncode==0
        for key,expected in [('WATER',current.water),('ENTHALPY',current.enthalpy),('TEMPERATURE',current.temperature),('LIQ',current.liquid),('ICE',current.ice)]:
            exact(final_readback['FINAL_SHARED_'+key],expected)
        assert previous_clock+1-first_clock==960 and len(step_records)==960
        completed=True
finally:
    signal.alarm(0)
    if process is not None and process.poll() is None:
        os.killpg(process.pid,signal.SIGTERM)
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
    if process is not None:actual_returncode=process.returncode
    save(here/'official-exit.json',dict(actual_parent_returncode=actual_returncode,completed=completed,
        actual_completed_official_steps=len(step_records),coupled_column_runs=0,scope=scope))

dynamic=history['pb_perched'];reference_mass=np.array(dynamic['adaptive_ledger']['layer_mass_kg_m2'])
reference_heat=np.array(dynamic['adaptive_ledger']['layer_enthalpy_j_m2'])
difference=reference_mass-mass
comparison=dict(original_1616_archive_sha256=binding['pb_e_archive_sha256'],original_dynamic_reused_not_rerun=True,
    dynamic_pb_layer_mass=reference_mass.tolist(),official_shared_thermal_layer_mass=mass.tolist(),
    dynamic_minus_reference_mass=difference.tolist(),
    percent_difference=[100*float(e/v) if abs(v)>=.01 else None for e,v in zip(difference,mass)],
    within_10pct_or_abs_001=(abs(difference)<=np.maximum(.001,.1*abs(mass))).tolist(),
    dynamic_front_m=dynamic['adaptive_ledger']['migrated_front_m'],official_migrating_front_m=front,
    front_difference_m=dynamic['adaptive_ledger']['migrated_front_m']-front,
    front_within_abs_001=abs(dynamic['adaptive_ledger']['migrated_front_m']-front)<=.001,
    dynamic_heat=reference_heat.tolist(),shared_reference_heat=heat.tolist(),
    heat_difference=(reference_heat-heat).tolist(),heat_is_shared_closure_not_official_thermal_truth=True,
    dynamic_final_temperature=dynamic['final_temperature_k'],shared_final_temperature=current.temperature.tolist(),
    dynamic_final_ice=dynamic['final_ice'],shared_final_ice=current.ice.tolist())
result=dict(execution_succeeded=True,profiles=[dict(spec=spec,actual_official_steps=960,actual_shared_phase_steps=960,
    actual_parent_returncode=actual_returncode,initial_diagnosis=diagnosis,
    original_official_initial_front_m=old['steps'][0]['DIAG'][1],
    initial_pb_minus_official_front_m=pb_initial_front-old['steps'][0]['DIAG'][1],final_migrating_front_m=front,
    final_diagnostic_readback=final_readback,final_shared_phase=stock_payload(current).tolist(),
    cumulative_water_export=mass.tolist(),cumulative_heat_export=heat.tolist(),comparison=comparison,
    maximum_official_water_budget_ratio=max(abs(r['official_water_residual'])/r['official_water_bound'] for r in step_records),
    maximum_shared_water_budget_ratio=max(abs(r['water_residual'])/r['water_bound'] for r in step_records),
    maximum_shared_heat_budget_ratio=max(abs(r['energy_residual'])/r['energy_bound'] for r in step_records),
    all_channels_pure=True,all_IPC_frames_exact=True,all_main_Sy_depths_2m=True)],
    official_processes=1,official_drainage_steps=960,numpy_shared_thermal_steps=960,numpy_component_integrations=0,
    original_1616_dynamic_pb_result=dynamic,source_pb_c_sha256=hashlib.sha256(Path(pb.__file__).read_bytes()).hexdigest(),
    physical_acceptance=False,official_thermal_truth=False,scope=scope)
assert result['source_pb_c_sha256']==binding['unchanged_pb_c_sha256']
save(root/'comparisons.json',plain(result))
print(json.dumps(dict(execution_succeeded=True,official_steps=960,shared_phase_steps=960,comparison=comparison),allow_nan=False))

import inspect,numpy as np,jax,jax.numpy as j,cupy as cp
from pathlib import Path
from test_gpu_canopy_phase_energy import batch,host
import noahmp_clm.gpu.canopy_phase_energy as phase
from noahmp_clm.gpu.cuda.canopy_phase_energy import run_canopy_phase_cuda
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as rk
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.snicar import _jax_tables
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
from check_canopy_phase_gpu import packed,cases,random_cases,same_precision
raw=[*cases(),*random_cases(60)];arrays=packed([phase.pack_canopy_phase(a,sw,lw,e,c,1800.,dtype=np.float32,**kw) for _,a,sw,lw,e,c,kw in raw],np.float32);got=host(phase.run_canopy_phase_jax(*arrays));cuda_final=host(run_canopy_phase_cuda(*arrays),cp.asnumpy)
for i,row in enumerate(raw):
 one=lambda data:{k:({key:value[i] for key,value in v.items()} if isinstance(v,dict) else v[i]) for k,v in data.items()}
 result=same_precision(one(got),one(cuda_final))
 if result['failures']:print('final failure',i,row[0],result,flush=True)
z=np.column_stack((got['phase_coordinates'],got['ground_temperature'],got['canopy_humidity']*1000.)).astype(np.float32)

trace=np.load('phase-iteration-trace.npz');indices=[41,48,56,58,67,68]
for i,k in enumerate(indices):
 z[k,:10]=trace['jax_1'][i,275:285];z[k,10]=trace['jax_1'][i,10];z[k,11]=trace['jax_1'][i,12]*np.float32(1000.)
source=inspect.getsource(phase.phase_energy_kernel_jax).replace('ice,impurity,*,','ice,impurity,z,*,')
debug="""
    r,_=evaluate(z)
    def column(k):
        step=j.where(k==11,j.asarray(.002,u.dtype),j.asarray(.02,u.dtype))
        lo=z.at[k].set(j.maximum(lower[k],s(z[k]-step)));hi=z.at[k].set(j.minimum(upper[k],s(z[k]+step)))
        a,_=evaluate(lo);d,_=evaluate(hi);return s(d-a)/s(hi[k]-lo[k])
    jac=jax.vmap(column)(j.arange(12)).T
    delta=_linear_solve(jac,-r);scale=j.maximum(1.,j.max(abs(delta)/j.concatenate((j.full(10,20.,u.dtype),j.asarray([5.,5.],u.dtype)))))
    return j.concatenate((r,jac.ravel(),delta,delta/scale,j.asarray([scale,_dot(r,r)])))
"""
source=source.replace('    old=j.concatenate',debug+'    old=j.concatenate')
ns=vars(phase).copy();exec(source,ns);kernel=jax.jit(jax.vmap(ns['phase_energy_kernel_jax'],in_axes=(*([0]*9),None,None,None,0)))
a=tuple(map(j.asarray,arrays));jp=j.asarray(pack_leaf_parameters(dtype=np.float32));ja=np.asarray(kernel(*a,jp,*_jax_tables('float32'),j.asarray(z)))
base=Path(phase.__file__).parent/'cuda';cu_source='\n'.join((base/p).read_text() for p in ('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu'))
cu_source+=r"""
extern "C" __global__ void diagnose_jac(const float* leaf,const float* u,const float* f,const float* soil,const float* stem,const float* c,const float* b,const float* radiation,const float* p,const float* input,float* outputs,int n) {
int row=threadIdx.x+blockIdx.x*blockDim.x;if(row>=n)return;PhaseContext v;phase_prepare(leaf+row*10,u+row*23,f+row*20,soil+row*10,stem+row*10,c+row*20,b+row*9,p,radiation+row*584,v);const float* z=input+row*12;float* out=outputs+row*182;
float r[12],jac[144],delta[12],rhs[12];phase_evaluate(v,z,r,nullptr);
for(int k=0;k<12;++k){float lo[12],hi[12],rl[12],rh[12],step=k==11?.002f:.02f;for(int i=0;i<12;++i){lo[i]=z[i];hi[i]=z[i];}
float low=k<10?(v.c[2*k]>0.f?-36.75f:-73.15f):k==10?200.f:0.f,up=k<10?(v.c[2*k]>0.f?(79.90430622009569f+350.f)-273.15f:76.85f):k==10?350.f:190.f;
lo[k]=fmaxf(low,z[k]-step);hi[k]=fminf(up,z[k]+step);phase_evaluate(v,lo,rl,nullptr);phase_evaluate(v,hi,rh,nullptr);for(int i=0;i<12;++i)jac[i*12+k]=(rh[i]-rl[i])/(hi[k]-lo[k]);}
for(int i=0;i<12;++i){out[i]=r[i];rhs[i]=-r[i];}for(int i=0;i<144;++i)out[12+i]=jac[i];phase_linear(jac,rhs,delta);float scale=1.f;for(int i=0;i<12;++i)scale=fmaxf(scale,fabsf(delta[i])/(i<10?20.f:5.f));
for(int i=0;i<12;++i){out[156+i]=delta[i];out[168+i]=delta[i]/scale;}out[180]=scale;out[181]=ca_dot(r,r,12);
}
"""
k=cp.RawKernel(cu_source,'diagnose_jac',options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'))
a,u,f,soil,stem,c,b,snow,n=[cp.asarray(x) for x in arrays];area=cp.ascontiguousarray(a+stem);ru=cp.ascontiguousarray(radiation_inputs(area,u,cp));rad=cp.empty((len(a),584),cp.float32);rk(True)((1,),(32,),(area,snow,n,ru,*_tables(),rad,np.int32(len(a))))
out=cp.empty((len(a),182),cp.float32);k(((len(a)+31)//32,),(32,),(a,u,f,soil,stem,c,b,rad,cp.asarray(pack_leaf_parameters(dtype=np.float32)),cp.asarray(z),out,np.int32(len(a))))
cu=cp.asnumpy(out);np.savez('phase-jacobian.npz',jax=ja,cuda=cu,coordinate=z)
for i in indices:
 for label,start,end in [('residual',0,12),('jacobian',12,156),('delta',156,168),('scaled',168,180),('scale_norm',180,182)]:
  idx=np.where(ja[i,start:end]!=cu[i,start:end])[0]+start
  print('row',i,label,[(int(k-start),float(ja[i,k]),float(cu[i,k])) for k in idx[:25]],flush=True)

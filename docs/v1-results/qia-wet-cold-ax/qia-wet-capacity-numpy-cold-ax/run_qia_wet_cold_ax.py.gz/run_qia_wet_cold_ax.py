from pathlib import Path
from dataclasses import fields,is_dataclass
import hashlib,json,os,pickle,struct,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');label=os.environ['CAPACITY_CASE'];assert label in ['capacity','capacity_optics'];b=Path('/home/zhangyq/noahmp-v1');r=b/('qia-wet-'+label+'-numpy-cold-ax');s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-canopy-wet-final-aq-source.tar.gz';assert sha(a)=='87d34428812ee484a75dce6c299cea95c3b24a828a0059506ed9d55103d408c7'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
cpu=b/'canopy-wet-final-ar';d=json.loads((cpu/'full-receipt.json').read_text());assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1091,failures=0,errors=0,skipped=0) and d['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
inputs=Path(os.environ['TMPDIR'])/'inputs';inputs.mkdir();a=b/'qia-recovery-c-inputs-u.tar.gz';assert sha(a)=='b5f3f02c09336140ab0d492bad9cade5e55076de62a4eb1a18c6aad1cabbe5fe'
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
from noahmp_clm.physics.canopy_interception import MAXIMUM_LEAF_WETTED_FRACTION
assert MAXIMUM_LEAF_WETTED_FRACTION==.05
private=b/('qia-wet005-'+label+'-numpy-ajb');pr=json.loads((private/'receipt.json').read_text());assert (private/'pbs-exit.txt').read_text().strip()=='0' and pr['failure'] is None and pr['private_runtime_patch'] and pr['captured_calls']==pr['steps_completed']==96
old=json.loads((private/'trajectory/report.json').read_text());assert sha(private/'trajectory/report.json')==pr['report_sha256'] and old['status']=='running' and old['steps_requested']==17520
cfg=json.loads((inputs/label/'config.json').read_text());assert set(cfg)==set(old['configuration']) and {k for k in cfg if cfg[k]!=old['configuration'][k]}<={'case','scope'}
cfg['case']='qia-wet-'+label+'-native-source-cold2003';cfg['scope']='FinalAQ unmodifiedproduction NumPy wetarea.05 prospectivecold2003 original17520request, fixedtwo variants and alloriginalinputs. First96 exactphysicaltrace/finalstate/ledger comparison to independentlyauditedprivateAJB; no runtimephysics replacement. Successfulownprefix maycontinue onlyafter actualterminal0 plus fullstate/ledger/guard verification. No year/spinup/multisite/sciencepass inferred from96.';config=r/'config.json';config.write_text(json.dumps(cfg,indent=2)+'\n')
assert sha(inputs/'CN-Qia.npz')=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960' and sha(inputs/'CN-Qia.json')=='db8d2b2ccb71134dde4bd0ea27abeae8ab4f205a732923bcae0d4b8bee465f93'
start=time.monotonic();failure=None;leaf_count=0;trace_fields=0
def same(x,y,path='state'):
    global leaf_count
    assert type(x) is type(y),(path,type(x),type(y))
    if isinstance(x,np.ndarray):assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes(),path;leaf_count+=1
    elif is_dataclass(x):
        for f in fields(x):same(getattr(x,f.name),getattr(y,f.name),path+'/'+f.name)
    elif isinstance(x,dict):
        assert x.keys()==y.keys(),path
        for k in x:same(x[k],y[k],path+'/'+str(k))
    elif isinstance(x,(tuple,list)):
        assert len(x)==len(y),path
        for k,(a,c) in enumerate(zip(x,y)):same(a,c,path+'/'+str(k))
    elif isinstance(x,(float,np.floating)):assert struct.pack('d',float(x))==struct.pack('d',float(y)),path;leaf_count+=1
    else:assert x==y,path;leaf_count+=1
try:
    report=runner.run(inputs/'CN-Qia.npz',inputs/'CN-Qia.json',config,r/'trajectory',stop_after=96)
    assert report['status']=='running' and report['steps_completed']==96 and report['steps_requested']==17520 and report['source_unchanged']
    left=r/'trajectory'/report['model_npz'];right=private/'trajectory'/old['model_npz'];assert sha(left)==report['model_npz_sha256'] and sha(right)==old['model_npz_sha256']
    with np.load(left,allow_pickle=False) as a,np.load(right,allow_pickle=False) as c:
        assert set(a.files)==set(c.files)
        for key in a.files:same(a[key],c[key],'trace/'+key)
        trace_fields=len(a.files)
    left=r/'trajectory'/report['checkpoint_file'];right=private/'trajectory'/old['checkpoint_file'];assert sha(left)==report['checkpoint_sha256'] and sha(right)==old['checkpoint_sha256'];same(pickle.loads(left.read_bytes()),pickle.loads(right.read_bytes()))
    comparison=json.loads((b/'qia-wet005-comparison-an/comparison.json').read_text());assert (b/'qia-wet005-comparison-an/pbs-exit.txt').read_text().strip()=='0' and comparison['cases'][label]['all96state_chains_and_original_guards_exact']
    (r/'all14-byte-identical-trace-reference.json').write_text(json.dumps(dict(source='EHPC375 independentall14 results for privatecap.05 exactlyidenticalphysicaltrace',metrics=comparison['cases'][label]['private_cap005_metrics'],comparison_sha256=sha(b/'qia-wet005-comparison-an/comparison.json'),scope='Allscientificfailures retained. Exactoutputequivalence does not turn scientificfailedmetrics into pass. OfficialSP NEE remainsunavailable.'),indent=2)+'\n')
except Exception as err:failure=type(err).__name__+': '+str(err);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
p=r/'trajectory/report.json';report=json.loads(p.read_text()) if p.exists() else {};unchanged=all(sha(s/n)==h for n,h in m.items());record=dict(case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_files=564,private_runtime_patch=False,physical_trace_fields_exact=trace_fields,trace_and_finalstate_ledger_checked_leaves=leaf_count,own_report_sha256=sha(p) if p.exists() else None,private_receipt_sha256=sha(private/'receipt.json'),cpu_receipt_sha256=sha(cpu/'full-receipt.json'),seconds=time.monotonic()-start,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),scope=cfg['scope'])
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert failure is None and unchanged and trace_fields==29 and report['steps_completed']==96

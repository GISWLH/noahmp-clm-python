from pathlib import Path
import hashlib,json,os,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'canopy-wet-final-ar';d=json.loads((r/'full-receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1091,failures=0,errors=0,skipped=0) and d['source_manifest_sha256']=='f7af9317a8f49f20d8469b5a09813cee563ffe4c331099d76dc0f1e24164a324';available=os.statvfs(b).f_favail;assert available>2000,available
for label in ['capacity','capacity_optics']:
    r=b/('qia-wet-'+label+'-numpy-cold-ax');assert not r.exists();r.mkdir();controls={}
    for n in ['run_qia_wet_cold_ax.py','qia_wet_cold_ax.pbs']:
        raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
    p=subprocess.run(['qsub','-v','CAPACITY_CASE='+label,str(r/'qia_wet_cold_ax.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
    d=dict(case=label,pbs_job=p.stdout.strip(),controls_sha256=controls,free_home_inodes=available,scope='FinalAQ unmodifiedNumPy physicalcold96 of original17520 request onEHPC compute, verifyall29trace/finalstate/ledger to privateauditedAJB before anyfuturecontinuation. No year/sciencepass.')
    (r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

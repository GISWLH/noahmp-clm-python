from pathlib import Path
import hashlib,json,os,subprocess,sys,time

base=Path('/home/lhwang/work/noahmp-v1');source=base/'capacity-station-final-c';root=source/'target-c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((source/'SOURCE_SHA256.json').read_text());start=time.monotonic()
assert len(manifest)==535 and all(sha(source/n)==h for n,h in manifest.items())
with (root/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(base/'collect_capacity_station_target_c.py')],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0;collection=json.loads((root/'collection.json').read_text())
worker=base/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
results=[];env=os.environ.copy();env['NOAHMP_CAPACITY_STATION_DIAGNOSTICS']=str(root/'diagnostics')
for filename in ['test_gpu_fluxnet_capacity_runner.py']:
    expected=collection['groups'][filename];stem=filename[:-3];expected_path=root/(stem+'-expected.json');expected_path.write_text(json.dumps(expected,indent=2)+'\n')
    receipt=root/(stem+'-receipt.json');xml=root/(stem+'.xml')
    command=[sys.executable,'-u',str(worker),'--source',str(source),'--test-file',str(source/'tests'/filename),'--expected',str(expected_path),'--receipt',str(receipt),'--xml',str(xml)]
    begin=time.monotonic()
    with (root/(stem+'.log')).open('x') as log:child=subprocess.Popen(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
    (root/'active-worker.json').write_text(json.dumps(dict(pid=child.pid,file=filename,command=command),indent=2)+'\n')
    code=child.wait();item=json.loads(receipt.read_text()) if receipt.exists() else None
    passed=bool(item and code==item['pytest_returncode']==item['worker_exitcode']==0 and item['passed'] and item['source_unchanged']
                and item['node_coverage_exact'] and item['all_setup_call_teardown_phases_passed'] and item['counts']==dict(tests=len(expected),failures=0,errors=0,skipped=0)
                and item['source_manifest_sha256']==sha(source/'SOURCE_SHA256.json') and item['test_sha256']==manifest['tests/'+filename] and item['xml_sha256']==sha(xml))
    result=dict(file=filename,returncode=code,passed=passed,seconds=time.monotonic()-begin,receipt_sha256=sha(receipt) if receipt.exists() else None)
    results.append(result);(root/'progress.json').write_text(json.dumps(dict(results=results),indent=2)+'\n');print(json.dumps(result),flush=True)
    if not passed:break
unchanged=all(sha(source/n)==h for n,h in manifest.items());passed=len(results)==1 and all(v['passed'] for v in results) and unchanged
record=dict(scope='535C actualnative station3:20-array evergreenCUDA/JAX32,23-array seasonalCUDA/JAX32 andJAX64 against successfulEHPC154 traces, originalMHCN/allreturnedraw1e-6/int/fullcarriedarrays/splitrestart. ActualfullCPU1009 prerequisite. Originalphases/barriers/atexit bypass disclosure; not full1375/realyear/spinup/FLUXNET acceptance',passed=passed,returncode=0 if passed else 1,
            results=results,source_unchanged=unchanged,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),seconds=time.monotonic()-start)
(root/'exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['returncode'])

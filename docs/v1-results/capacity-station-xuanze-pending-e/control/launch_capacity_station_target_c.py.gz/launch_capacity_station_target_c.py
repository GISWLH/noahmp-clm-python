from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'capacity-station-final-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=json.loads((b/'capacity-station-final-c-package.json').read_text());archive=b/'capacity-station-final-c-source.tar.gz'
assert sha(archive)==package['archive_sha256'] and not s.exists()
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==535 and sha(s/'SOURCE_SHA256.json')==package['manifest_sha256']
assert all(sha(s/n)==h for n,h in m.items())
prior=b/'capacity-station-numpy-b-evidence.tar.gz';assert sha(prior)==package['numpy_evidence_sha256']
with tarfile.open(prior) as tf:
    rec=json.load(tf.extractfile('receipt.json'));assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=154,failures=0,errors=0,skipped=0)
r=s/'target-c';r.mkdir();controls={n:sha(b/n) for n in ['launch_capacity_station_target_c.py','wait_capacity_station_target_c.py','control_capacity_station_target_c.py','collect_capacity_station_target_c.py']}
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',
    PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',
    XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
d=dict(scope='Deferred535C native station3 after actualNP154; wait ownfullCPU1009 evidence and oldFwhole3 actual0, then GPU1 resource guard. Original actual workers retained, queueing not execution or scientific acceptance.',
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device=1,controls_sha256=controls,
    waiting_for=[str(r/'cpu-ready.json'),str(b/'clm-capacity-final-f/full-bgc-f/exit.json')])
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n')
with (r/'wait.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-u',str(b/'wait_capacity_station_target_c.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d['pid']=p.pid;(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

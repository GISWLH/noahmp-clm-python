# PB-r authorized single CPU validation

Exact original1695 preparation19/test/fixture/oracle/observer/gold/reference byte preservation. Worker numerical collect/pytest/timeout/parser/assertions are unchanged; only private paths and transparent candidate-source metadata verification are adapted. New596 source contains one NumPy64 warm-liquid representation fix,595 old files exact. Original PB-p-b and1695/1702 failures remain unchanged.

One compute0021CPU/2GiB/10min job. Actual collect must still report24 nodes before execution; expected count is not a pass. Original20gold diagnosis/trials must retain all647 actual fields, without rerunning17fullgold integrations. All completed32/64 profile outputs, both outlets, layer stocks/T/diagnoses and original hard64eps accounts remain. No GPU/JAX/production or native full-column credit. No automatic retry.

Source597/preparation20/execution8/reference5/candidate8 plus originalsealedgold345/official58 are immutable runtime files; original586 is a subset of source, not additional. Top-level parent-source manifest is separately bound by original source identity and immutable stage inventory. Historical official reference remains provenance only, no rerun or new official truth. RealF/Exit/Stageout and all failures must be retained before publication.

"""Close original24-test PB-r run; stdlib bytes/JSON only, preserve failures."""
from pathlib import Path
from collections import Counter
import hashlib
import io
import json
import re
import shlex
import subprocess
import tarfile
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent; LABEL='clm-drainage-warm-phase-pb-r'
ROOT='/tmp/noahmp-'+LABEL; JOB='1704.manager'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda o:(json.dumps(o,indent=2,allow_nan=False)+'\n').encode()
data={}


def command(argv,label):
    result=subprocess.run(argv,capture_output=True,timeout=50)
    data['closure/'+label+'.stdout.txt']=result.stdout;data['closure/'+label+'.stderr.txt']=result.stderr
    assert result.returncode==0,(label,result.stderr)
    return result.stdout


def remote(cmd,label):
    return command(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20','ehpc',cmd],label)


def read_tar(blob):
    with tarfile.open(fileobj=io.BytesIO(blob)) as t:
        members=[m for m in t if m.isfile()]
        assert len({m.name.removeprefix('./') for m in members})==len(members)
        assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        return {m.name.removeprefix('./'):t.extractfile(m).read() for m in members}


status=remote('qstat -xf '+JOB,'actual-qstat').decode()
assert re.search(r'^\s*job_state = F\s*$',status,re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$',status,re.M)
code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M).group(1))
digest=remote('ssh compute002 '+shlex.quote('sha256sum '+ROOT+'/result.tar.gz'),'compute-result-hash').decode().split()[0]
assert int(remote('ssh compute002 '+shlex.quote('cat '+ROOT+'/pbs-exit.txt'),'compute-pbs-exit'))==code
remote('if test ! -e '+ROOT+'/result.tar.gz; then scp compute002:'+ROOT+'/result.tar.gz '+ROOT+'/result.tar.gz; fi','copy-manager')
assert remote('sha256sum '+ROOT+'/result.tar.gz','manager-result-hash').decode().split()[0]==digest
original_path=OUT/(LABEL+'-1704-original-result.tar.gz')
if not original_path.exists():
    command(['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=20','ehpc:'+ROOT+'/result.tar.gz',str(original_path)],'download-result')
assert sha(original_path.read_bytes())==digest
raw=read_tar(original_path.read_bytes());receipt=json.loads(raw['receipt.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002' and int(raw['worker-exit.txt'])==code
assert receipt['collect_parent_returncode']==0 and receipt['actual_collected_nodes']==24
cases=list(ET.fromstring(raw['tests.xml']).iter('testcase'))
failed=[dict(node=c.attrib['classname']+'::'+c.attrib['name'],message=c.find('failure').attrib['message'],traceback=c.find('failure').text)
    for c in cases if c.find('failure') is not None]
assert len(cases)==receipt['actual_tests']==24 and len(failed)==receipt['failures']
assert json.loads(raw['collect-nodes.json'])==json.loads(raw['run-nodes.json'])
before=json.loads(raw['immutable-before.json']);after=json.loads(raw['immutable-after.json'])
assert before==after and len(before)==1041 and all(sha(raw[n])==h for n,h in before.items())
source=json.loads(raw['source/SOURCE_SHA256.json']);binding=json.loads(raw['candidate/BINDINGS.json'])
assert len(source)==596 and all(sha(raw['source/'+n])==h for n,h in source.items())
assert sha(raw['source/SOURCE_SHA256.json'])==binding['source_manifest_sha256']
assert receipt['candidate_source_archive_sha256']==binding['source_archive_sha256']
for folder,count in (('preparation',19),('execution',7),('reference',4),('candidate',7)):
    index=json.loads(raw[folder+'/CONTROLS_SHA256.json'])
    assert len(index)==count and all(sha(raw[folder+'/'+n])==h for n,h in index.items())
    assert {n.removeprefix(folder+'/') for n in raw if n.startswith(folder+'/')}==set(index)|{'CONTROLS_SHA256.json'}
stage_blob=(OUT/(LABEL+'-stage.tar.gz')).read_bytes();stage=read_tar(stage_blob)
assert sha(stage_blob)=='a45bb261c08a07c48d44c0e5093b34a96b08007475caff524196802a6661da72'
assert len(stage)==46 and all(sha(stage[n])==h for n,h in json.loads(stage['stage-inventory.json']).items())
assert sha(stage['source.tar.gz'])==binding['source_archive_sha256']
parent=json.loads(stage['parent-source-manifest.json'])
assert sha(stage['parent-source-manifest.json'])==binding['parent_manifest_sha256']
assert set(parent)==set(source) and sum(source[n]==h for n,h in parent.items())==595
assert [n for n in parent if source[n]!=parent[n]]==binding['changed_source_files']
original_stage=read_tar((OUT/'clm-drainage-adapter-pb-p-b-stage.tar.gz').read_bytes())
assert all(raw[n]==b for n,b in original_stage.items() if n.startswith(('preparation/','reference/')))
assert raw['execution/observe_pbp.py']==original_stage['execution/observe_pbp.py']
base=json.loads(raw['reference/BASE_PBL_SOURCE_SHA256.json']);assert len(base)==586 and all(source[n]==h for n,h in base.items())
for folder,count in (('sealed-gold',345),('sealed-official-reference',58)):
    members={n.removeprefix(folder+'/'):b for n,b in raw.items() if n.startswith(folder+'/')}
    assert len(members)==count
    index=json.loads(members['artifact-inventory.json']);assert set(index)==set(members)-{'artifact-inventory.json'}
    assert all(sha(members[n])==(h if isinstance(h,str) else h['sha256']) for n,h in index.items())
diagnostics=json.loads(raw['parsed-diagnostics.json'])
parsed=[json.loads(line.split('PB_P_DIAGNOSTIC ',1)[1]) for line in raw['numerical.stdout.txt'].decode().splitlines() if 'PB_P_DIAGNOSTIC ' in line]
assert diagnostics==parsed
gold=json.loads(raw['parsed-gold-records.json'])
assert not receipt['cupy_imported'] and not receipt['jax_imported']
if code==0:
    assert receipt['passed'] and receipt['numerical_parent_returncode']==0
    assert receipt['failures']==receipt['errors']==receipt['skipped']==0
    assert len(diagnostics)==17 and len(gold)==1 and gold[0]['cases']==20
    assert all(all(v['passed'] for v in row['comparisons'].values()) for row in diagnostics)
else:
    assert not receipt['passed']
rows=[]
for record in diagnostics:
    name=record['case'];v=record['comparisons'];saved=json.loads(raw['results/'+name+'.json'])
    assert saved['comparisons']==v and sha(raw['results/'+saved['file']])==saved['sha256']
    relative=[abs(x) for value in v.values() for x in value.get('relative_percent',[]) if x is not None]
    rows.append(dict(case=name,saturated_mass_kg_m2=v['saturated.drained_kg_m2']['actual'],
        saturated_reference_mass_kg_m2=v['saturated.drained_kg_m2']['reference'],
        perched_mass_kg_m2=v['perched.drained_kg_m2']['actual'],perched_reference_mass_kg_m2=v['perched.drained_kg_m2']['reference'],
        maximum_resolved_relative_difference_percent=max(relative,default=None),
        largest_layer_mass_difference_kg_m2=max(x['maximum_absolute_difference'] for k,x in v.items() if 'layer_mass' in k),
        largest_layer_enthalpy_difference_j_m2=max(x['maximum_absolute_difference'] for k,x in v.items() if 'layer_enthalpy' in k),
        largest_temperature_difference_k=v['temperature']['maximum_absolute_difference'],
        original_hard_budget=v['hard_budget'],reference_hard_budget=v['reference_hard_budget']))
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt'):
    data['scheduler/'+name]=remote('cat '+shlex.quote(ROOT+'/'+name),'read-'+name)
data['scheduler/optional-pbs-output.txt']=remote('if test -f '+ROOT+'/pbs-output.log; then cat '+ROOT+'/pbs-output.log; else printf "Optional manager PBS log absent; raw controller/stdout/XML retained.\\n"; fi','optional-pbs-output')
assert json.loads(data['scheduler/dispatch.json'])['stage_archive_sha256']==sha(stage_blob)
scope=('Actual1704 CPU original24 tests of one-file NumPy64 warm-phase representation candidate; actual exit '+str(code)+'. '
    'Original1695 test/observer/fixtures/reference/gold/guards/64eps unchanged; new596source and595parent-exact identity. '
    'Original1695/1702 failures retained. No GPU/JAX/nativefullcolumn/annual/production credit.')
readout=dict(actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,passed=receipt['passed'],
    actual_tests=24,passed_tests=24-receipt['failures']-receipt['errors']-receipt['skipped'],failures=failed,
    receipt=receipt,case_results=rows,original_gold_record=gold,immutable_prefix_counts=dict(Counter(n.split('/')[0] for n in before)),
    raw_result_sha256=digest,raw_result_members=len(raw),source_archive_sha256=binding['source_archive_sha256'],
    source_files=596,unchanged_parent_files=595,original24_test_and_observer_exact=True,original64eps_unchanged=True,
    GPU_executed=False,JAX_executed=False,coupled_column_executed=False,scope=scope)
data['original-result.tar.gz']=original_path.read_bytes();data['original-executed-stage.tar.gz']=stage_blob
data['source-manifest.json']=raw['source/SOURCE_SHA256.json'];data['run-readout.json']=encode(readout)
data['original-result-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in raw.items()})
for n,b in raw.items():
    if '/' not in n or n.startswith(('preparation/','execution/','reference/','candidate/')) or (n.startswith('results/') and n.endswith('.json')):
        data['actual/'+n]=b
for name in ('prepare_drainage_warm_phase_pbr.py','stage_drainage_warm_phase_pbr.py','deploy_drainage_warm_phase_pbr.py',
             LABEL+'-deployment.json',LABEL+'-stage-preparation.json',LABEL+'-static.json',LABEL+'-independent-review-rg.json',
             'clm-drainage-adapter-pb-p-b-package.json','clm-drainage-nonuniform-pb-q-package.json'):
    data['provenance/'+name]=(OUT/name).read_bytes()
data['archive_drainage_warm_phase_pbr.py']=Path(__file__).read_bytes()
data['closed-run.json']=encode(dict(job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,
    raw_result_sha256=digest,source_archive_sha256=binding['source_archive_sha256'],run_count=1))
data['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in data.items()})
target=OUT/(LABEL+'-evidence.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:
    for n,b in sorted(data.items()):
        m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
assert read_tar(target.read_bytes())==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,actual_tests=24,passed_tests=readout['passed_tests'],
    completed_reference_records=len(diagnostics),scope=scope)
(OUT/(LABEL+'-package.json')).write_bytes(encode(package));(OUT/(LABEL+'-readout.json')).write_bytes(encode(readout))
print(json.dumps(package),flush=True)

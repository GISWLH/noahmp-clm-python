"""Bind original1695 tests/observer to the one-file PB-r candidate, stdlib only."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

OUT=Path(__file__).resolve().parent; LABEL='clm-drainage-warm-phase-pb-r'
PREP=OUT/(LABEL+'-preparation'); EXEC=OUT/(LABEL+'-execution')
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda o:(json.dumps(o,indent=2,allow_nan=False)+'\n').encode()


def read(path, digest):
    assert sha(path.read_bytes())==digest
    with tarfile.open(path) as t:
        ms=t.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in ms)
        assert len(set(m.name for m in ms))==len(ms)
        return {m.name:t.extractfile(m).read() for m in ms}


old_stage=read(OUT/'clm-drainage-adapter-pb-p-b-stage.tar.gz','166e8c3fde630e87e448a5d09a05480cecd3fcb4efff9b8df7036926b2fba997')
old_stage_index=json.loads(old_stage['stage-inventory.json'])
assert len(old_stage)==37 and all(sha(old_stage[n])==h for n,h in old_stage_index.items())
assert sha((PREP/'CONTROLS_SHA256.json').read_bytes())=='551b52ce68d204670275ddee2f9fb9839d89c05533a57bbd8388a79cbca45f2b'
controls=json.loads((PREP/'CONTROLS_SHA256.json').read_bytes());assert len(controls)==7
assert all(sha((PREP/n).read_bytes())==h for n,h in controls.items())
binding=json.loads((PREP/'BINDINGS.json').read_bytes())
source=read(OUT/binding['source_archive'],binding['source_archive_sha256'])
parent=read(OUT/binding['parent_archive'],binding['parent_archive_sha256'])
index=json.loads(source['SOURCE_SHA256.json']);old_index=json.loads(parent['SOURCE_SHA256.json'])
assert len(index)==len(old_index)==596
assert all(sha(source[n])==h for n,h in index.items())
changed=[n for n in old_index if old_index[n]!=index[n]]
assert changed==binding['changed_source_files']==['src/noahmp_clm/gpu/clm_drainage_adaptive.py']
assert all(source[n]==parent[n] for n in index if n not in changed)
EXEC.mkdir(exist_ok=True);patch=[]
for name in ('run_component_pb.py','dispatch_component_pb.py','component_pb.pbs','observe_pbp.py','REFERENCE_PROOF.json'):
    old=old_stage['execution/'+name].decode();new=old
    if name in ('run_component_pb.py','dispatch_component_pb.py','component_pb.pbs'):
        new=new.replace('clm-drainage-adapter-pb-p-b',LABEL).replace('drainage-adapter-pbp-b','drainage-warm-phase-pbr')
        new=new.replace('dispatch_drainage_adapter_pbp_b.py','dispatch_drainage_warm_phase_pbr.py')
    if name=='run_component_pb.py':
        new=new.replace("for folder in ('preparation', 'execution', 'reference'):","for folder in ('preparation', 'execution', 'reference', 'candidate'):")
        new=new.replace("        reference = json.loads((root/'reference/REFERENCE_BINDINGS.json').read_bytes())", "        candidate = json.loads((root/'candidate/BINDINGS.json').read_bytes())\n        assert candidate['parent_archive_sha256'] == binding['source_archive_sha256']\n        assert candidate['parent_manifest_sha256'] == binding['source_manifest_sha256']\n        parent_raw = (STAGE/'parent-source-manifest.json').read_bytes()\n        assert sha(parent_raw) == candidate['parent_manifest_sha256']\n        parent_index = json.loads(parent_raw)\n        reference = json.loads((root/'reference/REFERENCE_BINDINGS.json').read_bytes())")
        new=new.replace("assert sha((STAGE/'source.tar.gz').read_bytes()) == binding['source_archive_sha256']", "assert sha((STAGE/'source.tar.gz').read_bytes()) == candidate['source_archive_sha256']")
        new=new.replace("assert sha(source_raw) == binding['source_manifest_sha256']", "assert sha(source_raw) == candidate['source_manifest_sha256']\n        assert set(index) == set(parent_index) and len(parent_index) == 596\n        changed = [n for n in parent_index if parent_index[n] != index[n]]\n        assert changed == candidate['changed_source_files'] == ['src/noahmp_clm/gpu/clm_drainage_adaptive.py']\n        assert sum(index[n] == h for n, h in parent_index.items()) == 595\n        receipt.update(candidate_source_archive_sha256=candidate['source_archive_sha256'],\n            candidate_source_manifest_sha256=candidate['source_manifest_sha256'],\n            parent_source_archive_sha256=binding['source_archive_sha256'], unchanged_parent_files=595)")
        new=new.replace("scope='CPU-only new diagnosis/post-Richards adapter versus original independent physics; explicit32/64, original20gold diagnosis/trial.", "scope='PB-r one-file NumPy64 warm-liquid representation fix; exact original1695 CPU tests/observer/reference, explicit32/64 and20gold diagnosis/trial.")
    if name=='dispatch_component_pb.py':
        new=new.replace('PB-p isolated CPU diagnosis/adapter versus original physics and20gold diagnosis/trial, source596. Expected24nodes await actual collect. NoGPU/full-column/site/annual execution.',
            'PB-r single-file NumPy64 warm-phase fix versus exact1695 original24 tests and20gold647 diagnosis/trial; new596 source identity,595parent exact. NoGPU/full-column/site/annual execution.')
    (EXEC/name).write_text(new,encoding='utf-8',newline='\n')
    if old!=new:patch.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='actual1695/execution/'+name,tofile='candidatePB-r/execution/'+name))
assert (EXEC/'observe_pbp.py').read_bytes()==old_stage['execution/observe_pbp.py']
assert (EXEC/'REFERENCE_PROOF.json').read_bytes()==old_stage['execution/REFERENCE_PROOF.json']
(EXEC/'wrapper.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
(EXEC/'README.md').write_text('''# PB-r authorized single CPU validation

Exact original1695 preparation19/test/fixture/oracle/observer/gold/reference byte preservation. Worker numerical collect/pytest/timeout/parser/assertions are unchanged; only private paths and transparent candidate-source metadata verification are adapted. New596 source contains one NumPy64 warm-liquid representation fix,595 old files exact. Original PB-p-b and1695/1702 failures remain unchanged.

One compute0021CPU/2GiB/10min job. Actual collect must still report24 nodes before execution; expected count is not a pass. Original20gold diagnosis/trials must retain all647 actual fields, without rerunning17fullgold integrations. All completed32/64 profile outputs, both outlets, layer stocks/T/diagnoses and original hard64eps accounts remain. No GPU/JAX/production or native full-column credit. No automatic retry.

Source597/preparation20/execution8/reference5/candidate8 plus originalsealedgold345/official58 are immutable runtime files; original586 is a subset of source, not additional. Top-level parent-source manifest is separately bound by original source identity and immutable stage inventory. Historical official reference remains provenance only, no rerun or new official truth. RealF/Exit/Stageout and all failures must be retained before publication.
''',encoding='utf-8',newline='\n')
for p in EXEC.glob('*.py'):ast.parse(p.read_bytes())
exec_index={p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'}
assert len(exec_index)==7
(EXEC/'CONTROLS_SHA256.json').write_bytes(encode(exec_index))
data={n:b for n,b in old_stage.items() if n!='stage-inventory.json' and not n.startswith('execution/')}
data['source.tar.gz']=(OUT/binding['source_archive']).read_bytes()
data['parent-source-manifest.json']=parent['SOURCE_SHA256.json']
for folder,label in ((EXEC,'execution'),(PREP,'candidate')):
    data.update({label+'/'+p.relative_to(folder).as_posix():p.read_bytes() for p in sorted(folder.rglob('*')) if p.is_file()})
assert all(data[n]==b for n,b in old_stage.items() if n.startswith(('preparation/','reference/')))
data['stage-inventory.json']=encode({n:sha(b) for n,b in data.items()})
target=OUT/(LABEL+'-stage.tar.gz');assert not target.exists()
with target.open('wb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
    for n,b in sorted(data.items()):
        m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==data
report=dict(actual_stdlib_exit=0,stage_sha256=sha(target.read_bytes()),stage_members=len(data),
    candidate_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),candidate_controls=7,
    execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()),execution_controls=7,
    original_preparation_manifest_sha256=sha(data['preparation/CONTROLS_SHA256.json']),original19_controls_exact=True,
    original_test_and_observer_exact=True,original_reference_and_gold_exact=True,source_files=596,unchanged_parent_files=595,
    source_archive_sha256=binding['source_archive_sha256'],source_manifest_sha256=binding['source_manifest_sha256'],
    expected_nodes=24,expected_gold_fields=647,actual_nodes=None,numerical_executed=False,PBS_submitted=False)
(OUT/(LABEL+'-stage-preparation.json')).write_bytes(encode(report));print(json.dumps(report),flush=True)

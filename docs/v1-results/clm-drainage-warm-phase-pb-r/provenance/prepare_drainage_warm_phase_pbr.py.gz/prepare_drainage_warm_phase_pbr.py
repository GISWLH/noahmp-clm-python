"""Prepare one private NumPy64 warm-phase representation fix; stdlib only."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

OUT = Path(__file__).resolve().parent
LABEL = 'clm-drainage-warm-phase-pb-r'
PREP = OUT/(LABEL+'-preparation')
PARENT = OUT/'clm-drainage-adapter-pb-p-b-source.tar.gz'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, allow_nan=False)+'\n').encode()
assert sha(PARENT.read_bytes()) == 'ef4a7ddc1d1b4387d44e23fdf0e5449f3eb02627bbd2646c6f38859633c7ac8b'
with tarfile.open(PARENT) as t:
    members=t.getmembers(); assert all(m.isfile() for m in members)
    raw={m.name:t.extractfile(m).read() for m in members}
parent_index=json.loads(raw['SOURCE_SHA256.json'])
parent_manifest_sha256=sha(raw['SOURCE_SHA256.json'])
assert len(parent_index)==596 and len(raw)==597 and all(sha(raw[n])==h for n,h in parent_index.items())
name='src/noahmp_clm/gpu/clm_drainage_adaptive.py'
old=raw[name].decode()
needle='        liquid=soil.liquid;temperature=soil.temperature\n'
assert old.count(needle)==1
replacement=(needle+'        from ..physics.snowpack import TF\n'
    +'        liquid=xp.where(temperature>=TF,c[:,4],liquid)\n')
new=old.replace(needle,replacement)
assert new.replace(replacement,needle)==old
ast.parse(new)
raw[name]=new.encode()
candidate_index={n:sha(b) for n,b in raw.items() if n!='SOURCE_SHA256.json'}
assert [n for n in parent_index if parent_index[n]!=candidate_index[n]]==[name]
raw['SOURCE_SHA256.json']=encode(candidate_index)
q_package=json.loads((OUT/'clm-drainage-nonuniform-pb-q-package.json').read_bytes())
assert q_package['sha256']=='b4f212108bb0c1114f303b3f9c576125af28fc90894abb82ff00dc11c676f471'
with tarfile.open(OUT/q_package['archive']) as t:
    q={m.name:t.extractfile(m).read() for m in t}
assert sha((OUT/q_package['archive']).read_bytes())==q_package['sha256']
closed=json.loads(q['closed-run.json']); assert closed['actual_job_state']=='F' and closed['actual_exit']==1 and closed['Stageout_status']==0
analysis=json.loads(q['actual/independent-predicate-analysis.json'])
assert analysis['failing_predicates']==['ice_negative'] and analysis['phase']['all_warm']
assert analysis['phase']['liquid_equals_roundtrip_exact'] and analysis['phase']['liquid_minus_water_in_ulp']==[[0.,1.,0.,0.]]
source=OUT/(LABEL+'-source.tar.gz'); assert not source.exists()
with source.open('wb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
    for n,b in sorted(raw.items()):
        m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(source) as t: assert {m.name:t.extractfile(m).read() for m in t}==raw
PREP.mkdir(exist_ok=True)
for directory,content in (('original-files',old),('new-files',new)):
    p=PREP/directory/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content,encoding='utf-8',newline='\n')
(PREP/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='originalPB-p-b/'+name,tofile='candidatePB-r/'+name)),encoding='utf-8',newline='\n')
proof=dict(actual_stdlib_exit=0, source_files=596, source_members_including_manifest=597,
    changed_source_files=[name], unchanged_parent_files=595, exact_reverse_text_replacement=True,
    original_phase_functions_outside_NumPy64_branch_unchanged=True, original_frozen_liquid_expression_unchanged=True,
    original_stock_W_H_unchanged=True, original_ice_expression_unchanged=True,
    original_guard_budget_oracle_tests_fixture_gold_unchanged=True,
    original64eps_and_scientific_thresholds_unchanged=True,
    changed_file_old_sha256=parent_index[name], changed_file_new_sha256=candidate_index[name],
    numerical_executed=False, PBS_submitted=False, GPU_executed=False)
(PREP/'DIFF_PROOF.json').write_bytes(encode(proof))
binding=dict(prepared_only=True, source_archive=source.name, source_archive_sha256=sha(source.read_bytes()),
    source_manifest_sha256=sha(raw['SOURCE_SHA256.json']), source_files=596,
    parent_archive=PARENT.name, parent_archive_sha256=sha(PARENT.read_bytes()),
    parent_manifest_sha256=parent_manifest_sha256, changed_source_files=[name],
    actual_causal_evidence_archive=q_package['archive'], actual_causal_evidence_sha256=q_package['sha256'],
    original_failed_job='1695.manager', causal_capture_job='1702.manager', causal_capture_exit=1,
    original24_test_control_sha256=sha((OUT/'clm-drainage-adapter-pb-p-b-preparation/test_adapter_pbp.py').read_bytes()),
    original20_gold_archive_sha256='6ccfddeff32993f82819c9425774d6b3da7cfbc1e0e17ea14acf24aaa272db51',
    plan='One future run of exact original24 tests including20originalgold647 diagnosis/trial byte comparisons; no new scientific gate, cold-phase change or device/column run.',
    numerical_executed=False,PBS_submitted=False)
(PREP/'BINDINGS.json').write_bytes(encode(binding))
(PREP/'CANDIDATE_SOURCE_SHA256.json').write_bytes(raw['SOURCE_SHA256.json'])
(PREP/'README.md').write_text('''# PB-r private warm-phase candidate, prepared only

Only `gpu/clm_drainage_adaptive.py` changes in the original PB-p-b596 source. NumPy64 `_phase` still computes original `soil.liquid` and original temperature, then uses exact extensive W as liquid wherever temperature>=the original snowpack TF (273.15K). Below TF the original soil.liquid value remains unchanged: no new clip or frozen-phase algorithm. Ice remains W-liquid; extensive W/H, original inversion, guards and64eps water/heat budgets do not change. This matches the already existing32/device warm-state mass representation.

The causal input is actual PB-q1702 F1/Stageout0, repeating only original1695 nonuniform_dz-float64. At290K, second-layer W164.92674916302653kg/m2 and liquid164.92674916302656kg/m2 differ by exactly1ULP; derived ice is−2.842170943040401e−14kg/m2. Original volume/mass roundtrip reproduces liquid exactly; only ice_negative triggers, all other original predicates false. This is an invalid derived phase representation, not a relaxed acceptance threshold. Original1695 and1702 failures remain unchanged evidence.

Future CPU validation, pending root review, reuses the exact original24 tests, reference physics, fixtures, observer and20sealed-gold diagnosis/trials (647 fields in actual1695). It must collect the actual nodes, preserve all failures, compare same encoded32/64 input against the independent original NumPy physics, retain all layer/state/outlet/diagnosis and original hard budgets, and record source/control before-after identity. No additional profile, numerical tolerance,64eps or guard change; no GPU, complete native column, production or annual claim. Source596 remains a new candidate identity, not the old NM/PB-p-b identity. No PBS has been submitted for PB-r.
''',encoding='utf-8',newline='\n')
index={p.relative_to(PREP).as_posix():sha(p.read_bytes()) for p in sorted(PREP.rglob('*')) if p.is_file() and p.name!='CONTROLS_SHA256.json'}
assert len(index)==7
(PREP/'CONTROLS_SHA256.json').write_bytes(encode(index))
report=dict(**proof, source_archive_sha256=binding['source_archive_sha256'],source_manifest_sha256=binding['source_manifest_sha256'],
    preparation_controls=len(index),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()))
(OUT/(LABEL+'-static.json')).write_bytes(encode(report));print(json.dumps(report),flush=True)

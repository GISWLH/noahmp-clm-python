"""Explicit NumPy32 evaluation of the frozen NM device phase equations.

Generated from the three original pure functions by import replacement and
float-literal typing only. The local lax adapter executes the same bounded
loops; every barrier and carry rejects an intermediate floating dtype change.
This is NumPy CPU validation, not execution or acceptance of JAX/CUDA.
"""
import numpy as np
F=np.float32
PHASE_AUDIT={'barrier_calls':0,'floating_values_checked':0}

def _check(value):
    if isinstance(value,(tuple,list)):
        for item in value:_check(item)
    elif hasattr(value,'dtype') and value.dtype.kind=='f':
        PHASE_AUDIT['floating_values_checked']+=1
        if value.dtype!=np.float32:
            raise RuntimeError('Phase arithmetic changed explicit float32 dtype')
    return value

class _Lax:
    @staticmethod
    def optimization_barrier(value):
        PHASE_AUDIT['barrier_calls']+=1
        return _check(value)
    @staticmethod
    def fori_loop(start,end,body,carry):
        _check(carry)
        for index in range(start,end):carry=_check(body(index,carry))
        return carry
    @staticmethod
    def while_loop(condition,body,carry):
        _check(carry);iterations=0
        while bool(condition(carry)):
            carry=_check(body(carry));iterations+=1
            if iterations>64:raise RuntimeError('Original phase iteration bound exceeded')
        return carry
lax=_Lax()

def soil_thermodynamics_jax(water, offset, dz, porosity, bexp, saturated_suction_m, option):
    """Pure device expression returning H, dH/dT and liquid mass."""
    import numpy as j
    stop = lax.optimization_barrier

    def cap(total, potential):
        width = j.maximum(stop(F(0.04) * total), F(1e-12))
        dw = j.where(F(0.04) * total > F(1e-12), F(1.0), F(0.0)) * F(0.04)
        diff = stop(total - potential)
        sign = j.sign(diff)
        rounded = j.maximum(stop(width - j.abs(diff)), F(0.0))
        value = stop(j.minimum(total, potential) - stop(rounded * rounded) / stop(F(4.0) * width))
        dtotal = stop(j.where(diff < F(0.0), F(1.0), j.where(diff > F(0.0), F(0.0), F(0.5))) - stop(rounded * stop(dw - sign)) / stop(F(2.0) * width))
        dtotal = stop(dtotal + stop(stop(rounded * rounded) * dw) / stop(stop(F(4.0) * width) * width))
        dpotential = stop(j.where(diff > F(0.0), F(1.0), j.where(diff < F(0.0), F(0.0), F(0.5))) - stop(rounded * sign) / stop(F(2.0) * width))
        return (j.maximum(value, F(0.0)), j.where(value > F(0.0), dtotal, F(0.0)), j.where(value > F(0.0), dpotential, F(0.0)))
    theta = water / stop(F(1000.0) * dz)
    temperature = stop(F(273.15) + offset)
    coefficient = stop(F(334000.0) / stop(F(9.80616) * saturated_suction_m))
    raw = stop(stop(coefficient * j.maximum(-offset, F(0.0))) / temperature)
    ratio = j.maximum(raw, F(1e-12))
    potential = j.exp(j.minimum(stop(j.log(porosity) - stop(j.log(ratio) / bexp)), j.log(stop(F(2.0) * porosity))))
    denominator = stop(stop(stop(bexp * temperature) * temperature) * ratio)
    dp = j.where(raw > F(1e-12), stop(stop(stop(potential * coefficient) * F(273.15)) / denominator), F(0.0))
    liquid, _, dpotential = cap(theta, potential)
    derivative = stop(dpotential * dp)

    def adjust(_, carry):
        liq, deriv = carry
        limited, ds, dp_ = cap(liq, potential)
        slope = stop(stop(ds * deriv) + stop(dp_ * dp))
        slope = j.where(limited < theta, slope, F(0.0))
        return (stop(F(0.5) * stop(liq + j.minimum(theta, limited))), stop(F(0.5) * stop(deriv + slope)))
    corrected = lax.fori_loop(0, 3, adjust, (liquid, derivative))
    liquid = j.where(option == 2, corrected[0], liquid)
    derivative = j.where(option == 2, corrected[1], derivative)
    liquid = j.where(offset >= F(0.0), water, j.clip(stop(liquid * stop(F(1000.0) * dz)), F(0.0), water))
    derivative = stop(j.where(offset >= F(0.0), F(0.0), derivative) * stop(F(1000.0) * dz))
    dry = stop(stop(stop(F(1.0) - porosity) * F(2000000.0)) * dz)
    sensible = stop(stop(dry + stop(F(2100.0) * water)) + stop(F(2080.0) * liquid))
    enthalpy = stop(stop(sensible * offset) + stop(F(334000.0) * liquid))
    capacity = stop(sensible + stop(stop(stop(F(2080.0) * offset) + F(334000.0)) * derivative))
    return (enthalpy, capacity, liquid)

def invert_soil_enthalpy_jax(water, enthalpy, dz, porosity, bexp, saturated_suction_m, option):
    """Safeguarded H inversion; returns offset, H/C/liquid, status and count."""
    import numpy as j
    stop = lax.optimization_barrier
    low = j.full_like(water, -F(123.15))
    high = j.full_like(water, F(126.85))
    hlo = soil_thermodynamics_jax(water, low, dz, porosity, bexp, saturated_suction_m, option)[0]
    hhi = soil_thermodynamics_jax(water, high, dz, porosity, bexp, saturated_suction_m, option)[0]
    valid = (enthalpy >= hlo) & (enthalpy <= hhi)
    dry = stop(stop(stop(F(1.0) - porosity) * F(2000000.0)) * dz)
    t = j.clip(stop(enthalpy - stop(F(334000.0) * water)) / stop(dry + stop(F(4180.0) * water)), low, high)

    def tolerance(t, h, c, liquid):
        scale = j.maximum(j.maximum(j.abs(enthalpy), j.abs(stop(F(334000.0) * liquid))), F(1.0))
        return j.maximum(j.asarray(F(2e-08), water.dtype), stop(F(8.0) * j.finfo(water.dtype).eps * scale))

    def advance(_, carry):
        t, low, high, done, count = carry
        h, c, liq = soil_thermodynamics_jax(water, t, dz, porosity, bexp, saturated_suction_m, option)
        error = stop(h - enthalpy)
        finished = j.abs(error) <= tolerance(t, h, c, liq)
        count = count + j.where(~done, F(1.0), F(0.0))
        done = done | finished
        low = j.where(error < F(0.0), t, low)
        high = j.where(error > F(0.0), t, high)
        trial = stop(t - error / c)
        trial = j.where((trial > low) & (trial < high), trial, stop(F(0.5) * stop(low + high)))
        return (j.where(done, t, trial), low, high, done, count)
    initial = (t, low, high, j.zeros_like(water, dtype=bool), j.zeros_like(water))
    _, solved = lax.while_loop(lambda x: (x[0] < 64) & j.any(~x[1][3]), lambda x: (x[0] + 1, advance(x[0], x[1])), (j.asarray(0), initial))
    t, _, _, _, count = solved
    h, c, liq = soil_thermodynamics_jax(water, t, dz, porosity, bexp, saturated_suction_m, option)
    converged = valid & (j.abs(h - enthalpy) <= tolerance(t, h, c, liq))
    return (t, h, c, liq, converged, count)

def soil_thermodynamics_kernel_jax(inputs, option, *, inverse):
    import numpy as j
    w, q, z, por, b, psi = inputs
    if inverse:
        t, h, c, liq, ok, count = invert_soil_enthalpy_jax(w, q, z, por, b, psi, option)
        residual = h - q
    else:
        t = q
        h, c, liq = soil_thermodynamics_jax(w, t, z, por, b, psi, option)
        ok = j.asarray(True)
        count = j.zeros_like(w)
        residual = j.zeros_like(w)
    return j.stack((t, t + F(273.15), liq, w - liq, h, c, residual, count, ok.astype(w.dtype)))

OUTPUTS=('temperature_offset_k','temperature_k','liquid_kgm2','ice_kgm2',
    'enthalpy_jm2','capacity_jm2k','reconstruction_residual_jm2','iterations','converged')

def run_numpy32(inputs,options,*,inverse=False):
    from noahmp_clm.gpu.enthalpy import validate_soil_thermodynamics
    u=np.asarray(inputs);o=np.asarray(options)
    if u.dtype!=np.float32:raise ValueError('Explicit float32 phase input required')
    validate_soil_thermodynamics(u,o,inverse,np)
    if inverse:
        result=soil_thermodynamics_kernel_jax(u.T,o,inverse=True)
    else:
        w,t,z,por,b,psi=u.T
        h,c,liq=soil_thermodynamics_jax(w,t,z,por,b,psi,o)
        result=np.stack((t,t+F(273.15),liq,w-liq,h,c,np.zeros_like(w),
                         np.zeros_like(w),np.ones_like(w)))
    _check(result)
    if not np.all(np.isfinite(result)) or not np.all(result[-1]>0):
        raise ValueError('Original phase domain or convergence failed')
    return dict(zip(OUTPUTS,result))

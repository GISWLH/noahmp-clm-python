"""Metadata-only preflight for the new isolated CLM drainage entry points.

No array conversion, backend dispatch, phase calculation or device work occurs
here. Caller-requested pack(dtype=...) remains the explicit encoding boundary.
This does not validate values or replace the original physical validators.
"""
import math


def _float_array(value, name):
    dtype = getattr(value, 'dtype', None)
    shape = getattr(value, 'shape', None)
    if (dtype is None or shape is None or getattr(dtype, 'kind', None) != 'f'
            or getattr(dtype, 'itemsize', None) not in (4, 8)
            or not getattr(dtype, 'isnative', False)):
        raise ValueError(name + ': explicit native-endian float32/float64 array required; encode before the raw API')
    return dtype.itemsize, tuple(shape)


def _group(named, backend):
    if backend not in ('numpy', 'jax', 'cuda'):
        raise ValueError('Choose numpy, jax or cuda explicitly')
    information = {name: _float_array(value, name) for name, value in named}
    sizes = {item[0] for item in information.values()}
    if len(sizes) != 1:
        raise ValueError('Raw CLM drainage arrays must have the same explicit floating dtype')
    size = next(iter(sizes))
    if backend == 'cuda' and size != 4:
        raise ValueError('Raw CLM drainage CUDA requires float32; explicit pack(dtype=float32) is the encoding boundary')
    return size, information


def require_trial_inputs(cells, parameters, interval, backend):
    size, information = _group((('cells', cells), ('parameters', parameters), ('interval', interval)), backend)
    shape = information['cells'][1]
    if (len(shape) != 3 or shape[0] < 1 or shape[1:] != (4, 6)
            or information['parameters'][1] != (shape[0], 12)
            or information['interval'][1] != (shape[0], 3)):
        raise ValueError('Raw drainage trial shapes must be [B,4,6], [B,12], [B,3]')
    return size


def require_adaptive_inputs(cells, parameters, phase_option, duration, front, bottom, backend):
    size, information = _group((('cells', cells), ('parameters', parameters)), backend)
    if information['cells'][1] != (4, 6) or information['parameters'][1] != (12,):
        raise ValueError('Raw adaptive drainage shapes must be [4,6] and [12]')
    if type(phase_option) is not int or phase_option not in (1, 2):
        raise ValueError('Original integer phase option 1 or 2 required')
    # Python scalars are explicit control values, encoded by the existing API.
    # Already typed scalars must agree, rather than silently entering another dtype.
    for name, value in (('duration', duration), ('front', front), ('bottom', bottom)):
        if type(value) not in (int, float):
            scalar_size, shape = _float_array(value, name)
            if shape != () or scalar_size != size:
                raise ValueError(name + ': typed scalar must match the raw array precision')
        if not math.isfinite(value):
            raise ValueError(name + ': finite scalar required')
    if duration <= 0 or front < 0 or bottom < front:
        raise ValueError('Positive duration and ordered nonnegative front/bottom required')
    return size


def require_jax_precision(itemsize):
    # This is called only after all raw metadata validation, before j.asarray.
    # A JAX configuration read is not array conversion or a physics/kernel call.
    if itemsize == 8:
        import jax
        if not jax.config.jax_enable_x64:
            raise ValueError('Explicit float64 drainage inputs require JAX x64 enabled before conversion')

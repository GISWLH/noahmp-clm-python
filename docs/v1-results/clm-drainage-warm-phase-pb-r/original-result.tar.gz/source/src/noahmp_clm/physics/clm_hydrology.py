"""Explicit NumPy soil-column transport plus actual subsurface outlets.

No independent aquifer store or inter-column exchange is introduced. The
transport lower boundary and drainage bedrock coincide with the soil bottom.
This separate configuration does not inherit or extend Richards controls.
"""
from dataclasses import dataclass,field
import numpy as np
from .richards import RichardsHydrology,redistribute_soil_enthalpy
from .clm_saturated_drainage import (DrainageParameters,IntegrationControls,
    diagnose_water_tables,drain_saturated_soil)
from .soil_enthalpy import SoilEnthalpyState


@dataclass(frozen=True)
class CLMVerticalHydrology:
    drainage: DrainageParameters
    transport: RichardsHydrology=field(default_factory=RichardsHydrology)
    integration: IntegrationControls=field(default_factory=IntegrationControls)

    def __post_init__(self):
        if (not isinstance(self.drainage,DrainageParameters)
                or not isinstance(self.transport,RichardsHydrology)
                or not isinstance(self.integration,IntegrationControls)):
            raise TypeError('CLMVerticalHydrology requires separate drainage, transport and integration controls')

    def validate_ground(self,ground):
        if not isinstance(ground,SoilEnthalpyState):
            raise TypeError('CLMVerticalHydrology requires extensive SoilEnthalpyState')
        depth=float(ground.dz.sum())
        if abs(self.drainage.bedrock_depth_m-depth)>16*np.finfo(float).eps*max(depth,1.):
            raise ValueError('CLM transport zero-flux bottom and drainage bedrock must equal the full soil-column depth')
        # Validates the original arbitrary-layer geometry/material domain.
        diagnose_water_tables(ground,self.drainage)


def advance_clm_hydrology(ground,dt_seconds,configuration):
    """Return the actual transported/drained state and separate M/H ledgers.

    Frozen coefficients are never borrowed from another state. Drainage sees
    actual post-Richards phase; main drainage rediagnoses after perched flow.
    Neither this operator nor its component creates bottom-boundary flux.
    """
    if not isinstance(configuration,CLMVerticalHydrology):raise TypeError('Expected CLMVerticalHydrology')
    configuration.validate_ground(ground)
    transported,transport=redistribute_soil_enthalpy(ground,dt_seconds,**configuration.transport.controls())
    transport.update(method='richards_zero_flux',lower_boundary_condition=2,
        water_before_kg_m2=ground.water.copy(),enthalpy_before_j_m2=ground.enthalpy.copy())
    final,outlets=drain_saturated_soil(transported,dt_seconds,configuration.drainage,configuration.integration)
    zero=np.zeros_like(ground.water)
    named={kind:next((b for b in outlets['bands'] if b['kind']==kind),None) for kind in ('saturated','perched')}
    mass={k:(zero.copy() if b is None else b['layer_mass_kg_m2']) for k,b in named.items()}
    heat={k:(zero.copy() if b is None else b['layer_enthalpy_j_m2']) for k,b in named.items()}
    # A single independent combined extensive budget, with the existing
    # drainage operation-count bound. Component bounds are also retained.
    rm=float(final.water.sum()-ground.water.sum())+outlets['drained_kg_m2']
    rh=float(final.enthalpy.sum()-ground.enthalpy.sum())+outlets['drained_enthalpy_j_m2']
    eps=np.finfo(float).eps
    mb=64*eps*max(float(abs(final.water).sum()+abs(ground.water).sum())+abs(outlets['drained_kg_m2']),1.)
    hb=64*eps*max(float(abs(final.enthalpy).sum()+abs(ground.enthalpy).sum())+abs(outlets['drained_enthalpy_j_m2']),1.)
    if abs(rm)>mb or abs(rh)>hb:raise RuntimeError('CLM transport/drainage combined hard M/H budget failed')
    ledger=dict(outlets,operator_order=('richards_zero_flux','perched','saturated'),
        water_before_transport_kg_m2=ground.water.copy(),enthalpy_before_transport_j_m2=ground.enthalpy.copy(),
        water_after_transport_kg_m2=transported.water.copy(),enthalpy_after_transport_j_m2=transported.enthalpy.copy(),
        saturated_layer_mass_kg_m2=mass['saturated'],perched_layer_mass_kg_m2=mass['perched'],
        saturated_layer_enthalpy_j_m2=heat['saturated'],perched_layer_enthalpy_j_m2=heat['perched'],
        saturated_mass_kg_m2=float(mass['saturated'].sum()),perched_mass_kg_m2=float(mass['perched'].sum()),
        saturated_enthalpy_j_m2=float(heat['saturated'].sum()),perched_enthalpy_j_m2=float(heat['perched'].sum()),
        combined_water_residual_kg_m2=rm,combined_energy_residual_j_m2=rh,
        combined_water_bound_kg_m2=mb,combined_energy_bound_j_m2=hb,
        zero_flux_bottom_mass_kg_m2=0.,zero_flux_bottom_enthalpy_j_m2=0.,
        candidate_column_connected=True,production_integrated=False)
    return final,transport,ledger

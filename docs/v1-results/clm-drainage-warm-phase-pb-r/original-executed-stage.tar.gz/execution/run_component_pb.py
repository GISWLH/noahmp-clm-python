"""Prepared CPU wrapper: exact sources, actual collect, original-reference tests."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

STAGE = Path('/tmp/noahmp-clm-drainage-warm-phase-pb-r')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def unpack(path, target):
    target.mkdir()
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        for item in members:
            destination = target/item.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(archive.extractfile(item).read())
    return {p.relative_to(target).as_posix(): sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}


def main():
    assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    root = Path(sys.argv[1]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    started = time.monotonic(); immutable = {}; stage_index = {}
    receipt = dict(passed=False, pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
        python=sys.version, python_executable=sys.executable, numerical_parent_returncode=None,
        collect_parent_returncode=None, coupled_column_runs=0, official_caller_runs=0,
        expected_test_nodes=24, expected_is_not_actual=True, actual_calls=None)
    try:
        stage_index = json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/n).read_bytes()) == h for n, h in stage_index.items())
        for folder in ('preparation', 'execution', 'reference', 'candidate'):
            shutil.copytree(STAGE/folder, root/folder)
            index = json.loads((root/folder/'CONTROLS_SHA256.json').read_bytes())
            actual = {p.relative_to(root/folder).as_posix() for p in (root/folder).rglob('*') if p.is_file()}
            assert actual == set(index)|{'CONTROLS_SHA256.json'}
            assert all(sha((root/folder/n).read_bytes()) == h for n, h in index.items())
            immutable.update({folder+'/'+n: h for n, h in index.items()})
            immutable[folder+'/CONTROLS_SHA256.json'] = sha((root/folder/'CONTROLS_SHA256.json').read_bytes())
        binding = json.loads((root/'preparation/BINDINGS.json').read_bytes())
        candidate = json.loads((root/'candidate/BINDINGS.json').read_bytes())
        assert candidate['parent_archive_sha256'] == binding['source_archive_sha256']
        assert candidate['parent_manifest_sha256'] == binding['source_manifest_sha256']
        parent_raw = (STAGE/'parent-source-manifest.json').read_bytes()
        assert sha(parent_raw) == candidate['parent_manifest_sha256']
        parent_index = json.loads(parent_raw)
        reference = json.loads((root/'reference/REFERENCE_BINDINGS.json').read_bytes())
        gold = json.loads((root/'preparation/GOLD32_BINDINGS.json').read_bytes())
        assert sha((STAGE/'source.tar.gz').read_bytes()) == candidate['source_archive_sha256']
        source = unpack(STAGE/'source.tar.gz', root/'source')
        source_raw = (root/'source/SOURCE_SHA256.json').read_bytes(); index = json.loads(source_raw)
        assert len(index) == 596 and len(source) == 597
        assert sha(source_raw) == candidate['source_manifest_sha256']
        assert set(index) == set(parent_index) and len(parent_index) == 596
        changed = [n for n in parent_index if parent_index[n] != index[n]]
        assert changed == candidate['changed_source_files'] == ['src/noahmp_clm/gpu/clm_drainage_adaptive.py']
        assert sum(index[n] == h for n, h in parent_index.items()) == 595
        receipt.update(candidate_source_archive_sha256=candidate['source_archive_sha256'],
            candidate_source_manifest_sha256=candidate['source_manifest_sha256'],
            parent_source_archive_sha256=binding['source_archive_sha256'], unchanged_parent_files=595)
        assert {k: v for k, v in source.items() if k != 'SOURCE_SHA256.json'} == index
        assert all(index[k] == h for k, h in binding['source_reference_exact'].items())
        base = json.loads((root/'reference/BASE_PBL_SOURCE_SHA256.json').read_bytes())
        assert len(base) == 586 and all(index[k] == h for k, h in base.items())
        immutable.update({'source/'+k: v for k, v in source.items()})
        for archive_name, folder, digest, count in (
            ('gold.tar.gz', 'sealed-gold', gold['archive_sha256'], 345),
            ('official-reference.tar.gz', 'sealed-official-reference', reference['official_archive_sha256'], 58)):
            assert sha((STAGE/archive_name).read_bytes()) == digest
            members = unpack(STAGE/archive_name, root/folder)
            assert len(members) == count
            original_inventory = json.loads((root/folder/'artifact-inventory.json').read_bytes())
            assert set(original_inventory) == set(members)-{'artifact-inventory.json'}
            if folder == 'sealed-gold':
                assert all(type(h) is str and members[n] == h for n, h in original_inventory.items())
            else:
                assert all(set(h) == {'sha256', 'bytes'} and members[n] == h['sha256']
                    and (root/folder/n).stat().st_size == h['bytes'] for n, h in original_inventory.items())
            immutable.update({folder+'/'+n: h for n, h in members.items()})
        assert all(immutable['sealed-gold/'+n] == h for n, h in gold['members'].items())
        save(root/'immutable-before.json', immutable)
        env = os.environ.copy(); env.pop('PYTHONHOME', None)
        env.update(PYTHONPATH=str(root/'source/src')+':'+str(root/'execution')+':/home/zhangyq/noahmp-v1/test-deps',
            PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='', JAX_PLATFORMS='cpu',
            OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
            PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PBP_RUN_ROOT=str(root), PBP_RESULTS=str(root/'results'),
            PBP_GOLD_ARCHIVE=str(STAGE/'gold.tar.gz'))
        metadata = Path('/home/zhangyq/noahmp-v1/test-deps/numpy-2.2.6.dist-info/METADATA')
        save(root/'dependencies.json', dict(numpy_metadata_path=str(metadata), numpy_metadata_sha256=sha(metadata.read_bytes())))
        base_command = [sys.executable, '-B', '-m', 'pytest', '-q', '-s', '-p', 'no:cacheprovider', '-p', 'observe_pbp']
        test = str(root/'preparation/test_adapter_pbp.py')
        command = base_command+['--collect-only', test]
        save(root/'collect-command.json', command); env['PBP_OBSERVER_MODE'] = 'collect'
        collect_started = time.monotonic()
        with (root/'collect.stdout.txt').open('wb') as out, (root/'collect.stderr.txt').open('wb') as err:
            collected = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=60)
        receipt.update(collect_parent_returncode=collected.returncode, collect_seconds=time.monotonic()-collect_started)
        assert collected.returncode == 0
        nodes = json.loads((root/'collect-nodes.json').read_bytes())
        observation = json.loads((root/'collect-observation.json').read_bytes())
        assert nodes and len(set(nodes)) == len(nodes)
        assert all(c['attempted'] == c['returned'] == c['raised'] == 0 for c in observation['calls'].values())
        receipt.update(actual_collected_nodes=len(nodes), expected_node_count_matches=len(nodes) == 24)
        # A collection mismatch is a control/schema issue, never an assertion of
        # scientific failure or successful tests. Preserve actual collected IDs.
        assert len(nodes) == 24
        env['PBP_OBSERVER_MODE'] = 'run'
        command = base_command+['--junitxml='+str(root/'tests.xml'), test]
        save(root/'numerical-command.json', command)
        numerical_started = time.monotonic()
        with (root/'numerical.stdout.txt').open('wb') as out, (root/'numerical.stderr.txt').open('wb') as err:
            result = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=470)
        receipt.update(numerical_parent_returncode=result.returncode, numerical_seconds=time.monotonic()-numerical_started)
        cases = list(ET.parse(root/'tests.xml').getroot().iter('testcase'))
        run_nodes = json.loads((root/'run-nodes.json').read_bytes())
        observation = json.loads((root/'run-observation.json').read_bytes())
        stdout = (root/'numerical.stdout.txt').read_text()
        diagnostics = [json.loads(line.split('PB_P_DIAGNOSTIC ', 1)[1]) for line in stdout.splitlines() if 'PB_P_DIAGNOSTIC ' in line]
        gold_records = [json.loads(line.split('PB_P_GOLD ', 1)[1]) for line in stdout.splitlines() if 'PB_P_GOLD ' in line]
        save(root/'parsed-diagnostics.json', diagnostics)
        save(root/'parsed-gold-records.json', gold_records)
        receipt.update(actual_tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
            errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases),
            actual_calls=observation['calls'], cupy_imported=observation['cupy_imported'], jax_imported=observation['jax_imported'])
        receipt.update(diagnostic_records=len(diagnostics), gold_summary_records=gold_records)
        assert not observation['cupy_imported'] and not observation['jax_imported']
        assert nodes == run_nodes and len(cases) == len(nodes)
        assert result.returncode == 0 and receipt['failures'] == receipt['errors'] == receipt['skipped'] == 0
        assert len(diagnostics) == 17 and len(gold_records) == 1 and gold_records[0]['cases'] == 20
        receipt['passed'] = True
    except BaseException:
        receipt['error'] = traceback.format_exc()
        (root/'failure.txt').write_text(receipt['error'])
    finally:
        try:
            if immutable:
                after = {n: sha((root/n).read_bytes()) for n in immutable}
                save(root/'immutable-after.json', after)
                receipt['immutable_files_verified'] = len(immutable)
                receipt['source_controls_references_unchanged'] = after == immutable
                assert after == immutable
            if stage_index: assert all(sha((STAGE/n).read_bytes()) == h for n, h in stage_index.items())
        except BaseException:
            receipt['passed'] = False
            receipt['immutability_error'] = traceback.format_exc()
        if (root/'run-observation.json').exists():
            observation = json.loads((root/'run-observation.json').read_bytes())
            receipt['actual_calls'] = observation['calls']
        receipt.update(seconds=time.monotonic()-started,
            source_files=596, parent_PBl_files_unchanged=586, gold_members=345, historical_official_reference_members=58,
            scope='PB-r one-file NumPy64 warm-liquid representation fix; exact original1695 CPU tests/observer/reference, explicit32/64 and20gold diagnosis/trial. Historical official shared-thermal reference only retained, not rerun or requalified. No full column, device, annual or production acceptance.')
        save(root/'receipt.json', receipt)
        print(json.dumps(receipt), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__': raise SystemExit(main())

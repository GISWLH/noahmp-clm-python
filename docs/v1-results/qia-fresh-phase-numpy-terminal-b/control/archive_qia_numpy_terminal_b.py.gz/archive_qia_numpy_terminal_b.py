from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-fresh-phase-numpy-year-b'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = json.loads((r / 'receipt.json').read_text())
report = json.loads((r / 'trajectory/report.json').read_text())
assert (r / 'pbs-exit.txt').read_text().strip() == '1' and receipt['returncode'] == 1 and receipt['source_unchanged']
assert report['status'] == 'failed' and report['steps_completed'] == report['failed_index'] == 735 and report['steps_requested'] == 17520
assert sha(r / 'trajectory/report.json') == receipt['report_sha256']
assert sha(r / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
assert sha(r / 'trajectory' / report['model_npz']) == report['model_npz_sha256']
a = b / 'qia-fresh-phase-numpy-terminal-b-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():
            t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
    summary = dict(scope='Actual source510 EHPC PBS235 model/controller/PBS1 at735/17520 originalcold year. Own336 continuation and complete original state/ledgers/trace retained,original phase80/tol1e-7 unchanged;failure residual.00010874183W. Originalfailedyear immutable,not resumed or full/science accepted. No model source changes.',
                   model_and_pbs_returncode=1, steps_completed=735, steps_requested=17520, source_manifest_sha256=sha(r / 'SOURCE_SHA256.json'),
                   maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'], original_cumulative_bounds=report['cumulative_numerical_bounds_m_h_c_n'],
                   report_sha256=sha(r / 'trajectory/report.json'), checkpoint_sha256=report['checkpoint_sha256'])
    raw = (json.dumps(summary, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

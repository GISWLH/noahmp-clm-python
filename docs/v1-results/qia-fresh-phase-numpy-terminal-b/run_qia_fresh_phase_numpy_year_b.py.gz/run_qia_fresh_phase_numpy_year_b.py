from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-fresh-phase-numpy-year-b'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(a) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 510 and all(sha(s / n) == v for n, v in m.items())
assert (r / 'SOURCE_SHA256.json').read_bytes() == (s / 'SOURCE_SHA256.json').read_bytes()
continuation = json.loads((r / 'continuation.json').read_text())
assert continuation['initial_resume_steps'] == 336 and continuation['parent_pbs_returncode'] == 0
for name, digest in continuation['copied_generation_sha256'].items():
    assert sha(r / 'trajectory' / name) == digest
cpu = json.loads((b / 'fresh-phase-edge-cpu-b/cpu-full-receipt.json').read_text())
assert cpu['returncode'] == 0 and cpu['source_unchanged'] and cpu['counts'] == dict(tests=910, failures=0, errors=0, skipped=0)
assert json.loads((b / 'fresh-phase-edge-cpu-b/SOURCE_SHA256.json').read_text()) == m
inputs = b / 'qia-stem-inputs-a/inputs'
protocol = json.loads((inputs.parent / 'protocol.json').read_text())
assert all(sha(inputs / n) == v for n, v in protocol['inputs_sha256'].items())
env = os.environ.copy()
env.update(PYTHONPATH=':'.join(map(str, [b / 'test-deps', s, s / 'src', s / 'benchmarks'])),
           PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
env.pop('NOAHMP_REQUIRE_GPU', None)
cmd = [sys.executable, '-u', str(s / 'benchmarks/run_fluxnet_column.py'), '--input', str(inputs / 'CN-Qia.npz'),
       '--input-manifest', str(inputs / 'CN-Qia.json'), '--config', str(inputs / 'CN-Qia-stem-config.json'),
       '--output', str(r / 'trajectory'), '--resume']
start = time.monotonic()
launch = dict(scope=continuation['scope'], pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              source_archive_sha256=sha(a), source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'),
              continuation_sha256=sha(r / 'continuation.json'), command=cmd)
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
with (r / 'model.log').open('x') as log:
    code = subprocess.run(cmd, cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
p = r / 'trajectory/report.json'
d = json.loads(p.read_text())
unchanged = all(sha(s / n) == v for n, v in m.items())
receipt = dict(scope=launch['scope'], returncode=code, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
               source_unchanged=unchanged, seconds=time.monotonic() - start, status=d['status'],
               steps_completed=d['steps_completed'], steps_requested=d['steps_requested'], report_sha256=sha(p))
(r / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
assert code == 0 and unchanged and d['status'] == 'complete' and d['steps_completed'] == d['steps_requested'] == 17520

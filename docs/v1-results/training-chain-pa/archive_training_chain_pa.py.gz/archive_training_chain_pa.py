"""Read-only terminal archive of PA1603; no model/input changes or new jobs."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-training-chain-pa')
STAGE = Path('/tmp/noahmp-training-chain-pa-stage.tar.gz')
STAGE_SHA = '2ff48aa655dfab6d6ceaaa2087bd0887402db594d703f100824bfa6bdbd87e63'
JOB = '1603.manager'
LABEL = 'training-chain-pa'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def contents(raw):
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for m in archive.getmembers():
            if m.isdir():
                continue
            name = m.name.removeprefix('./')
            assert m.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts and name not in files
            files[name] = archive.extractfile(m).read()
    return files


def main():
    assert socket.gethostname() == 'manager'
    dispatch = json.loads((ROOT / 'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == JOB and dispatch['stage_archive_sha256'] == STAGE_SHA
    query = subprocess.run(['qstat', '-xf', JOB], capture_output=True)
    assert query.returncode == 0
    qstat = query.stdout.decode()
    assert qstat.splitlines()[0] == 'Job Id: ' + JOB and re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
    assert re.search(r'^\s*Stageout_status = 0\s*$', qstat, re.M)
    stage_raw = STAGE.read_bytes()
    assert sha(stage_raw) == STAGE_SHA
    stage = contents(stage_raw)
    index = json.loads(stage['stage-inventory.json'])
    assert set(index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[n]) == h == sha((ROOT / n).read_bytes()) for n, h in index.items())
    status = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'pbs-exit.txt')], capture_output=True)
    assert status.returncode == 0 and int(status.stdout.strip()) == code
    fetch = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'result.tar.gz')], capture_output=True)
    assert fetch.returncode == 0
    result = contents(fetch.stdout)
    receipt = json.loads(result['receipt.json'])
    assert int(result['worker-exit.txt'].strip()) == code
    assert receipt['pbs_job'] == JOB and receipt['node'] == 'compute002'
    assert receipt['forward_model_steps'] == receipt['states_constructed'] == receipt['GPU_tasks'] == 0
    assert receipt['production_launch_allowed'] is False and receipt['actual_spinup'] is False and receipt['actual_scoring'] is False
    if code == 0:
        assert receipt['passed'] and receipt['actual_test_count'] == 12
        assert receipt['original_load_batch_calls'] == 46 and receipt['columns_validated'] == 368
        for label in ('unittest', 'assembly', 'native-metadata'):
            assert receipt['commands'][label]['parent_returncode'] == int(result[label + '-parent-exit.txt']) == 0
            assert receipt['commands'][label]['timed_out'] is False
        assert 'Ran 12 tests' in result['unittest.stderr.txt'].decode() and '\nOK\n' in result['unittest.stderr.txt'].decode()
        assert receipt['source_before_after_584_exact'] and receipt['original_inputs_and_controls_unchanged']
        assert receipt['root_review_sha256'] == sha(stage['root-review.json']) == sha(result['root-review.json'])
        assert sha(result['native-metadata-report.json']) == receipt['native_metadata_report_sha256']
        for folder in ('preparation', 'execution'):
            manifest = json.loads(stage[folder + '/CONTROLS_SHA256.json'])
            assert receipt[folder + '_manifest_sha256'] == sha(stage[folder + '/CONTROLS_SHA256.json'])
            for name in [*manifest, 'CONTROLS_SHA256.json']:
                assert result[folder + '/' + name] == stage[folder + '/' + name]
        assembly = json.loads(result['assembly/ASSEMBLY_SHA256.json'])
        assert {n.removeprefix('assembly/') for n in result if n.startswith('assembly/')} == set(assembly) | {'ASSEMBLY_SHA256.json'}
        assert all(sha(result['assembly/' + n]) == v['sha256'] and len(result['assembly/' + n]) == v['bytes'] for n, v in assembly.items())
    artifacts = {'current/' + n: raw for n, raw in result.items()}
    artifacts.update({'original-stage-inventory.json': stage['stage-inventory.json'],
                      'original-stage-binding.json': (json.dumps(dict(archive=STAGE.name,
                          sha256=STAGE_SHA, bytes=len(stage_raw), members=len(stage)), indent=2) + '\n').encode(),
                      'original-result-binding.json': (json.dumps(dict(archive='result.tar.gz',
                          sha256=sha(fetch.stdout), bytes=len(fetch.stdout), files=len(result)), indent=2) + '\n').encode(),
                      'actual-pbs-qstat.txt': query.stdout, 'actual-pbs-qstat.stderr.txt': query.stderr,
                      'pbs-exit.txt': status.stdout, 'archive_training_chain_pa.py': Path(__file__).read_bytes()})
    for name in ('dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'qsub-actual-exit.json',
                 'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt'):
        artifacts['manager/' + name] = (ROOT / name).read_bytes()
    output = ROOT / 'pbs-output.log'
    artifacts['manager/pbs-output-presence.json'] = (json.dumps(dict(path=str(output), exists=output.exists(),
        note='Original controller and all child stdout/stderr retained.')) + '\n').encode()
    if output.exists():
        artifacts['manager/pbs-output.log'] = output.read_bytes()
    inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in artifacts.items()}
    artifacts['inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
    dest = ROOT / (LABEL + '-evidence.tar.gz')
    assert not dest.exists()
    with tarfile.open(dest, 'w:gz') as archive:
        for name, raw in sorted(artifacts.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(raw), 0o644
            archive.addfile(member, io.BytesIO(raw))
    assert contents(dest.read_bytes()) == artifacts
    package = dict(label=LABEL, archive=dest.name, sha256=sha(dest.read_bytes()), bytes=dest.stat().st_size,
                   artifacts=len(artifacts), artifact_sha256={n: sha(raw) for n, raw in artifacts.items()},
                   pbs_job=JOB, actual_pbs_state='F', actual_pbs_exit=code,
                   actual_worker_exit=int(result['worker-exit.txt']), passed=receipt['passed'],
                   actual_unittest_count=receipt.get('actual_test_count'), actual_test_seconds=receipt.get('actual_test_seconds'),
                   original_load_batch_calls=receipt.get('original_load_batch_calls'),
                   columns_validated=receipt.get('columns_validated'),
                   assembly_output_files=sum(n.startswith('assembly/') for n in result),
                   original_configuration_files=sum(n.startswith('assembly/configs/') for n in result),
                   native_batch_files=sum(n.startswith('assembly/batches/') for n in result),
                   original_year_input_files=sum(n.startswith('assembly/year-inputs/') for n in result),
                   stage_archive_sha256=STAGE_SHA, result_archive_sha256=sha(fetch.stdout),
                   forward_model_steps=0, states_constructed=0, GPU_tasks=0,
                   production_launch_allowed=False,
                   scope='PA metadata-only: 12 tests, OU4/OM184 exact byte join, 46 original NM load_batch checks. No physics, cold state, carry, spinup, prediction, score or GPU.')
    (ROOT / (LABEL + '-package.json')).write_text(json.dumps(package, indent=2) + '\n')
    print(json.dumps({k: v for k, v in package.items() if k != 'artifact_sha256'}), flush=True)


if __name__ == '__main__':
    main()

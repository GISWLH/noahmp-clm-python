"""EHPC-only original load_batch metadata check; never run/initialize a column."""
from __future__ import annotations

import argparse
import importlib
import json
import os
from pathlib import Path
import socket
import sys

from assemble_training_batches_pa import (bindings, build_documents, json_bytes,
                                         read_verified_archive, require, sha_bytes)


def verify_source(root, fixed):
    raw = (root / 'SOURCE_SHA256.json').read_bytes()
    require(sha_bytes(raw) == fixed['source']['manifest_sha256'], 'Exact NM manifest required')
    members = json.loads(raw)
    require(len(members) == 584, 'Exact NM 584 files required')
    for name, digest in members.items():
        require(sha_bytes((root / name).read_bytes()) == digest, 'Source changed: ' + name)
    return len(members)


def validate(output, source_root, om_archive, ou_archive):
    require(bool(os.environ.get('PBS_JOBID')) and socket.gethostname().split('.')[0] == 'compute002',
            'Array-loading validation is allowed only in an EHPC compute002 PBS job')
    fixed = bindings()
    require(fixed['production_launch_allowed'] is False, 'Metadata validation only')
    root, source = Path(output).resolve(), Path(source_root).resolve()
    verify_source(source, fixed)
    documents = build_documents(read_verified_archive(om_archive, fixed['om']),
                                read_verified_archive(ou_archive, fixed['ou']), fixed)
    inventory = json.loads((root / 'ASSEMBLY_SHA256.json').read_bytes())
    require(set(inventory) == set(documents), 'Complete original assembly required')
    for name, entry in inventory.items():
        raw = (root / name).read_bytes()
        require(raw == documents[name] and len(raw) == entry['bytes']
                and sha_bytes(raw) == entry['sha256'], 'Assembly changed: ' + name)
    del documents
    plan = json.loads((root / 'CHAIN_PLAN.json').read_bytes())
    identities = json.loads((root / 'CONFIG_IDENTITIES.json').read_bytes())
    expected = {(r['candidate'], r['case']): r for r in identities}
    require(plan['production_launch_allowed'] is False and plan['native_batches'] == 46
            and [r['candidate'] for r in plan['chains']] == fixed['candidate_order'], 'Plan changed')
    sys.path[:0] = [str(source / 'benchmarks'), str(source / 'src'), str(source)]
    native = importlib.import_module('run_fluxnet_native')
    require(Path(native.__file__).resolve() == source / 'benchmarks/run_fluxnet_native.py', 'Wrong native import')
    reports = []
    for chain in plan['chains']:
        require(chain['spinup_driver'] == chain['first_year']
                and chain['train1_from_own_spinup_mode'] == 'cycle'
                and chain['train2_from_train1_mode'] == 'continue', 'Wrong segment/mode contract')
        preceding_ends = None
        for which, label in enumerate(('first_year', 'second_year')):
            batch = root / chain[label]['path']
            require(sha_bytes(batch.read_bytes()) == chain[label]['sha256'], 'Batch SHA changed')
            loaded = native.load_batch(batch)
            require([r['case'] for r in loaded] == [r['case'] for r in fixed['original_cases']],
                    'Native case/order mismatch')
            require(native.native_state_count(loaded) == 16, 'Original 16-state mode required')
            starts, ends = [], []
            for row in loaded:
                case = expected[chain['candidate'], row['case']]
                year = fixed['site_years'][case['site']][which]
                stamps = row['data']
                start, end = str(stamps['time_start'][0]), str(stamps['time_end'][-1])
                require(start == str(year) + '01010000' and end == str(year + 1) + '01010000',
                        'Real calendar endpoints changed')
                require(len(row['stamps']) == (17520 if which == 0 else 17568), 'Wrong annual interval count')
                require(sha_bytes(row['paths']['configuration'].read_bytes()) == case['sha256'],
                        'Native configuration bytes changed')
                yr = next(r for r in fixed['years'] if r['site'] == case['site'] and r['year'] == year)
                require(sha_bytes(row['paths']['input'].read_bytes()) == yr['npz_sha256']
                        and sha_bytes(row['paths']['input_manifest'].read_bytes()) == yr['metadata_sha256'],
                        'Native input identity mismatch')
                starts.append(start)
                ends.append(end)
            if preceding_ends is not None:
                require(preceding_ends == starts, 'The two real years are not contiguous')
            preceding_ends = ends
            reports.append(dict(candidate=chain['candidate'], segment=label, columns=8,
                                steps_per_column=len(loaded[0]['stamps']), start=starts, end=ends,
                                native_state_arrays=16, batch_sha256=chain[label]['sha256']))
            del loaded
    verify_source(source, fixed)
    return dict(passed=True, pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
                original_load_batch_calls=len(reports), source_files_before_and_after=584,
                batches=reports, forward_model_steps=0, states_constructed=0,
                carry_generation_calls=0, GPU_tasks=0, actual_spinup=False, actual_scoring=False,
                production_launch_allowed=False,
                scope='Original input/config validation only; no state continuity or convergence claim.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assembly', required=True)
    parser.add_argument('--source-root', required=True)
    parser.add_argument('--om-archive', required=True)
    parser.add_argument('--ou-archive', required=True)
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    result = validate(args.assembly, args.source_root, args.om_archive, args.ou_archive)
    Path(args.report).write_bytes(json_bytes(result))
    print(json.dumps({k: v for k, v in result.items() if k != 'batches'}, sort_keys=True))

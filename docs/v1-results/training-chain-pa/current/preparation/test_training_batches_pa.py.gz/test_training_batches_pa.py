"""Metadata-only join/identity tests. Execute with the reviewed EHPC job."""
import copy
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

from assemble_training_batches_pa import (bindings, build_documents, json_bytes,
                                         read_verified_archive, require_production_launch,
                                         sha_bytes)


def fixture():
    fixed = copy.deepcopy(bindings())
    candidates = [dict(id=c, values={'synthetic_metadata_token': c}) for c in fixed['candidate_order']]
    plan = dict(first_batch=candidates[:7], second_batch=candidates[7:], candidate_count=23,
                active_dims=['b_s', 'mr_b', 'q10'], training_inputs=fixed['training_inputs'],
                preparation={'model_source_manifest_sha256': fixed['source']['manifest_sha256']})
    om = {'result/candidate-plan.json': json_bytes(plan)}
    ou, rows = {}, []
    for row in fixed['years']:
        for field, hash_field in [('npz', 'npz_sha256'), ('metadata', 'metadata_sha256')]:
            # Intentionally not a valid NPZ: proves the assembler never decodes arrays.
            raw = b'opaque\x00\xff\r\n' + row[field].encode()
            row[hash_field] = sha_bytes(raw)
            ou['current/prepared-inputs/' + row[field]] = raw
        rows.append(dict(row, complete_calendar=True, original_validate_input_succeeded=True))
    years = dict(rows=rows, source_manifest_sha256=fixed['source']['manifest_sha256'],
                 production_launch_allowed=False, reference_only=True, actual_spinup=False)
    ou['current/prepared-inputs/YEAR_IDENTITIES.json'] = json_bytes(years)
    index, references = [], []
    for candidate in candidates:
        for case in fixed['original_cases']:
            name = 'applied/' + candidate['id'] + '/' + case['case'] + '.json'
            raw = ('{\r\n  "case": ' + json.dumps(case['case']) + ',\r\n  "site": '
                   + json.dumps(case['site']) + ', "leaf_parameters": {"token": '
                   + json.dumps(candidate['id']) + '}\r\n}\r\n').encode()
            digest = sha_bytes(raw)
            sidecar = dict(candidate=candidate, registered_original=case, site=case['site'],
                           original_config_sha256=case['sha256'], output_config_sha256=digest,
                           spun_up=False, model_executed=False, score_computed=False)
            receipt = name[:-5] + '-receipt.json'
            om['result/' + name], om['result/' + receipt] = raw, json_bytes(sidecar)
            index.append(dict(candidate=candidate['id'], case=case['case'], config=name,
                              receipt=receipt, output_sha256=digest, original_sha256=case['sha256']))
            first, second = fixed['site_years'][case['site']]
            references.append(dict(candidate=candidate['id'], case=case['case'], site=case['site'],
                                   candidate_config_sha256=digest, original_config_sha256=case['sha256'],
                                   original_OM_member='result/' + name, first_year=first,
                                   second_year=second, same_config_sha_required_both_years=True))
    om['result/applied-index.json'] = json_bytes(index)
    refs = dict(original_cases=fixed['original_cases'], original_OM_applied_configurations=references,
                production_launch_allowed=False, executable_batch_created=False)
    ou['current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json'] = json_bytes(refs)
    return om, ou, fixed


def change_json(files, path, change):
    value = json.loads(files[path])
    change(value)
    files[path] = json_bytes(value)


class BatchJoinTests(unittest.TestCase):
    def setUp(self):
        self.om, self.ou, self.fixed = fixture()

    def build(self):
        return build_documents(self.om, self.ou, self.fixed)

    def test_all_46_batches_preserve_eight_case_order_and_modes(self):
        docs = self.build()
        plan = json.loads(docs['CHAIN_PLAN.json'])
        self.assertEqual(len([k for k in docs if k.startswith('batches/')]), 46)
        self.assertEqual(len([k for k in docs if k.startswith('configs/')]), 184)
        self.assertEqual([r['candidate'] for r in plan['chains']], self.fixed['candidate_order'])
        for chain in plan['chains']:
            self.assertEqual(chain['spinup_driver'], chain['first_year'])
            self.assertEqual(chain['train1_from_own_spinup_mode'], 'cycle')
            self.assertEqual(chain['train2_from_train1_mode'], 'continue')
            self.assertIsNone(chain['parent_run'])
            self.assertFalse(chain['own_seed_verified'])
            self.assertFalse(chain['score_eligible'])
            for label in ('first_year', 'second_year'):
                rows = json.loads(docs[chain[label]['path']])['cases']
                self.assertEqual([r['case'] for r in rows], [r['case'] for r in self.fixed['original_cases']])
        self.assertFalse(plan['production_launch_allowed'])
        self.assertFalse(plan['initialization_budget_frozen'])

    def test_original_bytes_and_same_config_both_years(self):
        docs = self.build()
        for row in json.loads(self.om['result/applied-index.json']):
            self.assertEqual(docs['configs/' + row['config'][8:]], self.om['result/' + row['config']])
        for year in self.fixed['years']:
            for field in ('npz', 'metadata'):
                self.assertEqual(docs[year[field]], self.ou['current/prepared-inputs/' + year[field]])
        for cid in self.fixed['candidate_order']:
            a = json.loads(docs['batches/' + cid + '/first-year.json'])['cases']
            b = json.loads(docs['batches/' + cid + '/second-year.json'])['cases']
            for first, second in zip(a, b):
                self.assertEqual(first['configuration'], second['configuration'])
                self.assertEqual(first['case'], second['case'])
                self.assertNotEqual(first['input'], second['input'])

    def test_join_does_not_depend_on_applied_or_reference_sort_order(self):
        expected = self.build()
        change_json(self.om, 'result/applied-index.json', lambda rows: rows.reverse())
        change_json(self.ou, 'current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json',
                    lambda r: r['original_OM_applied_configurations'].reverse())
        actual = self.build()
        # The original reference document is intentionally preserved in its input order.
        expected.pop('OU_CASE_YEAR_REFERENCE_ONLY.json')
        actual.pop('OU_CASE_YEAR_REFERENCE_ONLY.json')
        self.assertEqual(actual, expected)

    def test_duplicate_candidate_case_rejected(self):
        change_json(self.om, 'result/applied-index.json', lambda rows: rows.append(rows[0]))
        with self.assertRaisesRegex(ValueError, 'Duplicate OM'):
            self.build()

    def test_missing_candidate_case_rejected(self):
        change_json(self.ou, 'current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json',
                    lambda r: r['original_OM_applied_configurations'].pop())
        with self.assertRaisesRegex(ValueError, 'Missing/extra'):
            self.build()

    def test_candidate_and_case_order_cannot_change(self):
        for kind in ('candidate', 'case'):
            with self.subTest(kind=kind):
                self.om, self.ou, self.fixed = fixture()
                if kind == 'candidate':
                    change_json(self.om, 'result/candidate-plan.json', lambda p: p['first_batch'].reverse())
                else:
                    change_json(self.ou, 'current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json',
                                lambda r: r['original_cases'].reverse())
                with self.assertRaisesRegex(ValueError, 'order'):
                    self.build()

    def test_changed_config_or_input_bytes_rejected(self):
        for kind in ('config', 'input'):
            with self.subTest(kind=kind):
                self.om, self.ou, self.fixed = fixture()
                if kind == 'config':
                    row = json.loads(self.om['result/applied-index.json'])[0]
                    self.om['result/' + row['config']] += b' '
                else:
                    self.ou['current/prepared-inputs/' + self.fixed['years'][0]['npz']] += b' '
                with self.assertRaisesRegex(ValueError, 'bytes changed|SHA mismatch'):
                    self.build()

    def test_wrong_second_year_mapping_and_leap_count_rejected(self):
        for kind in ('mapping', 'steps'):
            with self.subTest(kind=kind):
                self.om, self.ou, self.fixed = fixture()
                if kind == 'mapping':
                    change_json(self.ou, 'current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json',
                                lambda r: r['original_OM_applied_configurations'][0].update(second_year=2009))
                else:
                    change_json(self.ou, 'current/prepared-inputs/YEAR_IDENTITIES.json',
                                lambda r: r['rows'][1].update(steps=17520))
                with self.assertRaisesRegex(ValueError, 'year join|calendar metadata'):
                    self.build()

    def test_metadata_cannot_claim_spun_up(self):
        row = json.loads(self.om['result/applied-index.json'])[0]
        change_json(self.om, 'result/' + row['receipt'], lambda r: r.update(spun_up=True))
        with self.assertRaisesRegex(ValueError, 'cannot certify a seed'):
            self.build()

    def test_training_role_and_site_cannot_be_substituted(self):
        change_json(self.om, 'result/candidate-plan.json',
                    lambda p: p['training_inputs'][0].update(site='CN-Cha', role='holdout'))
        with self.assertRaisesRegex(ValueError, 'Training roles/years'):
            self.build()

    def test_production_gate_rejects_without_touching_models(self):
        with self.assertRaisesRegex(ValueError, 'production launch is unsealed'):
            require_production_launch()

    def test_archive_rejects_nonterminal_receipt_even_with_matching_hash(self):
        for state in ('F', 'E'):
            with self.subTest(state=state), tempfile.TemporaryDirectory() as tmp:
                files = {'actual-pbs-qstat.txt': ('Job Id: toy.manager\n    job_state = ' + state
                         + '\n    Exit_status = 0\n    Stageout_status = 0\n').encode(),
                         'pbs-exit.txt': b'0\n', 'worker.txt': b'0\n',
                         'receipt.json': json_bytes(dict(passed=True, pbs_job='toy.manager', node='compute002'))}
                inventory = {n: dict(bytes=len(v), sha256=sha_bytes(v)) for n, v in files.items()}
                files['inventory.json'] = json_bytes(inventory)
                path = Path(tmp) / 'toy.tar.gz'
                with tarfile.open(path, 'w:gz') as tar:
                    for name, raw in files.items():
                        member = tarfile.TarInfo(name)
                        member.size = len(raw)
                        tar.addfile(member, io.BytesIO(raw))
                spec = dict(bytes=path.stat().st_size, sha256=sha_bytes(path.read_bytes()), members=len(files),
                            inventory='inventory.json', job='toy.manager', worker_exit='worker.txt',
                            receipt='receipt.json', selected_sha256={})
                if state == 'F':
                    self.assertEqual(read_verified_archive(path, spec), files)
                else:
                    with self.assertRaisesRegex(ValueError, 'terminal missing'):
                        read_verified_archive(path, spec)


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Join sealed OU inputs to sealed OM configurations; no array/physics imports."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def bindings():
    return json.loads((HERE / 'BINDINGS.json').read_bytes())


def require_production_launch():
    require(bindings()['production_launch_allowed'] is True,
            'PA production launch is unsealed: no candidate seed/spinup/score authorization')
    raise NotImplementedError('PA has no production launcher or state constructor')


def unique(rows, key, label):
    answer = {}
    for row in rows:
        k = key(row)
        require(k not in answer, 'Duplicate ' + label + ': ' + str(k))
        answer[k] = row
    return answer


def read_verified_archive(path, spec):
    raw = Path(path).read_bytes()
    require(len(raw) == spec['bytes'] and sha_bytes(raw) == spec['sha256'], 'Archive identity mismatch')
    files = {}
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            p = PurePosixPath(member.name)
            require(member.isfile() and not p.is_absolute() and '..' not in p.parts,
                    'Unsafe/non-file archive member')
            require(member.name not in files, 'Duplicate archive member')
            files[member.name] = archive.extractfile(member).read()
    require(len(files) == spec['members'], 'Archive member count mismatch')
    inventory = json.loads(files[spec['inventory']])
    require(set(inventory) == set(files) - {spec['inventory']}, 'Incomplete archive inventory')
    for name, entry in inventory.items():
        require(len(files[name]) == entry['bytes'] and sha_bytes(files[name]) == entry['sha256'],
                'Inventory mismatch: ' + name)
    qstat = files['actual-pbs-qstat.txt'].decode('utf-8')
    for field, value in [('job_state', 'F'), ('Exit_status', '0'), ('Stageout_status', '0')]:
        require(re.search(r'^\s*' + field + r'\s*=\s*' + value + r'\s*$', qstat, re.M),
                'Original PBS terminal missing: ' + field)
    require(qstat.splitlines()[0] == 'Job Id: ' + spec['job'], 'Original PBS job mismatch')
    for name in ('pbs-exit.txt', spec['worker_exit']):
        require(files[name].strip() == b'0', 'Original parent/worker exit is not zero')
    receipt = json.loads(files[spec['receipt']])
    require(receipt['passed'] is True and receipt['pbs_job'] == spec['job']
            and receipt['node'] == 'compute002', 'Original receipt identity mismatch')
    for name, expected in spec['selected_sha256'].items():
        require(sha_bytes(files[name]) == expected, 'Selected original member mismatch: ' + name)
    return files


def build_documents(om, ou, fixed):
    """Pure byte/JSON join. NPZ payloads stay opaque; no initialization is done."""
    plan = json.loads(om['result/candidate-plan.json'])
    index = json.loads(om['result/applied-index.json'])
    years = json.loads(ou['current/prepared-inputs/YEAR_IDENTITIES.json'])
    refs = json.loads(ou['current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json'])
    candidates = plan['first_batch'] + plan['second_batch']
    ids = [c['id'] for c in candidates]
    require(ids == fixed['candidate_order'] and len(set(ids)) == 23, 'Candidate order/count changed')
    require(plan['candidate_count'] == 23 and plan['active_dims'] == ['b_s', 'mr_b', 'q10'],
            'Original candidate dimensions changed')
    require(plan['training_inputs'] == fixed['training_inputs'], 'Training roles/years changed')
    source = fixed['source']['manifest_sha256']
    require(plan['preparation']['model_source_manifest_sha256'] == source
            and years['source_manifest_sha256'] == source, 'Source mismatch')
    require(years['production_launch_allowed'] is False and years['reference_only'] is True
            and years['actual_spinup'] is False and refs['production_launch_allowed'] is False,
            'OU preparation boundary changed')
    require(refs['original_cases'] == fixed['original_cases'], 'Original case/order changed')
    cases = refs['original_cases']
    case_names = [r['case'] for r in cases]
    require(len(cases) == 8 and len(set(case_names)) == 8, 'Eight unique original cases required')
    expected_pairs = {(candidate, case) for candidate in ids for case in case_names}
    applied = unique(index, lambda r: (r['candidate'], r['case']), 'OM candidate/case')
    refs_by_pair = unique(refs['original_OM_applied_configurations'],
                          lambda r: (r['candidate'], r['case']), 'OU candidate/case')
    require(set(applied) == set(refs_by_pair) == expected_pairs, 'Missing/extra candidate/case')
    by_year = unique(years['rows'], lambda r: (r['site'], r['year']), 'site/year')
    require(set(by_year) == {(r['site'], r['year']) for r in fixed['years']}, 'Year roster changed')
    documents = {}
    year_paths = {}
    for expected in fixed['years']:
        key = expected['site'], expected['year']
        row = by_year[key]
        require({k: row[k] for k in expected} == expected, 'Year identity/calendar metadata changed')
        require(row['complete_calendar'] is True and row['original_validate_input_succeeded'] is True,
                'OU complete original calendar validation required')
        for field, hash_field in [('npz', 'npz_sha256'), ('metadata', 'metadata_sha256')]:
            name = row[field]
            require(name == 'year-inputs/' + row['site'] + '-' + str(row['year'])
                    + ('.npz' if field == 'npz' else '.json'), 'Unexpected year input path')
            raw = ou['current/prepared-inputs/' + name]
            require(sha_bytes(raw) == row[hash_field], 'Original year input bytes changed')
            documents[name] = raw
        year_paths[key] = row
    chains = []
    configurations = []
    for candidate in candidates:
        cid = candidate['id']
        require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', cid), 'Unsafe candidate name')
        shared_leaf = None
        for case in cases:
            name = case['case']
            row, ref = applied[cid, name], refs_by_pair[cid, name]
            config_member = 'result/applied/' + cid + '/' + name + '.json'
            receipt_member = config_member[:-5] + '-receipt.json'
            require('result/' + row['config'] == config_member == ref['original_OM_member']
                    and 'result/' + row['receipt'] == receipt_member, 'Configuration member mismatch')
            raw = om[config_member]
            digest = sha_bytes(raw)
            config = json.loads(raw)
            sidecar = json.loads(om[receipt_member])
            first, second = fixed['site_years'][case['site']]
            require(ref['site'] == case['site'] and ref['first_year'] == first
                    and ref['second_year'] == second and ref['same_config_sha_required_both_years'] is True,
                    'OU configuration/year join changed')
            require(digest == row['output_sha256'] == ref['candidate_config_sha256']
                    == sidecar['output_config_sha256'], 'Candidate configuration SHA mismatch')
            require(case['sha256'] == row['original_sha256'] == ref['original_config_sha256']
                    == sidecar['original_config_sha256'], 'Original configuration SHA mismatch')
            require(sidecar['candidate'] == candidate and sidecar['registered_original'] == case
                    and sidecar['site'] == case['site'], 'OM sidecar/candidate identity changed')
            require(sidecar['spun_up'] is False and sidecar['model_executed'] is False
                    and sidecar['score_computed'] is False, 'OM metadata cannot certify a seed')
            require(config['case'] == name and config['site'] == case['site'], 'Case/site relabeling forbidden')
            if shared_leaf is None:
                shared_leaf = config['leaf_parameters']
            require(config['leaf_parameters'] == shared_leaf, 'Candidate leaf parameters not shared')
            target = 'configs/' + cid + '/' + name + '.json'
            documents[target] = raw
            configurations.append(dict(candidate=cid, case=name, site=case['site'],
                                       configuration=target, sha256=digest,
                                       original_config_sha256=case['sha256'],
                                       OM_member=config_member, OM_receipt_member=receipt_member,
                                       OM_receipt_sha256=sha_bytes(om[receipt_member])))
        batches = []
        for which, label in enumerate(('first-year', 'second-year')):
            rows = []
            for case in cases:
                year = fixed['site_years'][case['site']][which]
                forcing = year_paths[case['site'], year]
                rows.append(dict(case=case['case'], input='../../' + forcing['npz'],
                                 input_manifest='../../' + forcing['metadata'],
                                 configuration='../../configs/' + cid + '/' + case['case'] + '.json'))
            name = 'batches/' + cid + '/' + label + '.json'
            documents[name] = json_bytes(dict(cases=rows))
            batches.append(dict(path=name, sha256=sha_bytes(documents[name]),
                                steps_per_column=17520 if which == 0 else 17568))
        chains.append(dict(candidate=cid, original_case_order=case_names, first_year=batches[0],
                           spinup_driver=batches[0], train1_from_own_spinup_mode='cycle',
                           second_year=batches[1], train2_from_train1_mode='continue',
                           parent_run=None, own_seed_verified=False, actual_spinup=False,
                           score_eligible=False))
    chain_plan = dict(schema='training-chain-pa-metadata-v1', production_launch_allowed=False,
                      source_manifest_sha256=source, candidates=23, columns_per_candidate=8,
                      original_case_order=case_names, configurations=184, native_batches=46,
                      unique_site_year_inputs=4, chains=chains, initialization_budget_frozen=False,
                      scoring_policy_changed=False, forward_model_steps=0, states_constructed=0,
                      GPU_tasks=0, heldout_arrays_decoded=0,
                      scope='Batch metadata only. No own-parameter seed, spinup, carry audit or score.')
    documents['CHAIN_PLAN.json'] = json_bytes(chain_plan)
    documents['CONFIG_IDENTITIES.json'] = json_bytes(configurations)
    # Retain original linking metadata, without rewriting it or copying any held-out values.
    for name, raw in [('OM_PLAN.json', om['result/candidate-plan.json']),
                      ('OU_YEAR_IDENTITIES.json', ou['current/prepared-inputs/YEAR_IDENTITIES.json']),
                      ('OU_CASE_YEAR_REFERENCE_ONLY.json', ou['current/prepared-inputs/CASE_YEAR_REFERENCE_ONLY.json'])]:
        documents[name] = raw
    documents['ASSEMBLY_INPUTS.json'] = json_bytes(dict(
        OM_archive_sha256=fixed['om']['sha256'], OU_archive_sha256=fixed['ou']['sha256'],
        bindings_sha256=sha_bytes((HERE / 'BINDINGS.json').read_bytes()),
        production_launch_allowed=False))
    return documents


def assemble(om_archive, ou_archive, output):
    fixed = bindings()
    require(fixed['production_launch_allowed'] is False, 'Preparation only')
    om = read_verified_archive(om_archive, fixed['om'])
    ou = read_verified_archive(ou_archive, fixed['ou'])
    documents = build_documents(om, ou, fixed)
    output = Path(output)
    require(not output.exists(), 'Use a fresh output directory; never overwrite a trajectory')
    output.mkdir(parents=True)
    for name, raw in documents.items():
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    inventory = {name: dict(bytes=len(raw), sha256=sha_bytes(raw)) for name, raw in documents.items()}
    (output / 'ASSEMBLY_SHA256.json').write_bytes(json_bytes(inventory))
    return dict(passed=True, native_batches=46, configurations=184, inputs=4,
                output_files=len(inventory) + 1, forward_model_steps=0, states_constructed=0,
                production_launch_allowed=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--om-archive', required=True)
    parser.add_argument('--ou-archive', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(assemble(args.om_archive, args.ou_archive, args.output), sort_keys=True))

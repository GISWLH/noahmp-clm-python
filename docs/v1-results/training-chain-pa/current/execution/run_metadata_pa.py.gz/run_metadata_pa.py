"""One-shot EHPC PA metadata tests, byte assembly and original input loader only."""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-training-chain-pa')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    assert sys.version_info >= (3, 10)
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    result = Path(sys.argv[1]).resolve()
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
    result.mkdir()
    started = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
                   python_executable=sys.executable, passed=False, error=None,
                   forward_model_steps=0, states_constructed=0, GPU_tasks=0,
                   actual_spinup=False, actual_scoring=False, production_launch_allowed=False,
                   commands={}, scope='PA metadata assembly and original NM input loader only.')
    try:
        inventory = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in inventory.items())
        run = json.loads((STAGE / 'execution/RUN_BINDINGS.json').read_bytes())
        assert run['authorized'] is True and run['expected_tests'] == 12
        review_raw = (STAGE / 'root-review.json').read_bytes()
        review = json.loads(review_raw)
        assert sha(review_raw) == run['root_review_sha256'] and review['blocking_findings'] == []
        assert review['preparation_manifest_sha256'] == run['preparation_manifest_sha256']
        assert len(review['controls']) == 5 and len(review['test_names']) == 12
        (result / 'root-review.json').write_bytes(review_raw)
        receipt['root_review_sha256'] = sha(review_raw)
        for folder, expected, count in [('preparation', run['preparation_manifest_sha256'], 5),
                                         ('execution', None, 4)]:
            raw = (STAGE / folder / 'CONTROLS_SHA256.json').read_bytes()
            index = json.loads(raw)
            assert len(index) == count and (expected is None or sha(raw) == expected)
            assert all(sha((STAGE / folder / n).read_bytes()) == h for n, h in index.items())
            target = result / folder
            target.mkdir()
            for name in [*index, 'CONTROLS_SHA256.json']:
                shutil.copyfile(STAGE / folder / name, target / name)
            receipt[folder + '_manifest_sha256'] = sha(raw)
        work = result / 'preparation'
        fixed = json.loads((work / 'BINDINGS.json').read_bytes())
        assert fixed['production_launch_allowed'] is False
        for label in ('om', 'ou'):
            spec = fixed[label]
            assert sha((STAGE / 'inputs' / spec['file']).read_bytes()) == spec['sha256']
        source_archive = STAGE / 'inputs' / fixed['source']['archive']
        assert sha(source_archive.read_bytes()) == fixed['source']['archive_sha256']
        source_root = result.parent / 'source-nm584'
        source_root.mkdir()
        with tarfile.open(source_archive) as archive:
            members = archive.getmembers()
            assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
            assert len({m.name for m in members}) == len(members) == 585
            raw = archive.extractfile('SOURCE_SHA256.json').read()
            assert sha(raw) == fixed['source']['manifest_sha256']
            manifest = json.loads(raw)
            assert len(manifest) == 584 and {m.name for m in members} == set(manifest) | {'SOURCE_SHA256.json'}
            for name in [*manifest, 'SOURCE_SHA256.json']:
                value = archive.extractfile(name).read()
                assert name == 'SOURCE_SHA256.json' or sha(value) == manifest[name]
                target = source_root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(value)
        (result / 'SOURCE_SHA256.json').write_bytes(raw)
        assert all(sha((source_root / n).read_bytes()) == h for n, h in manifest.items())
        tree = ast.parse((work / 'test_training_batches_pa.py').read_bytes())
        tests = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
        assert len(tests) == len(set(tests)) == 12
        env = os.environ.copy()
        env.pop('PYTHONPATH', None)
        env.pop('PYTHONHOME', None)
        env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
        om = str(STAGE / 'inputs' / fixed['om']['file'])
        ou = str(STAGE / 'inputs' / fixed['ou']['file'])
        commands = [
            ('unittest', [sys.executable, '-B', '-m', 'unittest', '-v', 'test_training_batches_pa']),
            ('assembly', [sys.executable, '-B', str(work / 'assemble_training_batches_pa.py'),
                          '--om-archive', om, '--ou-archive', ou, '--output', str(result / 'assembly')]),
            ('native-metadata', [sys.executable, '-B', str(work / 'validate_native_batches_pa.py'),
                                 '--assembly', str(result / 'assembly'), '--source-root', str(source_root),
                                 '--om-archive', om, '--ou-archive', ou,
                                 '--report', str(result / 'native-metadata-report.json')])]
        for label, command in commands:
            save(result / (label + '-command.json'), dict(argv=command, cwd=str(work)))
            tick = time.monotonic()
            with (result / (label + '.stdout.txt')).open('w') as out, (result / (label + '.stderr.txt')).open('w') as err:
                proc = subprocess.Popen(command, cwd=work, env=env, stdout=out, stderr=err)
                try:
                    status = proc.wait(timeout=max(1., 510. - (time.monotonic() - started)))
                    timed_out = False
                except subprocess.TimeoutExpired:
                    proc.kill()
                    status = proc.wait()
                    timed_out = True
            receipt['commands'][label] = dict(parent_returncode=status, timed_out=timed_out,
                                               pid=proc.pid, seconds=time.monotonic() - tick)
            (result / (label + '-parent-exit.txt')).write_text(str(status) + '\n')
            assert status == 0 and not timed_out, label + ' failed; raw logs retained'
        stderr = (result / 'unittest.stderr.txt').read_text()
        count = re.search(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
        assert count and int(count.group(1)) == 12 and re.search(r'^OK$', stderr, re.M)
        assert 'skipped=' not in stderr and 'skipped ' not in stderr
        for name in tests:
            assert re.search(r'^' + name + r' \(.*\) \.\.\. ok$', stderr, re.M), name
        report = json.loads((result / 'native-metadata-report.json').read_bytes())
        assert report['passed'] is True and report['original_load_batch_calls'] == len(report['batches']) == 46
        assert report['source_files_before_and_after'] == 584 and report['production_launch_allowed'] is False
        assert report['forward_model_steps'] == report['states_constructed'] == report['GPU_tasks'] == 0
        assert report['carry_generation_calls'] == 0 and report['actual_spinup'] is False and report['actual_scoring'] is False
        assert report['pbs_job'] == os.environ['PBS_JOBID'] and report['node'] == 'compute002'
        assert all(sha((source_root / n).read_bytes()) == h for n, h in manifest.items())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in inventory.items())
        prep = json.loads((work / 'CONTROLS_SHA256.json').read_bytes())
        assert all(sha((work / n).read_bytes()) == h for n, h in prep.items())
        receipt.update(passed=True, actual_test_count=12, actual_test_seconds=float(count.group(2)),
                       test_names=tests, original_load_batch_calls=46, columns_validated=368,
                       source_before_after_584_exact=True, original_inputs_and_controls_unchanged=True,
                       source_manifest_sha256=fixed['source']['manifest_sha256'],
                       source_archive_sha256=fixed['source']['archive_sha256'],
                       OM_archive_sha256=fixed['om']['sha256'], OU_archive_sha256=fixed['ou']['sha256'],
                       native_metadata_report_sha256=sha((result / 'native-metadata-report.json').read_bytes()))
    except Exception as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        (result / 'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic() - started
    save(result / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

"""One bounded no-locals owned-process snapshot; never alter a model task."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=base/'profile_output/full-irrigation-wait-a';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
progress=(source/'full-by-file-a/progress.json').read_bytes();p=json.loads(progress);active=p['active'];pid=active['pid'];assert active['file']=='tests/test_gpu_clm_irrigation_column.py'
proc=Path('/proc')/str(pid);assert proc.stat().st_uid==os.getuid() and proc.joinpath('cwd').resolve()==source
command=(proc/'cmdline').read_bytes().rstrip(b'\0').split(b'\0');assert active['file'].encode() in command
status={}
for line in (proc/'status').read_text().splitlines():
    key=line.split(':',1)[0]
    if key in ['Name','State','Uid','VmRSS','Threads']:status[key]=line.split(':',1)[1].strip()
stat=(proc/'stat').read_text();wchan=(proc/'wchan').read_text();(root/'progress-before.json').write_bytes(progress)
spy=base/'profile-tools-pyspy-a/bin/py-spy';args=[str(spy),'dump','--pid',str(pid),'--json','--full-filenames','--nonblocking'];start=time.monotonic()
try:
    result=subprocess.run(args,capture_output=True,text=True,timeout=8);code=result.returncode;stdout=result.stdout;stderr=result.stderr
except subprocess.TimeoutExpired:code=124;stdout='';stderr='Bounded read-only snapshot timeout; model process was not terminated.'
if code==0:
    threads=json.loads(stdout);assert all(not frame.get('locals') for thread in threads for frame in thread['frames'])
    (root/'stack.json').write_text(stdout)
(root/'stderr.txt').write_text(stderr)
assert all(sha(source/n)==v for n,v in m.items())
value=dict(scope='Single instantaneous read-only stack/wchan/status from own canonical GPU regression child after30min; no locals/environment, production instrumentation, termination or performance attribution.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=pid,active_file=active['file'],state_before=status,wchan_before=wchan,stat_before=stat,command=[v.decode() for v in command],profiler_returncode=code,probe_seconds=time.monotonic()-start,
    completed_files_before=p['gpu_files_completed'],total_gpu_files=p['gpu_files_total'],source_files=len(m),source_unchanged=True,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),probe_sha256=sha(Path(__file__)),profiler_sha256=sha(spy),process_still_exists=proc.exists())
(root/'probe_full_gpu_irrigation_wait_a.py').write_bytes(Path(__file__).read_bytes());(root/'summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'profile_output/full-irrigation-wait-a';source=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((root/'summary.json').read_text());assert s['source_unchanged'] and s['profiler_returncode']==0 and s['process_still_exists']
frames=json.loads((root/'stack.json').read_text());assert all(not f.get('locals') for t in frames for f in t['frames']);assert frames[0]['frames'][0]['name']=='clear_backends'
names=['summary.json','stack.json','stderr.txt','progress-before.json','probe_full_gpu_irrigation_wait_a.py']
dest=base/'full-irrigation-wait-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for n in names:t.add(root/n,arcname='snapshots/'+n,recursive=False)
    t.add(source/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False);t.add(Path(__file__),arcname='archive_full_irrigation_wait_a.py',recursive=False)
print(json.dumps(dict(files=len(names)+2,sha256=sha(dest),scope='Single instantaneous stack/wchan/own process status, no locals/environment. Evidence of post-test JAX cleanup at the captured instant, not numerical failure or a performance distribution.')))

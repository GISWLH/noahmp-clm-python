from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-most-physical-c';r=s/'full-controller-c'
assert not r.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==509 and all(sha(s/n)==v for n,v in m.items())
archive=b/'most-warm-cpu-c-evidence.tar.gz'
assert sha(archive)=='15d44099440f09798fe88f766de4854fe7dfc565a6e9d3dd54084b209e685391'
with tarfile.open(archive) as t:
    assert json.loads(t.extractfile('SOURCE_SHA256.json').read())==m
    rec=json.loads(t.extractfile('cpu-full-receipt.json').read())
    assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=909,failures=0,errors=0,skipped=0)
r.mkdir()
wait_file=b/'p6-phase-final-check-a/full-controller-a/exit.json';wait_pid=2557162
if not wait_file.exists():assert Path('/proc/'+str(wait_pid)).exists()
controls={n:sha(b/n) for n in ['collect_most_full_gpu_c.py','run_most_full_gpu_c.py','wait_most_full_gpu_c.py','launch_most_full_gpu_c.py']}
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='1', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_COMPILATION_CACHE_DIR=str(b / 'jax-surface-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NOAHMP_REQUIRE_GPU='1')
launch=dict(scope='Deferred frozen509C canonical1249,exact CPU909 plus all340 GPU actual reruns; wait for predecessor actual exit. No cancellation,old results not credited. Queueing is not completion.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=1,source_files=509,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),controls_sha256=controls,wait_for_actual_exit=str(wait_file),wait_for_original_pid=wait_pid)
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
with (r/'controller.log').open('x') as log:
    child=subprocess.Popen([sys.executable,'-u',str(b/'wait_most_full_gpu_c.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
launch['pid']=child.pid;(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');print(json.dumps(launch))

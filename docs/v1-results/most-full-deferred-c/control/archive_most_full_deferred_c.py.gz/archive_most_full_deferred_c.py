from pathlib import Path
import hashlib,io,json,os,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-most-physical-c';r=s/'full-controller-c';a=b/'most-full-deferred-c-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'launch.json').read_text());assert d['source_files']==509
for n,h in d['controls_sha256'].items():assert sha(b/n)==h
proc=Path('/proc/'+str(d['pid']));assert proc.exists() and proc.stat().st_uid==os.getuid()
observed=dict(scope='Metadata-only snapshot of deferred final509C canonical1249. ExactCPU909 passed,all340GPU pending predecessor actual exit. Original506 full progress is historical/distinct,no result credit. No signal or model mutation.',pid=d['pid'],argv=(proc/'cmdline').read_bytes().decode().replace('\0',' '),worker_exists=(r/'worker.json').exists(),exit_exists=(r/'exit.json').exists(),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'))
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname='current/'+p.relative_to(r).as_posix(),recursive=False)
    for n in d['controls_sha256']:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    for n in ['full-controller-a/launch.json','full-controller-a/worker.json','full-by-file-a/collection.json','full-by-file-a/progress.json']:
        p=b/'p6-phase-final-check-a'/n
        raw=p.read_bytes();info=tarfile.TarInfo('predecessor/'+n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    raw=(json.dumps(observed,indent=2)+'\n').encode();info=tarfile.TarInfo('observation.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,observation=observed)))

from pathlib import Path
import io
import hashlib
import json
import os
import sys
import tarfile
import time
import traceback

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3803-numpy-current-h'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'thin-snow-event-native-a-source.tar.gz'
assert sha(a) == '21895b2ced35a664e3522b539ef43ccd61ea2d3ffff56f36645d6e6abad5d994'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in m.items())
cpu=b/'thin-snow-event-cpu-a';cpu_record=json.loads((cpu/'receipt.json').read_text())
assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and cpu_record['returncode']==0 and cpu_record['source_unchanged'] and cpu_record['counts']==dict(tests=1068,failures=0,errors=0,skipped=0)
assert json.loads((cpu/'SOURCE_SHA256.json').read_text())==m
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'tests'), str(s / 'benchmarks')]
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack, TF, LF, CW
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.gpu.canopy_phase_energy import unpack_phase

device = b / 'qia3803-numpy-guess-j/device'
binding = json.loads((device / 'binding.json').read_text())
cap = json.loads((device / 'surface-capture-a/receipt.json').read_text())
path = device / 'surface-capture-a/failed-surface.npz'
assert sha(path) == cap['failed_surface_sha256']
with np.load(path, allow_pickle=False) as z:
    packet = dict(z)
c, g, p, o, leaf, u, factors, v, cond = [np.asarray(packet['surface_a' + str(k)][0], float) for k in range(9)]
n = int(o[0]); dt = v[0]
snow = Snowpack(c[:n, 0], c[:n, 1], c[:n, 2], c[:n, 3], c[:n, 4:])
props = SoilParams(smcmax=p[0], bexp=p[1], smcref=p[2], satdk=p[3], quartz=p[4], smcwlt=p[5], saturated_suction_m=p[6])
soil = SoilEnthalpyState(g[:, 0], g[:, 1], g[:, 2], props, int(o[1]))
water = CanopyCondensate(cond[:, 0], cond[:, 1])
extra = packet['exchange_extension'][0]
exchange = CanopyExchange(*u[:11], atmosphere_water_velocity=extra[0], potential_temperature=extra[1])
parameters = LeafParameters(**json.loads((device / 'surface-capture-a/leaf-parameters.json').read_text()))
kwargs = dict(stem_area=packet['stem_area'][0], vegetated_fraction=u[13], transpiration_limit=u[16],
              ground_emissivity=u[18], ground_albedo=u[19:21], diffuse_fraction=u[21], cosine_zenith=u[22],
              nitrogen_factor=factors[:, 0], water_stress=factors[:, 1], leaf_parameters=parameters)
raw = packet['raw']; got = unpack_phase(raw[:, 441:741])
supply = SoilWaterSupply(np.maximum(soil.liquid - props.smcwlt * 1000. * soil.dz, 0.) / dt, v[3:], soil.liquid[0] / dt)
fixed = float(raw[0, 360])
archive=b/'qia3803-trace-bc-evidence.tar.gz'
assert sha(archive)=='bb609337dba41d65951f7c64cd5671967a82f8fff9e5453af097890efbda2bda'
with tarfile.open(archive) as tf:
    raw_trace=tf.extractfile('qia3803-trace-device-c/trace-and-raw.npz').read()
    with np.load(io.BytesIO(raw_trace),allow_pickle=False) as z:
        assert z['original_raw'].tobytes()==z['instrumented_raw'].tobytes()
        gpu_guess=z['iteration_trace'][99,:12].astype(float)
records = []
for label in ['fixed-rejected-boundary', 'fixed-from-gpu-stagnation', 'whole-surface']:
    start = time.monotonic(); failure = None; result = None
    try:
        if label.startswith('fixed'):
            out = solve_canopy_phase_energy(leaf, u[11], u[12], exchange, water, dt,
                  soil_supply=supply, root_enthalpy=LF + CW * (soil.temperature - TF),
                  ground_evaporation_limit=snow.mass[0] / dt if n else np.inf,
                  fixed_ground_temperature=fixed, ground_is_ice=bool(fixed < TF), ground_shares_soil=not n,
                  snowpack=snow, tolerance=1e-7, max_iterations=80, initial_guess=gpu_guess if label=='fixed-from-gpu-stagnation' else None, **kwargs)
            result = {name: np.asarray(out[name]).tolist() for name in ['leaf_temperature', 'ground_temperature', 'canopy_humidity', 'h', 'le', 'gpp', 'iterations', 'max_solver_residual'] if name in out}
        else:
            new_snow, new_soil, _, out = surface_step(snow, soil, dt, leaf, u[11], u[12], exchange,
                  canopy_condensate=water, root_weights=v[3:], **kwargs)
            result = {name: np.asarray(out[name]).tolist() for name in ['leaf_temperature', 'ground_temperature', 'h', 'le', 'gpp', 'iterations', 'energy_residual_jm2', 'mass_residual_kgm2'] if name in out}
            result.update(soil_temperature=new_soil.temperature.tolist(), snow_mass=new_snow.mass.tolist())
        if label.startswith('fixed'):
            assert max(abs(out['layer_residual']))<=1.05e-7 and abs(out['canopy_water_residual'])<1e-12
        else:
            assert abs(out['energy_residual_jm2'])<.02 and abs(out['water_residual_kgm2'])<1e-10
        values={k:np.asarray(x) for k,x in out.items() if isinstance(x,(float,int,np.ndarray))}
        values.update(condensate_mass=out['condensate'].mass,condensate_enthalpy=out['condensate'].enthalpy)
        if not label.startswith('fixed'):
            values.update(soil_water=new_soil.water,soil_enthalpy=new_soil.enthalpy,soil_temperature=new_soil.temperature,
                snow_mass=new_snow.mass,snow_enthalpy=new_snow.enthalpy,snow_thickness=new_snow.thickness)
        np.savez_compressed(r/(label+'-reference.npz'),**values)
    except Exception as e:
        failure = type(e).__name__ + ': ' + str(e)
        (r / (label + '-traceback.txt')).write_text(traceback.format_exc())
    records.append(dict(label=label, failure=failure, result=result, seconds=time.monotonic() - start))
record = dict(scope='Current558 complete1068CPU physical reference of exact retained original519H3803 scene, all old initialstores/forcing/leaf parameters and original1e-7/80 unchanged. Fixedboundary, exactGPUstagnation seeded and whole-surface results retained with independent original mass/heat checks. Not a model edit or accepted annual advancement; private CUDA recovery and fullJAX/CUDA verification separate',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, binding=binding, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'),
              source_unchanged=all(sha(s / k) == h for k, h in m.items()), original_surface_sha256=sha(path), fixed_ground_temperature=fixed,
              original_cuda_max_solver_residual=float(got['max_solver_residual'][0]), original_cuda_iterations=int(got['iterations'][0]),
              old_canopy_mass=water.mass.tolist(), old_canopy_enthalpy=water.enthalpy.tolist(), records=records)
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

assert record["source_unchanged"] and all(row["failure"] is None for row in records)

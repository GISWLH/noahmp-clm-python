from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=['qia3803-numpy-current-g','qia3803-numpy-current-h']
for n in roots:
    r=b/n;d=json.loads((r/'diagnosis.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged']
    if n.endswith('-h'):assert len(d['records'])==3 and all(x['failure'] is None for x in d['records'])
    else:assert d['records'][-1]['failure']=="KeyError: 'mass_residual_kgm2'"
source=b/'thin-snow-event-native-a-source.tar.gz';assert sha(source)=='21895b2ced35a664e3522b539ef43ccd61ea2d3ffff56f36645d6e6abad5d994'
a=b/'qia3803-numpy-current-gh-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n in roots:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=n+'/'+p.relative_to(b/n).as_posix(),recursive=False)
    for n in ['dispatch_qia3803_numpy_current_g.py','dispatch_qia3803_numpy_current_h.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    for n in ['failed-surface.npz','leaf-parameters.json','receipt.json']:t.add(b/'qia3803-numpy-guess-j/device/surface-capture-a'/n,arcname='original-capture/'+n,recursive=False)
    t.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-numpy-current-g';assert not r.exists();r.mkdir();controls={}
for n in ['probe_qia3803_numpy_current_g.py','qia3803_numpy_current_g.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'qia3803_numpy_current_g.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

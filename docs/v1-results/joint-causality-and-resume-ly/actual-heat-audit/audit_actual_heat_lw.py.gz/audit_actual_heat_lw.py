"""Independent 2x2 actual-input causal isolation; production remains unchanged."""
from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-actual-heat-audit-lw';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'k78-actual-heat-lo-export.tar.gz';assert sha(a)=='fa525967b877af3b55218e3748e5178cf6842018609a50d580a0653a603e789e';tmp=Path(os.environ['TMPDIR'])/'device';tmp.mkdir()
with tarfile.open(a) as tf:tf.extractall(tmp,filter='data')
started=time.monotonic();ref=json.loads((tmp/'numpy-reference-receipt.json').read_text());assert ref['passed'] and ref['only_first_snow_thickness_differs'] and len(ref['actual_operand_differences'])==1 and sha(tmp/'actual-operands.npz')==ref['actual_operand_archive_sha256'];q=subprocess.check_output(['qstat','-xf','1419.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);(r/'reference-actual-qstat.txt').write_text(q);exit=json.loads((tmp/'exit.json').read_text());assert exit['passed'] and len(exit['records'])==2 and all(x['passed'] and x['actual_parent_returncode']==0 for x in exit['records']);out={}
for name in ['cuda','jax']:
    d=json.loads((tmp/(name+'-receipt.json')).read_text());parent=next(x for x in exit['records'] if x['backend']==name);assert d['source_unchanged'] and d['device_barrier_complete'] and d['failure'] is None and sha(tmp/(name+'-receipt.json'))==parent['receipt_sha256'] and sha(tmp/(name+'-outputs.npz'))==d['output_sha256'] and d['actual_input_sha256']==ref['actual_operand_archive_sha256']
    with np.load(tmp/(name+'-outputs.npz'),allow_pickle=False) as z:out[name]={k:z[k] for k in z.files}
with np.load(tmp/'actual-operands.npz',allow_pickle=False) as z:inputs={k:z[k] for k in z.files}
checks=[]
for name in ['cuda','jax']:
    actual=out[name][name+'-input'];expected=inputs[name+'-expected-original-heat'];assert actual.shape==expected.shape==(4,77) and actual.dtype==expected.dtype==np.dtype('float32') and actual.tobytes()==expected.tobytes();checks.append(dict(kind='ownactualall77 reproducesfullfused original',backend=name,columns=4,raw_fields_per_column=77,maximum_absolute_difference=0.0))
for name in ['cuda','jax']:
    x,y=out['cuda'][name+'-input'],out['jax'][name+'-input'];assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes();checks.append(dict(kind='sameactualinputbothbackends all77bitwise',actual_input_source=name,columns=4,raw_fields_per_column=77,maximum_absolute_difference=0.0))
x,y=out['cuda']['cuda-input'],out['jax']['jax-input'];differences=[]
for col,k in np.argwhere(x.view(np.uint32)!=y.view(np.uint32)):
    differences.append(dict(column=int(col),raw_field=int(k),cuda=float(x[col,k]),jax=float(y[col,k]),absolute_difference=abs(float(x[col,k])-float(y[col,k]))))
assert any(x['column']==3 and x['raw_field']==45 and x['absolute_difference']==1.52587890625e-5 for x in differences)
outcome=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-started,passed=True,source_manifest_sha256=ref['source_manifest_sha256'],device_export_sha256=sha(a),actual_input_sha256=ref['actual_operand_archive_sha256'],actual_operand_differences=ref['actual_operand_differences'],checks=checks,original_diagonal_output_differences=differences,causal_actual_first_snow_thickness_difference_established=True,production_original_k78_fixed=False,scope='Bothoriginalwhole345fidelity proofs/actualreturnedinputassociation precede exact2x2 replay. All4x77 owninputstandalone outputs reproducefused originals bitwise; bothbackends all4x77 exacton eithercommonactualinput. Soleactualoperanddifference therefore causesoriginalHaMheatresidual mismatch. No productioninput/rounding/formula/gate/source changes, not fullK78closure; nextlocate upstreamsnowthickness arithmetic against NumPyreference.')
(r/'audit.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)

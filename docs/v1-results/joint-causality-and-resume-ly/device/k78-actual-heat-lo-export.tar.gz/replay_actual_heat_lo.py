from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-actual-heat-matrix-lo';s=Path('/tmp/noahmp-k78-corrected-js/source');backend=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert backend in ['cuda','jax'] and len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src')]
ref=json.loads((r/'numpy-reference-receipt.json').read_text());assert ref['passed'] and ref['only_first_snow_thickness_differs'] and ref['source_manifest_sha256']==manifest and sha(r/'actual-operands.npz')==ref['actual_operand_archive_sha256'];z=np.load(r/'actual-operands.npz',allow_pickle=False);outputs={};started=time.monotonic();failure=None;barrier=False
try:
    if backend=='cuda':
        import cupy as cp
        from noahmp_clm.gpu.cuda.column_heat import _kernel
        for name in ['cuda','jax']:
            c,p,bc=[cp.ascontiguousarray(cp.asarray(z[name+'-'+k],cp.float32)) for k in ['cells','props','boundary']];o=cp.ascontiguousarray(cp.asarray(z[name+'-options'],cp.int32));out=cp.empty((4,77),cp.float32);_kernel()((1,),(64,),(c,p,o,bc,out,np.int32(4)));outputs[name+'-input']=cp.asnumpy(out)
        cp.cuda.runtime.deviceSynchronize();barrier=True
    else:
        import jax
        import jax.numpy as j
        from noahmp_clm.gpu.column_heat import _compiled
        assert jax.default_backend()=='gpu'
        for name in ['cuda','jax']:
            c,p,o,bc=[j.asarray(z[name+'-'+k]) for k in ['cells','props','options','boundary']];out=_compiled()(c,p,o,bc);out=j.concatenate(out,axis=1);out.block_until_ready();outputs[name+'-input']=np.asarray(out)
        jax.effects_barrier();barrier=True
    np.savez_compressed(r/(backend+'-outputs.npz'),**outputs)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/(backend+'-traceback.txt')).write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(backend=backend,failure=failure,source_unchanged=unchanged,source_manifest_sha256=manifest,device_barrier_complete=barrier,actual_input_sha256=sha(r/'actual-operands.npz'),output_sha256=sha(r/(backend+'-outputs.npz')) if outputs and (r/(backend+'-outputs.npz')).exists() else None,seconds=time.monotonic()-started,scope='OriginalJN standalone jointheat, both exactactualCUDA/JAX wholefused operands after both345bitproofs and EHPC1419 originalNumPy reference. No NumPyforwardphysics onxuanze, adjustedinput/formula/gate or productionmutation. Exactall77 reproduction and causal2x2 checks deferredtoEHPC; compute0 alone isnotK78 closure.')
(r/(backend+'-receipt.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barrier else 1)

from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for backend in ['cuda','jax']:
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:break
        time.sleep(20.)
    with (r/(backend+'-worker.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'replay_actual_heat_lo.py'),backend],stdout=log,stderr=subprocess.STDOUT)
    (r/(backend+'-worker.json')).write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();q=r/(backend+'-receipt.json');d=json.loads(q.read_text()) if q.exists() else {};v=dict(backend=backend,actual_parent_returncode=code,passed=bool(code==0 and d.get('failure') is None and d.get('source_unchanged') and d.get('device_barrier_complete')),receipt_sha256=sha(q) if q.exists() else None);(r/(backend+'-exit.json')).write_text(json.dumps(v,indent=2)+'\n');records.append(v)
    if not v['passed']:break
(r/'exit.json').write_text(json.dumps(dict(records=records,passed=len(records)==2 and all(x['passed'] for x in records)),indent=2)+'\n');raise SystemExit(0 if len(records)==2 and all(x['passed'] for x in records) else 1)

from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,sys,tarfile,time
b=Path('/home/zhangyq/noahmp-v1');payload={};sha=lambda raw:hashlib.sha256(raw).hexdigest();root=b/'k78-actual-heat-audit-lw';status=subprocess.check_output(['qstat','-xf','1532.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M) and (root/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((root/'audit.json').read_text());assert d['passed'] and d['causal_actual_first_snow_thickness_difference_established'] and not d['production_original_k78_fixed']
for p in sorted(root.iterdir()):
    if p.is_file():payload['actual-heat-audit/'+p.name]=p.read_bytes()
payload['actual-heat-audit/actual-pbs-qstat.txt']=status.encode();a=b/'k78-actual-heat-lo-export.tar.gz';assert sha(a.read_bytes())==d['device_export_sha256'];payload['device/'+a.name]=a.read_bytes();chain=b/'hrldas-current-year-lq';sys.path.insert(0,str(chain))
from append_journal_lp import Journal
heads=json.loads((chain/'dispatch-complete.json').read_text())['first_jobs'];records=[]
for row in heads:
    q=subprocess.check_output(['qstat','-xf',row['pbs_job']],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M)
    p=chain/row['site']/'journal.bin'
    for attempt in range(5):
        try:j=Journal(p);break
        except AssertionError:
            if attempt==4:raise
            time.sleep(.2)
    receipt=json.loads(j.read('segment/384')['receipt.json']);assert receipt['pbs_job']==row['pbs_job'] and receipt['actual_stop']==432 and receipt['failure'] is None and receipt['source_unchanged'] and receipt['first_tendency_fullstate_exact'];offset,n,_=j.index['segment/384']
    with p.open('rb') as stream:raw=stream.read(offset+n)
    payload['successful432/'+row['site']+'/journal-prefix.bin']=raw;payload['successful432/'+row['site']+'/actual-pbs-qstat.txt']=q.encode();payload['successful432/'+row['site']+'/receipt.json']=(json.dumps(receipt,indent=2)+'\n').encode();records.append(dict(site=row['site'],job=row['pbs_job'],actual_exit=0,seconds=receipt['seconds'],report_sha256=receipt['report_sha256'],journal_prefix_sha256=sha(raw)))
for n in ['run_hrldas_year_lq.py','append_journal_lp.py','protocol.json','jobs.json','dispatch-complete.json','release.json']:payload['current-chain/'+n]=(chain/n).read_bytes()
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_heat_audit='1532.manager',actual_heat_audit_exit=0,actual_successful432=records,scope='LW actualF0 provesoriginalheat2x2 causalactualfirstsnowthickness input difference. OriginalK78productionstillfailed, nosource/input/gate changes. Allthree LQ first384to432 actualF0/sourceunchanged/fullstateexact, verifiedstablejournalprefixes through only successfulsegment; successorlive years remainincomplete. No annual/spinup/scientific/releasepass.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();payload['control/'+Path(__file__).name]=Path(__file__).read_bytes();target=b/'joint-causality-and-resume-ly-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for m in tf:assert tf.extractfile(m).read()==payload[m.name]
out=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'joint-causality-and-resume-ly-package.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

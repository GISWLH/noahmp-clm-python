from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-snow-reference-es';assert not r.exists();r.mkdir();controls={}
for n in ['reference_k78_snow_es.py','k78_snow_reference_es.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'k78_snow_reference_es.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='Queued independentNumPy/Decimal80 primitive reference onEHPCcompute, originalK78forcing/groundice unchanged. Not execution/wholeK78/pass.');(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

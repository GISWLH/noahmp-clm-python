from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-snow-reference-es';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged'] and d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and sha(r/'reference.npz')==d['reference_sha256'];items=[(p,'reference/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['dispatch_k78_snow_reference_es.py',Path(__file__).name]);a=b/'k78-snow-reference-es-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

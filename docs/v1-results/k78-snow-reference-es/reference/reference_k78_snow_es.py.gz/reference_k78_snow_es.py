from pathlib import Path
from decimal import Decimal,localcontext
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-snow-reference-es';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-phase-descent-ec-source.tar.gz';assert sha(a)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==571 and sha(s/'SOURCE_SHA256.json')=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s/'src')]
from noahmp_clm.physics.snow_evolution import fresh_snow_properties
old=b/'k78-current-b/device';p=old/'input.npz';assert sha(p)=='957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
with np.load(p,allow_pickle=False) as z:forcing=z['forcing'].copy()
values={};input_hashes={'input.npz':sha(p)}
for name in ['cuda32','jax32']:
    p=old/name/'output.npz';d=json.loads((old/name/'receipt.json').read_text());assert d['failure'] is None and sha(p)==d['result']['output_sha256'];input_hashes[name+'/output.npz']=sha(p)
    with np.load(p,allow_pickle=False) as z:values[name]=[z['canopy_interception/ledger/'+k].copy() for k in ['ground_ice_kgm2','ground_ice_enthalpy_jm2']]
assert all(x.tobytes()==y.tobytes() for x,y in zip(values['cuda32'],values['jax32']));mass,heat=values['cuda32'];offset32=np.asarray(forcing[:,1]-np.float32(273.15),np.float32);start=time.monotonic()
def high_density(offset,wind):
    D=Decimal
    with localcontext() as ctx:
        ctx.prec=80;t=D.from_float(float(offset));u=D.from_float(float(wind));x=max(min(t,D(2))+D(15),D(0))
        thermal=D(50)+D('1.7')*x*x.sqrt() if t>D(-15) else -D('3.833')*t-D('.0333')*t*t
        exponential=(D(2)*u/D(5)).exp();tanh=(exponential-D(1))/(exponential+D(1));base=(D(1)+tanh)/D(2);loading=D('266.861')*(D('8.8')*base.ln()).exp() if u>D('.1') else D(0)
        return min(max(thermal+loading,D(30)),D(917))
rows=[];decimal_quantized=[];decimal_physical=[];production_density,production_radius=fresh_snow_properties(forcing[:,1].astype(float),forcing[:,3].astype(float))
for i in range(len(forcing)):
    q=high_density(offset32[i],forcing[i,3]);physical=high_density(float(forcing[i,1])-273.15,forcing[i,3]);decimal_quantized.append(float(q));decimal_physical.append(float(physical));density32=np.float32(q);amount=np.float32(mass[i])
    with localcontext() as ctx:
        ctx.prec=80;ratio=Decimal.from_float(float(amount))/Decimal.from_float(float(density32));nearest=np.float32(float(ratio))
    reciprocal=np.float32(amount*np.float32(np.float32(1.)/density32));rows.append(dict(column=i,tair_k=float(forcing[i,1]),offset32_k=float(offset32[i]),wind_ms=float(forcing[i,3]),ground_ice_kgm2=float(amount),density_decimal80_physical=float(physical),density_decimal80_quantized_offset=float(q),density_round32=float(density32),density_round32_bits=int(density32.view(np.uint32)),fresh_depth_nearest32=float(nearest),fresh_depth_nearest32_bits=int(nearest.view(np.uint32)),fresh_depth_reciprocal_multiply32=float(reciprocal),fresh_depth_reciprocal_multiply32_bits=int(reciprocal.view(np.uint32))))
assert np.max(abs(production_density-np.asarray(decimal_physical)))<1e-10
np.savez_compressed(r/'reference.npz',forcing=forcing,ground_ice=mass,ground_ice_enthalpy=heat,offset32=offset32,density_decimal80_quantized_offset=np.asarray(decimal_quantized),density_decimal80_physical=np.asarray(decimal_physical),production_numpy_density=production_density,production_numpy_radius=production_radius)
d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),input_sha256=input_hashes,rows=rows,maximum_numpy_density_difference_from_decimal80=float(np.max(abs(production_density-np.asarray(decimal_physical)))),reference_sha256=sha(r/'reference.npz'),seconds=time.monotonic()-start,scope='IndependentEHPC NumPyproductionfreshsnow plus separatelywritten Decimal80 algebra and quantifiednearest32/reciprocaldivision, originalK78forcing/commonpreinterceptiongroundice. Referenceprepared independently before currentERGPU exports, no model/source/inputs/gates edit. Not wholeK78/rootcause/parity/year/scienceacceptance.')
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert d['source_unchanged']

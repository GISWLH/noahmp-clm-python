"""After PBS25 is terminal, finish only a missing day, preserving its old directory."""
from pathlib import Path
import json,os,shutil,subprocess,sys,time
root=Path('/home/zhangyq/noahmp-v1/fluxnet-first-climate-cycle-20261017-f')
source=Path('/home/zhangyq/noahmp-v1/p6-heat-coordinate-d');exe='/home/zhangyq/venvs/noahmp-closeout/bin/python'
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_column import source_hashes
current=source_hashes();completed=[]
for c in json.loads((root/'batch.json').read_text())['cases']:
    folder=root/'numpy-day'/c['case'];report=json.loads((folder/'report.json').read_text())
    assert report['source_sha256']==current
    if report['steps_completed']==48:
        completed.append(dict(case=c['case'],action='reuse completed original48'));continue
    assert report['steps_completed']==0,report['steps_completed']
    archive=root/'first-day-attempt-a'/c['case'];archive.parent.mkdir(exist_ok=True)
    assert not archive.exists() and folder.resolve().is_relative_to(root.resolve())
    folder.rename(archive)
    command=[exe,'-u','benchmarks/run_fluxnet_column.py','--input',c['input'],'--input-manifest',c['input_manifest'],
        '--config',c['configuration'],'--output',str(folder),'--stop-after','48']
    with (root/(c['case']+'-first-day-retry.log')).open('wb') as log:
        code=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
    completed.append(dict(case=c['case'],action='cold-start missing original day after terminal PBS25',returncode=code))
    assert code==0,completed
snapshot=root/'numpy-first-day';assert not snapshot.exists();snapshot.mkdir()
for c in json.loads((root/'batch.json').read_text())['cases']:
    folder=root/'numpy-day'/c['case'];report=json.loads((folder/'report.json').read_text())
    assert report['steps_completed']==48 and report['source_sha256']==current
    shutil.copytree(folder,snapshot/c['case'])
(root/'first-day-rescue-exit.json').write_text(json.dumps(dict(status='complete',completed=completed,
    scope='First48-step original sourceD reference; immutable copy before any weekly continuation. PBS25 terminal by afterany dependency.',
    pbs_job=os.environ.get('PBS_JOBID'),source_sha256=current),indent=2)+'\n')
print(json.dumps(completed),flush=True)

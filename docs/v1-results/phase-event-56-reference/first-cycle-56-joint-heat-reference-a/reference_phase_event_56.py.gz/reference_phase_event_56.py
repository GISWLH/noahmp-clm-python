"""Independent float64 solution of every exact quantized captured heat case."""
from pathlib import Path
import hashlib,json,time
import numpy as np
from test_gpu_column_heat import numpy_reference
from run_fluxnet_column import source_hashes
root=Path.cwd();path=root/'qia_phase_event_56_inputs.npz';started=time.monotonic()
with np.load(path,allow_pickle=False) as z:x=dict(z)
enthalpy=[];temperature=[];residual=[];bounds=[]
for c,p,o,b in zip(x['cells'],x['props'],x['options'],x['boundary']):
    h,t,d=numpy_reference(c,p,o,b);n=int(o[0])+4
    incoming=float(b[0])*(d['top_flux_wm2']+float(c[:n,4].astype(float).sum()))
    error=float((h-c[:n,1].astype(float)).sum()-incoming)
    bound=n*d['convergence_tolerance_jm2']+16*np.finfo(float).eps*max(abs(h).sum()+abs(c[:n,1]).sum()+abs(incoming),1.)
    assert abs(error)<=bound
    enthalpy.append(h);temperature.append(t);residual.append(error);bounds.append(bound)
np.savez_compressed(root/'numpy-reference.npz',enthalpy=np.stack(enthalpy),temperature=np.stack(temperature))
out=dict(scope='Independent NumPy64 on EHPC, exact quantized original failing joint-heat inputs.',
    input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_sha256=source_hashes(),
    reference_sha256=hashlib.sha256((root/'numpy-reference.npz').read_bytes()).hexdigest(),rows=len(enthalpy),
    energy_residual=residual,energy_bound=bounds,seconds=time.monotonic()-started)
(root/'numpy-reference.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='source_sha256'}),flush=True)

"""Read-only original 2640-step C/N audit and fixed-period diagnostics on PBS."""
from pathlib import Path
from datetime import datetime
import calendar
import gzip
import hashlib
import itertools
import json
import os
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
begun = time.monotonic()
base = Path('/home/zhangyq/noahmp-v1')
stage = Path('/tmp/noahmp-soc-prefix-nj')
root = stage / 'result'
tmp = Path(os.environ['TMPDIR'])
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
packs = {
    'source': ('clm-ballberry-jn-source.tar.gz', '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'),
    'cold': ('ballberry-climatology-cuda-jt-evidence.tar.gz', '040aa4fba7864879c4be031e8774a4009706ef024d873c08416365b1ce6d0a9b'),
    'failed': ('climatology-failed-year-mh-export.tar.gz', 'f728890bfe81cddae1d85ae2effa69e4eb541b6f1e9ba12b335f90374d098340'),
}
for label, (name, digest) in packs.items():
    archive = base / name
    assert sha(archive) == digest
    (tmp / label).mkdir()
    with tarfile.open(archive) as tf:
        tf.extractall(tmp / label, filter='data')
source, cold, failed = tmp / 'source', tmp / 'cold/current', tmp / 'failed'
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
manifest_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 581 and manifest_sha == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert all(sha(source / n) == digest for n, digest in manifest.items())
assert sha(stage / 'audit_bgc_stream_km.py') == '5c461e2b9a50469e34a764b796366e19c0aba9322297f3611ac0d730ebd8f4b2'
sys.path[:0] = [str(stage), str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_native as native
from audit_bgc_stream_km import audit_stream, cold_rows
from noahmp_clm.physics.decomposition import DecompositionParameters, POOLS

snapshot = json.loads((failed / 'snapshot.json').read_text())
parent = json.loads((failed / 'actual-year-parent/exit.json').read_text())
assert snapshot['actual_year_parent_returncode'] == parent['actual_parent_returncode'] == 1 and not parent['passed']
assert snapshot['completed_intervals'] == 2657 and snapshot['closed_bgc_last_index'] == 2640
assert snapshot['closed_bgc_chunk_count'] == 54 and snapshot['closed_continued_bgc_steps'] == 2592
assert snapshot['unpersisted_bgc_buffer_after2640_steps'] == 17
assert (failed / 'source/SOURCE_SHA256.json').read_bytes() == (source / 'SOURCE_SHA256.json').read_bytes()
cp = json.loads((cold / 'exit.json').read_text())
cr = json.loads((cold / 'receipt.json').read_text())
assert cp['passed'] and cp['actual_parent_returncode'] == 0 and cp['receipt_sha256'] == sha(cold / 'receipt.json')
assert cr['failure'] is None and cr['source_unchanged'] and cr['device_barrier_complete'] and cr['source_manifest_sha256'] == manifest_sha
cases = native.load_batch(failed / 'inputs/batch.json')
assert len(cases) == 12 and native.native_state_count(cases) == 16
cold_cases = native.load_batch(cold / 'inputs/batch.json')
assert len(cold_cases) == 12
for a, b in zip(cases, cold_cases):
    assert a['case'] == b['case'] and a['config'] == b['config']
    assert all(sha(a['paths'][n]) == sha(b['paths'][n]) for n in ['input','input_manifest','configuration'])
with np.load(cold / 'inputs/cold-reference.npz', allow_pickle=False) as z:
    initial = dict(z)
evidence = {'cold-reference.npz': sha(cold / 'inputs/cold-reference.npz'),
            'original-year-parent-exit.json': sha(failed / 'actual-year-parent/exit.json'),
            'original-snapshot.json': sha(failed / 'snapshot.json')}
year_receipt = json.loads((failed / 'model-root/year-receipt.json').read_text())
chunks = year_receipt['bgc_diagnostic_chunks']
assert len(chunks) == 54 and year_receipt['bgc_diagnostic_steps'] == 2592
def continued():
    for j, chunk in enumerate(chunks):
        first, end = 48 + 48*j, 96 + 48*j
        assert chunk['first'] == first and chunk['end'] == end
        path = failed / 'closed-bgc-chunks' / ('steps-' + str(first).zfill(7) + '-' + str(end).zfill(7) + '.npz')
        assert sha(path) == chunk['sha256']
        evidence['closed-bgc-chunks/' + path.name] = sha(path)
        with np.load(path, allow_pickle=False) as z:
            data = dict(z)
        assert all(v.shape[0] == 48 for v in data.values())
        for j in range(48):
            yield first + j, {n:v[j] for n,v in data.items()}
records = list(itertools.chain(cold_rows(cold), continued()))
assert len(records) == 2640
for index in range(48):
    n = 'steps/call-' + str(index).zfill(5) + '.npz'
    evidence['cold/' + n] = sha(cold / n)
traces = []
final = None
for k, c in enumerate(cases):
    folder = failed / 'reported2640' / c['case']
    rp = list(folder.glob('report-0002640-*.json')); assert len(rp) == 1
    report = json.loads(rp[0].read_text())
    desc = snapshot['reported_successful2640'][k]
    assert desc['case'] == c['case'] and sha(rp[0]) == desc['report_sha256']
    assert report['status'] == 'running' and report['steps_completed'] == 2640 and report['steps_requested'] == 17520
    assert report['configuration'] == c['config'] and report['source_sha256'] == native.source_hashes()
    for key, n in [('forcing_npz_sha256','input'), ('forcing_manifest_sha256','input_manifest'), ('configuration_sha256','configuration')]:
        assert report[key] == sha(c['paths'][n])
        evidence[c['case'] + '/' + n] = sha(c['paths'][n])
    tp = folder / report['model_npz']; sp = folder / report['batch_checkpoint_file']
    assert sha(tp) == report['model_npz_sha256'] and sha(sp) == report['batch_checkpoint_sha256'] == desc['checkpoint_sha256']
    evidence[c['case'] + '/report'] = sha(rp[0]); evidence[c['case'] + '/trace'] = sha(tp)
    evidence['checkpoint2640'] = sha(sp)
    with np.load(tp, allow_pickle=False) as z: traces.append(dict(z))
    if final is None:
        with np.load(sp, allow_pickle=False) as z: final = dict(z)
    assert list(traces[-1]['time_start']) == list(c['data']['time_start'][:2640])
    assert list(traces[-1]['time_end']) == list(c['data']['time_end'][:2640])
audit = audit_stream(iter(records), cases, initial, final, traces, 2640)
assert audit['physical_column_steps'] == 31680 and not audit['complete_calendar_year']
(root / 'original-cn-audit.json').write_text(json.dumps(audit, indent=2, allow_nan=False) + '\n')

keys = set(records[0][1])
assert all(set(row) == keys for _, row in records)
stack = {n:np.stack([row[n] for _,row in records]) for n in keys}
def stats(x):
    x = np.asarray(x, float)
    assert x.size and np.isfinite(x).all()
    return dict(minimum=float(x.min()), mean=float(x.mean()), maximum=float(x.max()))
def stock(before, after, take):
    old = np.asarray(before[take[0]], float); new = np.asarray(after[take[-1]], float)
    return dict(initial=old.tolist(), final=new.tolist(), change=(new-old).tolist())
details = []
summary_rows = []
for k, c in enumerate(cases):
    config = c['config']
    assert config['column']['options'].get('OptWetlandModel', 0) == 0 and config['column']['options'].get('OptCropModel', 0) == 0
    stamps = np.asarray(c['data']['time_start'][:2640], str)
    ends = np.asarray(c['data']['time_end'][:2640], str)
    assert stamps[0][4:] == '01010000' and ends[-1][4:] == '02250000'
    data = {n:v[:,k] for n,v in stack.items()}
    assert np.all(data['forcing'][:,0] == 1800.)
    npp = data['bgc/allocation/gpp_gc_m2'].astype(float) - data['bgc/allocation/autotrophic_respiration_gc_m2'].astype(float)
    dimensions = {
        'decomposition_n_factor':'bgc/decomposition/nitrogen_limitation',
        'leaf_n_factor_used':'bgc/nitrogen_factor_used',
        'leaf_n_factor_after':'bgc/nitrogen_factor_after',
        'soil_temperature_k':'bgc/environment/soil_temperature',
        'water_potential_mpa':'bgc/environment/water_potential_mpa',
        'normal_rate_multiplier':'bgc/decomposition/rate_multiplier',
    }
    def period(take, label, kind):
        first = datetime.strptime(stamps[take[0]], '%Y%m%d%H%M')
        expected = 48 if kind == 'day' else 48*calendar.monthrange(first.year, first.month)[1] if kind == 'month' else len(take)
        sums = {name:float(np.asarray(data[key][take],float).sum()) for name,key in {
            'gpp_gc_m2':'bgc/allocation/gpp_gc_m2', 'ra_gc_m2':'bgc/allocation/autotrophic_respiration_gc_m2',
            'rh_gc_m2':'bgc/decomposition/heterotrophic_respiration_gc_m2', 'n_deposition_gn_m2':'nitrogen',
            'plant_n_demand_gn_m2':'bgc/allocation/soil_n_demand_gn_m2', 'plant_n_uptake_gn_m2':'bgc/allocation/soil_n_uptake_gn_m2',
            'mineralization_gn_m2':'bgc/decomposition/gross_mineralization_gn_m2', 'immobilization_gn_m2':'bgc/decomposition/immobilization_gn_m2'}.items()}
        sums.update(npp_gc_m2=float(npp[take].sum()), litter_carbon_seven_pools_gc_m2=np.asarray(data['bgc/turnover/litter_carbon_gc_m2'][take],float).sum(axis=0).tolist(),
                    litter_nitrogen_seven_pools_gn_m2=np.asarray(data['bgc/turnover/litter_nitrogen_gn_m2'][take],float).sum(axis=0).tolist())
        return dict(label=label, kind=kind, intervals=len(take), expected_intervals=expected,
                    complete_calendar_period=kind != 'prefix' and len(take)==expected,
                    start=str(stamps[take[0]]), end_exclusive=str(ends[take[-1]]),
                    integrals_over_provided_intervals=sums,
                    ranges={n:stats(data[key][take]) for n,key in dimensions.items()},
                    n_limited_intervals=int(np.count_nonzero(data[dimensions['decomposition_n_factor']][take] < 1.)),
                    soil_carbon_seven_gc_m2=stock(data['before_soil_cn'][:,:7], data['after_soil_cn'][:,:7], take),
                    soil_organic_n_seven_gn_m2=stock(data['before_soil_cn'][:,7:14], data['after_soil_cn'][:,7:14], take),
                    mineral_n_gn_m2=stock(data['before_soil_cn'][:,14], data['after_soil_cn'][:,14], take),
                    plant_tissue_and_reserve_cn=stock(data['before_plant'], data['after_plant'], take))
    daily = [period(np.flatnonzero(np.char.startswith(stamps,label)), label, 'day') for label in sorted(set(v[:8] for v in stamps))]
    monthly = [period(np.flatnonzero(np.char.startswith(stamps,label)), label, 'month') for label in sorted(set(v[:6] for v in stamps))]
    assert len(daily)==55 and all(q['complete_calendar_period'] for q in daily)
    assert len(monthly)==2 and monthly[0]['complete_calendar_period'] and not monthly[1]['complete_calendar_period']
    whole = period(np.arange(2640), 'original_complete_55_days', 'prefix')
    # Independent algebra at the ORIGINAL before state; never propagate its prediction.
    p = DecompositionParameters(**config['biogeochemistry']['decomposition_parameters'])
    route = np.zeros((7,7)); route[4,0]=.45; route[4,1]=.5; route[5,2]=.5
    route[1,3]=p.wood_cellulose_fraction; route[2,3]=1.-p.wood_cellulose_fraction
    route[5,4]=1.-(.17+.68*p.sand_fraction)-.004; route[6,4]=.004
    route[4,5]=.42; route[6,5]=.03; route[4,6]=.45
    modifier = np.asarray(data['bgc/decomposition/rate_multiplier'],float)
    fraction = -np.expm1(-modifier[:,None]*1800./(np.asarray(p.turnover_years)*31536000.))
    c0 = np.asarray(data['before_soil_cn'][:,:7],float) + np.asarray(data['bgc/turnover/litter_carbon_gc_m2'],float)
    loss = c0*fraction
    predicted = c0 - loss + loss@route.T
    actual = np.asarray(data['after_soil_cn'][:,:7],float)
    take = np.flatnonzero(data['bgc/decomposition/nitrogen_limitation'] == np.float32(1.))
    delta = predicted[take]-actual[take]
    op = dict(eligible_actual_n_factor_one_intervals=len(take), excluded_n_limited_intervals=2640-len(take),
              maximum_absolute_pool_difference_gc_m2=float(abs(delta).max()) if len(take) else None,
              per_pool_maximum_absolute_difference_gc_m2=abs(delta).max(axis=0).tolist() if len(take) else None,
              original_cn_bounds_are_not_per_pool_accuracy_gates=True,
              interpretation='Independent float64 seven-pool one-step algebra uses original before C, original step litter, saved actual normal-rate modifier and original parameters/dt. Each prediction discarded; no forward trajectory, N bypass, annual operator, periodic point or initializer. Raw finite-precision differences are reported without a new pass gate.')
    row = dict(case=c['case'], site=config['site'], prefix=whole, daily=daily, monthly=monthly,
               original_cn_audit=audit['cases'][k], conditional_one_step_algebra=op,
               complete_calendar_year=False, periodic_carbon_initialization_eligible=False)
    details.append(row)
    small = dict(case=c['case'], original_cn_audit=audit['cases'][k], ranges=whole['ranges'],
                 n_limited_intervals=whole['n_limited_intervals'],
                 initial_final_mineral_n_gn_m2=whole['mineral_n_gn_m2'],
                 actual_prefix_integrals=whole['integrals_over_provided_intervals'], conditional_one_step_algebra=op,
                 complete_days=55, complete_months=1, partial_month_intervals=monthly[1]['intervals'])
    summary_rows.append(small)
    print(json.dumps(dict(case=c['case'], n_limited_intervals=whole['n_limited_intervals'], soil_C_window_change_percent=audit['cases'][k]['actual_window_soc_change_percent'], algebra_max_abs_gc_m2=op['maximum_absolute_pool_difference_gc_m2'])), flush=True)
scope = 'Read-only original JN twelve-case 2640-step prefix; cold48 plus54 closed continuation chunks2592, 31680 actual column records, 55 complete days/one January/partial February. Original failed year parent1 at2657 unchanged; last17 raw BGC rows absent and excluded. No forward model, repeated climate year, changed source/parameter/state/rate/precision/gate, periodic point, initializer or scientific/SOC acceptance.'
raw = (json.dumps(dict(scope=scope, pool_names=list(POOLS), plant_packed_order=['leaf_C','stem_C','root_C','leaf_N','stem_N','root_N','reserve_C','reserve_N'], cases=details), indent=2, allow_nan=False)+'\n').encode()
compressed = gzip.compress(raw, mtime=0)
assert gzip.decompress(compressed)==raw
(root/'diagnostic.json.gz').write_bytes(compressed)
unchanged = all(sha(source/n)==digest for n,digest in manifest.items()) and all(sha(base/name)==digest for name,digest in packs.values())
assert unchanged
receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, diagnostic_delivered=True,
               source_manifest_sha256=manifest_sha, source_and_original_archives_unchanged=unchanged,
               original_year_actual_parent_returncode=1, original_requested_steps=17520, audited_steps=2640,
               cold_steps=48, closed_continued_chunks=54, closed_continued_steps=2592, excluded_unpersisted_steps=17,
               all12_original_cn_audit_passed=True, original_cn_audit_sha256=sha(root/'original-cn-audit.json'),
               diagnostic_sha256=sha(root/'diagnostic.json.gz'), diagnostic_uncompressed_sha256=hashlib.sha256(raw).hexdigest(),
               inputs={name:digest for name,digest in packs.values()}, artifact_input_sha256=evidence,
               controls_sha256={n:sha(stage/n) for n in ['audit_soc_prefix_nj.py','audit_bgc_stream_km.py']},
               complete_calendar_year=False, periodic_carbon_initialization_eligible=False,
               actual_100_year_soil_carbon_drift_measured=False, seconds=time.monotonic()-begun,
               scope=scope, cases=summary_rows)
(root/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
(root/'summary.json').write_text(json.dumps({k:v for k,v in receipt.items() if k not in ['artifact_input_sha256','cases']} | dict(cases=[dict(case=q['case'],ranges=q['ranges'],n_limited_intervals=q['n_limited_intervals'],mineral_n=q['initial_final_mineral_n_gn_m2'],operator=q['conditional_one_step_algebra']) for q in summary_rows]),indent=2,allow_nan=False)+'\n')

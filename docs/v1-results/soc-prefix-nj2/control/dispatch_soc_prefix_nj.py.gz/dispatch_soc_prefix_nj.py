from pathlib import Path
import hashlib
import json
import subprocess

stage=Path('/tmp/noahmp-soc-prefix-nj2');root=stage/'result';assert not root.exists();root.mkdir()
names=['audit_soc_prefix_nj.py','audit_bgc_stream_km.py']
for n in names:(root/n).write_bytes((stage/n).read_bytes())
script='''#!/bin/bash
#PBS -N clm-soc-prefix-nj
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=4gb:host=compute002_00260924
#PBS -l walltime=00:15:00
#PBS -j oe
#PBS -o /tmp/noahmp-soc-prefix-nj2/pbs-output.log
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p /tmp/noahmp-soc-prefix-nj2/result
cd /tmp/noahmp-soc-prefix-nj2/result
/home/zhangyq/venvs/noahmp-closeout/bin/python -u /tmp/noahmp-soc-prefix-nj2/audit_soc_prefix_nj.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(root/'job.pbs').write_text(script)
q=subprocess.run(['qsub',str(root/'job.pbs')],cwd=root,capture_output=True,text=True);assert q.returncode==0,q.stderr
record=dict(pbs_job=q.stdout.strip(),controls_sha256={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names+['job.pbs']},storage='Shared HOME read-only; source/input extraction in PBS TMPDIR, result/control in manager/compute002 /tmp. No model step.')
(root/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

b=Path('/tmp/noahmp-soc-prefix-nj2');r=b/'result';label='soc-prefix-nj2'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
launch=json.loads((r/'dispatch.json').read_text());q=subprocess.check_output(['qstat','-xf',launch['pbs_job']],text=True)
assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M)
assert (r/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((r/'receipt.json').read_text())
assert d['diagnostic_delivered'] and d['source_and_original_archives_unchanged'] and d['all12_original_cn_audit_passed']
assert d['audited_steps']==2640 and d['closed_continued_chunks']==54 and len(d['cases'])==12
assert not d['complete_calendar_year'] and not d['periodic_carbon_initialization_eligible']
assert all(sha((r/n).read_bytes())==digest for n,digest in launch['controls_sha256'].items())
assert all(digest==launch['controls_sha256'][n] for n,digest in d['controls_sha256'].items())
assert sha((r/'original-cn-audit.json').read_bytes())==d['original_cn_audit_sha256'] and sha((r/'diagnostic.json.gz').read_bytes())==d['diagnostic_sha256']
payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()}
payload['actual-qstat.txt']=q.encode()
prior=Path('/tmp/noahmp-soc-prefix-nj/result')
prior_q=subprocess.check_output(['qstat','-xf','1582.manager'],text=True)
assert re.search(r'^\s*job_state = F\s*$',prior_q,re.M) and re.search(r'^\s*Exit_status = 1\s*$',prior_q,re.M)
assert (prior/'pbs-exit.txt').read_text().strip()=='1'
payload.update({'prior-attempt-a/'+p.relative_to(prior).as_posix():p.read_bytes() for p in prior.rglob('*') if p.is_file()})
payload['prior-attempt-a/actual-qstat.txt']=prior_q.encode()
for n in ['archive_soc_prefix_nj.py','dispatch_soc_prefix_nj.py']:payload['control/'+n]=(b/n).read_bytes()
payload['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(raw),bytes=len(raw)) for n,raw in payload.items()},indent=2)+'\n').encode()
a=b/(label+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
 for n,raw in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
with tarfile.open(a) as tf:
 assert len(tf.getmembers())==len(payload)
 for m in tf:assert tf.extractfile(m).read()==payload[m.name]
out=dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(payload),scope=d['scope'],pbs_job=launch['pbs_job'],actual_pbs_exit=0)
(b/(label+'-package.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

from pathlib import Path
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-tenday-comparison-ab';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
roots={}
for label,name,expected in [('source','clm-numerical-recovery-c-source.tar.gz','61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'),('cpu','qia-cpu-year-snapshot-aa-evidence.tar.gz','64ff41a5849ac6e3f8032123f02b98a0c8519707f6328dafe1d6ac0984cea734'),('gpu','qia-gpu-year-snapshot-aa-evidence.tar.gz','0a0597497ce8bf3925bdcef4d7f45467d35723cc280e99f08962cc48e2a4927d')]:
    a=b/name;assert sha(a)==expected;p=Path(os.environ['TMPDIR'])/label;p.mkdir();roots[label]=p
    with tarfile.open(a) as tf:tf.extractall(p,filter='data')
s=roots['source'];m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
specs={
'h_wm2':(1.,0.,10.,1.),'le_wm2':(1.,0.,10.,1.),
'gpp_gc_m2':(48.,0.,1.,.1),'nee_gc_m2':(48.,0.,1.,.1),'autotrophic_respiration_gc_m2':(48.,0.,1.,.1),'heterotrophic_respiration_gc_m2':(48.,0.,1.,.1),
'et_mm':(48.,0.,.5,.05),'runoff_mm':(48.,0.,.5,.05),'tsoil_k':(1.,273.15,5.,.5),'smc_m3m3':(1.,0.,.02,.002),'liquid_m3m3':(1.,0.,.02,.002),'swe_m':(1.,0.,.001,.0001),
'lai':(1.,0.,.1,.01),'sai_m2m2':(1.,0.,.1,.01),'canopy_sai_used_m2m2':(1.,0.,.1,.01),'canopy_exposed_lai_m2m2':(1.,0.,.1,.01),'canopy_exposed_sai_m2m2':(1.,0.,.1,.01),
'capacity_daylength_factor':(1.,0.,.01,.001),'capacity_vcmax25_top':(1.,0.,1.,.1),'capacity_nitrogen_extinction':(1.,0.,.01,.001)}
cases=[]
for label in ['capacity','capacity_optics']:
    summary={};failure=None
    try:
        cpu=roots['cpu']/('qia-richards-'+label+'-numpy-year-a');gpu=roots['gpu']/('qia-richards-'+label+'-cuda-year-c');np_report=json.loads((cpu/'trajectory/report.json').read_text());old=json.loads((cpu/'SOURCE_SHA256.json').read_text());common={n:h for n,h in old.items() if (n.startswith('src/') and not n.startswith('src/noahmp_clm/gpu/')) or n.startswith('benchmarks/')}
        assert len(common)==172 and all(m[n]==h for n,h in common.items()) and np_report['source_unchanged'] and np_report['status']=='running' and np_report['steps_completed']==720 and np_report['steps_requested']==17520
        assert all(old[n]==h for n,h in np_report['source_sha256'].items())
        p=cpu/'trajectory'/np_report['model_npz'];assert sha(p)==np_report['model_npz_sha256']
        with np.load(p,allow_pickle=False) as z:reference=dict(z)
        report,saved,rows=native.read_generation(gpu/'trajectory');assert report['identity']['source_sha256']==native.source_hashes() and report['status']=='running' and report['steps_completed']==480 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['ledger_steps']==480
        assert len(rows)==1;case_report,model=rows[0];cfg=case_report['configuration'];oldcfg=np_report['configuration'];different={k for k in cfg if cfg[k]!=oldcfg[k]};assert different<= {'case','scope'} and set(cfg)==set(oldcfg)
        n=480;reference={k:v[:n] for k,v in reference.items()};assert all(len(v)==n for v in model.values()) and all(len(v)==n for v in reference.values())
        for key in ['time_start','time_end']:np.testing.assert_array_equal(model[key],reference[key])
        assert str(model['time_start'][0])=='200301010000' and str(model['time_end'][-1])=='200301110000'
        for name,trace in [('cuda',model),('numpy',reference)]:
            step=trace['step_residual_m_h_c_n'];bound=trace['step_bound_m_h_c_n'];cumulative=trace['cumulative_residual_m_h_c_n'];assert step.shape==bound.shape==cumulative.shape==(n,4) and np.all(abs(step)<=bound) and np.all(abs(cumulative)<=np.cumsum(bound,axis=0))
        bound_sum=np.cumsum(model['step_bound_m_h_c_n'],axis=0)[-1];np.testing.assert_array_equal(saved['bounds'][0],bound_sum);np.testing.assert_array_equal(saved['maximum'][0],abs(model['cumulative_residual_m_h_c_n']).max(0));np.testing.assert_array_equal(saved['stepmax'][0],abs(model['step_residual_m_h_c_n']).max(0))
        independent_final=native.totals(tuple(saved['a'+str(k)] for k in range(23)))-saved['initial']-saved['net'];assert np.all(abs(independent_final)<=saved['bounds']);np.testing.assert_array_equal(independent_final[0],model['cumulative_residual_m_h_c_n'][-1])
        metrics={}
        for key,(scale,offset,floor,absolute) in specs.items():
            a=(model[key].astype(float)-offset)*scale;c=(reference[key].astype(float)-offset)*scale;difference=abs(a-c);limit=np.where(abs(c)<=floor,absolute,.1*abs(c));assert np.all(difference<=limit),(key,float((difference/limit).max()))
            mean=float(c.mean());correlation=float(np.corrcoef(a.ravel(),c.ravel())[0,1]) if a.std()>0 and c.std()>0 else None
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2']:assert correlation is not None and correlation>.85
            metrics[key]=dict(maximum_absolute_difference=float(difference.max()),maximum_gate_ratio=float((difference/limit).max()),signed_mean_bias_percent=100.*float((a-c).mean())/abs(mean) if abs(mean)>floor else None,instantaneous_correlation=correlation)
        for key in ['capacity_mean_temperature_used_k','capacity_next_mean_temperature_k']:
            difference=abs(model[key].astype(float)-reference[key]);assert np.all(difference<=.001);metrics[key]=dict(maximum_absolute_difference=float(difference.max()),fixed_absolute_tolerance_k=.001)
        for key in ['capacity_temperature_count','capacity_temperature_cursor']:np.testing.assert_array_equal(model[key],reference[key]);metrics[key]=dict(integer_exact=True)
        daily=[]
        for day in range(10):
            q=slice(day*48,(day+1)*48);values={}
            for key,floor,absolute in [('h_wm2',10.,1.),('le_wm2',10.,1.),('et_mm',.5,.05),('runoff_mm',.5,.05),('gpp_gc_m2',1.,.1),('nee_gc_m2',1.,.1)]:
                a=float(model[key][q].mean() if key.endswith('wm2') else model[key][q].sum());c=float(reference[key][q].mean() if key.endswith('wm2') else reference[key][q].sum());limit=absolute if abs(c)<=floor else .1*abs(c);assert abs(a-c)<=limit,(day,key,a,c,limit)
                values[key]=dict(model=a,reference=c,absolute_difference=abs(a-c),signed_relative_bias_percent=100.*(a-c)/abs(c) if abs(c)>floor else None,original_gate=limit)
            daily.append(dict(day=day+1,metrics=values))
        summary=dict(passed=True,steps=480,complete_days=10,unchanged_numpy_physics_and_runner_files=172,configuration_differing_metadata_keys=sorted(different),physical_trace_metrics=metrics,daily=daily,maximum_recorded_step_m_h_c_n=abs(model['step_residual_m_h_c_n']).max(0).tolist(),maximum_recorded_cumulative_m_h_c_n=abs(model['cumulative_residual_m_h_c_n']).max(0).tolist(),original_cumulative_bounds=saved['bounds'].tolist(),independent_final_m_h_c_n=independent_final.tolist(),same_precision_max_absolute=None)
    except Exception as e:
        failure=type(e).__name__+': '+str(e);(r/(label+'-traceback.txt')).write_text(traceback.format_exc());summary.update(passed=False,failure=failure)
    summary['case']=label;cases.append(summary)
record=dict(passed=all(x['passed'] for x in cases),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),cases=cases,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,scope='Both prospective originalcold years first480 actual steps /10days CUDA vs independent running NumPy year prefix. Identical172NumPyphysics/runner bytes and nonmetadata configuration verified. All24physicaltraces and10daily metrics retain original first48 10percent/nearzeroabsolute gates, H/LE/GPP/NEE r>.85. Original recorded perstep/cumulative numerical guards and independent final extensive-store ledger checked; not all480 before/after independent audit. No complete17520, JAXsameprecision, spinup, official/observational or multisite scientific acceptance.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True);assert record['passed'] and record['source_unchanged']

"""Reuse a verified complete archive to compact closed diagnostic duplicates."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1').resolve();root=b/'multisite-winter-energy-he';tmp=Path('/tmp/noahmp-closed-winter-mm');assert not tmp.exists();tmp.mkdir(mode=0o700);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();protected={};actual={}
for job in ['826.manager','828.manager']:
    q=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);actual[job]=q
receipt=json.loads((root/'receipt.json').read_text());assert receipt['passed'] and receipt['source_unchanged'] and len(receipt['cases'])==24;package=json.loads((b/'winter-energy-hj-package.json').read_text());archive=b/'winter-energy-hj-evidence.tar.gz';assert sha(archive)==package['archive_sha256'];files=[]
for row in receipt['cases']:
    assert row['failure'] is None and row['captured_steps']==48 and all(row['full_original_trace_fields_byteexact'].values());case=root/row['case'];folder=case/'trajectory';p=folder/'report.json';d=json.loads(p.read_text());assert d['status']=='running' and d['steps_completed']==144 and d['steps_requested']==17520 and d['source_unchanged'];protected[str(p)]=sha(p);protected[str(case/'receipt.json')]=sha(case/'receipt.json')
    for key,digest in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
        p=folder/d[key];assert sha(p)==d[digest];protected[str(p)]=d[digest]
    for name in ['trajectory/state-0000096.pkl','trajectory/trace-0000096.npz','derived-diagnostic-seed-report.json','original-later-model-report.json','successful-pilot-receipt.json','steps.tar.gz','direct-energy-components.json']:
        p=case/name;assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root) and p.stat().st_uid==os.getuid();files.append(p)
assert len(files)==168;inventory={str(p.relative_to(root)):dict(original_absolute_path=str(p),sha256=sha(p),bytes=p.stat().st_size,archive_member='replay/'+p.relative_to(root).as_posix()) for p in files};before=subprocess.check_output(['df','-i',str(b)],text=True)
with tarfile.open(archive) as tf:
    for name,row in inventory.items():
        raw=tf.extractfile(row['archive_member']).read();assert hashlib.sha256(raw).hexdigest()==row['sha256'] and raw==Path(row['original_absolute_path']).read_bytes();p=tmp/'restore'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);assert sha(p)==row['sha256']
assert all(sha(Path(p))==h for p,h in protected.items())
for p in files:
    name=str(p.relative_to(root));assert p.resolve().is_relative_to(root) and sha(p)==inventory[name]['sha256'] and (tmp/'restore'/name).read_bytes()==p.read_bytes();p.unlink()
assert all(sha(Path(p))==h for p,h in protected.items());out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=str(archive),archive_sha256=package['archive_sha256'],closed_files_compacted=168,all_restored_bytes_verified=True,all_latest144_state_trace_reports_and_receipts_unchanged=True,protected_sha256=protected,files=inventory,actual_terminal_job_proofs=actual,before_df_i=before,after_df_i=subprocess.check_output(['df','-i',str(b)],text=True),scope='Only actual826/828F0 closedJan3 diagnostic duplicate packets/96seeds/derivedmetadata/components, all168 bytesmatchedexistingcompleteHJarchive andfullTMPrestore beforeunlink. Latest144/checkpoints/traces/reports/casereceipts, allsource/inputs, activecurrentLQ/GH/GT jobs andallothermodels remain. FullrawHJarchive alreadydurableHOME/publicevidence; no numerical/source/gate/physicalyear changes.')
(tmp/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');(root/'closed-file-archive-mm.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['files','protected_sha256','actual_terminal_job_proofs']}),flush=True)

from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-j';source=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=root/'cuda-annual-launch.json';assert not receipt.exists()
target_path=source/'gpu-target-progress.json';target_raw=target_path.read_bytes();target=json.loads(target_raw)
assert target['status']!='failed'
core=[r for r in target['results'] if r['file']=='tests/test_gpu_most_oscillation.py'];assert len(core)==1
assert core[0]['returncode']==0 and core[0]['source_unchanged'] and core[0]['counts']==dict(tests=3,failures=0,errors=0,skipped=0)
assert all(r['returncode']==0 and r['source_unchanged'] and r['counts']['failures']==r['counts']['errors']==r['counts']['skipped']==0 for r in target['results'])
full_path=source/'full-by-file-a/progress.json';full_raw=full_path.read_bytes();full=json.loads(full_raw)
assert full['collected_nodes']==1105 and all(r['passed'] for r in full['results'])
cpu=json.loads((source/'cpu-full-receipt.json').read_text());assert cpu['returncode']==0 and cpu['counts']==dict(tests=780,failures=0,errors=0,skipped=0) and cpu['source_unchanged']
proof=json.loads((root/'pre-change-i48-comparison.json').read_text());comparison=json.loads((root/'backend-day-comparison.json').read_text());assert proof['all_fields_bitwise_equal'] and not comparison['failures']
archive=base/'most-climate-j-day-a-evidence.tar.gz';assert sha(archive)=='7ec79db4d16f44acf58c5d48ce531e32388710321159ae2082418dba037d6a4f'
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_native import source_hashes,read_generation
report,state,cases=read_generation(root/'cuda-day');assert report['steps_completed']==48 and report['steps_requested']==17520 and report['status']=='running' and report['source_unchanged'] and report['identity']['source_sha256']==source_hashes()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
(root/'gpu-target-before-annual.json').write_bytes(target_raw);(root/'full-suite-before-annual.json').write_bytes(full_raw)
binding=dict(prelaunch_report_sha256=sha(root/'cuda-day/batch.json'),checkpoint_file=report['checkpoint_file'],checkpoint_sha256=report['checkpoint_sha256'],first_day_comparison_sha256=sha(root/'backend-day-comparison.json'),pre_change_comparison_sha256=sha(root/'pre-change-i48-comparison.json'),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),batch_sha256=sha(root/'batch.json'),immutable_first48_archive_sha256=sha(archive),core_target_snapshot_sha256=hashlib.sha256(target_raw).hexdigest(),full_suite_snapshot_sha256=hashlib.sha256(full_raw).hexdigest())
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--resume']
with (root/'cuda-annual-resume.log').open('w') as log:proc=subprocess.Popen(command,cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
value=dict(pid=proc.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,steps_requested=17520,start_from_completed=48,command=command,bindings=binding,
    completed_core_device_tests=3,target_files_completed=len(target['results']),target_total_files=5,full_device_files_completed=full['gpu_files_completed'],full_device_files_total=62,
    scope='Current J continues its own archived and independently validated first48 after the exact I4016 JAX32/64 reference and CUDA32/JAX32 all-field gates passed, with CPU780 complete. Remaining old-MOST target files and complete current325 device tests run concurrently and remain required; no completion/scientific acceptance is claimed. Original failed I unchanged, no source-hash rewrite, no shorter annual request.')
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

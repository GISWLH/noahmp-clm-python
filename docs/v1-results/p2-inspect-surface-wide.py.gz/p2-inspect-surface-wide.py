import sys,numpy as np,json
sys.path.insert(0,'tests')
from test_gpu_canopy_surface import cases
from noahmp_clm.gpu.canopy_surface import run_canopy_surface_jax
x=tuple(a if a.dtype.kind in 'iu' else a.astype(np.float64) for a in cases(np.float32,40))
r=run_canopy_surface_jax(*x,raise_on_failure=False)
bad=np.flatnonzero(~np.asarray(r['converged']));print('BAD',bad,flush=True)
result=[]
for i in bad:
 row={'index':int(i),'inputs':[a[i].tolist() for a in x]}
 for k in ['surface_temperature','surface_temperature_residual','surface_evaluations','iterations','layer_residual','canopy_humidity_change','thermal_layer_residual','thermal_layer_tolerance','soil_cells','snow_counts']:
  row[k]=np.asarray(r[k][i]).tolist()
 result.append(row)
 print(json.dumps(row),flush=True)
open('surface-failures.json','w').write(json.dumps(result,indent=2))

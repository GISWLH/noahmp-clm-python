from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-capacity-comparison-d';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'capacity-station-final-c-source.tar.gz';assert sha(a)=='7341089ec7d992674e0976272dd0b4940e082f9baa7b887649ee1d130a3b4fe5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src')]
from noahmp_clm.validation import compare_series
official=b/'ctsm-qia-run-r';audit=json.loads((official/'year-boundary.json').read_text());assert (official/'pbs-exit.txt').read_text().strip()=='0' and sha(official/'official-year-fields.npz')==audit['fields_sha256']
with np.load(official/'official-year-fields.npz',allow_pickle=False) as z:ref=dict(z)
assert np.array_equal(ref['time_bounds_seconds'][:48],np.arange(48)[:,None]*1800+[[0,1800]])
original=json.loads((b/'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json').read_text());dz=np.asarray(original['column']['dz'],float);te=np.r_[0.,np.cumsum(dz)];se=np.r_[0.,np.cumsum(np.asarray(ref['DZSOI'],float).reshape(15))];overlap=np.maximum(0.,np.minimum(te[1:,None],se[None,1:])-np.maximum(te[:-1,None],se[None,:-1]))/dz[:,None];assert np.max(abs(overlap.sum(1)-1.))<1e-14 and np.all(overlap[:,10:]==0.)
cases={}
for label in ['capacity','capacity_optics']:
    root=b/('qia-'+label+'-firstday-d');receipt=json.loads((root/'receipt.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and receipt['returncode']==0 and receipt['source_unchanged'] and receipt['steps_completed']==48
    folder=root/'trajectory';report=json.loads((folder/'report.json').read_text());assert report['source_unchanged'] and report['status']=='running' and report['steps_completed']==48 and report['forcing_npz_sha256']=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
    p=folder/report['model_npz'];assert sha(p)==report['model_npz_sha256']
    with np.load(p,allow_pickle=False) as z:model={n:np.asarray(v) for n,v in z.items()}
    assert str(model['time_start'][0])=='200301010000' and str(model['time_end'][-1])=='200301020000'
    metrics={}
    for name,source,factor,unit in [('h_wm2','FSH',1.,'h_wm2'),('le_wm2','EFLX_LH_TOT',1.,'le_wm2'),('et_mm','QFLX_EVAP_TOT',86400.,'et_mm_day'),('runoff_mm','QRUNOFF',86400.,'runoff_mm_day'),('gpp_gc_m2','FPSN',12.0107e-6*86400.,'gpp_gc_day'),('swe_m','H2OSNO',.001,'swe_m')]:
        actual=np.asarray(model[name],float).reshape(48)*(48. if name in ['et_mm','runoff_mm','gpp_gc_m2'] else 1.);expected=np.asarray(ref[source][:48],float).reshape(48)*factor;metrics[name]=compare_series(actual,expected,unit,weights=np.full(48,1800.))
    soil_t=np.asarray(ref['TSOI'][:48],float).reshape(48,15)@overlap.T;soil_w=np.asarray(ref['H2OSOI'][:48],float).reshape(48,10)@overlap[:,:10].T
    for name,expected,unit,offset in [('tsoil_k',soil_t,'tsoil_c',273.15),('smc_m3m3',soil_w,'smc',0.)]:
        for layer in range(4):metrics[name+'/'+str(layer)]=compare_series(model[name][:,layer]-offset,expected[:,layer]-offset,unit,weights=np.full(48,1800.))
    cases[label]=dict(status='original-cold48 input diagnostic only',metrics=metrics,configuration=json.loads((root/'config.json').read_text()),trace_sha256=sha(p),report_sha256=sha(folder/'report.json'),configuration_sha256=report['configuration_sha256'],original_maximum_cumulative_MHCN=report['maximum_cumulative_residual_m_h_c_n'])
record=dict(scope='All2 prospectively declared formalC3-capacity cold48 cases, with/without originalPFT opticalfractions. Same535C source, originalforcing/CO2/heights/stores/geometry/window and originalMHCN. All14 exactofficialR48 metrics retained, temperatureCelsius/weighted integrals and fixed10percent/r/nearzero gates. NOAAphotoperiod/causalT10/multilayerN implemented but actualofficialDAYL/accumulator timing, sphericalangles, originalSP/CN/soil/root differences disclosed. Older4-case contrasts retained separately, no defaultselection/calibration/year/spinup/multisite/science acceptance',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),protocol_sha256={label:sha(b/('qia-'+label+'-firstday-d')/'dispatch.json') for label in ['capacity','capacity_optics']},reference_audit_sha256=sha(official/'year-boundary.json'),cases=cases)
(r/'comparison.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pbs_job=record['pbs_job'],source_unchanged=record['source_unchanged'],cases=list(cases))),flush=True)

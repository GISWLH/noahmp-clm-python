from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');data={};jobs=[]
for folder in ['qia-capacity-firstday-d','qia-capacity_optics-firstday-d','qia-capacity-comparison-d']:
    dispatch=json.loads((b/folder/'dispatch.json').read_text());jobs.append(dispatch['pbs_job'])
    data[folder+'/dispatch.json']=(b/folder/'dispatch.json').read_bytes()
    for control,digest in dispatch['controls_sha256'].items():
        raw=(b/folder/control).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest;data['control/'+control]=raw
assert jobs==['308.manager','309.manager','310.manager']
for name,relative in [('original/column-config.json','qia-stem-inputs-a/inputs/CN-Qia-stem-config.json'),
                      ('original/input-manifest.json','qia-stem-inputs-a/inputs/CN-Qia.json'),
                      ('original/physiology.json','ctsm-qia-run-s/physiology-restarts.json'),
                      ('original/optics.json','ctsm-qia-canopy-inputs-w-a/diagnosis.json'),
                      ('original/reference-audit.json','ctsm-qia-run-r/year-boundary.json'),
                      ('source/capacity-station-final-c-package.json','capacity-station-final-c-package.json')]:
    data[name]=(b/relative).read_bytes()
data['control/archive_qia_capacity_protocol_d.py']=Path(__file__).read_bytes()
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Declaredfixed-case protocol/control snapshot for two formalcapacity cold48 trials and dependent all14-metric comparison. No trajectory/score read here, no defaults selected. This is pending experiment evidence, not results or scientific acceptance.',
    jobs=jobs,qstat=subprocess.run(['qstat','-u','zhangyq'],text=True,capture_output=True).stdout,
    source_archive_sha256=hashlib.sha256((b/'capacity-station-final-c-source.tar.gz').read_bytes()).hexdigest(),
    original_forcing_sha256=hashlib.sha256((b/'qia-stem-inputs-a/inputs/CN-Qia.npz').read_bytes()).hexdigest())
data['protocol.json']=(json.dumps(record,indent=2)+'\n').encode();archive=b/'qia-capacity-protocol-d-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for name,raw in data.items():
        info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,utc=record['utc'])))

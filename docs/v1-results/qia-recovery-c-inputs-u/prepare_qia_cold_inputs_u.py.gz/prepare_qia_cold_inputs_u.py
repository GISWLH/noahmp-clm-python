from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-recovery-c-inputs-u';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
archive=b/'clm-numerical-recovery-c-source.tar.gz';assert sha(archive)=='61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());manifest=sha(s/'SOURCE_SHA256.json')
cpu=b/'numerical-recovery-cpu-c';d=json.loads((cpu/'full-receipt.json').read_text());assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1071,failures=0,errors=0,skipped=0) and d['source_manifest_sha256']==manifest
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
out=r/'inputs';out.mkdir();original=b/'qia-stem-inputs-a/inputs';forcing=original/'CN-Qia.npz';assert sha(forcing)=='237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
for name in ['CN-Qia.npz','CN-Qia.json']:(out/name).write_bytes((original/name).read_bytes())
records=[]
for label in ['capacity','capacity_optics']:
    prior=b/('qia-richards-'+label+'-firstday-b');rec=json.loads((prior/'receipt.json').read_text());report=json.loads((prior/'trajectory/report.json').read_text());old=json.loads((prior/'SOURCE_SHA256.json').read_text())
    assert (prior/'pbs-exit.txt').read_text().strip()=='0' and rec['returncode']==0 and rec['source_unchanged'] and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and sha(prior/'trajectory/report.json')==rec['report_sha256']
    common={n:h for n,h in old.items() if (n.startswith('src/') and not n.startswith('src/noahmp_clm/gpu/')) or n.startswith('benchmarks/')};assert len(common)>40 and all(m[n]==h for n,h in common.items())
    q=out/label;q.mkdir();cfg=json.loads((prior/'config.json').read_text());before=json.loads(json.dumps(cfg));cfg['case']=label
    cfg['scope']='Prospectively fixed originalcold2003 request17520, current563C complete1071CPU/formalwaterheat8 and unchangedphaseB4/3803pair. Original successfulNumPyB48 physicalconfig retained except declaredcase/scope metadata. Both capacity and capacity+PFToptics variants kept; originalforcing/heights/stores/traits/roots/CN/VICsurface/zeroverticalRichards unchanged. First48 is an engineering validation segment against prioractualNumPy whose physical+runnerbytes are exactly unchanged; CPU-certified20/23state coldseed and all7ledgerfields, independent step/cumulativeMHCN and allmetrics required before same-own-run continuation. No failedprefix, JAXshadow, defaultselection/calibration, completeyear/spinup/multisite/science claim.'
    assert {n for n in cfg if cfg[n]!=before[n]}=={'case','scope'}
    (q/'config.json').write_text(json.dumps(cfg,indent=2)+'\n');(q/'numpy-config.json').write_bytes((prior/'config.json').read_bytes())
    batch=dict(cases=[dict(case=label,input='../CN-Qia.npz',input_manifest='../CN-Qia.json',configuration='config.json')]);(q/'batch.json').write_text(json.dumps(batch,indent=2)+'\n')
    cases=native.load_batch(q/'batch.json');assert len(cases)==1 and len(cases[0]['stamps'])==17520;count=native.native_state_count(cases);assert count in (20,23)
    env=np.asarray([cases[0]['data']['environment'][0]],np.float32);state=native.build_state(cfg)
    arrays=native.pack_station_arrays([state],count,dtype=np.float32,co2_ppm=env[:,0],cosine_zenith=env[:,1],diffuse_fraction=env[:,2],leaf_dimension=np.asarray([cfg['leaf_dimension_m']],np.float32));assert len(arrays)==count
    zero=np.zeros((1,4));saved={f'a{k}':v for k,v in enumerate(arrays)};saved.update(index=np.array(0),initial=native.totals(arrays),net=zero.copy(),bounds=zero.copy(),maximum=zero.copy(),stepmax=zero.copy(),tracermax=np.zeros((1,5)))
    np.savez_compressed(q/'cold-reference.npz',**saved)
    p=prior/'trajectory'/report['model_npz'];assert sha(p)==report['model_npz_sha256'];(q/'numpy-reference-trace.npz').write_bytes(p.read_bytes())
    for source,target in [('trajectory/report.json','numpy-reference-report.json'),('receipt.json','numpy-reference-receipt.json'),('SOURCE_SHA256.json','numpy-SOURCE_SHA256.json')]: (q/target).write_bytes((prior/source).read_bytes())
    records.append(dict(case=label,configuration_sha256=sha(q/'config.json'),original_configuration_sha256=sha(prior/'config.json'),nonphysical_configuration_changes=['case','scope'],native_state_arrays=count,cold_fields=count+7,cold_sha256=sha(q/'cold-reference.npz'),batch_sha256=sha(q/'batch.json'),numpy_report_sha256=sha(q/'numpy-reference-report.json'),numpy_trace_sha256=sha(q/'numpy-reference-trace.npz'),identical_numpy_physics_and_runner_files=len(common),all_numpy_physics_and_runner_bytes_identical=True))
assert all(sha(s/n)==h for n,h in m.items());(out/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
record=dict(scope='EHPC compute-only original currentC physical cold packing and full successfulB48 reference binding, not a new modeltrajectory or GPU/year/science pass. No parameterchoice or changedphysicalforcing/initialization.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=True,cpu_receipt_sha256=sha(cpu/'full-receipt.json'),forcing_sha256=sha(out/'CN-Qia.npz'),forcing_manifest_sha256=sha(out/'CN-Qia.json'),cases=records,seconds=time.monotonic()-start)
(out/'protocol.json').write_text(json.dumps(record,indent=2)+'\n');(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
a=b/'qia-recovery-c-inputs-u.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(out.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(out).as_posix(),recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,receipt=record)),flush=True)

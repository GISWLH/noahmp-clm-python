from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-recovery-c-inputs-u';d=json.loads((r/'receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged'] and len(d['cases'])==2 and all(x['cold_fields']==30 and x['all_numpy_physics_and_runner_bytes_identical'] for x in d['cases']);a=b/'qia-recovery-c-inputs-u-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['clm-numerical-recovery-c-source.tar.gz','dispatch_qia_cold_inputs_u.py',Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

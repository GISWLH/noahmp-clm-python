"""Extract existing NQ irrigation log numbers and seal its closed raw evidence."""
from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import re
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
LABEL = 'nq-irrigation-closure-pa'
RAW = ROOT / LABEL
STEM = 'test_gpu_clm_irrigation_column'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def maxima(rows):
    return {key: max(row[key] for row in rows if key in row) for key in sorted({k for row in rows for k in row})}


def main():
    names = [STEM + s for s in ['-exit.json', '-receipt.json', '-expected.json', '.log', '.xml']]
    names += ['3799882-cache-events.jsonl', 'SOURCE_SHA256.json', 'plan.json']
    items = {'original/' + name: (RAW / name).read_bytes() for name in names}
    get = lambda name: items['original/' + name]
    parent = json.loads(get(STEM + '-exit.json'))
    receipt = json.loads(get(STEM + '-receipt.json'))
    expected = json.loads(get(STEM + '-expected.json'))
    manifest = json.loads(get('SOURCE_SHA256.json'))
    plan = json.loads(get('plan.json'))
    assert parent['passed'] and parent['actual_parent_returncode'] == 0 and parent['expected_tests'] == 13
    assert sha(get(STEM + '-receipt.json')) == parent['receipt_sha256']
    assert receipt['passed'] and receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0
    assert receipt['counts'] == dict(tests=13, failures=0, errors=0, skipped=0)
    assert receipt['all_setup_call_teardown_phases_passed'] and receipt['node_coverage_exact'] and receipt['source_unchanged']
    assert len(expected) == len(set(expected)) == 13 and receipt['nodes'] == expected
    assert sha(get(STEM + '-expected.json')) == receipt['expected_nodes_sha256']
    assert sha(get(STEM + '.xml')) == receipt['xml_sha256']
    assert sha(get('SOURCE_SHA256.json')) == receipt['source_manifest_sha256'] == plan['source_manifest_sha256']
    assert receipt['source_files'] == len(manifest) == 584
    assert receipt['source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert {v['backend']: v['status'] for v in receipt['device_barriers']} == {'jax': 'complete', 'cupy': 'complete'}
    cases = list(ET.fromstring(get(STEM + '.xml')).iter('testcase'))
    assert len(cases) == 13 and all(c.find(tag) is None for c in cases for tag in ['failure', 'error', 'skipped'])
    timings = {c.attrib['name']: float(c.attrib['time']) for c in cases}
    reference, budgets, same, cuda_budgets = {}, {}, {}, {}
    for line in get(STEM + '.log').decode().splitlines():
        match = re.fullmatch(r"\.*irrigation whole (reference|budgets) (\w+) <class 'numpy\.(float32|float64)'> ([01]) (\{.*\})", line)
        if match:
            category, kind, dtype, step, payload = match.groups()
            target = reference if category == 'reference' else budgets
            key = (dtype, kind, int(step))
            assert key not in target
            target[key] = ast.literal_eval(payload)
            continue
        match = re.fullmatch(r'\.*irrigation whole same precision (\w+) ([01]) ([0-9.eE+\-]+)', line)
        if match:
            kind, step, value = match.groups()
            assert (kind, int(step)) not in same
            same[kind, int(step)] = float(value)
            continue
        match = re.fullmatch(r'\.*irrigation whole CUDA budgets (\w+) ([01]) (\{.*\})', line)
        if match:
            kind, step, payload = match.groups()
            assert (kind, int(step)) not in cuda_budgets
            cuda_budgets[kind, int(step)] = ast.literal_eval(payload)
    kinds = ['layered', 'seasonal', 'bgc', 'crop']
    assert set(reference) == set(budgets) == {(d, k, s) for d in ['float32', 'float64'] for k in kinds for s in range(2)}
    assert set(same) == set(cuda_budgets) == {(k, s) for k in kinds for s in range(2)}
    nodes = []
    for dtype in ['float32', 'float64']:
        for kind in kinds:
            name = f'test_irrigation_native_whole_reference_and_conservation[{dtype}-{kind}]'
            nodes.append(dict(node=STEM+'.py::'+name, passed=True, junit_seconds=timings[name],
                independent_numpy_reference_max_absolute_difference=maxima([reference[dtype, kind, s] for s in range(2)]),
                original_reference_steps=[dict(step=s, differences=reference[dtype, kind, s], budgets=budgets[dtype, kind, s]) for s in range(2)]))
    for kind in kinds:
        name = f'test_irrigation_native_whole_same_precision_and_device_carry[{kind}]'
        nodes.append(dict(node=STEM+'.py::'+name, passed=True, junit_seconds=timings[name],
            CUDA_JAX32_whole_return_max_absolute_difference=max(same[kind, s] for s in range(2)),
            original_same_precision_steps=[dict(step=s, maximum_absolute_difference=same[kind, s], CUDA_budgets=cuda_budgets[kind, s]) for s in range(2)],
            carry_scope='Original device-array type and sequential next-state assertions passed. No separately printed numerical carry-only difference is invented.'))
    name = 'test_irrigation_extended_contract'
    nodes.append(dict(node=STEM+'.py::'+name, passed=True, junit_seconds=timings[name],
                      numeric_difference=None, scope='ABI/input rejection assertions; original log prints no numeric comparison for this node.'))
    assert [v['node'] for v in nodes] == expected
    by_dtype = {d: dict(independent_numpy_max_absolute_difference=maxima([v for (dt, _, _), v in reference.items() if dt == d]),
                       independent_budget_logged_maxima=maxima([v for (dt, _, _), v in budgets.items() if dt == d])) for d in ['float32', 'float64']}
    summary = dict(scope='Read-only extraction of already completed original log numbers; no physical recomputation or new tolerance.',
        closed_utc=receipt['utc'], source_manifest_sha256=receipt['source_manifest_sha256'],
        parent_exit=0, worker_exit=0, tests=13, failures=0, errors=0, skipped=0,
        parent_seconds=parent['seconds'], worker_seconds=receipt['seconds'], pytest_main_seconds=receipt['pytest_seconds'],
        same_precision_whole_return_max_absolute_difference=max(same.values()), precision_summaries=by_dtype,
        CUDA_budget_logged_maxima=maxima(list(cuda_budgets.values())), nodes=nodes,
        units={'h': 'W m-2', 'le': 'W m-2', 'g': 'W m-2', 'soil_temperature': 'K', 'ts': 'K',
               '*_mm': 'mm per model interval', '*_jm2': 'J m-2', 'water_kgm2': 'kg m-2', 'heat_jm2': 'J m-2'},
        limitations=['Reference log differences are absolute; relative percentage errors are not reconstructed.',
            'Budget residual maxima and bound maxima may occur in different columns; their ratio is not a replacement for the original per-column assertions.',
            'The13-node module closure adds13 fresh nodes, yielding108fresh+32inherited=140/408 at the PA snapshot; no full-queue or annual acceptance.'],
        source_checks='Original worker verified584 files before/after and recorded complete device barriers. Archived manifest and test/helper bytes retain original source identity.')
    summary_raw = encoded(summary)
    (ROOT / (LABEL + '-quantified.json')).write_bytes(summary_raw)
    items['quantified.json'] = summary_raw
    for name in ['nq-terminal-check-pa.json', 'candidate-progress-oz.json']:
        items['snapshots/' + name] = (ROOT / name).read_bytes()
    with tarfile.open(ROOT / 'climatology-final-candidate-nm-source.tar.gz') as tf:
        for name in ['tests/test_gpu_clm_irrigation_column.py', 'tests/test_gpu_clm_layered_column.py', 'tests/test_gpu_clm_enthalpy_column.py']:
            raw = tf.extractfile(name).read()
            assert sha(raw) == manifest[name]
            items['original-source/' + name] = raw
    assert sha(items['original-source/tests/test_gpu_clm_irrigation_column.py']) == receipt['test_sha256']
    items['package_nq_irrigation_closure_pa.py'] = Path(__file__).read_bytes()
    items['README.md'] = ("# NQ irrigation closure PA\n\nOriginal NM module13/13 closed with actual parent0 and complete worker/device/source checks. "
        "The archive retains original parent/receipt/expected/log/XML/cache events/manifest/plan plus existing snapshots and exact relevant test source. "
        "quantified.json extracts all13nodes from the original completed log; sameprecision eight step comparisons are0. "
        "No model, benchmark, extra GPU worker or new numerical validation was run.\n\n"
        "The OX16GiB guard-coverage observation remains valid: this module's final cache event has calls0, peak27667488KiB, swap0. "
        "Completion supplies performance and correctness evidence for this original module only, without changing the frozen guard or ETA formula. "
        "The10:19OZ snapshot retains its original timestamp; the10:20PA snapshot records the completed module.\n").encode()
    items['inventory.json'] = encoded({n: dict(sha256=sha(b), bytes=len(b)) for n, b in sorted(items.items())})
    archive = ROOT / (LABEL + '-evidence.tar.gz')
    with archive.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as gz:
        with tarfile.open(fileobj=gz, mode='w') as tf:
            for n, b in sorted(items.items()):
                info = tarfile.TarInfo(n); info.size = len(b); info.mode = 0o644
                tf.addfile(info, io.BytesIO(b))
    with tarfile.open(archive) as tf:
        assert {m.name: tf.extractfile(m).read() for m in tf.getmembers()} == items
    package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
        artifacts=len(items), publication_label=LABEL, passed=True, source_manifest_sha256=receipt['source_manifest_sha256'],
        actual_parent_returncode=0, actual_worker_exitcode=0, tests=13, failures=0, errors=0, skipped=0,
        parent_seconds=parent['seconds'], quantified_sha256=sha(summary_raw),
        scope='One original NM NQ irrigation module closure and read-only log extraction. No extra physical execution, full-suite or annual claim.')
    (ROOT / (LABEL + '-package.json')).write_bytes(encoded(package))
    print(json.dumps(package, indent=2))


if __name__ == '__main__':
    main()

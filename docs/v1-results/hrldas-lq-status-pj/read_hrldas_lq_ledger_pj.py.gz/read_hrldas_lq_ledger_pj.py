"""Read originalJN journal report metadata and exact active PID resources only."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import sys

ROOT=Path('/home/zhangyq/noahmp-v1/hrldas-current-year-lq')
sha=lambda b:hashlib.sha256(b).hexdigest()
protocol_raw=(ROOT/'protocol.json').read_bytes()
protocol=json.loads(protocol_raw)
assert protocol['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert sha((ROOT/'append_journal_lp.py').read_bytes())==protocol['controls_sha256']['append_journal_lp.py']
sys.path.insert(0,str(ROOT))
from append_journal_lp import Journal

rows=[]
for site,job,pid in [('CN-Qia','1430.manager',49244),('CN-Cha','1490.manager',48927),('CN-HaM','1513.manager',52846)]:
    journal=Journal(ROOT/site/'journal.bin')
    labels=[key for key in journal.index if re.fullmatch(r'generation/\d+/[a-f0-9]{64}',key)]
    label=max(labels,key=lambda key:int(key.split('/')[1]))
    generation=journal.read(label)
    report=json.loads(generation['report.json'])
    assert sha(generation['report.json'])==label.split('/')[-1]
    assert report['configuration_sha256']==protocol['input_sha256'][site+'-config.json']
    assert report['source_unchanged'] and report['steps_requested']==17520
    for key,digestkey in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
        assert sha(generation[report[key]])==report[digestkey]
    command='cat /proc/'+str(pid)+'/stat /proc/'+str(pid)+'/status; ps -p '+str(pid)+' -o pid=,ppid=,sid=,lstart=,etimes=,stat=,pcpu=,pmem=,rss=,args='
    proc=subprocess.run(['ssh','compute002',command],capture_output=True,text=True)
    rows.append(dict(site=site,active_job=job,expected_pid=pid,latest_saved_report=report,
        journal_generation=label,generation_frame_sha256=journal.index[label][2],
        report_raw=generation['report.json'].decode(),process_command=command,
        process_read_exit=proc.returncode,process_stdout=proc.stdout,process_stderr=proc.stderr,
        latest_generation_is_snapshot_not_actual_F0_credit=True))
print(json.dumps(dict(snapshot_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_manifest_sha256=protocol['source_manifest_sha256'],protocol_sha256=sha(protocol_raw),rows=rows,
    numerical_arrays_deserialized=False,new_physical_calls=0,remote_writes=False),indent=2,allow_nan=False))

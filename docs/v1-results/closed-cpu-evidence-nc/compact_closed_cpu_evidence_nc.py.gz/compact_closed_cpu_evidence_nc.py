"""Losslessly remove only two closed, fully archived numpy-full duplicates.

Controls, restore copies, journals and export live in /tmp. Original archives,
source files, inputs, active trajectories and all other directories stay intact.
"""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import time

b = Path('/home/zhangyq/noahmp-v1')
work = Path('/tmp/noahmp-closed-cpu-evidence-nc')
assert not work.exists()
work.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
jobs = [
    ('p6-heat-coordinate-d', 'heat-coordinate-cpu-d-evidence.tar.gz', '24.manager', 162,
     '6fcfc3567d2e788118552cb964df371ef931a02dff8ffe44306c05441812a9aa'),
    ('p6-surface-secant-e', 'numpy-full-e-evidence.tar.gz', '16.manager', 158,
     'bab987aea2616b79ab14ac675e587a0982f9d4419b645399d631e03e28c98789'),
]


def filesystem():
    info = os.statvfs(b)
    return dict(available_inodes=info.f_favail, total_inodes=info.f_files,
                free_bytes=info.f_bavail * info.f_frsize)


def terminal(job):
    text = subprocess.check_output(['qstat', '-xf', job], text=True)
    assert re.search(r'^Job Id: ' + re.escape(job) + r'\s*$', text, re.M)
    assert re.search(r'^\s*job_state = F\s*$', text, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', text, re.M)
    (work / (job + '-actual-qstat.txt')).write_text(text)


def process_refs():
    # The controls refer to these roots, so inspect cwd/fds and active model
    # command lines rather than flagging this controller's own source literal.
    script = '''from pathlib import Path
import os,json
targets=["/home/zhangyq/noahmp-v1/p6-heat-coordinate-d/", "/home/zhangyq/noahmp-v1/p6-surface-secant-e/"]
hits=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=os.getuid():continue
  cwd=os.readlink(p/'cwd')+'/'
  fds=[]
  try:fds=[os.readlink(q) for q in (p/'fd').iterdir()]
  except OSError:pass
  command=(p/'cmdline').read_bytes().replace(b'\\0',b' ').decode(errors='replace')
  if any(cwd.startswith(t) or any(x.startswith(t) for x in fds) or t in command for t in targets):hits.append(int(p.name))
 except OSError:pass
print(json.dumps(hits))
'''
    local = subprocess.check_output(['/home/zhangyq/venvs/noahmp-closeout/bin/python', '-B', '-'], input=script, text=True)
    remote = subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
        'compute002', '/home/zhangyq/venvs/noahmp-closeout/bin/python', '-B', '-'], input=script, text=True)
    assert json.loads(local) == [] and json.loads(remote) == [], (local, remote)
    return dict(manager_live_references=[], compute002_live_references=[])


record = dict(scope='NC: exactly320 closed numpy-full duplicate result files, existing archives '
    'fully restored in /tmp and every byte checked, actual PBS F0 and no active PID references. '
    'No other data/source/input/cache/venv directory touched.', started=time.time(),
    before=filesystem(), records=[])
(work / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
for name, archive_name, job, expected_count, expected_sha in jobs:
    root = b / name
    target = root / 'numpy-full'
    archive = root / archive_name
    assert root.resolve() == root and target.resolve() == target and target.parent == root
    assert archive.is_file() and sha(archive) == expected_sha
    terminal(job)
    process_proof = process_refs()
    files = sorted(p for p in target.rglob('*') if p.is_file())
    assert len(files) == expected_count and all(not p.is_symlink() and target in p.resolve().parents for p in files)
    restore = work / name
    restore.mkdir()
    with tarfile.open(archive) as tf:
        members = {member.name: member for member in tf.getmembers() if member.isfile()}
        for member in tf.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and (member.isdir() or member.isfile())
        tf.extractall(restore, filter='data')
        for member_name, member in members.items():
            assert hashlib.sha256(tf.extractfile(member).read()).hexdigest() == sha(restore / member_name)
    mapped = []
    for path in files:
        relative = path.relative_to(root).as_posix()
        possibilities = [n for n in members if n == relative or n.endswith('/' + relative)
                         or n == path.relative_to(target).as_posix()]
        assert len(possibilities) == 1, relative
        member_name = possibilities[0]
        digest = sha(path)
        assert digest == sha(restore / member_name)
        mapped.append(dict(path=str(path), archive_member=member_name, sha256=digest, bytes=path.stat().st_size))
    # Recheck immutable sources, terminal status and active references immediately before unlink.
    terminal(job)
    process_proof = process_refs()
    assert sha(archive) == expected_sha
    assert sorted(str(p) for p in target.rglob('*') if p.is_file()) == [v['path'] for v in mapped]
    item = dict(directory=str(target), archive=str(archive), archive_sha256=expected_sha,
                pbs_job=job, actual_pbs_exit=0, restored_archive_files=len(members),
                verified_duplicate_files=expected_count, process_proof=process_proof,
                before=filesystem(), files=mapped, removed=[])
    journal = work / (name + '-journal.json')
    journal.write_text(json.dumps(item, indent=2) + '\n')
    for entry in mapped:
        path = Path(entry['path'])
        assert target in path.resolve().parents and not path.is_symlink() and sha(path) == entry['sha256']
        path.unlink()
        assert not path.exists()
        item['removed'].append(entry['path'])
        journal.write_text(json.dumps(item, indent=2) + '\n')
    pointer = target / 'ARCHIVE_LOCATION.json'
    value = dict(archive=str(archive), archive_sha256=expected_sha, files=mapped,
                 actual_pbs_job=job, actual_pbs_exit=0, complete_restore=str(restore),
                 control_record=str(journal), scope=record['scope'])
    with pointer.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    assert json.loads(pointer.read_text()) == value and sha(archive) == expected_sha
    item.update(pointer=str(pointer), pointer_sha256=sha(pointer),
                actual_home_pointer_create_write_read_fsync_succeeded=True, after=filesystem())
    journal.write_text(json.dumps(item, indent=2) + '\n')
    record['records'].append(item)
    (work / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
record.update(passed=True, removed_duplicate_files=sum(len(v['removed']) for v in record['records']),
              pointers_created=len(record['records']), after=filesystem(), seconds=time.time() - record['started'])
(work / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
archive = Path('/tmp/closed-cpu-evidence-nc-evidence.tar.gz')
assert not archive.exists()
payload = {p.name: p.read_bytes() for p in work.iterdir() if p.is_file()}
for name, archive_name, _, _, _ in jobs:
    payload['original-archives/' + archive_name] = (b / name / archive_name).read_bytes()
    payload[name + '/ARCHIVE_LOCATION.json'] = (b / name / 'numpy-full/ARCHIVE_LOCATION.json').read_bytes()
with tarfile.open(archive, 'w:gz') as tf:
    for name, raw in sorted(payload.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        tf.addfile(member, io.BytesIO(raw))
with tarfile.open(archive) as tf:
    assert len(tf.getmembers()) == len(payload)
    for member in tf:
        assert tf.extractfile(member).read() == payload[member.name]
package = dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
               artifacts=len(payload), scope=record['scope'])
Path('/tmp/closed-cpu-evidence-nc-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(dict(passed=record['passed'], removed_duplicate_files=record['removed_duplicate_files'],
    actual_home_pointer_writes=record['pointers_created'], before=record['before'], after=record['after'],
    package=package)), flush=True)

"""Eighteen isolated component cases; numerical execution only in EHPC PBS."""
import os
import socket
if os.name == 'nt' or not os.environ.get('PBS_JOBID') or socket.gethostname() != 'compute002':
    raise RuntimeError('PB-k numerical tests require EHPC compute002 PBS')

from dataclasses import replace
from pathlib import Path
import hashlib
import json
import numpy as np
import pytest
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
import saturated_drainage_pb as pb
import drainage_primitives_pbf as primitive
import perched_primitives_pbk as trial
import adaptive_perched_pbk as adaptive
from phase_numpy32_pbi import run_numpy32, PHASE_AUDIT

HERE = Path(__file__).resolve().parent
DTYPES = [np.float64, np.float32]


def fixture(dtype, theta=(.39,.43,.4,.2), temperature=(280.,280.,270.,280.), ks=10., slope=.2, option=1):
    dz=np.full(4,.5); params=SoilParams(satdk=ks); theta=np.asarray(theta); temperature=np.asarray(temperature)
    water=1000*dz*theta; heat=enthalpy_and_capacity(water,temperature,dz,params,option=option)[0]
    soil=SoilEnthalpyState(water,heat,dz,params,option)
    dp=pb.DrainageParameters(2.,slope,baseflow_mm_s_per_m=0.)
    c64,p64,_=primitive.pack(soil,dp,1800.,.4375,1.25)
    if dtype==np.float64:return c64,p64,soil,dp,option
    f=np.float32; p=p64.astype(f); z=dz.astype(f); w=f(1000)*z*theta.astype(f)
    u=np.column_stack((w,temperature.astype(f)-f(273.15),z,np.full(4,p[0],f),np.full(4,p[2],f),np.full(4,p[1],f)))
    h=run_numpy32(u,np.full(4,option,np.int32))['enthalpy_jm2']; u[:,1]=h
    phase=run_numpy32(u,np.full(4,option,np.int32),inverse=True)
    c=np.column_stack((phase['liquid_kgm2'],w-phase['liquid_kgm2'],z,phase['temperature_k'],w,h))
    assert c.dtype==p.dtype==f
    return c,p,soil,dp,option


def checked_run(case,duration=1800.,front=.4375,bottom=1.25,controls=pb.IntegrationControls()):
    c,p,soil,dp,option=case; original=(c.tobytes(),p.tobytes())
    out,z,ledger=adaptive.advance_perched_band(c,p,option,duration,front,bottom,controls)
    assert original==(c.tobytes(),p.tobytes())
    assert out.dtype==np.asarray(z).dtype==c.dtype
    assert all(ledger[k].dtype==c.dtype for k in ('layer_mass_kg_m2','layer_enthalpy_j_m2'))
    assert np.all(out[:,4]>=0) and np.all(out[:,4]<=c[:,4])
    for residual,bound in [('water_residual_kg_m2','water_bound_kg_m2'),('energy_residual_j_m2','energy_bound_j_m2')]:
        assert abs(ledger[residual])<=ledger[bound]
    # Independent high-precision accumulation of the exact stored dtype values.
    rm=float(np.sum(out[:,4].astype(float)-c[:,4].astype(float)+ledger['layer_mass_kg_m2'].astype(float)))
    rh=float(np.sum(out[:,5].astype(float)-c[:,5].astype(float)+ledger['layer_enthalpy_j_m2'].astype(float)))
    assert abs(rm)<=float(ledger['water_bound_kg_m2']) and abs(rh)<=float(ledger['energy_bound_j_m2'])
    assert ledger['elapsed_seconds']==float(c.dtype.type(duration)) and ledger['clock_residual_seconds']==0
    if c.dtype==np.float32:
        u=np.column_stack((out[:,4],out[:,5],out[:,2],np.full(4,p[0],c.dtype),np.full(4,p[2],c.dtype),np.full(4,p[1],c.dtype)))
        phase=run_numpy32(u,np.full(4,option,np.int32),inverse=True)
        np.testing.assert_array_equal(out[:,3],phase['temperature_k'])
        np.testing.assert_array_equal(out[:,0],phase['liquid_kgm2'])
        assert PHASE_AUDIT['floating_values_checked']>0
    ledger['independent_water_residual']=rm;ledger['independent_heat_residual']=rh
    return out,z,ledger


def emit(name,case,out,z,d,**extra):
    c,p,soil,dp,option=case
    record=dict(test=name,precision=str(c.dtype),backend='numpy',option=option,
        layer_mass=d['layer_mass_kg_m2'].tolist(),layer_heat=d['layer_enthalpy_j_m2'].tolist(),
        front_m=float(z),water=out[:,4].tolist(),enthalpy=out[:,5].tolist(),temperature=out[:,3].tolist(),ice=out[:,1].tolist(),
        water_residual=float(d['water_residual_kg_m2']),water_bound=float(d['water_bound_kg_m2']),
        heat_residual=float(d['energy_residual_j_m2']),heat_bound=float(d['energy_bound_j_m2']),
        independent_water_residual=d['independent_water_residual'],independent_heat_residual=d['independent_heat_residual'],
        accepted=d['accepted_substeps'],rejected=d['rejected_substeps'],clock_residual=d['clock_residual_seconds'],
        requested=float(d['potential_requested_kg_m2']),unavailable=float(d['unavailable_liquid_kg_m2']),cap=float(d['band_exhaustion_kg_m2']),
        input_water_quantization=(c[:,4].astype(float)-soil.water).tolist(),input_heat_quantization=(c[:,5].astype(float)-soil.enthalpy).tolist(),**extra)
    print('PB_K_DIAGNOSTIC '+json.dumps(record,allow_nan=False),flush=True)


def physical(actual,reference,absolute):
    actual=np.asarray(actual,dtype=float);reference=np.asarray(reference,dtype=float)
    assert np.all(abs(actual-reference)<=np.maximum(absolute,.1*abs(reference)))


def micro_reference():
    records=json.loads((HERE/'reference-comparisons.json').read_bytes())['profiles']
    r=next(x for x in records if x['name']=='frost_perched_donor')['official']
    mass=np.asarray(r['INITIAL_LIQ'])-np.asarray(r['AFTER_PERCH_LIQ'])
    heat=mass*(334000+4180*(np.asarray([280.,280.,270.,280.])-273.15))
    return mass,heat,r['PERCHED'][1]


@pytest.mark.parametrize('dtype',DTYPES)
@pytest.mark.parametrize('profile',['micro','cap','depleted','zero_thickness'])
def test_perched_frozen_trial_reference_and_limits(dtype,profile):
    kwargs=dict(theta=(.2,.43,.4,.2),ks=1e-5) if profile=='micro' else {}
    if profile=='depleted':kwargs['theta']=(.39,.00002,.4,.2)
    case=fixture(dtype,**kwargs);c,p,soil,dp,option=case
    front=pb.diagnose_water_tables(soil,dp)['perched_water_table_m'] if profile=='micro' else .4375
    if profile=='zero_thickness':front=1.25
    duration=1800. if profile=='micro' else 86400.
    u=np.asarray([duration,front,1.25],dtype); before=(c.tobytes(),p.tobytes())
    diag,t=trial.run_numpy_perched(c[None],p[None],u[None]);t=t[0]
    assert diag.dtype==t.dtype==c.dtype and diag.shape==(1,29) and t.shape==(29,)
    assert before==(c.tobytes(),p.tobytes())
    assert abs(t[6])<=t[8] and abs(t[7])<=t[9]
    assert np.all(t[10:14]>=0) and np.all(t[10:14]<=np.maximum(c[:,0]-p[10],0))
    reference,rz,rd=pb._perched_transfer(soil,front,1.25,duration,dp)
    physical(t[10:14],rd['layer_mass_kg_m2'],.001);physical(t[14:18],rd['layer_enthalpy_j_m2'],.5)
    physical(t[0],rz,1e-6)
    if profile=='micro':
        om,oh,oz=micro_reference();assert np.max(abs(t[10:14].astype(float)-om))<=.001
        assert np.max(abs(t[14:18].astype(float)-oh))<=.5
    elif profile=='cap':assert t[4]>0 and t[0]==dtype(1.25) and t[3]==0
    elif profile=='depleted':assert t[3]>0 and t[5]==1 and t[0]<dtype(1.25) and t[11]==0
    else:assert t[2]==0 and t[0]==dtype(1.25);np.testing.assert_array_equal(t[18:22],c[:,4])
    bindings=json.loads((HERE/'BINDINGS.json').read_bytes())
    for n,h in bindings['frozen_dependencies'].items():assert hashlib.sha256((HERE/n).read_bytes()).hexdigest()==h
    print('PB_K_DIAGNOSTIC '+json.dumps(dict(test='trial_'+profile,precision=str(c.dtype),option=option,
        layer_mass=t[10:14].tolist(),layer_heat=t[14:18].tolist(),front_m=float(t[0]),requested=float(t[1]),
        unavailable=float(t[3]),cap=float(t[4]),water_residual=float(t[6]),heat_residual=float(t[7]),
        water_bound=float(t[8]),heat_bound=float(t[9]),main_depth=float(t[26]),specific_yield=float(t[27]),
        first_donor=int(t[28]),reference_mass=rd['layer_mass_kg_m2'].tolist(),reference_heat=rd['layer_enthalpy_j_m2'].tolist(),
        reference_front=float(rz)),allow_nan=False),flush=True)


@pytest.mark.parametrize('dtype',DTYPES)
def test_complete_microflow_original_official_absolute_gate(dtype):
    case=fixture(dtype,theta=(.2,.43,.4,.2),ks=1e-5)
    front=pb.diagnose_water_tables(case[2],case[3])['perched_water_table_m']
    out,z,d=checked_run(case,front=front);m,h,rz=micro_reference()
    assert np.max(abs(d['layer_mass_kg_m2'].astype(float)-m))<=.001
    assert np.max(abs(d['layer_enthalpy_j_m2'].astype(float)-h))<=.5
    assert abs(float(z)-rz)<=1e-6
    emit('complete_micro',case,out,z,d,official_mass=m.tolist(),official_heat=h.tolist(),official_front=rz)


@pytest.mark.parametrize('dtype',DTYPES)
def test_complete_shared_thermal_official_j_and_donor_switch(dtype):
    case=fixture(dtype);out,z,d=checked_run(case,86400.)
    r=json.loads((HERE/'reference-common-thermal-j.json').read_bytes())['profiles'][0]
    m=np.asarray(r['cumulative_water_export']);h=np.asarray(r['cumulative_heat_export']);rz=r['final_migrating_front_m']
    physical(d['layer_mass_kg_m2'],m,.001);physical(d['layer_enthalpy_j_m2'],h,.5);physical(z,rz,1e-6)
    readback=r['final_diagnostic_readback'];physical(out[:,4],readback['FINAL_SHARED_WATER'],.001)
    assert d['layer_mass_kg_m2'][1]>0 and d['layer_mass_kg_m2'][2]>0 and z>.5
    assert out[2,3]<case[0][2,3] and out[2,1]!=case[0][2,1] and d['rejected_substeps']>0
    emit('complete_J',case,out,z,d,official_mass=m.tolist(),official_heat=h.tolist(),official_front=rz,
        mass_percent=[None if v==0 else 100*(float(a)-v)/v for a,v in zip(d['layer_mass_kg_m2'],m)],
        front_difference_m=float(z)-rz,front_percent=100*(float(z)-rz)/rz,
        original_J_1mm_flag=r['comparison']['front_within_abs_001'],new_1mm_diagnostic_only=abs(float(z)-rz)<=.001,
        scope='Independent official hydrology with explicitly shared NM64 thermal closure; not official thermal truth.')


@pytest.mark.parametrize('dtype',DTYPES)
def test_complete_no_outlet_and_blocked_clock(dtype):
    for name,case in [('zero_slope',fixture(dtype,slope=0.)),('blocked',fixture(dtype,theta=(.39,0.,0.,.2)))]:
        out,z,d=checked_run(case,86400.)
        np.testing.assert_array_equal(out[:,4:],case[0][:,4:]);assert d['drained_kg_m2']==0 and z==dtype(.4375)
        if name=='blocked':assert d['unavailable_liquid_kg_m2']>0
        emit('complete_'+name,case,out,z,d)


@pytest.mark.parametrize('dtype',DTYPES)
def test_complete_rejection_failure_and_explicit_duration(dtype):
    case=fixture(dtype);c,p,_,_,_=case
    controls=replace(pb.IntegrationControls(),relative_tendency_tolerance=.0001)
    out,z,d=checked_run(case,1800.00001,controls=controls);assert d['rejected_substeps']>0
    with pytest.raises(RuntimeError,match='attempt budget'):
        checked_run(case,1800.,controls=replace(controls,maximum_attempts=1))
    with pytest.raises(ValueError,match='same-precision'):
        adaptive.advance_perched_band(c,p.astype(np.float32 if dtype==np.float64 else np.float64),1,1800.,.4375,1.25)
    broken=c.copy();broken[0,3]+=dtype(1)
    with pytest.raises(ValueError,match='inconsistent'):
        adaptive.advance_perched_band(broken,p,1,1800.,.4375,1.25)
    emit('complete_rejection',case,out,z,d,requested_python_duration=1800.00001,quantized_duration=d['quantized_requested_duration_seconds'])


@pytest.mark.parametrize('dtype',DTYPES)
def test_complete_option2_frozen_reference(dtype):
    case=fixture(dtype,option=2);out,z,d=checked_run(case)
    ref,rz,rd=pb.advance_saturated_band(case[2],1800.,.4375,1.25,'perched',case[3])
    physical(d['layer_mass_kg_m2'],rd['layer_mass_kg_m2'],.001)
    physical(d['layer_enthalpy_j_m2'],rd['layer_enthalpy_j_m2'],.5);physical(z,rz,1e-6)
    assert np.max(abs(out[:,3].astype(float)-ref.temperature))<.001
    assert out[2,1]>0 and d['drained_kg_m2']>0
    emit('complete_option2',case,out,z,d,reference64_mass=rd['layer_mass_kg_m2'].tolist(),
        reference64_heat=rd['layer_enthalpy_j_m2'].tolist(),reference64_front=float(rz),
        temperature_difference64=(out[:,3].astype(float)-ref.temperature).tolist())

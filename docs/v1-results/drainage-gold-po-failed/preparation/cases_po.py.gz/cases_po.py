"""Explicit recipes only: each actual input is generated and sealed on EHPC."""


def cases():
    rows = []
    def add(name, kind='main', fixture=None, duration=1800., front=.5, bottom=2.,
            controls=None, full=True):
        rows.append(dict(name=name, kind=kind, fixture=fixture or {}, duration=duration,
                         front=front, bottom=bottom, controls=controls or {}, full=full))
    for option in (1, 2):
        for label, temperature in [('warm', 290.), ('frozen', [280., 270., 270., 270.])]:
            add('main-' + label + '-option' + str(option), fixture=dict(theta=.4, temperature=temperature, option=option))
    add('main-crosslayer', duration=172800.)
    add('main-refined', duration=172800., controls=dict(maximum_step_seconds=900., relative_tendency_tolerance=.00025))
    add('main-zero-slope', fixture=dict(slope=0.), duration=86400.)
    add('main-blocked', fixture=dict(theta=[.45, 0., .45, .45]), duration=86400.)
    add('main-bedrock', fixture=dict(bedrock=1.5), bottom=1.5, duration=86400.)
    add('main-rejection', controls=dict(relative_tendency_tolerance=.0001))
    add('main-quantized-time', duration=1800.00001)
    add('perched-micro', 'perched', dict(theta=[.2,.43,.4,.2], ks=1e-5), front=None, bottom=1.25)
    add('perched-stress', 'perched', duration=86400., front=.4375, bottom=1.25)
    add('perched-zero-slope', 'perched', dict(slope=0.), 86400., .4375, 1.25)
    add('perched-blocked', 'perched', dict(theta=[.39,0.,0.,.2]), 86400., .4375, 1.25)
    add('perched-option2', 'perched', dict(option=2), front=.4375, bottom=1.25)
    add('perched-rejection', 'perched', duration=1800.00001, front=.4375, bottom=1.25,
        controls=dict(relative_tendency_tolerance=.0001))
    add('perched-cap-trial', 'perched', duration=86400., front=.4375, bottom=1.25, full=False)
    add('perched-depleted-trial', 'perched', dict(theta=[.39,.00002,.4,.2]), 86400., .4375, 1.25, full=False)
    add('perched-zero-thickness-trial', 'perched', duration=86400., front=1.25, bottom=1.25, full=False)
    assert len(rows) == 20 and sum(r['full'] for r in rows) == 17
    return rows

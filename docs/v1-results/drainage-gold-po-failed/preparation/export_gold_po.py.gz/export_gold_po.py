"""EHPC-only actual NumPy32/64 packet generation; no device imports or runs."""
from pathlib import Path
import argparse
import json
import sys
import traceback
from contract_po import cpu_host, controls, save


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();cpu_host();identity=controls(args.source)
    assert not args.output.exists();args.output.mkdir()
    sys.path.insert(0,str(args.source.resolve()/'src'))
    import numpy as np
    import fixture_main_original as mf
    import test_perched_pbk as pf
    import saturated_drainage_pb as pb
    from arrays_po import descriptor,freeze,run_one,physical
    from cases_po import cases
    recipe=cases();save(args.output/'case-recipes.json',recipe)
    reports=[]; executions=[]; error=None

    def execute_case(row):
        case_dir=args.output/row['name'];case_dir.mkdir()
        if row['kind']=='main':
            c32,p32,c64,p64,option=mf.fixture(**row['fixture'])
            front=row['front']
        else:
            a=pf.fixture(np.float32,**row['fixture']);b=pf.fixture(np.float64,**row['fixture'])
            c32,p32,_,_,option=a;c64,p64=b[:2]
            front=pb.diagnose_water_tables(b[2],b[3])['perched_water_table_m'] if row['front'] is None else row['front']
        inputs={}
        for label,c,p in [('32',c32,p32),('64',c64,p64)]:
            inputs[label]=dict(cells=c,parameters=p,interval=np.asarray([row['duration'],front,row['bottom']],c.dtype),option=np.asarray(option,np.int32))
            freeze(case_dir/('input'+label+'.npz'),inputs[label])
        quantization={k:(inputs['32'][k].astype(np.float64)-inputs['64'][k].astype(np.float64)).tolist()
                      for k in ('cells','parameters','interval')}
        save(case_dir/'input-quantization.json',dict(difference_32_minus_64=quantization,
            same_exact_inputs=False,same_nominal_recipe=True,explicit32_phase_construction=True,
            original_requested_duration=row['duration'],option=option))
        report=dict(case=row['name'],reference64_path='original G main' if row['kind']=='main' else 'K perched NumPy64',runs={})
        results={}
        for label in ('32','64'):
            before={k:descriptor(v) for k,v in inputs[label].items()}
            counted=dict(case=row['name'],precision=label,completed=False)
            executions.append(counted)
            try:
                result,run=run_one(inputs[label],row,'numpy',reference64=label=='64',observed=counted)
                counted['completed']=True
            finally:
                save(case_dir/('numpy'+label+'-observed-calls.json'),counted)
                save(args.output/'observed-calls.json',executions)
            assert before=={k:descriptor(v) for k,v in inputs[label].items()}
            freeze(case_dir/('numpy'+label+'.npz'),result)
            save(case_dir/('numpy'+label+'-run.json'),run)
            results[label]=result;report['runs'][label]=run
        report['physical32_vs64']=physical(results['32'],results['64'],row['kind'])
        save(case_dir/'export-comparison.json',report)
        reports.append(report)
        print('PO_EXPORT_CASE '+json.dumps(report,allow_nan=False),flush=True)

    try:
        for row in recipe:execute_case(row)
    except Exception:
        error=traceback.format_exc();(args.output/'export-failure.txt').write_text(error)
    identity.update(cases=len(reports),planned_cases=len(recipe),planned_full_cases=sum(r['full'] for r in recipe),
        actual_trial_executions=sum(r.get('actual_trial_calls',0) for r in executions),
        actual_full_integrations=sum(r.get('actual_full_calls',0) for r in executions),
        attempted_trial_executions=sum(r.get('trial_attempted',0) for r in executions),
        attempted_full_integrations=sum(r.get('full_attempted',0) for r in executions),
        count_scope='Observed direct primitive and full-component returns; internal adaptive trial calls are not this count',
        observed_execution_records=executions,error=error,
        passed=error is None and len(reports)==len(recipe) and all(r['physical32_vs64']['passed'] for r in reports),
        GPU_runs=0,coupled_columns=0,field_years=0,production_registered=False)
    # Compare identity before adding execution fields, not a synthetic successful flag.
    identity['source_and_controls_unchanged']=all(controls(args.source)[k]==identity[k]
        for k in ('controls_manifest_sha256','source_manifest_sha256','source_files'))
    save(args.output/'export-summary.json',identity)
    return 0 if identity['passed'] and identity['source_and_controls_unchanged'] else 1


if __name__=='__main__':raise SystemExit(main())

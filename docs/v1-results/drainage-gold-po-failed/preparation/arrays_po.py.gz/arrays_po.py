"""Remote-only array capture, complete numeric comparison and hard M/H checks."""
import os
if os.name == 'nt':
    raise RuntimeError('PO array operations are remote only')

from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import importlib
import json
import time
import numpy as np
from contract_po import sha, save
from saturated_drainage_pb import IntegrationControls


def host(value):
    if hasattr(value, 'block_until_ready'):
        value.block_until_ready()
    if type(value).__module__.startswith('cupy'):
        import cupy as cp
        return cp.asnumpy(value)
    return np.asarray(value)


def descriptor(value):
    value = np.asarray(value)
    assert type(value) is np.ndarray and value.dtype.kind in 'biuf' and np.all(np.isfinite(value))
    return dict(dtype=value.dtype.str, shape=list(value.shape), bytes=value.nbytes,
                c_order_sha256=sha(value.tobytes(order='C')))


def freeze(path, values):
    values = {k:host(v).copy() for k,v in values.items()}
    metadata = {k:descriptor(v) for k,v in values.items()}
    np.savez(path, **values)
    metadata = dict(npz_sha256=sha(Path(path).read_bytes()), arrays=metadata)
    save(str(path) + '.json', metadata)
    return metadata


def read_arrays(path):
    path = Path(path)
    metadata = json.loads(Path(str(path) + '.json').read_bytes())
    assert sha(path.read_bytes()) == metadata['npz_sha256']
    with np.load(path, allow_pickle=False) as store:
        assert set(store.files) == set(metadata['arrays'])
        values = {k:store[k].copy() for k in store.files}
    assert {k:descriptor(v) for k,v in values.items()} == metadata['arrays']
    return values


def same_precision(actual, reference):
    """No returned numeric field is excluded; discrete fields are exact."""
    assert set(actual) == set(reference)
    rows = {}
    for key in actual:
        a, b = actual[key], reference[key]
        assert a.dtype == b.dtype and a.shape == b.shape, key
        difference = np.abs(a.astype(np.float64) - b.astype(np.float64))
        discrete = a.dtype.kind in 'biu' or key in ('trial.liquid_limited', 'trial.first_donor',
            'diagnosis.has_frost','diagnosis.has_perched','diagnosis.transition_count',
            'diagnosis.active_layers','diagnosis.first_perched_donor_or_minus_one')
        bound = np.zeros_like(difference) if discrete else 1e-6 + 1e-6 * np.abs(b.astype(np.float64))
        rows[key] = dict(dtype=a.dtype.str, shape=list(a.shape), exact_required=discrete,
                         maximum_absolute_difference=float(difference.max(initial=0)),
                         maximum_scaled_difference=None if discrete else float(np.max(difference / bound, initial=0)),
                         passed=bool(np.all(difference <= bound)))
    return dict(passed=all(r['passed'] for r in rows.values()), fields=rows)


def physical(actual, reference, kind):
    """Cross-precision physical outputs only; every raw return remains saved."""
    rows = {}
    def check(label, a, b, absolute, relative=.1):
        a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
        difference=a-b;bound=np.maximum(absolute,relative*np.abs(b))
        rows[label]=dict(difference=difference.tolist(), maximum_absolute_difference=float(np.max(np.abs(difference),initial=0)),
            absolute_tolerance=absolute, relative_fraction=relative,
            percent_where_relative_applies=np.where(np.abs(b)>absolute/max(relative,1e-300),100*difference/np.where(b!=0,np.abs(b),1),np.nan).tolist(),
            passed=bool(np.all(np.abs(difference)<=bound)))
        # JSON must not hide NaN in actual predictions; these None are explicitly undefined percentages.
        def nullable(x):
            return [nullable(v) for v in x] if isinstance(x,list) else (None if not np.isfinite(x) else x)
        rows[label]['percent_where_relative_applies']=nullable(rows[label]['percent_where_relative_applies'])
    for prefix in ('trial', 'full'):
        if prefix+'.layer_mass_kg_m2' not in actual:
            continue
        check(prefix+'.mass', actual[prefix+'.layer_mass_kg_m2'], reference[prefix+'.layer_mass_kg_m2'], .001)
        check(prefix+'.heat', actual[prefix+'.layer_enthalpy_j_m2'], reference[prefix+'.layer_enthalpy_j_m2'], .05 if kind=='main' else .5)
        check(prefix+'.front', actual[prefix+'.front'], reference[prefix+'.front'], 1e-6, .1)
        for field,absolute in [('water_after',.001),('enthalpy_after',.5)]:
            check(prefix+'.'+field, actual[prefix+'.'+field],reference[prefix+'.'+field],absolute)
    if 'full.cells' in actual:
        for column,label,absolute,relative in [(0,'liquid',.001,.1),(1,'ice',.001,.1),(2,'dz',1e-6,0),(3,'temperature',.001,0)]:
            check('full.'+label,actual['full.cells'][:,column],reference['full.cells'][:,column],absolute,relative)
    return dict(passed=all(r['passed'] for r in rows.values()), fields=rows,
                same_nominal_recipe=True, same_exact_inputs=False, quantization_record_required=True)


@contextmanager
def phase_observer(backend, dtype):
    audit=dict(actual_inverse_calls=0, input_dtype=str(dtype), all_converged=True,
               maximum_absolute_reconstruction_residual_j_m2=0.)
    if backend=='numpy' and dtype==np.dtype('float64'):
        audit['scope']='Original SoilEnthalpyState path, not instrumented as a device inverse'
        yield audit
        return
    module, symbol = {'numpy':('phase_numpy32_pbi','run_numpy32'),
        'jax':('noahmp_clm.gpu.enthalpy','run_soil_thermodynamics_jax'),
        'cuda':('noahmp_clm.gpu.cuda.enthalpy','run_soil_thermodynamics_cuda')}[backend]
    module=importlib.import_module(module); original=getattr(module,symbol)
    def observed(inputs,options,*,inverse=False):
        assert inverse and inputs.dtype==dtype
        value=original(inputs,options,inverse=inverse)
        arrays={k:host(v) for k,v in value.items()}
        assert all(v.dtype==dtype for v in arrays.values() if v.dtype.kind=='f')
        assert np.all(arrays['converged']>0) and all(np.all(np.isfinite(v)) for v in arrays.values())
        audit['actual_inverse_calls']+=1
        residual=float(np.max(np.abs(arrays['reconstruction_residual_jm2']),initial=0))
        audit['maximum_absolute_reconstruction_residual_j_m2']=max(audit['maximum_absolute_reconstruction_residual_j_m2'],residual)
        return value
    with patch.object(module,symbol,observed):
        yield audit


def hard_audit(inputs, outputs, backend):
    c=inputs['cells']; dtype=c.dtype; audits={}
    for prefix in ('trial','full'):
        if prefix+'.water_after' not in outputs:
            continue
        audits[prefix]={}
        for label,col,outlet,residual,bound in [('water',4,'layer_mass_kg_m2','water_residual_kg_m2','water_bound_kg_m2'),
                ('heat',5,'layer_enthalpy_j_m2','energy_residual_j_m2','energy_bound_j_m2')]:
            final=outputs[prefix+('.water_after' if col==4 else '.enthalpy_after')]
            export=outputs[prefix+'.'+outlet]
            r=float(outputs[prefix+'.'+residual]); b=float(outputs[prefix+'.'+bound])
            exact_scale=float(np.sum(np.abs(c[:,col].astype(float))+np.abs(final.astype(float))+np.abs(export.astype(float))))
            mathematical_bound=64*np.finfo(dtype).eps*max(exact_scale,1.)
            # Bound recomputation uses the original backend/order in run_one; here
            # independently sum the stored exact dtype values without changing its bound.
            independent=float(np.sum(final.astype(float)-c[:,col].astype(float)+export.astype(float)))
            assert np.isfinite(b) and b>=0 and abs(r)<=b and abs(independent)<=b
            audits[prefix][label]=dict(native_residual=r, independent_residual=independent,
                original_bound=b, independently_scaled_bound=mathematical_bound,
                original_factor=64, explicit_dtype=str(dtype), passed=True,backend=backend)
    return audits


def run_one(inputs, row, backend, reference64=False, observed=None):
    import drainage_primitives_pbf as main_trial
    import perched_primitives_pbk as perched_trial
    import adaptive_main_pbi as main
    import adaptive_main_pbg as original_main64
    import adaptive_perched_pbk as perched
    if backend=='cuda':
        import cupy as xp
    elif backend=='jax':
        import jax.numpy as xp
    else:
        xp=np
    c,p,u=(xp.asarray(inputs[k]) for k in ('cells','parameters','interval'))
    dtype=inputs['cells'].dtype
    assert c.dtype==p.dtype==u.dtype==dtype
    assert all(descriptor(host(v))==descriptor(inputs[k]) for k,v in zip(('cells','parameters','interval'),(c,p,u)))
    kind=row['kind']; selector=main_trial if kind=='main' else perched_trial
    primitive=getattr(selector,'run_'+backend+('_perched' if kind=='perched' else ''))
    observed={} if observed is None else observed
    observed.update(actual_trial_calls=0,actual_full_calls=0,trial_attempted=0,full_attempted=0,phase={})
    started=time.monotonic()
    observed['trial_attempted']+=1
    diag,t=primitive(c[None],p[None],u[None]);t=t[0]
    observed['actual_trial_calls']+=1
    values={}
    for i,name in enumerate(main_trial.DIAGNOSTIC_FIELDS):values['diagnosis.'+name]=host(diag[0,i])
    for start,name in [(13,'main_weights'),(17,'perched_weights'),(21,'ice_fraction'),(25,'saturation')]:
        values['diagnosis.'+name]=host(diag[0,start:start+4])
    names=['front','potential_requested_kg_m2','drained_kg_m2','unavailable_liquid_kg_m2',
           'band_exhaustion_kg_m2','liquid_limited','water_residual_kg_m2','energy_residual_j_m2',
           'water_bound_kg_m2','energy_bound_j_m2']
    for i,name in enumerate(names):values['trial.'+name]=host(t[i])
    for key,start in [('layer_mass_kg_m2',10),('layer_enthalpy_j_m2',14),('water_after',18),('enthalpy_after',22)]:
        values['trial.'+key]=host(t[start:start+4])
    if kind=='perched':
        for i,name in enumerate(('main_depth_for_Sy','specific_yield','first_donor'),26):values['trial.'+name]=host(t[i])
    # Match the exact primitive summation order on its actual backend.
    for col,start,boundkey in [(4,10,'water_bound_kg_m2'),(5,14,'energy_bound_j_m2')]:
        total=xp.asarray(0.,dtype)
        after=t[(18 if col==4 else 22):(22 if col==4 else 26)]
        for k in range(4):total=total+((xp.abs(c[k,col])+xp.abs(after[k]))+xp.abs(t[start+k]))
        expected=64*xp.finfo(dtype).eps*xp.maximum(total,1)
        assert bool(t[8 if col==4 else 9]==expected), ('original trial bound',boundkey)
    metadata={}; observer={}
    if row['full']:
        controls=IntegrationControls(**row['controls'])
        execute=perched.advance_perched_band if kind=='perched' else (original_main64.advance_main_band if reference64 else main.advance_main_band)
        with phase_observer(backend,dtype) as observer:
            observed['phase']=observer
            observed['full_attempted']+=1
            final,front,ledger=execute(c,p,int(inputs['option']),*[float(x) for x in inputs['interval']],controls,backend=backend)
            observed['actual_full_calls']+=1
        values['full.cells']=host(final);values['full.front']=host(front)
        values['full.water_after']=host(final[:,4]);values['full.enthalpy_after']=host(final[:,5])
        for key,value in ledger.items():
            if isinstance(value,str):metadata[key]=value
            else:values['full.'+key]=host(value)
        # No artificial float64 widening of an explicitly requested device result.
        assert final.dtype==front.dtype==dtype
        assert all(ledger[k].dtype==dtype for k in ('layer_mass_kg_m2','layer_enthalpy_j_m2'))
        for col,flow,bound in [(4,'layer_mass_kg_m2','water_bound_kg_m2'),(5,'layer_enthalpy_j_m2','energy_bound_j_m2')]:
            expected=64*xp.finfo(dtype).eps*xp.maximum(xp.sum(xp.abs(c[:,col])+xp.abs(final[:,col])+xp.abs(ledger[flow])),1)
            assert bool(ledger[bound]==expected), ('original full bound',bound)
        assert ledger['clock_residual_seconds']==0 and ledger['elapsed_seconds']==float(inputs['interval'][0])
        metadata['controls']=asdict(controls)
    assert all(np.all(np.isfinite(a)) for a in values.values())
    assert all(descriptor(host(v))==descriptor(inputs[k]) for k,v in zip(('cells','parameters','interval'),(c,p,u)))
    return values,dict(backend=backend,seconds=time.monotonic()-started,phase=observer,
                       actual_trial_calls=observed['actual_trial_calls'],actual_full_calls=observed['actual_full_calls'],
                       trial_attempted=observed['trial_attempted'],full_attempted=observed['full_attempted'],
                       returned_nonnumeric=metadata,hard_ledgers=hard_audit(inputs,values,backend),
                       transferred_inputs_byteexact=True)

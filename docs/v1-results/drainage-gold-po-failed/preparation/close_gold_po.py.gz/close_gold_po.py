"""Stdlib closeout after actual F0; never creates/replaces a numerical reference."""
from pathlib import Path
import argparse
import json
import shutil
from contract_po import save,sha,HERE,closed_gold


def main():
    p=argparse.ArgumentParser()
    for key in ('result','qstat','output'):p.add_argument('--'+key,type=Path,required=True)
    a=p.parse_args();assert not a.output.exists()
    receipt=json.loads((a.result/'export-receipt.json').read_bytes())
    assert receipt['passed'] and receipt['child_returncode']==0 and receipt['source_and_controls_unchanged']
    assert receipt['controls_manifest_sha256']==sha((HERE/'CONTROLS_SHA256.json').read_bytes())
    assert (a.result/'export-parent-exit.txt').read_text().strip()=='0'
    shutil.copytree(a.result/'gold',a.output)
    for name in ('export-receipt.json','export-parent-exit.txt','child-exit.txt','export.stdout.txt','export.stderr.txt','checker.stdout.txt','checker.stderr.txt','command.json','controller.log','SOURCE_SHA256.json'):
        shutil.copyfile(a.result/name,a.output/name)
    shutil.copyfile(a.qstat,a.output/'export-qstat-final.txt')
    index={p.relative_to(a.output).as_posix():sha(p.read_bytes()) for p in a.output.rglob('*') if p.is_file()}
    save(a.output/'gold-inventory.json',index)
    seal=dict(pbs_job=receipt['pbs_job'],gold_inventory_sha256=sha((a.output/'gold-inventory.json').read_bytes()),
        qstat_final_sha256=sha(a.qstat.read_bytes()),controls_manifest_sha256=receipt['controls_manifest_sha256'],
        source_manifest_sha256=receipt['source_manifest_sha256'],actual_gold=True,GPU_runs=0)
    seal_path=a.output.with_name(a.output.name+'-seal.json');save(seal_path,seal)
    closed_gold(a.output,seal_path)


if __name__=='__main__':main()

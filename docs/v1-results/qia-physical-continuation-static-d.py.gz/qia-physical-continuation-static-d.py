"""Windows metadata/hash/AST only; all array comparisons ran on xuanze."""
from pathlib import Path
import ast,datetime,gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parents[2];e=r/'docs/v1-results';sha=lambda v:hashlib.sha256(v).hexdigest()
groups={'qia-physical-cuda-day-c':'9c43be0072770e4e32fcc59b6d7ed4f6b4cb8f4cb339f5c606d591563f6b8396','qia-physical-cuda-year-launch-d':'245d47ca3eab271b2cb864f3a846abe7299e42297cfe9bdf23982bb7d962d88c'}
data={};count=0
for group,digest in groups.items():
    assert sha((r/'outputs/v1'/(group+'-evidence.tar.gz')).read_bytes())==digest
    manifest=json.loads((e/group/'manifest.json').read_text());assert manifest['archive_sha256']==digest
    for item in manifest['artifacts']:
        raw=(e/group/item['path']).read_bytes();assert sha(raw)==item['stored_sha256']
        if item['path']==item['source']+'.gz':raw=gzip.decompress(raw)
        assert sha(raw)==item['source_sha256'];data[group,item['source']]=raw;count+=1
        if item['source'].endswith('.py'):ast.parse(raw.decode('utf-8-sig'))
assert count==47
read=lambda group,name:json.loads(data[group,name])
m=json.loads((r/'outputs/v1/p6-most-physical-c-source.json').read_text())
assert read('qia-physical-cuda-day-c','SOURCE_SHA256.json')==m
assert all(sha((r/n).read_bytes())==h for n,h in m.items() if n.startswith(('src/','tests/','benchmarks/')))
assert read('qia-physical-cuda-day-c','exit.json')['returncode']==1
assert read('qia-physical-cuda-day-c','trajectory/batch.json')['status']=='running'
assert read('qia-physical-cuda-day-c','trajectory/batch.json')['steps_completed']==48
assert read('qia-physical-cuda-day-c','day48-primary-audit-exit.json')['actual_returncode']==1
assert read('qia-physical-cuda-day-c','day48-primary-audit-b-exit.json')['actual_returncode']==0
d=read('qia-physical-cuda-day-c','day48-primary-audit-b.json')
assert d['source_unchanged'] and d['device_barrier_complete'] and d['primary_cold_fields_exact']==26 and d['previous_cuda48_trace_fields_exact']==22 and len(d['excluded_reference_shadow_fields'])==22
launch=read('qia-physical-cuda-year-launch-d','launch.json');assert launch['seed_day_archive_sha256']==groups['qia-physical-cuda-day-c']
assert read('qia-physical-cuda-year-launch-d','captured-batch.json')['status']=='running'
assert read('qia-physical-cuda-year-launch-d','captured-batch.json')['steps_completed']==96
assert read('qia-physical-cuda-year-launch-d','captured-batch.json')['same_precision_max_absolute'] is None
out=dict(scope='Local metadata/hash/AST only,no model/pytest/array comparisons. Actual xuanze C physical48 preserved despite parent postprocessing1; ISO text-dtype audit1 and corrected GPU26primary/22trace actual0 retained. Same frozen509C source copied owned valid prefix to D,live96 snapshot,no failed-physics/source-changed prefix resumed or science/year/currentGPU340 acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),archive_sha256=groups,artifacts_verified=47,model_source_and_tests_unchanged=True,original_parent_returncode=1,physical_prefix_steps=48,cold_primary_fields_exact=26,previous_cuda_trace_fields_exact=22,continuation_snapshot_steps=96,same_precision=None,script_sha256=sha(Path(__file__).read_bytes()))
(e/'qia-physical-continuation-static-d.json').write_text(json.dumps(out,indent=2)+'\n');(e/'qia-physical-continuation-static-d.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print(json.dumps(out))

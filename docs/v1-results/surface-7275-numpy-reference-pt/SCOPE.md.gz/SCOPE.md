# PT-b original NumPy surface reference

1681.manager closed F / Exit 1 / Stageout 0. Exactly three original NumPy surface calls were attempted on compute002: Qia raised the original canopy Newton error; Cha and HaM returned and both complete API tuples are saved. No retry, model edit, full-column step, GPU call, or year continuation occurred.

The actual PR represented float32 input values were lifted to NumPy64 using the unchanged helper. NumPy retains its original solver settings and cache, so this is an independent physical reference, not the same floating-point algorithm. PR remains a failed CUDA model call.

The initial c4a1 stage was prepared but never submitted; executed PT-b f5ff stage adds transparent preservation of the complete original surface tuple. WP's earlier review covers only the unchanged helper; root separately reviewed the PT-b runner and PBS.

Original binary result and stage archives are retained unchanged. Flat result members are included for inspection. Empty PBS output did not exist; controller and child logs are all present. Source TMPDIR was cleaned after PBS; the run's exact 584-file before/after manifests and approved source archive remain preserved.

# PT: actual PR input, three NumPy references, prepared only

One bounded EHPC compute002 job: 1 CPU, 2 GiB, 20 minutes; existing closeout
Python and NumPy test-deps. No GPU, JAX, full-column step, annual continuation,
source edit, altered solver tolerance or initial guess. This directory has not
been deployed or submitted. Root reviews the frozen controls before submission.

The actual 72-member PR archive is fixed in BINDINGS. Its original CUDA child
exit1 and zero completed steps remain unchanged. The capture is PR's new actual
reconstruction at checkpoint7275, not an originally saved failed-forward packet.
The one captured MOST call has three rows in original Qia/Cha/HaM order. Its
actual kernel coefficients are used, not nominal Python floats repacked to32.
The nine base arrays plus actual extension/VIC are byte-bound to the wrapper
input. The actual radiation and aging tables remain original diagnostic data;
they are not supplied to the independent NumPy physical calculation.

`surface_reference.py` is the exact previously reviewed helper, without changes.
The CLI authenticates the full PR archive/inventory and each selected packet,
then validates every NPZ descriptor's dtype/shape/payload before decoding. It
outputs original raw741 per row and the explicit341/362/433/509/733 fields,
physical11[496:507], phase coordinates10[716:726], heat residual9[311:320] and
tolerance9[328:337], counters508/732, and all original failure facts. Counters
are reported without treating them as observed function-call counts or assigning
a failure cause from max_solver_residual alone.

Three separate sequential row workers each have a 300-second timeout. Each
invokes the original NumPy surface_step once, with a transparent call counter
that leaves arguments, return and exceptions unchanged. A row failure or
timeout does not prevent the other rows from running. Raw Python return objects
are saved as protocol5 pickle before a full typed JSON/NPZ export. Every nested
array, scalar, dictionary, sequence and dataclass field is retained; unsupported
serialization fails explicitly with the original pickle already saved. Full
tracebacks, row stdout/stderr, child return codes and partial receipts persist.

The original common-field science and hard M/H/tracer checks remain unchanged.
They are diagnostic checks against a known failed GPU row, not a claim that it
passed. Raw full output is preserved; compatible common-field differences are
not a comparison of all741 fields. A successful PT job means all three NumPy
returns/comparison artifacts were saved; an original comparison failure is
recorded and never turns PR CUDA failure into acceptance. A NumPy exception or
timeout yields a nonzero PT parent after the remaining rows are attempted.

All584 original source files, the complete original PR capture and every control
are hash-checked. Source remains an isolated TMPDIR sibling, not the production
or active model tree. Results include source before/after hashes and the exact
captured packet bytes. Submission explicitly transfers the same stage to manager
and compute002; there is no shared-/tmp assumption. Scheduler F/Exit/Stageout and
actual logs must be retained before a numerical result is declared closed.

"""Three actual PR surface rows, original NM NumPy solver, EHPC only."""
import argparse
from dataclasses import fields, is_dataclass
import hashlib
import io
import json
import os
from pathlib import Path
import pickle
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-surface-numpy-reference-pt')
HERE = Path(__file__).resolve().parent
CALL = 'run/result/surface/call-0001'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def archive_files(path, expected):
    raw = Path(path).read_bytes()
    assert sha(raw) == expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: archive.extractfile(m).read() for m in members}


def authenticate_pr(path, binding):
    files = archive_files(path, binding['PR_archive_sha256'])
    assert len(files) == 72
    inventory = json.loads(files['artifact-inventory.json'])
    assert set(inventory) == set(files) - {'artifact-inventory.json'}
    assert all(sha(files[n]) == r['sha256'] and len(files[n]) == r['bytes'] for n, r in inventory.items())
    for n, expected in binding['PR_packet_members'].items():
        assert sha(files[n]) == expected
    receipt = json.loads(files['run/result/receipt.json'])
    parent = json.loads(files['run/exit.json'])
    assert parent['actual_parent_returncode'] == 1 and parent['model_call_passed'] is False
    assert parent['receipt_sha256'] == sha(files['run/result/receipt.json'])
    assert receipt['actual_batch_step_calls'] == 1 and receipt['actual_batch_step_returns'] == 0
    assert receipt['complete_failed_surface_capture'] and receipt['trajectory_steps_committed'] == 0
    assert receipt['source_manifest_sha256'] == binding['source_manifest_sha256']
    assert all(receipt[k]['unchanged'] and receipt[k]['checked_files'] == 1252 and not receipt[k]['mismatches']
               for k in ('before_immutable', 'after_immutable'))
    context = json.loads(files[CALL + '/input.json'])['metadata']
    assert context['cases'] == binding['cases'] and context['input_index_zero_based'] == 7275
    assert context['canopy_optics'] is None and context['call'] == 1
    assert context['source_manifest_sha256'] == binding['source_manifest_sha256']
    return files, context


def typed_arrays(files, name):
    """Read every original descriptor; no dtype conversion or dataclass rebuild."""
    import numpy as np
    metadata = json.loads(files[CALL + '/' + name + '.json'])
    raw = files[CALL + '/' + name + '.npz']
    assert metadata['schema'] == 'PR-typed-tree-v1' and sha(raw) == metadata['npz_sha256']
    descriptors = {}
    def walk(node):
        if isinstance(node, dict):
            if node.get('kind') == 'array':
                assert node['key'] not in descriptors
                descriptors[node['key']] = node
            for child in node.values():
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)
    walk(metadata['tree'])
    with np.load(io.BytesIO(raw), allow_pickle=False) as stream:
        assert set(stream.files) == set(descriptors) and len(stream.files) == metadata['array_count']
        values = {k: stream[k] for k in stream.files}
    for key, array in values.items():
        d = descriptors[key]
        assert type(array) is np.ndarray and array.dtype.str == d['dtype'] and list(array.shape) == d['shape']
        assert sha(array.tobytes(order='C')) == d['c_order_sha256']
        array.flags.writeable = False
    return metadata, values


def captured_inputs(files, binding):
    import numpy as np
    kernel, values = typed_arrays(files, 'kernel-input')
    actual_input, original = typed_arrays(files, 'input')
    _, raw_values = typed_arrays(files, 'raw-output')
    _, flags_values = typed_arrays(files, 'result-flags')
    assert kernel['metadata']['flags'] == dict(extended=True, vic=True, stems=False, profiled=False)
    assert kernel['metadata']['original_argument_count'] == 16
    assert kernel['metadata']['original_tail_indices'] == dict(radiation=-5, coefficients=-4, aging=-3, excluded_output=-2, n=-1)
    nodes = kernel['tree']['items']['arguments_without_output']['items']
    assert len(nodes) == 15 and all(node['kind'] == 'array' for node in nodes)
    args = tuple(values[node['key']] for node in nodes)
    assert args[-1].dtype == np.int32 and args[-1].shape == () and int(args[-1]) == 3
    assert args[12].shape == (10,) and args[12].dtype == np.float32
    assert set(actual_input['tree']['items']['kwargs']['items']) == {'parameters', 'exchange_extension', 'vic'}
    for k in range(9):
        assert args[k].dtype == original['value/args/' + str(k)].dtype
        assert args[k].shape == original['value/args/' + str(k)].shape
        assert args[k].tobytes() == original['value/args/' + str(k)].tobytes()
    for k, name in ((9, 'exchange_extension'), (10, 'vic')):
        assert args[k].tobytes() == original['value/kwargs/' + name].tobytes()
    raw = raw_values['value/raw741']
    assert raw.shape == (3, 741) and raw.dtype == np.float32
    # Validate the captured result-flags against original raw unpacking later;
    # do not interpret NumPy's truthiness of an arbitrary raw slot as a diagnosis.
    return args, raw, flags_values


def dump_return(path, value):
    """Preserve full raw Python return first, then every typed leaf losslessly."""
    import numpy as np
    path = Path(path)
    with path.with_suffix('.pkl').open('wb') as stream:
        pickle.dump(value, stream, protocol=5)
    arrays = {}
    def encode(obj, name):
        if isinstance(obj, np.ndarray) or isinstance(obj, np.generic):
            array = np.asarray(obj)
            assert array.dtype.kind != 'O'
            assert name not in arrays
            arrays[name] = array
            return dict(kind='array', key=name, dtype=array.dtype.str, shape=list(array.shape), c_order_sha256=sha(array.tobytes(order='C')))
        if is_dataclass(obj):
            return dict(kind='dataclass', module=type(obj).__module__, name=type(obj).__name__,
                        fields={f.name: encode(getattr(obj, f.name), name + '/' + f.name) for f in fields(obj)})
        if isinstance(obj, dict):
            assert all(type(k) is str for k in obj)
            return dict(kind='dict', items={k: encode(v, name + '/' + k) for k, v in obj.items()})
        if isinstance(obj, (tuple, list)):
            return dict(kind=type(obj).__name__, items=[encode(v, name + '/' + str(k)) for k, v in enumerate(obj)])
        if type(obj) is float:
            return dict(kind='float', hex=obj.hex())
        if obj is None or type(obj) in (bool, int, str):
            return dict(kind=type(obj).__name__, value=obj)
        raise TypeError('Unserialized original return type: ' + str(type(obj)))
    tree = encode(value, 'return')
    np.savez_compressed(path.with_suffix('.npz'), **arrays)
    save(path.with_suffix('.json'), dict(schema='PT-lossless-return-v1', tree=tree, array_count=len(arrays),
        npz_sha256=sha(path.with_suffix('.npz').read_bytes()), pickle_sha256=sha(path.with_suffix('.pkl').read_bytes())))


def row_worker(root, index):
    import surface_reference as ref
    binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
    source = root.parent / 'source-nm'
    ref.bind_source(source)
    files, context = authenticate_pr(STAGE / 'pr-evidence.tar.gz', binding)
    args, raw, flag_arrays = captured_inputs(files, binding)
    import numpy as np
    output = root / ('row-' + str(index))
    output.mkdir()
    started = time.monotonic()
    record = dict(row=index, case=context['cases'][index], reference_returned=False,
                  complete_return_saved=False, comparison_saved=False,
                  surface_step_calls_started=0, surface_step_calls_returned=0)
    # Transparent count only: the reference's actual surface_step, not solver
    # iterations, is counted. The original argument/return objects are unchanged.
    import noahmp_clm.physics.canopy_column as column
    original_step = column.surface_step
    def counted(*a, **kw):
        record['surface_step_calls_started'] += 1
        result = original_step(*a, **kw)
        record['surface_step_calls_returned'] += 1
        return result
    column.surface_step = counted
    try:
        d, identity = ref.reference_one(source, args[:9], index, coefficients=args[12], profiled=False,
                                       exchange_extension=args[9], vic=args[10], stem_area=None, canopy_optics=None)
        record['reference_returned'] = True
        dump_return(output / 'original-return', d)
        record['complete_return_saved'] = True
        save(output / 'input-identity.json', identity)
        comparison = ref.compare_row(source, args[:9], raw, index, d)
        dump_return(output / 'comparison', comparison)
        record['comparison_saved'] = True
        record['original_checks'] = {name: value['passed'] for name, value in comparison['checks'].items()}
        record['maximum_absolute_differences'] = comparison['common_numeric_differences']
        record['reference_surface_root_converged'] = bool(d['surface_root_converged'])
        record['reference_surface_root_residual_k'] = float(d['surface_root_residual_k'])
        record['reference_energy_residual_jm2'] = float(d['energy_residual_jm2'])
        record['reference_water_residual_kgm2'] = float(d['water_residual_kgm2'])
    except BaseException:
        record['exception_traceback'] = traceback.format_exc()
        (output / 'traceback.txt').write_text(record['exception_traceback'])
    finally:
        column.surface_step = original_step
        ref.bind_source(source)
        record.update(seconds=time.monotonic() - started,
                      original_CUDA_model_call_passed=False, scientific_year_acceptance=False)
        save(output / 'receipt.json', record)
    print(json.dumps(record, allow_nan=False), flush=True)
    return 0 if record['complete_return_saved'] and record['comparison_saved'] else 1


def controller(root):
    binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    source = root.parent / 'source-nm'
    assert not source.exists()
    source.mkdir()
    started = time.monotonic()
    receipt = dict(passed=False, purpose='Three-row diagnostic reference, not a repaired GPU run or annual acceptance',
                   pbs_job=os.environ['PBS_JOBID'], actual_children=[], full_column_calls=0, GPU_calls=0,
                   PR_original_child_returncode=1, source_files=584)
    try:
        stage_index = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        shutil.copytree(HERE, root / 'controls')
        files = archive_files(STAGE / 'source.tar.gz', binding['source_archive_sha256'])
        source_manifest = json.loads(files['SOURCE_SHA256.json'])
        assert len(source_manifest) == 584 and set(files) == set(source_manifest) | {'SOURCE_SHA256.json'}
        assert sha(files['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
        assert all(sha(files[n]) == h for n, h in source_manifest.items())
        for n, raw in files.items():
            target = source / n
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        import surface_reference as ref
        ref.bind_source(source)
        capture, context = authenticate_pr(STAGE / 'pr-evidence.tar.gz', binding)
        args, raw, flag_arrays = captured_inputs(capture, binding)
        decoded, facts = ref.inspect_raw_output(source, raw)
        import numpy as np
        for key, values in flag_arrays.items():
            name = key.removeprefix('value/')
            assert name in decoded and values.dtype == np.asarray(decoded[name]).dtype
            assert values.shape == np.asarray(decoded[name]).shape and values.tobytes() == np.asarray(decoded[name]).tobytes()
        raw_rows = []
        for k, case in enumerate(context['cases']):
            raw_rows.append(dict(case=case, row=k, facts=facts[k],
                physical_residual_496_507=raw[k, 496:507].tolist(), phase_coordinates_716_726=raw[k, 716:726].tolist(),
                heat_residual_311_320=raw[k, 311:320].tolist(), heat_tolerance_328_337=raw[k, 328:337].tolist(),
                full_raw741=raw[k].tolist()))
        save(root / 'actual-raw741.json', dict(rows=raw_rows, source='Original PR actual raw packet, read on EHPC',
            note='Raw iteration/restart counters are original implementation fields, not observed call counts.'))
        for name in ('call.json', 'input.json', 'input.npz', 'kernel-input.json', 'kernel-input.npz',
                     'raw-output.json', 'raw-output.npz', 'result-flags.json', 'result-flags.npz', 'traceback.txt'):
            (root / ('PR-' + name)).write_bytes(capture[CALL + '/' + name])
        save(root / 'context.json', context)
        save(root / 'source-before.json', {n: sha((source / n).read_bytes()) for n in source_manifest})
        env = os.environ.copy()
        env.update(PYTHONPATH=str(source / 'src') + ':' + str(source / 'tests') + ':' + str(HERE) + ':/home/zhangyq/noahmp-v1/test-deps',
                   PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        env.pop('PYTHONHOME', None)
        for index in range(3):
            command = [sys.executable, '-B', str(Path(__file__)), 'row', str(root), '--index', str(index)]
            entry = dict(row=index, command=command, timed_out=False, actual_child_returncode=None)
            with (root / ('row-' + str(index) + '.stdout')).open('wb') as out, (root / ('row-' + str(index) + '.stderr')).open('wb') as err:
                try:
                    child = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=300)
                    entry['actual_child_returncode'] = child.returncode
                except subprocess.TimeoutExpired:
                    entry['timed_out'] = True
                    entry['error'] = traceback.format_exc()
            receipt['actual_children'].append(entry)
            save(root / 'partial-receipt.json', receipt)
        after = {n: sha((source / n).read_bytes()) for n in source_manifest}
        save(root / 'source-after.json', after)
        assert after == source_manifest
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        receipt.update(source_controls_capture_unchanged=True,
                       source_archive_sha256=binding['source_archive_sha256'], PR_archive_sha256=binding['PR_archive_sha256'])
        receipt['passed'] = all(r['actual_child_returncode'] == 0 and not r['timed_out'] for r in receipt['actual_children'])
    except BaseException:
        receipt['exception_traceback'] = traceback.format_exc()
        (root / 'traceback.txt').write_text(receipt['exception_traceback'])
    receipt['seconds'] = time.monotonic() - started
    save(root / 'receipt.json', receipt)
    print(json.dumps(receipt, allow_nan=False), flush=True)
    return 0 if receipt['passed'] else 1


def main():
    assert os.name != 'nt' and socket.gethostname().split('.')[0] == 'compute002' and os.environ.get('PBS_JOBID')
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('run', 'row'))
    parser.add_argument('root', type=Path)
    parser.add_argument('--index', type=int, choices=range(3))
    args = parser.parse_args()
    if args.mode == 'row':
        assert args.index is not None
        return row_worker(args.root.resolve(), args.index)
    return controller(args.root.resolve())


if __name__ == '__main__':
    raise SystemExit(main())

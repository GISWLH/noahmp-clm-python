"""Freeze the reviewed helper and actual PR schema using stdlib only."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile
import zipfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'surface-7275-numpy-reference-pt-preparation'
BASE = OUT / 'surface-7275-numpy-reference-preparation'
sha = lambda value: hashlib.sha256(value).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def members(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        items = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in items)
        assert len(items) == len({m.name for m in items})
        return {m.name: archive.extractfile(m).read() for m in items}


def npz_headers(raw):
    result = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        for name in archive.namelist():
            value = archive.read(name)
            assert value[:6] == b'\x93NUMPY' and name.endswith('.npy')
            major, minor = value[6:8]
            assert minor == 0 and major in (1, 2)
            offset = 10 if major == 1 else 12
            size = struct.unpack('<H' if major == 1 else '<I', value[8:offset])[0]
            header = ast.literal_eval(value[offset:offset + size].decode('latin1'))
            assert header['fortran_order'] is False and header['descr'] in ('<f4', '<f8', '<i4', '<i8', '|b1')
            result[name[:-4]] = dict(dtype=header['descr'], shape=list(header['shape']),
                c_order_sha256=sha(value[offset + size:]))
    return result


def main():
    original_index = (BASE / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(original_index) == '58a672aa4efc821040ee2cfcaa93fe357d18ed96343595bcef0426d2e89ba983'
    original = json.loads(original_index)
    assert all(sha((BASE / n).read_bytes()) == h for n, h in original.items())
    core = (BASE / 'surface_reference.py').read_bytes()
    (PREP / 'surface_reference.py').write_bytes(core)
    pr_raw = (OUT / 'failed-surface-probe-pr-evidence.tar.gz').read_bytes()
    assert sha(pr_raw) == '9e52badfc6d8fd1f8fd39b118adff3d1777daafc7af6b7d2d8541b863e445db8'
    pr = members(pr_raw)
    inventory = json.loads(pr['artifact-inventory.json'])
    assert len(pr) == 72 and set(inventory) == set(pr) - {'artifact-inventory.json'}
    assert all(sha(pr[n]) == r['sha256'] and len(pr[n]) == r['bytes'] for n, r in inventory.items())
    source_raw = (OUT / 'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    assert sha(source_raw) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
    source = members(source_raw)
    source_index = json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index) == 584 and set(source) == set(source_index) | {'SOURCE_SHA256.json'}
    assert all(sha(source[n]) == h for n, h in source_index.items())
    assert pr['run/source-manifest.json'] == source['SOURCE_SHA256.json']
    prefix = 'run/result/surface/call-0001/'
    schema_proof = {}
    for name in ('input', 'kernel-input', 'raw-output', 'result-flags'):
        metadata = json.loads(pr[prefix + name + '.json'])
        assert metadata['schema'] == 'PR-typed-tree-v1' and sha(pr[prefix + name + '.npz']) == metadata['npz_sha256']
        descriptors = {}
        def walk(value):
            if isinstance(value, dict):
                if value.get('kind') == 'array':
                    assert value['key'] not in descriptors
                    descriptors[value['key']] = {k: value[k] for k in ('dtype', 'shape', 'c_order_sha256')}
                for child in value.values():
                    walk(child)
            elif isinstance(value, list):
                for child in value:
                    walk(child)
        walk(metadata['tree'])
        assert npz_headers(pr[prefix + name + '.npz']) == descriptors
        assert len(descriptors) == metadata['array_count']
        schema_proof[name] = dict(array_count=len(descriptors), arrays=descriptors)
    kernel = schema_proof['kernel-input']['arrays']
    original_input = schema_proof['input']['arrays']
    assert all(kernel['value/arguments_without_output/' + str(k)] == original_input['value/args/' + str(k)] for k in range(9))
    for k, name in ((9, 'exchange_extension'), (10, 'vic')):
        assert kernel['value/arguments_without_output/' + str(k)] == original_input['value/kwargs/' + name]
    context = json.loads(pr[prefix + 'input.json'])['metadata']
    assert context['cases'] == ['CN-Qia-suction-climate-cycle', 'CN-Cha-suction-climate-cycle', 'CN-HaM-suction-climate-cycle']
    assert context['canopy_optics'] is None
    binding = dict(source_archive_sha256=sha(source_raw), source_manifest_sha256=sha(source['SOURCE_SHA256.json']),
        PR_archive_sha256=sha(pr_raw), PR_packet_members={n: sha(b) for n, b in pr.items() if n.startswith(prefix)},
        original_core_manifest_sha256=sha(original_index), original_core_sha256=sha(core),
        independent_core_review_sha256='0e1f947dcc2d5e89a067ded527caf63bcbaabb1d2804efeb51664019070e4f83',
        cases=context['cases'], planned_surface_calls=3, planned_full_column_calls=0, GPU_calls=0,
        prepared_only=True, numerical_executed=False, PBS_submitted=False)
    (PREP / 'BINDINGS.json').write_bytes(encode(binding))
    (PREP / 'ACTUAL_PR_SCHEMA.json').write_bytes(encode(schema_proof))
    for p in PREP.glob('*.py'):
        compile(ast.parse(p.read_bytes()), str(p), 'exec')
    controls = {p.name: sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    (PREP / 'CONTROLS_SHA256.json').write_bytes(encode(controls))
    stage = {'source.tar.gz': source_raw, 'pr-evidence.tar.gz': pr_raw}
    stage.update({'controls/' + p.name: p.read_bytes() for p in PREP.iterdir() if p.is_file()})
    stage['stage-inventory.json'] = encode({n: sha(b) for n, b in sorted(stage.items())})
    target = OUT / 'surface-7275-numpy-reference-pt-stage.tar.gz'
    with target.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for name, raw in sorted(stage.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode = len(raw), 0o644
                archive.addfile(member, io.BytesIO(raw))
    assert members(target.read_bytes()) == stage
    report = dict(passed=True, prepared_only=True, stage_sha256=sha(target.read_bytes()), stage_members=len(stage),
        controls_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()), controls=len(controls),
        source_files=584, source_manifest_sha256=binding['source_manifest_sha256'],
        PR_archive_sha256=sha(pr_raw), PR_members=72, captured_array_descriptors=sum(v['array_count'] for v in schema_proof.values()),
        original_helper_exact=True, planned_surface_rows=3, numerical_executed=False, PBS_submitted=False)
    (OUT / 'surface-7275-numpy-reference-pt-static.json').write_bytes(encode(report))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

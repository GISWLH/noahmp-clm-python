"""Stdlib-only closed PT-b verification: raw hashes, typed headers, actual failures."""
import ast
import base64
import gzip
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import struct
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
LABEL = 'surface-7275-numpy-reference-pt'
CONTROL = '15b4eab4bfa501bd09ea9d3e7bb693ae3802c15f8ad51c5d775644afba98d317'
STAGE = 'f5ff398fc9475da76c8f133b66fa110984c33e47f6f93018015735534cf42612'
RESULT = '236405c91b6b7123f116c6c1a541aa1522442a558acde47daf6ca644bc6a7f4a'
PR = '9e52badfc6d8fd1f8fd39b118adff3d1777daafc7af6b7d2d8541b863e445db8'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda obj: (json.dumps(obj, indent=2, allow_nan=False) + '\n').encode()


def files(raw, directories=False):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for member in archive.getmembers():
            if directories and member.isdir():
                continue
            assert member.isfile()
            name = member.name.removeprefix('./')
            assert name not in result and not PurePosixPath(name).is_absolute()
            assert '..' not in PurePosixPath(name).parts and '\\' not in name
            result[name] = archive.extractfile(member).read()
    return result


def descriptors(node):
    result = {}
    def walk(value):
        if isinstance(value, dict):
            if value.get('kind') == 'array':
                assert value['key'] not in result
                result[value['key']] = value
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(node)
    return result


def typed_packet(raw, metadata):
    """Hash opaque NPY payloads; never decode arrays or import a numeric package."""
    assert sha(raw) == metadata['npz_sha256']
    expected = descriptors(metadata['tree'])
    assert len(expected) == metadata['array_count']
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == {name + '.npy' for name in expected}
        for name, descriptor in expected.items():
            data = archive.read(name + '.npy')
            assert data[:6] == b'\x93NUMPY'
            version = tuple(data[6:8])
            assert version in ((1, 0), (2, 0), (3, 0))
            width = 2 if version == (1, 0) else 4
            length = int.from_bytes(data[8:8 + width], 'little')
            header = ast.literal_eval(data[8 + width:8 + width + length].decode())
            payload = data[8 + width + length:]
            assert header['fortran_order'] is False
            assert header['descr'] == descriptor['dtype'] and list(header['shape']) == descriptor['shape']
            assert re.fullmatch(r'[<|>][fibucmM?][0-9]+', header['descr'])
            size = int(header['descr'][2:])
            assert len(payload) == math.prod(header['shape']) * size
            assert sha(payload) == descriptor['c_order_sha256']
    return len(expected)


def scalar_tree(node):
    """Only already-computed scalar JSON readout; arrays stay descriptors."""
    kind = node['kind']
    if kind == 'float':
        return float.fromhex(node['hex'])
    if kind in ('int', 'bool', 'str', 'NoneType'):
        return node['value']
    if kind == 'dict':
        return {k: scalar_tree(v) for k, v in node['items'].items()}
    if kind in ('list', 'tuple'):
        return [scalar_tree(v) for v in node['items']]
    return node


def main():
    stage_raw = (BASE / (LABEL + '-b-stage.tar.gz')).read_bytes()
    original_raw = (BASE / (LABEL + '-b-result.tar.gz')).read_bytes()
    assert sha(stage_raw) == STAGE and sha(original_raw) == RESULT
    stage = files(stage_raw)
    index = json.loads(stage['stage-inventory.json'])
    assert len(stage) == 11 and set(index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[n]) == h for n, h in index.items())
    assert sha(stage['controls/CONTROLS_SHA256.json']) == CONTROL
    controls = json.loads(stage['controls/CONTROLS_SHA256.json'])
    # The frozen control manifest is the original name-to-hash map.
    assert len(controls) == 7 and all(sha(stage['controls/' + n]) == h for n, h in controls.items())
    source = files(stage['source.tar.gz'])
    source_index = json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index) == 584 and set(source) == set(source_index) | {'SOURCE_SHA256.json'}
    assert all(sha(source[n]) == h for n, h in source_index.items())
    assert sha(stage['pr-evidence.tar.gz']) == PR
    pr = files(stage['pr-evidence.tar.gz'])
    pr_index = json.loads(pr['artifact-inventory.json'])
    assert len(pr) == 72 and set(pr_index) == set(pr) - {'artifact-inventory.json'}
    assert all(sha(pr[n]) == r['sha256'] and len(pr[n]) == r['bytes'] for n, r in pr_index.items())
    original = files(original_raw, directories=True)
    assert len(original) == 56
    receipt = json.loads(original['receipt.json'])
    assert receipt['pbs_job'] == '1681.manager' and receipt['passed'] is False
    assert [r['actual_child_returncode'] for r in receipt['actual_children']] == [1, 0, 0]
    assert all(not r['timed_out'] for r in receipt['actual_children'])
    assert receipt['full_column_calls'] == receipt['GPU_calls'] == 0
    assert original['worker-exit.txt'].strip() == b'1'
    assert json.loads(original['source-before.json']) == json.loads(original['source-after.json']) == source_index
    assert receipt['source_controls_capture_unchanged']
    for n in ['CONTROLS_SHA256.json', *controls]:
        assert original['controls/' + n] == stage['controls/' + n]
    for name in ('call.json', 'input.json', 'input.npz', 'kernel-input.json', 'kernel-input.npz',
                 'raw-output.json', 'raw-output.npz', 'result-flags.json', 'result-flags.npz', 'traceback.txt'):
        assert original['PR-' + name] == pr['run/result/surface/call-0001/' + name]

    closure = BASE / (LABEL + '-closure')
    items = {'result/' + n: b for n, b in original.items()}
    for host in ('manager', 'compute'):
        remote = json.loads((closure / (host + '.stdout')).read_bytes())
        command = json.loads((closure / (host + '.json')).read_bytes())
        assert command['actual_exit'] == 0 and remote['all_stage_immutable']
        assert remote['stage_files_before'] == remote['stage_files_after'] == index
        if host == 'compute':
            assert remote['result_archive_sha256'] == RESULT
            assert base64.b64decode(remote['files']['pbs-exit.txt']).strip() == b'1'
        for name, data in remote['files'].items():
            items['closed-' + host + '/' + name] = base64.b64decode(data)
    qstat = (closure / 'qstat.stdout').read_text()
    assert json.loads((closure / 'qstat.json').read_bytes())['actual_exit'] == 0
    assert re.search(r'job_state = F\b', qstat) and 'Exit_status = 1' in qstat and 'Stageout_status = 0' in qstat
    assert json.loads(items['closed-manager/dispatch.json'])['stage_sha256'] == STAGE

    checked_npz, checked_arrays = 0, 0
    for name, raw in original.items():
        if name.endswith('.json'):
            metadata = json.loads(raw)
            if metadata.get('schema') in ('PT-lossless-return-v1', 'PR-typed-tree-v1'):
                checked_arrays += typed_packet(original[name[:-5] + '.npz'], metadata)
                checked_npz += 1
                if 'pickle_sha256' in metadata:
                    assert sha(original[name[:-5] + '.pkl']) == metadata['pickle_sha256']
    assert checked_npz == 10
    raw_rows = json.loads(original['actual-raw741.json'])['rows']
    assert len(raw_rows) == 3
    rows = []
    for k in range(3):
        row = json.loads(original[f'row-{k}/receipt.json'])
        assert json.loads(original[f'row-{k}.stdout']) == row
        assert row['surface_step_calls_started'] == 1 and row['surface_step_calls_returned'] == (0 if k == 0 else 1)
        assert not row['original_CUDA_model_call_passed'] and not row['scientific_year_acceptance']
        raw = raw_rows[k]
        assert raw['row'] == k and raw['case'] == row['case'] and len(raw['full_raw741']) == 741
        assert sha(struct.pack('<741f', *raw['full_raw741'])) == raw['facts']['raw_identity']['payload_sha256']
        assert raw['facts']['all_741_finite']
        if k == 0:
            assert row['reference_returned'] is False
            assert 'Newton stalled at iteration 30: residual=13.75804 W/m2' in row['exception_traceback']
            assert original['row-0/traceback.txt'].decode() == row['exception_traceback']
        else:
            assert row['reference_returned'] and row['full_surface_return_saved'] and row['complete_return_saved'] and row['comparison_saved']
            assert all(row['original_checks'].values())
            tree = json.loads(original[f'row-{k}/original-surface-step-return.json'])['tree']
            assert tree['kind'] == 'tuple' and len(tree['items']) == 4
            assert [tree['items'][i]['name'] for i in (0, 1)] == ['Snowpack', 'SoilEnthalpyState']
            checks = scalar_tree(json.loads(original[f'row-{k}/comparison.json'])['tree'])['checks']
            row['original_science_numbers'] = checks['original_surface_science']['original_return']
            row['original_hard_budget_numbers'] = checks['original_hard_budgets']['original_return']
        row['raw_GPU_facts'] = {n: v for n, v in raw.items() if n != 'full_raw741'}
        rows.append(row)
    readout = dict(pbs_job='1681.manager', job_state='F', exit_status=1, Stageout_status=0,
        actual_surface_calls_started=3, actual_surface_calls_returned=2, full_column_calls=0, GPU_calls=0,
        original_PR_failed=True, rows=rows, controller_seconds=receipt['seconds'],
        interpretation=['Qia original NumPy failed in canopy phase Newton; it is not an import or serialization failure.',
                        'Cha and HaM original full surface tuples are preserved; original science and hard-budget assertions passed.',
                        'The original NumPy and CUDA solvers have different tolerances, initialization and cache behavior; these facts do not identify precision as the sole cause.',
                        'Compatible diagnostic differences are not a full-741 same-precision check and do not grant an annual pass.'])
    verification = dict(passed=True, scope='Stdlib hashes, headers, opaque payloads, actual exit/receipts only; not numerical execution.',
        original_result_sha256=RESULT, source_files=584, source_before_after_exact=True,
        closed_remote_source_present=json.loads((closure / 'compute.stdout').read_bytes())['original_source_present'],
        controls_manifest_sha256=CONTROL, stage_sha256=STAGE, PR_archive_sha256=PR,
        actual_PBS_exit=1, actual_children=[1, 0, 0], original_result_files=56,
        typed_npz_packets=checked_npz, typed_array_descriptors=checked_arrays,
        original_pickle_hashes=True, all_741_JSON_values_bound_to_original_raw_payload=True,
        source_cleanup_note='Post-job source TMPDIR is absent; original executed before/after584 hashes and frozen stage are preserved.',
        PBS_output_presence=json.loads((closure / 'manager.stdout').read_bytes())['actual_presence']['pbs-output.log'])
    (BASE / (LABEL + '-readout.json')).write_bytes(encode(readout))
    (BASE / (LABEL + '-verification.json')).write_bytes(encode(verification))
    items['readout.json'] = encode(readout)
    items['verification.json'] = encode(verification)
    items['original-result.tar.gz'] = original_raw
    items['executed-stage.tar.gz'] = stage_raw
    initial = (BASE / (LABEL + '-stage.tar.gz')).read_bytes()
    assert sha(initial) == 'c4a1c517d31cc76a2a5de5ebc1308369bfdc0f7de138384d82cc66545d67f483'
    items['initial-unexecuted-stage.tar.gz'] = initial
    for directory in (BASE / (LABEL + '-deployment'), closure):
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                items[directory.name + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
    for name in ('prepare_surface_reference_pt.py', 'prepare_surface_reference_pt_initial.py',
                 'surface-7275-numpy-reference-pt-b-static.json', 'surface-7275-numpy-reference-pt-initial-static.json',
                 'deploy_surface_reference_pt.py', 'read_surface_reference_pt_status.py',
                 'read_surface_reference_pt_closed.py', 'collect_surface_reference_pt_closed.py',
                 'package_surface_reference_pt.py', 'surface-7275-numpy-reference-independent-review-wp.json'):
        items['provenance/' + name] = (BASE / name).read_bytes()
    items['SCOPE.md'] = b'''# PT-b original NumPy surface reference\n\n1681.manager closed F / Exit 1 / Stageout 0. Exactly three original NumPy surface calls were attempted on compute002: Qia raised the original canopy Newton error; Cha and HaM returned and both complete API tuples are saved. No retry, model edit, full-column step, GPU call, or year continuation occurred.\n\nThe actual PR represented float32 input values were lifted to NumPy64 using the unchanged helper. NumPy retains its original solver settings and cache, so this is an independent physical reference, not the same floating-point algorithm. PR remains a failed CUDA model call.\n\nThe initial c4a1 stage was prepared but never submitted; executed PT-b f5ff stage adds transparent preservation of the complete original surface tuple. WP's earlier review covers only the unchanged helper; root separately reviewed the PT-b runner and PBS.\n\nOriginal binary result and stage archives are retained unchanged. Flat result members are included for inspection. Empty PBS output did not exist; controller and child logs are all present. Source TMPDIR was cleaned after PBS; the run's exact 584-file before/after manifests and approved source archive remain preserved.\n'''
    inventory = {n: dict(sha256=sha(b), bytes=len(b)) for n, b in sorted(items.items())}
    items['artifact-inventory.json'] = encode(inventory)
    destination = BASE / (LABEL + '-evidence.tar.gz')
    assert not destination.exists()
    with destination.open('wb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, raw in sorted(items.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
    result_package = dict(label=LABEL, archive=destination.name, sha256=sha(destination.read_bytes()),
        bytes=destination.stat().st_size, artifacts=len(items), members=len(items),
        scope='PT-b1681 actual F1/Stageout0; three original NumPy surface attempts, Qia Newton failure plus two complete returns. No GPU/column/year/retry; all actual failures preserved.',
        verification=verification)
    (BASE / (LABEL + '-package.json')).write_bytes(encode(result_package))
    assert files(destination.read_bytes()) == items
    print(json.dumps(result_package))


if __name__ == '__main__':
    main()

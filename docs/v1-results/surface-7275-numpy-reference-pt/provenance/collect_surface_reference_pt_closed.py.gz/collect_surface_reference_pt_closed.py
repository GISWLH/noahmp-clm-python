"""Preserve readonly closed PT-b SSH observations; never rerun the model."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
DEST = BASE / 'surface-7275-numpy-reference-pt-closure'


def main():
    DEST.mkdir(exist_ok=False)
    reader = (BASE / 'read_surface_reference_pt_closed.py').read_bytes()
    for label, command, data in (
        ('manager', ['ssh', 'ehpc', '/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'], reader),
        ('compute', ['ssh', 'ehpc-c2', '/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'], reader),
        ('qstat', ['ssh', 'ehpc', 'qstat -xf 1681.manager'], None),
    ):
        started = time.monotonic()
        result = subprocess.run(command, input=data, capture_output=True, timeout=60)
        (DEST / (label + '.stdout')).write_bytes(result.stdout)
        (DEST / (label + '.stderr')).write_bytes(result.stderr)
        record = dict(command=command, actual_exit=result.returncode, seconds=time.monotonic()-started,
            stdin_sha256=hashlib.sha256(data).hexdigest() if data else None,
            stdout_sha256=hashlib.sha256(result.stdout).hexdigest(), stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
        (DEST / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(label, result.returncode)
        assert result.returncode == 0, result.stderr.decode(errors='replace')


if __name__ == '__main__':
    main()

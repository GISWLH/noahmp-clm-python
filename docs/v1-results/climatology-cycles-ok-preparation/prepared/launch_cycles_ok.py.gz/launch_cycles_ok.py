"""One OK cycle at a time from audited NS; preparation does not invoke this."""
from pathlib import Path
import argparse
import datetime
import json
import os
import subprocess
import sys
from climatology_contract_ok import (ROOT, TMP, SOURCE, MODEL, INPUTS, EVIDENCE,
    TARGET, GPU, load, sha, controls, preflight)

HERE = Path(__file__).resolve().parent


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['cycle2', 'cycle3'])
    args = parser.parse_args()
    number = int(args.stage[-1])
    assert os.name == 'posix' and Path('/proc/meminfo').exists(), 'xuanze only'
    hashes = controls(HERE)
    folder = ROOT / ('cycle-0' + str(number))
    assert not folder.exists(), 'Never overwrite or restart a cycle attempt'
    if number == 2:
        assert not ROOT.exists() and not TMP.exists()
    else:
        assert ROOT.is_dir() and TMP.is_dir() and controls(ROOT) == hashes
    proof, parent = preflight(HERE, number)
    gpu = subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=uuid,memory.free',
        '--format=csv,noheader,nounits'], text=True).strip().split(',')
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
        if line.startswith('MemAvailable:')))
    assert gpu[0].strip() == GPU and int(gpu[1]) > 8192 and available > 32 * 1024 * 1024
    if number == 2:
        ROOT.mkdir()
        TMP.mkdir()
        for name in list(hashes) + ['CONTROLS_SHA256.json']:
            (ROOT / name).write_bytes((HERE / name).read_bytes())
        write(ROOT / 'plan.json', dict(source_manifest_sha256=TARGET, source=str(SOURCE),
            original_ns_model=str(MODEL), original_inputs=str(INPUTS), od_evidence_directory=str(EVIDENCE),
            controls_sha256=hashes, ns_od_proof=proof, batch_sha256=proof['batch_sha256'],
            prepared_cycles=[2, 3], protocol_maximum_cycles=20,
            scope='Actual originalNS17520/parent0 plus closed independentOD audit, then sameNM584/12inputs cycle2/3. '
                  'Original22nonindex/16device/fullstate/globalledgers and normalphysics retained. '
                  'No coldrestart, failedJN reuse, observedbias gate, newapprovalflag, automaticnextcycle or SOC claim.'))
    folder.mkdir()
    cache = TMP / args.stage
    cache.mkdir()
    env = os.environ.copy()
    for key in ['LD_LIBRARY_PATH', 'PYTEST_PLUGINS']:
        env.pop(key, None)
    env.update(OK_ROOT=str(ROOT), OK_SOURCE=str(SOURCE), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU,
        PYTHONPATH=':'.join(map(str, [ROOT, SOURCE, SOURCE / 'src', SOURCE / 'benchmarks'])),
        CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
        XLA_PYTHON_CLIENT_PREALLOCATE='false', CUPY_CACHE_DIR=str(cache / 'cupy'),
        CUDA_CACHE_PATH=str(cache / 'cuda'), JAX_COMPILATION_CACHE_DIR=str(cache / 'jax'))
    with (folder / 'controller.log').open('x') as log:
        process = subprocess.Popen([sys.executable, '-u', str(ROOT / 'control_cycles_ok.py'), args.stage],
            cwd=SOURCE, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    write(folder / 'launch.json', dict(stage=args.stage, pid=process.pid,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_manifest_sha256=TARGET,
        physical_gpu_index=1, physical_gpu_uuid=GPU, gpu_free_mib=int(gpu[1]), host_available_kib=available,
        private_cache=str(cache), plan_sha256=sha(ROOT / 'plan.json'),
        parent_checkpoint_sha256=parent['checkpoint_sha256'], parent_ledger_steps=parent['ledger_steps'],
        parent_ledger_segments=parent['ledger_segments'], ns_od_proof=proof))
    print(json.dumps(load(folder / 'launch.json')), flush=True)


if __name__ == '__main__':
    main()

"""Actual isolated worker status; no stage automatically starts another stage."""
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from climatology_contract_nm import TARGET, load, sha, verify_source

root = Path(os.environ['NM_ROOT'])
stage = sys.argv[1]
assert stage in ['cold48', 'year', 'cycle2', 'cycle3']
folder = root / ('cold48' if stage in ['cold48', 'year'] else 'cycle-0' + stage[-1])
stem = 'year-' if stage == 'year' else ''
worker = {'cold48': 'run_cold48_nm.py', 'year': 'run_year_nm.py',
          'cycle2': 'run_cycle_nm.py', 'cycle3': 'run_cycle_nm.py'}[stage]
command = [sys.executable, '-u', str(root / worker)]
if stage.startswith('cycle'):
    command.append(stage[-1])
started = time.monotonic()
code = None
failure = None
passed = False
try:
    plan = load(root / 'plan.json')
    assert all(sha(root / n) == h for n, h in plan['controls_sha256'].items())
    verify_source(Path(os.environ['NM_SOURCE']))
    with (folder / (stem + 'model.log')).open('x') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    (folder / (stem + 'worker.json')).write_text(json.dumps(dict(pid=process.pid, command=command)) + '\n')
    code = process.wait()
    record = load(folder / (stem + 'receipt.json'))
    passed = bool(code == 0 and record['failure'] is None and record['source_unchanged']
                  and record['source_manifest_sha256'] == TARGET and record['device_barrier_complete'])
    if stage == 'cold48':
        passed = passed and record['cold_fields_exact'] == 23 and record['primary_state_arrays'] == 16
        passed = passed and record['cases'] == 12 and record['captured_step_calls'] == record['steps_completed'] == 48
        passed = passed and record['steps_requested'] == 17520 and record['status'] == 'running'
    else:
        passed = passed and record['status'] == 'complete' and record['steps_completed'] == record['steps_requested'] == 17520
        if stage == 'year':
            passed = passed and record['continued_fields_exact'] == 23 and record['first_continued_step_captured']
            passed = passed and record['bgc_diagnostic_steps'] == 17472
        else:
            passed = passed and record['controls_unchanged'] and record['first_nonindex_checkpoint_fields_exact'] == 22
            passed = passed and record['first_actual_device_arrays_verified'] == 16 and record['first_continued_step_captured']
            passed = passed and record['ledger_steps'] == 17520 * int(stage[-1]) and record['ledger_segments'] == int(stage[-1])
            passed = passed and record['bgc_diagnostic_steps'] == 17520
    verify_source(Path(os.environ['NM_SOURCE']))
except Exception as error:
    failure = type(error).__name__ + ': ' + str(error)
    (folder / (stem + 'controller-traceback.txt')).write_text(traceback.format_exc())
result = dict(stage=stage, passed=bool(passed and failure is None), failure=failure,
              actual_parent_returncode=code, source_manifest_sha256=TARGET,
              receipt_sha256=sha(folder / (stem + 'receipt.json')) if (folder / (stem + 'receipt.json')).exists() else None,
              seconds=time.monotonic()-started,
              scope='Actual worker exit plus original guards only. Each subsequent stage needs a separate guarded launch; '
                    'cold48 needs new independent actualF0 paired audit. No annual/spinup/observational pass inferred.')
(folder / (stem + 'exit.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['passed'] else 1)

# OK: original NS climate cycles 2/3, preparation only

No deployment, GPU worker, export, PBS submission or physical calculation is performed by this preparation. The original NS trajectory, controls, input package and sealed NP evidence remain unchanged. This is the existing NM cycle runner with a separate control directory and explicit NS parent paths; no new model pipeline or approval flag is introduced.

Paths fixed from the real NT launch evidence:

| Role | Runtime path |
|---|---|
| Original model parent | `/home/lhwang/work/noahmp-v1/climatology-cold48-np/cold48/trajectory` |
| Original year receipt/parent exit | Same `cold48` directory, `year-receipt.json` / `year-exit.json` |
| Original NS controls/promotion | `/home/lhwang/work/noahmp-v1/climatology-year-ns` |
| Exact NM584 source | `/tmp/noahmp-climatology-cold48-np/source` |
| Original 12-case inputs | Original `cold48/inputs`, unchanged JN provenance |
| New independent OK controls/results | `/home/lhwang/work/noahmp-v1/climatology-cycles-ok`, each `cycle-02` / `cycle-03` separately |
| Private caches | `/tmp/noahmp-climatology-cycles-ok/cycle2` and `cycle3` |
| Future closed OD evidence | `/tmp/noahmp-climatology-cycles-ok-evidence` |

`original-ns-binding.json` retains exact original NT member hashes, NS plan and real promotion commit `9a67a855c6481c19862d17761f333c8623677ecc`. The old NP `candidate_only=true/continuation_allowed=false` flags are never rewritten. This new task's cycle authorization is separate from the original NP cold48 restriction, and uses the already promoted same source.

Before cycle2, stage the genuinely closed OD `climatology-year-od-device.tar.gz` and `device-package.json`, plus original result archive/package renamed `od-result.tar.gz` / `od-result-package.json` and actual terminal `od-actual-qstat.txt` / `od-pbs-exit.txt`. The reader checks actual compute002 F0, wrapper/evaluator parent0, all original OD controls, source/input identity, 210240 C/N column-step audit, all12 case delivery, and exact closed device bytes against the still-retained NS parent. It never treats an observational bias/r value or cold-year SOC change as permission to begin spinup; failed or unmeasured scientific criteria are retained. Original physical budgets remain hard requirements.

The minimal worker adapter preserves the three original functions `forbidden`, `first`, `audit`, every original assertion AST and the exact `native.run(..., initial_mode='cycle')` call. Before the first tendency it compares all22 non-index checkpoint fields and all16 actual device arrays; only the original CO2/solar/diffuse forcing update is allowed. Each cycle keeps the original global initial/net/bounds/maxima/tracer ledgers, same fixed full17520 forcing, first actual packet, all365 BGC blocks and real parent result. No failed or partial parent can seed another cycle, and no output folder is overwritten.

Future root execution after actual NS/OD closure uses the existing xuanze Python: `python -B launch_cycles_ok.py cycle2`; cycle3 is a later explicit invocation after actual cycle2 parent0. No automatic queue is started. Both stages require physical CUDA1 UUID and original >8GiB GPU / >32GiB host admission; worker peak limit remains4GiB. This preparation covers only2/3 and preserves the existing maximum20-cycle protocol. At least2 complete cycles and2 consecutive endpoint checks, dry/wet seed comparison, SOC drift and normal-mode C/N feedback must be evaluated separately with the existing assessor; executing these stages does not establish convergence or observational acceptance.

`prepare_climatology_cycles_ok.py` performs byte/AST metadata preparation only on Windows. `static-adapter-proof.json` records reversible substitutions and original functions/assertions/call identity. Full future parent/audit checks cannot pass until the original year and independent audit actually finish. Independent review is required before this preparation is packaged; no runtime action is performed here.

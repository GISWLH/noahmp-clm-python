"""OK metadata gates: actual audited NS parent; no observed-skill gate."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import tarfile

from climatology_contract_nm import (TARGET, SOURCE_ARCHIVE, INPUT, GPU, load, sha,
                                    verify_source, verify_inputs)
from od_contract import DEVICE_NAME, verify_device_archive, terminal

BASE = Path('/home/lhwang/work/noahmp-v1')
NP_ROOT = BASE / 'climatology-cold48-np'
MODEL = NP_ROOT / 'cold48'
INPUTS = MODEL / 'inputs'
SOURCE = Path('/tmp/noahmp-climatology-cold48-np/source')
NS_ROOT = BASE / 'climatology-year-ns'
ROOT = BASE / 'climatology-cycles-ok'
TMP = Path('/tmp/noahmp-climatology-cycles-ok')
EVIDENCE = Path('/tmp/noahmp-climatology-cycles-ok-evidence')
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def archive_bytes(path):
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members})
        for member in members:
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts
            assert name.as_posix() == member.name and '\\' not in member.name
        return {m.name: archive.extractfile(m).read() for m in members}


def controls(here):
    values = load(here / 'CONTROLS_SHA256.json')
    assert all(sha(here / name) == value for name, value in values.items())
    return values


def original_ns(here):
    """The original promotion is already real; no new approval flag is added."""
    binding = load(here / 'original-ns-binding.json')
    names = binding['original_NT_members']
    assert sha(NS_ROOT / 'plan.json') == names['remote/NS/plan.json']
    assert sha(NS_ROOT / 'promotion.json') == names['remote/NS/controls/promotion.json']
    assert sha(NP_ROOT / 'plan.json') == names['remote/NS/original-prefix-plan.json']
    for name in ['year-launch.json', 'year-prefix-binding.json', 'year-start-audit.json']:
        assert sha(MODEL / name) == names['remote/NS/' + name]
    ns_plan, promotion, np_plan = load(NS_ROOT / 'plan.json'), load(NS_ROOT / 'promotion.json'), load(NP_ROOT / 'plan.json')
    assert ns_plan == binding['ns_plan'] and promotion == binding['ns_promotion'] and np_plan == binding['np_plan']
    assert promotion['promotion_commit'] == '9a67a855c6481c19862d17761f333c8623677ecc'
    assert promotion['allow_np48_to_year'] and promotion['promoted_source_manifest_sha256'] == TARGET
    assert promotion['committed_source_proof']['remote_branch_confirmed'] and promotion['committed_source_proof']['frozen_files_checked'] == 584
    assert promotion['trajectory'] == str(MODEL / 'trajectory')
    assert ns_plan['source'] == str(SOURCE) and ns_plan['source_manifest_sha256'] == TARGET
    assert all(sha(NS_ROOT / name) == value for name, value in ns_plan['controls_sha256'].items())
    assert np_plan['candidate_only'] and np_plan['continuation_allowed'] is False
    assert np_plan['source_manifest_sha256'] == TARGET and np_plan['input_archive_sha256'] == INPUT
    assert sha(NP_ROOT / 'candidate-source.tar.gz') == SOURCE_ARCHIVE
    assert sha(NP_ROOT / 'reference-reuse.json') == np_plan['controls_sha256']['reference-reuse.json']
    verify_source(SOURCE)
    protocol = verify_inputs(INPUTS, load(NP_ROOT / 'reference-reuse.json'))
    return protocol


def audited_ns(here):
    """Closed OD may be unsuccessful scientifically; only audit integrity gates."""
    protocol = original_ns(here)
    packet = load(EVIDENCE / 'device-package.json')
    verify_device_archive(EVIDENCE / DEVICE_NAME, packet)
    device = archive_bytes(EVIDENCE / DEVICE_NAME)
    receipt = load(MODEL / 'year-receipt.json')
    batch = load(MODEL / 'trajectory/batch.json')
    terminal(load(MODEL / 'year-exit.json'), receipt, sha(MODEL / 'year-receipt.json'), batch)
    # Every archived current file is compared against its real, closed NS parent.
    for name, raw in device.items():
        if name.startswith('current/'):
            path = MODEL / name.removeprefix('current/')
            assert path.is_file() and not path.is_symlink() and path.read_bytes() == raw, name
    assert device['year-controller/exit.json'] == (MODEL / 'year-exit.json').read_bytes()
    assert device['year-controller/plan.json'] == (NS_ROOT / 'plan.json').read_bytes()
    assert device['SOURCE_SHA256.json'] == (SOURCE / 'SOURCE_SHA256.json').read_bytes()
    result_package = load(EVIDENCE / 'od-result-package.json')
    assert sha(EVIDENCE / 'od-result.tar.gz') == result_package['sha256']
    result = archive_bytes(EVIDENCE / 'od-result.tar.gz')
    actual = json.loads(result['worker-actual-exit.json'])
    assert actual['passed'] and actual['failure'] is None and actual['actual_evaluator_parent_returncode'] == 0
    assert actual['forward_model_runs'] == 0 and actual['node'] == 'compute002'
    assert all(result_package[key] == value for key, value in actual.items())
    qstat = (EVIDENCE / 'od-actual-qstat.txt').read_text()
    assert re.fullmatch(r'[0-9]+\.manager', actual['pbs_job'])
    assert re.search(r'^Job Id: ' + re.escape(actual['pbs_job']) + r'\s*$', qstat, re.M)
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M) and re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
    assert (EVIDENCE / 'od-pbs-exit.txt').read_text().strip() == '0'
    expected = (here / 'original-od-controls.json').read_bytes()
    assert result['CONTROLS_SHA256.json'] == expected
    assert all(digest(result[name]) == value for name, value in json.loads(expected).items())
    assert json.loads(result['device-package.json']) == packet
    plan = json.loads(result['plan.json'])
    assert plan['device_archive_sha256'] == packet['sha256'] and plan['source_manifest_sha256'] == TARGET
    assert plan['controls_sha256'] == json.loads(expected) and plan['actual_year_parent_returncode'] == 0
    report = json.loads(result['receipt.json'])
    assert actual['receipt_sha256'] == digest(result['receipt.json'])
    assert report['pbs_job'] == actual['pbs_job'] and report['node'] == 'compute002'
    assert report['evaluation_delivered'] and report['failure'] is None and report['source_unchanged']
    assert report['source_manifest_sha256'] == TARGET and len(report['cases']) == 12
    assert set(report['cases']) == set(batch['case_reports']) == {c['case'] for c in protocol['cases']}
    assert all(value['full365days12months_delivered'] for value in report['cases'].values())
    cn = json.loads(result['bgc-stream-audit.json'])
    assert cn['steps'] == 17520 and cn['physical_column_steps'] == 210240
    assert cn['all_c_n_chains_actual_input_and_final_checkpoint_exact']
    assert cn['all_original_c_n_bounds_rederived_float32_exact']
    assert cn['all_independent_float64_step_and_cumulative_c_n_within_original_bounds']
    # No bias/r/SOC-convergence decision is read as a prerequisite to spinup.
    return dict(device_archive_sha256=packet['sha256'], od_result_archive_sha256=result_package['sha256'],
        od_result_receipt_sha256=actual['receipt_sha256'], od_job=actual['pbs_job'],
        actual_parent_returncode=0, ns_batch_report_sha256=sha(MODEL / 'trajectory/batch.json'),
        ns_checkpoint_sha256=batch['checkpoint_sha256'], batch_sha256=batch['identity']['batch_sha256'],
        ns_promotion_sha256=sha(NS_ROOT / 'promotion.json'), ns_plan_sha256=sha(NS_ROOT / 'plan.json'),
        source_manifest_sha256=TARGET, input_archive_sha256=INPUT)


def cycle_parent(number):
    folder = MODEL if number == 2 else ROOT / 'cycle-02'
    stem = 'year-' if number == 2 else ''
    actual, receipt = load(folder / (stem + 'exit.json')), load(folder / (stem + 'receipt.json'))
    assert actual['passed'] and actual['actual_parent_returncode'] == 0 and actual['failure'] is None
    assert actual['receipt_sha256'] == sha(folder / (stem + 'receipt.json'))
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['device_barrier_complete'] and receipt['status'] == 'complete'
    assert receipt['steps_completed'] == receipt['steps_requested'] == 17520
    batch = load(folder / 'trajectory/batch.json')
    assert receipt['report_sha256'] == sha(folder / 'trajectory/batch.json')
    assert batch['status'] == 'complete' and batch['source_unchanged'] and batch['columns'] == 12
    assert batch['steps_completed'] == batch['steps_requested'] == 17520
    assert batch['ledger_steps'] == 17520 * (number - 1) and batch['ledger_segments'] == number - 1
    assert sha(folder / 'trajectory' / batch['checkpoint_file']) == batch['checkpoint_sha256']
    for case, descriptor in batch['case_reports'].items():
        path = folder / 'trajectory' / case / descriptor['file']
        assert sha(path) == descriptor['sha256']
        report = load(path)
        assert report['status'] == 'complete' and report['source_unchanged']
        assert report['steps_completed'] == report['steps_requested'] == 17520
        assert sha(path.parent / report['model_npz']) == report['model_npz_sha256']
        assert report['batch_checkpoint_sha256'] == batch['checkpoint_sha256']
    if number == 3:
        assert receipt['controls_unchanged'] and receipt['first_nonindex_checkpoint_fields_exact'] == 22
        assert receipt['first_actual_device_arrays_verified'] == 16 and receipt['first_continued_step_captured']
        assert receipt['bgc_diagnostic_steps'] == 17520 and len(receipt['bgc_diagnostic_chunks']) == 365
        for i, chunk in enumerate(receipt['bgc_diagnostic_chunks']):
            begin, end = 48 * i, 48 * (i + 1)
            assert chunk['first'] == begin and chunk['end'] == end
            assert sha(folder / 'bgc-diagnostics' / f'steps-{begin:07d}-{end:07d}.npz') == chunk['sha256']
        prior = load(MODEL / 'trajectory/batch.json')
        link = batch['identity']['initial_run']
        assert link['mode'] == 'cycle' and link['batch_report_sha256'] == sha(MODEL / 'trajectory/batch.json')
        assert link['checkpoint_sha256'] == prior['checkpoint_sha256']
        assert link['previous_ledger_steps'] == 17520 and link['previous_segments'] == 1
        assert (folder / 'parent-complete-report.json').read_bytes() == (MODEL / 'trajectory/batch.json').read_bytes()
        assert sha(folder / 'parent-complete-checkpoint.npz') == prior['checkpoint_sha256']
    return batch


def preflight(here, number):
    here = Path(here)
    assert number in (2, 3)
    controls(here)
    proof = audited_ns(here)
    batch = cycle_parent(number)
    if ROOT.exists():
        plan = load(ROOT / 'plan.json')
        assert plan['ns_od_proof'] == proof and plan['source_manifest_sha256'] == TARGET
        assert plan['batch_sha256'] == proof['batch_sha256'] and plan['protocol_maximum_cycles'] == 20
        assert plan['controls_sha256'] == controls(ROOT)
    return proof, batch

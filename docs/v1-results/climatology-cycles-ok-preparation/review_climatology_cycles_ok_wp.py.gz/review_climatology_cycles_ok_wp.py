"""Independent stdlib-only OK preparation review. No runtime preflight or model."""
from pathlib import Path
import ast,hashlib,io,json,tarfile
ROOT=Path(__file__).resolve().parent
P=ROOT/'climatology-cycles-ok-preparation'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest_raw=(P/'CONTROLS_SHA256.json').read_bytes()
assert sha(manifest_raw)=='c77278948987fde97797700decebadb0e99d5058d11d009809ed8d0bfeb520f2'
controls=json.loads(manifest_raw)
assert len(controls)==12 and all(sha((P/n).read_bytes())==h for n,h in controls.items())
for n in controls:
    if n.endswith('.py'):ast.parse((P/n).read_bytes())
proof=json.loads((P/'static-adapter-proof.json').read_text())
before=(P/'original-run_cycle_nm.py').read_bytes();after=(P/'run_cycle_ok.py').read_text()
old,new=ast.parse(before),ast.parse(after)
for name in ['forbidden','first','audit']:
    fn=lambda tree:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert ast.dump(fn(old))==ast.dump(fn(new))
asserts=lambda t:[ast.dump(n) for n in ast.walk(t) if isinstance(n,ast.Assert)]
assert len(asserts(old))==28 and asserts(old)==asserts(new)
calls=lambda t:[ast.dump(n) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='native' and n.func.attr=='run']
assert len(calls(old))==1 and calls(old)==calls(new)
reverse=after
for row in reversed(proof['replacements']):reverse=reverse.replace(row['new'],row['old'])
assert reverse.encode()==before
nm=ROOT/'climatology-preparation-nm-evidence.tar.gz'
assert sha(nm.read_bytes())=='d2c2b2eb6a0474e0b00ccc598fe07d04066b240a2eefc5ee19018464af46627d'
with tarfile.open(nm) as t:
    assert t.extractfile('prepared/run_cycle_nm.py').read()==before
    assert t.extractfile('prepared/control_climatology_nm.py').read()==(P/'original-control_climatology_nm.py').read_bytes()
    assert t.extractfile('prepared/climatology_contract_nm.py').read()==(P/'climatology_contract_nm.py').read_bytes()
binding=json.loads((P/'original-ns-binding.json').read_text())
nt=ROOT/'candidate-launches-nt-evidence.tar.gz'
assert sha(nt.read_bytes())==binding['original_NT_archive_sha256']=='4222f0a6e6530f17109cacc03aaf920ba07ce8d08e100f205960063a11db2838'
with tarfile.open(nt) as t:
    assert all(sha(t.extractfile(n).read())==h for n,h in binding['original_NT_members'].items())
assert len(binding['original_NT_members'])==6
assert binding['ns_plan']['source']=='/tmp/noahmp-climatology-cold48-np/source'
assert binding['ns_promotion']['trajectory']=='/home/lhwang/work/noahmp-v1/climatology-cold48-np/cold48/trajectory'
assert binding['ns_promotion']['promotion_commit']=='9a67a855c6481c19862d17761f333c8623677ecc'
source=ROOT/'climatology-final-candidate-nm-source.tar.gz'
assert sha(source.read_bytes())=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(source) as t:
    raw=t.extractfile('SOURCE_SHA256.json').read();m=json.loads(raw)
    assert sha(raw)=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    assert len(m)==584 and set(t.getnames())==set(m)|{'SOURCE_SHA256.json'}
    assert all(sha(t.extractfile(n).read())==h for n,h in m.items())
    native=t.extractfile('benchmarks/run_fluxnet_native.py').read()
with tarfile.open(ROOT/'climatology-cold48-np-device-evidence.tar.gz') as t:
    cold_raw=t.extractfile('original/cold48-evidence.tar.gz').read()
assert sha(cold_raw)=='ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416'
with tarfile.open(fileobj=io.BytesIO(cold_raw)) as t:cold={n.name:t.extractfile(n).read() for n in t if n.isfile()}
reuse=json.loads(cold['control/reference-reuse.json'])
assert sha(cold['control/reference-reuse.json'])==binding['np_plan']['controls_sha256']['reference-reuse.json']
inp=ROOT/'multisite-climatology-jr-inputs.tar.gz'
assert sha(inp.read_bytes())=='deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
with tarfile.open(inp) as t:inputs={n.name:t.extractfile(n).read() for n in t if n.isfile()}
assert len(inputs)==34 and set(inputs)==set(reuse['every_input_file_sha256'])
assert all(sha(v)==reuse['every_input_file_sha256'][n] and v==cold['current/inputs/'+n] for n,v in inputs.items())
protocol=json.loads(inputs['protocol.json'])
assert protocol['case_count']==12 and protocol['cold_fields']==23 and protocol['native_state_arrays']==16
assert protocol['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
od=ROOT/'climatology-year-od-preparation'
assert (P/'original-od-controls.json').read_bytes()==(od/'CONTROLS_SHA256.json').read_bytes()
assert (P/'od_contract.py').read_bytes()==(od/'od_contract.py').read_bytes()
od_manifest=json.loads((P/'original-od-controls.json').read_text())
assert all(sha((od/n).read_bytes())==h for n,h in od_manifest.items())
record=dict(review_mode='Independent standard-library archive/JSON/hash/AST inspection and manual control/schema review only',
    reviewed_controls_manifest_sha256=sha(manifest_raw),reviewed_control_count=12,
    reviewed_builder_sha256=sha((ROOT/'prepare_climatology_cycles_ok.py').read_bytes()),passed=True,blocking_findings=[],
    executed_byte_and_AST_checks=dict(original_NM_preparation_archive_sha256=sha(nm.read_bytes()),
        original_worker_controller_contract_byteequal_to_sealed_NM=True,
        exact_worker_functions=['forbidden','first','audit'],original_assertions_AST_exact=28,
        native_run_call_AST_exact=True,reverse_worker_substitution_byteexact=True,
        original_NT_archive_sha256=sha(nt.read_bytes()),original_NT_members_verified=6,
        promotion_commit=binding['ns_promotion']['promotion_commit'],
        NM_source_files_verified=584,original_JR_input_files_verified=34,fixed_cases=12,
        all_inputs_byteequal_to_sealed_NP=True,original_JN_input_identity_retained=True,
        original_OD_controls_and_contract_byteequal=True),
    manual_review=dict(split_path='cycle2 parent is NP/cold48/trajectory completed by NS; NS controls/promotion remain in NS root; cycle3 parent is new OK/cycle-02.',
        future_OD_schema='Matches original run_climatology_analysis_od output: root receipt.json/bgc-stream-audit.json/worker-actual-exit.json/plan.json/device-package.json plus controls. Future original result package wrapper fields match; qstat job/F0 and PBS exit0 required.',
        original_parent_binding='All archived current/ files compared byte-for-byte to unchanged live closed NS; original NP frozen payload is rechecked by original OD contract; OD device/result SHA and plan bindings retained.',
        runtime_required_before_launch='Real NS17520 parent0/barrier, original promotion/plan/584 source/34 inputs, delivered OD F0 with all12 cases and210240 C/N transitions, complete original checkpoint; no fabricated future hash.',
        state_and_calendar='Original native cycle carry requires same source/backend/configuration/forcing and complete calendar. Before first tendency all22 nonindex fields exact, all16 actual arrays exact except original prescribed first-interval environment update. Global initial/net/bounds/maxima/tracers remain carried; only local index resets.',
        cycle3='Requires real cycle2 parent0, 35040 cumulative steps/2 segments, 365 BGC chunks and original NS report/checkpoint parent link. Its new endpoint must report52560 steps/3 segments.',
        safety_and_lifecycle='Separate immutable control directory and per-cycle output; explicit cycle2 or3 only, no overwrite/restart/automatic next stage, physicalCUDA1 UUID, >8GiB GPU/>32GiB host admission, private per-cycle caches and original4GiB worker peak bound.',
        observations='No bias/r/SOC-convergence outcome read as launch gate. OD delivery/integrity and original conservation are prerequisites; failed/unmeasured observational criteria remain valid audit output.',
        scope='Maximum20-cycle protocol unchanged; execution of cycles2/3 alone does not establish convergence, long-term SOC equilibrium or scientific acceptance.'),
    related_author_static_check_sha256=sha((ROOT/'climatology-cycles-ok-static-verification.json').read_bytes()),
    not_executed=['Remote inspection or changes','Runtime preflight against future NS/OD terminal records','Numerical imports/array deserialization/model execution','Deployment, GPU launch or PBS submission'],
    deployment=False,arrays_loaded=False,numerical_execution=False)
target=ROOT/'climatology-cycles-ok-independent-review-wp.json'
target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(passed=True,remaining_blocking_findings=[],manifest=sha(manifest_raw),review_sha256=sha(target.read_bytes()),source_files=584,input_files=34,cases=12,assertions=28)))

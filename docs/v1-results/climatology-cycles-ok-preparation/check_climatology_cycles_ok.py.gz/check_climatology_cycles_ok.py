"""Static OK source/input/API evidence only; no arrays or physical imports."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'climatology-cycles-ok-preparation'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
controls = json.loads(manifest_raw)
assert len(controls) == 12 and all(digest((PREP / n).read_bytes()) == h for n,h in controls.items())
binding = json.loads((PREP / 'original-ns-binding.json').read_text())
source_path = OUT / 'climatology-final-candidate-nm-source.tar.gz'
assert digest(source_path.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(source_path) as archive:
    raw_manifest = archive.extractfile('SOURCE_SHA256.json').read()
    source = json.loads(raw_manifest)
    assert len(source) == 584 and set(archive.getnames()) == set(source) | {'SOURCE_SHA256.json'}
    assert all(digest(archive.extractfile(n).read()) == h for n,h in source.items())
assert digest(raw_manifest) == binding['ns_promotion']['promoted_source_manifest_sha256']
with tarfile.open(OUT / 'climatology-cold48-np-device-evidence.tar.gz') as archive:
    cold_raw = archive.extractfile('original/cold48-evidence.tar.gz').read()
assert digest(cold_raw) == 'ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416'
with tarfile.open(fileobj=io.BytesIO(cold_raw)) as archive:
    cold = {m.name: archive.extractfile(m).read() for m in archive if m.isfile()}
reuse_raw = cold['control/reference-reuse.json']
assert digest(reuse_raw) == binding['np_plan']['controls_sha256']['reference-reuse.json']
reuse = json.loads(reuse_raw)
input_path = OUT / 'multisite-climatology-jr-inputs.tar.gz'
assert digest(input_path.read_bytes()) == 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
with tarfile.open(input_path) as archive:
    inputs = {m.name: archive.extractfile(m).read() for m in archive if m.isfile()}
assert set(inputs) == set(reuse['every_input_file_sha256'])
assert all(digest(raw) == reuse['every_input_file_sha256'][n] and raw == cold['current/inputs/' + n] for n,raw in inputs.items())
protocol = json.loads(inputs['protocol.json'])
assert protocol['case_count'] == 12 and protocol['cold_fields'] == 23 and protocol['native_state_arrays'] == 16
assert protocol['source_manifest_sha256'] == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
cases = json.loads(inputs['batch.json'])['cases']
assert len(cases) == 12 and {json.loads(inputs[c['configuration']])['site'] for c in cases} == {'CN-Cng','CN-Qia','CN-Cha'}
for n in controls:
    if n.endswith('.py'):
        ast.parse((PREP / n).read_bytes())
tree = ast.parse((PREP / 'climatology_contract_ok.py').read_text())
keys = [n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.slice,ast.Constant) and isinstance(n.slice.value,str)]
assert not {'bias_pass','correlation_pass','water_heat_converged','soil_c_equilibrium_claim','soc_rate_criterion_met'} & set(keys)
help_run = subprocess.run([sys.executable, '-B', str(PREP / 'launch_cycles_ok.py'), '--help'], capture_output=True, text=True)
assert help_run.returncode == 0 and '{cycle2,cycle3}' in help_run.stdout
lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe','check','--select','F821',str(PREP),str(OUT/'prepare_climatology_cycles_ok.py'),str(Path(__file__))], capture_output=True, text=True)
assert lint.returncode == 0, lint.stdout + lint.stderr
record = dict(mode='static_only', passed=True, controls_manifest_sha256=digest(manifest_raw),
    source_files_bytechecked=584, input_files_bytechecked=len(inputs), fixed_cases=12,
    original_JN_input_identity_retained=True, original_NP_inputs_byteequal=True,
    original_NS_plan_sha256=binding['original_NT_members']['remote/NS/plan.json'],
    original_NS_promotion_sha256=binding['original_NT_members']['remote/NS/controls/promotion.json'],
    no_observation_or_convergence_pass_keys_used_as_launch_gate=True,
    launcher_help_actual_parent_returncode=help_run.returncode, launcher_help=help_run.stdout,
    ruff_actual_parent_returncode=lint.returncode, ruff_stdout=lint.stdout,
    deployed=False, cycles_launched=0, arrays_loaded=False, numerical_execution=False,
    future_actual_NS_terminal_OD_F0_cycle_carry_not_executed=True)
(OUT/'climatology-cycles-ok-static-verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['passed','mode','controls_manifest_sha256','source_files_bytechecked','input_files_bytechecked','fixed_cases','launcher_help_actual_parent_returncode','ruff_actual_parent_returncode','deployed','cycles_launched','arrays_loaded']}))

"""Seal independently reviewed OK preparation; metadata only, no runtime launch."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'climatology-cycles-ok-preparation'
EXPECTED = 'c77278948987fde97797700decebadb0e99d5058d11d009809ed8d0bfeb520f2'
REVIEW_SHA = '25c3b2f310722d664dedd9b94a53e1e70656aff7ded7bd55dafc77901ae4f20a'
STATIC_SHA = 'ba7b8eb96b15d38e53d256ad8146572f695389e1586c5f772ca8437533290650'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
assert digest(manifest_raw) == EXPECTED
controls = json.loads(manifest_raw)
assert len(controls) == 12
assert all(digest((PREP / name).read_bytes()) == value for name, value in controls.items())
static_raw = (OUT / 'climatology-cycles-ok-static-verification.json').read_bytes()
assert digest(static_raw) == STATIC_SHA
static = json.loads(static_raw)
assert static['passed'] and static['mode'] == 'static_only'
assert static['controls_manifest_sha256'] == EXPECTED
assert static['cycles_launched'] == 0
assert all(static[name] is False for name in ['deployed', 'arrays_loaded', 'numerical_execution'])
review_path = OUT / 'climatology-cycles-ok-independent-review-wp.json'
review_raw = review_path.read_bytes()
assert digest(review_raw) == REVIEW_SHA
review = json.loads(review_raw)
assert review['passed'] and review['blocking_findings'] == []
assert review['reviewed_controls_manifest_sha256'] == EXPECTED
assert review['reviewed_control_count'] == 12
assert review['reviewed_builder_sha256'] == digest((OUT / 'prepare_climatology_cycles_ok.py').read_bytes())
assert review['related_author_static_check_sha256'] == STATIC_SHA
assert all(review[name] is False for name in ['deployment', 'arrays_loaded', 'numerical_execution'])
files = {'prepared/' + name: (PREP / name).read_bytes() for name in controls}
files['prepared/CONTROLS_SHA256.json'] = manifest_raw
for name in [
    'prepare_climatology_cycles_ok.py', 'check_climatology_cycles_ok.py',
    'package_climatology_cycles_ok.py', 'climatology-cycles-ok-static-verification.json',
    'review_climatology_cycles_ok_wp.py', review_path.name,
    'CLIMATOLOGY_CYCLES_OK_PREPARATION_SCOPE.md',
]:
    files[name] = (OUT / name).read_bytes()
for name, raw in files.items():
    if name.endswith('.py'):
        ast.parse(raw)
scope = files['CLIMATOLOGY_CYCLES_OK_PREPARATION_SCOPE.md'].decode()
assert EXPECTED in scope and REVIEW_SHA in scope
result = subprocess.run([
    'E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(PREP),
    str(OUT / 'prepare_climatology_cycles_ok.py'),
    str(OUT / 'check_climatology_cycles_ok.py'),
    str(OUT / 'review_climatology_cycles_ok_wp.py'), str(Path(__file__)),
], capture_output=True, text=True)
check = dict(mode='static_only', actual_ruff_returncode=result.returncode,
             ruff_stdout=result.stdout, ruff_stderr=result.stderr,
             controls_manifest_sha256=EXPECTED, controls=12, AST_parsed=True,
             deployed=False, cycles_launched=0, arrays_loaded=False,
             numerical_execution=False)
check_raw = (json.dumps(check, indent=2) + '\n').encode()
(OUT / 'climatology-cycles-ok-packaging-check.json').write_bytes(check_raw)
assert result.returncode == 0, check
files['climatology-cycles-ok-packaging-check.json'] = check_raw
inventory = {name: dict(sha256=digest(raw), bytes=len(raw)) for name, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = OUT / 'climatology-cycles-ok-preparation-evidence.tar.gz'
package_path = OUT / 'climatology-cycles-ok-preparation-package.json'
assert not target.exists() and not package_path.exists(), 'Do not replace sealed evidence'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(target) as archive:
    members = archive.getmembers()
    assert len(members) == len(files) and all(member.isfile() for member in members)
    assert len({member.name for member in members}) == len(files)
    restored = {member.name: archive.extractfile(member).read() for member in members}
    assert restored == files
    restored_inventory = json.loads(restored['artifact-inventory.json'])
    assert set(restored_inventory) == set(restored) - {'artifact-inventory.json'}
    for name, record in restored_inventory.items():
        assert digest(restored[name]) == record['sha256'] and len(restored[name]) == record['bytes']
package = dict(
    archive=target.name, sha256=digest(target.read_bytes()), bytes=target.stat().st_size,
    artifacts=len(files), artifact_sha256={name: digest(raw) for name, raw in files.items()},
    controls_manifest_sha256=EXPECTED, control_files=12,
    status='prepared_only_independently_reviewed', deployed=False, cycles_launched=0,
    arrays_loaded=False, numerical_execution=False,
    review_file=review_path.name, review_sha256=REVIEW_SHA,
    source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
    source_files=584, original_input_files=34, fixed_cases=12,
    protocol_maximum_cycles=20, prepared_cycles=[2, 3],
    scope='Minimal original NM cycle adapter to actual NS/NP split paths. '
          'Requires future real NS17520 parent0 and closed OD integrity/conservation audit; '
          'all original physical assertions, device/state carry and cumulative ledgers retained. '
          'No observational acceptance or SOC convergence is a launch gate. '
          'Future runtime checks not executed; no convergence, calibration or scientific acceptance credit.',
)
package_path.write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps({key: package[key] for key in [
    'archive', 'sha256', 'bytes', 'artifacts', 'controls_manifest_sha256', 'status',
]}, indent=2))

"""Prepare minimal NS-to-cycle2/3 adapters; byte/AST only, never launch."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

OUT = Path(__file__).resolve().parent
DEST = OUT / 'climatology-cycles-ok-preparation'
NM = OUT / 'climatology-preparation-nm'
OD = OUT / 'climatology-year-od-preparation'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
DEST.mkdir(exist_ok=True)
for name in ['climatology_contract_nm.py']:
    (DEST / name).write_bytes((NM / name).read_bytes())
(DEST / 'od_contract.py').write_bytes((OD / 'od_contract.py').read_bytes())
changes = [
    ("os.environ['NM_ROOT']", "os.environ['OK_ROOT']"),
    ("os.environ['NM_SOURCE']", "os.environ['OK_SOURCE']"),
    ('from climatology_contract_nm import verify_source, verify_inputs, load as nm_load',
     'from climatology_contract_ok import verify_source, verify_inputs, load as nm_load, MODEL, INPUTS, NP_ROOT, preflight'),
    ("verify_source(source); verify_inputs(root/'cold48/inputs',nm_load(root/'reference-reuse.json'))",
     "verify_source(source); verify_inputs(INPUTS,nm_load(NP_ROOT/'reference-reuse.json')); preflight(root, number)"),
    ("prior = root / 'cold48' if number == 2 else root / 'cycle-02'",
     "prior = MODEL if number == 2 else root / 'cycle-02'"),
    ("batch = root / 'cold48/inputs/batch.json'", "batch = INPUTS / 'batch.json'"),
]
raw = (NM / 'run_cycle_nm.py').read_bytes()
text = raw.decode()
for old, new in changes:
    assert old in text
    text = text.replace(old, new)
(DEST / 'run_cycle_ok.py').write_text(text, newline='\n')
(DEST / 'original-run_cycle_nm.py').write_bytes(raw)
old_tree, new_tree = ast.parse(raw), ast.parse(text)
functions = [n.name for n in old_tree.body if isinstance(n, ast.FunctionDef)]
assert functions == ['forbidden', 'first', 'audit']
for name in functions:
    a = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    b = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)
assert [ast.dump(n, include_attributes=False) for n in ast.walk(old_tree) if isinstance(n, ast.Assert)] == [ast.dump(n, include_attributes=False) for n in ast.walk(new_tree) if isinstance(n, ast.Assert)]
call = lambda tree: [ast.dump(n, include_attributes=False) for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == 'native' and n.func.attr == 'run']
assert len(call(old_tree)) == 1 and call(old_tree) == call(new_tree)
reverse = text
for old, new in reversed(changes):
    reverse = reverse.replace(new, old)
assert reverse.encode() == raw
original_control = (NM / 'control_climatology_nm.py').read_bytes()
control = original_control.decode().replace('from climatology_contract_nm import', 'from climatology_contract_ok import')
control = control.replace("os.environ['NM_ROOT']", "os.environ['OK_ROOT']").replace("os.environ['NM_SOURCE']", "os.environ['OK_SOURCE']")
control = control.replace("assert stage in ['cold48', 'year', 'cycle2', 'cycle3']", "assert stage in ['cycle2', 'cycle3']")
control = control.replace('run_cycle_nm.py', 'run_cycle_ok.py')
control = control.replace("'cold48 needs new independent actualF0 paired audit. No annual/spinup/observational pass inferred.'", "'Only original successful NS year and separate complete cycles are carried; no spinup/observational pass inferred.'")
(DEST / 'control_cycles_ok.py').write_text(control, newline='\n')
(DEST / 'original-control_climatology_nm.py').write_bytes(original_control)
nt = OUT / 'candidate-launches-nt-evidence.tar.gz'
assert digest(nt.read_bytes()) == '4222f0a6e6530f17109cacc03aaf920ba07ce8d08e100f205960063a11db2838'
with tarfile.open(nt) as archive:
    selected = ['remote/NS/plan.json', 'remote/NS/controls/promotion.json', 'remote/NS/original-prefix-plan.json',
                'remote/NS/year-launch.json', 'remote/NS/year-prefix-binding.json', 'remote/NS/year-start-audit.json']
    evidence = {n: archive.extractfile(n).read() for n in selected}
binding = dict(original_NT_archive_sha256=digest(nt.read_bytes()), original_NT_members={n:digest(v) for n,v in evidence.items()},
    ns_plan=json.loads(evidence[selected[0]]), ns_promotion=json.loads(evidence[selected[1]]), np_plan=json.loads(evidence[selected[2]]),
    year_launch=json.loads(evidence[selected[3]]))
assert binding['ns_promotion']['promotion_commit'] == '9a67a855c6481c19862d17761f333c8623677ecc'
(DEST / 'original-ns-binding.json').write_text(json.dumps(binding, indent=2) + '\n', newline='\n')
od_manifest = (OD / 'CONTROLS_SHA256.json').read_bytes()
(DEST / 'original-od-controls.json').write_bytes(od_manifest)
proof = dict(prepared_only=True, numerical_execution=False, deployment=False, launches=0,
    original_worker_sha256=digest(raw), adapted_worker_sha256=digest(text.encode()),
    exact_functions=functions, all_original_assert_AST_exact=True, original_assert_count=sum(isinstance(n, ast.Assert) for n in ast.walk(old_tree)),
    original_native_run_call_AST_exact=True, reverse_adapter_byteexact=True,
    replacements=[dict(old=a,new=b) for a,b in changes],
    original_contract_byteexact=True, original_OD_contract_byteexact=True,
    original_OD_controls_manifest_sha256=digest(od_manifest), original_NT_archive_sha256=digest(nt.read_bytes()),
    source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',
    scope='Only separate OK control and exact NP/source/input/NS-parent paths change. No numerical assertions, observers, physical call, state, parameter, forcing or budget changes. Original20cycle protocol remains; only2/3 are prepared.')
(DEST / 'static-adapter-proof.json').write_text(json.dumps(proof, indent=2) + '\n', newline='\n')
names = ['run_cycle_ok.py', 'control_cycles_ok.py', 'climatology_contract_ok.py', 'launch_cycles_ok.py',
    'climatology_contract_nm.py', 'od_contract.py', 'original-run_cycle_nm.py', 'original-control_climatology_nm.py',
    'original-ns-binding.json', 'original-od-controls.json', 'static-adapter-proof.json', 'README.md']
for name in names:
    content = (DEST / name).read_bytes()
    if name.endswith('.py'):
        ast.parse(content)
hashes = {n:digest((DEST/n).read_bytes()) for n in names}
(DEST / 'CONTROLS_SHA256.json').write_text(json.dumps(hashes, indent=2) + '\n', newline='\n')
print(json.dumps(dict(prepared_only=True, controls=len(hashes), manifest_sha256=digest((DEST/'CONTROLS_SHA256.json').read_bytes()), **{k:proof[k] for k in ['original_assert_count','exact_functions','original_native_run_call_AST_exact','reverse_adapter_byteexact']})))

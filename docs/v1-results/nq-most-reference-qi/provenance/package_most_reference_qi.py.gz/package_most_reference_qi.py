"""Actual QI2 reference/driver requests/returns; stdlib opaque closure only."""
import base64
import gzip
import io
import json
from pathlib import Path
import tarfile
from package_surface_reference_pt import files,sha,encode
from package_nm_richards_reference_qc import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='nq-most-reference-qi'
STAGE='fc33999476ce7852172cceeb1c9ff31e494fae577d7706868e8ab467afa8a85b'
RESULT='63a23bf267dcb458dcfc165f7ca989072304f5d19c48bed75e8c75a67d3d897a'
def main():
    stage_raw=(BASE/(LABEL+'-stage-b.tar.gz')).read_bytes();raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes();assert sha(stage_raw)==STAGE and sha(raw)==RESULT
    stage=files(stage_raw);result=files(raw,directories=True);index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==15 and set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    source=files(stage['source.tar.gz']);manifest=json.loads(source['SOURCE_SHA256.json']);assert len(manifest)==584 and all(sha(source[n])==h for n,h in manifest.items())
    assert sha(source['SOURCE_SHA256.json'])=='da0c59b35d095df102db32eaebb956c97b02bf02c1553a901d911a0ebd652f80'
    for folder in ('preparation','execution'):
        for n,h in json.loads(stage[folder+'/CONTROLS_SHA256.json']).items():assert sha(stage[folder+'/'+n])==h
    for n in ('setup-exit.txt','stage-after-exit.txt','worker-exit.txt','pbs-command-exit.txt'):assert result[n].strip()==b'0'
    for n in ('stage-before.json','stage-after.json'):
        d=json.loads(result[n]);assert d['passed'] and d['expected']==d['actual']==index and not d['mismatches']
    for n in [*json.loads(stage['execution/CONTROLS_SHA256.json']),'CONTROLS_SHA256.json']:assert result['execution-controls/'+n]==stage['execution/'+n]
    closure=BASE/(LABEL+'-closure')
    for host in ('manager','compute'):
        d=json.loads((closure/(host+'.stdout')).read_bytes());assert d['all_stage_immutable'] and d['stage_files_before']==d['stage_files_after']==index
        if host=='compute':assert d['result_archive_sha256']==RESULT and base64.b64decode(d['files']['pbs-exit.txt']).strip()==b'0'
    final=[p.read_bytes() for p in closure.glob('poll-*.stdout') if b'job_state = F' in p.read_bytes()];assert len(final)==1 and all(v in final[0] for v in (b'Exit_status = 0',b'Stageout_status = 0',b'run_count = 1'))
    observation=json.loads((closure/'poll-2.json').read_bytes());assert observation['actual_exit']!=0 and 'Connection timed out' in (closure/'poll-2.stderr').read_text()
    receipt=json.loads(result['reference/receipt.json']);summary=json.loads(result['reference/reference-summary.json'])
    assert receipt['pbs_job']=='1843.manager' and receipt['host']=='compute002' and receipt['source584_exact'] and receipt['controls_exact']
    calls=dict(reference_started=2,reference_returned=2,driver_started=2,driver_returned=2);assert receipt['physical_calls']==summary['physical_calls']==calls and receipt['GPU_calls']==receipt['extra_physical_calls']==0
    assert not receipt['fixtures_or_tests_modified'] and not receipt['scientific_acceptance'] and set(summary['records'])=={'float32','float64'}
    counts={}
    for n,b in result.items():
        if not n.endswith('.json'):continue
        d=json.loads(b)
        if not isinstance(d,dict) or d.get('schema')!='QI-lossless-reference-v1':continue
        stem=n.removesuffix('.json');counts[stem]=opaque_packet(result[stem+'.npz'],d)[0];assert sha(result[stem+'.pkl'])==d['pickle_sha256']
    assert len(counts)==10
    for precision,record in summary['records'].items():
        assert record['input_immutable']
        for suffix in ('input','input-after'):
            doc=json.loads(result['reference/'+precision+'-'+suffix+'.json']);assert doc['tree']==record['input_packet']['tree']
        output=json.loads(result['reference/'+precision+'.json']);assert output==record['output_packet']
    verification=dict(passed=True,pbs_job='1843.manager',actual_PBS_exit=0,actual_Stageout_status=0,source584_exact=True,stage_sha256=STAGE,result_sha256=RESULT,actual_reference_calls=2,actual_underlying_driver_calls=2,total_physical_forward_calls=2,not_four_physical_calls=True,extra_physical_calls=0,GPU_calls=0,opaque_complete_packets=len(counts),opaque_arrays=sum(counts.values()),original_args_kwargs_after_exact=True,both_float32_float64_complete_returns=True,old_observation_SSH_timeout_retained=True,model_rerun_or_job_resubmit=False,scientific_acceptance=False)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification));(BASE/(LABEL+'-readout.json')).write_bytes(encode(dict(verification=verification,original_receipt=receipt,summary=summary)))
    items={'executed-stage.tar.gz':stage_raw,'raw-result.tar.gz':raw,'verification.json':encode(verification),'readout.json':(BASE/(LABEL+'-readout.json')).read_bytes()};items.update({'actual-result/'+n:b for n,b in result.items()})
    for directory in (closure,BASE/(LABEL+'-deployment')):
        for p in sorted(directory.iterdir()):
            if p.is_file():items['observations/'+directory.name+'/'+p.name]=p.read_bytes()
    for n in ('prepare_most_reference_qi_execution.py','deploy_most_reference_qi.py','read_most_reference_qi_closed.py','collect_most_reference_qi_closed.py','collect_most_reference_qi_closed_resume.py','package_most_reference_qi.py',LABEL+'-stage-b-package.json',LABEL+'-stage-b-metadata.diff'):
        items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(v),sha256=sha(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,v in sorted(items.items()):m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;t.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='EHPC1843 actual F0/Stageout0 two exact original MOST NumPy references at float32/float64 inputs, their two underlying driver calls are the same2 physical forwards. Complete original requests/returns and parameter/source/control immutability for strict GPU cache bridge;0 extra/GPU call, original transient SSH observation timeout retained, no job resubmit/fixture/model/test/gate change or scientific acceptance.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(dict(package=package,verification=verification)))

if __name__=='__main__':main()

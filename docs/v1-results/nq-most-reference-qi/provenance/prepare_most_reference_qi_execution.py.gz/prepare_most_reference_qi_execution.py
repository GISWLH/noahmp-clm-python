"""Mechanical LF QG/PW lifecycle reuse for the reviewed two-reference QI job."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
OLD=BASE/'nq-reference-values-qg-execution'
PREP=BASE/'nq-most-reference-qi-preparation'
NEW=BASE/'nq-most-reference-qi-execution'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
def main():
    prep_raw=(PREP/'CONTROLS_SHA256.json').read_bytes();assert sha(prep_raw)=='d3f213292aa416777b4b4124b82e656dfbb2311c822e1df1ebac7eb108cd6bfa'
    controls=json.loads(prep_raw);assert len(controls)==6 and all(sha((PREP/n).read_bytes())==h for n,h in controls.items())
    NEW.mkdir(exist_ok=False);diff=[]
    for old,new in [('check_stage_qg.py','check_stage_qi.py'),('dispatch_reference_qg.py','dispatch_most_reference_qi.py'),('reference_qg.pbs','reference_qi.pbs')]:
        before=(OLD/old).read_text();after=before.replace('reference-values-qg','most-reference-qi').replace('check_stage_qg','check_stage_qi').replace('dispatch_reference_qg','dispatch_most_reference_qi').replace('reference_qg.pbs','reference_qi.pbs').replace('qg-result','qi-result')
        if old.endswith('.pbs'):
            command='"$py" -B "$stage/preparation/reference_values_qg.py" --source "$stage/source.tar.gz" --qc "$stage/qc-result.tar.gz" --output "$root/values"'
            assert command in after
            after=after.replace(command,'"$py" -B "$stage/preparation/capture_most_reference_qi.py" --source "$stage/source.tar.gz" --output "$root/reference"')
            after=after.replace('tar -czf "$stage/result.tar.gz" -C','tar -czf "$stage/result.tar.gz" --exclude=\'./reference/source\' -C')
            assert after.startswith('#!/bin/bash\n') and '\r' not in after
        else:ast.parse(after)
        (NEW/new).write_text(after,encoding='utf-8',newline='\n');diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old,tofile=new))
    (NEW/'README.md').write_text('QI uses original QG/PW manager/compute002 stage/dispatch/hash lifecycle with fresh /tmp paths and1CPU/2GiB/5min. Exactly two original MOST NumPy reference calls plus their two underlying original driver calls, no extra solve/GPU call. Full typed requests/results retained. Root authorized one submission after actual PBS recovery and source/control/input preflight0; no retry or xuanze CPU reference. Historical CPU5 explicitly reused separately.\n',encoding='utf-8')
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(dict(preparation_manifest_sha256=sha(prep_raw),source_archive_sha256='004fa5d926d99f076bd5f176eb6b5cc827e64b073026d4d25a27ad2e5a50a0bd',source_manifest_sha256='da0c59b35d095df102db32eaebb956c97b02bf02c1553a901d911a0ebd652f80',planned_reference_calls=2,planned_underlying_driver_calls=2,extra_solves=0,GPU_calls=0,resources='1CPU/2GiB/5min/compute002',root_authorized_single_submission_when_PBS_healthy=True)))
    manifest={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir())};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(manifest))
    (BASE/'nq-most-reference-qi-execution.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()})
    source=(BASE/'nq-reference-semantics-qh-source.tar.gz').read_bytes();assert sha(source)=='004fa5d926d99f076bd5f176eb6b5cc827e64b073026d4d25a27ad2e5a50a0bd';items['source.tar.gz']=source
    items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/'nq-most-reference-qi-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    digest=sha(target.read_bytes())
    deploy=(BASE/'deploy_reference_values_qg.py').read_text().replace('nq-reference-values-qg','nq-most-reference-qi').replace('noahmp-reference-values-qg','noahmp-most-reference-qi').replace('dispatch_reference_qg','dispatch_most_reference_qi').replace('38575e1a7746d3124143ec60c4aa3145b4ab36ebe0c3026b1b433b341f853a41',digest)
    ast.parse(deploy);(BASE/'deploy_most_reference_qi.py').write_text(deploy,encoding='utf-8',newline='\n')
    result=dict(passed=True,stage_sha256=digest,stage_files=len(items),preparation_controls=len(controls),preparation_manifest_sha256=sha(prep_raw),execution_controls=len(manifest),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),LF_shebang_valid=True,planned_reference_calls=2,extra_physical_calls=0,GPU_calls=0,source584_unchanged=True,submitted=False,numerical_executed=False)
    (BASE/'nq-most-reference-qi-stage-package.json').write_bytes(encode(result));print(json.dumps(result))

if __name__=='__main__':main()

"""EHPC-only two exact original MOST reference calls, preserving complete values."""
import argparse
from dataclasses import fields,is_dataclass
from enum import Enum
import hashlib
import io
import json
import os
from pathlib import Path
import pickle
import socket
import sys
import tarfile
import time
import traceback

HERE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def main():
    parser=argparse.ArgumentParser()
    for n in ('source','output'):parser.add_argument('--'+n,type=Path,required=True)
    a=parser.parse_args()
    assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists();a.output.mkdir()
    controls=json.loads((HERE/'CONTROLS_SHA256.json').read_bytes());assert all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());source_raw=a.source.read_bytes();assert sha(source_raw)==binding['source_archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(source_raw)) as t:
        members=t.getmembers();assert len({m.name for m in members})==len(members)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        source_files={m.name:t.extractfile(m).read() for m in members}
    manifest=json.loads(source_files['SOURCE_SHA256.json']);assert len(manifest)==584 and sha(source_files['SOURCE_SHA256.json'])==binding['source_manifest_sha256'] and set(source_files)==set(manifest)|{'SOURCE_SHA256.json'}
    assert all(sha(source_files[n])==h for n,h in manifest.items())
    source=a.output/'source'
    for n,raw in source_files.items():
        p=source/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    sys.path[:0]=[str(source/'src'),str(source/'tests'),str(source/'benchmarks')]
    import numpy as np
    from test_most_stagnation import qia_case
    import test_gpu_clm_bgc_column as reference_module
    from noahmp_clm.physics.canopy_most import MOSTGeometry
    assert Path(reference_module.reference.__code__.co_filename).resolve()==source/'tests/test_gpu_clm_bgc_column.py'
    def capture(path,value):
        path.with_suffix('.pkl').write_bytes(pickle.dumps(value,protocol=5))
        arrays={}
        def walk(v,k):
            if isinstance(v,(np.ndarray,np.generic)):
                q=np.asarray(v);assert q.dtype.kind!='O';arrays[k]=q
                return dict(kind='array',key=k,dtype=q.dtype.str,shape=list(q.shape),c_order_sha256=sha(q.tobytes(order='C')))
            if is_dataclass(v):return dict(kind='dataclass',module=type(v).__module__,name=type(v).__name__,fields={f.name:walk(getattr(v,f.name),k+'/'+f.name) for f in fields(v)})
            if isinstance(v,dict):
                assert all(type(n)is str for n in v);return dict(kind='dict',items={n:walk(x,k+'/'+n) for n,x in v.items()})
            if isinstance(v,(tuple,list)):return dict(kind=type(v).__name__,items=[walk(x,k+'/'+str(i)) for i,x in enumerate(v)])
            if isinstance(v,Enum):return dict(kind='enum',module=type(v).__module__,name=type(v).__name__,value=walk(v.value,k+'/value'))
            if type(v)is float:return dict(kind='float',hex=v.hex())
            if v is None or type(v)in(str,int,bool):return dict(kind=type(v).__name__,value=v)
            raise TypeError('Unsupported original complete reference value '+str(type(v)))
        tree=walk(value,'value');np.savez_compressed(path.with_suffix('.npz'),**arrays)
        meta=dict(schema='QI-lossless-reference-v1',tree=tree,array_count=len(arrays),npz_sha256=sha(path.with_suffix('.npz').read_bytes()),pickle_sha256=sha(path.with_suffix('.pkl').read_bytes()))
        save(path.with_suffix('.json'),meta);return meta
    calls=dict(reference_started=0,reference_returned=0,driver_started=0,driver_returned=0);current_precision=[None];started=time.monotonic();records={}
    original_driver=reference_module.step_clm_enthalpy_column
    def observed_driver(*args,**kwargs):
        path=a.output/(current_precision[0]+'-driver')
        capture(path.with_name(path.name+'-input'),dict(args=args,kwargs=kwargs));calls['driver_started']+=1
        answer=original_driver(*args,**kwargs);calls['driver_returned']+=1
        capture(path,answer);return answer
    reference_module.step_clm_enthalpy_column=observed_driver
    try:
        for dtype in (np.float32,np.float64):
            tag=np.dtype(dtype).name;current_precision[0]=tag;arrays,values=qia_case(dtype)
            args=(tuple(x[0] for x in arrays),values['forcing'][0],np.zeros(5),values['environment'][0],values['calendar'][0],0.,1.)
            kwargs=dict(most_geometry=MOSTGeometry(*map(float,values['geometry'][0])))
            path=a.output/tag;input_meta=capture(path.with_name(tag+'-input'),dict(args=args,kwargs=kwargs))
            calls['reference_started']+=1;answer=reference_module.reference(*args,**kwargs);calls['reference_returned']+=1
            output_meta=capture(path,answer)
            after_meta=capture(path.with_name(tag+'-input-after'),dict(args=args,kwargs=kwargs))
            assert input_meta['tree']==after_meta['tree']
            records[tag]=dict(input_packet=input_meta,output_packet=output_meta,input_immutable=True,original_reference_function_sha256=sha((source/'tests/test_gpu_clm_bgc_column.py').read_bytes()),original_qia_helper_sha256=sha((source/'tests/test_most_stagnation.py').read_bytes()))
        assert calls==dict(reference_started=2,reference_returned=2,driver_started=2,driver_returned=2)
        save(a.output/'reference-summary.json',dict(records=records,physical_calls=calls,source_manifest_sha256=binding['source_manifest_sha256'],scope='Two exact original GPU-test NumPy reference calls, independently on EHPC. Complete original call args/kwargs, driver returns and helper returns, no extra solve. Not observation/annual acceptance.'))
    except BaseException:
        (a.output/'failure.txt').write_text(traceback.format_exc());raise
    finally:
        after={n:sha((source/n).read_bytes()) for n in manifest};assert after==manifest
        assert all(sha((HERE/n).read_bytes())==h for n,h in controls.items())
        save(a.output/'receipt.json',dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),source584_exact=True,controls_exact=True,physical_calls=calls,seconds=time.monotonic()-started,GPU_calls=0,extra_physical_calls=0,fixtures_or_tests_modified=False,scientific_acceptance=False))

if __name__=='__main__':main()

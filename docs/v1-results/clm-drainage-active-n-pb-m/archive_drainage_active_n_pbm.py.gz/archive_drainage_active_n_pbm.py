"""Flat PB-m actual-F evidence, including original failure if present."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname()=='manager'
ROOT=Path('/tmp/noahmp-clm-drainage-active-n-pb-m')
JOB='1658.manager';LABEL='clm-drainage-active-n-pb-m'
sha=lambda b:hashlib.sha256(b).hexdigest()
qstat=subprocess.check_output(['qstat','-xf',JOB]);status=qstat.decode()
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Stageout_status = 0\s*$',status,re.M)
code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M).group(1))
for name in ('result.tar.gz','pbs-exit.txt'):
    digest=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
    if not (ROOT/name).exists():subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
    assert sha((ROOT/name).read_bytes())==digest
assert int((ROOT/'pbs-exit.txt').read_text())==code
with tarfile.open(ROOT/'result.tar.gz') as t:
    items=[m for m in t if m.isfile()];assert len({m.name.removeprefix('./') for m in items})==len(items)
    raw={m.name.removeprefix('./'):t.extractfile(m).read() for m in items}
receipt=json.loads(raw['receipt.json']);binding=json.loads(raw['preparation/BINDINGS.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002' and int(raw['worker-exit.txt'])==code
assert receipt['pytest_parent_returncode']==code
index=json.loads(raw['source/SOURCE_SHA256.json']);assert len(index)==586
assert sha(raw['source/SOURCE_SHA256.json'])==binding['source_manifest_sha256']
assert all(sha(raw['source/'+n])==h for n,h in index.items())
old=json.loads(raw['preparation/ORIGINAL_NM_SOURCE_SHA256.json']);assert len(old)==584
assert sum(index[n]==h for n,h in old.items())==583
assert set(index)-set(old)==set(binding['added'])
for folder in ('preparation','execution'):
    manifest=json.loads(raw[folder+'/CONTROLS_SHA256.json'])
    assert all(sha(raw[folder+'/'+n])==h for n,h in manifest.items())
diag=[json.loads(line.split('PB_M_DIAGNOSTIC ',1)[1]) for line in raw['pytest.stdout.txt'].decode().splitlines() if 'PB_M_DIAGNOSTIC ' in line]
assert diag==json.loads(raw['diagnostics.json'])
assert diag==[json.loads(line) for line in raw['active-n-records.jsonl'].decode().splitlines()]
calls=json.loads(raw['component-call-counts.json']);assert calls==receipt['actual_call_counts']
if code==0:
    assert receipt['passed'] and receipt['tests']==1 and receipt['failures']==receipt['errors']==0
    assert len(diag)==2 and b'1 passed' in raw['pytest.stdout.txt']
    assert calls['completed_coupled_column_steps']==calls['BGC_coupled_steps']==2
    for key in ('independent_transport_replays','independent_drainage_replays','independent_plan_replays',
                'independent_decomposition_replays','independent_allocation_replays','actual_decomposition_calls'):
        assert calls[key]==2
    assert calls['original_NM_column_steps']==calls['independent_tile_replays']==calls['expected_invalid_calls']==0
    assert calls['actual_biochemical_coefficient_calls']==sum(d['actual_biochemical_calls'] for d in diag)
    assert receipt['source_and_controls_unchanged'] and receipt['official_calls_executed']==receipt['GPU_tasks']==0
else:assert not receipt['passed']
data={n:b for n,b in raw.items() if not n.startswith('source/')}
data['candidate-source-manifest.json']=raw['source/SOURCE_SHA256.json']
for n in set(binding['changed'])|set(binding['added']):data['candidate-files/'+n]=raw['source/'+n]
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt',
    'compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt'):
    data['scheduler/'+name]=(ROOT/name).read_bytes()
data['scheduler/actual-qstat.txt']=qstat
if (ROOT/'pbs-output.log').exists():data['scheduler/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
data['original-result-members.json']=(json.dumps({n:dict(sha256=sha(b),bytes=len(b),included=not n.startswith('source/')) for n,b in raw.items()},indent=2)+'\n').encode()
data['closed-run.json']=(json.dumps(dict(job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,receipt=receipt,
    raw_result_archive=str(ROOT/'result.tar.gz'),raw_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),
    original_members=len(raw),omitted_source_members=587,candidate_source_archive_sha256=binding['source_archive_sha256'],
    original_PBl_evidence_sha256='45421d63b2a01571530e7cfd26768937c7d3663b51125267d2685a82aa7b23f2',
    original_NM_archive_sha256=binding['base_archive_sha256'],source_derivation=binding),indent=2)+'\n').encode()
readout=dict(actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,actual_tests=receipt['tests'],
    diagnostics=len(diag),pytest_seconds=receipt['pytest_seconds'],worker_seconds=receipt['seconds'],actual_call_counts=calls,
    candidate_source_archive_sha256=binding['source_archive_sha256'],source_modified=False,original12_rerun=False,
    original_Component64eps=True,original_Richards32eps=True,original_runner_MHCN_bounds=True,
    real_column_connected=True,production_integrated=False,official_coupled_validation=False,annual_validation=False,
    JAX_executed=False,CUDA_executed=False,cases=diag,
    limitations=['One explicitly poor-N mechanism fixture, not site calibration or annual validation.',
        'Gross mineralization was recorded separately; starting mineral plus prescribed deposition alone funds current uptake/immobilization. New mineralization belongs to the following step.',
        'Every actual biochemical coefficient call is captured across transient leaf energy iterations. Vcmax ranges are not a final-canopy average or a pure nitrogen counterfactual.',
        'Original candidate586 only; new configuration is not integrated into production or native/GPU paths.'],
    scope='One real active-N column test, two coupled steps and separately counted independent replays on unchanged PB-l candidate.')
data['run-readout.json']=(json.dumps(readout,indent=2,allow_nan=False)+'\n').encode()
for name in ('stage_drainage_active_n_pbm.py','clm-drainage-active-n-pb-m-stage-preparation.json'):
    data['preparation-provenance/'+name]=(ROOT/name).read_bytes()
data['archive_drainage_active_n_pbm.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(b),bytes=len(b)) for n,b in data.items()},indent=2)+'\n').encode()
archive=ROOT/(LABEL+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for n,b in sorted(data.items()):ti=tarfile.TarInfo(n);ti.size=len(b);t.addfile(ti,io.BytesIO(b))
with tarfile.open(archive) as t:assert {m.name:t.extractfile(m).read() for m in t}==data
package=dict(archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,tests=receipt['tests'],diagnostics=len(diag),
    actual_call_counts=calls,candidate_source_archive_sha256=binding['source_archive_sha256'],production_integrated=False,
    scope='Actual one-test/two-step isolated poor-N column on exact PB-l586 source: real postdrain climate, positive N demand/uptake, observed Vcmax and next-state Nfactor, exact original plan/decomposition/allocation replays and MHCN hard bounds. No prior12 rerun, site, annual, official coupled, production or device acceptance.')
(ROOT/(LABEL+'-package.json')).write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(package),flush=True)

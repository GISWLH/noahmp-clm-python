"""Stdlib-only stage of one real two-step active-N test; no launch."""
from pathlib import Path
import ast
import hashlib
import io
import json
import tarfile

ROOT=Path(__file__).resolve().parent
PREP=ROOT/'clm-drainage-active-n-pb-m-preparation'
EXEC=ROOT/'clm-drainage-active-n-pb-m-execution'
OLD=ROOT/'clm-drainage-column-pb-l-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf8',newline='\n')


def main():
    EXEC.mkdir(exist_ok=True)
    manifest=json.loads((OLD/'CONTROLS_SHA256.json').read_bytes())
    assert sha((OLD/'CONTROLS_SHA256.json').read_bytes())=='a0bfbc3f9ead0c182abca10ea896eeee196e3b97de2b59fd0835884529c58d68'
    for name in ('test_column_pbl.py','BINDINGS.json','ORIGINAL_NM_SOURCE_SHA256.json'):
        raw=(OLD/name).read_bytes();assert sha(raw)==manifest[name]
        target='pbl_reference_helpers.py' if name=='test_column_pbl.py' else name
        (PREP/target).write_bytes(raw)
    readme='''# PB-m active nitrogen feedback

One test, two real coupled NumPy steps, on the exact PB-l candidate586 archive. No physics/source changes, no rerun of the twelve PB-l tests. The byte-identical PB-l test module is imported under pbl_reference_helpers solely for its observer/replay/budget utilities; pytest collects only test_active_n_pbm.py.

Fixed initial state: original BGC fixture carbon [120,600,150] gC/m2; leaf N2.4 gN/m2 (half original120/25 target), original target stem/root N, reserve C30 and N0; original seven soil C/N pools, mineral N0.01 gN/m2. Original geometry, root fractions, fveg0.8 and all default BGC/leaf parameters remain. theta0.43, T[290,289,288,287] K. OptDynamicVeg4 with real carbon-derived LAI. Two1800s steps: air295K, q0.008, wind3m/s,101325Pa, SW600/LW350W/m2, no rain. Explicit background N deposition1e-5gN/m2 per step, matching the earlier column test input, fixed before execution.

True potential plant demand includes tissue N-deficit repair; neither demand nor uptake is injected. Transparent observers return original decomposition and biochemical results unchanged. Independent replays reconstruct the original turnover/allocation plan, decomposition and allocation from the actual final soil environment, all compared exactly. Original PB-l transport/drainage replays and original run_fluxnet_column.audit_step M/H/C/N bounds remain. Source and controls are checked before/after.

Require actual GPP, LAI, potential demand and uptake positive, original competition limitation between0and1, uptake plus immobilization no larger than starting mineral+deposition. New gross mineralization is recorded separately and is available only on the next step. Observe every actual Vcmax coefficient with leaf temperature, water stress and post-turnover Nfactor; algebraically check the original peaked response without changing the call. Cross-step Vcmax changes are not pure nitrogen effects. Second-step Nfactor must use the genuinely funded then turned-over plant.

Output includes full biochemical call records, all soil/plant C/N stocks, true outlet/heat, actual M/H/C/N residuals and bounds. Counts distinguish two coupled steps from operator/plan/decomposition/allocation replays. Failure is retained without adjusting inputs or budgets. This is an isolated mechanistic column test, not station/annual/official coupled validation, production integration or device execution. CUDA1 remains untouched.
'''
    (PREP/'README.md').write_text(readme,encoding='utf8',newline='\n')
    for name in ('run_component_pb.py','component_pb.pbs','dispatch_component_pb.py'):
        code=(ROOT/'clm-drainage-column-pb-l-execution'/name).read_text(encoding='utf8')
        code=code.replace('clm-drainage-column-pb-l','clm-drainage-active-n-pb-m')
        code=code.replace('drainage-column-pbl','drainage-active-n-pbm').replace('dispatch_drainage_column_pbl.py','dispatch_drainage_active_n_pbm.py')
        code=code.replace('test_column_pbl.py','test_active_n_pbm.py').replace('PB_L_DIAGNOSTIC','PB_M_DIAGNOSTIC')
        code=code.replace('len(cases) == 12','len(cases) == 1')
        if name=='run_component_pb.py':
            start=code.index("    receipt['scope'] = ");end=code.index('\n',start)
            code=code[:start]+"    receipt['scope'] = 'One new active-N test, two real NumPy coupled steps on unchanged PB-l586 candidate, with separate independent operator/BGC replays. No original12 rerun, site/annual/official coupled/device acceptance or production integration.'"+code[end:]
        if name=='dispatch_component_pb.py':
            code=code.replace('PB-l12 isolated NumPy actual column/disabled cases, new586-source candidate; no site, annual, official call or GPU execution.',
                'PB-m one active-N test, two real NumPy steps on exact PB-l586 candidate; no previous12 rerun, site, annual, official call or GPU execution.')
        (EXEC/name).write_text(code,encoding='utf8',newline='\n')
    for folder in (PREP,EXEC):
        for path in folder.glob('*.py'):ast.parse(path.read_bytes())
        save(folder/'CONTROLS_SHA256.json',{p.name:sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'})
    tree=ast.parse((PREP/'test_active_n_pbm.py').read_bytes())
    tests=[n.name for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    assert tests==['test_two_real_steps_with_active_limited_n_feedback']
    binding=json.loads((PREP/'BINDINGS.json').read_bytes());source=ROOT/binding['source_archive']
    assert sha(source.read_bytes())==binding['source_archive_sha256']
    with tarfile.open(source) as t:
        index=json.loads(t.extractfile('SOURCE_SHA256.json').read())
        assert len(index)==586 and sha(t.extractfile('SOURCE_SHA256.json').read())==binding['source_manifest_sha256']
        assert all(sha(t.extractfile(n).read())==h for n,h in index.items())
    raw={'source.tar.gz':source.read_bytes()}
    for folder,name in [(PREP,'preparation'),(EXEC,'execution')]:
        raw.update({name+'/'+p.name:p.read_bytes() for p in sorted(folder.iterdir()) if p.is_file()})
    raw['stage-inventory.json']=(json.dumps({n:sha(b) for n,b in sorted(raw.items())},indent=2)+'\n').encode()
    archive=ROOT/'clm-drainage-active-n-pb-m-stage.tar.gz'
    with tarfile.open(archive,'w:gz') as t:
        for n,b in sorted(raw.items()):ti=tarfile.TarInfo(n);ti.size=len(b);t.addfile(ti,io.BytesIO(b))
    report=dict(actual_static_exit=0,stage_sha256=sha(archive.read_bytes()),members=len(raw),tests=tests,
        preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()),
        source_archive_sha256=binding['source_archive_sha256'],source_files=586,
        source_modified=False,original12_rerun=False,numerical_execution=False,PBS_submitted=False)
    save(ROOT/'clm-drainage-active-n-pb-m-stage-preparation.json',report)
    print(json.dumps(report))


if __name__=='__main__':main()

"""One real, two-step low-N column; numeric execution only on EHPC PBS."""
import os
import socket
if os.name == 'nt' or socket.gethostname() != 'compute002' or not os.environ.get('PBS_JOBID'):
    raise RuntimeError('PB-m numerical case requires EHPC compute002 PBS')

from dataclasses import asdict, replace
from pathlib import Path
import json
import numpy as np
import pytest
import pbl_reference_helpers as helper
from test_clm_bgc_column import case
from noahmp_clm.column import ColumnState, Forcing
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics import photosynthesis as photo
from noahmp_clm import clm_bgc_driver as bgc_driver
from noahmp_clm.physics.biogeochemistry import BGCParameters, soil_environment
from noahmp_clm.physics.plant_cn import (PlantState, turnover_plant, leaf_nitrogen_factor,
    plan_plant_allocation, apply_plant_allocation, GC_PER_UMOL)
from run_fluxnet_column import audit_step

COUNTS = dict(independent_plan_replays=0, independent_decomposition_replays=0,
    independent_allocation_replays=0, actual_decomposition_calls=0,
    actual_biochemical_coefficient_calls=0)
DEPOSITION = 1e-5


def emit(name, value):
    raw = dict(test=name, **value)
    # Persist before assertions so the first physical failure is reviewable.
    with (Path.cwd()/'active-n-records.jsonl').open('a') as stream:
        stream.write(json.dumps(raw, allow_nan=False)+'\n')
    print('PB_M_DIAGNOSTIC '+json.dumps(raw, allow_nan=False), flush=True)


@pytest.fixture(scope='session', autouse=True)
def preserve_actual_counts():
    yield
    merged = dict(helper.CALLS, **COUNTS)
    (Path.cwd()/'component-call-counts.json').write_text(json.dumps(merged, indent=2)+'\n')
    print('PB_M_CALL_COUNTS '+json.dumps(merged), flush=True)


def test_two_real_steps_with_active_limited_n_feedback(monkeypatch):
    state, _, _ = case(None, 285., False)
    p = state.bgc_parameters
    helper.same(asdict(p), asdict(BGCParameters()))
    original_plant = state.bgc_state.plant
    n = original_plant.nitrogen.copy()
    n[0] = 2.4
    plant = PlantState(original_plant.carbon.copy(), n, 30., 0.)
    soil = replace(state.bgc_state.soil, mineral_nitrogen=.01)
    ground = SoilEnthalpyState.from_column(ColumnState(dz=state.ground.dz,
        tsoil=np.array([290.,289.,288.,287.]), smc=np.full(4,.43), soil=state.ground.params))
    state = replace(state, ground=ground, bgc_state=replace(state.bgc_state,plant=plant,soil=soil))
    forcing = Forcing(1800.,295.,.008,3.,101325.,600.,350.,0.)
    initial = dict(plant_carbon=plant.carbon.tolist(),plant_nitrogen=plant.nitrogen.tolist(),
        reserve_carbon=plant.reserve_carbon,reserve_nitrogen=plant.reserve_nitrogen,
        soil_carbon=soil.carbon.tolist(),soil_nitrogen=soil.nitrogen.tolist(),
        mineral_nitrogen=soil.mineral_nitrogen,ground_water=ground.water.tolist(),
        ground_enthalpy=ground.enthalpy.tolist(),ground_temperature=ground.temperature.tolist(),
        dz=ground.dz.tolist(),root_fractions=state.root_frac.tolist(),fveg=state.fveg,
        forcing=asdict(forcing),nitrogen_deposition_per_step=DEPOSITION,parameters=asdict(p))
    (Path.cwd()/'initial-condition.json').write_text(json.dumps(initial,indent=2)+'\n')
    previous_factor_after = None
    original_coeff = photo._biochemical_coefficients
    original_decomp = bgc_driver.step_decomposition
    for step in range(2):
        coefficient_records = []
        decomposition_records = []
        def observe_coeff(par, temperature, nitrogen, parameters, water_stress=1.):
            answer = original_coeff(par,temperature,nitrogen,parameters,water_stress)
            COUNTS['actual_biochemical_coefficient_calls'] += 1
            t,nf,stress,base = np.broadcast_arrays(temperature,nitrogen,water_stress,parameters.vcmax25)
            entropy=668.39-1.07*np.clip(parameters.growth_temperature-273.15,11.,35.)
            factor=np.exp(72000./(8.314462618*298.15)*(1.-298.15/t))
            factor*= (1.+np.exp((298.15*entropy-200000.)/(8.314462618*298.15)))/(1.+np.exp((t*entropy-200000.)/(8.314462618*t)))
            expected=base*nf*factor*stress
            error=float(np.max(abs(answer[0]-expected)))
            bound=32*np.finfo(float).eps*max(float(np.max(abs(expected))),1.)
            coefficient_records.append(dict(nitrogen_factor=nf.tolist(),temperature_k=t.tolist(),
                water_stress=stress.tolist(),vcmax25=base.tolist(),thermal_factor=factor.tolist(),
                actual_vcmax=np.asarray(answer[0]).tolist(),algebraic_max_error=error,bound=bound))
            return answer
        def observe_decomp(*args,**kwargs):
            answer=original_decomp(*args,**kwargs)
            COUNTS['actual_decomposition_calls'] += 1
            decomposition_records.append((args,kwargs,answer))
            return answer
        with monkeypatch.context() as observed:
            observed.setattr(photo,'_biochemical_coefficients',observe_coeff)
            observed.setattr(bgc_driver,'step_decomposition',observe_decomp)
            after,d,b,_=helper.run_connected(monkeypatch,state,forcing,nitrogen_deposition_gn_m2=DEPOSITION)
        assert len(decomposition_records)==1 and coefficient_records
        turned,fall=turnover_plant(state.bgc_state.plant,forcing.dt,parameters=p.plant)
        nf=leaf_nitrogen_factor(turned,p.plant)
        environment=soil_environment(after.ground,state.root_frac,p)
        plan=plan_plant_allocation(turned,d['gpp_gcm2'],d['leaf_respiration']*GC_PER_UMOL*forcing.dt,
            forcing.tair,environment['root_temperature'],forcing.dt,
            target_leaf_carbon=p.maximum_lai*state.fveg/p.plant.specific_leaf_area,growing=True,parameters=p.plant)
        COUNTS['independent_plan_replays'] += 1
        args,kwargs,(actual_soil,actual_sd)=decomposition_records[0]
        expected_soil,expected_sd=original_decomp(state.bgc_state.soil,environment['soil_temperature'],
            environment['water_potential_mpa'],forcing.dt,carbon_input=fall['litter_carbon_gc_m2'],
            nitrogen_input=fall['litter_nitrogen_gn_m2'],mineral_n_input=DEPOSITION,
            plant_n_demand=plan.soil_n_demand,oxygen_factor=1.,parameters=p.decomposition)
        COUNTS['independent_decomposition_replays'] += 1
        expected_plant,expected_ad=apply_plant_allocation(plan,expected_sd['plant_uptake_gn_m2'])
        COUNTS['independent_allocation_replays'] += 1
        bgc=d['biogeochemistry'];sd=bgc['decomposition'];ad=bgc['allocation']
        available=state.bgc_state.soil.mineral_nitrogen+DEPOSITION
        award=sd['plant_uptake_gn_m2'];immobil=sd['immobilization_gn_m2'];gross=sd['gross_mineralization_gn_m2']
        supply_bound=32*np.finfo(float).eps*max(available+award+immobil,1.)
        _,residual,bound=audit_step(state,after,forcing,d,DEPOSITION)
        (Path.cwd()/('biochemical-step-'+str(step)+'.json')).write_text(json.dumps(coefficient_records,indent=2)+'\n')
        result=dict(step=step,gpp_gc_m2=d['gpp_gcm2'],lai_used=bgc['lai_used'],
            actual_potential_decomp_demand=kwargs['plant_n_demand'],independently_planned_demand=plan.soil_n_demand,
            demand=ad['soil_n_demand_gn_m2'],uptake=award,plant_recorded_uptake=ad['soil_n_uptake_gn_m2'],
            mineral_before=state.bgc_state.soil.mineral_nitrogen,deposition=DEPOSITION,starting_available=available,
            immobilization=immobil,potential_immobilization=sd['potential_immobilization_gn_m2'],
            gross_mineralization=gross,mineral_after=after.bgc_state.soil.mineral_nitrogen,
            next_step_available_if_same_deposition=after.bgc_state.soil.mineral_nitrogen+DEPOSITION,
            limitation=sd['nitrogen_limitation'],supply_bound=supply_bound,
            nitrogen_factor_used=bgc['nitrogen_factor_used'],independent_postturnover_factor=nf,
            previous_step_factor_after=previous_factor_after,nitrogen_factor_after=bgc['nitrogen_factor_after'],
            tissue_deficit=plan.tissue_n_deficit.tolist(),nitrogen_repair=ad['nitrogen_repair_gn_m2'].tolist(),
            plant_carbon_after=after.bgc_state.plant.carbon.tolist(),plant_nitrogen_after=after.bgc_state.plant.nitrogen.tolist(),
            soil_carbon_after=after.bgc_state.soil.carbon.tolist(),soil_nitrogen_after=after.bgc_state.soil.nitrogen.tolist(),
            reserve_carbon_after=after.bgc_state.plant.reserve_carbon,reserve_nitrogen_after=after.bgc_state.plant.reserve_nitrogen,
            environment=environment,soil_temperature_after=after.ground.temperature.tolist(),soil_water_after=after.ground.water.tolist(),
            saturated_mass=d['saturated_outflow_kgm2'],perched_mass=d['perched_outflow_kgm2'],
            drainage_layer_mass=d['clm_drainage']['layer_mass_kg_m2'].tolist(),
            drainage_layer_heat=d['clm_drainage']['layer_enthalpy_j_m2'].tolist(),
            MHCN_residual=residual.tolist(),MHCN_bound=bound.tolist(),**b,
            actual_biochemical_calls=len(coefficient_records),
            vcmax_min=min(float(np.min(r['actual_vcmax'])) for r in coefficient_records),
            vcmax_max=max(float(np.max(r['actual_vcmax'])) for r in coefficient_records),
            vcmax_algebra_max_error=max(r['algebraic_max_error'] for r in coefficient_records))
        emit('active_n_'+str(step),result)
        helper.same(environment,bgc['environment'])
        helper.same(args[0],state.bgc_state.soil)
        assert args[1:]==(environment['soil_temperature'],environment['water_potential_mpa'],forcing.dt)
        helper.same(kwargs,dict(carbon_input=fall['litter_carbon_gc_m2'],nitrogen_input=fall['litter_nitrogen_gn_m2'],
            mineral_n_input=DEPOSITION,plant_n_demand=plan.soil_n_demand,oxygen_factor=1.,parameters=p.decomposition))
        helper.same(actual_soil,expected_soil);helper.same(actual_sd,expected_sd)
        helper.same(after.bgc_state.soil,expected_soil);helper.same(after.bgc_state.plant,expected_plant)
        helper.same(sd,expected_sd);helper.same(ad,expected_ad)
        assert d['gpp_gcm2']>0 and bgc['lai_used']>0 and plan.soil_n_demand>0 and award>0
        assert award<=plan.soil_n_demand+supply_bound and award+immobil<=available+supply_bound
        assert award==ad['soil_n_uptake_gn_m2'] and 0.<sd['nitrogen_limitation']<1.
        assert abs(after.bgc_state.soil.mineral_nitrogen-(max(0.,available-immobil-award)+gross))<=supply_bound
        assert bgc['nitrogen_factor_used']==nf and bgc['nitrogen_factor_after']==leaf_nitrogen_factor(after.bgc_state.plant,p.plant)
        assert all(np.all(np.asarray(r['nitrogen_factor'])==nf) and r['algebraic_max_error']<=r['bound'] for r in coefficient_records)
        assert np.all(abs(residual)<=bound) and d['saturated_outflow_kgm2']>0
        if previous_factor_after is not None:
            # Compare the real second-step post-turnover state, never stale initial N.
            assert nf!=.5
        previous_factor_after=bgc['nitrogen_factor_after']
        state=after

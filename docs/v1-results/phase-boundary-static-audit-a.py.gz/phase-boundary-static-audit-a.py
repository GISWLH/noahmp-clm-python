"""Local metadata/source/AST audit only; no numerical model or pytest import."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import tarfile

r = Path(__file__).resolve().parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
groups = ['ctsm-qia-boundary-lm', 'ctsm-qia-year-n', 'qia-stem-numpy-week-a', 'qia-stem-numpy-163-af', 'phase-final-check-cpu-a', 'phase-final-check-gpu-a', 'phase-full-deferred-a']
index, count = {}, 0
for group in groups:
    folder = r / 'docs/v1-results' / group
    manifest = json.loads((folder / 'manifest.json').read_text())
    values = {}
    for item in manifest['artifacts']:
        stored = (folder / item['path']).read_bytes()
        assert sha(stored) == item['stored_sha256']
        raw = gzip.decompress(stored) if item['path'].endswith('.gz') and not item['source'].endswith('.gz') else stored
        assert sha(raw) == item['source_sha256']
        if item['source'].endswith('.py'):
            ast.parse(raw.decode('utf-8-sig'), filename=group + '/' + item['source'])
        values[item['source']] = raw
        count += 1
    index[group] = values

def data(group, name):
    return json.loads(index[group][name])

candidate = data('phase-final-check-cpu-a', 'SOURCE_SHA256.json')
with tarfile.open(r / 'outputs/v1/p6-stem-assessment-b-source.tar.gz') as t:
    base = json.loads(t.extractfile('SOURCE_SHA256.json').read())
    old_code = t.extractfile('src/noahmp_clm/physics/canopy_phase_energy.py').read().decode().replace('\r\n', '\n')
assert len(candidate) == 506 and sorted(n for n in candidate if candidate[n] != base[n]) == ['src/noahmp_clm/physics/canopy_phase_energy.py', 'tests/test_canopy_phase_energy.py']
runtime = [n for n in candidate if n.startswith(('src/', 'tests/', 'benchmarks/', 'examples/'))]
assert len(runtime) == 503 and all(sha((r / n).read_bytes()) == candidate[n] for n in runtime)
for n in runtime:
    if n.endswith('.py'):
        ast.parse((r / n).read_text(encoding='utf-8-sig'), filename=n)
new_code = index['phase-final-check-cpu-a']['src/noahmp_clm/physics/canopy_phase_energy.py'].decode().replace('\r\n', '\n')
old_guard = "        raise RuntimeError(f'Canopy phase energy did not converge: residual={np.max(abs(residual)):.8g} W/m2')"
new_guard = "        # The last permitted update may have reached the root. Check its\n        # accepted state before declaring failure; the loop's residual is\n        # from before that update. Keep the same tolerance and update budget.\n        residual=evaluate(x)\n        if np.max(abs(residual))>tolerance:\n            raise RuntimeError(f'Canopy phase energy did not converge: residual={np.max(abs(residual)):.8g} W/m2')"
assert new_code.count(new_guard) == 1 and new_code.replace(new_guard, old_guard) == old_code
assert all(candidate[n] == base[n] for n in candidate if n.startswith('src/noahmp_clm/gpu/'))
cpu = data('phase-final-check-cpu-a', 'cpu-full-receipt.json')
assert cpu['returncode'] == 0 and cpu['source_unchanged'] and cpu['counts'] == dict(tests=901, failures=0, errors=0, skipped=0)
baseline = data('phase-final-check-cpu-a', 'original-regression-receipt.json')
assert baseline['expected_failure'] and baseline['counts'] == dict(tests=2, failures=1, errors=0, skipped=0)
gpu = data('phase-final-check-gpu-a', 'receipt.json')
exit_record = data('phase-final-check-gpu-a', 'exit.json')
assert data('phase-final-check-gpu-a', 'SOURCE_SHA256.json') == candidate
assert exit_record['passed'] and exit_record['returncode'] == gpu['pytest_returncode'] == gpu['worker_exitcode'] == 0
assert gpu['source_unchanged'] and gpu['all_setup_call_teardown_phases_passed'] and gpu['node_coverage_exact'] and gpu['counts'] == dict(tests=8, failures=0, errors=0, skipped=0)
line = next(v for v in index['phase-final-check-gpu-a']['targets.log'].decode().splitlines() if 'phase same precision ' in v)
same = ast.literal_eval(line.split('phase same precision ', 1)[1])
assert same and all(v == 0 for v in same.values())
year = data('ctsm-qia-year-n', 'summary.json')
assert year['official_model_returncode'] == 0 and year['original_parent_pbs_returncode'] == 1 and year['last_nstep'] == 17520 and year['written_history_samples'] == 17521
audit = year['year_boundary_audit']
assert audit['positive_intervals'] == 17520 and all(audit['first48_M_physical_arrays_byte_value_equal'].values())
assert audit['input_field_differences']['QBOT']['nonmatching_at_history_dtype'] == 77
assert not audit['all_direct_met_fields_exact_at_history_dtype'] and not year['cold_firstday_diagnosis']['scientific_acceptance']
original = data('qia-stem-numpy-week-a', 'summary.json')
assert original['failed_index'] == 163 and original['receipt']['returncode'] == 1
queue = data('phase-full-deferred-a', 'snapshot.json')
assert queue['launch']['source_manifest_sha256'] == gpu['source_manifest_sha256'] and not queue['current_worker_present'] and not queue['current_exit_present']
assert queue['superseded_pending_B']['original_gpu_worker_still_absent'] and queue['superseded_pending_B']['observed_terminal_state'] == 'absent'
record = dict(scope='Local source/AST/evidence-hash/accounting audit only,no local numerical model or pytest. Only NumPy exhausted-loop final state check and2 CPU regressions changed; JAX/CUDA bytes unchanged. Full CPU901/phaseGPU8 actual0,all same-precision outputs0. Original163 whole-step unresolved,official N full year retains original parent1 and77humidity mismatches; current1241 queue pending,no science/release acceptance.', groups=groups, evidence_artifacts=count, runtime_files_matching_frozen_candidate=503, source_files=506, cpu_tests=901, targeted_gpu_tests=8, same_precision_maximum=0, official_intervals=17520, original_numpy_failed_index=163, remaining_gpu_nodes=332, full_gpu_status='deferred_not_collected', scientific_acceptance=False)
assert count == 401
(r / 'docs/v1-results/phase-boundary-static-audit-a.json').write_text(json.dumps(record, indent=2) + '\n')
(r / 'docs/v1-results/phase-boundary-static-audit-a.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps(record))

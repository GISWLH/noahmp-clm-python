def _one(old,p,duration,xp,stepper,absolute,relative,budget):
    n=len(old);zero=xp.zeros(n-1,old.dtype);head,floor=_head(old,p,xp);defined=p[:,1]>0.
    result=dict(water_kg_m2=old.copy(),pressure_head_m=head,pressure_defined=defined,
        pressure_floor_active=floor,interface_transfer_kg_m2=zero.copy(),forward_transfer_kg_m2=zero.copy(),
        reverse_transfer_kg_m2=zero.copy(),accepted_substeps=xp.asarray(0,xp.int32),rejected_substeps=xp.asarray(0,xp.int32),
        maximum_nonlinear_residual_kg_m2=xp.asarray(0.,old.dtype),maximum_temporal_error_kg_m2=xp.asarray(0.,old.dtype))
    connected=(p[:,2]>0.)&defined
    if not bool(xp.all(connected)):
        begin=0
        while begin<n:
            if not bool(connected[begin]):begin+=1;continue
            end=begin+1
            while end<n and bool(connected[end]):end+=1
            part=_one(old[begin:end],p[begin:end],duration,xp,stepper,absolute,relative,budget)
            for key in ('water_kg_m2','pressure_head_m','pressure_floor_active'):result[key]=_set(result[key],slice(begin,end),part[key],xp)
            for key in ('interface_transfer_kg_m2','forward_transfer_kg_m2','reverse_transfer_kg_m2'):result[key]=_set(result[key],slice(begin,end-1),part[key],xp)
            for key in ('accepted_substeps','rejected_substeps'):result[key]=result[key]+part[key]
            for key in ('maximum_nonlinear_residual_kg_m2','maximum_temporal_error_kg_m2'):result[key]=xp.maximum(result[key],part[key])
            begin=end
    elif bool(xp.all(old==1000.*p[:,0]*p[:,1])):
        z=xp.cumsum(p[:,0])-.5*p[:,0]
        result['pressure_head_m']=z+xp.max(-p[:,3]-z);result['pressure_floor_active']=xp.zeros(n,bool)
    else:
        current=old.copy();coordinate=old.copy();elapsed=0.;step=min(duration,3600.);accepted=rejected=0
        total=zero.copy();compensation=zero.copy();forward=zero.copy();reverse=zero.copy()
        while elapsed<duration:
            if accepted+rejected>=budget:raise RuntimeError('Device Richards adaptive budget exhausted')
            step=min(step,duration-elapsed)
            coarse=stepper(current,coordinate,p,step)
            first=stepper(current,coordinate,p,.5*step)
            second=stepper(first[:n],first[n:2*n],p,.5*step)
            good=bool((coarse[-1]>0.)&(first[-1]>0.)&(second[-1]>0.))
            if not good:
                rejected+=1;step*=.5
                if step<1e-7:raise RuntimeError('Device Richards nonlinear substep underflow')
                continue
            fine=second[:n];error=xp.abs(fine-coarse[:n]);tendency=xp.maximum(xp.abs(fine-current),xp.abs(coarse[:n]-current))
            ratio=float(xp.max(error*(approximate_inverse(absolute+relative*tendency) if xp.__name__.startswith('cupy') else xp.reciprocal(absolute+relative*tendency))))
            if ratio>1.:
                rejected+=1;step*=max(.2,.8/math.sqrt(ratio));continue
            for part in (first[2*n:3*n-1],second[2*n:3*n-1]):
                value=part-compensation;updated=total+value;compensation=(updated-total)-value;total=updated
                forward=forward+xp.maximum(part,0.);reverse=reverse+xp.maximum(-part,0.)
            current=fine;coordinate=second[n:2*n];elapsed+=step;accepted+=1
            result['maximum_nonlinear_residual_kg_m2']=xp.maximum(result['maximum_nonlinear_residual_kg_m2'],xp.maximum(first[-3],second[-3]))
            result['maximum_temporal_error_kg_m2']=xp.maximum(result['maximum_temporal_error_kg_m2'],xp.max(error))
            step*=min(2.,max(.5,.8/math.sqrt(max(ratio,1e-12))))
        head,floor=_head(coordinate,p,xp)
        result.update(water_kg_m2=old+xp.concatenate((xp.zeros(1,old.dtype),total))-xp.concatenate((total,xp.zeros(1,old.dtype))),
            pressure_head_m=head,pressure_floor_active=floor,interface_transfer_kg_m2=total,
            forward_transfer_kg_m2=forward,reverse_transfer_kg_m2=reverse,
            accepted_substeps=xp.asarray(accepted,xp.int32),rejected_substeps=xp.asarray(rejected,xp.int32))
    water=result['water_kg_m2'];mass=_sum(water,xp)-_sum(old,xp)
    bound=32.*xp.finfo(old.dtype).eps*xp.maximum(_sum(xp.abs(water),xp)+_sum(xp.abs(old),xp),1.)
    if not bool(xp.abs(mass)<=bound):raise RuntimeError('Device Richards extensive water budget failed')
    if bool(xp.any(water<0.)):raise RuntimeError('Device Richards generated negative liquid storage')
    result.update(mass_residual_kg_m2=mass,mass_bound_kg_m2=bound)
    return result

from pathlib import Path
import hashlib,inspect,json,os,runpy,sys
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-b';r=b/'richards-controller-candidate-q';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
import cupy as cp
import noahmp_clm.gpu.richards as module
source='extern "C" __global__ void controller_inverse(const float* v,float* out,int n){int i=threadIdx.x;if(i<n)out[i]=1.f/v[i];}'
(r/'private-reciprocal.cu').write_text(source);compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('controller_inverse',));kernel=compiled.get_function('controller_inverse')
def approximate_inverse(value):
    assert value.dtype==cp.float32;value=cp.ascontiguousarray(value);out=cp.empty_like(value);kernel((1,),(32,),(value,out,np.int32(len(value))));return out
original=inspect.getsource(module._one);needle='ratio=float(xp.max(error*xp.reciprocal(absolute+relative*tendency)))';assert original.count(needle)==1
patched=original.replace(needle,"ratio=float(xp.max(error*(approximate_inverse(absolute+relative*tendency) if xp.__name__.startswith('cupy') else xp.reciprocal(absolute+relative*tendency))))")
(r/'private-controller.py').write_text(patched);module.approximate_inverse=approximate_inverse;exec(compile(patched,str(r/'private-controller.py'),'exec'),module.__dict__)
(r/'private-patch.json').write_text(json.dumps(dict(scope='PRIVATE diagnostic candidate only: CUDA adaptivecontroller reciprocal uses samefloat32 approximate division as its existing implicit kernels and original JAX. Fixed original errorcriterion/coarsefine/threshold/physicalequations/timestepsbudget retained, no output rounding or CPUphysics. Existing source files unchanged; native production validation still separate.',source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_one_source_sha256=hashlib.sha256(original.encode()).hexdigest(),private_one_source_sha256=sha(r/'private-controller.py'),private_kernel_sha256=sha(r/'private-reciprocal.cu')),indent=2)+'\n')
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
sys.argv=[str(worker),'--source',str(s),'--test-file',str(s/'tests/test_gpu_richards.py'),'--expected',str(r/'expected.json'),'--receipt',str(r/'receipt.json'),'--xml',str(r/'tests.xml')];os.environ['NOAHMP_RICHARDS_DIAGNOSTICS']=str(r/'diagnostics');runpy.run_path(str(worker),run_name='__main__')

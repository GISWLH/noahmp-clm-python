from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-b';r=b/'richards-controller-candidate-q';assert not r.exists()
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>8192
mem=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')));assert mem>16*1024*1024
r.mkdir();env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
env['XLA_FLAGS']='--xla_dump_to='+str(r/'xla-dump')+' --xla_dump_hlo_as_text'
env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';env['NOAHMP_REQUIRE_GPU']='1'
nodes=['test_gpu_richards.py::test_liquid_native_against_all_ehpc_quantized_references['+v+']' for v in ['jax32','jax64','cuda32']]+['test_gpu_richards.py::test_liquid_cuda_jax_every_returned_field_same_precision']
(r/'expected.json').write_text(json.dumps(nodes,indent=2)+'\n')
with (r/'model.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_richards_controller_q.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,controls_sha256={n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in ['probe_richards_controller_q.py','control_richards_controller_q.py',Path(__file__).name]})
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

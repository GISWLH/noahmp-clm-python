from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='station':
    name='richards-station-numpy-a';source=b/(name+'-source.tar.gz');r=b/name;d=json.loads((r/'receipt.json').read_text());package=json.loads((r/'package.json').read_text())
    assert d['source_unchanged'] and d['returncode']==0 and d['counts']==dict(tests=55,failures=0,errors=0,skipped=0) and d['xml_sha256']==sha(r/'tests.xml')
    assert [sha(r/'references'/('case'+str(i)+'.npz')) for i in range(2)]==['3cd3c4ede9e36466ed1945737d6f75eb6c0212e10aaed7c1581bd3f7bc01e6b6','a48036fd627d95f3fe26eb7aad9b4820ece3bfe73cc38db61231d0dd90748851']
    assert sha(source)==package['archive_sha256'];controls=['run_richards_station_numpy_a.py','richards_station_numpy_a.pbs','dispatch_richards_station_numpy_a.py']
elif mode=='columncpu':
    name='richards-column-cpu-a';source=b/'richards-column-native-a-source.tar.gz';r=b/name;d=json.loads((r/'receipt.json').read_text());package=json.loads((r/'package.json').read_text())
    assert d['source_unchanged'] and d['returncode']==0 and d['counts']==dict(tests=1049,failures=0,errors=0,skipped=0) and d['xml_sha256']==sha(r/'cpu-full.xml')
    assert sha(source)==package['archive_sha256'];controls=['run_richards_column_cpu_a.py','richards_column_cpu_a.pbs','dispatch_richards_column_cpu_a.py']
else:
    assert mode=='pressure';name='richards-pressure-consistency-j';r=b/name;source=b/(name+'-input.tar.gz');d=json.loads((r/'analysis.json').read_text());assert sha(source)==d['input_archive_sha256'] and len(d['cases'])==5
    controls=['analyze_richards_pressure_consistency_j.py','richards_pressure_consistency_j.pbs','dispatch_richards_pressure_consistency_j.py']
assert (r/'pbs-exit.txt').read_text().strip()=='0'
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(source,arcname='source/'+source.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

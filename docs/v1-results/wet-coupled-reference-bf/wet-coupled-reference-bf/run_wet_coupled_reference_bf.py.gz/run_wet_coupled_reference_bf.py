from pathlib import Path
from dataclasses import astuple
import hashlib,json,os,subprocess,sys,tarfile,time,traceback,xml.etree.ElementTree as ET
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'wet-coupled-reference-bf';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-canopy-wet-final-az-source.tar.gz';assert sha(a)=='6c9d465a423397a4767aa825ee1b37bf9ceafcab25f78139cdf14e470f941426'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());old=json.loads((b/'canopy-wet-final-ar/SOURCE_SHA256.json').read_text());assert all(old[n]==h for n,h in m.items() if n.startswith(('src/','benchmarks/')));prereq=json.loads((b/'canopy-wet-final-ar/full-receipt.json').read_text());assert (b/'canopy-wet-final-ar/pbs-exit.txt').read_text().strip()=='0' and prereq['returncode']==0 and prereq['counts']==dict(tests=1091,failures=0,errors=0,skipped=0);target=json.loads((b/'canopy-wet-final-ba/target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=4,failures=0,errors=0,skipped=0)
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')];start=time.monotonic();records=[]
def check(name,path,expected_key):
    frozen=s/'tests/fixtures'/name
    with np.load(frozen,allow_pickle=False) as a,np.load(path,allow_pickle=False) as c:
        assert set(a.files)==set(c.files),(name,'keyset');inputs=[];changed=[]
        for key in a.files:
            x,y=a[key],c[key];equal=x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes()
            if not expected_key(key):assert equal,(name,'physicalinputchanged',key);inputs.append(key)
            elif not equal:changed.append(dict(key=key,old_shape=list(x.shape),new_shape=list(y.shape),maximum_absolute_difference=float(abs(x.astype(float)-y.astype(float)).max()) if x.dtype.kind in 'fiu' and x.shape==y.shape else None))
    return dict(file=name,old_sha256=sha(frozen),new_sha256=sha(path),physical_input_arrays_byteexact=len(inputs),changed_expected_arrays=changed,scope='Only expectedoutputs maydiffer; oldfixture retained frozen and no repositoryfixture applied.')
for label,helper,name,expected in [('capacity','generate_wet_capacity_bf.py','clm_canopy_capacity_reference.npz',lambda k:'/ref' in k),('richards','generate_wet_richards_bf.py','clm_richards_reference.npz',lambda k:'/expected/' in k),('optics','generate_wet_optics_bf.py','pft_canopy_optics_reference.npz',lambda k:'_ref_' in k or k.startswith('fullref'))]:
    q=r/label;q.mkdir();begun=time.monotonic()
    try:
        ns=dict(Path=Path,astuple=astuple,hashlib=hashlib,json=json,os=os,sys=sys,tarfile=tarfile,time=time,np=np,b=b,base=b,r=q,root=q,s=s,source=s,m=m,manifest=m,sha=sha,package=dict(scope='FreshAZ productionwetarea.05 reference regeneration, alloriginal physicalinputs retained, actualAR1091+BA4 prerequisite. No device/fullcanonical/sciencepass.'))
        code=(r/helper).read_bytes();exec(compile(code,str(r/helper),'exec'),ns)
        report=check(name,q/name,expected);report.update(label=label,failure=None,seconds=time.monotonic()-begun)
    except Exception as err:report=dict(label=label,failure=type(err).__name__+': '+str(err),seconds=time.monotonic()-begun);(q/'failure.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
    records.append(report);(r/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',NOAHMP_CAPACITY_STATION_REFERENCE=str(r/'station-capacity'),NOAHMP_RICHARDS_STATION_REFERENCE=str(r/'station-richards'));env.pop('NOAHMP_REQUIRE_GPU',None);selected=['tests/test_fluxnet_capacity_runner.py::test_actual_numpy_capacity_station_carries_history_across_restart_and_year','tests/test_fluxnet_richards_runner.py::test_actual_closed_station_continuity_and_configuration_bound_restart'];xml=r/'stations.xml'
with (r/'stations.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*selected,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
counts={k:sum(int(q.attrib[k]) for q in ET.parse(xml).getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};records.append(dict(label='stationtests',returncode=code,counts=counts,failure=None if code==0 and counts==dict(tests=4,failures=0,errors=0,skipped=0) else 'actualstationtestsfailed',xml_sha256=sha(xml)))
if records[-1]['failure'] is None:
    for kind in ['capacity','richards']:
        arrays={}
        for index in range(2):
            with np.load(r/('station-'+kind)/('case'+str(index)+'.npz'),allow_pickle=False) as z:arrays.update({str(index)+'/'+k:z[k] for k in z.files})
        name='clm_'+kind+'_station_reference.npz';path=r/name;np.savez_compressed(path,**arrays)
        try:records.append(dict(label='station-'+kind,**check(name,path,lambda k:'/trace/' in k or k.endswith('/report_json')),failure=None))
        except Exception as err:records.append(dict(label='station-'+kind,failure=type(err).__name__+': '+str(err)));(r/('station-'+kind+'-failure.txt')).write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,records=records,scope='Fresh NumPy coupled-oracle generation only onEHPC, original builder math/checks unchanged and allcases/inputs retained. Check every physicalinput array dtype/shape/bytes; preserve old expected outputs, do not apply fixtures untilreview. Original builderreport scope text is historical (53/103 etc), this wrapper/currentproof is authoritativeAR1091+BA4 with byteidenticalproduction. Not GPU/canonical/year/scienceacceptance.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');assert unchanged and all(q['failure'] is None for q in records)

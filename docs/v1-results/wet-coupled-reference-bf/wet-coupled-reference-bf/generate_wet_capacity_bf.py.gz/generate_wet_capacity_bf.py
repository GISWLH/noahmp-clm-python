# Runs only inside the successful EHPC NumPy reference worker.
sys.path[:0]=[str(source/'src'),str(source/'tests'),str(source/'benchmarks'),str(source)]
from dataclasses import astuple,replace
import numpy as np
from noahmp_clm.physics.canopy_capacity import TemperatureMemory,CanopyCapacityParameters,CanopyCapacityEnvironment,canopy_capacity_profile
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_optics import CanopyOptics
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.vegetation_structure import CanopyStructureParameters
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.column import Forcing
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase
from noahmp_clm.gpu.clm_capacity_column import pack_clm_capacity_columns,pack_capacity_environment
from test_canopy_phase_energy import cases as phase_cases
from test_gpu_canopy_phase_energy import reference as phase_reference
from test_clm_bgc_column import case
from test_gpu_clm_bgc_column import reference as column_reference
from run_fluxnet_column import audit_step

output={};audits=[]
for precision,dtype in [('32',np.float32),('64',np.float64)]:
    prefix='phase'+precision+'/'
    batches=[];parameters=[];references=[]
    for index,name in enumerate(['liquid','dry']):
        _,leaf,sw,lw,exchange,condensate,kwargs=next(row for row in phase_cases() if row[0]==name)
        arrays=pack_canopy_phase(leaf,sw,lw,exchange,condensate,1800.,dtype=dtype,**kwargs)
        traits=CanopyCapacityParameters(*np.asarray([.01 if index==0 else .015,58. if index==0 else 25.,.0509 if index==0 else .04,1.],dtype).astype(float))
        profile=canopy_capacity_profile(np.asarray(arrays[0],float),30000.+4000.*index,45000.,290.+5.*index,traits)
        rows=np.asarray(profile['leaf_parameters'],dtype)
        ref=phase_reference(arrays,leaf_parameters=LeafParameters.from_layer_rows(rows.astype(float)),tolerance=1e-7,max_iterations=80)
        assert np.max(abs(ref['solver_residual']))<=1e-7
        batches.append(arrays);parameters.append(rows);references.append(ref)
    for k in range(9):output[prefix+'a'+str(k)]=np.stack([a[k] for a in batches])
    output[prefix+'parameters']=np.stack(parameters)
    for name in ['h','le','gpp','leaf_temperature']:output[prefix+'ref/'+name]=np.asarray([v[name] for v in references])
    for structured in [False,True]:
        prefix='full'+precision+'/'+str(int(structured))+'/'
        states=[];forcings=[];environments=[]
        for k,poor in enumerate([False,True]):
            state,f,_=case(None,285.,poor)
            if k:f=replace(f,tair=295.,qair=.009,swdown=500.,lwdown=350.)
            if structured:state=state.with_vegetation_structure(CanopyStructureParameters(canopy_top_m=8.,canopy_bottom_m=1.),sai=.55 if k==0 else .2)
            memory=TemperatureMemory.cold(f.dt) if k==0 else TemperatureMemory(np.linspace(275.,305.,480),f.dt,480,237)
            traits=CanopyCapacityParameters(.01 if k==0 else .015,58. if k==0 else 35.,.0509 if k==0 else .04)
            states.append(state.with_canopy_capacity(traits,memory));forcings.append(astuple(f))
            environments.append(CanopyCapacityEnvironment(30000.+4000.*k,45000.))
        arrays=pack_clm_capacity_columns(states,kind='bgc',structured=structured,dtype=dtype)
        forcing=np.asarray(forcings,dtype);environment=pack_capacity_environment(environments,dtype=dtype)
        geometry=np.asarray([astuple(MOSTGeometry())]*2,dtype)
        optics=np.asarray([[.07,.35,.05,.10,.16,.39,.001,.001]]*2,dtype)
        template=np.asarray([astuple(LeafParameters()),astuple(LeafParameters(ball_berry_slope=4.4713363873))],dtype)
        output[prefix+'state_count']=np.asarray(len(arrays),np.int32)
        for k,value in enumerate(arrays):output[prefix+'a'+str(k)]=value
        for name,value in [('forcing',forcing),('environment',environment),('geometry',geometry),('optics',optics),('template',template)]:output[prefix+name]=value
        base=19 if structured else 16
        for most in [False,True]:
            columns=[]
            for k in range(2):
                row=tuple(a[k] for a in arrays)
                capacity_environment=CanopyCapacityEnvironment(*environment[k].astype(float))
                optical=CanopyOptics(*optics[k].astype(float).reshape(4,2))
                leaf_parameters=LeafParameters(*template[k].astype(float))
                measurement=MOSTGeometry(*geometry[k].astype(float)) if most else None
                nitrogen=float(dtype(1e-5))
                ref,old,final=column_reference(row[:16],forcing[k],np.zeros(5,dtype),np.zeros(2,dtype),np.zeros(2,np.int32),nitrogen,1.,
                    canopy_structure=row[16:19] if structured else None,canopy_capacity=row[base:],capacity_environment=capacity_environment,
                    canopy_optics=optical,leaf_parameters=leaf_parameters,most_geometry=measurement,return_states=True)
                sequence=[]
                for step in range(2):
                    if step:
                        old=final
                        final,diagnostic=step_clm_enthalpy_column(old,Forcing(*forcing[k].astype(float)),
                            co2_ppm=float(row[4][7]),cosine_zenith=float(row[4][8]),diffuse_fraction=float(row[4][9]),leaf_dimension=float(row[4][10]),
                            nitrogen_deposition_gn_m2=nitrogen,capacity_environment=capacity_environment,canopy_optics=optical,
                            leaf_parameters=leaf_parameters,most_geometry=measurement)
                    else:diagnostic=ref['diagnostics']
                    _,residual,bound=audit_step(old,final,Forcing(*forcing[k].astype(float)),diagnostic,nitrogen)
                    assert np.all(abs(residual)<=bound)
                    memory=final.canopy_capacity_state
                    sequence.append(dict(**{name:diagnostic[name] for name in ['h','le','gpp_gc_m2','nee_gc_m2','leaf_temperature']},
                        memory_values=memory.values,memory_controls=np.asarray([memory.count,memory.cursor],np.int32),
                        next_mean_temperature_k=memory.mean_temperature_k,tsoil_k=final.tsoil,smc_m3m3=final.smc,
                        original_MHCN_residual=residual,original_MHCN_bounds=bound))
                    audits.append(dict(precision=precision,structured=structured,most=most,column=k,step=step,
                                       residual=residual.tolist(),original_bounds=bound.tolist()))
                columns.append(sequence)
            for step in range(2):
                refprefix=prefix+'ref'+str(int(most))+'/'+str(step)+'/'
                for name in columns[0][step]:output[refprefix+name]=np.asarray([column[step][name] for column in columns])
path=root/'clm_canopy_capacity_reference.npz';np.savez_compressed(path,**output)
unchanged=all(sha(source/name)==value for name,value in manifest.items())
record=dict(scope='EHPC NumPy-only original-input quantized32/64 references after53actual0. Per-layer phase two-column300 boundaries; complete20/23-array two-column trait/gas-exchange distinctions, MOST off/on, two strictly continuous DP steps. Quantized root weights normalize on NumPy reconstruction as existingreference; DP reference states are not re-rounded between steps. Original per-step hard MHCN bounds all checked. No device forward calculation or year/FLUXNET acceptance.',
            pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,reference_sha256=sha(path),source_unchanged=unchanged,
            source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),phase_cases_per_precision=2,whole_audits=audits)
(root/'reference.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='whole_audits'}),flush=True)
assert unchanged

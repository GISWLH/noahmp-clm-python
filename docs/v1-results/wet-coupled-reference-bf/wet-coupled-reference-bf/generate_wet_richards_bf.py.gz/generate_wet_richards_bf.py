from richards_column_cases import KINDS,initial,decode,pack
from noahmp_clm.column import Forcing
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.richards import RichardsHydrology
from noahmp_clm.physics.canopy_most import MOSTGeometry
start=time.monotonic();data={};records=[]
for precision,dtype in [('32',np.float32),('64',np.float64)]:
    for index,kind in enumerate(KINDS):
        arrays,forcing,deposition,geometry=initial(kind,dtype);state=decode(arrays,kind);prefix=precision+'/'+str(index)+'/'
        data[prefix+'arrays']=np.array(len(arrays),np.int32)
        data.update({prefix+'initial/'+str(i):v for i,v in enumerate(arrays)})
        data.update({prefix+'forcing':forcing,prefix+'deposition':deposition})
        if geometry is not None:
            values=np.asarray(astuple(geometry),dtype);data[prefix+'geometry']=values[None,:];geometry=MOSTGeometry(*map(float,values))
        nitrogen=np.full(1,1e-5,dtype);data[prefix+'nitrogen']=nitrogen
        site=arrays[4][0].astype(float);kwargs=dict(zip(['co2_ppm','cosine_zenith','diffuse_fraction','leaf_dimension'],site[7:11]))
        kwargs['soil_hydrology']=None if kind=='legacy' else RichardsHydrology()
        if geometry is not None:kwargs['most_geometry']=geometry
        if kind in ('bgc','structure'):kwargs['nitrogen_deposition_gn_m2']=float(nitrogen[0])
        steps=[]
        for step in range(2):
            old=state;state,d=step_clm_enthalpy_column(state,Forcing(*forcing[step,0].astype(float)),deposition_rates=deposition[step,0].astype(float),**kwargs)
            assert abs(d['water_residual_kgm2'])<3e-10 and abs(d['energy_residual_jm2'])<.02
            ref=pack(state,kind,np.float64);e=prefix+'expected/'+str(step)+'/'
            data.update({e+'soil_cells':ref[1],e+'options':ref[3],e+'temperature_k':state.ground.temperature[None,:]})
            keys=['h','le','gpp_gcm2','et_mm','runoff_mm','swe','prcp_mm','precipitation_enthalpy_jm2']
            if 'nee_gc_m2' in d:keys.append('nee_gc_m2')
            data.update({e+'diagnostics/'+key:np.asarray([d[key]]) for key in keys})
            cn=None
            if state.bgc_state is not None:
                carbon=state.bgc_state.total_carbon-old.bgc_state.total_carbon+d['nee_gc_m2']
                nitrogen_res=state.bgc_state.total_nitrogen-old.bgc_state.total_nitrogen-float(nitrogen[0])
                bg=d['biogeochemistry'];assert abs(carbon)<=bg['carbon_bound_gc_m2'] and abs(nitrogen_res)<=bg['nitrogen_bound_gn_m2']
                cn=dict(carbon=carbon,nitrogen=nitrogen_res)
            steps.append(dict(step=step,water_residual=d['water_residual_kgm2'],heat_residual=d['energy_residual_jm2'],cn=cn))
        records.append(dict(precision=precision,index=index,kind=kind,arrays=len(arrays),steps=steps))
assert len(records)==18
np.savez_compressed(r/'clm_richards_reference.npz',**data)
d=dict(scope=package['scope'],pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),reference_sha256=sha(r/'clm_richards_reference.npz'),trajectories=records,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

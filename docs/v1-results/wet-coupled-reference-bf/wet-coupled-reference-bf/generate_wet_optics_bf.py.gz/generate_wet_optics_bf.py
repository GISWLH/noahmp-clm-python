from noahmp_clm.physics.canopy_optics import CanopyOptics
from noahmp_clm.physics.canopy_snow_radiation import canopy_snow_shortwave
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.gpu.canopy_snow_radiation import pack_canopy_snow_case
pft=CanopyOptics((.07,.35),(.05,.1),(.16,.39),(.001,.001));rows=[]
for layers in [0,1,5]:
    snow=Snowpack.from_ice(np.full(layers,10.),265.) if layers else Snowpack.empty()
    for fv in [0.,.65,1.]:
        for diff in [0.,.6,1.]:rows.append((np.full(10,.3),np.full(10,.055),snow,700.,fv,diff,[.1,.5,1.][len(rows)%3],pft))
rows.extend([(np.zeros(10),np.full(10,.1),Snowpack.empty(),600.,1.,.5,.5,pft),
    (np.zeros(10),np.zeros(10),Snowpack.from_ice([20.],265.),600.,.7,.4,.4,pft),
    (np.full(10,.3),np.full(10,.055),Snowpack.from_ice([10.],265.),0.,1.,1.,.2,pft),
    (np.full(10,.3),np.full(10,.1),Snowpack.empty(),600.,1.,.5,.5,CanopyOptics((.5,.75),(.5,.25),(.16,.39),(.001,.001)))])
rng=np.random.default_rng(622891)
for i in range(16):
    ns=i%6;mass=10.**rng.uniform(-3.,2.,ns);snow=Snowpack(mass,-2100.*mass*5.,mass/250.,rng.uniform(40.,1200.,ns),mass[:,None]*10.**rng.uniform(-10.,-5.,(ns,5)))
    leaf=rng.uniform(.01,.6,10);stem=rng.uniform(0.,.15,10);leaf[::4]=0.
    optics=CanopyOptics(tuple(rng.uniform(.04,.4,2)),tuple(rng.uniform(.02,.3,2)),tuple(rng.uniform(.08,.4,2)),tuple(rng.uniform(0.,.08,2)))
    rows.append((leaf,stem,snow,float(rng.uniform(10.,900.)),float(rng.uniform(.1,1.)),float(rng.uniform(0.,1.)),float(rng.uniform(.1,1.)),optics))
out={};primary=['canopy_absorbed','absorbed_par','snow_absorbed','soil_absorbed','reflected','residual','snow_direct_albedo','snow_diffuse_albedo','leaf_absorbed_bands','stem_absorbed_bands']
for label,dtype in [('32',np.float32),('64',np.float64)]:
    packed=[];leaves=[];parameters=[];references={n:[] for n in primary}
    for leaf,stem,snow,sw,fv,diff,mu,optics in rows:
        area=(leaf+stem).astype(dtype);l=leaf.astype(dtype);p=np.asarray([v for n in optics.__dataclass_fields__ for v in getattr(optics,n)],dtype)
        a,c,n,u=pack_canopy_snow_case(area,snow,sw,vegetated_fraction=fv,diffuse_fraction=diff,cosine_zenith=mu,dtype=dtype)
        packed.append((a,c,n,u));leaves.append(l);parameters.append(p)
        nn=int(n);cc=np.asarray(c,float);pack=Snowpack(cc[:nn,0],np.zeros(nn),cc[:nn,0]/250.,cc[:nn,1],cc[:nn,2:])
        props=CanopyOptics(*np.asarray(p,float).reshape(4,2));uu=np.asarray(u,float)
        ref=canopy_snow_shortwave(np.asarray(a,float),pack,float(uu[0]),vegetated_fraction=float(uu[1]),diffuse_fraction=float(uu[2]),cosine_zenith=float(uu[3]),ground_albedo=tuple(uu[4:6]),canopy_optics=props,photosynthetic_leaf_area=np.asarray(l,float))
        ref.update(absorbed_par=ref['canopy']['absorbed_par'],leaf_absorbed_bands=ref['canopy']['leaf_absorbed_bands'],stem_absorbed_bands=ref['canopy']['stem_absorbed_bands']);ref['snow_absorbed']=np.pad(ref['snow_absorbed'],(0,5-nn))
        for name in primary:references[name].append(ref[name])
    for k in range(4):out[label+'_a'+str(k)]=np.stack([v[k] for v in packed])
    out[label+'_leaf']=np.stack(leaves);out[label+'_optics']=np.stack(parameters)
    for n,vals in references.items():out[label+'_ref_'+n]=np.asarray(vals,float)
# Whole-column references use identical physical input configuration; float32
# input packing is separately disclosed, not labelled bit-identical float64.
from test_clm_bgc_column import case
from noahmp_clm.physics.vegetation_structure import CanopyStructureParameters
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.gpu.clm_structure_column import pack_clm_structure_columns
from run_fluxnet_column import audit_step
old,f,env=case(None,285.);old=old.with_vegetation_structure(CanopyStructureParameters(canopy_top_m=8.,canopy_bottom_m=1.),sai=.55)
for label,dtype in [('32',np.float32),('64',np.float64)]:
    arrays=pack_clm_structure_columns([old],kind='bgc',dtype=dtype)
    for k,v in enumerate(arrays):out['full'+label+'_a'+str(k)]=v
    out['full'+label+'_forcing']=np.asarray([astuple(f)],dtype);out['full'+label+'_optics']=np.asarray([[v for n in pft.__dataclass_fields__ for v in getattr(pft,n)]],dtype)
    out['full'+label+'_geometry']=np.asarray([astuple(MOSTGeometry())],dtype)
for most in [False,True]:
    new,d=step_clm_enthalpy_column(old,f,canopy_optics=pft,most_geometry=MOSTGeometry() if most else None,nitrogen_deposition_gn_m2=1e-5)
    _,residual,bound=audit_step(old,new,f,d,1e-5);prefix='fullref'+str(int(most))+'_'
    for n in ['h','le','gpp_gc_m2','nee_gc_m2']:out[prefix+n]=np.asarray([d[n]],float)
    out[prefix+'tsoil_k']=new.tsoil[None,:];out[prefix+'smc_m3m3']=new.smc[None,:]
    out[prefix+'MHCN_residual']=residual;out[prefix+'MHCN_bound']=bound
assert all(sha(s/n)==h for n,h in m.items())
dest=r/'pft_canopy_optics_reference.npz';np.savez_compressed(dest,**out)
record=dict(scope='EHPC PBS NumPy-only physical reference generation after103actual0. Component47cases for both float32/64: every device input first quantized then CPU reference reconstructed in float64. Whole structuredBGC/MOST references from originalfloat64physical configuration,devicepacked32/64 differences disclosed;all originalMHCN bounds checked. No GPUcode or science/defaults/annual acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,component_cases=len(rows),component_reference_fields=primary,whole_reference_MOST_cases=2,source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),fixture_sha256=sha(dest),fixture_bytes=dest.stat().st_size)
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());print(json.dumps(record),flush=True)

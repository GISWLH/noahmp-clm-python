from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'wet-coupled-reference-bf';assert not r.exists();r.mkdir();controls={}
for name in ['run_wet_coupled_reference_bf.py','wet_coupled_reference_bf.pbs','generate_wet_capacity_bf.py','generate_wet_richards_bf.py','generate_wet_optics_bf.py']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'wet_coupled_reference_bf.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

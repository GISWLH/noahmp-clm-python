from pathlib import Path
import hashlib,json,sys,tarfile
mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[];roots=[]
if mode in ['gpu-bc','gpu-bi']:
    b=Path('/home/lhwang/work/noahmp-v1');s=b/('clm-canopy-wet-final-az' if mode=='gpu-bc' else 'clm-canopy-wet-key-bi');root=s/mode;d=json.loads((root/'exit.json').read_text());q=json.loads((root/'test_gpu_canopy_phase_energy-receipt.json').read_text());assert d['source_unchanged'] and q['node_coverage_exact'] and q['counts']==dict(tests=14,failures=1 if mode=='gpu-bc' else 0,errors=0,skipped=0) and d['passed']==(mode=='gpu-bi');roots=[root];items.append((s/'SOURCE_SHA256.json','SOURCE_SHA256.json'));controls=['clm-canopy-wet-final-az-source.tar.gz','gpu-worker-lifecycle-a/run_pytest_worker_a.py'];name='canopy-wet-'+mode
else:
    b=Path('/home/zhangyq/noahmp-v1')
    if mode=='refs-bg':
        root=b/'wet-reference-bg';d=json.loads((root/'references/receipt.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['failure'] is None and d['source_unchanged'] and d['keys']==190 and d['solver_defaults_from_production_signature'];roots=[root];controls=['clm-canopy-wet-final-az-source.tar.gz','clm-canopy-wet-final-az-package.json','dispatch_wet_reference_bg.py'];name='canopy-wet-references-bg'
    elif mode=='cpu-ba':
        root=b/'canopy-wet-final-ba';d=json.loads((root/'full-receipt.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1093,failures=0,errors=0,skipped=0);roots=[root];controls=['clm-canopy-wet-final-az-source.tar.gz','clm-canopy-wet-final-az-package.json','dispatch_canopy_wet_final_ba.py'];name='canopy-wet-cpu-ba'
    elif mode=='coupled-bf':
        root=b/'wet-coupled-reference-bf';d=json.loads((root/'receipt.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged'] and len(d['records'])==6 and all(q['failure'] is None for q in d['records']);roots=[root];controls=['clm-canopy-wet-final-az-source.tar.gz','dispatch_wet_coupled_bf.py'];name='wet-coupled-reference-bf'
    elif mode=='cold-ax':
        for label in ['capacity','capacity_optics']:
            root=b/('qia-wet-'+label+'-numpy-cold-ax');d=json.loads((root/'receipt.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['failure'] is None and d['source_unchanged'] and not d['private_runtime_patch'] and d['physical_trace_fields_exact']==29 and d['steps_completed']==96 and d['steps_requested']==17520;roots.append(root)
        controls=['clm-canopy-wet-final-aq-source.tar.gz','dispatch_qia_wet_cold_ax.py'];name='qia-wet-cold-ax'
    else:raise ValueError(mode)
for root in roots:
    for p in sorted(root.rglob('*')):
        if p.is_file():items.append((p,root.name+'/'+p.relative_to(root).as_posix()))
items.extend((b/n,'control/'+n) for n in [*controls,Path(__file__).name]);a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

from pathlib import Path
import tarfile

b=Path('/home/zhangyq/noahmp-v1')
with tarfile.open(b/'ctsm-qia-run-f/case-configuration-private.tar.gz') as t:
 for m in t:
  if m.isfile() and ('atm.log.' in m.name or 'lnd.log.' in m.name):
   print('FILE',m.name);print(t.extractfile(m).read().decode(errors='replace')[-13000:])
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 for m in t:
  if m.isfile() and m.name.endswith('shr_stream_mod.F90'):
   lines=t.extractfile(m).read().decode().splitlines();wanted=set()
   for i,line in enumerate(lines):
    if 'subroutine shr_stream_getCalendar' in line:wanted.update(range(max(0,i-3),min(len(lines),i+95)))
   print('FILE',m.name);print('\n'.join(str(i+1)+':'+lines[i] for i in sorted(wanted)))

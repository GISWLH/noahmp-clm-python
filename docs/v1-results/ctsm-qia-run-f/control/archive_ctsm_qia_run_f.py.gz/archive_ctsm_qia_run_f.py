from pathlib import Path
import hashlib,io,json,tarfile

b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-run-f';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'configuration.json').read_text());assert d['upstream_original_bytes_unchanged'] and d['official_model_returncode']==233 and (r/'pbs-exit.txt').read_text().strip()=='1'
assert {x['stage']:x['returncode'] for x in d['stages']}['case-build']==0
a=b/'ctsm-qia-run-f-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.name!='case-configuration-private.tar.gz':t.add(p,arcname=p.name,recursive=False)
 with tarfile.open(r/'case-configuration-private.tar.gz') as original:
  for m in original:
   if m.isfile() and (m.name.endswith(('.stdout.txt','.stderr.txt','-adaptation.json','.stream')) or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in','drv_in','lnd_in'])) or m.name.startswith('case/user_nl_')):
    data=original.extractfile(m).read();info=tarfile.TarInfo('workspace/'+m.name);info.size=len(data);t.addfile(info,io.BytesIO(data))
 info=tarfile.TarInfo('summary.json');data=(json.dumps(dict(scope='Official Qia F/PBS172 namelist/build/linkage0,actual executable233 before physics at missing static topography time coordinate,not a scientific model output. Source unchanged; original complete workspace retained privately.',pbs='172.manager',upstream_unchanged=True,private_workspace_sha256=sha(r/'case-configuration-private.tar.gz'),executable=d['executable'],failure='shr_stream_getCalendar: derived static TOPO file omitted original singleton time variable and axis.',seconds=d['seconds']),indent=2)+'\n').encode();info.size=len(data);t.addfile(info,io.BytesIO(data))
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 t.add(b/'inspect_ctsm_qia_calendar_f.py',arcname='control/inspect_ctsm_qia_calendar_f.py',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

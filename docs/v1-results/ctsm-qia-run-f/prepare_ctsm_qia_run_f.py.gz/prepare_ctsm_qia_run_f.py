from pathlib import Path
import ast

r=Path(__file__).resolve().parent
p=(r/'run_ctsm_qia_e.py').read_text().replace('ctsm-qia-run-e','ctsm-qia-run-f')
old="                ET.ElementTree(root).write(rundir/name,encoding='utf-8',xml_declaration=True)"
new="""                # The pinned Fortran reader scans one tag/data record per line.
                # E aborted before physics: <dataSource> was inline after <file>.
                for element in root.iter():
                    if element.text and element.text.strip():element.text='\\n'+element.text.strip()+'\\n'
                ET.indent(root,space='  ')
                ET.ElementTree(root).write(rundir/name,encoding='utf-8',xml_declaration=True)
                lines=(rundir/name).read_text().splitlines()
                assert all(any(line.lstrip().startswith('<'+tag+'>') for line in lines) for tag in ['dataSource','domainInfo','fieldInfo','variableNames','filePath','fileNames','offset'])"""
assert p.count(old)==1;p=p.replace(old,new);ast.parse(p)
(r/'run_ctsm_qia_f.py').write_text(p)
p=(r/'ctsm_qia_run_e.pbs').read_text().replace('ctsm-qia-run-e','ctsm-qia-run-f').replace('run_ctsm_qia_e.py','run_ctsm_qia_f.py').replace('clm-qia-official-e','clm-qia-official-f')
(r/'ctsm_qia_run_f.pbs').write_bytes(p.encode())

from pathlib import Path
import hashlib,io,json,re,tarfile
base=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pairs=[];extras=[];private=[];summaries=[]
for label,job in [('a','111.manager'),('b','112.manager'),('c','113.manager')]:
    root=base/('ctsm-case-config-'+label);r=json.loads((root/'configuration.json').read_text());assert r['pbs_job']==job and (root/'pbs-exit.txt').read_text().strip()=='1'
    if label=='c':
        assert r['case_configuration_created'] and r['upstream_original_bytes_unchanged']
        assert next(v for v in r['stages'] if v['stage']=='case-setup')['returncode']==0 and next(v for v in r['stages'] if v['stage']=='preview-namelists')['returncode']==1
    for name in ['configure_ctsm_case_'+label+'.py','ctsm_case_config_'+label+'.pbs','configuration.json','configuration.log','node.txt','pbs-exit.txt']:pairs.append((root/name,label+'/'+name))
    errors={};workspace=root/'case-configuration-private.tar.gz'
    with tarfile.open(workspace) as archive:
        names=archive.getnames()
        for name in ['case-setup.stdout.txt','case-setup.stderr.txt','preview-namelists.stdout.txt','preview-namelists.stderr.txt']:
            if name not in names:continue
            raw=archive.extractfile(name).read().decode();lines=[];redacted=0
            for line in raw.splitlines()[-35:]:
                if re.search(r'(token|password|authorization|secret|api_key)\s*[=:]',line,re.I):lines.append('[credential-like assignment omitted]');redacted+=1
                else:lines.append(line)
            errors[name]=dict(text='\n'.join(lines),redacted_lines=redacted)
        for name in ['machine-adaptation.json','resource-adaptation.json']:
            if name in names:extras.append((label+'/'+name,archive.extractfile(name).read()))
    extras.append((label+'/safe-error-excerpts.json',(json.dumps(errors,indent=2)+'\n').encode()))
    private.append(dict(case=label,path=str(workspace),sha256=sha(workspace),scope='Private original generated case/workspace, not included in public evidence.'))
    summaries.append(dict(case=label,pbs_job=job,overall_exit=1,stages=[dict(stage=s['stage'],returncode=s['returncode']) for s in r['stages']],errors=errors))
extras.append(('private-workspace-bindings.json',(json.dumps(private,indent=2)+'\n').encode()));pairs.append((Path(__file__),'archive_ctsm_case_config_abc.py'))
dest=base/'ctsm-case-config-abc-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as archive:
    for path,name in pairs:archive.add(path,arcname=name,recursive=False)
    for name,data in extras:
        member=tarfile.TarInfo(name);member.size=len(data);archive.addfile(member,io.BytesIO(data))
print(json.dumps(dict(files=len(pairs)+len(extras),sha256=sha(dest),scope='EHPC original111 modulecmd/112 stack-hard-limit failures and113 successful case/setup with preview still failing. Upstream2930 bytes unchanged; no official build/output or scientific acceptance.',summary=summaries)))

from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-case-config-b';scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-case-config-b';scratch.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic();stages=[];failure=None;value={}
try:
    for archive,digest,dest in [(base/'ctsm-portable-env-a.tar.gz','8f1d5ba12ed58a68e18293c182991d84cacbccd53f7dd8c86e06f687ea719769',scratch/'toolchain'),(base/'ctsm-reference-source-bundle-a.tar.gz','f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',scratch)]:
        assert sha(archive)==digest;dest.mkdir(exist_ok=True)
        with tarfile.open(archive) as t:t.extractall(dest,filter='data')
    source=scratch/'CTSM';prefix=scratch/'toolchain';case=scratch/'case';inputs=scratch/'inputdata';inputs.mkdir();output=scratch/'output'
    lock=json.loads((scratch/'UPSTREAM_SOURCE_LOCK.json').read_text());verify=lambda:all(sha(scratch/n)==v for n,v in lock['files'].items());assert verify()
    aliases=scratch/'compiler-bin';aliases.mkdir()
    for name,target in [('gcc','gcc'),('g++','g++'),('gfortran','gfortran')]:
        (aliases/name).symlink_to(prefix/'bin'/('x86_64-conda-linux-gnu-'+target))
    env=os.environ.copy()
    for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
    env.update(PATH=str(aliases)+':'+str(prefix/'bin')+':/usr/bin:/bin',CONDA_PREFIX=str(prefix),NETCDF_PATH=str(prefix),NETCDF_C_PATH=str(prefix),NETCDF_FORTRAN_PATH=str(prefix),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    def run(label,args,cwd=source):
        start=time.monotonic()
        try:p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,timeout=120);code=p.returncode;out=p.stdout;err=p.stderr
        except subprocess.TimeoutExpired as e:code=124;out=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else (e.stdout or '');err='Bounded case-configuration subprocess timeout.'
        (scratch/(label+'.stdout.txt')).write_text(out);(scratch/(label+'.stderr.txt')).write_text(err)
        stages.append(dict(stage=label,command=[str(v) for v in args],returncode=code,seconds=time.monotonic()-start));return code
    py=str(prefix/'bin/python');assert run('relocate',[py,str(prefix/'bin/conda-unpack')])==0
    assert run('machine-query',[py,str(source/'cime/scripts/query_config'),'--machines','centos7-linux','--long'])==0
    command=[py,str(source/'cime/scripts/create_newcase'),'--case',str(case),'--srcroot',str(source),'--compset','2000_DATM%1PT_CLM50%SP_SICE_SOCN_SROF_SGLC_SWAV','--res','1x1_brazil','--machine','centos7-linux','--compiler','gnu','--mpilib','mpi-serial','--pecount','1','--output-root',str(output),'--input-dir',str(inputs),'--handle-preexisting-dirs','a','--run-unsupported']
    assert run('create-case',command)==0
    assert run('xmlchange',[py,str(case/'xmlchange'),'GMAKE_J=1,STOP_OPTION=nsteps,STOP_N=48,DOUT_S=FALSE'],case)==0
    # Adapt only generated case configuration: EHPC has no modulecmd.
    specific=case/'env_mach_specific.xml';tree=ET.parse(specific);node=tree.getroot()
    module=node.find('module_system');assert module is not None
    before=ET.tostring(module,encoding='unicode');module.clear();module.set('type','none')
    for child in list(node):
        if child.tag=='modules':node.remove(child)
    variables=node.find('environment_variables')
    if variables is None:variables=ET.SubElement(node,'environment_variables')
    for name in ['NETCDF_PATH','NETCDF_C_PATH','NETCDF_FORTRAN_PATH','LD_LIBRARY_PATH']:
        for element in node.findall('.//env'):
            if element.get('name')==name:element.text=str(prefix/'lib') if name=='LD_LIBRARY_PATH' else str(prefix)
        if not any(element.get('name')==name for element in node.findall('.//env')):
            element=ET.SubElement(variables,'env',{'name':name});element.text=str(prefix/'lib') if name=='LD_LIBRARY_PATH' else str(prefix)
    tree.write(specific,encoding='utf-8',xml_declaration=True)
    (scratch/'machine-adaptation.json').write_text(json.dumps(dict(scope='Generated case environment only, no upstream machine/physics source edits.',original_module_system=before,new_module_system='none',netcdf_root=str(prefix)),indent=2)+'\n')
    assert run('case-setup',[py,str(case/'case.setup')],case)==0
    run('preview-namelists',[py,str(case/'preview_namelists')],case)
    value['input_file_lists']={p.relative_to(case).as_posix():p.read_text() for p in case.rglob('*input_data_list*') if p.is_file()}
    value['case_configuration_created']=True
    value['upstream_original_bytes_unchanged']=verify();assert verify()
except BaseException as e:failure=type(e).__name__+': '+str(e)
if 'verify' in locals():value['upstream_original_bytes_unchanged']=verify()
value.update(scope='Official single-column SP/stub runoff/glacier case configuration only, not a model build/run/science result. Original upstream physics unchanged; generated case stays private until its metadata is reviewed.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,failure=failure,seconds=time.monotonic()-begun)
(root/'configuration.json').write_text(json.dumps(value,indent=2)+'\n')
with tarfile.open(root/'case-configuration-private.tar.gz','w:gz') as t:
    for p in sorted(scratch.iterdir()):
        if p.name not in ['CTSM','toolchain','compiler-bin']:t.add(p,arcname=p.name)
print(json.dumps(value),flush=True)
raise SystemExit(0 if failure is None and all(s['returncode']==0 for s in stages) else 1)

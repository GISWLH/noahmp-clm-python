"""One isolated B geometry diagnostic; host only loads/assembles/encodes packets."""
import argparse
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import traceback
from contract_pcd import GPU,HERE,bound_evidence,controls,save,sha,source_identity

def main():
    p=argparse.ArgumentParser()
    for key in ('source','evidence','output'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--backend',choices=('cuda',),required=True);a=p.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert os.environ.get('XLA_FLAGS') is None and os.environ.get('JAX_ENABLE_X64','').lower()=='false'
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert all(str(Path(os.environ[n]).resolve()).startswith('/tmp/drainage-pc-d-') for n in ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH'))
    assert not a.output.exists();binding=json.loads((HERE/'BINDINGS.json').read_bytes());control=controls()
    identity=source_identity(a.source,binding);prior=bound_evidence(a.evidence,binding)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))
    assert free>8192 and mem>32*1024*1024
    a.output.mkdir();record=dict(capture_completed=False,scientific_acceptance=False,pid=os.getpid(),gpu_uuid=GPU,**identity,
        controls_manifest_sha256=control,CPU_physical_reference_calls=0,model_calls=0,phase_calls=0,
        candidate_kernel_attempted=0,candidate_kernel_returned=0,RN_kernel_attempted=0,RN_kernel_returned=0,
        JAX_imported=False,default_JAX_flags_changed=False,production_source_patch_applied=False,FP64_introduced=False)
    started=time.monotonic()
    try:
        import numpy as np
        import cupy as cp
        from cupy.cuda import compiler as cc
        from cupy.cuda import function as cf
        assert cp.__version__=='14.2.0' and cp.cuda.runtime.getDeviceCount()==1
        cp.cuda.Device(0).use();cp.cuda.runtime.free(0)
        inputs=[];groups=[]
        for case in binding['original_cases']:
            prefix='jax/device/'+case+'/';meta=json.loads(prior[prefix+'result.json'])
            with np.load(io.BytesIO(prior[prefix+'result.npz']),allow_pickle=False) as store:
                row={key:store[key].copy() for key in ('input.phase_cells','input.parameters','context.components')}
            for key,value in row.items():
                desc=meta['arrays'][key]
                assert (value.dtype.str,list(value.shape),sha(value.tobytes()))==(desc['dtype'],desc['shape'],desc['c_order_sha256'])
            assert row['input.phase_cells'].shape==(1,4,6) and row['input.parameters'].shape==(1,12) and row['context.components'].shape==(1,4,9)
            inputs.append(row);groups.append(dict(kind='original-default-JAX',case=case))
        # Boundary words are literal IEEE encodings; no host arithmetic/reference.
        prototype=inputs[0]
        for boundary in binding['boundary_cases']:
            row={key:value.copy() for key,value in prototype.items()}
            words=b''.join(struct.pack('<I',int(word,16)) for word in boundary['primitive_words'])
            typed=np.frombuffer(words,dtype='<f4')
            row['input.phase_cells'][:,:,0:3]=typed[0:3]
            row['input.parameters'][:,0]=typed[3]
            # Boundary groups have no original JAX observation; the GPU marks
            # comparison flags2, never a claimed match to synthetic zero data.
            row['context.components']=np.zeros_like(prototype['context.components'])
            inputs.append(row);groups.append(dict(kind='primitive-boundary',**boundary))
        host={key:np.concatenate([row[key] for row in inputs],axis=0) for key in prototype}
        assert all(v.dtype==np.float32 for v in host.values());count=len(inputs)
        assert count==10 and 4*count<=128
        dev={key:cp.asarray(value) for key,value in host.items()}
        options=('--std=c++14','--fmad=false','--prec-div=true','--prec-sqrt=true','--ftz=false',
            '-arch=sm_'+str(cp.cuda.Device(0).compute_capability),'--device-as-default-execution-space')
        codes={'candidate':(HERE/'geometry_default_pcd.cuh').read_bytes()+b'\n'+(HERE/'geometry_default_pcd_probe.cu').read_bytes(),
               'RN':(HERE/'rn_geometry_probe.cu').read_bytes()}
        assert sha(codes['RN'])==binding['original_RN_kernel_sha256']
        loaded={};compiled={};compiler=a.output/'compiler';compiler.mkdir()
        for name,code in codes.items():
            program=cc._NVRTCProgram(code.decode(),name=name+'_pcd.cu',method='cubin');cubin,_=program.compile(options)
            (compiler/(name+'-ACTUAL-LOADED.cubin')).write_bytes(cubin)
            module=cf.Module();module.load(cubin);loaded[name]=module;compiled[name]=dict(source_sha256=sha(code),actual_loaded_cubin_sha256=sha(cubin))
        candidate=cp.empty((count,4,9),cp.float32)
        outputs={name:cp.empty(shape,cp.uint32) for name,shape in {
            'input_bits':(count,4,4),'candidate_bits':(count,4,9),'previous_bits':(count,4,9),
            'previous_equal':(count,4,9),'input_valid':(count,4),'output_finite':(count,4),
            'constant_bits':(count,4,4),'constant_equal':(count,4,2)}.items()}
        outputs['group_counts']=cp.zeros((count,4),cp.uint32)
        record['candidate_kernel_attempted']+=1
        loaded['candidate'].get_function('geometry_default_probe')((1,),(128,),tuple(dev[n] for n in ('input.phase_cells','input.parameters','context.components'))+
            (candidate,)+tuple(outputs[n] for n in ('input_bits','candidate_bits','previous_bits','previous_equal','input_valid','output_finite','constant_bits','constant_equal','group_counts'))+(np.int32(count),np.int32(4)))
        cp.cuda.get_current_stream().synchronize();record['candidate_kernel_returned']+=1
        references={name:cp.empty((count,4,9),cp.uint32) for name in ('observed_bits','strict_rn_bits','actual_operand_rn_bits','strict_equal','actual_operand_equal')}
        references['valid_rows']=cp.empty((count,4),cp.uint32);references['group_counts']=cp.zeros((count,3),cp.uint32)
        record['RN_kernel_attempted']+=1
        loaded['RN'].get_function('rn_geometry_probe')((1,),(128,),tuple(dev[n] for n in ('input.phase_cells','input.parameters'))+(candidate,)+
            tuple(references[n] for n in ('observed_bits','strict_rn_bits','actual_operand_rn_bits','strict_equal','actual_operand_equal','valid_rows','group_counts'))+(np.int32(count),))
        cp.cuda.get_current_stream().synchronize();record['RN_kernel_returned']+=1
        # All tests/classification are GPU-side. RN equality is descriptive.
        context=bool(cp.all(outputs['previous_equal'][:4]==1))
        inputs_valid=bool(cp.all(outputs['input_valid']==1));constants_valid=bool(cp.all(outputs['constant_equal']==1))
        finite=bool(cp.all(outputs['output_finite']==1));rn_domain=bool(cp.all(references['valid_rows']==1))
        flat={**{key:cp.asnumpy(value) for key,value in dev.items()},'candidate.components':cp.asnumpy(candidate),
              **{'candidate.'+key:cp.asnumpy(value) for key,value in outputs.items()},**{'RN.'+key:cp.asnumpy(value) for key,value in references.items()}}
        assert all(sha(flat[key].tobytes())==sha(value.tobytes()) for key,value in host.items())
        np.savez(a.output/'result.npz',**flat)
        apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True)
        own=[line.split(',')[1].strip() for line in apps.splitlines() if line.split(',')[0].strip()==str(os.getpid())]
        assert own and set(own)=={GPU}
        flags={**{'candidate.'+key:cp.asnumpy(value).tolist() for key,value in outputs.items()},**{'RN.'+key:cp.asnumpy(value).tolist() for key,value in references.items()}}
        meta=dict(npz_sha256=sha((a.output/'result.npz').read_bytes()),groups=groups,component_fields=binding['component_fields'],
            arrays={key:dict(dtype=value.dtype.str,shape=list(value.shape),c_order_sha256=sha(value.tobytes())) for key,value in flat.items()},
            uint32_output_encoding=flags,all_flags_and_counts_computed_inside_GPU=True,
            original_context_reproduced=context,all_primitive_inputs_valid=inputs_valid,all_constants_RN_checked=constants_valid,
            all_candidate_outputs_finite=finite,all_RN_recorded_domains_valid=rn_domain,own_process_GPU_UUIDs=own,
            previous_equal_encoding=dict(unavailable=2,equal=1,different=0),actual_compile_options=options,compiled=compiled,
            group_count_columns=['default_JAX_original_mismatches','invalid_primitive_input_rows','nonfinite_candidate_output_rows','constant_check_failures'])
        save(a.output/'result.json',meta)
        record.update(capture_completed=context and inputs_valid and constants_valid and finite and rn_domain,
            original_context_reproduced=context,all_primitive_inputs_valid=inputs_valid,all_constants_RN_checked=constants_valid,
            all_candidate_outputs_finite=finite,all_RN_recorded_domains_valid=rn_domain,
            candidate_group_counts_GPU=flags['candidate.group_counts'],RN_group_counts_GPU=flags['RN.group_counts'],
            actual_compile_options=options,compiled=compiled,source_patch_production_credit=False,
            scope='Only isolated float32 geometry hypothesis. Original RN differences are descriptive; no integration/physical gate credit. Fraction candidate analysis requires separately authorized EHPC followup.')
    except BaseException:
        record['error']=traceback.format_exc();(a.output/'failure.txt').write_text(record['error'])
    finally:
        try:
            assert controls()==control and source_identity(a.source,binding)==identity
            bound_evidence(a.evidence,binding);record['source_controls_prior_unchanged']=True
        except BaseException:
            record['identity_error']=traceback.format_exc();record['capture_completed']=False
        record['seconds']=time.monotonic()-started;save(a.output/'capture-receipt.json',record)
    return 0 if record['capture_completed'] else 1

if __name__=='__main__':raise SystemExit(main())

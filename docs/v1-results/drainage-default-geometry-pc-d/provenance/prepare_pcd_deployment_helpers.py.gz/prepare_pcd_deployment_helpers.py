"""Mechanically bind prior lifecycle/collection helpers to frozen PC-d."""
from pathlib import Path

base=Path(__file__).resolve().parent
changes={
    'drainage-rn-primitives-pb-z':'drainage-default-geometry-pc-d',
    'drainage-pb-s-pbz-20261026':'drainage-pc-d-20261026',
    'launch_hardware_rn_pbz.py':'launch_geometry_default_pcd.py',
    '3b35b289ddfffe7fb24671d0cb126626de8f0648905fb5823d0dce207f248293':'82f9e26f5868780319c608701a9fee2d5ced96288b9a184777e1f47c9257c7d8',
}
for old,new in [('deploy_hardware_rn_pbz.py','deploy_geometry_default_pcd.py'),('read_hardware_rn_pbz.py','read_geometry_default_pcd.py'),('collect_hardware_rn_pbz.py','collect_geometry_default_pcd.py')]:
    target=base/new;assert not target.exists();text=(base/old).read_text()
    for before,after in changes.items():text=text.replace(before,after)
    if old.startswith('deploy_'):
        text=text.replace("assert prelaunch['nvidia_smi_exit']==0 and prelaunch['live_task_python']==[]", "assert prelaunch['nvidia_smi_exit']==0 and prelaunch['live_task_python']==[]\nassert prelaunch['QN_parents']==[0] and not any(prelaunch['QN_PID_exists'].values())\nassert not prelaunch['own_GPU_processes'] and prelaunch['target_GPU_memory_free_MiB']>8192 and prelaunch['host_available_KiB']>32*1024*1024")
    target.write_text(text,encoding='utf-8',newline='\n')
text=(base/'run_pcb_reader.py').read_text()
text=text.replace("'read_gpu_project_ownership_pcb.py'","'read_gpu_project_ownership_pcd.py'").replace("'read_jax_division_pcb.py'","'read_geometry_default_pcd.py'")
text=text.replace('jax-division-probe-pc-b','drainage-default-geometry-pc-d')
target=base/'run_pcd_reader.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')

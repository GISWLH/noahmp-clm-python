"""Freeze proposal-only B geometry code; no model/NumPy/GPU/remote execution."""
from pathlib import Path
import ast
import difflib
import gzip
import io
import json
import tarfile
import urllib.request
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
LABEL='drainage-default-geometry-pc-d'
PREP=BASE/(LABEL+'-preparation');EXEC=BASE/(LABEL+'-execution')
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def main():
    assert not PREP.exists() and not EXEC.exists();PREP.mkdir();EXEC.mkdir()
    oldstage=files((BASE/'jax-division-probe-pc-b-stage.tar.gz').read_bytes())
    source=oldstage['source.tar.gz'];prior=oldstage['prior-device.tar.gz'];sourcefiles=files(source)
    assert sha(source)=='da270dcfac9517b2ed73cbe0fa48e26c2a2dd570b0634cc88f22a7ef9d30e30d'
    assert sha(prior)=='f5221539e4ab7371171b1b67e4b488317e5157d62ddec002dd3d6792e0b6c9b9'
    binding=json.loads((BASE/'drainage-rn-primitives-pb-z-preparation/BINDINGS.json').read_bytes())
    binding.update(prepared_only=True,launched=False,numerical_executed=False,
        original_cases=[row['case'] for row in binding['groups'] if row['backend']=='jax'],
        original_RN_kernel_sha256='a2ce278f8c2ab9e208c64a1ecbb8424b7f8e1c38ab94c1c2a456090be37a19f1',
        planned_candidate_kernels=1,planned_hardware_reference_kernels=1,layer_rows=40,
        original_default_JAX_groups=4,boundary_groups=6,
        boundary_cases=[
            dict(case='zero-stores',primitive_words=['0x00000000','0x00000000','0x3e800000','0x3f000000']),
            dict(case='small-normal-store-subnormal-volume',primitive_words=['0x03800000','0x03800000','0x3f800000','0x3f000000']),
            dict(case='small-normal-thickness',primitive_words=['0x03800000','0x00000000','0x03800000','0x3f000000']),
            dict(case='minimum-subnormal-store',primitive_words=['0x00000001','0x00000000','0x3e800000','0x3f000000']),
            dict(case='subnormal-saturation-denominator',primitive_words=['0x03800000','0x00000000','0x00800000','0x3f000000']),
            dict(case='large-normal-geometry',primitive_words=['0x71800000','0x00000000','0x71800000','0x3f000000']),
        ],
        boundary_primitive_order=['liquid_mass','ice_mass','thickness','porosity'],
        boundary_scope='Finite nonnegative stores, positive finite thickness/porosity. Primitive geometry domain only, not claimed complete physical columns.',
        source_patch_applied=False,default_JAX_flags_changed=False,CUDA64_proposal_branch='Exact original arithmetic remains in sizeof(T)!=sizeof(float) else branch',
        no_new_divider_algorithm=True,no_FP64_introduced=True,no_gate_relaxation=True)
    (PREP/'BINDINGS.json').write_bytes(encode(binding))
    for name in ('capture_geometry_default_pcd.py','geometry_default_pcd.cuh','geometry_default_pcd_probe.cu'):
        raw=(BASE/name).read_bytes();assert b'\r' not in raw
        if name.endswith('.py'):ast.parse(raw)
        (PREP/name).write_bytes(raw)
    contract=(BASE/'drainage-rn-primitives-pb-z-preparation/contract_rn.py').read_bytes()
    (PREP/'contract_pcd.py').write_bytes(contract)
    rn=(BASE/'drainage-rn-primitives-pb-z-preparation/rn_geometry_probe.cu').read_bytes()
    assert sha(rn)==binding['original_RN_kernel_sha256'];(PREP/'rn_geometry_probe.cu').write_bytes(rn)
    # Actual previous default-JAX process artifacts, never labeled new loaded code.
    gpu=files((BASE/'jax-division-probe-pc-b-gpu-closed/gpu-result.tar.gz').read_bytes())
    receipt=json.loads(gpu['baseline/device/capture-receipt.json'])
    assert receipt['actual_XLA_FLAGS'] is None and receipt['all_PBv_payloads_reproduced'] and receipt['context_reproduction_passed']
    assert receipt['X64_before'] is receipt['X64_after'] is False
    mapping={}
    for leaf in ('original-optimized-hlo.txt','context-optimized-hlo.txt','context-lowered.mlir'):
        raw=gpu['baseline/device/compiler/'+leaf];(PREP/('ACTUAL-PCb-BASELINE-'+leaf)).write_bytes(raw)
        mapping[leaf]=dict(sha256=sha(raw),bytes=len(raw),constant_lowering_lines=[dict(line=i,text=line) for i,line in enumerate(raw.decode().splitlines(),1) if 'constant(0.001)' in line or 'constant(0.00109051249)' in line])
    (PREP/'CURRENT_DEFAULT_JAX_HLO_MAP.json').write_bytes(encode(dict(actual_capture='PC-b baseline',actual_GPU_result_sha256=sha((BASE/'jax-division-probe-pc-b-gpu-closed/gpu-result.tar.gz').read_bytes()),
        actual_default_XLA_FLAGS=None,X64_before=False,X64_after=False,JAX_version=receipt['JAX_version'],CuPy_version=receipt['CuPy_version'],
        old_PBv_all29_and9_payloads_reproduced=True,HLO_files=mapping,
        correspondences=dict(liquid_divided_1000='f32 reciprocal literal0.001 then multiply',ice_divided_917='f32 reciprocal literal0.00109051249 then multiply',
            saturation='HLO variable divide of recorded numerator/denominator',ice_quotient='HLO variable divide of recorded ice/denominator',
            LLVM_default='Pinned OpenXLA emits -nvptx-prec-divf32=1; pinned LLVM Full pattern emits div.full$ftz.f32'),
        limitation='Actual prior HLO, not newly executed JAX or loaded JAX PTX. FTZ suffix and exact JAX machine-code expansion are not independently established.')))
    # Proposed source patch is review-only; immutable source tree is never patched.
    path='src/noahmp_clm/gpu/cuda/clm_drainage_primitives_kernel.cu';before=sourcefiles[path]
    needle=b'    sat[k]=(c[6*k]/T(1000)+c[6*k+1]/T(917))/(c[6*k+2]*p[0]);\n    ice[k]=mn(T(1),c[6*k+1]/((T(917)*c[6*k+2])*p[0]));\n'
    assert before.count(needle)==1
    helper=(PREP/'geometry_default_pcd.cuh').read_bytes()
    replacement=b'    if(sizeof(T)==sizeof(float)){\n      float geometry[9];\n      geometry_default_f32(float(c[6*k]),float(c[6*k+1]),float(c[6*k+2]),float(p[0]),geometry);\n      sat[k]=T(geometry[4]);ice[k]=T(geometry[8]);\n    }else{\n'+needle+b'    }\n'
    proposed=helper+b'\n'+before.replace(needle,replacement)
    (PREP/'PROPOSAL-ONLY-kernel.cu.txt').write_bytes(proposed)
    (PREP/'candidate.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),proposed.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path)),encoding='utf-8',newline='\n')
    (PREP/'SOURCE_PROPOSAL_GUARD.json').write_bytes(encode(dict(original_source_archive_sha256=sha(source),source_manifest_sha256=binding['source_manifest_sha256'],
        original_kernel_sha256=sha(before),proposed_kernel_sha256=sha(proposed),helper_sha256=sha(helper),proposed_files_changed=[path],other595_source_files_unchanged=True,
        original_double_statements_preserved_in_else=needle in proposed,source_patch_applied=False,proposed_complete_kernel_compiled_by_worker=False,
        actual_worker_compiles_only=['geometry_default_pcd.cuh + geometry_default_pcd_probe.cu','byte-identical PB-z rn_geometry_probe.cu'],
        original_integer_P0_1e6_and_hard_ledgers_unchanged=True)))
    url='https://raw.githubusercontent.com/llvm/llvm-project/7024b9e1b423b3c3c6ac76ab6a73cb2c9e4ef842/llvm/lib/Target/NVPTX/NVPTXInstrInfo.td'
    with urllib.request.urlopen(url,timeout=30) as response:llvm=response.read()
    (PREP/'PINNED-LLVM-NVPTXInstrInfo.td.txt').write_bytes(llvm)
    (PREP/'PTX_SEMANTICS.json').write_bytes(encode(dict(primary_PTX='https://docs.nvidia.com/cuda/archive/12.4.0/parallel-thread-execution/index.html#floating-point-instructions-div',
        pinned_LLVM_url=url,pinned_LLVM_sha256=sha(llvm),full_pattern='Full f32 division -> div.full$ftz.f32; reciprocal1/x may select rcp.approx',
        div_full='Full-range approximate division, maximum2ULP, not IEEE RN and no rounding modifier.',
        FTZ='Subnormal behavior is a required separate diagnostic. Do not infer production JAX/CuPy suffixes from this standalone ftz=false worker.',
        boundary_outputs='A legal primitive input producing nonfinite or invalid candidate outputs is retained, makes capture exit1, and prevents promotion; no silent RN fallback.',
        scientific_scope='2ULP per primitive is not a proof of adaptive trajectory precision. RN differences are descriptive, not a new physical acceptance standard.')))
    (PREP/'README.md').write_text('''# PC-d B geometry probe — prepared only

One isolated CUDA1 worker tests the four actual default-JAX PB-v input groups and six explicit binary32 primitive-domain boundaries. No JAX process is started, no production file is patched, no CUDA64 arithmetic is changed, no FP64 or new division algorithm is introduced. The reviewed proposal-only patch is limited to a float32 geometry branch; original double expressions remain verbatim in its else branch. The worker compiles only the small helper/probe and unchanged PB-z hardware-RN kernel, never the complete proposed physical kernel.

The helper follows default JAX's actual HLO grouping: liquid times float32 literal0.001, ice times0.00109051249, explicit f32 add/multiplications, variable div.full.f32, then the original min(1,q) conditional order. Actual PC-b baseline optimized HLO/MLIR, process flags/versions and byte reproduction of prior29+9 are preserved. Source-supported LLVM Full lowering is recorded separately from actual loaded JAX PTX, which has not been captured. Inline PTX is an existing documented instruction, not a new software divider. No __fdividef equivalence is assumed.

One candidate kernel writes every primitive input/result bit, original-default-JAX equality flags and per-group counts on GPU. A second, byte-identical PB-z RN kernel records strict-chain and own-operand RN references/flags on the candidate results. Host NumPy only loads, copies, stacks and encodes packets; no host arithmetic, reference calculation, numerical comparison or mismatch counting. The two actual HLO reciprocal literals are independently bit-checked against hardware RN(1/rho) inside the candidate kernel. Missing JAX observations for boundaries are explicitly flag2, not synthetic equal flags. The original closed EHPC1845 Fraction result is retained verbatim; new candidate exact-Fraction analysis requires a separate authorized EHPC stage after actual GPU capture.

All four original9-field outputs must exactly reproduce the recorded default-JAX context for attribution. This diagnostic reproduction requirement is not a bitwise-RN science specification. RN mismatches alone do not cause failure. Legal primitive inputs, finite candidate outputs, nonzero recorded denominators and reciprocal-literal guards are explicit delivery checks; any failure is saved and returns1. Boundaries include zero stores, tiny normal stores/thickness, minimum subnormal stores, a subnormal saturation denominator and large finite geometry. They are legal for the stated primitive domain, not asserted complete physical columns. div.full's documented2ULP scope, non-RN behavior and subnormal/FTZ limits remain visible; no workaround or automatic fallback is added if a boundary fails.

Direct NVRTC uses std14/fmadfalse/prec-divtrue/prec-sqrttrue/ftzfalse and saves the actual returned/loaded CUBIN. This deliberately bypasses CuPy's cache helper automatic ftztrue, as in PB-z. It is a diagnostic compilation contract, not proof of the proposed complete module under its original production wrapper. Original CUDA wrapper flags, JAX defaults, NumPy64/32 references,1e-6/integer comparisons,P0 and hard ledgers remain unchanged and require subsequent complete module/option/adaptive/annual regression before any production change.

Mechanical PB-z lifecycle: one child,900s actual wait/kill-wait,8GiB GPU/32GiB host startup gates,one thread,three private caches,physical CUDA1 UUID. Prepared only: root must read code/stage and authorize any launch; QN currently owns the UUID. No upload, device/model execution or automatic retry occurs in preparation.
''',encoding='utf-8',newline='\n')
    (PREP/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file()}))
    old=BASE/'drainage-rn-primitives-pb-z-execution';diff=[]
    names={'run_hardware_rn_parent_pbz.py':'run_geometry_default_parent_pcd.py','control_hardware_rn_pbz.py':'control_geometry_default_pcd.py','launch_hardware_rn_pbz.py':'launch_geometry_default_pcd.py'}
    for oldname,newname in names.items():
        initial=(old/oldname).read_text();updated=initial
        for before_text,after_text in [('contract_rn','contract_pcd'),('capture_hardware_rn.py','capture_geometry_default_pcd.py'),('/tmp/drainage-pb-s-pbz-','/tmp/drainage-pc-d-'),*names.items()]:updated=updated.replace(before_text,after_text)
        if oldname.startswith('run_'):
            updated=updated.replace("env.pop('LD_LIBRARY_PATH',None)","env.pop('LD_LIBRARY_PATH',None);env.pop('XLA_FLAGS',None)")
            updated=updated.replace("JAX_ENABLE_X64='true'","JAX_ENABLE_X64='false'")
        ast.parse(updated);(EXEC/newname).write_text(updated,encoding='utf-8',newline='\n')
        diff.extend(difflib.unified_diff(initial.splitlines(True),updated.splitlines(True),fromfile='PB-z/'+oldname,tofile='PC-d/'+newname))
    policy=dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),source_archive_sha256=sha(source),source_manifest_sha256=binding['source_manifest_sha256'],
        evidence_archive_sha256=sha(prior),root='/home/lhwang/work/noahmp-v1/clm-drainage-default-geometry-pc-d',temporary='/tmp/drainage-pc-d-20261026',gpu_uuid=binding.get('GPU_UUID','GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'),
        backend_order=['cuda'],maximum_worker_seconds=900,single_launch=True,automatic_retry=False,root_review_pending=True,prepared_only=True,source_modified=False,scientific_acceptance=False,
        Fraction_actual1845_result_sha256='0863648515d5ea0e2edb72ce1405bad327d2b3643b9cd6f1c79be4909f67a70e')
    (EXEC/'EXECUTION_BINDINGS.json').write_bytes(encode(policy));(EXEC/'PBZ_TO_PCD.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
    (EXEC/'README.md').write_text('Prepared-only mechanical PB-z single-child900s lifecycle,default flags/private paths. No launch authorized, no deployment; original resource/UUID/thread/wait gates retained.\n',encoding='utf-8',newline='\n')
    (EXEC/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file()}))
    payload={prefix+'/'+p.name:p.read_bytes() for root,prefix in ((PREP,'preparation'),(EXEC,'execution')) for p in root.iterdir() if p.is_file()}
    fraction=(BASE/'drainage-geometry-pb-v-analysis-result/result.tar.gz').read_bytes();assert sha(fraction)==policy['Fraction_actual1845_result_sha256']
    payload.update({'source.tar.gz':source,'prior-device.tar.gz':prior,'prior-Fraction1845-result.tar.gz':fraction})
    payload['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(payload.items())})
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,raw in sorted(payload.items()):
                m=tarfile.TarInfo(name);m.size=len(raw);m.mode=0o644;tar.addfile(m,io.BytesIO(raw))
    assert files(target.read_bytes())==payload
    record=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),bytes=target.stat().st_size,stage_files=len(payload),
        preparation_manifest_sha256=policy['preparation_manifest_sha256'],execution_manifest_sha256=sha(payload['execution/CONTROLS_SHA256.json']),
        prepared_only=True,launched=False,numerical_executed=False,production_source_modified=False,original_source596_unchanged=True,original4_groups=True,boundary_groups=6)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(record));print(json.dumps(record))

if __name__=='__main__':main()

"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'drainage-default-geometry-pc-d-stage.tar.gz'
expected='82f9e26f5868780319c608701a9fee2d5ced96288b9a184777e1f47c9257c7d8'
assert sha(stage.read_bytes())==expected
prelaunch_path=BASE/'drainage-default-geometry-pc-d-prelaunchAfterSharedAuthorization.json'
prelaunch=json.loads(prelaunch_path.read_text(encoding='utf-8-sig'))
assert prelaunch['nvidia_smi_exit']==0 and prelaunch['live_task_python']==[]
assert prelaunch['QN_parents']==[0] and not any(prelaunch['QN_PID_exists'].values())
# Root explicitly authorized project-family exclusivity on this shared account.
# Unknown/external training is recorded and never controlled; the original
# stricter all-UID-zero observation is retained as a separate failed gate.
assert prelaunch['target_GPU_memory_free_MiB']>8192 and prelaunch['host_available_KiB']>32*1024*1024
target=BASE/'drainage-default-geometry-pc-d-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'drainage-default-geometry-pc-d-execution/launch_geometry_default_pcd.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/clm-drainage-default-geometry-pc-d && test ! -e /tmp/drainage-pc-d-20261026 && test ! -e /tmp/noahmp-drainage-default-geometry-pc-d-stage.tar.gz && test ! -e /tmp/launch_geometry_default_pcd.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-drainage-default-geometry-pc-d-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_geometry_default_pcd.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_geometry_default_pcd.py --stage /tmp/noahmp-drainage-default-geometry-pc-d-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None,
    prelaunch_receipt_sha256=sha(prelaunch_path.read_bytes()),project_family_exclusivity=True,
    external_training_shared=True,performance_measurement=False,
    external_GPU_processes=prelaunch['own_GPU_processes']+prelaunch['other_user_GPU_processes_untouched'])
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('drainage-default-geometry-pc-d-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('drainage-default-geometry-pc-d-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

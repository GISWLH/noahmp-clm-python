"""Readonly final actual controller/parent/worker handles, no GPU calls."""
from pathlib import Path
import json

root=Path('/home/lhwang/work/noahmp-v1/clm-drainage-default-geometry-pc-d')
controller=json.loads((root/'controller-receipt.json').read_bytes())
launch=json.loads((root/'launch.json').read_bytes())
row=controller['actual_parents'][0];worker=row['parent_receipt']
assert controller['completed'] and controller['stage_unchanged'] and row['actual_parent_returncode']==0
assert worker['completed'] and worker['returncode']==0 and worker['error'] is None
parent_pid=int(worker['proc_stat_at_launch'].rpartition(') ')[2].split()[1])
pids=dict(controller=launch['controller_pid'],parent=parent_pid,worker=worker['pid'])
print(json.dumps(dict(actual_parent_exit=0,actual_worker_exit=0,controller_completed=True,stage_unchanged=True,
    timed_out=False,pids=pids,proc_exists={name:(Path('/proc')/str(pid)).exists() for name,pid in pids.items()},
    actual_controller_OS_exit_unknown=True,external_training_untouched=True)))

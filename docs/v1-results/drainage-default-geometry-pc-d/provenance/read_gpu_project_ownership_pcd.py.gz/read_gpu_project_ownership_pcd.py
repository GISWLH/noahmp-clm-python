"""Read-only current QN handles and own GPU processes; ignore other users."""
from pathlib import Path
import json
import os
import subprocess
import time

gpu='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
rows=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit() or int(p.name)==os.getpid():continue
    try:
        if p.stat().st_uid!=os.getuid():continue
        args=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if args and 'python' in args.split()[0] and ('noahmp' in args or 'drainage-pb' in args or 'drainage-pc' in args):
            rows.append(dict(pid=int(p.name),cmdline=args,stat=(p/'stat').read_text()))
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
qn=json.loads(Path('/home/lhwang/work/noahmp-v1/nq-most-cache-bridge-qn/controller-receipt.json').read_bytes())
assert qn['completed'] and qn['stage_unchanged']
parents=[r['actual_parent_returncode'] for r in qn['actual_parents']]
pids={str(pid):(Path('/proc')/str(pid)).exists() for pid in (886777,886778,886779)}
r=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,memory.free','--format=csv,noheader'],capture_output=True,text=True)
assert r.returncode==0
apps=subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],capture_output=True,text=True)
assert apps.returncode==0
owned=[];other=[]
for line in apps.stdout.splitlines():
    pid,uuid=[v.strip() for v in line.split(',')]
    try:uid=(Path('/proc')/pid).stat().st_uid
    except FileNotFoundError:continue
    (owned if uid==os.getuid() else other).append(dict(pid=int(pid),gpu_uuid=uuid,uid=uid))
free=int(subprocess.check_output(['nvidia-smi','--id='+gpu,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))
print(json.dumps(dict(observed_unix=time.time(),uid=os.getuid(),live_task_python=rows,QN_parents=parents,QN_PID_exists=pids,
    own_GPU_processes=owned,other_user_GPU_processes_untouched=other,nvidia_smi_exit=r.returncode,stdout=r.stdout,stderr=r.stderr,
    target_GPU_memory_free_MiB=free,host_available_KiB=available,gpu_uuid=gpu)))

"""Close one isolated PC-d attempt; label GPU bits/flags without numeric decode."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,packet,sha

BASE=Path(__file__).resolve().parent;LABEL='drainage-default-geometry-pc-d'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='82f9e26f5868780319c608701a9fee2d5ced96288b9a184777e1f47c9257c7d8'
    index=json.loads(stage['stage-inventory.json']);assert len(stage)==28 and all(sha(stage[n])==h for n,h in index.items())
    raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes();gpu=files(raw)
    assert sha(raw)=='8cb523d79eeb201096f5256b977e35ebfb7d51cc6c4686a728831400a7f30efc' and len(gpu)==14
    controller=json.loads(gpu['controller/controller-receipt.json']);parent=json.loads(gpu['cuda/device-parent-receipt.json'])
    capture=json.loads(gpu['cuda/device/capture-receipt.json']);meta=json.loads(gpu['cuda/device/result.json'])
    assert controller['completed'] and controller['stage_unchanged'] and [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0]
    assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
    assert capture['capture_completed'] and capture['source_controls_prior_unchanged'] and capture['original_context_reproduced']
    assert all(capture[k] for k in ('all_primitive_inputs_valid','all_constants_RN_checked','all_candidate_outputs_finite','all_RN_recorded_domains_valid'))
    assert capture['candidate_kernel_attempted']==capture['candidate_kernel_returned']==capture['RN_kernel_attempted']==capture['RN_kernel_returned']==1
    assert capture['CPU_physical_reference_calls']==capture['model_calls']==capture['phase_calls']==0
    assert not capture['JAX_imported'] and not capture['default_JAX_flags_changed'] and not capture['production_source_patch_applied'] and not capture['FP64_introduced']
    assert capture['scientific_acceptance'] is False and capture['source_patch_production_credit'] is False
    arrays=packet(gpu['cuda/device/result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
    for name in ('candidate','RN'):assert sha(gpu['cuda/device/compiler/'+name+'-ACTUAL-LOADED.cubin'])==meta['compiled'][name]['actual_loaded_cubin_sha256']
    assert meta['compiled']['candidate']['source_sha256']==sha(stage['preparation/geometry_default_pcd.cuh']+b'\n'+stage['preparation/geometry_default_pcd_probe.cu'])
    assert meta['compiled']['RN']['source_sha256']=='a2ce278f8c2ab9e208c64a1ecbb8424b7f8e1c38ab94c1c2a456090be37a19f1'
    release=json.loads((BASE/(LABEL+'-final-release.json')).read_bytes());assert not any(release['proc_exists'].values())
    assert release['actual_parent_exit']==release['actual_worker_exit']==0
    after=json.loads((BASE/(LABEL+'-prelaunchAfterRelease.json')).read_bytes());assert not after['live_task_python']
    flags=meta['uint32_output_encoding'];groups=[]
    for group,spec in enumerate(meta['groups']):
        groups.append(dict(specification=spec,candidate_GPU_group_counts=flags['candidate.group_counts'][group],
            RN_GPU_group_counts=flags['RN.group_counts'][group],
            own_operand_non_RN_fields=[dict(layer_zero_based=layer,fields=[meta['component_fields'][i] for i,equal in enumerate(words) if equal==0]) for layer,words in enumerate(flags['RN.actual_operand_equal'][group])],
            default_JAX_geometry_observation_available=group<4))
    readout=dict(actual_worker_exit=0,actual_parent_exit=0,actual_controller_OS_exit=None,controller_completed=True,stage_unchanged=True,
        controller_seconds_shared_not_performance=controller['seconds'],parent_seconds_shared_not_performance=parent['seconds'],
        source_files=596,source_manifest_sha256=capture['source_manifest_sha256'],production_source_patch_applied=False,
        original4_default_JAX_geometry_reproduced=True,boundary_groups=6,all10_groups_primitive_domains_finite=True,reciprocal_literal_RN_guards_passed=True,
        candidate_GPU_group_count_columns=meta['group_count_columns'],RN_GPU_group_count_columns=['strict_chain_mismatches','actual_operand_mismatches','invalid_rows'],
        groups=groups,verified_opaque_arrays=arrays,actual_compile_options=meta['actual_compile_options'],compiled=meta['compiled'],
        actual_explicit_candidate_kernels=1,actual_explicit_RN_kernels=1,new_JAX_processes=0,physical_forward_calls=0,phase_calls=0,
        all_bits_flags_counts_computed_inside_GPU=True,complete_raw_metadata_retained=True,actual_release=release,
        actual_GPU_result_sha256=sha(raw),candidate_Fraction_audit_executed=False,scientific_acceptance=False,
        scope='Independent geometry only. Four actual original default-JAX9-field contexts reproduce; six stated primitive-boundary inputs are finite on this actual standalone ftz=false compilation. Non-RN candidate differences remain descriptive. No complete CUDA wrapper/module/CUDA64/annual/1e-6/integer/P0/hard-ledger acceptance credit; source proposal not applied. External training shared, all preflight failures retained, no performance measurement.')
    items={'executed-stage.tar.gz':stage_raw,'original-GPU-result.tar.gz':raw,'readout.json':encode(readout),
        'original-result-inventory.json':encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(gpu.items())}),
        'original-GPU-output-metadata.json':gpu['cuda/device/result.json'],
        'shared-scheduling-scope.json':encode(dict(source='Parent explicit authorization after identifying other projects sharing uid1002',
            replaced_conservative_gate='all same-UID GPU processes absent',actual_gate='this noahmp task family absent; QN3PID gone; GPUfree>8GiB; hostfree>32GiB',
            scientific_or_numeric_gate_changes=0,external_processes_modified=0,original_stricter_observation_retained=True,performance_measurement=False))}
    for name,payload in stage.items():
        if name.startswith(('preparation/','execution/')):items[name]=payload
    for p in (BASE/(LABEL+'-gpu-closed')).iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-prelaunch',LABEL+'-closed',LABEL+'-final-release'):
        for p in BASE.glob(prefix+'*'):
            if p.is_file() and not p.name.endswith('.tar.gz'):items['deployment/'+p.name]=p.read_bytes()
    for name in (LABEL+'-stage-package.json',LABEL+'-gpu-deployment.json','prepare_geometry_default_pcd.py',
        'prepare_pcd_deployment_helpers.py','deploy_geometry_default_pcd.py','read_geometry_default_pcd.py','collect_geometry_default_pcd.py',
        'read_gpu_project_ownership_pcd.py','run_pcd_reader.py','read_pcd_final_release.py','run_pcd_final_release.py',Path(__file__).name):items['provenance/'+name]=(BASE/name).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name,payload in sorted(items.items()):
                member=tarfile.TarInfo(name);member.size=len(payload);member.mode=0o644;archive.addfile(member,io.BytesIO(payload))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual PC-d isolated CUDA1 worker/parent0 and closed3PIDs; original4×9 default-JAX bits reproduced,6 primitive boundaries finite. No complete module/production/precision/physical acceptance credit.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout));(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

if __name__=='__main__':main()

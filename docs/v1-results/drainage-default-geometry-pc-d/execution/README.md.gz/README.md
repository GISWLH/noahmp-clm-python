Prepared-only mechanical PB-z single-child900s lifecycle,default flags/private paths. No launch authorized, no deployment; original resource/UUID/thread/wait gates retained.

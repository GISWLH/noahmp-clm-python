from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'canopy-wet-final-ba';assert not r.exists();r.mkdir();controls={}
for name in ['run_canopy_wet_final_ba.py','canopy_wet_final_ba.pbs','generate_wet_references_bb.py','clm-canopy-wet-final-az-package.json']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/('package.json' if name.endswith('package.json') else name)).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'canopy_wet_final_ba.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

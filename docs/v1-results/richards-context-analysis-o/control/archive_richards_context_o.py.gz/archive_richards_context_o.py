from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-context-analysis-o';assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'analysis.json').read_text());assert d['pbs_job']=='353.manager' and d['node'].startswith('compute');a=b/'richards-context-analysis-o-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['dispatch_richards_context_analysis_o.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

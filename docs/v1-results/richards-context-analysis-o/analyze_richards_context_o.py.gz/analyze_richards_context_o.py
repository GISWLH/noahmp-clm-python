from pathlib import Path
import hashlib,io,json,os,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-context-analysis-o';sha=lambda raw:hashlib.sha256(raw).hexdigest();start=time.monotonic()
def packet(name,expected,member):
    a=b/name;assert sha(a.read_bytes())==expected
    with tarfile.open(a) as t:
        raw=t.extractfile(member).read()
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:return dict(z)
flow=packet('richards-current-flow-n-evidence.tar.gz','d4803adeb50ed89c5a431d0290752ca0474aec3520ee406bb525621895758016','flow-and-systems.npz')
first={};rows=[]
for i in range(195):
    differences={}
    for key in ['old','guess','dt','raw','system']:
        c,j=flow['cuda/'+str(i)+'/'+key],flow['jax/'+str(i)+'/'+key]
        if c.dtype!=j.dtype or c.tobytes()!=j.tobytes():
            delta=abs(c.astype(float)-j.astype(float));where=int(delta.argmax());row=dict(maximum_absolute=float(delta.max()),flat_index=where,cuda=float(c.ravel()[where]),jax=float(j.ravel()[where]));differences[key]=row;first.setdefault(key,dict(call=i,**row))
    if i<12:rows.append(dict(call=i,dt=float(flow['cuda/'+str(i)+'/dt']),differences=differences))
last={}
for k in flow:
    if k.startswith('cuda/final/'):
        name=k.split('cuda/final/')[1];c,j=flow[k],flow['jax/final/'+name];delta=abs(c.astype(float)-j.astype(float));last[name]=dict(maximum_absolute=float(delta.max(initial=0.)),original_raw1e6_pass=bool(np.allclose(c,j,rtol=1e-6,atol=1e-6)),cuda=c.tolist(),jax=j.tolist())
contexts={}
for label in ['l','m']:
    data=packet('richards-context-klm-evidence.tar.gz','14cb0f88494fb4e542222175fa44274ee9a803ecd682053ca0ee92982f214bf2','richards-context-'+label+'/context.npz');records=[]
    for i in [0,6,7]:
        c,j=data[str(i)+'/cuda'],data[str(i)+'/jax'];dt=data[str(i)+'/dt'];a=np.float32(np.float32(1000.)*np.float32(dt));wide=np.float32(1000.*float(dt));q=data[str(i)+'/system_q'];reconstructed=np.float32(a*q)
        records.append(dict(call=i,dt=float(dt),physical_f32_coefficient=float(a),weak_f64_then_f32_coefficient=float(wide),cuda_transfer=c[8:11].tolist(),jax_transfer=j[8:11].tolist(),standalone_q=q.tolist(),physical_f32_transfer=reconstructed.tolist(),raw_maximum_difference=float(abs(c.astype(float)-j.astype(float)).max()),raw_same_precision_pass=bool(np.allclose(c,j,rtol=1e-6,atol=1e-6))))
    contexts[label]=records
d=dict(scope='EHPC compute-only exact currentG 195-call trajectory and old543E weak/current563 strong ABI compiler-context analysis. No new model, candidate, accepted step or raw-gate waiver; all final fields and first differences retained.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,first_current_differences=first,first_current_calls=rows,current_final_fields=last,isolated_contexts=contexts,seconds=time.monotonic()-start)
(r/'analysis.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

"""QJ raw source/receipts/opaque return closure only; EHPC analysis still pending."""
import ast
import gzip
import io
import itertools
import json
import math
from pathlib import Path
import tarfile
import zipfile
from package_surface_reference_pt import files,sha,encode
from package_nm_richards_reference_qc import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='nq-transport-trace-qj'
STAGE='e005dcb5ee418db9059a565bdc0da1b8b6b959dbc4ca701abd89a6dbfa4575e3'
RAW='f4fd3ea8a662f2ede58370b2c90cb5011690d87f50392841e7ae4da597f0fded'
def npy_identity(raw):
    assert raw[:6]==b'\x93NUMPY';width=2 if raw[6:8]==b'\x01\x00' else 4;length=int.from_bytes(raw[8:8+width],'little')
    header=ast.literal_eval(raw[8+width:8+width+length].decode());payload=raw[8+width+length:]
    if header['fortran_order']:
        size=int(header['descr'][2:]);shape=header['shape'];assert len(payload)==math.prod(shape)*size;strides=[math.prod(shape[:i]) for i in range(len(shape))];ordered=bytearray()
        for coord in itertools.product(*(range(n) for n in shape)):
            at=sum(k*s for k,s in zip(coord,strides))*size;ordered.extend(payload[at:at+size])
        payload=bytes(ordered)
    return dict(dtype=header['descr'],shape=list(header['shape']),C_payload_sha256=sha(payload),C_payload_bytes=len(payload))
def opaque_arrays(raw,metadata):
    tree=dict(kind='dict',items={n:dict(kind='array',key=n,**d) for n,d in metadata['arrays'].items()})
    return opaque_packet(raw,dict(npz_sha256=metadata['npz_sha256'],array_count=len(metadata['arrays']),tree=tree))[0]
def main():
    stage_raw=(BASE/(LABEL+'-gpu-stage-b.tar.gz')).read_bytes();raw=(BASE/(LABEL+'-gpu-closed/gpu-result.tar.gz')).read_bytes();assert sha(stage_raw)==STAGE and sha(raw)==RAW
    stage=files(stage_raw);gpu=files(raw,directories=True);index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==17 and set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    for folder in ('preparation','execution'):
        for n,h in json.loads(stage[folder+'/CONTROLS_SHA256.json']).items():assert sha(stage[folder+'/'+n])==h
    source=files(stage['source.tar.gz']);manifest=json.loads(source['SOURCE_SHA256.json']);assert len(manifest)==584 and all(sha(source[n])==h for n,h in manifest.items())
    nq=files(stage['nq-evidence.tar.gz']);binding=json.loads(stage['preparation/BINDINGS.json']);original=nq[binding['actual_aggregate0_packet_path']]
    assert sha(stage['nq-evidence.tar.gz'])==binding['original_NQ_archive_sha256'] and sha(original)==binding['actual_aggregate0_packet_sha256']
    controller=json.loads(gpu['controller/controller-receipt.json']);assert controller['completed'] and controller['stage_unchanged'] and controller['error'] is None and controller['actual_controller_OS_returncode'] is None
    assert [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0,0]
    counts={};receipts={};unwrapped={}
    with zipfile.ZipFile(io.BytesIO(original)) as z:gold={n:npy_identity(z.read(n)) for n in z.namelist()}
    for backend in ('cuda','jax'):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json']);assert parent['completed'] and parent['returncode']==0 and parent['error'] is None
        assert gpu[backend+'/device-parent-exit.txt'].strip()==b'0'
        r=json.loads(gpu[backend+'/device/capture-receipt.json']);receipts[backend]=r
        assert r['actual_aggregate_calls']==dict(started=1,returned=1) and r['source584_exact'] and r['controls_exact'] and r['inputs_unchanged']
        assert r['controls_manifest_sha256']==sha(stage['preparation/CONTROLS_SHA256.json']) and r['source_manifest_sha256']==sha(source['SOURCE_SHA256.json'])
        assert r['all126_same_backend_byte_exact'] and not r['observation_limit_reached'] and not r['logging_errors'] and not r['forbidden_attempts']
        assert r['events']==11 and r['raw_array_payload_bytes']==8975 and r['observer_limits']==dict(max_events=100000,max_raw_array_bytes=536870912)
        assert r['extra_phase_or_reference_replays']==r['NumPy_physical_forward_calls']==0
        assert not any(r['actual_original_test_named_alias_presence'].values()) and len(r['disabled_already_imported_CPU_aliases'])==2
        for k,n in [('adapter',1),('phase',4),('profile',3),('redistribute',3)]:assert r['observed_original_call_counts'][k]==dict(entered=n,actual_original_started=n,actual_original_returned=n,actual_original_raised=0)
        assert json.loads(gpu[backend+'/device/original-input-identities-before.json'])==json.loads(gpu[backend+'/device/original-input-identities-after.json'])
        events_raw=gpu[backend+'/device/events.tar'];assert sha(events_raw)==r['events_tar_sha256'];events=files(events_raw)
        assert sha(gpu[backend+'/device/events.jsonl'])==r['events_jsonl_sha256']
        for name,value in events.items():
            unwrapped[backend+'/'+name]=value
            if not name.endswith('.json'):continue
            meta=json.loads(value);stem=name.removesuffix('.json')
            counts[backend+'/'+stem]=opaque_packet(events[stem+'.npz'],dict(npz_sha256=meta['npz_sha256'],array_count=meta['array_count'],tree=meta['tree']))[0]
        final_meta=json.loads(gpu[backend+'/device/complete-final126.json']);final_raw=gpu[backend+'/device/complete-final126.npz'];assert opaque_arrays(final_raw,final_meta)==126
        with zipfile.ZipFile(io.BytesIO(final_raw)) as z:
            actual={n:npy_identity(z.read(n)) for n in z.namelist()}
        assert len(actual)==126 and all(d==gold[backend+'/'+n] for n,d in actual.items())
        counts[backend+'/complete-final126']=126
    verification=dict(passed=True,scope='Raw receipts/source/input bindings and opaque typed payload checks only; no numerical/common-prefix analysis on Windows',GPU_parent_actual_exits=[0,0],detached_controller_OS_exit=None,source584_exact=True,original_aggregate_advances=2,extra_phase_or_reference_replays=0,NumPy_physical_calls=0,per_backend_same_original126_opaque_byte_exact=True,per_backend_events=11,per_backend_raw_ndarray_payload_bytes=8975,observer_limits_unreached=True,all_input_source_controls_exact=True,opaque_packets=len(counts),opaque_arrays=sum(counts.values()),stage_sha256=STAGE,raw_sha256=RAW,original_1J_CUDA_JAX_same_precision_failure_unresolved=True,independent_numeric_common_prefix_and_hard_ledger_EHPC_analysis_pending=True,scientific_acceptance=False)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    readout=dict(verification=verification,controller=controller,captures=receipts,causal_conclusion=None,scope='Actual capture only, including original independent NumPy-forward alias fence. Do not infer a first divergence or credit hard ledgers until the separate EHPC numeric audit executes.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={'executed-stage.tar.gz':stage_raw,'raw-gpu-result.tar.gz':raw,'unexecuted-original-review-stage.tar.gz':(BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes(),'verification.json':encode(verification),'readout.json':encode(readout)}
    items.update({'actual-gpu/'+n:v for n,v in gpu.items()});items.update({'opaque-unwrapped-events/'+n:v for n,v in unwrapped.items()})
    for p in (BASE/(LABEL+'-gpu-closed')).iterdir():
        if p.is_file() and p.name!='gpu-result.tar.gz':items['observations/closed/'+p.name]=p.read_bytes()
    for n in ('prepare_transport_trace_qj_execution.py','deploy_transport_trace_qj_gpu.py','collect_transport_trace_qj_closed.py','read_transport_trace_qj.py','package_transport_trace_qj.py',LABEL+'-gpu-deployment.json',LABEL+'-gpu-stage-b-package.json','capture_transport_trace_qj-unexecuted-before-observer-guards.py'):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for p in BASE.glob(LABEL+'-progress-*'):
        if p.is_file():items['observations/'+p.name]=p.read_bytes()
    for p in BASE.glob(LABEL+'-gpu-deploy-*'):
        if p.is_file():items['observations/'+p.name]=p.read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(v),sha256=sha(v)) for n,v in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,v in sorted(items.items()):m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;t.addfile(m,io.BytesIO(v))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Unique original NM aggregate0 once/backend on CUDA1; GPU actual parents0/0, each126 final fields opaque byte exact to original NQ. Original phase/profile/redistribute calls fully captured without extra replay, limits unreached and NumPy-forward aliases fenced. This is capture/provenance only: independent numeric/common-prefix/hard-ledger EHPC analysis is pending; original1J parity failure and all scientific/annual failures retained.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(dict(package=package,verification=verification)))

if __name__=='__main__':main()

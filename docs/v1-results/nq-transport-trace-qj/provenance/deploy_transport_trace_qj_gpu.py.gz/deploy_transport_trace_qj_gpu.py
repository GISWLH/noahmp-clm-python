"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'nq-transport-trace-qj-gpu-stage-b.tar.gz'
expected='e005dcb5ee418db9059a565bdc0da1b8b6b959dbc4ca701abd89a6dbfa4575e3'
assert sha(stage.read_bytes())==expected
target=BASE/'nq-transport-trace-qj-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'nq-transport-trace-qj-execution/launch_device_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/nq-transport-trace-qj && test ! -e /tmp/nq-transport-trace-qj-20261026 && test ! -e /tmp/noahmp-nq-transport-trace-qj-stage.tar.gz && test ! -e /tmp/launch_nq_transport_trace_qj.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-nq-transport-trace-qj-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_nq_transport_trace_qj.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_nq_transport_trace_qj.py --stage /tmp/noahmp-nq-transport-trace-qj-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('nq-transport-trace-qj-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('nq-transport-trace-qj-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

"""Download only the uniquely closed QJ GPU capture, without numerical analysis."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
DEST=BASE/'nq-transport-trace-qj-gpu-closed'
REMOTE='/home/lhwang/work/noahmp-v1/nq-transport-trace-qj'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def main():
    DEST.mkdir(exist_ok=False)
    command=['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12',*['xuanze-neiwang:'+REMOTE+'/'+n for n in ('gpu-result.tar.gz','gpu-result-hash.json','controller-receipt.json','launch.json','controller.log')],str(DEST.resolve())]
    r=subprocess.run(command,capture_output=True,timeout=180)
    (DEST/'scp.stdout').write_bytes(r.stdout);(DEST/'scp.stderr').write_bytes(r.stderr)
    (DEST/'scp-exit.json').write_text(json.dumps(dict(command=command,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)),indent=2)+'\n',encoding='utf-8')
    assert r.returncode==0,r.stderr.decode(errors='replace')
    raw=(DEST/'gpu-result.tar.gz').read_bytes();expected=json.loads((DEST/'gpu-result-hash.json').read_bytes());assert sha(raw)==expected['sha256'] and len(raw)==expected['bytes']
    with tarfile.open(DEST/'gpu-result.tar.gz') as t:files={m.name:t.extractfile(m).read() for m in t if m.isfile()}
    controller=json.loads(files['controller/controller-receipt.json']);assert (DEST/'controller-receipt.json').read_bytes()==files['controller/controller-receipt.json']
    assert controller['completed'] and controller['stage_unchanged'] and controller['error'] is None and controller['actual_controller_OS_returncode'] is None
    assert [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0,0]
    print(json.dumps(dict(actual_download_exit=0,raw_sha256=sha(raw),raw_bytes=len(raw),members=len(files),actual_GPU_parent_exits=[0,0],actual_detached_controller_OS_exit=None,numerical_or_common_prefix_analysis_performed=False)))

if __name__=='__main__':main()

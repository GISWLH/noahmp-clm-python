"""Freeze transparent QJ worker and review-only original GPU lifecycle stage."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'nq-transport-trace-qj-preparation'
OLD=BASE/'nq-phase-cross-qf-execution'
NEW=BASE/'nq-transport-trace-qj-execution'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
def main():
    assert sha((PREP/'CONTROLS_SHA256.json').read_bytes())=='d24a3c91534f6c79be38a145a7363c5d942ee80575b1abe78efbc85418aecf4a'
    shutil.copytree(PREP,BASE/'nq-transport-trace-qj-preparation-original-plan-only')
    for n in ('capture_transport_trace_qj.py','transport_contract_qj.py'):
        raw=(BASE/n).read_bytes();ast.parse(raw);(PREP/n).write_bytes(raw)
    readme='''# QJ original aggregate trace worker — review-only stage, not launched

The external worker invokes the unchanged original aggregate0 advance once on each backend, exactly the original fixture32/index1 seven arrays/forcing[0]/deposition[0]/kwargs. It observes actual adapter/phase/profile/whole-redistribute calls without replaying any primitive/reference or changing result objects. Original NM584 source, original fixture and actual NQ aggregate0 full126 outputs are bound. Every backend's final126 dtype/shape/C-bytes must exactly reproduce its original NQ packet before the trace is eligible for interpretation. No source, input, physical, same-precision or ledger gate is changed.

Call entry/return/raised events include strict sequence/parent/function ordinal and original typed arrays/scalar hex/kwargs. The worker stores all snapshots in one tar+JSONL, distinguishing original rejected calls from actual recorder failures, with all attempt/return/raise counts. The shared original host dispatch sees its saved original callable exactly once per hook. Original NumPy physical entry points are forbidden. Modules/callbacks/backend context are recorded separately from physical array data; those context tokens must not be mistaken for a numerical input difference in subsequent EHPC analysis.

Only metadata/opaque bytes are compared on GPU host. Actual numerical differences, common-prefix event alignment, first identical-input/different-output boundary and original independent whole-column M/H/C/N/impurity audits remain an EHPC posthoc task after actual captures exist. If transport entry already differs, report that rather than attributing the difference to redistribution. No JAX tracer is inspected inside a jitted kernel; this first-stage trace stops at the original whole flow function. Any final byte/control-path difference or missing boundary/recorder error makes the run nontransparent, with no causal credit.

Prepared GPU lifecycle reuses the reviewed QF/PB-t launcher/controller/worker parent on fresh private paths, original8GiB GPU/32GiB host startup gate, one thread/private caches, CUDA1 UUID only, sequential CUDA then JAX,3600s/backend and no retry. It waits actual worker and parent exits; detached controller OS return stays unknown. Root requested static review of this worker/stage before any deployment. No submit/launch script is executed or included by this preparation. Independent numerical comparison stage will bind the actual raw capture hash when available; it is not performed by this review-only bundle.
'''
    (PREP/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    index={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'};(PREP/'CONTROLS_SHA256.json').write_bytes(encode(index))
    NEW.mkdir(exist_ok=False);differences=[]
    for n in ('launch_device_pbs.py','control_device_pbs.py','run_device_parent_pbs.py'):
        before=(OLD/n).read_text();after=before
        if n=='run_device_parent_pbs.py':
            after=after.replace('from phase_cross_contract_qf import HERE,GPU,controls,original_inputs,source_identity,save,sha','from transport_contract_qj import HERE,GPU,controls,bound_evidence,source_identity,save,sha').replace('original_inputs(a.source,a.nq,binding)','bound_evidence(a.nq,binding)').replace('/tmp/nq-phase-cross-qf-','/tmp/nq-transport-trace-qj-').replace('capture_phase_cross_qf.py','capture_transport_trace_qj.py')
        ast.parse(after);(NEW/n).write_text(after,encoding='utf-8',newline='\n');differences.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='QF/'+n,tofile='QJ/'+n))
    policy=json.loads((OLD/'EXECUTION_BINDINGS.json').read_bytes())
    policy.update(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),root='/home/lhwang/work/noahmp-v1/nq-transport-trace-qj',temporary='/tmp/nq-transport-trace-qj-20261026',change_scope='Original NM584 aggregate0 trace once/backend;0 extra phase/reference replay; full126 same-backend opaque byte transparency required',native_inverse_calls='Only actual original calls observed; no replay',full_column_calls=2,transport_calls='Only original calls observed',prepared_only=True,root_pre_execution_review_pending=True)
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(policy));(NEW/'README.md').write_text('QJ review-only lifecycle. Original QF/PB-t worker/controller/launcher reused with QJ contract, capture filename and private paths only. Actual original aggregate forward once/backend; no extra phase/reference. Not launched. Independent EHPC posthoc stage remains separate and is not a fabricated scientific pass.\n',encoding='utf-8')
    (NEW/'QF_TO_QJ.diff').write_text(''.join(differences),encoding='utf-8',newline='\n')
    execution={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir()) if p.is_file()};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(execution))
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()})
    items['source.tar.gz']=(BASE/'climatology-final-candidate-nm-source.tar.gz').read_bytes();items['nq-evidence.tar.gz']=(BASE/'nq-terminal-qb-evidence.tar.gz').read_bytes()
    assert sha(items['source.tar.gz'])==policy['source_archive_sha256'] and sha(items['nq-evidence.tar.gz'])==policy['evidence_archive_sha256']
    items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/'nq-transport-trace-qj-gpu-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    result=dict(passed=True,stage_sha256=sha(target.read_bytes()),stage_files=len(items),preparation_controls=len(index),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(execution),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),source584_unchanged=True,planned_original_aggregate_calls_per_backend=1,extra_phase_or_reference_replays=0,transparency_full_original_fields_per_backend=126,root_review_pending=True,launched=False,numerical_executed=False)
    (BASE/'nq-transport-trace-qj-gpu-stage-package.json').write_bytes(encode(result));print(json.dumps(result))

if __name__=='__main__':main()

"""Metadata-only QJ lifecycle source/input/controls contract."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE=Path(__file__).resolve().parent
GPU='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def controls():
    raw=(HERE/'CONTROLS_SHA256.json').read_bytes();index=json.loads(raw)
    assert all(sha((HERE/n).read_bytes())==h for n,h in index.items());return sha(raw)
def source_identity(root,binding):
    raw=(root/'SOURCE_SHA256.json').read_bytes();manifest=json.loads(raw)
    assert len(manifest)==584 and sha(raw)==binding['source_manifest_sha256']
    assert all(sha((root/n).read_bytes())==h for n,h in manifest.items());return manifest
def bound_evidence(path,binding):
    raw=path.read_bytes();assert sha(raw)==binding['original_NQ_archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=t.getmembers();assert len({m.name for m in members})==len(members) and all(m.isfile() for m in members)
        data={m.name:t.extractfile(m).read() for m in members}
    index=json.loads(data['artifact-inventory.json'])
    assert set(index)==set(data)-{'artifact-inventory.json'} and all(sha(data[n])==v['sha256'] and len(data[n])==v['bytes'] for n,v in index.items())
    assert sha(data[binding['actual_aggregate0_packet_path']])==binding['actual_aggregate0_packet_sha256'];return data

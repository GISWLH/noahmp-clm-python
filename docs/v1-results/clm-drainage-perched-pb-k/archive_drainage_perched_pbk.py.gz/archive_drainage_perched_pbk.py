"""Flat true-F PB-k evidence, retaining failures and unchanged source inventory."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname()=='manager'
ROOT=Path('/tmp/noahmp-clm-drainage-perched-pb-k')
JOB='1649.manager'
LABEL='clm-drainage-perched-pb-k'
sha=lambda b:hashlib.sha256(b).hexdigest()
data={}
qstat=subprocess.check_output(['qstat','-xf',JOB]);status=qstat.decode()
assert re.search(r'^\s*job_state = F\s*$',status,re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$',status,re.M)
code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M).group(1))
for name in ('result.tar.gz','pbs-exit.txt'):
    digest=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
    if not (ROOT/name).exists():subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
    assert sha((ROOT/name).read_bytes())==digest
assert int((ROOT/'pbs-exit.txt').read_text())==code
with tarfile.open(ROOT/'result.tar.gz') as t:
    files=[m for m in t if m.isfile()]
    assert len({m.name.removeprefix('./') for m in files})==len(files)
    members={m.name.removeprefix('./'):t.extractfile(m).read() for m in files}
receipt=json.loads(members['receipt.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002'
assert receipt['pytest_parent_returncode']==code and int(members['worker-exit.txt'])==code
index=json.loads(members['source/SOURCE_SHA256.json'])
assert len(index)==584 and sha(members['source/SOURCE_SHA256.json'])=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert all(sha(members['source/'+n])==h for n,h in index.items())
for folder in ('preparation','execution'):
    controls=json.loads(members[folder+'/CONTROLS_SHA256.json'])
    assert all(sha(members[folder+'/'+n])==h for n,h in controls.items())
data.update({n:b for n,b in members.items() if not n.startswith('source/')})
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt',
             'compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt'):
    data['scheduler/'+name]=(ROOT/name).read_bytes()
data['scheduler/actual-qstat.txt']=qstat
if (ROOT/'pbs-output.log').exists():data['scheduler/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
diag=[json.loads(line.split('PB_K_DIAGNOSTIC ',1)[1]) for line in members['pytest.stdout.txt'].decode().splitlines() if 'PB_K_DIAGNOSTIC ' in line]
assert diag==json.loads(members['diagnostics.json'])
if code==0:
    assert receipt['passed'] and receipt['tests']==18 and receipt['failures']==receipt['errors']==0
    assert receipt['source_and_controls_unchanged'] and len(diag)==20 and b'18 passed' in members['pytest.stdout.txt']
    assert receipt['coupled_column_runs']==receipt['official_calls_executed']==receipt['GPU_tasks']==0
else:assert not receipt['passed']
data['original-result-members.json']=(json.dumps({n:dict(sha256=sha(b),bytes=len(b),included=not n.startswith('source/')) for n,b in members.items()},indent=2)+'\n').encode()
closed=dict(job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,receipt=receipt,
    raw_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),raw_result_archive=str(ROOT/'result.tar.gz'),
    original_members=len(members),omitted_unchanged_source_members=585,
    source_archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d')
data['closed-run.json']=(json.dumps(closed,indent=2)+'\n').encode()
readout=dict(actual_job=JOB,actual_job_state='F',actual_exit=code,tests=receipt.get('tests'),diagnostics=len(diag),
    pytest_seconds=receipt.get('pytest_seconds'),worker_seconds=receipt['seconds'],
    original_hard_budget_factor=64,original_official_budget_factor=128,
    future_same_precision_device_gate=1e-6,JAX_executed=False,CUDA_executed=False,
    component_integrations_are_physical=True,coupled_column_runs=0,new_official_calls=0,
    complete_module_acceptance=False,J_comparison_scope='Original public hydrology with explicitly shared NM64 thermal closure; not official thermal truth',
    cases=diag)
for dtype in ('float64','float32'):
    rows=[d for d in diag if d.get('precision')==dtype]
    readout[dtype]=dict(diagnostics=len(rows))
    if rows:
        readout[dtype].update(maximum_water_residual_record=max(rows,key=lambda d:abs(d['water_residual'])),
            maximum_heat_residual_record=max(rows,key=lambda d:abs(d['heat_residual'])))
data['run-readout.json']=(json.dumps(readout,indent=2,allow_nan=False)+'\n').encode()
for name in ('prepare_drainage_perched_pbk.py','stage_drainage_perched_pbk.py','clm-drainage-perched-pb-k-static-preparation.json'):
    data['preparation-provenance/'+name]=(ROOT/name).read_bytes()
data['archive_drainage_perched_pbk.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(b),bytes=len(b)) for n,b in data.items()},indent=2)+'\n').encode()
archive=ROOT/(LABEL+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for name,raw in sorted(data.items()):
        ti=tarfile.TarInfo(name);ti.size=len(raw);t.addfile(ti,io.BytesIO(raw))
with tarfile.open(archive) as t:assert {m.name:t.extractfile(m).read() for m in t}==data
package=dict(archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,tests=receipt.get('tests'),diagnostics=len(diag),
    NumPy64_perched_executed=True,NumPy32_perched_executed=True,JAX_executed=False,CUDA_executed=False,
    scope='Isolated NumPy64/explicit32 perched trial/full phase, actual per-case outcome and original hard M/H. Original J shared-thermal hydrology and1610 nearzero references reused. No new official, coupled-column, annual, production or GPU runs; JAX/CUDA prepared only. Original J1mm false retained, P0 physical10% and nearzero absolute gates unchanged.')
(ROOT/(LABEL+'-package.json')).write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

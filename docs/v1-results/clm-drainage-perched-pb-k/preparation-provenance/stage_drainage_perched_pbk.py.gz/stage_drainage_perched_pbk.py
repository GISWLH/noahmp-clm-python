"""Stdlib-only PB-k stage; no numerical import, collection or launch."""
from pathlib import Path
import ast
import hashlib
import io
import json
import tarfile

ROOT=Path(__file__).resolve().parent
PREP=ROOT/'clm-drainage-perched-pb-k-preparation'
EXEC=ROOT/'clm-drainage-perched-pb-k-execution'
OLD=ROOT/'clm-drainage-adaptive-pb-i-execution'
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf8',newline='\n')


def main():
    EXEC.mkdir(exist_ok=True)
    for name in ('run_component_pb.py','component_pb.pbs','dispatch_component_pb.py'):
        text=(OLD/name).read_text(encoding='utf8').replace('clm-drainage-adaptive-pb-i','clm-drainage-perched-pb-k')
        text=text.replace('drainage-adaptive-pbi','drainage-perched-pbk').replace('dispatch_drainage_adaptive_pbi.py','dispatch_drainage_perched_pbk.py')
        if name=='run_component_pb.py':
            old="str(root / 'preparation/test_adaptive_main_pbg.py'),str(root / 'preparation/test_adaptive_main_pbi.py')"
            assert text.count(old)==1;text=text.replace(old,"str(root / 'preparation/test_perched_pbk.py')")
            text=text.replace("('PB_G_DIAGNOSTIC ','PB_I_DIAGNOSTIC ')","('PB_K_DIAGNOSTIC ',)")
            oldscope='Original NumPy64 eight cases plus ten explicit NumPy32 phase/adaptive main-band cases, original hard budgets, actual 1616 and independent ODE; JAX/CUDA unexecuted; no device acceptance; no new official call, coupled column, annual, GPU or release acceptance.'
            assert oldscope in text
            text=text.replace(oldscope,'Eighteen new isolated perched trial/full-phase cases, nine per NumPy64/32; original hard budgets and sealed actual J shared-thermal/1610 nearzero references. JAX/CUDA unexecuted, no device or column acceptance, no new official calls. Original J 1mm flag remains false and is not a new P0 gate.')
        elif name=='dispatch_component_pb.py':
            text=text.replace('PB-i NumPy32 and unchanged NumPy64 main band against frozen PB-c, actual 1616 and independent ODE; no coupled column, annual or GPU execution.',
                'PB-k nine NumPy64 and nine explicit NumPy32 isolated perched cases; no coupled column, annual, new official call or GPU execution.')
        (EXEC/name).write_text(text,encoding='utf8',newline='\n')
    for folder in (PREP,EXEC):
        for p in folder.glob('*.py'):ast.parse(p.read_text(encoding='utf8'))
        save(folder/'CONTROLS_SHA256.json',{p.name:sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'})
    binding=json.loads((PREP/'BINDINGS.json').read_bytes())
    assert all(sha((PREP/n).read_bytes())==h for n,h in binding['frozen_dependencies'].items())
    source=ROOT/binding['source_archive'];assert sha(source.read_bytes())==binding['source_archive_sha256']
    tree=ast.parse((PREP/'test_perched_pbk.py').read_bytes())
    count=0;names=[]
    for f in tree.body:
        if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
            n=1
            for d in f.decorator_list:
                assert isinstance(d,ast.Call) and d.func.attr=='parametrize'
                n*=2 if isinstance(d.args[1],ast.Name) and d.args[1].id=='DTYPES' else len(ast.literal_eval(d.args[1]))
            count+=n;names.append(dict(function=f.name,cases=n))
    assert count==18
    raw={'source.tar.gz':source.read_bytes()}
    for folder,label in [(PREP,'preparation'),(EXEC,'execution')]:
        raw.update({label+'/'+p.name:p.read_bytes() for p in sorted(folder.iterdir()) if p.is_file()})
    raw['stage-inventory.json']=(json.dumps({n:sha(b) for n,b in sorted(raw.items())},indent=2)+'\n').encode()
    dest=ROOT/'clm-drainage-perched-pb-k-stage.tar.gz'
    with tarfile.open(dest,'w:gz') as t:
        for name,value in raw.items():
            ti=tarfile.TarInfo(name);ti.size=len(value);t.addfile(ti,io.BytesIO(value))
    report=dict(actual_static_exit=0,numerical_execution=False,tests=count,test_functions=names,
        controls=len(json.loads((PREP/'CONTROLS_SHA256.json').read_bytes())),
        preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()),
        stage=dest.name,stage_sha256=sha(dest.read_bytes()),stage_members=len(raw),
        preserved_main_dependencies=binding['frozen_dependencies'],source_archive_sha256=binding['source_archive_sha256'])
    save(ROOT/'clm-drainage-perched-pb-k-static-preparation.json',report)
    print(json.dumps(report))


if __name__=='__main__':main()

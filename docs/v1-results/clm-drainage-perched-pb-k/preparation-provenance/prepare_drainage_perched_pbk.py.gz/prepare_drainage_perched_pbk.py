"""Isolated perched array/full-loop preparation using immutable main dependencies."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'clm-drainage-perched-pb-k-preparation'
OLD=ROOT/'clm-drainage-adaptive-pb-i-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()

CUDA_TAIL='''
  T factor,weights[4];int front_layer,bi=0;
  T q=rate(c,p,e,ice,u[1],u[2],true,factor,weights,front_layer);
  for(int k=0;k<4;k++)bi+=e[k+1]<u[2];
  T sy=yield(main,p),requested=q*u[0],capacity=(T(1000)*sy)*(u[2]-u[1]);
  T desired=mn(requested,capacity),remaining=desired;
  for(int k=0;k<4;k++){
    bool eligible=q>T(0)&&k>front_layer&&k<=bi&&remaining>T(0);
    T take=eligible?mn(remaining,mx(T(0),c[6*k]-p[10])):T(0);
    remaining=remaining-take;
    T heat=take*(T(334000)+T(4180)*(c[6*k+3]-T(273.15)));
    t[10+k]=take;t[14+k]=heat;t[18+k]=c[6*k+4]-take;t[22+k]=c[6*k+5]-heat;
  }
  T total=0,mr=0,hr=0,wm=0,hm=0;
  for(int k=0;k<4;k++){
    total=total+t[10+k];mr=mr+((t[18+k]-c[6*k+4])+t[10+k]);
    hr=hr+((t[22+k]-c[6*k+5])+t[14+k]);
    wm=wm+((ab(c[6*k+4])+ab(t[18+k]))+ab(t[10+k]));
    hm=hm+((ab(c[6*k+5])+ab(t[22+k]))+ab(t[14+k]));
  }
  t[0]=mn(u[2],u[1]+total/(T(1000)*sy));t[1]=requested;t[2]=total;
  t[3]=mx(T(0),desired-total);t[4]=mx(T(0),requested-desired);t[5]=total<desired;
  t[6]=mr;t[7]=hr;t[8]=T(64)*eps*mx(wm,T(1));t[9]=T(64)*eps*mx(hm,T(1));
  t[26]=main;t[27]=sy;t[28]=front_layer+1;
}
'''

HEADER='''"""Separate perched full phase/adaptive loop; immutable I main path retained."""
import math
import drainage_primitives_pbf as primitives
import perched_primitives_pbk as perched
from saturated_drainage_pb import IntegrationControls
from adaptive_main_pbi import _phase, _stocks, _kahan, _backend as _main_backend

def _backend(name):
    xp,_=_main_backend(name)
    run={'numpy':perched.run_numpy_perched,'jax':perched.run_jax_perched,'cuda':perched.run_cuda_perched}[name]
    return xp,run

'''


def main():
    DEST.mkdir(exist_ok=True)
    old_index=json.loads((OLD/'CONTROLS_SHA256.json').read_bytes())
    names=['drainage_primitives_pbf.py','drainage_primitives_pbf.cu','adaptive_main_pbi.py',
        'adaptive_main_pbg.py','phase_numpy32_pbi.py','saturated_drainage_pb.py']
    dependencies={}
    for name in names:
        raw=(OLD/name).read_bytes();assert sha(raw)==old_index[name]
        (DEST/name).write_bytes(raw);dependencies[name]=sha(raw)
    module=(OLD/'adaptive_main_pbi.py').read_text(encoding='utf8')
    function=module[module.index('def advance_main_band('):]
    function=function.replace('def advance_main_band(','def advance_perched_band(')
    old='        stored=1000*primitives._integral(front,xp.asarray(bottom_m,c.dtype),p,xp,lambda x:x)'
    new="""        main_depth=primitives._diagnosis(current,p,xp,lambda x:x)[0]
        sy=primitives._sy(main_depth,p,xp,lambda x:x)
        stored=(1000*sy)*(xp.asarray(bottom_m,c.dtype)-front)"""
    assert function.count(old)==1;function=function.replace(old,new)
    function=function.replace("kind='saturated'","kind='perched'").replace('perched_evolution=False','perched_evolution=True')
    function=function.replace('Main drainage','Perched drainage').replace('main trial','perched trial').replace('main hard','perched hard')
    (DEST/'adaptive_perched_pbk.py').write_text(HEADER+function,encoding='utf8',newline='\n')
    # Original own-code helper implementation is not modified; this new kernel
    # reuses its geometry/diagnosis prefix and adds only the perched trial.
    source=(OLD/'drainage_primitives_pbf.cu').read_text(encoding='utf8')
    kernel=source[source.index('template<class T> __global__ void drainage('):source.index('  T factor,weights[4];int front_layer;')]
    kernel=kernel.replace('void drainage(','void perched(').replace('T* t=ts+26*row;','T* t=ts+29*row;')
    (DEST/'perched_primitives_pbk.cu').write_text('// New perched kernel; compile after unchanged F helper source.\n'+kernel+CUDA_TAIL,encoding='utf8',newline='\n')
    refs={}
    for archive,expected,mapping in [
        ('clm-drainage-common-thermal-pb-j-evidence.tar.gz','1360fb8305ddf55fd18a941416a0dbec8da112735ddb3fcef5d5b7dc28077b16',
         {'comparison/comparisons.json':'reference-common-thermal-j.json','receipt.json':'reference-j-receipt.json'}),
        ('clm-drainage-backends-pb-f-evidence.tar.gz','566a89313ce6570c0d5f61d269776c2f76a5c1f47228bfe5326dc71414e0ddec',{})]:
        assert sha((ROOT/archive).read_bytes())==expected
        with tarfile.open(ROOT/archive) as t:
            for member,name in mapping.items():
                raw=t.extractfile(member).read();(DEST/name).write_bytes(raw);refs[name]=dict(archive=archive,archive_sha256=expected,member=member,sha256=sha(raw))
    f2=ROOT/'clm-drainage-backends-pb-f2-preparation'
    for name in ('reference-comparisons.json','reference-frost_perched_donor--fixture.txt','reference-frost_perched_donor--official.stdout.txt'):
        raw=(f2/name).read_bytes();(DEST/name).write_bytes(raw);refs[name]=dict(source_preparation='clm-drainage-backends-pb-f2-preparation',sha256=sha(raw))
    binding=json.loads((OLD/'BINDINGS.json').read_bytes())
    binding.pop('original_float64_tests',None);binding.pop('new_float32_tests',None)
    binding.update(frozen_dependencies=dependencies,reference_members=refs,original_I_actual_job='1641.manager:F0',
        original_J_actual_job='1647.manager:F0',prepared_only=True,numerical_execution=False,
        planned_tests=18,planned_numpy64_tests=9,planned_numpy32_tests=9,
        original_component_hard_budget_factor=64,original_official_budget_factor=128,same_precision_device_gate=1e-6,
        scope='Independent perched trial/full phase loop. Official hydrology J has explicitly shared NM64 heat; original 1mm diagnostic is not a new P0 gate.')
    (DEST/'BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf8',newline='\n')
    for f in DEST.glob('*.py'):ast.parse(f.read_text(encoding='utf8'))
    print(json.dumps(dict(actual_static_exit=0,immutable_dependencies=dependencies,prepared_only=True)))


if __name__=='__main__':main()

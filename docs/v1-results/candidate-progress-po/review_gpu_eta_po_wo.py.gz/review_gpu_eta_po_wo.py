"""Independent scalar timing/count audit of the existing PO snapshot; no SSH."""
from pathlib import Path
import ast
import csv
import hashlib
import io
import json
import math
import re
from datetime import datetime

root = Path(__file__).resolve().parent
paths = {n: root/n for n in ('refresh_gpu_eta_po.py', 'candidate-progress-po.json', 'GPU_ETA_NQ.json', 'GPU_ETA_NQ_PO_REFRESH.json')}
raw = {n: p.read_bytes() for n, p in paths.items()}
sha = lambda b: hashlib.sha256(b).hexdigest()
snapshot = json.loads(raw['candidate-progress-po.json'])
prior = json.loads(raw['GPU_ETA_NQ.json'])
refresh = json.loads(raw['GPU_ETA_NQ_PO_REFRESH.json'])
for name, digest in refresh['input_sha256'].items():
    assert sha(raw[name]) == digest
tree = ast.parse(raw['refresh_gpu_eta_po.py'])
imports = {n.names[0].name for n in ast.walk(tree) if isinstance(n, ast.Import)}
assert imports == {'hashlib', 'json', 'math'}
assert {n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)} == {'datetime', 'pathlib'}
assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('exec', 'eval', '__import__') for n in ast.walk(tree))
modules = prior['modules_in_execution_order']
lookup = {m['file']: m for m in modules}
assert len(lookup) == len(modules) == 72
closed = snapshot['closed']
assert closed == snapshot['progress']['records'] and len(closed) == 21
closed_names = {r['file'] for r in closed}
assert len(closed_names) == 21
for row in closed:
    assert row['actual_parent_returncode'] == 0 and row['passed'] is True
    assert row['expected_tests'] == lookup[row['file']]['tests']
    assert re.fullmatch('[0-9a-f]{64}', row['receipt_sha256'])
assert 'test_gpu_clm_most_column.py' in closed_names
assert closed[-1]['file'] == 'test_gpu_clm_most_column.py'
fresh = sum(r['expected_tests'] for r in closed)
reused = snapshot['progress']['reused']
reused_names = {r['file'] for r in reused}
assert len(reused_names) == len(reused) == 9 and not (reused_names & set(lookup))
assert all(r['actual_parent_returncode'] == 0 for r in reused)
reuse = sum(r['tests'] for r in reused)
remaining = [m for m in modules if m['file'] not in closed_names]
assert fresh == 116 and reuse == 32 and fresh+reuse == 148
assert len(remaining) == 51 and sum(r['tests'] for r in remaining) == 260
assert fresh+reuse+sum(r['tests'] for r in remaining) == 408
current = snapshot['progress']['file']
assert current not in closed_names and sum(m['file'] == current for m in remaining) == 1
recent = [m for m in remaining if m['timing_group'] != 'older_history']
older = [m for m in remaining if m['timing_group'] == 'older_history']
assert len(recent) == 2 and len(older) == 49
assert [r['file'] for r in recent] == ['test_gpu_clm_optics_column.py', 'test_gpu_photosynthesis.py']
assert all(r['baseline_min_seconds'] == r['baseline_max_seconds'] for r in recent)
recent_seconds = math.fsum(r['baseline_min_seconds'] for r in recent)
older_seconds = [math.fsum(r['baseline_'+bound+'_seconds'] for r in older) for bound in ('min', 'max')]
hours = [(recent_seconds+factor*old)/3600 for factor, old in zip((1.3, 2.6), older_seconds)]
assert hours == refresh['regression']['remaining_hours']
assert refresh['regression']['formula'] == prior['estimate']['formula']
assert refresh['regression']['active_elapsed_subtracted_seconds'] == 0
assert [round(v) for v in hours] == [20, 43]
assert refresh['regression']['completed'] == 148 and refresh['regression']['fresh'] == 116 and refresh['regression']['reused'] == 32
uuid = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
first = {r['pid']: r for r in snapshot['first']['processes']}
second = {r['pid']: r for r in snapshot['second']['processes']}
assert len(first) == len(second) == 6 and set(first) == set(second)
for pid in first:
    assert first[pid]['start_ticks'] == second[pid]['start_ticks']
    assert first[pid]['environment']['CUDA_VISIBLE_DEVICES'] == second[pid]['environment']['CUDA_VISIBLE_DEVICES'] == uuid
    assert first[pid]['status']['VmSwap'] == second[pid]['status']['VmSwap'] == '0 kB'
elapsed_monotonic = snapshot['second']['monotonic'] - snapshot['first']['monotonic']
elapsed_utc = (datetime.fromisoformat(snapshot['second']['utc']) - datetime.fromisoformat(snapshot['first']['utc'])).total_seconds()
assert 5 < elapsed_monotonic < 6 and abs(elapsed_monotonic-elapsed_utc) < .01
workers = list(csv.DictReader(io.StringIO(snapshot['gpu_processes']), skipinitialspace=True))
actual_gpu_pids = {int(r['pid']) for r in workers if r['gpu_uuid'] == uuid}
assert actual_gpu_pids == {3709792, 3712669, 4014180}
assert snapshot['progress']['pid'] == 4014180
assert all(second[p]['user_ticks'] + second[p]['system_ticks'] > first[p]['user_ticks'] + first[p]['system_ticks'] for p in actual_gpu_pids)
util = []
for sample in snapshot['gpu_samples']:
    rows = list(csv.DictReader(io.StringIO(sample['output']), skipinitialspace=True))
    assert len(rows) == 1 and rows[0]['index'] == '1' and rows[0]['uuid'] == uuid
    util.append(int(rows[0]['utilization.gpu [%]'].split()[0]))
assert util == [94, 97, 91] and refresh['gpu_samples'] == snapshot['gpu_samples']
assert all(datetime.fromisoformat(snapshot['first']['utc']) <= datetime.fromisoformat(s['utc']) <= datetime.fromisoformat(snapshot['second']['utc']) for s in snapshot['gpu_samples'])
years = {}
for name, data in snapshot['years'].items():
    logs = [json.loads(line) for line in data['log_tail']]
    a, b = logs[0], logs[-1]
    assert len(logs) == 15 and b['steps']-a['steps'] == 672
    assert all(y['steps']-x['steps'] == 48 and y['seconds'] > x['seconds'] for x, y in zip(logs, logs[1:]))
    assert b['steps'] == data['steps_completed'] == data['ledger_steps']
    assert data['status'] == 'running' and data['steps_requested'] == 17520
    assert all(row['columns'] == (12 if name == 'NS' else 3) for row in logs)
    speed = (b['seconds']-a['seconds'])/(b['steps']-a['steps'])
    estimate = (17520-b['steps'])*speed/3600
    assert speed == refresh['years'][name]['recent_seconds_per_batch_step']
    assert estimate == refresh['years'][name]['conditional_remaining_hours']
    years[name] = dict(completed=b['steps'], requested=17520, recent_window_steps=672,
                       recent_seconds_per_batch_step=speed, conditional_remaining_hours=estimate)
assert years['NS']['completed'] == 5760 and years['NZ']['completed'] == 6192
assert round(years['NS']['conditional_remaining_hours'], 3) == 6.139
assert round(years['NZ']['conditional_remaining_hours'], 3) == 5.789
result = dict(passed=True, blocking_findings=[], sample_utc=snapshot['second']['utc'],
              input_sha256={n:sha(b) for n,b in raw.items()}, fresh=116, reused=32, completed=148,
              total=408, remaining_nodes=260, closed_modules=21, remaining_modules=51,
              current_module_counted_once=current, active_elapsed_subtracted_seconds=0,
              remaining_recent_modules=[r['file'] for r in recent], remaining_older_modules=49,
              recent_baseline_seconds=recent_seconds, older_baseline_seconds=older_seconds,
              independently_recomputed_remaining_hours=hours, nearest_hour_display=[20,43],
              years=years, process_pids=sorted(first), all_six_same_uuid=True,
              actual_gpu_process_pids=sorted(actual_gpu_pids), physical_gpu=1, gpu_uuid=uuid,
              sampled_gpu_utilization_percent=util,
              snapshot_elapsed_monotonic_seconds=elapsed_monotonic, snapshot_elapsed_utc_seconds=elapsed_utc,
              newly_closed_most=closed[-1],
              formula_annotation={'inherited_text': refresh['regression']['formula'],
                  'actual_remaining_formula': 'sum(remaining recent2 baseline parent seconds) + 1.3*sum(remaining older49 min seconds) or2.6*sum(remaining older49 max seconds); divide3600; no active elapsed subtraction',
                  'inherited_text_describes_initial_queue_not_current_counts': True,
                  'newly_closed_MOST_removed_from_sum': True},
              limitations=['20–43h is rounded conditional planning metadata, not a guaranteed enclosing interval or release ETA.',
                          'After removing completed modules, only2 recent modules plus49 older modules remain in the original formula.',
                          'Annual rates use the recent672-step windows; seasonal workload and concurrent GPU load can change them.',
                          'The three jobs are concurrent; their remaining times must not be added.',
                          'Six task processes are UUID-bound; only the three worker processes appear as GPU compute consumers in the snapshot.',
                          'This review verifies sampled original-exit entries and their receipt SHA references; full receipt/XML byte inventories belong to separate closed-module validation evidence, not this progress snapshot.',
                          'Original timing baselines include source/worker/cache differences and are performance context only, never execution credit.'],
              review_scope='Stdlib JSON/AST and scalar timing arithmetic only; no remote resampling, scientific array decoding, model or solver.')
output = root/'gpu-eta-po-independent-review-wo.json'
output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(passed=True,review_sha256=sha(output.read_bytes()),hours=hours,years=years)))

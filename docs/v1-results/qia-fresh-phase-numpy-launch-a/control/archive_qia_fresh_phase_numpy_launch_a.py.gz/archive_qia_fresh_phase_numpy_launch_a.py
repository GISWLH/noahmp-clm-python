from pathlib import Path
import hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-fresh-phase-numpy-week-a';a=b/'qia-fresh-phase-numpy-launch-a-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((r/'launch.json').read_text());assert launch['pbs_job']=='225.manager' and launch['node']=='compute002'
raw=(r/'trajectory/report.json').read_bytes();report=json.loads(raw)
assert report['status']=='running' and report['steps_requested']==17520 and report['source_unchanged']
with tarfile.open(a,'w:gz') as t:
    for n in ['launch.json','controller.log','run_qia_fresh_phase_numpy_week_a.py','qia_fresh_phase_numpy_week_a.pbs','SOURCE_SHA256.json']:
        t.add(r/n,arcname=n,recursive=False)
    info=tarfile.TarInfo('report-snapshot.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    for name,digest in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:
        p=r/'trajectory'/report[name];assert sha(p)==report[digest];t.add(p,arcname='trajectory/'+p.name,recursive=False)
    qstat=subprocess.check_output(['qstat','-f','225.manager'],text=True).encode();info=tarfile.TarInfo('qstat.txt');info.size=len(qstat);t.addfile(info,io.BytesIO(qstat))
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,steps_completed=report['steps_completed'],steps_requested=17520,scope='Actual EHPC PBS225 compute002 new original-cold510 NumPy trajectory to336,original17520 retained; live snapshot not completed week/year/spinup/science. No original failed trajectory resumed.')))

from pathlib import Path
from dataclasses import astuple
from datetime import datetime,timezone
import hashlib,inspect,json,sys,time,traceback
import numpy as np
import run_fluxnet_native as native
import noahmp_clm.gpu.canopy_most_surface as most
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.gpu.clm_bgc_column import pack_bgc_environment
from fluxnet_deposition import DepositionSchedule
root=Path.cwd();base=root.parent;original=base/'fluxnet-first-climate-cycle-20261017-i';folder=original/'cuda-day';source=native.ROOT;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items());report=json.loads((folder/'batch.json').read_text())
assert report['status']=='failed' and report['steps_completed']==4016 and 'Native MOST flux feedback did not converge in 50 iterations' in report['failure']
checkpoint=folder/report['checkpoint_file'];assert sha(checkpoint)==report['checkpoint_sha256']
with np.load(checkpoint,allow_pickle=False) as z:saved=dict(z)
assert saved['index'].item()==4016;cases=native.load_batch(original/'batch.json');index=4016;dtype=np.float32
f=np.asarray([c['data']['forcing'][index] for c in cases],dtype);env=np.asarray([c['data']['environment'][index] for c in cases],dtype)
e,cal=pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype)
schedules=[DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([s.nitrogen_rate for s in schedules],dtype)*f[:,0]
deposition=np.asarray([s.aerosol(c['stamps'][index],f[k,0]) for k,(c,s) in enumerate(zip(cases,schedules))],dtype)
geometry=np.asarray([astuple(MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype)
leaf=LeafParameters(**cases[0]['config']['leaf_parameters']);engine=native.Backend('cuda32');cp=engine.xp
arrays=tuple(saved[f'a{k}'] for k in range(16));device=engine.update_forcing(tuple(cp.asarray(v) for v in arrays),env)
payload={f'a{k}':v for k,v in enumerate(arrays)};payload.update(forcing=f,forcing_environment=env,environment=e,calendar=cal,nitrogen=nitrogen,deposition=deposition,geometry=geometry)
np.savez_compressed(root/'whole-inputs.npz',**payload)
real=most.run_most_surface;lines,start=inspect.getsourcelines(real);capture_line=next(start+i for i,line in enumerate(lines) if 'previous=(surface[' in line)
records=[]
def host(value):
    if isinstance(value,dict):return {k:host(v) for k,v in value.items()}
    if isinstance(value,(int,float,bool)):return value
    return cp.asnumpy(value).tolist()
def trace(frame,event,arg):
    if frame.f_code is not real.__code__:return None
    if event=='line' and frame.f_lineno==capture_line:
        values=frame.f_locals;keys=['count','zeta','effective','done','iterations','lower','upper','stable_bracket','bisection_restarts','mismatch','dh','de','dt']
        row={key:host(values[key]) for key in keys if key in values}
        row.update(current=host(values['current']),feedback=host(values['feedback']),target=host(values['target']),
            h=host(values['surface']['h']),et=host(values['surface']['et_kgm2']),leaf_temperature=host(values['surface']['leaf_temperature']))
        records.append(row)
    return trace

def capture(a,g,w,d,l,**kwargs):
    data={f'a{k}':cp.asnumpy(v) for k,v in enumerate(a)};data.update(geometry=np.asarray(g),wind=cp.asnumpy(w),leaf_dimension=cp.asnumpy(d),plant_area=cp.asnumpy(l))
    np.savez_compressed(root/'most-inputs.npz',**data);return real(a,g,w,d,l,**kwargs)
most.run_most_surface=capture;started=time.monotonic();status='unexpected_success';failure=None
try:
    sys.settrace(trace)
    engine.step(*device,f,environment=e,calendar=cal,nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,most_geometry=geometry,leaf_parameters=leaf,return_surface=True)
except Exception:status='reproduced_failure';failure=traceback.format_exc()
finally:sys.settrace(None);most.run_most_surface=real
assert all(sha(source/k)==v for k,v in manifest.items())
(root/'iterations.json').write_text(json.dumps(records,indent=2,allow_nan=False)+'\n')
result=dict(scope='Original I4016 complete step with read-only Python line hook; selected MOST locals only, no physical source, parameter, limit or tolerance changes.',status=status,failure=failure,
    index=index,node='xuanze',backend='cuda32',source_unchanged=True,source_sha256=native.source_hashes(),original_failed_checkpoint_sha256=sha(checkpoint),
    original_failed_batch_sha256=sha(folder/'batch.json'),cases=[dict(case=c['case'],site=c['config']['site'],local_time=c['stamps'][index].isoformat()) for c in cases],
    observed_iterations=len(records),seconds=time.monotonic()-started,instrument_sha256=sha(__file__),artifacts={p.name:sha(p) for p in [root/'whole-inputs.npz',root/'most-inputs.npz',root/'iterations.json']})
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}),flush=True)
assert status=='reproduced_failure' and 'Native MOST flux feedback did not converge in 50 iterations' in failure and len(records)==50

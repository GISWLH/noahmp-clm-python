from pathlib import Path
import inspect,json,hashlib,time,traceback
import numpy as np
import cupy as cp
import noahmp_clm.gpu.canopy_most_surface as module
from noahmp_clm.physics.photosynthesis import LeafParameters
root=Path.cwd();base=root.parent;original=base/'failure-i4016-most-a';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
with np.load(original/'most-inputs.npz',allow_pickle=False) as z:data=dict(z)
config=json.loads((base/'fluxnet-first-climate-cycle-20261017-h/inputs/CN-Qia-config.json').read_text());leaf=LeafParameters(**config['leaf_parameters'])
source=inspect.getsource(module.run_most_surface)
old_z="next_zeta=xp.where(stable_bracket,.5*(lower+upper),.5*(zeta+feedback['zeta']))"
old_w="effective=xp.where(done|stable_bracket,effective,.5*(effective+feedback['effective_wind']))"
rows=[]
for mode in ['quarter','adaptive']:
    text=source.replace('previous=None','previous=None;relaxation=zero+.5;previous_stability_residual=None')
    before='        previous=(surface'
    added="""        stability_residual=feedback['zeta']-zeta
        if previous_stability_residual is not None:
            growing_oscillation=(stability_residual*previous_stability_residual<0.)&(xp.abs(stability_residual)>xp.abs(previous_stability_residual))&(~stable_bracket)&(~done)&(mismatch>1e-4)
            relaxation=xp.where(growing_oscillation,xp.maximum(.0625,.5*relaxation),relaxation)
        previous_stability_residual=stability_residual
"""
    if mode=='adaptive':text=text.replace(before,added+before)
    else:text=text.replace('relaxation=zero+.5','relaxation=zero+.25')
    new_z="next_zeta=xp.where(stable_bracket,.5*(lower+upper),xp.where(relaxation==.5,.5*(zeta+feedback['zeta']),zeta+relaxation*(feedback['zeta']-zeta)))"
    new_w="effective=xp.where(done|stable_bracket,effective,xp.where(relaxation==.5,.5*(effective+feedback['effective_wind']),effective+relaxation*(feedback['effective_wind']-effective)))"
    assert old_z in text and old_w in text;text=text.replace(old_z,new_z).replace(old_w,new_w)
    path=root/(mode+'.py');path.write_text(text);namespace=module.__dict__.copy();exec(compile(text,str(path),'exec'),namespace);function=namespace['run_most_surface']
    started=time.monotonic();record=dict(mode=mode,source_sha256=sha(path),scope='Numerical candidate only, original physical module/parameters/limits/tolerances unchanged; not production adopted.')
    try:
        out=function(tuple(cp.asarray(data[f'a{k}']) for k in range(9)),data['geometry'],data['wind'],data['leaf_dimension'],data['plant_area'],backend='cuda',parameters=leaf)
        most=out['most'];record.update(status='complete',iterations=cp.asnumpy(most['iterations']).tolist(),coefficient_residual=cp.asnumpy(most['coefficient_residual']).tolist(),heat_change=cp.asnumpy(most['heat_change_wm2']).tolist(),vapor_change=cp.asnumpy(most['vapor_change_kgm2s']).tolist(),leaf_temperature_change=cp.asnumpy(most['leaf_temperature_change_k']).tolist())
    except Exception:record.update(status='failed',failure=traceback.format_exc())
    record['seconds']=time.monotonic()-started;rows.append(record)
(root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows),flush=True)

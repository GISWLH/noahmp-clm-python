from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'gpu-worker-lifecycle-a';source=base/'p6-most-oscillation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'test_gpu_photosynthesis-receipt.json').read_text());assert r['passed'] and r['pytest_returncode']==r['worker_exitcode']==0 and r['counts']==dict(tests=6,failures=0,errors=0,skipped=0)
assert r['source_unchanged'] and r['node_coverage_exact'] and r['all_setup_call_teardown_phases_passed'] and all(v['status']=='complete' for v in r['device_barriers'])
assert sha(root/'run_pytest_worker_a.py')==r['worker_sha256'];m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
progress=(root/'progress.json').read_bytes();p=json.loads(progress);assert p['results'][0]['returncode']==0
snapshot=root/'first-file-snapshot.json';assert not snapshot.exists();snapshot.write_bytes(progress)
names=['run_pytest_worker_a.py','launch_gpu_worker_lifecycle_a.py','launch.json','first-file-snapshot.json','test_gpu_photosynthesis-expected.json','test_gpu_photosynthesis-receipt.json','test_gpu_photosynthesis.xml','test_gpu_photosynthesis.log']
dest=base/'gpu-worker-first-file-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for n in names:t.add(root/n,arcname=n,recursive=False)
    t.add(source/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False);t.add(Path(__file__),arcname='archive_gpu_worker_prefix_a.py',recursive=False)
print(json.dumps(dict(files=len(names)+2,sha256=sha(dest),scope='Original leaf6 GPU tests completed in isolated worker with full test phases, barriers, exact nodes/source/XML and real process return0. Large irrigation prototype/full canonical/annual still pending.')))

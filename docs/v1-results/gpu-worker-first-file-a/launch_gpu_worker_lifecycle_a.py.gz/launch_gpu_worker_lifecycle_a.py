from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=base/'gpu-worker-lifecycle-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False)
    for name in ['run_pytest_worker_a.py','launch_gpu_worker_lifecycle_a.py']:(root/name).write_bytes((base/name).read_bytes())
    env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
    env.update(PYTHONPATH=str(source/'src')+':'+str(source/'tests')+':'+str(source/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
    command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'launch_gpu_worker_lifecycle_a.py'),'--run']
    with (root/'controller.log').open('w') as stream:proc=subprocess.Popen(command,cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    r=dict(pid=proc.pid,gpu=1,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Lifecycle prototype only, original canonical full queue and annual remain unchanged.',worker_sha256=sha(root/'run_pytest_worker_a.py'))
    (root/'launch.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(0)
selection=json.loads((source/'full-by-file-a/selection.json').read_text());results=[];begun=time.monotonic()
for file in ['tests/test_gpu_photosynthesis.py','tests/test_gpu_clm_irrigation_column.py']:
    assert file in selection['gpu_files'];name=Path(file).stem
    nodes=[Path(v.split('::',1)[0]).name+'::'+v.split('::',1)[1] for v in selection['all_nodes'] if v.split('::',1)[0]==file]
    expected=root/(name+'-expected.json');expected.write_text(json.dumps(nodes,indent=2)+'\n')
    command=[sys.executable,'-u',str(root/'run_pytest_worker_a.py'),'--source',str(source),'--test-file',str(source/file),'--expected',str(expected),'--receipt',str(root/(name+'-receipt.json')),'--xml',str(root/(name+'.xml'))]
    start=time.monotonic()
    with (root/(name+'.log')).open('w') as log:
        proc=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
        (root/'progress.json').write_text(json.dumps(dict(status='running',active=dict(file=file,pid=proc.pid),results=results),indent=2)+'\n');code=proc.wait()
    r=json.loads((root/(name+'-receipt.json')).read_text());assert code==r['worker_exitcode']
    row=dict(file=file,returncode=code,seconds=time.monotonic()-start,receipt=r);results.append(row);print(json.dumps(row),flush=True)
    if code or not r['passed']:break
passed=len(results)==2 and all(v['returncode']==0 and v['receipt']['passed'] for v in results)
(root/'summary.json').write_text(json.dumps(dict(status='complete' if passed else 'failed',seconds=time.monotonic()-begun,results=results,scope='Original device tests, no physical changes or full-suite/annual/scientific completion claim.'),indent=2)+'\n')
assert passed

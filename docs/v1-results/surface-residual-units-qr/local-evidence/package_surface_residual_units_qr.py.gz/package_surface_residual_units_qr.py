"""Seal actual existing-array unit table; no physical solve or unit rewriting."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-residual-units-qr'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def files(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()];names=[m.name.removeprefix('./') for m in members]
        assert len(names)==len(set(names)) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();result_raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes()
    assert sha(stage_raw)=='8cb397ba0699bfa8e711efda8fd7ac61db75478df948b7fcecf0c9a6a59417d9'
    assert sha(result_raw)=='12e5725e0f1034f58f1ab56b2ebed5055947e8c3ff6d78e53d3a1e0b98c6eca6'
    stage=files(stage_raw);result=files(result_raw);assert len(stage)==16 and len(result)==26
    index=json.loads(stage['stage-inventory.json']);assert set(index)==set(stage)-{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    for folder,copy in [('preparation','preparation-controls'),('execution','execution-controls')]:
        manifest=json.loads(stage[folder+'/CONTROLS_SHA256.json'])
        for name in [*manifest,'CONTROLS_SHA256.json']:
            assert result[copy+'/'+name]==stage[folder+'/'+name]
            if name in manifest:assert sha(stage[folder+'/'+name])==manifest[name]
    for name in ('setup-exit.txt','worker-exit.txt','stage-after-exit.txt','pbs-command-exit.txt'):assert result[name].strip()==b'0'
    before=json.loads(result['stage-before.json']);after=json.loads(result['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']==index
    qstat=(BASE/(LABEL+'-closure/initial-qstat.stdout')).read_bytes()
    for field,value in [('job_state','F'),('Exit_status','0'),('Stageout_status','0')]:
        assert re.search(rb'^\s*'+field.encode()+rb' = '+value.encode()+rb'\s*$',qstat,re.M)
    report=json.loads((BASE/(LABEL+'-readout.json')).read_bytes())
    assert report['analysis_completed'] and report['actual_analysis_exit']==0 and report['immutable_before_after_exact']
    assert report['model_calls']==report['evaluate_calls']==report['new_Jacobian_computations']==0
    assert set(report['rows'])=={'QN','QF','PW_stalled_x','PW_stored_ambient'} and not report['original_error_messages_modified']
    closure=dict(pbs_job='1868.manager',job_state='F',PBS_exit=0,Stageout_status=0,actual_analysis_exit=0,
        source_and_inputs_before_after_exact=True,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        ground_constraint_units='K',other11_active_dry_solver_equations_units='W/m2',physical11_units='W/m2',
        original_error_messages_retained=True,original1864_1865_Newton_scalar_component_unit_not_inferred=True,
        result_sha256=sha(result_raw),stage_sha256=sha(stage_raw),result_files=26,stage_files=16,
        original_QN_QF_model_failures_preserved=True,solver_fix_or_scientific_acceptance=False)
    (BASE/(LABEL+'-closure.json')).write_bytes(encode(closure))
    items={'original-result.tar.gz':result_raw,'stage-inventory.json':stage['stage-inventory.json']}
    items.update({'actual-result/'+name:raw for name,raw in result.items()})
    items.update({'executed-controls/'+name:raw for name,raw in stage.items() if name.startswith(('preparation/','execution/'))})
    items['HEAVY-INPUT-REFERENCES.json']=encode({name:dict(bytes=len(raw),sha256=sha(raw),included=False,scope='Prior sealed original result; referenced without duplication.')
        for name,raw in stage.items() if name.endswith('-result.tar.gz')})
    for folder in (BASE/(LABEL+'-closure'),BASE/(LABEL+'-deployment')):
        for path in sorted(folder.rglob('*')):
            if path.is_file():items[folder.name+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
    for name in (LABEL+'-readout.json',LABEL+'-closure.json',LABEL+'-stage-package.json','prepare_surface_residual_units_qr.py',
        'deploy_surface_residual_units_qr.py','collect_surface_residual_units_qr.py','package_surface_residual_units_qr.py'):
        items['local-evidence/'+name]=(BASE/name).read_bytes()
    items['README.md']=b'Actual1868F0/Stageout0,1CPU2GiB2min, savedQN/QF/PW arrays only. Zero model/evaluate/newJ/reference solve. Separate row10 prescribed-ground K constraint, other11 active-dry solver equationsWm2 and physical11energyWm2, max row/name, actual prescribed and solution ground temperature. Full original source/error-message bytes remain in prior sealed archives; this table corrects interpretation, not history. Original1864/65 Newton scalar13.757259Wm2 cannot be assigned a component/unit without its own original frame. Full26result members/raw, stage16 inventory/hash/exact controls, immutable input proofs, actual command exits and typed JSON retained. Three heavy inputs hash-reference prior original archives. Analysis F0 is not a physical solver repair or scientific score.\n'
    items['artifact-inventory.json']=encode({name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    package=dict(label=LABEL,artifacts=len(items),bytes=target.stat().st_size,sha256=sha(target.read_bytes()),
        actual_PBS_job='1868.manager',PBS_exit=0,Stageout_status=0,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

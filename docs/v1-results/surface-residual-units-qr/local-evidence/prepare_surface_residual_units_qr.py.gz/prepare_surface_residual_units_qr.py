"""Metadata-only one authorized2min existing residual-unit table job."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-residual-units-qr'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution');assert not execution.exists();execution.mkdir()
    qp=BASE/'surface-lm-path-comparison-qp-preparation'
    decoder=(qp/'analyze_saved_paths_qp.py').read_bytes();assert sha(decoder)=='5c4e82fe3c27f9febdc2aa3ea28293009d447923b71f0e0d7baf2f27f3ddd96f'
    (prep/'saved_qp_decoder.py').write_bytes(decoder);(prep/'serialization_pt.py').write_bytes((qp/'serialization_pt.py').read_bytes())
    inputs={}
    expected={
        'qn':('surface-lm-merit-qn-result.tar.gz','3f774feeb13b6556eb2228bb2d4727dd3684ec85c51dfe3a920f5085ecb14553'),
        'qf':('surface-lm-transparent-trace-qf-result.tar.gz','1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd'),
        'pw':('surface-7275-feasible-root-pw-result.tar.gz','44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')}
    for name,(path,digest) in expected.items():
        inputs[name+'-result.tar.gz']=(BASE/path).read_bytes();assert sha(inputs[name+'-result.tar.gz'])==digest
    (prep/'BINDINGS.json').write_bytes(encode(dict(input_archives=expected,decoder_sha256=sha(decoder),
        model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,units_only=True,physical_source_imported=False)))
    (prep/'README.md').write_bytes(b'One root-authorized1CPU2GiB2min compute002 PBS job, reading only bound existingQN/QF/PW arrays. Report fixed-ground constraintK separately from other11 active-dry solver equationsWm2 and physical11Wm2, actual prescribed/solution groundT, max row/name, full already-saved residual values. No model/evaluate/newJ/ref call, original source/error message/control/input modifications. Missing arrays remain missing. Original1864/65 Newton13.757259Wm2 message preserved verbatim; its component/unit is not inferred without its own original frame. Raw pickle before lossless typedJSON/NPZ.\n')
    for path in prep.glob('*.py'):ast.parse(path.read_bytes())
    (prep/'STATIC_CHECKS.json').write_bytes(encode(dict(AST_parse_exit=0,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,numerical_execution=0)))
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(prep.iterdir()) if p.is_file()}))
    old=BASE/'surface-lm-event-analysis-qm-execution';patches=[]
    for name in ('check_stage_qm.py','dispatch_analysis_qm.py'):
        raw=(old/name).read_bytes()
        changed=raw.replace(b'noahmp-surface-lm-event-analysis-qm',b'noahmp-surface-residual-units-qr').replace(b'analysis_qm',b'units_qr').replace(b'1CPU/2GiB/5min',b'1CPU/2GiB/2min')
        target=name.replace('stage_qm','stage_qr').replace('analysis_qm','units_qr')
        (execution/target).write_bytes(changed)
        patches.append(''.join(difflib.unified_diff(raw.decode().splitlines(True),changed.decode().splitlines(True),fromfile='QM/'+name,tofile='QR/'+target)))
    raw=(old/'analysis_qm.pbs').read_bytes()
    pbs=raw.replace(b'surface-lm-event-qm',b'surface-units-qr').replace(b'00:05:00',b'00:02:00').replace(b'noahmp-surface-lm-event-analysis-qm',b'noahmp-surface-residual-units-qr')
    pbs=pbs.replace(b'qm-result',b'qr-result').replace(b'check_stage_qm',b'check_stage_qr').replace(b'analyze_saved_lm_events_qm.py',b'read_saved_residual_units_qr.py')
    pbs=pbs.replace(b'--qf "$stage/qf-result.tar.gz"',b'--qn "$stage/qn-result.tar.gz" --qf "$stage/qf-result.tar.gz"')
    assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs
    (execution/'units_qr.pbs').write_bytes(pbs)
    patches.append(''.join(difflib.unified_diff(raw.decode().splitlines(True),pbs.decode().splitlines(True),fromfile='QM/analysis_qm.pbs',tofile='QR/units_qr.pbs')))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={directory+'/'+p.name:p.read_bytes() for directory,folder in [('preparation',prep),('execution',execution)] for p in folder.iterdir() if p.is_file()}
    items.update(inputs);items['stage-inventory.json']=encode({name:sha(raw) for name,raw in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    out=dict(stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),
        worker_sha256=sha((prep/'read_saved_residual_units_qr.py').read_bytes()),model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,submitted=False)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(out));print(json.dumps(out))


if __name__=='__main__':main()

"""PBS-only split-unit summaries of existing recorded residuals;0new eval/J."""
from pathlib import Path
import argparse
import hashlib
import os
import socket
import sys
import time
import traceback

if os.name=='nt' or not os.environ.get('PBS_JOBID') or socket.gethostname().split('.')[0]!='compute002':
    raise RuntimeError('Existing residual analysis requires compute002 PBS')
import numpy as np
from saved_qp_decoder import archive,unpack,exact
from serialization_pt import dump_return

sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    p=argparse.ArgumentParser()
    for name in ('qn','qf','pw'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert sys.dont_write_bytecode and np.__version__=='2.2.6'
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(key)=='1' for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    output=args.output.resolve();assert output.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not output.exists();output.mkdir()
    inputs={name:getattr(args,name) for name in ('qn','qf','pw')}
    expected=dict(qn='3f774feeb13b6556eb2228bb2d4727dd3684ec85c51dfe3a920f5085ecb14553',
        qf='1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd',
        pw='44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')
    immutable={str(path):sha(path.read_bytes()) for path in [*inputs.values(),Path(__file__),Path(__file__).with_name('saved_qp_decoder.py'),Path(__file__).with_name('serialization_pt.py')]}
    report=dict(pbs_job=os.environ['PBS_JOBID'],analysis_completed=False,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        original_error_messages_modified=False,original_model_outcomes_unchanged=True)
    start=time.monotonic();status=1
    try:
        data={name:archive(path,expected[name]) for name,path in inputs.items()}
        qn=unpack(data['qn'],'probe/external-lm-trace-qn/observed');assert len(qn['calls'])==1 and not qn['observer_errors']
        qf=unpack(data['qf'],'probe/trace/raw-observation');assert not qf['observer_errors']
        before=unpack(data['qn'],'probe/actual-row-0/first-phase-before')
        fixed=before['fixed_ground_temperature'];assert fixed is not None
        n=len(before['leaf_area']);assert n==10
        non_ground=np.r_[np.arange(n),n+1]
        solver_names=['leaf_energy['+str(i)+']' for i in range(n)]+['fixed_ground_constraint','air_water_times_LV']
        physical_names=['leaf_energy['+str(i)+']' for i in range(n)]+['ground_energy']
        rows={}
        def summarize(label,x,detail,scope):
            r=np.asarray(detail['solver_residual']);assert r.shape==(n+2,)
            result=dict(scope=scope,fixed_ground_temperature_K=float(fixed),solution_ground_temperature_K=float(x[n]),
                ground_coordinate_exact_to_prescribed_Tf=exact(np.asarray(x[n]),np.asarray(fixed)),
                ground_constraint_K=float(r[n]),ground_constraint_abs_K=float(abs(r[n])),
                ground_constraint_row=n,solver_r12_values=r.tolist(),solver_r12_units=['W/m2']*n+['K','W/m2'])
            selected=abs(r[non_ground]);which=int(non_ground[int(np.argmax(selected))])
            result['other11_solver_residual_max']=dict(abs_value=float(abs(r[which])),signed_value=float(r[which]),row=which,name=solver_names[which],unit='W/m2')
            raw=int(np.argmax(abs(r)))
            result['legacy_mixed_unit_numeric_max']=dict(abs_value=float(abs(r[raw])),row=raw,name=solver_names[raw],unit='K' if raw==n else 'W/m2',
                scope='Historical scalar only; values with different units are not a unified physical-error metric.')
            if 'layer_residual' not in detail:result['physical11']=dict(available=False,reason='Original physical layer residual not saved; no re-evaluation.')
            else:
                physical=np.asarray(detail['layer_residual']);assert physical.shape==(n+1,)
                row=int(np.argmax(abs(physical)))
                result['physical11']=dict(available=True,values_Wm2=physical.tolist(),max_abs_Wm2=float(abs(physical[row])),
                    signed_at_max_Wm2=float(physical[row]),row=row,name=physical_names[row])
            rows[label]=result
        for label,events in [('QN',qn['calls'][0]['events']),('QF',qf['events'])]:
            event=[e for e in events if e['event']=='return'][-1];values=event['locals']
            assert np.all(values['active']) and not np.any(values['phase_active'])
            detail=event['already_computed_detail'];assert exact(values['residual'],detail['solver_residual'])
            summarize(label,values['x'],detail,'Original final helper return detail; no fresh evaluate. Iteration'+str(event['iteration']))
        for seed in ('stalled_x','stored_ambient'):
            original=unpack(data['pw'],'probe/diagnostic/'+seed+'-diagnostic')
            assert exact(original['optimizer_result']['x'],original['last_attempted_x']) and exact(original['optimizer_result']['fun'],original['original_detail']['solver_residual'])
            summarize('PW_'+seed,original['last_attempted_x'],original['original_detail'],'Original saved final optimizer/detail point, posthoc only.')
        report.update(analysis_completed=True,rows=rows,units_source='Unchanged evaluate sets row10=Tf-tground; active dry10 leaf rows and fv1 air_water*LV row are W/m2. Physical layer_residual11 is separate energy closure.',
            original_newton_error_message_scope='Historical source prints W/m2 for a mixed-unit max. Original error-message bytes stay intact. 1864/65 original Newton scalar13.757259 cannot be assigned a component/unit without its own recorded frame.')
        status=0
    except BaseException:report['exception']=traceback.format_exc()
    finally:
        report['immutable_before_after_exact']=all(sha(Path(name).read_bytes())==digest for name,digest in immutable.items())
        if not report['immutable_before_after_exact']:status=1
        report.update(actual_analysis_exit=status,seconds=time.monotonic()-start)
        dump_return(output/'analysis',report)
    return status


if __name__=='__main__':sys.exit(main())

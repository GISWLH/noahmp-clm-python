"""Cover every current pytest node using EHPC CPU receipts and fresh GPU workers."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET

root=Path.cwd();out=root/'full-by-file-e';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
def verify_source():
    for name,value in manifest.items():
        if sha(root/name)!=value:raise RuntimeError('Source changed: '+name)
verify_source();started=time.monotonic()

def junit_nodes(data,file):
    document=ET.fromstring(data);nodes=[];counts={k:0 for k in ['tests','failures','errors','skipped']}
    stem=Path(file).stem
    for test in document.iter('testcase'):
        cls=test.attrib.get('classname','').split('.')
        if stem not in cls:raise ValueError('Unrecognized JUnit module: '+repr(test.attrib))
        tail=cls[cls.index(stem)+1:]+[test.attrib['name']]
        nodes.append(file+'::'+'::'.join(tail));counts['tests']+=1
        for key,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]:
            counts[key]+=int(test.find(tag) is not None)
    return nodes,counts

collection=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q'],capture_output=True,text=True)
(out/'collection.log').write_text(collection.stdout+collection.stderr)
if collection.returncode:raise RuntimeError('Current whole-suite collection failed')
all_nodes=[line.strip() for line in collection.stdout.splitlines() if line.startswith('tests/') and '::' in line]
assert len(set(all_nodes))==len(all_nodes) and all_nodes
gpu=lambda name:Path(name).name.startswith(('test_gpu','test_cuda','test_jax'))
cpu_expected={n for n in all_nodes if not gpu(n.split('::',1)[0])}
gpu_expected={n for n in all_nodes if gpu(n.split('::',1)[0])}
gpu_files=sorted({n.split('::',1)[0] for n in gpu_expected})
cpu_nodes=[];cpu_counts={k:0 for k in ['tests','failures','errors','skipped']}
archive=root/'heat-coordinate-cpu-d-evidence.tar.gz'
assert sha(archive)=='6fcfc3567d2e788118552cb964df371ef931a02dff8ffe44306c05441812a9aa'
with tarfile.open(archive) as t:
    old_manifest=json.load(t.extractfile('SOURCE_SHA256.json'))
    differences={name for name,value in manifest.items() if old_manifest.get(name)!=value}
    assert differences=={'tests/test_gpu_heat_coordinate_rounding.py'},differences
    for member in t.getmembers():
        if member.name.startswith('numpy-full/') and member.name.endswith('.xml'):
            file='tests/'+Path(member.name).stem+'.py'
            nodes,counts=junit_nodes(t.extractfile(member).read(),file)
            cpu_nodes.extend(nodes)
            for key in cpu_counts:cpu_counts[key]+=counts[key]
assert set(cpu_nodes)==cpu_expected and len(cpu_nodes)==len(cpu_expected),dict(missing=sorted(cpu_expected-set(cpu_nodes)),extra=sorted(set(cpu_nodes)-cpu_expected))
assert cpu_counts==dict(tests=685,failures=0,errors=0,skipped=0),cpu_counts
selection=dict(scope='Every current collected node: NumPy CPU files on EHPC PBS24, GPU/JAX/CUDA files each in a fresh xuanze pytest process. Not a single-process full-suite result.',
    source_manifest_sha256=sha(root/'SOURCE_SHA256.json'),tool_sha256=sha(Path(__file__)),python=sys.version,
    all_nodes=all_nodes,gpu_files=gpu_files,cpu_counts=cpu_counts,cpu_receipt_archive_sha256=sha(archive),
    cpu_source_differences=sorted(differences))
(out/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
results=[];covered=set(cpu_nodes)
def save(active=None):
    report=dict(scope=selection['scope'],status='running',seconds=time.monotonic()-started,
        collected_nodes=len(all_nodes),covered_nodes=len(covered),gpu_files_completed=len(results),gpu_files_total=len(gpu_files),
        active=active,cpu_counts=cpu_counts,results=results)
    temporary=out/'progress.json.tmp';temporary.write_text(json.dumps(report,indent=2)+'\n');os.replace(temporary,out/'progress.json')
save()
for file in gpu_files:
    verify_source();name=Path(file).stem;begin=time.monotonic();xml=out/(name+'.xml')
    command=[sys.executable,'-m','pytest',file,'-q','-s','--junitxml='+str(xml)]
    with (out/(name+'.log')).open('wb') as log:
        process=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        save(dict(file=file,pid=process.pid,started_unix=time.time(),command=command))
        code=process.wait()
    row=dict(file=file,pid=process.pid,returncode=code,seconds=time.monotonic()-begin)
    try:
        nodes,counts=junit_nodes(xml.read_bytes(),file)
        expected={n for n in gpu_expected if n.split('::',1)[0]==file}
        row.update(counts=counts,node_coverage_exact=set(nodes)==expected and len(nodes)==len(expected),nodes=nodes)
        if row['node_coverage_exact']:covered.update(nodes)
        row['passed']=code==0 and row['node_coverage_exact'] and counts['failures']==counts['errors']==counts['skipped']==0
    except Exception as error:row.update(passed=False,report_error=repr(error))
    results.append(row);save();print(json.dumps({k:v for k,v in row.items() if k!='nodes'}),flush=True)
verify_source();complete=covered==set(all_nodes) and all(r['passed'] for r in results)
report=dict(scope=selection['scope'],status='complete' if complete else 'failed',seconds=time.monotonic()-started,
    source_unchanged=True,all_node_coverage_exact=covered==set(all_nodes),collected_nodes=len(all_nodes),covered_nodes=len(covered),cpu_counts=cpu_counts,results=results)
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if complete else 1)

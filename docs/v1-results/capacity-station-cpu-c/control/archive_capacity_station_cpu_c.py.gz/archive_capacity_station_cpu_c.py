from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'capacity-station-cpu-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'pbs-exit.txt').read_text().strip()=='0'
rec=json.loads((r/'receipt.json').read_text());assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=1009,failures=0,errors=0,skipped=0)
assert rec['source_manifest_sha256']==sha(r/'SOURCE_SHA256.json')=='609c39cc071899d0d4a3a9102babf8908fe679797337d3f9c01bc3949af03dd9'
assert rec['xml_sha256']==sha(r/'cpu-full.xml')
a=b/'capacity-station-final-c-source.tar.gz';assert sha(a)=='7341089ec7d992674e0976272dd0b4940e082f9baa7b887649ee1d130a3b4fe5'
archive=b/'capacity-station-cpu-c-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    tf.add(a,arcname='source/'+a.name,recursive=False)
    for name in ['archive_capacity_station_cpu_c.py','dispatch_capacity_station_cpu_c.py']:tf.add(b/name,arcname='control/'+name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,receipt=rec)))

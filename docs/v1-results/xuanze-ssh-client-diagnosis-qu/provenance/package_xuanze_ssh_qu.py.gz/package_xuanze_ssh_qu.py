"""Freeze readonly SSH diagnostic logs after bounded credential screening."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from inspect_pbs_recovery_qr import scan
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent;LABEL='xuanze-ssh-client-diagnosis-qu'
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
folder=BASE/LABEL;items={p.name:p.read_bytes() for p in folder.iterdir() if p.is_file()}
readout=json.loads(items['readout.json'])
assert len(readout['probes'])==2 and all(p['receipt']['actual_exit']==0 and not p['receipt']['timed_out'] for p in readout['probes'])
assert all(all(p['handshake_markers'].values()) for p in readout['probes'])
for probe in readout['probes']:
    label='system-direct' if probe['binary'].lower().startswith('c:\\windows') else 'alternate-direct'
    assert sha(items[label+'-debug.log'])==probe['debug_log_sha256']
for suffix in ('prelaunch','prelaunchAfterSSHClose','prelaunchAfterCooldown'):
    stem='drainage-default-geometry-pc-d-'+suffix
    for ending in ('.stdout','.stderr','-exit.json'):
        items['original-preflights/'+stem+ending]=(BASE/(stem+ending)).read_bytes()
    row=json.loads(items['original-preflights/'+stem+'-exit.json']);assert row['actual_exit']==255
items['README.md']=('''# Xuanze SSH client diagnosis QU

Readonly transport diagnosis only, no remote service/configuration modification or GPU/model call. Three original metadata preflights returned255 with Connection closed and remain verbatim. The NAS route failure is separate QT evidence, not replaced here.

Get-Command found system OpenSSH9.5p2 as the only ssh on PATH. Existing configured Git installations provide10.3p1 (E:/Git) and10.2p1 (Codex bundled Git). All three versions were queried; only system9.5 and one version-distinct existing alternate10.3 made a direct true connection. Original config was explicitly passed with-F; both used BatchMode,StrictHostKeyChecking=yes,explicit original known_hosts,ConnectTimeout12 and total35s. Both actual exits were0, with TCP,banner,KEX,hostkey and authentication observed. This confirms restored access at observation time, not whether the preceding failure originated in the client/server/network. The alternate was not needed to replace the working system route and was not used for PC-d deployment.

Configured private identity existence was checked without reading its contents. configuration-metadata's key_contents_read=false refers to this private identity; a SHA was computed from the public known_hosts file to bind strong host-key checking. Full effective-config stdout was never saved. All published payloads passed bounded credential-pattern screening; no matched content is printed/stored and arbitrary-secret detection is not guaranteed.

The initial combined Get-Command query returned1 because optional plink was absent, despite valid ssh/scp/git results and empty stderr. That local failure is preserved. The completion helper reused its actual inventory rather than rerunning remote work. SSH-PID exits came from actual communicate/wait; no background diagnostic connection remained. No client defect or performance comparison is claimed.
''').encode()
for name in ('diagnose_xuanze_ssh_client_qu.py','complete_xuanze_ssh_client_qu.py',Path(__file__).name):items['provenance/'+name]=(BASE/name).read_bytes()
assert not any(any(scan(raw).values()) for raw in items.values()),'Credential pattern detected; content not printed'
items['credential-pattern-screening.json']=encode(dict(published_payloads=len(items),detected_pattern_matches=0,private_identity_contents_read=False,
    full_effective_config_persisted=False,matched_content_printed=False,arbitrary_secret_detection_guaranteed=False))
items['artifact-inventory.json']=encode({n:dict(sha256=sha(v),bytes=len(v)) for n,v in sorted(items.items())})
target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w') as archive:
        for name,raw in sorted(items.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
assert files(target.read_bytes())==items
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
    scope='Readonly SSH phase/client/config-existence diagnostic, system and one existing alternate actual0, three earlier255 retained; cause not established, no remote/model/GPU mutation.')
(BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))

"""One readonly system-SSH handshake diagnostic, no remote/service mutation."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

BASE=Path(__file__).resolve().parent
DEST=BASE/'xuanze-ssh-client-diagnosis-qu'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
save=lambda name,value:(DEST/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

def run(label,command,timeout=15):
    started=time.time();p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timed_out=False
    try:out,err=p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out=True;p.kill();out,err=p.communicate()
    (DEST/(label+'.stdout')).write_bytes(out);(DEST/(label+'.stderr')).write_bytes(err)
    row=dict(command=command,pid=p.pid,started_unix=started,seconds=time.time()-started,actual_exit=p.returncode,
        timed_out=timed_out,total_timeout_seconds=timeout,stdout_sha256=sha(out),stderr_sha256=sha(err))
    save(label+'-exit.json',row);return row,out,err

def main():
    assert not DEST.exists();DEST.mkdir()
    script="Get-Command ssh,scp,git,plink -All -ErrorAction SilentlyContinue | Select-Object Name,CommandType,Source,Path | ConvertTo-Json -Depth 3"
    command=['powershell','-NoProfile','-Command',script]
    inventory,raw,_=run('binary-inventory',command)
    assert inventory['actual_exit']==0
    entries=json.loads(raw);entries=[entries] if isinstance(entries,dict) else entries
    system=Path('C:/Windows/System32/OpenSSH/ssh.exe');assert system.is_file()
    candidates={str(system)}
    for item in entries:
        if item['Name'].lower()=='ssh.exe':candidates.add(item['Path'])
        if item['Name'].lower()=='git.exe':
            sibling=Path(item['Path']).parent.parent/'usr/bin/ssh.exe'
            if sibling.is_file():candidates.add(str(sibling))
    versions={}
    for i,name in enumerate(sorted(candidates)):
        row,out,err=run('version-'+str(i),[name,'-V'])
        versions[name]=dict(actual_exit=row['actual_exit'],version=(out+err).decode(errors='replace').strip())
    config=Path('C:/Users/hhuwl/.ssh/config');assert config.is_file()
    # Effective config stdout is held in memory only, never persisted wholesale.
    effective=subprocess.run([str(system),'-G','-F',str(config),'xuanze-neiwang'],capture_output=True,timeout=15)
    selected={};identities=[]
    allow={'hostname','port','user','hostkeyalias','userknownhostsfile','globalknownhostsfile','controlmaster','controlpath','proxyjump'}
    for line in effective.stdout.decode(errors='replace').splitlines():
        key,_,value=line.partition(' ')
        if key in allow:selected[key]=value
        if key=='identityfile':
            expanded=value.replace('%d',str(Path.home())).strip('"');path=Path(expanded).expanduser()
            identities.append(dict(configured_path=value,exists=path.is_file()))
    selected['proxycommand_present']=any(line.startswith('proxycommand ') and line!='proxycommand none' for line in effective.stdout.decode(errors='replace').splitlines())
    save('configuration-metadata.json',dict(original_config_path=str(config),original_config_sha256=sha(config.read_bytes()),
        effective_config_actual_exit=effective.returncode,effective_config_stdout_sha256=sha(effective.stdout),
        effective_config_stderr_sha256=sha(effective.stderr),selected_nonsecret_fields=selected,identityfile_existence=identities,
        GIT_SSH_present='GIT_SSH' in os.environ,GIT_SSH_COMMAND_present='GIT_SSH_COMMAND' in os.environ,key_contents_read=False))
    assert effective.returncode==0
    debug=DEST/'system-direct-debug.log';assert not debug.exists()
    row,out,err=run('system-direct',[str(system),'-vv','-E',str(debug),'-F',str(config),'-o','BatchMode=yes',
        '-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=12','-o','ConnectionAttempts=1','-T','xuanze-neiwang','true'],35)
    log=debug.read_bytes() if debug.exists() else b''
    markers={
        'TCP_established':b'Connection established' in log,
        'local_version_sent':b'Local version string' in log,
        'remote_protocol_banner_received':b'Remote protocol version' in log,
        'KEXINIT_sent':b'SSH2_MSG_KEXINIT sent' in log,
        'KEXINIT_received':b'SSH2_MSG_KEXINIT received' in log,
        'server_host_key_seen':b'Server host key:' in log,
        'auth_methods_received':b'Authentications that can continue:' in log,
        'authenticated':b'Authenticated to ' in log,
    }
    report=dict(binary_versions=versions,effective_configuration=selected,identityfile_existence=identities,
        system_direct=row,handshake_markers=markers,debug_log_sha256=sha(log),debug_log_bytes=len(log),
        remote_command='true',remote_modifications=0,model_calls=0,GPU_launches=0,
        interpretation='Markers identify the last observed handshake phase only; server/client/network root cause is not established.')
    save('readout.json',report);print(json.dumps(report,indent=2))

if __name__=='__main__':main()

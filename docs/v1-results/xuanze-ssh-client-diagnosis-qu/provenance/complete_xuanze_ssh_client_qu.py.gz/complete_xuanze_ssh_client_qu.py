"""Continue after optional-plink inventory returned1; unique direct+alternate diagnostics."""
from pathlib import Path
import json
import os
import subprocess
from diagnose_xuanze_ssh_client_qu import DEST,sha,save,run

def main():
    entries=json.loads((DEST/'binary-inventory.stdout').read_bytes())
    inventory=json.loads((DEST/'binary-inventory-exit.json').read_bytes())
    assert inventory['actual_exit']==1 and (DEST/'binary-inventory.stderr').read_bytes()==b''
    assert any(row['Name'].lower()=='ssh.exe' for row in entries)
    system=Path('C:/Windows/System32/OpenSSH/ssh.exe');candidates={str(system)}
    for item in entries:
        if item['Name'].lower()=='ssh.exe':candidates.add(item['Path'])
        if item['Name'].lower()=='git.exe':
            sibling=Path(item['Path']).parent.parent/'usr/bin/ssh.exe'
            if sibling.is_file():candidates.add(str(sibling))
    versions={}
    for i,name in enumerate(sorted(candidates)):
        assert not (DEST/('version-'+str(i)+'-exit.json')).exists()
        row,out,err=run('version-'+str(i),[name,'-V'])
        versions[name]=dict(actual_exit=row['actual_exit'],version=(out+err).decode(errors='replace').strip())
    config=Path('C:/Users/hhuwl/.ssh/config');assert config.is_file()
    effective=subprocess.run([str(system),'-G','-F',str(config),'xuanze-neiwang'],capture_output=True,timeout=15)
    selected={};identities=[]
    allow={'hostname','port','user','hostkeyalias','userknownhostsfile','globalknownhostsfile','controlmaster','controlpath','proxyjump'}
    effective_lines=effective.stdout.decode(errors='replace').splitlines()
    for line in effective_lines:
        key,_,value=line.partition(' ')
        if key in allow:selected[key]=value
        if key=='identityfile':
            path=Path(value.replace('%d',str(Path.home())).strip('"')).expanduser()
            identities.append(dict(configured_path=value,exists=path.is_file()))
    selected['proxycommand_present']=any(l.startswith('proxycommand ') and l!='proxycommand none' for l in effective_lines)
    known=Path(selected['userknownhostsfile'].split()[0].replace('%d',str(Path.home())).strip('"')).expanduser()
    assert known.is_file()
    save('configuration-metadata.json',dict(original_config_path=str(config),original_config_sha256=sha(config.read_bytes()),
        effective_config_actual_exit=effective.returncode,effective_config_stdout_sha256=sha(effective.stdout),
        effective_config_stderr_sha256=sha(effective.stderr),selected_nonsecret_fields=selected,identityfile_existence=identities,
        explicit_known_hosts_path=str(known),explicit_known_hosts_sha256=sha(known.read_bytes()),
        GIT_SSH_present='GIT_SSH' in os.environ,GIT_SSH_COMMAND_present='GIT_SSH_COMMAND' in os.environ,key_contents_read=False,
        initial_inventory_exit1_preserved=True,initial_inventory_optional_missing_tool='plink'))
    assert effective.returncode==0
    probes=[]
    alternatives=[name for name in versions if str(Path(name)).lower()!=str(system).lower() and versions[name]['actual_exit']==0 and versions[name]['version']!=versions[str(system)]['version']]
    # At most one pre-existing alternate, derived from actual configured Git path.
    chosen=[('system-direct',str(system))]
    preferred=[name for name in alternatives if str(name).replace('\\','/').lower().startswith('e:/git/')]
    if alternatives:chosen.append(('alternate-direct',(preferred or alternatives)[0]))
    for label,binary in chosen:
        debug=DEST/(label+'-debug.log');assert not debug.exists()
        row,out,err=run(label,[binary,'-vv','-E',str(debug),'-F',str(config),'-o','BatchMode=yes',
            '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(known),'-o','ConnectTimeout=12',
            '-o','ConnectionAttempts=1','-T','xuanze-neiwang','true'],35)
        log=debug.read_bytes() if debug.exists() else b''
        markers={name:needle in log for name,needle in {
            'TCP_established':b'Connection established','local_version_sent':b'Local version string',
            'remote_protocol_banner_received':b'Remote protocol version','KEXINIT_sent':b'SSH2_MSG_KEXINIT sent',
            'KEXINIT_received':b'SSH2_MSG_KEXINIT received','server_host_key_seen':b'Server host key:',
            'auth_methods_received':b'Authentications that can continue:','authenticated':b'Authenticated to '}.items()}
        probes.append(dict(binary=binary,receipt=row,handshake_markers=markers,debug_log_sha256=sha(log),debug_log_bytes=len(log)))
    report=dict(binary_versions=versions,effective_configuration=selected,identityfile_existence=identities,
        explicit_known_hosts=str(known),probes=probes,remote_command='true',remote_modifications=0,model_calls=0,GPU_launches=0,
        initial_local_inventory_exit1_preserved=True,
        interpretation='Last observed handshake phase only; server/client/network cause not established. At most one existing version-distinct alternate was tried with original config and strict known-key checking.')
    save('readout.json',report);print(json.dumps(report,indent=2))

if __name__=='__main__':main()

from pathlib import Path
import ast,datetime,hashlib,json,re,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-material-event-b';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'summary.json').read_text());assert d['status']=='complete'
rec=json.loads((r/'test_gpu_canopy_phase_surface-receipt.json').read_text());assert rec['counts']==dict(tests=4,failures=0,errors=0,skipped=0) and rec['passed']
text=(r/'test_gpu_canopy_phase_surface.log').read_text();same=[];budgets=[];maximum={}
for line in text.splitlines():
 if line.startswith('phase surface same '):
  token=line.rsplit(' ',1)[1];same.append(float(token) if token not in ['False','True'] else float(token=='True'))
 if line.startswith('phase surface budgets ') or line.startswith('CUDA phase surface budgets '):budgets.append(ast.literal_eval(line[line.index('{'):]))
 match=re.match(r"phase surface <class 'numpy.float64'> [0-9]+ (.*)",line)
 if match:
  row=ast.literal_eval(match[1])
  for name in ['h','le','surface_temperature','leaf_temperature','ground_heat']:
   value=row[name];maximum[name]=max(maximum.get(name,0.),max(value) if isinstance(value,list) else value)
assert same and maximum
value=dict(scope='Actual current493 integrated4, all original phases/barriers/source and actual exits0. Phase8 separately preserved. Complete target12, not full327 GPU/1135 or annual/spinup/scientific acceptance.',same_precision_maximum_absolute=max(same),numpy_float64_maximum_absolute_difference=maximum,budget_rows=budgets,log_sha256=sha(r/'test_gpu_canopy_phase_surface.log'),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),target_seconds=d['seconds'],integrated_seconds=d['results'][1]['seconds'])
(r/'integrated-numerical-summary.json').write_text(json.dumps(value,indent=2)+'\n')
a=b/'material-event-gpu-integrated-b-evidence.tar.gz';assert not a.exists();names=['test_gpu_canopy_phase_surface'+suffix for suffix in ['.log','.xml','-receipt.json','-expected.json']]+['summary.json','integrated-numerical-summary.json']
with tarfile.open(a,'w:gz') as t:
 for name in names:t.add(r/name,arcname=name,recursive=False)
 t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
 t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
print(json.dumps(dict(**value,archive_sha256=sha(a),files=len(names)+1)))

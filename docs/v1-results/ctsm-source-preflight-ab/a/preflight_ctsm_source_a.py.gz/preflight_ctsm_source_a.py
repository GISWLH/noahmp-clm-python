from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-source-preflight-a';scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-source-preflight';scratch.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic();stages=[];failure=None;value={}
try:
    packages=[(base/'ctsm-portable-env-a.tar.gz','8f1d5ba12ed58a68e18293c182991d84cacbccd53f7dd8c86e06f687ea719769',scratch/'toolchain'),(base/'ctsm-reference-source-bundle-a.tar.gz','f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',scratch)]
    for archive,digest,dest in packages:
        assert sha(archive)==digest
        dest.mkdir(exist_ok=True)
        with tarfile.open(archive) as t:t.extractall(dest,filter='data')
    source=scratch/'CTSM';prefix=scratch/'toolchain';lock=json.loads((scratch/'UPSTREAM_SOURCE_LOCK.json').read_text())
    verify=lambda:all(sha(scratch/n)==v for n,v in lock['files'].items())
    assert verify()
    env=os.environ.copy()
    for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
    env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',CONDA_PREFIX=str(prefix),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    def run(label,args):
        start=time.monotonic();p=subprocess.run(args,cwd=source,env=env,capture_output=True,text=True,timeout=60)
        (scratch/(label+'.stdout.txt')).write_text(p.stdout);(scratch/(label+'.stderr.txt')).write_text(p.stderr)
        stages.append(dict(stage=label,command=[str(v) for v in args],returncode=p.returncode,seconds=time.monotonic()-start));return p.returncode
    assert run('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')])==0
    for name in ['create_newcase','query_config']:
        path=source/'cime/scripts'/name
        assert path.is_file(),str(path)
        run(name+'-help',[str(prefix/'bin/python'),str(path),'--help'])
    metadata=dict(top_level_paths=sorted(p.name for p in source.iterdir()),machine_config_files=[p.relative_to(source).as_posix() for p in source.rglob('config_machines.xml')],
        files_config_files=[p.relative_to(source).as_posix() for p in source.rglob('config_files.xml')],source_files=len(lock['files']),source_unchanged=verify(),sources=lock['sources'])
    excerpts={}
    for name in ['cime/CIME/XML/machines.py','cime/CIME/XML/files.py','cime/scripts/create_newcase']:
        lines=(source/name).read_text().splitlines();selected=set()
        for k,line in enumerate(lines):
            if any(v in line for v in ['mach_dir','machine_dir','extra_machines','CIME_MODEL','get_src_root','SRCROOT','CIME_CONFIG']):selected.update(range(max(0,k-2),min(len(lines),k+3)))
        excerpts[name]=[dict(line=k+1,text=lines[k]) for k in sorted(selected)]
    (scratch/'build-configuration-excerpts.json').write_text(json.dumps(excerpts,indent=2)+'\n');(scratch/'layout.json').write_text(json.dumps(metadata,indent=2)+'\n')
    assert verify();value.update(metadata)
except BaseException as e:failure=type(e).__name__+': '+str(e)
value.update(scope='EHPC offline pinned source layout/CIME command help only; no custom machine, official compilation/model output or science acceptance yet.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,failure=failure,seconds=time.monotonic()-begun)
(root/'preflight.json').write_text(json.dumps(value,indent=2)+'\n')
with tarfile.open(root/'preflight-artifacts.tar.gz','w:gz') as t:
    for p in sorted(scratch.iterdir()):
        if p.is_file() and p.name!='UPSTREAM_SOURCE_LOCK.json':t.add(p,arcname=p.name,recursive=False)
print(json.dumps(value),flush=True)
raise SystemExit(0 if failure is None and all(s['returncode']==0 for s in stages) else 1)

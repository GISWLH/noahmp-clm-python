from pathlib import Path
import hashlib,io,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pairs=[];extra=[]
for label,job,expected_code in [('a','109.manager','1'),('b','110.manager','0')]:
    root=base/('ctsm-source-preflight-'+label);r=json.loads((root/'preflight.json').read_text());assert r['pbs_job']==job and (root/'pbs-exit.txt').read_text().strip()==expected_code
    if label=='a':assert r['failure'].startswith('FileNotFoundError:') and all(v['returncode']==0 for v in r['stages'])
    else:assert r['failure'] is None and r['source_unchanged'] and r['source_files']==2930 and all(v['returncode']==0 for v in r['stages'])
    for name in ['preflight_ctsm_source_'+label+'.py','ctsm_source_preflight_'+label+'.pbs','preflight.json','preflight.log','node.txt','pbs-exit.txt']:pairs.append((root/name,label+'/'+name))
    with tarfile.open(root/'preflight-artifacts.tar.gz') as t:
        for name in ['create_newcase-help.stdout.txt','create_newcase-help.stderr.txt','query_config-help.stdout.txt','query_config-help.stderr.txt']+(['layout.json'] if label=='b' else []):
            extra.append((label+'/'+name,t.extractfile(name).read()))
bundle=base/'ctsm-reference-source-bundle-a.tar.gz';assert sha(bundle)=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
with tarfile.open(bundle) as t:extra.append(('UPSTREAM_SOURCE_LOCK.json',t.extractfile('UPSTREAM_SOURCE_LOCK.json').read()))
pairs.append((Path(__file__),'archive_ctsm_source_preflight_ab.py'))
dest=base/'ctsm-source-preflight-ab-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for path,name in pairs:t.add(path,arcname=name,recursive=False)
    for name,data in extra:
        member=tarfile.TarInfo(name);member.size=len(data);t.addfile(member,io.BytesIO(data))
print(json.dumps(dict(files=len(pairs)+len(extra),sha256=sha(dest),scope='EHPC PBS109 original diagnostic path failure and PBS110 successful original2930-file source layout/CLI-help checks. No upstream implementation excerpts, compiled model, official physics output or scientific acceptance.')))

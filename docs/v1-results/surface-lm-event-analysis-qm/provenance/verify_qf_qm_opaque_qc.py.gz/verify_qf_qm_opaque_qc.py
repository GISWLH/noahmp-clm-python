"""Independent stdlib-only QF/QM hashes and opaque NPY payload verification."""
import json
from pathlib import Path

from package_surface_feasible_root_pw import opaque_packet
from package_surface_reference_pt import files,sha,encode,scalar_tree

BASE=Path(__file__).resolve().parent


def main():
    policies={
        'QF':dict(label='surface-lm-transparent-trace-qf',result='1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd',stage='0f28c81c34d6909cb2b2812136395d2c5215004950d469dcc0c0879adafe2d04',worker_exit=1),
        'QM':dict(label='surface-lm-event-analysis-qm',result='74eea2098ab3a0cd9992e694596c8f3de51f99368470a7d2d0308385fe3ba416',stage='9195c974fe512fa23509e6cd6f15df5c25631c83cac2136078e3340fed8dbcb9',worker_exit=0)}
    results={};packets={};stages={};verification={}
    for tag,policy in policies.items():
        result_raw=(BASE/(policy['label']+'-result.tar.gz')).read_bytes();stage_raw=(BASE/(policy['label']+'-stage.tar.gz')).read_bytes()
        assert sha(result_raw)==policy['result'] and sha(stage_raw)==policy['stage']
        result=files(result_raw,directories=True);stage=files(stage_raw);index=json.loads(stage['stage-inventory.json'])
        assert set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
        assert result['stage-inventory.json']==stage['stage-inventory.json']
        assert result['worker-exit.txt'].strip()==result['pbs-command-exit.txt'].strip()==str(policy['worker_exit']).encode()
        assert result['setup-exit.txt'].strip()==result['stage-after-exit.txt'].strip()==b'0'
        for name in ('stage-before.json','stage-after.json'):
            check=json.loads(result[name]);assert check['passed'] and check['actual']==check['expected']==index and not check['mismatches']
        counts={};fortran={}
        for name,raw in result.items():
            if not name.endswith('.json'):continue
            meta=json.loads(raw);stem=name.removesuffix('.json')
            if isinstance(meta,dict) and 'tree' in meta and stem+'.npz' in result:
                counts[stem],fortran[stem]=opaque_packet(result[stem+'.npz'],meta)
                if 'pickle_sha256' in meta:assert sha(result[stem+'.pkl'])==meta['pickle_sha256']
        verification[tag]=dict(result_sha256=sha(result_raw),stage_sha256=sha(stage_raw),result_files=len(result),stage_files=len(stage),typed_packets=len(counts),opaque_array_payloads=sum(counts.values()),per_packet_arrays=counts,fortran_members={n:v for n,v in fortran.items() if v},actual_worker_exit=policy['worker_exit'],actual_PBS_command_exit=policy['worker_exit'],setup_and_stage_after_exit=0,stage_before_after_exact=True)
        results[tag]=result;stages[tag]=stage;packets[tag]=counts
    qf=results['QF'];qm=results['QM'];source=files(stages['QF']['source.tar.gz']);manifest=json.loads(source['SOURCE_SHA256.json'])
    assert len(manifest)==584 and set(source)==set(manifest)|{'SOURCE_SHA256.json'} and all(sha(source[n])==h for n,h in manifest.items())
    before=json.loads(qf['probe/trace/source-before.json']);after=json.loads(qf['probe/trace/source-after.json']);assert before==after==manifest
    kw_before=json.loads(qf['probe/trace/kwargs-before.json']);kw_after=json.loads(qf['probe/trace/kwargs-after.json']);assert kw_before['tree']==kw_after['tree']
    assert qf['probe/trace/kwargs-before.pkl']==qf['probe/trace/kwargs-after.pkl']
    identity=scalar_tree(json.loads(qf['probe/trace/replay-identity.json'])['tree']);receipt=json.loads(qf['probe/receipt.json'])
    assert identity['conclusive'] and identity['source_unchanged'] and identity['inputs_unchanged'] and identity['original_rescue_record_exact']
    assert identity['original_model_returned'] is False and identity['original_model_exception_preserved'] and identity['expected_original_model_exit']==1
    assert identity['phase_calls']==1 and identity['extra_evaluate_calls']==identity['extra_Jacobian_computations']==0
    assert identity['source_before_sha256']==sha(qf['probe/trace/source-before.json']) and identity['source_after_sha256']==sha(qf['probe/trace/source-after.json'])
    assert identity['kwargs_before_pickle_sha256']==sha(qf['probe/trace/kwargs-before.pkl']) and identity['kwargs_after_pickle_sha256']==sha(qf['probe/trace/kwargs-after.pkl'])
    assert receipt['pbs_job']=='1844.manager' and receipt['wrapper_actual_exit']==1 and receipt['diagnostic_conclusive'] and receipt['original_physical_failure_preserved'] and not receipt['physical_model_succeeded']
    observed=json.loads(qf['probe/trace/raw-observation.json'])['tree']['items'];assert len(observed['events']['items'])==367
    old_raw=(BASE/'surface-dry-lm-py-c-result.tar.gz').read_bytes();assert sha(old_raw)=='c899a551629463dc3f4b159756f762df2f1fd91f23a4527091e24bf27a48b61d'
    old=files(old_raw,directories=True);old_json=old['probe/actual-row-0/actual-observation.json']
    assert old_json==(BASE/'surface-dry-lm-py-c-closure/readable/probe/actual-row-0/actual-observation.json').read_bytes()
    old_meta=json.loads(old_json);old_arrays,old_fortran=opaque_packet(old['probe/actual-row-0/actual-observation.npz'],old_meta)
    assert sha(old['probe/actual-row-0/actual-observation.pkl'])==old_meta['pickle_sha256']
    def normalize(v):
        if isinstance(v,dict):return {n:normalize(x) for n,x in v.items() if not (v.get('kind')=='array' and n=='key')}
        if isinstance(v,list):return [normalize(x) for x in v]
        return v
    assert normalize(observed['helper_returns'])==normalize(old_meta['tree']['items']['rescue_records'])
    analysis=scalar_tree(json.loads(qm['probe/analysis.json'])['tree'])
    assert analysis['pbs_job']=='1854.manager' and analysis['analysis_completed'] and analysis['actual_analysis_exit']==0
    assert analysis['original_QF_job']=='1844.manager' and analysis['original_QF_model_exit']==1 and analysis['original_failure_preserved']
    assert analysis['model_calls']==analysis['evaluate_calls']==analysis['new_Jacobian_computations']==0 and not analysis['original_data_modified']
    assert analysis['immutable_before_after_exact'] and not analysis['nonlinear_stationarity_proved'] and not analysis['stable_formula_solver_fix_proved']
    assert analysis['event_count']==367 and analysis['iterations_analyzed']==31
    record=dict(passed=True,scope='Independent stdlib archive/hash/JSON/opaque NPY header, shape, dtype, C-payload verification; no NumPy, unpickle, model, pytest or numerical array decode',
                results=verification,QF_source584_exact=True,QF_kwargs_before_after_exact=True,QF_events=367,QF_helper_return_all_fields_and_final_x_exact_to_actual1822_after_array_key_normalization=True,
                original1822_result_sha256=sha(old_raw),original1822_opaque_arrays=old_arrays,original1822_fortran_members=old_fortran,
                QM_actual_analysis_worker_and_PBS_command_exit=0,QM_original_QF_model_exit1_retained=True,QM_model_evaluate_Jacobian_calls=0,model_repaired=False,scientific_acceptance=False,
                fortran_policy='shape/itemsize-directed opaque byte permutation only; no numerical values decoded',verifier_sha256=sha(Path(__file__).read_bytes()))
    target=BASE/'verify_qf_qm_opaque_qc.json';assert not target.exists();target.write_bytes(encode(record));print(json.dumps(record))


if __name__=='__main__':main()

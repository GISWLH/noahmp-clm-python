"""Metadata-only QF actual failure and QM saved-analysis evidence archives."""
import gzip
import io
import json
from pathlib import Path
import re
import tarfile

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent


def main():
    verification=json.loads((BASE/'verify_qf_qm_opaque_qc.json').read_bytes());assert verification['passed']
    for tag,label,job,exitcode in [('QF','surface-lm-transparent-trace-qf','1844.manager',1),('QM','surface-lm-event-analysis-qm','1854.manager',0)]:
        proof=verification['results'][tag];raw=(BASE/(label+'-result.tar.gz')).read_bytes();stage_raw=(BASE/(label+'-stage.tar.gz')).read_bytes()
        assert sha(raw)==proof['result_sha256'] and sha(stage_raw)==proof['stage_sha256']
        original=files(raw,directories=True);stage=files(stage_raw);index=json.loads(stage['stage-inventory.json'])
        assert set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
        closure=BASE/(label+'-closure');commands=json.loads((closure/'commands.json').read_bytes())
        for name,v in commands.items():
            assert v['actual_exit']==0
            assert sha((closure/(name+'.stdout')).read_bytes())==v['stdout_sha256'] and sha((closure/(name+'.stderr')).read_bytes())==v['stderr_sha256']
        qstat=(closure/'qstat.stdout').read_text();assert 'Job Id: '+job in qstat and re.search(r'job_state = F\b',qstat) and 'Exit_status = '+str(exitcode) in qstat and 'Stageout_status = 0' in qstat
        assert (closure/'pbs-exit.stdout').read_bytes().strip()==str(exitcode).encode() and (closure/'result-hash.stdout').read_text().split()[0]==sha(raw)
        assert original['worker-exit.txt'].strip()==original['pbs-command-exit.txt'].strip()==str(exitcode).encode()
        items={'actual-result/'+n:b for n,b in original.items()};items['original-result.tar.gz']=raw
        omitted={}
        for name,b in stage.items():
            if name.endswith('.tar.gz'):omitted[name]=dict(sha256=sha(b),bytes=len(b),reference='Unchanged local original '+label+'-stage.tar.gz member '+name)
            else:items['executed-stage-controls/'+name]=b
        if tag=='QF':
            source=files(stage['source.tar.gz']);items['source-SOURCE_SHA256.json']=source['SOURCE_SHA256.json']
        items['executed-stage-original-hash.json']=encode(dict(sha256=sha(stage_raw),bytes=len(stage_raw),all_stage_members={n:dict(sha256=sha(b),bytes=len(b)) for n,b in stage.items()},omitted_input_archives=omitted,scope='Original compressed execution stage/input archives remain unmodified and are hash-referenced to avoid duplicating prior source/input packages. Complete actual result bytes and all controls are included.'))
        for directory in [closure,BASE/(label+'-deployment')]:
            for path in sorted(directory.iterdir()):
                if path.is_file():items['observations/'+directory.name+'/'+path.name]=path.read_bytes()
        for name in ['verify_qf_qm_opaque_qc.py','verify_qf_qm_opaque_qc.json','package_qf_qm_opaque_qc.py',label+'-stage-package.json',label+'-closure.json']:
            items['provenance/'+name]=(BASE/name).read_bytes()
        if tag=='QM':
            readout=(BASE/(label+'-readout.json')).read_bytes();items['readout.json']=readout
            scope='QM1854 actual F0/Stageout0 offline saved-event arithmetic analysis only. Original QF1844 model failure1 is explicitly retained. No model/evaluate/Jacobian/GPU calls, no changed data, no demonstrated solver fix or nonlinear stationarity. Complete31-row results and raw344 array payloads are retained; these existing EHPC calculations were not rerun during packaging.'
        else:
            readout=encode(json.loads((BASE/(label+'-closure.json')).read_bytes()));items['readout.json']=readout
            scope='QF1844 actual F1/Stageout0 original unchanged phase failure, separate diagnostic_conclusive true. One original phase attempt with367 transparent observed events, no extra evaluate/Jacobian/column/GPU calls. Complete original helper-return fields and finalx match actual1822 after removing descriptor key paths only. No model repair or physical acceptance is claimed.'
        items['SCOPE.md']=(scope+'\n\nIndependent stdlib-only verifier checks actual original result/stage hashes, all typed packet NPY dtype/shape/opaque C-payload hashes and original pickle byte hashes without unpickling. QF source584/kwargs/stage remain exact; QM data remain exact. Original command exits, qstat F/Stageout0, stderr/stdout and failed-model records are preserved. Source/input archives are explicitly hash-referenced, not silently fabricated or replaced.\n').encode()
        items['verification.json']=encode(dict(**proof,independent_verification_sha256=sha((BASE/'verify_qf_qm_opaque_qc.json').read_bytes()),actual_job=job,actual_job_state='F',actual_PBS_exit=exitcode,actual_Stageout_status=0,model_repaired=False,scientific_acceptance=False))
        items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
        target=BASE/(label+'-evidence.tar.gz');assert not target.exists()
        with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
            for name,b in sorted(items.items()):
                m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
        assert files(target.read_bytes())==items
        package=dict(label=label,archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope=scope,verification=dict(actual_job=job,PBS_exit=exitcode,Stageout_status=0,opaque_arrays=proof['opaque_array_payloads'],independent_verification=True,source_inputs_hash_referenced=True,model_repaired=False,scientific_acceptance=False))
        (BASE/(label+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

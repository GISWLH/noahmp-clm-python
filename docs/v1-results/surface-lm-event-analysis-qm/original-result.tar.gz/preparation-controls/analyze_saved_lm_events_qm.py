"""PBS-only algebra on saved QF367 events; no model/evaluate/new Jacobian."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import math
import os
import pickle
import socket
import sys
import tarfile
import time
import traceback
from decimal import Decimal,localcontext

import numpy as np
from serialization_pt import dump_return

sha=lambda raw:hashlib.sha256(raw).hexdigest()


def archive(path,expected):
    raw=path.read_bytes();assert sha(raw)==expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()]
        names=[m.name.removeprefix('./') for m in members]
        assert len(set(names))==len(names)
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def exact(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return a.dtype==b.dtype and a.shape==b.shape and a.tobytes(order='C')==b.tobytes(order='C')


def decimal_predicted(r,jac,displacement):
    # Exact conversion of original binary64 inputs, then80-digit arithmetic.
    with localcontext() as context:
        context.prec=80
        D=Decimal.from_float
        rr=[D(float(v)) for v in r];dd=[D(float(v)) for v in displacement]
        jd=[sum((D(float(v))*d for v,d in zip(row,dd)),Decimal(0)) for row in jac]
        prediction=-2*sum((v*w for v,w in zip(rr,jd)),Decimal(0))-sum((v*v for v in jd),Decimal(0))
        gradient=[sum((D(float(v))*q for v,q in zip(column,rr)),Decimal(0)) for column in jac.T]
        gradient_norm=sum((v*v for v in gradient),Decimal(0)).sqrt()
        return dict(prediction=str(prediction),sign=1 if prediction>0 else -1 if prediction<0 else 0,
            J_transpose_r_norm=str(gradient_norm),J_transpose_r=[str(v) for v in gradient],precision_decimal_digits=80)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--qf',type=Path,required=True)
    parser.add_argument('--pw',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert os.name!='nt' and socket.gethostname().split('.')[0]=='compute002' and os.environ.get('PBS_JOBID')
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')=='' and np.__version__=='2.2.6'
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root=args.output.resolve();assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists();root.mkdir()
    report=dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),analysis_completed=False,
        original_QF_job='1844.manager',original_QF_model_exit=1,original_failure_preserved=True,
        model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,original_data_modified=False,
        nonlinear_stationarity_proved=False,stable_formula_solver_fix_proved=False)
    began=time.monotonic();status=1
    immutable={str(p):sha(p.read_bytes()) for p in (args.qf,args.pw,Path(__file__),Path(__file__).with_name('serialization_pt.py'))}
    try:
        qf=archive(args.qf,'1eab92628275ce4fbfc765fda3e12dd65a71389bfd291394c52951e43367e7fd')
        receipt=json.loads(qf['probe/receipt.json']);assert receipt['diagnostic_conclusive'] and not receipt['physical_model_succeeded']
        metadata=json.loads(qf['probe/trace/raw-observation.json'])
        assert sha(qf['probe/trace/raw-observation.pkl'])==metadata['pickle_sha256']
        packet=pickle.loads(qf['probe/trace/raw-observation.pkl'])
        events=packet['events'];assert len(events)==367 and packet['phase_calls']==1 and not packet['observer_errors']
        assert packet['helper_state']['helper_calls']==packet['helper_state']['helper_returns']==1
        assert packet['helper_returns'][0]['reason']=='no_feasible_displacement'
        groups={i:[e for e in events if e['iteration']==i] for i in range(31,62)}
        refreshed={e['iteration']:e for e in events if e['anchor']=='J_scaling_normal_gradient_complete'}
        rows=[]
        for iteration,group in groups.items():
            selected=[e for e in group if e['anchor']=='trial_and_displacement_complete'];assert len(selected)==1
            event=selected[0];data=event['locals'];ages=event['field_ages']
            assert ages['direction_iteration']==iteration
            point=refreshed[ages['J_iteration']]['locals']
            assert exact(point['x'],data['x']) and exact(point['residual'],data['residual'])
            x=np.asarray(data['x']);r=np.asarray(data['residual']);jac=np.asarray(data['jac'])
            direction=np.asarray(data['direction']);d=np.asarray(data['displacement'])
            scaled=np.asarray(data['scaled']);scale=np.asarray(data['scale'])
            assert x.shape==r.shape==direction.shape==d.shape==(12,) and jac.shape==scaled.shape==(12,12)
            assert all(np.all(np.isfinite(v)) for v in (x,r,jac,direction,d,scaled,scale))
            sv=np.linalg.svd(jac,compute_uv=False);sv_scaled=np.linalg.svd(scaled,compute_uv=False)
            gradient=jac.T@r;scaled_gradient=scaled.T@r;stored_gradient=np.asarray(data['gradient'])
            jd=jac@d
            stable=-2.*float(r@jd)-float(jd@jd)
            stable_fsum=-2.*math.fsum(float(a)*float(b) for a,b in zip(r,jd))-math.fsum(float(v)*float(v) for v in jd)
            decimal=decimal_predicted(r,jac,d)
            predictions=[e for e in group if e['anchor']=='linear_prediction_complete']
            assert len(predictions)<=1
            original_pred=None;original_norm=None
            if predictions:
                pred=predictions[0];assert pred['field_ages']['prediction_iteration']==iteration
                assert exact(pred['locals']['x'],x) and exact(pred['locals']['displacement'],d)
                original_pred=float(pred['locals']['predicted']);original_norm=float(pred['locals']['norm'])
            trials=[e for e in group if e['anchor']=='actual_reduction_and_ratio_complete'];assert len(trials)<=1
            actual_record=None
            if trials:
                trial=trials[0];assert trial['field_ages']['trial_iteration']==iteration
                values=trial['locals'];rt=np.asarray(values['trial_residual'])
                assert exact(values['x'],x) and exact(values['residual'],r) and exact(values['displacement'],d)
                actual_stable=float((r-rt)@(r+rt))
                with localcontext() as context:
                    context.prec=80
                    D=Decimal.from_float
                    actual_decimal=sum(((D(float(a))-D(float(b)))*(D(float(a))+D(float(b))) for a,b in zip(r,rt)),Decimal(0))
                actual_record=dict(original_actual=float(values['actual']),original_ratio=float(values['ratio']),
                    stable_actual=actual_stable,stable_actual_decimal80=str(actual_decimal),
                    stable_ratio_to_stable_pred=actual_stable/stable if stable!=0. else None,trial_residual=rt.copy(),iteration=iteration)
            with np.errstate(over='ignore',divide='ignore',invalid='ignore'):
                ulp=np.abs(np.spacing(x));direction_ulps=np.abs(direction)/ulp;displacement_ulps=np.abs(d)/ulp
            row=dict(iteration=iteration,J_age=ages['J_iteration'],direction_age=ages['direction_iteration'],
                original_lambda=float(data['damping']),original_alpha=float(data['alpha']),
                max_original_r12_residual=float(np.max(abs(r))),residual_l2=float(np.linalg.norm(r)),
                J_singular_values=sv.tolist(),J_singular_values_array=sv.copy(),J_condition=float(sv[0]/sv[-1]) if sv[-1]!=0. else float('inf'),
                scaled_J_singular_values=sv_scaled.tolist(),scaled_J_singular_values_array=sv_scaled.copy(),scaled_J_condition=float(sv_scaled[0]/sv_scaled[-1]) if sv_scaled[-1]!=0. else float('inf'),
                original_scaled_gradient_norm=float(np.linalg.norm(stored_gradient)),unscaled_Jtr_norm=float(np.linalg.norm(gradient)),
                recomputed_scaled_gradient_norm=float(np.linalg.norm(scaled_gradient)),
                stored_vs_recomputed_scaled_gradient_max_diff=float(np.max(abs(stored_gradient-scaled_gradient))),
                direction_max_abs=float(np.max(abs(direction))),displacement_max_abs=float(np.max(abs(d))),
                direction_nonzero_components=int(np.count_nonzero(direction)),displacement_nonzero_components=int(np.count_nonzero(d)),
                direction_max_abs_local_ULPs=float(np.max(direction_ulps)),displacement_max_abs_local_ULPs=float(np.max(displacement_ulps)),
                original_predicted_fresh=original_pred,original_norm_fresh=original_norm,stable_predicted=stable,
                stable_predicted_fsum=stable_fsum,stable_predicted_decimal80=decimal,
                old_zero_positive_exact_linear_prediction=(original_pred==0. and decimal['sign']>0),
                actual_reduction=actual_record,branch_anchors=[e['anchor'] for e in group if e['anchor'].startswith(('reject_','accept_'))],
                x=x.copy(),r=r.copy(),J=jac.copy(),direction=direction.copy(),displacement=d.copy(),ULP_at_x=ulp,
                direction_in_local_ULPs=direction_ulps,displacement_in_local_ULPs=displacement_ulps,
                strict_inside_original_bounds=bool(np.all((x>data['lower'])&(x<data['upper']))))
            rows.append(row)
        last=rows[-1];assert last['iteration']==61 and last['original_alpha']==1. and last['displacement_nonzero_components']==0
        last['component_step_report']=[dict(index=k,x=float(x),direction=float(direction),displacement=float(displacement),
            ULP_at_x=float(ulp),direction_in_local_ULPs=float(direction_ulps),displacement_in_local_ULPs=float(displacement_ulps))
            for k,(x,direction,displacement,ulp,direction_ulps,displacement_ulps) in enumerate(zip(
                last['x'],last['direction'],last['displacement'],last['ULP_at_x'],last['direction_in_local_ULPs'],last['displacement_in_local_ULPs']))]
        report.update(event_count=len(events),iterations_analyzed=len(rows),rows=rows,final_iteration=last,
            cancellation_old_zero_positive_exact_pred_iterations=[r['iteration'] for r in rows if r['old_zero_positive_exact_linear_prediction']],
            old_zero_nonpositive_exact_pred_iterations=[r['iteration'] for r in rows if r['original_predicted_fresh']==0. and r['stable_predicted_decimal80']['sign']<=0],
            final_inference='Original alpha1 and exactly zero representable displacement at interior saved state establish roundoff/no-movement termination. Old zero prediction versus positive80-digit prediction diagnoses cancellation for those specific stored steps, not a repaired nonlinear solver or a proved absence/presence of a physical stationary point.')
        # Optional already-saved PW root/trajectory, read only after QF algebra.
        pw=archive(args.pw,'44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')
        meta=json.loads(pw['probe/diagnostic/stored_ambient-diagnostic.json'])
        npz=pw['probe/diagnostic/stored_ambient-diagnostic.npz'];assert sha(npz)==meta['npz_sha256']
        def value(node,arrays):
            if node['kind']=='array':
                v=arrays[node['key']];assert v.dtype.str==node['dtype'] and list(v.shape)==node['shape'] and sha(v.tobytes(order='C'))==node['c_order_sha256'];return v.copy()
            if node['kind']=='float':return float.fromhex(node['hex'])
            return node.get('value')
        tree=meta['tree']['items']
        with np.load(io.BytesIO(npz),allow_pickle=False) as arrays:
            root_x=value(tree['last_attempted_x'],arrays);trajectory=value(tree['returned_evaluations']['items']['x'],arrays)
            residuals=value(tree['returned_evaluations']['items']['r12'],arrays)
            original_max=value(tree['maximum_original_12_residual'],arrays)
        assert value(tree['diagnostic_root_found'],{}) and trajectory.shape==residuals.shape==(301,12)
        distances=np.max(abs(trajectory-last['x'])/np.r_[np.full(10,20.),5.,5.],axis=1)
        nearest=int(np.argmin(distances))
        report['PW_posthoc_only']=dict(original_PW_job='1700.manager',root_x=root_x,original_root_r12_max=original_max,
            QF_final_minus_PW_root=last['x']-root_x,maximum_coordinate_difference=float(np.max(abs(last['x']-root_x))),
            trajectory_points=301,trajectory_points_are_calls_not_iterations=True,nearest_saved_point_index=nearest,
            nearest_saved_point_coordinate_distance_in_original_caps=float(distances[nearest]),nearest_saved_point_r12_max=float(np.max(abs(residuals[nearest]))),
            used_as_model_seed=False,physical_or_extra_evaluate_calls=0)
        report['analysis_completed']=True;status=0
    except BaseException:
        report['exception']=traceback.format_exc()
    finally:
        report['immutable_before_after_exact']=all(sha(Path(name).read_bytes())==digest for name,digest in immutable.items())
        if not report['immutable_before_after_exact']:status=1
        report.update(actual_analysis_exit=status,seconds=time.monotonic()-began,
            arithmetic_scope='Saved arrays only; singular values/Decimal algebra are new analysis, not new physical evaluations/Jacobians. All nonfinite values remain losslessly encoded.')
        dump_return(root/'analysis',report)
    return status


if __name__=='__main__':sys.exit(main())

from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();r=b/'qia-all-phase-numpy-year-c';launch=json.loads((r/'launch.json').read_text());raw=(r/'trajectory/report.json').read_bytes();d=json.loads(raw);assert d['source_unchanged'] and d['steps_requested']==17520
m=json.loads((r/'SOURCE_SHA256.json').read_text());assert all(m[n]==h for n,h in d['source_sha256'].items())
record=dict(scope='Read-only live metadata/sourcehash observation only,no physical/numerical work on login. Actual NumPy originalcold currentproduction year C generation snapshot,not completion/year/science acceptance. Separate267/268 diagnostic state only;no selected outcomes/default changes.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_verification='B metadata probe tried compute-node TMPDIR from login and failed before creating any archive; no model/source checksum failure. C verifies model-reported CPUsource hashes against archived fullmanifest,without claiming independent login access to compute-localfiles.',numpy_year=dict(status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],source_unchanged=True,report_sha256=sha(raw),maximum_cumulative_residual_m_h_c_n=d['maximum_cumulative_residual_m_h_c_n']),jobs={})
files=[('numpy-year/report.json',raw)]
for job,folder in [('260.manager',r),('267.manager',b/'qia-trait-daylength-upper-b'),('268.manager',b/'qia-daylength-firstday-comparison-b')]:
    q=subprocess.run(['qstat','-f',job],text=True,capture_output=True);files.append((job+'/qstat.txt',(q.stdout+q.stderr).encode()));record['jobs'][job]=dict(qstat_returncode=q.returncode,pbs_exit=(folder/'pbs-exit.txt').read_text().strip() if (folder/'pbs-exit.txt').exists() else None)
    if job!='260.manager':
        for p in sorted(folder.iterdir()):
            if p.is_file():files.append((folder.name+'/'+p.name,p.read_bytes()))
a=b/'all-phase-ehpc-progress-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n,data in files:
        i=tarfile.TarInfo(n);i.size=len(data);t.addfile(i,io.BytesIO(data))
    data=(json.dumps(record,indent=2)+'\n').encode();i=tarfile.TarInfo('snapshot.json');i.size=len(data);t.addfile(i,io.BytesIO(data));t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,snapshot=record)))

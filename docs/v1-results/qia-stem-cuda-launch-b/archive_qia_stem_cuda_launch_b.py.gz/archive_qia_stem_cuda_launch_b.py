from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-stem-cuda-day-b';s=b/'p6-stem-split-f';strict=b/'qia-stem-device-day-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());pid=json.loads((r/'worker.json').read_text())['pid'];assert b'run_qia_stem_cuda_day_b.py' in Path('/proc',str(pid),'cmdline').read_bytes()
cold=list((r/'trajectory').glob('state-0000000-*.npz'));assert len(cold)==1
with np.load(cold[0],allow_pickle=False) as z:a=dict(z)
with np.load(r/'strict-reference-cold0.npz',allow_pickle=False) as z:c=dict(z)
assert len(a)==26 and set(a)<=c.keys()
for name in a:np.testing.assert_array_equal(a[name],c[name])
raw=(r/'trajectory/batch.json').read_bytes();report=json.loads(raw);assert report['identity']['compare_jax32'] is False and report['same_precision_max_absolute'] is None and report['identity']['native_state_arrays']==19
pmon=subprocess.run(['nvidia-smi','pmon','-i','0','-s','um','-c','1'],capture_output=True,text=True,timeout=10);selected=[]
for line in pmon.stdout.splitlines():
 parts=line.split()
 if line.startswith('#') or len(parts)>1 and parts[1] in [str(pid),'2242411']:selected.append(line)
obs=dict(scope='Actual separate CUDA-only Qia48 launch, first26 primary19+ledger7 cold arrays exactly equal original strictA seed. Original strictA still live, one GDB sample located nested XLA GPU WhileThunk execution and detached; unsupported py-bt is not a Python trace. No unique bottleneck/deadlock/compiler/hardware diagnosis; no solver/gate change. StrictA1e-6 result remains pending,none claimed for CUDA-only B.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),ps=subprocess.check_output(['ps','-p',str(pid)+',2242411','-o','pid,ppid,stat,etime,pcpu,args'],text=True),current_steps_committed=report['steps_completed'],original_requested_steps=report['steps_requested'],primary_cold_arrays_exact=26,source_unchanged=True,own_gpu_pmon_lines=selected,pmon_returncode=pmon.returncode)
archive=b/'qia-stem-cuda-launch-b-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in [r/'launch.json',r/'worker.json',r/'strict-reference-cold0.npz',cold[0],strict/'profile-gdb-main-a.txt',s/'SOURCE_SHA256.json',b/'run_qia_stem_cuda_day_b.py',b/'control_qia_stem_cuda_day_b.py',b/'launch_qia_stem_cuda_day_b.py',Path(__file__)]:t.add(p,arcname=p.name,recursive=False)
 for name,data in [('observation.json',(json.dumps(obs,indent=2)+'\n').encode()),('captured-batch.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),observation=obs)))

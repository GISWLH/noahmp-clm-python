"""Read and archive the closed original MX experiment; never launch or rerun it."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import sys
import tarfile
import xml.etree.ElementTree as ET

BASE = Path('/home/lhwang/work/noahmp-v1')
ROOT = BASE / 'surface-root-regression-mx'
SOURCE = Path('/tmp/noahmp-surface-root-regression-mx/source')
MANIFEST = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
CONTRACT = '2a0460c2bca17fbf17e9fcfb5be9c83c1eea34d051ba02c618366f914b0477d9'
WORKER = '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def identity(pid):
    path = Path('/proc') / str(pid)
    try:
        parts = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        try:
            cwd = str((path / 'cwd').resolve())
        except PermissionError:
            cwd = '<unreadable:PermissionError>'
        return dict(pid=pid, state=parts[0], start_ticks=int(parts[19]), cwd=cwd,
                    cmdline=(path / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace'))
    except (FileNotFoundError, ProcessLookupError):
        return None


def source_check():
    assert sha(SOURCE / 'SOURCE_SHA256.json') == MANIFEST
    source_manifest = read(SOURCE / 'SOURCE_SHA256.json')
    assert len(source_manifest) == 581
    assert all(sha(SOURCE / name) == digest for name, digest in source_manifest.items())
    return source_manifest


def no_active_experiment(launch, terminal):
    records = {}
    for pid in [launch['pid']] + [r['pid'] for r in terminal['records']]:
        record = identity(pid)
        assert record is None or record['state'] == 'Z', ('Original PID is still present', record)
        records[str(pid)] = record
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            if path.stat().st_uid != os.getuid():
                continue
            process = identity(int(path.name))
            if process and process['state'] != 'Z':
                assert str(ROOT) not in process['cmdline']
                assert str(SOURCE) not in process['cmdline']
                assert not process['cwd'].startswith(str(SOURCE))
        except (FileNotFoundError, ProcessLookupError):
            continue
    return records


def main():
    # A missing terminal, live controller or worker rejects export without mutation.
    terminal, plan, launch = [read(ROOT / name) for name in ['exit.json', 'plan.json', 'launch.json']]
    process_records = no_active_experiment(launch, terminal)
    assert plan['source'] == str(SOURCE) and plan['derived_manifest_sha256'] == MANIFEST
    assert launch['physical_gpu_index'] == 1
    assert launch['physical_gpu_uuid'] == 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
    source_manifest = source_check()
    assert (ROOT / 'SOURCE_SHA256.json').read_bytes() == (SOURCE / 'SOURCE_SHA256.json').read_bytes()
    assert all(sha(ROOT / name) == digest for name, digest in plan['controls_sha256'].items())
    assert sha(ROOT / 'surface_regression_contract_mx.py') == CONTRACT
    sys.path.insert(0, str(ROOT))
    from surface_regression_contract_mx import FILES, selected_nodes, verify_preflight
    nodes = selected_nodes(ROOT / 'original-JO-collection.json')
    assert nodes == plan['nodes'] and sum(map(len, nodes.values())) == plan['total_original_nodes'] == 31
    preflight = verify_preflight(ROOT / 'preflight')
    by_file = {row['file']: row for row in terminal['records']}
    assert len(by_file) == len(terminal['records'])
    validations, issues = {}, []
    for name, count in FILES.items():
        stem = Path(name).stem
        if name not in by_file:
            issues.append(name + ': missing original terminal record')
            continue
        row = by_file[name]
        try:
            receipt = read(ROOT / (stem + '-receipt.json'))
            assert row == read(ROOT / (stem + '-exit.json'))
            assert row['expected_tests'] == count and row['counts'] == receipt['counts']
            assert row['receipt_sha256'] == sha(ROOT / (stem + '-receipt.json'))
            assert row['actual_parent_returncode'] == receipt['worker_exitcode'] == receipt['pytest_returncode'] == 0
            assert row['passed'] and receipt['passed'] and receipt['source_unchanged']
            assert receipt['source_files'] == 581 and receipt['source_manifest_sha256'] == MANIFEST
            assert receipt['worker_sha256'] == WORKER
            assert receipt['node_coverage_exact'] and receipt['all_setup_call_teardown_phases_passed']
            assert receipt['errors'] == []
            assert len(receipt['nodes']) == count and set(receipt['nodes']) == set(nodes[name])
            expected = ROOT / (stem + '-expected.json')
            assert read(expected) == nodes[name] and receipt['expected_nodes_sha256'] == sha(expected)
            assert receipt['test_sha256'] == source_manifest['tests/' + name]
            assert receipt['counts'] == dict(tests=count, failures=0, errors=0, skipped=0)
            assert {r['backend']: r['status'] for r in receipt['device_barriers']} == dict(jax='complete', cupy='complete')
            xml = ROOT / (stem + '.xml')
            assert receipt['xml_sha256'] == sha(xml)
            cases = list(ET.parse(xml).getroot().iter('testcase'))
            assert len(cases) == count and all(case.find(tag) is None for case in cases
                                               for tag in ['failure', 'error', 'skipped'])
            validations[name] = dict(actual_parent_returncode=0, nodes=count,
                receipt_sha256=sha(ROOT / (stem + '-receipt.json')),
                original_full_phase_assertion=True, device_barriers=receipt['device_barriers'],
                xml_sha256=sha(xml), passed=True)
        except Exception as error:
            issues.append(name + ': ' + type(error).__name__ + ': ' + str(error))
    validated = (not issues and set(by_file) == set(FILES) and terminal['passed'] is True
                 and terminal['failure'] is None and terminal['source_unchanged'] is True
                 and terminal['source_manifest_sha256'] == MANIFEST
                 and terminal['original_nodes_attempted'] == terminal['total_original_nodes'] == 31)
    assert bool(terminal['passed']) == validated, ('Receipt/terminal disagreement; preserve original tree', issues)
    audit = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 passed=validated, issues=issues, source_manifest_sha256=MANIFEST,
                 source_files=581, source_unchanged=True, original_nodes=31,
                 original_terminal_sha256=sha(ROOT / 'exit.json'), original_pid_states=process_records,
                 preflight=preflight, module_validation=validations,
                 scope='Read-only closure audit and archive of the original MX run. No rerun, promotion or source change. '
                       'All original receipt phase assertions retained; original worker did not persist per-node phase rows. '
                       'No new phase trace is fabricated. Original numerical logs, XML, diagnostics, controls and all frozen source files included.')
    archive = BASE / 'surface-root-regression-mx-evidence.tar.gz'
    metadata = BASE / 'surface-root-regression-mx-package.json'
    assert not archive.exists() and not metadata.exists()
    root_files = sorted(p for p in ROOT.rglob('*') if p.is_file())
    assert all(not p.is_symlink() for p in root_files)
    files = {'evidence/' + p.relative_to(ROOT).as_posix(): p for p in root_files}
    files.update({'source/' + name: SOURCE / name for name in source_manifest})
    files['source/SOURCE_SHA256.json'] = SOURCE / 'SOURCE_SHA256.json'
    files['export_surface_regression_mx.py'] = Path(__file__).resolve()
    assert all(not p.is_symlink() for p in files.values())
    details = {name: dict(sha256=sha(path), bytes=path.stat().st_size) for name, path in files.items()}
    audit_bytes = (json.dumps(audit, indent=2, allow_nan=False) + '\n').encode()
    details['EXPORT_AUDIT.json'] = dict(sha256=hashlib.sha256(audit_bytes).hexdigest(), bytes=len(audit_bytes))
    with tarfile.open(archive, 'w:gz') as packed:
        for name, path in sorted(files.items()):
            packed.add(path, arcname=name, recursive=False)
        member = tarfile.TarInfo('EXPORT_AUDIT.json')
        member.size = len(audit_bytes)
        packed.addfile(member, io.BytesIO(audit_bytes))
    assert all(sha(path) == details[name]['sha256'] for name, path in files.items())
    assert source_check() == source_manifest
    assert root_files == sorted(p for p in ROOT.rglob('*') if p.is_file())
    no_active_experiment(launch, terminal)
    with tarfile.open(archive) as packed:
        assert len(packed.getmembers()) == len(details) and set(packed.getnames()) == set(details)
        for name, detail in details.items():
            data = packed.extractfile(name).read()
            assert len(data) == detail['bytes'] and hashlib.sha256(data).hexdigest() == detail['sha256']
    value = dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                 artifacts=len(details), artifact_details=details,
                 passed=validated, original_source_manifest_sha256=MANIFEST,
                 frozen_source_files=581, original_nodes=31,
                 original_actual_parent_codes=[row['actual_parent_returncode'] for row in terminal['records']],
                 scope=audit['scope'])
    with metadata.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({key: value for key, value in value.items() if key != 'artifact_details'}), flush=True)


if __name__ == '__main__':
    main()

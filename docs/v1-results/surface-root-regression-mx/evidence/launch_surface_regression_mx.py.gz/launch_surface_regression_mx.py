"""Launch 31 original regression nodes only AFTER both closed EHPC proofs.

No --wait mode: a missing ACK exits before directory creation. Run only on
xuanze after placing ack.json plus its four proof files in the preflight folder.
"""
from pathlib import Path
import argparse
import datetime
import json
import os
import subprocess
import sys
import tarfile
from surface_regression_contract_mx import (
    ARCHIVE, CHANGES, DERIVED, GUARD, GPU_UUID, PARENT, WORKER,
    selected_nodes, sha, verify_preflight,
)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--preflight', type=Path, required=True)
args = parser.parse_args()
b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'surface-root-regression-mx'
tmp = Path('/tmp/noahmp-surface-root-regression-mx')
assert not r.exists() and not tmp.exists(), 'One immutable attempt; never overwrite an existing experiment'
proof = verify_preflight(args.preflight)
collection = b / 'ballberry-jo-full-gpu/collection.json'
nodes = selected_nodes(collection)
archive = b / 'clm-ballberry-jn-source.tar.gz'
assert sha(archive) == ARCHIVE
patch_path = b / 'surface-root-ml-patch.json'
patch = json.loads(patch_path.read_text())
assert patch['parent_source_manifest_sha256'] == PARENT
assert set(patch['changes']) == set(CHANGES)
controls = ['surface_regression_contract_mx.py', 'control_surface_regression_mx.py',
            'worker_surface_regression_mx.py', Path(__file__).name,
            'bounded_cache_guard_gd.py']
for name in controls:
    assert (b / name).is_file() and b'\r\n' not in (b / name).read_bytes(), name
assert sha(b / 'bounded_cache_guard_gd.py') == GUARD
generic = b / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
assert sha(generic) == WORKER
# All prerequisite guards above are read-only. Only this new experiment is written.
r.mkdir()
tmp.mkdir()
s = tmp / 'source'
s.mkdir()
with tarfile.open(archive) as tf:
    tf.extractall(s, filter='data')
manifest_path = s / 'SOURCE_SHA256.json'
assert sha(manifest_path) == PARENT
parent = json.loads(manifest_path.read_text())
assert len(parent) == 581 and all(sha(s / name) == digest for name, digest in parent.items())
(r / 'PARENT_SOURCE_SHA256.json').write_bytes(manifest_path.read_bytes())
for name, change in patch['changes'].items():
    assert change['before_sha256'] == parent[name]
    (s / name).write_text(change['after_text'])
    assert sha(s / name) == change['after_sha256'] == CHANGES[name]
derived = {name: sha(s / name) for name in parent}
assert {name for name in parent if derived[name] != parent[name]} == set(CHANGES)
manifest_path.write_text(json.dumps(derived, indent=2) + '\n')
assert sha(manifest_path) == DERIVED
(r / 'SOURCE_SHA256.json').write_bytes(manifest_path.read_bytes())
(r / 'patch.json').write_bytes(patch_path.read_bytes())
(r / 'original-JO-collection.json').write_bytes(collection.read_bytes())
preflight = r / 'preflight'
preflight.mkdir()
for name in ['ack.json', 'point_pair-audit.json', 'point_pair-actual-qstat.txt',
             'k78-audit.json', 'k78-actual-qstat.txt']:
    (preflight / name).write_bytes((args.preflight / name).read_bytes())
assert verify_preflight(preflight) == proof
for name in controls:
    (r / name).write_bytes((b / name).read_bytes())
(r / 'run_pytest_worker_a.py').write_bytes(generic.read_bytes())
controls.append('run_pytest_worker_a.py')
meta = dict(source=str(s), private_cache_root=str(tmp), parent_manifest_sha256=PARENT,
            derived_manifest_sha256=DERIVED, nodes=nodes, total_original_nodes=31,
            controls_sha256={name: sha(r / name) for name in controls},
            scope='Private ML 4-file candidate; eight complete original JO modules, 31 nodes. '
                  'All existing gates and fixtures unchanged. Not full407 or annual/science/release acceptance.')
(r / 'plan.json').write_text(json.dumps(meta, indent=2) + '\n')
env = os.environ.copy()
for key in ['LD_LIBRARY_PATH', 'PYTEST_PLUGINS']:
    env.pop(key, None)
env.update(PYTHONPATH=':'.join(map(str, [r, s, s / 'src', s / 'tests', s / 'benchmarks'])),
           PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES=GPU_UUID,
           CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda',
           JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false',
           JAX_COMPILATION_CACHE_DIR=str(tmp / 'jax-cache'), CUPY_CACHE_DIR=str(tmp / 'cupy-cache'),
           CUDA_CACHE_PATH=str(tmp / 'cuda-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
           NOAHMP_REQUIRE_GPU='1')
with (r / 'controller.log').open('x') as log:
    process = subprocess.Popen([sys.executable, '-u', str(r / 'control_surface_regression_mx.py')],
                               cwd=s, env=env, stdin=subprocess.DEVNULL, stdout=log,
                               stderr=subprocess.STDOUT, start_new_session=True)
launch = dict(pid=process.pid, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              physical_gpu_index=1, physical_gpu_uuid=GPU_UUID, **meta)
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps(launch), flush=True)

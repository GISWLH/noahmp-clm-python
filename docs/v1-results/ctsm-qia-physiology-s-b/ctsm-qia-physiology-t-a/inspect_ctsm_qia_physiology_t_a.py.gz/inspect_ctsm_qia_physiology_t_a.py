from pathlib import Path
import hashlib
import json
import os
import re
import tarfile

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-physiology-t-a'
s = b / 'ctsm-qia-run-s'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert (s / 'pbs-exit.txt').read_text().strip() == '0'
d = json.loads((s / 'physiology-restarts.json').read_text())
assert d['positive_intervals'] == 48 and len(d['shared_first48_raw_fields_exact']) == 27 and all(d['shared_first48_raw_fields_exact'].values())
with np.load(b / 'qia-stem-inputs-a/inputs/CN-Qia.npz', allow_pickle=False) as z:
    daylight = np.asarray(z['forcing'][:48, 5]) > 1.
assert daylight.sum() > 0
after = np.asarray([v['fields']['T10_VALUE']['values'] for v in d['restarts']], float).reshape(48)
initial = np.asarray(d['initial']['fields']['T10_VALUE']['values'], float).reshape(())
before = np.r_[initial, after[:-1]]
assert np.isfinite(before).all() and np.isfinite(after).all()
selected = {}
scratch = Path(os.environ['TMPDIR']) / 'selected-t-a'
scratch.mkdir()
with tarfile.open(s / 'case-configuration-private.tar.gz') as t:
    for m in t:
        keep = m.name == 'inputdata/CN-Qia.official-interpolated-cold.nc' or ('.clm2.h0.' in m.name and m.name.endswith('.nc')) or m.name.endswith(d['restarts'][0]['file'])
        if not keep or not m.isfile():
            continue
        p = scratch / Path(m.name).name
        p.write_bytes(t.extractfile(m).read())
        values = {}
        with Dataset(p) as nc:
            for name, v in nc.variables.items():
                if not re.search('DAYL|OBLIQ|DECLIN|VCMAX|JMAX|T10|VCMX25|NSTEP', name, re.I):
                    continue
                a = np.ma.asarray(v[:])
                if a.dtype.kind not in 'fiu' or a.size > 256:
                    values[name] = dict(shape=a.shape, status='not reduced: nonnumeric or >256 values')
                    continue
                mask = np.ma.getmaskarray(a); bad = ~np.isfinite(np.ma.getdata(a))
                values[name] = dict(units=getattr(v, 'units', None), shape=a.shape, masked=int(mask.sum()), nonfinite=int(bad.sum()),
                                    values=np.ma.masked_array(np.ma.getdata(a), mask=mask | bad).tolist())
        selected[m.name] = dict(sha256=sha(p), fields=values)
record = dict(scope='EHPC PBS actual S48 T10 readback and available original restart/history daylength/physiology fields. Require27 raw R fields exactly same. Before-step memory reconstructed by previous completed restart plus initial value; exact driver phase still requires source ordering check. No fabricated DAYL/max_DAYL or unmasked missing Vcmax,parameter fitting or science acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, original_S_readback_sha256=sha(s / 'physiology-restarts.json'),
              initial_T10_K=float(initial), before_T10_K=before.tolist(), after_T10_K=after.tolist(),
              daylight_indices=np.flatnonzero(daylight).tolist(), daylight_before_T10_min_K=float(before[daylight].min()), daylight_before_T10_max_K=float(before[daylight].max()),
              daylight_after_T10_min_K=float(after[daylight].min()), daylight_after_T10_max_K=float(after[daylight].max()),
              daylight_before_growth_temperature_clipped_11_35_C=np.clip(before[daylight] - 273.15, 11., 35.).tolist(),
              selected_original_netcdf_fields=selected)
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'selected_original_netcdf_fields'}, allow_nan=False), flush=True)

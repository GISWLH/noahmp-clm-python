from pathlib import Path
import hashlib
import json
import os
import re
import sys
import tarfile

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-stress-b'
scratch = Path(os.environ['TMPDIR']) / 'ctsm-stress-data-b'
scratch.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
official = b / 'ctsm-qia-run-r'
config = json.loads((official / 'configuration.json').read_text())
assert (official / 'pbs-exit.txt').read_text().strip() == '0' and config['official_model_returncode'] == 0 and config['upstream_original_bytes_unchanged']
inputs = b / 'qia-stem-inputs-a/inputs'
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    day = np.asarray(z['forcing'][:48, 5]) > 1.
assert sha(inputs / 'CN-Qia.npz') == '237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
names = ['inputdata/clm5_params.c171117.nc', 'inputdata/surfdata.CN-Qia.engineering.nc', 'output/case/run/case.clm2.h0.2002-12-31-57600.nc']
files = {}
with tarfile.open(official / 'case-configuration-private.tar.gz') as t:
    for name in names:
        member = t.getmember(name)
        p = scratch / Path(name).name
        p.write_bytes(t.extractfile(member).read())
        files[name] = dict(path=p, sha256=sha(p))
history = files[names[-1]]['path']
assert files[names[-1]]['sha256'] == config['model_outputs'][history.name]['sha256']
stress = {}
with Dataset(history) as d:
    bounds = np.asarray(d['time_bounds'][:], float) * 86400.
    take = (bounds[:, 0] >= 0) & (bounds[:, 1] <= 86400.)
    assert take.sum() == 48 and np.array_equal(np.rint(bounds[take]).astype(int), np.arange(48)[:, None] * 1800 + [[0, 1800]])
    for name in ['BTRAN', 'BTRAN2', 'BTRANMN']:
        v = d[name]
        values = np.ma.asarray(v[:])[take].reshape(48)
        mask=np.ma.getmaskarray(values);nonfinite=~np.isfinite(np.ma.getdata(values));valid=~(mask|nonfinite)
        full=bool(valid.all());light=bool(valid[day].all())
        stress[name] = dict(units=v.units,long_name=getattr(v,'long_name',None),status='measured' if full else 'partially measured/unmeasured: original mask/nonfinite retained',
                            samples=48,original_masked_count=int(mask.sum()),original_nonfinite_count=int(nonfinite.sum()),missing_indices=np.flatnonzero(~valid).tolist(),
                            daylight_samples=int(day.sum()),daylight_all_valid=light,
                            mean=float(values.mean()) if full else None,minimum=float(values.min()) if full else None,maximum=float(values.max()) if full else None,
                            daylight_mean=float(values[day].mean()) if light else None,daylight_minimum=float(values[day].min()) if light else None,daylight_maximum=float(values[day].max()) if light else None,
                            values=np.ma.masked_array(np.ma.getdata(values),mask=~valid).tolist())
    available = [n for n in d.variables if re.search('HKSAT|SUCSAT|WATSAT|ROOTFR|BSW|SMP', n, re.I)]
    soil_potential = dict(status='unmeasured: SMP absent from original history')
    if 'SMP' in d.variables:
        v = d['SMP']
        values = np.ma.asarray(v[:])[take].reshape(48, -1)
        soil_potential = dict(units=v.units, dimensions=v.dimensions, shape=values.shape,
                              masked=int(np.ma.getmaskarray(values).sum()),
                              mean_by_layer=np.ma.mean(values, axis=0).tolist(),
                              daylight_mean_by_layer=np.ma.mean(values[day], axis=0).tolist(),
                              values=values.tolist())
surface = {}
with Dataset(files[names[1]]['path']) as d:
    for name in ['PCT_SAND', 'PCT_CLAY', 'ORGANIC', 'PCT_NAT_PFT']:
        v = d[name]
        values = np.ma.asarray(v[:])
        assert not np.any(np.ma.getmaskarray(values)) and np.all(np.isfinite(values))
        surface[name] = dict(units=getattr(v, 'units', None), dimensions=v.dimensions, values=values.tolist())
traits, trait_names = {}, []
pattern = re.compile('roota|rootb|rootprof|smpso|smpsc|leafcn|slatop|flnr|fnr|mbbopt|bbbopt|vcmax|jmax|lmr25|qe|theta_cj|tpu', re.I)
with Dataset(files[names[0]]['path']) as d:
    for name, v in d.variables.items():
        if not pattern.search(name):
            continue
        trait_names.append(name)
        row = dict(units=getattr(v, 'units', None), long_name=getattr(v, 'long_name', None), dimensions=v.dimensions, dtype=str(v.dtype))
        values = np.ma.asarray(v[:])
        if 'pft' in v.dimensions:
            axis = v.dimensions.index('pft')
            assert values.shape[axis] >= 2
            values = np.take(values, 1, axis=axis)
            row['selection'] = 'CLM pft index1,original forest point vegetation type1; bare0 retained in parameterfile,not an off-by-one vector'
        else:
            row['selection'] = 'global scalar/array,not silently indexed as PFT'
        if values.size <= 64 and values.dtype.kind in 'fiu':
            mask=np.ma.getmaskarray(values);nonfinite=~np.isfinite(np.ma.getdata(values))
            row['original_masked_count']=int(mask.sum());row['original_nonfinite_count']=int(nonfinite.sum())
            row['values']=np.ma.masked_array(np.ma.getdata(values),mask=mask|nonfinite).tolist()
        else:
            row['values'] = 'not summarized: nonnumeric or >64 values'
        traits[name] = row
source = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(source) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
s = scratch / 'source'
s.mkdir()
with tarfile.open(source) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
from run_fluxnet_column import build_state
from noahmp_clm.physics.stress import soil_water_stress
native_config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
assert sha(inputs / 'CN-Qia-stem-config.json') == '339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1'
state = build_state(native_config)
view = state.parameter_view()
view.smc = state.ground.liquid / (1000. * state.ground.dz)
initial = dict(scope='Original native initial cold state before any precipitation/iteration,not an actual per-step/canopy-accepted BTRAN series or fitted coefficient.',
               configured_option=state.options.OptSoilWaterTranspiration,
               configured_stress=soil_water_stress(view, state.options.OptSoilWaterTranspiration),
               liquid_theta=view.smc.tolist(), soil=native_config['column']['soil'], root_fraction=state.root_frac.tolist(),
               leaf_parameters=native_config['leaf_parameters'])
record = dict(scope='Read-only actual official R first48 BTRAN and unchanged original surface/PFT traits plus native configured initial stress on EHPC PBS. Parameters/physics/met/observation windows untouched. No assertion that soil stress explains all flux differences; no scientific acceptance or per-step native-stress reconstruction.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, official_R_configuration_sha256=sha(official / 'configuration.json'),
              files={n: dict(sha256=v['sha256']) for n, v in files.items()}, original_parameter_bundle_pft_index=1,
              official_stress=stress, original_surface=surface, matching_parameter_names=trait_names, official_traits=traits,
              available_hydraulic_history_fields=available, actual_official_soil_potential=soil_potential, native_initial=initial,
              native_source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), native_source_unchanged=all(sha(s / n) == v for n, v in m.items()))
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(pbs_job=record['pbs_job'], official_stress={n: {k: v[k] for k in ['mean', 'daylight_mean', 'minimum', 'maximum']} for n, v in stress.items()},
                      native_initial=initial, traits=traits), allow_nan=False), flush=True)

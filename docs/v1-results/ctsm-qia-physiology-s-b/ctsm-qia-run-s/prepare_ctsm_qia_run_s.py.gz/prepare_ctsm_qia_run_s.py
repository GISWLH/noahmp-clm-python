from pathlib import Path
import ast
import json

p = Path(__file__).resolve().parent
s = (p / 'run_ctsm_qia_r.py').read_text().replace('ctsm-qia-run-r', 'ctsm-qia-run-s')
old = 'GMAKE_J=1,STOP_OPTION=nsteps,STOP_N=17520,DOUT_S=FALSE'
assert s.count(old) == 1
s = s.replace(old, 'GMAKE_J=1,STOP_OPTION=nsteps,STOP_N=48,REST_OPTION=nsteps,REST_N=1,DOUT_S=FALSE')
s = s.replace('audit_ctsm_qia_year_boundary_o_a.py', 'audit_ctsm_qia_photo_restart_s.py')
s = s.replace("value['year_boundary_audit']=json.loads((root/'year-boundary.json').read_text())", "value['photo_restart_audit']=json.loads((root/'physiology-restarts.json').read_text())")
s = s.replace('Official pinned single-column Qia SP full17520-step engineering reference,5 snow layers/Ball-Berry/LUNA and hydraulic stress disabled.', 'Official pinned single-column Qia SP first48 diagnostic with originalR hydrothermal/canopy inputs and restart every timestep. Exact shared raw first48 replay against originalR mandatory; no year or scientific acceptance.')
ast.parse(s)
(p / 'run_ctsm_qia_s.py').write_bytes(s.encode())
s = (p / 'ctsm_qia_run_r.pbs').read_text().replace('ctsm-qia-run-r', 'ctsm-qia-run-s').replace('run_ctsm_qia_r.py', 'run_ctsm_qia_s.py').replace('clm-qia-official-r', 'clm-qia-official-s')
(p / 'ctsm_qia_run_s.pbs').write_bytes(s.encode())
d = dict(scope='Prospective official S48 physiology diagnostic: keep every originalR source/input/physical choice,only48 endstop and restart-frequency1. Require exact all-shared first48 R replay;read actual fresh initial/T10 evolving scalar states and original fnitr/PFT traits before any physiology mapping. No output-score fitting or source instrumentation.',
         upstream_bundle_sha256='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6',
         original_native_configuration_sha256='339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1',
         steps=48, restart_every_steps=1, independent_science_acceptance=False)
(p / 'ctsm-qia-run-s-protocol.json').write_bytes((json.dumps(d, indent=2) + '\n').encode())
print('Prepared unmodified-physics S48 per-step restart diagnosis')

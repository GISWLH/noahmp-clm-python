from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
w, r = map(Path, sys.argv[1:3])
b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
epoch = datetime.datetime(2002, 12, 31, 16)
old = b / 'ctsm-qia-run-r'
old_audit = json.loads((old / 'year-boundary.json').read_text())
assert (old / 'pbs-exit.txt').read_text().strip() == '0' and sha(old / 'official-year-fields.npz') == old_audit['fields_sha256']
with np.load(old / 'official-year-fields.npz', allow_pickle=False) as z:
    reference = dict(z)
parts, bounds, history = {}, [], []
for p in sorted((w / 'output/case/run').glob('*.clm2.h0.*.nc')):
    with Dataset(p) as d:
        assert d['time'].units == 'days since 2002-12-31 16:00:00'
        bt = np.asarray(d['time_bounds'][:], float) * 86400.
        assert np.max(abs(bt - np.rint(bt))) < .01
        bounds.append(np.rint(bt).astype(np.int64))
        for name in reference:
            if name not in d.variables or 'time' not in d[name].dimensions:
                continue
            a = np.ma.asarray(d[name][:])
            assert not np.any(np.ma.getmaskarray(a)), name
            parts.setdefault(name, []).append(np.asarray(a).reshape(len(bt), -1))
        if 'TREFHT' in d.variables:
            parts.setdefault('TREFHT', []).append(np.asarray(d['TREFHT'][:]).reshape(len(bt), -1))
    history.append(dict(file=p.name, sha256=sha(p), samples=len(bt)))
allbounds = np.concatenate(bounds)
order = np.argsort(allbounds[:, 0], kind='stable')
allbounds = allbounds[order]
valid = (allbounds[:, 0] >= 0) & (allbounds[:, 1] <= 86400)
assert len(allbounds) == 49 and valid.sum() == 48
assert np.array_equal(allbounds[valid], np.arange(48)[:, None] * 1800 + [[0, 1800]])
fields = {n: np.concatenate(v)[order][valid] for n, v in parts.items()}
same = {n: bool(np.array_equal(a, reference[n][:48])) for n, a in fields.items() if n in reference}
assert len(same) >= 20 and all(same.values()), same
np.savez_compressed(r / 'official-first48-fields.npz', **fields, time_bounds_seconds=allbounds[valid])

names = ['T10_VALUE', 'T10_NSTEPS', 'T10_PERIOD', 'T_VEG24_VALUE', 'T_VEG240_VALUE', 'T_VEG240_NSTEPS',
         'T_REF2M', 'T_VEG', 'vcmx25t', 'jmx25t', 'tpu25t', 'lnca', 'tlai', 'tsai', 'nrad', 'ncan',
         'tlai_z', 'tsai_z', 'vcmaxcintsun', 'vcmaxcintsha']
def read_fields(p):
    out = {}
    with Dataset(p) as d:
        for name in names:
            if name not in d.variables:
                out[name] = dict(status='unmeasured: field absent')
                continue
            v = d[name]
            a = np.ma.asarray(v[:])
            bad = ~np.isfinite(np.ma.getdata(a))
            mask = np.ma.getmaskarray(a)
            out[name] = dict(units=getattr(v, 'units', None), shape=a.shape, dtype=str(v.dtype),
                             original_masked_count=int(mask.sum()), original_nonfinite_count=int(bad.sum()),
                             values=np.ma.masked_array(np.ma.getdata(a), mask=mask | bad).tolist())
        ymd, sod = int(np.asarray(d['timemgr_rst_curr_ymd'][:])), int(np.asarray(d['timemgr_rst_curr_tod'][:]))
    date = datetime.datetime.strptime(str(ymd), '%Y%m%d') + datetime.timedelta(seconds=sod)
    return dict(file=p.name, sha256=sha(p), current_utc=date.isoformat(), seconds_from_original_epoch=int((date - epoch).total_seconds()), fields=out)
initial = read_fields(w / 'inputdata/CN-Qia.official-interpolated-cold.nc')
restarts = [read_fields(p) for p in sorted((w / 'output/case/run').glob('*.clm2.r.*.nc'))]
restarts.sort(key=lambda row: row['seconds_from_original_epoch'])
assert [v['seconds_from_original_epoch'] for v in restarts] == (np.arange(1, 49) * 1800).tolist()
traits = {}
with Dataset(w / 'inputdata/clm5_params.c171117.nc') as d:
    for name in ['slatop', 'leafcn', 'flnr', 'fnitr', 'mbbopt', 'roota_par', 'rootb_par', 'smpso', 'smpsc']:
        v = d[name]
        a = np.ma.asarray(v[:])
        axis = v.dimensions.index('pft')
        a = np.take(a, 1, axis=axis)
        assert not np.any(np.ma.getmaskarray(a)) and np.isfinite(a).all() and a.size == 1
        traits[name] = dict(value=float(np.asarray(a).reshape(())), units=getattr(v, 'units', None))
leafn = 1. / (traits['slatop']['value'] * traits['leafcn']['value'])
maximum = leafn * traits['flnr']['value'] * 7.16 * (3.6 * 1000. / 60.) * traits['fnitr']['value']
record = dict(scope='Actual unchanged official R physical case rerun as S48 with restart-every-step diagnostics only. All shared first48 raw meteorological/physical fields must exactly reproduce R before physiology readback is interpreted. No source/initial/met/parameter/window change,not science/year acceptance. Missing non-LUNA fields/masks retained. Equation-derived maximum Vcmax below excludes daylength and is not a measured per-step capacity.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, positive_intervals=48, original_samples=49,
              shared_first48_raw_fields_exact=same, original_R_fields_sha256=old_audit['fields_sha256'],
              fields_sha256=sha(r / 'official-first48-fields.npz'), history=history, initial=initial, restarts=restarts,
              pft_index=1, original_traits=traits, equation_leaf_n_gn_m2=leafn, equation_maximum_vcmax25_without_daylength=maximum)
(r / 'physiology-restarts.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(pbs_job=record['pbs_job'], positive_intervals=48, shared_fields=len(same), all_shared_fields_exact=True,
                      restart_count=len(restarts), traits=traits, equation_maximum_vcmax25_without_daylength=maximum,
                      initial_T10=initial['fields']['T10_VALUE'], first_restart_T10=restarts[0]['fields']['T10_VALUE'], last_restart_T10=restarts[-1]['fields']['T10_VALUE'])), flush=True)

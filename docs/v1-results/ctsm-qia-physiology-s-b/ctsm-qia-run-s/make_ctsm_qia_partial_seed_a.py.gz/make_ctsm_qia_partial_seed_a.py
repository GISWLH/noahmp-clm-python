from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
mode, inputs_arg, root_arg = sys.argv[1:4]
inputs, root = Path(inputs_arg), Path(root_arg)
b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
temperature, theta = 278.722, .28
nt, ns, nh = 15, 5, 10
zeros = ['SNLSNO', 'DZSNO', 'ZSNO', 'ZISNO', 'INT_SNOW', 'H2OSFC', 'H2OSNO', 'H2OCAN',
         'SNOCAN', 'LIQCAN', 'SNOUNLOAD', 'FH2OSFC', 'SNOW_DEPTH', 'frac_sno_eff', 'frac_sno', 'FWET', 'FCANSNO']
temperatures = ['T_SOISNO', 'T_VEG', 'TH2OSFC', 'T_GRND', 'T_GRND_R', 'T_REF2M', 'T_REF2M_R']
physical = zeros + temperatures + ['H2OSOI_LIQ', 'H2OSOI_ICE']
target = inputs / 'CN-Qia.partial-hydrothermal-init.nc'

if mode == 'make':
    geometry = inputs / 'seed-geometry-source'
    geometry.mkdir()
    sources = []
    for key, archive, expected, predicate in [
        ('restart_geometry', b / 'ctsm-qia-run-n/case-configuration-private.tar.gz',
         'ece99750873614fa682add584574d00c0e1d9fdbf12708e913a825efe57c2a0d', lambda n: '.clm2.r.' in n and n.endswith('.nc')),
        ('soil_thickness', b / 'ctsm-qia-run-o/case-configuration-private.tar.gz',
         '0123de586c89dfc65abb0adf424bdaa2155441d50438e5dd2b5bb99e120ce6d1', lambda n: n.endswith('case.clm2.h0.2002-12-31-57600.nc')),
    ]:
        assert sha(archive) == expected
        with tarfile.open(archive) as t:
            found = [m for m in t if m.isfile() and predicate(m.name)]
            assert len(found) == 1
            p = geometry / (key + '.nc')
            p.write_bytes(t.extractfile(found[0]).read())
        sources.append(dict(role=key, archive_sha256=expected, member=found[0].name, file_sha256=sha(p)))
    with Dataset(geometry / 'soil_thickness.nc') as history:
        dz = np.asarray(history['DZSOI'][:], dtype=float).reshape(-1)
        assert dz.size == nt and np.all(np.isfinite(dz)) and np.all(dz > 0)
    with Dataset(geometry / 'restart_geometry.nc') as original, Dataset(target, 'w', format=original.data_model) as out:
        assert len(original.dimensions['column']) == len(original.dimensions['pft']) == 1
        assert np.asarray(original['pfts1d_itypveg'][:]).tolist() == [1]
        out.setncatts({k: original.getncattr(k) for k in original.ncattrs()})
        out.setncattr('derived_seed_scope', 'Geometry only from official N end-year template; every physical field here replaced by predeclared original Python cold T/water/zero snow-canopy targets. Historical state/time/rolling counters not copied. Unlisted variables remain fresh official cold defaults through standard init_interp; soil/depth/aquifer/SP-CN differences persist.')
        for name, dimension in original.dimensions.items():
            out.createDimension(name, None if dimension.isunlimited() else len(dimension))
        included = [n for n in original.variables if n.startswith(('grid1d_', 'land1d_', 'cols1d_', 'pfts1d_')) or n in ['LEVGRND_CLASS', 'COL_Z', 'LEVGRND_CLASS_p', 'COL_Z_p', 'glc_elevclass_bounds'] or n in physical]
        assert all(n in included for n in physical)
        assert not any(n.startswith('timemgr_') or n.endswith(('_VALUE', '_NSTEPS', '_PERIOD')) for n in included)
        for name in included:
            v = original[name]
            attrs = {k: v.getncattr(k) for k in v.ncattrs() if k != '_FillValue'}
            kw = {'fill_value': v.getncattr('_FillValue')} if '_FillValue' in v.ncattrs() else {}
            new = out.createVariable(name, v.dtype, v.dimensions, **kw)
            new.setncatts(attrs)
            data = np.ma.asarray(v[:]).copy()
            if name in zeros:
                data = np.zeros(data.shape, dtype=v.dtype)
            elif name == 'T_SOISNO':
                assert data.shape == (1, ns + nt)
                data = np.zeros(data.shape, dtype=v.dtype)
                data[:, ns:] = temperature
            elif name in temperatures:
                data = np.full(data.shape, temperature, dtype=v.dtype)
            elif name in ['H2OSOI_LIQ', 'H2OSOI_ICE']:
                assert data.shape == (1, ns + nt)
                data = np.zeros(data.shape, dtype=v.dtype)
                if name == 'H2OSOI_LIQ':
                    data[:, ns:ns + nh] = 1000. * theta * dz[:nh]
            new[:] = data
        excluded = sorted(set(original.variables) - set(included))
    record = dict(scope='Predeclared T278.722K and theta0.28 transferred through standard official init_interp partial source. No eoy physical values or clocks/accumulators reused, no output-score fitting. Not all initial/background conditions match: official15thermal/10hydrologic vs native4, soil/aquifer/SP-CN and official fresh accumulator defaults remain.',
                  pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, temperature_K=temperature,
                  liquid_theta_m3m3=theta, soil_thickness_m=dz.tolist(), hydrologic_layers=nh, thermal_layers=nt,
                  hydrologic_depth_m=float(dz[:nh].sum()), thermal_depth_m=float(dz.sum()),
                  zero_fields=zeros, temperature_fields=temperatures, included_variables=included,
                  excluded_historical_variables=excluded, source_files=sources, partial_seed_sha256=sha(target))
    (root / 'partial-seed.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: record[k] for k in ['scope', 'partial_seed_sha256', 'hydrologic_depth_m', 'thermal_depth_m']}), flush=True)
elif mode == 'audit':
    record = json.loads((root / 'partial-seed.json').read_text())
    assert sha(target) == record['partial_seed_sha256']
    dz = np.array(record['soil_thickness_m'])
    p = inputs / 'CN-Qia.official-interpolated-cold.nc'
    with Dataset(p) as d, Dataset(target) as partial:
        checks = {}
        for name in temperatures:
            raw = np.ma.asarray(d[name][:])
            values = np.asarray(raw[:, ns:] if name == 'T_SOISNO' else raw)
            error = float(np.max(abs(values - temperature)))
            assert error <= 1e-10, (name, error)
            checks[name] = dict(maximum_temperature_error_K=error)
        for name in zeros:
            values = np.ma.asarray(d[name][:]).compressed()
            assert np.all(values == 0.), name
            checks[name] = dict(maximum_absolute=float(np.max(abs(values))) if values.size else None)
        liquid, ice = np.asarray(d['H2OSOI_LIQ'][:])[:, ns:], np.asarray(d['H2OSOI_ICE'][:])[:, ns:]
        actual_theta = liquid[:, :nh] / (1000. * dz[:nh])
        theta_error = float(np.max(abs(actual_theta - theta)))
        assert theta_error <= 1e-12 and np.all(ice == 0.) and np.all(liquid[:, nh:] == 0.)
        counters = {n: np.ma.asarray(v[:]).filled(0).tolist() for n, v in d.variables.items() if n.endswith('_NSTEPS')}
        assert all(np.all(np.asarray(v) == 0) for v in counters.values())
        initial_temperatures = {n: np.ma.asarray(v[:]).filled(0).tolist() for n, v in d.variables.items() if n.startswith(('T_VEG24_', 'T_VEG240_'))}
        nstep = np.ma.asarray(d['timemgr_rst_nstep_rad_prev'][:]).filled(0).tolist()
        result = dict(scope='Actual official standard-init_interp destination before first integration, matched declared hydrothermal fields only. All rolling counters remain fresh zero; not a resumed old year or all-conditions scientific match.',
                      pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, checks=checks,
                      maximum_liquid_theta_error_m3m3=theta_error, inactive_bedrock_water_zero=True,
                      fresh_accumulation_counters=counters, official_fresh_vegetation_accumulators=initial_temperatures,
                      official_nstep_rad_prev=nstep, partial_seed_unchanged=True, official_seed_sha256=sha(p))
    (root / 'partial-seed-audit.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(result), flush=True)
else:
    raise ValueError(mode)

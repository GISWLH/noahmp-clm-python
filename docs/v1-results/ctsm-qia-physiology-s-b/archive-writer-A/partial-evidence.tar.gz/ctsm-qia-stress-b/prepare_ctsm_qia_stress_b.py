from pathlib import Path
import ast

p = Path(__file__).resolve().parent
s = (p / 'inspect_ctsm_qia_stress_a.py').read_text().replace("r = b / 'ctsm-qia-stress-a'", "r = b / 'ctsm-qia-stress-b'").replace('ctsm-stress-data-a', 'ctsm-stress-data-b')
old = """        assert not np.any(np.ma.getmaskarray(values)) and np.all(np.isfinite(values))
        stress[name] = dict(units=v.units, mean=float(values.mean()), minimum=float(values.min()), maximum=float(values.max()),
                            daylight_mean=float(values[day].mean()), daylight_minimum=float(values[day].min()), daylight_maximum=float(values[day].max()),
                            values=values.tolist())"""
new = """        mask=np.ma.getmaskarray(values);nonfinite=~np.isfinite(np.ma.getdata(values));valid=~(mask|nonfinite)
        full=bool(valid.all());light=bool(valid[day].all())
        stress[name] = dict(units=v.units,long_name=getattr(v,'long_name',None),status='measured' if full else 'partially measured/unmeasured: original mask/nonfinite retained',
                            samples=48,original_masked_count=int(mask.sum()),original_nonfinite_count=int(nonfinite.sum()),missing_indices=np.flatnonzero(~valid).tolist(),
                            daylight_samples=int(day.sum()),daylight_all_valid=light,
                            mean=float(values.mean()) if full else None,minimum=float(values.min()) if full else None,maximum=float(values.max()) if full else None,
                            daylight_mean=float(values[day].mean()) if light else None,daylight_minimum=float(values[day].min()) if light else None,daylight_maximum=float(values[day].max()) if light else None,
                            values=np.ma.masked_array(np.ma.getdata(values),mask=~valid).tolist())"""
assert s.count(old) == 1
s = s.replace(old, new).replace('np.ma.mean(values, axis=0).filled(None).tolist()', 'np.ma.mean(values, axis=0).tolist()').replace('np.ma.mean(values[day], axis=0).filled(None).tolist()', 'np.ma.mean(values[day], axis=0).tolist()').replace('values=values.filled(None).tolist()', 'values=values.tolist()')
old = """            assert not np.any(np.ma.getmaskarray(values)) and np.all(np.isfinite(values))
            row['values'] = np.asarray(values).tolist()"""
new = """            mask=np.ma.getmaskarray(values);nonfinite=~np.isfinite(np.ma.getdata(values))
            row['original_masked_count']=int(mask.sum());row['original_nonfinite_count']=int(nonfinite.sum())
            row['values']=np.ma.masked_array(np.ma.getdata(values),mask=mask|nonfinite).tolist()"""
assert s.count(old) == 1
s = s.replace(old, new)
ast.parse(s)
(p / 'inspect_ctsm_qia_stress_b.py').write_bytes(s.encode())
s = (p / 'run_ctsm_qia_stress_a.py').read_text().replace('ctsm-qia-stress-a', 'ctsm-qia-stress-b').replace('stress-portable-a', 'stress-portable-b').replace('inspect_ctsm_qia_stress_a.py', 'inspect_ctsm_qia_stress_b.py')
s = s.replace('no science acceptance.', 'no science acceptance. Original PBS236 reader assertion on missing optional diagnostics retained; B records all masks/nonfinite/whole and predeclared daylight availability explicitly without treating missing as zero/pass.')
ast.parse(s)
(p / 'run_ctsm_qia_stress_b.py').write_bytes(s.encode())
s = (p / 'ctsm_qia_stress_a.pbs').read_text().replace('clm-qia-stress-a', 'clm-qia-stress-b').replace('ctsm-qia-stress-a', 'ctsm-qia-stress-b').replace('run_ctsm_qia_stress_a.py', 'run_ctsm_qia_stress_b.py')
(p / 'ctsm_qia_stress_b.pbs').write_bytes(s.encode())
print('Prepared B explicit original missing masks; no model/gate/parameter changes')

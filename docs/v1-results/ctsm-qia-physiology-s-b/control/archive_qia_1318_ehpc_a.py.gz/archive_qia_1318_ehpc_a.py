from pathlib import Path
import datetime
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
results = []


def add_json(t, name, value):
    raw = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    item = tarfile.TarInfo(name); item.size = len(raw)
    t.addfile(item, io.BytesIO(raw))


def roots_archive(name, roots, scope):
    a = b / (name + '-evidence.tar.gz')
    assert not a.exists()
    with tarfile.open(a, 'w:gz') as t:
        for root in roots:
            for p in sorted(root.rglob('*')):
                if p.is_file():
                    t.add(p, arcname=root.name + '/' + p.relative_to(root).as_posix(), recursive=False)
        add_json(t, 'summary.json', dict(scope=scope, utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
    results.append(dict(name=name, sha256=sha(a), bytes=a.stat().st_size))


s = b / 'ctsm-qia-run-s'
cfg = json.loads((s / 'configuration.json').read_text())
d = json.loads((s / 'physiology-restarts.json').read_text())
assert (s / 'pbs-exit.txt').read_text().strip() == '0' and cfg['official_model_returncode'] == 0
assert cfg['upstream_original_bytes_unchanged'] and all(v['returncode'] == 0 for v in cfg['stages'])
assert d['positive_intervals'] == 48 and len(d['restarts']) == 48 and len(d['shared_first48_raw_fields_exact']) == 27 and all(d['shared_first48_raw_fields_exact'].values())
assert (b / 'ctsm-qia-stress-a/pbs-exit.txt').read_text().strip() == '1'
assert (b / 'ctsm-qia-stress-b/pbs-exit.txt').read_text().strip() == (b / 'ctsm-qia-physiology-t-a/pbs-exit.txt').read_text().strip() == '0'
a = b / 'ctsm-qia-physiology-s-a-evidence.tar.gz'
assert not a.exists()
restart_count, raw_files = 0, []
with tarfile.open(a, 'w:gz') as t:
    for root in [s, b / 'ctsm-qia-stress-a', b / 'ctsm-qia-stress-b', b / 'ctsm-qia-physiology-t-a']:
        for p in sorted(root.iterdir()):
            if p.is_file() and p.name != 'case-configuration-private.tar.gz':
                t.add(p, arcname=root.name + '/' + p.name, recursive=False)
    with tarfile.open(s / 'case-configuration-private.tar.gz') as private:
        for m in private:
            if not m.isfile():
                continue
            base = Path(m.name).name
            output_nc = m.name.startswith('output/case/run/') and ('.clm2.r.' in base or '.clm2.h0.' in base) and base.endswith('.nc')
            input_nc = m.name in ['inputdata/CN-Qia.partial-hydrothermal-init.nc', 'inputdata/CN-Qia.official-interpolated-cold.nc', 'inputdata/clm5_params.c171117.nc', 'inputdata/surfdata.CN-Qia.engineering.nc']
            text = m.name.endswith(('.stdout.txt', '.stderr.txt', '.stream')) or m.name.startswith('case/user_nl_') or (m.name.startswith('output/case/run/') and ('.log.' in base or base in ['datm_in', 'lnd_in', 'drv_in']))
            if not (output_nc or input_nc or text):
                continue
            raw = private.extractfile(m).read()
            item = tarfile.TarInfo(s.name + '/workspace/' + m.name); item.size = len(raw)
            t.addfile(item, io.BytesIO(raw))
            if output_nc:
                digest = hashlib.sha256(raw).hexdigest()
                assert cfg['model_outputs'][base]['sha256'] == digest
                raw_files.append(dict(member=m.name, sha256=digest, bytes=len(raw)))
                restart_count += int('.clm2.r.' in base)
    assert restart_count == 48 and len(raw_files) == 50
    add_json(t, 'summary.json', dict(scope='Official S48 repeat-R with only48 endstop/restart-frequency1,model/PBS238actual0,27shared raw fields exact and48actual raw restarts. Original stress236reader failure on masked BTRANMN retained,B237available-data audit0,T241memory/daylength availability audit0. All original masks/nonfinite fields remain missing,not zero/pass. No parameter/source/input changes or year/scientific acceptance.',
             official_pbs='238.manager', original_private_sha256=sha(s / 'case-configuration-private.tar.gz'),
             model_seconds=next(v['seconds'] for v in cfg['stages'] if v['stage'] == 'official-model'), total_seconds=cfg['seconds'],
             raw_model_output_files=raw_files, physiology_readback_sha256=sha(s / 'physiology-restarts.json')))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
results.append(dict(name='ctsm-qia-physiology-s-a', sha256=sha(a), bytes=a.stat().st_size))

roots_archive('k78-current-b-audit-a', [b / 'k78-current-b', b / 'qia-resume-k78-inspection-a'],
              'Current510 K78 GPU raw export independently audited on EHPC PBS239actual1: original MHCN/impurity bounds pass,but original allraw1e-6 fails same HaM thermal layer residual1.52587890625e-5. PBS240actual0 proves own NumPy336 full-state/ledgers/trace copied exactly and inspects original snow geometry. No tolerance/source/failed-year changes; K78 unaccepted. GPU export archive hash475b73f4b7688b27c08315b9b6cde4447a4a189b0a39c567ef5ecb2a3ea14ba0.')
roots_archive('qia3798-numpy-reference-a', [b / 'qia3798-numpy-a'],
              'Actual EHPC PBS242 source510 NumPy reference of exact original509C rejected CUDA3798 surface; fixed1e-7/80 and full coupled surface both returned within original criteria. Original CUDA101/.485879W rejection retained; not an accepted year step,full backend comparison or science acceptance.')

r = b / 'qia-fresh-phase-numpy-year-b'
raw = (r / 'trajectory/report.json').read_bytes(); live = json.loads(raw)
assert live['status'] == 'running' and live['steps_completed'] >= 336 and live['source_unchanged'] and live['steps_requested'] == 17520
paths = [live['checkpoint_file'], live['model_npz']]
assert sha(r / 'trajectory' / paths[0]) == live['checkpoint_sha256'] and sha(r / 'trajectory' / paths[1]) == live['model_npz_sha256']
a = b / 'qia-fresh-phase-numpy-year-launch-b-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():
            t.add(p, arcname=p.name, recursive=False)
    item = tarfile.TarInfo('snapshot/report.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
    for name in paths:
        t.add(r / 'trajectory' / name, arcname='snapshot/' + name, recursive=False)
    parent = json.loads((b / 'qia-fresh-phase-numpy-week-a/trajectory/report.json').read_text())
    for name in [parent['checkpoint_file'], parent['model_npz']]:
        t.add(r / 'trajectory' / name, arcname='initial336/' + name, recursive=False)
    add_json(t, 'summary.json', dict(scope='Actual source510 EHPC PBS235 continues own successful336 full original state/initial/net/bounds/trace with exact same source/input. Live running snapshot only,not complete year/spinup/science; original week and failed trajectories untouched. PBS240 independent exact336 proof archived separately.',
             utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), status=live['status'], steps_completed=live['steps_completed'], steps_requested=17520,
             report_snapshot_sha256=hashlib.sha256(raw).hexdigest(), source_manifest_sha256=sha(r / 'SOURCE_SHA256.json')))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
results.append(dict(name='qia-fresh-phase-numpy-year-launch-b', sha256=sha(a), bytes=a.stat().st_size))
print(json.dumps(results))

from pathlib import Path
import ast

p = Path(__file__).resolve().parent
s = (p / 'run_ctsm_qia_canopy_start_b.py').read_text().replace('ctsm-qia-canopy-start-b', 'ctsm-qia-stress-a').replace('canopy-start-portable-b', 'stress-portable-a').replace('inspect_ctsm_qia_canopy_start_b.py', 'inspect_ctsm_qia_stress_a.py')
s = s.replace('EHPC PBS read-only actual O/Q canopy-initial/history diagnosis with unchanged pinned portable NetCDF environment. Previous PBS229 missing-module failure retained, no physics/data changes.', 'EHPC PBS read-only actual R first48 BTRAN/SMP and unchanged original PFT/soil traits plus configured native initial stress. Pinned portable NetCDF environment and frozen510 NumPy functions, no physics/input/window or parameter modifications;no science acceptance.')
ast.parse(s)
(p / 'run_ctsm_qia_stress_a.py').write_bytes(s.encode())
s = (p / 'ctsm_qia_canopy_start_b.pbs').read_text().replace('clm-qia-canopy-start-b', 'clm-qia-stress-a').replace('ctsm-qia-canopy-start-b', 'ctsm-qia-stress-a').replace('run_ctsm_qia_canopy_start_b.py', 'run_ctsm_qia_stress_a.py')
(p / 'ctsm_qia_stress_a.pbs').write_bytes(s.encode())
print('Prepared stress analysis only; physics and calibration unchanged')

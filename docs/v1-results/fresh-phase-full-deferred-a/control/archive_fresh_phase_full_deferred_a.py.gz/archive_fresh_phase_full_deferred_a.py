from pathlib import Path
import datetime
import hashlib
import io
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-fresh-phase-edge-a'
r = s / 'full-controller-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
launch = json.loads((r / 'launch.json').read_text())
assert sha(s / 'SOURCE_SHA256.json') == launch['source_manifest_sha256']
for n, v in launch['controls_sha256'].items():
    assert sha(b / n) == v
assert sha(r / 'superseded-pending-c.json') == launch['superseded_record_sha256']
cancel = json.loads((r / 'superseded-pending-c.json').read_text())
assert cancel['original_pid'] == 2634162 and cancel['original_gpu_worker_still_absent']
assert not (b / 'p6-most-physical-c/full-controller-c/worker.json').exists()
assert str(b / 'wait_fresh_phase_full_gpu_a.py').encode() in Path('/proc/' + str(launch['pid']) + '/cmdline').read_bytes().split(b'\0')
old_root = b / 'p6-phase-final-check-a'
old = json.loads((old_root / 'full-by-file-a/progress.json').read_text())
snapshot = dict(scope='Actual current1250 queue snapshot; no current collection/worker completion inferred. Original506 results not credited. Only obsolete C idle coordinator canceled, original models remain untouched.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), launch=launch,
                current_worker_present=(r / 'worker.json').exists(), current_exit_present=(r / 'exit.json').exists(),
                previous506=dict(status=old['status'], covered_nodes=old['covered_nodes'], active=old['active'], actual_exit_present=(old_root / 'full-controller-a/exit.json').exists()), superseded_pending_C=cancel)
a = b / 'fresh-phase-full-deferred-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():
            t.add(p, arcname='controller/' + p.name, recursive=False)
    for n in list(launch['controls_sha256']):
        t.add(b / n, arcname='control/' + n, recursive=False)
    t.add(s / 'SOURCE_SHA256.json', arcname='SOURCE_SHA256.json', recursive=False)
    raw = (json.dumps(snapshot, indent=2) + '\n').encode()
    info = tarfile.TarInfo('snapshot.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, current_pid=launch['pid'], current_worker_present=snapshot['current_worker_present'], previous506=snapshot['previous506'])))

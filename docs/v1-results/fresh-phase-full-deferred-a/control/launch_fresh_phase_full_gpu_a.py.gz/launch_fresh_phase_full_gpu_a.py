from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import tarfile
import time

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-fresh-phase-edge-a'
r = s / 'full-controller-a'
assert not r.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 510 and all(sha(s / n) == v for n, v in m.items())
for label, digest in [('fresh-phase-edge-cpu-b', 'e623d1aaac00aedf2f8f2dd0f8b761c4ab1824fab2f5b88fb41cfb9b6f977c25'), ('fresh-phase-edge-gpu-b', '315d548602aac759dcc684346ae7fa75f3ea493585c5d83048a86be4d9e7a2df')]:
    path = b / (label + '-evidence.tar.gz')
    assert sha(path) == digest
    with tarfile.open(path) as t:
        assert json.loads(t.extractfile('SOURCE_SHA256.json').read()) == m
        if label == 'fresh-phase-edge-cpu-b':
            d = json.loads(t.extractfile('cpu-full-receipt.json').read())
            assert d['returncode'] == 0 and d['counts'] == dict(tests=910, failures=0, errors=0, skipped=0) and d['source_unchanged']
        else:
            d = json.loads(t.extractfile('target-a/exit.json').read())
            assert d['passed'] and d['returncode'] == 0
r.mkdir()
old_b = b / 'p6-most-physical-c/full-controller-c'
old_launch = json.loads((old_b / 'launch.json').read_text())
old_pid = int(old_launch['pid'])
assert old_pid == 2634162
wait_file = b / 'p6-phase-final-check-a/full-controller-a/exit.json'
wait_pid = 2557162
cancel = dict(scope='Supersede only obsolete509C idle deferred coordinator after current910CPU/8GPU evidence and complete next pipeline are staged. No model/GPU worker,old493 task,strict real day or annual trajectory is signaled. Original C source/launch/records retained; no fabricated exit code.', original_launch_sha256=sha(old_b / 'launch.json'), original_pid=old_pid, current_source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'))
(r / 'original-pending-c-launch.json').write_bytes((old_b / 'launch.json').read_bytes())
if (old_b / 'worker.json').exists() or (old_b / 'exit.json').exists():
    wait_file = old_b / 'exit.json'
    wait_pid = old_pid
    cancel['action'] = 'No signal; original C already launched/terminated, wait for its actual exit'
else:
    proc = Path('/proc/' + str(old_pid))
    assert proc.exists() and proc.stat().st_uid == os.getuid()
    argv = (proc / 'cmdline').read_bytes().split(b'\0')
    assert str(b / 'wait_most_full_gpu_c.py').encode() in argv
    cancel.update(verified_uid=os.getuid(), original_argv=[a.decode() for a in argv if a], original_start_ticks=int((proc / 'stat').read_text().split()[21]))
    stopped = False
    try:
        # Freeze this owned idle coordinator to close the child-launch race.
        # If a child already exists, resume it and leave the original job alone.
        os.kill(old_pid, signal.SIGSTOP)
        stopped = True
        deadline = time.monotonic() + 5
        while (proc / 'stat').read_text().split()[2] not in ['T', 't']:
            assert time.monotonic() < deadline
            time.sleep(.05)
        children = (proc / 'task' / str(old_pid) / 'children').read_text().strip()
        if children or (old_b / 'worker.json').exists():
            cancel.update(action='Resumed without terminating: existing child/worker observed', children=children)
            wait_file, wait_pid = old_b / 'exit.json', old_pid
        else:
            cancel.update(action='SIGTERM sent only to verified stopped idle C coordinator', children_before_signal='', original_gpu_worker_absent=True)
            (r / 'superseded-pending-c.json').write_text(json.dumps(cancel, indent=2) + '\n')
            os.kill(old_pid, signal.SIGTERM)
    finally:
        if stopped:
            try:
                os.kill(old_pid, signal.SIGCONT)
            except ProcessLookupError:
                pass
    if cancel['action'].startswith('SIGTERM'):
        deadline = time.monotonic() + 10
        while proc.exists() and (proc / 'stat').read_text().split()[2] != 'Z':
            assert time.monotonic() < deadline
            time.sleep(.05)
        cancel.update(observed_terminal_state='absent' if not proc.exists() else 'Z', original_gpu_worker_still_absent=not (old_b / 'worker.json').exists(), actual_returncode='not observable by this external coordinator; no exit receipt invented')
        assert cancel['original_gpu_worker_still_absent']
(r / 'superseded-pending-c.json').write_text(json.dumps(cancel, indent=2) + '\n')
if not wait_file.exists():
    assert Path('/proc/' + str(wait_pid)).exists()
controls = {n: sha(b / n) for n in ['collect_fresh_phase_full_gpu_a.py', 'run_fresh_phase_full_gpu_a.py', 'wait_fresh_phase_full_gpu_a.py', 'launch_fresh_phase_full_gpu_a.py']}
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='1', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_COMPILATION_CACHE_DIR=str(b / 'jax-surface-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NOAHMP_REQUIRE_GPU='1')
launch = dict(scope='Deferred current-source canonical1250: exact same-source910CPU plus8GPU, every remaining332 GPU node will run after actual predecessor exit. Obsolete B pending coordinator superseded with ownership/child guards; original model tasks untouched. Queueing is not collection/completion or science acceptance.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), device=1, source_files=510, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), controls_sha256=controls, wait_for_actual_exit=str(wait_file), wait_for_original_pid=wait_pid, superseded_record_sha256=sha(r / 'superseded-pending-c.json'))
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
with (r / 'controller.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'wait_fresh_phase_full_gpu_a.py')], cwd=s, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
launch['pid'] = p.pid
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps(dict(launch=launch, superseded=cancel)))

"""Stdlib only: bind actual PU/PT and freeze five new PW controls."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT/'surface-7275-feasible-root-pw-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        members = stream.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name:stream.extractfile(m).read() for m in members}


def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    pu_raw = (OUT/'surface-7275-frame-trace-pu-evidence.tar.gz').read_bytes()
    assert sha(pu_raw) == 'c845dcba7ced66ee56f4e8b1b24785eb85f3f636c835e393321f1e67d53b9071'
    pu = unpack(pu_raw)
    index = json.loads(pu['artifact-inventory.json'])
    assert len(pu)==100 and set(index)==set(pu)-{'artifact-inventory.json'}
    assert all(sha(pu[n])==r['sha256'] and len(pu[n])==r['bytes'] for n,r in index.items())
    base = 'result/model/controls/'
    original_manifest = json.loads(pu[base+'CONTROLS_SHA256.json'])
    assert len(original_manifest)==6 and sha(pu[base+'CONTROLS_SHA256.json'])=='73a47e7a4d31bb69c1ad4f9b04b29072e434affed2a2912a46ecc145ce316419'
    copied = {}
    for name in [*original_manifest,'CONTROLS_SHA256.json']:
        data = pu[base+name]
        if name in original_manifest:
            assert sha(data)==original_manifest[name]
        target=PREP/'pu'/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        copied[name]=sha(data)
    binding=json.loads(pu[base+'BINDINGS.json'])
    pt_raw=(OUT/'surface-7275-numpy-reference-pt-evidence.tar.gz').read_bytes()
    assert sha(pt_raw)==binding['PT_archive_sha256']
    pt=unpack(pt_raw)
    pt_index=json.loads(pt['artifact-inventory.json'])
    assert len(pt)==111 and set(pt_index)==set(pt)-{'artifact-inventory.json'}
    assert all(sha(pt[n])==r['sha256'] and len(pt[n])==r['bytes'] for n,r in pt_index.items())
    stage=unpack(pt['executed-stage.tar.gz'])
    source=unpack(stage['source.tar.gz'])
    source_manifest=json.loads(source['SOURCE_SHA256.json'])
    assert len(source_manifest)==584 and set(source)==set(source_manifest)|{'SOURCE_SHA256.json'}
    assert all(sha(source[n])==h for n,h in source_manifest.items())
    phase=ast.parse(source[binding['phase_source_relative_path']])
    solver=next(n for n in phase.body if isinstance(n,ast.FunctionDef) and n.name=='solve_canopy_phase_energy')
    evaluate=next(n for n in solver.body if isinstance(n,ast.FunctionDef) and n.name=='evaluate')
    assert evaluate.lineno==134
    binding.update(PU_archive_sha256=sha(pu_raw),PU_archive_members=100,
        PU_reused_files=copied,PU_original_job='1688.manager',PU_original_model_exit=1,PU_original_analysis_exit=0,
        PW_preparation_scope='Five new controls plus seven exact executed PU dependency files; no numerical execution',
        prepared_only=True,submitted=False,numerical_executed=False,
        additional_evaluations='Future bounded original live-closure calls, separately counted; not physical time steps',
        initial_states_changed=False)
    save(PREP/'BINDINGS.json',binding)
    new_names=['diagnose_live_closure_pw.py','probe_feasible_root_pw.py','POLICY.json','BINDINGS.json','README.md']
    names=new_names+['pu/'+n for n in copied]
    assert {p.relative_to(PREP).as_posix() for p in PREP.rglob('*') if p.is_file()}<=set(names)|{'CONTROLS_SHA256.json'}
    for name in names:
        if name.endswith('.py'):
            ast.parse((PREP/name).read_bytes())
    wrapper=ast.parse((PREP/'probe_feasible_root_pw.py').read_bytes())
    diagnostic=ast.parse((PREP/'diagnose_live_closure_pw.py').read_bytes())
    assert len([n for n in ast.walk(wrapper) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='pu' and n.func.attr=='main'])==1
    assert len([n for n in ast.walk(diagnostic) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='evaluate'])==1
    assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('settrace','qsub') for n in ast.walk(wrapper))
    assert not any(isinstance(n,ast.Import) and any(a.name=='pickle' for a in n.names) for n in ast.walk(wrapper))
    controls={n:sha((PREP/n).read_bytes()) for n in names}
    save(PREP/'CONTROLS_SHA256.json',controls)
    record=dict(passed=True,scope='Stdlib hash/AST only; no NumPy/SciPy import, array decoding, SSH or numerical work',
        new_controls=5,reused_PU_files_exact=7,controls=len(controls),controls_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        source_files_exact=584,PU_archive_members=100,PT_archive_members=111,
        original_wrapper_call_sites=1,diagnostic_original_evaluate_call_sites=1,
        numerical_executed=False,submitted=False)
    save(OUT/'surface-7275-feasible-root-pw-static.json',record)
    print(json.dumps(record))


if __name__=='__main__':
    main()

"""Mechanical PU execution reuse; stdlib metadata only, no deployment."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE/'surface-7275-feasible-root-pw-preparation'
EXECUTION = BASE/'surface-7275-feasible-root-pw-execution'
OLD = BASE/'surface-7275-frame-trace-pu-execution'
PREP_SHA = '858566c1b94b1852ed01f38e78e0dfe43456f2eb2efd39b1c81885e363d2441a'
sha = lambda raw:hashlib.sha256(raw).hexdigest()
encode = lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def main():
    assert sha((PREP/'CONTROLS_SHA256.json').read_bytes())==PREP_SHA
    controls=json.loads((PREP/'CONTROLS_SHA256.json').read_bytes())
    assert len(controls)==12 and all(sha((PREP/n).read_bytes())==h for n,h in controls.items())
    review=(BASE/'surface-7275-feasible-root-pw-independent-review-rg.json').read_bytes()
    reviewed=json.loads(review)
    assert reviewed['passed'] and not reviewed['blocking_findings'] and reviewed['controls_manifest_sha256']==PREP_SHA
    binding=json.loads((PREP/'BINDINGS.json').read_bytes())
    archives={key:(BASE/filename).read_bytes() for key,filename in (
        ('pt-evidence.tar.gz','surface-7275-numpy-reference-pt-evidence.tar.gz'),
        ('pu-evidence.tar.gz','surface-7275-frame-trace-pu-evidence.tar.gz'))}
    assert sha(archives['pt-evidence.tar.gz'])==binding['PT_archive_sha256']
    assert sha(archives['pu-evidence.tar.gz'])==binding['PU_archive_sha256']
    EXECUTION.mkdir(exist_ok=False)
    diffs=[]
    for original,target in (('check_stage_pu.py','check_stage_pw.py'),('dispatch_frame_pu.py','dispatch_feasible_pw.py')):
        old=(OLD/original).read_text()
        new=old.replace('surface-frame-trace-pu','surface-feasible-root-pw').replace('dispatch_frame_pu','dispatch_feasible_pw').replace('check_stage_pu','check_stage_pw').replace('frame_pu.pbs','feasible_pw.pbs').replace('PU stage','PW stage').replace('exact PU','exact PW')
        (EXECUTION/target).write_text(new,encoding='utf-8',newline='\n')
        diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=original,tofile=target))
    old=(OLD/'frame_pu.pbs').read_text()
    new=old.replace('surface-frame-pu','surface-feasible-pw').replace('surface-frame-trace-pu','surface-feasible-root-pw').replace('frame-result','pw-result').replace('check_stage_pu.py','check_stage_pw.py')
    old_command='"$py" -B "$stage/preparation/trace_qia_pu.py" --pt "$stage/pt-evidence.tar.gz" --output "$root/model" > "$root/model.stdout" 2> "$root/model.stderr"'
    new_command='"$py" -B "$stage/preparation/probe_feasible_root_pw.py" --pu "$stage/pu-evidence.tar.gz" --pt "$stage/pt-evidence.tar.gz" --output "$root/probe" > "$root/worker.stdout" 2> "$root/worker.stderr"'
    assert old_command in new
    new=new.replace(old_command,new_command).replace('model_status','worker_status').replace('model-exit.txt','worker-exit.txt')
    analysis='    "$py" -B "$stage/execution/analyze_frame_pu.py" --root "$root" > "$root/analysis.stdout" 2> "$root/analysis.stderr"\n    analysis_status=$?\n    echo "$analysis_status" > "$root/analysis-exit.txt"\n'
    assert analysis in new
    new=new.replace(analysis,'    if test -f "$root/probe/diagnostic-status.txt"; then\n        cp "$root/probe/diagnostic-status.txt" "$root/diagnostic-status.txt"\n    fi\n')
    new=new.replace("--exclude='./model/source-nm'","--exclude='./probe/original-model/source-nm'")
    (EXECUTION/'feasible_pw.pbs').write_text(new,encoding='utf-8',newline='\n')
    diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frame_pu.pbs',tofile='feasible_pw.pbs'))
    (EXECUTION/'README.md').write_text('PW mechanically reuses the reviewed PU transfer and 1CPU/2GiB/10min PBS. One child runs the frozen PW wrapper. There is no second numerical analysis process. Raw worker/PBS exit and wrapper diagnostic status remain separate; the original error must remain worker/PBS 1. All paths are new private /tmp paths; original sources and jobs are untouched. Prepared-only until deployment; actual execution is documented separately.\n',encoding='utf-8')
    execution_binding=dict(preparation_manifest_sha256=PREP_SHA,preparation_controls=12,
        preparation_review_sha256=sha(review),PU_archive_sha256=binding['PU_archive_sha256'],PT_archive_sha256=binding['PT_archive_sha256'],
        source_manifest_sha256=binding['source_manifest_sha256'],planned_reference_calls=1,
        planned_full_column_calls=0,planned_GPU_calls=0,diagnostic_actual_call_cap=12000,
        diagnostic_seconds_per_start=45,PBS_resources='1CPU/2GiB/10min/compute002',
        preserve_original_model_exit=True,current_status='prepared-only',submitted=False)
    (EXECUTION/'EXECUTION_BINDINGS.json').write_bytes(encode(execution_binding))
    names=['check_stage_pw.py','dispatch_feasible_pw.py','feasible_pw.pbs','README.md','EXECUTION_BINDINGS.json']
    index={n:sha((EXECUTION/n).read_bytes()) for n in names}
    (EXECUTION/'CONTROLS_SHA256.json').write_bytes(encode(index))
    for p in EXECUTION.glob('*.py'):
        ast.parse(p.read_bytes())
    (BASE/'surface-7275-feasible-root-pw-execution.diff').write_text(''.join(diffs),encoding='utf-8')
    items={'preparation/'+n:(PREP/n).read_bytes() for n in [*controls,'CONTROLS_SHA256.json']}
    items.update({'execution/'+n:(EXECUTION/n).read_bytes() for n in [*index,'CONTROLS_SHA256.json']})
    items.update(archives)
    items['preparation-independent-review.json']=review
    items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/'surface-7275-feasible-root-pw-stage.tar.gz'
    assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as archive:
        for name,raw in sorted(items.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644
            archive.addfile(member,io.BytesIO(raw))
    with tarfile.open(target) as archive:
        assert {m.name:archive.extractfile(m).read() for m in archive.getmembers()}==items
    output=dict(passed=True,scope='Stdlib mechanical execution preparation only; no numerical execution/submission',
        preparation_manifest_sha256=PREP_SHA,preparation_review_sha256=sha(review),
        execution_manifest_sha256=sha((EXECUTION/'CONTROLS_SHA256.json').read_bytes()),
        execution_controls=5,stage_sha256=sha(target.read_bytes()),stage_members=len(items),stage_bytes=target.stat().st_size,
        execution_diff_sha256=sha((BASE/'surface-7275-feasible-root-pw-execution.diff').read_bytes()))
    (BASE/'surface-7275-feasible-root-pw-execution-static.json').write_bytes(encode(output))
    print(json.dumps(output))


if __name__=='__main__':
    main()

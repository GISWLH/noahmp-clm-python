"""PW1700 raw/hash/JSON/opaque NPY closure. No local numerical imports."""
import base64
import ast
import gzip
import io
import itertools
import json
import math
from pathlib import Path
import re
import tarfile
import zipfile

from package_surface_reference_pt import files, descriptors, scalar_tree, sha, encode

BASE=Path(__file__).resolve().parent
LABEL='surface-7275-feasible-root-pw'
PREP='858566c1b94b1852ed01f38e78e0dfe43456f2eb2efd39b1c81885e363d2441a'
EXEC='dafb1301902086870ab55efc897d247c31fd23359368af276905ff3e6ffefdb7'
STAGE='c534bca6b9de70e31275bb8b0d264eda9f69828c729334701bfc6cb91a5b8cc5'
RESULT='44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef'


def opaque_packet(raw,metadata):
    """Honor NPY storage order using opaque item-byte permutation, no decode."""
    assert sha(raw)==metadata['npz_sha256']
    expected=descriptors(metadata['tree']);fortran=[]
    assert len(expected)==metadata['array_count']
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        assert set(archive.namelist())=={n+'.npy' for n in expected}
        for name,descriptor in expected.items():
            raw_npy=archive.read(name+'.npy')
            assert raw_npy[:6]==b'\x93NUMPY'
            version=tuple(raw_npy[6:8]);assert version in ((1,0),(2,0),(3,0))
            width=2 if version==(1,0) else 4
            length=int.from_bytes(raw_npy[8:8+width],'little')
            header=ast.literal_eval(raw_npy[8+width:8+width+length].decode())
            payload=raw_npy[8+width+length:]
            assert header['descr']==descriptor['dtype'] and list(header['shape'])==descriptor['shape']
            assert re.fullmatch(r'[<|>][fibucmM?][0-9]+',header['descr'])
            size=int(header['descr'][2:]);shape=header['shape']
            assert len(payload)==math.prod(shape)*size and type(header['fortran_order']) is bool
            if header['fortran_order']:
                fortran.append(name)
                # Descriptor hashes the C-order bytes. Move opaque dtype-sized
                # chunks according to shape only; never parse a stored number.
                strides=[math.prod(shape[:i]) for i in range(len(shape))]
                ordered=bytearray()
                for coordinate in itertools.product(*(range(n) for n in shape)):
                    offset=sum(k*s for k,s in zip(coordinate,strides))*size
                    ordered.extend(payload[offset:offset+size])
                payload=bytes(ordered)
            assert sha(payload)==descriptor['c_order_sha256']
    return len(expected),fortran


def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    result_raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes()
    assert sha(stage_raw)==STAGE and sha(result_raw)==RESULT
    stage=files(stage_raw);original=files(result_raw,directories=True)
    index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==23 and set(index)==set(stage)-{'stage-inventory.json'}
    assert all(sha(stage[n])==h for n,h in index.items())
    prep=json.loads(stage['preparation/CONTROLS_SHA256.json']);execution=json.loads(stage['execution/CONTROLS_SHA256.json'])
    assert len(prep)==12 and len(execution)==5
    assert sha(stage['preparation/CONTROLS_SHA256.json'])==PREP and sha(stage['execution/CONTROLS_SHA256.json'])==EXEC
    for directory,controls,prefix in [('preparation',prep,'probe/controls'),('execution',execution,'execution-controls')]:
        for name in [*controls,'CONTROLS_SHA256.json']:
            if name in controls:
                assert sha(stage[directory+'/'+name])==controls[name]
            assert original[prefix+'/'+name]==stage[directory+'/'+name]
    review=json.loads(stage['preparation-independent-review.json'])
    assert review['passed'] and not review['blocking_findings'] and review['controls_manifest_sha256']==PREP
    binding=json.loads(stage['preparation/BINDINGS.json'])
    for name,key,count in [('pu-evidence.tar.gz','PU_archive_sha256',100),('pt-evidence.tar.gz','PT_archive_sha256',111)]:
        assert sha(stage[name])==binding[key]
        prior=files(stage[name]);manifest=json.loads(prior['artifact-inventory.json'])
        assert len(prior)==count and set(manifest)==set(prior)-{'artifact-inventory.json'}
        assert all(sha(prior[n])==r['sha256'] and len(prior[n])==r['bytes'] for n,r in manifest.items())
    pt=files(stage['pt-evidence.tar.gz']);pt_stage=files(pt['executed-stage.tar.gz'])
    source=files(pt_stage['source.tar.gz']);source_index=json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index)==584 and set(source)==set(source_index)|{'SOURCE_SHA256.json'}
    assert all(sha(source[n])==h for n,h in source_index.items())
    assert len(original)==86
    assert original['worker-exit.txt'].strip()==original['pbs-command-exit.txt'].strip()==b'1'
    assert original['diagnostic-status.txt'].strip()==original['probe/diagnostic-status.txt'].strip()==b'0'
    assert original['setup-exit.txt'].strip()==original['stage-after-exit.txt'].strip()==b'0'
    assert original['stage-inventory.json']==stage['stage-inventory.json']
    for name in ('stage-before.json','stage-after.json'):
        check=json.loads(original[name]);assert check['passed'] and check['actual']==check['expected']==index and not check['mismatches']
    receipt=json.loads(original['probe/receipt.json'])
    assert receipt['pbs_job']=='1700.manager' and receipt['actual_child_returncode'] is None
    assert receipt['original_reference_wrapper_calls']==1 and receipt['original_reference_wrapper_returns']==0
    assert receipt['diagnostic_status']==0 and receipt['immutable_checks_passed']
    assert receipt['full_column_calls']==receipt['GPU_calls']==receipt['physical_time_steps_completed']==0
    assert not receipt['original_model_repaired'] and not receipt['scientific_model_acceptance']
    assert receipt['original_exception_message']==binding['expected_exception']
    assert receipt['original_exception_message'] in original['worker.stderr'].decode()
    pu_record=json.loads(original['probe/original-model/receipt.json'])
    assert pu_record['same_PT_exception_site'] and pu_record['same_PT_exception_message'] and pu_record['immutable_checks_passed']
    assert pu_record['reference_calls_started']==1 and pu_record['reference_calls_returned']==0
    assert pu_record['additional_evaluate_calls']==0  # This receipt covers the model attempt ONLY.
    for name in ('source-before-diagnostic.json','source-after-diagnostic.json'):
        assert json.loads(original['probe/'+name])==source_index
    inputs=json.loads(original['probe/input-before-diagnostic.json'])
    assert len(inputs)==15 and inputs==json.loads(original['probe/input-after-diagnostic.json'])
    assert inputs==json.loads(original['probe/original-model/input-before.json'])==json.loads(original['probe/original-model/input-after.json'])
    packet_before=json.loads(original['probe/original-packet-before-diagnostic.json'])
    packet_after=json.loads(original['probe/original-packet-after-diagnostic.json'])
    packet={n.removeprefix('probe/original-model/'):b for n,b in original.items() if n.startswith('probe/original-model/')}
    packet.update({'source-nm/'+n:b for n,b in source.items()})
    assert len(packet)==605 and {n:sha(b) for n,b in packet.items()}==packet_before==packet_after
    packet_counts={};fortran_members={}
    for name,raw in original.items():
        if name.endswith('.json'):
            doc=json.loads(raw)
            if isinstance(doc,dict) and doc.get('schema')=='PT-lossless-return-v1':
                stem=name.removesuffix('.json')
                packet_counts[stem],fortran_members[stem]=opaque_packet(original[stem+'.npz'],doc)
                assert sha(original[stem+'.pkl'])==doc['pickle_sha256']
    trees=[json.loads(original['probe/'+n+'.json'])['tree'] for n in ('closure-before-diagnostic','closure-after-diagnostic','diagnostic/closure-before','diagnostic/closure-after')]
    assert trees.count(trees[0])==4
    summary=scalar_tree(json.loads(original['probe/diagnostic/diagnostic-summary.json'])['tree'])
    assert summary['original_closure_before_after_exact'] and summary['original_exception_retained']
    assert summary['additional_original_evaluate_calls_started']==summary['additional_original_evaluate_calls_returned']==589
    assert receipt['diagnostic_progress']==dict(evaluate_calls_started=589,evaluate_calls_returned=589)
    assert summary['additional_physical_time_steps']==summary['GPU_calls']==summary['full_column_calls']==0
    starts=[]
    for name,expected_calls,root in [('stalled_x',288,False),('stored_ambient',301,True)]:
        entry=scalar_tree(json.loads(original['probe/diagnostic/'+name+'-diagnostic.json'])['tree'])
        assert entry['counters']==dict(started=expected_calls,returned=expected_calls,detail_started=1,detail_returned=1)
        assert entry['diagnostic_root_found'] is root and entry['finite_residuals'] and entry['within_original_bounds']
        assert entry['seconds']<45 and entry['first_evaluated_point_equals_declared_seed']
        assert entry['maximum_original_12_residual']<=1e-7 if root else entry['maximum_original_12_residual']>1e-7
        assert entry['maximum_original_physical11_residual']<=1.01e-7 if root else entry['maximum_original_physical11_residual']>1.01e-7
        opt=entry['optimizer_result']
        starts.append({k:entry[k] for k in ('name','counters','seconds','diagnostic_root_found','maximum_original_12_residual','maximum_original_physical11_residual','first_evaluated_point_equals_declared_seed')} |
            dict(optimizer={k:opt[k] for k in ('success','status','message','nfev','njev','cost','optimality')},
                 cost_optimality_note='Original 0d NumPy fields are opaque descriptors; not decoded numerically on Windows.'))
    assert receipt['conditional_roots_validated']==['stored_ambient']
    algebra=scalar_tree(json.loads(original['probe/diagnostic/stored-direction-algebra.json'])['tree'])
    readout=dict(pbs_job='1700.manager',job_state='F',PBS_exit=1,Stageout_status=0,
        actual_worker_exit=1,actual_diagnostic_status=0,original_exception=receipt['original_exception_message'],
        wrapper_seconds=receipt['seconds'],original_reference_calls=1,original_reference_returns=0,
        additional_evaluate_started=589,additional_evaluate_returned=589,starts=starts,
        stored_direction_algebra={k:{n:v[n] for n in ('residual_dot_J_delta','squared_norm_first_derivative','relative_squared_norm_first_derivative','linearized_residual_at_unit_normalized_step')} for k,v in algebra.items()},
        numpy_version=summary['numpy_version'],scipy_version=summary['scipy_version'],
        source584_exact=True,encoded15_exact=True,original_packet605_exact=True,live_closure_exact=True,
        scientific_model_acceptance=False,model_repaired=False,
        scope='Original model still failed. One original fixed-mask root is feasible from stored ambient; stalled start is a nonroot despite optimizer success. No causal or repair conclusion. Scalars are existing EHPC JSON; arrays remain opaque descriptors.')
    closure=BASE/(LABEL+'-closure')
    qstat=(closure/'qstat.stdout').read_text()
    assert 'Job Id: 1700.manager' in qstat and re.search(r'job_state = F\b',qstat) and 'Exit_status = 1' in qstat and 'Stageout_status = 0' in qstat
    assert json.loads((closure/'qstat.json').read_bytes())['actual_exit']==0
    items={'result/'+n:b for n,b in original.items()}
    for host in ('manager','compute'):
        remote=json.loads((closure/(host+'.stdout')).read_bytes())
        assert json.loads((closure/(host+'.json')).read_bytes())['actual_exit']==0
        assert remote['all_stage_immutable'] and remote['stage_files_before']==remote['stage_files_after']==index
        if host=='compute':
            assert remote['result_archive_sha256']==RESULT and base64.b64decode(remote['files']['pbs-exit.txt']).strip()==b'1'
        for name,raw in remote['files'].items():
            items['closed-'+host+'/'+name]=base64.b64decode(raw)
    assert json.loads(items['closed-manager/dispatch.json'])['stage_sha256']==STAGE
    verification=dict(passed=True,scope='Stdlib original hash/JSON/opaque NPY header+payload validation only; no local array decode or numerical calls',
        prep_manifest_sha256=PREP,execution_manifest_sha256=EXEC,stage_sha256=STAGE,original_result_sha256=RESULT,
        actual_job='1700.manager',actual_PBS_exit=1,actual_Stageout_status=0,actual_worker_exit=1,diagnostic_status=0,
        source_files=584,encoded_inputs=15,original_model_packet_files=605,
        original_result_files=86,typed_packets=len(packet_counts),opaque_array_payloads=sum(packet_counts.values()),
        typed_packet_counts=packet_counts,fortran_storage_members={k:v for k,v in fortran_members.items() if v},
        fortran_validation='NPY shape/itemsize-directed opaque byte permutation to descriptor C-order; no numerical value decoding',
        conditional_root_seed='stored_ambient',model_scientific_pass=False)
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    items.update({'readout.json':encode(readout),'verification.json':encode(verification),
        'original-result.tar.gz':result_raw,'executed-stage.tar.gz':stage_raw})
    for directory in [BASE/(LABEL+'-deployment'),closure]:
        for path in sorted(directory.rglob('*')):
            if path.is_file():items[directory.name+'/'+path.relative_to(directory).as_posix()]=path.read_bytes()
    for name in ('prepare_surface_feasible_root_pw.py','prepare_surface_feasible_root_pw_execution.py',
        LABEL+'-static.json',LABEL+'-execution-static.json',LABEL+'-execution.diff',
        LABEL+'-independent-review-rg.json','review_surface_feasible_root_pw_rg.py',
        'deploy_surface_feasible_root_pw.py','read_surface_feasible_root_pw_status.py','read_surface_feasible_root_pw_closed.py',
        'collect_surface_feasible_root_pw_closed.py','package_surface_feasible_root_pw.py','package_surface_reference_pt.py',LABEL+'-result-download.json'):
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['SCOPE.md']=b'''# PW1700 actual failure and separate feasible-root diagnosis

PBS F1 / Stageout0, worker1, diagnostic0. The unchanged Qia surface attempt still raises its original iteration30 residual13.75804 exception. The original failure is not normalized to success. It made one original reference attempt with no return or completed physical timestep.

After that failure, the same process retained the original live closure and performed exactly the two declared separate diagnostics. Stalled_x:288 actual extra evaluate calls, maximum original r12 10.769007465341872, physical11 1.7446254742888212: nonroot despite SciPy success. Stored_ambient:301 calls, both maxima9.61564161627848e-13: conditional root within the unchanged original bounds and active mask, under the original 1e-7 and 1.01e-7 gates. Total589 extra physics-function residual evaluations, not column timesteps. No full-column/GPU/year continuation or parameter/initial-state adoption.

All584 source files,15 encoded inputs,605 original model-packet files and live closure are unchanged after diagnosis. Root feasibility does not establish the failure cause or constitute a production repair. Three stored branch matrix/step algebra records may have different ages. Both starts, every returned point/residual, full original detail, exception, policy, actual counts and typed raw arrays are retained. Cost/optimality0d arrays and vector algebra are kept opaque on Windows; existing EHPC JSON scalars alone are reported.

No extra model call, numerical rerun, input adjustment or retry was performed during closure. Expanded source is reconstructable from exact NM bytes within the executed PT input archive; it was excluded from the result tar. The original compressed result and executed stage are preserved unchanged.
'''
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as archive:
        for name,raw in sorted(items.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    package=dict(label=LABEL,archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,
        artifacts=len(items),members=len(items),scope='PW1700 actual F1/Stageout0 and original Qia failure; bounded live-closure diagnostic0 finds one conditional root. No model repair, GPU/column/year or scientific acceptance.',verification=verification)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package))
    print(json.dumps(package))


if __name__=='__main__':
    main()

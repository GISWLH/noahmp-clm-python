"""Re-raise one original Qia error after a separate bounded live-closure probe."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import time
import traceback

from diagnose_live_closure_pw import run_diagnostics

HERE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def hashes(root):
    return {p.relative_to(root).as_posix(): sha(p.read_bytes())
            for p in sorted(root.rglob('*')) if p.is_file()}


def load_pu():
    spec = importlib.util.spec_from_file_location('unchanged_pu_pw', HERE/'pu/trace_qia_pu.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def authenticate_pu(path, binding, pu):
    raw = path.read_bytes()
    assert sha(raw) == binding['PU_archive_sha256']
    files = pu.unpack(raw)
    index = json.loads(files['artifact-inventory.json'])
    assert len(files) == 100 and set(index) == set(files)-{'artifact-inventory.json'}
    assert all(sha(files[n]) == r['sha256'] and len(files[n]) == r['bytes'] for n,r in index.items())
    terminal = files['surface-7275-frame-trace-pu-closure/qstat.stdout'].decode()
    assert all(t in terminal for t in ('Job Id: 1688.manager','job_state = F','Exit_status = 1','Stageout_status = 0'))
    assert files['result/model-exit.txt'].strip() == b'1'
    assert files['result/analysis-exit.txt'].strip() == b'0'
    receipt = json.loads(files['result/model/receipt.json'])
    assert receipt['reference_calls_started'] == 1 and receipt['reference_calls_returned'] == 0
    assert receipt['exception_message'] == binding['expected_exception']
    assert receipt['same_PT_exception_site'] and receipt['immutable_checks_passed']
    for name,h in binding['PU_reused_files'].items():
        assert sha(files['result/model/controls/'+name]) == h
        assert files['result/model/controls/'+name] == (HERE/'pu'/name).read_bytes()
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pt', required=True, type=Path)
    parser.add_argument('--pu', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args_cli = parser.parse_args()
    assert os.name != 'nt' and socket.gethostname().split('.')[0] == 'compute002'
    assert os.environ.get('PBS_JOBID') and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == '' and sys.gettrace() is None
    assert all(os.environ.get(k) == '1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    root = args_cli.output.resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    binding = json.loads((HERE/'BINDINGS.json').read_bytes())
    policy = json.loads((HERE/'POLICY.json').read_bytes())
    controls = json.loads((HERE/'CONTROLS_SHA256.json').read_bytes())
    assert all(sha((HERE/n).read_bytes()) == h for n,h in controls.items())
    assert sha(args_cli.pt.read_bytes()) == binding['PT_archive_sha256']
    pu = load_pu()
    prior = authenticate_pu(args_cli.pu, binding, pu)
    root.mkdir()
    shutil.copytree(HERE,root/'controls')
    (root/'original-PU-model-receipt.json').write_bytes(prior['result/model/receipt.json'])
    (root/'original-PU-traceback.txt').write_bytes(prior['result/model/traceback.txt'])
    model = root/'original-model'
    record = dict(schema='PW-original-failure-plus-independent-diagnostic-v1',
        pbs_job=os.environ['PBS_JOBID'], host=socket.gethostname(),
        original_reference_wrapper_calls=0, original_reference_wrapper_returns=0,
        original_model_repaired=False, scientific_model_acceptance=False,
        full_column_calls=0, GPU_calls=0, physical_time_steps_completed=0,
        actual_child_returncode=None, diagnostic_status=None,
        controls_manifest_sha256=sha((HERE/'CONTROLS_SHA256.json').read_bytes()),
        original_PU_archive_sha256=binding['PU_archive_sha256'], policy=policy,
        diagnostic_progress=dict(evaluate_calls_started=0,evaluate_calls_returned=0))
    started = time.monotonic()
    old_argv = sys.argv
    try:
        sys.argv = [str(HERE/'pu/trace_qia_pu.py'),'--pt',str(args_cli.pt),'--output',str(model)]
        record['original_reference_wrapper_calls'] += 1
        pu.main()  # EXACT PU call; original helper and scientific source unchanged.
        record['original_reference_wrapper_returns'] += 1
    except BaseException as original:
        record.update(original_exception_type=type(original).__name__, original_exception_message=str(original))
        try:
            (root/'original-traceback.txt').write_text(traceback.format_exc())
            assert type(original) is RuntimeError and str(original) == binding['expected_exception']
            source_frames, pu_frames = [], []
            tb = original.__traceback__
            while tb is not None:
                frame = tb.tb_frame
                if frame.f_code is pu.main.__code__:
                    pu_frames.append(frame)
                if frame.f_code.co_name == 'solve_canopy_phase_energy' and tb.tb_lineno == 357:
                    assert Path(frame.f_code.co_filename).resolve() == (model/'source-nm'/binding['phase_source_relative_path']).resolve()
                    source_frames.append(frame)
                tb = tb.tb_next
            assert len(source_frames) == len(pu_frames) == 1
            original_receipt = json.loads((model/'receipt.json').read_bytes())
            assert original_receipt['immutable_checks_passed'] and original_receipt['same_PT_exception_site']
            assert original_receipt['reference_calls_started'] == 1 and original_receipt['reference_calls_returned'] == 0
            live = dict(pu_frames[0].f_locals)
            source, manifest, encoded_args = live['source'], live['manifest'], live['args']
            ref, pt = live['ref'], live['pt']
            assert len(manifest) == 584 and len(encoded_args) == 15
            before_source = {n:sha((source/n).read_bytes()) for n in manifest}
            before_input = [ref.array_identity(a) for a in encoded_args]
            before_packet = hashes(model)
            assert before_source == manifest
            assert before_input == json.loads((model/'input-after.json').read_bytes())
            save(root/'source-before-diagnostic.json',before_source)
            save(root/'input-before-diagnostic.json',before_input)
            save(root/'original-packet-before-diagnostic.json',before_packet)
            evaluate = source_frames[0].f_locals['evaluate']
            closure = dict(zip(evaluate.__code__.co_freevars,(c.cell_contents for c in evaluate.__closure__)))
            pt.dump_return(root/'closure-before-diagnostic',copy.deepcopy(closure))
            before_closure = json.loads((root/'closure-before-diagnostic.json').read_bytes())['tree']
            try:
                report = run_diagnostics(source_frames[0],root/'diagnostic',pt.dump_return,policy,record['diagnostic_progress'])
                record['diagnostic_status'] = 0
                record['conditional_roots_before_outer_audit'] = [r['name'] for r in report['starts'] if r['diagnostic_root_found']]
            except BaseException:
                record['diagnostic_status'] = 1
                record['diagnostic_traceback'] = traceback.format_exc()
            finally:
                # PU's earlier receipt does NOT cover this later diagnostic.
                # Independently recheck all original source/encoded input/live
                # closure/original packet bytes after EVERY diagnostic outcome.
                after_source = {n:sha((source/n).read_bytes()) for n in manifest}
                after_input = [ref.array_identity(a) for a in encoded_args]
                after_packet = hashes(model)
                pt.dump_return(root/'closure-after-diagnostic',copy.deepcopy(closure))
                after_closure = json.loads((root/'closure-after-diagnostic.json').read_bytes())['tree']
                save(root/'source-after-diagnostic.json',after_source)
                save(root/'input-after-diagnostic.json',after_input)
                save(root/'original-packet-after-diagnostic.json',after_packet)
                record.update(source584_exact=after_source==before_source==manifest,
                    encoded15_exact=after_input==before_input,
                    original_packet_exact=after_packet==before_packet,
                    live_closure_exact=after_closure==before_closure,
                    source_files=len(manifest), encoded_arrays=len(encoded_args), original_packet_files=len(before_packet))
        except BaseException:
            record['diagnostic_status'] = 1
            record['capture_or_audit_error'] = traceback.format_exc()
        finally:
            try:
                record.update(controls_after_exact=all(sha((HERE/n).read_bytes())==h for n,h in controls.items()),
                    controls_manifest_after_exact=sha((HERE/'CONTROLS_SHA256.json').read_bytes())==record['controls_manifest_sha256'],
                    PU_archive_after_exact=sha(args_cli.pu.read_bytes())==binding['PU_archive_sha256'],
                    PT_archive_after_exact=sha(args_cli.pt.read_bytes())==binding['PT_archive_sha256'],
                    trace_still_absent=sys.gettrace() is None)
                record['immutable_checks_passed'] = all(record.get(k) is True for k in (
                    'source584_exact','encoded15_exact','original_packet_exact','live_closure_exact',
                    'controls_after_exact','controls_manifest_after_exact','PU_archive_after_exact','PT_archive_after_exact','trace_still_absent'))
                if not record['immutable_checks_passed']:
                    record['diagnostic_status'] = 1
                record['conditional_roots_validated'] = record.get('conditional_roots_before_outer_audit',[]) if record['immutable_checks_passed'] and record['diagnostic_status']==0 else []
                record['seconds'] = time.monotonic()-started
                save(root/'receipt.json',record)
                (root/'diagnostic-status.txt').write_text(str(record['diagnostic_status'])+'\n')
            except BaseException:
                try:
                    sys.stderr.write('PW evidence write failed; original exception is preserved:\n'+traceback.format_exc())
                except BaseException:
                    pass
        raise  # Preserve the SAME original RuntimeError, even on diagnostic IO failure.
    finally:
        sys.argv = old_argv
    # An unexpected original successful return is not the requested failure probe.
    record['diagnostic_status'] = 1
    record['unexpected_original_return'] = True
    save(root/'receipt.json',record)
    raise RuntimeError('Original Qia returned; diagnostic closure was not available and was not synthesized')


if __name__ == '__main__':
    main()

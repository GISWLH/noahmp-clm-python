"""Bounded post-failure algebra/least squares, using a live original closure."""
import copy
import json
import os
from pathlib import Path
import socket
import time
import traceback


class DiagnosticLimit(RuntimeError):
    pass


def run_diagnostics(frame, output, dump, policy, progress):
    assert os.name != 'nt' and socket.gethostname().split('.')[0] == 'compute002'
    assert os.environ.get('PBS_JOBID') and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    import numpy as np
    import scipy
    from scipy.optimize import least_squares
    output = Path(output)
    output.mkdir(exist_ok=False)
    loc = dict(frame.f_locals)
    evaluate = loc['evaluate']
    assert evaluate.__code__.co_name == 'evaluate' and evaluate.__code__.co_firstlineno == 134
    assert evaluate.__code__.co_filename == frame.f_code.co_filename
    closure = dict(zip(evaluate.__code__.co_freevars, (cell.cell_contents for cell in evaluate.__closure__)))
    assert closure['phase_active'] is loc['phase_active']
    assert all(not callable(value) for value in closure.values())
    dump(output/'closure-before', copy.deepcopy(closure))
    before_tree = json.loads((output/'closure-before.json').read_bytes())['tree']
    lower, upper = loc['lower'].copy(), loc['upper'].copy()
    assert lower.shape == upper.shape == loc['x'].shape == (12,)
    assert np.all(lower < upper) and float(loc['tolerance']) == 1e-7
    assert np.all(np.isfinite(loc['residual']))
    # Pure post-run algebra on the stored branch matrices and normalized steps.
    # No residual calls, matrix re-estimation, or alternative Newton solve here.
    algebra = {}
    residual = loc['residual'].copy()
    for matrix_name, delta_name in (('jac','delta'), ('local_jac','local_delta'), ('wide_jac','wide_delta')):
        matrix, delta = loc[matrix_name].copy(), loc[delta_name].copy()
        assert matrix.shape == (12,12) and delta.shape == (12,)
        assert np.all(np.isfinite(matrix)) and np.all(np.isfinite(delta))
        u, singular, vt = np.linalg.svd(matrix, full_matrices=False)
        image = matrix @ delta
        inner = float(residual @ image)
        algebra[matrix_name] = dict(stored_matrix=matrix, stored_normalized_delta=delta,
            J_delta=image, residual=residual, residual_dot_J_delta=inner,
            squared_norm_first_derivative=2*inner,
            relative_squared_norm_first_derivative=2*inner/float(residual@residual),
            linearized_residual_at_unit_normalized_step=residual+image,
            singular_values=singular, residual_projection_Ut= u.T @ residual,
            delta_projection_Vt=vt @ delta, gradient=matrix.T @ residual,
            scope='Stored final branch locals may have different ages. Algebra is not a new physical evaluation or causal attribution.')
    dump(output/'stored-direction-algebra', algebra)
    # Exactly two predeclared starts; no observation, fitting, random starts,
    # retries, or selection of a favorable subset after results are visible.
    starts = [('stalled_x', loc['x'].copy()), ('stored_ambient', loc['ambient'].copy())]
    assert [name for name,_ in starts] == policy['starts']
    results = []
    total_started = total_returned = 0
    for name, x0 in starts:
        entry = dict(name=name, initial=x0, initial_in_original_bounds=bool(np.all((x0>=lower)&(x0<=upper))),
            optimizer_returned=False, diagnostic_root_found=False, counters=dict(started=0, returned=0, detail_started=0, detail_returned=0))
        points, residuals, times, kinds = [], [], [], []
        started = time.monotonic()
        def call(z, details=False):
            if entry['counters']['started'] >= policy['maximum_actual_evaluate_calls_per_start']:
                raise DiagnosticLimit('Declared actual evaluate-call cap reached')
            if time.monotonic()-started >= policy['seconds_per_start']:
                raise DiagnosticLimit('Declared per-start time cap reached before next evaluate')
            assert z.shape == (12,) and z.dtype == np.float64
            assert np.all(np.isfinite(z)) and np.all((z>=lower)&(z<=upper))
            entry['counters']['started'] += 1
            progress['evaluate_calls_started'] += 1
            entry['last_attempted_x'] = z.copy()
            entry['last_attempt_was_details'] = bool(details)
            if details:
                entry['counters']['detail_started'] += 1
            answer = evaluate(z, details)  # The retained ORIGINAL live closure.
            entry['counters']['returned'] += 1
            progress['evaluate_calls_returned'] += 1
            if details:
                entry['counters']['detail_returned'] += 1
            r = answer['solver_residual'] if details else answer
            assert r.shape == (12,)
            points.append(z.copy()); residuals.append(r.copy())
            times.append(time.monotonic()-started); kinds.append(bool(details))
            if not np.all(np.isfinite(r)):
                raise FloatingPointError('Original residual returned a nonfinite diagnostic value')
            return answer
        try:
            if not entry['initial_in_original_bounds']:
                raise ValueError('Predeclared seed outside original bounds; no clipping or replacement')
            fitted = least_squares(call, x0.copy(), bounds=(lower.copy(),upper.copy()),
                method='trf', jac='3-point', x_scale='jac', tr_solver='exact', loss='linear',
                max_nfev=policy['max_nfev'], ftol=1e-12, xtol=1e-12, gtol=1e-12,
                verbose=0)
            entry['optimizer_returned'] = True
            entry['optimizer_result'] = dict(fitted)
            # SciPy success is not a root. Re-evaluate at its final point with
            # the same original detail path and use the ORIGINAL gates.
            detail = call(fitted.x.copy(), True)
            entry['original_detail'] = detail
            rmax = float(np.max(np.abs(detail['solver_residual'])))
            physical_max = float(np.max(np.abs(detail['layer_residual'])))
            finite = bool(np.all(np.isfinite(detail['solver_residual'])) and
                          np.all(np.isfinite(detail['layer_residual'])))
            within_bounds = bool(np.all((fitted.x>=lower)&(fitted.x<=upper)))
            assert detail['layer_residual'].shape == (11,)
            entry.update(maximum_original_12_residual=rmax, maximum_original_physical11_residual=physical_max,
                original_solver_tolerance=float(loc['tolerance']),
                original_physical_tolerance=float(loc['tolerance'])*1.01,
                diagnostic_root_found=finite and within_bounds and rmax<=loc['tolerance'] and physical_max<=loc['tolerance']*1.01,
                finite_residuals=finite, within_original_bounds=within_bounds)
        except BaseException as error:
            entry['diagnostic_exception_type'] = type(error).__name__
            entry['diagnostic_exception_message'] = str(error)
            entry['diagnostic_traceback'] = traceback.format_exc()
        finally:
            entry['seconds'] = time.monotonic()-started
            entry['returned_evaluations'] = dict(x=np.stack(points) if points else np.empty((0,12)),
                r12=np.stack(residuals) if residuals else np.empty((0,12)),
                seconds=np.asarray(times), detail_call=np.asarray(kinds,dtype=bool))
            if points:
                entry['first_evaluated_point_equals_declared_seed'] = bool(np.array_equal(points[0],x0))
                # TRF may move a bound-start slightly inward; actual point saved.
                if name == 'stalled_x':
                    entry['first_residual_minus_original_stored'] = residuals[0]-residual
            total_started += entry['counters']['started']
            total_returned += entry['counters']['returned']
            dump(output/(name+'-diagnostic'), entry)
            results.append(entry)
    dump(output/'closure-after', copy.deepcopy(closure))
    after_tree = json.loads((output/'closure-after.json').read_bytes())['tree']
    unchanged = before_tree == after_tree
    # No diagnostic root receives credit if any original closure input changed.
    report = dict(schema='PW-live-original-closure-diagnostic-v1',
        numpy_version=np.__version__, scipy_version=scipy.__version__,
        evaluate_identity=dict(filename=evaluate.__code__.co_filename,
            first_line=evaluate.__code__.co_firstlineno, freevars=list(evaluate.__code__.co_freevars)),
        policy=policy, original_exception_retained=True, original_model_repaired=False,
        original_closure_before_after_exact=unchanged,
        additional_original_evaluate_calls_started=total_started,
        additional_original_evaluate_calls_returned=total_returned,
        additional_physical_time_steps=0, GPU_calls=0, full_column_calls=0,
        phase_active_frozen_to_original_failed_invocation=True,
        lower=lower, upper=upper, phase_active=loc['phase_active'].copy(), active=loc['active'].copy(),
        starts=[dict(name=r['name'], diagnostic_root_found=r['diagnostic_root_found'] and unchanged,
            optimizer_returned=r['optimizer_returned'], counters=r['counters'], seconds=r['seconds'],
            maximum_original_12_residual=r.get('maximum_original_12_residual'),
            maximum_original_physical11_residual=r.get('maximum_original_physical11_residual'),
            diagnostic_exception=r.get('diagnostic_exception_message')) for r in results],
        scope='Conditional fixed-active-mask feasibility only. Nonzero least-squares stationary points are not roots; no continuation or repair credit.')
    dump(output/'diagnostic-summary', report)
    if not unchanged:
        raise RuntimeError('Original closure data changed during separate diagnostic')
    return report

# PU: one original Qia failure-frame snapshot — prepared only

This is one unchanged NM NumPy surface attempt on PR's actual encoded float32 input, decoded through the **unchanged PT-b helper** into NumPy float64. It does not run a complete column, GPU kernel or year, and does not repair or initialize anything. The earlier annual pre-forward input was never saved; PR is the later actual reconstructed-input capture. No PU numerical execution or submission has occurred.

The sole input is the closed PT111 archive `e039cc8d055612ef427719f2b0cd93076831f5983c18bde133f388c17c59cbc2`. Original `1681.manager` is F1 / Stageout0, children `[1,0,0]`. Qia started one surface call and returned zero with `Canopy phase Newton stalled at iteration 30: residual=13.75804 W/m2`. Its traceback reaches the first center-temperature evaluate in `canopy_column.surface_step`; no successful phase result had yet entered that call's cache. This observation does not establish the cause of failure.

`trace_qia_pu.py` authenticates all 111 original members, original executed stage, source584 and PR72, then extracts the exact original source into a fresh PBS TMPDIR. The three files under `pt/` are byte copies from the **executed** PT result and stage: `run_reference_pt.py`, `surface_reference.py` (SHA `30563e5a89a5cb30dc68e05c9195d5548ab0ca5a395e4d2c4d6de1c13357b125`) and its bindings. Their original three-row/controller scope remains historical; neither copied controller nor row_worker is called. PU makes only:

```python
ref.reference_one(source, args[:9], 0, coefficients=args[12], profiled=False,
                  exchange_extension=args[9], vic=args[10],
                  stem_area=None, canopy_optics=None)
```

The reference recomputes its own radiation. No original function, argument, return value, initial guess, tolerance, array flag or source file is changed. **No sys.settrace callback is installed.** On the original exception, the caller follows its actual traceback and matches the exact original `solve_canopy_phase_energy.__code__` object. It copies that frame's existing non-callable locals, and records callable names/code locations without invoking them. The unchanged PT writer preserves all typed fields in `phase-final-frame.{pkl,json,npz}`. This contains the actual failing invocation's input condensate M/H, geometry, exchange, final phase_active/x/r12/Jacobians/deltas, norm and recovery flags where those locals exist. It does not recover earlier iteration values. Final `r`, `rr`, `fresh`, `depleted`, matrix or branch temporaries can retain values from older branches; no freshness or full-initialization assertion is made merely from their presence. Final `initial_guess` is the original argument; other argument locals may have been transformed by the original code and are explicitly final-frame values. The PR packet remains the exact before-call source of input truth.

There is no additional residual evaluation, linear solve or comparison, and no repeated attempt. The original RuntimeError is saved and **re-raised**. Logging errors are separately recorded rather than replacing the physical error. A different error or unexpected successful return remains visible, with no automatic retry. The raw output includes the original PT Qia receipt/traceback, source/input before/after identities, original PT/PR archive hashes and control hashes. All 15 encoded arrays and all 584 source files are checked unchanged. Total phase-invocation count is unobserved, rather than inferred from the single traceback frame. The child's exit code remains null in its own receipt until a real parent waits for it.

After root review, a minimal EHPC wrapper can use `compute002_00260924`, 1 CPU, 2 GiB, 10 minutes; blank `CUDA_VISIBLE_DEVICES`, all BLAS/OpenMP thread limits set to 1, `PYTHONDONTWRITEBYTECODE=1`, and `/home/zhangyq/venvs/noahmp-closeout/bin/python -B`. Stage these controls and exact PT archive in new compute-local `/tmp/noahmp-surface-frame-trace-pu`, then call:

```sh
/home/zhangyq/venvs/noahmp-closeout/bin/python -B controls/trace_qia_pu.py \
  --pt pt-evidence.tar.gz --output "$TMPDIR/qia-frame-trace"
```

The wrapper must preserve actual stdout/stderr/exit, typed frame snapshot, receipt, controls, before/after hashes and original PT receipt/traceback before TMPDIR cleanup. It must retain actual F1 / Stageout0 if the same stall recurs, not convert an expected physical failure to zero. The extracted source may be excluded from the small result archive after all checks because its original archive and each file hash are bound. No submit/dispatch script is included yet. Subsequent rank/finite/direction analysis of saved J/delta would be explicitly labelled **post-run EHPC numerical analysis**, not a model call; it is not part of this preparation. The older unexecuted per-line observer draft is outside these controls and is not imported; only if this final frame proves insufficient should preceding-iteration tracing be considered.

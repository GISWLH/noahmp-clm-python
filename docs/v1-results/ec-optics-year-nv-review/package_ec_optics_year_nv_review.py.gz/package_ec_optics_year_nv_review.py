"""Publish the completed independent readout/review; no array/model execution."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

HERE = Path(__file__).resolve().parent
LABEL = 'ec-optics-year-nv-review'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
names = ['EC_OPTICS_YEAR_NV.md', 'ec-optics-year-nv-readout.json',
         'ec-optics-year-nv-independent-review-wp.json', 'review_ec_optics_year_nv_wp.py',
         'ec-optics-year-nv-package.json', Path(__file__).name]
raws = {name: (HERE / name).read_bytes() for name in names}
assert sha(raws['ec-optics-year-nv-independent-review-wp.json']) == 'b78d9811581a7e5c3525f82acea7aef69afec8dfb1dfc683bd6e451d91bcd3a5'
assert sha(raws['ec-optics-year-nv-readout.json']) == '792fa53024a0a9d24ae32c4731537a61fe61fe2e215ef23f21133e885150b340'
assert sha(raws['EC_OPTICS_YEAR_NV.md']) == 'eb4155e0b8692bb3978f972baae50c0fe03177e85c32eb9de874f190b316bf5b'
package = json.loads(raws['ec-optics-year-nv-package.json'])
assert sha((HERE / package['archive']).read_bytes()) == package['sha256'] == 'cc87ed8bee34602d1eaec920238923dcd5dcb902d1a7d32d13fc1b59132ab6f2'
raws['artifact-inventory.json'] = (json.dumps({name: sha(raw) for name, raw in raws.items()}, indent=2) + '\n').encode()
archive = HERE / (LABEL + '-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as stream:
    for name, raw in raws.items():
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mtime = 0
        stream.addfile(info, io.BytesIO(raw))
with tarfile.open(archive) as stream:
    assert {member.name: stream.extractfile(member).read() for member in stream} == raws
result = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
              artifacts=len(raws), original_evidence_archive_sha256=package['sha256'],
              scope='Read-only independent review and actual EHPC metric readout of closed EC571 optics year NV. '
                    'No model, numerical recomputation, NM acceptance or new calibration credit. '
                    'Original science failures and line-ending normalization caveat remain explicit.')
(HERE / (LABEL + '-package.json')).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))

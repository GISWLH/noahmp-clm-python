"""Read only sealed bytes/metadata/AST; never imports numerical/model code."""
from pathlib import Path
import ast
import hashlib
import io
import json
import re
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
SHA = lambda value: hashlib.sha256(value).hexdigest()


def tar_bytes(value):
    with tarfile.open(fileobj=io.BytesIO(value), mode='r:gz') as archive:
        files = [m for m in archive.getmembers() if m.isfile()]
        assert len(files) == len({m.name for m in files})
        return {m.name: archive.extractfile(m).read() for m in files}


def inventory(files, prefix=''):
    inv = json.loads(files[prefix + 'artifact-inventory.json'])
    for name, meta in inv.items():
        value = files[prefix + name]
        assert SHA(value) == meta['sha256'] and len(value) == meta['bytes'], name
    return len(inv)


def assertions(code):
    return [ast.dump(n, include_attributes=False) for n in ast.walk(ast.parse(code)) if isinstance(n, ast.Assert)]


archive = BASE / 'ec-optics-year-nv-evidence.tar.gz'
package = json.loads((BASE / 'ec-optics-year-nv-package.json').read_bytes())
assert SHA(archive.read_bytes()) == package['sha256'] == 'cc87ed8bee34602d1eaec920238923dcd5dcb902d1a7d32d13fc1b59132ab6f2'
assert archive.stat().st_size == package['bytes'] == 11358786
files = tar_bytes(archive.read_bytes())
assert len(files) == package['artifacts'] == 65
assert set(files) == {'artifact-inventory.json'} | set(json.loads(files['artifact-inventory.json']))
assert inventory(files) == 64
j = lambda name: json.loads(files[name])
plan = j('control/plan.json')
for name, digest in plan['controls_sha256'].items():
    assert SHA(files['control/' + name]) == digest
for name, digest in plan['expected_reference_sha256'].items():
    assert SHA(files['original-reference/' + name]) == digest
source = tar_bytes(files['original-reference/clm-phase-descent-ec-source.tar.gz'])
source_manifest = json.loads(source['SOURCE_SHA256.json'])
assert len(source_manifest) == 571
assert SHA(source['SOURCE_SHA256.json']) == package['source_manifest_sha256'] == '96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
assert all(SHA(source[name]) == digest for name, digest in source_manifest.items())
assert files['evaluation/device/SOURCE_SHA256.json'] == source['SOURCE_SHA256.json']

native = tar_bytes(files['control/native-year.tar.gz'])
assert SHA(files['control/native-year.tar.gz']) == package['native_archive_sha256'] == j('control/native-year-package.json')['sha256']
assert len(native) == 19 and inventory(native) == 18
assert all(value == files['evaluation/device/' + name] for name, value in native.items())
assert inventory(files, 'evaluation/device/') == 18
parent, receipt = j('evaluation/device/year-exit.json'), j('evaluation/device/year-receipt.json')
assert parent['returncode'] == 0 and parent['passed'] is True
assert parent['receipt_sha256'] == SHA(files['evaluation/device/year-receipt.json'])
assert receipt['status'] == 'complete' and receipt['failure'] is None and receipt['device_barrier_complete'] is True
assert receipt['steps_completed'] == receipt['steps_requested'] == 17520
assert receipt['source_unchanged'] is True and receipt['source_manifest_sha256'] == package['source_manifest_sha256']
batch = j('evaluation/device/trajectory/batch.json')
assert receipt['report_sha256'] == SHA(files['evaluation/device/trajectory/batch.json'])
assert batch['status'] == 'complete' and batch['steps_completed'] == batch['steps_requested'] == batch['ledger_steps'] == 17520
assert batch['ledger_segments'] == 1 and len(batch['case_reports']) == 1
case, case_meta = next(iter(batch['case_reports'].items()))
report_name = 'evaluation/device/trajectory/' + case + '/' + case_meta['file']
report = j(report_name)
assert SHA(files[report_name]) == case_meta['sha256']
assert report['case'] == 'qia-phase-capacity_optics-cold2003' and report['backend'] == 'cuda32'
assert report['status'] == 'complete' and report['steps_completed'] == report['steps_requested'] == 17520
assert all(source_manifest[name] == digest for name, digest in report['source_sha256'].items())
for name, digest in [(report['model_npz'], report['model_npz_sha256']), ('../' + batch['checkpoint_file'], batch['checkpoint_sha256'])]:
    resolved = ('evaluation/device/trajectory/' + name[3:] if name.startswith('../') else 'evaluation/device/trajectory/' + case + '/' + name)
    assert SHA(files[resolved]) == digest
inputs = tar_bytes(files['original-reference/qia-phase-cold-ef-inputs.tar.gz'])
assert SHA(inputs['CN-Qia.npz']) == report['forcing_npz_sha256']
assert SHA(inputs['CN-Qia.json']) == report['forcing_manifest_sha256']
assert len([name for name, value in inputs.items() if SHA(value) == report['configuration_sha256']]) == 1
checkpoints = {}
for name, value in files.items():
    if name.startswith('evaluation/device/trajectory/state-') and name.endswith('.npz'):
        with zipfile.ZipFile(io.BytesIO(value)) as z:
            names = z.namelist()
        assert len(names) == 30
        checkpoints[name] = {'zip_members': len(names), 'sha256': SHA(value)}
assert len(checkpoints) == 2

jobs = {}
for stage, expected in [('evaluation', '1594.manager'), ('summary', '1595.manager')]:
    qstat = files[stage + '/actual-qstat.txt'].decode()
    assert 'Job Id: ' + expected in qstat and re.search(r'job_state\s*=\s*F\b', qstat)
    assert re.search(r'Exit_status\s*=\s*0\b', qstat) and 'exec_host = compute002/' in qstat
    assert files[stage + '/pbs-exit.txt'].strip() == b'0'
    item = j(stage + '/receipt.json')
    assert item['pbs_job'] == expected and item['node'] == 'compute002' and item['source_unchanged'] is True
    assert item['source_manifest_sha256'] == package['source_manifest_sha256']
    jobs[stage] = {'job': expected, 'actual_state': 'F', 'actual_exit': 0, 'receipt_sha256': SHA(files[stage + '/receipt.json'])}
evaluation, summary_receipt, summary = j('evaluation/receipt.json'), j('summary/receipt.json'), j('summary/summary.json')
assert evaluation['evaluation_delivered'] is True and evaluation['failure'] is None and evaluation['model_complete_steps'] == 17520
assert evaluation['model_report_sha256'] == SHA(files[report_name])
assert all(SHA(files['evaluation/' + name]) == digest for name, digest in evaluation['output_sha256'].items())
assert summary_receipt['passed'] is True and summary_receipt['source_steps'] == 17520
assert summary_receipt['summary_sha256'] == SHA(files['summary/summary.json'])
assert summary['parent_evaluation_receipt_sha256'] == SHA(files['evaluation/receipt.json'])
assert summary['model_complete_steps'] == 17520 and summary['source_manifest_sha256'] == package['source_manifest_sha256']

adaptations = {}
for adapted_name, meta in j('control/path-adaptation.json').items():
    original = files['control/original-' + meta['original']]
    adapted = files['control/' + adapted_name]
    assert SHA(original) == meta['original_sha256'] and SHA(adapted) == meta['adapted_sha256']
    assert original == (BASE / meta['original']).read_bytes()
    forward = original
    for old, new in meta['only_path_replacements']:
        assert forward.count(old.encode()) == 1
        forward = forward.replace(old.encode(), new.encode())
    assert forward.replace(b'\r\n', b'\n') == adapted.replace(b'\r\n', b'\n') and assertions(original) == assertions(adapted)
    adaptations[adapted_name] = {'only_two_path_replacements_after_LF_normalization': True, 'original_asserts_ast_exact': len(assertions(original)), 'original_CRLF_count': original.count(b'\r\n'), 'adapted_CRLF_count': adapted.count(b'\r\n')}
assert sorted(v['original_asserts_ast_exact'] for v in adaptations.values()) == [15, 24]

official, observations = j('evaluation/official-comparison.json'), j('evaluation/fluxnet-observations.json')
assert official['source_manifest_sha256'] == package['source_manifest_sha256']
assert official['reference_full_fields_sha256'] == evaluation['reference_fields_sha256'] == SHA(files['original-reference/ctsm-qia-run-r/official-year-fields.npz'])
assert official['cold_start_not_spinup'] is True and official['nee_reference_status'].startswith('unmeasured:')
assert len(official['metrics']['year']['2003']) == 14 and len(official['metrics']['daily']) == 365 and len(official['metrics']['monthly']) == 12
for name, meta in summary['official14fields'].items():
    assert meta['year'] == official['metrics']['year']['2003'][name]
    for frequency, count, key in [('daily', 365, 'complete_days'), ('monthly', 12, 'complete_months')]:
        assert meta[key] == count
        for criterion in ['bias', 'correlation']:
            assert meta[frequency + '_' + criterion + '_pass'] == sum(row[name][criterion + '_pass'] is True for row in official['metrics'][frequency].values())
assert summary['fluxnet_original_own_qc_instantaneous'] == observations['instantaneous']
assert len(observations['daily']) == 365 and len(observations['monthly']) == 12
assert observations['dt_seconds'] == 1800 and observations['utc_offset_hours'] == 8
for key in ['H_CORR', 'LE_CORR']:
    assert observations['instantaneous'][key]['metrics']['status'] == 'unmeasured'
assert all(summary[k] == official[k] for k in ['independent_ledger_checks', 'independent_final_storage_checks'])
readout_path = BASE / 'ec-optics-year-nv-readout.json'
readout = json.loads(readout_path.read_bytes())
assert SHA(readout_path.read_bytes()) == '792fa53024a0a9d24ae32c4731537a61fe61fe2e215ef23f21133e885150b340'
assert readout['summary_sha256'] == SHA(files['summary/summary.json']) and readout['observation_sha256'] == SHA(files['evaluation/fluxnet-observations.json'])
for key, meta in readout['observed'].items():
    assert meta['instantaneous'] == observations['instantaneous'][key]['metrics']
    for period, count in [('daily', 365), ('monthly', 12)]:
        rows = [date[key] for date in observations[period].values()]
        assert meta[period]['total_periods'] == len(rows) == count
        assert meta[period]['bias_pass'] == sum(row['metrics']['bias_pass'] is True for row in rows)
        assert meta[period]['own_qc_counts_total'] == {kind: sum(row['own_qc_counts'][kind] for row in rows) for kind in ['zero', 'nonzero', 'missing']}
    assert meta['monthly_original'] == {date: row[key] for date, row in observations['monthly'].items()}

result = dict(
    reviewer='winter_physics', mode='stdlib sealed-byte/JSON/AST/ZIP-member review only; no ndarray deserialization, model, remote action or numerical re-evaluation',
    archive_sha256=package['sha256'], archive_bytes=package['bytes'], members=65, inventory_checked=64,
    nested_native_members_byteexact_to_evaluation=19, original_source_files_sha_checked=571,
    source_manifest_sha256=package['source_manifest_sha256'], original_source='EC571, never NM584',
    actual_jobs=jobs, original_cuda_parent_exit=0, complete_model_steps=17520, native_ledger_segments=1,
    checkpoints=checkpoints, original_controls=adaptations,
    official_fields=14, complete_days=365, complete_months=12, observation_products=len(observations['instantaneous']),
    original_report_forcing_config_hashes_checked=True, readout_matches_sealed_metrics_and_qc_counts=True,
    manuscript_sha256=SHA((BASE / 'EC_OPTICS_YEAR_NV.md').read_bytes()),
    scientific_interpretation={
        'gpp': 'Both NT and DT satisfy P4 bias<=10% OR r>0.85. NT bias=-12.310419323178068%, r=.8518468584640547; DT bias=-5.832963684363143%, r=.907733203713779. This is not all-day/month bias acceptance.',
        'official': 'All 14 fields retained, no official SP NEE; daily/monthly failures explicit. State r is descriptive, not an added required state gate.',
        'qc': 'Own QC=0 for instantaneous H/LE/NEE; gap-filled products retained for full daily/monthly periods. GPP partitioning products have no independent QC. H_CORR/LE_CORR unmeasured.',
        'conservation': 'All 17520 stored step/cumulative ledger records and independent final extensive-storage sum checked by original EC audit. No raw every-tendency recomputation, stricter new tolerance, or 10% waiver is claimed. Large original carried bounds are explicitly printed.',
        'snow_soc': 'SWE endpoint disappearances do not isolate melt heat routing. Single cold-year SOC endpoint annualization is not a century trajectory or spinup acceptance.',
        'scope': 'Original EC single Qia2003 cold-year result; no current NM, multisite/year, calibration/holdout or release credit.'},
    blocking_findings=[], nonblocking_findings=['Original IH/IM controls use LF; adapted NV controls have 60/50 CRLF lines. Two-path-only comparison is exact after LF normalization, not raw file-byte equality. Original archived controls themselves remain exact and all 24/15 assertion ASTs are identical. No scientific change or artifact repair needed.'], verdict='0 blocking; result narrative supported within stated scope')
out = BASE / 'ec-optics-year-nv-independent-review-wp.json'
out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'review': str(out), 'sha256': SHA(out.read_bytes()), 'verdict': result['verdict'], 'members': len(files), 'source_files': len(source_manifest)}))

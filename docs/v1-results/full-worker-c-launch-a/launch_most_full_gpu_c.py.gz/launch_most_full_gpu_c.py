from pathlib import Path
import datetime,hashlib,json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';dest=source/'full-worker-c-launch.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(source/'src')+':'+str(source/'tests')+':'+str(source/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(source/'run_most_full_gpu_c.py')]
with (source/'full-worker-c-controller.log').open('w') as log:p=subprocess.Popen(command,cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
value=dict(pid=p.pid,gpu=1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,runner_sha256=sha(source/'run_most_full_gpu_c.py'),scope='Current1129 distributed suite continuation;104 device nodes genuinely completed,221 device nodes still required; original804 CPU coverage retained. No full/annual/scientific completion claim.')
dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

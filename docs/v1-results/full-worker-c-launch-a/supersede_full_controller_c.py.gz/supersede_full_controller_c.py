from pathlib import Path
import datetime,hashlib,json,os,signal,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';dest=source/'full-controller-superseded-c.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre=json.loads((source/'full-worker-preflight-c/selection.json').read_text());assert pre['collected_nodes']==1129 and pre['verified_gpu_prefix_files']==19 and pre['verified_gpu_prefix_nodes']==104 and pre['remaining_gpu_nodes']==221 and len(pre['remaining_gpu_files'])==43
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
def identity(pid):
    p=Path('/proc')/str(pid)
    if not p.exists():return None
    stat=(p/'stat').read_text().split(') ',1)[1].split()
    return dict(pid=pid,uid=p.stat().st_uid,cwd=os.readlink(p/'cwd'),command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),pgid=os.getpgid(pid),start_ticks=stat[19],state=stat[0])
def same(a,b):return b is not None and all(a[k]==b[k] for k in ['pid','uid','cwd','command','pgid','start_ticks'])
controller=identity(3968670);child=identity(4024593);annual=identity(3983588)
for value,script in [(controller,'run_most_full_gpu_b.py'),(child,'tests/test_gpu_clm_irrigation_column.py'),(annual,'run_fluxnet_native.py')]:assert value and value['uid']==os.getuid() and value['cwd']==str(source) and script in value['command']
assert controller['pgid']==child['pgid']==3968670 and annual['pgid']!=3968670
p=(source/'full-by-file-a/progress.json').read_bytes();progress=json.loads(p);assert progress['active']['pid']==4024593 and len(progress['results'])==17 and all(r['passed'] for r in progress['results'])
(source/'full-before-controller-supersession-c.json').write_bytes(p)
actions=[];os.kill(controller['pid'],signal.SIGINT);actions.append(dict(signal='SIGINT',pid=controller['pid']));time.sleep(1)
after=identity(controller['pid'])
if after and after['state']!='Z':
    assert same(controller,after);os.kill(controller['pid'],signal.SIGTERM);actions.append(dict(signal='SIGTERM',pid=controller['pid']));time.sleep(1)
after=identity(controller['pid']);assert after is None or after['state']=='Z'
assert same(annual,identity(annual['pid'])) and all(sha(source/n)==v for n,v in m.items())
remaining=identity(child['pid'])
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Controller-only scheduling supersession after independent original irrigation13 worker completed with actual process return0, all phases/barriers/budgets and exact nodes/source. Original17 normal-exit files retained. Original cleanup child is not killed or falsely marked terminal; no annual/source/physics/test/tolerance change.',old_controller=controller,old_cleanup_child=child,old_cleanup_child_after=remaining,old_controller_terminal=True,annual_identity=annual,annual_identity_unchanged=True,source_unchanged=True,preflight_selection_sha256=sha(source/'full-worker-preflight-c/selection.json'),actions=actions)
dest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

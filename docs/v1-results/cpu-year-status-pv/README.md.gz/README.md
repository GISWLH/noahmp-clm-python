CPU status PV �� 2026-10-25 15:02 UTC

Three SSH reads returned actual 0 with empty stderr. The original PJ controller PID 48727/start269100908 remains live and its controls match. No new failure was found in these sampled records.

| PJ case | Closed stop | Saved stop | Current job/state |
|---|---:|---:|---|
| CN-Cng-2007-wilting-hydraulic-clim | 3888 | 4320 | 1684.manager R |
| CN-Cng-2007-wilting-legacy-clim | 3888 | 4128 | 1685.manager R |
| CN-Cng-2007-field-capacity-hydraulic-clim | 3888 | 3888 | 1686.manager R |
| CN-Cng-2007-field-capacity-legacy-clim | 3408 | None | 1683.manager E |
| CN-Qia-2003-wilting-hydraulic-clim | 528 | 912 | 1660.manager R |
| CN-Qia-2003-wilting-legacy-clim | 528 | 912 | 1662.manager R |
| CN-Qia-2003-field-capacity-hydraulic-clim | 528 | 912 | 1663.manager R |
| CN-Qia-2003-field-capacity-legacy-clim | 528 | 912 | 1664.manager R |

PJ case3 is E/Exit0 without final Stageout0, so its closed stop stays 3408. No live worker matched this E sample; its current saved report is unobserved (null), not inferred. All four Qia roots have saved 912 but only 528 closed. New controller-closed archives were not downloaded or independently re-audited.

Original JN LQ: Qia closed5712/saved5760 (1433R); Cha closed/saved17520, final1494 actualF0/Stageout0; HaM closed9552/saved9888 (1515R). Original journal receipt/report/seed hashes were checked without array decoding. LU1536 remains H, never started, with dependencies1457+1531. CN-Cha is a completed execution under oldJN, not official/scientific acceptance or NM credit.

No model, new PBS task, restart, continuation, array computation or remote write was performed. Raw JSON/stderr/commands remain alongside this summary.

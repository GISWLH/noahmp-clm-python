"""Summarize preserved status JSON only; no new remote reads or array work."""
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
ROOT = BASE/'cpu-year-status-pv'
sha = lambda b: hashlib.sha256(b).hexdigest()


def fields(raw):
    return dict(re.findall(r'^    ([\w.]+) = (.*)$', raw, re.M))


def main():
    commands = json.loads((ROOT/'commands.json').read_bytes())
    for name, row in commands['reads'].items():
        assert row['actual_SSH_exit'] == 0 and not row['timed_out']
        assert sha((ROOT/(name+'.json')).read_bytes()) == row['stdout_sha256']
        assert sha((ROOT/(name+'.stderr')).read_bytes()) == row['stderr_sha256']
        assert sha((ROOT/(name+'-reader.py')).read_bytes()) == row['reader_sha256']
    pj = json.loads((ROOT/'pj-manager.json').read_bytes())
    compute = json.loads((ROOT/'pj-compute.json').read_bytes())
    lq = json.loads((ROOT/'lq-manager.json').read_bytes())
    assert pj['manager_process']['identity_matches']
    processes = {p['environment']['PBS_JOBID']: p for p in compute['live_processes']}
    sched = {name: fields(record['stdout']) for name, record in pj['scheduler'].items()}
    rows = []
    for case in pj['progress']['cases']:
        identity = case['identity']
        current = sched[case['job']]
        process = processes.get(case['job'])
        latest = case['history'][-1]
        assert latest['stop'] == case['steps']
        status = sched.get(latest['job'])
        if status is not None:
            assert (status.get('job_state'), status.get('Exit_status'), status.get('Stageout_status')) == ('F','0','0')
        rows.append(dict(case_index=case['case_index'], case=identity['case'],
            source_manifest_sha256=identity['source_manifest_sha256'],
            controller_status=case['status'], controller_closed_stop=case['steps'],
            latest_closed_job=latest['job'], latest_closed_archive_sha256=latest['closed_archive_sha256'],
            latest_closed_qstat_verified_this_snapshot=status is not None,
            closed_evidence_scope='Existing controller closure plus actual scheduler; no new archive reconstruction or independent array audit',
            current_job=case['job'], job_state=current.get('job_state'),
            Exit_status=current.get('Exit_status'), Stageout_status=current.get('Stageout_status'),
            requested_window=[case['start'],case['stop']],
            live_pid=None if process is None else process['pid'],
            saved_steps=None if process is None or process['saved_report'] is None else process['saved_report']['steps_completed'],
            saved_status=None if process is None or process['saved_report'] is None else process['saved_report']['status'],
            saved_scope='Saved report read from actual worker TMPDIR; not F0 credit' if process else 'No live worker matched at this sample; saved current-window report not observed',
            latest_controller_residual_m_h_c_n=latest['residual_m_h_c_n'],
            latest_controller_bounds_m_h_c_n=latest['bounds_m_h_c_n']))
    pj_failures = [dict(job=job, state=q.get('job_state'), exit=q.get('Exit_status'))
                   for job,q in sched.items() if q.get('Exit_status') not in (None,'0')]
    lq_rows = []
    for site in lq['sites']:
        assert all(row['Stageout_status'] == '0' for row in site['completed_segments'])
        latest = site['latest_success']
        lq_rows.append(dict(site=site['site'], source_manifest_sha256=site['source_manifest_sha256'],
            actual_contiguous_F0_Stageout0_stop=site['actual_successful_stop'],
            latest_saved_steps=site['latest_saved_report']['steps_completed'],
            latest_saved_report_sha256=sha(site['latest_saved_report_raw'].encode()),
            latest_saved_status=site['latest_saved_report'].get('status'),
            latest_closed_job=latest['pbs_job'], latest_closed_receipt_sha256=latest['receipt_sha256'],
            active_jobs=[dict(job=x['pbs_job'],state=x['job_state'],exit=x['exit_status'],
                Stageout_status=x['Stageout_status']) for x in site['pending_jobs'] if x['job_state'] in ('R','E')],
            failure_receipts=site['failure_receipts'],
            year_execution_complete=site['actual_successful_stop']==17520,
            independently_archived_annual_evaluation=False))
    audit = lq['final_audit_job']
    result = dict(scope='Read-only original CPU status, not new scientific/annual acceptance',
        sample_utc=dict(PJ_manager=pj['sample_utc'],PJ_compute=compute['sample_utc'],
            LQ_started=lq['snapshot_started_utc'],LQ_finished=lq['snapshot_finished_utc']),
        actual_SSH_exits={n:r['actual_SSH_exit'] for n,r in commands['reads'].items()},
        PJ_manager=pj['manager_process'], PJ_controls_manifest_sha256=pj['controls_manifest_sha256'],
        PJ=rows, PJ_nonzero_terminal_snapshots=pj_failures,
        PJ_controller_complete_years=pj['progress']['actual_complete_years'],
        LQ=lq_rows, LU=dict(job=audit['pbs_job'], state=audit['job_state'],
            dependency=audit.get('depend'), started='stime' in audit or 'exec_host' in audit,
            exit=audit.get('Exit_status')),
        no_new_failure_found=not pj_failures and all(not s['failure_receipts'] for s in lq_rows)
            and all(c['controller_status']=='running' for c in rows),
        new_model_calls=0, new_PBS_submissions=0, remote_mutations=0,
        arrays_or_pickle_deserialized=False, new_window_archives_downloaded=0,
        scope_notes=['PJ current E/Exit0 is not F0; no closed-stop promotion.',
            'PJ new closed windows are only original controller/scheduler status here; no new independent byte closure.',
            'Original JN CN-Cha finished 17520; this does not make NM or the full three-site official evaluation pass.',
            'LU1536 remains held for the remaining original dependencies; it has no run or evaluation credit.'])
    (ROOT/'summary.json').write_text(json.dumps(result, indent=2)+'\n')
    table = ['| PJ case | Closed stop | Saved stop | Current job/state |', '|---|---:|---:|---|']
    for row in rows:
        table.append('| '+row['case']+' | '+str(row['controller_closed_stop'])+' | '+str(row['saved_steps'])+' | '+row['current_job']+' '+row['job_state']+' |')
    text = 'CPU status PV — 2026-10-25 15:02 UTC\n\nThree SSH reads returned actual 0 with empty stderr. The original PJ controller PID 48727/start269100908 remains live and its controls match. No new failure was found in these sampled records.\n\n'+'\n'.join(table)+'\n\nPJ case3 is E/Exit0 without final Stageout0, so its closed stop stays 3408. No live worker matched this E sample; its current saved report is unobserved (null), not inferred. All four Qia roots have saved 912 but only 528 closed. New controller-closed archives were not downloaded or independently re-audited.\n\nOriginal JN LQ: Qia closed5712/saved5760 (1433R); Cha closed/saved17520, final1494 actualF0/Stageout0; HaM closed9552/saved9888 (1515R). Original journal receipt/report/seed hashes were checked without array decoding. LU1536 remains H, never started, with dependencies1457+1531. CN-Cha is a completed execution under oldJN, not official/scientific acceptance or NM credit.\n\nNo model, new PBS task, restart, continuation, array computation or remote write was performed. Raw JSON/stderr/commands remain alongside this summary.\n'
    (ROOT/'README.md').write_text(text)
    print(json.dumps(dict(summary_sha256=sha((ROOT/'summary.json').read_bytes()),
        PJ_closed_stops=[r['controller_closed_stop'] for r in rows],
        PJ_saved_stops=[r['saved_steps'] for r in rows], LQ=lq_rows, LU=result['LU'],
        no_new_failure_found=result['no_new_failure_found']),indent=2))


if __name__ == '__main__':
    main()

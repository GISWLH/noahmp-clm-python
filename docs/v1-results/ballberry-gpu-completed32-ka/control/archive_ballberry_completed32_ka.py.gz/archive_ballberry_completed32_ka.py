"""Export only already completed immutable file sessions, not active layered5."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-iv-gpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();names={'test_gpu_photosynthesis':9,'test_gpu_canopy_energy':5,'test_gpu_canopy_phase_energy':14,'test_gpu_clm_enthalpy_column':4};pairs=[];records=[]
for stem,count in names.items():
    d=json.loads((r/(stem+'-receipt.json')).read_text());e=json.loads((r/(stem+'-exit.json')).read_text());assert e['passed'] and e['actual_parent_returncode']==d['worker_exitcode']==d['pytest_returncode']==0 and e['receipt_sha256']==sha(r/(stem+'-receipt.json')) and d['passed'] and d['source_unchanged'] and d['node_coverage_exact'] and d['all_setup_call_teardown_phases_passed'] and d['counts']==dict(tests=count,failures=0,errors=0,skipped=0) and d['xml_sha256']==sha(r/(stem+'.xml')) and d['expected_nodes_sha256']==sha(r/(stem+'-expected.json')) and all(v['status']=='complete' for v in d['device_barriers']);records.append(e)
    for suffix in ['-receipt.json','-exit.json','-expected.json','.xml','.log','-reference-requests.jsonl']:
        p=r/(stem+suffix)
        if p.exists():pairs.append((p,'gpu/'+p.name))
s=Path(json.loads((r/'source-location.json').read_text())['source']);m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==581 and all(sha(s/n)==h for n,h in m.items());launch=json.loads((r/'launch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items())
for n in ['SOURCE_SHA256.json','package.json','source-location.json','launch.json','reference-ready.json',*launch['controls_sha256']]:pairs.append((r/n,'gpu/'+n))
for n in ['receipt.json','actual-pbs-qstat.txt','pbs-exit.txt','requests.json','nodes.json']:pairs.append((r/'reference-evidence'/n,'reference-origin/'+n))
pairs.extend([(b/'clm-ballberry-iv-source.tar.gz','frozen-source/clm-ballberry-iv-source.tar.gz'),(b/'ballberry-jo-full-gpu/inheritance-prevalidation-proof.json','current-JN-inheritance-proof.json'),(Path(__file__),'control/'+Path(__file__).name)])
archive=b/'ballberry-gpu-completed32-ka-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
    for p,n in pairs:assert n not in inventory;inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
d=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),completed_tests=32,records=records,scope='ActualIV physicalCUDA1 completed32 originalnodes fromleaf9/liquidcanopy5/phase14/enthalpy4, everyoriginalphase/XML/source/dtype/int/barrier andraw1e-6/science/hardbudgets kept. RuntimeNumPyreferencecalls useEHPC1181 exactcache;4historicalphasefixture referencecombinations retainoriginalEHPC values. JN differs only standaloneCPUBrenttest, allproduction/GPUtests/fixtures/benchmarks byteexact; originalGPUorigin kept. Active layered5 EXCLUDED, no 37/407/canonical1563/year/spinup/observational/releasepass.');(b/'ballberry-gpu-completed32-ka-package.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)

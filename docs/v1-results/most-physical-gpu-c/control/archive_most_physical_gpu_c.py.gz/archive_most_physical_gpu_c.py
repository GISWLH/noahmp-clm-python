from pathlib import Path
import hashlib
import json
import tarfile

b=Path('/home/lhwang/work/noahmp-v1');a=b/'most-physical-gpu-c-evidence.tar.gz';assert not a.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(a,'w:gz') as t:
    for label in ['b','c']:
        s=b/('p6-most-physical-'+label);r=s/('production1519-controller-'+label)
        assert json.loads((r/'exit.json').read_text())['actual_children_exitcodes']==[0,0]
        for backend in ('cuda32','jax32'):
            d=json.loads((s/('production1519-'+label)/backend/'receipt.json').read_text())
            assert d['failure'] is None and d['source_unchanged'] and d['input_unchanged'] and d['device_barrier_complete'] and d['result']['fields']==361
            assert json.loads((r/(backend+'-exit.json')).read_text())['actual_returncode']==0
            if backend=='jax32':assert d['result']['maximum_same_precision_difference']==0.
        for root in [r,s/('production1519-'+label)]:
            for p in sorted(root.rglob('*')):
                if p.is_file():t.add(p,arcname=s.name+'/'+p.relative_to(s).as_posix(),recursive=False)
        t.add(s/'SOURCE_SHA256.json',arcname=s.name+'/SOURCE_SHA256.json',recursive=False)
        for prefix in ['probe_most_production1519_','control_most_production1519_','launch_most_production1519_']:
            p=b/(prefix+label+'.py');t.add(p,arcname='control/'+p.name,recursive=False)
        p=b/('most-production1519-'+label+'-launch.json');t.add(p,arcname='control/'+p.name,recursive=False)
    for n in ['input.npz','binding.json']:
        t.add(b/'qia-stem-cuda-1519-a'/n,arcname='original1519/'+n,recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Uninstrumented actual frozen509B and final509C original1519 whole-step replay on xuanze CUDA32 and independentJAX32,all361raw maxdiff0,originalMHCN,actual child exits0,devicebarriers. Atexit explicitly bypassed only after receipts/barriers. No original failed year advancement,canonicalGPU-node or science acceptance.')))

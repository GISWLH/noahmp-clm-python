from pathlib import Path
import datetime
import json
import subprocess
import sys

b=Path('/home/lhwang/work/noahmp-v1');p=b/'most-production1519-b-launch.json';assert not p.exists()
with (b/'most-production1519-b-controller.log').open('x') as log:
    child=subprocess.Popen([sys.executable,'-u',str(b/'control_most_production1519_b.py')],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
d=dict(controller_pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Uninstrumented frozen production509,original1519 whole step CUDA32 then independentJAX32,allraw1e-6,originalMHCN. No trajectory continuation or science acceptance.')
p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

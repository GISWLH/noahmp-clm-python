"""Exact original1519 input through uninstrumented frozen production code."""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback
import numpy as np

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-most-physical-b'
backend=sys.argv[1];assert backend in ('cuda32','jax32')
r=s/'production1519-b';out=r/backend;out.mkdir(parents=True,exist_ok=False)
original=b/'qia-stem-cuda-1519-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==509 and all(sha(s/n)==v for n,v in m.items())
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as driver
binding=json.loads((original/'binding.json').read_text());assert sha(original/'input.npz')==binding['input_sha256']
with np.load(original/'input.npz',allow_pickle=False) as z:data=dict(z)
report,saved,_=driver.read_generation(b/'qia-stem-cuda-year-c/trajectory')
assert report['status']=='failed' and report['steps_completed']==1519 and report['checkpoint_sha256']==binding['original_checkpoint_sha256']
engine=driver.Backend(backend);xp=engine.xp
old=tuple(data['a'+str(k)] for k in range(19));before=engine.update_forcing(tuple(xp.asarray(v) for v in old),data['environment'])
before_host=tuple(engine.host(v) for v in before)
start=time.monotonic();failure=None;result=None
try:
    device=engine.step(*before,data['forcing'],environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']),return_surface=True)
    host=engine.host(device);after=tuple(engine.host(v) for v in driver.next_station_arrays(before,device))
    incoming,residual,bound,tracer=driver.audit_step(old,after,data['forcing'],data['deposition'],data['nitrogen'],host)
    cumulative=driver.totals(after)-saved['initial']-(saved['net']+incoming)
    assert np.all(abs(residual)<=bound) and np.all(abs(cumulative)<=saved['bounds']+bound)
    flat={}
    def flatten(value,prefix=''):
        for k,v in value.items():
            if isinstance(v,dict):flatten(v,prefix+k+'/')
            else:flat[prefix+k]=np.asarray(v)
    flatten(host)
    assert len(flat)==361 and all(np.all(np.isfinite(v)) for v in flat.values())
    np.savez_compressed(out/'output.npz',**flat)
    np.savez_compressed(out/'state.npz',**{'a'+str(k):v for k,v in enumerate(after)})
    comparisons={};mismatches=[]
    if backend=='jax32':
        with np.load(r/'cuda32/output.npz',allow_pickle=False) as z:
            assert set(z.files)==set(flat)
            for k,v in flat.items():
                comparisons[k]=float(np.max(abs(v.astype(float)-z[k].astype(float)))) if v.size else 0.
                try:
                    if v.dtype.kind in 'biu':np.testing.assert_array_equal(v,z[k],err_msg=k)
                    else:np.testing.assert_allclose(v,z[k],rtol=1e-6,atol=1e-6,equal_nan=False,err_msg=k)
                except AssertionError as e:mismatches.append(dict(field=k,error=str(e)))
        (out/'same-precision.json').write_text(json.dumps(dict(fields=361,maximum_absolute=comparisons,failures=mismatches),indent=2)+'\n')
        assert not mismatches
    result=dict(fields=len(flat),step_residual_m_h_c_n=residual.tolist(),original_step_bounds_m_h_c_n=bound.tolist(),cumulative_residual_m_h_c_n=cumulative.tolist(),tracer_residual=tracer,maximum_same_precision_difference=max(comparisons.values(),default=None),diagnostics={k:np.asarray(v).tolist() for k,v in host['diagnostics'].items()})
except Exception as e:
    failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
if backend=='jax32':__import__('jax').effects_barrier()
else:xp.cuda.runtime.deviceSynchronize()
unchanged=all(sha(s/n)==v for n,v in m.items());input_unchanged=all(np.array_equal(v,engine.host(w)) for v,w in zip(before_host,before))
record=dict(scope='Frozen production MOST physical-target verification,original failed1519 input; no runtime function replacement,original hard ledgers and unrounded raw1e-6 compare. Original failed year unchanged; no complete year/scientific acceptance. Device barrier and durable receipts precede explicit interpreter atexit bypass.',backend=backend,source_files=509,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=unchanged,input_unchanged=input_unchanged,device_barrier_complete=True,interpreter_atexit_handlers_bypassed=True,failure=failure,result=result,seconds=time.monotonic()-start)
(out/'receipt.json').write_text(json.dumps(record,indent=2,default=lambda v:v.tolist() if hasattr(v,'tolist') else str(v),allow_nan=False)+'\n')
print(json.dumps(record,default=lambda v:v.tolist() if hasattr(v,'tolist') else str(v),allow_nan=False),flush=True)
os._exit(0 if failure is None and unchanged and input_unchanged else 1)

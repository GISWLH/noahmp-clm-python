from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-most-physical-c';r=s/'production1519-controller-c';r.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
for backend in ('cuda32','jax32'):
    with (r/(backend+'.log')).open('x') as log:
        p=subprocess.Popen([sys.executable,'-u',str(b/'probe_most_production1519_c.py'),backend],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
        (r/(backend+'-worker.json')).write_text(json.dumps(dict(pid=p.pid,backend=backend,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
        code=p.wait()
    (r/(backend+'-exit.json')).write_text(json.dumps(dict(actual_returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
    assert code==0
(r/'exit.json').write_text(json.dumps(dict(actual_children_exitcodes=[0,0],utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')

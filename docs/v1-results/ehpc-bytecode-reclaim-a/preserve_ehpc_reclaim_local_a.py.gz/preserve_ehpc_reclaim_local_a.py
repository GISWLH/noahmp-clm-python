from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).parent;r=json.loads((root/'reclaim-ehpc-bytecode-a.json').read_text());assert r['active_source_unchanged'] and all(v['path'].endswith('.pyc') and '/__pycache__/' in '/'+v['path'] for v in r['deleted_cache_files'])
archive=root/'ehpc-bytecode-reclaim-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for name in ['reclaim-ehpc-bytecode-a.json','reclaim_ehpc_bytecode_a.py',Path(__file__).name]:t.add(root/name,arcname=name,recursive=False)
print(json.dumps(dict(files=3,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),deleted_disposable_cache_files=len(r['deleted_cache_files']),removed_empty_cache_directories=len(r['removed_empty_cache_directories']),free_inodes_before=r['free_inodes_before'],free_inodes_after=r['free_inodes_after'],active_source_unchanged=True)))

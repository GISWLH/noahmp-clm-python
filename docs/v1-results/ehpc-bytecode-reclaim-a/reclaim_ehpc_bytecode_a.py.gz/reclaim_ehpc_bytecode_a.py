from pathlib import Path
import datetime,hashlib,json,os
base=Path('/home/zhangyq/noahmp-v1').resolve();assert str(base)=='/home/zhangyq/noahmp-v1';source=base/'p6-spinup-assessment-c';m=json.loads((source/'SOURCE_SHA256.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not any(n.endswith('.pyc') for n in m)
assert all(sha(source/n)==v for n,v in m.items());before=os.statvfs(base);deleted=[];dirs=[]
for cache in sorted(base.rglob('__pycache__')):
    if cache.is_symlink() or not cache.is_dir() or not cache.resolve().is_relative_to(base):continue
    for path in list(cache.iterdir()):
        if path.is_symlink() or not path.is_file() or path.suffix!='.pyc' or path.stat().st_uid!=os.getuid():continue
        assert path.resolve().is_relative_to(base) and path.parent.name=='__pycache__'
        deleted.append(dict(path=path.relative_to(base).as_posix(),bytes=path.stat().st_size));path.unlink()
    if not any(cache.iterdir()):cache.rmdir();dirs.append(cache.relative_to(base).as_posix())
after=os.statvfs(base);assert all(sha(source/n)==v for n,v in m.items());value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Project-local disposable __pycache__/*.pyc only; no source/input/result/checkpoint/venv removals. Active488 frozen source hashes verified before/after.',free_inodes_before=before.f_favail,free_inodes_after=after.f_favail,free_bytes_before=before.f_bavail*before.f_frsize,free_bytes_after=after.f_bavail*after.f_frsize,deleted_cache_files=deleted,removed_empty_cache_directories=dirs,active_source_unchanged=True)
try:(base/'reclaim-ehpc-bytecode-a.json').write_text(json.dumps(value,indent=2)+'\n')
except OSError as e:value['receipt_write_error']=str(e)
print(json.dumps(value))

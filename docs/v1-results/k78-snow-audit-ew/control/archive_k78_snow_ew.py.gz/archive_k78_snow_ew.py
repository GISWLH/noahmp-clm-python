from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-snow-audit-ew';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'comparison.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['primitive_causal_density_swap_confirmed'] and d['all_common_density_transfer_raw_fields_byteexact'] and not d['whole_k78_rootcause_proven'] and not d['whole_k78_same_precision_accepted'];items=[(p,'audit/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()]
for name in ['receipt.json','reference.npz','pbs-exit.txt']:items.append((b/'k78-snow-reference-es'/name,'independent-reference/'+name))
items.extend((b/n,'control/'+n) for n in ['k78-snow-primitives-er-evidence.tar.gz','dispatch_k78_snow_audit_ew.py',Path(__file__).name]);a=b/'k78-snow-audit-ew-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

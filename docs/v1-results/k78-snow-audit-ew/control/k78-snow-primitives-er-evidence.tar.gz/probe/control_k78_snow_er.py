from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-snow-primitives-er';prior=b/'phase-cold-queue-ej';failure=None;code=None;begun=time.monotonic()
try:
    pid=json.loads((prior/'launch.json').read_text())['pid']
    while not (prior/'exit.json').exists():
        os.kill(pid,0);(r/'waiting.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Wait physical1 currentcold48 both actualterminal before isolatedproductionprimitive probe'))+'\n');time.sleep(20.)
    d=json.loads((prior/'exit.json').read_text());assert d['passed'] and d['failure'] is None
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
        if free>8192 and memory>32*1024*1024:break
        time.sleep(20.)
    with (r/'probe.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'probe_k78_snow_primitives_er.py')],stdout=log,stderr=subprocess.STDOUT)
    (r/'worker.json').write_text(json.dumps(dict(pid=p.pid),indent=2)+'\n');code=p.wait()
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'controller-traceback.txt').write_text(traceback.format_exc())
p=r/'receipt.json';d=json.loads(p.read_text()) if p.exists() else {};record=dict(actual_parent_returncode=code,delivered=code==0 and d.get('failure') is None and d.get('source_unchanged') and d.get('device_barriers_complete'),controller_failure=failure,receipt_sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None,seconds=time.monotonic()-begun,scope='Isolatedprimitive export parentexit only; not K78 wholecolumn sameprecision pass or acceptedrootcause.')
(r/'exit.json').write_text(json.dumps(record,indent=2)+'\n');raise SystemExit(0 if record['delivered'] and failure is None else 1)

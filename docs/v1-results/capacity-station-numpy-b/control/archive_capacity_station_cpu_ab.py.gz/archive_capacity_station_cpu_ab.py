from pathlib import Path
import hashlib,io,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');letter=sys.argv[1];assert letter in ('a','b')
name='capacity-station-numpy-'+letter;r=b/name;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'pbs-exit.txt').read_text().strip()==('1' if letter=='a' else '0')
rec=json.loads((r/'receipt.json').read_text());assert rec['returncode']==(1 if letter=='a' else 0)
assert rec['source_unchanged'] and rec['counts']==dict(tests=154,failures=1 if letter=='a' else 0,errors=0,skipped=0)
package=json.loads((r/'package.json').read_text());assert rec['source_manifest_sha256']==package['manifest_sha256']==sha(r/'SOURCE_SHA256.json')
assert rec['xml_sha256']==sha(r/'numpy-target.xml')
source=b/(name+'-source.tar.gz');assert sha(source)==package['archive_sha256']
controls=['archive_capacity_station_cpu_ab.py','dispatch_capacity_station_numpy_'+letter+'.py']
archive=b/(name+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    tf.add(source,arcname='source/'+source.name,recursive=False)
    for name in controls:tf.add(b/name,arcname='control/'+name,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,receipt=rec)))

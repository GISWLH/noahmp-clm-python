# NY 三站冷48独立EHPC审计：准备包

仅准备，未提交PBS、未运行模型／数值分析。原KG三站参考、旧CPU年度、GPU控制、生产源码和观测不变。等待根代理确认新NY的CUDA父进程实际0及原归档精确SHA。

## 固定对象

- NM584源：`39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d`；manifest `a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f`。
- 原KG输入：`044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e`；CN-Qia、CN-Cha、CN-HaM原3配置／15文件，原23字段冷账、16数组。
- 原LE完整1008 NumPy包：`bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416`，KG1188及KH1189实际F0。固定前48×3和call47.after，不重建参考、不伪造48checkpoint；原336报告保持。
- GPU控件清单固定 `EXPECTED_GPU_CONTROLS_SHA256.json`，实际与NY作者封存18控件清单字节一致。独立审计控件用自己的`AUDIT_CONTROLS_SHA256.json`核验，不能要求两者目录全相同。

## 保留的门与最小适配

从原NP1586通过的审计改为3列／144对，原`compare`函数、13变量specs、完整瞬时比较＋r>.85条件、6日门、逐个植物／土壤C/N库门均原字节。原native.audit_step、杂质审计、累计MHCN、23冷字段逐字节、16状态链／末checkpoint和原1e-12预算记录核对不改。

独立helper按原KH递归byte相等函数核对原48包的before/after链、forcing、kwargs、全部13物理轨迹及原MHCN，不运行forward。使用NM前向NumPy59节点闭包／61生产数据与JN逐字节相同的证明；SOC评价入口改变明确排除于记录生成闭包。原313完整输出键清单来自同NM16数组NP实际call0（原1586配对F0），不是猜测字段数；NY逐步要求保留该完整结构。没有新增近零／物理／守恒容差或把候选冷48当全年、正式晋升、同精度或科学验收。

313是完整返回结构的保存／schema检查；物理对照沿原13轨迹、日门和逐库门，不将其表述为313个字段分别与NumPy数值相等。

## 在真实CUDA0之后的执行顺序

1. 将NY原`cold48-evidence.tar.gz`和`cold48-package.json`下载到新目录，先验证根给出的SHA。源NM包和原LE包保持在`outputs/v1`，不重打这些包。
2. 本机只运行标准库封装：`E:/miniconda3/python.exe -B outputs/v1/hrldas-cold48-audit-ny-preparation/stage_cold48_ny_audit.py --download <下载目录> --expected-device-sha256 <根确认的精确SHA>`。它复核真实parent0、receipt、48步、控制、源和15输入，生成一次性`outputs/v1/hrldas-cold48-ny-audit-input.tar.gz`及package；拒绝覆盖旧尝试。无模型导入／数组计算。
3. 用manager和compute002各自的新`/tmp/noahmp-hrldas-cold48-ny-audit`。输入包包含原source、原LE、原CUDA包、独立controls和manifest，无新增HOME文件。manager解包并hash核验后，从该目录运行`dispatch_cold48_ny_audit.py`。它先查所有文件hash，显式SCP根文件及controls子目录到compute002（两端/tmp不共享），再qsub。仅1 CPU、4 GB、30分钟、`host=compute002_00260924`。
4. PBS只在其TMPDIR解包／读取模型与packet。实际审计stdout/stderr、receipt／三站逐变量结果／失败traceback、原参考readback预算和控件身份留在result。最后将result整包写回compute002暂存目录，保留worker真实exit。
5. 合理间隔只读qstat。仅实际`job_state=F`后运行manager的`archive_cold48_ny_audit.py`，严格比对Exit_status、pbs-exit和receipt；E不当F。实际失败也封存，不自动重试。结果连原控制／helper／原KH代码／3proof／313字段schema／全部实际日志、每件SHA整包回读，产出通用archive/sha256/artifacts/scope包。成功需3×48、313字段、23冷字段、16链、三站全部门与CPU原参考readback真实通过。

输出目标为`hrldas-cold48-ny-pair-evidence.tar.gz/package.json`。后续年度属于根代理另行处理的独立后继；本包没有GPU启动／年度／resume入口。

"""EHPC-only readback of fixed KG first48 packets; never executes a model step."""
from pathlib import Path
from dataclasses import fields, is_dataclass
import gzip
import hashlib
import json
import os
import pickle
import re
import struct
import tarfile

assert os.environ.get('PBS_JOBID'), 'Reference packet interpretation is EHPC PBS only'
import numpy as np

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def identical(a,b,path='state'):
    assert type(a) is type(b), (path,type(a),type(b))
    if isinstance(a,np.ndarray):
        assert a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes(),path
    elif is_dataclass(a):
        for field in fields(a): identical(getattr(a,field.name),getattr(b,field.name),path+'.'+field.name)
    elif isinstance(a,dict):
        assert a.keys() == b.keys(),path
        for key in a: identical(a[key],b[key],path+'.'+str(key))
    elif isinstance(a,(list,tuple)):
        assert len(a) == len(b),path
        for i,(x,y) in enumerate(zip(a,b)): identical(x,y,path+'.'+str(i))
    elif isinstance(a,float):
        assert struct.pack('d',a) == struct.pack('d',b),path
    elif isinstance(a,np.generic):
        assert a.dtype == b.dtype and a.tobytes() == b.tobytes(),path
    else: assert a == b,path


def audit_first48(kg_root, case, proof_path=None):
    """Return (raw_trace_first48, original_call47_after, independent_CPU_audit).

    The caller first verifies/extracts the exact LE archive and NM source.
    Preserve the original336 report/checkpoint; do not create a synthetic48
    report or checkpoint. Only construction of the declared cold state and
    original budget/readback algebra occur here; no forward solver is called.
    """
    assert os.environ.get('PBS_JOBID')
    import run_fluxnet_column as runner
    root = Path(kg_root)
    proof_path = Path(proof_path) if proof_path is not None else Path(__file__).with_name('reference-reuse.json')
    proof = json.loads(proof_path.read_text())
    assert proof['reference_reusable'] and proof['numerical_execution'] is False
    assert proof['reference_source_manifest_sha256'] == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
    assert proof['candidate_source_manifest_sha256'] == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    info = next(row for row in proof['cases'] if row['case'] == case)
    site = info['site']; assert case == site+'-suction-climate-cycle'
    graph = json.loads(proof_path.with_name('reference-dependency-graph.json').read_text())
    old_manifest = json.loads((root/'SOURCE_SHA256.json').read_text())
    assert sha(root/'SOURCE_SHA256.json') == proof['reference_source_manifest_sha256']
    for name in graph['closures']['benchmarks/run_fluxnet_column.py']:
        assert sha(runner.ROOT/name) == graph['source_sha256'][name] == old_manifest[name], name
    receipt = json.loads((root/'receipt.json').read_text())
    assert receipt['passed'] and receipt['source_unchanged'] and receipt['pbs_job'] == '1188.manager'
    assert receipt['source_manifest_sha256'] == proof['reference_source_manifest_sha256']
    for folder,job in [(root,'1188.manager'),(root.parent/'hrldas-current-kh','1189.manager')]:
        status = (folder/'actual-pbs-qstat.txt').read_text()
        assert 'Job Id: '+job in status and re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
        assert (folder/'pbs-exit.txt').read_text().strip() == '0'
    assert set(proof['every_input_file_sha256']) == {p.relative_to(root/'inputs').as_posix() for p in (root/'inputs').rglob('*') if p.is_file()}
    assert all(sha(root/'inputs'/name) == expected for name,expected in proof['every_input_file_sha256'].items())
    folder = root/'runs'/case
    own = next(row for row in receipt['cases'] if row['case'] == case)
    assert own == json.loads((folder/'receipt.json').read_text())
    assert own['failure'] is None and own['source_unchanged'] and own['captured_steps'] == own['steps_completed'] == 336
    assert own['steps_requested'] == 17520 and own['preflight']['passed'] and own['preflight']['steps_completed'] == 48
    report_path = folder/'trajectory/report.json'; report = json.loads(report_path.read_text())
    assert sha(report_path) == info['reference_report_sha256'] == own['report_sha256']
    assert report['source_unchanged'] and report['status'] == 'running' and report['steps_completed'] == 336 and report['steps_requested'] == 17520
    assert all(old_manifest[name] == expected for name,expected in report['source_sha256'].items())
    config_path = root/'inputs'/(site+'-config.json'); config = json.loads(config_path.read_text())
    assert config == report['configuration'] and sha(config_path) == info['configuration_sha256'] == report['configuration_sha256']
    trace_path = folder/'trajectory'/report['model_npz']
    assert sha(trace_path) == info['reference_trace_sha256'] == report['model_npz_sha256']
    assert sha(folder/'trajectory'/report['checkpoint_file']) == report['checkpoint_sha256']
    assert sha(folder/'steps.tar.gz') == info['reference_packet_archive_sha256'] == own['packets_sha256']
    with np.load(trace_path,allow_pickle=False) as z: trace = dict(z)
    with np.load(root/'inputs'/(site+'.npz'),allow_pickle=False) as z: data = dict(z)
    assert sha(root/'inputs'/(site+'.npz')) == report['forcing_npz_sha256']
    assert sha(root/'inputs'/(site+'.json')) == report['forcing_manifest_sha256']
    metadata = json.loads((root/'inputs'/(site+'.json')).read_text())
    stamps = runner.validate_input(data,metadata,root/'inputs'/(site+'.npz'))
    for key in ['time_start','time_end']: identical(trace[key][:48],data[key][:48],key)
    state = runner.build_state(config)
    initial = runner.totals(state)
    net,bounds,maximum,stepmax,gate_max = [np.zeros(4) for _ in range(5)]
    deposition = runner.DepositionSchedule(config)
    capacity = runner.capacity_configuration(config)
    with tarfile.open(folder/'steps.tar.gz') as packets:
        assert packets.getnames() == [f'call-{k:05d}.pkl.gz' for k in range(336)]
        for k in range(48):
            name = f'call-{k:05d}.pkl.gz'; raw = packets.extractfile(name).read()
            assert hashlib.sha256(raw).hexdigest() == info['selected_first48_packets'][name]['sha256']
            packet = pickle.loads(gzip.decompress(raw))
            before,after,diagnostic = packet['before'],packet['after'],packet['diagnostics']
            identical(before,state,'step'+str(k)+'.before_chain')
            forcing = runner.Forcing(*data['forcing'][k])
            identical(packet['forcing'],forcing,'forcing')
            co2,mu,diffuse = data['environment'][k]
            expected = dict(co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),
                leaf_dimension=config['leaf_dimension_m'],leaf_parameters=runner.LeafParameters(**config['leaf_parameters']),
                most_geometry=runner.MOSTGeometry(**config['most_geometry']),
                phenology_environment=runner.calendar(stamps[k],metadata,config['phenology'] is not None),
                deposition_rates=deposition.aerosol(stamps[k],forcing.dt),nitrogen_deposition_gn_m2=deposition.nitrogen_rate*forcing.dt,
                capacity_environment=runner.capacity_environment(stamps[k],metadata,capacity is not None))
            if config.get('canopy_optics') is not None: expected['canopy_optics'] = runner.CanopyOptics(**config['canopy_optics'])
            hydrology = runner.hydrology_configuration(config)
            if hydrology is not None: expected['soil_hydrology'] = hydrology
            identical(packet['kwargs'],expected,'kwargs')
            incoming,residual,bound = runner.audit_step(before,after,forcing,diagnostic,expected['nitrogen_deposition_gn_m2'])
            net += incoming; bounds += bound
            cumulative = runner.totals(after)-initial-net
            assert np.all(abs(cumulative) <= bounds),(site,k,'original cumulative MHCN bound')
            for key,value in [('step_residual_m_h_c_n',residual),('step_bound_m_h_c_n',bound),('cumulative_residual_m_h_c_n',cumulative)]:
                identical(trace[key][k],value,site+'.'+key+'.'+str(k))
            for key,field in runner.TRACE.items():
                assert np.asarray(trace[key][k]).tobytes() == np.asarray(float(diagnostic[field])).tobytes(),(site,k,key)
            for key,value in [('tsoil_k',after.tsoil),('smc_m3m3',after.smc),('liquid_m3m3',after.ground.liquid/(1000.*after.ground.dz))]:
                identical(trace[key][k],value,site+'.'+key)
            assert trace['swe_m'][k] == after.swe and trace['lai'][k] == after.lai
            maximum = np.maximum(maximum,abs(cumulative)); stepmax = np.maximum(stepmax,abs(residual))
            gate_max = np.maximum(gate_max,abs(residual)/bound)
            state = after
    summary = dict(case=case,site=site,passed=True,steps=48,model_forward_calls=0,
        reference_archive_sha256=proof['reference_archive_sha256'],reference_packet_archive_sha256=info['reference_packet_archive_sha256'],
        original_report_steps=336,raw_trace_prefix='all fixed intervals[0:48], no resampling',
        final_reference_state_member='call-00047.pkl.gz:after',final_reference_state_packet_sha256=info['selected_first48_packets']['call-00047.pkl.gz']['sha256'],
        packet47_sha256=info['selected_first48_packets']['call-00047.pkl.gz']['sha256'],
        all48_original_inputs_kwargs_state_chain_and_13traces_exact=True,
        all_original_step_and_cumulative_m_h_c_n_gates_passed=True,
        maximum_step_absolute_m_h_c_n=stepmax.tolist(),maximum_cumulative_absolute_m_h_c_n=maximum.tolist(),
        maximum_step_original_gate_ratio=gate_max.tolist(),final_cumulative_bounds_m_h_c_n=bounds.tolist(),
        scope='Readback only of actual KG NumPy first48. Not a new forward reference or scientific acceptance; original336 report/checkpoint remain unchanged.')
    return {key:value[:48] for key,value in trace.items()},state,summary

"""EHPC manager only: stage archives in compute002/tmp and submit the original NY audit."""
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path('/tmp/noahmp-hrldas-cold48-ny-audit')
REFERENCE = ROOT / 'hrldas-current-week-le-evidence.tar.gz'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert os.name == 'posix' and os.uname().nodename == 'manager'
    assert Path(__file__).resolve().parent == ROOT
    manifest = json.loads((ROOT / 'audit-input-manifest.json').read_text())
    assert manifest['actual_gpu_parent_returncode'] == 0 and manifest['candidate_only']
    assert manifest['continuation_allowed'] is False
    for name, identity in manifest['inputs'].items():
        assert sha(ROOT / name) == identity['sha256'] and (ROOT / name).stat().st_size == identity['bytes']
    assert sha(REFERENCE) == manifest['reference_archive_sha256']
    assert sha(ROOT/'controls/AUDIT_CONTROLS_SHA256.json') == manifest['audit_controls_manifest_sha256']
    pbs = ROOT / 'controls/audit_cold48_ny.pbs'
    assert b'\r\n' not in pbs.read_bytes()
    manager = ROOT / 'manager'
    assert not manager.exists()
    manager.mkdir()
    subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'compute002',
                    'test ! -e /tmp/noahmp-hrldas-cold48-ny-audit && mkdir /tmp/noahmp-hrldas-cold48-ny-audit'], check=True)
    names = [n for n in manifest['inputs'] if '/' not in n] + ['audit-input-manifest.json']
    subprocess.run(['scp', *[str(ROOT / n) for n in names], 'compute002:' + str(ROOT) + '/'], check=True)
    subprocess.run(['scp', '-r', str(ROOT/'controls'), 'compute002:' + str(ROOT) + '/'], check=True)
    job = subprocess.run(['qsub', '-v', 'NY_STAGE=' + str(ROOT), '-o', str(ROOT / 'pbs-output.log'), str(pbs)],
                         cwd=manager, capture_output=True, text=True)
    (manager / 'qsub-stdout.txt').write_text(job.stdout)
    (manager / 'qsub-stderr.txt').write_text(job.stderr)
    assert job.returncode == 0, job.stderr
    job_id = job.stdout.strip()
    assert re.fullmatch(r'\d+\.manager', job_id), job_id
    record = dict(pbs_job=job_id, qsub_actual_exit=job.returncode,
                  manifest_sha256=sha(ROOT / 'audit-input-manifest.json'), pbs_sha256=sha(pbs),
                  source_manifest_sha256=manifest['source_manifest_sha256'],
                  device_archive_sha256=manifest['device_archive_sha256'],
                  reference_archive_sha256=sha(REFERENCE),
                  audit_controls_manifest_sha256=manifest['audit_controls_manifest_sha256'],
                  node='compute002_00260924', cpus=1, memory_gb=4, walltime='00:30:00',
                  candidate_only=True, continuation_allowed=False,
                  scope='Only independent144pair original-gate readback; all new staging under/tmp and model imports only PBS TMPDIR.')
    (manager / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

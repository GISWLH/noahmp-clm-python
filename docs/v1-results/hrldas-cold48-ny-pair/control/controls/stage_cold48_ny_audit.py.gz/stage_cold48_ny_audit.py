"""Metadata-only preparation after the NY GPU parent has actually returned zero."""
import argparse
import hashlib
import io
import json
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREPARED = HERE
ARTIFACTS = HERE.parent
SOURCE_SHA = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
REFERENCE = 'bc1ac1d31dbee19c8f76d98731cfa66f6d9e9c44bb4f8a8770ded7bf921b1416'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--download', type=Path, required=True)
    parser.add_argument('--expected-device-sha256', required=True)
    args = parser.parse_args()
    package = json.loads((args.download / 'cold48-package.json').read_text())
    device = (args.download / 'cold48-evidence.tar.gz').read_bytes()
    source = (ARTIFACTS / 'climatology-final-candidate-nm-source.tar.gz').read_bytes()
    reference = (ARTIFACTS / 'hrldas-current-week-le-evidence.tar.gz').read_bytes()
    assert sha(source) == SOURCE_SHA
    assert sha(reference) == REFERENCE
    assert sha(device) == package['device_archive_sha256'] == args.expected_device_sha256
    assert package['source_manifest_sha256'] == TARGET
    assert package['candidate_only'] and package['continuation_allowed'] is False
    with tarfile.open(fileobj=io.BytesIO(device)) as tf:
        members = tf.getmembers()
        assert all(m.isfile() for m in members) and len(members) == len({m.name for m in members})
        payload = {m.name: tf.extractfile(m).read() for m in members}
    receipt = json.loads(payload['current/receipt.json'])
    end = json.loads(payload['current/exit.json'])
    assert end['passed'] and end['actual_parent_returncode'] == 0
    assert end['receipt_sha256'] == sha(payload['current/receipt.json'])
    assert end['candidate_only'] and end['continuation_allowed'] is False
    assert receipt['source_manifest_sha256'] == TARGET and receipt['source_unchanged']
    assert receipt['failure'] is None and receipt['device_barrier_complete']
    assert receipt['cases'] == 3 and receipt['captured_step_calls'] == receipt['steps_completed'] == 48
    assert receipt['cold_fields_exact'] == 23 and receipt['primary_state_arrays'] == 16
    assert receipt['steps_requested'] == 17520 and receipt['status'] == 'running'
    assert receipt['report_sha256'] == sha(payload['current/trajectory/batch.json'])
    plan = json.loads(payload['control/plan.json'])
    gpu_controls = json.loads(payload['control/CONTROLS_SHA256.json'])
    assert payload['control/CONTROLS_SHA256.json'] == (PREPARED/'EXPECTED_GPU_CONTROLS_SHA256.json').read_bytes()
    assert plan['controls_sha256'] == gpu_controls
    assert all(sha(payload['control/'+n]) == h for n,h in gpu_controls.items())
    assert {n.removeprefix('control/') for n in payload if n.startswith('control/')} == set(gpu_controls)|{'plan.json','launch.json','CONTROLS_SHA256.json'}
    assert plan['source_manifest_sha256'] == TARGET and plan['reference_archive_sha256'] == REFERENCE
    assert plan['candidate_only'] and plan['continuation_allowed'] is False and plan['maximum_forward_steps'] == 48
    proof = json.loads((PREPARED/'reference-reuse.json').read_text())
    assert proof['reference_archive_sha256'] == REFERENCE and proof['selected_packet_count'] == 144
    assert all(sha(payload['current/inputs/'+n]) == h for n,h in proof['every_input_file_sha256'].items())
    for name in ['reference-reuse.json','reference-dependency-graph.json','source-dependencies.json']:
        assert payload['control/'+name] == (PREPARED/name).read_bytes()
    files = {'candidate-source.tar.gz': source, 'cold48-evidence.tar.gz': device,
             'hrldas-current-week-le-evidence.tar.gz': reference,
             'cold48-package.json': (args.download / 'cold48-package.json').read_bytes()}
    audit_controls = json.loads((PREPARED/'AUDIT_CONTROLS_SHA256.json').read_text())
    for name,expected in audit_controls.items():
        raw = (PREPARED/name).read_bytes()
        assert sha(raw) == expected
        files['controls/'+name] = raw
    files['controls/AUDIT_CONTROLS_SHA256.json'] = (PREPARED/'AUDIT_CONTROLS_SHA256.json').read_bytes()
    for name in ['dispatch_cold48_ny_audit.py', 'archive_cold48_ny_audit.py']:
        files[name] = (PREPARED / name).read_bytes()
    manifest = dict(source_archive_sha256=SOURCE_SHA, source_manifest_sha256=TARGET,
                    device_archive_sha256=sha(device), reference_archive_sha256=REFERENCE,
                    actual_gpu_parent_returncode=0, candidate_only=True, continuation_allowed=False,
                    input_archive_sha256=proof['input_archive_sha256'],
                    audit_controls_manifest_sha256=sha(files['controls/AUDIT_CONTROLS_SHA256.json']),
                    inputs={n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in files.items()},
                    scope='Independent readback only of this actual NY3x48; original144paired/gates, no annual continuation.')
    files['audit-input-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    out = ARTIFACTS / 'hrldas-cold48-ny-audit-input.tar.gz'
    assert not out.exists(), 'Do not replace a staged attempt'
    with tarfile.open(out, 'w:gz') as tf:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            tf.addfile(info, io.BytesIO(raw))
    with tarfile.open(out) as tf:
        assert {m.name: tf.extractfile(m).read() for m in tf} == files
    record = dict(archive=out.name, sha256=sha(out.read_bytes()), bytes=out.stat().st_size,
                  artifacts=len(files), gpu_parent_actual_zero_verified=True,
                  reference_sha256=REFERENCE, pbs_submitted=False,
                  scope='Staged input only for independent original-gate NY three-station144pair audit. No PBS/model execution or new scientific pass.')
    (ARTIFACTS / 'hrldas-cold48-ny-audit-input-package.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'richards-producer-bw';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'exit.json').read_text());assert d['diagnostic_delivered'] and all(q['actual_child_returncode']==0 for q in d['records']);items=[]
for p in sorted(r.rglob('*')):
    if p.is_file():items.append((p,p.relative_to(r).as_posix()))
for label in ['capacity','capacity_optics']:
    d=json.loads((r/label/'receipt.json').read_text());assert d['failure'] is None and d['all30_endpoint_state_and_ledger_exact'] and d['source_unchanged'] and d['original_year_report_unchanged'];old=b/('qia-richards-'+label+'-cuda-year-c');states=list((old/'trajectory').glob('state-0006480-*.npz'));reports=list((old/'trajectory'/label).glob('report-0006480-*.json'));assert len(states)==len(reports)==1 and sha(states[0])==d['original_checkpoint6480_sha256'] and sha(reports[0])==d['original_case_report6480_sha256'];items.extend((p,label+'/original6480/'+p.name) for p in [*states,*reports]);items.extend((p,label+'/inputs/'+p.relative_to(old/'inputs').as_posix()) for p in sorted((old/'inputs').rglob('*.json')))
items.extend((b/n,'control/'+n) for n in ['clm-numerical-recovery-c-source.tar.gz','qia-recovery-c-inputs-u.tar.gz','prepare_richards_producer_bw.py',Path(__file__).name]);a=b/'richards-producer-bw-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

from pathlib import Path
import ast
o=Path(__file__).parent
for old,new in [('control_richards_invalid_bt.py','control_richards_producer_bw.py'),('launch_richards_invalid_bt.py','launch_richards_producer_bw.py')]:
    text=(o/old).read_text(encoding='utf-8').replace('richards-invalid-bt','richards-producer-bw').replace('probe_richards_invalid_bt.py','replay_richards_producer_bw.py').replace('control_richards_invalid_bt.py','control_richards_producer_bw.py').replace('launch_richards_invalid_bt.py','launch_richards_producer_bw.py').replace("d.get('expected_failure_reproduced') and d.get('invalid_input_captured')","d.get('all30_endpoint_state_and_ledger_exact') and d.get('first_overfull') is not None")
    text=text.replace('Read-only-of-originalstate CUDA tendency reprobes','Private producerreconstruction fromactualsuccessful6480, no originalresume')
    ast.parse(text);p=o/new;assert not p.exists();p.write_bytes(text.encode())
print('BW uses retainedsuccessful6480 sourceC reconstruction, raw30endpoint equality and producerpackets.')

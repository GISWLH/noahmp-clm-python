from pathlib import Path
from dataclasses import astuple
import hashlib,json,os,sys,time,traceback
import numpy as np
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-numerical-recovery-c';r=b/'richards-producer-bw'/label;r.mkdir();old=b/('qia-richards-'+label+'-cuda-year-c');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import noahmp_clm.gpu.richards_enthalpy as heat
import noahmp_clm.gpu.cuda.richards as flow
import cupy as cp
terminal=json.loads((old/'year-exit.json').read_text());year=json.loads((old/'year-receipt.json').read_text());report,expected,prior=native.read_generation(old/'trajectory');target=int(expected['index']);assert terminal['returncode']==1 and report['status']=='failed' and target==(6501 if label=='capacity' else 6499)
checkpoint=list((old/'trajectory').glob('state-0006480-*.npz'));assert len(checkpoint)==1;case_report=list((old/'trajectory'/label).glob('report-0006480-*.json'));assert len(case_report)==1;former=json.loads(case_report[0].read_text());assert former['status']=='running' and former['steps_completed']==6480 and sha(checkpoint[0])==former['batch_checkpoint_sha256']
with np.load(checkpoint[0],allow_pickle=False) as z:saved=dict(z)
a=native.checkpoint_arrays(saved,report['identity']);initial,net,bounds,maximum,stepmax,tracermax=[saved[k].copy() for k in ['initial','net','bounds','maximum','stepmax','tracermax']];cases=native.load_batch(old/'inputs'/label/'batch.json');dtype=np.float32;engine=native.Backend('cuda32');device=tuple(cp.asarray(q) for q in a);geometry=np.asarray([astuple(native.MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype);leaf=np.asarray([astuple(native.LeafParameters(**c['config']['leaf_parameters'])) for c in cases],dtype);schedules=[native.DepositionSchedule(c['config']) for c in cases];kwargs=dict(most_geometry=geometry,leaf_parameters=leaf,return_surface=True,soil_hydrology=native.batch_hydrology(cases))
if cases[0]['config'].get('canopy_optics') is not None:
    from noahmp_clm.physics.canopy_optics import CanopyOptics
    from noahmp_clm.gpu.canopy_optics import pack_canopy_optics
    kwargs['canopy_optics']=np.stack([pack_canopy_optics(CanopyOptics(**c['config']['canopy_optics']),dtype) for c in cases])
original_profile=heat._profile;original_flow=flow.run_richards_cuda;latest={};calls=0;index=6480;failure=None;first_overfull=None;start=time.monotonic()
def capture_profile(c,p,liquid,xp,exponent):
    result=original_profile(c,p,liquid,xp,exponent)
    if index==target-1:latest.clear();latest.update(heat_cells=cp.asnumpy(c),properties=cp.asnumpy(p),liquid=cp.asnumpy(liquid),profile=cp.asnumpy(result))
    return result
def capture_flow(w,p,dt,**controls):
    global calls
    result=original_flow(w,p,dt,**controls)
    if index==target-1:
        packet=dict(latest,water=cp.asnumpy(w),hydraulics=cp.asnumpy(p),dt=cp.asnumpy(dt));packet.update({'out_'+k:cp.asnumpy(v) for k,v in result.items()});np.savez_compressed(r/('producer-flow-'+str(calls).zfill(3)+'.npz'),**packet);calls+=1
    return result
try:
    heat._profile=capture_profile;flow.run_richards_cuda=capture_flow
    while index<target:
        forcing=np.asarray([c['data']['forcing'][index] for c in cases],dtype);env=np.asarray([c['data']['environment'][index] for c in cases],dtype);calendar,flags=native.pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype);nitrogen=np.asarray([q.nitrogen_rate for q in schedules],dtype)*forcing[:,0];deposition=np.asarray([q.aerosol(c['stamps'][index],forcing[k,0]) for k,(c,q) in enumerate(zip(cases,schedules))],dtype);kw=dict(kwargs,environment=calendar,calendar=flags,nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,capacity_environment=native.pack_capacity_environment([native.capacity_environment(c['stamps'][index],c['metadata'],True) for c in cases],dtype=dtype));before=engine.update_forcing(device,env)
        if index==target-1:
            packet={'before'+str(k):engine.host(v) for k,v in enumerate(before)};packet.update(forcing=forcing,environment=env,calendar=calendar,calendar_flags=flags,nitrogen=nitrogen,deposition=deposition,geometry=geometry,leaf_parameters=leaf,capacity_environment=kw['capacity_environment'],initial=initial,net=net,bounds=bounds);np.savez_compressed(r/'producer-before.npz',**packet)
        out_device=engine.step(*before,forcing,**kw);out=engine.host(out_device);next_device=native.next_station_arrays(before,out_device);after=tuple(engine.host(v) for v in next_device);incoming,residual,bound,tracer=native.audit_step(a,after,forcing,deposition,nitrogen,out);net=net+incoming;bounds=bounds+bound;cumulative=native.totals(after)-initial-net;assert np.all(abs(cumulative)<=bounds);maximum=np.maximum(maximum,abs(cumulative));stepmax=np.maximum(stepmax,abs(residual));tracermax=np.maximum(tracermax,tracer)
        capacity=np.float32(1000.)*after[1][:,:,2]*after[2][:,0,None];over=after[1][:,:,0]>capacity
        if over.any() and first_overfull is None:first_overfull=dict(completed_steps=index+1,locations=np.argwhere(over).tolist(),excess_kgm2=(after[1][:,:,0]-capacity).tolist())
        if index==target-1:
            def flat(d,prefix=''):
                for key,val in d.items():
                    if isinstance(val,dict):yield from flat(val,prefix+key+'/')
                    else:yield prefix+key,np.asarray(val)
            packet=dict(flat(out));packet.update({'after'+str(k):v for k,v in enumerate(after)});packet.update(original_incoming=incoming,original_residual=residual,original_bound=bound,original_tracer=tracer);np.savez_compressed(r/'producer-output.npz',**packet)
        a,device=after,next_device;index+=1
except Exception as err:failure=type(err).__name__+': '+str(err);(r/'traceback.txt').write_text(traceback.format_exc())
finally:heat._profile=original_profile;flow.run_richards_cuda=original_flow
actual={**{'a'+str(k):v for k,v in enumerate(a)},'initial':initial,'net':net,'bounds':bounds,'maximum':maximum,'stepmax':stepmax,'tracermax':tracermax,'index':np.asarray(index,dtype=expected['index'].dtype)};equal={k:actual[k].dtype==expected[k].dtype and actual[k].shape==expected[k].shape and actual[k].tobytes()==expected[k].tobytes() for k in actual};cp.cuda.runtime.deviceSynchronize();d=dict(case=label,failure=failure,replay_start=6480,completed_steps=index,original_terminal_completed_steps=target,all30_endpoint_state_and_ledger_exact=all(equal.values()) and len(equal)==30,endpoint_equal=equal,first_overfull=first_overfull,producer_flow_calls=calls,seconds=time.monotonic()-start,original_checkpoint6480_sha256=sha(checkpoint[0]),original_case_report6480_sha256=sha(case_report[0]),original_year_report_unchanged=sha(old/'trajectory/batch.json')==year['report_sha256'],source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barrier_complete=True,scope='PrivateCUDA forward reconstruction from retainedactualsuccessful6480 checkpoint through original6501/6499 endpoint, I/O wrappers only. No native.run/resume, no originalyear/files/source modified. Originalguardson eachstep/cumulative ledger retained; exact30endpoint provesfaithful replay. Rawproducer before/output/allwatercalls exported, not a fix/year/sciencepass.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and d['all30_endpoint_state_and_ledger_exact'] and d['source_unchanged'] and d['original_year_report_unchanged'] and first_overfull is not None else 1)

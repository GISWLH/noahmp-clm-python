from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import tarfile

base = Path('/home/lhwang/work/noahmp-v1')
source = base / 'qia1110-final-h'
root = base / 'qia-kink-cuda-year-h'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert not root.exists()
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 519 and all(sha(source / n) == h for n, h in manifest.items())
assert sha(source / 'SOURCE_SHA256.json') == '095f94bdce98640df6902983c71c44798e7ddca8d7352564895fe915834a0871'
cpu = base / 'qia1110-cpu-final-h-evidence.tar.gz'
assert sha(cpu) == '5ec4f1160f94f7264077437bc1cb9a5e1aaeec6967ea99654742283ffd4ed491'
with tarfile.open(cpu) as tf:
    assert json.loads(tf.extractfile('SOURCE_SHA256.json').read()) == manifest
    receipt = json.loads(tf.extractfile('receipt.json').read())
    assert receipt['returncode'] == 0 and receipt['source_unchanged']
    assert receipt['counts'] == dict(tests=943, failures=0, errors=0, skipped=0)
phase = source / 'target-h'
exit_record = json.loads((phase / 'exit.json').read_text())
receipt = json.loads((phase / 'receipt.json').read_text())
assert exit_record['passed'] and exit_record['returncode'] == 0
assert sha(phase / 'receipt.json') == exit_record['receipt_sha256']
assert receipt['source_manifest_sha256'] == sha(source / 'SOURCE_SHA256.json') and receipt['source_unchanged']
assert receipt['counts'] == dict(tests=14, failures=0, errors=0, skipped=0)
assert receipt['all_setup_call_teardown_phases_passed'] and receipt['node_coverage_exact']
paired = base / 'qia1110-paired-audit-j-evidence.tar.gz'
assert sha(paired) == '191f2d249a874590740cc835c5459d0be9e98fca16110bee6b364e207d857321'
with tarfile.open(paired) as tf:
    audit = json.loads(tf.extractfile('qia1110-paired-audit-j/audit.json').read())
    assert audit['passed'] and audit['source_unchanged'] and len(audit['fields']) == 380
    assert audit['source_manifest_sha256'] == sha(source / 'SOURCE_SHA256.json')
inputs = base / 'qia-stem-inputs-a.tar.gz'
assert sha(inputs) == '66ca0988cc66751284f61bf0909bd97b54c234cab895a53b51ce308d9ecec2f7'
free = int(subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
assert free > 6144
memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
assert int(memory['MemAvailable'].split()[0]) > 12 * 1024**2
root.mkdir()
with tarfile.open(inputs) as tf:
    tf.extractall(root, filter='data')
protocol = json.loads((root / 'protocol.json').read_text())
assert all(sha(root / 'inputs' / n) == h for n, h in protocol['inputs_sha256'].items())
cold = list((base / 'qia-stem-device-day-a/trajectory').glob('state-0000000-*.npz'))
assert len(cold) == 1
(root / 'strict-cold-reference.npz').write_bytes(cold[0].read_bytes())
(root / 'SOURCE_SHA256.json').write_bytes((source / 'SOURCE_SHA256.json').read_bytes())
environment = os.environ.copy()
environment.pop('LD_LIBRARY_PATH', None)
environment.update(PYTHONPATH=':'.join(map(str, [source, source / 'src', source / 'tests', source / 'benchmarks'])),
                   PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='1', CUDA_PATH='/usr/local/cuda-12.4',
                   PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false',
                   JAX_COMPILATION_CACHE_DIR=str(base / 'jax-surface-cache'))
with (root / 'controller.log').open('x') as log:
    child = subprocess.Popen([sys.executable, '-u', str(base / 'control_qia_kink_cuda_year_h.py')],
                             cwd=source, env=environment, stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=child.pid,
              gpu=1, free_memory_mib=free, source_manifest_sha256=sha(source / 'SOURCE_SHA256.json'),
              cpu_evidence_sha256=sha(cpu), phase_receipt_sha256=sha(phase / 'receipt.json'),
              paired1110_evidence_sha256=sha(paired), input_archive_sha256=sha(inputs),
              controls_sha256={n: sha(base / n) for n in ['run_qia_kink_cuda_year_h.py', 'control_qia_kink_cuda_year_h.py', Path(__file__).name]},
              scope='New original-cold519H CUDA-only17520 request after exactsource943CPU/14GPU and native1110 all380/originalhardbudgets. Own successful48 and corrected26-primary cold audit before own same-source continuation. No failed trajectory reused, no JAX shadow or year/full/spinup/science pass; actual older GPU workers remain.')
(root / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

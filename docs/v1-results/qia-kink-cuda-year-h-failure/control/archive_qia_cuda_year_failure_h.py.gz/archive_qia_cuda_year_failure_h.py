from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-kink-cuda-year-h';s=b/'qia1110-final-h';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text())
assert e['returncode']==1 and not e['passed'] and d['status']=='failed' and d['steps_completed']==3803 and d['source_unchanged']
assert sha(r/'receipt.json')==e['receipt_sha256']
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and sha(s/'SOURCE_SHA256.json')==d['source_manifest_sha256'] and all(sha(s/n)==v for n,v in m.items())
a=b/'qia-kink-cuda-year-h-failure-evidence.tar.gz';assert not a.exists();count=0
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname='original-run/'+p.relative_to(r).as_posix(),recursive=False);count+=1
    for n in [*m,'SOURCE_SHA256.json']:tf.add(s/n,arcname='source/'+n,recursive=False);count+=1
    for n in ['launch_qia_kink_cuda_year_h.py','control_qia_kink_cuda_year_h.py','run_qia_kink_cuda_year_h.py',Path(__file__).name]:
        tf.add(b/n,arcname='control/'+n,recursive=False);count+=1
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,files=count,
    scope='Actual original519H CUDA32 cold-year failure after3803/17520. All original inputs/checkpoints/traces/ledgers, source519 and controls retained. No failed-prefix acceptance or restart. Inner phase surface exception; root cause not yet localized.')))

from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile
base=Path('/home/zhangyq/noahmp-v1');root=base/'leafweb-light-fluorescence-a';source=base/'p6-spinup-assessment-c';old=base/'leafweb-electrons-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
reports=[]
for file,protocol,exit_name,job in [('diagnostic.json','protocol.json','pbs-exit.txt','103.manager'),('capacity-envelope.json','capacity-envelope-protocol.json','capacity-envelope-exit.txt','104.manager')]:
    r=json.loads((root/file).read_text());assert r['protocol']==json.loads((root/protocol).read_text())
    assert r['pbs_job']==job and r['node']=='compute002' and r['source_unchanged'] and not r['scientific_acceptance_claim'] and (root/exit_name).read_text().strip()=='0'
    result=subprocess.run(['qstat','-xf',job],capture_output=True,text=True,check=True);fields={}
    for line in result.stdout.splitlines():
        m=re.match(r'\s*(job_state|exec_host|Exit_status|resources_used\.(?:cput|walltime|mem))\s*=\s*(.*)$',line)
        if m:fields[m[1]]=m[2]
    assert fields['job_state']=='F' and fields['Exit_status']=='0'
    reports.append(dict(file=file,sha256=sha(root/file),pbs_job=job,pbs_fields=fields,reported_seconds=r['seconds']))
first=json.loads((root/'diagnostic.json').read_text());second=json.loads((root/'capacity-envelope.json').read_text())
assert [f['light_n'] for f in first['files']]==[13,13,13,13,0]
assert all(f['all_original_light_rows_have_valid_fluorescence'] for f in first['files'])
assert sum(f['above_ceiling_n'] for f in second['files'])==0
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual EHPC PBS103/104 light-curve fluorescence diagnostic and fixed-capacity ceiling, no fitting/production changes/acceptance. Filtered PBS metadata excludes process environments.',source_files=len(manifest),source_unchanged=True,reports=reports)
(root/'post-run-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
names=['probe_leafweb_light_fluorescence_a.py','leafweb_light_fluorescence_a.pbs','protocol.json','diagnostic.json','diagnostic.log','node.txt','pbs-exit.txt',
       'probe_leafweb_capacity_envelope_a.py','leafweb_capacity_envelope_a.pbs','capacity-envelope-protocol.json','capacity-envelope.json','capacity-envelope.log','capacity-envelope-node.txt','capacity-envelope-exit.txt','post-run-audit.json']
pairs=[(root/n,n) for n in names]+[(source/'SOURCE_SHA256.json','SOURCE_SHA256.json'),(source/'src/noahmp_clm/physics/photosynthesis.py','src/noahmp_clm/physics/photosynthesis.py'),
    (source/'tests/fixtures/leafweb_c3_grass.zip','tests/fixtures/leafweb_c3_grass.zip'),(old/'diagnostic.json','prior-aci-electron-diagnostic.json'),(old/'leafweb-multistart.json.gz','leafweb-multistart.json.gz'),(Path(__file__),'archive_leafweb_light_fluorescence_a.py')]
archive=base/'leafweb-light-fluorescence-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for path,name in pairs:t.add(path,arcname=name,recursive=False)
print(json.dumps(dict(files=len(pairs),sha256=sha(archive),receipt=receipt)))

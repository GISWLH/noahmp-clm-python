"""Check the J-independent upper envelope of the unchanged fitted capacities."""
from pathlib import Path
import hashlib,json,os,time
import numpy as np
from noahmp_clm.physics.photosynthesis import LeafParameters,farquhar_rates
import noahmp_clm.physics.photosynthesis as model
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=base/'leafweb-light-fluorescence-a';source=base/'p6-spinup-assessment-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
original=root/'diagnostic.json';r=json.loads(original.read_text());assert r['source_unchanged'] and r['protocol']['model_sha256']==sha(Path(model.__file__))
protocol=dict(scope='Necessary fixed-capacity upper bound independent of any nonnegative electron-transport J. This is a conditional mathematical diagnostic, not a new calibration, physical module or causal proof.',
    ceiling='min(Ac,Ap)-Rd at each original measured Ci and leaf temperature, with original fixed A-Ci/dark parameters; Aj can only lower net assimilation.',
    measurement_comparison='All original light rows retained; near-zero abs(observed)<=1 uses absolute0.5 micromol/m2/s, otherwise10% abs(observed). Counts are ceiling incompatibility with that fixed parameter state, not a new acceptance gate.',
    preceding_fluorescence_diagnostic_sha256=sha(original),model_sha256=sha(Path(model.__file__)),probe_sha256=sha(Path(__file__)),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'))
dest=root/'capacity-envelope-protocol.json';assert not dest.exists();dest.write_text(json.dumps(protocol,indent=2)+'\n')
begun=time.monotonic();files=[]
for case in r['files']:
    p=LeafParameters(**case['parameters']);rows=[]
    for row in case['rows']:
        rates=farquhar_rates(row['ci_ppm'],.84*row['incident_par'],row['leaf_temperature_k'],p)
        assert float(rates['net'])==row['predictions']['original-farquhar']
        ceiling=min(float(rates['rubisco']),float(rates['tpu']))-float(rates['respiration'])
        observed=row['observed_net'];tol=.5 if abs(observed)<=1. else .1*abs(observed)
        rows.append(dict(time=row['time'],incident_par=row['incident_par'],ci_ppm=row['ci_ppm'],leaf_temperature_k=row['leaf_temperature_k'],observed_net=observed,
            rubisco_gross=float(rates['rubisco']),product_gross=float(rates['tpu']),respiration=float(rates['respiration']),j_independent_net_ceiling=ceiling,
            observed_minus_ceiling=observed-ceiling,original_point_tolerance=tol,observed_exceeds_ceiling_beyond_tolerance=bool(observed-ceiling>tol)))
    files.append(dict(file=case['file'],light_n=len(rows),above_ceiling_n=sum(v['observed_minus_ceiling']>0. for v in rows),above_ceiling_beyond_tolerance_n=sum(v['observed_exceeds_ceiling_beyond_tolerance'] for v in rows),
        maximum_observed_minus_ceiling=None if not rows else max(v['observed_minus_ceiling'] for v in rows),rows=rows))
assert all(sha(source/n)==v for n,v in manifest.items())
value=dict(protocol=protocol,files=files,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-begun,source_unchanged=True,scientific_acceptance_claim=False,
    caveat='A violation rules out changing J alone under these fixed capacities/Ci/temperature/Rd. It does not uniquely identify the erroneous capacity, experimental state, mesophyll assumption or measurement, and does not justify fitting light rows.')
dest=root/'capacity-envelope.json';assert not dest.exists();dest.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps([{k:v for k,v in f.items() if k!='rows'} for f in files]),flush=True)

"""Bounded diagnostic with measured light-curve PSII, no fits or model edits."""
from pathlib import Path
from dataclasses import asdict
import csv,gzip,hashlib,io,json,os,time,zipfile
import numpy as np
from noahmp_clm.physics.photosynthesis import LeafParameters,farquhar_rates,R_GAS,T_REFERENCE
import noahmp_clm.physics.photosynthesis as model
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');source=base/'p6-spinup-assessment-c';root=base/'leafweb-light-fluorescence-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
archive=source/'tests/fixtures/leafweb_c3_grass.zip';prior=base/'leafweb-electrons-a/diagnostic.json';baseline=base/'leafweb-electrons-a/leafweb-multistart.json.gz'
assert sha(archive)=='936cff54c647e84bb4fc59e380c6d234888f8e47722635b00d24e55068c83cd5'
calibration=json.loads(gzip.decompress(baseline.read_bytes()));electron=json.loads(prior.read_text())
assert electron['baseline_sha256']==sha(baseline) and electron['model_sha256']==sha(Path(model.__file__))
old={v['file']:v for v in calibration['multistart']['files']};training={v['file']:v for v in electron['files']}
protocol=dict(scope='Diagnostic replacement of potential electron transport by operating PSII measurements in the original held-out light curves. No new fit, production change, blind-validation or scientific-acceptance claim.',
    labels=['original-farquhar','measured-psii-chi-0.42','measured-psii-original-aci-estimate'],
    parameter_source='Unchanged original A-Ci-only 27-start capacities and separate dark record.',
    fluorescence_formula='J = chi * incident_PAR * (Fm_prime - Fs) / Fm_prime',
    optical_hypotheses='chi=.42 fixed original .84 absorptance times .5 PSII fraction; alternative chi is the already-frozen A-Ci-only conditional estimate, not selected or fitted using light values.',
    row_selection='Every original DataType31..45 row; all five files retained, no model-score mask. Invalid fluorescence retained with explicit null conditional predictions; no conditional acceptance flag.',
    near_zero_definition='abs(observed net)<=1 micromol CO2 m-2 s-1',near_zero_absolute_tolerance=.5,
    archive_sha256=sha(archive),baseline_sha256=sha(baseline),prior_aci_electron_diagnostic_sha256=sha(prior),
    model_sha256=sha(Path(model.__file__)),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),probe_sha256=sha(Path(__file__)))
protocol_path=root/'protocol.json';assert not protocol_path.exists();protocol_path.write_text(json.dumps(protocol,indent=2)+'\n')
start=time.monotonic();files=[]
def statistics(prediction,observed):
    a=np.asarray(prediction);o=np.asarray(observed);assert a.shape==o.shape and a.size and np.all(np.isfinite(a))
    delta=a-o;near=abs(o)<=1.;mean=float(o.mean())
    return dict(n=int(a.size),mean_observed=mean,mean_bias=float(delta.mean()),relative_mean_bias=None if abs(mean)<=1. else float(delta.mean()/mean),
        rmse=float(np.sqrt(np.mean(delta**2))),normalized_rmse=None if abs(mean)<=1. else float(np.sqrt(np.mean(delta**2))/abs(mean)),
        r=None if np.ptp(a)==0. or np.ptp(o)==0. else float(np.corrcoef(a,o)[0,1]),
        near_zero_n=int(near.sum()),near_zero_max_abs=None if not near.any() else float(abs(delta[near]).max()),
        near_zero_failures=int(np.sum(abs(delta[near])>.5)),non_near_zero_pointwise_relative_failures=int(np.sum(abs(delta[~near])>.1*abs(o[~near]))))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(old)==set(training)
    for name in sorted(z.namelist()):
        records=list(csv.DictReader(io.StringIO(z.read(name).decode('cp1252'))))[1:]
        p=LeafParameters(**old[name]['parameters']);aci=[r for r in records if 11<=int(r['DataType'])<=25]
        data=np.asarray([[float(r[k]) for k in ['CO2i','PARi','Tleaf','AnetCO2']] for r in aci])
        reproduced=farquhar_rates(data[:,0],.84*data[:,1],data[:,2]+273.15,p)['net']
        assert abs(float(np.sqrt(np.mean((reproduced-data[:,3])**2)))-old[name]['calibration_rmse'])<1e-10
        points=[r for r in records if 31<=int(r['DataType'])<=45];chi=training[name]['summary']['inferred_product'];assert chi is not None and 0.<chi<1.
        entry=dict(file=name,parameters=asdict(p),unchanged_aci_rmse=old[name]['calibration_rmse'],aci_only_chi=chi,light_n=len(points),rows=[])
        predictions={label:[] for label in protocol['labels']};observations=[];valid=True;jpairs=[]
        for r in points:
            ci,par,temp,observed,fm,fs=[float(r[k]) for k in ['CO2i','PARi','Tleaf','AnetCO2','FmorFm.','FoorFs']];temp+=273.15
            assert np.all(np.isfinite([ci,par,temp,observed,fm,fs]))
            rates=farquhar_rates(ci,.84*par,temp,p);ok=fm>0. and 0.<=fs<=fm and par>=0.
            phi=(fm-fs)/fm if ok else None
            gamma=42.75*np.exp(37830./(R_GAS*T_REFERENCE)*(1.-T_REFERENCE/temp));carbon=max(ci-gamma,0.)
            row=dict(time=r['ObsDate']+'T'+r['HHMMSS'],ci_ppm=ci,incident_par=par,leaf_temperature_k=temp,observed_net=observed,
                fluorescence_valid=ok,measured_operating_psii_yield=phi,modeled_potential_j=float(rates['electron_transport']),predictions={protocol['labels'][0]:float(rates['net'])})
            predictions[protocol['labels'][0]].append(float(rates['net']));observations.append(observed)
            for label,factor in [(protocol['labels'][1],.42),(protocol['labels'][2],chi)]:
                j=factor*par*phi if ok else None
                conditional=min(float(rates['rubisco']),j*carbon/(4.*ci+8.*gamma),float(rates['tpu']))-float(rates['respiration']) if ok else None
                row['predictions'][label]=conditional;row[label+'_j']=j;predictions[label].append(conditional)
            if ok:jpairs.append([float(rates['electron_transport']),.42*par*phi,chi*par*phi])
            valid=valid and ok;entry['rows'].append(row)
        entry['all_original_light_rows_have_valid_fluorescence']=valid
        entry['summaries']={}
        if points:
            entry['summaries'][protocol['labels'][0]]=statistics(predictions[protocol['labels'][0]],observations)
            for label in protocol['labels'][1:]:
                entry['summaries'][label]=statistics(predictions[label],observations) if valid else dict(status='unmeasured_all_rows_required')
            if valid:
                j=np.asarray(jpairs);entry['j_max_abs_differences_from_potential']={label:float(abs(j[:,k]-j[:,0]).max()) for k,label in enumerate(protocol['labels'][1:],start=1)}
        else:entry['status']='unmeasured_no_light_records'
        files.append(entry)
assert all(sha(source/n)==v for n,v in manifest.items())
value=dict(protocol=protocol,files=files,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,source_files=len(manifest),source_unchanged=True,production_parameters_or_physics_changed=False,scientific_acceptance_claim=False,
    caveat='Measured operating PSII is an extra experimental input absent from the model driver. Conditional predictions cannot replace the original light-response validation or prove causation; chi, mesophyll conductance, Rd and electron sinks remain uncertain.')
output=root/'diagnostic.json';assert not output.exists();output.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps([dict(file=v['file'],n=v['light_n'],summaries=v['summaries']) for v in files]),flush=True)

from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-phase-jacobian-legacy-replay-a';receipt=root/'cuda-launch.json';assert not receipt.exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:benchmarks',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with (root/'cuda-replay.log').open('w') as log:p=subprocess.Popen(['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'replay_legacy_g614_cuda.py')],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0);receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

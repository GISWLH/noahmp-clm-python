from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,time,traceback
import numpy as np
from run_fluxnet_native import Backend,audit_step,source_hashes
from noahmp_clm.gpu.clm_bgc_column import next_bgc_arrays
from noahmp_clm.physics.photosynthesis import LeafParameters
root=Path.cwd();base=root.parent;original=base/'fluxnet-first-climate-cycle-20261017-g/failure-614-capture-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in manifest.items())
capture=json.loads((original/'summary.json').read_text());input_path=original/'whole-column-inputs.npz';assert sha(input_path)==capture['artifacts'][input_path.name]
with np.load(input_path,allow_pickle=False) as z:v=dict(z)
configs=[json.loads(Path(row['configuration']).read_text()) for row in json.loads((original.parent/'batch.json').read_text())['cases']]
assert all(c['leaf_parameters']==configs[0]['leaf_parameters'] for c in configs)
engine=Backend('cuda32');a=tuple(engine.xp.asarray(v[f'a{k}']) for k in range(16));a=engine.update_forcing(a,v['forcing_environment'])
begun=time.monotonic();result=dict(scope='Actual old G614 four-column step, unchanged old soil law/six-field arrays, only three phase solver files patched. JAX whole-step shadow and new-suction climate are separate.',input_sha256=sha(input_path),source_sha256=source_hashes())
try:
    out=engine.step(*a,v['forcing'],environment=v['environment'],calendar=v['calendar'],nitrogen_deposition_gn_m2=v['nitrogen'],deposition=v['deposition'],most_geometry=v['geometry'],
        leaf_parameters=LeafParameters(**configs[0]['leaf_parameters']),return_surface=True)
    host=engine.host(out);after=tuple(engine.host(x) for x in next_bgc_arrays(a,out));before=tuple(engine.host(x) for x in a)
    _,residual,bound,tracer=audit_step(before,after,v['forcing'],v['deposition'],v['nitrogen'],host)
    flat={}
    def flatten(value,prefix=''):
        for k,x in value.items():
            if isinstance(x,dict):flatten(x,prefix+k+'/')
            else:flat[prefix+k]=np.asarray(x)
    flatten(host);assert all(np.all(np.isfinite(x)) for x in flat.values())
    np.savez_compressed(root/'cuda-output.npz',**flat);np.savez_compressed(root/'cuda-next-state.npz',**{f'a{k}':x for k,x in enumerate(after)})
    result.update(status='complete',residual_m_h_c_n=residual.tolist(),bound_m_h_c_n=bound.tolist(),impurity_residual=tracer.tolist(),
        most_iterations=host['surface']['most']['iterations'].tolist(),max_canopy_residual=host['surface']['max_solver_residual'].tolist())
except Exception:result.update(status='failed',failure=traceback.format_exc())
result['seconds']=time.monotonic()-begun;assert all(sha(root/k)==x for k,x in manifest.items())
result['source_unchanged']=True;result['finished_utc']=datetime.now(timezone.utc).isoformat()
(root/'cuda-replay.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}),flush=True)
assert result['status']=='complete'

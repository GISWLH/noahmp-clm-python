from pathlib import Path,PurePosixPath
import hashlib,json,shutil,tarfile
base=Path('/home/lhwang/work/noahmp-v1');old=base/'p6-heat-phase-event-a';root=base/'p6-phase-jacobian-legacy-replay-a';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();original=json.loads((old/'SOURCE_SHA256.json').read_text())
names=sorted(k for k in original if k.startswith('src/') or k in ['benchmarks/run_fluxnet_native.py','benchmarks/run_fluxnet_column.py','benchmarks/fluxnet_solar.py','benchmarks/fluxnet_deposition.py'])
for name in names:
    p=old/name;assert sha(p)==original[name];target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
allowed={'src/noahmp_clm/physics/canopy_phase_energy.py','src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu'}
archive=base/'phase-interval-patches-a.tar.gz'
with tarfile.open(archive) as t:
    members=t.getmembers();assert {m.name for m in members}==allowed
    for m in members:
        p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
        (root/m.name).write_bytes(t.extractfile(m).read())
current={name:sha(root/name) for name in names};changed={name for name in names if current[name]!=original[name]};assert changed==allowed
(root/'SOURCE_SHA256.json').write_text(json.dumps(current,indent=2)+'\n')
(root/'original-source-sha256.json').write_text(json.dumps({n:original[n] for n in names},indent=2)+'\n')
(root/'source-differences.json').write_text(json.dumps(dict(scope='Isolated old six-property thermodynamics retained. Only three phase solver files patched. No original directory or old checkpoint changed.',files=sorted(changed),patch_archive_sha256=sha(archive)),indent=2)+'\n')
print(json.dumps(dict(files=len(names),changed=sorted(changed))))

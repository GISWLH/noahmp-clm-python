from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

root = Path('/home/lhwang/work/noahmp-v1/climatology-cycles-ho')
number = int(sys.argv[1])
assert number in [2, 3]
folder = root / ('cycle-' + str(number).zfill(2))
begun = time.monotonic()
command = [sys.executable, '-u', str(root / 'run_climatology_cycle_ho.py'), str(number)]
with (folder / 'model.log').open('x') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
(folder / 'worker.json').write_text(json.dumps(dict(pid=process.pid, command=command), indent=2) + '\n')
code = process.wait()
path = folder / 'receipt.json'
data = json.loads(path.read_text()) if path.exists() else {}
passed = bool(code == 0 and data.get('failure') is None and data.get('source_unchanged') and data.get('controls_unchanged')
    and data.get('device_barrier_complete') and data.get('first_nonindex_checkpoint_fields_exact') == 22
    and data.get('first_actual_device_arrays_verified') == 16 and data.get('first_continued_step_captured')
    and data.get('status') == 'complete' and data.get('steps_completed') == data.get('steps_requested') == 17520
    and data.get('ledger_steps') == 17520 * number and data.get('ledger_segments') == number
    and data.get('bgc_diagnostic_steps') == 17520)
record = dict(actual_parent_returncode=code, passed=passed, cycle=number,
    receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None,
    seconds=time.monotonic()-begun,
    scope='ActualnativeCUDA-only fullclimatecycleparent terminal; queue/childreceipt alone not enough. No backendshadow/fullGPU/observedscience/waterheat/SOC equilibrium assertion.')
(folder / 'exit.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if passed else 1)

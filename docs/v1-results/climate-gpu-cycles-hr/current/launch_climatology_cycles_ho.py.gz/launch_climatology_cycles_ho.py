"""Metadata-only source/control staging and live queue launch, no GPU model step."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import tarfile

base = Path('/home/lhwang/work/noahmp-v1')
root = base / 'climatology-cycles-ho'
source = Path('/tmp/noahmp-climatology-cycles-ho/source')
assert not root.exists() and not source.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
source.mkdir(parents=True)
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(sha(source / name) == digest for name, digest in manifest.items())
gw = base / 'climatology-year-queue-gw'
previous = json.loads((gw / 'launch.json').read_text())
assert previous['source_manifest_sha256'] == source_sha and previous['physical_gpu_index'] == 1
os.kill(previous['pid'], 0)
root.mkdir()
for number in [2, 3]:
    (root / ('cycle-' + str(number).zfill(2))).mkdir()
names = ['run_climatology_cycle_ho.py', 'control_climatology_cycle_ho.py', 'queue_climatology_cycles_ho.py', Path(__file__).name]
for name in names:
    raw = (base / name).read_bytes()
    assert b'\r\n' not in raw
    (root / name).write_bytes(raw)
scope = ('ProspectivecurrentFL57912case repeatedoriginal365dayclimatecycles2/3 onlyafter ownactualGWfull17520parent0; '
    'source/config/forcing/QC/splits unchanged, original16physicalarrays andall6conservationledgerfields carriedbyteexact, '
    'onlycycle-localindex restarts0 with ledger_steps/segments monotonicallyincreasing. Firstactualdevicearrays checked '
    'after only prescribedCO2/solar/diffuse update; nativeCUDAonly, no NumPyforward/JAXshadow/failedprefix/reseed/preconditioning. '
    'Original32GiBhost/8GiBGPUstart,4GiBhostpeak/physicalguards andrawdailyBGCdiagnostics retained. '
    'All20maxcycleprotocol unchanged; thisboundedbatch covers onlycycles2/3, actualindependentEHPC endpoint/SOCassessment stillrequired; '
    'no full404/sameprecision/climateconvergence/SOC/observedmultiyear/calibration/holdout/release claim.')
plan = dict(source_manifest_sha256=source_sha, source_files=579, physical_gpu_index=1,
    cycles_requested=[2, 3], original_maximum_cycles=20, original_steps_per_cycle=17520,
    initial_parent_root=str(base / 'climatology-cuda-cold-go'), source=str(source),
    batch_sha256=sha(base / 'climatology-cuda-cold-go/inputs/batch.json'),
    controls_sha256={name: sha(root / name) for name in names}, scope=scope)
(root / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
with (root / 'controller.log').open('x') as log:
    process = subprocess.Popen([sys.executable, '-u', str(root / 'queue_climatology_cycles_ho.py')],
        cwd=source, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
record = dict(pid=process.pid, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_manifest_sha256=source_sha, physical_gpu_index=1, original_gw_pid=previous['pid'],
    plan_sha256=sha(root / 'plan.json'), controls_sha256=plan['controls_sha256'], scope=scope)
(root / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

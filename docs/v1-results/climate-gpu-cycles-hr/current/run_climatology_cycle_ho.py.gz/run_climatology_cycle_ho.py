"""Actual native climate cycle2/3, only from the successful original full year."""
from pathlib import Path
import hashlib
import json
import os
import resource
import sys
import time
import traceback
import numpy as np

base = Path('/home/lhwang/work/noahmp-v1')
root = base / 'climatology-cycles-ho'
number = int(sys.argv[1])
assert number in [2, 3]
folder = root / ('cycle-' + str(number).zfill(2))
source = Path('/tmp/noahmp-climatology-cycles-ho/source')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan = json.loads((root / 'plan.json').read_text())
assert all(sha(root / name) == digest for name, digest in plan['controls_sha256'].items())
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == plan['source_manifest_sha256']
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as numpy_runner
import noahmp_clm.clm_enthalpy_driver as numpy_driver
import noahmp_clm.physics.richards as numpy_flow
import cupy as cp

prior = base / 'climatology-cuda-cold-go' if number == 2 else root / 'cycle-02'
exit_path = prior / ('year-exit.json' if number == 2 else 'exit.json')
receipt_path = prior / ('year-receipt.json' if number == 2 else 'receipt.json')
parent = json.loads(exit_path.read_text())
parent_receipt = json.loads(receipt_path.read_text())
assert parent['passed'] and parent['actual_parent_returncode'] == 0 and sha(receipt_path) == parent['receipt_sha256']
assert parent_receipt['failure'] is None and parent_receipt['source_unchanged']
assert parent_receipt['source_manifest_sha256'] == source_sha
previous, saved, old_rows = native.read_generation(prior / 'trajectory')
assert previous['status'] == 'complete' and previous['steps_completed'] == previous['steps_requested'] == 17520
assert previous['source_unchanged'] and previous['ledger_steps'] == 17520 * (number - 1)
assert previous['ledger_segments'] == number - 1 and len(saved) == 23 and len(old_rows) == 12
assert previous['identity']['backend'] == 'cuda32' and not previous['identity']['compare_jax32']
assert previous['identity']['source_sha256'] == native.source_hashes()
batch = base / 'climatology-cuda-cold-go/inputs/batch.json'
assert sha(batch) == previous['identity']['batch_sha256'] == plan['batch_sha256']
cases = native.load_batch(batch)
assert native.native_state_count(cases) == 16 and len(cases) == 12
expected_device = [value.copy() for value in native.checkpoint_arrays(saved, previous['identity'])]
expected_device[4][:, 7:10] = np.asarray([c['data']['environment'][0] for c in cases], np.float32)
(folder / 'parent-complete-checkpoint.npz').write_bytes((prior / 'trajectory' / previous['checkpoint_file']).read_bytes())
assert sha(folder / 'parent-complete-checkpoint.npz') == previous['checkpoint_sha256']
(folder / 'parent-complete-report.json').write_bytes((prior / 'trajectory/batch.json').read_bytes())
(folder / 'actual-parent-exit.json').write_bytes(exit_path.read_bytes())
(folder / 'actual-parent-receipt.json').write_bytes(receipt_path.read_bytes())
original_step = native.Backend.step
original_audit = native.audit_step
original_forbidden = [numpy_runner.step_clm_enthalpy_column, numpy_driver.step_clm_enthalpy_column,
                      numpy_flow.redistribute_soil_enthalpy]
first_exact = False
captured_first = False
index = 0
buffer = []
chunks = []
diagnostics_folder = folder / 'bgc-diagnostics'
diagnostics_folder.mkdir()
begun = time.monotonic()
failure = None


def forbidden(*args, **kwargs):
    raise AssertionError('Native climate cycles cannot use NumPy forward physics')


def first(self, *args, **kwargs):
    global first_exact
    if not first_exact:
        current, start, rows = native.read_generation(folder / 'trajectory')
        assert current['status'] == 'running' and current['steps_completed'] == 0
        assert current['identity']['initial_run']['mode'] == 'cycle'
        assert current['ledger_steps'] == previous['ledger_steps'] and current['ledger_segments'] == number
        assert set(start) == set(saved) and int(start['index']) == 0
        for key in set(start) - {'index'}:
            a, b = start[key], saved[key]
            assert a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes(), key
        assert len(args) == 17 and len(rows) == 12
        for k in range(16):
            actual = self.host(args[k])
            expected = expected_device[k]
            assert actual.dtype == expected.dtype and actual.shape == expected.shape and actual.tobytes() == expected.tobytes(), k
        native.atomic_json(folder / 'first-cycle-state-audit.json', dict(
            nonindex_checkpoint_fields_byteexact=22, primary_device_arrays_verified=16,
            cycle_local_index=0, previous_ledger_steps=previous['ledger_steps'], ledger_segments=number,
            parent_report_sha256=sha(prior / 'trajectory/batch.json'),
            zero_step_report_sha256=sha(folder / 'trajectory/batch.json'),
            prescribed_environment_update='Only originalnativeupdate_forcing sitearray[:,7:10] CO2/solar/diffuse to firstoriginalyear interval; allother actualdevice fields exact to successfulparent',
            scope='Immediately before firstphysicaltendency: all22nonindex parentcheckpoint fields exact, originalfullstate/initial/net/bounds/maxima/tracers retained; onlycycle-local calendarindex reset. No coldreset/failedprefix/ledgerreset.'))
        first_exact = True
    return original_step(self, *args, **kwargs)


def audit(before, after, forcing, deposition, nitrogen, output):
    global index, captured_first
    result = original_audit(before, after, forcing, deposition, nitrogen, output)
    if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss > 4 * 1024 * 1024:
        raise RuntimeError('CUDA-only climate cycle exceeded original4GiB measured host peak')
    row = dict(forcing=np.asarray(forcing).copy(), deposition=np.asarray(deposition).copy(),
        nitrogen=np.asarray(nitrogen).copy(), before_plant=np.asarray(before[11]).copy(),
        before_soil_cn=np.asarray(before[13]).copy(), after_plant=np.asarray(after[11]).copy(),
        after_soil_cn=np.asarray(after[13]).copy())
    def flatten(value, prefix, target):
        for key, item in value.items():
            if isinstance(item, dict):
                flatten(item, prefix + key + '/', target)
            else:
                target[prefix + key] = np.asarray(item).copy()
    flatten(output['biogeochemistry'], 'bgc/', row)
    assert all(value.dtype.kind != 'O' for value in row.values())
    buffer.append(row)
    if not captured_first:
        packet = {f'before{k}': np.asarray(value) for k, value in enumerate(before)}
        packet.update({f'after{k}': np.asarray(value) for k, value in enumerate(after)})
        packet.update(forcing=np.asarray(forcing), deposition=np.asarray(deposition), nitrogen=np.asarray(nitrogen))
        flatten(output, 'out/', packet)
        assert all(value.dtype.kind != 'O' for value in packet.values())
        native.write_npz(folder / 'first-continued-step.npz', **packet)
        captured_first = True
    index += 1
    if index % 48 == 0:
        path = diagnostics_folder / ('steps-' + str(index - len(buffer)).zfill(7) + '-' + str(index).zfill(7) + '.npz')
        native.write_npz(path, **{key: np.stack([one[key] for one in buffer]) for key in row})
        chunks.append(dict(first=index-len(buffer), end=index, sha256=sha(path)))
        buffer.clear()
    return result


try:
    native.Backend.step = first
    native.audit_step = audit
    numpy_runner.step_clm_enthalpy_column = forbidden
    numpy_driver.step_clm_enthalpy_column = forbidden
    numpy_flow.redistribute_soil_enthalpy = forbidden
    report = native.run(batch, folder / 'trajectory', backend='cuda32', compare_jax32=False,
        initial_run=prior / 'trajectory', initial_mode='cycle')
    assert first_exact and captured_first and index == 17520 and not buffer
    assert report['status'] == 'complete' and report['steps_completed'] == report['steps_requested'] == 17520
    assert report['ledger_steps'] == number * 17520 and report['ledger_segments'] == number
    assert report['source_unchanged'] and report['same_precision_max_absolute'] is None
except Exception as exc:
    failure = type(exc).__name__ + ': ' + str(exc)
    (folder / 'traceback.txt').write_text(traceback.format_exc())
    print(traceback.format_exc(), flush=True)
finally:
    native.Backend.step = original_step
    native.audit_step = original_audit
    numpy_runner.step_clm_enthalpy_column, numpy_driver.step_clm_enthalpy_column, numpy_flow.redistribute_soil_enthalpy = original_forbidden
cp.cuda.runtime.deviceSynchronize()
path = folder / 'trajectory/batch.json'
report = json.loads(path.read_text()) if path.exists() else {}
record = dict(cycle=number, failure=failure, source_manifest_sha256=source_sha,
    source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    controls_unchanged=all(sha(root / name) == digest for name, digest in plan['controls_sha256'].items()),
    status=report.get('status'), steps_completed=report.get('steps_completed'), steps_requested=report.get('steps_requested'),
    ledger_steps=report.get('ledger_steps'), ledger_segments=report.get('ledger_segments'),
    first_nonindex_checkpoint_fields_exact=22 if first_exact else None,
    first_actual_device_arrays_verified=16 if first_exact else None, first_continued_step_captured=captured_first,
    bgc_diagnostic_steps=index, bgc_diagnostic_chunks=chunks, device_barrier_complete=True,
    maximum_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    report_sha256=sha(path) if path.exists() else None, seconds=time.monotonic()-begun, scope=plan['scope'])
native.atomic_json(folder / 'receipt.json', record)
with (folder / 'receipt.json').open('rb') as stream:
    os.fsync(stream.fileno())
print(json.dumps(record), flush=True)
os._exit(0 if failure is None and record['source_unchanged'] and record['controls_unchanged'] else 1)

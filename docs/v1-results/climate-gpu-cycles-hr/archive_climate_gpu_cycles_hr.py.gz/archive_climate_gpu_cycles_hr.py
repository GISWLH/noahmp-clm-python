"""Metadata-only proof of the live serialized cycle queue, no simulated credit."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import subprocess
import tarfile

base = Path('/home/lhwang/work/noahmp-v1')
root = base / 'climatology-cycles-ho'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
launch = json.loads((root / 'launch.json').read_text())
plan = json.loads((root / 'plan.json').read_text())
assert sha((root / 'plan.json').read_bytes()) == launch['plan_sha256']
assert all(sha((root / n).read_bytes()) == h for n, h in plan['controls_sha256'].items())
pid = launch['pid']
os.kill(pid, 0)
cmdline = Path('/proc') / str(pid) / 'cmdline'
assert b'queue_climatology_cycles_ho.py' in cmdline.read_bytes()
parent = base / 'climatology-year-queue-gw'
parent_launch = json.loads((parent / 'launch.json').read_text())
os.kill(parent_launch['pid'], 0)
assert not (root / 'exit.json').exists() and not (parent / 'exit.json').exists()
assert all(not any((root / ('cycle-' + str(n).zfill(2))).iterdir()) for n in [2, 3])
snapshot = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=pid,
    actual_proc_cmdline=cmdline.read_bytes().replace(b'\0', b' ').decode(),
    actual_ps=subprocess.check_output(['ps', '-p', str(pid), '-o', 'pid,etime,stat,args'], text=True),
    original_gw_pid=parent_launch['pid'], original_gw_alive=True, physical_gpu_index=1,
    no_cycle_worker_or_zero_seed_created=True, no_parent_year_completion_claim=True, scope=plan['scope'])
items = {'snapshot.json': (json.dumps(snapshot, indent=2) + '\n').encode()}
for p in root.iterdir():
    if p.is_file():
        items['current/' + p.name] = p.read_bytes()
items['original-gw-launch.json'] = (parent / 'launch.json').read_bytes()
items['archive_climate_gpu_cycles_hr.py'] = Path(__file__).read_bytes()
archive = base / 'climate-gpu-cycles-hr-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for name, raw in items.items():
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        tf.addfile(member, io.BytesIO(raw))
with tarfile.open(archive) as tf:
    for member in tf:
        assert tf.extractfile(member).read() == items[member.name]
package = dict(archive_sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size, artifacts=len(items),
    source_manifest_sha256=plan['source_manifest_sha256'], scope=plan['scope'])
(base / 'climate-gpu-cycles-hr-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

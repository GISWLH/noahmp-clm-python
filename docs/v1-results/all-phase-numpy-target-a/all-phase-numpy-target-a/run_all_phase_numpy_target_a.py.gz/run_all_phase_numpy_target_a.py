from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1'); r = b / 'all-phase-numpy-target-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
package = json.loads((r / 'package.json').read_text()); roots = {}
for label, name, digest in [('baseline', 'p6-fresh-phase-edge-a-source.tar.gz', '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'),
                             ('candidate', 'p6-all-phase-numpy-a-source.tar.gz', package['archive_sha256'])]:
    a = b / name; assert sha(a) == digest
    s = Path(os.environ['TMPDIR']) / label; s.mkdir()
    with tarfile.open(a) as t:
        t.extractall(s, filter='data')
    m = json.loads((s / 'SOURCE_SHA256.json').read_text()); assert all(sha(s / n) == h for n, h in m.items())
    roots[label] = (s, m)
old, om = roots['baseline']; new, m = roots['candidate']
assert len(om) == 510 and len(m) == 511
assert sorted(n for n, h in m.items() if om.get(n) != h) == sorted(package['changed'])
for name in ['tests/test_canopy_phase_energy.py', 'tests/fixtures/qia_735_phase_oldwet.json']:
    (old / name).write_bytes((new / name).read_bytes())
observed = {n: sha(old / n) for n in m}
(r / 'baseline-observed-manifest.json').write_text(json.dumps(observed, indent=2) + '\n')
(r / 'SOURCE_SHA256.json').write_bytes((new / 'SOURCE_SHA256.json').read_bytes())
for label, s, manifest, selection, count, expected_failure in [
    ('baseline735', old, observed, ['tests/test_canopy_phase_energy.py::test_existing_wet_phase_edge_closes_saved_qia735_without_changing_stores'], 1, 1),
    ('phase-target', new, m, ['tests/test_canopy_phase_energy.py'], 26, 0),
]:
    env = os.environ.copy(); env.update(PYTHONPATH=':'.join(map(str, [b / 'test-deps', s, s / 'src', s / 'tests'])),
           PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    start = time.monotonic(); xml = r / (label + '.xml')
    with (r / (label + '.log')).open('x') as log:
        code = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-s', *selection, '--junitxml=' + str(xml)], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    tree = ET.parse(xml).getroot(); counts = {k: sum(int(x.attrib[k]) for x in tree.iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
    unchanged = all(sha(s / n) == h for n, h in manifest.items())
    record = dict(scope='NumPy-first targeted validation with original735 baseline failure retained and original26phase cases. Original equations/stores/80/1e-7/science10percent and independent guards unchanged;no GPU/full/year/science pass.',
                  label=label, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, returncode=code, counts=counts, source_unchanged=unchanged, seconds=time.monotonic() - start,
                  source_files=len(manifest), xml_sha256=sha(xml), package_sha256=sha(r / 'package.json'))
    (r / (label + '-receipt.json')).write_text(json.dumps(record, indent=2) + '\n'); print(json.dumps(record), flush=True)
    assert code == (1 if expected_failure else 0) and unchanged and counts == dict(tests=count, failures=expected_failure, errors=0, skipped=0)

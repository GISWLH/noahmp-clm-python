from pathlib import Path
import hashlib
import io
import json
import tarfile

b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
def archive(name,roots,scope):
 a=b/(name+'-evidence.tar.gz');assert not a.exists()
 with tarfile.open(a,'w:gz') as t:
  for root in roots:
   for p in sorted(root.rglob('*')):
    if p.is_file():t.add(p,arcname=root.name+'/'+p.relative_to(root).as_posix(),recursive=False)
  raw=(json.dumps(dict(scope=scope),indent=2)+'\n').encode();item=tarfile.TarInfo('summary.json');item.size=len(raw);t.addfile(item,io.BytesIO(raw))
  t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 results.append(dict(name=name,sha256=sha(a),bytes=a.stat().st_size))
probe=b/'qia735-numpy-probe-a';d=json.loads((probe/'comparison.json').read_text())
assert (probe/'pbs-exit.txt').read_text().strip()=='0' and d['records'][0]['failure'] and d['records'][1]['failure'] is None
assert (b/'qia735-reference-fixture-a/pbs-exit.txt').read_text().strip()=='1' and (b/'qia735-reference-fixture-b/pbs-exit.txt').read_text().strip()=='0'
assert sha(b/'qia735-reference-fixture-b/qia_735_phase_oldwet.json')=='93bf18fcbfba472509ee03a32681a5746c57190e4decac75697f0af7d521ffc6'
archive('qia735-numpy-probes-a',[probe,b/'qia735-reference-fixture-a',b/'qia735-reference-fixture-b'],
 'EHPC254 exact original735 full-step failure reproduced and F oldwet-edge succeeds under original80/1e-7/MHCN. Fixture255base ABI rejectsMOST extension,256correct base-plus-explicit originalextension preserves all values and independent SciPy comparison T5.68434e-14K/H1.25588e-12/LE3.49942e-13W. Bothquantized32/64NumPy refs generated on EHPC. All failed/scored outcomes retained,no year continuation or backend acceptance.')
root=b/'all-phase-numpy-target-a';assert (root/'pbs-exit.txt').read_text().strip()=='0'
assert json.loads((root/'baseline735-receipt.json').read_text())['counts']==dict(tests=1,failures=1,errors=0,skipped=0)
assert json.loads((root/'phase-target-receipt.json').read_text())['counts']==dict(tests=26,failures=0,errors=0,skipped=0)
archive('all-phase-numpy-target-a',[root], 'EHPC257 NumPy-first intermediate511 target26actual0 and original baseline735expected1failure retained. New independent real-failure regression,oldphysical equations/oldstores/80/1e-7 unchanged;not finalGPU/fullcanonical/year/science acceptance.')
root=b/'all-phase-cpu-final-a';assert (root/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((root/'cpu-full-receipt.json').read_text());assert d['counts']==dict(tests=911,failures=0,errors=0,skipped=0) and d['source_unchanged']
assert json.loads((root/'point735-probe.json').read_text())['failure'] is None
archive('all-phase-cpu-final-a',[root], 'FinalA source511 EHPC258 fullCPU911actual0 plus uninstrumented production735whole-step originalhardguards. Heat3.84025e-8J vs1.45253e-5originalbound. Source800455;sourceB later onlynewGPUtest argument-binding correction,allproduction bytes identical. Not GPU/fullcanonical/year/science acceptance.')
root=b/'qia3798-paired-audit-g';assert (root/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((root/'audit.json').read_text());assert d['passed'] and d['maximum_absolute_difference']==0. and len(d['fields'])==380
archive('qia3798-paired-audit-g',[root], 'EHPC259 original509C independent unchanged MHCN/impurity and original1e-6/int-exact audit of both isolated F original3798 whole steps. All361outputs+19next fields maximumdifference0,each originalstep/cumulativehardbound satisfied;original failedyear untouched. Actual functions/tokens match final511production via separately preserved package proof. Not fullcanonical/year/science acceptance.')
root=b/'qia735-staging-analysis-c';assert (root/'pbs-exit.txt').read_text().strip()=='0'
d=json.loads((root/'analysis.json').read_text());assert d['variants']['default_dynamic_parameters']['bitwise_equal'] and d['tracked_radiation']['bitwise_equal']
assert not d['variants']['jax_original_raw']['sameprecision_pass'] and not d['variants']['explicit_radiation_constant_parameters']['sameprecision_pass']
archive('qia735-staging-analysis-c',[root], 'EHPC261 predeclared full300raw comparison: captured-constant leaf/MOST parameters fail57fields,max.18237305J;dynamic devicearguments as production pass all300bitwise0,whether radiation internal or explicit. All584trackedradiationbitwise0. Originalfailedpaths retained,onlytest call correction indicated;no physical/tolerance/precision/gate or acceptedtrajectory changes.')
print(json.dumps(results))

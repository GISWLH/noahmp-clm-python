"""Independent stdlib review of actual OO EHPC evidence, without numerical work."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()


def unpack(data):
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() or m.isdir() for m in members)
        assert len({m.name for m in members}) == len(members)
        assert all(not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
        files = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in members if m.isfile()}
        assert len(files) == sum(m.isfile() for m in members)
        return files


p = json.loads((ROOT / 'fluxnet-calibration-score-oo-package.json').read_bytes())
raw = (ROOT / p['archive']).read_bytes()
assert sha(raw) == p['sha256'] == 'e0ccc6aa7739c8c3d2dc3e43d2f7240993ed960be90b5da7241db5b93ab4cf49'
assert len(raw) == p['bytes']
files = unpack(raw)
assert len(files) == p['artifacts'] == 86
assert {n: sha(b) for n, b in files.items()} == p['artifact_sha256']
inventory = json.loads(files['artifact-inventory.json'])
assert set(inventory) == set(files) - {'artifact-inventory.json'}
assert all(sha(files[n]) == v['sha256'] and len(files[n]) == v['bytes'] for n, v in inventory.items())
receipt = json.loads(files['result/receipt.json'])
assert receipt['pbs_job'] == '1599.manager' and receipt['node'] == 'compute002'
assert receipt['passed'] is True and receipt['error'] is None
assert receipt['unittest_parent_returncode'] == receipt['diagnostic_parent_returncode'] == 0
assert not receipt['unittest_timed_out']
assert receipt['model_runs'] == receipt['GPU_runs'] == receipt['physical_candidate_scores'] == 0
assert receipt['production_scoring_enabled'] is False
assert receipt['source_files_verified_before_after'] == 584
assert receipt['preparation_source_and_originals_unchanged'] is True
for name in ['pbs-exit.txt', 'result/worker-exit.txt', 'result/unittest-parent-exit.txt', 'result/diagnostic-parent-exit.txt']:
    assert files[name].decode().strip() == '0'
qstat = files['actual-pbs-qstat.txt'].decode()
for pattern in [r'^Job Id: 1599\.manager\s*$', r'^\s*job_state = F\s*$', r'^\s*Exit_status = 0\s*$', r'^\s*Stageout_status = 0\s*$']:
    assert re.search(pattern, qstat, re.M), pattern
stage = unpack(files['original-stage.tar.gz'])
assert sha(files['original-stage.tar.gz']) == '4c269540ba683e5e0e520b65952d82a72f4f13efec3e1f3933836ba4fe9598f5'
stage_inventory = json.loads(stage['stage-inventory.json'])
assert set(stage_inventory) == set(stage) - {'stage-inventory.json'}
assert all(sha(stage[n]) == v for n, v in stage_inventory.items())
for folder in ['preparation', 'execution']:
    control = json.loads(stage[folder + '/CONTROLS_SHA256.json'])
    for name, digest in control.items():
        assert sha(stage[folder + '/' + name]) == digest
        assert stage[folder + '/' + name] == files['result/' + folder + '/' + name]
assert sha(stage['preparation/CONTROLS_SHA256.json']) == receipt['preparation_manifest_sha256'] == '6f2b3be0643803669a3379ea5ff173dcd960046c020c1da71c8da1635a2e0e52'
source_raw = stage['inputs/climatology-final-candidate-nm-source.tar.gz']
assert sha(source_raw) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
source = unpack(source_raw)
assert sha(source['SOURCE_SHA256.json']) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
source_manifest = json.loads(source['SOURCE_SHA256.json'])
assert len(source_manifest) == 584 and all(sha(source[n]) == v for n, v in source_manifest.items())
test_names = []
for name, data in stage.items():
    if name.startswith('preparation/test_') and name.endswith('.py'):
        test_names.extend(n.name for n in ast.walk(ast.parse(data)) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_'))
log = files['result/unittest.stderr.txt'].decode()
actual = re.findall(r'^(test_\w+) \(.*\) \.\.\. ok$', log, re.M)
assert len(actual) == len(test_names) == receipt['actual_test_count'] == 28
assert set(actual) == set(test_names) == {n.split(':')[1] for n in receipt['test_names']}
assert re.search(r'Ran 28 tests in 25\.883s\s+OK\s*$', log)
diagnostic_raw = files['result/quantified-synthetic-diagnostics.json']
assert sha(diagnostic_raw) == receipt['quantified_diagnostics_sha256']
diagnostic = json.loads(diagnostic_raw)
assert diagnostic['test_only'] is True and diagnostic['physical_candidate_evidence'] is False
assert diagnostic['production_scoring_enabled'] is False
assert len(diagnostic['original_ON_twelve_cell_comparison']) == 12
assert diagnostic['maximum_decimal_oracle_absolute_difference'] == 0
assert diagnostic['maximum_ON_population_identity_absolute_difference'] == 2.220446049250313e-16
assert diagnostic['objective_absolute_difference'] == 0
assert list(diagnostic['family_weights'].values()) == [0.25] * 4
assert list(diagnostic['family_cell_counts'].values()) == [12] * 4
result = unpack(files['result.tar.gz'])
assert all(files['result/' + n] == b for n, b in result.items())
presence = json.loads(files['manager/pbs-output-presence.json'])
assert presence['present'] is False and 'manager/pbs-output.log' not in files
review = dict(passed=True, blocking_findings=[], archive_sha256=p['sha256'], artifacts=86,
              actual_job='1599.manager', actual_state='F', actual_exit=0, actual_tests=28,
              test_seconds=receipt['actual_test_seconds'], worker_seconds=receipt['seconds'],
              decimal_oracle_max_difference=0.0, ON_population_identity_max_difference=2.220446049250313e-16,
              production_scoring_enabled=False, physical_candidate_scores=0,
              source_files_verified=584, original_control_bytes_unchanged=True,
              scope='Independent root stdlib bytes/AST/raw-log review. Numerical tests ran only on EHPC. No model score, calibration or scientific acceptance.')
target = ROOT / 'fluxnet-calibration-score-oo-closed-root-review.json'
assert not target.exists()
target.write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review))

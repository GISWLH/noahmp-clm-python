from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-cuda-3803-a';start=time.monotonic()
with (r/'capture-model.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-u',str(b/'capture_qia_cuda_3803_a.py')],stdout=log,stderr=subprocess.STDOUT)
    (r/'capture-worker.json').write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait()
receipt=r/'surface-capture-a/receipt.json'
d=dict(returncode=code,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None)
(r/'capture-exit.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
sys.exit(code)

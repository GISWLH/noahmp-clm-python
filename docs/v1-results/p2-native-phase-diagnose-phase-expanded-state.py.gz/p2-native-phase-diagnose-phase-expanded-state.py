import inspect,numpy as np,jax,jax.numpy as j,cupy as cp
from pathlib import Path
from test_gpu_canopy_phase_energy import batch,host
import noahmp_clm.gpu.canopy_phase_energy as phase
from noahmp_clm.gpu.cuda.canopy_phase_energy import run_canopy_phase_cuda
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as rk
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.snicar import _jax_tables
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
from check_canopy_phase_gpu import packed,cases,random_cases,same_precision
raw=[*cases(),*random_cases(60)];arrays=packed([phase.pack_canopy_phase(a,sw,lw,e,c,1800.,dtype=np.float32,**kw) for _,a,sw,lw,e,c,kw in raw],np.float32);got=host(phase.run_canopy_phase_jax(*arrays));cuda_final=host(run_canopy_phase_cuda(*arrays),cp.asnumpy)
for i,row in enumerate(raw):
 one=lambda data:{k:({key:value[i] for key,value in v.items()} if isinstance(v,dict) else v[i]) for k,v in data.items()}
 result=same_precision(one(got),one(cuda_final))
 if result['failures']:print('final failure',i,row[0],result,flush=True)
z=np.column_stack((got['phase_coordinates'],got['ground_temperature'],got['canopy_humidity']*1000.)).astype(np.float32)
source=inspect.getsource(phase.phase_energy_kernel_jax).replace('ice,impurity,*,','ice,impurity,z,*,').replace('    old=j.concatenate','    return evaluate(z)[1]\n    old=j.concatenate')
ns=vars(phase).copy();exec(source,ns);kernel=jax.jit(jax.vmap(ns['phase_energy_kernel_jax'],in_axes=(*([0]*9),None,None,None,0)))
a=tuple(map(j.asarray,arrays));jp=j.asarray(pack_leaf_parameters(dtype=np.float32));ja=np.asarray(kernel(*a,jp,*_jax_tables('float32'),j.asarray(z)))
base=Path(phase.__file__).parent/'cuda';cu_source='\n'.join((base/p).read_text() for p in ('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu'))
cu_source+='''
extern "C" __global__ void diagnose_phase(const float* leaf,const float* u,const float* f,const float* soil,const float* stem,const float* c,const float* b,const float* radiation,const float* p,const float* z,float* out,int n) {
int row=threadIdx.x+blockIdx.x*blockDim.x;if(row>=n)return;PhaseContext v;phase_prepare(leaf+row*10,u+row*23,f+row*20,soil+row*10,stem+row*10,c+row*20,b+row*9,p,radiation+row*584,v);float r[12];phase_evaluate(v,z+row*12,r,out+row*298);
}
'''
k=cp.RawKernel(cu_source,'diagnose_phase',options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'))
a,u,f,soil,stem,c,b,snow,n=[cp.asarray(x) for x in arrays];area=cp.ascontiguousarray(a+stem);ru=cp.ascontiguousarray(radiation_inputs(area,u,cp));rad=cp.empty((len(a),584),cp.float32);rk(True)((1,),(32,),(area,snow,n,ru,*_tables(),rad,np.int32(len(a))))
out=cp.empty((len(a),298),cp.float32);k(((len(a)+31)//32,),(32,),(a,u,f,soil,stem,c,b,rad,cp.asarray(pack_leaf_parameters(dtype=np.float32)),cp.asarray(z),out,np.int32(len(a))))
cu=cp.asnumpy(out)
np.savez('phase-identical-state.npz',jax=ja,cuda=cu,coordinate=z)
for i in range(len(a)):
 idx=np.where(ja[i]!=cu[i])[0]
 print('row',i,'count',len(idx),'first',[(int(k),float(ja[i,k]),float(cu[i,k])) for k in idx[:25]],flush=True)

"""Independent high precision audit of existing option2/3, not a model patch."""
from pathlib import Path
from decimal import Decimal,localcontext
import hashlib,json,os,sys,tarfile
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'soil-stress-reference-fg';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'clm-phase-descent-ec-source.tar.gz';assert sha(a)=='8ba22f3408c3ac4f3fd11dee248528a3d39fbae06402bf2305a8f4b22318a27e'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==v for n,v in m.items())
official=b/'official_soil_transpiration_17751dc.F90';table=b/'official_noahmp_table_17751dc.TBL';assert sha(official)=='d1b389b7ace326d1b5f2eb0da74bd84dc334f9b14774973baafbf52338aa596d' and sha(table)=='43abb5d6e27a39c768555e617dc43f1c331500fc8a0a044f5a5790026a36f143';assert 'PSIWLT              = -150.0' in table.read_text()
sys.path[:0]=[str(b/'test-deps'),str(s/'src')]
from noahmp_clm.column import ColumnState,default_soil_params
from noahmp_clm.physics.stress import soil_water_stress

def reference(theta,soil,option):
    with localcontext() as ctx:
        ctx.prec=80;d=lambda x:Decimal(str(x));one=Decimal(1);wilt=d(-150);head=d(soil.saturated_suction_m);relative=max(d('.01'),d(theta))/d(soil.smcmax);psi=max(wilt,-head*(-d(soil.bexp)*relative.ln()).exp())
        if option==2:beta=(one-psi/wilt)/(one+head/wilt)
        else:beta=one-(-d('5.8')*(wilt/psi).ln()).exp()
        return float(min(one,max(Decimal(0),beta))),float(psi)

rows=[]
for texture in ('sand','loam','clay'):
    p=default_soil_params(texture)
    # All predefined dry-to-saturated fractions, named bounds and exactQia theta.
    points=sorted(set([p.smcmax*k/20. for k in range(21)]+[.009,.01,.011,p.smcwlt,p.smcref,.137]))
    for theta in points:
        state=ColumnState(soil=p,smc=np.full(4,theta),root_frac=np.array([.4,.3,.2,.1]))
        for option in (1,2,3):
            actual=soil_water_stress(state,option,layer=0)
            if option==1:ref=float(np.clip((theta-p.smcwlt)/(p.smcref-p.smcwlt),0.,1.));psi=None
            else:ref,psi=reference(theta,p,option)
            delta=actual-ref;near=ref<=.01;passed=abs(delta)<=.001 if near else abs(delta/ref)<=.1
            rows.append(dict(texture=texture,theta_m3m3=theta,option=option,soil_saturated_suction_m=p.saturated_suction_m,official_wilting_potential_m=-150.,reference_beta=ref,reference_soil_potential_m=psi,current_beta=actual,absolute_difference=delta,relative_difference_percent=None if near else 100.*delta/ref,nearzero_reference=near,comparison_rule='absolute0.001 if beta<=0.01; otherwise relative10percent',within_diagnostic_rule=bool(passed)))
summary={}
for option in (1,2,3):
    selected=[q for q in rows if q['option']==option]
    summary[str(option)]=dict(cases=len(selected),outside_rule=sum(not q['within_diagnostic_rule'] for q in selected),maximum_absolute_difference=max(abs(q['absolute_difference']) for q in selected),maximum_relative_difference_percent=max(abs(q['relative_difference_percent']) for q in selected if q['relative_difference_percent'] is not None))
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),official_commit='17751dcd7a2442a3c57138f530f523daf08dc1c5',official_equation_file_sha256=sha(official),official_parameter_table_sha256=sha(table),reference='Independently written Decimal80 evaluation of published pinnedNoah-MP option2/3 soilpotential/wetness equations in metres; fixedPSIWLT=-150m fromitsparameter table. No upstream code copiedinto model, no output-fitting, and no rootweight/minimum-normalization equivalence claimed.',summary=summary,all_cases=rows,scope='Componentfactor diagnostic only. ExistingfrozenEC model unmodified. ColdQia campaigns use option1 so option2/3 mismatch is not assumedto explainobservedLE bias orinvalidate unchangedoption1 behavior. Analysisexit0 means resultdelivered, not existingphysics passed or fullCLM5 planthydraulics implemented.')
(r/'audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');assert result['source_unchanged'];print(json.dumps(dict(pbs_job=result['pbs_job'],summary=summary,qia=[q for q in rows if q['texture']=='loam' and q['theta_m3m3']==.137])),flush=True)

"""Precompute quantized-input NumPy references on PBS, before device tests."""
from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'soil-stress-gpu-reference-fj';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-soil-stress-numpy-fh-source.tar.gz';assert sha(a)=='768cc368b05ec64e8606f673a593f48922fb635c1595e2ac502837d5e4b82e04'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert manifest=='f67608b2908ef57edf519b353ee4beaa1dd23a2641e3e24c58bdfde8374333e8' and len(m)==574 and all(sha(s/n)==v for n,v in m.items());prior=b/'soil-stress-numpy-fh';proof=json.loads((prior/'reference.json').read_text());assert (prior/'pbs-exit.txt').read_text().strip()=='0' and proof['source_unchanged'] and proof['unit']['returncode']==0 and proof['unit']['counts']==dict(tests=26,failures=0,errors=0,skipped=0) and proof['source_manifest_sha256']==manifest and all(q['outside_rule']==0 for q in proof['summary'].values())
sys.path[:0]=[str(b/'test-deps'),str(s/'src')]
from noahmp_clm.column import ColumnState,SoilParams,default_soil_params
from noahmp_clm.physics.clm_water_stress import soil_water_stress
fixture=json.loads((s/'tests/fixtures/soil_water_stress_reference.json').read_text());cases=[]
for q in fixture['cases']:cases.append((q['texture'],[q['theta_m3m3']]*4,[.5,.25,.125,.125],q['option']))
for texture in ('sand','loam','clay'):
    p=default_soil_params(texture)
    for option in (1,2,3):
        for roots in ([.5,.25,.125,.125],[1.,0.,0.,0.],[0.,0.,0.,0.],[.125,.125,.25,.5]):cases.append((texture,[0.,p.smcwlt,p.smcref,p.smcmax],roots,option))
assert len(cases)==270;out=dict(options=np.array([q[3] for q in cases],np.int32))
for dtype,suffix in [(np.float32,'32'),(np.float64,'64')]:
    liquid=np.array([q[1] for q in cases],dtype);roots=np.array([q[2] for q in cases],dtype);parameters=[]
    for texture,*_ in cases:
        p=default_soil_params(texture);parameters.append([p.smcmax,p.bexp,p.smcref,p.satdk,p.quartz,p.smcwlt,p.saturated_suction_m])
    parameters=np.array(parameters,dtype);answers=[]
    for theta,root,p,option in zip(liquid,roots,parameters,out['options']):
        p=list(map(float,p));soil=SoilParams(smcmax=p[0],bexp=p[1],smcref=p[2],satdk=p[3],quartz=p[4],smcwlt=p[5],saturated_suction_m=p[6]);state=ColumnState(soil=soil,smc=theta.astype(float),root_frac=root.astype(float));answers.append([soil_water_stress(state,int(option)),*[soil_water_stress(state,int(option),k) for k in range(4)]])
    out.update({k+suffix:v for k,v in [('liquid',liquid),('roots',roots),('parameters',parameters),('reference',np.asarray(answers))]})
target=r/'clm_water_stress_gpu_reference.npz';np.savez_compressed(target,**out);result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,cases=270,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),numpy_proof_sha256=sha(prior/'reference.json'),reference_sha256=sha(target),scope='NumPy-first component expectedroot/layer factors for both float64 and separatelyfloat32-quantized originalinputs, 234pinned-grid cases plus36predefinedheterogeneous/rootzero cases. Referenceonly onPBScompute, no GPUexecution or coupled-driver integration credit.');(r/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert result['source_unchanged']

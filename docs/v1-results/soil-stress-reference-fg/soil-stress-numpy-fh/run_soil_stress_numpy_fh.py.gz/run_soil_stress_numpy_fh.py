"""NumPy-first unit/reference validation, no driver/GPU integration credit."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'soil-stress-numpy-fh';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());a=b/'clm-soil-stress-numpy-fh-source.tar.gz';assert sha(a)==meta['archive_sha256']=='768cc368b05ec64e8606f673a593f48922fb635c1595e2ac502837d5e4b82e04'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==574 and manifest==meta['manifest_sha256']=='f67608b2908ef57edf519b353ee4beaa1dd23a2641e3e24c58bdfde8374333e8' and all(sha(s/n)==h for n,h in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
selected=['tests/test_clm_water_stress.py','tests/test_stress.py'];collect=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q',*selected],cwd=s,env=env,capture_output=True,text=True);(r/'collection.txt').write_text(collect.stdout+collect.stderr);assert collect.returncode==0;nodes=[v for v in collect.stdout.splitlines() if v.startswith('tests/') and '::' in v];assert len(nodes)==len(set(nodes))==26;xml=r/'targeted.xml';start=time.monotonic()
with (r/'targeted.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*selected,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
counts={k:sum(int(q.attrib[k]) for q in ET.parse(xml).getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};unit=dict(returncode=code,counts=counts,xml_sha256=sha(xml),seconds=time.monotonic()-start);(r/'unit-receipt.json').write_text(json.dumps(unit,indent=2)+'\n');assert code==0 and counts==dict(tests=26,failures=0,errors=0,skipped=0)
sys.path[:0]=[str(b/'test-deps'),str(s/'src')]
from noahmp_clm.column import ColumnState,default_soil_params
from noahmp_clm.physics.clm_water_stress import soil_water_stress
fixture=s/'tests/fixtures/soil_water_stress_reference.json';f=json.loads(fixture.read_text());assert f['audit_sha256']=='2724ccfb043fd80f4f71ec85c2f65fbe10e579b28d23767e30f3de562fe43009'
rows=[]
for q in f['cases']:
    state=ColumnState(soil=default_soil_params(q['texture']),smc=np.full(4,q['theta_m3m3']),root_frac=np.array([.4,.3,.2,.1]));actual=soil_water_stress(state,q['option'],0);ref=q['reference_beta'];difference=actual-ref;near=ref<=.01;rule=abs(difference)<=.001 if near else abs(difference/ref)<=.1
    rows.append(dict(q,actual_beta=actual,absolute_difference=difference,relative_difference_percent=None if near else 100.*difference/ref,passed=bool(rule)))
summary={str(option):dict(cases=sum(q['option']==option for q in rows),outside_rule=sum(q['option']==option and not q['passed'] for q in rows),maximum_absolute_difference=max(abs(q['absolute_difference']) for q in rows if q['option']==option),maximum_relative_difference_percent=max(abs(q['relative_difference_percent']) for q in rows if q['option']==option and q['relative_difference_percent'] is not None)) for option in (1,2,3)}
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),fixture_sha256=sha(fixture),unit=unit,summary=summary,all_cases=rows,scope=meta['scope']);(r/'reference.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:result[k] for k in ['pbs_job','node','unit','summary','source_unchanged']}),flush=True);assert result['source_unchanged'] and all(q['passed'] for q in rows)

"""Resume F's own frozen first-day state; CPU day scoring is independently pending."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-heat-coordinate-e';root=base/'fluxnet-first-climate-cycle-20261017-f'
os.chdir(source);sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_native import source_hashes
hashes=source_hashes();r=json.loads((root/'cuda-year/batch.json').read_text())
assert r['status']=='running' and r['steps_completed']==48 and r['identity']['source_sha256']==hashes
for key,field in [('checkpoint_file','checkpoint_sha256')]:
    assert hashlib.sha256((root/'cuda-year'/r[key]).read_bytes()).hexdigest()==r[field]
assert hashlib.sha256((base/'first-climate-day-f-native-evidence.tar.gz').read_bytes()).hexdigest()=='eb750c88265fcd7eb92cef702ed91fe8da3d05121b17b51034264a53ce7d14ac'
assert not (root/'annual-launch.json').exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:tests:benchmarks',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',
    CUDA_VISIBLE_DEVICES='0',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',
    JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),CUDA_PATH='/usr/local/cuda-12.4',
    PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
command=[sys.executable,'-u','benchmarks/run_fluxnet_native.py','--batch',str(root/'batch.json'),
    '--output',str(root/'cuda-year'),'--resume']
with (root/'cuda-annual-resume.log').open('wb') as log:
    p=subprocess.Popen(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt=dict(pid=p.pid,command=command,source_directory=str(source),runtime_source_identity_exact=True,
    started_unix=time.time(),first_day_backend_validation='Pending independent EHPC PBS25. Annual numerical execution proceeds separately; no observational or science pass asserted.',
    original_first_day_archive_sha256='eb750c88265fcd7eb92cef702ed91fe8da3d05121b17b51034264a53ce7d14ac')
(root/'annual-launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in manifest.items())
files=['tests/test_gpu_canopy_surface.py','tests/test_gpu_canopy_phase_surface.py','tests/test_gpu_clm_enthalpy_column.py','tests/test_gpu_clm_layered_column.py','tests/test_gpu_clm_bgc_column.py','tests/test_gpu_clm_phenology_column.py','tests/test_gpu_clm_irrigation_column.py','tests/test_gpu_clm_crop_column.py','tests/test_gpu_clm_tile_column.py','tests/test_gpu_clm_wetland_column.py','tests/test_gpu_clm_most_column.py']
results=[];out=root/'integration-by-file';out.mkdir(exist_ok=False)
for i,name in enumerate(files):
    stem=Path(name).stem;begun=time.monotonic()
    with (out/(stem+'.log')).open('w') as log:
        code=subprocess.run([sys.executable,'-m','pytest','-q','-s',name,'--junitxml='+str(out/(stem+'.xml'))],stdout=log,stderr=subprocess.STDOUT).returncode
    counts={k:sum(int(s.attrib[k]) for s in ET.parse(out/(stem+'.xml')).getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
    row=dict(file=name,returncode=code,seconds=time.monotonic()-begun,counts=counts)
    results.append(row);print(json.dumps(row),flush=True)
    assert all(sha(root/n)==v for n,v in manifest.items())
    (root/'integration-progress.json').write_text(json.dumps(dict(source_unchanged=True,source_files=len(manifest),completed=results,remaining=files[i+1:]),indent=2)+'\n')
    # Preserve each numerical failure and still exercise independent modules.
passed=all(r['returncode']==0 and all(r['counts'][k]==0 for k in ['failures','errors','skipped']) for r in results)
(root/'integration-complete.json').write_text(json.dumps(dict(passed=passed,source_unchanged=True,node=os.uname().nodename,files=results),indent=2)+'\n')
sys.exit(0 if passed else 1)

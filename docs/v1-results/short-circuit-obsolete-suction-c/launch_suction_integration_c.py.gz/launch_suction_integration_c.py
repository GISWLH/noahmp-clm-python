from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
root=Path('/home/lhwang/work/noahmp-v1/p6-suction-coupled-c')
assert not (root/'integration-launch.json').exists()
with (root/'integration-launch.log').open('w') as stream:
    p=subprocess.Popen(['bash',str(root/'suction_integration_gpu_c.sh')],cwd=root,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
receipt=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,source_archive_sha256='f59327322195158fb66e55580d07e5e25b309192d0a6e2fbfee458249dc4b2fd')
(root/'integration-launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

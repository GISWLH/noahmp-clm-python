from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,time,urllib.parse,urllib.request
base=Path('/home/lhwang/work/noahmp-v1');root=base/'ctsm-external-archives-a';root.mkdir(exist_ok=False);begun=time.monotonic();rows=[]
def request(url):return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Wang-CLM-independent-reference'}),timeout=20)
for name,repo,tag in [('cime','ESMCI/cime','cime5.6.47'),('fates','NGEET/fates','sci.1.30.0_api.8.0.0')]:
    row=dict(component=name,repository='https://github.com/'+repo,requested_tag=tag)
    try:
        url='https://api.github.com/repos/'+repo+'/commits/'+urllib.parse.quote(tag,safe='')
        with request(url) as response:metadata=json.load(response)
        pin=metadata['sha'];row['commit_sha']=pin
        (root/(name+'-commit.json')).write_text(json.dumps(dict(sha=pin,commit_date=metadata['commit']['committer']['date']),indent=2)+'\n')
        url='https://api.github.com/repos/'+repo+'/tarball/'+pin;dest=root/(name+'.tar.gz');part=root/(name+'.tar.gz.partial')
        with request(url) as response,part.open('wb') as output:
            final=response.url
            while True:
                data=response.read(1024*1024)
                if not data:break
                output.write(data)
        part.rename(dest);configs={}
        with tarfile.open(dest) as archive:
            members=archive.getmembers()
            for member in members:
                path=PurePosixPath(member.name)
                if member.isfile() and path.name.startswith('Externals') and path.suffix=='.cfg':configs[member.name]=archive.extractfile(member).read().decode()
        (root/(name+'-externals.json')).write_text(json.dumps(configs,indent=2)+'\n')
        row.update(status='complete',url=url,final_url=final,archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),archive_bytes=dest.stat().st_size,members=len(members),external_configurations=configs)
    except Exception as e:row.update(status='failed',error=type(e).__name__,detail=str(e)[:300])
    rows.append(row);(root/'progress.json').write_text(json.dumps(dict(results=rows),indent=2)+'\n')
value=dict(scope='Pinned official CIME/FATES source dependencies for an independent CTSM reference; no copied Python physics or component build/run. CISM/RTM/MOSART are not selected for the intended stub glacier/runoff single-column reference.',status='complete' if all(v['status']=='complete' for v in rows) else 'failed',results=rows,seconds=time.monotonic()-begun)
(root/'download_ctsm_external_archives_a.py').write_bytes(Path(__file__).read_bytes());(root/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

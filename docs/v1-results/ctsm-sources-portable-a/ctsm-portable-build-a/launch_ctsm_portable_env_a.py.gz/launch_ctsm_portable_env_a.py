from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');plan=base/'ctsm-dependency-plan-a';root=base/'ctsm-portable-build-a';prefix=base/'ctsm-portable-env-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);assert not prefix.exists();(root/'launch_ctsm_portable_env_a.py').write_bytes(Path(__file__).read_bytes())
    command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'launch_ctsm_portable_env_a.py'),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    r=dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Prepare isolated portable compiler/NetCDF environment from exact solved public package URLs; CPU reference build/run remains on EHPC.')
    (root/'launch.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(0)
solution=json.loads((plan/'solve.json').read_text());receipt=json.loads((plan/'exit.json').read_text());assert solution['success'] and solution['dry_run'] and receipt['returncode']==0 and not receipt['environment_created']
fetch=solution['actions']['FETCH'];link=solution['actions']['LINK'];assert len(fetch)==len(link)==87
assert {(v['name'],v['version'],v['build']) for v in fetch}=={(v['name'],v['version'],v['build_string']) for v in link}
for v in fetch:assert v['url'].startswith('https://conda.anaconda.org/conda-forge/') and '?' not in v['url'] and len(v['sha256'])==64 and len(v['md5'])==32
lock=root/'explicit-lock.txt';lock.write_text('@EXPLICIT\n'+'\n'.join(v['url']+'#'+v['md5'] for v in fetch)+'\n')
(root/'package-lock.json').write_text(json.dumps(dict(solve_sha256=sha(plan/'solve.json'),target_glibc='2.17',packages=fetch),indent=2)+'\n')
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(CONDA_PKGS_DIRS=str(plan/'package-cache'),CONDA_OVERRIDE_GLIBC='2.17',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
stages=[];begun=time.monotonic()
def run(stage,command):
    start=time.monotonic()
    with (root/(stage+'.stdout.txt')).open('w') as out,(root/(stage+'.stderr.txt')).open('w') as err:p=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=err)
    (root/'progress.json').write_text(json.dumps(dict(status='running',stage=stage,pid=p.pid,command=command),indent=2)+'\n');code=p.wait()
    stages.append(dict(stage=stage,command=command,returncode=code,seconds=time.monotonic()-start))
    (root/'stages.json').write_text(json.dumps(stages,indent=2)+'\n')
    if code:
        (root/'exit.json').write_text(json.dumps(dict(status='failed',stages=stages,seconds=time.monotonic()-begun),indent=2)+'\n');raise SystemExit(code)
run('install',['/home/lhwang/anaconda3/bin/conda','create','--yes','--no-default-packages','--json','--override-channels','--channel','https://conda.anaconda.org/conda-forge','--prefix',str(prefix),'--file',str(lock)])
actual={}
for p in (prefix/'conda-meta').glob('*.json'):
    v=json.loads(p.read_text());actual[(v['name'],v['version'],v['build'])]=v
assert set(actual)=={(v['name'],v['version'],v['build']) for v in fetch}
for v in fetch:
    path=plan/'package-cache'/v['fn'];assert path.is_file() and sha(path)==v['sha256']
dest=base/'ctsm-portable-env-a.tar.gz';assert not dest.exists()
run('pack',[str(prefix/'bin/conda-pack'),'--prefix',str(prefix),'--output',str(dest),'--format','tar.gz','--compress-level','4'])
value=dict(status='complete',scope='Portable environment prepared from87 exact conda-forge packages with downloaded SHA256 verified; not yet validated on EHPC, not an official CTSM build/model output or scientific acceptance.',stages=stages,seconds=time.monotonic()-begun,archive=str(dest),archive_bytes=dest.stat().st_size,archive_sha256=sha(dest),package_lock_sha256=sha(root/'package-lock.json'),source_solver_sha256=sha(plan/'solve.json'))
(root/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

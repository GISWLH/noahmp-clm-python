from pathlib import Path
import hashlib,json,tarfile,time,urllib.request
base=Path('/home/lhwang/work/noahmp-v1');old=base/'ctsm-source-stage-a';root=base/'ctsm-source-archive-b';root.mkdir(exist_ok=False)
failed=json.loads((old/'exit.json').read_text());assert failed['status']=='failed' and failed['stages'][-1]['returncode']!=0
(root/'prior-git-exit.json').write_bytes((old/'exit.json').read_bytes());(root/'prior-fetch.log').write_bytes((old/'2-git.log').read_bytes())
pin='fdfc03a0abec838ec0b66663a6a2f5e619cd2611';url='https://api.github.com/repos/ESCOMP/CTSM/tarball/'+pin;begun=time.monotonic();partial=root/'CTSM.tar.gz.partial'
try:
    req=urllib.request.Request(url,headers={'User-Agent':'Wang-CLM-independent-reference'})
    with urllib.request.urlopen(req,timeout=20) as response,partial.open('wb') as output:
        final_url=response.url;code=response.status
        while True:
            data=response.read(1024*1024)
            if not data:break
            output.write(data)
    dest=root/'CTSM.tar.gz';partial.rename(dest)
    with tarfile.open(dest) as archive:members=archive.getmembers()
    value=dict(status='complete',scope='Unmodified pinned official CTSM source tarball only; no dependency checkout/model build/output or science acceptance.',pinned_commit=pin,url=url,final_url=final_url,http_status=code,seconds=time.monotonic()-begun,archive_bytes=dest.stat().st_size,archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),members=len(members),fortran_members=sum(v.name.lower().endswith('.f90') for v in members))
except Exception as e:
    value=dict(status='failed',pinned_commit=pin,url=url,error=type(e).__name__,detail=str(e)[:300],seconds=time.monotonic()-begun,partial_bytes=partial.stat().st_size if partial.exists() else 0)
(root/'download_ctsm_source_archive_b.py').write_bytes(Path(__file__).read_bytes());(root/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

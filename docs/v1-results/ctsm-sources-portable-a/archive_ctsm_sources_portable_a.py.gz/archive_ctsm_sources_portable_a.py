from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();build=base/'ctsm-portable-build-a';source=base/'ctsm-source-archive-b';external=base/'ctsm-external-archives-a'
b=json.loads((build/'exit.json').read_text());s=json.loads((source/'receipt.json').read_text());e=json.loads((external/'receipt.json').read_text())
assert b['status']==s['status']==e['status']=='complete' and sha(Path(b['archive']))==b['archive_sha256']
assert sha(source/'CTSM.tar.gz')==s['archive_sha256']
for row in e['results']:assert sha(external/(row['component']+'.tar.gz'))==row['archive_sha256']
pairs=[]
for folder,names in [(build,['launch_ctsm_portable_env_a.py','launch.json','explicit-lock.txt','package-lock.json','install.stdout.txt','install.stderr.txt','pack.stdout.txt','pack.stderr.txt','stages.json','exit.json','controller.log']),
    (source,['download_ctsm_source_archive_b.py','receipt.json','external-configurations.json','prior-git-exit.json','prior-fetch.log']),
    (external,['download_ctsm_external_archives_a.py','receipt.json','cime-commit.json','cime-externals.json','fates-commit.json','fates-externals.json'])]:
    for n in names:pairs.append((folder/n,folder.name+'/'+n))
pairs.append((Path(__file__),'archive_ctsm_sources_portable_a.py'))
dest=base/'ctsm-sources-portable-a-evidence.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz') as t:
    for path,name in pairs:t.add(path,arcname=name,recursive=False)
print(json.dumps(dict(files=len(pairs),sha256=sha(dest),scope='Actual87-package install/pack and pinned upstream CTSM/CIME/FATES archive metadata; original terminal git-fetch failure retained. Upstream source/toolchain binaries excluded from public archive. Other source submodules, official reference build/run and scientific comparison still pending.')))

"""Independent float64 physical reference for the saved Cng surface trial."""
from dataclasses import asdict
from pathlib import Path
import json,time
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.vic import VICParameters

root=Path('/home/zhangyq/noahmp-v1/first-cycle-262-surface-reference-a')
with np.load(root/'failed-surface-inputs.npz',allow_pickle=False) as z:arrays={k:z[k] for k in z}
row=0;c,g,p,o,a,u,f,v,condensate=[arrays[f'a{k}'][row].astype(float) for k in range(9)];n=int(o[0])
pack=Snowpack(c[:n,0],c[:n,1],c[:n,2],c[:n,3],c[:n,4:])
soil=SoilEnthalpyState(g[:,0],g[:,1],g[:,2],SoilParams(smcmax=p[0],bexp=p[1],smcref=p[2],satdk=p[3],quartz=p[4],smcwlt=p[5]),int(o[1]))
config=json.loads(Path('/home/zhangyq/noahmp-v1/fluxnet-first-climate-cycle-20261017-b/inputs/CN-Cng-config.json').read_text())
extension=arrays['exchange_extension'][row].astype(float)
exchange=CanopyExchange(*u[:11],atmosphere_water_velocity=extension[0],potential_temperature=extension[1])
vic=arrays['vic'][row].astype(float)
assert vic[0]==1
infiltration=VICParameters(*vic[2:])
started=time.monotonic()
snow,ground,water,d=surface_step(pack,soil,v[0],a,u[11],u[12],exchange,
    canopy_condensate=CanopyCondensate(condensate[:,0],condensate[:,1]),root_weights=v[3:],
    vegetated_fraction=u[13],transpiration_limit=u[16],ground_emissivity=u[18],ground_albedo=u[19:21],
    diffuse_fraction=u[21],cosine_zenith=u[22],nitrogen_factor=f[:,0],water_stress=f[:,1],
    leaf_parameters=LeafParameters(**config['leaf_parameters']),infiltration_parameters=infiltration)
fields={k:d[k] for k in ['h','le','et_kgm2','surface_temperature','water_residual_kgm2','energy_residual_jm2',
    'surface_evaluations','outgoing_shortwave','outgoing_longwave','runoff_kgm2','runoff_enthalpy_jm2',
    'advected_enthalpy_jm2','layer_residual']}
fields.update(snow_mass=snow.mass,snow_enthalpy=snow.enthalpy,soil_water=ground.water,soil_enthalpy=ground.enthalpy,
    soil_temperature=ground.temperature,thermal=d['thermal'],seconds=time.monotonic()-started)
def encode(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
(root/'numpy-reference.json').write_text(json.dumps(fields,indent=2,default=encode,allow_nan=False)+'\n')
print(json.dumps(fields,default=encode),flush=True)

"""One exact failed old state, original 50-iteration limits, on EHPC."""
from dataclasses import asdict,is_dataclass
from datetime import datetime
from pathlib import Path
import argparse,hashlib,json,pickle,time,traceback
import numpy as np
from noahmp_clm.column import Forcing
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.photosynthesis import LeafParameters
import noahmp_clm.physics.canopy_most as most
from run_fluxnet_column import calendar,audit_step,source_hashes

p=argparse.ArgumentParser();p.add_argument('--label',required=True);a=p.parse_args()
root=Path('/home/zhangyq/noahmp-v1/ham-most-6121-replay-a')
report=json.loads((root/'failed-run/report.json').read_text());config=report['configuration']
current_hashes=source_hashes();old_hashes=report['source_sha256']
if a.label=='original':assert current_hashes==old_hashes
state,initial,net,bounds,maximum,stepmax,index=pickle.loads((root/'failed-run'/report['checkpoint_file']).read_bytes())
assert index==6121
with np.load(root/'inputs/fluxnet-ham-2002-prepared.npz',allow_pickle=False) as archive:data=dict(archive)
metadata=json.loads((root/'inputs/fluxnet-ham-2002-prepared.json').read_text())
f=Forcing(*data['forcing'][index]);co2,mu,diffuse=map(float,data['environment'][index])
stamp=datetime.strptime(str(data['time_start'][index]),'%Y%m%d%H%M')
environment=calendar(stamp,metadata,config['phenology'] is not None)
geometry=most.MOSTGeometry(**config['most_geometry'])
calls=[];surfaces=[];exchange_calls=[]
original_flux=most.flux_stability;original_exchange=most.canopy_exchange;original_solve=most.solve_surface_most
def flux(*args,**kwargs):
    result=original_flux(*args,**kwargs)
    row=dict(iteration=len(calls)+1,h=args[4],water=args[5],ustar=args[6],**result)
    calls.append(row);print(json.dumps(row),flush=True)
    return result
def exchange(*args,**kwargs):
    result=original_exchange(*args,**kwargs)
    exchange_calls.append(dict(zeta=args[0],effective_wind=args[1],**result))
    return result
def solve(solve_surface,*args,**kwargs):
    def traced(boundary):
        result=solve_surface(boundary);d=result[-1]
        surfaces.append(dict(boundary=asdict(boundary),diagnostics={k:d[k] for k in
            ('h','le','et_kgm2','leaf_temperature','layer_residual') if k in d}))
        return result
    return original_solve(traced,*args,**kwargs)
most.flux_stability=flux;most.canopy_exchange=exchange;most.solve_surface_most=solve
out=dict(scope='Single saved old-state replay. Original forcing, geometry, limits and conservation audit; no annual/observation pass implied.',
    label=a.label,index=index,time_start=str(data['time_start'][index]),forcing=asdict(f),configuration=config,
    source_sha256=current_hashes,source_differences={k:dict(original=v,current=current_hashes.get(k)) for k,v in old_hashes.items() if current_hashes.get(k)!=v},
    state_sha256=hashlib.sha256((root/'failed-run'/report['checkpoint_file']).read_bytes()).hexdigest(),
    calls=calls,surfaces=surfaces,exchange_calls=exchange_calls)
started=time.monotonic()
try:
    nitrogen=config['nitrogen_deposition_gn_m2_s']*f.dt
    after,d=step_clm_enthalpy_column(state,f,co2_ppm=co2,cosine_zenith=mu,diffuse_fraction=diffuse,
        leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),
        most_geometry=geometry,phenology_environment=environment,
        deposition_rates=np.array(config['aerosol_deposition_kg_m2_s']),nitrogen_deposition_gn_m2=nitrogen)
    incoming,residual,bound=audit_step(state,after,f,d,nitrogen)
    out.update(status='complete',most=d['most'],budget_residual=residual,budget_bound=bound)
except Exception:out.update(status='failed',failure=traceback.format_exc())
out['seconds']=time.monotonic()-started
def encode(value):
    if is_dataclass(value):return asdict(value)
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,np.generic):return value.item()
    raise TypeError(type(value).__name__)
(root/(a.label+'-replay.json')).write_text(json.dumps(out,indent=2,default=encode,allow_nan=False)+'\n')
print(json.dumps(dict(status=out['status'],calls=len(calls),seconds=out['seconds'])),flush=True)

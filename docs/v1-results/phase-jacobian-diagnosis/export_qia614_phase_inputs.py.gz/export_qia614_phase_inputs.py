from pathlib import Path
import numpy as np
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-qia614-phase-diagnostic-b'
with np.load(base/'fluxnet-first-climate-cycle-20261017-g/failure-614-capture-a/failed-surface-inputs.npz') as z:raw=dict(z)
with np.load(root/'original.npz') as z:out=z['output'];leaf_parameters=z['leaf_parameters']
np.savez_compressed(root/'phase-reference-inputs.npz',leaf=raw['a4'][1],u=out[334:357],factors=raw['a6'][1],soil=out[357:367],
    condensate=raw['a8'][1],boundary=out[367:376],snow=raw['a0'][1],snow_count=raw['a3'][1,0],extension=raw['exchange_extension'][1],leaf_parameters=leaf_parameters)
print(root/'phase-reference-inputs.npz')

// Original C3 Farquhar / Ball--Berry implementation. See CLM_PHOTOSYNTHESIS.md.
// One independent leaf per thread; AoS input (n,7), output (n,12).
// NVRTC provides device math builtins without a host math.h include path.

__device__ float arrhenius(float t, float activation) {
    return expf((activation / (float)(8.314462618 * 298.15)) * (1.f - 298.15f / t));
}

__device__ float peaked(float t, float activation, float deactivation, float entropy) {
    float numerator = 1.f + expf((298.15f * entropy - deactivation) / (float)(8.314462618 * 298.15));
    float denominator = 1.f + expf((t * entropy - deactivation) / (8.314462618f * t));
    return arrhenius(t, activation) * numerator / denominator;
}

struct LeafEnvironment {
    float ca, rh, gb, stress, vcmax, product, rd, kc, ko, gamma, transport;
};

__device__ void evaluate(float ci, const LeafEnvironment& e, const float* p, float* v) {
    float carbon = fmaxf(ci-e.gamma, 0.f);
    float ac = e.vcmax*carbon/(ci+e.kc*(1.f+p[9]/e.ko));
    float aj = e.transport*carbon/(4.f*ci+8.f*e.gamma);
    float gross = fminf(fminf(ac, aj), e.product);
    float net = gross-e.rd;
    float cs = fmaxf(e.ca-1.4f*net/e.gb, 1e-9f);
    float x = p[6]*fmaxf(net, 0.f)*e.stress/cs;
    float b = e.gb-p[7]-x;
    float c = e.gb*(p[7]+x*fminf(e.rh, 1.f));
    float root = sqrtf(b*b+4.f*c);
    float gs = b >= 0.f ? 2.f*c/fmaxf(b+root, 1e-30f) : .5f*(root-b);
    v[0]=gross; v[1]=net; v[2]=ac; v[3]=aj; v[4]=cs; v[5]=gs;
    v[6]=net-(e.ca-ci)/(1.4f/e.gb+1.6f/gs);
}

__device__ void leaf_gas_exchange_device(const float* v, const float* p, float* out) {
        float par=v[0], t=v[1], nitrogen=v[5];
        float growth=fminf(fmaxf(p[8]-273.15f, 11.f), 35.f);
        LeafEnvironment e;
        e.ca=v[2]; e.rh=v[3]; e.gb=v[4]; e.stress=v[6];
        float vc_factor=peaked(t, 72000.f, 200000.f, 668.39f-1.07f*growth);
        e.vcmax=p[0]*nitrogen*vc_factor;
        float jmax=p[1]*nitrogen*peaked(t, 50000.f, 200000.f, 659.70f-.75f*growth);
        e.product=3.f*p[2]*nitrogen*vc_factor;
        e.rd=p[3]*peaked(t, 46390.f, 150650.f, 490.f);
        e.kc=404.9f*arrhenius(t, 79430.f);
        e.ko=278400.f*arrhenius(t, 36380.f);
        e.gamma=42.75f*arrhenius(t, 37830.f);
        float light=.5f*p[4]*par;
        float total=light+jmax;
        float den=total+sqrtf(fmaxf(total*total-4.f*p[5]*light*jmax, 0.f));
        e.transport=den>0.f ? 2.f*light*jmax/fmaxf(den, 1e-30f) : 0.f;
        float lo=0.f, hi=e.ca+e.rd*(1.4f/e.gb+1.6f/p[7])+1.f;
        float rates[7];
        for (int iter=0; iter<48; ++iter) {
            float mid=.5f*(lo+hi);
            evaluate(mid, e, p, rates);
            if (rates[6]<0.f) lo=mid;
            else hi=mid;
        }
        float ci=.5f*(lo+hi);
        evaluate(ci, e, p, rates);
        out[0]=rates[0]; out[1]=rates[1]; out[2]=rates[2]; out[3]=rates[3];
        out[4]=e.product; out[5]=e.rd; out[6]=e.transport; out[7]=ci;
        out[8]=rates[4]; out[9]=rates[5];
        out[10]=(e.gb*fminf(e.rh, 1.f)+rates[5])/(e.gb+rates[5]);
        out[11]=rates[6];
}

extern "C" __global__ void run_leaves(const float* u, const float* p, float* output, int n) {
    for (int row=blockIdx.x*blockDim.x+threadIdx.x; row<n; row+=blockDim.x*gridDim.x)
        leaf_gas_exchange_device(u+7*row,p,output+12*row);
}

// Ten-layer two-stream component, independent of the NumPy and JAX code.
// NVRTC device math is built in; no system includes are needed.
__device__ void shortwave_device_albedos(const float* lai, const float* u,
                                         float direct_albedo,bool separate_albedo,float* out,bool track_absorption=false) {
        float beam0=u[0], diffuse0=u[1], ag=u[2], mu=u[3], refl=u[4], tran=u[5];
        float k=.5f/mu, omega=refl+tran, back=.625f*refl+.375f*tran;
        // Explicit .5/k == mu avoids a second, separately rounded reciprocal.
        float beta=(1.f+k)*mu*(1.f-mu*logf(1.f+1.f/mu));
        float a=1.f-omega+back;
        float r[10],t[10],su[10],sd[10],bt[10],beam[11],da[10],ba[10];
        for(int j=0;j<10;++j) {
            float width=lai[j]/1024.f;
            t[j]=1.f/(1.f+a*width);
            r[j]=back*width*t[j];
            float intercepted=-expm1f(-k*width);
            bt[j]=1.f-intercepted;
            su[j]=omega*beta*intercepted;
            sd[j]=omega*(1.f-beta)*intercepted;
            da[j]=(1.f-omega)*width*t[j];ba[j]=(1.f-omega)*intercepted;
            for(int iter=0;iter<10;++iter) {
                float den=1.f-r[j]*r[j];
                float nr=r[j]+t[j]*t[j]*r[j]/den;
                float nt=t[j]*t[j]/den;
                float nu=su[j]+t[j]*(r[j]*sd[j]+su[j]*bt[j])/den;
                float nd=sd[j]*bt[j]+t[j]*(sd[j]+r[j]*su[j]*bt[j])/den;
                float nb=bt[j]*bt[j];
                if(track_absorption) {
                    float nda=da[j]*(1.f+t[j]/(1.f-r[j]));
                    float nba=ba[j]*(1.f+bt[j])+da[j]*(sd[j]+su[j]*bt[j])/(1.f-r[j]);
                    intercepted=intercepted*(2.f-intercepted);
                    nt=(1.f-nr)-nda;nb=1.f-intercepted;nd=(intercepted-nu)-nba;
                    da[j]=nda;ba[j]=nba;
                }
                r[j]=nr;t[j]=nt;su[j]=nu;sd[j]=nd;bt[j]=nb;
                if(omega==1.f) {t[j]=1.f-r[j];sd[j]=1.f-bt[j]-su[j];}
            }
        }
        beam[0]=beam0;
        for(int j=0;j<10;++j) {
            beam[j+1]=beam[j]*bt[j];
            su[j]*=beam[j];sd[j]*=beam[j];
        }
        float re[11],so[11],down[11],up[11],absorbed[10];
        re[10]=ag;so[10]=direct_albedo*beam[10];
        for(int j=9;j>=0;--j) {
            float den=1.f-r[j]*re[j+1];
            re[j]=r[j]+t[j]*t[j]*re[j+1]/den;
            so[j]=su[j]+t[j]*(so[j+1]+re[j+1]*sd[j])/den;
        }
        down[0]=diffuse0;
        for(int j=0;j<10;++j) {
            down[j+1]=(t[j]*down[j]+r[j]*so[j+1]+sd[j])/(1.f-r[j]*re[j+1]);
        }
        for(int j=0;j<11;++j)up[j]=re[j]*down[j]+so[j];
        float total=0.f;
        for(int j=0;j<10;++j) {
            absorbed[j]=beam[j]+down[j]+up[j+1]-beam[j+1]-down[j+1]-up[j];
            if(track_absorption)absorbed[j]=da[j]*(down[j]+up[j+1])+ba[j]*beam[j];
            total+=absorbed[j];
        }
        float ground=separate_albedo?(1.f-direct_albedo)*beam[10]+(1.f-ag)*down[10]:(1.f-ag)*(beam[10]+down[10]);
        float residual=beam0+diffuse0-up[0]-total-ground;
        for(int j=0;j<10;++j)out[j]=absorbed[j];
        for(int j=0;j<11;++j) {out[10+j]=beam[j];out[21+j]=down[j];out[32+j]=up[j];}
        out[43]=up[0];out[44]=ground;out[45]=residual;
}

__device__ void shortwave_device(const float* lai,const float* u,float* out) {
    shortwave_device_albedos(lai,u,u[2],false,out);
}

extern "C" __global__ void run_shortwave(const float* leaf, const float* inputs,
                                         float* output, int n) {
    for (int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        shortwave_device(leaf+10*row,inputs+6*row,output+46*row);
}

extern "C" __global__ void run_longwave(const float* leaf, const float* temperature,
                                        const float* inputs,float* output,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x) {
        const float* lai=leaf+10*row;
        const float* temp=temperature+10*row;
        const float* u=inputs+3*row;
        float transmission[10],emission[10],down[11],up[11];
        for(int j=0;j<10;++j) {
            transmission[j]=expf(-lai[j]);
            float square=temp[j]*temp[j];
            emission[j]=(1.f-transmission[j])*5.670374419e-8f*(square*square);
        }
        down[0]=u[0];
        for(int j=0;j<10;++j)down[j+1]=transmission[j]*down[j]+emission[j];
        float ground_square=u[1]*u[1];
        up[10]=(1.f-u[2])*down[10]+u[2]*5.670374419e-8f*(ground_square*ground_square);
        for(int j=9;j>=0;--j)up[j]=transmission[j]*up[j+1]+emission[j];
        float total=0.f;
        float* out=output+35*row;
        for(int j=0;j<10;++j) {
            out[j]=down[j]+up[j+1]-down[j+1]-up[j];
            total+=out[j];
        }
        for(int j=0;j<11;++j){out[10+j]=down[j];out[21+j]=up[j];}
        out[32]=down[10]-up[10];out[33]=up[0];out[34]=u[0]-up[0]-total-out[32];
    }
}

// Ten leaf temperatures + ground, one diagnostic air box, four root layers.
// Compiled with leaf_kernel.cu and radiation_kernel.cu in the same translation unit.
__device__ float ca_sum(const float* v,int n) {
    float s=0.f;for(int j=0;j<n;++j)s+=v[j];return s;
}
__device__ float ca_dot(const float* a,const float* b,int n) {
    float s=0.f;for(int j=0;j<n;++j)s+=a[j]*b[j];return s;
}
__device__ float ca_root_capacity(const float* soil) {
    float total=0.f;for(int j=0;j<4;++j)total+=soil[5+j]>0.f?soil[1+j]:0.f;return total;
}
__device__ void ca_allocate(float demand,const float* soil,float* take) {
    float target=fminf(demand,ca_root_capacity(soil));
    for(int j=0;j<4;++j)take[j]=0.f;
    for(int iter=0;iter<4;++iter) {
        float remaining=fmaxf(0.f,target-ca_sum(take,4)),active[4];
        for(int j=0;j<4;++j)active[j]=take[j]<soil[1+j]?soil[5+j]:0.f;
        float denom=ca_sum(active,4);
        for(int j=0;j<4;++j)take[j]+=fminf(remaining*active[j]/fmaxf(denom,1e-30f),soil[1+j]-take[j]);
    }
}
__device__ float ca_scale(const float* v,int n,float limit) {
    float pos=0.f,neg=0.f;
    for(int j=0;j<n;++j) {pos+=fmaxf(v[j],0.f);neg+=fminf(v[j],0.f);}
    return pos>0.f?fminf(1.f,(limit-neg)/fmaxf(pos,1e-30f)):1.f;
}
struct CanopyWater {
    float wet[10],tr[10],kleaf[10],eg,eb,kunder,kbare,residual,uptake[4];
};
__device__ void ca_water(float q,const float* qs,const float* gs,const float* area,
                         float fv,float rho,const float* u,const float* soil,CanopyWater& w,bool shares=true) {
    float kw[10],kt[10],raw_wet[10],raw_tr[10];
    for(int j=0;j<10;++j) {
        float boundary=rho*fv*area[j]*u[5];
        bool drying=qs[j]>q;
        kw[j]=boundary*(drying?u[14]:1.f);
        kt[j]=boundary*(drying?1.f-u[14]:0.f)*gs[j]/(u[5]+gs[j]);
        raw_wet[j]=kw[j]*(qs[j]-q);
        raw_tr[j]=kt[j]*(qs[j]-q);
    }
    float wet_scale=ca_scale(raw_wet,10,u[15]);
    float tr_limit=soil[0]>0.f?fminf(u[16],ca_root_capacity(soil)):u[16];
    float tr_scale=ca_scale(raw_tr,10,tr_limit);
    for(int j=0;j<10;++j) {
        kw[j]*=raw_wet[j]>0.f?wet_scale:1.f;
        kt[j]*=tr_scale;
        w.tr[j]=kt[j]*(qs[j]-q);
    }
    ca_allocate(ca_sum(w.tr,10),soil,w.uptake);
    if(soil[0]==0.f)for(int j=0;j<4;++j)w.uptake[j]=0.f;
    float glimit=soil[0]>0.f&&shares?fminf(u[17],fmaxf(0.f,soil[9]-w.uptake[0])):u[17];
    float under=rho*fv/(1.f/u[4]+u[9]),bare=rho*(1.f-fv)/(1.f/u[3]+u[9]);
    float ground[2]={under*(qs[10]-q),bare*(qs[10]-u[1])};
    float ground_scale=ca_scale(ground,2,glimit);
    under*=ground[0]>0.f?ground_scale:1.f;
    bare*=ground[1]>0.f?ground_scale:1.f;
    for(int j=0;j<10;++j){w.wet[j]=kw[j]*(qs[j]-q);w.kleaf[j]=kw[j]+kt[j];}
    w.eg=under*(qs[10]-q);w.eb=bare*(qs[10]-u[1]);w.kunder=under;w.kbare=bare;
    w.residual=ca_sum(w.wet,10)+ca_sum(w.tr,10)+w.eg-rho*fv*u[3]*(q-u[1]);
}
__device__ void ca_longwave(const float* area,float eps,float fv,float* matrix) {
    float down[132],up[132],t[10];
    for(int j=0;j<132;++j){down[j]=0.f;up[j]=0.f;}
    down[11]=1.f;
    for(int j=0;j<10;++j) {
        t[j]=expf(-area[j]);
        for(int k=0;k<12;++k)down[(j+1)*12+k]=t[j]*down[j*12+k];
        down[(j+1)*12+j]+=1.f-t[j];
    }
    for(int k=0;k<12;++k)up[120+k]=(1.f-eps)*down[120+k];
    up[130]+=eps;
    for(int j=9;j>=0;--j) {
        for(int k=0;k<12;++k)up[j*12+k]=t[j]*up[(j+1)*12+k];
        up[j*12+j]+=1.f-t[j];
    }
    for(int j=0;j<10;++j)for(int k=0;k<12;++k)
        matrix[j*12+k]=fv*(down[j*12+k]+up[(j+1)*12+k]-down[(j+1)*12+k]-up[j*12+k]);
    for(int k=0;k<12;++k)matrix[120+k]=fv*(down[120+k]-up[120+k]);
    matrix[130]+=-(1.f-fv)*eps;matrix[131]+=(1.f-fv)*eps;
}
__device__ void ca_linear_solve(float* a,float* b,float* x) {
    for(int k=0;k<11;++k) {
        int pivot=k;
        for(int j=k+1;j<11;++j)if(fabsf(a[j*11+k])>fabsf(a[pivot*11+k]))pivot=j;
        for(int j=0;j<11;++j){float old=a[k*11+j];a[k*11+j]=a[pivot*11+j];a[pivot*11+j]=old;}
        float old=b[k];b[k]=b[pivot];b[pivot]=old;
        for(int j=k+1;j<11;++j) {
            float factor=a[j*11+k]/a[k*11+k];
            for(int i=k+1;i<11;++i)a[j*11+i]-=factor*a[k*11+i];
            b[j]-=factor*b[k];
        }
    }
    for(int j=10;j>=0;--j) {
        float value=b[j];for(int k=j+1;k<11;++k)value-=a[j*11+k]*x[k];
        x[j]=value/a[j*11+j];
    }
}
__device__ void canopy_energy_device(const float* area,const float* u,const float* f,
    const float* soil,const float* initial,const float* p,float* out,
    int max_iterations,float tolerance,float q_tolerance,const float* boundary=nullptr,const float* radiation=nullptr) {
        float fv=ca_sum(area,10)>0.f?u[13]:0.f;
        bool active[10];for(int j=0;j<10;++j)active[j]=fv*area[j]>0.f;
        float bands[2][46];
        for(int i=0;i<2;++i) {
            float optics[6]={u[11]*.5f*(1.f-u[21]),u[11]*.5f*u[21],u[19+i],u[22],
                i==0?.1f:.45f,i==0?.05f:.25f};
            shortwave_device(area,optics,bands[i]);
        }
        float bare_sw=u[11]*(1.f-.5f*(u[19]+u[20]));
        float sw[11],par[10],lw[132];
        for(int j=0;j<10;++j) {
            sw[j]=fv*(bands[0][j]+bands[1][j]);
            par[j]=area[j]>0.f?bands[0][j]*4.6f/fmaxf(area[j],1e-30f):0.f;
        }
        sw[10]=fv*(bands[0][44]+bands[1][44])+(1.f-fv)*bare_sw;
        float outgoing_sw=fv*(bands[0][43]+bands[1][43])+(1.f-fv)*(u[11]-bare_sw);
        float latent[11],weights[10];
        for(int j=0;j<11;++j)latent[j]=2.5e6f;
        for(int j=0;j<10;++j)weights[j]=area[j]/fmaxf(ca_sum(area,10),1e-30f);
        if(boundary) {
            for(int j=0;j<10;++j){sw[j]=radiation[j];par[j]=radiation[10+j];}
            sw[10]=ca_sum(radiation+20,5)+radiation[25];outgoing_sw=radiation[26];
            if(boundary[1]>0.f)latent[10]+=334000.f;
        }
        ca_longwave(area,u[18],fv,lw);
        float rho=u[2]/(287.f*u[0]*(1.f+.61f*u[1]));
        float hcan[11],hjac[121];
        for(int j=0;j<10;++j)hcan[j]=rho*1004.f*(fv*area[j]*u[5]);
        hcan[10]=rho*1004.f*(fv*u[4]);
        float hatm=rho*1004.f*fv*u[3],hbare=rho*1004.f*(1.f-fv)*u[3];
        float hden=ca_sum(hcan,11)+hatm;
        for(int j=0;j<11;++j)for(int k=0;k<11;++k)
            hjac[j*11+k]=(j==k?hcan[j]:0.f)-(hden>0.f?hcan[j]*hcan[k]/fmaxf(hden,1e-30f):0.f);
        hjac[120]+=hbare;
        float mol_density=u[2]/(8.314462618f*u[0]),temp[11],qcan=u[1];
        for(int j=0;j<11;++j)temp[j]=(j<10&&!active[j])?u[0]:initial[j];
        if(boundary)temp[10]=boundary[0];
        bool dry=u[16]==0.f||(soil[0]>0.f&&ca_root_capacity(soil)==0.f);
        for(int count=0;count<max_iterations;++count) {
            float qs[11],dq[11],es[11],gas[120],gs[10];
            for(int j=0;j<11;++j) {
                float tc=temp[j]-273.15f;
                es[j]=611.2f*expf(17.67f*tc/(tc+243.5f));
                float den=u[2]-.378f*es[j];
                qs[j]=.622f*es[j]/den;
                dq[j]=.622f*u[2]*es[j]*17.67f*243.5f/(den*den*(tc+243.5f)*(tc+243.5f));
            }
            if(boundary&&boundary[1]>0.f) {
                float t=temp[10];
                es[10]=expf(9.550426f-5723.265f/t+3.53068f*logf(t)-.00728332f*t);
                float slope=5723.265f/(t*t)+3.53068f/t-.00728332f,den=u[2]-.378f*es[10];
                qs[10]=.622f*es[10]/den;dq[10]=.622f*u[2]*es[10]*slope/(den*den);
            }
            float vapor=qcan*u[2]/(.622f+.378f*qcan);
            for(int j=0;j<10;++j) {
                float leaf[7]={par[j],temp[j],u[8],vapor/es[j],u[5]*mol_density,
                    f[j*2]*(dry?0.f:f[j*2+1]),f[j*2+1]};
                leaf_gas_exchange_device(leaf,p,gas+j*12);
                gs[j]=gas[j*12+9]/mol_density;
            }
            float left=u[1],right=u[1];
            for(int j=0;j<11;++j){left=fminf(left,qs[j]);right=fmaxf(right,qs[j]);}
            CanopyWater water;
            for(int iter=0;iter<42;++iter) {
                float middle=.5f*(left+right);
                ca_water(middle,qs,gs,area,fv,rho,u,soil,water,boundary?boundary[2]>0.f:true);
                if(water.residual>0.f)left=middle;else right=middle;
            }
            float qnew=fv>0.f?.5f*(left+right):u[1];
            ca_water(qnew,qs,gs,area,fv,rho,u,soil,water,boundary?boundary[2]>0.f:true);
            float relative_temp[11];for(int j=0;j<11;++j)relative_temp[j]=temp[j]-u[0];
            float air_offset=hden>0.f?ca_dot(hcan,relative_temp,11)/fmaxf(hden,1e-30f):0.f;
            float tair=u[0]+air_offset;
            float sensible[11],evaporation[11],net[11],blackbody[12],residual[11];
            for(int j=0;j<11;++j) {
                sensible[j]=hcan[j]*((temp[j]-u[0])-air_offset);
                float square=temp[j]*temp[j];blackbody[j]=5.670374419e-8f*(square*square);
            }
            blackbody[11]=u[12];sensible[10]+=hbare*(temp[10]-u[0]);
            for(int j=0;j<10;++j)evaporation[j]=water.wet[j]+water.tr[j];
            evaporation[10]=water.eg+water.eb;
            float ground=u[7]*(temp[10]-u[6])+u[10];
            for(int j=0;j<11;++j) {
                net[j]=sw[j]+ca_dot(lw+j*12,blackbody,12);
                residual[j]=net[j]-sensible[j]-2.5e6f*evaporation[j];
            }
            residual[10]+=-ground;
            bool enabled=boundary&&boundary[3]>0.f;
            float mass=0.f,enthalpy=0.f,storage=0.f,wet_adv=0.f,tr_adv=0.f;
            if(boundary) {
                for(int j=0;j<11;++j)residual[j]=net[j]-sensible[j]-latent[j]*evaporation[j];
                ground=residual[10];residual[10]=0.f;
                if(enabled) {
                    mass=fmaxf(0.f,boundary[4]-boundary[6]*ca_sum(water.wet,10));
                    float heat[10];for(int j=0;j<10;++j)heat[j]=334000.f+4180.f*(temp[j]-273.15f);
                    enthalpy=mass*ca_dot(weights,heat,10);storage=(enthalpy-boundary[5])/boundary[6];
                    float uptake=ca_sum(water.uptake,4);
                    float root_mean=uptake>0.f?ca_dot(water.uptake,boundary+7,4)/fmaxf(uptake,1e-30f):0.f;
                    wet_adv=ca_dot(water.wet,heat,10);tr_adv=ca_dot(water.tr,heat,10);
                    for(int j=0;j<10;++j)residual[j]-=weights[j]*storage+water.wet[j]*heat[j]+water.tr[j]*(heat[j]-root_mean);
                }
            }
            float maxres=0.f;for(int j=0;j<11;++j)maxres=fmaxf(maxres,fabsf(residual[j]));
            float qerror=fabsf(qnew-qcan);
            bool energy_balanced=maxres<=tolerance;
            bool converged=energy_balanced&&qerror<=q_tolerance;
            float h=ca_sum(sensible,11),evap=ca_sum(evaporation,11),gross[10],resp[10],netlw[11];
            for(int j=0;j<10;++j){gross[j]=active[j]?gas[j*12]:0.f;resp[j]=active[j]?gas[j*12+5]:0.f;}
            for(int j=0;j<11;++j){out[j]=temp[j];netlw[j]=net[j]-sw[j];}
            out[11]=tair;out[12]=qnew;out[13]=fv*ca_dot(area,gross,10);out[14]=fv*ca_dot(area,resp,10);
            for(int j=0;j<10;++j){out[15+j]=sensible[j];out[30+j]=water.wet[j];out[40+j]=water.tr[j];}
            out[25]=sensible[10];out[26]=h;out[27]=2.5e6f*evap;out[28]=ground;out[29]=ca_sum(net,11);
            out[50]=water.eg+water.eb;for(int j=0;j<4;++j)out[51+j]=water.uptake[j];
            for(int j=0;j<11;++j)out[55+j]=residual[j];
            out[66]=ca_sum(residual,11);out[67]=(float)(count+1);out[68]=converged?1.f:0.f;
            out[69]=water.residual;out[70]=qerror;
            out[71]=h-(hatm*air_offset+hbare*(temp[10]-u[0]));
            out[72]=evap-(rho*fv*u[3]*(qnew-u[1])+water.eb);
            out[73]=outgoing_sw;out[74]=u[12]-ca_sum(netlw,11);
            for(int j=0;j<120;++j)out[75+j]=gas[j];
            if(boundary) {
                out[27]=ca_dot(latent,evaporation,11);out[195]=ground-sw[10];
                for(int j=0;j<6;++j)out[196+j]=radiation[20+j];
                out[202]=latent[10];out[203]=storage;out[204]=mass;out[205]=enthalpy;out[206]=wet_adv;out[207]=tr_adv;
            }
            if(converged)break;
            if(energy_balanced){qcan=qnew;continue;}
            float kcan[11],kd[11],jac[121],rhs[11],delta[11];
            for(int j=0;j<10;++j)kcan[j]=water.kleaf[j];kcan[10]=water.kunder;
            for(int j=0;j<11;++j)kd[j]=kcan[j]*dq[j];
            float kden=ca_sum(kcan,11)+rho*fv*u[3];
            for(int j=0;j<11;++j)for(int k=0;k<11;++k) {
                float ejac=(j==k?kd[j]:0.f)-(kden>0.f?kcan[j]*kd[k]/fmaxf(kden,1e-30f):0.f);
                if(j==10&&k==10)ejac+=water.kbare*dq[10];
                jac[j*11+k]=lw[j*12+k]*((float)(4.*5.670374419e-8)*(temp[k]*temp[k]*temp[k]))-hjac[j*11+k]-2.5e6f*ejac;
                if(j==10&&k==10)jac[j*11+k]+=-u[7];
                if(boundary) {
                    jac[j*11+k]=lw[j*12+k]*((float)(4.*5.670374419e-8)*(temp[k]*temp[k]*temp[k]))-hjac[j*11+k]-latent[j]*ejac;
                    if(enabled&&j<10&&k<10)jac[j*11+k]-=4180.f*mass/boundary[6]*(weights[j]*weights[k]);
                    if(enabled&&j<10&&j==k)jac[j*11+k]-=4180.f*(water.wet[j]+water.tr[j]);
                }
                if(j<10&&!active[j])jac[j*11+k]=j==k?-1.f:0.f;
            }
            for(int j=0;j<11;++j)rhs[j]=-((j<10&&!active[j])?u[0]-temp[j]:residual[j]);
            if(boundary) {for(int k=0;k<11;++k)jac[110+k]=k==10?-1.f:0.f;rhs[10]=0.f;}
            ca_linear_solve(jac,rhs,delta);
            for(int j=0;j<11;++j)temp[j]=fminf(350.f,fmaxf(200.f,temp[j]+.8f*fminf(5.f,fmaxf(-5.f,delta[j]))));
            qcan=qnew;
        }
}

extern "C" __global__ void run_canopy_energy(const float* areas,const float* inputs,
    const float* factors,const float* soils,const float* initials,const float* p,float* outputs,
    int n,int max_iterations,float tolerance,float q_tolerance) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        canopy_energy_device(areas+row*10,inputs+row*23,factors+row*20,soils+row*10,initials+row*11,p,outputs+row*195,
            max_iterations,tolerance,q_tolerance);
}
extern "C" __global__ void run_canopy_boundary(const float* areas,const float* inputs,
    const float* factors,const float* soils,const float* initials,const float* boundaries,const float* radiation,
    const float* p,float* outputs,int n,int max_iterations,float tolerance,float q_tolerance) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x)
        canopy_energy_device(areas+row*10,inputs+row*23,factors+row*20,soils+row*10,initials+row*11,p,outputs+row*208,
            max_iterations,tolerance,q_tolerance,boundaries+row*11,radiation+row*584);
}

// Coupled extensive canopy phase state. Every Newton operation runs on GPU.
// Uses the validated leaf and radiation kernels, with deterministic reductions.
struct PhaseContext {
    const float *leaf,*u,*f,*soil,*c,*b,*p,*rad;
    float area[10],fw[10],dry[10],vc[10],weights[11],sw[11],lw[132];
    float fv,rho,mol,atm,bare,hden,trlimit,lg,water_velocity,heat_temperature;
    bool phase_active[10];
};
__device__ void phase_prepare(const float* leaf,const float* u,const float* f,const float* soil,
    const float* stem,const float* c,const float* b,const float* p,const float* rad,PhaseContext& v) {
    v.leaf=leaf;v.u=u;v.f=f;v.soil=soil;v.c=c;v.b=b;v.p=p;v.rad=rad;
    v.water_velocity=u[3];v.heat_temperature=u[0];
    for(int i=0;i<10;++i)v.area[i]=leaf[i]+stem[i];
    v.fv=ca_sum(v.area,10)>0.f?u[13]:0.f;v.rho=u[2]/((287.f*u[0])*(1.f+.61f*u[1]));v.mol=u[2]/(8.314462618f*u[0]);
    v.atm=((v.rho*1004.f)*v.fv)*u[3];v.bare=((v.rho*1004.f)*(1.f-v.fv))*u[3];
    for(int i=0;i<10;++i) {
        v.phase_active[i]=c[2*i]>0.f;
        v.weights[i]=(v.rho*1004.f)*((v.fv*v.area[i])*u[5]);v.vc[i]=((v.rho*v.fv)*v.area[i])*u[5];
        float cap=(.1f*v.fv)*v.area[i];v.fw[i]=cap>0.f?fminf(1.f,powf(c[2*i]/cap,2.f/3.f)):0.f;
        v.dry[i]=(1.f-v.fw[i])*(leaf[i]/(v.area[i]>0.f?v.area[i]:1.f));v.sw[i]=rad[i];
    }
    v.weights[10]=(v.rho*1004.f)*(v.fv*u[4]);v.hden=ca_sum(v.weights,11)+v.atm;
    v.sw[10]=ca_sum(rad+20,5)+rad[25];ca_longwave(v.area,u[18],v.fv,v.lw);
    v.trlimit=soil[0]>0.f?fminf(u[16],ca_root_capacity(soil)):0.f;v.lg=2.5e6f+(b[2]>0.f?334000.f:0.f);
}

__device__ __noinline__ void phase_evaluate(const PhaseContext& v,const float* z,float* residual,float* out) {
    const float *u=v.u,*b=v.b,*c=v.c;float t[11],thermal[10],qs[11],qi[11],es[11],gas[120];
    float mass[10],heat[10],adv[10],vapor[10],iv[10],liq[10],wetle[10],unmet[10],wet[10],tr[10],take[4];
    const float plateau=79.90430622009569f;float q=z[11]*.001f;
    for(int i=0;i<10;++i) {
        t[i]=v.phase_active[i]?273.15f+((fminf(z[i],0.f)*4180.f/2100.f)+fmaxf(z[i]-plateau,0.f)):273.15f+z[i];
        thermal[i]=(c[2*i]*4180.f)*z[i];
    }
    t[10]=z[10];
    float decoded_offset[11];for(int i=0;i<10;++i)decoded_offset[i]=v.phase_active[i]?(fminf(z[i],0.f)*4180.f/2100.f)+fmaxf(z[i]-plateau,0.f):z[i];decoded_offset[10]=t[10]-273.15f;
    for(int i=0;i<11;++i) {
        float tc=decoded_offset[i];es[i]=611.2f*expf((17.67f*tc)/(tc+243.5f));qs[i]=(.622f*es[i])/(u[2]-.378f*es[i]);
        float esi=expf(((9.550426f-5723.265f/t[i])+3.53068f*logf(t[i]))-.00728332f*t[i]);qi[i]=(.622f*esi)/(u[2]-.378f*esi);
    }
    for(int i=0;i<10;++i) {
        float dry_fraction=v.phase_active[i]?fminf(1.f,fmaxf(0.f,(z[i]*4180.f)/334000.f)):(t[i]>273.15f?1.f:0.f);
        float m=c[2*i],frac=m>0.f?fminf(m,fmaxf(0.f,thermal[i]/334000.f))/m:dry_fraction;
        float sat=frac*qs[i]+(1.f-frac)*qi[i],rh=((q*u[2])/(.622f+.378f*q))/es[i];
        float input[7]={v.rad[10+i],t[i],u[8],rh,u[5]*v.mol,v.f[2*i]*(v.trlimit>0.f?v.f[2*i+1]:0.f),v.f[2*i+1]};
        leaf_gas_exchange_device(input,v.p,gas+12*i);
        float amount=b[4]*((v.vc[i]*(sat>q?v.fw[i]:1.f))*(sat-q));
        float loss=fminf(fmaxf(amount,0.f),m),deposit=fmaxf(-amount,0.f),remaining=m-loss;
        float retained=(remaining/(m>0.f?m:1.f))*thermal[i];
        float added=deposit*((1.f-frac)*(2100.f*(t[i]-273.15f))+frac*(334000.f+4180.f*(t[i]-273.15f)));
        mass[i]=remaining+deposit;heat[i]=retained+added;adv[i]=(thermal[i]-retained)-added;
        vapor[i]=loss-deposit;liq[i]=vapor[i]*frac;iv[i]=vapor[i]-liq[i];wetle[i]=2.5e6f*vapor[i]+334000.f*iv[i];
        wet[i]=vapor[i]/b[4];unmet[i]=fmaxf(amount-loss,0.f);
        tr[i]=(((v.vc[i]*v.dry[i])*gas[12*i+9])/(u[5]*v.mol+gas[12*i+9]))*fmaxf(qs[i]-q,0.f);
    }
    float total=ca_sum(tr,10),scale=total>0.f?fminf(1.f,v.trlimit/fmaxf(total,1e-30f)):1.f;
    for(int i=0;i<10;++i)tr[i]*=scale;
    ca_allocate(ca_sum(tr,10),v.soil,take);if(v.soil[0]==0.f)for(int i=0;i<4;++i)take[i]=0.f;
    float limit=v.soil[0]>0.f&&b[3]>0.f?fminf(u[17],fmaxf(0.f,v.soil[9]-take[0])):u[17];
    float gqs=b[2]>0.f?qi[10]:qs[10];
    float ge[2]={(v.rho*(v.fv*(gqs-q)))/(1.f/u[4]+u[9]),(v.rho*((1.f-v.fv)*(gqs-u[1])))/(1.f/v.water_velocity+u[9])};
    scale=ca_scale(ge,2,limit);for(int i=0;i<2;++i)ge[i]=fminf(ge[i],0.f)+fmaxf(ge[i],0.f)*scale;
    float offset=0.f;for(int i=0;i<11;++i)offset+=v.weights[i]*(t[i]-v.heat_temperature);offset=v.hden>0.f?offset/fmaxf(v.hden,1e-30f):0.f;
    float sensible[11],emission[12],rn[11],latent[11],raw[11],storage[10],trheat[10],physical[11];
    float taken=ca_sum(take,4),root=taken>0.f?ca_dot(take,b+5,4)/fmaxf(taken,1e-30f):0.f;
    for(int i=0;i<11;++i){sensible[i]=v.weights[i]*((t[i]-v.heat_temperature)-offset);emission[i]=5.670374419e-8f*((t[i]*t[i])*(t[i]*t[i]));}
    sensible[10]+=v.bare*(t[10]-v.heat_temperature);emission[11]=u[12];
    for(int i=0;i<11;++i) {
        rn[i]=v.sw[i]+ca_dot(v.lw+12*i,emission,12);
        latent[i]=i<10?wetle[i]/b[4]+2.5e6f*tr[i]:v.lg*ca_sum(ge,2);
        raw[i]=(rn[i]-sensible[i])-latent[i];
    }
    float gh=b[0]>0.f?raw[10]:u[7]*(t[10]-u[6])+u[10];
    for(int i=0;i<10;++i) {
        trheat[i]=tr[i]*((334000.f+4180.f*(t[i]-273.15f))-root);storage[i]=(heat[i]-c[2*i+1])/b[4];
        physical[i]=raw[i]-((storage[i]+adv[i]/b[4])+trheat[i]);
        residual[i]=v.fv*v.area[i]>0.f?raw[i]-((thermal[i]-c[2*i+1])/b[4]+trheat[i]):u[0]-t[i];
    }
    physical[10]=raw[10]-gh;residual[10]=b[0]>0.f?b[1]-t[10]:raw[10]-gh;
    float airwater=((ca_sum(wet,10)+ca_sum(tr,10))+ge[0])-((v.rho*v.fv)*v.water_velocity)*(q-u[1]);
    residual[11]=v.fv>0.f?airwater*2.5e6f:(q-u[1])*1e5f;
    if(!out)return;
    for(int i=0;i<300;++i)out[i]=0.f;
    for(int i=0;i<10;++i) {
        out[i]=t[i];out[15+i]=sensible[i];out[30+i]=wet[i];out[40+i]=tr[i];
        out[195+i]=mass[i];out[205+i]=heat[i];out[215+i]=thermal[i];out[225+i]=iv[i];out[235+i]=liq[i];
        out[245+i]=adv[i];out[255+i]=wetle[i];out[265+i]=unmet[i];out[275+i]=z[i];
        out[13]+=v.leaf[i]*(v.fv*v.area[i]>0.f?gas[12*i]:0.f);out[14]+=v.leaf[i]*(v.fv*v.area[i]>0.f?gas[12*i+5]:0.f);
        out[69]+=(mass[i]-c[2*i])+vapor[i];
    }
    out[13]*=v.fv;out[14]*=v.fv;out[10]=t[10];out[11]=v.heat_temperature+offset;out[12]=q;out[25]=sensible[10];
    out[26]=ca_sum(sensible,11);out[27]=ca_sum(latent,11);out[28]=gh;out[29]=ca_sum(rn,11);out[50]=ca_sum(ge,2);
    for(int i=0;i<4;++i)out[51+i]=take[i];for(int i=0;i<11;++i)out[55+i]=physical[i];out[66]=ca_sum(physical,11);
    out[71]=(ca_sum(sensible,11)-v.atm*offset)-v.bare*(t[10]-v.heat_temperature);out[72]=airwater;out[73]=v.rad[26];
    float lwtotal=0.f;for(int i=0;i<11;++i)lwtotal+=rn[i]-v.sw[i];out[74]=u[12]-lwtotal;
    for(int i=0;i<120;++i)out[75+i]=gas[i];
    out[285]=ca_sum(storage,10);out[286]=ca_sum(adv,10)/b[4];
    for(int i=0;i<10;++i)out[287]+=tr[i]*(334000.f+4180.f*(t[i]-273.15f));out[288]=gh-v.sw[10];
    out[289]=v.rad[25];out[290]=v.lg;for(int i=0;i<12;++i)out[292]=fmaxf(out[292],fabsf(residual[i]));
    for(int i=0;i<5;++i)out[293+i]=v.rad[20+i];
    out[298]=ca_dot(take,b+5,4);out[299]=ca_sum(trheat,10);
}

__device__ void phase_linear(float* a,float* b,float* x) {
    for(int k=0;k<12;++k) {
        int pivot=k;for(int i=k+1;i<12;++i)if(fabsf(a[i*12+k])>fabsf(a[pivot*12+k]))pivot=i;
        for(int i=0;i<12;++i){float old=a[k*12+i];a[k*12+i]=a[pivot*12+i];a[pivot*12+i]=old;}
        float old=b[k];b[k]=b[pivot];b[pivot]=old;
        for(int i=k+1;i<12;++i) {
            float factor=a[i*12+k]/a[k*12+k];for(int j=k+1;j<12;++j)a[i*12+j]-=factor*a[k*12+j];b[i]-=factor*b[k];
        }
    }
    for(int i=11;i>=0;--i){float value=b[i];for(int k=i+1;k<12;++k)value-=a[i*12+k]*x[k];x[i]=value/a[i*12+i];}
}
__device__ float phase_max(const float* v,int n){float x=0.f;for(int i=0;i<n;++i)x=fmaxf(x,fabsf(v[i]));return x;}

__device__ void phase_solve(PhaseContext& v,float* out,int max_iterations,float tolerance,float* debug=nullptr) {
    float x[12],ambient[12],alternative[12],lower[12],upper[12],r[12],ra[12];const float plateau=79.90430622009569f;
    for(int i=0;i<10;++i) {
        float mass=v.c[2*i];x[i]=mass>0.f?v.c[2*i+1]/(mass*4180.f):v.u[0]-273.15f;
        ambient[i]=mass>0.f?(v.u[0]<273.15f?(v.u[0]-273.15f)*2100.f/4180.f:plateau+(v.u[0]-273.15f)):v.u[0]-273.15f;
        if(v.u[0]==273.15f)ambient[i]=x[i];
        lower[i]=mass>0.f?-36.75f:-73.15f;upper[i]=mass>0.f?(plateau+350.f)-273.15f:76.85f;
    }
    x[10]=v.b[0]>0.f?v.b[1]:v.u[0];x[11]=v.u[1]*1000.f;ambient[10]=x[10];ambient[11]=x[11];
    lower[10]=200.f;lower[11]=0.f;upper[10]=350.f;upper[11]=190.f;
    phase_evaluate(v,x,r,nullptr);phase_evaluate(v,ambient,ra,nullptr);bool choose=ca_dot(ra,ra,12)<ca_dot(r,r,12),available=false;
    for(int i=0;i<12;++i){alternative[i]=choose?x[i]:ambient[i];x[i]=choose?ambient[i]:x[i];available|=x[i]!=alternative[i];}
    int iteration=0,restarts=0;bool failed=false;
    while(iteration<max_iterations&&!failed) {
        phase_evaluate(v,x,r,out);if(phase_max(r,12)<=tolerance)break;
        for(int i=0;i<10;++i)if(!v.phase_active[i]&&v.fv*v.area[i]>0.f&&fabsf(x[i])<=.05f&&out[30+i]<0.f){
            v.phase_active[i]=true;
            x[i]=x[i]<0.f?(x[i]*2100.f)/4180.f:plateau+x[i];
            alternative[i]=alternative[i]<0.f?(alternative[i]*2100.f)/4180.f:plateau+alternative[i];
            lower[i]=-36.75f;upper[i]=(plateau+350.f)-273.15f;
        }
        phase_evaluate(v,x,r,out);
        for(int i=0;i<10;++i)if(v.phase_active[i]&&out[195+i]==0.f&&x[i]>0.f&&x[i]<plateau&&fabsf(r[i])>tolerance)x[i]=r[i]>0.f?plateau:0.f;
        phase_evaluate(v,x,r,nullptr);float jac[144],delta[12],rhs[12];
        for(int k=0;k<12;++k) {
            float lo[12],hi[12],rl[12],rh[12],step=k==11?.002f:.02f;
            for(int i=0;i<12;++i){lo[i]=x[i];hi[i]=x[i];}
            lo[k]=fmaxf(lower[k],x[k]-step);hi[k]=fminf(upper[k],x[k]+step);
            phase_evaluate(v,lo,rl,nullptr);phase_evaluate(v,hi,rh,nullptr);
            for(int i=0;i<12;++i)jac[i*12+k]=(rh[i]-rl[i])/(hi[k]-lo[k]);
        }
        for(int i=0;i<12;++i)rhs[i]=-r[i];phase_linear(jac,rhs,delta);
        float scale=1.f;for(int i=0;i<12;++i)scale=fmaxf(scale,fabsf(delta[i])/(i<10?20.f:5.f));
        for(int i=0;i<12;++i)delta[i]/=scale;
        float norm=ca_dot(r,r,12),chosen_norm=norm,chosen[12];bool accepted=false;
        for(int i=0;i<12;++i)chosen[i]=x[i];
        for(int k=0;k<24;++k) {
            float trial[12],rr[12];for(int i=0;i<12;++i)trial[i]=fminf(upper[i],fmaxf(lower[i],x[i]+delta[i]*ldexpf(1.f,-k)));
            phase_evaluate(v,trial,rr,nullptr);
            float trial_norm=ca_dot(rr,rr,12);
            if(!accepted&&trial_norm<norm){for(int i=0;i<12;++i)chosen[i]=trial[i];accepted=true;chosen_norm=trial_norm;}
        }
        if(!accepted||chosen_norm>.999f*norm) {
            float low[12],high[12],mid[12],rl[12],rh[12],rr[12];
            for(int i=0;i<12;++i){low[i]=chosen[i];high[i]=chosen[i];}
            low[11]=lower[11];high[11]=upper[11];phase_evaluate(v,low,rl,nullptr);phase_evaluate(v,high,rh,nullptr);
            if(rl[11]>=0.f&&rh[11]<=0.f) {
                for(int k=0;k<32;++k){
                    for(int i=0;i<12;++i)mid[i]=.5f*(low[i]+high[i]);phase_evaluate(v,mid,rr,nullptr);
                    for(int i=0;i<12;++i){if(rr[11]>0.f)low[i]=mid[i];else high[i]=mid[i];}
                }
                for(int i=0;i<12;++i)mid[i]=.5f*(low[i]+high[i]);phase_evaluate(v,mid,rr,nullptr);
                if(ca_dot(rr,rr,12)<chosen_norm){for(int i=0;i<12;++i)chosen[i]=mid[i];accepted=true;++restarts;}
            }
        }
        bool retry=!accepted&&available;
        for(int i=0;i<12;++i)x[i]=retry?alternative[i]:chosen[i];
        if(retry){available=false;++restarts;}failed=!(accepted||retry);++iteration;
    }
    phase_evaluate(v,x,r,out);out[67]=iteration+1;out[68]=!failed&&phase_max(r,12)<=tolerance&&phase_max(out+55,11)<=tolerance*1.05f;
    out[291]=restarts;
    if(debug) {
        for(int i=0;i<12;++i){debug[i]=x[i];debug[12+i]=r[i];}
        for(int i=0;i<10;++i)debug[24+i]=v.phase_active[i]?1.f:0.f;
        for(int i=0;i<23;++i)debug[34+i]=v.u[i];
        for(int i=0;i<10;++i)debug[57+i]=v.soil[i];
        for(int i=0;i<9;++i)debug[67+i]=v.b[i];
        // Probe represented coordinate neighbours without changing the solve.
        for(int k=0;k<12;++k)for(int direction=0;direction<2;++direction)for(int level=0;level<4;++level){
            float trial[12],rr[12];for(int i=0;i<12;++i)trial[i]=x[i];
            float neighbour=nextafterf(x[k],direction?__int_as_float(0x7f800000):-__int_as_float(0x7f800000));
            trial[k]=x[k]+(neighbour-x[k])*(float)(1<<(2*level));phase_evaluate(v,trial,rr,nullptr);
            int q=80+4*((k*2+direction)*4+level);debug[q]=trial[k];debug[q+1]=ca_dot(rr,rr,12);debug[q+2]=phase_max(rr,12);debug[q+3]=rr[k];
        }
    }

}
extern "C" __global__ void run_canopy_phase(const float* leaf,const float* u,const float* f,const float* soil,
    const float* stem,const float* c,const float* b,const float* radiation,const float* p,float* out,int n,int max_iterations,float tolerance,float* debug=nullptr) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x) {
        PhaseContext v;phase_prepare(leaf+row*10,u+row*23,f+row*20,soil+row*10,stem+row*10,c+row*20,b+row*9,p,radiation+row*584,v);
        phase_solve(v,out+row*300,max_iterations,tolerance);
    }
}

// Native CUDA extensive soil thermodynamics; physical T is TF + offset.
// This is independent of the released AHC/Thomas temperature solver.
__device__ void cap_partials(float total,float potential,float &v,float &ds,float &dp) {
    float width=fmaxf(.04f*total,1e-12f),dw=.04f*total>1e-12f?.04f:0.f;
    float diff=total-potential,sign=diff>0.f?1.f:(diff<0.f?-1.f:0.f);
    float rounded=fmaxf(width-fabsf(diff),0.f);
    v=fminf(total,potential)-rounded*rounded/(4.f*width);
    ds=(diff<0.f?1.f:(diff>0.f?0.f:.5f))-rounded*(dw-sign)/(2.f*width);
    ds+=rounded*rounded*dw/(4.f*width*width);
    dp=(diff>0.f?1.f:(diff<0.f?0.f:.5f))-rounded*sign/(2.f*width);
    if(v<=0.f) {v=0.f;ds=0.f;dp=0.f;}
}

__device__ void soil_thermodynamics(float water,float offset,float dz,float por,float b,int option,
                                   float &h,float &c,float &liquid) {
    const float clausius=(float)(334000./461.5/(273.15*273.15));
    float theta=water/(1000.f*dz),suction=fmaxf(clausius*fmaxf(-offset,0.f),1e-8f);
    float potential=por*powf(suction/5e-5f,-1.f/b);
    float dp=clausius*fmaxf(-offset,0.f)>1e-8f?potential*clausius/(b*suction):0.f;
    float unused,dpot;cap_partials(theta,potential,liquid,unused,dpot);
    float derivative=dpot*dp;
    if(option==2) for(int j=0;j<3;++j) {
        float limited,ds,dl;cap_partials(liquid,potential,limited,ds,dl);
        float slope=ds*derivative+dl*dp;
        if(limited>=theta) slope=0.f;
        liquid=.5f*(liquid+fminf(theta,limited));derivative=.5f*(derivative+slope);
    }
    liquid=offset>=0.f?water:fminf(water,fmaxf(0.f,liquid*(1000.f*dz)));
    derivative=(offset>=0.f?0.f:derivative)*(1000.f*dz);
    float dry=((1.f-por)*2e6f)*dz;
    float sensible=(dry+2100.f*water)+2080.f*liquid;
    h=sensible*offset+334000.f*liquid;
    c=sensible+(2080.f*offset+334000.f)*derivative;
}

__device__ bool invert_soil_enthalpy(float water,float target,float dz,float por,float b,int option,
                                    float &t,float &h,float &c,float &liquid,float &count) {
    float lo=-123.15f,hi=126.85f,hlo,hhi;
    soil_thermodynamics(water,lo,dz,por,b,option,hlo,c,liquid);
    soil_thermodynamics(water,hi,dz,por,b,option,hhi,c,liquid);
    bool valid=target>=hlo&&target<=hhi;
    float dry=((1.f-por)*2e6f)*dz;
    t=fminf(hi,fmaxf(lo,(target-334000.f*water)/(dry+4180.f*water)));
    count=0.f;
    for(int iteration=0;iteration<64;++iteration) {
        soil_thermodynamics(water,t,dz,por,b,option,h,c,liquid);count+=1.f;
        float err=h-target;
        float tol=fmaxf(2e-8f,8.f*1.1920928955078125e-7f*fmaxf(1.f,fmaxf(fabsf(target),fabsf(334000.f*liquid))));
        if(fabsf(err)<=tol) return valid;
        if(err<0.f)lo=t;else if(err>0.f)hi=t;
        float trial=t-err/c;
        if(!(trial>lo&&trial<hi)) trial=.5f*(lo+hi);
        t=trial;
    }
    soil_thermodynamics(water,t,dz,por,b,option,h,c,liquid);
    float tol=fmaxf(2e-8f,8.f*1.1920928955078125e-7f*fmaxf(1.f,fmaxf(fabsf(target),fabsf(334000.f*liquid))));
    return valid&&fabsf(h-target)<=tol;
}

extern "C" __global__ void run_soil_thermodynamics(const float* inputs,const int* option,
                                                  float* output,int inverse,int n) {
    for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x) {
        const float* u=inputs+5*row;float* out=output+9*row;
        float t=u[1],h,c,liq,count=0.f;bool ok=true;
        if(inverse) ok=invert_soil_enthalpy(u[0],u[1],u[2],u[3],u[4],option[row],t,h,c,liq,count);
        else soil_thermodynamics(u[0],t,u[2],u[3],u[4],option[row],h,c,liq);
        out[0]=t;out[1]=t+273.15f;out[2]=liq;out[3]=u[0]-liq;
        out[4]=h;out[5]=c;out[6]=inverse?h-u[1]:0.f;out[7]=count;out[8]=ok?1.f:0.f;
    }
}

extern "C" __global__ void fixed_phase(const float* c,const float* g,const float* p,const int* o,
 const float* a,const float* input,const float* f,const float* vv,const float* cc,const float* extension,
 const float* radiation,const float* leaf,float temp,float* out) {
 float u[23],v[7],soil[10],root_h[4],stem[10]={0.f};
 for(int i=0;i<23;++i)u[i]=input[i];for(int i=0;i<7;++i)v[i]=vv[i];v[1]=0.f;v[2]=0.f;
 for(int i=0;i<10;++i){v[1]+=cc[2*i];v[2]+=cc[2*i+1];}
 u[15]=v[1]/v[0];u[17]=o[0]>0?c[0]/v[0]:__int_as_float(0x7f800000);soil[0]=1.f;
 for(int i=0;i<4;++i){float t,h,cap,liquid,count;invert_soil_enthalpy(g[3*i],g[3*i+1],g[3*i+2],p[0],p[1],o[1],t,h,cap,liquid,count);
  root_h[i]=334000.f+4180.f*t;soil[1+i]=fmaxf(0.f,liquid-(p[5]*1000.f)*g[3*i+2])/v[0];soil[5+i]=v[3+i];if(i==0)soil[9]=liquid/v[0];}
 float b[9]={1.f,temp,temp<273.15f?1.f:0.f,o[0]==0?1.f:0.f,v[0]};for(int i=0;i<4;++i)b[5+i]=root_h[i];
 PhaseContext context;phase_prepare(a,u,f,soil,stem,cc,b,leaf,radiation,context);context.water_velocity=extension[0];context.heat_temperature=extension[1];
 phase_solve(context,out,100,.005f,out+300);
}

"""Fixed-boundary GPU experiments on the actual old G614 phase operands.

No frozen source is edited. Every in-memory experimental CUDA source is saved.
The original0.005W/m2 convergence and physical-residual gates are retained.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,time
import numpy as np
import cupy as cp
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as radiation_kernel
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.physics.photosynthesis import LeafParameters

base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-heat-phase-event-a'
original=base/'fluxnet-first-climate-cycle-20261017-g/failure-614-capture-a'
root=base/'p6-qia614-phase-diagnostic-a';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((original/'summary.json').read_text())
for name in ['failed-surface-inputs.npz','failed-surface-output.npz']:assert sha(original/name)==receipt['artifacts'][name]
with np.load(original/'failed-surface-inputs.npz',allow_pickle=False) as z:raw=dict(z)
with np.load(original/'failed-surface-output.npz',allow_pickle=False) as z:expected=dict(z)
arrays=tuple(cp.asarray(raw[f'a{k}'][1:2]) for k in range(9));c,g,p,o,a,u,f,v,cc=arrays
extension=cp.asarray(raw['exchange_extension'][1:2]);rad=cp.empty((1,584),cp.float32)
radiation_kernel(True)((1,),(32,),(a,cp.ascontiguousarray(c[:,:,cp.array([0,3,4,5,6,7,8])]),cp.ascontiguousarray(o[:,0]),cp.ascontiguousarray(radiation_inputs(a,u,cp)),*_tables(),rad,np.int32(1)))
configuration=json.loads((original.parent/'inputs/CN-Qia-config.json').read_text())
leaf=cp.asarray(pack_leaf_parameters(LeafParameters(**configuration['leaf_parameters']),np.float32))
paths=[source/'src/noahmp_clm/gpu/cuda'/n for n in ['leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu','enthalpy_kernel.cu']]
hashes={str(p.relative_to(source)):sha(p) for p in paths}
original_source='\n'.join(p.read_text() for p in paths)
marker='    out[291]=restarts;'
assert original_source.count(marker)==1
debug=r'''
    if(debug) {
        for(int i=0;i<12;++i){debug[i]=x[i];debug[12+i]=r[i];}
        for(int i=0;i<10;++i)debug[24+i]=v.phase_active[i]?1.f:0.f;
        for(int i=0;i<23;++i)debug[34+i]=v.u[i];
        for(int i=0;i<10;++i)debug[57+i]=v.soil[i];
        for(int i=0;i<9;++i)debug[67+i]=v.b[i];
        // Probe represented coordinate neighbours without changing the solve.
        for(int k=0;k<12;++k)for(int direction=0;direction<2;++direction)for(int level=0;level<4;++level){
            float trial[12],rr[12];for(int i=0;i<12;++i)trial[i]=x[i];
            float neighbour=nextafterf(x[k],direction?__int_as_float(0x7f800000):-__int_as_float(0x7f800000));
            trial[k]=x[k]+(neighbour-x[k])*(float)(1<<(2*level));phase_evaluate(v,trial,rr,nullptr);
            int q=80+4*((k*2+direction)*4+level);debug[q]=trial[k];debug[q+1]=ca_dot(rr,rr,12);debug[q+2]=phase_max(rr,12);debug[q+3]=rr[k];
        }
    }
'''
common=original_source.replace('int max_iterations,float tolerance) {','int max_iterations,float tolerance,float* debug=nullptr) {').replace(marker,marker+debug)
kernel=r'''
extern "C" __global__ void fixed_phase(const float* c,const float* g,const float* p,const int* o,
 const float* a,const float* input,const float* f,const float* vv,const float* cc,const float* extension,
 const float* radiation,const float* leaf,float temp,float* out) {
 float u[23],v[7],soil[10],root_h[4],stem[10]={0.f};
 for(int i=0;i<23;++i)u[i]=input[i];for(int i=0;i<7;++i)v[i]=vv[i];v[1]=0.f;v[2]=0.f;
 for(int i=0;i<10;++i){v[1]+=cc[2*i];v[2]+=cc[2*i+1];}
 u[15]=v[1]/v[0];u[17]=o[0]>0?c[0]/v[0]:__int_as_float(0x7f800000);soil[0]=1.f;
 for(int i=0;i<4;++i){float t,h,cap,liquid,count;invert_soil_enthalpy(g[3*i],g[3*i+1],g[3*i+2],p[0],p[1],o[1],t,h,cap,liquid,count);
  root_h[i]=334000.f+4180.f*t;soil[1+i]=fmaxf(0.f,liquid-(p[5]*1000.f)*g[3*i+2])/v[0];soil[5+i]=v[3+i];if(i==0)soil[9]=liquid/v[0];}
 float b[9]={1.f,temp,temp<273.15f?1.f:0.f,o[0]==0?1.f:0.f,v[0]};for(int i=0;i<4;++i)b[5+i]=root_h[i];
 PhaseContext context;phase_prepare(a,u,f,soil,stem,cc,b,leaf,radiation,context);context.water_velocity=extension[0];context.heat_temperature=extension[1];
 phase_solve(context,out,100,.005f,out+300);
}
'''
results=[]
for mode in ['original','sensible_offset','water_saturation_offset','both_offsets']:
    code=common
    if mode!='original':
        old='    t[10]=z[10];'
        assert old in code
        code=code.replace(old,old+'\n    float decoded_offset[11];for(int i=0;i<10;++i)decoded_offset[i]=v.phase_active[i]?(fminf(z[i],0.f)*4180.f/2100.f)+fmaxf(z[i]-plateau,0.f):z[i];decoded_offset[10]=t[10]-273.15f;')
        if mode in ['water_saturation_offset','both_offsets']:code=code.replace('float tc=t[i]-273.15f;','float tc=decoded_offset[i];')
        if mode in ['sensible_offset','both_offsets']:
            code=code.replace('float offset=0.f;for(int i=0;i<11;++i)offset+=v.weights[i]*(t[i]-v.heat_temperature);','float temperature_delta[11];for(int i=0;i<11;++i)temperature_delta[i]=i<10?(273.15f-v.heat_temperature)+decoded_offset[i]:t[i]-v.heat_temperature;\n    float offset=0.f;for(int i=0;i<11;++i)offset+=v.weights[i]*temperature_delta[i];')
            code=code.replace('sensible[i]=v.weights[i]*((t[i]-v.heat_temperature)-offset);','sensible[i]=v.weights[i]*(temperature_delta[i]-offset);')
    code+=kernel;(root/(mode+'.cu')).write_text(code)
    started=time.monotonic();module=cp.RawModule(code=code,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('fixed_phase',))
    out=cp.zeros(780,cp.float32);module.get_function('fixed_phase')((1,),(1,),(*arrays,extension,rad,leaf,np.float32(281.27642822265625),out))
    host=cp.asnumpy(out);np.savez_compressed(root/(mode+'.npz'),output=host,radiation=cp.asnumpy(rad),leaf_parameters=cp.asnumpy(leaf))
    row=dict(mode=mode,seconds=time.monotonic()-started,converged=bool(host[68]),iterations=float(host[67]),max_solver_residual=float(host[292]),
        max_physical_residual=float(abs(host[55:66]).max()),residual=host[312:324].tolist(),phase_coordinates=host[275:285].tolist(),
        leaf_temperature=host[:10].tolist(),original_saved_residual=float(expected['max_solver_residual'][1]),
        saved_coordinate_max_absolute=float(abs(host[275:285]-expected['phase_coordinates'][1]).max()),source_sha256=sha(root/(mode+'.cu')))
    results.append(row);print(json.dumps(row),flush=True)
assert all(sha(source/k)==v for k,v in hashes.items())
(root/'summary.json').write_text(json.dumps(dict(scope='GPU fixed-boundary G614 original phase context with explicit in-memory arithmetic experiments. Not a production fix, full surface/whole step, or new-suction annual.',source_sha256=hashes,input_sha256=sha(original/'failed-surface-inputs.npz'),results=results,finished_utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n')

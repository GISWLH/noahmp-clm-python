from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');label='p6-qia614-phase-diagnostic-c';receipt=base/(label+'-launch.json')
assert not receipt.exists() and not (base/label).exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(base/'p6-heat-phase-event-a/src')+':'+str(base/'p6-heat-phase-event-a/benchmarks'),CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with (base/(label+'.log')).open('w') as log:
    p=subprocess.Popen(['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(base/'diagnose_qia_614_phase_c.py')],cwd=base,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=0,scope='Original phase fixed-boundary diagnosis only')
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

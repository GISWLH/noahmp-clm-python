from pathlib import Path
import json
import numpy as np
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-qia614-phase-diagnostic-b'
with np.load(base/'fluxnet-first-climate-cycle-20261017-g/failure-614-capture-a/failed-surface-inputs.npz') as z:raw=dict(z)
for mode in ['original','both_offsets']:
    with np.load(root/(mode+'.npz')) as z:out=z['output']
    probes=out[380:764].reshape(12,2,4,4)
    norm=float(np.square(out[312:324].astype(float)).sum());best=np.unravel_index(np.argmin(probes[:,:,:,1]),(12,2,4))
    row=dict(mode=mode,initial_condensate=raw['a8'][1].tolist(),leaf_area=raw['a4'][1].tolist(),u=out[334:357].tolist(),
        boundary=out[367:376].tolist(),x=out[300:312].tolist(),phase_active=out[324:334].tolist(),
        norm=norm,best_neighbour=dict(index=list(map(int,best)),values=probes[best].tolist()))
    print(json.dumps(row),flush=True)

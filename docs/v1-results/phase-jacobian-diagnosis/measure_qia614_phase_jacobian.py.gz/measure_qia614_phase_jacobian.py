from pathlib import Path
import hashlib,json
import numpy as np
import cupy as cp
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-heat-phase-event-a/src/noahmp_clm/gpu/cuda';root=base/'p6-qia614-phase-diagnostic-b'
with np.load(root/'phase-reference-inputs.npz') as z:v=dict(z)
with np.load(root/'original.npz') as z:x=z['output'][300:312];rad=z['radiation']
code='\n'.join((source/name).read_text() for name in ['leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu'])
code+='''
extern "C" __global__ void measure(const float* a,const float* u,const float* f,const float* soil,const float* c,
 const float* b,const float* p,const float* rad,const float* extension,const float* saved,float* out) {
 float stem[10]={0.f};PhaseContext v;phase_prepare(a,u,f,soil,stem,c,b,p,rad,v);v.water_velocity=extension[0];v.heat_temperature=extension[1];
 float x[12],r[12];for(int i=0;i<12;++i)x[i]=saved[i];phase_evaluate(v,x,r,nullptr);
 out[0]=x[0];out[1]=r[0];out[2]=79.90430622009569f;
 for(int method=0;method<2;++method){float lo[12],hi[12],rl[12],rh[12];for(int i=0;i<12;++i){lo[i]=x[i];hi[i]=x[i];}
  lo[0]=x[0]-.02f;hi[0]=x[0]+.02f;if(method)hi[0]=fminf(hi[0],79.90430622009569f);
  phase_evaluate(v,lo,rl,nullptr);phase_evaluate(v,hi,rh,nullptr);
  int k=3+5*method;out[k]=lo[0];out[k+1]=hi[0];out[k+2]=rl[0];out[k+3]=rh[0];out[k+4]=(rh[0]-rl[0])/(hi[0]-lo[0]);
 }
}
'''
(root/'measure-jacobian.cu').write_text(code)
module=cp.RawModule(code=code,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('measure',))
arrays=[v[k] for k in ['leaf','u','factors','soil','condensate','boundary','leaf_parameters']]+[rad,v['extension'],x]
out=cp.empty(13,cp.float32);module.get_function('measure')((1,),(1,),(*[cp.asarray(a,cp.float32) for a in arrays],out));r=cp.asnumpy(out).astype(float)
result=dict(scope='Measured original CUDA phase evaluator at exactly saved G614 failed coordinates; no solver/physics changes.',phase_coordinate=r[0],residual_wm2=r[1],melting_endpoint=r[2],
    centred=dict(lower=r[3],upper=r[4],residual_lower=r[5],residual_upper=r[6],d_residual_d_coordinate=r[7]),
    within_phase=dict(lower=r[8],upper=r[9],residual_lower=r[10],residual_upper=r[11],d_residual_d_coordinate=r[12]),
    source_sha256=hashlib.sha256(code.encode()).hexdigest())
(root/'measured-jacobian.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-stem-cuda-year-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'launch.json').read_text());pid=json.loads((r/'worker.json').read_text())['pid'];assert b'run_qia_stem_cuda_year_c.py' in Path('/proc',str(pid),'cmdline').read_bytes();raw=(r/'trajectory/batch.json').read_bytes();report=json.loads(raw);assert report['status']=='running' and report['steps_completed']>=48 and report['steps_requested']==17520 and report['identity']['compare_jax32'] is False and report['same_precision_max_absolute'] is None
seed=r/'seed-day-b'
for name,digest in launch['exact_copied_prefix_files'].items():
 assert sha(seed/name)==digest
 if name.startswith('inputs/') or name.endswith('.npz'):assert sha(r/name)==digest
def trace(folder,d):
 assert len(d['case_reports'])==1;name,item=next(iter(d['case_reports'].items()));p=folder/name/item['file'];assert sha(p)==item['sha256'];case=json.loads(p.read_text());p=folder/name/case['model_npz'];assert sha(p)==case['model_npz_sha256']
 with np.load(p,allow_pickle=False) as z:return dict(z)
old=json.loads((seed/'trajectory/batch.json').read_text());before=trace(seed/'trajectory',old);after=trace(r/'trajectory',report);assert before.keys()==after.keys()
for name in before:assert before[name].dtype==after[name].dtype;np.testing.assert_array_equal(before[name],after[name][:48])
obs=dict(scope='Actual CUDA-only current-source Qia year continuation live,all initial prefix files exact at launch and preserved immutable npz/input copies; every original first48 trace value/dtype still exactly equal in current appended trajectory. Original17520 request/MHCN ledger carried; no year/spinup/scientific completion. StrictA JAX comparison and current full1239 remain separate/pending.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),ps=subprocess.check_output(['ps','-p',str(pid)+',2242411,2387702','-o','pid,ppid,stat,etime,pcpu,args'],text=True),committed_steps=report['steps_completed'],requested_steps=17520,exact_first48_trace_arrays=len(before),same_precision_max_absolute=None,maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],source_manifest_sha256=launch['source_manifest_sha256'])
a=b/'qia-stem-cuda-year-launch-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [r/'launch.json',r/'worker.json',b/'run_qia_stem_cuda_year_c.py',b/'control_qia_stem_cuda_year_c.py',b/'launch_qia_stem_cuda_year_c.py',Path(__file__)]:t.add(p,arcname=p.name,recursive=False)
 for name,data in [('observation.json',(json.dumps(obs,indent=2)+'\n').encode()),('captured-batch.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=sha(a),observation=obs)))

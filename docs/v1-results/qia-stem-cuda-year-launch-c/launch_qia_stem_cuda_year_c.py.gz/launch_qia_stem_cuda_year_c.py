from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-f';r=b/'qia-stem-cuda-year-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not r.exists();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items());a=b/'qia-stem-cuda-day-b-evidence.tar.gz';assert sha(a)=='20bc1c0345f62dd05996ab67f003ec7d3c634665fffbb96308c533b6c2156e17';free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>2048
r.mkdir();seed=r/'seed-day-b';seed.mkdir()
with tarfile.open(a) as t:t.extractall(seed,filter='data')
report=json.loads((seed/'trajectory/batch.json').read_text());receipt=json.loads((seed/'receipt.json').read_text());exit=json.loads((seed/'exit.json').read_text());assert exit['returncode']==0 and exit['passed'] and sha(seed/'receipt.json')==exit['receipt_sha256'] and receipt['failure'] is None and receipt['source_unchanged'] and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['identity']['compare_jax32'] is False and receipt['result']['primary_cold_seed_arrays_exact']==26
assert json.loads((seed/'SOURCE_SHA256.json').read_text())==m and all(v['bias_pass'] for v in receipt['result']['metrics'].values()) and receipt['result']['instantaneous_flux_criteria_met']
copied={}
for name in ['inputs','trajectory']:
 shutil.copytree(seed/name,r/name)
 for p in (seed/name).rglob('*'):
  if p.is_file():relative=p.relative_to(seed);assert sha(p)==sha(r/relative);copied[relative.as_posix()]=sha(p)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_qia_stem_cuda_year_c.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,free_memory_mib=free,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seed_day_archive_sha256=sha(a),exact_copied_prefix_files=copied,scope='Actual own successful CUDA-only48 to17520 continuation on GPU0; all copied input/state/trace/ledger files byte-identical. StrictA remains independent/pending. CUDA-only same_precision=None,never0 or claimed JAX comparison. Source/solver/MHCN/near-zero/bias gates unchanged,not spinup/scientific/year completion.')
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='exact_copied_prefix_files'}))

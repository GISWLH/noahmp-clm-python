"""Local stdlib-only raw evidence verification; no NumPy decode/re-execution."""
from pathlib import Path
import ast
import hashlib
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parent
LABEL = 'clm-drainage-package-pb-n'
sha = lambda b: hashlib.sha256(b).hexdigest()
package = json.loads((ROOT / (LABEL + '-package.json')).read_bytes())
archive = ROOT / package['archive']
assert sha(archive.read_bytes()) == package['sha256']
assert archive.stat().st_size == package['bytes']
with tarfile.open(archive) as t:
    items = t.getmembers()
    assert all(m.isfile() for m in items) and len({m.name for m in items}) == len(items)
    raw = {m.name: t.extractfile(m).read() for m in items}
assert len(raw) == package['artifacts']
inventory = json.loads(raw['artifact-inventory.json'])
assert set(inventory) == set(raw) - {'artifact-inventory.json'}
assert all(sha(raw[n]) == h['sha256'] and len(raw[n]) == h['bytes'] for n, h in inventory.items())
status = raw['scheduler/actual-qstat.txt'].decode()
assert re.search(r'^\s*job_state = F\s*$', status, re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', status, re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$', status, re.M)
receipt = json.loads(raw['receipt.json'])
summary = json.loads(raw['parity/summary.json'])
assert receipt['pbs_job'] == '1673.manager' and receipt['passed'] and receipt['numerical_parent_returncode'] == 0
assert int(raw['worker-exit.txt']) == int(raw['scheduler/pbs-exit.txt']) == 0
assert summary['passed'] and summary['completed_cases'] == 20
assert summary['actual_trial_calls'] == 20 and summary['actual_full_calls'] == 17
assert summary['numeric_fields_compared'] == 1106
assert json.loads(raw['immutable-before.json']) == json.loads(raw['immutable-after.json'])
for folder in ('preparation', 'execution'):
    index = json.loads(raw[folder + '/CONTROLS_SHA256.json'])
    assert all(sha(raw[folder + '/' + n]) == h for n, h in index.items())
    assert all((ROOT / (LABEL + '-' + folder) / n).read_bytes() == raw[folder + '/' + n] for n in index)
source = json.loads(raw['source-manifest.json'])
assert len(source) == 593
with tarfile.open(ROOT / (LABEL + '-source.tar.gz')) as t:
    source_raw = {m.name: t.extractfile(m).read() for m in t}
assert len(source_raw) == 594
assert source_raw['SOURCE_SHA256.json'] == raw['source-manifest.json']
assert all(sha(source_raw[n]) == h for n, h in source.items())
base = json.loads(raw['preparation/BASE_PBL_SOURCE_SHA256.json'])
assert len(base) == 586 and all(source[n] == h for n, h in base.items())
with tarfile.open(ROOT / 'drainage-gold-po-b-evidence.tar.gz') as t:
    original = {m.name: t.extractfile(m).read() for m in t}
gold_binding = json.loads(raw['preparation/GOLD32_BINDINGS.json'])
assert all(raw['original1665/' + n] == original[n] and sha(original[n]) == h for n, h in gold_binding['members'].items())
assert raw['execution/original_arrays_po.py'] == original['preparation/arrays_po.py']
adaptation = json.loads(raw['execution/ENCODER_ADAPTATION.json'])
code = raw['execution/original_arrays_po.py'].decode()
for row in adaptation['exact_replacements']:
    assert code.count(row['old']) == 1
    code = code.replace(row['old'], row['new'])
assert code.encode() == raw['execution/arrays_pbn.py']
for n, b in raw.items():
    if n.startswith(('execution/', 'preparation/')) and n.endswith('.py'): ast.parse(b)
rows = [json.loads(line.split('PB_N_PARITY ', 1)[1]) for line in raw['numerical.stdout.txt'].decode().splitlines() if 'PB_N_PARITY ' in line]
assert rows == summary['records']
fields = 0
for row in rows:
    compare = json.loads(raw['parity/' + row['case'] + '/all-numeric-byte-comparison.json'])
    original_descriptors = json.loads(raw['original1665/gold/' + row['case'] + '/numpy32.npz.json'])['arrays']
    actual_descriptors = json.loads(raw['parity/' + row['case'] + '/actual32.npz.json'])
    assert sha(raw['parity/' + row['case'] + '/actual32.npz']) == actual_descriptors['npz_sha256']
    assert actual_descriptors['arrays'] == original_descriptors
    assert set(compare) == set(original_descriptors)
    for key, value in compare.items():
        assert value['passed'] and value['dtype_equal'] and value['shape_equal'] and value['bytes_equal']
        assert value['actual'] == value['expected'] == original_descriptors[key]
    fields += len(compare)
assert fields == 1106
review = dict(actual_static_exit=0, blocking_findings=[], archive_sha256=package['sha256'],
    artifacts=len(raw), actual_job='1673.manager', actual_F0=True, Stageout_status=0,
    source_files=593, unchanged_base_files=586, sealed_gold_members=345, original_gold_targets_byteexact=100,
    actual_trial_calls=20, actual_full_calls=17, numeric_field_proofs=1106,
    scope='Stdlib raw hash/log/metadata verification only; numeric byte-comparison proof is the original EHPC computation, not locally repeated.')
(ROOT / (LABEL + '-verification.json')).write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(review))

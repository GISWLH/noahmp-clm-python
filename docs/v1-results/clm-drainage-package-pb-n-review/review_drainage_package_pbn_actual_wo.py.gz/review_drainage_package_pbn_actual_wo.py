"""Independent closed1673 audit, stdlib/raw bytes only; never scientific imports."""
from pathlib import Path
import ast
import hashlib
import json
import math
import re
from review_drainage_gold_pob_wo import untar, check_npz, terminal

BASE = Path(__file__).resolve().parent
SHA = 'bd5e179136af200b9f57906c8334dc1a7473f8377cf317464fcbfc4fef71e9a7'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    label = 'clm-drainage-package-pb-n'
    body = (BASE / (label + '-evidence.tar.gz')).read_bytes()
    package = json.loads((BASE / (label + '-package.json')).read_bytes())
    assert sha(body) == SHA == package['sha256'] and len(body) == package['bytes'] == 536938
    raw = untar(body)
    assert len(raw) == package['artifacts'] == 270
    index = json.loads(raw['artifact-inventory.json'])
    assert set(index) == set(raw) - {'artifact-inventory.json'}
    assert all(sha(raw[n]) == item['sha256'] and len(raw[n]) == item['bytes'] for n, item in index.items())
    get = lambda n: json.loads(raw[n])
    terminal(raw['scheduler/actual-qstat.txt'], '1673.manager', 0)
    assert re.search(rb'^\s*exec_host = compute002/', raw['scheduler/actual-qstat.txt'], re.M)
    assert raw['worker-exit.txt'].strip() == raw['scheduler/pbs-exit.txt'].strip() == b'0'
    assert raw['scheduler/qsub.stdout.txt'].strip() == b'1673.manager'
    receipt, summary = get('receipt.json'), get('parity/summary.json')
    assert receipt['pbs_job'] == '1673.manager' and receipt['node'] == 'compute002'
    assert receipt['passed'] and receipt['numerical_parent_returncode'] == 0
    assert summary['passed'] and summary['completed_cases'] == 20
    assert raw['numerical.stderr.txt'].strip() == b''
    stdout_lines = raw['numerical.stdout.txt'].decode().splitlines()
    stdout_rows = [json.loads(line.removeprefix('PB_N_PARITY ')) for line in stdout_lines if line.startswith('PB_N_PARITY ')]
    assert stdout_rows == summary['records'] and len(stdout_rows) == 20
    assert json.loads(stdout_lines[-1]) == summary
    assert json.loads(raw['controller.log'].decode().splitlines()[-1]) == receipt

    nm_body = (BASE / (label + '-source.tar.gz')).read_bytes()
    assert sha(nm_body) == receipt['source_archive_sha256'] == '232db42838e256133c1b3aa4a9d4adb57295cce09f8650487835eb826ca7411f'
    source = untar(nm_body)
    assert source['SOURCE_SHA256.json'] == raw['source-manifest.json']
    source_index = get('source-manifest.json')
    assert len(source_index) == 593 and len(source) == 594
    assert all(sha(source[n]) == h for n, h in source_index.items())
    base = get('preparation/BASE_PBL_SOURCE_SHA256.json')
    assert len(base) == 586 and all(source_index[n] == h for n, h in base.items())
    original_body = (BASE / 'drainage-gold-po-b-evidence.tar.gz').read_bytes()
    assert sha(original_body) == receipt['gold_archive_sha256'] == '6ccfddeff32993f82819c9425774d6b3da7cfbc1e0e17ea14acf24aaa272db51'
    original = untar(original_body)
    assert len(original) == 345
    gold_index = json.loads(original['artifact-inventory.json'])
    assert set(original) == set(gold_index) | {'artifact-inventory.json'}
    assert all(sha(original[n]) == h for n, h in gold_index.items())
    terminal(original['closure/actual-qstat-final.txt'], '1665.manager', 0)
    assert json.loads(original['gold-seal.json'])['actual_gold'] is True
    target_members = get('preparation/GOLD32_BINDINGS.json')['members']
    assert len([n for n in target_members if re.match(r'gold/[^/]+/(input32|numpy32)', n)]) == 100
    assert all(raw['original1665/' + n] == original[n] and sha(original[n]) == h for n, h in target_members.items())
    immutable = {}
    for folder, count in (('preparation', 23), ('execution', 10)):
        controls = get(folder + '/CONTROLS_SHA256.json')
        assert len(controls) == count
        assert sha(raw[folder + '/CONTROLS_SHA256.json']) == receipt[folder + '_manifest_sha256']
        for n, h in controls.items():
            assert sha(raw[folder + '/' + n]) == h
            immutable[folder + '/' + n] = h
        immutable[folder + '/CONTROLS_SHA256.json'] = sha(raw[folder + '/CONTROLS_SHA256.json'])
    immutable.update({'source/' + n: sha(b) for n, b in source.items()})
    immutable.update({'sealed-gold/' + n: sha(b) for n, b in original.items()})
    assert len(immutable) == 974 == receipt['immutable_files_verified']
    assert immutable == get('immutable-before.json') == get('immutable-after.json')
    paths = get('parity/module-paths.json')
    assert len(paths) == 6 and all(v['path'].startswith('/var/tmp/pbs.1673.manager/result/source/src/')
              and source_index[v['source_relative_path']] == v['sha256'] for v in paths.values())
    adaptation = get('execution/ENCODER_ADAPTATION.json')
    assert raw['execution/original_arrays_po.py'] == original['preparation/arrays_po.py']
    code = raw['execution/original_arrays_po.py'].decode()
    for replacement in adaptation['exact_replacements']:
        assert code.count(replacement['old']) == 1
        code = code.replace(replacement['old'], replacement['new'])
    assert code.encode() == raw['execution/arrays_pbn.py']
    trees = [ast.parse(raw['execution/' + n]) for n in ('original_arrays_po.py', 'arrays_pbn.py')]
    funcs = [{n.name: ast.dump(n, include_attributes=False) for n in t.body if isinstance(n, ast.FunctionDef)} for t in trees]
    assert all(funcs[0][n] == funcs[1][n] for n in adaptation['unchanged_function_AST'])

    recipes = json.loads(original['gold/case-recipes.json'])
    assert len(recipes) == 20 and sum(r['full'] for r in recipes) == 17
    assert [r['name'] for r in recipes] == [r['case'] for r in stdout_rows]
    counts = dict(trial=0, full=0, inverse=0, fields=0, npz=0, npy=0)
    hard = []
    case_rows = []
    host_numeric_dtypes = set()
    for recipe, row in zip(recipes, stdout_rows, strict=True):
        name = recipe['name']
        prefix = 'parity/' + name + '/'
        old = 'original1665/gold/' + name + '/'
        run, obs = get(prefix + 'run.json'), get(prefix + 'observed-calls.json')
        assert row['passed'] and row['observed'] == obs
        assert obs['trial_attempted'] == obs['actual_trial_calls'] == 1
        assert obs['full_attempted'] == obs['actual_full_calls'] == int(recipe['full'])
        assert all(run[k] == obs[k] for k in ('phase', 'actual_trial_calls', 'actual_full_calls', 'trial_attempted', 'full_attempted'))
        original_run = get(old + 'numpy32-run.json')
        for key in ('actual_trial_calls', 'actual_full_calls', 'trial_attempted', 'full_attempted', 'phase',
                    'returned_nonnumeric', 'hard_ledgers', 'transferred_inputs_byteexact'):
            assert run[key] == original_run[key], (name, key)
        assert run['transferred_inputs_byteexact'] and row['input_arrays_unchanged']
        if recipe['full']:
            assert obs['phase']['input_dtype'] == 'float32' and obs['phase']['all_converged']
        counts['trial'] += obs['actual_trial_calls']
        counts['full'] += obs['actual_full_calls']
        counts['inverse'] += obs['phase'].get('actual_inverse_calls', 0)
        compared = get(prefix + 'all-numeric-byte-comparison.json')
        actual_meta, old_meta = get(prefix + 'actual32.npz.json'), get(old + 'numpy32.npz.json')
        packets = {}
        for key, packet_name, metadata in [('actual', prefix + 'actual32.npz', actual_meta),
             ('expected', old + 'numpy32.npz', old_meta), ('input', old + 'input32.npz', get(old + 'input32.npz.json'))]:
            packets[key] = check_npz(raw[packet_name], metadata)
            counts['npz'] += 1
            counts['npy'] += len(packets[key])
        assert packets['actual'] == packets['expected'] and actual_meta['arrays'] == old_meta['arrays']
        assert set(compared) == set(packets['actual']) and len(compared) == row['numeric_fields']
        assert all(v['dtype_equal'] and v['shape_equal'] and v['bytes_equal'] and v['passed']
                   and v['actual'] == v['expected'] == old_meta['arrays'][k] for k, v in compared.items())
        assert all(packets['input'][k]['dtype'] == '<f4' for k in ('cells', 'parameters', 'interval'))
        host_numeric_dtypes.update(v['dtype'] for v in actual_meta['arrays'].values())
        counts['fields'] += len(compared)
        for stage, channels in run['hard_ledgers'].items():
            for channel, budget in channels.items():
                assert budget['explicit_dtype'] == 'float32' and budget['original_factor'] == 64 and budget['backend'] == 'numpy'
                assert budget['passed'] and all(math.isfinite(budget[k]) for k in ('native_residual', 'independent_residual', 'original_bound', 'independently_scaled_bound'))
                assert abs(budget['native_residual']) <= budget['original_bound'] and abs(budget['independent_residual']) <= budget['original_bound']
                hard.append(dict(case=name, stage=stage, channel=channel, **budget))
        case_rows.append(dict(case=name, numeric_fields=len(compared), trial_calls=obs['actual_trial_calls'], full_calls=obs['actual_full_calls'],
                              inverse_calls=obs['phase'].get('actual_inverse_calls', 0), phase=obs['phase']))
    assert counts['trial'] == 20 and counts['full'] == 17 and counts['inverse'] == 5768 and counts['fields'] == 1106
    assert len(hard) == 74
    readout = get('run-readout.json')
    assert readout['receipt'] == receipt and readout['original_hard_budget_rows'] == hard
    maxima = {}
    for channel in ('water', 'heat'):
        rows = [r for r in hard if r['channel'] == channel]
        maximum = max(rows, key=lambda r: abs(r['native_residual']))
        fraction = max(abs(r['native_residual']) / r['original_bound'] for r in rows)
        assert abs(maximum['native_residual']) == readout['maximum_absolute_native_residual'][channel]
        assert fraction == readout['maximum_original_bound_fraction'][channel]
        maxima[channel] = dict(case=maximum['case'], stage=maximum['stage'], signed_residual=maximum['native_residual'],
                               original_bound=maximum['original_bound'], maximum_bound_fraction=fraction,
                               unit='kg/m2' if channel == 'water' else 'J/m2')
    for key in ('GPU_calls', 'JAX_calls', 'float64_component_calls', 'coupled_column_runs'):
        assert summary[key] == receipt[key] == 0
    result = dict(passed=True, blocking_findings=[], actual_static_exit=0,
                  archive_sha256=SHA, archive_members=270, inventory_entries=269,
                  actual_job='1673.manager', actual_F0=True, Stageout_status=0, numerical_parent_returncode=0,
                  source_files=593, unchanged_base_files=586, immutable_before_after_files=974,
                  preparation_manifest_sha256=receipt['preparation_manifest_sha256'], execution_manifest_sha256=receipt['execution_manifest_sha256'],
                  source_manifest_sha256=receipt['source_manifest_sha256'], original_gold_archive_sha256=receipt['gold_archive_sha256'],
                  source_gold_targets_original_bytes_equal=100, actual_execution_counts=counts,
                  case_records=case_rows, hard_ledger_rows=74, original_hard_bound_maxima=maxima,
                  worker_seconds=receipt['seconds'], numeric_seconds=summary['seconds'],
                  all_returned_numeric_dtype_shape_payload_equal=True, returned_dtypes=sorted(host_numeric_dtypes),
                  dtype_scope='Physical state inputs/results float32; complete returned tree also retains original bool/int and host scalar float64 metadata. No float64 component was run.',
                  original_phase_8eps_preserved_by_source_byte_binding=True,
                  scope='Closed EHPC NumPy32 import/resource/package parity on exact sealed1665 input32 only. All1106 numeric fields opaque payload-checked locally, no local array value decode/scientific import. No new NumPy64 comparison, GPU/JAX/coupled/annual acceptance, production wiring or dtype-guard credit.',
                  local_physics_calls=0, local_array_value_decodes=0, local_scientific_imports=0,
                  script_sha256=sha(Path(__file__).read_bytes()),
                  npy_metadata_helper_sha256=sha((BASE / 'review_drainage_gold_pob_wo.py').read_bytes()))
    target = BASE / (label + '-actual-independent-review-wo.json')
    target.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(passed=True, blocking_findings=[], review_sha256=sha(target.read_bytes()), counts=counts, maxima=maxima)))


if __name__ == '__main__':
    main()

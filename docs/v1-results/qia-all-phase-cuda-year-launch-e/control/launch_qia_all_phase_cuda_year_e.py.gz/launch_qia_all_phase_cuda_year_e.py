from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile

b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-b';r=b/'qia-all-phase-cuda-year-e';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not r.exists()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==511 and all(sha(s/n)==v for n,v in m.items())
archive=b/'all-phase-cpu-final-b-evidence.tar.gz';assert sha(archive)=='d883698681d114e5822982614190c0565551a45ac98fdff6460dfc322cfcc38b'
with tarfile.open(archive) as t:
    assert json.loads(t.extractfile('SOURCE_SHA256.json').read())==m
    d=json.loads(t.extractfile('cpu-full-receipt.json').read());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=911,failures=0,errors=0,skipped=0)
phase=json.loads((s/'target-a/exit.json').read_text());rec=json.loads((s/'target-a/receipt.json').read_text())
assert phase['returncode']==0 and phase['passed'] and rec['counts']==dict(tests=11,failures=0,errors=0,skipped=0) and rec['source_unchanged'] and rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
assert rec['all_setup_call_teardown_phases_passed'] and rec['node_coverage_exact']
assert sha(s/'target-a/receipt.json')==phase['receipt_sha256']
audit=b/'qia3798-paired-audit-g-evidence.tar.gz';assert sha(audit)=='1822130d22192fddbc91a84e0593ec7525e75c9c3f9009a601eb88e2f45ff795'
with tarfile.open(audit) as t:
    d=json.loads(t.extractfile('qia3798-paired-audit-g/audit.json').read());assert d['passed'] and len(d['fields'])==380 and d['maximum_absolute_difference']==0.
inputs=b/'qia-stem-inputs-a.tar.gz';assert sha(inputs)=='66ca0988cc66751284f61bf0909bd97b54c234cab895a53b51ce308d9ecec2f7'
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>2048
r.mkdir()
with tarfile.open(inputs) as t:t.extractall(r,filter='data')
protocol=json.loads((r/'protocol.json').read_text());assert all(sha(r/'inputs'/n)==v for n,v in protocol['inputs_sha256'].items())
cold=list((b/'qia-stem-device-day-a/trajectory').glob('state-0000000-*.npz'));assert len(cold)==1
(r/'strict-cold-reference.npz').write_bytes(cold[0].read_bytes());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes())
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
with (r/'controller.log').open('x') as log:
    child=subprocess.Popen([sys.executable,'-u',str(b/'control_qia_all_phase_cuda_year_e.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=child.pid,free_memory_mib=free,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cpu_evidence_sha256=sha(archive),phase_receipt_sha256=sha(s/'target-a/receipt.json'),paired3798_evidence_sha256=sha(audit),input_archive_sha256=sha(inputs),scope='New original-cold511B CUDA-only annual request after CPU911 and actual finalphase11 plus isolated3798 raw380 validation. Own first48 then own same-source continuation; no original failed prefix reused,strictA untouched,full1254 separately queued. same_precision=None; not climateyear/spinup/scientific completion.')
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

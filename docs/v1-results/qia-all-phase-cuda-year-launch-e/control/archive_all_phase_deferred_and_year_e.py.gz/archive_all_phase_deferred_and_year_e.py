from pathlib import Path
import datetime,hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=s/'full-controller-a';launch=json.loads((r/'launch.json').read_text())
for n,h in launch['controls_sha256'].items():assert sha(b/n)==h
assert sha(s/'SOURCE_SHA256.json')==launch['source_manifest_sha256']=='37187bea427930cdf1772c5db1d07b679c7dda15d8033e85e5a013a06089517f'
cancel=json.loads((r/'superseded-pending-510.json').read_text());assert cancel['original_pid']==2750196 and cancel['original_gpu_worker_still_absent']
assert not (b/'p6-fresh-phase-edge-a/full-controller-a/worker.json').exists()
c=s/'collection-preflight-a';d=json.loads((c/'collection.json').read_text());assert len(d['nodes'])==1254 and d['source_unchanged']
assert json.loads((c/'actual-exit.json').read_text())['returncode']==0
old=b/'p6-phase-final-check-a';v=json.loads((old/'full-by-file-a/progress.json').read_text())
proc=Path('/proc')/str(launch['pid']);assert str(b/'wait_all_phase_full_gpu_b.py').encode() in (proc/'cmdline').read_bytes().split(b'\0')
summary=dict(scope='Current frozenB511 actualcollection1254;CPU911 and phase11 completed exactsource. Remaining332GPU deferred only until predecessor actualexit. Owned510 idlewaiter superseded under UID/SIGSTOP/nochild/worker guards; originalmodelworkers untouched. Queue/precollection not full execution/year/science acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),launch=launch,worker_present=(r/'worker.json').exists(),exit_present=(r/'exit.json').exists(),previous506=dict(covered_nodes=v['covered_nodes'],active=v['active'],actual_exit_present=(old/'full-controller-a/exit.json').exists()),superseded=cancel)
results=[]
def archive(name,roots,controls,summary):
    a=b/(name+'-evidence.tar.gz');assert not a.exists()
    with tarfile.open(a,'w:gz') as t:
        for folder in roots:
            for p in sorted(folder.iterdir()):
                if p.is_file():t.add(p,arcname=folder.name+'/'+p.name,recursive=False)
        for n in controls:t.add(b/n,arcname='control/'+n,recursive=False)
        t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
        raw=(json.dumps(summary,indent=2)+'\n').encode();item=tarfile.TarInfo('snapshot.json');item.size=len(raw);t.addfile(item,io.BytesIO(raw))
        t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
    results.append(dict(name=a.name,sha256=sha(a),bytes=a.stat().st_size))
archive('all-phase-full-deferred-b',[r,c],list(launch['controls_sha256'])+['collect_all_phase_preflight_b.py','run_all_phase_precollection_b.py'],summary)
r=b/'qia-all-phase-cuda-year-e';launch=json.loads((r/'launch.json').read_text());worker=json.loads((r/'worker.json').read_text())
summary=dict(scope='New originalcold B511 CUDA-only annual launch snapshot,notterminal/year/science acceptance. Currentphase11 andCPU911 actual0;isolated3798raw380andoriginalhardguards prerequisites. NoJAXshadow,same_precision=None;K78rawsameprecisionstillunaccepted. Own valid48 will continue own source/state; no failed or sourcechangedprefix resumed.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),launch=launch,worker=worker,processes={},trajectory_report=None)
for role,pid in [('controller',launch['pid']),('worker',worker['pid'])]:
    proc=Path('/proc')/str(pid);summary['processes'][role]=dict(pid=pid,present=proc.exists(),cmdline=(proc/'cmdline').read_bytes().decode().split('\0') if proc.exists() else None,stat=(proc/'stat').read_text() if proc.exists() else None)
p=r/'trajectory/batch.json'
if p.exists():summary['trajectory_report']=json.loads(p.read_text())
controls=['run_qia_all_phase_cuda_year_e.py','control_qia_all_phase_cuda_year_e.py','launch_qia_all_phase_cuda_year_e.py'];summary['controls_sha256']={n:sha(b/n) for n in controls}
archive('qia-all-phase-cuda-year-launch-e',[r],controls,summary)
print(json.dumps(results))

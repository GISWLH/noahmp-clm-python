from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
root=Path.cwd();base=root.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in m.items())
archive=base/'most-oscillation-cpu-a-evidence.tar.gz';assert sha(archive)=='a1d40d43bac51cc0408f42207bd44cc2f4a33e8b8831016f3404b7d47b851c54'
def nodes(raw):
    result=[]
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(k) is None for k in ['failure','error','skipped'])
        parts=c.attrib['classname'].split('.');indices=[i for i,v in enumerate(parts) if v.startswith('test_')];assert len(indices)==1;k=indices[0]
        result.append('tests/'+parts[k]+'.py::'+'::'.join(parts[k+1:]+[c.attrib['name']]))
    assert len(result)==len(set(result));return set(result)
with tarfile.open(archive) as t:
    old=json.load(t.extractfile('SOURCE_SHA256.json'));receipt=json.load(t.extractfile('cpu-full-receipt.json'));old_nodes=nodes(t.extractfile('cpu-full.xml').read())
assert len(old_nodes)==780 and receipt['returncode']==0 and receipt['source_unchanged']
code_names=[n for n in old if n.startswith(('src/','tests/','benchmarks/','examples/'))];assert all(old[n]==m[n] for n in code_names)
new_nodes=nodes((root/'spinup-target.xml').read_bytes());target=json.loads((root/'spinup-target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=79,failures=0,errors=0,skipped=0)
added=new_nodes-old_nodes;assert len(added)==24 and all(n.startswith('tests/test_clm_spinup.py::') for n in added)
files=sorted(str(p) for p in Path('tests').glob('test_*.py') if not p.name.startswith('test_gpu'));begin=time.monotonic()
r=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q',*files],capture_output=True,text=True)
(root/'cpu-coverage-collection.log').write_text(r.stdout+r.stderr);assert r.returncode==0
collected=[s.strip() for s in r.stdout.splitlines() if s.startswith('tests/') and '::' in s];assert len(collected)==len(set(collected))==804
assert set(collected)==old_nodes|new_nodes and all(sha(root/n)==v for n,v in m.items())
value=dict(scope='Exact current CPU collection covered by same-source PBS95 old780 plus current target new24, with55 overlapping target nodes. No model tests rerun here and not a new single-process full pytest. GPU325 still execute under their separate identical physical/test freeze.',
    current_cpu_nodes=804,original_cpu_nodes=780,new_cpu_nodes=24,overlap=55,all_current_cpu_nodes_covered=True,source_files=len(m),unchanged_existing_code_test_benchmark_files=len(code_names),source_unchanged=True,
    original_cpu_archive_sha256=sha(archive),target_pbs_job=target['pbs_job'],current_target_xml_sha256=sha(root/'spinup-target.xml'),collection_seconds=time.monotonic()-begin,node=os.uname().nodename,pbs_job=os.environ['PBS_JOBID'],new_nodes=sorted(added),scientific_acceptance_claim=False)
(root/'cpu-coverage-receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
root=Path.cwd();base=root.parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in m.items())
old=json.loads((base/'p6-most-oscillation-a/SOURCE_SHA256.json').read_text());assert all(old[n]==v for n,v in m.items() if n.startswith('src/'))
files=['tests/test_clm_spinup.py','tests/test_fluxnet_native_runner.py','tests/test_hrldas_native_year.py']
begin=time.monotonic();code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml=spinup-target.xml']).returncode
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'spinup-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
negative=None
if code==0:
    from assess_clm_spinup import assess_cycles
    prefix=base/'most-climate-j48-prefix'
    original=json.loads((prefix/'cuda-day/batch.json').read_text());assert original['status']=='running' and original['steps_completed']==48 and original['steps_requested']==17520
    try:assess_cycles(prefix/'batch.json',base/'fluxnet-first-climate-cycle-20261017-h/inputs',[prefix/'cuda-day'],prefix/'gpu-SOURCE_SHA256.json')
    except ValueError as exc:
        negative=str(exc);assert 'Unchanged complete original year required' in negative
    else:raise AssertionError('Real running48 was promoted to spinup')
assert all(sha(root/n)==v for n,v in m.items())
(root/'spinup-target-receipt.json').write_text(json.dumps(dict(returncode=code,counts=counts,seconds=time.monotonic()-begin,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_files=len(m),source_unchanged=True,
    runtime_identical_most_a=True,original_j48_rejection=negative,actual_spinup_completed=False,scientific_acceptance_claim=False),indent=2)+'\n')
assert code==0 and negative and counts['failures']==counts['errors']==counts['skipped']==0

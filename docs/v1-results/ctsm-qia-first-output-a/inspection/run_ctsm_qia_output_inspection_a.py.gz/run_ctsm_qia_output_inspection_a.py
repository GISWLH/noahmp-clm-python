from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-output-inspection-a';scratch=Path(os.environ['TMPDIR'])/'ctsm-qia-output-inspection-a';scratch.mkdir();prefix=scratch/'toolchain';prefix.mkdir();workspace=scratch/'workspace';workspace.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();case=b/'ctsm-qia-run-k';d=json.loads((case/'configuration.json').read_text());assert d['official_model_returncode']==0 and d['upstream_original_bytes_unchanged'] and all(s['returncode']==0 for s in d['stages']) and (case/'pbs-exit.txt').read_text().strip()=='0'
a=b/'ctsm-portable-env-b.tar.gz';assert sha(a)=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(a) as t:t.extractall(prefix,filter='data')
private=case/'case-configuration-private.tar.gz';private_sha=sha(private)
with tarfile.open(private) as t:
 members=[m for m in t if m.isfile() and (m.name.startswith('output/case/run/') and m.name.endswith('.nc') or m.name=='inputdata/CN-Qia.datm.2003.nc')];t.extractall(workspace,members=members,filter='data')
for name,metadata in d['model_outputs'].items():
 if name.endswith('.nc'):assert sha(workspace/'output/case/run'/name)==metadata['sha256']
point=json.loads((b/'ctsm-qia-point-inputs-b/derivation.json').read_text());assert sha(workspace/'inputdata/CN-Qia.datm.2003.nc')==point['files']['CN-Qia.datm.2003.nc']['sha256']
env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(prefix/'lib'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');stages=[]
for name,cmd in [('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]),('inspect',[str(prefix/'bin/python'),str(r/'inspect_ctsm_qia_outputs_k.py'),str(workspace),str(r)])]:
 p=subprocess.run(cmd,env=env,cwd=scratch,capture_output=True,text=True,timeout=180);(r/(name+'.stdout.txt')).write_text(p.stdout);(r/(name+'.stderr.txt')).write_text(p.stderr);stages.append(dict(stage=name,returncode=p.returncode));assert p.returncode==0,p.stderr
receipt=dict(scope='Official K actual model0/PBS0 and all model-output hashes verified; NetCDF schema/time/raw-selected-field inspection only on EHPC compute node. Not a science/forcing-alignment pass.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,official_model_returncode=0,official_upstream_unchanged=True,official_private_workspace_sha256=private_sha,official_configuration_sha256=sha(case/'configuration.json'),stages=stages,schema_sha256=sha(r/'schema.json'),extracted_fields_sha256=sha(r/'extracted-reference-fields.npz'))
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

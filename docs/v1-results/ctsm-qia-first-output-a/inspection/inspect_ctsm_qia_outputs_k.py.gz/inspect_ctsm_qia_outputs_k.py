from pathlib import Path
import hashlib,json,sys
import numpy as np
from netCDF4 import Dataset,num2date
workspace,root=map(Path,sys.argv[1:3]);run=workspace/'output/case/run';wanted={'TBOT','QBOT','WIND','ZBOT','PBOT','FSDS','FLDS','RAIN','SNOW','H2OSNO','TSOI','H2OSOI','FPSN','FSH','EFLX_LH_TOT','FCEV','FCTR','FGEV','QOVER','QDRAI','TLAI','TSAI','ELAI','FGR','FSA','FIRA','TG','time','time_bounds','time_bnds','levgrnd','levsoi','DZSOI','ZSOI'};arrays={};rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[workspace/'inputdata/CN-Qia.datm.2003.nc',*sorted(run.glob('*.nc'))]
for index,path in enumerate(files):
 with Dataset(path) as d:
  metadata=dict(file=path.relative_to(workspace).as_posix(),sha256=sha(path),bytes=path.stat().st_size,dimensions={n:len(v) for n,v in d.dimensions.items()},variables={n:dict(dimensions=v.dimensions,units=getattr(v,'units',None),long_name=getattr(v,'long_name',None)) for n,v in d.variables.items()},array_keys={})
  if 'time' in d.variables:
   t=d['time'];metadata['time_units']=getattr(t,'units',None);metadata['time_calendar']=getattr(t,'calendar','standard');metadata['time_bounds_name']=getattr(t,'bounds',None)
   if len(t)>0 and getattr(t,'units',None):metadata['time_first_last']=[str(x) for x in num2date(t[[0,-1]],t.units,calendar=metadata['time_calendar'])]
  for name,v in d.variables.items():
   if name in wanted or any(n in name.lower() for n in ['co2diag','sa_tbot','sa_pbot','sa_shum','sa_z','faxa_swv','faxa_swn','faxa_lwdn','faxa_rain','faxa_snow']):
    values=np.ma.asarray(v[:]);values=np.asarray(values.filled(np.nan) if np.issubdtype(values.dtype,np.floating) else values)
    if index==0 and v.dimensions and v.dimensions[0]=='time':values=values[:49]
    key=f'f{index}_{name}';arrays[key]=values;metadata['array_keys'][name]=key
  rows.append(metadata)
np.savez_compressed(root/'extracted-reference-fields.npz',**arrays)
record=dict(scope='Actual official K/PBS178 output NetCDF read/schema/time axes and raw field extraction on EHPC compute node only. Successful execution/metadata extraction is not matched soil/cold-state/SP-CN/GPP/FLUXNET acceptance. Time-bin/forcing feed-through and FPSN interpretation remain explicit next checks.',source_case='ctsm-qia-run-k',files=rows,extracted_npz_sha256=sha(root/'extracted-reference-fields.npz'),extracted_array_count=len(arrays))
(root/'schema.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(files=[dict(file=x['file'],dimensions=x['dimensions'],time_units=x.get('time_units'),time_first_last=x.get('time_first_last'),arrays=list(x['array_keys'])) for x in rows],extracted_array_count=len(arrays),extracted_npz_sha256=record['extracted_npz_sha256'])))

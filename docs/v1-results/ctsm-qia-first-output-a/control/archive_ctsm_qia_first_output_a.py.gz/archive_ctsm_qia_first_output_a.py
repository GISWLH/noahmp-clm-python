from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'ctsm-qia-first-output-a-evidence.tar.gz';assert not a.exists();inspection=b/'ctsm-qia-output-inspection-a';alignment=b/'ctsm-qia-input-alignment-a';receipt=json.loads((inspection/'receipt.json').read_text());d=json.loads((alignment/'alignment.json').read_text());assert (inspection/'pbs-exit.txt').read_text().strip()==(alignment/'pbs-exit.txt').read_text().strip()=='0' and all(s['returncode']==0 for s in receipt['stages']);assert sha(inspection/'schema.json')==receipt['schema_sha256'] and sha(inspection/'extracted-reference-fields.npz')==receipt['extracted_fields_sha256'] and sha(alignment/'official-first48.npz')==d['official_first48_npz_sha256'] and d['selected_intervals']==48
with tarfile.open(a,'w:gz') as t:
 for r,label in [(inspection,'inspection'),(alignment,'alignment')]:
  for p in sorted(r.iterdir()):
   if p.is_file():t.add(p,arcname=label+'/'+p.name,recursive=False)
 summary=dict(scope='Official K model/PBS0 first requested48,original49 history samples include startup[-1800,0]; actual complete48 original half-hour bins read on EHPC179/180. This is not an input-alignment/science pass: measured land diagnostics differ in temperature/humidity/wind/radiation and diffuse split; driver-terminal CO2 only checked at one point. Raw observed data/numerical errors and all controls retained for diagnosis.',official_execution_archive_sha256='ef18ca2e8d1f30cbfc6b99ddf913f67f982c26d51927c51ee4686e8325c1591d',inspection_receipt=receipt,alignment=d)
 data=(json.dumps(summary,indent=2)+'\n').encode();info=tarfile.TarInfo('summary.json');info.size=len(data);t.addfile(info,io.BytesIO(data));t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

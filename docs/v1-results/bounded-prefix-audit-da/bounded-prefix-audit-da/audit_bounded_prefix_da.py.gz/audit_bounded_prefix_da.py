from pathlib import Path
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-prefix-audit-da';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();device=Path(os.environ['TMPDIR'])/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
a=b/'clm-bounded-native-cn-source.tar.gz';assert sha(a)=='9f28e8874c2a365fdb9c39764fc33e54a542c8aff4d0a5375906d6c22819e286'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==568 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
a=b/'bounded-gpu-prefix-cy-evidence.tar.gz';assert sha(a)==json.loads((r/'package.json').read_text())['prefix_archive_sha256']
with tarfile.open(a) as t:t.extractall(device,filter='data')
specs={
'h_wm2':(1.,0.,10.,1.),'le_wm2':(1.,0.,10.,1.),
'gpp_gc_m2':(48.,0.,1.,.1),'nee_gc_m2':(48.,0.,1.,.1),'autotrophic_respiration_gc_m2':(48.,0.,1.,.1),'heterotrophic_respiration_gc_m2':(48.,0.,1.,.1),
'et_mm':(48.,0.,.5,.05),'runoff_mm':(48.,0.,.5,.05),
'tsoil_k':(1.,273.15,5.,.5),'smc_m3m3':(1.,0.,.02,.002),'liquid_m3m3':(1.,0.,.02,.002),'swe_m':(1.,0.,.001,.0001),
'lai':(1.,0.,.1,.01),'sai_m2m2':(1.,0.,.1,.01),'canopy_sai_used_m2m2':(1.,0.,.1,.01),'canopy_exposed_lai_m2m2':(1.,0.,.1,.01),'canopy_exposed_sai_m2m2':(1.,0.,.1,.01),
'capacity_daylength_factor':(1.,0.,.01,.001),'capacity_vcmax25_top':(1.,0.,1.,.1),'capacity_nitrogen_extinction':(1.,0.,.01,.001)}
cases=[]
for label in ['capacity','capacity_optics']:
    q=r/label;q.mkdir();p=device/label;failure=None;summary={};begin=time.monotonic()
    try:
        d=json.loads((p/'prefix-receipt.json').read_text());exit_record=json.loads((p/'prefix-exit.json').read_text());assert exit_record['returncode']==0 and exit_record['passed'] and exit_record['receipt_sha256']==sha(p/'prefix-receipt.json') and d['failure'] is None and d['source_unchanged'] and d['cold_fields_exact']==30 and d['captured_step_calls']==48 and sha(p/'trajectory/batch.json')==d['report_sha256']
        protocol=json.loads((p/'inputs/protocol.json').read_text());identity=next(x for x in protocol['cases'] if x['case']==label);assert protocol['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')==d['source_manifest_sha256']
        cpu=b/('qia-bounded-'+label+'-numpy-cold-cx');cp=json.loads((cpu/'receipt.json').read_text());reference=json.loads((cpu/'cold48-report.json').read_text());assert (cpu/'pbs-exit.txt').read_text().strip()=='0' and cp['failure'] is None and cp['source_unchanged'] and cp['steps_completed']==48 and cp['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and sha(cpu/'cold48-report.json')==cp['report_sha256'];assert reference['status']=='running' and reference['steps_completed']==48 and reference['steps_requested']==17520
        report,saved,rows=native.read_generation(p/'trajectory');assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['identity']['source_sha256']==native.source_hashes() and report['identity']['native_state_arrays']==23
        assert len(rows)==1;trace=rows[0][1]
        with np.load(p/'inputs'/label/'cold-reference.npz',allow_pickle=False) as z:cold=dict(z)
        cold_paths=list((p/'trajectory').glob('state-0000000-*.npz'));assert len(cold_paths)==1 and sha(cold_paths[0])==json.loads((p/'cold-audit.json').read_text())['cold_checkpoint_sha256']
        with np.load(cold_paths[0],allow_pickle=False) as z:assert set(z.files)==set(cold) and all(z[k].dtype==cold[k].dtype and z[k].shape==cold[k].shape and z[k].tobytes()==cold[k].tobytes() for k in cold)
        initial=cold['initial'];net=np.zeros((1,4));bounds=net.copy();recorded_net=net.copy();maximum=net.copy();cumulative_max=net.copy();gate_max=net.copy();previous=tuple(cold['a'+str(k)] for k in range(23));tracer_max=np.zeros((1,5));field_count=None
        for index in range(48):
            with np.load(p/'prefix-steps'/('call-'+str(index).zfill(5)+'.npz'),allow_pickle=False) as z:data=dict(z)
            before=tuple(data['before'+str(k)] for k in range(23));after=tuple(data['after'+str(k)] for k in range(23))
            for x,y in zip(before,previous):assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes()
            out={}
            for name,value in data.items():
                if not name.startswith('output/'):continue
                parts=name.split('/')[1:];target=out
                for part in parts[:-1]:target=target.setdefault(part,{})
                target[parts[-1]]=value
            fields=sum(name.startswith('output/') for name in data);assert field_count is None or field_count==fields;field_count=fields
            incoming,residual,calculated_bound,tracer=native.audit_step(before,after,data['forcing'],data['deposition'],data['nitrogen'],out)
            bound=data['recorded/bound'];assert np.all(abs(residual)<=bound) and np.all(abs(residual)<=calculated_bound) and np.all(abs(data['recorded/residual'])<=bound)
            np.testing.assert_allclose(bound,calculated_bound,rtol=1e-12,atol=1e-12)
            net+=incoming;recorded_net+=data['recorded/incoming'];bounds+=bound;cumulative=native.totals(after)-initial-net;assert np.all(abs(cumulative)<=bounds)
            maximum=np.maximum(maximum,abs(residual));cumulative_max=np.maximum(cumulative_max,abs(cumulative));gate_max=np.maximum(gate_max,abs(residual)/bound);tracer_max=np.maximum(tracer_max,tracer);previous=after
        for k in range(23):assert previous[k].dtype==saved['a'+str(k)].dtype and previous[k].tobytes()==saved['a'+str(k)].tobytes()
        for name,value in [('initial',initial),('net',recorded_net),('bounds',bounds)]:np.testing.assert_array_equal(saved[name],value,err_msg=name)
        refpath=cpu/'trajectory'/reference['model_npz'];assert sha(refpath)==reference['model_npz_sha256']
        with np.load(refpath,allow_pickle=False) as z:ref=dict(z)
        for key in ['time_start','time_end']:np.testing.assert_array_equal(trace[key],ref[key])
        metrics={}
        for key,(scale,offset,floor,absolute) in specs.items():
            actual=(trace[key].astype(float)-offset)*scale;expected=(ref[key].astype(float)-offset)*scale;difference=abs(actual-expected);limit=np.where(abs(expected)<=floor,absolute,.1*abs(expected));assert np.all(difference<=limit),(key,float(difference.max()),float((difference/limit).max()))
            mean=float(expected.mean());corr=float(np.corrcoef(actual.ravel(),expected.ravel())[0,1]) if actual.std()>0 and expected.std()>0 else None
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and float(np.ptp(expected))>absolute and corr is not None:assert corr>.85,(key,corr)
            metrics[key]=dict(scale=scale,offset=offset,maximum_absolute_difference=float(difference.max()),maximum_gate_ratio=float((difference/limit).max()),mean_absolute_difference=float(difference.mean()),reference_mean=mean,signed_relative_bias_percent_reference_magnitude=100.*float((actual-expected).mean())/abs(mean) if abs(mean)>floor else None,instantaneous_correlation=corr)
        for key in ['capacity_mean_temperature_used_k','capacity_next_mean_temperature_k']:
            difference=abs(trace[key].astype(float)-ref[key]);assert np.all(difference<=.001);metrics[key]=dict(maximum_absolute_difference=float(difference.max()),fixed_absolute_tolerance_k=.001)
        for key in ['capacity_temperature_count','capacity_temperature_cursor']:np.testing.assert_array_equal(trace[key],ref[key]);metrics[key]=dict(integer_exact=True)
        daily={}
        for key,floor,absolute in [('h_wm2',10.,1.),('le_wm2',10.,1.),('et_mm',.5,.05),('runoff_mm',.5,.05),('gpp_gc_m2',1.,.1),('nee_gc_m2',1.,.1)]:
            actual=float(trace[key].mean() if key.endswith('wm2') else trace[key].sum());expected=float(ref[key].mean() if key.endswith('wm2') else ref[key].sum());limit=absolute if abs(expected)<=floor else .1*abs(expected);assert abs(actual-expected)<=limit
            daily[key]=dict(model=actual,reference=expected,absolute_difference=abs(actual-expected),signed_relative_bias_percent_reference_magnitude=100.*(actual-expected)/abs(expected) if abs(expected)>floor else None,original_gate=limit)
        summary=dict(passed=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),prefix_batch_report_sha256=sha(p/'trajectory/batch.json'),prefix_checkpoint_sha256=report['checkpoint_sha256'],configuration_sha256=identity['configuration_sha256'],batch_sha256=identity['batch_sha256'],cold_fields_exact=30,physical_step_pairs=48,returned_fields_per_step=field_count,all23state_chains_and_final_checkpoint_exact=True,maximum_independent_step_m_h_c_n=maximum.tolist(),maximum_independent_cumulative_m_h_c_n=cumulative_max.tolist(),maximum_step_original_gate_ratio=gate_max.tolist(),original_cumulative_bounds=bounds.tolist(),maximum_impurity_residual=tracer_max.tolist(),all23physical_trace_metrics=metrics,daily=daily,same_precision_max_absolute=None)
    except Exception as error:
        failure=type(error).__name__+': '+str(error);(q/'traceback.txt').write_text(traceback.format_exc());summary.update(passed=False,failure=failure)
    summary.update(case=label,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-begin,scope='IndependentEHPC currentCN native48 vs actualcurrentCN NumPyCX48, allsource/cold30/23statechains/perstep/cumulativeMHCN/impurity/originalbounds verified. All24 physicaltrace values underoriginal10%/nearzeroabsolute, nonflatH/LE/GPP/NEEr>.85. Original17520request and twofixedvariants kept. No oldsource tracecredit/JAXshadow, completeyear/spinup/official/observedsciencepass.')
    (q/'verification.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');cases.append(summary)
record=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),passed=all(v['passed'] for v in cases),cases=cases,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True);assert record['passed'] and record['source_unchanged']

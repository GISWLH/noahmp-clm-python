from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-prefix-audit-da';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and all(q['passed'] and q['physical_step_pairs']==48 and q['all23state_chains_and_final_checkpoint_exact'] for q in d['cases']);items=[(p,'bounded-prefix-audit-da/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['clm-bounded-native-cn-source.tar.gz','dispatch_bounded_prefix_audit_da.py',Path(__file__).name]);a=b/'bounded-prefix-audit-da-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

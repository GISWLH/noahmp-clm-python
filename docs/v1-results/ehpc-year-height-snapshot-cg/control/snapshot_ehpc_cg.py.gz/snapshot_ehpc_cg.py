from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();data={};record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),years={},height={})
def add(p,n,h=None):
    raw=p.read_bytes()
    if h:assert sha(raw)==h
    data[n]=raw;return raw
for name in ['qia-richards-'+x+'-numpy-year-a' for x in ['capacity','capacity_optics']]+['qia-wet-'+x+'-numpy-year-be' for x in ['capacity','capacity_optics']]:
    r=b/name;d=json.loads(add(r/'trajectory/report.json',name+'/trajectory/report.json'));assert d['steps_requested']==17520 and d['source_unchanged'];record['years'][name]={k:d[k] for k in ['status','steps_completed','steps_requested','seconds','maximum_cumulative_residual_m_h_c_n','cumulative_numerical_bounds_m_h_c_n']}
    for field,hfield in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
        p=r/'trajectory'/d[field];assert p.parent==r/'trajectory';add(p,name+'/trajectory/'+p.name,d[hfield])
    for n in ['SOURCE_SHA256.json','year-launch.json','lineage.json','dispatch.json','launch.json','receipt.json','pbs-exit.txt']:
        if (r/n).is_file():add(r/n,name+'/'+n)
r=b/'height-matrix-bx';q=json.loads(add(r/'height-runs/queue.json','height-matrix-bx/queue.json'));record['height']['queue']=q;rows=[]
for p in sorted((r/'height-runs').glob('*/report.json')):
    d=json.loads(add(p,'height-matrix-bx/'+p.relative_to(r).as_posix()));rows.append(dict(case=p.parent.name,metadata={k:d[k] for k in ['status','steps_completed','steps_requested','source_unchanged','seconds'] if k in d}))
for n in ['SOURCE_SHA256.json','dispatch.json','package.json','run_height_matrix_bx.py','run_height_queue_bx.py','height_matrix_bx.pbs','queue.log','receipt.json','pbs-exit.txt']:
    if (r/n).is_file():add(r/n,'height-matrix-bx/'+n)
record['height']['reports']=rows;p=subprocess.run(['qstat','-a'],capture_output=True,text=True);record['qstat']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);record['scope']='Read-only hash-bound liveEHPC metadata and originalreported generation snapshots. Originalcap1 and new.05 years distinct, all17520requests retained; no annualcompletion. HeightBO27 lockedliterature cases launchedPBS390, VIC/cold336, not Richards/spinup/multiyear/holdout/scienceacceptance. Eachreport copiedonce, preserve status/steps exactly; no numerical forward/metrics onlogin.';data['record.json']=(json.dumps(record,indent=2)+'\n').encode();data['control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/'ehpc-year-height-snapshot-cg-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in data.items():info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,years=record['years'],height_reports=rows,utc=record['utc'])),flush=True)

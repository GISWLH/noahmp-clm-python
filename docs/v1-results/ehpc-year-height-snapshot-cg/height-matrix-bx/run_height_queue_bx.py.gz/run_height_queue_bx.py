import concurrent.futures,json,os,subprocess,sys,threading,time,hashlib
from pathlib import Path
root=Path.cwd();out=Path('/home/zhangyq/noahmp-v1/height-matrix-bx/height-runs');out.mkdir(exist_ok=False)
source=root/'SOURCE_SHA256.json'; manifest=json.loads(source.read_text());assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in manifest.items())
cases=json.loads((root/'inputs/configs/cases.json').read_text())['cases'];order=[]
order.extend(x for x in cases if x['baseline'])
others={s:[c for c in cases if c['site']==s and not c['baseline']] for s in ('CN-Cng','CN-Qia','CN-Cha')}
for i in range(8):order.extend(others[s][i] for s in others)
report={'scope':'CurrentBO .05 NumPy all27 predeclared cold336 literatureheight cases, sameinput/config/VIC/baselines; no bestheight/date selection or spinup/multiyear/sciencepass','source_manifest_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'workers':6,'cases':{c['case']:{'status':'queued'} for c in order}}
lock=threading.Lock()
def save():
 t=out/'queue.json.tmp';t.write_text(json.dumps(report,indent=2)+'\n');os.replace(t,out/'queue.json')
def one(c):
 case=c['case'];site=c['site'];config=root/'inputs/configs'/c['configuration']
 assert hashlib.sha256(config.read_bytes()).hexdigest()==c['configuration_sha256']
 cmd=[sys.executable,'-u','benchmarks/run_fluxnet_column.py','--input',f'inputs/{site}.npz','--input-manifest',f'inputs/{site}.json','--config',str(config),'--output',str(out/case)]
 with (out/(case+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  with lock:report['cases'][case]={'status':'running','pid':p.pid,'baseline':c['baseline'],'command':cmd};save()
  code=p.wait()
 with lock:
  report['cases'][case].update(status='complete' if code==0 else 'failed',exit_code=code);save()
  print(json.dumps({'case':case,'exit_code':code}),flush=True)
 return code
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(one,order))
report['status']='complete' if all(x==0 for x in results) else 'finished_with_failures';save()
print(json.dumps({'status':report['status'],'cases':len(results),'failed':sum(x!=0 for x in results)}),flush=True)

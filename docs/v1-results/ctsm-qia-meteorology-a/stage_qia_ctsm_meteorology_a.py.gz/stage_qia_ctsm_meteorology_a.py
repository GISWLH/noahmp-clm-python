from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID');base=Path('/home/zhangyq/noahmp-v1');root=base/'ctsm-qia-meteorology-a';scratch=Path(os.environ['TMPDIR']).resolve()/'ctsm-qia-meteorology-a';scratch.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic();archive=base/'ctsm-portable-env-b.tar.gz';assert sha(archive)=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
prefix=scratch/'environment';prefix.mkdir()
with tarfile.open(archive) as t:t.extractall(prefix,filter='data')
env=os.environ.copy()
for k in ['PYTHONPATH','PYTHONHOME','LD_LIBRARY_PATH']:env.pop(k,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
child=r'''from pathlib import Path
from datetime import datetime,timedelta
import hashlib,json,math,os,xml.etree.ElementTree as ET
import numpy as np
from netCDF4 import Dataset
base=Path('/home/zhangyq/noahmp-v1');folder=base/'fluxnet-first-climate-cycle-20261017-h/inputs';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();config=folder/'CN-Qia-config.json';manifest=folder/'CN-Qia.json';path=folder/'CN-Qia.npz';c=json.loads(config.read_text());meta=json.loads(manifest.read_text());protocol=json.loads((base/'fluxnet-numpy-current-first-year-a/protocol.json').read_text());identity=[v for v in protocol['cases'] if v['case']=='CN-Qia-suction-climate-cycle'];assert len(identity)==1
for k,p in [('input',path),('input_manifest',manifest),('configuration',config)]:assert sha(p)==identity[0]['hashes'][k]
assert meta['forcing_columns']==['dt_s','tair_k','qair_kgkg','wind_ms','pressure_pa','swdown_wm2','lwdown_wm2','precipitation_m_s']
with np.load(path,allow_pickle=False) as z:data=dict(z)
forcing=data['forcing'];assert forcing.shape==(17520,8) and np.isfinite(forcing).all() and np.all(forcing[:,0]==1800)
geometry=c['most_geometry'];heights=[geometry[k] for k in ['temperature_height','humidity_height','wind_height']];assert heights==[39.6]*3
offset=float(meta['utc_offset_hours']);starts=[datetime.strptime(str(v),'%Y%m%d%H%M')-timedelta(hours=offset) for v in data['time_start']];ends=[datetime.strptime(str(v),'%Y%m%d%H%M')-timedelta(hours=offset) for v in data['time_end']];assert all((b-a).total_seconds()==1800 for a,b in zip(starts,ends)) and all(a==b for a,b in zip(ends[:-1],starts[1:])) and not any(t.month==2 and t.day==29 for t in starts)
epoch=starts[0];bounds=np.array([[(a-epoch).total_seconds()/3600,(b-epoch).total_seconds()/3600] for a,b in zip(starts,ends)],float);units='hours since '+epoch.strftime('%Y-%m-%d %H:%M:%S');time_values=bounds.mean(axis=1)
mapping={'TBOT':(1,1.,'K','tbot'),'QBOT':(2,1.,'kg kg-1','shum'),'WIND':(3,1.,'m s-1','wind'),'PSRF':(4,1.,'Pa','pbot'),'FSDS':(5,1.,'W m-2','swdn'),'FLDS':(6,1.,'W m-2','lwdn'),'PRECTmms':(7,1000.,'mm s-1','precn')}
definition=base/'ctsm-forcing-contract-a/selected-upstream/CTSM/cime/src/components/data_comps/datm/cime_config/namelist_definition_datm.xml';xml=ET.parse(definition).getroot();entries={n.get('id'):n for n in xml.findall('entry')};supported=' '.join((v.text or '') for e in entries.values() for v in e.findall('.//value'))
for name,(_,_,_,target) in mapping.items():assert any((v.text or '').split()[i:i+2]==[name,target] for e in entries.values() for v in e.findall('.//value') for i in range(max(0,len((v.text or '').split())-1)))
target=Path('CN-Qia.datm.2003.nc')
with Dataset(target,'w',format='NETCDF3_64BIT_OFFSET') as d:
    for name,size in [('time',None),('lat',1),('lon',1),('nbnd',2)]:d.createDimension(name,size)
    t=d.createVariable('time','f8',('time',));t.units=units;t.calendar='noleap';t.bounds='time_bounds';t[:]=time_values
    b=d.createVariable('time_bounds','f8',('time','nbnd'));b.units=units;b.calendar='noleap';b[:]=bounds
    for name,key,unit in [('lat','latitude','degrees_north'),('lon','longitude','degrees_east')]:v=d.createVariable(name,'f8',(name,));v.units=unit;v[:]=c[key]
    z=d.createVariable('ZBOT','f8',('time','lat','lon'));z.units='m';z[:]=39.6
    for name,(column,factor,unit,_) in mapping.items():v=d.createVariable(name,'f8',('time','lat','lon'));v.units=unit;v[:]=forcing[:,column,None,None]*factor
    co2=d.createVariable('CO2_PPM_AUXILIARY','f8',('time','lat','lon'));co2.units='ppm';co2[:]=data['environment'][:,0,None,None];co2.comment='Original background CO2 preserved; actual official CO2 stream or constant setting remains to be configured, this auxiliary is not silently mapped.'
    d.Conventions='CF-1.8';d.source_forcing_sha256=sha(path);d.source_manifest_sha256=sha(manifest);d.source_configuration_sha256=sha(config);d.time_semantics='UTC interval midpoints; exact original local standard intervals shifted by fixed +08 offset. Nearest interpolation/time boundary treatment must be checked in an actual DATM run before scientific comparison.'
    d.scope='Actual Qia meteorology serialization only. Domain/surface/PFT/soil/initial-state and aerosol/CO2 mapping, official model execution and science validation remain pending.'
errors={}
with Dataset(target) as d:
    np.testing.assert_array_equal(d['time'][:],time_values);np.testing.assert_array_equal(d['time_bounds'][:],bounds);np.testing.assert_array_equal(d['ZBOT'][:],np.full((17520,1,1),39.6));np.testing.assert_array_equal(d['CO2_PPM_AUXILIARY'][:,0,0],data['environment'][:,0])
    for name,(column,factor,_,_) in mapping.items():
        actual=np.asarray(d[name][:,0,0]);expected=forcing[:,column]*factor;np.testing.assert_array_equal(actual,expected);restored=actual/factor;error=float(np.max(np.abs(restored-forcing[:,column])));assert np.all(np.abs(restored-forcing[:,column])<=4*np.finfo(float).eps*np.maximum(np.abs(forcing[:,column]),np.finfo(float).tiny));errors[name]=dict(serialized_max_abs_difference=0.,restored_max_abs_difference=error,original_column=meta['forcing_columns'][column],scale=factor)
value=dict(scope='Actual locked CN-Qia17520 meteorology serialized and reopened exactly on PBS compute node, preserving raw input/config hashes, actual UTC conversion and all three39.6m heights. No official model output/reference science acceptance; no data outside original intervals or fabricated edge padding. DATM nearest alignment still needs actual run audit.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,steps=17520,first_utc=starts[0].isoformat(),end_utc_exclusive=ends[-1].isoformat(),time_units=units,calendar='noleap',original_utc_offset_hours=offset,measurement_heights=geometry,latitude=c['latitude'],longitude=c['longitude'],source_hashes={p.name:sha(p) for p in [path,manifest,config]},official_namelist_definition_sha256=sha(definition),field_mapping={name:v[3] for name,v in mapping.items()},numeric_roundtrip=errors,netcdf_sha256=sha(target),netcdf_bytes=target.stat().st_size,co2_original_min_max=[float(data['environment'][:,0].min()),float(data['environment'][:,0].max())],pending=['Matched single-point domain/surface/PFT/soil/initial-state','Aerosol and actual CO2 stream/constant settings','Generated CLM1PT stream/namelist and actual DATM interval-alignment audit','Official model run and paired physical error evaluation'])
Path('meteorology.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
'''
(scratch/'convert_qia.py').write_text(child);stages=[]
for label,command in [('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]),('convert-and-reopen',[str(prefix/'bin/python'),str(scratch/'convert_qia.py')])]:
    start=time.monotonic();p=subprocess.run(command,cwd=scratch,env=env,capture_output=True,text=True,timeout=180);(root/(label+'.stdout.txt')).write_text(p.stdout);(root/(label+'.stderr.txt')).write_text(p.stderr);stages.append(dict(stage=label,returncode=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,p.stderr
(root/'meteorology.json').write_bytes((scratch/'meteorology.json').read_bytes());(root/'execution.json').write_text(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,seconds=time.monotonic()-begun),indent=2)+'\n')
with tarfile.open(root/'meteorology-private.tar.gz','w:gz') as t:
    for name in ['CN-Qia.datm.2003.nc','meteorology.json','convert_qia.py']:t.add(scratch/name,arcname=name,recursive=False)
print(json.dumps(dict(stages=stages,seconds=time.monotonic()-begun,private_archive_sha256=sha(root/'meteorology-private.tar.gz'))),flush=True)

from pathlib import Path
import hashlib,json,subprocess,tarfile
base=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,folder in [('numpy-current-year-terminal-a','fluxnet-numpy-current-first-year-a'),('ctsm-qia-meteorology-a','ctsm-qia-meteorology-a')]:
    root=base/folder;paths=[]
    if name=='numpy-current-year-terminal-a':
        r=json.loads((root/'exit.json').read_text());assert r['status']=='failed' and r['source_unchanged']
        for row in r['cases']:assert sha(root/row['terminal_archive'])==row['terminal_archive_sha256'];paths.append((row['terminal_archive'],root/row['terminal_archive']))
        for n in ['exit.json','progress.json','protocol.json','launch.json','SOURCE_SHA256.json','run_numpy_current_first_year_a.py','numpy_current_first_year_a.pbs','numpy_snapshot_preserver_a.pbs','preserve_numpy_current_year_snapshots_a.py']: 
            if (root/n).exists():paths.append((n,root/n))
        paths += [(p.relative_to(root).as_posix(),p) for p in sorted((root/'snapshots').glob('*.json'))]
        for job in ['121.manager','123.manager']:
            p=root/(job+'-qstat-terminal.txt');p.write_text(subprocess.run(['qstat','-xf',job],capture_output=True,text=True).stdout);paths.append((p.name,p))
    else:
        assert (root/'pbs-exit.txt').read_text().strip()=='0'
        paths=[(p.name,p) for p in sorted(root.iterdir()) if p.is_file() and p.name!='meteorology-private.tar.gz']
        with tarfile.open(root/'meteorology-private.tar.gz') as t:
            p=root/'convert_qia.py';p.write_bytes(t.extractfile('convert_qia.py').read());paths.append((p.name,p))
    archive=base/(name+'-evidence.tar.gz');assert not archive.exists()
    with tarfile.open(archive,'w:gz') as t:
        for n,p in paths:t.add(p,arcname=n,recursive=False)
        t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
    print(json.dumps(dict(name=name,sha256=sha(archive),files=len(paths)+1,bytes=archive.stat().st_size)))

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=b/'bounded-transfers-ce';assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['analytic_checks']==20 and len(d['records'])==8 and all(q['all_stored_in_domain'] for q in d['records']);assert (b/'bounded-transfers-cc/pbs-exit.txt').read_text().strip()=='1';items=[(p,stem+'/'+p.relative_to(b/stem).as_posix()) for stem in ['bounded-transfers-cc','bounded-transfers-ce'] for p in sorted((b/stem).rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['dispatch_bounded_transfers_cc.py','dispatch_bounded_transfers_ce.py',Path(__file__).name]);a=b/'bounded-transfers-ce-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

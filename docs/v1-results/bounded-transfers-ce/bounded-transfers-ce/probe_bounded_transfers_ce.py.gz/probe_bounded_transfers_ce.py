"""Independent NumPy experiment, not installed into the model or an annual run."""
from pathlib import Path
import hashlib,json,math,os,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'bounded-transfers-ce';packet=Path(os.environ['TMPDIR'])/'packet';packet.mkdir();a=b/'richards-producer-bw-evidence.tar.gz';assert hashlib.sha256(a.read_bytes()).hexdigest()=='6d79dafb621e4bbefdd712f653cf2bc21b07d6111f11bda543cdef0c9171386d'
with tarfile.open(a) as tf:tf.extractall(packet,filter='data')

def water_from_faces(old,net):
    z=np.zeros(1,dtype=old.dtype)
    return (old+np.r_[z,net])-np.r_[net,z]

def bounded(old,capacity,net):
    """Reduce signed incoming/outgoing faces, preserving their direction.

    Capacity is the declared extensive capacity in the model precision.
    Promoted arithmetic detects sub-ULP overflow too; water is never clipped.
    """
    old,capacity,net=map(np.asarray,(old,capacity,net));assert old.ndim==1 and capacity.shape==old.shape and net.shape==(len(old)-1,) and old.dtype==capacity.dtype==net.dtype and old.dtype in (np.float32,np.float64)
    assert all(np.isfinite(v).all() for v in (old,capacity,net)) and np.all((old>=0)&(old<=capacity))
    face=net.copy();exact_old=old.astype(np.longdouble);exact_cap=capacity.astype(np.longdouble)
    for count in range(8*len(old)**2+1):
        exact=exact_old+np.r_[np.longdouble(0),face.astype(np.longdouble)]-np.r_[face.astype(np.longdouble),np.longdouble(0)]
        stored=water_from_faces(old,face);bad=np.flatnonzero((exact<0)|(exact>exact_cap)|(stored<0)|(stored>capacity))
        if not len(bad):return face,count
        i=int(bad[0]);wet=exact[i]>exact_cap[i] or stored[i]>capacity[i];excess=max(float(exact[i]-exact_cap[i]),float(stored[i]-capacity[i])) if wet else max(float(-exact[i]),float(-stored[i]))
        candidates=[]
        if i>0 and ((face[i-1]>0)==wet) and face[i-1]!=0:candidates.append(i-1)
        if i<len(face) and ((face[i]<0)==wet) and face[i]!=0:candidates.append(i)
        assert candidates,('No directed face can correct valid old state',i,old,face)
        j=max(candidates,key=lambda j:abs(float(face[j])));magnitude=abs(float(face[j]));target=max(magnitude-excess,0.);new=np.asarray(math.copysign(target,float(face[j])),dtype=face.dtype)
        if abs(float(new))>target or new==face[j]:new=np.nextafter(new,np.asarray(0.,dtype=face.dtype))
        assert abs(float(new))<magnitude and (new==0 or np.signbit(new)==np.signbit(face[j]));face[j]=new
    raise RuntimeError('Directed face correction failed to terminate')

start=time.monotonic();analytic=[]
cases=[([5,9],[10,10],[2],[1],[4,10]),([1,5],[10,10],[2],[1],[0,6]),([9,5],[10,10],[-2],[-1],[10,4]),([5,10,10],[10]*3,[2,2],[0,0],[5,10,10]),([0,0,5],[10]*3,[2,2],[0,0],[0,0,5]),([10,0,10],[10]*3,[-1,1],[0,0],[10,0,10]),([5,10,5],[10]*3,[1,-1],[0,0],[5,10,5]),([1,2,3],[10]*3,[.125,-.25],[.125,-.25],[.875,2.375,2.75]),([0],[1],[],[],[0])]
for dtype in (np.float32,np.float64):
    for k,(old,cap,net,expected,water) in enumerate(cases):
        old,cap,net,expected,water=[np.asarray(v,dtype=dtype) for v in (old,cap,net,expected,water)];fixed,count=bounded(old,cap,net);np.testing.assert_array_equal(fixed,expected);np.testing.assert_array_equal(water_from_faces(old,fixed),water);assert math.fsum(water)==math.fsum(old);analytic.append(dict(dtype=np.dtype(dtype).name,case=k,iterations=count))
    # Known donor heat: one kg returns to its donor; no water/heat projection.
    old=np.array([5.,9.],dtype);cap=np.array([10.,10.],dtype);net=np.array([2.],dtype);fixed,_=bounded(old,cap,net);h=np.array([2e6,3e6],dtype);parcel=np.array([340000.],dtype);before=np.array([1.32e6,3.68e6],dtype);after=water_from_faces(h,fixed*parcel);np.testing.assert_array_equal(after,np.array([1.66e6,3.34e6],dtype));assert math.fsum(after)==5e6 and np.all(after!=before)

records=[]
for label in ['capacity','capacity_optics']:
    p=packet/label
    with np.load(p/'producer-output.npz',allow_pickle=False) as z:out=dict(z)
    with np.load(p/'producer-before.npz',allow_pickle=False) as z:before=dict(z)
    stages=[]
    for path in sorted(p.glob('producer-flow-*.npz')):
        with np.load(path,allow_pickle=False) as z:d=dict(z)
        stages.append((path.name,d['water'][0],np.float32(1000.)*d['hydraulics'][0,:,0]*d['hydraulics'][0,:,1],d['out_interface_transfer_kg_m2'][0]))
    stages.append(('cumulative_heat',out['soil_hydrology/water_before_kg_m2'][0],np.float32(1000.)*out['after1'][0,:,2]*before['before2'][0,0],out['soil_hydrology/interface_transfer_kg_m2'][0]))
    for name,old,cap,net in stages:
        fixed,count=bounded(old,cap,net);water=water_from_faces(old,fixed);delta=net.astype(float)-fixed.astype(float);scale=max(float(abs(old).max()),float(cap.max()),1.);assert max(abs(delta),default=0.)<=8*np.finfo(old.dtype).eps*scale
        mass=math.fsum(water)-math.fsum(old);bound=32*np.finfo(old.dtype).eps*max(math.fsum(abs(water))+math.fsum(abs(old)),1.);assert abs(mass)<=bound
        records.append(dict(case=label,stage=name,old_water=old.tolist(),capacity=cap.tolist(),original_net=net.tolist(),limited_net=fixed.tolist(),removed_signed_transfer=delta.tolist(),stored_water=water.tolist(),all_stored_in_domain=bool(np.all((water>=0)&(water<=cap))),iterations=count,mass_residual=mass,original_mass_bound=float(bound)))
d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,analytic_checks=len(analytic)+2,analytic=analytic,records=records,scope='IndependentNumPy directedface-limiter prototype: analytic wet/dry/reverse/chain/unchanged/onecell and donorheat checks, actualunchangedBW rawflow/cumulativefaces. Declared extensivecapacities preserved, exactpromoted domain checked, no clipping/inputadjustment or mass/heat sink. Rawstate checks within originalmassbound and corrections below8epsscale. Not integratedproduction, not completeRichards/phase/annual/science validation.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

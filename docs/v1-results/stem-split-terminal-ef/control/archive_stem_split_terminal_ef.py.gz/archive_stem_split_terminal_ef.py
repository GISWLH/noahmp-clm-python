from pathlib import Path
import hashlib,json,re,tarfile,xml.etree.ElementTree as ET
b=Path('/home/lhwang/work/noahmp-v1');e=b/'p6-stem-split-e';f=b/'p6-stem-split-f';r=e/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'summary.json').read_text());g=json.loads((f/'target-a/summary.json').read_text());assert d['status']=='failed' and d['collected_nodes']==22 and d['source_unchanged'] and g['status']=='complete' and g['collected_nodes']==3 and g['source_unchanged'];rows=d['results'];assert rows[0]['receipt']['counts']==dict(tests=3,failures=1,errors=0,skipped=0)
for v in rows[1:]:assert v['passed'] and v['returncode']==v['receipt']['worker_exitcode']==v['receipt']['pytest_returncode']==0
me=json.loads((e/'SOURCE_SHA256.json').read_text());mf=json.loads((f/'SOURCE_SHA256.json').read_text());assert [n for n in me if me[n]!=mf[n]]==['tests/test_gpu_stem_column_precision.py'];assert all(sha(e/n)==v for n,v in me.items()) and all(sha(f/n)==v for n,v in mf.items())
def nodes(p):
 result=[(v.attrib['classname'],v.attrib['name']) for v in ET.parse(p).getroot().iter('testcase')];assert len(result)==len(set(result));return set(result)
original=nodes(r/'test_gpu_stem_column_precision.xml');current=nodes(f/'target-a/test_gpu_stem_column_precision.xml');assert len(original)==len(current)==3 and original==current;remaining=set()
for v in rows[1:]:remaining|=nodes(r/(Path(v['file']).stem+'.xml'))
assert len(remaining)==19 and len(remaining|current)==22 and not remaining&current
log=(r/'test_gpu_clm_structure_column.log').read_text();maximum={};precision=[]
for line in log.splitlines():
 m=re.search(r"native structure whole (\w+) <class 'numpy\.(float32|float64)'> (\{.*\})",line)
 if m:
  kind,dtype,payload=m.groups();v=json.loads(payload)
  for key,value in v['maximum_absolute'].items():maximum[dtype+'/'+key]=max(maximum.get(dtype+'/'+key,0.),value)
 m=re.search(r'structure whole same precision (\w+) ([\d.eE+\-]+)',line)
 if m:precision.append(dict(kind=m[1],maximum_absolute=float(m[2])))
assert precision and maximum
record=dict(scope='Frozen506E original22 terminal21pass1float64-input-failure preserved. E other19 real passed worker receipts plus exact same-node F3 passed after only test-input promotion normalization gives canonical22. All production/runtime bytes E/F identical, no skipped or renamed test; not a single E22pass or fullGPU/scientific/annual result. Interpreter atexit bypass remains disclosed in original receipts.',canonical_nodes=22,e_other_passed=19,f_regression_passed=3,source_e_manifest_sha256=sha(e/'SOURCE_SHA256.json'),source_f_manifest_sha256=sha(f/'SOURCE_SHA256.json'),numpy_reference_maximum_absolute=maximum,same_precision_reported=precision)
(r/'canonical-ef.json').write_text(json.dumps(record,indent=2)+'\n');a=b/'stem-split-terminal-ef-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname='e/'+p.name,recursive=False)
 for p in sorted((f/'target-a').iterdir()):
  if p.is_file():t.add(p,arcname='f/'+p.name,recursive=False)
 t.add(e/'SOURCE_SHA256.json',arcname='e/SOURCE_SHA256.json',recursive=False);t.add(f/'SOURCE_SHA256.json',arcname='f/SOURCE_SHA256.json',recursive=False);t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,canonical=record)))

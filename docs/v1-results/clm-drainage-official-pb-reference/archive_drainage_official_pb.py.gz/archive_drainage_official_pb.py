"""Actual-F closure of original-library PB reference calls; flat artifacts only."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname()=='manager'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
data={};records=[]
BASE=Path('/tmp/noahmp-clm-drainage-official-pb-c')
for label,suffix,job,code in [('a','','1608.manager',1),('b','-b','1609.manager',1),('c','-c','1610.manager',0)]:
    root=Path('/tmp/noahmp-clm-drainage-official-pb'+suffix)
    qstat=subprocess.check_output(['qstat','-xf',job]);text=qstat.decode()
    assert re.search(r'^\s*job_state = F\s*$',text,re.M)
    assert re.search(r'^\s*Stageout_status = 0\s*$',text,re.M)
    assert int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',text,re.M).group(1))==code
    for name in ['result.tar.gz','pbs-exit.txt','controller.log']:
        remote_hash=subprocess.check_output(['ssh','compute002','sha256sum',str(root/name)]).decode().split()[0]
        if not (root/name).exists():subprocess.run(['scp','compute002:'+str(root/name),str(root/name)],check=True)
        assert sha((root/name).read_bytes())==remote_hash
    assert int((root/'pbs-exit.txt').read_text())==code
    with tarfile.open(root/'result.tar.gz') as tar:
        members={m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
    receipt=json.loads(members['receipt.json'])
    assert receipt['pbs_job']==job and receipt['node']=='compute002' and receipt['passed']==(code==0)
    assert receipt['coupled_column_runs']==receipt['GPU_tasks']==0
    assert not receipt['official_implementation_changed'] and not receipt['official_stubs']
    if code==0:
        assert receipt['profiles']==3 and receipt['component_physics_runs']==6
        assert all(s['actual_parent_returncode']==0 for s in receipt['stages'])
        assert receipt['original_official_objects_unchanged'] and receipt['source_and_controls_unchanged']
        comparison=json.loads(members['comparison/comparisons.json'])
        assert comparison['execution_succeeded'] and len(comparison['profiles'])==3
    for name,raw in members.items():
        if name!='drainage_caller':data[label+'/'+name]=raw
    data[label+'/complete-result-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v),
        included=n!='drainage_caller') for n,v in members.items()},indent=2)+'\n').encode()
    data[label+'/actual-qstat.txt']=qstat
    for name in ['dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt',
        'compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt','controller.log']:
        data[label+'/scheduler/'+name]=(root/name).read_bytes()
    records.append(dict(label=label,pbs_job=job,actual_state='F',actual_exit=code,Stageout_status=0,
        original_complete_result_archive=str(root/'result.tar.gz'),original_complete_result_sha256=sha((root/'result.tar.gz').read_bytes()),
        original_result_members=len(members),omitted_executable_sha256=sha(members['drainage_caller']) if 'drainage_caller' in members else None,
        note='Compiled executable stays in original complete result archive; original library/toolchain/source are separate fixed artifacts. All controls, logs and comparison outputs are included.'))
data['closed-runs.json']=(json.dumps(records,indent=2)+'\n').encode()
data['CLM_DRAINAGE_OFFICIAL_PB.md']=(BASE/'CLM_DRAINAGE_OFFICIAL_PB.md').read_bytes()
data['archive_drainage_official_pb.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
target=BASE/'clm-drainage-official-pb-reference-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tar:
    for n,v in sorted(data.items()):
        info=tarfile.TarInfo(n);info.size=len(v);tar.addfile(info,io.BytesIO(v))
with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    actual_jobs=['1608:F1:Stageout0','1609:F1:Stageout0','1610:F0:Stageout0'],profiles=3,component_physics_runs=6,
    coupled_column_runs=0,physics_acceptance=False,original_implementation_unchanged=True,
    scope='Direct unchanged pinned libclm.a public diagnosis/drainage calls with real MPI/ESMF/CLM clock. Three matched 1800s synthetic profiles quantify the frozen PB prototype ice-weighting and perched donor differences, preserving first compile/clock failures. No correction-active, column, annual, site, GPU or full physical acceptance claim.')
(BASE/'clm-drainage-official-pb-reference-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

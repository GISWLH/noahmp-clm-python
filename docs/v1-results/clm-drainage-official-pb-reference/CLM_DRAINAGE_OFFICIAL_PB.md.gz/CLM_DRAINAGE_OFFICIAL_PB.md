# PB original official drainage comparison

EHPC compute002 actual terminal states: 1608 F1 / Stageout0 (caller kind-import
name), 1609 F1 / Stageout0 (missing ESMF initialization before the real CLM
clock), and 1610 F0 / Stageout0. The two failures preceded drainage calls.
The successful job linked the existing unchanged pinned official libraries;
no official physics implementation was copied, replaced, stubbed or rebuilt.
Compile 0.264097 s, matched comparison 0.614628 s, whole worker 15.420551 s.

The caller uses the existing build archive
`fff6b1645893854d8a8edc30be80b9be8b562a506eebe021b3a6fdd7d5604781`
and portable environment
`6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20`.
The official source is pinned CTSM commit
`fdfc03a0abec838ec0b66663a6a2f5e619cd2611`. Its unchanged compiled public
diagnosis and drainage routines operate on exactly the same initial liquid,
ice, temperature, geometry, porosity, retention and conductivity as frozen PB
`024a1246e2355e6f71107c815a0196ded544128215d2b99a5e503de99640f4d8`.

All three profiles use four 0.5 m layers, bedrock 2 m, slope 0.2 radians,
baseflow scalar .001 mm/s/m and one 1800 s interval. They are synthetic
component comparisons, with no station input, calibration, annual or GPU run.

| Profile | Official total outlet, kg/m2 | PB total outlet, kg/m2 | Actual evidence |
| --- | ---: | ---: | --- |
| Unfrozen connected | 0.547317095873416 | 0.546245372230211 | Same second-layer donor; total difference -0.195814% |
| Ice contrast, connected | 0.000556478343772 | 0.0000559566048962 | Same donor; absolute difference -0.000500521738875 kg/m2 |
| Frost perched | 0.000000200443450518 | 0.0000108845370210 | Official withdraws layer 3; PB withdraws layer 2 |

The small frozen/perched quantities are reported with absolute differences,
not treated as a near-zero relative-error acceptance gate. Their actual rate
weighting and donor mismatch nevertheless confirm structural differences
identified in source review. The third profile's official donor mass is
2.004434520586e-7 kg/m2 from layer 3; PB takes 1.088453702095e-5 kg/m2 from
layer 2. These must be addressed in the next isolated revision rather than
hidden by aggregate stock tolerances. No <=10% frozen/perched claim follows
from this diagnostic.

Initial main theta levels agree (0.5, 0.5, 2 m). The perched crossing is
0.695652150589487 m official versus 0.695652173913043 m PB. This roughly
2.33e-8 m difference does not warrant an old elementwise precision campaign.
PB's migrating front and diagnosed theta level remain distinct quantities.

All initial/after-perched/final WA, qcharge and surface-water values were zero.
Saturation-excess, ice-excess and qrgwl outlets were zero; ice masses were
unchanged and liquid stayed above the reserve. The declared no-correction
profile assertions passed. Official complete water residuals were
3.40838e-14, -3.87523e-14 and -1.54056e-15 kg/m2. Thus these measured
differences are not mixed with floor replenishment or excess-water routing.
This does not validate those correction-active regimes, which remain separate.

The official routines return no heat flux. The comparison independently
computes donor enthalpy as Mi*[Lf+cw*(Ti-Tf)] from the actual official donor
mass and matched initial donor temperature. It is not labelled an official
energy output. PB retains its own hard extensive water/enthalpy check.

Next: align main whole-layer ice weighting, perched adjacent-layer weighting,
perched supply-layer selection and its distinct specific-yield depth meaning;
retain PB's hard liquid and heat limits. Then repeat these immutable fixtures
and add bounded correction-active/step-refinement cases before JAX/CUDA or
column integration. The 1610 run is a successful reference measurement, not
completion of the physics gap.

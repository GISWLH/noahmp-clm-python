"""EHPC-only matched three-profile readout, original official calls versus frozen PB."""
from pathlib import Path
import json
import math
import os
import socket
import subprocess
import sys

assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
from noahmp_clm.physics.snowpack import LF, CW, TF
import saturated_drainage_pb as pb


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


root, executable = Path(sys.argv[1]), Path(sys.argv[2])
root.mkdir(exist_ok=False)
rows = []
profiles = [dict(name='unfrozen_connected', theta=[.45]*4, temperature=[285.,289.,293.,297.]),
            dict(name='ice_contrast_connected', theta=[.4]*4, temperature=[280.,270.,270.,270.]),
            dict(name='frost_perched_donor', theta=[.2,.43,.4,.2], temperature=[280.,280.,270.,280.])]
for profile in profiles:
    here = root / profile['name']; here.mkdir()
    p = SoilParams(); dz = np.full(4, .5); water = np.array(profile['theta']) * 1000. * dz
    t = np.array(profile['temperature'])
    soil = SoilEnthalpyState(water, enthalpy_and_capacity(water, t, dz, p)[0], dz, p)
    dt, slope = 1800, .2
    parameters = pb.DrainageParameters(2., slope)
    # Actual phase diagnosis defines identical official input stocks. No holdout/site data.
    lines = [f'{dt} {math.degrees(slope):.17g} {parameters.baseflow_mm_s_per_m:.17g}']
    for j in range(4):
        values = [dz[j], p.smcmax, p.bexp, p.saturated_suction_m*1000., p.satdk*1000.,
                  soil.liquid[j], soil.ice[j], soil.temperature[j]]
        lines.append(' '.join(format(float(v), '.17g') for v in values))
    fixture = here / 'fixture.txt'; fixture.write_text('\n'.join(lines)+'\n')
    result = subprocess.run([str(executable), str(fixture)], cwd=here, capture_output=True, timeout=30)
    (here / 'official.stdout.txt').write_bytes(result.stdout)
    (here / 'official.stderr.txt').write_bytes(result.stderr)
    save(here / 'official-exit.json', dict(actual_parent_returncode=result.returncode))
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    official = {}
    for line in result.stdout.decode().splitlines():
        if line.startswith('PB_OFFICIAL_'):
            parts = line.split(); official[parts[0].removeprefix('PB_OFFICIAL_')] = np.array([float(v) for v in parts[1:]])
    assert set(official) == {'DIAG','INITIAL_LIQ','INITIAL_ICE','PERCHED','AFTER_PERCH_LIQ',
        'AFTER_PERCH_ICE','MAIN','FINAL_LIQ','FINAL_ICE','OTHER','INITIAL_OTHER','AFTER_PERCH_OTHER'}
    np.testing.assert_array_equal(official['INITIAL_LIQ'], soil.liquid)
    np.testing.assert_array_equal(official['INITIAL_ICE'], soil.ice)
    assert all(np.all(np.isfinite(v)) for v in official.values())
    # These first three profiles intentionally have no floor/excess correction.
    # Do not infer donor exports from a profile in which another stock changes.
    np.testing.assert_array_equal(official['INITIAL_OTHER'], official['AFTER_PERCH_OTHER'])
    np.testing.assert_array_equal(official['INITIAL_OTHER'], official['OTHER'][:3])
    assert np.max(abs(official['OTHER'][3:])) < 1.e-12
    np.testing.assert_array_equal(official['INITIAL_ICE'], official['FINAL_ICE'])
    assert np.min(official['FINAL_LIQ']) > .01
    after, diagnostics = pb.drain_saturated_soil(soil, dt, parameters)
    orig_perch = official['INITIAL_LIQ']-official['AFTER_PERCH_LIQ']
    orig_main = official['AFTER_PERCH_LIQ']-official['FINAL_LIQ']
    specific_heat = LF + CW*(soil.temperature-TF)
    row = dict(name=profile['name'], dt_seconds=dt, official_parent_returncode=0,
        initial_liquid_kg_m2=soil.liquid.tolist(), initial_ice_kg_m2=soil.ice.tolist(),
        temperature_k=soil.temperature.tolist(), official={k:v.tolist() for k,v in official.items()},
        official_perched_layer_mass_kg_m2=orig_perch.tolist(), official_main_layer_mass_kg_m2=orig_main.tolist(),
        official_other_fields=['surface_water_kg_m2','aquifer_water_kg_m2','qcharge_kg_m2_s',
            'saturation_excess_kg_m2_s','ice_excess_runoff_kg_m2_s','qrgwl_kg_m2_s'],
        initial_other_fields=['surface_water_kg_m2','aquifer_water_kg_m2','qcharge_kg_m2_s'],
        official_floor_excess_correction_inactive=True,
        official_water_budget_residual_kg_m2=float(
            official['FINAL_LIQ'].sum()+official['FINAL_ICE'].sum()+official['OTHER'][:2].sum()
            -official['INITIAL_LIQ'].sum()-official['INITIAL_ICE'].sum()-official['INITIAL_OTHER'][:2].sum()
            +dt*(official['PERCHED'][0]+official['MAIN'][0]+official['OTHER'][4]+official['OTHER'][5])),
        official_perched_donor_enthalpy_j_m2=(orig_perch*specific_heat).tolist(),
        official_main_donor_enthalpy_j_m2=(orig_main*specific_heat).tolist(),
        heat_reference='Independent Mi*(Lf+cw*(Ti-Tf)) using official donor mass and matched donor temperature; official routine does not return energy.',
        pb_main_theta_m=diagnostics['diagnosis_before']['water_table_m'],
        pb_perched_theta_m=diagnostics['diagnosis_before']['perched_water_table_m'],
        pb_frost_m=diagnostics['diagnosis_before']['frost_table_m'],
        pb_total_layer_mass_kg_m2=diagnostics['layer_mass_kg_m2'].tolist(),
        pb_total_layer_enthalpy_j_m2=diagnostics['layer_enthalpy_j_m2'].tolist(),
        pb_final_water_kg_m2=after.water.tolist(),
        pb_water_residual_kg_m2=diagnostics['water_residual_kg_m2'],
        pb_water_bound_kg_m2=diagnostics['water_bound_kg_m2'],
        pb_energy_residual_j_m2=diagnostics['energy_residual_j_m2'],
        pb_energy_bound_j_m2=diagnostics['energy_bound_j_m2'],
        pb_bands=[])
    for band in diagnostics['bands']:
        old = orig_perch if band['kind']=='perched' else orig_main
        official_q = float(official['PERCHED' if band['kind']=='perched' else 'MAIN'][0])
        final_water = (official['AFTER_PERCH_LIQ']+official['AFTER_PERCH_ICE'] if band['kind']=='perched'
                       else official['FINAL_LIQ']+official['FINAL_ICE'])
        row['pb_bands'].append(dict(kind=band['kind'], mass_kg_m2=band['layer_mass_kg_m2'].tolist(),
            heat_j_m2=band['layer_enthalpy_j_m2'].tolist(), initial_front_m=band['initial_front_m'],
            migrated_front_m=band['migrated_front_m'], total_kg_m2=band['drained_kg_m2'],
            official_reported_outflow_kg_m2=official_q*dt, official_final_water=final_water.tolist(),
            difference_layer_mass_kg_m2=(band['layer_mass_kg_m2']-old).tolist(),
            total_relative_difference=None if abs(official_q*dt)<1.e-12 else band['drained_kg_m2']/(official_q*dt)-1.,
            official_mass_balance_residual_kg_m2=float(old.sum())-official_q*dt))
    save(here / 'comparison.json', row); rows.append(row)
save(root / 'comparisons.json', dict(execution_succeeded=True, profiles=rows, component_physics_runs=6,
    coupled_column_runs=0, production_changes=False, all_official_calls_unmodified=True,
    physical_acceptance=False, scope='Three matched one-step profiles; disclose prototype ice weighting/donor-layer differences before revision, not a completed hydrology acceptance.'))
print(json.dumps(dict(execution_succeeded=True, profiles=3, component_physics_runs=6, coupled_column_runs=0)))

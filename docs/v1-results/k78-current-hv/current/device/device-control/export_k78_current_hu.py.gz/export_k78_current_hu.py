from pathlib import Path
import hashlib
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'k78-current-hu'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
launch = json.loads((r / 'launch.json').read_text())
assert all(sha(b / n) == v for n, v in launch['controls_sha256'].items())
assert json.loads((r / 'exit.json').read_text())['workers']
for name in ['cuda32', 'jax32']:
    exit = json.loads((r / (name + '-exit.json')).read_text())
    d = json.loads((r / name / 'receipt.json').read_text())
    assert exit['actual_returncode'] == 0 and sha(r / name / 'receipt.json') == exit['receipt_sha256']
    assert d['failure'] is None and d['source_unchanged'] and len(d['device_barriers']) == 1
    assert sha(r / name / 'output.npz') == d['result']['output_sha256']
    assert d['source_manifest_sha256'] == launch['source_manifest_sha256']
a = b / 'k78-current-hu-device-export.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():
            t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    for n in [*launch['controls_sha256'], Path(__file__).name]:
        t.add(b / n, arcname='device-control/' + n, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size,
                      scope='Actual currentFL579 bothGPU exports/barriers/worker0 only; independent allraw1e-6 and original MHCN/impurity gates still pending EHPC PBS. No original failed trajectory advanced.')))

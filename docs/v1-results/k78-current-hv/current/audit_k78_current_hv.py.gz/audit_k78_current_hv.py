from pathlib import Path
import hashlib
import json
import os
import re
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'k78-current-hv'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = b / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(source) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(source) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert sha(s/'SOURCE_SHA256.json')=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert len(m) == 579 and all(sha(s / n) == v for n, v in m.items())
packet = b / 'k78-current-hu-device-export.tar.gz'
metadata = json.loads((r / 'packet.json').read_text())
assert sha(packet) == metadata['sha256']
with tarfile.open(packet) as t:
    t.extractall(r / 'device', filter='data')
d = r / 'device'
assert (d / 'SOURCE_SHA256.json').read_bytes() == (s / 'SOURCE_SHA256.json').read_bytes()
assert sha(d / 'input.npz') == '957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

with np.load(d / 'input.npz', allow_pickle=False) as z:
    inputs = dict(z)
exports, budgets = {}, {}
errors = []
for name, prefix in [('cuda32', 'a'), ('jax32', 'shadow')]:
    receipt = json.loads((d / name / 'receipt.json').read_text())
    exit = json.loads((d / (name + '-exit.json')).read_text())
    assert exit['actual_returncode'] == 0 and receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barriers']
    assert sha(d / name / 'receipt.json') == exit['receipt_sha256']
    assert sha(d / name / 'output.npz') == receipt['result']['output_sha256']
    with np.load(d / name / 'output.npz', allow_pickle=False) as z:
        fields = dict(z)
    before = tuple(fields['before' + str(k)] for k in range(16))
    after = tuple(fields['next' + str(k)] for k in range(16))
    for k in range(16):
        expected = inputs[prefix + str(k)].copy()
        if k == 4:
            expected[:, 7:10] = inputs['environment']
        assert before[k].dtype == expected.dtype and before[k].shape == expected.shape and before[k].tobytes() == expected.tobytes(), (name, k)
    result = {}
    for key, value in fields.items():
        if re.fullmatch(r'(?:before|next)\d+', key):
            continue
        parts = key.split('/')
        one = result
        for part in parts[:-1]:
            one = one.setdefault(part, {})
        one[parts[-1]] = value
    try:
        incoming, residual, bound, tracer = driver.audit_step(before, after, inputs['forcing'], inputs['deposition'], inputs['nitrogen'], result)
        budgets[name] = dict(passed=True, residual_m_h_c_n=residual.tolist(), original_bounds=bound.tolist(), impurity_absolute_residual=tracer.tolist())
    except Exception as e:
        budgets[name] = dict(passed=False, failure=type(e).__name__ + ': ' + str(e))
        errors.append('Original independent MHCN/impurity audit failed: ' + name)
    exports[name] = fields
assert exports['cuda32'].keys() == exports['jax32'].keys()
rows = []
for name in exports['cuda32']:
    x, y = exports['cuda32'][name], exports['jax32'][name]
    assert x.shape == y.shape
    integer = x.dtype.kind in 'ibu'
    dtype_match = x.dtype == y.dtype
    finite = bool(np.all(np.isfinite(x)) and np.all(np.isfinite(y)))
    raw_difference = abs(x.astype(float) - y.astype(float))
    maximum = float(np.max(raw_difference)) if raw_difference.size else 0.
    equal = bool(x.dtype == y.dtype and x.tobytes() == y.tobytes())
    before_field = bool(re.fullmatch(r'before\d+', name))
    passed = dtype_match and (equal if integer or before_field else finite and x.dtype == np.dtype('float32') and bool(np.allclose(x, y, rtol=1e-6, atol=1e-6)))
    row = dict(field=name, dtype_cuda=str(x.dtype), dtype_jax=str(y.dtype), maximum_absolute=maximum, bitwise_equal=equal, passed=bool(passed), before_input_only=before_field)
    if maximum:
        index = np.unravel_index(np.argmax(raw_difference), raw_difference.shape)
        row.update(index=list(map(int, index)), cuda=float(x[index]), jax=float(y[index]))
    rows.append(row)
    if not passed:
        errors.append('Raw sameprecision gate failed: ' + name)
model_rows = [v for v in rows if not v['before_input_only']]
failed = [v for v in rows if not v['passed']]
record = dict(scope='Actual currentFL579 original K78 whole-step replay on xuanze,then independent original production MHCN/impurity audit and every raw output/next16 field rtol=atol1e-6,int exact,float32/dtype validation on EHPC PBS. Primary/shadow original16 inputs independently verified exact. No original failed trajectory advancement or source/physics/gate change; not full-suite/year/science acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=not errors, errors=errors, budgets=budgets,
              raw_model_and_next_fields=len(model_rows), additional_before_arrays=16,
              maximum_absolute_difference=max(v['maximum_absolute'] for v in model_rows), fields=rows, failed=failed,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == v for n, v in m.items()),
              device_export_sha256=sha(packet), original_input_sha256=sha(d / 'input.npz'))
(r / 'audit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: record[k] for k in ['pbs_job', 'passed', 'errors', 'raw_model_and_next_fields', 'maximum_absolute_difference', 'failed', 'budgets']}), flush=True)
raise SystemExit(0 if not errors and record['source_unchanged'] else 1)

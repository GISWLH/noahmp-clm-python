from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-current-hv';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
packet=b/'k78-current-hu-device-export.tar.gz';expected=sys.argv[1]
assert sha(packet)==expected and not r.exists()
with tarfile.open(packet) as tf:
 launch=json.load(tf.extractfile('launch.json'));parent=json.load(tf.extractfile('exit.json'))
 assert len(parent['workers'])==2 and all(q['actual_returncode']==0 for q in parent['workers'])
 assert launch['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
 for name in ['cuda32','jax32']:
  raw=tf.extractfile(name+'/receipt.json').read();d=json.loads(raw);e=json.load(tf.extractfile(name+'-exit.json'))
  assert e['actual_returncode']==0 and hashlib.sha256(raw).hexdigest()==e['receipt_sha256']
  assert d['failure'] is None and d['source_unchanged'] and d['device_barriers'] and d['source_manifest_sha256']==launch['source_manifest_sha256']
r.mkdir();controls={}
for name in ['audit_k78_current_hv.py','audit_k78_current_hv.pbs']:
 raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
(r/'packet.json').write_text(json.dumps(dict(sha256=expected,archive=packet.name,source_manifest_sha256=launch['source_manifest_sha256']),indent=2)+'\n')
p=subprocess.run(['qsub',str(r/'audit_k78_current_hv.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,packet_sha256=expected,scope='CurrentFL579 afteractualbothGPUworkers0/barriers/exports: originalraw329field1e-6/int/dtype plus16beforeexact and independentMHCN/impurity acceptance on PBScompute. Device0 aloneisnotacceptance. No trajectoryadvance/source/gate change.')
(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

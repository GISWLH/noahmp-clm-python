"""Read only exact EHPC NumPy references; original tests and assertions retained."""
from pathlib import Path
import copy,hashlib,json,pickle,runpy,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-descent-ee-gpu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==571 and all(sha(s/n)==h for n,h in m.items());ref=r/'reference-evidence/references';receipt=json.loads((ref/'receipt.json').read_text());assert (ref/'pbs-exit.txt').read_text().strip()=='0' and receipt['failure'] is None and receipt['source_unchanged'] and receipt['keys']==104 and receipt['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json');assert sha(ref/'references.pkl')==receipt['reference_pickle_sha256'] and sha(r/'phase_reference_key_dw.py')==receipt['key_helper_sha256'];sys.path.insert(0,str(r))
from phase_reference_key_dw import reference_key
cache=pickle.loads((ref/'references.pkl').read_bytes());assert len(cache)==104;file=Path(sys.argv[sys.argv.index('--test-file')+1]).stem
binding=dict(source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cache_sha256=sha(ref/'references.pkl'),reference_receipt_sha256=sha(ref/'receipt.json'),matching_source_files=571,scope='Exactdtype/shape/inputbytes/parameters/extension/actualsignaturecontrols cachelookup only. Missingkey fails, no NumPyforward fallback. Originalpytestnodes/assertions unchanged; packing and independentbudget audits retained.');(r/(file+'-oracle-binding.json')).write_text(json.dumps(binding,indent=2)+'\n')
def lookup(family,row,kwargs):
    key=reference_key(family,tuple(row),kwargs);assert key in cache,(family,key)
    with (r/(file+'-oracle-requests.jsonl')).open('a') as stream:stream.write(json.dumps(dict(family=family,key=key))+'\n')
    return copy.deepcopy(cache[key])
def blocked(*args,**kwargs):raise AssertionError('NumPyforward references must run onEHPCcompute, never here')
if file=='test_gpu_canopy_phase_energy':
    import test_gpu_canopy_phase_energy as module
    module.reference=lambda row,**kwargs:lookup('phase',row,kwargs);module.solve_canopy_phase_energy=blocked
elif file=='test_gpu_canopy_phase_surface':
    import test_gpu_canopy_phase_surface as module
    module.reference=lambda row:lookup('surface',row,{});module.surface_step=blocked
else:raise AssertionError(file)
import noahmp_clm.physics.canopy_phase_energy as phase
import noahmp_clm.physics.canopy_column as column
phase.solve_canopy_phase_energy=blocked;column.surface_step=blocked
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';runpy.run_path(str(worker),run_name='__main__')

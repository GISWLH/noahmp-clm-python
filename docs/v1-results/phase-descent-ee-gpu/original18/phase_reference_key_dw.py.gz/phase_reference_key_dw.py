"""Exact argument keys, with original production defaults captured before guards."""
import dataclasses,hashlib,json
from inspect import signature
import numpy as np
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
_DEFAULTS=signature(solve_canopy_phase_energy).parameters
_TOLERANCE=_DEFAULTS['tolerance'].default
_MAX_ITERATIONS=_DEFAULTS['max_iterations'].default


def reference_key(family,row,kwargs=None):
    h=hashlib.sha256();h.update(family.encode());kwargs=dict(kwargs or {})
    def array(value):
        a=np.asarray(value);h.update(a.dtype.str.encode());h.update(json.dumps(a.shape).encode());h.update(np.ascontiguousarray(a).tobytes())
    for value in row:array(value)
    if family=='phase':
        from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
        p=kwargs.pop('leaf_parameters',None);array(pack_leaf_parameters(dtype=row[0].dtype).astype(float) if p is None else np.asarray(dataclasses.astuple(p),float));extension=kwargs.pop('exchange_extension',None);h.update(b'none' if extension is None else b'extension')
        if extension is not None:array(np.asarray(extension,float))
        kwargs['tolerance']=kwargs.get('tolerance',_TOLERANCE);kwargs['max_iterations']=kwargs.get('max_iterations',_MAX_ITERATIONS)
    h.update(json.dumps(kwargs,sort_keys=True,allow_nan=False).encode());return h.hexdigest()

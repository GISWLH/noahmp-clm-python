from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-descent-ee-gpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'exit.json').read_text());assert d['passed'] and d['returncode']==0 and d['source_unchanged'] and d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and len(d['records'])==2
for row,count in zip(d['records'],[14,4]):
    stem=Path(row['file']).stem;p=r/(stem+'-receipt.json');q=json.loads(p.read_text());assert row['passed'] and row['actual_parent_returncode']==0 and row['receipt_sha256']==sha(p) and q['counts']==dict(tests=count,failures=0,errors=0,skipped=0) and q['source_unchanged'] and q['all_setup_call_teardown_phases_passed'] and q['node_coverage_exact'] and sha(r/(stem+'.xml'))==q['xml_sha256']
items=[(p,'original18/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.append((b/Path(__file__).name,'control/'+Path(__file__).name));a=b/'phase-descent-ee-gpu-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

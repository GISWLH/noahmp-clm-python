from pathlib import Path
import hashlib,json,gzip
import numpy as np
source=Path('outputs/v1/p5-glacier-year-f.json')
r=json.loads(source.read_text(encoding='utf-8'));assert r['status']=='complete' and r['steps_completed']==1460
report=dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    scope='Postprocess the completed F synthetic non-leap year. Fluxes/amounts only; no observations or monthly state-mean claim.',
    calendar_month_lengths=[31,28,31,30,31,30,31,31,30,31,30,31],backends={})
cuts=np.r_[0,np.cumsum(report['calendar_month_lengths'])]
for name in ('jax64','jax32','cuda32'):
    records=[]
    for month,(a,b) in enumerate(zip(cuts[:-1],cuts[1:]),1):
        fields={}
        for key in ('et_mm','runoff_mm','h','le','rnet'):
            ref=np.array([v[key] for v in r['daily']['numpy64'][a:b]],float)
            val=np.array([v[key] for v in r['daily'][name][a:b]],float)
            meanref=float(ref.mean());meanval=float(val.mean());bias=meanval-meanref
            amount=key.endswith('_mm');atol=.05 if amount else 1.;cutoff=.5 if amount else 10.
            nearzero=abs(meanref)<=cutoff;limit=atol if nearzero else .1*abs(meanref)
            assert abs(bias)<=limit
            fields[key]=dict(reference_daily_equivalent=meanref,model_daily_equivalent=meanval,
                signed_bias_daily_equivalent=bias,absolute_error_daily_equivalent=abs(bias),
                signed_relative_bias_percent=None if nearzero else 100.*bias/abs(meanref),
                near_zero=nearzero,absolute_limit_daily_equivalent=limit,
                reference_monthly_total=float(ref.sum())*(1. if amount else 86400.),
                model_monthly_total=float(val.sum())*(1. if amount else 86400.),
                daily_equivalent_unit='mm/day' if amount else 'W/m2',
                monthly_total_unit='mm' if amount else 'J/m2')
        records.append(dict(month=month,days=int(b-a),fields=fields))
    report['backends'][name]=records
out=Path('docs/v1-results/p5-glacier-year-f-monthly.json.gz')
report['instrument_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
out.write_bytes(gzip.compress((json.dumps(report,indent=2)+'\n').encode(),mtime=0))
for key in ('et_mm','runoff_mm','h','le','rnet'):
    values=[v['fields'][key] for v in report['backends']['jax32']]
    print(key,'max absolute daily-equivalent',max(v['absolute_error_daily_equivalent'] for v in values),
          'max non-nearzero abs bias percent',max((abs(v['signed_relative_bias_percent']) for v in values if v['signed_relative_bias_percent'] is not None),default=None))

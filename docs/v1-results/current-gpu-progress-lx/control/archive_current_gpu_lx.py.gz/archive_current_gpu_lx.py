"""Export only terminal GPU file sessions and allowlisted live metadata."""
from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-jo-full-gpu';sha=lambda raw:hashlib.sha256(raw).hexdigest();payload={}
progress=json.loads((r/'progress.json').read_text());launch=json.loads((r/'launch.json').read_text());source=Path(json.loads((r/'source-location.json').read_text())['source']);m=json.loads((source/'SOURCE_SHA256.json').read_text());manifest=sha((source/'SOURCE_SHA256.json').read_bytes())
assert manifest==launch['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and len(m)==581 and all(sha((source/n).read_bytes())==h for n,h in m.items())
for n,h in launch['controls_sha256'].items():
    raw=(r/n).read_bytes();assert sha(raw)==h;payload['control/'+n]=raw
for name in ['SOURCE_SHA256.json','package.json','source-location.json','launch.json','collection.json','collection-exit.json','inheritance-proof.json','execution-plan.json']:
    payload['gpu/'+name]=(r/name).read_bytes()
payload['gpu/progress-at-snapshot.json']=(json.dumps(progress,indent=2)+'\n').encode()
for row in progress['records']:
    stem=Path(row['file']).stem;receipt=(r/(stem+'-receipt.json')).read_bytes();d=json.loads(receipt)
    assert sha(receipt)==row['receipt_sha256'] and d['source_manifest_sha256']==manifest and d['source_unchanged']
    assert sha((r/(stem+'.xml')).read_bytes())==d['xml_sha256']
    assert sha((r/(stem+'-expected.json')).read_bytes())==d['expected_nodes_sha256']
    if row['passed']:
        assert row['actual_parent_returncode']==d['pytest_returncode']==d['worker_exitcode']==0 and d['passed'] and d['node_coverage_exact'] and d['all_setup_call_teardown_phases_passed']
        assert d['counts']==dict(tests=row['expected_tests'],failures=0,errors=0,skipped=0)
        assert all(x['status']=='complete' for x in d['device_barriers'])
    for suffix in ['-receipt.json','-exit.json','-expected.json','.xml','.log']:
        payload['gpu/completed/'+stem+suffix]=(r/(stem+suffix)).read_bytes()
def process(pid):
    p=Path('/proc')/str(pid);env=dict(x.split('=',1) for x in (p/'environ').read_bytes().decode().split('\0') if '=' in x)
    assert env['CUDA_VISIBLE_DEVICES']=='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
    return dict(pid=pid,observed_live=True,command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),selected_nonsecret_environment={k:env.get(k) for k in ['CUDA_VISIBLE_DEVICES','JAX_PLATFORMS','JAX_ENABLE_X64','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']})
live=[process(launch['pid']),process(progress['pid'])]
for name,pid in [('ballberry-climatology-cuda-jt',3150299),('qia-phase-capacity_optics-cuda-year-ej',3042732)]:
    raw=(b/name/'trajectory/batch.json').read_bytes();d=json.loads(raw);payload['years/'+name+'-batch-at-snapshot.json']=raw
    live.append(dict(**process(pid),trajectory=name,steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],status=d['status'],seconds=d['seconds'],source_manifest_sha256=d.get('source_manifest_sha256')))
passed=sum(x['expected_tests'] for x in progress['records'] if x['passed'])+sum(x['tests'] for x in progress['reused'] if x['passed'])
snap=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),current_source_manifest_sha256=manifest,completed_passed_tests=passed,canonical_gpu_tests=407,completed_current_files=len(progress['records']),failed_files=[x['file'] for x in progress['records'] if not x['passed']],active_file=progress['file'],live=live,physical_gpu1=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=uuid,memory.used,memory.total,utilization.gpu','--format=csv,noheader'],text=True).strip(),
    scope='CurrentJN GPU407 stillinprogress: onlyterminaloriginalfile sessions exported withactualparent/pytest/phases/XML/source/dtype/integer/originalgates/barriers, inheritedIV37 originunchanged withall566byteproof. Allobservedworkers physicalCUDA1. Bothyear snapshots retain ownsource identities andincompletestatus; no full407/1563/year/spinup/observational/science/releasepass.')
payload['snapshot.json']=(json.dumps(snap,indent=2)+'\n').encode();payload['control/'+Path(__file__).name]=Path(__file__).read_bytes()
target=b/'current-gpu-progress-lx-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):
        member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
value=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),completed_passed_tests=passed,active_file=progress['file'],scope=snap['scope'])
(b/'current-gpu-progress-lx-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

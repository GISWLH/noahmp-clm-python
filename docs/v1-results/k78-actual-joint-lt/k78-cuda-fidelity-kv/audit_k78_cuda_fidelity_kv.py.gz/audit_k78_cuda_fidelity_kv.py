"""PBS bitwise noninterference proof before interpreting private operands."""
from pathlib import Path
import hashlib,json,os,re,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-cuda-fidelity-kv';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();archive=b/'clm-ballberry-jn-source.tar.gz';assert sha(archive)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from noahmp_clm.gpu.canopy_phase_surface import unpack_phase_surface
metadata=json.loads((r/'packet.json').read_text());packet=b/metadata['archive'];assert sha(packet)==metadata['sha256'];device=tmp/'device';device.mkdir()
with tarfile.open(packet) as tf:tf.extractall(device,filter='data')
meta=json.loads((device/'instrumentation.json').read_text());assert meta['parent_JN_manifest_sha256']==manifest and (device/'PARENT_SOURCE_SHA256.json').read_bytes()==(s/'SOURCE_SHA256.json').read_bytes();derived=json.loads((device/'INSTRUMENTED_SHA256.json').read_text());assert len(derived)==581 and sha(device/'INSTRUMENTED_SHA256.json')==meta['derived_manifest_sha256'];assert {n for n in m if m[n]!=derived[n]}==set(meta['changes']) and len(meta['changes'])==5
for n,change in meta['changes'].items():assert change['before_sha256']==m[n] and change['after_sha256']==derived[n]==sha(device/'instrumented-source'/n)
assert sha(device/'input.npz')==meta['input_sha256']=='957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
receipt=json.loads((device/'cuda32/receipt.json').read_text());parent=json.loads((device/'cuda32-exit.json').read_text());old=json.loads((device/'baseline/cuda32/receipt.json').read_text());assert parent['passed'] and parent['actual_parent_returncode']==0 and parent['receipt_sha256']==sha(device/'cuda32/receipt.json') and receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barriers'];assert sha(device/'cuda32/output.npz')==receipt['result']['output_sha256'] and sha(device/'baseline/cuda32/output.npz')==old['result']['output_sha256'] and old['source_manifest_sha256']==manifest and old['source_unchanged'] and old['failure'] is None
with np.load(device/'cuda32/output.npz',allow_pickle=False) as z:actual=dict(z)
with np.load(device/'baseline/cuda32/output.npz',allow_pickle=False) as z:original=dict(z)
assert actual.keys()==original.keys() and len(actual)==345;rows=[]
for name in original:
    x,y=actual[name],original[name];equal=x.shape==y.shape and x.dtype==y.dtype and x.tobytes()==y.tobytes();row=dict(field=name,bitwise_equal=bool(equal),dtype_original=str(y.dtype),dtype_instrumented=str(x.dtype),shape_original=list(y.shape),shape_instrumented=list(x.shape))
    if x.shape==y.shape and x.size:
        diff=abs(x.astype(float)-y.astype(float));row['maximum_absolute_difference']=float(diff.max())
        if diff.max()>0:
            index=np.unravel_index(diff.argmax(),diff.shape);row.update(index=list(map(int,index)),original=float(y[index]),instrumented=float(x[index]))
    rows.append(row)
equal=all(x['bitwise_equal'] for x in rows);out={}
for name,value in actual.items():
    if re.fullmatch(r'(?:before|next)\d+',name):continue
    parts=name.split('/');target=out
    for part in parts[:-1]:target=target.setdefault(part,{})
    target[parts[-1]]=value
with np.load(device/'input.npz',allow_pickle=False) as z:inputs=dict(z)
budget=None;errors=[]
try:
    checked=native.audit_step(tuple(actual['before'+str(k)] for k in range(16)),tuple(actual['next'+str(k)] for k in range(16)),inputs['forcing'],inputs['deposition'],inputs['nitrogen'],out)
    budget=dict(passed=True,residual_m_h_c_n=checked[1].tolist(),original_bounds=checked[2].tolist(),impurity_residual=checked[3].tolist())
except Exception as e:budget=dict(passed=False,failure=type(e).__name__+': '+str(e));errors.append('OriginalindependentMHCN/impurity audit failed')
association=[]
if not equal:errors.append('Instrumentation changed original345 outputs; auxiliary inputs NOT trusted')
else:
    assert sha(device/'cuda32/phase-surface-captures.npz')==receipt['result']['captures_sha256']
    with np.load(device/'cuda32/phase-surface-captures.npz',allow_pickle=False) as z:captures=dict(z)
    assert len(captures)==receipt['result']['captured_surface_calls']
    keys=['thermal_snow_cells','thermal_snow_counts','thermal_soil_cells','thermal_temperature_offset','thermal_layer_residual','thermal_layer_tolerance','surface_temperature','surface_temperature_residual','surface_root_bracket_k','surface_evaluations','snow_cells','snow_counts','soil_cells','condensate']
    decoded={}
    for name,raw in captures.items():
        assert raw.dtype==np.dtype('float32') and raw.shape==(4,796) and np.isfinite(raw).all();decoded[name]=unpack_phase_surface(raw[:,:741])
    selected=[]
    for col in range(4):
        matches=[]
        for name,data in decoded.items():
            if all(np.asarray(data[key][col]).dtype==np.asarray(actual['surface/'+key][col]).dtype and np.asarray(data[key][col]).shape==np.asarray(actual['surface/'+key][col]).shape and np.asarray(data[key][col]).tobytes()==np.asarray(actual['surface/'+key][col]).tobytes() for key in keys):matches.append(name)
        if not matches:errors.append('No originalreturnedrawsurface match forcolumn '+str(col));continue
        first=captures[matches[0]][col]
        if not all(captures[name][col,741:].tobytes()==first[741:].tobytes() for name in matches):errors.append('Ambiguousjointinput association incolumn '+str(col));continue
        options=first[790:792];assert np.array_equal(options,options.astype(np.int32).astype(np.float32));selected.append(first)
        association.append(dict(column=col,matching_raw_surface_calls=matches,matched_direct_return_fields=keys,all_matching_operands_byteexact=True,cells=first[741:786].reshape(9,5).tolist(),properties=first[786:790].tolist(),options=options.astype(np.int32).tolist(),boundary=first[792:796].tolist()))
    if len(selected)==4:np.savez_compressed(r/'associated-actual-surface.npz',raw_phase_surface_and_actual_operands=np.stack(selected))
passed=equal and budget['passed'] and not errors;unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged
result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=passed,all_original345_fields_bitwise_equal=equal,fields=rows,changed_fields=[row for row in rows if not row['bitwise_equal']],errors=errors,budget=budget,original_surface_association=association,parent_manifest_sha256=manifest,derived_manifest_sha256=meta['derived_manifest_sha256'],source_unchanged=unchanged,original_output_sha256=sha(device/'baseline/cuda32/output.npz'),instrumented_output_sha256=sha(device/'cuda32/output.npz'),seconds=time.monotonic()-start,
    scope='ActualKUprivateCUDA0 then EHPC all345raw fields/dtypes/shapes/bytes againstoriginalJNJSbaseline, originalindependentMHCN/impuritygates. Auxiliaryinputassociation attemptedONLYafteralloriginalbytesunchanged, using14directreturnedfields percolumn; no arbitrarylastcallselection. This is diagnosticnoninterference/association, not closing originalCUDA/JAX1e-6K78, causalnumericfix/science/release.')
(r/'audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['fields','original_surface_association']}),flush=True);raise SystemExit(0 if passed else 1)

"""Compare proven actual operands and prepare unmodified 2x2 replay inputs."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-actual-operands-li';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
from test_gpu_column_heat import numpy_reference
from noahmp_clm.gpu.column_heat import validate_joint_heat
raws={};proofs={}
for name,folder,job in [('cuda','k78-cuda-fidelity-kv','1303.manager'),('jax','k78-jax-fidelity-lh','1418.manager')]:
    q=b/folder;proof=json.loads((q/'audit.json').read_text());assert proof['passed'] and proof['all_original345_fields_bitwise_equal'] and proof['source_unchanged'] and proof['parent_manifest_sha256']==manifest and len(proof['original_surface_association'])==4 and (q/'pbs-exit.txt').read_text().strip()=='0';status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
    with np.load(q/'associated-actual-surface.npz',allow_pickle=False) as z:raws[name]=z['raw_phase_surface_and_actual_operands']
    proofs[name]=dict(job=job,audit_sha256=sha(q/'audit.json'),associated_actual_surface_sha256=sha(q/'associated-actual-surface.npz'));(r/(name+'-fidelity-audit.json')).write_bytes((q/'audit.json').read_bytes());(r/(name+'-actual-pbs-qstat.txt')).write_text(status)
x,y=raws['cuda'][:,741:],raws['jax'][:,741:];assert x.shape==y.shape==(4,55) and x.dtype==y.dtype==np.dtype('float32');locations=np.argwhere(x.view(np.uint32)!=y.view(np.uint32));differences=[]
for col,k in locations:
    field='cells' if k<45 else ('properties' if k<49 else ('options' if k<51 else 'boundary'));index=[int(k//5),int(k%5)] if k<45 else [int(k-{'properties':45,'options':49,'boundary':51}[field])]
    differences.append(dict(column=int(col),field=field,index=index,cuda=float(x[col,k]),jax=float(y[col,k]),absolute_difference=abs(float(x[col,k])-float(y[col,k]))))
arrays={};reference=[]
for name,raw in raws.items():
    cells=raw[:,741:786].reshape(4,9,5);props=raw[:,786:790];options=raw[:,790:792].astype(np.int32);boundary=raw[:,792:796];validate_joint_heat(cells,props,options,boundary,np)
    for key,value in [('cells',cells),('props',props),('options',options),('boundary',boundary),('expected-original-heat',raw[:,266:343])]:arrays[name+'-'+key]=value
    for col in range(4):
        n=int(options[col,0])+4;h,t,d=numpy_reference(cells[col],props[col],options[col],boundary[col]);expected=raw[col,266:343];np.testing.assert_allclose(expected[:n],h,rtol=.1,atol=.1);np.testing.assert_allclose(expected[9:9+n],t,rtol=0,atol=.01)
        reference.append(dict(actual_input_source=name,column=col,maximum_original_gpu_numpy_enthalpy_difference_jm2=float(abs(expected[:n].astype(float)-h).max()),maximum_original_gpu_numpy_temperature_difference_k=float(abs(expected[9:9+n].astype(float)-t).max()),numpy_original_heat_residual_jm2=d['residual_jm2'],numpy_original_convergence_tolerance_jm2=d['convergence_tolerance_jm2']))
np.savez_compressed(r/'actual-operands.npz',**arrays);unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,source_unchanged=unchanged,source_manifest_sha256=manifest,fidelity_proofs=proofs,actual_operand_differences=differences,only_first_snow_thickness_differs=bool(len(differences)==1 and differences[0]['column']==3 and differences[0]['field']=='cells' and differences[0]['index']==[0,2]),numpy_reference=reference,actual_operand_archive_sha256=sha(r/'actual-operands.npz'),
    scope='Bothactualcapturedoperands comparedonlyafter eachoriginal345bitproof/truepercolumnreturnassociation andactualPBS0. OriginalNumPyjointreference runsbothactualsets before2x2GPUreplay. Inputs unmodified, no rounding/commonparameter imposed onproduction; differences alone donot prove wholeK78causality or close1e-6.')
(r/'receipt.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out),flush=True)

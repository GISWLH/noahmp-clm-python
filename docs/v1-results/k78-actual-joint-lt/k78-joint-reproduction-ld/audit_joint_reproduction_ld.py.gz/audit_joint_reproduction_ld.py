from pathlib import Path
import hashlib,json,os,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-joint-reproduction-ld';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();packet=json.loads((r/'packet.json').read_text());a=b/packet['archive'];assert sha(a)==packet['sha256'];device=Path(os.environ['TMPDIR'])/'device';device.mkdir()
with tarfile.open(a) as tf:tf.extractall(device,filter='data')
q=device/'completed-ky';e=json.loads((q/'exit.json').read_text());d=json.loads((q/'receipt.json').read_text());assert e['passed'] and e['actual_parent_returncode']==0 and e['receipt_sha256']==sha(q/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and d['device_barrier_complete'] and sha(q/'actual-joint-replay.npz')==d['output_sha256']
reference=b/'k78-actual-heat-reference-kx';ref=json.loads((reference/'receipt.json').read_text());assert ref['passed'] and ref['source_unchanged'] and (reference/'pbs-exit.txt').read_text().strip()=='0' and sha(q/'associated-actual-surface.npz')==ref['actual_associated_inputs_sha256']==sha(reference/'associated-actual-surface.npz')
with np.load(q/'associated-actual-surface.npz',allow_pickle=False) as z:raw=z['raw_phase_surface_and_actual_operands']
with np.load(q/'actual-joint-replay.npz',allow_pickle=False) as z:got=z['raw_joint_result']
expected=raw[:,266:343];assert got.shape==expected.shape==(4,77) and got.dtype==expected.dtype==np.dtype('float32');equal=got.tobytes()==expected.tobytes();difference=abs(got.astype(float)-expected.astype(float));records=[]
for col in range(4):
    changed=np.flatnonzero(got[col].view(np.uint32)!=expected[col].copy().view(np.uint32));records.append(dict(column=col,all77_joint_values_bitwise_equal=not len(changed),maximum_absolute_difference=float(difference[col].max()),changed_values=[dict(index=int(k),whole_column=float(expected[col,k]),standalone=float(got[col,k])) for k in changed]))
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=equal,all_four_columns_all77_joint_values_bitwise_equal=equal,records=records,actual_inputs_sha256=sha(q/'associated-actual-surface.npz'),source_manifest_sha256=d['source_manifest_sha256'],
    scope='ActualoriginalJN standaloneCUDAjoint output all77values comparedbitwise tooriginalfullfusedsurface raw77, using actualKU operands onlyafterKV345bitproof andKXNumPy0. KWarraypackaging failure retained. Reproductiondiagnostic only; actualJAXoperands/noninterference, cross-input causaltest andK78sameprecision stillindependent/pending.')
(r/'audit.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out),flush=True);raise SystemExit(0 if equal else 1)

from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');payload={};sha=lambda raw:hashlib.sha256(raw).hexdigest();completed=[]
for name,job,receipt in [('k78-cuda-fidelity-kv','1303.manager','audit.json'),('k78-actual-heat-reference-kx','1304.manager','receipt.json'),('k78-joint-reproduction-ld','1417.manager','audit.json'),('k78-jax-fidelity-lh','1418.manager','audit.json'),('k78-actual-operands-li','1419.manager','receipt.json')]:
    root=b/name;status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M) and (root/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((root/receipt).read_text());assert d['passed'] and d.get('source_unchanged',True)
    for p in sorted(root.rglob('*')):
        if p.is_file():assert not p.is_symlink();payload[name+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
    payload[name+'/actual-pbs-qstat.txt']=status.encode();completed.append(dict(root=name,pbs_job=job,actual_exit=0))
archives=[('k78-joint-ku-cuda32-export.tar.gz','ccabd48a28bb37cc84ce78d5db3ffdd86c8983aa82d1647e7240aa0b9cc64f2a'),('k78-joint-ku-jax32-export.tar.gz','e6b2baaf10cd84e84d5b99ffae8e66250d4408460f4d7dfaa2afc93c29639130'),('k78-actual-joint-ky-export.tar.gz','a7bf139a6a062003a3323b393a272a39fd765e60712ae3c18aee2cced0919c04')]
for name,digest in archives:
    raw=(b/name).read_bytes();assert sha(raw)==digest;payload['device/'+name]=raw
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_completed=completed,source_manifest_sha256='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5',scope='ActualbothKU GPU0 andKV/LH original345bitwise proofs/truepercolumnreturnassociation, KX bothoriginalreference bounds, KY/LD exactall4x77CUDAjointreproduction, LI actualall4x55operands andbothNumPyrefs. Soleinputdifference HaM firstsnowthickness7.275957614183426e-12m. LI differencesalone notcausal2x2proof; LOreplayqueuedseparately. OriginalK78 1.52587890625e-5 Jm-2 failure remains; production/formula/gates/M1/liveyears unchanged.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();payload['control/'+Path(__file__).name]=Path(__file__).read_bytes();target=b/'k78-actual-joint-lt-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for m in tf:assert tf.extractfile(m).read()==payload[m.name]
out=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'k78-actual-joint-lt-package.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

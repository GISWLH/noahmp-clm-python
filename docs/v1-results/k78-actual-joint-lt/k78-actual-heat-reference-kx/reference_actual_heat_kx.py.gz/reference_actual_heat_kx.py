"""PBS NumPy reference on proven actual CUDA joint operands, no re-packing."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'k78-actual-heat-reference-kx';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();archive=b/'clm-ballberry-jn-source.tar.gz';assert sha(archive)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.column_heat import coupled_heat_step
from noahmp_clm.physics.snow_heat import conductivity
from noahmp_clm.physics.soil import thermal_conductivity
from noahmp_clm.gpu.column_heat import validate_joint_heat
q=b/'k78-cuda-fidelity-kv';proof=json.loads((q/'audit.json').read_text());assert proof['passed'] and proof['all_original345_fields_bitwise_equal'] and proof['source_unchanged'] and len(proof['original_surface_association'])==4 and (q/'pbs-exit.txt').read_text().strip()=='0'
status=subprocess.check_output(['qstat','-xf','1303.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
with np.load(q/'associated-actual-surface.npz',allow_pickle=False) as z:raw=z['raw_phase_surface_and_actual_operands']
assert raw.shape==(4,796) and raw.dtype==np.dtype('float32');(r/'associated-actual-surface.npz').write_bytes((q/'associated-actual-surface.npz').read_bytes());(r/'fidelity-audit.json').write_bytes((q/'audit.json').read_bytes());(r/'actual-fidelity-qstat.txt').write_text(status)
cells=raw[:,741:786].reshape(4,9,5);props=raw[:,786:790];options=raw[:,790:792].astype(np.int32);boundary=raw[:,792:796];validate_joint_heat(cells,props,options,boundary,np)
records=[];results={};start=time.monotonic()
for i in range(4):
    c,p,o,bnd=cells[i].astype(float),props[i].astype(float),options[i],boundary[i].astype(float);ns=int(o[0]);n=ns+4
    snow=Snowpack(c[:ns,0],c[:ns,1],c[:ns,2]) if ns else Snowpack.empty()
    soil=SoilEnthalpyState(c[ns:n,0],c[ns:n,1],c[ns:n,2],SoilParams(smcmax=p[0],bexp=p[1],quartz=p[2],saturated_suction_m=p[3]),int(o[1]))
    k=np.r_[conductivity(snow),thermal_conductivity(soil.water/(1000*soil.dz),soil.params)];k=np.where(c[:n,3]>0,c[:n,3],k)
    snow,soil,d=coupled_heat_step(snow,soil,bnd[0],bnd[1],snow_absorbed=c[:ns,4],soil_absorbed=c[ns:n,4],top_temperature=bnd[2]+273.15,top_conductance=bnd[3],thermal_conductivity=k)
    h=np.r_[snow.enthalpy,soil.enthalpy];t=np.r_[snow.temperature,soil.temperature];device=raw[i,266:343].astype(float);dh=abs(device[:n]-h);dt=abs(device[9:9+n]-t)
    np.testing.assert_allclose(device[:n],h,rtol=.1,atol=.1);np.testing.assert_allclose(device[9:9+n],t,rtol=0,atol=.01)
    independent_cuda_budget=float(np.sum(device[:n]-c[:n,1])-bnd[0]*(device[73]+float(c[:n,4].sum())))
    original_allowance=float(device[62:62+n].sum()+16*np.finfo(np.float32).eps*max(1.,abs(device[71])))+1e-5
    assert abs(independent_cuda_budget)<=original_allowance and np.all(abs(device[45:54])<=device[62:71])
    results['enthalpy-'+str(i)]=h;results['temperature-'+str(i)]=t;results['layer-residual-'+str(i)]=d['layer_residual_jm2']
    records.append(dict(column=i,active_snow_layers=ns,maximum_cuda_numpy_enthalpy_difference_jm2=float(dh.max()),maximum_cuda_numpy_temperature_difference_k=float(dt.max()),numpy_independent_heat_residual_jm2=d['residual_jm2'],numpy_original_convergence_tolerance_jm2=d['convergence_tolerance_jm2'],cuda_independent_heat_residual_jm2=independent_cuda_budget,cuda_original_propagated_bound_jm2=original_allowance,original_module_reference_and_independent_conservation_criteria_met=True))
np.savez_compressed(r/'numpy-reference.npz',**results);unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,source_unchanged=unchanged,source_manifest_sha256=manifest,actual_associated_inputs_sha256=sha(r/'associated-actual-surface.npz'),records=records,seconds=time.monotonic()-start,
    scope='FouractualCUDAjointinputs ONLYafter1303 original345bitwiseproof andpercolumnrawsurfaceassociation. ExistingNumPyreference andoriginaljoint-module10percent/.1J enthalpy/.01K temperature plusindependentoriginalheatbudgets; no re-packing/adjustedinputs/Numericfix/productionchange. ActualJAXinputcapture, sameinputstandalonereproduction andcausalisolation stillpending; no K78parity/science/releasepass.')
(r/'receipt.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out),flush=True)

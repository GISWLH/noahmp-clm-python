"""Native layered canopy phase coupled to snow and soil extensive stores."""
from functools import lru_cache
import numpy as np
from .canopy_surface import pack_canopy_surface,validate_surface,surface_kernel_jax,unpack_surface,_radiation
from .canopy_phase_energy import validate_phase,unpack_phase
from .canopy_boundary import radiation_inputs
from .photosynthesis import prepare_canopy_leaf_parameters
from .snicar import _jax_tables
from .snow_evolution import _tables as _aging


def pack_canopy_phase_surface(snow,soil,dt,area,swdown,lwdown,exchange,condensate,*,dtype=np.float64,**kwargs):
    if condensate.mass.shape!=(10,):raise ValueError('Ten canopy condensate layers required')
    if {'canopy_water_kgm2','canopy_enthalpy_jm2'} & kwargs.keys():raise ValueError('Use the layer stores, not both layer and aggregate storage')
    base=pack_canopy_surface(snow,soil,dt,area,swdown,lwdown,exchange,
        canopy_water_kgm2=float(condensate.mass.sum()),canopy_enthalpy_jm2=float(condensate.enthalpy.sum()),dtype=dtype,**kwargs)
    return (*base,np.column_stack((condensate.mass,condensate.enthalpy)).astype(dtype))


def validate_phase_surface(arrays,xp,*,stem_area=None):
    *base,condensate=arrays
    c,g,p,o,a,u,f,v=base;n=len(c);dtype=c.dtype
    stem=xp.zeros_like(a) if stem_area is None else stem_area
    if (stem.shape!=(n,10) or stem.dtype!=dtype or not bool(xp.all(xp.isfinite(stem)))
            or bool(xp.any(stem<0.))):raise ValueError('Invalid surface stem-area extension')
    validate_surface(base,xp,plant_area=None if stem_area is None else a+stem)
    supply=xp.zeros((n,10),dtype=dtype)
    supply=xp.concatenate((xp.ones((n,1),dtype=dtype),supply[:,1:]),axis=1)
    boundary=xp.stack((xp.ones(n,dtype),u[:,0],xp.zeros(n,dtype),xp.ones(n,dtype),v[:,0]),axis=1)
    boundary=xp.concatenate((boundary,xp.zeros((n,4),dtype=dtype)),axis=1)
    validate_phase((a,u,f,supply,stem,condensate,boundary,c[:,:,[0,3,4,5,6,7,8]],o[:,0]),xp)
    # Aggregate aliases are packing metadata only; device reductions below
    # establish the authoritative sums from individual layer state.
    eps=xp.finfo(dtype).eps
    for k in range(2):
        total=xp.sum(condensate[:,:,k],axis=1)
        if bool(xp.any(abs(total-v[:,1+k])>16.*eps*xp.maximum(xp.sum(abs(condensate[:,:,k]),axis=1),1.))):
            raise ValueError('Aggregate canopy aliases disagree with layer state')


def unpack_phase_surface(out):
    result=unpack_surface(out[:,:441]);phase=unpack_phase(out[:,441:741])
    # Surface LE includes the actual ground phase parcel. Keep it separate
    # from the fixed-boundary canopy solver's predicted ground latent heat.
    result['condensate']=out[:,636:656].reshape(-1,2,10).transpose(0,2,1)
    for key in ('mass','enthalpy','thermal_enthalpy','ice_vapor','liquid_vapor','vapor_enthalpy',
                'vapor_latent_energy','unmet_evaporation','phase_coordinates','root_advected_heat_wm2',
                'transpiration_net_heat_wm2','restarts','max_solver_residual'):
        result[key]=phase[key]
    result['canopy_converged']=phase['converged']
    return result


_K78_CAPTURE=[]

@lru_cache(maxsize=16)
def _compiled(extended=False,vic=False,stems=False,profiled=False):
    import jax
    axes=(0,0,0,0,0,0,0,0,0,0 if profiled else None,None,0)
    return jax.jit(jax.vmap(surface_kernel_jax,in_axes=axes+(0 if extended else None,0 if vic else None,0 if stems else None)))


def validate_exchange_extension(extension,n,xp):
    if extension.shape!=(n,2) or not bool(xp.all(xp.isfinite(extension))) or bool(xp.any(
            (extension[:,0]<=0.)|(extension[:,1]<200.)|(extension[:,1]>400.))):
        raise ValueError('Invalid separate water velocity/potential temperature extension')


def run_canopy_phase_surface_jax(*arrays,parameters=None,raise_on_failure=True,exchange_extension=None,vic=None,stem_area=None,canopy_optics=None):
    import jax.numpy as j
    arrays=tuple(map(j.asarray,arrays));stem=None if stem_area is None else j.asarray(stem_area)
    validate_phase_surface(arrays,j,stem_area=stem)
    c,g,p,o,a,u,f,v,condensate=arrays;dtype=str(c.dtype)
    plant=a if stem is None else a+stem
    optical_result=None
    if canopy_optics is None:
        radiation=_radiation()(plant,c[:,:,j.array([0,3,4,5,6,7,8])],o[:,0],radiation_inputs(plant,u,j),*_jax_tables(dtype))
    else:
        from .canopy_optics import canopy_snow_optics_raw_jax
        optical_result=canopy_snow_optics_raw_jax(plant,c[:,:,j.array([0,3,4,5,6,7,8])],o[:,0],
            radiation_inputs(plant,u,j),a,canopy_optics)
        radiation=optical_result[:,:584]
    extra=() if exchange_extension is None else (j.asarray(exchange_extension),)
    if extra:
        validate_exchange_extension(extra[0],len(c),j)
        if extra[0].dtype!=c.dtype:raise ValueError('Exchange extension precision mismatch')
    if vic is not None:
        from .vic import validate_vic
        vic=j.asarray(vic);validate_vic(vic,len(c),j)
        if vic.dtype!=c.dtype:raise ValueError('VIC precision mismatch')
    parameters,profiled=prepare_canopy_leaf_parameters(parameters,j,len(c),c.dtype)
    out=_compiled(bool(extra),vic is not None,stem is not None,profiled)(*arrays[:8],radiation,parameters,_aging(dtype),condensate,
        extra[0] if extra else None,vic,stem)
    result=unpack_phase_surface(out)
    _K78_CAPTURE.append(out)
    if optical_result is not None:
        from .canopy_optics import attach_optical_absorption
        attach_optical_absorption(result,optical_result)
    if raise_on_failure and (not bool(j.all(j.isfinite(out))) or not bool(j.all(result['converged']))):
        raise RuntimeError('Layered phase surface failed; inspect with raise_on_failure=False')
    return result

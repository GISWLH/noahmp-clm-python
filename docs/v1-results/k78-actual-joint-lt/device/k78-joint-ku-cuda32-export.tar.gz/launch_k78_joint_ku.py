"""Private auxiliary-output probe; original JN and active models untouched."""
from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-joint-input-ku';tmp=Path('/tmp/noahmp-k78-joint-input-ku');s=tmp/'source';old=b/'k78-corrected-js';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not r.exists() and not tmp.exists();archive=b/'clm-ballberry-jn-source.tar.gz';assert sha(archive)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
original=json.loads((old/'exit.json').read_text());assert len(original['workers'])==2 and all(x['actual_returncode']==0 for x in original['workers'])
for row in original['workers']:
    name=row['backend'];d=json.loads((old/name/'receipt.json').read_text());assert sha(old/name/'receipt.json')==row['receipt_sha256'] and d['failure'] is None and d['source_unchanged'] and d['result']['raw_fields_including_before_arrays']==345 and d['device_barriers'] and sha(old/name/'output.npz')==d['result']['output_sha256']
r.mkdir();s.mkdir(parents=True)
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());parent=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and parent=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items())
changes={}
def patch(name,replacements):
    p=s/name;raw=p.read_bytes();text=raw.decode()
    for old,new,count in replacements:
        assert text.count(old)==count,(name,old,text.count(old),count);text=text.replace(old,new)
    p.write_bytes(text.encode());changes[name]=dict(before_sha256=hashlib.sha256(raw).hexdigest(),after_sha256=sha(p))
patch('src/noahmp_clm/gpu/canopy_surface.py',[(
    '        heat=j.concatenate(joint_heat_kernel_jax(cells,p[j.array([0,1,4,6])],j.stack((nn,phase)),row(dt,top,0.,0.)))',
    '        _ku_props=p[j.array([0,1,4,6])];_ku_options=j.stack((nn,phase));_ku_bc=row(dt,top,0.,0.)\n'
    '        heat=j.concatenate(joint_heat_kernel_jax(cells,_ku_props,_ku_options,_ku_bc))\n'
    '        if condensate is not None:extra=j.concatenate((extra,cells.ravel(),_ku_props,_ku_options.astype(dtype),_ku_bc))',1)])
for name in ['src/noahmp_clm/gpu/canopy_phase_surface.py','src/noahmp_clm/gpu/cuda/canopy_phase_surface.py']:
    replacements=[('@lru_cache(maxsize=16)','_K78_CAPTURE=[]\n\n@lru_cache(maxsize=16)',1),('    result=unpack_phase_surface(out)','    result=unpack_phase_surface(out)\n    _K78_CAPTURE.append(out)',1)]
    if '/cuda/' in name:replacements.append(('out=cp.empty((size,741),cp.float32)','out=cp.empty((size,796),cp.float32)',1))
    patch(name,replacements)
patch('src/noahmp_clm/gpu/cuda/canopy_phase_surface_kernel.cu',[('output_size=741','output_size=796',1),('out+741*row','out+796*row',4)])
patch('src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu',[(
    '    float* heat=out+266;joint_heat_device(cells,props,options,bc,heat);',
    '    if(Solver::output_size==796){\n'
    '        for(int i=0;i<45;++i)out[741+i]=cells[i];\n'
    '        for(int i=0;i<4;++i)out[786+i]=props[i];\n'
    '        for(int i=0;i<2;++i)out[790+i]=(float)options[i];\n'
    '        for(int i=0;i<4;++i)out[792+i]=bc[i];\n'
    '    }\n    float* heat=out+266;joint_heat_device(cells,props,options,bc,heat);',1)])
derived={n:sha(s/n) for n in m};assert set(changes)=={n for n in m if m[n]!=derived[n]} and len(changes)==5
for n in changes:
    if n.endswith('.py'):ast.parse((s/n).read_text())
for n in ['input.npz','binding.json']:(r/n).write_bytes((old/n).read_bytes())
assert sha(r/'input.npz')=='957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
for name in ['cuda32','jax32']:
    q=r/'baseline'/name;q.mkdir(parents=True)
    for n in ['output.npz','receipt.json']:(q/n).write_bytes((old/name/n).read_bytes())
(r/'baseline/original-parent-exit.json').write_bytes((old/'exit.json').read_bytes());(r/'PARENT_SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());(r/'INSTRUMENTED_SHA256.json').write_text(json.dumps(derived,indent=2)+'\n')
meta=dict(parent_JN_manifest_sha256=parent,derived_manifest_sha256=sha(r/'INSTRUMENTED_SHA256.json'),source=str(s),changes=changes,original_source_files=581,input_sha256=sha(r/'input.npz'),auxiliary_layout=dict(original_phase_surface_floats=741,full_instrumented_floats=796,cells=[741,786],properties=[786,790],options_cast_exact_ints_to_float32=[790,792],boundary=[792,796]),
    scope='Private5file instrumentation only, no originalformula/iteration/gate or production/liveyear change. Additional55 fields areactualjointheatcall operands retained forfinalcandidate ofeveryphase-surface call. Alloriginal345outputs mustfirst beproven bitwiseunchanged onEHPC beforeany auxiliaryinput causalclaim. MultipleMOSTcalls/columnselection must beassociated byoriginalrawsurfacefields; no assumption lastcall isreported result.')
(r/'instrumentation.json').write_text(json.dumps(meta,indent=2)+'\n')
names=['replay_k78_joint_ku.py','control_k78_joint_ku.py',Path(__file__).name]
for n in names:raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(tmp/'jax-cache'),CUPY_CACHE_DIR=str(tmp/'cupy-cache'),CUDA_CACHE_PATH=str(tmp/'cuda-cache'))
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'control_k78_joint_ku.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
launch=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),physical_gpu_index=1,physical_gpu_uuid=env['CUDA_VISIBLE_DEVICES'],controls_sha256={n:sha(r/n) for n in names},parent_manifest_sha256=parent,derived_manifest_sha256=meta['derived_manifest_sha256'],scope=meta['scope']);(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');print(json.dumps(launch),flush=True)

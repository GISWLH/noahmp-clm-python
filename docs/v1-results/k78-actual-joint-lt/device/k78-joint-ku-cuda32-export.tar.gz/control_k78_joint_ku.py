from pathlib import Path
import hashlib,json,subprocess,sys,time,traceback
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];failure=None;start=time.monotonic()
try:
    for name in ['cuda32','jax32']:
        if name=='jax32':
            while not (r/'cuda-fidelity-ack.json').exists():
                (r/'waiting-cuda-fidelity.json').write_text(json.dumps(dict(actual_cuda_exit=rows[0]['actual_parent_returncode'],scope='Wait independentEHPC actualoriginal345bitwiseproof. No JAXcompute beforeack, no acceptancefromCUDAexport.'))+'\n');time.sleep(20.)
            ack=json.loads((r/'cuda-fidelity-ack.json').read_text());assert ack['passed'] and ack['actual_pbs_exit']==0 and ack['all_original345_fields_bitwise_equal'] and ack['original_output_sha256']==sha(r/'baseline/cuda32/output.npz') and ack['instrumented_output_sha256']==sha(r/'cuda32/output.npz')
        while True:
            free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
            if free>8192 and mem>32*1024*1024:break
            time.sleep(20.)
        with (r/(name+'.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'replay_k78_joint_ku.py'),name],stdout=log,stderr=subprocess.STDOUT)
        (r/(name+'-worker.json')).write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();receipt=r/name/'receipt.json';d=json.loads(receipt.read_text()) if receipt.exists() else {};row=dict(backend=name,actual_parent_returncode=code,receipt_sha256=sha(receipt) if receipt.exists() else None,passed=bool(code==0 and d.get('failure') is None and d.get('source_unchanged') and d.get('device_barriers')));rows.append(row);(r/(name+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n');assert row['passed'],'Instrumentedcompute failed; no subsequentbackend launch'
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
d=dict(rows=rows,failure=failure,seconds=time.monotonic()-start,scope='Privatecapture controller; CUDAoriginal345bitproof onEHPC precedesJAX. Eachactualcompute/export/barrier retained, independentbothbackendfidelity/operandassociation/causalisolation stillrequired. Never originalsameprecision/physics/releasepass.');(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);raise SystemExit(0 if failure is None and len(rows)==2 else 1)

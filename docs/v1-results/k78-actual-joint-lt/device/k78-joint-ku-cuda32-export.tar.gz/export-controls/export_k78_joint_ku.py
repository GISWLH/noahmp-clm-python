from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-joint-input-ku';backend=sys.argv[1];assert backend in ['cuda32','jax32'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'instrumentation.json').read_text());source=Path(meta['source']);m=json.loads((r/'INSTRUMENTED_SHA256.json').read_text());assert len(m)==581 and all(sha(source/n)==h for n,h in m.items())
exit=json.loads((r/(backend+'-exit.json')).read_text());receipt=json.loads((r/backend/'receipt.json').read_text());assert exit['passed'] and exit['actual_parent_returncode']==0 and exit['receipt_sha256']==sha(r/backend/'receipt.json') and receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barriers'];assert receipt['result']['original_raw_fields']==345
assert sha(r/backend/'output.npz')==receipt['result']['output_sha256'] and sha(r/backend/'phase-surface-captures.npz')==receipt['result']['captures_sha256'];launch=json.loads((r/'launch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items())
paths=[]
for n in ['instrumentation.json','INSTRUMENTED_SHA256.json','PARENT_SOURCE_SHA256.json','input.npz','binding.json','launch.json',backend+'-exit.json',backend+'-worker.json',backend+'.log',*launch['controls_sha256']]:paths.append((r/n,n))
for prefix in [backend,'baseline/'+backend]:
    for p in sorted((r/prefix).iterdir()):
        if p.is_file():paths.append((p,p.relative_to(r).as_posix()))
paths.append((r/'baseline/original-parent-exit.json','baseline/original-parent-exit.json'))
for n,change in meta['changes'].items():assert sha(source/n)==change['after_sha256'];paths.append((source/n,'instrumented-source/'+n))
paths.append((Path(__file__),'export-controls/'+Path(__file__).name))
target=b/('k78-joint-ku-'+backend+'-export.tar.gz');assert not target.exists();inventory={}
with tarfile.open(target,'w:gz') as tf:
    for p,n in paths:assert n not in inventory;inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
out=dict(archive=target.name,sha256=sha(target),bytes=target.stat().st_size,artifacts=len(inventory),backend=backend,parent_manifest_sha256=meta['parent_JN_manifest_sha256'],derived_manifest_sha256=meta['derived_manifest_sha256'],scope='PrivateKUactualcompute0/source/barrier original345exports plusallrawsurface796captures andactualchanged5sourcefiles. OriginalJNphysical/year untouched; actualEHPCbitwisefidelity proof beforeauxiliary operands maybetrusted. Not K78/gpuparity/science/releasepass.');(b/('k78-joint-ku-'+backend+'-export.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

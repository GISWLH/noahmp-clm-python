from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
import cupy as cp
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-actual-joint-replay-kw';s=Path('/tmp/noahmp-k78-corrected-js/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
from noahmp_clm.gpu.column_heat import validate_joint_heat
from noahmp_clm.gpu.cuda.column_heat import _kernel
ref=json.loads((r/'numpy-reference-receipt.json').read_text());assert ref['passed'] and ref['source_unchanged'] and ref['source_manifest_sha256']==manifest and sha(r/'associated-actual-surface.npz')==ref['actual_associated_inputs_sha256']
with np.load(r/'associated-actual-surface.npz',allow_pickle=False) as z:raw=z['raw_phase_surface_and_actual_operands']
c=cp.ascontiguousarray(raw[:,741:786].reshape(4,9,5));p=cp.ascontiguousarray(raw[:,786:790]);o=cp.ascontiguousarray(raw[:,790:792].astype(np.int32));bc=cp.ascontiguousarray(raw[:,792:796]);validate_joint_heat(c,p,o,bc,cp)
start=time.monotonic();failure=None;barrier=False
try:
    result=cp.empty((4,77),cp.float32);_kernel()((1,),(64,),(c,p,o,bc,result,np.int32(4)));output=cp.asnumpy(result);np.savez_compressed(r/'actual-joint-replay.npz',raw_joint_result=output);cp.cuda.runtime.deviceSynchronize();barrier=True
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(failure=failure,source_unchanged=unchanged,source_manifest_sha256=manifest,device_barrier_complete=barrier,actual_inputs_sha256=sha(r/'associated-actual-surface.npz'),output_sha256=sha(r/'actual-joint-replay.npz') if (r/'actual-joint-replay.npz').exists() else None,seconds=time.monotonic()-start,
    scope='OriginalJN standaloneCUDAjointkernel onexactprovenactualKU/KVoperands afteractualNumPy1304reference0. No fullcolumn, source/formula/input change or NumPyforwardphysics onxuanze. EHPC mustverifyall77rawheatvalues reproducefullfusedoriginalbytes beforecausalinputexchanges. Actualcompute0 isnotfidelity/1e-6/K78/science/releasepass.')
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barrier else 1)

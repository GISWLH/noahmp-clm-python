from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'k78-actual-joint-replay-ky';old=b/'k78-actual-joint-replay-kw';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());e=json.loads((r/'exit.json').read_text());assert e['passed'] and e['actual_parent_returncode']==0 and e['receipt_sha256']==sha(r/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and sha(r/'actual-joint-replay.npz')==d['output_sha256'];launch=json.loads((r/'launch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items());failure=json.loads((old/'exit.json').read_text());assert failure['actual_parent_returncode']==1 and not failure['passed'] and not (old/'receipt.json').exists()
target=b/'k78-actual-joint-ky-export.tar.gz';assert not target.exists();inventory={}
with tarfile.open(target,'w:gz') as tf:
    for root,prefix in [(r,'completed-ky'),(old,'failed-kw')]:
        for p in sorted(root.iterdir()):
            if p.is_file():name=prefix+'/'+p.name;inventory[name]=sha(p);tf.add(p,arcname=name,recursive=False)
    inventory['export-controls/'+Path(__file__).name]=sha(Path(__file__));tf.add(Path(__file__),arcname='export-controls/'+Path(__file__).name,recursive=False)
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
out=dict(archive=target.name,sha256=sha(target),bytes=target.stat().st_size,artifacts=len(inventory),scope='OriginalJN actualjointinputs standaloneKYactualCUDA0 afterNumPy1304reference0; originalKWwrapperTypeError beforekernel actual1 retained. Onlychanged devicearraypackaging/newprivatecache/paths, no source/inputs/formulas/gates. EHPCall77raw reproduction stillrequired; not K78sameprecision/science/releasepass.');(b/'k78-actual-joint-ky-export.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

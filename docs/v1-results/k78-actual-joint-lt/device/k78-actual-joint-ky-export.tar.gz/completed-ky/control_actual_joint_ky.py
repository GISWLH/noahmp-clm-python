from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
    if free>8192 and mem>32*1024*1024:break
    time.sleep(20.)
with (r/'worker.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'replay_actual_joint_ky.py')],stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();d=json.loads((r/'receipt.json').read_text()) if (r/'receipt.json').exists() else {};v=dict(actual_parent_returncode=code,passed=bool(code==0 and d.get('failure') is None and d.get('source_unchanged') and d.get('device_barrier_complete')),receipt_sha256=sha(r/'receipt.json') if (r/'receipt.json').exists() else None,scope='Actualstandalonejointcomputation/export status only; all77fidelity isdeferredtoEHPC.');(r/'exit.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True);raise SystemExit(0 if v['passed'] else 1)

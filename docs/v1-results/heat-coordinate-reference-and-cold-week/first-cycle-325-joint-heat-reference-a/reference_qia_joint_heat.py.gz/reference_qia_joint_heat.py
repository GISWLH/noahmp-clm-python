"""EHPC independent float64 solution of the exact retained joint-heat cells."""
from pathlib import Path
import hashlib,json
import numpy as np
from test_gpu_column_heat import numpy_reference
from run_fluxnet_column import source_hashes
r=Path.cwd();p=r/'inputs.npz'
with np.load(p,allow_pickle=False) as z:arrays={k:z[k] for k in z}
h,t,d=numpy_reference(arrays['cells'][0],arrays['props'][0],arrays['options'][0],arrays['boundary'][0])
out=dict(scope='Exact captured Qia first-climate-cycle index325 joint heat, NumPy64 independent reference on EHPC, sourceE unchanged.',
 input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_sha256=source_hashes(),
 enthalpy_jm2=h.tolist(),temperature_k=t.tolist(),ledger={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in d.items()})
(r/'qia_heat_coordinate_reference.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='source_sha256'}),flush=True)

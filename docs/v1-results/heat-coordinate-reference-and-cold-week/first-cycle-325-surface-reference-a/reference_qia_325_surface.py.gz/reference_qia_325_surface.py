"""Independent same-input NumPy surface, source E before any thermal repair."""
from pathlib import Path
import hashlib,json,time,traceback
import numpy as np
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.vic import VICParameters
from run_fluxnet_column import source_hashes

r=Path.cwd();p=r/'failed-surface-325-inputs.npz'
with np.load(p,allow_pickle=False) as z:arrays=dict(z)
row=1;c,g,p,o,a,u,f,v,condensate=[arrays[f'a{k}'][row].astype(float) for k in range(9)];n=int(o[0])
pack=Snowpack(c[:n,0],c[:n,1],c[:n,2],c[:n,3],c[:n,4:])
soil=SoilEnthalpyState(g[:,0],g[:,1],g[:,2],SoilParams(smcmax=p[0],bexp=p[1],smcref=p[2],satdk=p[3],quartz=p[4],smcwlt=p[5]),int(o[1]))
extension=arrays['exchange_extension'][row].astype(float)
exchange=CanopyExchange(*u[:11],atmosphere_water_velocity=extension[0],potential_temperature=extension[1])
vic=arrays['vic'][row].astype(float);assert vic[0]==1
out=dict(scope='Qia first climate-year index325 surface, actual quantized CUDA inputs, independent NumPy64 sourceE. Not annual completion.',source_sha256=source_hashes())
started=time.monotonic()
try:
    snow,ground,water,d=surface_step(pack,soil,v[0],a,u[11],u[12],exchange,
        canopy_condensate=CanopyCondensate(condensate[:,0],condensate[:,1]),root_weights=v[3:],
        vegetated_fraction=u[13],transpiration_limit=u[16],ground_emissivity=u[18],ground_albedo=u[19:21],
        diffuse_fraction=u[21],cosine_zenith=u[22],nitrogen_factor=f[:,0],water_stress=f[:,1],
        leaf_parameters=LeafParameters(),infiltration_parameters=VICParameters(*vic[2:]))
    fields={k:d[k] for k in ['h','le','et_kgm2','surface_temperature','water_residual_kgm2','energy_residual_jm2',
        'surface_evaluations','outgoing_shortwave','outgoing_longwave','runoff_kgm2','runoff_enthalpy_jm2',
        'advected_enthalpy_jm2','layer_residual']}
    fields.update(snow_mass=snow.mass,snow_enthalpy=snow.enthalpy,soil_water=ground.water,soil_enthalpy=ground.enthalpy,
        soil_temperature=ground.temperature,thermal=d['thermal'])
    out.update(status='complete',result=fields)
except Exception:out.update(status='failed',failure=traceback.format_exc())
out['seconds']=time.monotonic()-started
def encode(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
(r/'numpy-reference.json').write_text(json.dumps(out,indent=2,default=encode,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='source_sha256'},default=encode),flush=True)

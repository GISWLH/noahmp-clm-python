from pathlib import Path
import json,subprocess,shutil,time,hashlib
r=Path('/home/zhangyq/noahmp-v1/fluxnet-first-climate-cycle-20261017-b');source=Path('/home/zhangyq/noahmp-v1/p6-dry-condensation-b');case='CN-Qia-initial-climate-cycle';folder=r/'numpy-day'/case;report=folder/'report.json'
d=json.loads(report.read_text())
if d['status']=='failed':
 (r/'qia-checkpoint-controller.json').write_text(json.dumps(dict(scope='Original process failed physically; no automatic retry',status='stopped',failure=d.get('failure')),indent=2)+'\n');raise SystemExit(1)
if d['steps_completed']>=48:
 (r/'qia-checkpoint-controller.json').write_text(json.dumps(dict(status='original-first-day-already-finished',steps=d['steps_completed']),indent=2)+'\n');raise SystemExit(0)
shutil.copytree(folder,r/'qia-first-attempt-checkpoint')
row=next(x for x in json.loads((r/'batch.json').read_text())['cases'] if x['case']==case);results=[];exe='/home/zhangyq/venvs/noahmp-closeout/bin/python'
while d['steps_completed']<48:
 start=d['steps_completed'];n=min(12,48-start)
 command=[exe,'-u','benchmarks/run_fluxnet_column.py','--input',row['input'],'--input-manifest',row['input_manifest'],'--config',row['configuration'],'--output',str(folder),'--resume','--stop-after',str(n)]
 with (r/f'qia-checkpoint-{start:04d}.log').open('w') as log:p=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
 d=json.loads(report.read_text());results.append(dict(start=start,requested=n,returncode=p.returncode,completed=d['steps_completed'],report_sha256=hashlib.sha256(report.read_bytes()).hexdigest()))
 (r/'qia-checkpoint-controller.json').write_text(json.dumps(dict(scope='Parent job terminal; continue original identical NumPy source/config at committed state with 12-step checkpoints',status='running' if d['steps_completed']<48 else 'first-day-finished',results=results),indent=2)+'\n')
 if p.returncode or d['status']=='failed':raise SystemExit(1)
 assert d['steps_completed']==start+n

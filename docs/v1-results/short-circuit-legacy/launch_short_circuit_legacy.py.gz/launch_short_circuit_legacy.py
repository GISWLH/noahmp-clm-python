from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-short-circuit-legacy-replay-a';target=base/'p6-phase-short-circuit-gpu-a'
assert json.loads((target/'production-baseline-comparison.json').read_text())['source_unchanged']
assert json.loads((target/'phase-target-receipt.json').read_text())['returncode']==0
receipt=root/'launch.json';assert not receipt.exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:benchmarks',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'))
with (root/'controller.log').open('w') as log:p=subprocess.Popen(['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_short_circuit_legacy.py')],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=1,scope='Fresh immutable copy of original six-field G614 physics, device early exit only; compares both complete backends to their pre-change baselines.')
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

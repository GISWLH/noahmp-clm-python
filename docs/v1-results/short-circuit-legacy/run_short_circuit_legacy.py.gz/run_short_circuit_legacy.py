from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,time
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in manifest.items())
rows=[]
for mode in ['cuda','jax']:
    begun=time.monotonic()
    with (root/(mode+'-replay.log')).open('w') as log:code=subprocess.run([sys.executable,'-u',str(root/('replay_short_circuit_g614_'+mode+'.py'))],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    rows.append(dict(backend=mode,returncode=code,seconds=time.monotonic()-begun));print(json.dumps(rows[-1]),flush=True)
    if code:break
assert all(sha(root/k)==v for k,v in manifest.items())
(root/'controller.json').write_text(json.dumps(dict(finished_utc=datetime.now(timezone.utc).isoformat(),source_unchanged=True,results=rows),indent=2)+'\n')
assert len(rows)==2 and all(r['returncode']==0 for r in rows)

import sys,json,traceback
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from test_gpu_canopy_phase_surface import cases,reference
arrays=cases(np.float32);row=tuple(x[15] for x in arrays)
Path('failed-input.json').write_text(json.dumps([x.tolist() for x in row],indent=2))
caught=[]
def local(frame,event,arg):
 if event=='exception' and arg[0] is RuntimeError:caught.append(frame.f_locals.copy())
 return local
def trace(frame,event,arg):
 if event=='call' and frame.f_code.co_name=='solve_canopy_phase_energy':return local
sys.settrace(trace)
try:reference(row)
except Exception:traceback.print_exc()
finally:sys.settrace(None)
q=caught[-1];ev=q['evaluate'];x=q['x'];print('stalled', {k:q[k] for k in ('iteration','restarts','x','residual','delta','lower','upper')},flush=True)
for name,initial in [('stalled',x),('ambient',q['ambient']),('old',q['alternative'])]:
 for method in ('dogbox','trf'):
  z=least_squares(ev,initial,method=method,bounds=(q['lower'],q['upper']),xtol=1e-12,gtol=1e-12,ftol=1e-12,max_nfev=500)
  d=ev(z.x,True)
  print('reference',name,method,'norm',np.max(abs(z.fun)),'x',z.x,'mass',d['condensate'].mass,'physical',d['layer_residual'],flush=True)
  if np.max(abs(z.fun))<1e-5:
   Path('reference-solution.json').write_text(json.dumps(dict(x=z.x.tolist(),residual=z.fun.tolist(),method=method,name=name),indent=2))
print('Jacobian singular values',np.linalg.svd(q['jac'],compute_uv=False),flush=True)
for k in range(10):
 z=x.copy();z[k]=0.;print('move cold',k,np.max(abs(ev(z))),np.linalg.norm(ev(z)),flush=True)
 z=x.copy();z[k]=334000./4180.;print('move warm',k,np.max(abs(ev(z))),np.linalg.norm(ev(z)),flush=True)

"""Pack controlled official-week outputs without expanding NetCDF in shared home."""
from pathlib import Path
import argparse,hashlib,json,shutil,tarfile
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('destination',type=Path);a=p.parse_args()
root=a.root.resolve();assert root.is_relative_to(Path('/tmp')) and root.name.startswith('noahmp-hrldas-canopy-choice-a-')
completed=json.loads((root/'completed.json').read_text());assert completed['original_runtime_unchanged']
selected=[root/'protocol.json',root/'completed.json']
for result in completed['results']:
    assert result['control_ldasout_byte_equal']==337 and result['scientific_acceptance_claim'] is False
    site=root/result['site'];selected.append(site/'summary.json')
    for mode in result['modes']:
        selected += [site/mode/n for n in ['namelist.hrldas','run-receipt.json','audit.json','raw-conditions.npz','official.log','official-output.tar.gz']]
source=Path('/home/zhangyq/noahmp-v1/hrldas-canopy-choice-a')
selected += [p for p in source.iterdir() if p.is_file() and p.suffix in ['.py','.pbs','.log','.sha256','.txt']]
temporary=root/'hrldas-canopy-choice-a-evidence.tar.gz'
with tarfile.open(temporary,'w:gz') as t:
    for f in selected:t.add(f,arcname=f.relative_to(root).as_posix() if f.is_relative_to(root) else 'instruments/'+f.name,recursive=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not a.destination.exists();shutil.copyfile(temporary,a.destination);assert sha(temporary)==sha(a.destination)
print(json.dumps(dict(archive=str(a.destination),sha256=sha(a.destination),files=len(selected),bytes=a.destination.stat().st_size)))

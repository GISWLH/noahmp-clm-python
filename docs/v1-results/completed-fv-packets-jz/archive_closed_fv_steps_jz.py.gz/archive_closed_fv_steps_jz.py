"""Lossless compaction of completed446 raw step packets; no model evaluation."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,tarfile,tempfile,zipfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'multisite-numpy-cold-fv';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and len(d['cases'])==12 and all(q['failure'] is None and q['captured_steps']==48 for q in d['cases']) and (r/'pbs-exit.txt').read_text().strip()=='0';qstat=subprocess.check_output(['qstat','-xf',d['pbs_job']],text=True);assert re.search(r'^\s*job_state = F\s*$',qstat,re.M) and re.search(r'^\s*Exit_status = 0\s*$',qstat,re.M)
files=sorted((r/'runs').glob('*/steps/call-*.pkl.gz'));assert len(files)==576 and len({p.parent for p in files})==12;assert all(len(list(folder.glob('call-*.pkl.gz')))==48 for folder in {p.parent for p in files});root=r.resolve();inventory={}
for p in files:
    assert not p.is_symlink() and p.resolve().is_relative_to(root/'runs');inventory[p.relative_to(r).as_posix()]=dict(sha256=sha(p),bytes=p.stat().st_size)
targets={str(p.resolve()) for p in files}
for process in Path('/proc').iterdir():
    if not process.name.isdigit():continue
    try:
        if process.stat().st_uid!=os.getuid():continue
        for fd in (process/'fd').iterdir():
            try:assert str(fd.resolve()) not in targets,('Still-open completedpacket',str(fd))
            except (FileNotFoundError,PermissionError):pass
    except (FileNotFoundError,PermissionError):pass
archive=r/'closed-step-packets-jz.zip';assert not archive.exists();before=subprocess.check_output(['df','-i','/home/zhangyq'],text=True)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
    for p in files:z.write(p,p.relative_to(r).as_posix())
with archive.open('rb') as f:os.fsync(f.fileno())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,record in inventory.items():raw=z.read(name);assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
    with tempfile.TemporaryDirectory(prefix='noahmp-fv-restore-jz-',dir='/tmp') as directory:
        dest=Path(directory).resolve();assert dest.parent==Path('/tmp') and dest.name.startswith('noahmp-fv-restore-jz-')
        for name in z.namelist():
            target=dest/name;assert target.resolve().is_relative_to(dest);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name));assert sha(target)==inventory[name]['sha256']
fd=os.open(str(r),os.O_DIRECTORY);os.fsync(fd);os.close(fd)
manifest=r/'closed-step-packets-jz.json';manifest.write_text(json.dumps(dict(archive=archive.name,archive_sha256=sha(archive),original_paths=inventory,receipt_sha256=sha(r/'receipt.json'),actual_original_pbs=d['pbs_job'],all576_crc_sha_and_actual_tmp_restore_checked=True),indent=2)+'\n')
with manifest.open('rb') as f:os.fsync(f.fileno())
assert sha(archive)==json.loads(manifest.read_text())['archive_sha256']
for p in files:
    assert p.resolve().is_relative_to(root/'runs') and not p.is_symlink() and sha(p)==inventory[p.relative_to(r).as_posix()]['sha256'];p.unlink()
after=subprocess.check_output(['df','-i','/home/zhangyq'],text=True);readme=r/'closed-step-packets-jz.README.md';readme.write_text('# Completed446 raw packet storage\n\nAll576 original runs/*/steps/call-*.pkl.gz bytes are stored at their originalrelativepaths in closed-step-packets-jz.zip. Each SHA256/size is in closed-step-packets-jz.json. AllCRC/SHA andfulltemporary restoration were verified before removing scattered copies. No active state/checkpoint/input/trace/receipt/source was changed. Read a packet with ZipFile(archive).read(original_relative_path); verify its SHA against the manifest before trusted unpickling. Full restore, if needed andquota allows: iterate manifest paths, reject absolute/.. paths, write under this directory, verify SHA. Original physicsresults/status/receipts remain unchanged.\n')
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed_original_job=d['pbs_job'],original_actual_pbs_exit=0,packed_files=576,archive_sha256=sha(archive),original_inventory_sha256=sha(manifest),all576_crc_sha_and_full_tmp_restore_checked=True,open_file_check_passed=True,only_verified576_closed_step_packets_unlinked=True,quota_before=before,quota_after=after,scope='Losslesscompletedrawpacketcompaction only. Original coldstate/input/trajectory/checkpoint/receipt/source andallactivejobs unchanged. No physicsrerun/change/pass from archiveoperation. Original576 paths/bytes recoverable inoneZIP, no data removed fromevidence.')
receipt=r/'closed-step-packets-jz-receipt.json';receipt.write_text(json.dumps(record,indent=2)+'\n');packet=b/'completed-fv-packets-jz-evidence.tar.gz';assert not packet.exists();items=[archive,manifest,readme,receipt,Path(__file__)];inventory2={}
with tarfile.open(packet,'w:gz') as tf:
    for p in items:inventory2[p.name]=sha(p);tf.add(p,arcname=p.name,recursive=False)
with tarfile.open(packet) as tf:
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory2[member.name]
package=dict(archive=packet.name,sha256=sha(packet),bytes=packet.stat().st_size,artifacts=len(items),scope=record['scope']);(b/'completed-fv-packets-jz-package.json').write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(dict(package=package,record=record)),flush=True)

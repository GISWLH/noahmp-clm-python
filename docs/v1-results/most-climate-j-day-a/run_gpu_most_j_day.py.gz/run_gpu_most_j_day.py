from pathlib import Path
import hashlib,json,os,subprocess,sys,time
import numpy as np
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=base/'fluxnet-first-climate-cycle-20261017-j';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
reference_manifest=json.loads((root/'numpy-source-manifest.json').read_text())
differences={k:dict(native=v,numpy=reference_manifest[k]) for k,v in manifest.items() if k.startswith('src/') and v!=reference_manifest[k]}
assert set(differences)=={'src/noahmp_clm/physics/canopy_phase_energy.py','src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu','src/noahmp_clm/physics/canopy_most.py','src/noahmp_clm/gpu/canopy_most_surface.py','src/noahmp_clm/__init__.py','src/noahmp_clm/driver.py'}
begun=time.monotonic()
with (root/'cuda-day.log').open('w') as log:
    code=subprocess.run([sys.executable,'-u',str(source/'benchmarks/run_fluxnet_native.py'),'--batch',str(root/'batch.json'),'--output',str(root/'cuda-day'),'--stop-after','48'],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
(root/'cuda-day-exit.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun))+'\n');assert code==0
rows=[];failures=[]
for row in json.loads((root/'batch.json').read_text())['cases']:
    folders=[root/'cuda-day'/row['case'],root/'numpy-day'/row['case']];reports=[json.loads((p/'report.json').read_text()) for p in folders]
    assert all(r['source_unchanged'] and r['status']=='running' and r['steps_requested']==17520 and r['steps_completed']==48 for r in reports)
    for field in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert reports[0][field]==reports[1][field]
    assert all(v==reference_manifest[k] for k,v in reports[1]['source_sha256'].items())
    assert all(sha(source/k)==v for k,v in reports[0]['source_sha256'].items())
    data=[]
    for p,r in zip(folders,reports):
        path=p/r['model_npz'];assert sha(path)==r['model_npz_sha256']
        with np.load(path,allow_pickle=False) as z:data.append(dict(z))
    for key in ['time_start','time_end']:np.testing.assert_array_equal(data[0][key],data[1][key]);assert len(data[0][key])==48
    fields={}
    for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
        a,b=[d[key].astype(float)*factor+offset for d in data]
        if a.ndim==1:a=a[:,None];b=b[:,None]
        values=[compare_series(a[:,k],b[:,k],var) for k in range(a.shape[1])]
        for k,value in enumerate(values):
            if not value['bias_pass']:failures.append([row['case'],key,k,'bias',value['bias']])
            if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'] and value['correlation_pass'] is False:failures.append([row['case'],key,k,'r',value['r']])
        fields[key]=values
    rows.append(dict(case=row['case'],metrics=fields,reports_sha256=[sha(p/'report.json') for p in folders],
        maximum_cumulative_m_h_c_n={name:r['maximum_cumulative_residual_m_h_c_n'] for name,r in zip(['cuda32','numpy64'],reports)}))
assert all(sha(source/k)==v for k,v in manifest.items())
result=dict(scope='Four fresh explicit-suction first48 CUDA32 versus independent NumPy64. Disclosed seven runtime differences: three phase solver files, two numerical MOST schedules, two public entry files, identical physical equations; not annual/spinup/observed acceptance or a JAX trajectory.',cases=rows,failures=failures,source_differences=differences,instrument_sha256=sha(Path(__file__)),source_unchanged=True)
(root/'backend-day-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(failures=failures,source_unchanged=True,cases=len(rows))),flush=True)
assert not failures,failures

# The prior I48 archive cannot advance or change identity after its export.
import io,tarfile
from run_fluxnet_native import read_generation
archive=base/'short-circuit-climate-i-day-evidence.tar.gz'
assert sha(archive)=='745d13275acee7d840ac1cdd944aaf679b1e5c0b8d7479adbe0f4ca0f777bc34'
global_report,state,cases=read_generation(root/'cuda-day');proof=[];state_differences=[]
with tarfile.open(archive) as t:
    baseline=json.load(t.extractfile('cuda-day/batch.json'));assert baseline['steps_completed']==48
    for (report,data),identity in zip(cases,global_report['identity']['cases']):
        case=identity['case'];descriptor=baseline['case_reports'][case]
        old_report=json.load(t.extractfile('cuda-day/'+case+'/'+descriptor['file']))
        for field in ['configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256']:assert report[field]==old_report[field]
        raw=t.extractfile('cuda-day/'+case+'/'+old_report['model_npz']).read();assert hashlib.sha256(raw).hexdigest()==old_report['model_npz_sha256']
        fields={}
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:
            assert set(z.files)==set(data)
            for key in data:
                left,right=z[key],data[key];assert left.dtype==right.dtype and left.shape==right.shape
                fields[key]=dict(bitwise_equal=left.tobytes()==right.tobytes(),maximum_absolute_difference=None if left.dtype.kind not in 'fiu' else float(abs(left.astype(float)-right.astype(float)).max()))
        proof.append(dict(case=case,fields=fields))
    raw=t.extractfile('cuda-day/'+baseline['checkpoint_file']).read();assert hashlib.sha256(raw).hexdigest()==baseline['checkpoint_sha256']
    with np.load(io.BytesIO(raw),allow_pickle=False) as z:
        assert set(z.files)==set(state)
        for key in state:
            left,right=z[key],state[key];assert left.dtype==right.dtype and left.shape==right.shape
            state_differences.append(dict(field=key,bitwise_equal=left.tobytes()==right.tobytes(),maximum_absolute_difference=float(abs(left.astype(float)-right.astype(float)).max())))
proof_result=dict(scope='Fresh J48 against immutable original I48; differences fully disclosed, independent NumPy science/conservation comparison above remains required. No I checkpoint reused.',baseline_archive_sha256=sha(archive),cases=proof,checkpoint_fields=state_differences)
proof_result['all_fields_bitwise_equal']=all(v['bitwise_equal'] for c in proof for v in c['fields'].values()) and all(v['bitwise_equal'] for v in state_differences)
(root/'pre-change-i48-comparison.json').write_text(json.dumps(proof_result,indent=2)+'\n')
print(json.dumps(dict(all_fields_bitwise_equal=proof_result['all_fields_bitwise_equal'])),flush=True)

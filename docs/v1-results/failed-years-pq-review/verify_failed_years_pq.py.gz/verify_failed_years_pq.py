"""Stdlib byte/header verification of closed NS/NZ evidence; no scientific compute."""
import ast
import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def headers(data):
    fields = {}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            raw = archive.read(name)
            assert raw[:6] == b'\x93NUMPY'
            version = tuple(raw[6:8])
            assert version in ((1, 0), (2, 0), (3, 0))
            width = 2 if version == (1, 0) else 4
            length = int.from_bytes(raw[8:8 + width], 'little')
            header = ast.literal_eval(raw[8 + width:8 + width + length].decode('utf-8' if version == (3, 0) else 'latin1'))
            payload = raw[8 + width + length:]
            fields[name[:-4]] = dict(dtype=header['descr'], shape=list(header['shape']), fortran_order=header['fortran_order'],
                payload_bytes=len(payload), payload_sha256=sha(payload))
            if name == 'index.npy':
                assert header['shape'] == () and header['descr'] == '<i8'
                fields['index']['scalar_value'] = struct.unpack('<q', payload)[0]
    return fields


def main():
    package = json.loads((ROOT / 'failed-years-pq-package.json').read_text())
    path = ROOT / package['archive']
    assert sha(path.read_bytes()) == package['sha256'] == 'a5f337cf0623d0ae00da40829673f9ae3b283b6dd33a45c2b4db47e20a33d046'
    nt_path = ROOT / 'candidate-launches-nt-evidence.tar.gz'
    nt_package = json.loads((ROOT / 'candidate-launches-nt-package.json').read_text())
    assert sha(nt_path.read_bytes()) == nt_package['sha256']
    result = dict(passed=True, archive_sha256=package['sha256'], artifacts=package['artifacts'],
        original_launch_archive_sha256=nt_package['sha256'], scientific_arrays_decoded=0,
        scalar_index_decoded=True, model_calls=0, gpu_calls=0, years={})
    with tarfile.open(path, 'r:gz') as archive, tarfile.open(nt_path, 'r:gz') as nt:
        data = {m.name: archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
        assert len(data) == package['artifacts'] == len(archive.getmembers()) == 658
        inventory = json.loads(data['INVENTORY.json'])
        assert set(inventory) == set(data) - {'INVENTORY.json'} and len(inventory) == 657
        assert all(sha(data[n]) == v['sha256'] and len(data[n]) == v['bytes'] for n, v in inventory.items())
        summary = json.loads(data['SUMMARY.json'])
        assert data['SUMMARY.json'] == (ROOT / 'failed-years-pq-summary.json').read_bytes()
        assert sha(data['source/candidate-source.tar.gz']) == package['source_archive_sha256']
        with tarfile.open(fileobj=io.BytesIO(data['source/candidate-source.tar.gz']), mode='r:gz') as source:
            manifest_raw = source.extractfile('SOURCE_SHA256.json').read()
            assert sha(manifest_raw) == package['source_manifest_sha256']
            manifest = json.loads(manifest_raw)
            assert len(manifest) == 584
            assert all(sha(source.extractfile(n).read()) == h for n, h in manifest.items())
        for label, columns in [('NS', 12), ('NZ', 3)]:
            prefix = label + '/current/'
            row = summary['years'][label]
            end, receipt, report = [json.loads(data[prefix + n]) for n in ('year-exit.json', 'year-receipt.json', 'trajectory/batch.json')]
            assert end['actual_parent_returncode'] == 1 and end['passed'] is False and end['failure'] is None
            assert end['receipt_sha256'] == sha(data[prefix + 'year-receipt.json'])
            assert receipt['report_sha256'] == sha(data[prefix + 'trajectory/batch.json'])
            assert receipt['status'] == report['status'] == 'failed'
            assert report['failed_step'] == report['steps_completed'] == report['ledger_steps'] == 7275
            assert report['columns'] == columns and report['steps_requested'] == 17520 and report['ledger_segments'] == 1
            assert receipt['source_unchanged'] and receipt['device_barrier_complete']
            checkpoint = data[prefix + 'trajectory/' + report['checkpoint_file']]
            assert sha(checkpoint) == report['checkpoint_sha256']
            desc = headers(checkpoint)
            assert len(desc) == 23 and desc == row['checkpoint_fields'] and desc['index']['scalar_value'] == 7275
            assert row['source_before_after_verified'] and row['control_before_after_verified']
            assert all(not p['exists'] for p in row['original_processes'])
            old_report = json.load(nt.extractfile('remote/' + label + '/snapshot/batch.json'))
            assert report['identity'] == old_report['identity']
            launch_matches = []
            for member in nt.getmembers():
                marker = 'remote/' + label + '/controls/'
                if member.name.startswith(marker):
                    destination = label + '/year-controller/' + member.name[len(marker):]
                    assert data[destination] == nt.extractfile(member).read(), destination
                    launch_matches.append(destination)
            for original, destination in [
                ('plan.json', label + '/year-controller/plan.json'),
                ('SOURCE_SHA256.json', label + '/source/SOURCE_SHA256.json'),
                ('original-prefix-plan.json', label + '/original-root/plan.json'),
                *[(n, prefix + n) for n in ('year-launch.json', 'year-worker.json', 'year-prefix-binding.json',
                                           'year-start-audit.json', 'validated-prefix-report.json')],
            ]:
                assert data[destination] == nt.extractfile('remote/' + label + '/' + original).read()
                launch_matches.append(destination)
            batch = json.loads(data[prefix + 'inputs/batch.json'])
            assert sha(data[prefix + 'inputs/batch.json']) == report['identity']['batch_sha256']
            assert len(batch['cases']) == len(report['identity']['cases']) == columns
            for case, identity in zip(batch['cases'], report['identity']['cases']):
                assert case['case'] == identity['case']
                for path_key, sha_key in [('input', 'forcing_npz_sha256'), ('input_manifest', 'forcing_manifest_sha256'), ('configuration', 'configuration_sha256')]:
                    assert sha(data[prefix + 'inputs/' + case[path_key]]) == identity[sha_key]
            assert len(receipt['bgc_diagnostic_chunks']) == 150
            for item in receipt['bgc_diagnostic_chunks']:
                name = prefix + f"year-bgc-diagnostics/steps-{item['first']:07d}-{item['end']:07d}.npz"
                assert sha(data[name]) == item['sha256']
            assert receipt['bgc_diagnostic_steps'] == 7227
            assert row['successful_bgc_steps_without_persisted_chunk'] == 27
            result['years'][label] = dict(actual_worker_returncode=1, parent_record_passed=False,
                controller_extra_exception=None, status='failed', completed=7275, requested=17520,
                checkpoint_fields=23, primary_state_arrays=16, ledger_fields_including_index=7,
                checkpoint_header_and_payload_hashes_exact=True, launch_immutable_byte_matches=len(launch_matches),
                identity_exact_to_original_launch=True, original_input_configs_bound=columns,
                source_files=584, source_before_after_exact=True, controls_before_after_exact=True,
                byte_verified_bgc_chunks=150, persisted_bgc_end=7248, unpersisted_successful_bgc_steps=27,
                failure=receipt['failure'], failed_input_packet_saved=False,
                replay_limit=row['replay_scope'], original_processes=row['original_processes'])
        result['all_inventory_files_verified'] = len(inventory)
    result['limits'] = [
        'This is byte/metadata closure of failed attempts, not physical or annual acceptance.',
        'A saved committed7275 state is retained; no actual failed before_device/kwargs packet or internal surface trial is claimed.',
        'BGC records for27 successfully completed steps after7248 were buffered only and are absent from disk.',
        'Original detached controller has no separate OS wait receipt; worker return1 is directly observed by its original controller record.',
        'No scientific values were recomputed or tolerances changed. Original trees and GPU tasks were untouched.',
    ]
    output = ROOT / 'failed-years-pq-local-verification.json'
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(passed=True, sha256=sha(output.read_bytes()), inventory_files=657,
                         launch_byte_matches={k: v['launch_immutable_byte_matches'] for k, v in result['years'].items()})))


if __name__ == '__main__':
    main()

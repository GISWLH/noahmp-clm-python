"""Read only the original NS/NZ terminal artifacts, source and PID identities."""
from pathlib import Path
import datetime
import hashlib
import json
import os

BASE = Path('/home/lhwang/work/noahmp-v1')
SPECS = {
    'NS': ('climatology-cold48-np', 'climatology-year-ns', '/tmp/noahmp-climatology-cold48-np/source'),
    'NZ': ('hrldas-candidate-cold48-ny', 'hrldas-year-nz', '/tmp/noahmp-hrldas-candidate-cold48-ny/source'),
}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_text())


def main():
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), hostname=os.uname().nodename,
                  scope='Read-only terminal metadata/source/PID inventory; no NumPy/model/GPU calls.', years={})
    for label, (original, controller, source_path) in SPECS.items():
        root, control, source = BASE / original, BASE / controller, Path(source_path)
        current = root / 'cold48'
        plan = load(control / 'plan.json')
        source = Path(plan['source'])
        report = load(current / 'trajectory/batch.json')
        manifest = load(source / 'SOURCE_SHA256.json')
        source_bad = [name for name, expected in manifest.items() if sha(source / name) != expected]
        control_bad = [name for name, expected in plan['controls_sha256'].items() if sha(control / name) != expected]
        fields = {}
        for name in ('year-launch.json', 'year-worker.json', 'year-exit.json', 'year-receipt.json'):
            value = load(current / name)
            fields[name] = {k: v for k, v in value.items() if k != 'bgc_diagnostic_chunks'}
        pids = []
        for name in ('year-launch.json', 'year-worker.json'):
            pid = fields[name]['pid']
            path = Path('/proc') / str(pid)
            record = dict(pid=pid, exists=path.exists())
            if path.exists():
                record['stat'] = (path / 'stat').read_text()
                record['cmdline'] = (path / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            pids.append(record)
        files = lambda folder: [{'name': p.name, 'bytes': p.stat().st_size} for p in sorted(folder.iterdir()) if p.is_file()]
        result['years'][label] = dict(root=str(root), controller=str(control), source=str(source),
            terminal=fields, processes=pids, source_manifest_sha256=sha(source / 'SOURCE_SHA256.json'),
            source_files=len(manifest), source_mismatches=source_bad, control_mismatches=control_bad,
            root_files=files(root), current_files=files(current), control_files=files(control),
            report={k: v for k, v in report.items() if k not in ('identity', 'case_reports', 'maximum_cumulative_residual_m_h_c_n', 'cumulative_numerical_bounds_m_h_c_n')},
            case_report_count=len(report['case_reports']), checkpoint_bytes=(current / 'trajectory' / report['checkpoint_file']).stat().st_size,
            bgc_files=len(list((current / 'year-bgc-diagnostics').glob('*'))),
            bgc_bytes=sum(p.stat().st_size for p in (current / 'year-bgc-diagnostics').glob('*') if p.is_file()),
            suspicious_named_files=[str(p.relative_to(current)) for p in current.rglob('*') if p.is_file()
                and any(word in p.name.lower() for word in ('failed', 'failure', 'partial', 'before', 'export'))])
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

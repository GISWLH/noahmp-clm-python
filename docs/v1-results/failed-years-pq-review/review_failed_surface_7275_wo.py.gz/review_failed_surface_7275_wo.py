"""Static NM failure-path/source/input-identity check. No scientific imports or array decoding."""
import ast
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def archive(name):
    with tarfile.open(ROOT / name) as stream:
        return {m.name: stream.extractfile(m).read() for m in stream.getmembers() if m.isfile()}


def main():
    inspection_raw = (ROOT / 'failed-years-pq-inspection.json').read_bytes()
    inspection = json.loads(inspection_raw)
    nm = archive('climatology-final-candidate-nm-source.tar.gz')
    assert sha(nm['SOURCE_SHA256.json']) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    manifest = json.loads(nm['SOURCE_SHA256.json'])
    names = ['benchmarks/run_fluxnet_native.py', 'src/noahmp_clm/gpu/clm_bgc_column.py',
             'src/noahmp_clm/gpu/canopy_most_surface.py', 'src/noahmp_clm/gpu/canopy_phase_surface.py',
             'src/noahmp_clm/gpu/canopy_surface.py', 'src/noahmp_clm/gpu/canopy_phase_energy.py',
             'src/noahmp_clm/gpu/cuda/clm_layered_column.py', 'src/noahmp_clm/gpu/cuda/canopy_phase_surface.py',
             'src/noahmp_clm/gpu/cuda/canopy_phase_surface_kernel.cu',
             'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu',
             'src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu',
             'src/noahmp_clm/gpu/cuda/column_heat_kernel.cu']
    hashes = {}
    for name in names:
        raw = (REPO / name).read_bytes()
        assert raw == nm[name] and sha(raw) == manifest[name], name
        if name.endswith('.py'):
            ast.parse(raw)
        hashes[name] = sha(raw)
    statuses = {}
    for label, entry in inspection['years'].items():
        report, terminal = entry['report'], entry['terminal']
        assert report['status'] == 'failed' and report['steps_completed'] == report['ledger_steps'] == 7275
        assert report['steps_requested'] == 17520
        assert terminal['year-exit.json']['actual_parent_returncode'] == 1
        assert terminal['year-receipt.json']['bgc_diagnostic_steps'] == 7227
        assert entry['source_files'] == 584 and not entry['source_mismatches'] and not entry['control_mismatches']
        assert all(not p['exists'] for p in entry['processes'])
        assert entry['bgc_files'] == 150
        assert 'canopy_phase_surface.py' in report['failure'] and 'line 64' in report['failure']
        statuses[label] = {'actual_parent_exit': 1, 'successful_steps': 7275,
                           'failed_input_index_zero_based': 7275,
                           'checkpoint_sha256': report['checkpoint_sha256'],
                           'checkpoint_members_expected_from_original_runner': 23,
                           'persisted_postprefix_BGC_blocks': 150, 'persisted_postprefix_BGC_steps': 7200,
                           'first48_separate': True, 'postprefix_audit_count_in_receipt': 7227,
                           'unflushed_BGC_records_inferred_from_original_wrapper': 27,
                           'year_complete': False}
    jr = archive('multisite-climatology-jr-inputs.tar.gz')
    kg = archive('hrldas-current-kg-inputs.tar.gz')
    shared = {}
    for site in ('CN-Qia', 'CN-Cha'):
        assert jr[site + '.npz'] == kg[site + '.npz']
        metas = [json.loads(data[site + '.json']) for data in (jr, kg)]
        assert all(m['start'] == '2003-01-01' and m['dt_seconds'] == 1800 and m['steps'] == 17520 for m in metas)
        start = datetime.fromisoformat(metas[0]['start']) + timedelta(seconds=7275 * 1800)
        shared[site] = {'input_npz_sha256': sha(jr[site + '.npz']), 'input_archive_member_byteexact': True,
                        'metadata_byteexact': jr[site + '.json'] == kg[site + '.json'],
                        'calendar_derived_failed_interval': [start.isoformat(), (start + timedelta(seconds=1800)).isoformat()],
                        'interval_row_not_decoded': True, 'same_state_not_claimed': True}
    result = {
        'passed': True, 'actual_static_exit': 0, 'diagnosis_complete': False,
        'scope': 'Static control flow and archived metadata/opaque NPZ-byte identities only; no replay, scientific import, decoded array, source edit or acceptance credit.',
        'inspection_sha256': sha(inspection_raw), 'inspection_utc': inspection['utc'],
        'source_manifest_sha256': sha(nm['SOURCE_SHA256.json']), 'source_files_read_byteexact_to_NM': hashes,
        'original_wrapper_sha256': {label: sha((ROOT / directory / filename).read_bytes())
                                   for label, directory, filename in [
                                       ('NS', 'climatology-year-ns-preparation', 'run_year_ns.py'),
                                       ('NZ', 'hrldas-year-nz-preparation', 'run_year_nz.py')]},
        'observed_statuses': statuses, 'common_forcing_metadata': shared,
        'first_discriminating_probe': 'Original failed-state clone, one unchanged original batch step, transparent wrapper copies actual surface inputs and raw741 before original unpack/raise. Preserve original exception and do not advance a trajectory.',
        'exception_does_not_identify_single_cause': True,
        'raw_output_map': {'surface_temperature': 360, 'surface_temperature_residual': 361,
                           'combined_inner_valid': 362, 'joint_heat_converged': 341,
                           'joint_heat_iterations': 340, 'joint_heat_maximum_tolerance': 342,
                           'joint_heat_residuals_slice': [311, 320], 'joint_heat_tolerances_slice': [328, 337],
                           'surface_evaluations': 432, 'final_converged': 433, 'root_bracket_slice': [439, 441],
                           'phase_iterations': 508, 'phase_converged': 509,
                           'phase_physical_residual_slice': [496, 507], 'phase_coordinates_slice': [716, 726],
                           'phase_restarts': 732, 'phase_max_solver_residual': 733},
        'preserved_gates': 'Original phase .005 and physical *1.05, original temperature resolution/bracket signs, all heat/transport/finite gates; no new tolerance or exception swallowing.',
        'scientific_calls': 0, 'GPU_calls': 0, 'array_value_decodes': 0,
        'readout_sha256': sha((ROOT / 'FAILED_SURFACE_7275_STATIC_WO.md').read_bytes()),
        'script_sha256': sha(Path(__file__).read_bytes())}
    output = ROOT / 'failed-surface-7275-static-wo.json'
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'actual_static_exit': 0, 'result_sha256': sha(output.read_bytes()),
                      'source_files_checked': len(hashes), 'diagnosis_complete': False,
                      'common_forcing_sites': list(shared)}))


if __name__ == '__main__':
    main()

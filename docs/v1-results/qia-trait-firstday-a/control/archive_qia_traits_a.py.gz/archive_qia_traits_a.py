from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
roots = [b / name for name in ['qia-trait-bb-only-a', 'qia-trait-pft-upper-a', 'qia-trait-firstday-comparison-a', 'qia-trait-firstday-comparison-b']]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for root in roots[:2]:
    d = json.loads((root / 'receipt.json').read_text())
    assert (root / 'pbs-exit.txt').read_text().strip() == '0' and d['returncode'] == 0 and d['source_unchanged'] and d['steps_completed'] == 48
assert (roots[2] / 'pbs-exit.txt').read_text().strip() == '1' and 'AssertionError' in (roots[2] / 'comparison.log').read_text()
assert (roots[3] / 'pbs-exit.txt').read_text().strip() == '0'
d = json.loads((roots[3] / 'comparison.json').read_text())
assert d['pbs_job'] == '250.manager' and d['original_baseline_all_metrics_exact'] and not d['scientific_acceptance']
assert set(d['cases']) == {'original-generic', 'bb-only', 'pft-upper'} and all(row['status'] == 'measured original first48 diagnostic only' for row in d['cases'].values())
a = b / 'qia-trait-firstday-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for root in roots:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                t.add(p, arcname=root.name + '/' + p.relative_to(root).as_posix(), recursive=False)
    for name in ['qia-trait-diagnostic-a-protocol.json', 'dispatch_qia_trait_diagnostic_a.py', 'dispatch_qia_trait_comparison_a.py', 'archive_qia_traits_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    summary = dict(scope='Prospective originalfirst48 allcases retained,actual EHPC models/PBS243/244both0,analysis249 original-float32-cast metric assertion1 retained,250 restores prior float64-rate arithmetic/no modelrerun and exactly reproduces priorR generic baseline. Original generic and two declared trait cases,no new production input,score selection or science/year acceptance. Fixed soil/C-N/height/met/window/daylengthupper1 interpretation unchanged.',
                   models={p.name: json.loads((p / 'receipt.json').read_text()) for p in roots[:2]}, original_analysis_failure_pbs='249.manager', actual_analysis_pbs='250.manager', comparison_sha256=sha(roots[3] / 'comparison.json'),
                   original_protocol_sha256=sha(b / 'qia-trait-diagnostic-a-protocol.json'))
    raw = (json.dumps(summary, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

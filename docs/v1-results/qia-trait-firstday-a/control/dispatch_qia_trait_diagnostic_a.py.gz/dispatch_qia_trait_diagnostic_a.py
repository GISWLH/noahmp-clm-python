from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
protocol = dict(scope='Prospective original-first48 cold diagnostics,keep all model/state/soil/C-N/root/LAI/height/met/observation/window choices fixed. Two cases: only official PFT1 Ball-Berry slope; or combined originalPFT1 equation upper capacities(daylengthfactor1),Jratio/TPU/Rd and actual S daylight-acclimation lower bound11C plus slope. No new production defaults or actual daylength reproduction claimed; everycase and original generic baseline retained,not score selection/calibration/science acceptance.',
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), endstop=48, original_steps_requested=17520,
                cases=['bb-only', 'pft-upper'], original_native_config_sha256='339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1',
                controls_sha256={n: hashlib.sha256((b / n).read_bytes()).hexdigest() for n in ['run_qia_trait_diagnostic_a.py', 'qia_trait_diagnostic_a.pbs', 'dispatch_qia_trait_diagnostic_a.py']})
path = b / 'qia-trait-diagnostic-a-protocol.json'
assert not path.exists()
path.write_text(json.dumps(protocol, indent=2) + '\n')
records = []
for label in protocol['cases']:
    r = b / ('qia-trait-' + label + '-a'); r.mkdir(exist_ok=False)
    for name in ['run_qia_trait_diagnostic_a.py', 'qia_trait_diagnostic_a.pbs', path.name]:
        shutil.copyfile(b / name, r / name)
    assert b'\r' not in (r / 'qia_trait_diagnostic_a.pbs').read_bytes()
    job = subprocess.check_output(['qsub', '-v', 'TRAIT_CASE=' + label, 'qia_trait_diagnostic_a.pbs'], cwd=r, text=True).strip()
    record = dict(case=label, pbs_job=job, protocol_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
print(json.dumps(records))

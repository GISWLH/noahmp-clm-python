from pathlib import Path
import json
import shutil
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-trait-firstday-comparison-a'; r.mkdir(exist_ok=False)
for name in ['compare_qia_traits_firstday_a.py', 'qia_trait_comparison_a.pbs']:
    shutil.copyfile(b / name, r / name)
assert (b / 'qia-trait-bb-only-a/pbs-exit.txt').read_text().strip() == '0'
q = subprocess.run(['qstat', '244.manager'], capture_output=True, text=True)
cmd = ['qsub']
if q.returncode == 0:
    cmd += ['-W', 'depend=afterany:244.manager']
else:
    assert (b / 'qia-trait-pft-upper-a/pbs-exit.txt').exists()
cmd += ['qia_trait_comparison_a.pbs']
job = subprocess.check_output(cmd, cwd=r, text=True).strip()
record = dict(pbs_job=job, command=cmd, original_parent244_qstat_returncode=q.returncode, scope='All declared cases retained;only live244 dependency,not stale historical243 dependency.')
(r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

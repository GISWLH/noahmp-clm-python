from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time

assert os.environ.get('PBS_JOBID')
label = os.environ['TRAIT_CASE']
assert label in ['bb-only', 'pft-upper']
b = Path('/home/zhangyq/noahmp-v1')
r = b / ('qia-trait-' + label + '-a')
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
archive = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(archive) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(archive) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 510 and all(sha(s / n) == v for n, v in m.items())
original = b / 'qia-stem-inputs-a/inputs'
assert sha(original / 'CN-Qia-stem-config.json') == '339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1'
assert sha(original / 'CN-Qia.npz') == '237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
config = json.loads((original / 'CN-Qia-stem-config.json').read_text())
official = json.loads((b / 'ctsm-qia-run-s/physiology-restarts.json').read_text())
memory = json.loads((b / 'ctsm-qia-physiology-t-a/diagnosis.json').read_text())
assert memory['original_S_readback_sha256'] == sha(b / 'ctsm-qia-run-s/physiology-restarts.json')
assert all(v == 11. for v in memory['daylight_before_growth_temperature_clipped_11_35_C'])
old = config['leaf_parameters'].copy()
traits = official['original_traits']
config['leaf_parameters']['ball_berry_slope'] = traits['mbbopt']['value']
if label == 'pft-upper':
    vcmax = official['equation_maximum_vcmax25_without_daylength']
    growth_c = 11.
    config['leaf_parameters'].update(vcmax25=vcmax, jmax25=(2.59 - .035 * growth_c) * vcmax,
                                   tpu25=.167 * vcmax, respiration25=.015 * vcmax, growth_temperature=273.15 + growth_c)
config['scope'] += ' Diagnostic ' + label + ': original same cold state/physics/met/site,only predeclared leaf scalar traits changed. WholePFT case uses daylengthfactor1 upper bound,not actual official daylength or fitted effective trait. All cases retained,not a new production default or scientific acceptance.'
(r / 'config.json').write_text(json.dumps(config, indent=2, allow_nan=False) + '\n')
(r / 'SOURCE_SHA256.json').write_bytes((s / 'SOURCE_SHA256.json').read_bytes())
env = os.environ.copy()
env.update(PYTHONPATH=':'.join(map(str, [b / 'test-deps', s, s / 'src', s / 'benchmarks'])),
           PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
env.pop('NOAHMP_REQUIRE_GPU', None)
command = [sys.executable, '-u', str(s / 'benchmarks/run_fluxnet_column.py'), '--input', str(original / 'CN-Qia.npz'),
           '--input-manifest', str(original / 'CN-Qia.json'), '--config', str(r / 'config.json'), '--output', str(r / 'trajectory'), '--stop-after', '48']
start = time.monotonic()
launch = dict(scope=config['scope'], pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, label=label,
              original_config_sha256=sha(original / 'CN-Qia-stem-config.json'), original_leaf_parameters=old,
              declared_leaf_parameters=config['leaf_parameters'], config_sha256=sha(r / 'config.json'),
              actual_S_readback_sha256=sha(b / 'ctsm-qia-run-s/physiology-restarts.json'),
              actual_T_readback_sha256=sha(b / 'ctsm-qia-physiology-t-a/diagnosis.json'),
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), command=command)
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
with (r / 'model.log').open('x') as log:
    code = subprocess.run(command, cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
p = r / 'trajectory/report.json'
d = json.loads(p.read_text()) if p.exists() else None
receipt = dict(scope=config['scope'], label=label, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
               returncode=code, seconds=time.monotonic() - start, source_unchanged=all(sha(s / n) == h for n, h in m.items()),
               status=d['status'] if d else None, steps_completed=d['steps_completed'] if d else None,
               report_sha256=sha(p) if p.exists() else None)
(r / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
assert code == 0 and receipt['source_unchanged'] and d['status'] == 'running' and d['steps_completed'] == 48 and d['steps_requested'] == 17520

from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-trait-firstday-comparison-b'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
archive = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(archive) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(archive) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s / 'src')]
from noahmp_clm.validation import compare_series

official = b / 'ctsm-qia-run-r'
audit = json.loads((official / 'year-boundary.json').read_text())
assert (official / 'pbs-exit.txt').read_text().strip() == '0' and sha(official / 'official-year-fields.npz') == audit['fields_sha256']
with np.load(official / 'official-year-fields.npz', allow_pickle=False) as z:
    ref = dict(z)
assert np.array_equal(ref['time_bounds_seconds'][:48], np.arange(48)[:, None] * 1800 + [[0, 1800]])
config = json.loads((b / 'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json').read_text())
target_dz = np.asarray(config['column']['dz'], float)
te = np.r_[0., np.cumsum(target_dz)]; se = np.r_[0., np.cumsum(np.asarray(ref['DZSOI'], float).reshape(15))]
overlap = np.maximum(0., np.minimum(te[1:, None], se[None, 1:]) - np.maximum(te[:-1, None], se[None, :-1])) / target_dz[:, None]
assert np.max(abs(overlap.sum(1) - 1.)) < 1e-14 and np.all(overlap[:, 10:] == 0.)
cases = {}
for label, root in [('original-generic', b / 'qia-fresh-phase-numpy-week-a'), ('bb-only', b / 'qia-trait-bb-only-a'), ('pft-upper', b / 'qia-trait-pft-upper-a')]:
    receipt = json.loads((root / 'receipt.json').read_text())
    report = json.loads((root / 'trajectory/report.json').read_text())
    assert sha(root / 'trajectory/report.json') == receipt['report_sha256']
    declared = config['leaf_parameters'] if label == 'original-generic' else json.loads((root / 'config.json').read_text())['leaf_parameters']
    if receipt['returncode'] != 0 or (root / 'pbs-exit.txt').read_text().strip() != '0' or not receipt['source_unchanged'] or report['steps_completed'] < 48:
        cases[label] = dict(status='unmeasured: original48-day diagnostic failed/incomplete', receipt=receipt, declared_leaf_parameters=declared)
        continue
    trace = root / 'trajectory' / report['model_npz']
    assert sha(trace) == report['model_npz_sha256'] and report['forcing_npz_sha256'] == '237dacf7f7d62d48f44cc28ed8213a94731419c77b98b1d9c77d94d3b3272960'
    with np.load(trace, allow_pickle=False) as z:
        model = {name: np.asarray(value)[:48] for name, value in z.items()}
    assert str(model['time_start'][0]) == '200301010000' and str(model['time_end'][-1]) == '200301020000'
    metrics = {}
    for name, source, factor, unit in [('h_wm2', 'FSH', 1., 'h_wm2'), ('le_wm2', 'EFLX_LH_TOT', 1., 'le_wm2'),
            ('et_mm', 'QFLX_EVAP_TOT', 86400., 'et_mm_day'), ('runoff_mm', 'QRUNOFF', 86400., 'runoff_mm_day'),
            ('gpp_gc_m2', 'FPSN', 12.0107e-6 * 86400., 'gpp_gc_day'), ('swe_m', 'H2OSNO', .001, 'swe_m')]:
        actual = np.asarray(model[name], float).reshape(48) * (48. if name in ['et_mm', 'runoff_mm', 'gpp_gc_m2'] else 1.)
        expected = np.asarray(ref[source][:48], float).reshape(48) * factor
        metrics[name] = compare_series(actual, expected, unit, weights=np.full(48, 1800.))
    soil_t = np.asarray(ref['TSOI'][:48], float).reshape(48, 15) @ overlap.T
    soil_w = np.asarray(ref['H2OSOI'][:48], float).reshape(48, 10) @ overlap[:, :10].T
    for name, expected, unit, offset in [('tsoil_k', soil_t, 'tsoil_c', 273.15), ('smc_m3m3', soil_w, 'smc', 0.)]:
        for layer in range(4):
            metrics[name + '/' + str(layer)] = compare_series(model[name][:, layer] - offset, expected[:, layer] - offset, unit, weights=np.full(48, 1800.))
    cases[label] = dict(status='measured original first48 diagnostic only', metrics=metrics, declared_leaf_parameters=declared,
                        trace_sha256=sha(trace), report_sha256=sha(root / 'trajectory/report.json'), receipt=receipt)
old = json.loads((b / 'ctsm-qia-seed-firstday-c/diagnosis.json').read_text())
differences = {name: {key: dict(new=value, prior=old['cases']['R']['metrics'][name][key]) for key, value in row.items() if value != old['cases']['R']['metrics'][name][key]} for name, row in cases['original-generic']['metrics'].items()}
(r / 'baseline-differences.json').write_text(json.dumps(differences, indent=2, allow_nan=False) + '\n')
assert cases['original-generic']['metrics'] == old['cases']['R']['metrics']
record = dict(scope='Predeclared all-case first48 input-trait diagnostic on EHPC PBS. Original analysis249 lacked prior float64 cast before multiplying official float32 rates;retain its baseline-exact assertion failure,no rerun of model or changed inputs/windows. B restores exact prior metric arithmetic and records baseline differences before assertion. Original generic baseline exactly reproduces priorR comparison;officialPFT slope-only and combined daylengthfactor1 capacity-upper cases all retained,no score-based choice or new production default. Complete original surface/soil/C-N/height/met/windows fixed apart from explicit leaf scalars. No fullPFT/daylength mapping,science/year/spinup or observational acceptance;SPNEE unmeasured.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, samples=48, cases=cases,
              protocol_sha256=sha(b / 'qia-trait-diagnostic-a-protocol.json'), official_R_fields_sha256=audit['fields_sha256'],
              original_baseline_all_metrics_exact=True, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'),
              original_S_physiology_sha256=sha(b / 'ctsm-qia-run-s/physiology-restarts.json'), soil_overlap_weights=overlap.tolist(), scientific_acceptance=False)
(r / 'comparison.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({label: dict(status=row['status'], metrics=row.get('metrics'), declared_leaf_parameters=row['declared_leaf_parameters']) for label, row in cases.items()}, allow_nan=False), flush=True)

from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/noahmp-pj-capacity-resume-qd-b')
controller=root/'resume_capacity_pj_qd.py'
assert hashlib.sha256(controller.read_bytes()).hexdigest()=='62694b3eae242b33f1ac097b4e6705e57974579c8a2dcca749fd6f6b707e0d53'
assert not (root/'CONTROLLER_STARTED.json').exists()
assert not (root/'controller.stdout').exists()
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (root/'controller.stdout').open('xb') as stdout,(root/'controller.stderr').open('xb') as stderr:
    child=subprocess.Popen(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B',str(controller),'--run'],
        stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,env=env,start_new_session=True)
pid=child.pid
stat=Path('/proc')/str(pid)/'stat'
print(json.dumps(dict(controller_pid=pid,start_ticks=int(stat.read_text().rsplit(')',1)[1].split()[19]),
    detached_controller_OS_exit=None,unique_launch=True,physical_job_submitted_by_launcher=False)))

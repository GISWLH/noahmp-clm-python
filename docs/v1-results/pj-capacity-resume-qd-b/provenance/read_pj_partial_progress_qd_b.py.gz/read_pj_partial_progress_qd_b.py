"""Read only existing JSON checkpoint counters from the eight resumed jobs."""
from pathlib import Path
import hashlib
import json
import socket
import time

assert socket.gethostname()=='compute002'
rows=[]
for i,start in enumerate((13488,13488,13008,13008,6768,6768,6768,6768)):
    job=str(1846+i)+'.manager'
    path=Path('/var/tmp/pbs.'+job+'/result/run/trajectory/report.json')
    row=dict(case_index=i,job=job,parent_closed_steps=start,path=str(path),exists=path.exists())
    if path.exists():
        raw=path.read_bytes();report=json.loads(raw)
        row.update(report_sha256=hashlib.sha256(raw).hexdigest(),report_bytes=len(raw),
            saved_steps=report.get('steps_completed'),requested_steps=report.get('steps_requested'),
            saved_status=report.get('status'),scope='Existing partial checkpoint only; no F0/window-closure/scientific credit.')
    rows.append(row)
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),read_only=True,
    numerical_execution=0,rows=rows),indent=2))

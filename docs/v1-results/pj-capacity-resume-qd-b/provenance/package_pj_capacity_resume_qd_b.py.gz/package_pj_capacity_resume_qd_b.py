"""Seal the unique resumed original chains, not a completed-window/year claim."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='pj-capacity-resume-qd-b'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    deploy=BASE/(LABEL+'-deployment')
    for k in range(3):assert json.loads((deploy/(str(k)+'-exit.json')).read_bytes())['actual_exit']==0
    preflight=json.loads((deploy/'2.stdout').read_bytes());assert preflight['preflight_passed'] and not preflight['run_authorized']
    assert len(preflight['parents'])==8 and preflight['wrapper_sha256']=='62694b3eae242b33f1ac097b4e6705e57974579c8a2dcca749fd6f6b707e0d53'
    launch=json.loads((BASE/(LABEL+'-launch.stdout')).read_bytes())
    assert launch['unique_launch'] and launch['controller_pid']==99446 and launch['start_ticks']==279549118 and launch['detached_controller_OS_exit'] is None
    status=json.loads((BASE/(LABEL+'-status-second.json')).read_bytes())
    assert status['process']['present'] and status['process']['pid']==99446 and status['process']['start_ticks']==279549118
    assert status['finished'] is None and status['old_progress_sha256']=='159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'
    assert all(re.search(r'job_state = R\s',row['stdout']) for row in status['jobs'].values())
    assert len(status['jobs'])==8 and all(case['status']=='running' for case in status['progress']['cases'])
    partial=json.loads((BASE/(LABEL+'-partial-checkpoints.json')).read_bytes())
    assert all(row['exists'] and row['saved_steps']>row['parent_closed_steps'] for row in partial['rows'])
    rows=[dict(case_index=case['case_index'],job=case['job'],parent_closed_steps=case['steps'],window_start=case['start'],window_stop=case['stop'],actual_PBS_state='R') for case in status['progress']['cases']]
    readout=dict(unique_controller=launch,actual_preflight_exits=[0,0,0],preflight=preflight,current_cases=rows,
        existing_partial_checkpoint_observation=partial,new_F0_closed_windows_credited=0,complete_years_credited=0,
        spinup_calibration_or_scientific_credit=False,original_progress_unchanged=True,
        original_zero_step_failure_and_seed_repair_reference=json.loads((BASE/'pj-dependency-repair-qd-b-package.json').read_bytes()),
        scope='Unique62694 wrapper continues8 original successful parents; each next window requires original actualF0/Stageout0/full ledger closure. Original36 dependencies retained. No physical-failure-year continuation, retry, new source, relaxed gate or cycle2.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={'readout.json':encode(readout),'SCOPE.md':b'Actual metadata preflight3 steps all0: both-host36 original dependency files exact,8 originalF0/Stageout0 parents/source/progress/controls/capacity verified. Unique controller99446/start279549118 launches1846--1853; current actual states allR. Existing JSON checkpoints advance to13872/13872/13344/13344/7056/7056/7056/7056 at17:59:44UTC, but no new window F0/year/spinup/calibration/scientific credit is claimed. Parent states remain13488/13488/13008/13008/6768x4 until original closure. Old zero-step failures retained via hash-reference to repair packet. No source/physics/test/gate changes, no automatic cycle2, physical failures stop the original case.\n'}
    for p in deploy.iterdir():
        if p.is_file():items['deployment/'+p.name]=p.read_bytes()
    names=['resume_capacity_pj_qd_b.py','resume_capacity_pj_qd_b.diff','resume_capacity_pj_qd_b-static.json','deploy_capacity_pj_qd_b.py',
        'launch_capacity_pj_qd_b.py','read_capacity_resume_pj_qd_b.py','read_pj_partial_progress_qd_b.py',Path(__file__).name]
    for name in names:items['provenance/'+name]=(BASE/name).read_bytes()
    for suffix in ('launch.py','launch.stdout','launch.stderr','launch-exit.json','status-first.json','status-first.stderr','status-first-exit.json',
        'status-second.json','status-second.stderr','status-second-exit.json','partial-checkpoints.json','partial-checkpoints.stderr','partial-checkpoints-exit.json'):
        name=LABEL+'-'+suffix;items['actual/'+name]=(BASE/name).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Unique resumed8 originalF0 parents after three actual0 metadata preflights;99446 controller/1846--1853 allR, advancing partial checkpoints only. No new closed-window/year/spinup/scientific credit or physical failure retry; dependencies and original gates unchanged.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

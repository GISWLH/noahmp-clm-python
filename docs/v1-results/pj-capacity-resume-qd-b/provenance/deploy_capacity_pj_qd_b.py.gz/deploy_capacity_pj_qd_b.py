"""Prepared-only QD-b deployment: require live PBS and exact36 dependencies first."""
from pathlib import Path
import base64
import hashlib
import json
import shlex
import subprocess

BASE=Path(__file__).resolve().parent
DEST='/tmp/noahmp-pj-capacity-resume-qd-b'
PYTHON='/home/zhangyq/venvs/noahmp-closeout/bin/python'
OUT=BASE/'pj-capacity-resume-qd-b-deployment'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    proof=json.loads((BASE/'pj-capacity-resume-qd-b-preparation/METADATA_REPAIR_PROOF.json').read_bytes())
    assert proof['passed'] and not proof['controller_launched']
    files={'resume_capacity_pj_qd.py':(BASE/'resume_capacity_pj_qd_b.py').read_bytes(),
        'BACKUP_PROOF.json':(BASE/'pj-closed-archives-20261026-qa-verified.json').read_bytes(),
        'METADATA_REPAIR_PROOF.json':(BASE/'pj-capacity-resume-qd-b-preparation/METADATA_REPAIR_PROOF.json').read_bytes()}
    assert sha(files['resume_capacity_pj_qd.py'])=='62694b3eae242b33f1ac097b4e6705e57974579c8a2dcca749fd6f6b707e0d53'
    manifest={n:sha(b) for n,b in files.items()};files['CONTROLS_SHA256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    for name,raw in files.items():(OUT/name).write_bytes(raw)
    precheck="""from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/tmp/noahmp-numpy-baseline-resume-pj')
assert not Path('/proc/48727').exists() and not Path('/proc/69080').exists()
jobs={}
for job,expected_exit in [('1831.manager','1'),('1813.manager','0')]:
 r=subprocess.run(['qstat','-fx',job],capture_output=True);assert r.returncode==0,(job,r.stderr)
 for key,value in [('job_state','F'),('Exit_status',expected_exit),('Stageout_status','0')]:
  assert re.search(rb'^\\s*'+key.encode()+rb' = '+value.encode()+rb'\\s*$',r.stdout,re.M)
 jobs[job]=dict(stdout=r.stdout.decode(),stderr=r.stderr.decode(),actual_exit=r.returncode)
index=json.loads((root/'STAGE_SHA256.json').read_bytes());assert len(index)==36
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in index.items())
remote_code=\"from pathlib import Path;import hashlib,json;root=Path('/tmp/noahmp-numpy-baseline-resume-pj');index=json.loads((root/'STAGE_SHA256.json').read_bytes());assert len(index)==36;assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in index.items());print(json.dumps(dict(original36_stage_files_exact=True)))\"
r=subprocess.run(['ssh','compute002',__import__('shlex').join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B','-c',remote_code])],capture_output=True)
assert r.returncode==0,r.stderr
print(json.dumps(dict(PBS_available=True,original36_stage_files_exact_both_hosts=True,original_jobs=jobs,compute_confirmation=json.loads(r.stdout))))
"""
    payload={n:base64.b64encode(b).decode() for n,b in files.items()}
    deployment="""from pathlib import Path
import base64,hashlib,json,socket
assert socket.gethostname()=='manager'
root=Path(%r);assert not root.exists();root.mkdir()
payload=json.loads(%r)
for name,encoded in payload.items():(root/name).write_bytes(base64.b64decode(encoded))
manifest=json.loads((root/'CONTROLS_SHA256.json').read_bytes())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
print(json.dumps(dict(deployed=True,root=str(root),manifest=manifest,controller_started=False)))
""" % (DEST,json.dumps(payload))
    commands=[([PYTHON,'-B','-'],precheck.encode()),([PYTHON,'-B','-'],deployment.encode()),
        ([PYTHON,'-B',DEST+'/resume_capacity_pj_qd.py'],None)]
    for k,(argv,body) in enumerate(commands):
        if body:(OUT/(str(k)+'-remote.py')).write_bytes(body)
        result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc',shlex.join(argv)],input=body,capture_output=True,timeout=180)
        (OUT/(str(k)+'.stdout')).write_bytes(result.stdout);(OUT/(str(k)+'.stderr')).write_bytes(result.stderr)
        receipt=dict(actual_exit=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
        (OUT/(str(k)+'-exit.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps(dict(step=k,**receipt)),flush=True)
        assert result.returncode==0,result.stderr.decode(errors='replace')


if __name__=='__main__':main()

"""Launch the reviewed unique metadata controller, not a physical worker."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess

OUT = Path(__file__).resolve().parent
receipt = json.loads((OUT/'pj-capacity-resume-qd-b-deployment/2-exit.json').read_text())
assert receipt['actual_exit'] == 0
proof_raw = (OUT/'pj-capacity-resume-qd-b-deployment/2.stdout').read_bytes()
assert hashlib.sha256(proof_raw).hexdigest() == receipt['stdout_sha256']
proof = json.loads(proof_raw)
assert proof['preflight_passed'] and not proof['run_authorized']
code = '''from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/noahmp-pj-capacity-resume-qd-b')
controller=root/'resume_capacity_pj_qd.py'
assert hashlib.sha256(controller.read_bytes()).hexdigest()=='62694b3eae242b33f1ac097b4e6705e57974579c8a2dcca749fd6f6b707e0d53'
assert not (root/'CONTROLLER_STARTED.json').exists()
assert not (root/'controller.stdout').exists()
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (root/'controller.stdout').open('xb') as stdout,(root/'controller.stderr').open('xb') as stderr:
    child=subprocess.Popen(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B',str(controller),'--run'],
        stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,env=env,start_new_session=True)
pid=child.pid
stat=Path('/proc')/str(pid)/'stat'
print(json.dumps(dict(controller_pid=pid,start_ticks=int(stat.read_text().rsplit(')',1)[1].split()[19]),
    detached_controller_OS_exit=None,unique_launch=True,physical_job_submitted_by_launcher=False)))
'''
(OUT/'pj-capacity-resume-qd-b-launch.py').write_text(code)
result = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc',
    shlex.join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B','-'])],input=code.encode(),capture_output=True)
(OUT/'pj-capacity-resume-qd-b-launch.stdout').write_bytes(result.stdout)
(OUT/'pj-capacity-resume-qd-b-launch.stderr').write_bytes(result.stderr)
(OUT/'pj-capacity-resume-qd-b-launch-exit.json').write_text(json.dumps(dict(actual_ssh_exit=result.returncode,
    code_sha256=hashlib.sha256(code.encode()).hexdigest(),stdout_sha256=hashlib.sha256(result.stdout).hexdigest()),indent=2)+'\n')
print(result.stdout.decode(),flush=True)
assert result.returncode == 0,result.stderr.decode()

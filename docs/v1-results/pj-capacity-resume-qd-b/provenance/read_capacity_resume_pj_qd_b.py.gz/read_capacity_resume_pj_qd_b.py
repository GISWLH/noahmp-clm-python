"""Read the unique current PID and PBS handles; no model or mutation."""
from pathlib import Path
import hashlib
import json
import os
import socket
import subprocess

ROOT = Path('/tmp/noahmp-pj-capacity-resume-qd-b')
OLD = Path('/tmp/noahmp-numpy-baseline-resume-pj')
assert socket.gethostname() == 'manager'
sha = lambda b: hashlib.sha256(b).hexdigest()
started = json.loads((ROOT/'CONTROLLER_STARTED.json').read_bytes()) if (ROOT/'CONTROLLER_STARTED.json').exists() else None
pid = 99446
base = Path('/proc')/str(pid)
process = dict(pid=pid,present=base.exists())
if base.exists():
    stat = (base/'stat').read_text().rsplit(')',1)[1].split()
    process.update(start_ticks=int(stat[19]),state=stat[0],cmdline=(base/'cmdline').read_bytes().replace(b'\0',b' ').decode())
    assert process['start_ticks'] == 279549118 and str(ROOT/'resume_capacity_pj_qd.py') in process['cmdline']
progress = json.loads((ROOT/'PROGRESS.json').read_bytes()) if (ROOT/'PROGRESS.json').exists() else None
jobs = {}
if progress:
    for case in progress['cases']:
        if case['status'] == 'running':
            result = subprocess.run(['qstat','-xf',case['job']],capture_output=True)
            jobs[case['job']] = dict(actual_exit=result.returncode,stdout=result.stdout.decode(),stderr=result.stderr.decode())
old_progress_sha = sha((OLD/'PROGRESS.json').read_bytes())
assert old_progress_sha == '159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'
print(json.dumps(dict(process=process,started=started,progress=progress,jobs=jobs,
    old_progress_sha256=old_progress_sha,
    controller_stdout=(ROOT/'controller.stdout').read_text(),controller_stderr=(ROOT/'controller.stderr').read_text(),
    finished=json.loads((ROOT/'CONTROLLER_FINISHED.json').read_bytes()) if (ROOT/'CONTROLLER_FINISHED.json').exists() else None,
    capacity={str(p):dict(free_bytes=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize,free_inodes=os.statvfs(p).f_favail) for p in (ROOT,)},
    numerical_models_executed=False,remote_mutations=0),indent=2))

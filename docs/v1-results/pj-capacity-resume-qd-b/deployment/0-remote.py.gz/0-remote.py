from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/tmp/noahmp-numpy-baseline-resume-pj')
assert not Path('/proc/48727').exists() and not Path('/proc/69080').exists()
jobs={}
for job,expected_exit in [('1831.manager','1'),('1813.manager','0')]:
 r=subprocess.run(['qstat','-fx',job],capture_output=True);assert r.returncode==0,(job,r.stderr)
 for key,value in [('job_state','F'),('Exit_status',expected_exit),('Stageout_status','0')]:
  assert re.search(rb'^\s*'+key.encode()+rb' = '+value.encode()+rb'\s*$',r.stdout,re.M)
 jobs[job]=dict(stdout=r.stdout.decode(),stderr=r.stderr.decode(),actual_exit=r.returncode)
index=json.loads((root/'STAGE_SHA256.json').read_bytes());assert len(index)==36
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in index.items())
remote_code="from pathlib import Path;import hashlib,json;root=Path('/tmp/noahmp-numpy-baseline-resume-pj');index=json.loads((root/'STAGE_SHA256.json').read_bytes());assert len(index)==36;assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in index.items());print(json.dumps(dict(original36_stage_files_exact=True)))"
r=subprocess.run(['ssh','compute002',__import__('shlex').join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B','-c',remote_code])],capture_output=True)
assert r.returncode==0,r.stderr
print(json.dumps(dict(PBS_available=True,original36_stage_files_exact_both_hosts=True,original_jobs=jobs,compute_confirmation=json.loads(r.stdout))))

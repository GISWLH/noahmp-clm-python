from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-kink-numpy-year-h';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());report=json.loads((r/'trajectory/report.json').read_text())
assert (r/'pbs-exit.txt').read_text().strip()=='1' and d['returncode']==1 and d['status']=='failed' and d['steps_completed']==3162 and d['steps_requested']==17520 and d['source_unchanged']
assert sha(r/'trajectory/report.json')==d['report_sha256'] and report['failed_index']==3162
for key,hashkey in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:assert sha(r/'trajectory'/report[key])==report[hashkey]
inputs=b/'qia-stem-inputs-a/inputs';a=b/'qia-kink-numpy-year-h-failure-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname='original-run/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['CN-Qia.npz','CN-Qia.json','CN-Qia-stem-config.json']:tf.add(inputs/n,arcname='inputs/'+n,recursive=False)
    for n in ['qia1110-final-h-source.tar.gz',Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Actual immutable old519H NumPy originalcold17520 failure3162, all original generations/config/forcing/receipts/controls/source retained. No failedyear resume or annual acceptance. Current563C diagnostic replay separate.')))

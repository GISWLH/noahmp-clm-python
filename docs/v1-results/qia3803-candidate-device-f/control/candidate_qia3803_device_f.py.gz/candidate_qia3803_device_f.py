from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=b/'qia3803-candidate-device-f';old=b/'qia-cuda-3803-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and all(sha(s/n)==h for n,h in m.items())
cap=json.loads((old/'surface-capture-a/receipt.json').read_text());path=old/'surface-capture-a/failed-surface.npz';assert sha(path)==cap['failed_surface_sha256']
with np.load(path,allow_pickle=False) as z:packet=dict(z)
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import cupy as cp
import noahmp_clm.gpu.cuda.canopy_phase_surface as module
from noahmp_clm.physics.photosynthesis import LeafParameters
args=tuple(cp.asarray(packet['surface_a'+str(i)]) for i in range(9))
kwargs={k:cp.asarray(packet[k]) for k in ['exchange_extension','vic','stem_area'] if k in packet}
kwargs.update(parameters=LeafParameters(**json.loads((old/'surface-capture-a/leaf-parameters.json').read_text())),raise_on_failure=False)
raws=[];unpack=module.unpack_phase_surface
def observe(raw):raws.append(raw.copy());return unpack(raw)
module.unpack_phase_surface=observe;start=time.monotonic()
module.run_canopy_phase_surface_cuda(*args,**kwargs)
baseline=cp.asnumpy(raws[-1]);assert baseline.tobytes()==packet['raw'].tobytes()
names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu','enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu','snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu')
sources=[]
for name in names:
    text=Path(module.__file__).with_name(name).read_text()
    if name=='canopy_phase_energy_kernel.cu':
        marker='struct PhaseContext {';assert text.count(marker)==1;text=text.replace(marker,'extern "C" __device__ float phase_edge_trace[12000];\nextern "C" __device__ int phase_edge_count;\n'+marker)
        marker='        // Retry a derivative confined to the current smooth phase branch';assert text.count(marker)==1
        text=text.replace(marker,"""        // Private experiment: single-coordinate exact phase events after
        // weak progress, always below the actual best full residual norm.
        if(!accepted||chosen_norm>.999f*norm){
            float current_r[12];phase_evaluate(v,chosen,current_r,nullptr);
            float best_norm=ca_dot(current_r,current_r,12);
            if(!accepted||best_norm>.999f*norm){
                for(int layer=0;layer<10;++layer)if(v.phase_active[layer]&&chosen[layer]>0.f&&chosen[layer]<plateau){
                    for(int side=0;side<2;++side){
                        float candidate[12],rr[12];for(int k=0;k<12;++k)candidate[k]=chosen[k];
                        candidate[layer]=side?plateau:0.f;phase_evaluate(v,candidate,rr,nullptr);
                        float candidate_norm=ca_dot(rr,rr,12);
                        if(candidate_norm<best_norm){
                            int logrow=phase_edge_count++;
                            if(logrow<2000){phase_edge_trace[logrow*6]=float(iteration);phase_edge_trace[logrow*6+1]=float(layer);phase_edge_trace[logrow*6+2]=candidate[layer];phase_edge_trace[logrow*6+3]=best_norm;phase_edge_trace[logrow*6+4]=candidate_norm;phase_edge_trace[logrow*6+5]=phase_max(rr,12);}
                            for(int k=0;k<12;++k)chosen[k]=candidate[k];best_norm=candidate_norm;accepted=true;++restarts;
                        }
                    }
                }
            }
            chosen_norm=best_norm;
        }
"""+marker)
    sources.append(text)
source='\n'.join(sources);(r/'diagnostic-kernel.cu').write_text(source)
name='run_canopy_phase_surface_stems';compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=(name,))
fn=compiled.get_function(name);original=module._kernel
def traced(extended=False,vic=False,stems=False,profiled=False):
    assert stems and not profiled
    return fn
count_pointer=compiled.get_global('phase_edge_count');event_pointer=compiled.get_global('phase_edge_trace')
count_array=cp.ndarray((1,),cp.int32,memptr=count_pointer);count_array.fill(0)
event_array=cp.ndarray((2000,6),cp.float32,memptr=event_pointer);event_array.fill(cp.nan)
module._kernel=traced
try:module.run_canopy_phase_surface_cuda(*args,**kwargs)
finally:module._kernel=original;module.unpack_phase_surface=unpack
event_count=int(cp.asnumpy(count_array)[0]);events=cp.asnumpy(event_array)[:min(event_count,2000)];variant=cp.asnumpy(raws[-1])
result=unpack(cp.asarray(variant));summary={k:cp.asnumpy(result[k]).tolist() for k in ['converged','canopy_converged','max_solver_residual','surface_evaluations','energy_residual_jm2','mass_residual_kgm2','h','le','gpp','restarts'] if k in result}
np.savez_compressed(r/'candidate-and-original.npz',original_raw=baseline,candidate_raw=variant,edge_events=events)
cp.cuda.runtime.deviceSynchronize();unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged and sha(path)==cap['failed_surface_sha256']
d=dict(scope='Private CUDA-only original519H3803 numerical recovery experiment after original318/323 NumPy physical reference and exact-D/E observer evidence. Normal equations/100/.005/outer controls unchanged; single-coordinate exact latent-edge candidates tried only after weak old progress and strict improvement of actual full residual. Original failure retained, no production/annual advancement, no JAX or whole-column acceptance',
    original_raw_byte_exact=True,candidate=summary,accepted_phase_events=event_count,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(path),payload_sha256=sha(r/'candidate-and-original.npz'),compiled_diagnostic_source_sha256=sha(r/'diagnostic-kernel.cu'),device_barrier_complete=True,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

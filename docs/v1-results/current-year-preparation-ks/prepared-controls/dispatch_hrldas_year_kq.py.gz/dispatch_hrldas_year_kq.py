"""Independent bounded original-year chains, each starting after audit1189F0."""
from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-year-kq';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=b/'hrldas-current-kg/inputs';protocol=json.loads((inputs/'protocol.json').read_text());assert protocol['case_count']==3 and protocol['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5';sites=['CN-Qia','CN-Cha','CN-HaM'];starts=[336]+list(range(384,17520,480));assert len(starts)==37
name='run_hrldas_year_kq.py';raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/name).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-jn-hrldas-year
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=4gb
#PBS -l walltime=04:00:00
#PBS -j oe
#PBS -o /dev/null
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/hrldas-current-year-kq
/home/zhangyq/venvs/noahmp-closeout/bin/python -u run_hrldas_year_kq.py >"$CASE_SITE/worker-bootstrap-$BEGIN_INDEX.log" 2>&1
code=$?
printf '%s\\n' "$code" >"$CASE_SITE/pbs-exit-current.txt"
exit "$code"
'''
(r/'job.pbs').write_text(script)
locked=dict(source_manifest_sha256=protocol['source_manifest_sha256'],sites=sites,segment_starts=starts,first_continuation_segment_steps=48,maximum_steps_per_segment=480,requested_year_steps=17520,own_firstweek_model_job='1188.manager',independent_firstweek_audit_job='1189.manager',input_protocol_sha256=sha(inputs/'protocol.json'),input_sha256=protocol['original_I_inputs_sha256'],controls_sha256={n:sha(r/n) for n in [name,'job.pbs']},
    scope='UnchangedcurrentJN originalthree HRLDASpaired coldyears, ownverified336 copiedto NEWroots thenonlyresume withall7physical/globalbudgetfields. No actualfirstyear/spinup/calibration/scientificpass fromqueue. Independentcasechains continueonlyafteractualsuccess; originalKG336/KHresults andallothermodels untouched. Perdayclosedgenerations losslesslyarchived/readbackverifiedbeforeunlink; currentgenerations/inputs/source neverremoved.')
(r/'protocol.json').write_text(json.dumps(locked,indent=2)+'\n');jobs=[]
for site in sites:
    (r/site).mkdir();parent='1189.manager'
    for begin in starts:
        q=subprocess.run(['qsub','-W','depend=afterok:'+parent,'-v','CASE_SITE='+site+',BEGIN_INDEX='+str(begin),str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr
        jobs.append(dict(site=site,begin=begin,stop=min(begin+(48 if begin==336 else 480),17520),pbs_job=q.stdout.strip(),depends_on=parent));parent=q.stdout.strip()
        (r/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
out=dict(jobs=len(jobs),first_jobs=[next(x for x in jobs if x['site']==site) for site in sites],last_jobs=[next(x for x in reversed(jobs) if x['site']==site) for site in sites],protocol_sha256=sha(r/'protocol.json'),scope=locked['scope']);assert len(jobs)==111
(r/'dispatch-complete.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

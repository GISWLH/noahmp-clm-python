from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-year-archive-check-kr';assert not r.exists();r.mkdir();n='check_year_archival_kr.py';raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-year-archive-kr
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=2gb
#PBS -l walltime=00:10:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1
cd /home/zhangyq/noahmp-v1/hrldas-year-archive-check-kr
/home/zhangyq/venvs/noahmp-closeout/bin/python -u check_year_archival_kr.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(r/'job.pbs').write_text(script);q=subprocess.run(['qsub',str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();out=dict(pbs_job=q.stdout.strip(),controls_sha256={name:sha(r/name) for name in [n,'job.pbs']});(r/'dispatch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

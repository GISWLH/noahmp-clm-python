"""Run only after actual immutable KK export is copied to EHPC and verified."""
from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-year-analysis-kl';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();packet=json.loads((b/'climatology-current-year-kk-export.json').read_text())
assert packet['steps']==17520 and packet['cases']==12 and packet['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and sha(b/packet['archive'])==packet['sha256']
preflight=b/'climatology-bgc-stream-kn';d=json.loads((preflight/'audit.json').read_text());assert d['source_unchanged'] and d['result']['physical_column_steps']==1152 and (preflight/'pbs-exit.txt').read_text().strip()=='0'
assert not r.exists();r.mkdir();controls={}
for n in ['evaluate_climatology_year_kl.py','audit_bgc_stream_km.py']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw
    if n=='audit_bgc_stream_km.py':assert raw==(preflight/n).read_bytes()
    (r/n).write_bytes(raw);controls[n]=sha(r/n)
operators={'CN-Cng':'0a9b838cc545e1976d55a00bf019b5ebc2ea086726f7ed993a1e0d07d2d7cd78','CN-Qia':'49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095','CN-Cha':'56b41a9c173f28c56f71b453a15626dac329d443582cdc2d5080428180ce91ac'}
assert all(sha(b/'height-observations-ea'/(site+'-soil-operator.json'))==h for site,h in operators.items())
(r/'plan.json').write_text(json.dumps(dict(device_archive=packet['archive'],device_archive_sha256=packet['sha256'],controls_sha256=controls,soil_operator_sha256=operators,source_manifest_sha256=packet['source_manifest_sha256']),indent=2)+'\n')
script='''#!/bin/bash
#PBS -N clm-year-audit-kl
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=12gb
#PBS -l walltime=01:00:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/climatology-year-analysis-kl
/home/zhangyq/venvs/noahmp-closeout/bin/python -u evaluate_climatology_year_kl.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(r/'job.pbs').write_text(script);q=subprocess.run(['qsub',str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr
out=dict(pbs_job=q.stdout.strip(),controls_sha256={n:sha(r/n) for n in ['evaluate_climatology_year_kl.py','audit_bgc_stream_km.py','plan.json','job.pbs']},scope='Independentfull12year audit dispatched only after actualKKdeviceexport; no science/SOC/1e-6/fullGPU/releasecredit fromsubmission.');(r/'dispatch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

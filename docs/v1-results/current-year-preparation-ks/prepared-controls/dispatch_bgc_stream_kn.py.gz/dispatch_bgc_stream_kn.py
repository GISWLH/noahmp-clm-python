from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-bgc-stream-kn';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['audit_bgc_stream_km.py','probe_bgc_stream_kn.py']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-bgc-stream-kn
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=6gb
#PBS -l walltime=00:20:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/climatology-bgc-stream-kn
/home/zhangyq/venvs/noahmp-closeout/bin/python -u probe_bgc_stream_kn.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(r/'job.pbs').write_text(script);q=subprocess.run(['qsub',str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr
d=dict(pbs_job=q.stdout.strip(),controls_sha256={n:sha(r/n) for n in ['audit_bgc_stream_km.py','probe_bgc_stream_kn.py','job.pbs']},scope='Actual96step currentJN archivedC/N stream diagnostic preflight onPBS; no physicalintegration ornewinitialization. Retainrealnonzeroifreaderfails.');(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

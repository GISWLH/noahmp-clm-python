"""PBS-only all12 actual complete currentJN year stock/budget/FLUXNET audit."""
from pathlib import Path
import gzip,hashlib,itertools,json,os,subprocess,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=Path.cwd();tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();failure=None
plan=json.loads((r/'plan.json').read_text());assert all(sha(r/n)==h for n,h in plan['controls_sha256'].items())
a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(r),str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from compare_hrldas_native_year import check_ledgers,check_final_checkpoint
from assess_clm_spinup import _frame,compare_endpoints
from audit_bgc_stream_km import audit_stream,cold_rows,continued_rows
results={}
try:
    a=b/plan['device_archive'];assert sha(a)==plan['device_archive_sha256'];device=tmp/'device';device.mkdir()
    with tarfile.open(a) as t:t.extractall(device,filter='data')
    p=device/'current';controller=device/'year-controller';receipt=json.loads((p/'year-receipt.json').read_text());parent=json.loads((controller/'exit.json').read_text())
    assert parent['passed'] and parent['actual_parent_returncode']==0 and parent['failure'] is None and parent['receipt_sha256']==sha(p/'year-receipt.json')
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256']==manifest and receipt['status']=='complete' and receipt['steps_completed']==receipt['steps_requested']==17520 and receipt['device_barrier_complete']
    assert receipt['continued_fields_exact']==23 and receipt['first_continued_step_captured'] and (device/'SOURCE_SHA256.json').read_bytes()==(s/'SOURCE_SHA256.json').read_bytes()
    folder=p/'trajectory';batch,saved,pairs=native.read_generation(folder)
    assert sha(folder/'batch.json')==receipt['report_sha256'] and batch['status']=='complete' and batch['steps_completed']==batch['steps_requested']==17520 and batch['source_unchanged'] and batch['columns']==12 and len(saved)==23 and len(pairs)==12
    assert batch['identity']['source_sha256']==native.source_hashes() and batch['identity']['backend']=='cuda32' and not batch['identity']['compare_jax32'] and batch['same_precision_max_absolute'] is None
    package=json.loads((device/'frozen-inputs/package.json').read_text());a=device/'frozen-inputs'/package['archive'];assert sha(a)==package['archive_sha256'] and package['source_manifest_sha256']==manifest
    inputs=tmp/'inputs';inputs.mkdir()
    with tarfile.open(a) as t:t.extractall(inputs,filter='data')
    loaded=native.load_batch(inputs/'batch.json');protocol=json.loads((inputs/'protocol.json').read_text())
    assert protocol['source_manifest_sha256']==manifest and protocol['case_count']==12 and sha(inputs/'batch.json')==protocol['batch_sha256']==batch['identity']['batch_sha256']
    with np.load(inputs/'cold-reference.npz',allow_pickle=False) as z:cold=dict(z)
    paths=list(folder.glob('state-0000000-*.npz'));assert len(paths)==1 and sha(inputs/'cold-reference.npz')==protocol['cold_reference_sha256']
    with np.load(paths[0],allow_pickle=False) as z:
        assert set(z.files)==set(cold) and len(cold)==23
        for key in z.files:assert z[key].dtype==cold[key].dtype and z[key].shape==cold[key].shape and z[key].tobytes()==cold[key].tobytes(),key
    assert all(np.all(cold[k]==0) for k in ['net','bounds','maximum','stepmax','tracermax'])
    binding=json.loads((p/'year-prefix-binding.json').read_text());verification=json.loads((p/'prefix-verification.json').read_text());prefix_report=json.loads((p/'validated-prefix-report.json').read_text())
    assert verification['passed'] and verification['physical_step_pairs']==576 and verification['source_manifest_sha256']==manifest and (p/'prefix-verification-pbs-exit.txt').read_text().strip()=='0'
    assert sha(p/'validated-prefix-report.json')==binding['prefix_batch_report_sha256'] and sha(p/'validated-prefix-state.npz')==binding['prefix_checkpoint_sha256']
    assert prefix_report['status']=='running' and prefix_report['steps_completed']==48 and prefix_report['steps_requested']==17520
    with np.load(p/'validated-prefix-state.npz',allow_pickle=False) as z:prefix=dict(z)
    with np.load(p/'first-continued-step.npz',allow_pickle=False) as z:first=dict(z)
    for k in range(16):
        expected=prefix['a'+str(k)].copy()
        if k==4:expected[:,7:10]=np.asarray([c['data']['environment'][48] for c in loaded],expected.dtype)
        actual=first['before'+str(k)];assert actual.dtype==expected.dtype and actual.shape==expected.shape and actual.tobytes()==expected.tobytes(),('continued actual state',k)
    out={}
    for name,value in first.items():
        if name.startswith('output/'):
            parts=name.split('/')[1:];target=out
            for part in parts[:-1]:target=target.setdefault(part,{})
            target[parts[-1]]=value
    first_audit=native.audit_step(tuple(first['before'+str(k)] for k in range(16)),tuple(first['after'+str(k)] for k in range(16)),first['forcing'],first['deposition'],first['nitrogen'],out)
    for key,value in zip(['incoming','residual','bound','impurity'],first_audit):np.testing.assert_allclose(value,first['recorded/'+key],rtol=1e-12,atol=1e-12)
    chunks=receipt['bgc_diagnostic_chunks'];assert len(chunks)==364 and receipt['bgc_diagnostic_steps']==17472
    for i,c in enumerate(chunks):
        begin,end=48+48*i,96+48*i;assert c['first']==begin and c['end']==end
        assert sha(p/'year-bgc-diagnostics'/('steps-'+str(begin).zfill(7)+'-'+str(end).zfill(7)+'.npz'))==c['sha256']
    bgc=audit_stream(itertools.chain(cold_rows(p),continued_rows(p,17520)),loaded,cold,saved,[trace for _,trace in pairs],17520)
    (r/'bgc-stream-audit.json').write_text(json.dumps(bgc,indent=2,allow_nan=False)+'\n')
    env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    for k,((report,trace),case) in enumerate(zip(pairs,loaded)):
        name=case['case'];site=case['config']['site'];sub=r/name;sub.mkdir()
        assert report['case']==name and report['configuration']==case['config'] and report['source_sha256']==native.source_hashes() and report['source_unchanged'] and report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520
        assert all(report[key]==sha(case['paths'][path]) for key,path in [('forcing_npz_sha256','input'),('forcing_manifest_sha256','input_manifest'),('configuration_sha256','configuration')])
        assert np.array_equal(trace['time_start'],case['data']['time_start']) and np.array_equal(trace['time_end'],case['data']['time_end'])
        assert len(case['stamps'])==17520 and case['stamps'][0].strftime('%m%d%H%M')=='01010000' and str(trace['time_end'][-1])==str(int(str(trace['time_start'][0])[:4])+1)+'01010000'
        ledgers=check_ledgers(trace,report);storage=check_final_checkpoint(folder/batch['checkpoint_file'],trace,report)
        endpoints=compare_endpoints(_frame(cold,k,batch['identity']),_frame(saved,k,batch['identity']))
        report_path=folder/name/batch['case_reports'][name]['file'];trace_path=report_path.parent/report['model_npz']
        operator=b/'height-observations-ea'/(site+'-soil-operator.json');assert sha(operator)==plan['soil_operator_sha256'][site]
        (sub/'soil-operator.json').write_bytes(operator.read_bytes());output=sub/'observations.json'
        command=[sys.executable,str(s/'benchmarks/evaluate_fluxnet_series.py'),'--model',str(trace_path),'--model-manifest',str(report_path),'--observations',str(case['paths']['input']),'--observation-manifest',str(case['paths']['input_manifest']),'--soil-operator',str(sub/'soil-operator.json'),'--output',str(output)]
        with (sub/'observations.log').open('x') as log:code=subprocess.run(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
        assert code==0,'Original observation evaluator failed: '+name
        metrics=json.loads(output.read_text());assert len(metrics['daily'])==365 and len(metrics['monthly'])==12
        assert all(product['calendar_period_complete'] for freq in ['daily','monthly'] for day in metrics[freq].values() for product in day.values())
        counts={}
        for freq in ['daily','monthly']:
            values=[v['metrics']['bias_pass'] for day in metrics[freq].values() for v in day.values()]
            counts[freq]=dict(bias_met=sum(x is True for x in values),bias_failed=sum(x is False for x in values),unmeasured=sum(x is None for x in values))
        result=dict(case=name,site=site,full365days12months_delivered=True,independent_stored_m_h_c_n_ledgers=ledgers,independent_final_extensive_storage=storage,
            cold_to_first_year_endpoint=endpoints,water_heat_converged=False,soil_c_equilibrium_claim=False,
            instantaneous={key:value['metrics'] for key,value in metrics['instantaneous'].items()},period_counts=counts,
            source_sha256={str(x):sha(x) for x in [report_path,trace_path,case['paths']['input'],case['paths']['input_manifest'],case['paths']['configuration'],operator]},
            scope='Allfixedproducts andQC/soiloperators preserved. Coldfirstyear endpoint/rate isnot repeatedclimateconvergence or100observedyears; criteriafailures/unmeasured remain independent ofdelivered audit status.')
        (sub/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');results[name]=result
        raw=output.read_bytes();compressed=gzip.compress(raw,mtime=0);assert gzip.decompress(compressed)==raw;output.with_suffix('.json.gz').write_bytes(compressed);output.unlink()
except Exception as e:
    failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,evaluation_delivered=failure is None and len(results)==12,failure=failure,source_manifest_sha256=manifest,source_unchanged=unchanged,cases=results,seconds=time.monotonic()-start,
    scope='ActualcurrentJN originaltwelve complete17520coldyears only after realCUDAparent0/source/barrier. Full365day/12month FLUXNETallproducts/ownQC/soiloperators plusoriginalMHCNtraces/finalstocks, 210240actualCNstates/inputs/independentledgers andone-yearendpointrates. No scientificpass fromanalysis0, conditionalSOCalgebra,newinitializer, longtermSOC/climateconvergence, K78/full407 orreleaseclaim.')
(r/'receipt.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='cases'}),flush=True);raise SystemExit(0 if d['evaluation_delivered'] and unchanged else 1)

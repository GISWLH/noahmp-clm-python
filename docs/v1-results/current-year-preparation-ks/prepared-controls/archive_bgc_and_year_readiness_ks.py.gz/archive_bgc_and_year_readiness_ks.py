"""Archive actual completed diagnostic tests and explicitly unstarted year plans."""
from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();payload={};completed=[]
for name,receipt_name in [('climatology-bgc-stream-kn','audit.json'),('hrldas-year-archive-check-kr','check.json')]:
    root=b/name;dispatch=json.loads((root/'dispatch.json').read_text());status=subprocess.check_output(['qstat','-xf',dispatch['pbs_job']],text=True)
    assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M) and (root/'pbs-exit.txt').read_text().strip()=='0'
    assert all(sha((root/n).read_bytes())==h for n,h in dispatch['controls_sha256'].items())
    d=json.loads((root/receipt_name).read_text())
    if receipt_name=='audit.json':assert d['source_unchanged'] and d['result']['physical_column_steps']==1152
    else:assert d['passed'] and d['all_original_model_files_unchanged']
    for path in sorted(root.iterdir()):
        if path.is_file():payload[name+'/'+path.name]=path.read_bytes()
    payload[name+'/actual-pbs-qstat.txt']=status.encode();completed.append(dict(root=name,pbs_job=dispatch['pbs_job'],actual_exit=0,scope=d['scope']))
root=b/'hrldas-current-year-kq';protocol=json.loads((root/'protocol.json').read_text());jobs=json.loads((root/'jobs.json').read_text());assert len(jobs)==111 and all(sha((root/n).read_bytes())==h for n,h in protocol['controls_sha256'].items())
assert json.loads((b/'hrldas-year-archive-check-kr/check.json').read_text())['source_control_sha256']==sha((root/'run_hrldas_year_kq.py').read_bytes())
status=subprocess.check_output(['qstat','-xf',*[x['pbs_job'] for x in jobs]],text=True)
blocks=list(re.finditer(r'Job Id: (\S+)\n(.*?)(?=\nJob Id: |\Z)',status,re.S));assert len(blocks)==111
states={match.group(1):re.search(r'^\s*job_state = (\w+)\s*$',match.group(2),re.M).group(1) for match in blocks};assert set(states)=={x['pbs_job'] for x in jobs} and all(v=='H' for v in states.values())
assert all(not (root/site/'trajectory').exists() for site in protocol['sites'])
for path in sorted(root.iterdir()):
    if path.is_file():payload['year-chain/'+path.name]=path.read_bytes()
payload['year-chain/actual-all111-pbs-qstat.txt']=status.encode()
for n in ['evaluate_climatology_year_kl.py','dispatch_climatology_analysis_kl.py','audit_bgc_stream_km.py','dispatch_hrldas_year_kq.py','dispatch_bgc_stream_kn.py','dispatch_year_archival_kr.py',Path(__file__).name]:payload['prepared-controls/'+n]=(b/n).read_bytes()
assert payload['prepared-controls/audit_bgc_stream_km.py']==payload['climatology-bgc-stream-kn/audit_bgc_stream_km.py']
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=completed,current_year_chain_jobs=111,current_year_chain_states=states,all_three_new_trajectory_directories_absent=True,source_manifest_sha256=protocol['source_manifest_sha256'],
    scope='ActualEHPC1190 realJN96step/1152columnCN diagnostics audit0 and1302 realclosed-file archival loss/corruption negatives0. CurrentJN HRLDAS originalthree completeyear chains111H wait1189actualaudit0, no yearintegration yet. Current12case CUDA annualanalysisKL controls preparedbutNOTdispatched until actualKKcompleteexport. Originalrates/input/source/state/ledgers/science1e-6gates unchanged; no modelyear/spinup/SOC/observation/fullGPU/releasepass.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();target=b/'current-year-preparation-ks-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):
        member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'current-year-preparation-ks-package.json').write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(package),flush=True)

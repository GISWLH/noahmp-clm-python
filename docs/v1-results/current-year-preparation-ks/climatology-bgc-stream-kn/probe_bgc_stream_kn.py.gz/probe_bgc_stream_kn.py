"""PBS preflight on actual currentJN cold48 plus successful continuation48."""
from pathlib import Path
import hashlib,itertools,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-bgc-stream-kn';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic()
a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(r),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from audit_bgc_stream_km import audit_stream,cold_rows,continued_rows
cold=tmp/'cold';continuation=tmp/'continuation';cold.mkdir();continuation.mkdir()
a=b/'ballberry-climatology-cuda-jt-evidence.tar.gz';assert sha(a)=='040aa4fba7864879c4be031e8774a4009706ef024d873c08416365b1ce6d0a9b'
with tarfile.open(a) as t:t.extractall(cold,filter='data')
a=b/'current-jn-year-ke-evidence.tar.gz';assert sha(a)=='3b8cfaf8d04a6d4bf2476946cd3d692f6c7d85cbce3c49e7bcca0fe1cb68ccac'
with tarfile.open(a) as t:t.extractall(continuation,filter='data')
p=cold/'current';receipt=json.loads((p/'receipt.json').read_text());parent=json.loads((p/'exit.json').read_text());assert parent['passed'] and parent['actual_parent_returncode']==0 and parent['receipt_sha256']==sha(p/'receipt.json') and receipt['failure'] is None and receipt['device_barrier_complete'] and receipt['source_manifest_sha256']==manifest
for n in ['prefix-verification.json','validated-prefix-report.json']:
    assert (continuation/'start'/n).exists()
verification=json.loads((continuation/'start/prefix-verification.json').read_text());assert verification['passed'] and verification['source_manifest_sha256']==manifest and verification['physical_step_pairs']==576
report=json.loads((continuation/'chosen-report.json').read_text());assert report['status']=='running' and report['steps_completed']>=96 and report['steps_requested']==17520 and report['identity']['source_sha256']==native.source_hashes()
loaded=native.load_batch(p/'inputs/batch.json');cold_report,cold_saved,cold_pairs=native.read_generation(p/'trajectory')
assert cold_report['steps_completed']==48 and len(cold_pairs)==12
with np.load(p/'inputs/cold-reference.npz',allow_pickle=False) as z:initial=dict(z)
with np.load(continuation/'first-bgc-day/steps-0000048-0000096.npz',allow_pickle=False) as z:first_day=dict(z)
replay=tmp/'replay';(replay/'year-bgc-diagnostics').mkdir(parents=True)
(replay/'year-bgc-diagnostics/steps-0000048-0000096.npz').write_bytes((continuation/'first-bgc-day/steps-0000048-0000096.npz').read_bytes())
final={'a11':first_day['after_plant'][-1],'a13':first_day['after_soil_cn'][-1]};traces=[]
for descriptor in report['identity']['cases']:
    folder=continuation/'generation'/descriptor['case'];rr=json.loads((folder/report['case_reports'][descriptor['case']]['file']).read_text())
    with np.load(folder/rr['model_npz'],allow_pickle=False) as z:traces.append(dict(z))
result=audit_stream(itertools.chain(cold_rows(p),continued_rows(replay,96)),loaded,initial,final,traces,96)
assert result['steps']==96 and result['physical_column_steps']==1152 and not result['complete_calendar_year']
for claim in ['periodic_carbon_initialization_eligible']:
    assert not any(c[claim] for c in result['cases'])
source_unchanged=all(sha(s/n)==h for n,h in m.items());assert source_unchanged
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=source_unchanged,result=result,seconds=time.monotonic()-begun,
    scope='ActualJN frozenJT48+KCfirstcontinued48, 1152columnsteps ofarchivedC/N diagnostics only. Successfulreader/budget preflight doesnot make96a completeyear, climate/SOCequilibrium ornewinitializer. No original trajectory/source/parameter/rate changed.')
(r/'audit.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='result'}),flush=True)

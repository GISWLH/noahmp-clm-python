"""Exercise the queued archiver on copies of real closed files; no model run."""
from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,os,subprocess,tarfile,types,zipfile,zlib
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-year-archive-check-kr';tmp=Path(os.environ['TMPDIR']);source=b/'hrldas-current-year-kq/run_hrldas_year_kq.py';sha=lambda raw:hashlib.sha256(raw).hexdigest();digest=lambda p:sha(Path(p).read_bytes());tree=ast.parse(source.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['append_history','preserve_generation']];assert len(nodes)==2
scope=types.ModuleType('archival_under_test');scope.__dict__.update(Path=Path,json=json,os=os,zipfile=zipfile,zlib=zlib,sha=sha)
def atomic_json(path,value):
    p=Path(path);q=p.with_suffix('.tmp');q.write_text(json.dumps(value,indent=2)+'\n');os.replace(q,p)
scope.runner=SimpleNamespace(atomic_json=atomic_json);scope.trajectory=tmp/'trajectory';scope.trajectory.mkdir();scope.history=tmp/'history.zip';scope.index_path=tmp/'index.json';exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),scope.__dict__)
original=b/'hrldas-current-kg/runs/CN-HaM-suction-climate-cycle/trajectory';raw=(original/'report.json').read_bytes();report=json.loads(raw);assert report['status']=='running' and report['steps_completed']==336 and report['steps_requested']==17520 and report['source_unchanged'];closed={name:(original/name).read_bytes() for name in ['report.json',report['checkpoint_file'],report['model_npz']]}
assert sha(closed[report['checkpoint_file']])==report['checkpoint_sha256'] and sha(closed[report['model_npz']])==report['model_npz_sha256']
for name,value in closed.items():(scope.trajectory/name).write_bytes(value)
scope.preserve_generation(report)
with zipfile.ZipFile(scope.history) as z:
    for name,value in closed.items():assert z.read('0000336/'+name)==value
checks=['actual336-report-state-trace roundtrip exact']
old_names=['state-0000288.pkl','trace-0000288.npz'];older={name:(original/name).read_bytes() for name in old_names}
for name,value in older.items():(scope.trajectory/name).write_bytes(value)
try:scope.preserve_generation(report)
except AssertionError:pass
else:raise AssertionError('Unarchived closed generation was accepted for unlink')
assert all((scope.trajectory/n).read_bytes()==v for n,v in {**closed,**older}.items());checks.append('unarchived real288 generation rejected without data removal')
scope.append_history({'verified-closed/'+name:value for name,value in older.items()});scope.preserve_generation(report)
assert all(not (scope.trajectory/n).exists() for n in older)
with zipfile.ZipFile(scope.history) as z:
    for name,value in older.items():assert z.read('verified-closed/'+name)==value
checks.append('only previously verified real288 files removed; exact bytes remain in ZIP')
name=old_names[0];changed=bytes([older[name][0]^1])+older[name][1:];(scope.trajectory/name).write_bytes(changed)
try:scope.preserve_generation(report)
except AssertionError:pass
else:raise AssertionError('Byte-mismatched old file was accepted for unlink')
assert (scope.trajectory/name).read_bytes()==changed and all((scope.trajectory/n).read_bytes()==v for n,v in closed.items());checks.append('changed closed-file bytes rejected, copied current336 remains intact')
try:scope.append_history({'verified-closed/'+name:changed})
except AssertionError:pass
else:raise AssertionError('Different payload overwrote an existing archived identity')
with zipfile.ZipFile(scope.history) as z:assert z.testzip() is None and z.read('verified-closed/'+name)==older[name]
checks.append('duplicate archive identity with different bytes rejected; original CRC/data intact')
canary=r/'home-fsync-canary.tmp';assert not canary.exists();canary.write_bytes(b'archival-fsync-check\n')
with canary.open('r+b') as stream:os.fsync(stream.fileno())
assert canary.read_bytes()==b'archival-fsync-check\n';canary.unlink();checks.append('actual EHPC home filesystem r+b fsync verified')
assert (original/'report.json').read_bytes()==raw and all((original/n).read_bytes()==v for n,v in {**closed,**older}.items())
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_control_sha256=digest(source),passed=True,checks=checks,source_original336_files_sha256={n:sha(v) for n,v in closed.items()},older_actual288_files_sha256={n:sha(v) for n,v in older.items()},all_original_model_files_unchanged=True,
    scope='QueuedKQ actualarchival functions selected unchanged viaAST andexecuted onTMPDIR copies ofrealclosedHaM336/288 bytes. Data-loss negatives andactualhomefsync only, no physicalstepping/reportrewrite/oldmodelmutation or scientific/year/continuationclaim.')
(r/'check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

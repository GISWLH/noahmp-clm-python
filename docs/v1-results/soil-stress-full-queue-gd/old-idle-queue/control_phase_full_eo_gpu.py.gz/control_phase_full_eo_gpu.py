from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-full-eo-gpu';s=Path('/tmp/noahmp-phase-descent-ec/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==571 and manifest=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20' and all(sha(s/n)==h for n,h in m.items());records=[];reused=[];failure=None;begun=time.monotonic()
try:
    prior=b/'phase-cuda-years-en';pid=json.loads((prior/'launch.json').read_text())['pid']
    while not (prior/'exit.json').exists():
        try:os.kill(pid,0)
        except ProcessLookupError:raise RuntimeError('Prior yearqueue missing without durable actual terminal proof; do not overlap unknown workers')
        (r/'waiting-years.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),prior_controller_pid=pid,reason='Physical1 serialized after bothactualnativeyear parents terminal; failedyears remainfailed and do not receive passcredit'))+'\n');time.sleep(20.)
    years=json.loads((prior/'exit.json').read_text());assert years['source_unchanged'] and years['source_manifest_sha256']==manifest and len(years['records'])==2
    for case in years['records']:
        q=b/('qia-phase-'+case['case']+'-cuda-year-ej');e=json.loads((q/'year-exit.json').read_text());assert e['returncode']==case['actual_parent_returncode'] and sha(q/'year-receipt.json')==e['receipt_sha256']
    (r/'prior-year-exit.json').write_bytes((prior/'exit.json').read_bytes());collection=json.loads((b/'phase-descent-ec-gpu/collection.json').read_text());assert collection['passed'] and collection['total_count']==1521 and collection['gpu_count']==401 and collection['source_unchanged'] and collection['source_manifest_sha256']==manifest;(r/'collection.json').write_bytes((b/'phase-descent-ec-gpu/collection.json').read_bytes())
    cpu=b/'phase-descent-ec-gpu/cpu-full-receipt.json';proof=json.loads(cpu.read_text());assert proof['returncode']==0 and proof['counts']==dict(tests=1120,failures=0,errors=0,skipped=0) and proof['source_unchanged'] and proof['source_manifest_sha256']==manifest;(r/'cpu-full-receipt.json').write_bytes(cpu.read_bytes());(r/'cpu-pbs-exit.txt').write_bytes((b/'phase-descent-ec-gpu/cpu-pbs-exit.txt').read_bytes());assert (r/'cpu-pbs-exit.txt').read_text().strip()=='0'
    gpu=[n for n in collection['nodes'] if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];assert len(gpu)==len(set(gpu))==401;by_file={}
    for node in gpu:by_file.setdefault(Path(node.split('::')[0]).name,[]).append(Path(node.split('::')[0]).name+'::'+node.split('::',1)[1])
    excluded=['test_gpu_canopy_phase_weak_descent.py','test_gpu_canopy_phase_energy.py','test_gpu_canopy_phase_surface.py']
    for parent,names in [(b/'phase-descent-ec-gpu',excluded[:1]),(b/'phase-descent-ee-gpu',excluded[1:])]:
        e=json.loads((parent/'exit.json').read_text());assert e['passed'] and e['returncode']==0 and e['source_unchanged'] and e['source_manifest_sha256']==manifest
        for name in names:
            stem=Path(name).stem;d=json.loads((parent/(stem+'-receipt.json')).read_text());row=next(q for q in e['records'] if q['file']==name)
            assert row['passed'] and row['actual_parent_returncode']==0 and row['receipt_sha256']==sha(parent/(stem+'-receipt.json')) and d['counts']==dict(tests=len(by_file[name]),failures=0,errors=0,skipped=0) and d['source_unchanged'] and d['source_manifest_sha256']==manifest and d['test_sha256']==sha(s/'tests'/name) and d['node_coverage_exact'] and d['all_setup_call_teardown_phases_passed']
            assert d['xml_sha256']==sha(parent/(stem+'.xml')) and d['expected_nodes_sha256']==sha(parent/(stem+'-expected.json')) and set(json.loads((parent/(stem+'-expected.json')).read_text()))==set(by_file[name])
            folder=r/'reused'/stem;folder.mkdir(parents=True)
            for suffix in ['-receipt.json','-expected.json','.xml','.log']:(folder/(stem+suffix)).write_bytes((parent/(stem+suffix)).read_bytes())
            reused.append(dict(file=name,tests=len(by_file[name]),actual_parent_returncode=0,receipt_sha256=row['receipt_sha256'],original_root=str(parent)))
    assert sum(q['tests'] for q in reused)==21
    coupled=['test_gpu_clm_richards_column.py','test_gpu_fluxnet_richards_runner.py','test_gpu_clm_capacity_column.py','test_gpu_fluxnet_capacity_runner.py'];files=sorted(n for n in by_file if n not in excluded and n not in coupled)+coupled;assert len(files)==len(by_file)-3 and sum(len(by_file[n]) for n in files)==380
    (r/'execution-plan.json').write_text(json.dumps(dict(files=[dict(file=n,tests=len(by_file[n])) for n in files],reused=reused,source_manifest_sha256=manifest,scope='All401 currentEC GPU nodes, exact21 actualpassed reused plus remaining380 originalunmodifiedtests. Source/test/node/XML/phase proof checked; allCPU1120 alreadyEHPC. Embedded NumPyreferences in originalGPUtest bodies retained, no standaloneCPU suite or climate NumPy onxuanze.'),indent=2)+'\n')
    for name in files:
        while True:
            free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());memory=int(next(q.split()[1] for q in Path('/proc/meminfo').read_text().splitlines() if q.startswith('MemAvailable:')))
            if free>8192 and memory>32*1024*1024:break
            (r/'waiting-resource.json').write_text(json.dumps(dict(file=name,gpu_free_mib=free,host_available_kib=memory))+'\n');time.sleep(20.)
        assert all(sha(s/n)==h for n,h in m.items());stem=Path(name).stem;expected=r/(stem+'-expected.json');expected.write_text(json.dumps(by_file[name],indent=2)+'\n');receipt=r/(stem+'-receipt.json');xml=r/(stem+'.xml');env=os.environ.copy();diag=r/(stem+'-diagnostics');diag.mkdir()
        for key in ['NOAHMP_CAPACITY_COLUMN_DIAGNOSTICS','NOAHMP_PFT_DIAGNOSTICS','NOAHMP_RICHARDS_COLUMN_DIAGNOSTICS','NOAHMP_RICHARDS_STATION_DIAGNOSTICS','NOAHMP_CAPACITY_STATION_DIAGNOSTICS']:env[key]=str(diag)
        command=[sys.executable,'-u',str(r/'phase_full_eo_worker.py'),'--source',str(s),'--test-file',str(s/'tests'/name),'--expected',str(expected),'--receipt',str(receipt),'--xml',str(xml)];started=time.monotonic()
        with (r/(stem+'.log')).open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
        (r/'progress.json').write_text(json.dumps(dict(active_file=name,pid=p.pid,records=records,reused=reused),indent=2)+'\n');code=p.wait();d=json.loads(receipt.read_text()) if receipt.exists() else {};passed=bool(code==d.get('worker_exitcode')==d.get('pytest_returncode')==0 and d.get('passed') and d.get('source_unchanged') and d.get('source_manifest_sha256')==manifest and d.get('node_coverage_exact') and d.get('all_setup_call_teardown_phases_passed') and d.get('counts')==dict(tests=len(by_file[name]),failures=0,errors=0,skipped=0) and d.get('xml_sha256')==sha(xml))
        row=dict(file=name,pid=p.pid,expected_tests=len(by_file[name]),counts=d.get('counts'),passed=passed,actual_parent_returncode=code,seconds=time.monotonic()-started,receipt_sha256=sha(receipt) if receipt.exists() else None);records.append(row);(r/(stem+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
        # Keep every original failure and still exercise independent files.
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc())
d=dict(passed=failure is None and sum(q['expected_tests'] for q in records)==380 and all(q['passed'] for q in records) and len(reused)==3,records=records,reused=reused,failure=failure,seconds=time.monotonic()-begun,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=manifest,scope='CurrentEC full401GPU coverage requires exact21 same-source actualpassed nodes plus allremaining380 completeoriginalpytest phases/XML/devicebarriers/source/int/1e-6/science/budgets. Actualfailure/resourceattempt remainsfailed; originalreference bodies retained. FullGPU pass does not prove annual/FLUXNET/officialscience/spinup or release.')
(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');raise SystemExit(0 if d['passed'] and d['source_unchanged'] else 1)

from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
root=Path.cwd();out=root/'numpy-full';summary=json.loads((out/'summary.json').read_text())
selection=json.loads((out/'selection.json').read_text());assert not summary['failures']
assert {v['file'] for v in summary['results']}==set(selection['files'])
counts={key:0 for key in ['tests','failures','errors','skipped']}
for file in selection['files']:
    document=ET.parse(out/(Path(file).stem+'.xml')).getroot()
    for suite in document.iter('testsuite'):
        for key in counts:counts[key]+=int(suite.attrib[key])
assert counts['failures']==counts['errors']==counts['skipped']==0,counts
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in manifest.items())
report=dict(scope=summary['scope'],source_unchanged=True,source_files=len(manifest),source_manifest_sha256=hashlib.sha256((root/'SOURCE_SHA256.json').read_bytes()).hexdigest(),
    files=summary['files_total'],counts=counts,seconds=summary['seconds'])
(out/'verified-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

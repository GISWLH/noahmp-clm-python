from pathlib import Path
import hashlib,json,os,sys
import pytest
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-b';r=s/'full-by-file-a';m=json.loads((s/'SOURCE_SHA256.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(s/n)==v for n,v in m.items());nodes=[]
class Capture:
 def pytest_collection_finish(self,session):nodes.extend(x.nodeid for x in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));assert code==0 and len(nodes)==len(set(nodes))==1254
barriers=[]
for name in ['jax','cupy']:
 if name in sys.modules:
  if name=='jax':sys.modules[name].effects_barrier()
  else:sys.modules[name].cuda.runtime.deviceSynchronize()
  barriers.append(name)
assert all(sha(s/n)==v for n,v in m.items())
d=dict(scope='Actual collect-only,not test execution or science acceptance; interpreter atexit bypass only after pytest return/device barriers and durable receipt.',returncode=code,nodes=nodes,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,device_barriers=barriers)
with (r/'collection.json').open('x') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
sys.stdout.flush();sys.stderr.flush();os._exit(0)

from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-all-phase-final-b'
r = s / 'full-by-file-a'
r.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
begun = time.monotonic()

def verify():
    assert len(m) == 511 and all(sha(s / n) == v for n, v in m.items())

def nodes(raw):
    result = []
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(k) is None for k in ['failure', 'error', 'skipped'])
        parts = c.attrib['classname'].split('.')
        where = [i for i, n in enumerate(parts) if n.startswith('test_')]
        assert len(where) == 1
        i = where[0]
        result.append('tests/' + parts[i] + '.py::' + '::'.join(parts[i+1:] + [c.attrib['name']]))
    assert len(result) == len(set(result))
    return set(result)

verify()
with (r / 'collection.log').open('x') as log:
    code = subprocess.run([sys.executable, '-u', str(b / 'collect_all_phase_full_gpu_b.py')], cwd=s, stdout=log, stderr=subprocess.STDOUT).returncode
assert code == 0
collection = json.loads((r / 'collection.json').read_text())
allnodes = set(collection['nodes'])
assert len(allnodes) == 1254 and collection['source_unchanged'] and collection['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json')
gpu = {n for n in allnodes if Path(n.split('::')[0]).name.startswith(('test_gpu', 'test_jax', 'test_cuda'))}
cpu = allnodes - gpu
assert len(cpu) == 911 and len(gpu) == 343

archives = {}
for label, digest in [('all-phase-cpu-final-b', 'd883698681d114e5822982614190c0565551a45ac98fdff6460dfc322cfcc38b'), ('all-phase-gpu-target-b', '057d5819299b118f61b557fcacdf2cf33e29a968a74a6ae6d4cfd753f21d6f0b')]:
    path = b / (label + '-evidence.tar.gz')
    assert sha(path) == digest
    with tarfile.open(path) as t:
        archives[label] = {v.name: t.extractfile(v).read() for v in t if v.isfile()}
a, g = archives['all-phase-cpu-final-b'], archives['all-phase-gpu-target-b']
g={n.split('/',1)[1] if n.startswith('target-a/') else n:raw for n,raw in g.items()}
assert json.loads(a['SOURCE_SHA256.json']) == json.loads(g['SOURCE_SHA256.json']) == m
cpu_receipt = json.loads(a['cpu-full-receipt.json'])
assert cpu_receipt['returncode'] == 0 and cpu_receipt['source_unchanged'] and cpu_receipt['counts'] == dict(tests=911, failures=0, errors=0, skipped=0)
assert nodes(a['cpu-full.xml']) == cpu and hashlib.sha256(a['cpu-full.xml']).hexdigest() == cpu_receipt['xml_sha256']
rec = json.loads(g['receipt.json'])
exit_record = json.loads(g['exit.json'])
prefix = nodes(g['targets.xml'])
file = 'tests/test_gpu_canopy_phase_energy.py'
assert prefix == {n for n in gpu if n.split('::')[0] == file} and len(prefix) == 11
assert exit_record['passed'] and exit_record['returncode'] == rec['worker_exitcode'] == rec['pytest_returncode'] == 0 and hashlib.sha256(g['receipt.json']).hexdigest() == exit_record['receipt_sha256']
assert rec['passed'] and rec['source_unchanged'] and rec['all_setup_call_teardown_phases_passed'] and rec['node_coverage_exact'] and rec['counts'] == dict(tests=11, failures=0, errors=0, skipped=0)
assert rec['test_sha256'] == m[file] and rec['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and hashlib.sha256(g['targets.xml']).hexdigest() == rec['xml_sha256']
covered = cpu | prefix
worker = b / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
assert sha(worker) == '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
pending = sorted({n.split('::')[0] for n in gpu} - {file}, key=lambda n: ('_column' in n or 'surface' in n, n))
scope = 'Current frozen511 all-phase-edge B canonical1254: exact EHPC911 plus actual xuanzephase11,remaining332GPU run only after predecessor actualexit. No prior506/509/510 or failed A targets credited. Original phases/barriers/exits/raw1e-6/MHCN/atexit disclosure retained;not science/year/spinup acceptance.'
(r / 'selection.json').write_text(json.dumps(dict(scope=scope, collected_nodes=sorted(allnodes), cpu_nodes=911, gpu_nodes=343, same_source_gpu_prefix_nodes=sorted(prefix), pending_files=pending, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json')), indent=2) + '\n')
results = []

def save(active=None):
    d = dict(scope=scope, status='running', covered_nodes=len(covered), covered_gpu_nodes=len(covered) - 911, collected_nodes=1254, active=active, results=results, seconds=time.monotonic() - begun)
    tmp = r / 'progress.json.tmp'
    tmp.write_text(json.dumps(d, indent=2) + '\n')
    os.replace(tmp, r / 'progress.json')

save()
for file in pending:
    verify()
    name = Path(file).stem
    expected = {n for n in gpu if n.split('::')[0] == file}
    expected_path = r / (name + '-expected.json')
    expected_path.write_text(json.dumps(sorted(Path(n.split('::')[0]).name + '::' + n.split('::', 1)[1] for n in expected), indent=2) + '\n')
    receipt_path, xml = r / (name + '-receipt.json'), r / (name + '.xml')
    start = time.monotonic()
    with (r / (name + '.log')).open('x') as log:
        p = subprocess.Popen([sys.executable, '-u', str(worker), '--source', str(s), '--test-file', str(s / file), '--expected', str(expected_path), '--receipt', str(receipt_path), '--xml', str(xml)], cwd=s, stdout=log, stderr=subprocess.STDOUT)
        save(dict(file=file, pid=p.pid))
        code = p.wait()
    row = dict(file=file, pid=p.pid, returncode=code, seconds=time.monotonic() - start, passed=False)
    if receipt_path.exists():
        rec = json.loads(receipt_path.read_text())
        row['receipt'] = rec
        if code == rec['worker_exitcode'] == rec['pytest_returncode'] == 0 and rec['passed'] and rec['source_unchanged'] and rec['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and rec['test_sha256'] == m[file] and rec['xml_sha256'] == sha(xml) and nodes(xml.read_bytes()) == expected:
            row['passed'] = True
            covered.update(expected)
    results.append(row)
    save()
    print(json.dumps({k: v for k, v in row.items() if k != 'receipt'}), flush=True)
verify()
complete = covered == allnodes and all(x['passed'] for x in results)
(r / 'summary.json').write_text(json.dumps(dict(scope=scope, status='complete' if complete else 'failed', source_unchanged=True, collected_nodes=1254, covered_nodes=len(covered), all_node_coverage_exact=covered == allnodes, results=results, same_source_gpu_prefix_nodes=sorted(prefix), seconds=time.monotonic() - begun), indent=2) + '\n')
raise SystemExit(0 if complete else 1)

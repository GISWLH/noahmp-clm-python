from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import tarfile
import time

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'p6-all-phase-final-b'
r = s / 'full-controller-a'
assert not r.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 511 and all(sha(s / n) == v for n, v in m.items())
for label, digest in [('all-phase-cpu-final-b', 'd883698681d114e5822982614190c0565551a45ac98fdff6460dfc322cfcc38b'), ('all-phase-gpu-target-b', '057d5819299b118f61b557fcacdf2cf33e29a968a74a6ae6d4cfd753f21d6f0b')]:
    path = b / (label + '-evidence.tar.gz')
    assert sha(path) == digest
    with tarfile.open(path) as t:
        assert json.loads(t.extractfile('SOURCE_SHA256.json').read()) == m
        if label == 'all-phase-cpu-final-b':
            d = json.loads(t.extractfile('cpu-full-receipt.json').read())
            assert d['returncode'] == 0 and d['counts'] == dict(tests=911, failures=0, errors=0, skipped=0) and d['source_unchanged']
        else:
            d = json.loads(t.extractfile('target-a/exit.json').read())
            assert d['passed'] and d['returncode'] == 0
r.mkdir()
old_b = b / 'p6-fresh-phase-edge-a/full-controller-a'
old_launch = json.loads((old_b / 'launch.json').read_text())
old_pid = int(old_launch['pid'])
assert old_pid == 2750196
wait_file = b / 'p6-phase-final-check-a/full-controller-a/exit.json'
wait_pid = 2557162
cancel = dict(scope='Supersede only obsolete510 idle deferred coordinator after current911CPU/11GPU evidence and complete next pipeline are staged. No model/GPU worker,old493 task,strict real day or annual trajectory is signaled. Original 510 source/launch/records retained; no fabricated exit code.', original_launch_sha256=sha(old_b / 'launch.json'), original_pid=old_pid, current_source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'))
(r / 'original-pending-510-launch.json').write_bytes((old_b / 'launch.json').read_bytes())
if (old_b / 'worker.json').exists() or (old_b / 'exit.json').exists():
    wait_file = old_b / 'exit.json'
    wait_pid = old_pid
    cancel['action'] = 'No signal; original 510 already launched/terminated, wait for its actual exit'
else:
    proc = Path('/proc/' + str(old_pid))
    assert proc.exists() and proc.stat().st_uid == os.getuid()
    argv = (proc / 'cmdline').read_bytes().split(b'\0')
    assert str(b / 'wait_fresh_phase_full_gpu_a.py').encode() in argv
    cancel.update(verified_uid=os.getuid(), original_argv=[a.decode() for a in argv if a], original_start_ticks=int((proc / 'stat').read_text().split()[21]))
    stopped = False
    try:
        # Freeze this owned idle coordinator to close the child-launch race.
        # If a child already exists, resume it and leave the original job alone.
        os.kill(old_pid, signal.SIGSTOP)
        stopped = True
        deadline = time.monotonic() + 5
        while (proc / 'stat').read_text().split()[2] not in ['T', 't']:
            assert time.monotonic() < deadline
            time.sleep(.05)
        children = (proc / 'task' / str(old_pid) / 'children').read_text().strip()
        if children or (old_b / 'worker.json').exists():
            cancel.update(action='Resumed without terminating: existing child/worker observed', children=children)
            wait_file, wait_pid = old_b / 'exit.json', old_pid
        else:
            cancel.update(action='SIGTERM sent only to verified stopped idle 510 coordinator', children_before_signal='', original_gpu_worker_absent=True)
            (r / 'superseded-pending-510.json').write_text(json.dumps(cancel, indent=2) + '\n')
            os.kill(old_pid, signal.SIGTERM)
    finally:
        if stopped:
            try:
                os.kill(old_pid, signal.SIGCONT)
            except ProcessLookupError:
                pass
    if cancel['action'].startswith('SIGTERM'):
        deadline = time.monotonic() + 10
        while proc.exists() and (proc / 'stat').read_text().split()[2] != 'Z':
            assert time.monotonic() < deadline
            time.sleep(.05)
        cancel.update(observed_terminal_state='absent' if not proc.exists() else 'Z', original_gpu_worker_still_absent=not (old_b / 'worker.json').exists(), actual_returncode='not observable by this external coordinator; no exit receipt invented')
        assert cancel['original_gpu_worker_still_absent']
(r / 'superseded-pending-510.json').write_text(json.dumps(cancel, indent=2) + '\n')
if not wait_file.exists():
    assert Path('/proc/' + str(wait_pid)).exists()
controls = {n: sha(b / n) for n in ['collect_all_phase_full_gpu_b.py', 'run_all_phase_full_gpu_b.py', 'wait_all_phase_full_gpu_b.py', 'launch_all_phase_full_gpu_b.py']}
env = os.environ.copy()
env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str, [s, s / 'src', s / 'tests', s / 'benchmarks'])), PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='1', CUDA_PATH='/usr/local/cuda-12.4', PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_COMPILATION_CACHE_DIR=str(b / 'jax-surface-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NOAHMP_REQUIRE_GPU='1')
launch = dict(scope='Deferred current-source canonical1254: exact same-source911CPU plus11GPU, every remaining332 GPU node will run after actual predecessor exit. Obsolete510 pending coordinator superseded with ownership/child guards; original model tasks untouched. Queueing is not collection/completion or science acceptance.', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), device=1, source_files=511, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), controls_sha256=controls, wait_for_actual_exit=str(wait_file), wait_for_original_pid=wait_pid, superseded_record_sha256=sha(r / 'superseded-pending-510.json'))
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
with (r / 'controller.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'wait_all_phase_full_gpu_b.py')], cwd=s, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
launch['pid'] = p.pid
(r / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps(dict(launch=launch, superseded=cancel)))

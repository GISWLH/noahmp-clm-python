from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-b';r=s/'collection-preflight-a'
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
with (b/'all-phase-precollection-b.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(b/'collect_all_phase_preflight_b.py')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
rec=json.loads((r/'collection.json').read_text()) if (r/'collection.json').exists() else None
assert code==0 and rec and rec['source_unchanged'] and len(rec['nodes'])==1254
(r/'actual-exit.json').write_text(json.dumps(dict(scope='Actual frozen B511 collection only; not test execution or scientific acceptance. Original worker-atexit bypass disclosed after collection/barriers in receipt.',returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),nodes=len(rec['nodes']),collection_sha256=hashlib.sha256((r/'collection.json').read_bytes()).hexdigest()),indent=2)+'\n')
print(json.dumps(dict(returncode=code,nodes=len(rec['nodes']),source_manifest_sha256=rec['source_manifest_sha256'])))

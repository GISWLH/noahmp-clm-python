from pathlib import Path
import ast
r=Path(__file__).resolve().parent;p=(r/'run_ctsm_qia_i.py').read_text().replace('ctsm-qia-run-i','ctsm-qia-run-j');old='CLM_CO2_TYPE=diagnostic,CLM_FORCE_COLDSTART=on';assert p.count(old)==1;p=p.replace(old,old+',CCSM_BGC=CO2A');ast.parse(p);(r/'run_ctsm_qia_j.py').write_text(p)
p=(r/'ctsm_qia_run_i.pbs').read_text().replace('ctsm-qia-run-i','ctsm-qia-run-j').replace('run_ctsm_qia_i.py','run_ctsm_qia_j.py').replace('clm-qia-official-i','clm-qia-official-j');(r/'ctsm_qia_run_j.pbs').write_bytes(p.encode())

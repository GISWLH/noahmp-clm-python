from pathlib import Path
import hashlib,json,re,tarfile,xml.etree.ElementTree as ET
b=Path('/home/zhangyq/noahmp-v1');entries=[];sources=[]
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 for m in t:
  if not m.isfile():continue
  if m.name.endswith('.xml') and 'cime' in m.name:
   raw=t.extractfile(m).read()
   try:tree=ET.fromstring(raw)
   except ET.ParseError:continue
   for e in tree.iter('entry'):
    if e.get('id') in ['CCSM_BGC','CLM_CO2_TYPE','DATM_CO2_TSERIES']:entries.append(dict(source=m.name,sha256=hashlib.sha256(raw).hexdigest(),entry=ET.tostring(e,encoding='unicode')))
  if m.name.endswith('.F90') and any(n in m.name for n in ['seq_flds_mod','datm_comp_mod']):
   raw=t.extractfile(m).read();lines=raw.decode().splitlines();selected=set()
   for i,line in enumerate(lines):
    if 'co2diag' in line.lower():selected.update(range(max(0,i-6),min(len(lines),i+8)))
   if selected:sources.append(dict(source=m.name,sha256=hashlib.sha256(raw).hexdigest(),lines=[str(i+1)+':'+lines[i] for i in sorted(selected)]))
d=dict(scope='Read-only pinned official CO2 stream/coupler-field configuration after actual I init error; no physical implementation copied or modified.',entries=entries,sources=sources);p=b/'ctsm-qia-run-i/co2-field-contract.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,io,json,re,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'ctsm-qia-runs-ijk-evidence.tar.gz';assert not a.exists();rows=[]
with tarfile.open(a,'w:gz') as t:
 for letter,modelcode in [('i',233),('j',2),('k',0)]:
  name='ctsm-qia-run-'+letter;r=b/name;d=json.loads((r/'configuration.json').read_text());assert d['official_model_returncode']==modelcode and d['upstream_original_bytes_unchanged'] and (r/'pbs-exit.txt').read_text().strip()==('0' if modelcode==0 else '1');assert next(s for s in d['stages'] if s['stage']=='case-build')['returncode']==0
  for p in sorted(r.iterdir()):
   if p.is_file() and p.name!='case-configuration-private.tar.gz':t.add(p,arcname=name+'/'+p.name,recursive=False)
  indices=[];samples=0
  with tarfile.open(r/'case-configuration-private.tar.gz') as original:
   for m in original:
    if m.isfile() and (m.name.endswith(('.stdout.txt','.stderr.txt','-adaptation.json','.stream')) or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in','drv_in','lnd_in'])) or m.name.startswith('case/user_nl_')):
     data=original.extractfile(m).read();info=tarfile.TarInfo(name+'/workspace/'+m.name);info.size=len(data);t.addfile(info,io.BytesIO(data))
     if 'lnd.log.' in m.name:
      text=data.decode(errors='replace');indices.extend(map(int,re.findall(r'clm: completed timestep\s+(\d+)',text)));samples+=text.count('Writing current time sample')
  rows.append(dict(case=name,pbs=d['pbs_job'],model_returncode=modelcode,parent_pbs_returncode=0 if modelcode==0 else 1,seconds=d['seconds'],upstream_original_bytes_unchanged=True,written_history_samples=samples,last_completed_nstep=max(indices) if indices else None,output_files=d['model_outputs'],private_workspace_sha256=sha(r/'case-configuration-private.tar.gz')))
 assert rows[1]['written_history_samples']==17 and rows[1]['last_completed_nstep']==16
 assert rows[2]['written_history_samples']>=48 and rows[2]['last_completed_nstep']>=47
 summary=dict(scope='Actual pinned official I init failure233 at missing CO2 driver field, J16 physical intervals plus startup sample then timing-dir failure2, K first48-step requested execution model/PBS0 after generated CO2A fields/output-dir configuration only. Original2930 source bytes unchanged. K time-bin/feed-through/FPSN/cold-soil/SP-CN comparability still need explicit output audit; no scientific acceptance.',cases=rows)
 data=(json.dumps(summary,indent=2)+'\n').encode();info=tarfile.TarInfo('summary.json');info.size=len(data);t.addfile(info,io.BytesIO(data));t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False);t.add(b/'inspect_ctsm_co2_field_contract_i.py',arcname='control/inspect_ctsm_co2_field_contract_i.py',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,cases=[{k:v for k,v in row.items() if k not in ['output_files','private_workspace_sha256']} for row in rows])))

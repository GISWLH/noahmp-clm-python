from pathlib import Path
import ast
r=Path(__file__).resolve().parent;p=(r/'run_ctsm_qia_h.py').read_text().replace('ctsm-qia-run-h','ctsm-qia-run-i');assert p.count("'GPP'")==1;p=p.replace("'GPP'","'FPSN'")
marker="    value['crop_landunit_scope']=";i=p.index(marker);p=p[:i]+"    value['sp_photosynthesis_history_scope']='Actual H catalog lacks CN-only GPP; request available FPSN photosynthesis diagnostic. Gross/net GPP interpretation still requires source/output audit; SP cannot validate NEE/CN.'\n"+p[i:];ast.parse(p);(r/'run_ctsm_qia_i.py').write_text(p)
p=(r/'ctsm_qia_run_h.pbs').read_text().replace('ctsm-qia-run-h','ctsm-qia-run-i').replace('run_ctsm_qia_h.py','run_ctsm_qia_i.py').replace('clm-qia-official-h','clm-qia-official-i');(r/'ctsm_qia_run_i.pbs').write_bytes(p.encode())

from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-stem-numpy-week-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = json.loads((r / 'receipt.json').read_text())
report = json.loads((r / 'trajectory/report.json').read_text())
assert receipt['returncode'] == 1 and receipt['source_unchanged'] and (r / 'pbs-exit.txt').read_text().strip() == '1'
assert report['status'] == 'failed' and report['steps_completed'] == report['failed_index'] == 163 and report['steps_requested'] == 17520
assert sha(r / 'trajectory/report.json') == receipt['report_sha256']
for key, digest in [('model_npz', 'model_npz_sha256'), ('checkpoint_file', 'checkpoint_sha256')]:
    assert sha(r / 'trajectory' / report[key]) == report[digest]
a = b / 'qia-stem-numpy-week-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():
            t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
    summary = dict(scope='Actual original NumPy continuation of successful48 toward336, failed unchanged source at next step index163 before accepting it. Original failed trajectory/state and all conservation traces retained; not a completed week/year,never resumed with changed source.', receipt=receipt, failure=report['failure'], maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'], failed_index=163)
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, status='failed', steps_completed=163, maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'])))

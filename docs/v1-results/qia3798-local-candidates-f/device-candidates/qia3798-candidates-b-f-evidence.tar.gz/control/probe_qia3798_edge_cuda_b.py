from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s, r = b / 'p6-most-physical-c', b / 'qia-cuda-3798-a'
out = r / 'edge-trial-b'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver
import noahmp_clm.gpu.cuda.canopy_phase_surface as module
import cupy as cp

binding = json.loads((r / 'binding.json').read_text())
assert sha(r / 'input.npz') == binding['input_sha256']
with np.load(r / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
engine = driver.Backend('cuda32')
before = engine.update_forcing(tuple(cp.asarray(data['a' + str(k)]) for k in range(19)), data['environment'])
old = tuple(engine.host(v) for v in before)
files = ['leaf_kernel.cu', 'radiation_kernel.cu', 'canopy_energy_kernel.cu', 'canopy_phase_energy_kernel.cu',
         'enthalpy_kernel.cu', 'column_heat_kernel.cu', 'snow_mass_kernel.cu', 'snow_vapor_kernel.cu',
         'snow_evolution_kernel.cu', 'soil_transport_kernel.cu', 'canopy_surface_kernel.cu', 'canopy_phase_surface_kernel.cu']
folder = s / 'src/noahmp_clm/gpu/cuda'
phase = (folder / 'canopy_phase_energy_kernel.cu').read_text()
marker = '        if(!accepted||chosen_norm>.999f*norm) {'
assert phase.count(marker) == 1
addition = '''        // Diagnostic port of the already validated NumPy fresh-parcel edge trial.
        float edge_alpha=2.f,edge_value=0.f;int edge_layer=-1;
        for(int i=0;i<10;++i)if(v.phase_active[i]&&v.c[2*i]==0.f&&delta[i]!=0.f){
            for(int side=0;side<2;++side){
                float edge=side?plateau:0.f,alpha=(edge-x[i])/delta[i];
                if(alpha>0.f&&alpha<=1.f&&alpha<edge_alpha){edge_alpha=alpha;edge_layer=i;edge_value=edge;}
            }
        }
        if(edge_layer>=0){
            float trial[12],rr[12];
            for(int i=0;i<12;++i)trial[i]=fminf(upper[i],fmaxf(lower[i],x[i]+edge_alpha*delta[i]));
            trial[edge_layer]=edge_value;phase_evaluate(v,trial,rr,nullptr);
            float event_norm=ca_dot(rr,rr,12);
            if(event_norm<chosen_norm){for(int i=0;i<12;++i)chosen[i]=trial[i];accepted=true;chosen_norm=event_norm;}
        }
'''
candidate = phase.replace(marker, addition + marker)
(out / 'phase-original.cu').write_text(phase)
(out / 'phase-candidate.cu').write_text(candidate)
code = '\n'.join(candidate if name == 'canopy_phase_energy_kernel.cu' else (folder / name).read_text() for name in files)
compiled = {}


def kernel(extended=False, vic=False, stems=False):
    name = 'run_canopy_phase_surface_stems' if stems else ('run_canopy_phase_surface_vic' if vic else ('run_canopy_phase_surface_extended' if extended else 'run_canopy_phase_surface'))
    if name not in compiled:
        compiled[name] = cp.RawModule(code=code, options=('--std=c++14', '--fmad=false', '--prec-div=false', '--prec-sqrt=false'), name_expressions=(name,))
    return compiled[name].get_function(name)


original = module._kernel
module._kernel = kernel
start, failure, result = time.monotonic(), None, None
try:
    value = engine.step(*before, data['forcing'], environment=data['calendar_values'], calendar=data['calendar_flags'],
                        nitrogen_deposition_gn_m2=data['nitrogen'], deposition=data['deposition'], most_geometry=data['geometry'],
                        leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']), return_surface=True)
    host = engine.host(value)
    after = tuple(engine.host(v) for v in driver.next_station_arrays(before, value))
    flat = {}
    def flatten(value, prefix=''):
        for name, v in value.items():
            if isinstance(v, dict):
                flatten(v, prefix + name + '/')
            else:
                flat[prefix + name] = np.asarray(v)
    flatten(host)
    np.savez_compressed(out / 'output.npz', **flat)
    np.savez_compressed(out / 'state.npz', **{'a' + str(k): v for k, v in enumerate(after)})
    result = dict(fields=len(flat), diagnostics={k: np.asarray(v).tolist() for k, v in host['diagnostics'].items()},
                  output_sha256=sha(out / 'output.npz'), state_sha256=sha(out / 'state.npz'))
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (out / 'traceback.txt').write_text(traceback.format_exc())
finally:
    module._kernel = original
cp.cuda.runtime.deviceSynchronize()
assert all(sha(s / n) == h for n, h in m.items()) and all(np.array_equal(v, engine.host(w)) for v, w in zip(old, before))
record = dict(scope='Isolated CUDA diagnostic candidate ports only current NumPy strict-descent fresh-parcel phase-edge trial. Original phase100/.005 and all production final checks retained; no production source change or acceptance of failed year. Full raw outputs exported for independent EHPC MHCN acceptance; no NumPy forward physics/audit on xuanze. Not JAX parity/current canonical/year/science pass. Atexit bypass after explicit barrier/receipt.',
              failure=failure, result=result, seconds=time.monotonic() - start, source_unchanged=True, input_unchanged=True,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), input_sha256=binding['input_sha256'],
              original_phase_sha256=sha(out / 'phase-original.cu'), candidate_phase_sha256=sha(out / 'phase-candidate.cu'), device_barrier_complete=True)
(out / 'receipt.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)
os._exit(0 if failure is None else 1)

from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s, r = b / 'p6-most-physical-c', b / 'qia-cuda-3798-a'
out = r / 'edge-capture-c'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 509 and all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver
import noahmp_clm.gpu.cuda.canopy_phase_surface as module

binding = json.loads((r / 'binding.json').read_text())
assert sha(r / 'input.npz') == binding['input_sha256']
with np.load(r / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
engine = driver.Backend('cuda32')
xp = engine.xp
before = engine.update_forcing(tuple(xp.asarray(data['a' + str(k)]) for k in range(19)), data['environment'])
before_host = tuple(engine.host(v) for v in before)
original, unpack = module.run_canopy_phase_surface_cuda, module.unpack_phase_surface
calls, captured = [], {}


def observe_raw(raw):
    result = unpack(raw)
    if not bool(xp.all(result['converged'])) or not bool(xp.all(xp.isfinite(raw))):
        captured['raw'] = engine.host(raw)
    return result


def observe(*arrays, **kwargs):
    result = original(*arrays, **{**kwargs, 'raise_on_failure': False})
    good = bool(xp.all(result['converged']))
    calls.append(dict(call=len(calls) + 1, converged=good,
                      canopy_converged=engine.host(result['canopy_converged']).tolist(),
                      max_solver_residual=engine.host(result['max_solver_residual']).tolist()))
    if not good or 'raw' in captured:
        payload = {'surface_a' + str(k): engine.host(v) for k, v in enumerate(arrays)}
        for name in ['exchange_extension', 'vic', 'stem_area']:
            if kwargs.get(name) is not None:
                payload[name] = engine.host(kwargs[name])
        payload['raw'] = captured['raw']
        np.savez_compressed(out / 'failed-surface.npz', **payload)
        (out / 'leaf-parameters.json').write_text(json.dumps(vars(kwargs['parameters']), indent=2) + '\n')
        raise RuntimeError('CUDA layered phase surface failed; inspect with raise_on_failure=False')
    return result


files = ['leaf_kernel.cu', 'radiation_kernel.cu', 'canopy_energy_kernel.cu', 'canopy_phase_energy_kernel.cu',
         'enthalpy_kernel.cu', 'column_heat_kernel.cu', 'snow_mass_kernel.cu', 'snow_vapor_kernel.cu',
         'snow_evolution_kernel.cu', 'soil_transport_kernel.cu', 'canopy_surface_kernel.cu', 'canopy_phase_surface_kernel.cu']
import cupy as cp
folder = s / 'src/noahmp_clm/gpu/cuda'
phase = (folder / 'canopy_phase_energy_kernel.cu').read_text()
marker = '        if(!accepted||chosen_norm>.999f*norm) {'
assert phase.count(marker) == 1
addition = '''        // Diagnostic port of the already validated NumPy fresh-parcel edge trial.
        float edge_alpha=2.f,edge_value=0.f;int edge_layer=-1;
        for(int i=0;i<10;++i)if(v.phase_active[i]&&v.c[2*i]==0.f&&delta[i]!=0.f){
            for(int side=0;side<2;++side){
                float edge=side?plateau:0.f,alpha=(edge-x[i])/delta[i];
                if(alpha>0.f&&alpha<=1.f&&alpha<edge_alpha){edge_alpha=alpha;edge_layer=i;edge_value=edge;}
            }
        }
        if(edge_layer>=0){
            float trial[12],rr[12];
            for(int i=0;i<12;++i)trial[i]=fminf(upper[i],fmaxf(lower[i],x[i]+edge_alpha*delta[i]));
            trial[edge_layer]=edge_value;phase_evaluate(v,trial,rr,nullptr);
            float event_norm=ca_dot(rr,rr,12);
            if(event_norm<chosen_norm){for(int i=0;i<12;++i)chosen[i]=trial[i];accepted=true;chosen_norm=event_norm;}
        }
'''
candidate = phase.replace(marker, addition + marker)
(out / 'phase-original.cu').write_text(phase)
(out / 'phase-candidate.cu').write_text(candidate)
code = '\n'.join(candidate if name == 'canopy_phase_energy_kernel.cu' else (folder / name).read_text() for name in files)
compiled = {}


def kernel(extended=False, vic=False, stems=False):
    name = 'run_canopy_phase_surface_stems' if stems else ('run_canopy_phase_surface_vic' if vic else ('run_canopy_phase_surface_extended' if extended else 'run_canopy_phase_surface'))
    if name not in compiled:
        compiled[name] = cp.RawModule(code=code, options=('--std=c++14', '--fmad=false', '--prec-div=false', '--prec-sqrt=false'), name_expressions=(name,))
    return compiled[name].get_function(name)



module._kernel = kernel
module.run_canopy_phase_surface_cuda, module.unpack_phase_surface = observe, observe_raw
start, failure = time.monotonic(), None
try:
    engine.step(*before, data['forcing'], environment=data['calendar_values'], calendar=data['calendar_flags'],
                nitrogen_deposition_gn_m2=data['nitrogen'], deposition=data['deposition'],
                most_geometry=data['geometry'], leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']), return_surface=True)
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (out / 'traceback.txt').write_text(traceback.format_exc())
finally:
    module.run_canopy_phase_surface_cuda, module.unpack_phase_surface = original, unpack
xp.cuda.runtime.deviceSynchronize()
unchanged = all(sha(s / n) == v for n, v in m.items())
same = all(np.array_equal(v, engine.host(w)) for v, w in zip(before_host, before))
assert unchanged and same and sha(r / 'input.npz') == binding['input_sha256']
record = dict(scope='Isolated NumPy-edge candidate CUDA3798 read-only rejected-surface capture; original A failure retained. Original production kernel/raw741 and exact rejected surface inputs exported,then identical original failure raised. No source/tolerance/iteration or failed-year advancement; not an accepted model step. NumPy reference work deferred to EHPC PBS. Interpreter shutdown bypass after barrier/durable receipt only.',
              failure=failure, calls=calls, seconds=time.monotonic() - start, source_unchanged=unchanged,
              input_unchanged=same, device_barrier_complete=True, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'),
              input_sha256=sha(r / 'input.npz'), failed_surface_sha256=sha(out / 'failed-surface.npz') if (out / 'failed-surface.npz').exists() else None)
(out / 'receipt.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)
os._exit(0 if captured and failure == 'RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False' else 1)

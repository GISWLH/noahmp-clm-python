from pathlib import Path
import hashlib
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'qia-cuda-3798-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['edge-trial-b', 'phase-stencil-d']:
    d = json.loads((r / name / 'receipt.json').read_text())
    assert d['failure'] == 'RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False'
    assert d['source_unchanged'] and d['input_unchanged'] and d['device_barrier_complete']
c = json.loads((r / 'edge-capture-c/receipt.json').read_text())
assert c['failed_surface_sha256'] == 'ed0f06634389ef2ff5fdcddd82f96cfdc4773fa7735a609193750c499e0a0a91'
d = json.loads((r / 'general-edge-f/receipt.json').read_text())
assert d['failure'] is None and d['result']['fields'] == 361 and d['device_barrier_complete']
assert sha(r / 'general-edge-f/output.npz') == d['result']['output_sha256'] and sha(r / 'general-edge-f/state.npz') == d['result']['state_sha256']
a = b / 'qia3798-candidates-b-f-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():
            t.add(p, arcname=p.name, recursive=False)
    for name in ['edge-trial-b', 'edge-capture-c', 'phase-stencil-d', 'general-edge-f']:
        for p in sorted((r / name).rglob('*')):
            if p.is_file():
                t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    for name in ['probe_qia3798_edge_cuda_b.py', 'launch_qia3798_edge_b.py', 'capture_qia3798_edge_c.py', 'launch_qia3798_edge_capture_c.py',
                 'probe_qia3798_stencil_cuda_d.py', 'launch_qia3798_stencil_d.py', 'probe_qia3798_general_edge_cuda_f.py', 'launch_qia3798_general_edge_f.py', 'export_qia3798_candidates_f.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

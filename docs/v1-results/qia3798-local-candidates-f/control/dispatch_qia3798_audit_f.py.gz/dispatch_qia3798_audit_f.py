from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3798-device-audit-f'; r.mkdir(exist_ok=False)
a = b / 'qia3798-candidates-b-f-evidence.tar.gz'
assert hashlib.sha256(a.read_bytes()).hexdigest() == '73b60e7528d2c1a2ba808aadeddef3b94d9bb4ddeb519568f0f6d3a7a98f795f'
(r / 'device').mkdir()
with tarfile.open(a) as t:
    t.extractall(r / 'device', filter='data')
for name in ['audit_qia3798_cuda_f.py', 'qia3798_cuda_f_audit.pbs']:
    shutil.copyfile(b / name, r / name)
assert b'\r' not in (r / 'qia3798_cuda_f_audit.pbs').read_bytes()
job = subprocess.check_output(['qsub', 'qia3798_cuda_f_audit.pbs'], cwd=r, text=True).strip()
record = dict(pbs_job=job, scope='Original509C independent MHCN/impurity audit only of isolated CUDA F original3798 whole step;not accepted into original failedyear or sameprecision/science pass.', input_archive_sha256=hashlib.sha256(a.read_bytes()).hexdigest())
(r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

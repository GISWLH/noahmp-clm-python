from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name, exitcode in [('qia3798-numpy-f', '0'), ('qia3798-input-readback-d', '1'), ('qia3798-input-readback-e', '0'), ('qia3798-device-audit-f', '0')]:
    assert (b / name / 'pbs-exit.txt').read_text().strip() == exitcode
audit = json.loads((b / 'qia3798-device-audit-f/audit.json').read_text())
assert audit['passed'] and audit['source_unchanged'] and audit['raw_fields'] == 361 and audit['next_state_arrays'] == 19
reference = json.loads((b / 'qia3798-numpy-f/diagnosis.json').read_text())
assert all(row['failure'] is None for row in reference['records']) and reference['records'][0]['result']['iterations'] == 7
candidate = b / 'qia3798-candidates-b-f-evidence.tar.gz'
assert sha(candidate) == '73b60e7528d2c1a2ba808aadeddef3b94d9bb4ddeb519568f0f6d3a7a98f795f'
a = b / 'qia3798-local-candidates-f-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for name in ['qia3798-numpy-f', 'qia3798-input-readback-d', 'qia3798-input-readback-e']:
        root = b / name
        for p in sorted(root.rglob('*')):
            if p.is_file():
                t.add(p, arcname=name + '/' + p.relative_to(root).as_posix(), recursive=False)
    root = b / 'qia3798-device-audit-f'
    for p in sorted(root.iterdir()):
        if p.is_file():
            t.add(p, arcname=root.name + '/' + p.name, recursive=False)
    t.add(candidate, arcname='device-candidates/' + candidate.name, recursive=False)
    for name in ['dispatch_qia3798_audit_f.py', 'archive_qia3798_cpu_candidates_f.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    summary = dict(scope='All isolated original3798 numerical candidates retained. NumPy F PBS248oldwet phase-edge converges7 vs reference50 at original1e-7/80;fullsurface heat3.37482e-8J. CUDA F full361/next19 returnsvalid and PBS251 original independent step/cumulative MHCN/impurity pass,heat4.54107J within original2114.58109J bound. Bfreshonly/Crawexact and Dbranchfinite-difference failures preserved. Original246JSONdisplay failed on prescribedunbounded+inf limits,247explicit-null-index presentation0 preserved,no modelinputs imputed. JAXF pending,not production/canonical/year/science acceptance.',
                   audit_sha256=sha(root / 'audit.json'), numpy_F_sha256=sha(b / 'qia3798-numpy-f/diagnosis.json'), device_candidate_archive_sha256=sha(candidate))
    raw = (json.dumps(summary, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

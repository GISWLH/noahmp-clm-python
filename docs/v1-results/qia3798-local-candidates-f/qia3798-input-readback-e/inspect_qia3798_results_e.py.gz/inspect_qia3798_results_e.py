from pathlib import Path
import json
import os

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3798-input-readback-e'
original = b / 'qia3798-numpy-a'
with np.load(original / 'device/surface-capture-a/failed-surface.npz', allow_pickle=False) as z:
    data = dict(z)
with np.load(original / 'fixed-rejected-boundary-reference.npz', allow_pickle=False) as z:
    reference = dict(z)
raw = data['raw'][0, 441:741]
record = dict(scope='EHPC PBS read-only exact CUDA3798 final rejected raw phase state vs already converged current510 NumPy same fixed boundary. No accepted step/source/gate changes.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              old_mass=data['surface_a8'][0, :, 0].tolist(), old_enthalpy=data['surface_a8'][0, :, 1].tolist(),
              cuda_leaf_temperature=raw[:10].tolist(), cuda_phase_coordinates=raw[275:285].tolist(),
              cuda_layer_residual=raw[55:66].tolist(), cuda_air_water_residual=float(raw[72]),
              cuda_new_mass=raw[195:205].tolist(), cuda_wet_evaporation=raw[30:40].tolist(),
              cuda_iterations=float(raw[67]), cuda_max_solver_residual=float(raw[292]),
              reference_leaf_temperature=reference['leaf_temperature'].tolist(), reference_phase_coordinates=reference['phase_coordinates'].tolist(),
              reference_layer_residual=reference['layer_residual'].tolist(),
              exchange=[float(x) if np.isfinite(x) else None for x in data['surface_a5'][0]], exchange_original_unbounded_positive_infinity_indices=np.flatnonzero(np.isposinf(data['surface_a5'][0])).tolist(), missing_exchange_values_mean='Original prescribed unbounded flux limits only,not imputed finite values or model changes.', surface_fixed_temperature=float(data['raw'][0, 360]))
assert np.all(np.isfinite(data['surface_a5'][0]) | np.isposinf(data['surface_a5'][0]))
assert set(np.flatnonzero(np.isposinf(data['surface_a5'][0]))) <= {16, 17}
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

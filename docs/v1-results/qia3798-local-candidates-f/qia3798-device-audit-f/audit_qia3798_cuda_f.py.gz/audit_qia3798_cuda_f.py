from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3798-device-audit-f'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-most-physical-c-source.tar.gz'
assert sha(a) == 'bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 509 and all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

terminal = b / 'qia-physical-cuda-year-terminal-d-evidence.tar.gz'
assert sha(terminal) == 'bb5ecbd15f68589ee7574d20e6179f4c6f900331229fca7cac3d204a744df70e'
td = Path(os.environ['TMPDIR']) / 'original-terminal'; td.mkdir()
with tarfile.open(terminal) as t:
    t.extractall(td, filter='data')
report = json.loads((td / 'trajectory/batch.json').read_text())
assert report['status'] == 'failed' and report['steps_completed'] == 3798
checkpoint = td / 'trajectory' / report['checkpoint_file']
assert sha(checkpoint) == report['checkpoint_sha256']
with np.load(checkpoint, allow_pickle=False) as z:
    saved = dict(z)
device = r / 'device'
binding = json.loads((device / 'binding.json').read_text())
receipt = json.loads((device / 'general-edge-f/receipt.json').read_text())
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
assert binding['original_checkpoint_sha256'] == report['checkpoint_sha256'] and sha(device / 'input.npz') == binding['input_sha256']
with np.load(device / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
before = tuple(data['a' + str(k)] for k in range(19))
for k in range(19):
    np.testing.assert_array_equal(before[k], saved['a' + str(k)])
assert sha(device / 'general-edge-f/output.npz') == receipt['result']['output_sha256']
assert sha(device / 'general-edge-f/state.npz') == receipt['result']['state_sha256']
with np.load(device / 'general-edge-f/output.npz', allow_pickle=False) as z:
    flat = dict(z)
with np.load(device / 'general-edge-f/state.npz', allow_pickle=False) as z:
    after = tuple(z['a' + str(k)] for k in range(19))
out = {}
for name, value in flat.items():
    parts = name.split('/'); target = out
    for part in parts[:-1]:
        target = target.setdefault(part, {})
    target[parts[-1]] = value
incoming, residual, bound, tracer = driver.audit_step(before, after, data['forcing'], data['deposition'], data['nitrogen'], out)
cumulative = driver.totals(after) - saved['initial'] - (saved['net'] + incoming)
cbound = saved['bounds'] + bound
assert np.all(abs(cumulative) <= cbound)
record = dict(scope='EHPC PBS original509C independent unchanged production MHCN/impurity audit of isolated all-phase-edge CUDA F whole3798 step361raw/19next arrays. Exact originalfailed19state/initial/ledger verified. All original step/cumulative bounds required;not accepted into failedyear,not JAX parity/fullcanonical/NumPy-whole-step/science acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True,
              step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(),
              cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=cbound.tolist(), impurity_residual=tracer.tolist(),
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == h for n, h in m.items()),
              original_checkpoint_sha256=report['checkpoint_sha256'], candidate_receipt_sha256=sha(device / 'general-edge-f/receipt.json'),
              raw_fields=len(flat), next_state_arrays=19)
(r / 'audit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

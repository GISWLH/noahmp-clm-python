from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile
import time
import traceback

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3798-numpy-f'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-fresh-phase-edge-a-source.tar.gz'
assert sha(a) == '04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'tests'), str(s / 'benchmarks')]
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack, TF, LF, CW
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.gpu.canopy_phase_energy import unpack_phase

import inspect
import noahmp_clm.physics.canopy_phase_energy as phase_module
original_solver = phase_module.solve_canopy_phase_energy
original_solver_source = inspect.getsource(original_solver)
marker = 'if phase_active[k] and mass[k]==0. and delta[k]!=0.:'
assert original_solver_source.count(marker) == 1
candidate_solver_source = original_solver_source.replace(marker, 'if phase_active[k] and delta[k]!=0.:')
namespace = dict(original_solver.__globals__)
exec(compile(candidate_solver_source, '<isolated general-phase-edge hypothesis F>', 'exec'), namespace)
solve_canopy_phase_energy = namespace['solve_canopy_phase_energy']
phase_module.solve_canopy_phase_energy = solve_canopy_phase_energy
(r / 'solver-original.py').write_text(original_solver_source)
(r / 'solver-candidate.py').write_text(candidate_solver_source)

device = r / 'device'
binding = json.loads((device / 'binding.json').read_text())
cap = json.loads((device / 'surface-capture-a/receipt.json').read_text())
path = device / 'surface-capture-a/failed-surface.npz'
assert sha(path) == cap['failed_surface_sha256']
with np.load(path, allow_pickle=False) as z:
    packet = dict(z)
c, g, p, o, leaf, u, factors, v, cond = [np.asarray(packet['surface_a' + str(k)][0], float) for k in range(9)]
n = int(o[0]); dt = v[0]
snow = Snowpack(c[:n, 0], c[:n, 1], c[:n, 2], c[:n, 3], c[:n, 4:])
props = SoilParams(smcmax=p[0], bexp=p[1], smcref=p[2], satdk=p[3], quartz=p[4], smcwlt=p[5], saturated_suction_m=p[6])
soil = SoilEnthalpyState(g[:, 0], g[:, 1], g[:, 2], props, int(o[1]))
water = CanopyCondensate(cond[:, 0], cond[:, 1])
extra = packet['exchange_extension'][0]
exchange = CanopyExchange(*u[:11], atmosphere_water_velocity=extra[0], potential_temperature=extra[1])
parameters = LeafParameters(**json.loads((device / 'surface-capture-a/leaf-parameters.json').read_text()))
kwargs = dict(stem_area=packet['stem_area'][0], vegetated_fraction=u[13], transpiration_limit=u[16],
              ground_emissivity=u[18], ground_albedo=u[19:21], diffuse_fraction=u[21], cosine_zenith=u[22],
              nitrogen_factor=factors[:, 0], water_stress=factors[:, 1], leaf_parameters=parameters)
raw = packet['raw']; got = unpack_phase(raw[:, 441:741])
supply = SoilWaterSupply(np.maximum(soil.liquid - props.smcwlt * 1000. * soil.dz, 0.) / dt, v[3:], soil.liquid[0] / dt)
fixed = float(raw[0, 360])
records = []
for label in ['fixed-rejected-boundary', 'whole-surface']:
    start = time.monotonic(); failure = None; result = None
    try:
        if label == 'fixed-rejected-boundary':
            out = solve_canopy_phase_energy(leaf, u[11], u[12], exchange, water, dt,
                  soil_supply=supply, root_enthalpy=LF + CW * (soil.temperature - TF),
                  ground_evaporation_limit=snow.mass[0] / dt if n else np.inf,
                  fixed_ground_temperature=fixed, ground_is_ice=bool(fixed < TF), ground_shares_soil=not n,
                  snowpack=snow, tolerance=1e-7, max_iterations=80, **kwargs)
            result = {name: np.asarray(out[name]).tolist() for name in ['leaf_temperature', 'ground_temperature', 'canopy_humidity', 'h', 'le', 'gpp', 'iterations', 'max_solver_residual'] if name in out}
        else:
            new_snow, new_soil, _, out = surface_step(snow, soil, dt, leaf, u[11], u[12], exchange,
                  canopy_condensate=water, root_weights=v[3:], **kwargs)
            result = {name: np.asarray(out[name]).tolist() for name in ['leaf_temperature', 'ground_temperature', 'h', 'le', 'gpp', 'iterations', 'energy_residual_jm2', 'mass_residual_kgm2'] if name in out}
            result.update(soil_temperature=new_soil.temperature.tolist(), snow_mass=new_snow.mass.tolist())
        np.savez_compressed(r / (label + '-reference.npz'), **{k: np.asarray(x) for k, x in out.items() if isinstance(x, (float, int, np.ndarray))})
    except Exception as e:
        failure = type(e).__name__ + ': ' + str(e)
        (r / (label + '-traceback.txt')).write_text(traceback.format_exc())
    records.append(dict(label=label, failure=failure, result=result, seconds=time.monotonic() - start))
record = dict(scope='EHPC PBS isolated NumPy general-phase-edge numerical hypothesis F of exact original CUDA3798 boundary. Existing wet parcels may also try the first exact phase edge along the same Newton direction iff complete coupled residual strictly decreases; old stores/equations/1e-7/80 unchanged. Original reference A retained,no production change. Original fixed-ground1e-7/80 and whole-surface controls preserved,all outcomes retained. No new accepted annual step,source/gate modification or scientific pass; discrepancies in arithmetic precision/background remain explicit.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, binding=binding, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'),
              source_unchanged=all(sha(s / k) == h for k, h in m.items()), original_surface_sha256=sha(path), fixed_ground_temperature=fixed,
              original_cuda_max_solver_residual=float(got['max_solver_residual'][0]), original_cuda_iterations=int(got['iterations'][0]),
              old_canopy_mass=water.mass.tolist(), old_canopy_enthalpy=water.enthalpy.tolist(), records=records)
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

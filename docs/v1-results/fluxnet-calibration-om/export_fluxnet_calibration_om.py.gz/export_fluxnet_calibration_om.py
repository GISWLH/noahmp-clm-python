"""Read-only closed OM1596 export; no model, queue mutation or active-tree edits."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import re
import shlex
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-fluxnet-calibration-om')
EXPORT = Path('/tmp/noahmp-fluxnet-calibration-om-export')
assert socket.gethostname() == 'manager' and not EXPORT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dispatch = json.loads((ROOT / 'dispatch.json').read_bytes())
assert dispatch['pbs_job'] == '1596.manager'
result = subprocess.run(['qstat', '-xf', dispatch['pbs_job']], capture_output=True, text=True)
assert result.returncode == 0, result.stderr
assert re.search(r'^\s*job_state = F\s*$', result.stdout, re.M), 'Wait for actual F, not E'
actual_exit = int(re.search(r'^\s*Exit_status = (\d+)\s*$', result.stdout, re.M).group(1))
EXPORT.mkdir()
(EXPORT / 'actual-pbs-qstat.txt').write_text(result.stdout)
(EXPORT / 'actual-pbs-qstat.stderr.txt').write_text(result.stderr)
for name in ['result.tar.gz', 'pbs-exit.txt']:
    subprocess.run(['scp', 'compute002:' + str(ROOT / name), str(EXPORT / name)], check=True)
remote = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', str(ROOT / 'result.tar.gz'), str(ROOT / 'pbs-exit.txt')])],
                        capture_output=True, text=True)
assert remote.returncode == 0, remote.stderr
(EXPORT / 'compute-original-hashes.txt').write_text(remote.stdout)
remote_hashes = {line.split()[1]: line.split()[0] for line in remote.stdout.splitlines()}
assert all(remote_hashes[str(ROOT / name)] == sha((EXPORT / name).read_bytes()) for name in ['result.tar.gz', 'pbs-exit.txt'])
files = {name: (EXPORT / name).read_bytes() for name in
         ['actual-pbs-qstat.txt', 'actual-pbs-qstat.stderr.txt', 'result.tar.gz', 'pbs-exit.txt', 'compute-original-hashes.txt']}
with tarfile.open(EXPORT / 'result.tar.gz') as archive:
    for member in archive:
        assert member.isfile() or member.isdir()
        if not member.isfile():
            continue
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        name = 'result/' + str(path)
        assert name not in files
        files[name] = archive.extractfile(member).read()
for name in ['dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'compute-extract.stdout.txt',
             'compute-extract.stderr.txt', 'compute-file-hashes.txt', 'stage-inventory.json', 'independent-review.json',
             ]:
    files['manager/' + name] = (ROOT / name).read_bytes()
pbs_output = ROOT / 'pbs-output.log'
if pbs_output.is_file():
    files['manager/pbs-output.log'] = pbs_output.read_bytes()
files['manager/pbs-output-presence.json'] = (json.dumps(dict(
    path=str(pbs_output), present=pbs_output.is_file(),
    note='PBS wrapper redirected its worker stdout/stderr into result/controller.log. '
         'A missing optional scheduler output file is recorded as missing, not fabricated empty.'), indent=2) + '\n').encode()
worker = json.loads(files['result/receipt.json'])
assert int(files['result/worker-exit.txt'].strip()) == actual_exit
assert int(files['pbs-exit.txt'].strip()) == actual_exit
assert worker['pbs_job'] == '1596.manager' and worker['forward_model_runs'] == 0
if actual_exit == 0:
    assert worker['passed'] and worker['unittest_parent_returncode'] == 0
    assert worker['actual_unittest_count'] == 15 and worker['generated_candidates'] == 23
    assert worker['original_training_initialization_cases'] == 8 and worker['metadata_configuration_applications'] == 184
    index = json.loads(files['result/applied-index.json'])
    assert len(index) == 184
    for row in index:
        assert sha(files['result/' + row['config']]) == row['output_sha256']
        sidecar = json.loads(files['result/' + row['receipt']])
        assert sidecar['output_config_sha256'] == row['output_sha256']
    assert sum(name.startswith('result/applied/') and name.endswith('-receipt.json') for name in files) == 184
    assert sum(name.startswith('result/applied/') and not name.endswith('-receipt.json') for name in files) == 184
files['export_fluxnet_calibration_om.py'] = Path(__file__).read_bytes()
inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = EXPORT / 'closed-export.tar.gz'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive}
assert restored == files
record = dict(archive_sha256=sha(target.read_bytes()), bytes=target.stat().st_size, artifacts=len(files),
              actual_job=dispatch['pbs_job'], actual_state='F', actual_exit=actual_exit,
              result_archive_sha256=sha(files['result.tar.gz']), receipt=worker, every_exported_byte_reverified=True,
              scope='Closed metadata-only job export. No physical model/calibration or own-parameter spinup claim.')
(EXPORT / 'closed-export-package.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

三个维度可以通过现有配置和多后端入口做有限校准；没有发现字段失效、单位错接或需要先改生产代码的阻断。它们是当前简化模型中的参数，不代表已经复现 Post et al. 的完整 CLM 参数作用范围，也不保证科学指标通过。本审阅仅读源码与原 Cng/Qia 配置 JSON；未读 Cha/HaM 预测，未加载物理数组或运行模型。

|维度|准确 JSON 路径|当前默认 / 拟定范围|本项目语义及打包位置|
|---|---|---|---|
|Ball–Berry 斜率|`leaf_parameters.ball_berry_slope`|9 / 5–12|无量纲；`x=b_s*max(A_net,0)/c_s`，通过叶面湿度反馈二次式求水汽气孔导度。`LeafParameters` 第6索引，JAX和CUDA均读`p[6]`。不是Medlyn的`g1`。|
|维持呼吸基础系数|`biogeochemistry.plant_parameters.maintenance_base`|2.525e-6 / 1.5e-6–4.5e-6|gC/(gN·s)，根与活茎参考293.15 K。`pack_plant`参数索引13；Q10索引14，活茎N比例索引15。|
|共享Q10|同时写`biogeochemistry.plant_parameters.maintenance_q10`和`biogeochemistry.decomposition_parameters.q10`|两者1.5 / 1.1–3|无量纲10 K倍率；植物参数索引14、分解参数索引12。**代码不自动绑定这两个字段**，协议必须同时赋同一候选值。|

本项目根/茎维持呼吸需求为：`R_stem=N_stem*f_live*maintenance_base*dt*Q10^((T_air-293.15)/10)`；`R_root=N_root*maintenance_base*dt*Σ(root_fraction_i*Q10^((T_soil_i-293.15)/10))`。N库存为gN/m²，dt为秒，因此输出为gC/m²/步。NumPy把根加权Q10映射成等效温度后传入分配函数；原生JAX/CUDA路径执行同一映射。293.15 K和上述单位由本项目代码及已有组件文档证明，不归因于Post表格。

土壤分解采用`temperature_factor=Q10^((T_topsoil-reference_temperature)/10)`，默认`reference_temperature=298.15 K`，另乘水分/氧限制，再作用于七库指数衰减。共享Q10仅共享温度敏感性倍率，**必须保留分解298.15 K与根/茎293.15 K两套基准**；把分解参考温度改到293.15 K会同时改变基准周转速率，不属于这三个维度。`pack_decomposition`的Q10/参考温度分别是索引12/13，JAX及CUDA均按此读取。

入口已静态对齐：`run_fluxnet_column.build_state`按上述嵌套JSON构造`PlantParameters`/`DecompositionParameters`；NumPy整柱直接调用对应方程。`run_fluxnet_native`经`pack_station_arrays → pack_clm_bgc_columns`携带每柱植物/分解参数，`Backend.step`分派JAX/CUDA；叶参数另由同一JSON传给冠层求解。即使启用容量剖面，其覆盖的列为0/1/2/3/8，保留Ball–Berry索引6，斜率不会被容量剖面静默重置。拟定范围全部在现有验证器定义域内，但5–12等更窄校准边界仍须由协议显式实施。

需要保留的科学边界：

- `maintenance_base`和`maintenance_q10`直接控制根/活茎，**不直接控制叶暗呼吸**。叶暗呼吸来自`respiration25`及298.15 K参考的峰形Arrhenius函数，计入植物支付需求一次。不要把此三参数方案描述成改变全部植物组织的统一呼吸方程。
- 实际维持呼吸受`reserve_carbon + GPP`供给上限约束；未满足需求独立记录。土壤分解还受水势、冻结、氧及氮竞争约束。资源受限时改变基础系数或Q10未必同比改变实际RA/RH，不能预设参数可辨识或目标必达。
- 本项目分解是顶层气候驱动的柱聚合七库，既有文档明确没有CLM原版Century温度归一化/垂向C-N结构。文献区间可作为有限候选范围，不能当成该简化结构与原CLM输出同义的证明。
- 无活叶或净同化非正时，Ball–Berry斜率项为零；固定PFT/叶面积季节性、SAI、根系及水文结构不在这三维内。参数搜索不能自动修复这些结构差异；此处没有新增对偏差根因的判断。
- 参数改变后必须为新候选重新构造/打包参数并绑定新配置身份。现有续跑会核对配置/源/forcing身份，不能改原NS/NZ或直接把旧参数检查点当新候选继续。根/茎与分解Q10不得只改一侧，土壤参考温度、周转时间、叶Rd及其他参数保持协议冻结。

只读配置证据：原`multisite-climatology-jr-inputs.tar.gz`内Cng2007与Qia2003共8个配置，均为斜率9、基础系数2.525e-6、双Q10=1.5、分解参考298.15 K；`OptStomataResistance=1`、`OptWetlandModel=0`。此处未检查后续2008/2004新训练输入，也未读取留出预测。

源码定位：`physics/photosynthesis.py:25,136`；`physics/plant_cn.py:22,153`；`physics/biogeochemistry.py:39`；`physics/decomposition.py:24,68`；`gpu/photosynthesis.py:17,92`；`gpu/plant_cn.py:18,99`；`gpu/decomposition.py:13,41`；`gpu/clm_bgc_column.py:36,195`；`gpu/cuda/leaf_kernel.cu:35`；`gpu/cuda/plant_cn_kernel.cu:32`；`gpu/cuda/decomposition_kernel.cu:7`；`benchmarks/run_fluxnet_column.py:175`；`benchmarks/run_fluxnet_native.py:70,235,369,486`。路径均相对仓库根，文件摘要另见同名前缀JSON。

范围出处采用root已实际读取的[Post et al. (2017), Table1与§3.2](https://agupubs.onlinelibrary.wiley.com/doi/10.1002/2015JG003297)：Ball–Berry5–12、mr_b1.5e-6–4.5e-6、共享Q10 1.1–3。论文表中单位未由本次读取另行确认；代码2.525e-6默认与论文表2.53e-6的显示精度差异无需擅自修改。没有引用CLM5 Medlyn范围。训练/留出划分按root计划固定为Cng07–08/Qia03–04训练、Cha/HaM留出；本审阅不改变划分、QC或观测。

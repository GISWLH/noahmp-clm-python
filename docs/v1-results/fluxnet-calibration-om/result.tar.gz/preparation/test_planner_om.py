"""Metadata-only unittest cases; execute on EHPC, never import model/arrays."""
import copy
import json
from pathlib import Path
import unittest

import planner_om as p


def fitting():
    originals = p.strict_json((Path(__file__).parent / 'SOURCE_BINDINGS.json').read_bytes())['multiyear_site_inputs']
    return [dict(site=site, year=year, role=role,
                 input_sha256=originals[site]['input_sha256'], metadata_sha256=originals[site]['metadata_sha256'])
            for site, years in p.ROLES.items() for year, role in years.items() if role == 'training']


class CandidateTests(unittest.TestCase):
    def test_baseline_and_six_single_dimension_endpoints(self):
        rows = p.first_batch()
        self.assertEqual(len(rows), 7)
        self.assertEqual(rows[0]['values'], {'b_s': 9.0, 'mr_b': 2.525e-6, 'q10': 1.5})
        actual = set()
        for row in rows[1:]:
            changed = [dim for dim in p.DIMS if row['values'][dim] != rows[0]['values'][dim]]
            self.assertEqual(len(changed), 1)
            dim = changed[0]
            actual.add((dim, row['values'][dim]))
            self.assertEqual(p.validate_candidate(row), row)
        self.assertEqual(actual, {(dim, endpoint) for dim in p.DIMS for endpoint in p.BOUNDS[dim][:2]})

    def test_joint_lhs_centres_cover_each_stratum_once(self):
        rows = p.second_batch(['q10', 'b_s', 'mr_b'])
        self.assertEqual(rows, p.second_batch(['b_s', 'mr_b', 'q10']))
        self.assertEqual(len(rows), 16)
        for dim in p.DIMS:
            self.assertEqual(sorted(row['strata'][dim] for row in rows), list(range(16)))
            low, high, _ = p.BOUNDS[dim]
            for row in rows:
                value = row['values'][dim]
                self.assertGreater(value, low)
                self.assertLess(value, high)
                self.assertEqual(value, low + (high - low) * ((row['strata'][dim] + 0.5) / 16))
        for row in rows:
            self.assertEqual(p.validate_candidate(row), row)
        self.assertEqual(len({p.canonical(row['values']) for row in rows}), 16)

    def test_inactive_dimensions_remain_baseline_without_claiming_sensitivity(self):
        for row in p.second_batch(['mr_b'], count=7):
            self.assertEqual(row['values']['b_s'], 9.0)
            self.assertEqual(row['values']['q10'], 1.5)
            self.assertEqual(row['active_dims'], ['mr_b'])
        self.assertEqual(p.second_batch([]), [])

    def test_batch_budget_and_dimensions_reject_coercions(self):
        for count in [0, 17, -1, True, 16.0, '16', None]:
            with self.subTest(count=count), self.assertRaises(ValueError):
                p.second_batch(['b_s'], count)
        for dims in ['b_s', None, ['b_s', 'b_s'], ['not_a_parameter'], [True]]:
            with self.subTest(dims=dims), self.assertRaises(ValueError):
                p.second_batch(dims)

    def test_tampered_candidate_grid_seed_types_bounds_and_extra_keys_rejected(self):
        for dim in p.DIMS:
            for value in [True, False, '1.5', float('nan'), float('inf'), -float('inf'), 0, 100]:
                row = p.first_batch()[0]
                row['values'][dim] = value
                with self.subTest(dim=dim, value=value), self.assertRaises(ValueError):
                    p.validate_candidate(row)
        row = p.second_batch(['q10'])[0]
        row['seed'] += 1
        with self.assertRaises(ValueError):
            p.validate_candidate(row)
        for change in [('extra', 'hidden override'), ('id', 'om-lhs-99')]:
            row = p.second_batch(['b_s'])[0]
            row[change[0]] = change[1]
            with self.assertRaises(ValueError):
                p.validate_candidate(row)
        row = p.second_batch(['b_s'])[0]
        row['values']['b_s'] += 0.001
        with self.assertRaises(ValueError):
            p.validate_candidate(row)

    def test_plan_budget_source_identity_and_no_automatic_execution(self):
        plan = p.plan(list(p.DIMS), fitting())
        self.assertEqual(plan['candidate_count'], 23)
        self.assertEqual(plan['candidate_budget'], 23)
        self.assertFalse(plan['model_execution'])
        self.assertFalse(plan['calibrated'])
        self.assertIsNone(plan['objective'])
        self.assertIsNone(plan['scoring'])
        self.assertEqual(plan['preparation']['model_source_manifest_sha256'],
                         'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f')
        self.assertEqual(p.plan([], fitting())['candidate_count'], 7)
        for index in range(4):
            omitted = fitting()
            del omitted[index]
            with self.subTest(omitted=index), self.assertRaises(ValueError):
                p.plan(list(p.DIMS), omitted)


class RoleTests(unittest.TestCase):
    def test_exact_original_17_plus_7_roles(self):
        roles = [role for years in p.ROLES.values() for role in years.values()]
        self.assertEqual(len(roles), 24)
        self.assertEqual(roles.count('training'), 4)
        self.assertEqual(roles.count('initialization-only'), 1)
        self.assertEqual(sum('holdout' in role or role == 'independent-evaluation' for role in roles), 12)
        self.assertEqual(roles.count('spinup-forcing-only-no-observation-fitting'), 7)
        self.assertEqual(len(p.validate_fit_inputs(fitting())), 4)

    def test_every_nontraining_original_year_is_rejected_for_fitting(self):
        for site, years in p.ROLES.items():
            for year, role in years.items():
                if role == 'training':
                    continue
                row = dict(site=site, year=year, role=role, input_sha256='a' * 64, metadata_sha256='b' * 64)
                with self.subTest(site=site, year=year), self.assertRaises(ValueError):
                    p.validate_fit_inputs([row])
                row['role'] = 'training'
                with self.subTest(forged_site=site, year=year), self.assertRaises(ValueError):
                    p.validate_fit_inputs([row])

    def test_unknown_coerced_duplicate_and_unbound_fit_inputs_fail(self):
        for field, value in [('year', 2007.0), ('year', True), ('year', '2007'), ('year', 2006),
                             ('site', 'CN-other'), ('role', None), ('input_sha256', 'unbound')]:
            row = fitting()[0]
            row[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                p.validate_fit_inputs([row])
        with self.assertRaises(ValueError):
            p.validate_fit_inputs([fitting()[0], fitting()[0]])
        with self.assertRaises(ValueError):
            p.validate_fit_inputs([])


class ConfigurationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (Path(__file__).parent / 'original-cng-config.json').read_bytes()
        cls.config = p.strict_json(cls.raw)
        cls.original_sha = p.sha(cls.raw)

    def test_real_original_config_and_full_candidate_whitelist(self):
        binding = p.strict_json((Path(__file__).parent / 'SOURCE_BINDINGS.json').read_bytes())
        self.assertEqual(self.original_sha, binding['test_configuration']['sha256'])
        unchanged = p.canonical(self.config)
        for candidate in p.first_batch() + p.second_batch(list(p.DIMS)):
            out, receipt = p.apply_candidate(self.raw, candidate, self.original_sha)
            result = p.strict_json(out)
            self.assertEqual(p.canonical(self.config), unchanged)
            self.assertEqual(receipt['original_config_sha256'], self.original_sha)
            self.assertEqual(receipt['output_config_sha256'], p.sha(out))
            self.assertEqual(receipt['candidate_sha256'], p.sha(p.canonical(candidate)))
            self.assertFalse(receipt['spun_up'])
            self.assertEqual(result['biogeochemistry']['plant_state'], self.config['biogeochemistry']['plant_state'])
            self.assertEqual(result['biogeochemistry']['soil_state'], self.config['biogeochemistry']['soil_state'])
            self.assertEqual(result['leaf_parameters']['respiration25'], self.config['leaf_parameters']['respiration25'])
            self.assertEqual(result['biogeochemistry']['decomposition_parameters']['reference_temperature'], 298.15)
            self.assertEqual(result['column'], self.config['column'])
            self.assertEqual(result['most_geometry'], self.config['most_geometry'])
            for change in receipt['changes']:
                self.assertIn(tuple(change['path']), {path for paths in p.PATHS.values() for path in paths})

    def test_shared_q10_updates_both_and_no_other_parameters(self):
        candidate = next(row for row in p.first_batch() if row['id'] == 'om-oat-q10-high')
        out, receipt = p.apply_candidate(self.raw, candidate, self.original_sha)
        config = p.strict_json(out)
        self.assertEqual(config['biogeochemistry']['plant_parameters']['maintenance_q10'], 3.0)
        self.assertEqual(config['biogeochemistry']['decomposition_parameters']['q10'], 3.0)
        self.assertEqual(len(receipt['changes']), 2)

    def test_one_candidate_for_all_cases_no_site_override_or_alias(self):
        candidate = p.second_batch(list(p.DIMS))[0]
        records = [dict(case=self.config['case'], config_bytes=self.raw, sha256=self.original_sha)]
        results = p.apply_shared_configurations(records, candidate)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['receipt']['candidate_sha256'], p.sha(p.canonical(candidate)))
        self.assertEqual(results[0]['case'], self.config['case'])
        altered = copy.deepcopy(records)
        altered[0]['case'] = 'CN-Qia-forged-alias'
        with self.assertRaises(ValueError):
            p.apply_shared_configurations(altered, candidate)
        altered = copy.deepcopy(records)
        altered[0]['values'] = p.baseline()
        with self.assertRaises(ValueError):
            p.apply_shared_configurations(altered, candidate)
        with self.assertRaises(ValueError):
            p.apply_shared_configurations([records[0], records[0]], candidate)

    def test_state_forcing_switch_height_time_and_signedzero_mutations_rejected(self):
        candidate = p.first_batch()[0]
        mutations = [
            ('state', lambda c: c['biogeochemistry']['plant_state']['carbon'].__setitem__(0, 999.0)),
            ('soil', lambda c: c['column']['soil'].__setitem__('smcmax', 0.99)),
            ('switch', lambda c: c['column']['options'].__setitem__('OptDynamicVeg', 1)),
            ('height', lambda c: c['most_geometry'].__setitem__('wind_height', 1.0)),
            ('forcing', lambda c: c.__setitem__('forcing', 'replacement')),
            ('time', lambda c: c.__setitem__('year', 2008)),
            ('QC', lambda c: c.__setitem__('qc', 'masked')),
            ('leafRd', lambda c: c['leaf_parameters'].__setitem__('respiration25', 2.0)),
            ('referenceT', lambda c: c['biogeochemistry']['decomposition_parameters'].__setitem__('reference_temperature', 293.15)),
            ('zero-sign', lambda c: c['column'].__setitem__('canw', -0.0)),
        ]
        for name, mutate in mutations:
            altered = copy.deepcopy(self.config)
            mutate(altered)
            with self.subTest(name=name), self.assertRaises(ValueError):
                p.verify_changes(self.config, altered, candidate)

    def test_hash_missing_parameter_nonbaseline_and_numeric_bool_fail_closed(self):
        with self.assertRaises(ValueError):
            p.apply_candidate(self.raw, p.first_batch()[0], '0' * 64)
        changed_state = copy.deepcopy(self.config)
        changed_state['biogeochemistry']['plant_state']['carbon'][0] += 1.0
        raw = p.canonical(changed_state)
        with self.assertRaisesRegex(ValueError, 'registered original JR'):
            p.apply_candidate(raw, p.first_batch()[0], p.sha(raw))
        for change in ['missing', 'nonbaseline', 'boolean', 'nan']:
            config = copy.deepcopy(self.config)
            if change == 'missing':
                del config['leaf_parameters']['ball_berry_slope']
            elif change == 'nonbaseline':
                config['leaf_parameters']['ball_berry_slope'] = 5.0
            elif change == 'boolean':
                config['biogeochemistry']['plant_parameters']['maintenance_base'] = True
            else:
                config['column']['smc'][0] = float('nan')
            raw = json.dumps(config).encode()
            with self.subTest(change=change), self.assertRaises(ValueError):
                p.apply_candidate(raw, p.first_batch()[0], p.sha(raw))

    def test_strict_json_duplicate_and_nonfinite_values_are_not_masked(self):
        for raw in [b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}', b'{"x":1e999}']:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                p.strict_json(raw)
        self.assertNotEqual(p.canonical({'x': True}), p.canonical({'x': 1.0}))
        self.assertNotEqual(p.canonical({'x': 1}), p.canonical({'x': 1.0}))


if __name__ == '__main__':
    unittest.main()

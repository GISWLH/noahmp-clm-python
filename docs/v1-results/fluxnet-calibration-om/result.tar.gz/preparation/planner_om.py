"""Finite, shared-parameter metadata planner. No model, scoring or state reuse."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
DIMS = ('b_s', 'mr_b', 'q10')
SEED = 20261025
MAX_SECOND_BATCH = 16
PATHS = {
    'b_s': (('leaf_parameters', 'ball_berry_slope'),),
    'mr_b': (('biogeochemistry', 'plant_parameters', 'maintenance_base'),),
    'q10': (('biogeochemistry', 'plant_parameters', 'maintenance_q10'),
            ('biogeochemistry', 'decomposition_parameters', 'q10')),
}
BOUNDS = {'b_s': (5.0, 12.0, 9.0), 'mr_b': (1.5e-6, 4.5e-6, 2.525e-6),
          'q10': (1.1, 3.0, 1.5)}
ROLES = {
    'CN-Cng': {2007: 'training', 2008: 'training', 2009: 'temporal-holdout', 2010: 'temporal-holdout'},
    'CN-Qia': {2003: 'training', 2004: 'training', 2005: 'temporal-holdout'},
    'CN-Cha': {2003: 'initialization-only', 2004: 'site-holdout', 2005: 'site-holdout'},
    'CN-HaM': {**{year: 'spinup-forcing-only-no-observation-fitting' for year in range(2001, 2008)},
               **{year: 'independent-evaluation' for year in range(2008, 2015)}},
}


def sha(raw):
    if type(raw) is not bytes:
        raise TypeError('Hash input must be original bytes')
    return hashlib.sha256(raw).hexdigest()


def _json_value(value):
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    if type(value) is list:
        for item in value:
            _json_value(item)
        return
    if type(value) is dict and all(type(key) is str for key in value):
        for item in value.values():
            _json_value(item)
        return
    raise ValueError('Only finite JSON primitives are permitted; no coercion')


def canonical(value):
    _json_value(value)
    return json.dumps(value, allow_nan=False, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False).encode('utf-8')


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def _constant(value):
    raise ValueError('Nonfinite JSON constant: ' + value)


def strict_json(raw):
    if type(raw) is not bytes:
        raise TypeError('Read original bytes, not a coerced object')
    result = json.loads(raw.decode('utf-8'), object_pairs_hook=_pairs, parse_constant=_constant)
    _json_value(result)
    return result


def _digest(value):
    if type(value) is not str or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
        raise ValueError('Expected a lowercase SHA256')
    return value


def _number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError('Expected a finite real JSON number; bool/string are not numbers')
    return value


def _dims(active_dims):
    if type(active_dims) not in (list, tuple) or any(type(d) is not str for d in active_dims):
        raise ValueError('active_dims must be an explicit list/tuple')
    if len(active_dims) != len(set(active_dims)) or not set(active_dims) <= set(DIMS):
        raise ValueError('Unknown or repeated dimension')
    return [d for d in DIMS if d in active_dims]


def baseline():
    return {dim: BOUNDS[dim][2] for dim in DIMS}


def preparation_identity():
    """Bind every preparation byte and original source/input archive identity."""
    manifest_raw = (HERE / 'CONTROLS_SHA256.json').read_bytes()
    manifest = strict_json(manifest_raw)
    if type(manifest) is not dict or not manifest:
        raise ValueError('Missing preparation manifest')
    for name, expected in manifest.items():
        if type(name) is not str or Path(name).name != name or '\\' in name:
            raise ValueError('Only preparation-local manifest names are allowed')
        if sha((HERE / name).read_bytes()) != _digest(expected):
            raise ValueError('Preparation byte mismatch: ' + name)
    required = {'planner_om.py', 'PARAMETER_SPEC.json', 'SOURCE_BINDINGS.json'}
    if not required <= set(manifest):
        raise ValueError('Preparation identity is incomplete')
    spec = strict_json((HERE / 'PARAMETER_SPEC.json').read_bytes())
    for dim in DIMS:
        actual = spec['dimensions'][dim]
        if actual['bounds'] != list(BOUNDS[dim][:2]) or actual['baseline'] != BOUNDS[dim][2]:
            raise ValueError('Parameter specification diverges from planner')
        if actual['configuration_paths'] != [list(path) for path in PATHS[dim]]:
            raise ValueError('Parameter mapping diverges from planner')
    sources = strict_json((HERE / 'SOURCE_BINDINGS.json').read_bytes())
    if sources['locked_roles'] != {site: {str(year): role for year, role in years.items()}
                                   for site, years in ROLES.items()}:
        raise ValueError('Locked source role declaration diverges from planner')
    return dict(preparation_manifest_sha256=sha(manifest_raw),
                planner_sha256=manifest['planner_om.py'], parameter_spec_sha256=manifest['PARAMETER_SPEC.json'],
                source_bindings_sha256=manifest['SOURCE_BINDINGS.json'],
                model_source_archive_sha256=sources['model_source_archive']['sha256'],
                model_source_manifest_sha256=sources['model_source_archive']['manifest_sha256'],
                original_inputs_archive_sha256=sources['original_inputs_archive']['sha256'],
                locked_roles_source_sha256=sources['locked_roles_source']['sha256'])


def first_batch():
    """Exactly one baseline and six one-at-a-time endpoints, in fixed order."""
    rows = [dict(id='om-baseline', stage='baseline', active_dims=[], values=baseline())]
    for dim in DIMS:
        for endpoint, index in [('low', 0), ('high', 1)]:
            values = baseline()
            values[dim] = BOUNDS[dim][index]
            rows.append(dict(id='om-oat-' + dim + '-' + endpoint, stage='oat',
                             active_dims=[dim], values=values))
    return rows


def second_batch(active_dims, count=16):
    """A single deterministic LHS batch, not an adaptive extension API.

    Each dimension uses all count equal-width stratum centres once. Independent
    SHA256 ordering binds permutations to the fixed seed and dimension name;
    no Python PRNG version, observation value or score enters the construction.
    Inactive dimensions retain baseline. An explicit empty set produces no rows.
    """
    dims = _dims(active_dims)
    if type(count) is not int or not 1 <= count <= MAX_SECOND_BATCH:
        raise ValueError('Second batch count must be an integer in [1,16]')
    if not dims:
        return []
    permutations = {
        dim: sorted(range(count), key=lambda k: (
            sha(f'OM|{SEED}|{dim}|{count}|{k}'.encode('ascii')), k)) for dim in dims
    }
    rows = []
    for index in range(count):
        values = baseline()
        strata = {}
        for dim in dims:
            k = permutations[dim][index]
            low, high, _ = BOUNDS[dim]
            values[dim] = low + (high - low) * ((k + 0.5) / count)
            strata[dim] = k
        rows.append(dict(id=f'om-lhs-{index + 1:02d}', stage='lhs', seed=SEED,
                         batch_count=count, active_dims=dims.copy(), strata=strata, values=values))
    return rows


def validate_candidate(candidate):
    if type(candidate) is not dict or type(candidate.get('values')) is not dict:
        raise ValueError('Candidate must contain values')
    if set(candidate['values']) != set(DIMS):
        raise ValueError('Exactly three shared dimensions are required')
    for dim, value in candidate['values'].items():
        low, high, _ = BOUNDS[dim]
        if not low <= _number(value) <= high:
            raise ValueError('Parameter outside frozen bounds: ' + dim)
    expected = first_batch()
    if candidate.get('stage') == 'lhs':
        if type(candidate.get('seed')) is not int or candidate['seed'] != SEED:
            raise ValueError('Fixed seed is required')
        expected = second_batch(candidate.get('active_dims'), candidate.get('batch_count'))
    encoded = canonical(candidate)
    if not any(encoded == canonical(row) for row in expected):
        raise ValueError('Candidate differs from the frozen finite recipe')
    return copy.deepcopy(candidate)


def year_role(site, year, declared_role=None):
    if type(site) is not str or type(year) is not int:
        raise ValueError('Site must be string and year must be integer (not bool/float)')
    if site not in ROLES or year not in ROLES[site]:
        raise ValueError('Site/year outside the locked original 24-year inventory')
    role = ROLES[site][year]
    if declared_role is not None and (type(declared_role) is not str or declared_role != role):
        raise ValueError('Declared role contradicts the locked protocol')
    return role


def validate_fit_inputs(records):
    """Metadata only: reject every non-training year before any future scoring."""
    if type(records) is not list or not records:
        raise ValueError('Nonempty training-input records are required')
    preparation_identity()
    originals = strict_json((HERE / 'SOURCE_BINDINGS.json').read_bytes())['multiyear_site_inputs']
    seen = set()
    checked = []
    for row in records:
        if type(row) is not dict or set(row) != {'site', 'year', 'role', 'input_sha256', 'metadata_sha256'}:
            raise ValueError('Unexpected fit-input fields')
        if type(row['role']) is not str or year_role(row['site'], row['year'], row['role']) != 'training':
            raise ValueError('Holdout/initialization/driver-only observations cannot enter fitting')
        key = (row['site'], row['year'])
        if key in seen:
            raise ValueError('Duplicate training site-year')
        seen.add(key)
        _digest(row['input_sha256'])
        _digest(row['metadata_sha256'])
        original = originals[row['site']]
        if (row['input_sha256'] != original['input_sha256'] or
                row['metadata_sha256'] != original['metadata_sha256']):
            raise ValueError('Training declaration is not bound to original HM input identities')
        checked.append(copy.deepcopy(row))
    return sorted(checked, key=lambda row: (row['site'], row['year']))


def _get(config, path):
    value = config
    for part in path:
        if type(value) is not dict or part not in value:
            raise ValueError('Missing explicit configuration path: ' + '.'.join(path))
        value = value[part]
    return value


def differences(before, after, path=()):
    """Type-sensitive leaf differences, including insertion/deletion and -0.0."""
    if type(before) is dict and type(after) is dict and before.keys() == after.keys():
        return [change for key in before for change in differences(before[key], after[key], path + (key,))]
    if type(before) is list and type(after) is list and len(before) == len(after):
        return [change for index, (old, new) in enumerate(zip(before, after))
                for change in differences(old, new, path + (index,))]
    return [] if canonical(before) == canonical(after) else [dict(path=list(path), before=before, after=after)]


def verify_changes(before, after, candidate):
    row = validate_candidate(candidate)
    changes = differences(before, after)
    allowed = {path for paths in PATHS.values() for path in paths}
    if any(tuple(change['path']) not in allowed for change in changes):
        raise ValueError('Non-parameter change outside the four-path whitelist')
    for dim, paths in PATHS.items():
        for path in paths:
            if canonical(_get(after, path)) != canonical(row['values'][dim]):
                raise ValueError('Applied parameter does not match shared candidate')
    return changes


def apply_candidate(original_bytes, candidate, expected_config_sha256):
    """Return a new config and sidecar; original initial state is not a spinup claim."""
    if sha(original_bytes) != _digest(expected_config_sha256):
        raise ValueError('Original configuration SHA256 mismatch')
    config = strict_json(original_bytes)
    if type(config) is not dict or type(config.get('site')) is not str or config['site'] not in ROLES:
        raise ValueError('Unknown/missing explicit site')
    identity = preparation_identity()
    originals = strict_json((HERE / 'SOURCE_BINDINGS.json').read_bytes())['allowed_original_configurations']
    matched = [entry for entry in originals if entry['sha256'] == expected_config_sha256
               and entry['site'] == config['site'] and entry['case'] == config.get('case')]
    if len(matched) != 1:
        raise ValueError('Configuration is not a registered original JR case/site/hash')
    candidate = validate_candidate(candidate)
    for dim, paths in PATHS.items():
        for path in paths:
            if _number(_get(config, path)) != BOUNDS[dim][2]:
                raise ValueError('An original baseline configuration is required, not another candidate')
    if _number(_get(config, ('biogeochemistry', 'decomposition_parameters', 'reference_temperature'))) != 298.15:
        raise ValueError('Original decomposition reference temperature must remain 298.15 K')
    result = copy.deepcopy(config)
    for dim, paths in PATHS.items():
        for path in paths:
            parent = _get(result, path[:-1])
            parent[path[-1]] = candidate['values'][dim]
    changes = verify_changes(config, result, candidate)
    output = canonical(result) + b'\n'
    receipt = dict(original_config_sha256=sha(original_bytes), output_config_sha256=sha(output),
                   original_canonical_sha256=sha(canonical(config)), candidate_sha256=sha(canonical(candidate)),
                   candidate=candidate, changes=changes, site=config['site'],
                   initialization='Original seed values preserved; own-parameter initialization/spinup is still required.',
                   spun_up=False, model_executed=False, score_computed=False,
                   registered_original=matched[0], preparation=identity)
    return output, receipt


def apply_shared_configurations(originals, candidate):
    """Apply one global candidate to all declared cases, without per-site overrides."""
    candidate = validate_candidate(candidate)
    if type(originals) is not list or not originals:
        raise ValueError('Explicit original configuration records are required')
    results = []
    seen = set()
    original_identities = set()
    for record in originals:
        if type(record) is not dict or set(record) != {'case', 'config_bytes', 'sha256'}:
            raise ValueError('No per-site candidate values or hidden configuration overrides')
        case = record['case']
        if type(case) is not str or not case or case in seen:
            raise ValueError('Distinct explicit case identifiers are required')
        seen.add(case)
        output, receipt = apply_candidate(record['config_bytes'], candidate, record['sha256'])
        if case != receipt['registered_original']['case']:
            raise ValueError('Declared case does not match the registered original configuration')
        if receipt['original_config_sha256'] in original_identities:
            raise ValueError('An original configuration cannot be counted under multiple case labels')
        original_identities.add(receipt['original_config_sha256'])
        results.append(dict(case=case, config_bytes=output, receipt=receipt))
    return results


def plan(active_dims, fit_inputs, count=16):
    """Only one 7 + at most 16 batch; there is no follow-on sampling scheduler."""
    first = first_batch()
    second = second_batch(active_dims, count)
    checked = validate_fit_inputs(fit_inputs)
    required = {(site, year) for site, years in ROLES.items() for year, role in years.items()
                if role == 'training'}
    if {(row['site'], row['year']) for row in checked} != required:
        raise ValueError('A formal plan must include all four fixed training site-years')
    return dict(schema='fluxnet-calibration-om-metadata-v1', seed=SEED,
                training_inputs=checked, first_batch=first, second_batch=second,
                active_dims=_dims(active_dims), candidate_count=len(first) + len(second), candidate_budget=23,
                site_shared_parameters=True, baseline_and_endpoints_executed=False,
                active_dimensions_are_explicit_not_inferred=True,
                objective=None, scoring=None, model_execution=False, calibrated=False,
                preparation=preparation_identity(),
                limitation='Finite budget for this round, not a reduced project goal or a guarantee of acceptance. '
                           'No own-parameter spinup or model state is created or inherited here.')


def write_new(path, raw):
    with Path(path).open('xb') as stream:
        stream.write(raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('plan')
    p.add_argument('--active-dims', nargs='*', required=True, choices=DIMS)
    p.add_argument('--count', type=int, default=16)
    p.add_argument('--fit-inputs', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p = sub.add_parser('apply')
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--expected-sha256', required=True)
    p.add_argument('--candidate', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'plan':
        value = plan(args.active_dims, strict_json(args.fit_inputs.read_bytes()), args.count)
        write_new(args.output, canonical(value) + b'\n')
    else:
        targets = [args.output.resolve(), args.receipt.resolve()]
        if len(set(targets)) != 2 or any(path.exists() for path in targets):
            raise ValueError('Separate new config and receipt paths are required')
        raw, receipt = apply_candidate(args.config.read_bytes(), strict_json(args.candidate.read_bytes()),
                                       args.expected_sha256)
        write_new(args.output, raw)
        write_new(args.receipt, canonical(receipt) + b'\n')


if __name__ == '__main__':
    main()

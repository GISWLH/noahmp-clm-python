# OM finite calibration metadata planner — preparation only

This is a pure standard-library planner, not a model runner, objective, optimizer or calibration result. It never opens physical arrays or prediction files. It cannot mark a configuration as spun up or calibrated, and does not deploy or submit tasks. Execute the metadata tests only on an EHPC compute node; this preparation is checked on Windows by AST, hashes and static lint only.

The three globally shared parameters are Ball–Berry slope `b_s` (5–12; baseline 9), maintenance respiration base `mr_b` (1.5e-6–4.5e-6 gC/(gN s); baseline 2.525e-6), and common `q10` (1.1–3; baseline 1.5). The bounds follow root's reading of Post et al. (2017), DOI 10.1002/2015JG003297, Table 1 and section 3.2. The model-specific meaning and units come from the frozen source and the included independent mapping review, not an assertion that this simplified model reproduces all CLM parameter effects.

`q10` writes both `biogeochemistry.plant_parameters.maintenance_q10` and `biogeochemistry.decomposition_parameters.q10`. The root/stem reference remains 293.15 K in source; decomposition `reference_temperature` remains 298.15 K. Leaf `respiration25`, its separate response, turnover times, live-stem N fraction and every other parameter remain unchanged.

The first batch is exactly one baseline plus the six single-dimension endpoints. The second batch contains at most 16 deterministic Latin-hypercube stratum centres with fixed seed 20261025. SHA256 ordering of `OM|seed|dimension|count|stratum` defines each independent permutation. All three dimensions may be active jointly; inactive dimensions stay at baseline. The caller must explicitly provide `active_dims`; the planner does not invent an OAT result. An empty list yields no second batch. Reordering the dimension list does not change points. One second batch is part of the frozen plan: making another plan with different dimensions/count is a new protocol choice, not automatic budget expansion. The 23-candidate bound is this round's finite budget, not a reduction of the overall project or a promise of acceptance. No sensitivity result exists here.

APIs:

- `first_batch()` returns the 7 frozen records; `second_batch(active_dims, count=16)` returns one finite LHS batch. `validate_candidate()` rejects altered endpoints, seeds, values, IDs and metadata.
- `plan(active_dims, fit_inputs, count=16)` freezes one batch with all four original training site-years and their input identities. Omitting even one year fails; the lower-level `validate_fit_inputs()` also supports checking a subset without making a formal plan. No objective or score is defined. The plan validates the complete preparation manifest and original source bindings.
- `apply_candidate(original_bytes, candidate, expected_config_sha256)` returns new JSON bytes plus a sidecar, leaving the input untouched. It requires a case/site/hash present in the fixed registry of 12 original JR climatology configurations; changing initial state and supplying its new hash still fails. Future cross-year configurations need separately prepared provenance and cannot self-register. `apply_shared_configurations(records, candidate)` applies one shared candidate to all explicit cases; records cannot supply per-site overrides. Configurations must have all four explicit baseline parameter fields; a configuration already modified for another candidate is rejected.
- `verify_changes()` rejects every change outside those four exact paths, including inserted/deleted fields, type changes and signed zero changes elsewhere. The builder never changes initial C/N/water/heat state, forcing, QC, height, calendar, soil, physical options or state identity. Finite numeric checks reject NaN/Infinity and bool/string coercion at numeric parameter paths; JSON duplicate keys are rejected. Valid pre-existing Boolean physics/phenology fields remain Boolean and unchanged.
- `year_role()` fixes all original 24 site-years. Only Cng 2007–08 and Qia 2003–04 may enter `validate_fit_inputs()`. Cha 2003 is initialization-only; Cha 2004–05, Cng 2009–10, Qia 2005 and HaM 2008–14 are held out; HaM 2001–07 is driver-only, never observation fitting. Fake role labels, unknown/coerced years, duplicate fit rows and unbound input hashes fail. A metadata declaration does not slice a multi-year archive: the later runner must enforce the same year boundary before reading observations or scores.

Every plan/configuration receipt binds the preparation manifest, planner, parameter specification, original NM source archive/manifest, original JR configuration package and original locked-role source. `SOURCE_BINDINGS.json` retains all 584 source and 34 JR member hashes, original HM 831 receipt/archive identity, and the four original multi-year input/metadata hashes. The test fixture is the byte-exact original Cng 2007 field-capacity hydraulic climatology configuration. The metadata tests cover actual configuration copies and negative leakage/whitelist/numeric/grid controls; they do not run or assert a physical sensitivity.

Future EHPC metadata check, from an isolated copy of this directory:

```sh
python -B -m unittest discover -s . -p test_planner_om.py -v
```

CLI metadata operations use new output files only:

```sh
python -B planner_om.py plan --active-dims b_s mr_b q10 --fit-inputs training-inputs.json --output plan.json
python -B planner_om.py apply --config original.json --expected-sha256 ORIGINAL_SHA256 --candidate candidate.json --output candidate-config.json --receipt candidate-config-receipt.json
```

`fit_inputs` records have exactly `site`, integer `year`, locked `role`, `input_sha256` and `metadata_sha256`; use the original HM identities from `SOURCE_BINDINGS.json`. The same site's original input spans multiple years, so the year restriction remains an explicit obligation of the later scoring runner. This preparation does not fabricate 2008/2004 configurations, transfer another parameter's equilibrated state, select a winner, read held-out predictions, or claim own-parameter initialization/spinup is complete. Initialization, appropriate spinup for each parameter setting, objective/scoring and execution are separate subsequent work.

"""EHPC-only stdlib metadata tests and explicit 23 x 8 configuration applications."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-fluxnet-calibration-om')
PREPARATION_SHA = '5fd375b9f455242e4062461379d60c9edf52eb33cdf2dd36f98ae2a5f05b2bc3'
REVIEW_SHA = '65c7a3ab5692bd3b296a621be5bdf09ff32ff4cc2b073764f14beac2e5ff77d7'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def read_archive(path, expected):
    assert sha(path.read_bytes()) == expected
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(member.isfile() for member in members)
        assert len({member.name for member in members}) == len(members)
        return {member.name: archive.extractfile(member).read() for member in members}


result = Path(sys.argv[1]).resolve()
assert os.environ.get('PBS_JOBID') and socket.gethostname().startswith('compute002')
assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
assert sys.version_info >= (3, 10)
result.mkdir()
started = time.monotonic()
receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
               python_executable=sys.executable, passed=False, error=None,
               unittest_parent_returncode=None, forward_model_runs=0,
               physical_arrays_loaded=False, calibrated=False, metadata_only=True)
try:
    controls_raw = (STAGE / 'execution/CONTROLS_SHA256.json').read_bytes()
    controls = json.loads(controls_raw)
    assert all(sha((STAGE / 'execution' / name).read_bytes()) == digest for name, digest in controls.items())
    prep_manifest = (STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()
    assert sha(prep_manifest) == PREPARATION_SHA
    prep_hashes = json.loads(prep_manifest)
    assert len(prep_hashes) == 9
    assert all(sha((STAGE / 'preparation' / name).read_bytes()) == digest for name, digest in prep_hashes.items())
    review_raw = (STAGE / 'independent-review.json').read_bytes()
    review = json.loads(review_raw)
    assert sha(review_raw) == REVIEW_SHA and review['blocking_findings'] == [] and review['controls'] == 9
    assert review['controls_manifest_sha256'] == PREPARATION_SHA
    preparation = result / 'preparation'
    preparation.mkdir()
    for name in [*prep_hashes, 'CONTROLS_SHA256.json']:
        shutil.copyfile(STAGE / 'preparation' / name, preparation / name)
    execution = result / 'execution'
    execution.mkdir()
    for name in [*controls, 'CONTROLS_SHA256.json']:
        shutil.copyfile(STAGE / 'execution' / name, execution / name)
    shutil.copyfile(STAGE / 'independent-review.json', result / 'independent-review.json')
    source_binding = json.loads((preparation / 'SOURCE_BINDINGS.json').read_bytes())
    source_description = source_binding['model_source_archive']
    model = read_archive(STAGE / 'inputs' / source_description['file'], source_description['sha256'])
    assert sha(model['SOURCE_SHA256.json']) == source_description['manifest_sha256']
    model_hashes = json.loads(model['SOURCE_SHA256.json'])
    assert model_hashes == source_description['source_sha256'] and len(model_hashes) == 584
    assert set(model) == set(model_hashes) | {'SOURCE_SHA256.json'}
    assert all(sha(model[name]) == digest for name, digest in model_hashes.items())
    input_description = source_binding['original_inputs_archive']
    originals = read_archive(STAGE / 'inputs' / input_description['file'], input_description['sha256'])
    assert {name: sha(raw) for name, raw in originals.items()} == input_description['member_sha256']
    hm_description = source_binding['multiyear_inventory']
    hm = read_archive(STAGE / 'inputs' / hm_description['file'], hm_description['sha256'])
    assert sha(hm['current/receipt.json']) == hm_description['receipt_sha256']
    hm_receipt = json.loads(hm['current/receipt.json'])
    assert hm_receipt['locked_splits'] == source_binding['locked_roles']
    assert hm_receipt['passed'] and hm_receipt['source_unchanged'] and hm_receipt['pbs_job'] == '831.manager'
    assert hm['current/pbs-exit.txt'].strip() == b'0'
    assert 'job_state = F' in hm['current/actual-pbs-qstat.txt'].decode()
    assert 'Exit_status = 0' in hm['current/actual-pbs-qstat.txt'].decode()
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    unit = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(preparation),
                           '-p', 'test_planner_om.py', '-v'], cwd=preparation, env=env,
                          capture_output=True, text=True, timeout=120)
    (result / 'unittest.stdout.txt').write_text(unit.stdout)
    (result / 'unittest.stderr.txt').write_text(unit.stderr)
    receipt['unittest_parent_returncode'] = unit.returncode
    assert unit.returncode == 0, unit.stderr
    assert 'Ran 15 tests' in unit.stderr and '\nOK\n' in unit.stderr
    specification = importlib.util.spec_from_file_location('planner_om', preparation / 'planner_om.py')
    planner = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(planner)
    training = []
    for site, years in planner.ROLES.items():
        for year, role in years.items():
            if role == 'training':
                identity = source_binding['multiyear_site_inputs'][site]
                training.append(dict(site=site, year=year, role=role,
                                     input_sha256=identity['input_sha256'], metadata_sha256=identity['metadata_sha256']))
    candidate_plan = planner.plan(list(planner.DIMS), training)
    save(result / 'candidate-plan.json', candidate_plan)
    candidates = candidate_plan['first_batch'] + candidate_plan['second_batch']
    assert len(candidates) == 23 and len(candidate_plan['first_batch']) == 7
    registry = source_binding['allowed_original_configurations']
    chosen = [row for row in registry if row['site'] in {'CN-Cng', 'CN-Qia'}]
    assert len(chosen) == 8 and {row['site'] for row in chosen} == {'CN-Cng', 'CN-Qia'}
    assert all(sha(originals[row['member']]) == row['sha256'] for row in registry)
    base_records = [dict(case=row['case'], config_bytes=originals[row['member']], sha256=row['sha256']) for row in chosen]
    applied = []
    root = result / 'applied'
    root.mkdir()
    for candidate in candidates:
        destination = root / candidate['id']
        destination.mkdir()
        rows = planner.apply_shared_configurations(base_records, candidate)
        assert len(rows) == 8 and {row['case'] for row in rows} == {row['case'] for row in chosen}
        for row in rows:
            config_name = row['case'] + '.json'
            receipt_name = row['case'] + '-receipt.json'
            (destination / config_name).write_bytes(row['config_bytes'])
            save(destination / receipt_name, row['receipt'])
            applied.append(dict(candidate=candidate['id'], case=row['case'],
                                config=str((destination / config_name).relative_to(result)),
                                receipt=str((destination / receipt_name).relative_to(result)),
                                output_sha256=sha(row['config_bytes']),
                                changes=row['receipt']['changes'],
                                original_sha256=row['receipt']['original_config_sha256']))
    assert len(applied) == 184
    save(result / 'applied-index.json', applied)
    assert all(sha((preparation / name).read_bytes()) == digest for name, digest in prep_hashes.items())
    assert all(sha((STAGE / 'preparation' / name).read_bytes()) == digest for name, digest in prep_hashes.items())
    assert all(sha((STAGE / 'execution' / name).read_bytes()) == digest for name, digest in controls.items())
    assert sha((STAGE / 'inputs' / source_description['file']).read_bytes()) == source_description['sha256']
    assert sha((STAGE / 'inputs' / input_description['file']).read_bytes()) == input_description['sha256']
    receipt.update(passed=True, preparation_manifest_sha256=PREPARATION_SHA,
                   execution_manifest_sha256=sha(controls_raw), review_sha256=sha(review_raw),
                   source_files_byteverified=584, original_input_members_byteverified=34,
                   original_configuration_registry_count=12, actual_unittest_count=15,
                   first_batch_candidates=7, second_batch_candidates=16, generated_candidates=23,
                   active_dims=list(planner.DIMS), original_training_initialization_cases=8,
                   metadata_configuration_applications=184, preparation_and_source_unchanged=True,
                   plan_sha256=sha((result / 'candidate-plan.json').read_bytes()),
                   applied_index_sha256=sha((result / 'applied-index.json').read_bytes()),
                   scope='Metadata only: no physical response, sensitivity, model, own-parameter spinup, scoring, calibration or scientific acceptance.')
except Exception as error:
    receipt['error'] = type(error).__name__ + ': ' + str(error)
    (result / 'traceback.txt').write_text(traceback.format_exc())
receipt['seconds'] = time.monotonic() - started
save(result / 'receipt.json', receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if receipt['passed'] else 1)

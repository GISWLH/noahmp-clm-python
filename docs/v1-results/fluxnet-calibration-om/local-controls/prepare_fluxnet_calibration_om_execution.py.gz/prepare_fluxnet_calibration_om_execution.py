"""Seal reviewed OM metadata-only EHPC stage; do not deploy or submit here."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'fluxnet-calibration-om-preparation'
EXEC = OUT / 'fluxnet-calibration-om-execution'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
assert sha(manifest_raw) == '5fd375b9f455242e4062461379d60c9edf52eb33cdf2dd36f98ae2a5f05b2bc3'
prep = json.loads(manifest_raw)
assert len(prep) == 9 and all(sha((PREP / name).read_bytes()) == digest for name, digest in prep.items())
review_raw = (OUT / 'fluxnet-calibration-om-independent-review-wp.json').read_bytes()
assert sha(review_raw) == '65c7a3ab5692bd3b296a621be5bdf09ff32ff4cc2b073764f14beac2e5ff77d7'
review = json.loads(review_raw)
assert review['blocking_findings'] == [] and review['controls_manifest_sha256'] == sha(manifest_raw)
controls = {name: sha((EXEC / name).read_bytes()) for name in
            ['run_metadata_om.py', 'metadata_om.pbs', 'dispatch_metadata_om.py']}
controls_raw = (json.dumps(controls, indent=2) + '\n').encode()
(EXEC / 'CONTROLS_SHA256.json').write_bytes(controls_raw)
for name in controls:
    if name.endswith('.py'):
        ast.parse((EXEC / name).read_bytes())
lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(EXEC), str(Path(__file__))],
                      capture_output=True, text=True)
assert lint.returncode == 0, lint.stdout + lint.stderr
files = {'preparation/' + name: (PREP / name).read_bytes() for name in prep}
files['preparation/CONTROLS_SHA256.json'] = manifest_raw
files.update({'execution/' + name: (EXEC / name).read_bytes() for name in controls})
files['execution/CONTROLS_SHA256.json'] = controls_raw
files['independent-review.json'] = review_raw
sources = json.loads((PREP / 'SOURCE_BINDINGS.json').read_bytes())
for key in ['model_source_archive', 'original_inputs_archive', 'multiyear_inventory']:
    source = sources[key]
    raw = (OUT / source['file']).read_bytes()
    assert sha(raw) == source['sha256']
    files['inputs/' + source['file']] = raw
index = {name: sha(raw) for name, raw in files.items()}
files['stage-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
target = OUT / 'fluxnet-calibration-om-stage.tar.gz'
assert not target.exists(), 'Do not replace a sealed execution stage'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        archive.addfile(item, io.BytesIO(raw))
with tarfile.open(target) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive}
assert restored == files
record = dict(stage_archive=target.name, stage_archive_sha256=sha(target.read_bytes()), bytes=target.stat().st_size,
              artifacts=len(files), preparation_manifest_sha256=sha(manifest_raw), execution_manifest_sha256=sha(controls_raw),
              review_sha256=sha(review_raw), stage_inventory=index, actual_ruff_returncode=lint.returncode,
              AST_parsed=True, planner_executed=False, tests_executed=False, deployed=False, PBS_submitted=False,
              resource_request='1CPU/2GB/5min/compute002', python='/home/zhangyq/venvs/noahmp-closeout/bin/python',
              scope='Prepared metadata tests and generation only; no model, numerical arrays, sensitivity or calibration.')
(OUT / 'fluxnet-calibration-om-execution-preparation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['stage_archive', 'stage_archive_sha256', 'bytes', 'artifacts',
      'preparation_manifest_sha256', 'execution_manifest_sha256', 'actual_ruff_returncode', 'deployed', 'PBS_submitted']}, indent=2))

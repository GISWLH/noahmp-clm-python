"""Independent OM metadata/AST/byte review; never import or run planner/tests."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

BASE = Path(__file__).resolve().parent
PREP = BASE / 'fluxnet-calibration-om-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda name: (PREP / name).read_bytes()
j = lambda name: json.loads(read(name))


def members(name, expected):
    path = BASE / name
    assert sha(path.read_bytes()) == expected
    with tarfile.open(path) as archive:
        found = [m for m in archive.getmembers() if m.isfile()]
        assert len(found) == len({m.name for m in found})
        return {m.name: archive.extractfile(m).read() for m in found}


manifest = j('CONTROLS_SHA256.json')
assert sha(read('CONTROLS_SHA256.json')) == '5fd375b9f455242e4062461379d60c9edf52eb33cdf2dd36f98ae2a5f05b2bc3'
assert len(manifest) == 9 and all(sha(read(name)) == digest for name, digest in manifest.items())
binding = j('SOURCE_BINDINGS.json')
source = members(binding['model_source_archive']['file'], binding['model_source_archive']['sha256'])
sm = json.loads(source['SOURCE_SHA256.json'])
assert len(sm) == 584 and sm == binding['model_source_archive']['source_sha256']
assert sha(source['SOURCE_SHA256.json']) == binding['model_source_archive']['manifest_sha256']
assert all(sha(source[name]) == digest for name, digest in sm.items())
inputs = members(binding['original_inputs_archive']['file'], binding['original_inputs_archive']['sha256'])
assert len(inputs) == 34 and {name: sha(value) for name, value in inputs.items()} == binding['original_inputs_archive']['member_sha256']
assert json.loads(inputs['protocol.json'])['source_manifest_sha256'] == binding['original_inputs_archive']['original_JN_manifest_sha256']
registered = []
for row in json.loads(inputs['batch.json'])['cases']:
    name = row['configuration']
    cfg = json.loads(inputs[name])
    assert cfg['case'] == row['case']
    registered.append(dict(member=name, site=cfg['site'], case=cfg['case'], sha256=sha(inputs[name])))
assert len(registered) == len({r['sha256'] for r in registered}) == 12
assert registered == binding['allowed_original_configurations']
fixture = binding['test_configuration']
assert inputs[fixture['original_member']] == read(fixture['file']) and sha(read(fixture['file'])) == fixture['sha256']
hm = members(binding['multiyear_inventory']['file'], binding['multiyear_inventory']['sha256'])
hr = json.loads(hm['current/receipt.json'])
assert hr['pbs_job'] == '831.manager' and hr['passed'] is True and hr['source_unchanged'] is True and hr['site_years'] == 24
assert hm['current/pbs-exit.txt'].strip() == b'0'
assert 'job_state = F' in hm['current/actual-pbs-qstat.txt'].decode() and 'Exit_status = 0' in hm['current/actual-pbs-qstat.txt'].decode()
assert sha(hm['current/receipt.json']) == binding['multiyear_inventory']['receipt_sha256']
assert hr['locked_splits'] == binding['locked_roles']
assert binding['multiyear_site_inputs'] == {r['site']: dict(input_sha256=r['original_prepared_npz_sha256'], metadata_sha256=r['original_manifest_sha256'], original_years=r['actual_years']) for r in hr['site_identities']}
role = binding['locked_roles_source']
assert hm[role['original_member']] == read(role['file']) and sha(read(role['file'])) == role['sha256']
for name, digest in binding['semantic_review'].items():
    assert read(name) == (BASE / name).read_bytes() and sha(read(name)) == digest
semantic = j('FLUXNET_CALIBRATION_PARAMETERS_WP.json')
assert semantic['blocking_findings'] == [] and all(sm[n] == h for n, h in semantic['source_files_sha256'].items())

planner = ast.parse(read('planner_om.py'))
tests = ast.parse(read('test_planner_om.py'))
functions = {n.name: n for n in planner.body if isinstance(n, ast.FunctionDef)}
assignments = {target.id: n.value for n in planner.body if isinstance(n, ast.Assign) for target in n.targets if isinstance(target, ast.Name)}
assert ast.literal_eval(assignments['DIMS']) == ('b_s', 'mr_b', 'q10')
assert ast.literal_eval(assignments['SEED']) == 20261025 and ast.literal_eval(assignments['MAX_SECOND_BATCH']) == 16
assert ast.literal_eval(assignments['BOUNDS']) == {'b_s': (5., 12., 9.), 'mr_b': (1.5e-6, 4.5e-6, 2.525e-6), 'q10': (1.1, 3., 1.5)}
paths = ast.literal_eval(assignments['PATHS'])
assert sum(map(len, paths.values())) == 4
for dim, spec in j('PARAMETER_SPEC.json')['dimensions'].items():
    assert spec['configuration_paths'] == [list(p) for p in paths[dim]]
    assert spec['bounds'] == list(ast.literal_eval(assignments['BOUNDS'])[dim][:2])
original_roles = ast.parse(read(role['file']))
role_assignments = {target.id: n.value for n in original_roles.body if isinstance(n, ast.Assign) for target in n.targets if isinstance(target, ast.Name)}
assert ast.dump(assignments['ROLES'], include_attributes=False) == ast.dump(role_assignments['splits'], include_attributes=False)
imports = {}
for name, tree in [('planner_om.py', planner), ('test_planner_om.py', tests)]:
    used = {node.module.split('.')[0] for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)} | {a.name.split('.')[0] for node in ast.walk(tree) if isinstance(node, ast.Import) for a in node.names}
    assert used <= {'argparse', 'copy', 'hashlib', 'json', 'math', 'pathlib', 'unittest', 'planner_om'}
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('eval', 'exec', '__import__') for n in ast.walk(tree))
    imports[name] = sorted(used)
test_names = [n.name for n in ast.walk(tests) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
assert len(test_names) == 15
shared = ast.unparse(functions['apply_shared_configurations'])
assert "case != receipt['registered_original']['case']" in shared
assert "receipt['original_config_sha256'] in original_identities" in shared
assert 'original_identities.add' in shared
fit = ast.unparse(functions['plan'])
assert "if {(row['site'], row['year']) for row in checked} != required:" in fit
apply = ast.unparse(functions['apply_candidate'])
assert "entry['sha256'] == expected_config_sha256" in apply and "entry['case'] == config.get('case')" in apply and "entry['site'] == config['site']" in apply
assert '298.15' in apply and 'verify_changes(config, result, candidate)' in apply
static = json.loads((BASE / 'fluxnet-calibration-om-static-verification.json').read_bytes())
assert static['controls_manifest_sha256'] == sha(read('CONTROLS_SHA256.json')) and static['actual_ruff_returncode'] == 0

result = dict(
    scope='Independent read-only stdlib archive/JSON/AST review only; planner/tests/models were not imported or executed. No physical array or heldout prediction was opened.',
    controls_manifest_sha256=sha(read('CONTROLS_SHA256.json')), controls=9, source_members_bytechecked=584, JR_input_members_bytechecked=34,
    registered_original_cases=12, exact_training_site_years=4, locked_original_site_years=24, original_HM_job='831.manager actual F0',
    reviewed_parameters=['b_s shared 5..12 baseline9', 'mr_b shared 1.5e-6..4.5e-6 gC/(gN s) baseline2.525e-6', 'Q10 shared1.1..3 baseline1.5 written both plant and decomposition'],
    preserved_reference_temperatures_K={'maintenance': 293.15, 'decomposition': 298.15},
    candidate_recipe='Seven baseline/OAT records; one explicit-dimension SHA256-seeded centre-LHS batch of <=16, total<=23. No objective, scores or OAT sensitivity invented.',
    static_imports=imports, unittest_methods_prepared=15, unittest_executed_by_this_review=False,
    findings_closed=[{'initial': 'apply_shared_configurations permitted a caller to relabel one registered original config as arbitrary distinct case labels.',
                     'fix': 'Outer case must now equal receipt.registered_original.case, repeated original SHA rejected; negative alias test added.'}],
    verified_boundaries=['Fixed four-year plan rejects any omission; lower-level subset checker is not a formal plan.',
                        'Every non-training year/forged role/coerced year is rejected for fitting metadata.',
                        'Fixed JR SHA/site/case registry prevents changed initial state with caller-recomputed SHA.',
                        'Only four parameter paths may differ; bool/nonfinite/duplicate-key/unknown-candidate rejection and common Q10 explicit.',
                        'One shared candidate passed to every original config; no per-site parameter override fields.',
                        'Writes only fresh output files; no execution, optimizer or source mutations.'],
    limitations=['Multi-year HM SHA does not by itself slice observations. Future scorer must enforce the exact training-year mask before reading scores; README states this explicitly.',
                 'Only original Cng2007/Qia2003/Cha2003 climate config identities are registered; future2008/2004 configs require separately reviewed provenance.',
                 'Application preserves original seeds but does not create own-parameter spinup or permit active-year checkpoint reuse.',
                 'Finite23 candidate recipe is not a total initialization-year or wallclock budget; planner cannot stop manual re-protocoling.'],
    blocking_findings=[], verdict='0 blocking for frozen metadata preparation and isolated EHPC stdlib checks; no model/scientific acceptance')
out = BASE / 'fluxnet-calibration-om-independent-review-wp.json'
out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(dict(review=str(out), sha256=sha(out.read_bytes()), verdict=result['verdict'])))

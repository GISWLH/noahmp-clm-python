"""Package complete closed OM metadata evidence with every generated config and sidecar."""
from pathlib import Path
import ast
import hashlib
import io
import json
import re
import tarfile

OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
download = OUT / 'fluxnet-calibration-om-closed-export.tar.gz'
remote_package_raw = (OUT / 'fluxnet-calibration-om-closed-export-package.json').read_bytes()
remote_package = json.loads(remote_package_raw)
assert sha(download.read_bytes()) == remote_package['archive_sha256']
assert remote_package['actual_job'] == '1596.manager'
assert remote_package['actual_state'] == 'F' and remote_package['actual_exit'] == 0
with tarfile.open(download) as archive:
    items = archive.getmembers()
    assert all(member.isfile() for member in items) and len({member.name for member in items}) == len(items)
    closed = {member.name: archive.extractfile(member).read() for member in items}
inventory = json.loads(closed.pop('artifact-inventory.json'))
assert set(inventory) == set(closed)
assert all(sha(closed[name]) == row['sha256'] and len(closed[name]) == row['bytes'] for name, row in inventory.items())
assert re.search(r'^\s*job_state = F\s*$', closed['actual-pbs-qstat.txt'].decode(), re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', closed['actual-pbs-qstat.txt'].decode(), re.M)
receipt = json.loads(closed['result/receipt.json'])
assert receipt == remote_package['receipt'] and receipt['passed'] and receipt['error'] is None
assert receipt['unittest_parent_returncode'] == 0 and receipt['actual_unittest_count'] == 15
assert receipt['generated_candidates'] == 23 and receipt['metadata_configuration_applications'] == 184
assert receipt['forward_model_runs'] == 0 and receipt['physical_arrays_loaded'] is False
assert closed['result/worker-exit.txt'].strip() == b'0' and closed['pbs-exit.txt'].strip() == b'0'
assert sum(name.startswith('result/applied/') and name.endswith('-receipt.json') for name in closed) == 184
assert sum(name.startswith('result/applied/') and not name.endswith('-receipt.json') for name in closed) == 184
assert sha(closed['result/preparation/CONTROLS_SHA256.json']) == '5fd375b9f455242e4062461379d60c9edf52eb33cdf2dd36f98ae2a5f05b2bc3'
prep = json.loads(closed['result/preparation/CONTROLS_SHA256.json'])
assert all(sha(closed['result/preparation/' + name]) == digest for name, digest in prep.items())
files = dict(closed)
files['closed-export-package.json'] = remote_package_raw
for name in ['prepare_fluxnet_calibration_om.py', 'prepare_fluxnet_calibration_om_execution.py',
             'package_fluxnet_calibration_om.py', 'review_fluxnet_calibration_om_wp.py',
             'fluxnet-calibration-om-independent-review-wp.json',
             'fluxnet-calibration-om-static-verification.json', 'fluxnet-calibration-om-execution-preparation.json',
             'FLUXNET_CALIBRATION_OM_SCOPE.md', 'fluxnet-calibration-om-dispatch.stdout.txt',
             'fluxnet-calibration-om-dispatch.stderr.txt', 'fluxnet-calibration-om-qstat.snapshot.txt',
             'fluxnet-calibration-om-qstat.second-snapshot.txt', 'fluxnet-calibration-om-qstat.third-snapshot.txt']:
    files['local-controls/' + name] = (OUT / name).read_bytes()
stage_raw = (OUT / 'fluxnet-calibration-om-stage.tar.gz').read_bytes()
assert sha(stage_raw) == 'e17270d51cba2bb36e117c403a3e54f1abc81a6fadd4c03425dc4d0e127cdf4e'
files['original-stage.tar.gz'] = stage_raw
with tarfile.open(fileobj=io.BytesIO(stage_raw)) as archive:
    staged = {member.name: archive.extractfile(member).read() for member in archive}
staged_index = json.loads(staged['stage-inventory.json'])
assert set(staged_index) == set(staged) - {'stage-inventory.json'}
assert all(sha(staged[name]) == digest for name, digest in staged_index.items())
assert staged['preparation/CONTROLS_SHA256.json'] == closed['result/preparation/CONTROLS_SHA256.json']
review_sha = '65c7a3ab5692bd3b296a621be5bdf09ff32ff4cc2b073764f14beac2e5ff77d7'
assert sha(staged['independent-review.json']) == review_sha
assert staged['independent-review.json'] == files['local-controls/fluxnet-calibration-om-independent-review-wp.json']
for name, raw in files.items():
    if name.endswith('.py'):
        ast.parse(raw)
preflight = dict(status='historical_readonly_preflight_failure', actual_exit=1,
                 source='Transcript of session tool output, not an original redirected SSH log',
                 action='A second absence-only Python -c probe before any upload',
                 error='SyntaxError: unexpected character after line continuation character',
                 cause='PowerShell quote escaping in Python -c. Replaced with fixed-path shell test predicates; actual exit 0 before SCP.',
                 uploads_before_failure=0, qsub_before_failure=0, model_execution=False,
                 note='The first SSH hostname/Python3.11.9 check was exit0; this failure made no remote file or job changes.')
files['local-controls/readonly-preflight-failure-provenance.json'] = (json.dumps(preflight, indent=2) + '\n').encode()
inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in files.items()}
files['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
target = OUT / 'fluxnet-calibration-om-evidence.tar.gz'
package_path = OUT / 'fluxnet-calibration-om-package.json'
assert not target.exists() and not package_path.exists(), 'Do not replace completed evidence'
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive}
assert restored == files
assert set(json.loads(restored['artifact-inventory.json'])) == set(restored) - {'artifact-inventory.json'}
package = dict(label='fluxnet-calibration-om', archive=target.name, sha256=sha(target.read_bytes()),
               bytes=target.stat().st_size, artifacts=len(files), artifact_sha256={name: sha(raw) for name, raw in files.items()},
               actual_job='1596.manager', actual_state='F', actual_parent_returncode=0,
               metadata_tests=15, metadata_tests_all_passed=True,
               generated_candidates=23, original_training_initialization_cases=8,
               configuration_files=184, configuration_sidecars=184,
               preparation_manifest_sha256=receipt['preparation_manifest_sha256'],
               execution_manifest_sha256=receipt['execution_manifest_sha256'], review_sha256=review_sha,
               original_stage_sha256=sha(stage_raw), model_executed=False, physical_arrays_loaded=False,
               own_parameter_spinup_executed=False, objective_frozen=False, scoring_executed=False,
               total_initialization_spinup_budget_frozen=False, calibrated=False,
               scope='Actual EHPC metadata-only tests and complete configuration generation evidence. '
                     'Formal loss, candidate initialization/spinup and total execution budget remain separate; '
                     'no physical response, parameter sensitivity, station pass, calibration or release claim.')
package_path.write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps({key: package[key] for key in ['label', 'archive', 'sha256', 'bytes', 'artifacts', 'actual_job',
      'metadata_tests', 'configuration_files', 'configuration_sidecars', 'calibrated']}, indent=2))

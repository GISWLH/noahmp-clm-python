"""Assemble OM source/metadata bindings and AST proof only; never execute planner/tests."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PREP = OUT / 'fluxnet-calibration-om-preparation'
REPO = OUT.parents[1]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (PREP / name).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')


def members(path, expected):
    assert sha(path.read_bytes()) == expected
    with tarfile.open(path) as archive:
        items = archive.getmembers()
        assert all(item.isfile() for item in items)
        assert len({item.name for item in items}) == len(items)
        return {item.name: archive.extractfile(item).read() for item in items}


source_name = 'climatology-final-candidate-nm-source.tar.gz'
source_sha = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
source = members(OUT / source_name, source_sha)
source_manifest = json.loads(source['SOURCE_SHA256.json'])
source_manifest_sha = sha(source['SOURCE_SHA256.json'])
assert source_manifest_sha == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert len(source_manifest) == 584 and set(source) == set(source_manifest) | {'SOURCE_SHA256.json'}
assert all(sha(source[name]) == digest for name, digest in source_manifest.items())
input_name = 'multisite-climatology-jr-inputs.tar.gz'
input_sha = 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
inputs = members(OUT / input_name, input_sha)
assert len(inputs) == 34
original_configurations = []
for case in json.loads(inputs['batch.json'])['cases']:
    name = case['configuration']
    config = json.loads(inputs[name])
    assert config['case'] == case['case']
    original_configurations.append(dict(member=name, site=config['site'], case=config['case'],
                                        sha256=sha(inputs[name])))
assert len(original_configurations) == 12
assert len({row['sha256'] for row in original_configurations}) == 12
fixture_name = 'configs/CN-Cng-2007-field-capacity-hydraulic-clim.json'
fixture_raw = inputs[fixture_name]
assert sha(fixture_raw) == '927ec061bcc6dad7cce47945549b56bb7908687c01c64ebe4ef4da4604533f7a'
(PREP / 'original-cng-config.json').write_bytes(fixture_raw)

hm_name = 'multiyear-qc-inventory-hm-evidence.tar.gz'
hm_sha = '5fe01b014f112000c71c235a58ec24a3e2c502eaf175060bc5758f1f955a5cc1'
hm = members(OUT / hm_name, hm_sha)
hm_receipt = json.loads(hm['current/receipt.json'])
assert hm_receipt['passed'] and hm_receipt['source_unchanged']
assert hm_receipt['pbs_job'] == '831.manager' and hm_receipt['site_years'] == 24
assert hm['current/pbs-exit.txt'].strip() == b'0'
assert 'job_state = F' in hm['current/actual-pbs-qstat.txt'].decode()
assert 'Exit_status = 0' in hm['current/actual-pbs-qstat.txt'].decode()
role_source = hm['current/inventory_multiyear_qc_hm.py']
assert role_source == (OUT / 'inventory_multiyear_qc_hm.py').read_bytes()
(PREP / 'original-locked-role-source.txt').write_bytes(role_source)
semantic_names = ['FLUXNET_CALIBRATION_PARAMETERS_WP.md', 'FLUXNET_CALIBRATION_PARAMETERS_WP.json']
for name in semantic_names:
    (PREP / name).write_bytes((OUT / name).read_bytes())
semantic = json.loads((PREP / semantic_names[1]).read_text(encoding='utf-8'))
assert semantic['blocking_findings'] == [] and semantic['all_reviewed_source_files_byteequal_frozen_NM']
assert all(digest == source_manifest[name] for name, digest in semantic['source_files_sha256'].items())

spec = dict(
    schema='fluxnet-calibration-om-parameter-spec-v1', shared_across_all_sites=True,
    range_reference=dict(doi='10.1002/2015JG003297', year=2017, location='Table 1 and section 3.2',
                         provenance='Bounds supplied by root after its primary-source web reading; no new literature fetch in this preparation.'),
    dimensions={
        'b_s': dict(bounds=[5.0, 12.0], baseline=9.0, units='dimensionless',
                    configuration_paths=[['leaf_parameters', 'ball_berry_slope']]),
        'mr_b': dict(bounds=[1.5e-6, 4.5e-6], baseline=2.525e-6, units='gC/(gN s)',
                     configuration_paths=[['biogeochemistry', 'plant_parameters', 'maintenance_base']],
                     model_scope='Root and live-stem maintenance; leaf dark respiration remains independent.'),
        'q10': dict(bounds=[1.1, 3.0], baseline=1.5, units='dimensionless multiplier per 10 K',
                    configuration_paths=[['biogeochemistry', 'plant_parameters', 'maintenance_q10'],
                                         ['biogeochemistry', 'decomposition_parameters', 'q10']]),
    },
    unchanged_reference_temperatures_K=dict(plant_maintenance_source_constant=293.15, decomposition=298.15),
    unchanged_leaf_respiration=True, first_batch=7, second_batch_maximum=16, round_candidate_budget=23,
    fixed_seed=20261025, objective=None, scoring=None, sensitivity_evidence=None,
    status='metadata_preparation_only_not_calibrated', own_parameter_spinup_required=True,
)
save('PARAMETER_SPEC.json', spec)
bindings = dict(
    model_source_archive=dict(file=source_name, sha256=source_sha, manifest_sha256=source_manifest_sha,
                              files=584, source_sha256=source_manifest),
    original_inputs_archive=dict(file=input_name, sha256=input_sha, files=34,
                                 member_sha256={name: sha(raw) for name, raw in inputs.items()},
                                 original_JN_manifest_sha256=json.loads(inputs['protocol.json'])['source_manifest_sha256']),
    test_configuration=dict(original_member=fixture_name, file='original-cng-config.json', sha256=sha(fixture_raw)),
    allowed_original_configurations=original_configurations,
    multiyear_inventory=dict(file=hm_name, sha256=hm_sha, receipt_member='current/receipt.json',
                            receipt_sha256=sha(hm['current/receipt.json']), actual_job='831.manager',
                            actual_terminal='F0', original_inputs_archive_sha256=hm_receipt['original_archive_sha256']),
    multiyear_site_inputs={row['site']: dict(input_sha256=row['original_prepared_npz_sha256'],
                                           metadata_sha256=row['original_manifest_sha256'],
                                           original_years=row['actual_years']) for row in hm_receipt['site_identities']},
    locked_roles=hm_receipt['locked_splits'],
    locked_roles_source=dict(original_member='current/inventory_multiyear_qc_hm.py',
                             file='original-locked-role-source.txt', sha256=sha(role_source)),
    semantic_review={name: sha((PREP / name).read_bytes()) for name in semantic_names},
    limitations=['Metadata provenance only: no physical input array loaded, no new model result or sensitivity.',
                 'Only original 2007/2003 JR configurations are available here; future training-year configuration building is not implemented.'],
)
save('SOURCE_BINDINGS.json', bindings)
names = ['planner_om.py', 'test_planner_om.py', 'README.md', 'PARAMETER_SPEC.json', 'SOURCE_BINDINGS.json',
         'original-cng-config.json', 'original-locked-role-source.txt', *semantic_names]
imports = {}
test_count = 0
for name in ['planner_om.py', 'test_planner_om.py']:
    tree = ast.parse((PREP / name).read_bytes())
    imports[name] = sorted({node.module.split('.')[0] for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)} |
                           {alias.name.split('.')[0] for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names})
    assert set(imports[name]) <= {'argparse', 'copy', 'hashlib', 'json', 'math', 'pathlib', 'unittest', 'planner_om'}
    if name == 'test_planner_om.py':
        test_count = sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_') for node in ast.walk(tree))
    assert not any(isinstance(node, (ast.Import, ast.ImportFrom)) and 'numpy' in ast.unparse(node) for node in ast.walk(tree))
manifest = {name: sha((PREP / name).read_bytes()) for name in names}
save('CONTROLS_SHA256.json', manifest)
lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(PREP), str(Path(__file__))],
                      capture_output=True, text=True)
record = dict(mode='AST_hash_static_only', controls=len(manifest),
              controls_manifest_sha256=sha((PREP / 'CONTROLS_SHA256.json').read_bytes()),
              source_files_byteverified=584, original_input_members_hashed=34,
              original_HM_receipt_checked=True, original_fixture_byteequal=True,
              imports=imports, unittest_methods_prepared=test_count, unittest_execution=False,
              planner_executed=False, arrays_loaded=False, model_executed=False,
              deployed=False, PBS_submitted=False, actual_ruff_returncode=lint.returncode,
              ruff_stdout=lint.stdout, ruff_stderr=lint.stderr)
(OUT / 'fluxnet-calibration-om-static-verification.json').write_text(json.dumps(record, indent=2) + '\n')
assert lint.returncode == 0, record
print(json.dumps(record, indent=2))

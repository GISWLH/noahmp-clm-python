from pathlib import Path
import hashlib,json,sys
import numpy as np
from netCDF4 import Dataset

source,dest=map(Path,sys.argv[1:3]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(source)=='2f06147f8a9b6b07e0f3e261bf7170adea3c738cfa33c880c3b1fcf69bf50641';record=json.loads(source.read_text());assert record['failure'] is None;d=record['result'];assert not dest.exists()
expected={};dimensions={};variables=d['variables'];years=[1999,2000,2001]
for name in ['lat','lon']:expected[name]=np.asarray([d['latitude'] if name=='lat' else d['longitude']]);dimensions[name]=(name,)
for name,value in d['static'].items():expected[name]=np.asarray([[value]]);dimensions[name]=('lat','lon')
for name in ['time','year','time_bnds','tbuildmax_TBD','tbuildmax_HD','tbuildmax_MD']:
 values=np.asarray([d['years'][str(y)][name] for y in years]);expected[name]=values[:,None,None] if name.startswith('tbuildmax') else values;dimensions[name]=('time','lat','lon') if name.startswith('tbuildmax') else ('time','nv') if name=='time_bnds' else ('time',)
with Dataset(dest,'w',format='NETCDF3_CLASSIC') as out:
 for name,size in [('lat',1),('lon',1),('nv',2),('time',None)]:out.createDimension(name,size)
 for name,values in expected.items():
  attrs=variables[name]['attributes'].copy();kw={}
  if '_FillValue' in attrs:kw['fill_value']=attrs.pop('_FillValue')
  v=out.createVariable(name,np.dtype(variables[name]['dtype']),dimensions[name],**kw);v.setncatts(attrs);v[:]=values
 out.source_url=d['source_url'];out.source_etag=d['source_etag'];out.original_nc_header_sha256=d['header_sha256'];out.selection_sha256=sha(source);out.scope=record['scope']
with Dataset(dest) as out:
 for name,values in expected.items():np.testing.assert_array_equal(out[name][:],values)
 assert out['time'].calendar=='noleap' and out['time'].units=='days since 0000-01-01 00:00' and out['LANDMASK'][0,0]==1
print(json.dumps(dict(scope='EHPC compute-node build/reopen of actual selected original auxiliary values, three annual samples1999-2001; each variable exactly roundtrips. Forest urban area0. Mirror header/static selected bytes match actual NCAR prefix; original full NCAR hash unavailable. No meteorology/soil/initial-state/active physics change or science pass.',source_selection_sha256=sha(source),output_sha256=sha(dest),output_bytes=dest.stat().st_size,variables=list(expected),maximum_value_roundtrip_difference=0.)))

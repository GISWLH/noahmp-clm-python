from pathlib import Path
import hashlib
import json
import os
import sys

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
mode, inputs_arg, root_arg = sys.argv[1:4]
inputs, root = Path(inputs_arg), Path(root_arg)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
config = Path('/home/zhangyq/noahmp-v1/qia-stem-inputs-a/inputs/CN-Qia-stem-config.json')
assert sha(config) == '339310f80d579cd52926447c5e0645438c918343753ae096bd4a75ff5e941bf1'
c = json.loads(config.read_text())
assert c['column']['fveg'] == 1. and c['column']['swe'] == 0. and c['column']['canw'] == 0.
canopy = c['canopy_structure']
values = dict(tlai=c['column']['lai'], elai=c['column']['lai'], tsai=canopy['initial_sai'], esai=canopy['initial_sai'],
              htop=canopy['parameters']['canopy_top_m'], hbot=canopy['parameters']['canopy_bottom_m'], FRAC_VEG_NOSNO_ALB=1)
target = inputs / 'CN-Qia.partial-hydrothermal-init.nc'
if mode == 'make':
    record = json.loads((root / 'partial-seed.json').read_text())
    assert sha(target) == record['partial_seed_sha256']
    before = sha(target)
    with Dataset(inputs / 'seed-geometry-source/restart_geometry.nc') as metadata, Dataset(target, 'a') as out:
        for name, expected in values.items():
            assert name not in out.variables
            v = metadata[name]
            kw = {'fill_value': v.getncattr('_FillValue')} if '_FillValue' in v.ncattrs() else {}
            new = out.createVariable(name, v.dtype, v.dimensions, **kw)
            new.setncatts({k: v.getncattr(k) for k in v.ncattrs() if k != '_FillValue'})
            new[:] = np.full(v.shape, expected, dtype=v.dtype)
        out.setncattr('initial_canopy_scope', 'Additional predeclared native LAI3/SAI0.54936333/crown11/5.5m and vegetation flag1,not eoy values. O/Q fresh cold canopy0 retained as prior experiments. Other unlisted official cold fields remain defaults; not an all-conditions match.')
    record.update(partial_seed_sha256=sha(target), initial_canopy_values=values,
                  original_partial_hydrothermal_seed_sha256=before, original_native_configuration_sha256=sha(config))
    record['included_variables'] += list(values)
    record['excluded_historical_variables'] = [n for n in record['excluded_historical_variables'] if n not in values]
    (root / 'partial-seed.json').write_text(json.dumps(record, indent=2) + '\n')
    (root / 'canopy-seed.json').write_text(json.dumps(dict(scope='Additional cold-canopy initialization experiment only, prompted by actual O/Q first-bin zero LAI/SAI and verified official late-driver SP update. Values from original native pre-score configuration,not fitted.', values=values,
                                                      native_configuration_sha256=sha(config), before_sha256=before, partial_seed_sha256=sha(target)), indent=2) + '\n')
    print(json.dumps(dict(values=values, partial_seed_sha256=sha(target))), flush=True)
elif mode == 'audit':
    record = json.loads((root / 'canopy-seed.json').read_text())
    assert sha(target) == record['partial_seed_sha256']
    p = inputs / 'CN-Qia.official-interpolated-cold.nc'
    errors = {}
    with Dataset(p) as d:
        for name, expected in values.items():
            a = np.ma.asarray(d[name][:])
            assert not np.any(np.ma.getmaskarray(a))
            error = float(np.max(abs(np.asarray(a, float) - expected)))
            assert error <= 1e-12, (name, error)
            errors[name] = error
    result = dict(scope='Actual standard official interpolation destination before first integration,initial canopy only. No upstream source change or all-background/scientific acceptance.',
                  pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, maximum_absolute_errors=errors,
                  initial_canopy_values=values, official_seed_sha256=sha(p), original_native_configuration_sha256=sha(config))
    (root / 'canopy-seed-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
else:
    raise ValueError(mode)

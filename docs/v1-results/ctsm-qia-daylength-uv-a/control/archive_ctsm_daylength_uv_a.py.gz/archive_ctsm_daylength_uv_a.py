from pathlib import Path
import hashlib
import io
import json
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'ctsm-qia-daylength-uv-a-evidence.tar.gz'
assert not a.exists()
inspection = json.loads((b / 'ctsm-qia-daylength-registration-a.json').read_text())
assert len(inspection['source_matches']) == 2 and all('if (use_cn) then' in x['excerpt'] for x in inspection['source_matches'])
with tarfile.open(a, 'w:gz') as t:
    cases = {}
    for name in ['ctsm-qia-run-u', 'ctsm-qia-run-v']:
        root = b / name; d = json.loads((root / 'configuration.json').read_text())
        assert (root / 'pbs-exit.txt').read_text().strip() == '1' and d['upstream_original_bytes_unchanged']
        assert d.get('official_model_returncode') == (None if name.endswith('-u') else 233)
        cases[name] = dict(configuration_sha256=sha(root / 'configuration.json'), original_private_sha256=sha(root / 'case-configuration-private.tar.gz'),
                           official_model_returncode=d.get('official_model_returncode'), pbs_returncode=1)
        for p in sorted(root.iterdir()):
            if p.is_file() and p.name != 'case-configuration-private.tar.gz':
                t.add(p, arcname=name + '/' + p.name, recursive=False)
        with tarfile.open(root / 'case-configuration-private.tar.gz') as private:
            for m in private:
                if not m.isfile():
                    continue
                base = Path(m.name).name
                keep = m.name.endswith(('.stdout.txt', '.stderr.txt', '.stream')) or m.name.startswith('case/user_nl_') or (m.name.startswith('output/case/run/') and ('.log.' in base or base in ['datm_in', 'lnd_in', 'drv_in']))
                if keep:
                    raw = private.extractfile(m).read(); item = tarfile.TarInfo(name + '/workspace/' + m.name); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
    for name in ['ctsm-qia-daylength-registration-a.json', 'inspect_ctsm_daylength_registration_a.py', 'dispatch_ctsm_qia_u.py', 'dispatch_ctsm_qia_v.py', 'archive_ctsm_daylength_uv_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
    summary = dict(scope='Original extra-DAYL diagnostic failures retained: U252missing unchanged auxselection preflight1, V253corrected same originalfile but officialmodel233/PBS1 before first sample because DAYL history registration is inside use_cn. Original R/S use SP/nonCN;actual DAYL unmeasured,not fabricated fromfactor1 or obtained by changingphysics/CN. Pinnedsource/physical/met/initial choices unchanged,no source edits. No additional DAYL trial or scientific pass.', cases=cases,
                   source_inspection_sha256=sha(b / 'ctsm-qia-daylength-registration-a.json'))
    raw = (json.dumps(summary, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

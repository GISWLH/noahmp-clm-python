from pathlib import Path
import hashlib
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
archive = b / 'ctsm-reference-source-bundle-a.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
rows = []
with tarfile.open(archive) as t:
    for m in t:
        if not m.isfile() or not m.name.endswith('.F90') or not m.name.startswith('CTSM/src/'):
            continue
        lines = t.extractfile(m).read().decode().splitlines()
        for i, line in enumerate(lines):
            if re.search(r"['\"](?:DAYL|PREV_DAYL)['\"]", line):
                rows.append(dict(file=m.name, line=i + 1, excerpt='\n'.join(lines[max(0, i - 16):i + 10])))
logs = {}
for name in ['ctsm-qia-run-u', 'ctsm-qia-run-v']:
    root = b / name
    config = json.loads((root / 'configuration.json').read_text())
    assert (root / 'pbs-exit.txt').read_text().strip() == '1' and config['upstream_original_bytes_unchanged']
    with tarfile.open(root / 'case-configuration-private.tar.gz') as t:
        selected = {}
        for m in t:
            if not m.isfile():
                continue
            base = Path(m.name).name
            if 'lnd.log.' in base or m.name in ['urban-auxiliary-point.stderr.txt', 'official-model.stderr.txt'] or base == 'drv_in':
                text = t.extractfile(m).read().decode(errors='replace')
                lines = text.splitlines()
                selected[m.name] = dict(last_lines=lines[-12:] if base != 'drv_in' else [line for line in lines if re.search('orb_', line, re.I)],
                                       any_completed_timestep='clm: completed timestep' in text,
                                       any_history_current_sample='Writing current time sample' in text)
        logs[name] = dict(configuration_sha256=hashlib.sha256((root / 'configuration.json').read_bytes()).hexdigest(), failure=config['failure'], official_model_returncode=config.get('official_model_returncode'), selected_logs=selected)
record = dict(scope='Read-only pinned-source metadata and original U/V error logs only;no numerical model/array computation on login. Identify official DAYL history availability before any further trial;original fields/sources/gates untouched.', source_bundle_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), source_matches=rows, original_U_V=logs)
p = b / 'ctsm-qia-daylength-registration-a.json'
assert not p.exists(); p.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

from pathlib import Path
import hashlib
import json
import shutil
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-run-u'; r.mkdir(exist_ok=False)
for name in ['derive_ctsm_qia_common_radiation_a.py', 'derive_ctsm_qia_copyall_a.py', 'make_ctsm_qia_partial_seed_a.py', 'make_ctsm_urbantv_point_b.py', 'restore_ctsm_topo_time_a.py', 'set_ctsm_qia_canopy_seed_a.py']:
    shutil.copyfile(b / 'ctsm-qia-run-s' / name, r / name)
for name in ['run_ctsm_qia_u.py', 'audit_ctsm_qia_photo_daylength_u.py', 'ctsm_qia_run_u.pbs', 'ctsm-qia-run-u-protocol.json']:
    shutil.copyfile(b / name, r / name)
assert b'\r' not in (r / 'ctsm_qia_run_u.pbs').read_bytes()
job = subprocess.check_output(['qsub', 'ctsm_qia_run_u.pbs'], cwd=r, text=True).strip()
record = dict(pbs_job=job, controls_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in r.iterdir() if p.is_file()},
              scope='Only extra DAYL history output;new independent official48 case,prior original physics/source/met/initial cases not altered.')
(r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

from pathlib import Path
import hashlib
import json
import shutil
import subprocess

b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-run-v'; r.mkdir(exist_ok=False)
for name in ['derive_ctsm_qia_common_radiation_a.py', 'derive_ctsm_qia_copyall_a.py', 'make_ctsm_qia_partial_seed_a.py', 'make_ctsm_urbantv_point_b.py', 'restore_ctsm_topo_time_a.py', 'set_ctsm_qia_canopy_seed_a.py', 'urbantv-selection.json']:
    shutil.copyfile(b / 'ctsm-qia-run-s' / name, r / name)
for name in ['run_ctsm_qia_v.py', 'audit_ctsm_qia_photo_daylength_v.py', 'ctsm_qia_run_v.pbs', 'ctsm-qia-run-v-protocol.json']:
    shutil.copyfile(b / name, r / name)
assert b'\r' not in (r / 'ctsm_qia_run_v.pbs').read_bytes()
assert hashlib.sha256((r / 'urbantv-selection.json').read_bytes()).hexdigest() == '2f06147f8a9b6b07e0f3e261bf7170adea3c738cfa33c880c3b1fcf69bf50641'
assert (b / 'ctsm-qia-run-u/pbs-exit.txt').read_text().strip() == '1'
job = subprocess.check_output(['qsub', 'ctsm_qia_run_v.pbs'], cwd=r, text=True).strip()
record = dict(original_U_prephysics_failure='Missing unchanged S urbantv-selection.json in dispatcher;U252 physical model never launched,original failure/archive retained.', original_U_configuration_sha256=hashlib.sha256((b / 'ctsm-qia-run-u/configuration.json').read_bytes()).hexdigest(), pbs_job=job, controls_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in r.iterdir() if p.is_file()},
              scope='Only extra DAYL history output;new independent official48 case,prior original physics/source/met/initial cases not altered.')
(r / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

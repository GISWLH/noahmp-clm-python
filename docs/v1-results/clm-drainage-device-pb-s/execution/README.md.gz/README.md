# PB-s execution wrappers, not numerical/source changes

The five frozen preparation controls remain manifest `9b20b092b2be1f2426364d98d43b40e71c93a188bdd0949b0891aa2541601a2d`. The PB-r candidate and all eight recorded inputs/reference packets remain bound to the original hashes.

`run_device_parent_pbs.py` is the reviewed PO one-worker parent with entry/data names changed to PB-s, timeout reduced to 3600 seconds, fresh cache prefix changed, and explicit CUDA12.4 PATH. Its original Popen/wait/timeout kill-and-wait and raw log/exit/receipt pattern is retained. `control_device_pbs.py` runs these parents exactly once in cuda,jax order and waits their real return codes even when one fails. `launch_device_pbs.py` checks fresh persistent/private paths and the full stage/source before starting that controller. The detached controller's OS exit remains unknown; the actual waited parent and worker exits are separately recorded.

GPU results are archived after both parents, excluding their three private caches and retaining all raw outputs/logs/receipts. No GPU-side scientific comparison or NumPy physical reference runs.

The comparison dispatcher is the reviewed PW manager-to-compute002 transfer/qsub pattern with private paths/resources/entry metadata changed. PBS uses1CPU/2GiB/5min and the frozen EHPC comparator once. The outer comparison worker preserves a missing original GPU receipt as explicit unavailable case failures rather than fabricating one. Completed/partial original receipts go unchanged to the frozen comparator; no missing case is silently passed. Parent child timeout is240s within the PBS limit. Actual child/PBS/Stageout codes must be closed independently.

This preparation does not launch itself. Root authorized one sequential CUDA/JAX execution and one EHPC comparison, no retry. Source, inputs and the five numerical preparation controls are unchanged.

"""Closed1820 raw stage/result/qstat collection, without numerical execution."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
DEST=BASE/'clm-drainage-device-pb-s-comparison-closed'
assert not DEST.exists();DEST.mkdir()
sha=lambda r:hashlib.sha256(r).hexdigest()
commands=[('qstat',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc','qstat -xf 1820.manager']),
    ('compute-before',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc-c2',
        'sha256sum /tmp/noahmp-drainage-device-pb-s-compare/result.tar.gz /tmp/noahmp-drainage-device-pb-s-compare/stage-inventory.json && cat /tmp/noahmp-drainage-device-pb-s-compare/pbs-exit.txt']),
    ('scp',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',
        'ehpc-c2:/tmp/noahmp-drainage-device-pb-s-compare/result.tar.gz',
        'ehpc-c2:/tmp/noahmp-drainage-device-pb-s-compare/pbs-exit.txt',str(DEST.resolve())]),
    ('compute-after',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc-c2',
        'sha256sum /tmp/noahmp-drainage-device-pb-s-compare/result.tar.gz /tmp/noahmp-drainage-device-pb-s-compare/stage-inventory.json && cat /tmp/noahmp-drainage-device-pb-s-compare/pbs-exit.txt'])]
for label,command in commands:
    r=subprocess.run(command,capture_output=True,timeout=120)
    (DEST/(label+'.stdout')).write_bytes(r.stdout);(DEST/(label+'.stderr')).write_bytes(r.stderr)
    (DEST/(label+'.json')).write_text(json.dumps(dict(command=command,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)),indent=2)+'\n',encoding='utf-8')
    assert r.returncode==0,r.stderr.decode(errors='replace')
qstat=(DEST/'qstat.stdout').read_text();assert all(s in qstat for s in ('job_state = F','Exit_status = 1','Stageout_status = 0','run_count = 1'))
assert (DEST/'compute-before.stdout').read_bytes()==(DEST/'compute-after.stdout').read_bytes()
expected=(DEST/'compute-before.stdout').read_text().split()[0]
assert sha((DEST/'result.tar.gz').read_bytes())==expected
assert (DEST/'pbs-exit.txt').read_bytes().strip()==b'1'
print(json.dumps(dict(actual_job='1820.manager',F_exit=1,Stageout_status=0,original_result_sha256=expected,read_exits=[0,0,0,0])))

"""One authorized upload/launcher invocation; retain every actual command exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'clm-drainage-device-pb-s-gpu-stage-b.tar.gz'
expected='91454014cd10df43935237c9005056f726c1612ab99e97e071fa7401d73267e4'
assert sha(stage.read_bytes())==expected
target=BASE/'clm-drainage-device-pb-s-gpu-deployment.json'
assert not target.exists()
launcher=BASE/'clm-drainage-device-pb-s-execution/launch_device_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
    'test ! -e /home/lhwang/work/noahmp-v1/clm-drainage-device-pb-s && test ! -e /tmp/drainage-pb-s-20261026 && test ! -e /tmp/noahmp-clm-drainage-device-pb-s-stage.tar.gz && test ! -e /tmp/launch_drainage_device_pbs.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'xuanze-neiwang:/tmp/noahmp-clm-drainage-device-pb-s-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(launcher),'xuanze-neiwang:/tmp/launch_drainage_device_pbs.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xuanze-neiwang',
     '/home/lhwang/venvs/noahmp-phase3b/bin/python -B /tmp/launch_drainage_device_pbs.py --stage /tmp/noahmp-clm-drainage-device-pb-s-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_launch=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('clm-drainage-device-pb-s-gpu-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('clm-drainage-device-pb-s-gpu-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['launch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['launch']))

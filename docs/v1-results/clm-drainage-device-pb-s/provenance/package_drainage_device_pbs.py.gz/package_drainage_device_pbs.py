"""Closed PB-s device attempt and 1820 comparison; no local numeric decoding."""
from pathlib import Path
import gzip
import io
import json
import tarfile

from verify_drainage_1704_pc import files, packet, sha

BASE=Path(__file__).resolve().parent
LABEL='clm-drainage-device-pb-s'
GPU_STAGE='91454014cd10df43935237c9005056f726c1612ab99e97e071fa7401d73267e4'
CPU_STAGE='c1afb8f53da5e5257ac9e4258cb2173e4046810eaad469be32c7a45f8c871aaa'
GPU_RESULT='fa494d47ae0b34218a3c70b1d127aaa93c7bc2442dc5de4fe319c8203d2b5a5b'
CPU_RESULT='cb9124f361a0c147f8a0427d828fa845e9df4c6940df30a7b80e0b87882353f5'
encode=lambda d:(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()


def main():
    gpu_stage_raw=(BASE/(LABEL+'-gpu-stage-b.tar.gz')).read_bytes()
    cpu_stage_raw=(BASE/(LABEL+'-comparison-stage.tar.gz')).read_bytes()
    gpu_raw=(BASE/(LABEL+'-gpu-closed')/'gpu-result.tar.gz').read_bytes()
    cpu_raw=(BASE/(LABEL+'-comparison-closed')/'result.tar.gz').read_bytes()
    assert [sha(raw) for raw in (gpu_stage_raw,cpu_stage_raw,gpu_raw,cpu_raw)]==[GPU_STAGE,CPU_STAGE,GPU_RESULT,CPU_RESULT]
    gpu_stage,cpu_stage,gpu,cpu=map(files,(gpu_stage_raw,cpu_stage_raw,gpu_raw,cpu_raw))
    for stage in (gpu_stage,cpu_stage):
        index=json.loads(stage['stage-inventory.json'])
        assert len(stage)==21 and set(index)==set(stage)-{'stage-inventory.json'}
        assert all(sha(stage[n])==h for n,h in index.items())
    for name in gpu_stage:
        if name.startswith(('preparation/','execution/')):assert gpu_stage[name]==cpu_stage[name]
    assert sha(gpu_stage['preparation/CONTROLS_SHA256.json'])=='9b20b092b2be1f2426364d98d43b40e71c93a188bdd0949b0891aa2541601a2d'
    assert sha(gpu_stage['execution/CONTROLS_SHA256.json'])=='082bc23626b9db413e81e576c0c0cf67cbe2e7b6d76dc8fea1780fcec07301e8'
    assert cpu_stage['gpu-result.tar.gz']==gpu_raw
    assert sha(gpu_stage['pbr-evidence.tar.gz'])=='0dc619264334c45aabafc398b42202df717dd07e58cfcfab19080b5a0cb82739'
    assert gpu_stage['pbr-evidence.tar.gz']==cpu_stage['pbr-evidence.tar.gz']
    binding=json.loads(gpu_stage['preparation/BINDINGS.json'])
    source=files(gpu_stage['source.tar.gz']);source_index=json.loads(source['SOURCE_SHA256.json'])
    assert len(source_index)==596 and sha(source['SOURCE_SHA256.json'])==binding['source_manifest_sha256']
    assert all(sha(source[n])==h for n,h in source_index.items())
    controller=json.loads(gpu['controller/controller-receipt.json'])
    assert controller['completed'] and controller['stage_unchanged'] and controller['actual_controller_OS_returncode'] is None
    assert [r['actual_parent_returncode'] for r in controller['actual_parents']]==[1,0]
    capture={};array_count=0
    for backend,code,count in (('cuda',1,0),('jax',0,8)):
        parent=json.loads(gpu[backend+'/device-parent-receipt.json'])
        value=json.loads(gpu[backend+'/device/capture-receipt.json'])
        assert parent['completed'] and parent['returncode']==code and parent['error'] is None
        assert parent['device_receipt_sha256']==sha(gpu[backend+'/device/capture-receipt.json'])
        assert value['backend']==backend and len(value['cases'])==count
        assert value['source_controls_evidence_unchanged'] and not value['forbidden_cpu_reference_calls']
        assert value['source_manifest_sha256']==binding['source_manifest_sha256']
        assert value['controls_manifest_sha256']==sha(gpu_stage['preparation/CONTROLS_SHA256.json'])
        assert value['actual_model_returns']==count
        capture[backend]=value
    assert capture['cuda']['actual_model_attempts']==1 and 'cannot open source file' in capture['cuda']['error'] and 'math.h' in capture['cuda']['error']
    assert capture['jax']['actual_model_attempts']==capture['jax']['actual_model_returns']==8 and capture['jax']['passed']
    assert capture['jax']['calls']['actual_device_inverse']['returned']==capture['jax']['calls']['device_phase']['returned']>0
    for name in binding['cases']:
        meta=json.loads(gpu['jax/device/'+name+'/result.json'])
        assert meta['actual_device_barrier_complete'] and meta['actual_encoded_parameters_phase_duration_echo_exact'] and meta['initial_phase_stock_payload_exact']
        assert set(meta['own_process_gpu_uuids'])=={'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'}
        assert len(meta['arrays'])==75
        array_count+=packet(gpu['jax/device/'+name+'/result.npz'],dict(sha256=meta['npz_sha256'],arrays=meta['arrays']))
    qstat=(BASE/(LABEL+'-comparison-closed')/'qstat.stdout').read_text()
    assert all(v in qstat for v in ('Job Id: 1820.manager','job_state = F','Exit_status = 1','Stageout_status = 0','run_count = 1'))
    assert cpu['worker-exit.txt'].strip()==cpu['pbs-command-exit.txt'].strip()==b'1'
    assert cpu['setup-exit.txt'].strip()==cpu['stage-after-exit.txt'].strip()==b'0'
    for directory,prefix in (('preparation','preparation-controls'),('execution','execution-controls')):
        controls=json.loads(cpu_stage[directory+'/CONTROLS_SHA256.json'])
        for name in [*controls,'CONTROLS_SHA256.json']:
            assert cpu[prefix+'/'+name]==cpu_stage[directory+'/'+name]
    index=json.loads(cpu_stage['stage-inventory.json'])
    for name in ('stage-before.json','stage-after.json'):
        check=json.loads(cpu[name]);assert check['passed'] and check['actual']==check['expected']==index
    parent=json.loads(cpu['run/comparison-parent-receipt.json'])
    assert parent['comparison_child_attempts']==1 and parent['comparison_child_returncode']==1 and parent['stage_unchanged']
    assert cpu['worker.stderr']==cpu['run/comparison.stderr']==b''
    comparison=json.loads(cpu['run/comparison/comparison.json'])
    assert not comparison['passed'] and comparison['gpu_capture_status']==dict(cuda=False,jax=True)
    assert len(comparison['cases'])==8
    cases=[]
    for row in comparison['cases']:
        assert not row['passed'] and not row['cuda32_jax32']['passed'] and not row['backends']['cuda']['passed']
        jax=row['backends']['jax']
        assert jax['passed'] and jax['physical64']['passed'] and jax['hard_ledgers']['passed'] and jax['original_behavior']['passed']
        fields=jax['physical64']['fields']
        cases.append(dict(case=row['case'],jax_physical64_passed=True,original_hard_ledgers=jax['hard_ledgers'],
            original_behavior_passed=True,temperature_maximum_absolute_difference_k=fields['temperature']['maximum_absolute_difference'],
            layer_mass_absolute_difference_kg_m2={k:fields[k+'.layer_mass_kg_m2']['maximum_absolute_difference'] for k in ('saturated','perched')},
            layer_enthalpy_absolute_difference_j_m2={k:fields[k+'.layer_enthalpy_j_m2']['maximum_absolute_difference'] for k in ('saturated','perched')},
            total_mass_signed_difference_kg_m2={k:fields[k+'.drained_kg_m2']['difference'] for k in ('saturated','perched')},
            numpy32_additional_sameprecision_passed=jax['numpy32_sameprecision_diagnostic']['passed'],
            numpy32_additional_failed_fields={k:v for k,v in jax['numpy32_sameprecision_diagnostic']['fields'].items() if not v['passed']}))
    readout=dict(actual_GPU_parent_returncodes=[1,0],actual_GPU_worker_returncodes=[1,0],GPU_timeouts=0,
        original_controller_OS_returncode=None,cuda_complete_cases=0,jax_complete_cases=8,
        cuda_failure='First pure-diagnosis NVRTC compile cannot open math.h; one device inverse returned, no full adapter returned',
        jax_worker_seconds=capture['jax']['seconds'],jax_parent_seconds=controller['actual_parents'][1]['parent_receipt']['seconds'],
        actual_comparison_job='1820.manager',actual_comparison_PBS_state='F',actual_comparison_PBS_exit=1,
        actual_comparison_Stageout_status=0,actual_comparison_child_exit=1,comparison_seconds=parent['seconds'],
        primary_cuda32_jax32_validated=False,overall_validation_passed=False,source_files=596,
        original_preparation_controls_unchanged=True,actual_input_and_parameter_echo_exact=True,
        JAX_original_physical64_and_hard_budgets_passed=8,JAX_opaque_arrays_verified=array_count,
        cases=cases,scope='Original GPU attempt and actual EHPC comparison. CUDA failed compilation; JAX physical/hard checks succeeded. No primary device pair, full column, year or production acceptance; no rerun. Numeric statistics copied from already-computed EHPC JSON only.')
    verification=dict(evidence_verified=True,overall_model_validation_passed=False,gpu_stage_sha256=GPU_STAGE,
        comparison_stage_sha256=CPU_STAGE,original_GPU_result_sha256=GPU_RESULT,original_comparison_result_sha256=CPU_RESULT,
        actual_GPU_parent_returncodes=[1,0],actual_comparison_F_exit=1,Stageout_status=0,
        source_files=596,preparation_controls=5,execution_controls=11,JAX_payload_headers_and_hashes_verified=array_count,
        source_controls_inputs_unchanged=True,local_numerical_decode=False,local_model_runs=0)
    items={'executed-gpu-stage.tar.gz':gpu_stage_raw,'executed-comparison-stage.tar.gz':cpu_stage_raw,
           'original-gpu-result.tar.gz':gpu_raw,'original-comparison-result.tar.gz':cpu_raw,
           'readout.json':encode(readout),'verification.json':encode(verification)}
    for name,raw in gpu_stage.items():
        if name.startswith(('preparation/','execution/')):items[name]=raw
    for directory in (BASE/(LABEL+'-gpu-closed'),BASE/(LABEL+'-comparison-closed')):
        for path in directory.iterdir():
            if path.is_file() and not path.name.endswith('.tar.gz'):
                items['closure/'+directory.name+'/'+path.name]=path.read_bytes()
    for name in (LABEL+'-gpu-deployment.json',LABEL+'-comparison-deployment.json',LABEL+'-gpu-stage-package.json',
        LABEL+'-gpu-stage-b-package.json',LABEL+'-comparison-stage-package.json','verify_drainage_1704_pc.py',
        'clm-drainage-warm-phase-pb-r-actual-independent-review-pc.json','deploy_drainage_device_pbs_gpu.py',
        'deploy_drainage_device_pbs_compare.py','collect_drainage_device_pbs_compare_closed.py',Path(__file__).name):
        items['provenance/'+name]=(BASE/name).read_bytes()
    for prefix in (LABEL+'-gpu-deploy-',LABEL+'-compare-deploy-'):
        for path in BASE.glob(prefix+'*'):
            if path.is_file():items['deployment/'+path.name]=path.read_bytes()
    initial=files((BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes())
    assert sha((BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes())=='590742053b45beeb8d983072d5cd77247a9f2d1187a4abd7688713ede4547aed'
    for name in ('execution/run_device_parent_pbs.py','execution/CONTROLS_SHA256.json','stage-inventory.json'):
        items['unexecuted-initial-stage/'+name]=initial[name]
    items['artifact-inventory.json']=encode({name:dict(sha256=sha(raw),bytes=len(raw)) for name,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,raw in sorted(items.items()):
                member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual PB-s CUDA worker1 compile failure / JAX worker0 eight complete encoded32 cases; EHPC1820 F1/Stageout0 explicit missing-CUDA pairing and successful JAX original physical/hard-budget checks. All original inputs/controls preserved; no model repair, full-device-pair, column, annual or production credit.')
    (BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package))
    print(json.dumps(package))


if __name__=='__main__':main()

from pathlib import Path
import datetime,hashlib,io,json,os,tarfile,time
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');source=b/'material-numpy-day-b';r=b/'material-numpy-day-preserve-b';protocol=json.loads((source/'protocol.json').read_text());assert protocol['pbs_job']=='145.manager' and protocol['node']==os.uname().nodename
scratch=Path('/var/tmp/pbs.145.manager/model');sha=lambda raw:hashlib.sha256(raw).hexdigest();rows=[]
for row in json.loads((b/'fluxnet-first-climate-cycle-20261017-h/batch.json').read_text())['cases']:
 folder=scratch/row['case'];error=None;saved=None
 for attempt in range(3):
  try:
   raw=(folder/'report.json').read_bytes();d=json.loads(raw);assert d['steps_requested']==17520 and d['source_unchanged'];files=[('report.json',raw)]
   for key,digest in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:
    p=folder/d[key];assert p.parent==folder;payload=p.read_bytes();assert sha(payload)==d[digest];files.append((p.name,payload))
   archive=r/(row['case']+'.tar.gz')
   with tarfile.open(archive,'w:gz') as t:
    for name,payload in files:
     member=tarfile.TarInfo(name);member.size=len(payload);t.addfile(member,io.BytesIO(payload))
   saved=dict(case=row['case'],status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],report_sha256=sha(raw),archive=archive.name,archive_sha256=sha(archive.read_bytes()));break
  except (FileNotFoundError,AssertionError) as e:error=type(e).__name__+': '+str(e);time.sleep(1)
 rows.append(saved if saved is not None else dict(case=row['case'],snapshot_unavailable=error))
record=dict(scope='One read-only same-node snapshot of original145 committed NumPy report/trace/pickle generations, all raw hashes verified. No source/model/input/process/initial-state changes or restart; snapshot result is not original CLI completion, full year/spinup or all-four comparison.',source_pbs='145.manager',preserver_pbs=os.environ['PBS_JOBID'],node=os.uname().nodename,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_controller_terminal=(source/'exit.json').exists(),cases=rows)
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

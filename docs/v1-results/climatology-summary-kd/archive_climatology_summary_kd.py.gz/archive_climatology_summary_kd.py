from pathlib import Path
import hashlib,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-cold-summary-kd';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'dispatch.json').read_text());raw=subprocess.check_output(['qstat','-xf',launch['pbs_job']],text=True);assert re.search(r'^\s*job_state = F\s*$',raw,re.M) and re.search(r'^\s*Exit_status = 0\s*$',raw,re.M) and (r/'pbs-exit.txt').read_text().strip()=='0';(r/'actual-pbs-qstat.txt').write_text(raw);d=json.loads((r/'summary.json').read_text());assert d['all12_independentpassed'] and d['source_unchanged'] and d['physical_step_pairs']==576 and all(sha(r/n)==h for n,h in launch['controls_sha256'].items());archive=b/'climatology-summary-kd-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():n=p.relative_to(r).as_posix();inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
    p=Path(__file__);inventory[p.name]=sha(p);tf.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive) as tf:
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
v=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),scope='ActualEHPC1186F0 summaryof1185independentJN12x48audit, all13physicaltraces/daily/eachCNpool/actualinputfeedthrough andhardMHCN retained. Nonnzero-relative versusnearzero-absolute explicitlyseparated; backend agreement only, not observederror/full17520/spinup/SOC/releaseacceptance.');(b/'climatology-summary-kd-package.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)

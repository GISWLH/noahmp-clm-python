from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();names=[]
for label in ['b','c']:
    root=base/('ctsm-dependency-plan-'+label);r=json.loads((root/'exit.json').read_text());assert r['returncode']==(1 if label=='b' else 0)
    for n in ['launch.json','protocol.json','progress.json','exit.json','solve.json','solve.stderr.txt','controller.log']+[('launch_ctsm_dependency_plan_a.py' if label=='b' else 'launch_ctsm_dependency_plan_c.py')]:names.append((root/n,'plan-'+label+'/'+n))
root=base/'ctsm-portable-build-b';r=json.loads((root/'exit.json').read_text());assert r['status']=='complete' and r['package_count']==111 and r['archive_sha256']==sha(base/'ctsm-portable-env-b.tar.gz')
assert r['original_a_archive_sha256']==sha(base/'ctsm-portable-env-a.tar.gz')=='8f1d5ba12ed58a68e18293c182991d84cacbccd53f7dd8c86e06f687ea719769'
for n in ['launch_ctsm_portable_env_b.py','launch.json','controller.log','progress.json','stages.json','exit.json','package-lock.json','explicit-lock.txt','install.stdout.txt','install.stderr.txt','pack.stdout.txt','pack.stderr.txt']:names.append((root/n,'build-b/'+n))
names.append((Path(__file__),Path(__file__).name));archive=base/'ctsm-portable-b-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,name in names:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(files=len(names),path=str(archive),sha256=sha(archive))))

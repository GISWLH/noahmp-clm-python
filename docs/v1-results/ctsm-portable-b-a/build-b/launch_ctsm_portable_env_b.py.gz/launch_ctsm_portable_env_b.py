from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');plan=base/'ctsm-dependency-plan-c';cache=base/'ctsm-dependency-plan-a/package-cache';root=base/'ctsm-portable-build-b';prefix=base/'ctsm-portable-env-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);assert not prefix.exists();(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    command=[sys.executable,'-u',str(root/Path(__file__).name),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    r=dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Prepare separate portable compiler/NetCDF/Perl XML environment from exact solved public package URLs; original A environment/archive retained. Compilation/runtime remains on EHPC.')
    (root/'launch.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(0)
solution=json.loads((plan/'solve.json').read_text());receipt=json.loads((plan/'exit.json').read_text());assert solution['success'] and solution['dry_run'] and receipt['returncode']==0 and not receipt['environment_created']
metadata={}
for original in [base/'ctsm-dependency-plan-a/solve.json',plan/'solve.json']:
    for v in json.loads(original.read_text())['actions'].get('FETCH',[]):
        key=(v['name'],v['version'],v['build'])
        if key in metadata:assert metadata[key]['sha256']==v['sha256']
        metadata[key]=v
packages=[metadata[(v['name'],v['version'],v['build_string'])] for v in solution['actions']['LINK']]
assert len(packages)==len({v['name'] for v in packages}) and any(v['name']=='perl-xml-libxml' for v in packages)
for v in packages:assert any(v['url'].startswith('https://conda.anaconda.org/'+channel+'/') for channel in ['conda-forge','bioconda']) and '?' not in v['url'] and len(v['sha256'])==64 and len(v['md5'])==32
old=json.loads((base/'ctsm-portable-build-a/package-lock.json').read_text())['packages'];old_by_name={v['name']:v for v in old}
changes=[dict(name=v['name'],old=None if v['name'] not in old_by_name else [old_by_name[v['name']]['version'],old_by_name[v['name']]['build']],new=[v['version'],v['build']]) for v in packages if v['name'] not in old_by_name or (v['version'],v['build'])!=(old_by_name[v['name']]['version'],old_by_name[v['name']]['build'])]
lock=root/'explicit-lock.txt';lock.write_text('@EXPLICIT\n'+'\n'.join(v['url']+'#'+v['md5'] for v in packages)+'\n')
(root/'package-lock.json').write_text(json.dumps(dict(solve_sha256=sha(plan/'solve.json'),target_glibc='2.17',packages=packages,changes_from_a=changes),indent=2)+'\n')
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(CONDA_PKGS_DIRS=str(cache),CONDA_OVERRIDE_GLIBC='2.17',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
stages=[];begun=time.monotonic()
def run(stage,command):
    start=time.monotonic()
    with (root/(stage+'.stdout.txt')).open('w') as out,(root/(stage+'.stderr.txt')).open('w') as err:p=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=err)
    (root/'progress.json').write_text(json.dumps(dict(status='running',stage=stage,pid=p.pid,command=command),indent=2)+'\n');code=p.wait()
    stages.append(dict(stage=stage,command=command,returncode=code,seconds=time.monotonic()-start));(root/'stages.json').write_text(json.dumps(stages,indent=2)+'\n')
    if code:
        (root/'exit.json').write_text(json.dumps(dict(status='failed',stages=stages,seconds=time.monotonic()-begun),indent=2)+'\n');raise SystemExit(code)
run('install',['/home/lhwang/anaconda3/bin/conda','create','--yes','--no-default-packages','--json','--override-channels','--channel','https://conda.anaconda.org/conda-forge','--channel','https://conda.anaconda.org/bioconda','--prefix',str(prefix),'--file',str(lock)])
actual={}
for p in (prefix/'conda-meta').glob('*.json'):
    v=json.loads(p.read_text());actual[(v['name'],v['version'],v['build'])]=v
assert set(actual)=={(v['name'],v['version'],v['build']) for v in packages}
for v in packages:assert (cache/v['fn']).is_file() and sha(cache/v['fn'])==v['sha256']
dest=base/'ctsm-portable-env-b.tar.gz';assert not dest.exists()
run('pack',[str(prefix/'bin/conda-pack'),'--prefix',str(prefix),'--output',str(dest),'--format','tar.gz','--compress-level','4'])
value=dict(status='complete',scope='Separate portable environment with exact downloaded package SHA256 checks; not yet an EHPC smoke test or official model build/output.',package_count=len(packages),changes_from_a=changes,stages=stages,seconds=time.monotonic()-begun,archive=str(dest),archive_bytes=dest.stat().st_size,archive_sha256=sha(dest),package_lock_sha256=sha(root/'package-lock.json'),source_solver_sha256=sha(plan/'solve.json'),original_a_archive_sha256=sha(base/'ctsm-portable-env-a.tar.gz'))
(root/'exit.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

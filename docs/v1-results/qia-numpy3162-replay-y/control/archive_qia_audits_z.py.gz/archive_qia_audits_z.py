from pathlib import Path
import hashlib,json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='boundary-x':
    name='qia-recovery-c-boundary-audit-x';r=b/name;d=json.loads((r/'receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and d['pbs_job']=='358.manager'
    assert len(d['cases'])==2 and all(c['passed'] and c['saved_fields']==30 and c['before_state_fields_exact']==23 for c in d['cases'])
    controls=['dispatch_qia_boundary_audit_x.py'];scope='Actual EHPC358 compute002 first continued CUDA step audit, bothcases all23 primary before exact, all30 bootstrap fields hash-bound to successful48, original perstep/cumulative MHCN and impurity guards. Boundary input archive5ae2336d58fb936238fe1a13fd1e2e942ac0f22c063a9e94dbcf3b1082794383 retained separately. Not full year or science acceptance.'
elif mode=='numpy3162-y':
    name='qia-numpy3162-replay-y';r=b/name;d=json.loads((r/'receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['diagnosis_complete'] and d['pbs_job']=='359.manager' and all(c['source_unchanged'] for c in d['results'])
    controls=['dispatch_qia_numpy3162_y.py'];scope='Actual EHPC359 separate old519/current563 one-step diagnostics of immutable oldfailed3162. Original failedyearf95255859d4790a3fb1fbcbb3298b8f3aa3e43a71e28363cbfafd9944e3a867d retained separately. Do not reinterpret diagnostic as annual continuation.'
else:raise ValueError(mode)
a=b/(name+'-evidence.tar.gz');assert not a.exists();meta=b/(name+'-archive-scope.json');assert not meta.exists();meta.write_text(json.dumps(dict(scope=scope),indent=2)+'\n')
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in [*controls,Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
    tf.add(meta,arcname='archive-scope.json',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

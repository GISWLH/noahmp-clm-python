from pathlib import Path
import hashlib,json,os,pickle,subprocess,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-numpy3162-replay-y';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if len(sys.argv)>1:
    label=sys.argv[1];s=Path(os.environ['TMPDIR'])/label;sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
    import run_fluxnet_column as runner
    from noahmp_clm.column import Forcing
    from noahmp_clm.physics.canopy_most import MOSTGeometry
    from noahmp_clm.physics.photosynthesis import LeafParameters
    # Own hash-verified repository checkpoint, never an external pickle.
    p=b/'qia-kink-numpy-year-h';report=json.loads((p/'trajectory/report.json').read_text());assert report['status']=='failed' and report['steps_completed']==report['failed_index']==3162
    cp=p/'trajectory'/report['checkpoint_file'];assert sha(cp)==report['checkpoint_sha256'];state,initial,net,bounds,maximum,stepmax,index=pickle.loads(cp.read_bytes());assert index==3162
    inputs=b/'qia-stem-inputs-a/inputs';config_path=inputs/'CN-Qia-stem-config.json';config=json.loads(config_path.read_text());metadata=json.loads((inputs/'CN-Qia.json').read_text())
    assert sha(config_path)==report['configuration_sha256'] and sha(inputs/'CN-Qia.npz')==report['forcing_npz_sha256'] and sha(inputs/'CN-Qia.json')==report['forcing_manifest_sha256']
    with np.load(inputs/'CN-Qia.npz',allow_pickle=False) as z:data=dict(z)
    stamps=runner.validate_input(data,metadata,inputs/'CN-Qia.npz');f=Forcing(*data['forcing'][index]);co2,mu,diffuse=data['environment'][index];schedule=runner.DepositionSchedule(config);nitrogen=schedule.nitrogen_rate*f.dt
    hydrology=runner.hydrology_configuration(config) if config.get('soil_hydrology') is not None else None
    capacity=runner.capacity_configuration(config) if config.get('canopy_capacity') is not None else None
    optics=None if config.get('canopy_optics') is None else runner.CanopyOptics(**config['canopy_optics']);m=json.loads((s/'SOURCE_SHA256.json').read_text());start=time.monotonic();failure=None;physical=None
    try:
        after,d=runner.step_clm_enthalpy_column(state,f,co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),most_geometry=MOSTGeometry(**config['most_geometry']),phenology_environment=runner.calendar(stamps[index],metadata,config['phenology'] is not None),deposition_rates=schedule.aerosol(stamps[index],f.dt),nitrogen_deposition_gn_m2=nitrogen,**({} if capacity is None else dict(capacity_environment=runner.capacity_environment(stamps[index],metadata,True))),**({} if optics is None else dict(canopy_optics=optics)),**({} if hydrology is None else dict(soil_hydrology=hydrology)))
        incoming,residual,bound=runner.audit_step(state,after,f,d,nitrogen);cumulative=runner.totals(after)-initial-net-incoming;newbounds=bounds+bound;assert np.all(abs(cumulative)<=newbounds)
        (r/(label+'-after.pkl')).write_bytes(pickle.dumps(after));physical=dict(step_m_h_c_n=residual.tolist(),original_step_bounds=bound.tolist(),cumulative_m_h_c_n=cumulative.tolist(),original_cumulative_bounds=newbounds.tolist(),snow_mass_before=state.snow.mass.tolist(),snow_mass_after=after.snow.mass.tolist(),h_wm2=float(d['h']),le_wm2=float(d['le']))
    except Exception as e:
        failure=type(e).__name__+': '+str(e);(r/(label+'-traceback.txt')).write_text(traceback.format_exc())
    result=dict(mode=label,failure=failure,physical=physical,seconds=time.monotonic()-start,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),original_failed_checkpoint_sha256=sha(cp),configuration_sha256=sha(config_path),index=index,time_start=str(data['time_start'][index]))
    (r/(label+'-result.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result,allow_nan=False),flush=True)
    assert result['source_unchanged'];sys.exit(0)
archives={'old519':('qia1110-final-h-source.tar.gz','ffa30e87bc515d0694c9135c8b77d14286112e6da2cf7f4ef6467417319132a0'),'current563':('clm-numerical-recovery-c-source.tar.gz','61b5c5936b57cc6427893bbe6629536aa594ff19733628604f8e2cb98510d84a')}
results=[]
for label,(name,expected) in archives.items():
    s=Path(os.environ['TMPDIR'])/label;s.mkdir();a=b/name;assert sha(a)==expected
    with tarfile.open(a) as tf:tf.extractall(s,filter='data')
    m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items())
    with (r/(label+'-model.log')).open('x') as log:code=subprocess.run([sys.executable,'-u',str(Path(__file__)),label],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
    assert code==0,(label,code);results.append(json.loads((r/(label+'-result.json')).read_text()))
assert results[0]['failure']=='RuntimeError: Coupled snow/soil enthalpy solve failed: 232736.225 J/m2'
record=dict(diagnosis_complete=True,current_step_succeeded=results[1]['failure'] is None,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,results=results,scope='Separate-process exact immutable old519H failed3162 one-step replay vs current563C physical source. Original state/config/forcing/budgets fixed. Diagnostic only, no failed annual resume/accepted scientific trajectory.')
(r/'receipt.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(record,allow_nan=False),flush=True)

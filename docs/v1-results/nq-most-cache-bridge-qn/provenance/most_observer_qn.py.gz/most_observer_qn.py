"""External original-three-node observer and strict EHPC reference reader."""
from dataclasses import fields,is_dataclass
from enum import Enum
import inspect
import io
import json
from pathlib import Path
import pickle
import sys
import traceback
import types

from most_contract_qn import sha,save

EXPECTED_NAMES={'test_qia_stagnation_jax_reference_and_conservation[float32]','test_qia_stagnation_jax_reference_and_conservation[float64]','test_qia_stagnation_cuda_jax_same_precision'}

class MostObserver:
    def __init__(self,source,output,reference_files,np,cp,jax):
        self.source=source.resolve();self.output=output;self.reference_files=reference_files;self.np=np;self.cp=cp;self.jax=jax
        self.current_node=None;self.installed=False;self.nodes=[];self.reports=[];self.cache_hits=dict(float32=0,float64=0)
        self.cache_requests=[];self.native_calls={};self.disabled_aliases=[];self.forbidden_attempts=[];self.bridge_errors=[]
        self.expected={}
        for precision in self.cache_hits:
            prefix='actual-result/reference/'+precision
            inp=json.loads(reference_files[prefix+'-input.json']);out=json.loads(reference_files[prefix+'.json'])
            for suffix,meta in [('-input',inp),('',out)]:
                assert sha(reference_files[prefix+suffix+'.pkl'])==meta['pickle_sha256'] and sha(reference_files[prefix+suffix+'.npz'])==meta['npz_sha256']
            self.expected[precision]=dict(input_tree=inp['tree'],output_pickle=reference_files[prefix+'.pkl'],input_metadata=inp,output_metadata=out)
    def encoded(self,value):
        arrays={};np=self.np
        def walk(v,key):
            if isinstance(v,(np.ndarray,np.generic,self.cp.ndarray,self.jax.Array)):
                if isinstance(v,self.cp.ndarray):q=self.cp.asnumpy(v)
                else:
                    if hasattr(v,'block_until_ready'):v.block_until_ready()
                    q=np.asarray(v)
                assert q.dtype.kind!='O';arrays[key]=q
                return dict(kind='array',key=key,dtype=q.dtype.str,shape=list(q.shape),c_order_sha256=sha(q.tobytes(order='C')))
            if is_dataclass(v):return dict(kind='dataclass',module=type(v).__module__,name=type(v).__name__,fields={f.name:walk(getattr(v,f.name),key+'/'+f.name) for f in fields(v)})
            if isinstance(v,dict):
                assert all(type(k)is str for k in v);return dict(kind='dict',items={k:walk(x,key+'/'+k) for k,x in v.items()})
            if isinstance(v,(tuple,list)):return dict(kind=type(v).__name__,items=[walk(x,key+'/'+str(i)) for i,x in enumerate(v)])
            if isinstance(v,Enum):return dict(kind='enum',module=type(v).__module__,name=type(v).__name__,value=walk(v.value,key+'/value'))
            if type(v)is float:return dict(kind='float',hex=v.hex())
            if v is None or type(v)in(str,int,bool):return dict(kind=type(v).__name__,value=v)
            raise TypeError('Unsupported original request/return '+str(type(v)))
        return walk(value,'value'),arrays
    def packet(self,name,value):
        tree,arrays=self.encoded(value);path=self.output/name;path.parent.mkdir(parents=True,exist_ok=True)
        self.np.savez_compressed(path.with_suffix('.npz'),**arrays)
        metadata=dict(schema='QN-host-encoded-native-v1',tree=tree,array_count=len(arrays),npz_sha256=sha(path.with_suffix('.npz').read_bytes()))
        save(path.with_suffix('.json'),metadata);return metadata
    def cached_reference(self,*args,**kwargs):
        # All actual values, dtypes, geometry fields, scalar hex and ordering
        # must match one independent original request; no fallback computation.
        tree,_=self.encoded(dict(args=args,kwargs=kwargs))
        matches=[p for p,v in self.expected.items() if tree==v['input_tree']]
        record=dict(nodeid=self.current_node,input_tree=tree,matches=matches)
        self.cache_requests.append(record)
        try:
            assert len(matches)==1,'Unknown or ambiguous reference request'
            precision=matches[0];assert self.cache_hits[precision]==0,'Duplicate reference request'
            self.cache_hits[precision]+=1;record['served']=precision
            return pickle.loads(self.expected[precision]['output_pickle'])
        except BaseException:
            self.bridge_errors.append(traceback.format_exc());raise
    def no_cpu(self,*args,**kwargs):
        self.forbidden_attempts.append(dict(nodeid=self.current_node,reason='Actual NumPy physical forward attempted'))
        raise AssertionError('GPU semantic test must read exact independent EHPC reference; no CPU forward')
    def install(self,module):
        import test_gpu_clm_bgc_column as helper
        from noahmp_clm import clm_enthalpy_driver as driver
        from noahmp_clm.physics import richards
        targets=(helper.reference,helper.step_clm_enthalpy_column,driver.step_clm_enthalpy_column,richards.redistribute_soil_enthalpy)
        for loaded in list(sys.modules.values()):
            if not isinstance(loaded,types.ModuleType):continue
            path=vars(loaded).get('__file__')
            if not isinstance(path,str):continue
            try:inside=Path(path).resolve().is_relative_to(self.source)
            except (OSError,ValueError):continue
            if not inside:continue
            for name,value in list(vars(loaded).items()):
                if any(value is original for original in targets):
                    self.disabled_aliases.append(dict(module=loaded.__name__,name=name,original_module=getattr(value,'__module__',None),original_name=getattr(value,'__name__',None)))
                    setattr(loaded,name,self.no_cpu)
        # The only permitted reference callable is this exact cache reader.
        assert 'reference' in vars(module);module.reference=self.cached_reference
        from noahmp_clm.gpu import clm_bgc_column as jm
        from noahmp_clm.gpu.cuda import clm_bgc_column as cm
        self.wrap_native(jm,'step_clm_bgc_columns_jax','jax')
        self.wrap_native(cm,'step_clm_bgc_columns_cuda','cuda')
        self.installed=True
    def wrap_native(self,module,name,backend):
        original=getattr(module,name)
        assert Path(original.__code__.co_filename).resolve().is_relative_to(self.source/'src')
        def wrapped(*args,**kwargs):
            precision=self.np.dtype(args[0].dtype).name
            parity='test_qia_stagnation_cuda_jax_same_precision' in self.current_node
            tag=backend+'-'+precision+('-parity' if parity else '-reference')
            assert tag not in self.native_calls,'Duplicate/unexpected original native call'
            row=dict(nodeid=self.current_node,backend=backend,dtype=precision,actual_calls_started=0,actual_calls_returned=0,original_function_module=original.__module__,original_function_name=original.__name__)
            self.native_calls[tag]=row;self.packet('native/'+tag+'-input',dict(args=args,kwargs=kwargs));row['actual_calls_started']=1
            try:
                answer=original(*args,**kwargs);row['actual_calls_returned']=1
                self.packet('native/'+tag,answer);return answer
            except BaseException:
                row['exception']=traceback.format_exc();raise
        setattr(module,name,wrapped)
    def pytest_collection_finish(self,session):
        self.nodes=[dict(nodeid=i.nodeid,name=i.name,path=str(i.path.resolve())) for i in session.items]
        assert len(self.nodes)==3 and {i['name'] for i in self.nodes}==EXPECTED_NAMES
        assert all(Path(i['path'])==self.source/'tests/test_gpu_most_stagnation.py' for i in self.nodes)
        save(self.output/'collected-original3.json',self.nodes)
    def pytest_runtest_setup(self,item):
        self.current_node=item.nodeid
        if not self.installed:self.install(item.module)
        assert item.module.reference==self.cached_reference
    def pytest_runtest_logreport(self,report):
        row=dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome,wasxfail=getattr(report,'wasxfail',None),duration=report.duration)
        if report.failed or report.skipped:row['longrepr']=str(report.longrepr)
        self.reports.append(row);save(self.output/'pytest-node-reports.json',self.reports)
    def receipt(self):
        return dict(collected_nodes=self.nodes,reports=self.reports,reference_cache_hits=self.cache_hits,complete_actual_reference_requests=self.cache_requests,native_original_calls=self.native_calls,disabled_actual_CPU_aliases=self.disabled_aliases,forbidden_CPU_attempts=self.forbidden_attempts,bridge_errors=self.bridge_errors,NumPy_physical_forward_calls=0,scope='External exact reference reader and native observer; original three-node test body/gates unchanged. Numerical independent EHPC audit remains separate.')

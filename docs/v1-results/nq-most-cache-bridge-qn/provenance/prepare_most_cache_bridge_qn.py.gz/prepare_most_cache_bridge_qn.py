"""Metadata-only freeze of the original three-node MOST strict-cache stage."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
OLD=BASE/'nq-transport-trace-qj-execution'
PREP=BASE/'nq-most-cache-bridge-qn-preparation'
NEW=BASE/'nq-most-cache-bridge-qn-execution'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()


def main():
    PREP.mkdir(exist_ok=False);NEW.mkdir(exist_ok=False)
    source=(BASE/'nq-reference-semantics-qh-source.tar.gz').read_bytes()
    evidence=(BASE/'nq-most-reference-qi-evidence.tar.gz').read_bytes()
    assert sha(source)=='004fa5d926d99f076bd5f176eb6b5cc827e64b073026d4d25a27ad2e5a50a0bd'
    assert sha(evidence)=='4adc3fbe6e705330476e3a8c6e6d7207343d3b825e7180e8db21b8f8c211539b'
    with tarfile.open(fileobj=io.BytesIO(evidence)) as t:qi={m.name:t.extractfile(m).read() for m in t if m.isfile()}
    binding=dict(source_archive_sha256=sha(source),source_manifest_sha256='da0c59b35d095df102db32eaebb956c97b02bf02c1553a901d911a0ebd652f80',source_files=584,
                 QI_evidence_archive_sha256=sha(evidence),QI_actual_result_sha256='63a23bf267dcb458dcfc165f7ca989072304f5d19c48bed75e8c75a67d3d897a',QI_job='1843.manager',
                 QI_complete_request_return_packet_sha256={n:sha(qi[n]) for precision in ('float32','float64') for suffix in ('-input.json','-input.pkl','-input.npz','.json','.pkl','.npz') for n in ['actual-result/reference/'+precision+suffix]},
                 CPU5_reuse_proof_sha256=sha((BASE/'nq-reference-semantics-qh-cpu-reuse.json').read_bytes()),
                 historical_original_NQ_evidence_sha256='e6e7c16c8ac7587ccd3ef192d59c422b1754f1d75a06fc33edc3bdd5321b1ba9',historical_NQ_status='399/408; original9failures retained',
                 original_test='tests/test_gpu_most_stagnation.py',original_nodes=3,original_reports=9,planned_reference_cache_requests=dict(float32=1,float64=1),planned_actual_NumPy_physical_calls=0,
                 planned_native_calls=['jax-float32-reference','jax-float64-reference','cuda-float32-parity','jax-float32-parity'],XLA_FLAGS='unset; original default',
                 source_scope='Private root-reviewed QH3file candidate only; 581others exact NM. No checkout changes.')
    for name in ('capture_most_qn.py','most_observer_qn.py','most_contract_qn.py'):
        raw=(BASE/name).read_bytes();ast.parse(raw);assert b'\r' not in raw;(PREP/name).write_bytes(raw)
    (PREP/'BINDINGS.json').write_bytes(encode(binding))
    for name,origin in [('CPU5_REUSE_PROOF.json','nq-reference-semantics-qh-cpu-reuse.json'),('QH_CANDIDATE.patch','nq-reference-semantics-qh-preparation/candidate.patch'),('QH_DIFF_PROOF.json','nq-reference-semantics-qh-preparation/DIFF_PROOF.json')]:
        (PREP/name).write_bytes((BASE/origin).read_bytes())
    (PREP/'README.md').write_text('''# QN original MOST three-node strict-reference bridge — review only

The private QH584 source is unchanged during this run: exactly two QG independently computed Richards NumPy fixtures and two incidental float32 restart-count assertions differ from original NM; all581 other files are exact. This run exercises the original complete three-node GPU MOST module; it does not retest Richards or remove its1J failure. Original NQ399/408 and all9failed records remain historical failures. Original CPU MOST five-node manufactured-stagnation/no-root tests are unchanged and explicitly reuse NR1585 success with the attached dependency identity proof; no new five-node CPU claim.

Actual independent EHPC1843 F0/Stageout0 delivered precisely two original helper/driver forwards, one per dtype. The sealed QI evidence bundle and all twelve input/return packet files are SHA bound here. The external plugin replaces the original GPU test reference callable only with a strict cache reader. Actual argument order, geometry dataclass module/name/fields, every dtype/shape/C-order array hash, Python scalar type/hex and kwargs must equal precisely one complete original QI typed request; unknown, ambiguous, duplicate or wrong-total requests fail with no fallback. A fresh unpickled complete original helper return is supplied, with no arithmetic or synthetic fields. All real imported NumPy driver/redistribution definitions and loaded project aliases, including the helper's imported driver alias, are replaced with fail-only guards before any test call. Input setup remains the original qia_case routine.

Observe native modules transparently for original JAX32, JAX64, CUDA32 parity and JAX32 parity calls: four actual original bodies, each once, full actual request and complete returned tree/arrays saved. Original source test bodies, per-variable reference gates, coefficient/iteration bounds, complete nested1e-6/integer comparison and original M/H/C/N ledger functions execute unchanged. Host assertions are the original light assertions only; all independent full-value numerical/ledger analysis remains a subsequent EHPC posthoc stage tied to the actual raw GPU archive hash, not a claimed independent host audit.

Coverage requires original three named nodes, nine unique setup/call/teardown reports all passed, all3 actual XML testcases/no skips, exactly one cache hit per dtype and all4 saved native returns. Real pytest return code is recorded separately and never normalized to0. Source584, controls and QI bundle must remain byte exact. Default XLA flags are explicitly unset; new precision2 diagnostic flags are excluded.

Lifecycle mechanically reuses reviewed QJ/QF/PB-t launcher, controller and actual-worker parent, now one combined original pytest worker (backend label most),3600s hard maximum, original8GiB GPU/32GiB host startup gates, CUDA1 physical UUID, one thread and three private caches. The actual parent waits and records the worker exit. Detached controller OS status remains unknown; its complete original controller/parent/worker stdout, stderr, launch/status receipts and pytest XML are retained. No deployment or launch occurs in this preparation; root must read the worker and stage before any execution.
''',encoding='utf-8',newline='\n')
    controls={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file()};(PREP/'CONTROLS_SHA256.json').write_bytes(encode(controls))
    diff=[]
    for name in ('launch_device_pbs.py','control_device_pbs.py','run_device_parent_pbs.py'):
        before=(OLD/name).read_text();after=before
        if name=='launch_device_pbs.py':after=after.replace('nq-evidence.tar.gz','reference-evidence.tar.gz')
        if name=='control_device_pbs.py':
            after=after.replace('Two sequential reviewed parents; wait actual parent exits and preserve both.','One reviewed original three-node parent; wait its actual exit.')
            after=after.replace("'--nq',str(ROOT/'nq-evidence.tar.gz')","'--reference',str(ROOT/'reference-evidence.tar.gz')")
            after=after.replace("'cuda-parent.stdout','cuda-parent.stderr','jax-parent.stdout','jax-parent.stderr'","'most-parent.stdout','most-parent.stderr'")
        if name=='run_device_parent_pbs.py':
            after=after.replace('from transport_contract_qj import HERE,GPU,controls,bound_evidence,source_identity,save,sha','from most_contract_qn import HERE,GPU,controls,bound_reference,source_identity,save,sha')
            after=after.replace("('source','nq','output')","('source','reference','output')").replace("choices=('cuda','jax')","choices=('most',)")
            after=after.replace('bound_evidence(a.nq,binding)','bound_reference(a.reference,binding)').replace('/tmp/nq-transport-trace-qj-','/tmp/nq-most-cache-bridge-qn-')
            after=after.replace("env.pop('LD_LIBRARY_PATH',None)","env.pop('LD_LIBRARY_PATH',None);env.pop('XLA_FLAGS',None)")
            after=after.replace('capture_transport_trace_qj.py','capture_most_qn.py').replace("'--nq',str(a.nq.resolve())","'--reference',str(a.reference.resolve())")
        ast.parse(after);assert '\r' not in after;(NEW/name).write_text(after,encoding='utf-8',newline='\n')
        diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='QJ/'+name,tofile='QN/'+name))
    policy=dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),source_archive_sha256=sha(source),source_manifest_sha256=binding['source_manifest_sha256'],evidence_archive_sha256=sha(evidence),
                root='/home/lhwang/work/noahmp-v1/nq-most-cache-bridge-qn',temporary='/tmp/nq-most-cache-bridge-qn-20261026',gpu_uuid='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452',backend_order=['most'],maximum_worker_seconds=3600,
                single_launch=True,automatic_retry=False,original_pytest_nodes=3,actual_native_calls=4,actual_NumPy_physical_calls=0,reference_cache_calls=2,XLA_FLAGS='unset',prepared_only=True,root_pre_execution_review_pending=True)
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(policy));(NEW/'QJ_TO_QN.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
    (NEW/'README.md').write_text('One original MOST complete3node worker, two strict independent cache requests, four original native calls. Mechanical QJ lifecycle adaptation only; actual worker3600s, original resource/UUID/privatecache gates, default XLAflags. Prepared but not deployed/launched. Independent full numerical/ledger EHPC audit remains required.\n',encoding='utf-8',newline='\n')
    execution={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir()) if p.is_file()};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(execution))
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()};items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()})
    items.update({'source.tar.gz':source,'reference-evidence.tar.gz':evidence});items['stage-inventory.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/'nq-most-cache-bridge-qn-gpu-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for name,raw in sorted(items.items()):
            m=tarfile.TarInfo(name);m.size=len(raw);m.mode=0o644;t.addfile(m,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    result=dict(passed=True,stage_sha256=sha(target.read_bytes()),stage_files=len(items),preparation_controls=len(controls),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),execution_controls=len(execution),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),source584_QH_exact=True,QI_evidence_exact=True,original_nodes=3,original_reports=9,planned_native_calls=4,planned_NumPy_physical_calls=0,root_review_pending=True,launched=False,numerical_executed=False)
    (BASE/'nq-most-cache-bridge-qn-stage-package.json').write_bytes(encode(result));print(json.dumps(result))


if __name__=='__main__':main()

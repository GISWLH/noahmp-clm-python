"""Recover two missing SCP metadata files; verify same QN terminal/release."""
import base64
import json
from pathlib import Path
import subprocess
import time

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent
DEST=BASE/'nq-most-cache-bridge-qn-gpu-closed'
CODE=b"""import json,base64,os,subprocess
from pathlib import Path
r=Path('/home/lhwang/work/noahmp-v1/nq-most-cache-bridge-qn');gpu='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
records={n:base64.b64encode((r/n).read_bytes()).decode() for n in ['controller-receipt.json','launch.json']}
p=subprocess.run(['nvidia-smi','--id='+gpu,'--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader,nounits'],capture_output=True,text=True)
owners=[]
for line in p.stdout.splitlines():
 v=[x.strip() for x in line.split(',')]
 if len(v)>1 and v[1].isdigit():
  path=Path('/proc')/v[1]
  owners.append(dict(pid=int(v[1]),uid=path.stat().st_uid if path.exists() else None))
print(json.dumps(dict(files=records,proc_exists={str(pid):(Path('/proc')/str(pid)).exists() for pid in [886777,886778,886779]},gpu_query=dict(actual_exit=p.returncode,stdout=p.stdout,stderr=p.stderr),GPU_process_owners=owners,current_uid=os.getuid())))
"""


def main():
    started=time.monotonic();command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -']
    r=subprocess.run(command,input=CODE,capture_output=True,timeout=60)
    (DEST/'metadata-recovery.stdout').write_bytes(r.stdout);(DEST/'metadata-recovery.stderr').write_bytes(r.stderr)
    record=dict(actual_exit=r.returncode,seconds=time.monotonic()-started,read_only=True,stdin_sha256=sha(CODE),earlier_SCP_return0_missing_controller_and_launch_preserved=True,earlier_local_collector_status=1)
    assert r.returncode==0,r.stderr.decode(errors='replace');data=json.loads(r.stdout);raw=files((DEST/'gpu-result.tar.gz').read_bytes())
    for name,encoded in data['files'].items():
        value=base64.b64decode(encoded);path=DEST/name
        if path.exists():assert path.read_bytes()==value
        else:path.write_bytes(value)
    assert (DEST/'controller-receipt.json').read_bytes()==raw['controller/controller-receipt.json']
    launch=json.loads((DEST/'launch.json').read_bytes());assert launch['controller_pid']==886777 and launch['stage_sha256']=='1d814fa98e9897922db9777f2ba98674c9fd4069c1daa4cad014fb47db2d3879'
    assert not any(data['proc_exists'].values()) and data['gpu_query']['actual_exit']==0 and all(v['uid']!=data['current_uid'] for v in data['GPU_process_owners'])
    record.update(metadata_hashes={n:sha(base64.b64decode(v)) for n,v in data['files'].items()},release_probe=data,all_three_QN_PIDs_absent=True,own_CUDA1_processes=0,scientific_raw_archive_unchanged=True)
    (DEST/'metadata-recovery.json').write_bytes(encode(record));print(json.dumps({k:v for k,v in record.items() if k!='release_probe'}))


if __name__=='__main__':main()

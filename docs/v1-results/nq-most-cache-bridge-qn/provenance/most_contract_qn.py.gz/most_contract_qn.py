"""Metadata-only QH source and actual independent QI reference bundle contract."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE=Path(__file__).resolve().parent
GPU='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def controls():
    raw=(HERE/'CONTROLS_SHA256.json').read_bytes();d=json.loads(raw)
    assert all(sha((HERE/n).read_bytes())==h for n,h in d.items());return sha(raw)
def source_identity(root,binding):
    raw=(root/'SOURCE_SHA256.json').read_bytes();d=json.loads(raw)
    assert len(d)==584 and sha(raw)==binding['source_manifest_sha256']
    assert all(sha((root/n).read_bytes())==h for n,h in d.items());return d
def bound_reference(path,binding):
    raw=path.read_bytes();assert sha(raw)==binding['QI_evidence_archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        m=t.getmembers();assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts and '\\' not in x.name for x in m) and len({x.name for x in m})==len(m)
        d={x.name:t.extractfile(x).read() for x in m}
    index=json.loads(d['artifact-inventory.json']);assert set(index)==set(d)-{'artifact-inventory.json'} and all(sha(d[n])==v['sha256'] and len(d[n])==v['bytes'] for n,v in index.items())
    receipt=json.loads(d['actual-result/reference/receipt.json']);assert receipt['pbs_job']=='1843.manager' and receipt['source584_exact'] and receipt['controls_exact'] and receipt['physical_calls']==dict(reference_started=2,reference_returned=2,driver_started=2,driver_returned=2)
    assert d['actual-result/worker-exit.txt'].strip()==d['actual-result/pbs-command-exit.txt'].strip()==b'0'
    summary=json.loads(d['actual-result/reference/reference-summary.json']);assert summary['source_manifest_sha256']==binding['source_manifest_sha256'] and set(summary['records'])=={'float32','float64'}
    return d

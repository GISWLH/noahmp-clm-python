"""Original three MOST GPU nodes, strict independent EHPC reference bridge."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

from most_contract_qn import HERE,GPU,sha,save,controls,source_identity,bound_reference


def main():
    parser=argparse.ArgumentParser()
    for name in ('source','reference','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--backend',choices=('most',),required=True);a=parser.parse_args()
    assert os.name!='nt' and sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
    assert os.environ.get('JAX_PLATFORMS')=='cuda' and os.environ.get('JAX_ENABLE_X64','').lower()=='true'
    assert not os.environ.get('XLA_FLAGS'),'Semantic stage uses original default XLA flags'
    assert all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    caches=[Path(os.environ[n]).resolve() for n in ('CUPY_CACHE_DIR','JAX_COMPILATION_CACHE_DIR','CUDA_CACHE_PATH')]
    assert len(set(caches))==3 and all(str(p).startswith('/tmp/nq-most-cache-bridge-qn-') for p in caches)
    free=int(subprocess.check_output(['nvidia-smi','--id='+GPU,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))
    assert free>8192 and available>32*1024*1024,'Original8GiB GPU/32GiB host startup gate'
    assert not a.output.exists();a.output.mkdir()
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());control_hash=controls();manifest=source_identity(a.source,binding)
    refs=bound_reference(a.reference,binding)
    sys.path[:0]=[str(a.source.resolve()/'src'),str(a.source.resolve()/'tests'),str(a.source.resolve()/'benchmarks')]
    import numpy as np  # Transfers/serialization and original lightweight assertions only.
    import cupy as cp
    import jax
    import pytest
    from most_observer_qn import MostObserver,EXPECTED_NAMES
    assert cp.__version__=='14.2.0' and jax.__version__=='0.11.2'
    assert cp.cuda.runtime.getDeviceCount()==1;cp.cuda.Device(0).use();cp.cuda.runtime.free(0)
    jax.config.update('jax_enable_x64',True)
    assert len(jax.devices())==1 and jax.devices()[0].platform=='gpu'
    observer=MostObserver(a.source,a.output,refs,np,cp,jax)
    argv=[str(a.source.resolve()/'tests/test_gpu_most_stagnation.py'),'-vv','-s','-ra','--tb=long',
          '--junitxml='+str(a.output/'original3.xml'),'-o','cache_dir='+str(a.output/'pytest-cache')]
    actual_pytest_returncode=None;error=None;guard_error=None;xml_records=[];started=time.monotonic()
    try:
        actual_pytest_returncode=int(pytest.main(argv,plugins=[observer]))
        # Preserve the real pytest status even when coverage/delivery also fails.
        cp.cuda.get_current_stream().synchronize();jax.effects_barrier()
        xml=ET.fromstring((a.output/'original3.xml').read_bytes())
        xml_records=[dict(name=x.attrib['name'],classname=x.attrib.get('classname'),time=x.attrib.get('time'),
                          children=[y.tag for y in x]) for x in xml.iter('testcase')]
        assert len(xml_records)==3 and {x['name'] for x in xml_records}==EXPECTED_NAMES
        assert not any('skipped' in x['children'] for x in xml_records)
        assert len(observer.reports)==9 and all(sum(r['nodeid']==n['nodeid'] and r['when']==stage for r in observer.reports)==1 for n in observer.nodes for stage in ('setup','call','teardown'))
        assert all(r['outcome']=='passed' and r['wasxfail'] is None for r in observer.reports)
        assert observer.cache_hits==dict(float32=1,float64=1)
        expected={'jax-float32-reference','jax-float64-reference','cuda-float32-parity','jax-float32-parity'}
        assert set(observer.native_calls)==expected and all(r['actual_calls_started']==r['actual_calls_returned']==1 for r in observer.native_calls.values())
        assert not observer.forbidden_attempts and not observer.bridge_errors
    except BaseException:
        error=traceback.format_exc();(a.output/'failure.txt').write_text(error)
    finally:
        try:
            assert source_identity(a.source,binding)==manifest and controls()==control_hash
            assert sha(a.reference.read_bytes())==binding['QI_evidence_archive_sha256']
        except BaseException:guard_error=traceback.format_exc();(a.output/'identity-guard-failure.txt').write_text(guard_error)
        receipt=observer.receipt()
        receipt.update(gpu_uuid=GPU,source_manifest_sha256=binding['source_manifest_sha256'],controls_manifest_sha256=control_hash,
                       source584_exact=guard_error is None,controls_exact=guard_error is None,reference_bundle_exact=guard_error is None,
                       independent_QI_job='1843.manager',independent_QI_evidence_archive_sha256=binding['QI_evidence_archive_sha256'],
                       argv=argv,actual_original_pytest_returncode=actual_pytest_returncode,original_XML_records=xml_records,
                       original_XML_sha256=sha((a.output/'original3.xml').read_bytes()) if (a.output/'original3.xml').exists() else None,
                       error=error,identity_guard_error=guard_error,seconds=time.monotonic()-started,
                       device_library_versions=dict(jax=jax.__version__,cupy=cp.__version__,pytest=pytest.__version__),
                       default_XLA_FLAGS=os.environ.get('XLA_FLAGS'),CPU5_credit='Reused NR1585 original5; not rerun',
                       fixtures_or_tests_modified=False,independent_full_field_and_hard_ledger_EHPC_audit='pending actual raw hash and separate authorization',
                       historical_NQ399_of408_and9failures_retained=True)
        save(a.output/'capture-receipt.json',receipt)
    return actual_pytest_returncode if actual_pytest_returncode not in (None,0) else (1 if error or guard_error else 0)


if __name__=='__main__':raise SystemExit(main())

"""Read-only observation of the one authorized QN controller and worker."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
CODE="""import json
from pathlib import Path
r=Path('/home/lhwang/work/noahmp-v1/nq-most-cache-bridge-qn');o=Path('/tmp/nq-most-cache-bridge-qn-20261026/most');d={}
for root,leaf,key in [(r,'launch.json','launch'),(r,'controller-receipt.json','controller'),(o,'device-launch.json','worker_launch'),(o,'device-parent-receipt.json','parent'),(o/'device','capture-receipt.json','capture')]:
 p=root/leaf
 if p.exists():d[key]=json.loads(p.read_bytes())
for root,leaf,key in [(r,'controller.log','controller_log_tail'),(o,'device.stdout.txt','stdout_tail'),(o,'device.stderr.txt','stderr_tail')]:
 p=root/leaf
 if p.exists():d[key]=p.read_bytes()[-24000:].decode(errors='replace')
d['proc_exists']={str(pid):(Path('/proc')/str(pid)).exists() for pid in [886777]+([d['worker_launch']['pid']] if 'worker_launch' in d else [])}
print(json.dumps(d))
"""


def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);a=p.parse_args()
    destination=BASE/('nq-most-cache-bridge-qn-gpu-poll-'+str(a.index));assert not destination.with_suffix('.json').exists()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -c '+shlex.quote(CODE)]
    started=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=60)
    destination.with_suffix('.stdout').write_bytes(r.stdout);destination.with_suffix('.stderr').write_bytes(r.stderr)
    record=dict(actual_exit=r.returncode,seconds=time.monotonic()-started,read_only=True,snapshot=json.loads(r.stdout) if r.returncode==0 else None)
    destination.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if record['snapshot']:
        d=record['snapshot'];print(json.dumps(dict(actual_query_exit=r.returncode,proc_exists=d['proc_exists'],worker_launch=d.get('worker_launch'),controller=d.get('controller'),stdout_tail=d.get('stdout_tail'),stderr_tail=d.get('stderr_tail'))))
    else:print(json.dumps(record))


if __name__=='__main__':main()

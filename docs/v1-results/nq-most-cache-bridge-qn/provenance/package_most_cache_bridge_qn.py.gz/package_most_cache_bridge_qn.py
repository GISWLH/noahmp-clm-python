"""Seal original QN three-node GPU capture; independent QP audit is separate."""
import gzip
import io
import json
from pathlib import Path
import tarfile
import xml.etree.ElementTree as ET

from package_surface_reference_pt import files,sha,encode
from package_surface_feasible_root_pw import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='nq-most-cache-bridge-qn'


def main():
    closed=BASE/(LABEL+'-gpu-closed');raw=(closed/'gpu-result.tar.gz').read_bytes();hashdoc=json.loads((closed/'gpu-result-hash.json').read_bytes());assert sha(raw)==hashdoc['sha256']=='78aad10274a38f6ceddea53c0fc2b9bbd9fc7e92ddb9b6028c022baabba3410f' and len(raw)==hashdoc['bytes']
    actual=files(raw);controller=json.loads(actual['controller/controller-receipt.json']);capture=json.loads(actual['most/device/capture-receipt.json'])
    assert (closed/'controller-receipt.json').read_bytes()==actual['controller/controller-receipt.json'] and controller['completed'] and controller['stage_unchanged'] and controller['error'] is None and controller['actual_controller_OS_returncode'] is None
    assert [r['actual_parent_returncode'] for r in controller['actual_parents']]==[0] and controller['actual_parents'][0]['parent_receipt']['completed'] and controller['actual_parents'][0]['parent_receipt']['returncode']==0 and controller['actual_parents'][0]['parent_receipt']['error'] is None
    assert actual['most/device-parent-exit.txt'].strip()==b'0'
    assert capture['actual_original_pytest_returncode']==0 and capture['source584_exact'] and capture['controls_exact'] and capture['reference_bundle_exact'] and capture['error'] is None and capture['identity_guard_error'] is None
    assert capture['reference_cache_hits']==dict(float32=1,float64=1) and len(capture['complete_actual_reference_requests'])==2 and not capture['bridge_errors'] and not capture['forbidden_CPU_attempts'] and capture['NumPy_physical_forward_calls']==0 and capture['default_XLA_FLAGS'] is None
    assert len(capture['reports'])==9 and all(r['outcome']=='passed' and r['wasxfail'] is None for r in capture['reports'])
    cases=list(ET.fromstring(actual['most/device/original3.xml']).iter('testcase'));assert len(cases)==3 and all(not list(x) for x in cases)
    assert sha(actual['most/device/original3.xml'])==capture['original_XML_sha256']
    assert set(capture['native_original_calls'])=={'jax-float32-reference','jax-float64-reference','cuda-float32-parity','jax-float32-parity'} and all(r['actual_calls_started']==r['actual_calls_returned']==1 for r in capture['native_original_calls'].values())
    counts={};fortran={}
    for name,b in actual.items():
        if not name.endswith('.json'):continue
        meta=json.loads(b);stem=name.removesuffix('.json')
        if isinstance(meta,dict) and 'tree' in meta and stem+'.npz' in actual:counts[stem],fortran[stem]=opaque_packet(actual[stem+'.npz'],meta)
    assert len(counts)==8
    stage_raw=(BASE/(LABEL+'-gpu-stage.tar.gz')).read_bytes();assert sha(stage_raw)=='1d814fa98e9897922db9777f2ba98674c9fd4069c1daa4cad014fb47db2d3879'
    stage=files(stage_raw);index=json.loads(stage['stage-inventory.json']);assert set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    source=files(stage['source.tar.gz']);manifest=json.loads(source['SOURCE_SHA256.json']);assert len(manifest)==584 and all(sha(source[n])==h for n,h in manifest.items())
    assert sha(source['SOURCE_SHA256.json'])==capture['source_manifest_sha256']=='da0c59b35d095df102db32eaebb956c97b02bf02c1553a901d911a0ebd652f80'
    qi=files(stage['reference-evidence.tar.gz']);assert sha(stage['reference-evidence.tar.gz'])==capture['independent_QI_evidence_archive_sha256']=='4adc3fbe6e705330476e3a8c6e6d7207343d3b825e7180e8db21b8f8c211539b'
    for dtype in ('float32','float64'):
        expected=json.loads(qi['actual-result/reference/'+dtype+'-input.json'])['tree'];requests=[x for x in capture['complete_actual_reference_requests'] if x.get('served')==dtype]
        assert len(requests)==1 and requests[0]['matches']==[dtype] and requests[0]['input_tree']==expected
    release=json.loads((closed/'metadata-recovery.json').read_bytes());assert release['actual_exit']==0 and release['all_three_QN_PIDs_absent'] and release['own_CUDA1_processes']==0
    verification=dict(passed=True,scope='Stdlib immutable archives/hash/JSON/XML and opaque NPY payloads only; no numeric array decode, unpickle, model, pytest or GPU run during packaging',raw_GPU_sha256=sha(raw),stage_sha256=sha(stage_raw),source_files=584,source_manifest_sha256=sha(source['SOURCE_SHA256.json']),typed_packets=8,opaque_array_payloads=sum(counts.values()),per_packet_arrays=counts,fortran_members={n:v for n,v in fortran.items() if v},actual_original_pytest_nodes=3,actual_original_reports=9,actual_original_pytest_exit=0,actual_original_native_calls=4,actual_reference_cache_hits=capture['reference_cache_hits'],actual_worker_exit=0,actual_parent_exit=0,actual_detached_controller_OS_exit=None,source_and_controls_exact=True,default_XLA_FLAGS_unset=True,NumPy_physical_forward_calls=0,independent_EHPC_full_field_and_hard_ledger_audit='Separate QP1859 pending at time of this capture package; no combined credit here',historical_original_NQ399_of408_and9failed_records_retained=True)
    readout=dict(actual_GPU_original_pytest='3 passed',pytest_reports=capture['reports'],XML_cases=[x.attrib for x in cases],GPU_worker_seconds=capture['seconds'],GPU_parent_seconds=controller['actual_parents'][0]['parent_receipt']['seconds'],controller_seconds=controller['seconds'],actual_parent_exit=0,actual_worker_exit=0,actual_detached_controller_OS_exit=None,native_calls=capture['native_original_calls'],reference_cache_hits=capture['reference_cache_hits'],actual_QI_source='Private QH source identical to QN; original CPU reference job1843 F0/Stageout0',NumPy_physical_forward_calls=0,default_XLA_FLAGS=None,source584_exact=True,source_or_fixture_or_test_modified=False,CPU5_credit='NR1585 explicit reuse only; no new5node run',CUDA1_released=release['all_three_QN_PIDs_absent'],independent_EHPC_audit='Separate QP; original light host assertions alone do not supply independent full-field/hard-ledger credit',historical_original_NQ399_of408_and9failed_records_retained=True)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification));(BASE/(LABEL+'-readout.json')).write_bytes(encode(readout))
    items={'actual-gpu/'+n:b for n,b in actual.items()};items.update({'raw-gpu-result.tar.gz':raw,'executed-stage.tar.gz':stage_raw,'verification.json':encode(verification),'readout.json':encode(readout)})
    for directory in [closed]:
        for path in sorted(directory.iterdir()):
            if path.is_file():items['observations/closed/'+path.name]=path.read_bytes()
    for pattern in [LABEL+'-gpu-poll-*',LABEL+'-gpu-preflight*',LABEL+'-gpu-deploy-*']:
        for path in sorted(BASE.glob(pattern)):
            if path.is_file():items['observations/'+path.name]=path.read_bytes()
    for name in ['capture_most_qn.py','most_observer_qn.py','most_contract_qn.py','prepare_most_cache_bridge_qn.py','check_most_qn_gpu_readonly.py','poll_most_qn_gpu.py','deploy_most_cache_bridge_qn_gpu.py','collect_most_cache_bridge_qn_closed.py','recover_most_qn_metadata_readonly.py','package_most_cache_bridge_qn.py',LABEL+'-stage-package.json',LABEL+'-gpu-deployment.json']:
        items['provenance/'+name]=(BASE/name).read_bytes()
    items['SCOPE.md']=b'''# QN original three-node GPU semantic verification capture

Actual unique CUDA1 original3node pytest0 with9passed setup/call/teardown reports, no skip. Actual original four native requests and complete returns saved; exact one independent-QI cache request per dtype with no fallback or NumPy physical forward. Default XLA flags, x64true and original3600s/resource/UUID/privatecache guards. Source584 and every original test/fixture byte unchanged during capture. PrivateQH original counter legality changes were reviewed separately; original CPU manufactured-stagnation tests unchanged, five CPU results explicitly reused from NR1585 only.

Actual worker0 and waited parent0, no timeout, actual detached controller OS status unknown. All three original process PIDs subsequently absent and own CUDA1 processes0. A read-only observation SSH socket failure and a return0 multi-sourceSCP that omitted two metadata files are preserved; metadata-only recovery verified controller bytes against raw tar. No model/reference/GPU retry. Complete raw output, original arrays, original pytest/stdout/XML, source and controls are retained. This package does not by itself grant independent full-field/hard-ledger credit; the separate actual EHPC QP audit supplies that evidence. Original NQ399/408 and all9failed/scientific/annual records remain retained; no Richards1J removal or release claim.
'''
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(label=LABEL,archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='Unique original MOST3node GPU capture0, four complete native calls and two exact independent EHPC cached references; source/default flags unchanged, CUDA1 released. Separate independent QP audit required; historical NQ9failures retained.',verification=verification)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

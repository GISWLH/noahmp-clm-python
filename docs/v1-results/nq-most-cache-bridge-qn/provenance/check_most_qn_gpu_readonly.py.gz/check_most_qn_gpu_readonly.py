"""One read-only CUDA1/old-parent inventory before the authorized unique QN."""
import json
from pathlib import Path
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
CODE="""import json,os,subprocess
from pathlib import Path
gpu='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
old=[874350,874353,874693,864244,864246,864677]
queries={}
for name,args in [('processes',['--query-compute-apps=gpu_uuid,pid,process_name,used_memory']),('device',['--query-gpu=index,uuid,name,memory.free'])]:
 r=subprocess.run(['nvidia-smi','--id='+gpu,*args,'--format=csv,noheader,nounits'],capture_output=True,text=True)
 queries[name]=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
rows=[]
for line in queries['processes']['stdout'].splitlines():
 values=[v.strip() for v in line.split(',')]
 if len(values)<2 or not values[1].isdigit():continue
 pid=int(values[1]);path=Path('/proc')/str(pid);row=dict(pid=pid)
 try:row['uid']=path.stat().st_uid;row['cwd']=os.readlink(path/'cwd')
 except OSError as e:row['process_metadata_error']=str(e)
 rows.append(row)
print(json.dumps(dict(old_proc_exists={str(pid):(Path('/proc')/str(pid)).exists() for pid in old},queries=queries,current_gpu_process_metadata=rows,current_uid=os.getuid())))
"""
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang','/home/lhwang/venvs/noahmp-phase3b/bin/python -B -c '+shlex.quote(CODE)]
started=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=60)
for suffix,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
    (BASE/('nq-most-cache-bridge-qn-gpu-preflight.'+suffix)).write_bytes(raw)
record=dict(actual_exit=r.returncode,seconds=time.monotonic()-started,read_only=True,query=json.loads(r.stdout) if r.returncode==0 else None)
(BASE/'nq-most-cache-bridge-qn-gpu-preflight.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
assert r.returncode==0 and not any(record['query']['old_proc_exists'].values())
assert all(v['returncode']==0 for v in record['query']['queries'].values())
assert all('uid' in row and row['uid']!=record['query']['current_uid'] for row in record['query']['current_gpu_process_metadata']),'Wait for own active CUDA1 task before unique QN'

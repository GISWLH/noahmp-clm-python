"""One reviewed original three-node parent; wait its actual exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    policy=json.loads((HERE/'EXECUTION_BINDINGS.json').read_bytes())
    index=json.loads((ROOT/'stage-inventory.json').read_bytes())
    assert all(sha((ROOT/n).read_bytes())==h for n,h in index.items())
    temporary=Path(policy['temporary'])
    record=dict(completed=False,actual_controller_OS_returncode=None,actual_parents=[],started_unix=time.time(),error=None)
    try:
        for backend in policy['backend_order']:
            output=temporary/backend
            command=[sys.executable,'-B',str(HERE/'run_device_parent_pbs.py'),'--source',str(temporary/'source'),
                '--reference',str(ROOT/'reference-evidence.tar.gz'),'--output',str(output),'--backend',backend]
            with (ROOT/(backend+'-parent.stdout')).open('xb') as out,(ROOT/(backend+'-parent.stderr')).open('xb') as err:
                result=subprocess.run(command,stdout=out,stderr=err)
            row=dict(backend=backend,actual_parent_returncode=result.returncode,output=str(output))
            path=output/'device-parent-receipt.json'
            if path.exists():row.update(parent_receipt_sha256=sha(path.read_bytes()),parent_receipt=json.loads(path.read_bytes()))
            record['actual_parents'].append(row)
            save(ROOT/'controller-progress.json',record)
        record['completed']=True
    except BaseException:
        record['error']=traceback.format_exc()
    finally:
        record['stage_unchanged']=all(sha((ROOT/n).read_bytes())==h for n,h in index.items())
        record['seconds']=time.time()-record['started_unix']
        save(ROOT/'controller-receipt.json',record)
        with tarfile.open(ROOT/'gpu-result.tar.gz','w:gz') as archive:
            for backend in policy['backend_order']:
                output=temporary/backend
                if output.exists():
                    for path in sorted(output.rglob('*')):
                        if path.is_file() and not any(part in ('cupy-cache','jax-cache','cuda-cache') for part in path.relative_to(output).parts):
                            archive.add(path,arcname=backend+'/'+path.relative_to(output).as_posix(),recursive=False)
            for leaf in ('controller-receipt.json','controller-progress.json','most-parent.stdout','most-parent.stderr'):
                if (ROOT/leaf).exists():archive.add(ROOT/leaf,arcname='controller/'+leaf,recursive=False)
        save(ROOT/'gpu-result-hash.json',dict(sha256=sha((ROOT/'gpu-result.tar.gz').read_bytes()),bytes=(ROOT/'gpu-result.tar.gz').stat().st_size))
    return 0 if record['completed'] and record['stage_unchanged'] and all(r['actual_parent_returncode']==0 for r in record['actual_parents']) else 1


if __name__=='__main__':raise SystemExit(main())

from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'climatology-current-year-export-kk';sha=lambda raw:hashlib.sha256(raw).hexdigest();launch=json.loads((r/'launch.json').read_text());worker=json.loads((r/'worker.json').read_text());pid=worker['pid'];proc=Path('/proc')/str(pid);assert proc.exists() and b'control_current_year_export_kk.py' in (proc/'cmdline').read_bytes();assert worker['launch_sha256']==sha((r/'launch.json').read_bytes()) and not (r/'exit.json').exists()
assert all(sha((r/n).read_bytes())==h for n,h in launch['controls_sha256'].items());payload={p.name:p.read_bytes() for p in r.iterdir() if p.is_file()};observed=[]
for pid in [3150296,3150299]:
    p=Path('/proc')/str(pid);assert p.exists();observed.append(dict(pid=pid,command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),observed_live=True))
    if pid==3150299:
        env=dict(x.split('=',1) for x in (p/'environ').read_bytes().decode().split('\0') if '=' in x);assert env['CUDA_VISIBLE_DEVICES']=='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
report=(b/'ballberry-climatology-cuda-jt/trajectory/batch.json').read_bytes();d=json.loads(report);assert d['status']=='running' and d['steps_requested']==17520 and d['source_unchanged'];payload['actual-year-batch-at-snapshot.json']=report
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),export_controller_pid=worker['pid'],export_controller_observed_live=True,year_observed_live=observed,actual_year_steps=d['steps_completed'],requested=17520,cases=12,source_manifest_sha256=launch['source_manifest_sha256'],scope='Read-onlyI/O exporter actuallyqueued after existingcurrent12case CUDA1yearactualparent0; waitingdoesnotclaim successfulyear/export/independentaudit/spinup/SOC/full407/K78/science/release. Originalmodelprocess/source/cache/inputs/state untouched; no extraGPUmodel.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();payload[Path(__file__).name]=Path(__file__).read_bytes();target=b/'current-year-export-readiness-kt-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):
        member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'current-year-export-readiness-kt-package.json').write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(package),flush=True)

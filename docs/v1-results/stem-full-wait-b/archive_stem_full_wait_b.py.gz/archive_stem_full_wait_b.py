from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'p6-stem-full-gpu-b/full-controller-b';pid=json.loads((r/'launch.json').read_text())['pid'];assert not (r/'worker.json').exists() and not (r/'exit.json').exists() and not (b/'p6-material-event-b/full-controller-b/exit.json').exists();assert b'wait_stem_full_gpu_b.py' in Path('/proc',str(pid),'cmdline').read_bytes() and b'run_material_full_gpu_b.py' in Path('/proc/597245/cmdline').read_bytes();elapsed=int(subprocess.check_output(['ps','-p',str(pid),'-o','etimes='],text=True).strip());assert elapsed>=1800
raw=(b/'p6-material-event-b/full-by-file-b/progress.json').read_bytes();d=json.loads(raw);obs=dict(scope='Actual current506B fullGPU deferred wait >30min,original493 controller still live and no original exit/current worker receipt. Do not start a duplicate worker or credit queued tests. Independent CUDA year/reference diagnostics continue.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=elapsed,ps=subprocess.check_output(['ps','-p',str(pid)+',597245','-o','pid,ppid,stat,etime,pcpu,args'],text=True),old493_covered_nodes=d['covered_nodes'],old493_active=d['active'],current_gpu_worker_started=False)
a=b/'stem-full-wait-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
 for name,data in [('observation.json',(json.dumps(obs,indent=2)+'\n').encode()),('captured-old493-progress.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),observation=obs)))

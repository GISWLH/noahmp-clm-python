from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'surface-root-k78-mv';assert not r.exists();package=json.loads((b/'surface-root-ml-k78-export.json').read_text())
assert package['archive']=='surface-root-ml-k78-export.tar.gz' and package['stage']=='k78'
assert package['derived_manifest_sha256']=='01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
assert package['required_actual_computations']==['point-cuda32','point-jax32','k78-cuda32','k78-jax32']
assert hashlib.sha256((b/package['archive']).read_bytes()).hexdigest()==package['sha256']
n='audit_surface_k78_mv.py';raw=(b/n).read_bytes();assert b'\r\n' not in raw
r.mkdir();(r/'packet.json').write_text(json.dumps(package,indent=2)+'\n');(r/n).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-surface-k78-mv
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=6gb
#PBS -l walltime=00:10:00
#PBS -j oe
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/surface-root-k78-mv
/home/zhangyq/venvs/noahmp-closeout/bin/python -u audit_surface_k78_mv.py >worker.log 2>&1
code=$?
printf '%s\\n' "$code" >pbs-exit.txt
exit "$code"
'''
(r/'job.pbs').write_text(script);q=subprocess.run(['qsub',str(r/'job.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr;out=dict(pbs_job=q.stdout.strip(),controls_sha256={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in [n,'job.pbs']});(r/'dispatch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

"""Archive actual MV success and bind the two real prerequisites for MX."""
from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile

b=Path('/home/zhangyq/noahmp-v1')
r=b/'surface-root-k78-mv'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
derived='01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
proofs={}
preflight={}
for label,root,job in [('point_pair',b/'surface-root-pair-mp','1544.manager'),('k78',r,'1550.manager')]:
    q=subprocess.check_output(['qstat','-xf',job],text=True)
    assert re.search(r'^Job Id: '+re.escape(job)+r'\s*$',q,re.M)
    assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M)
    assert (root/'pbs-exit.txt').read_text().strip()=='0'
    raw=(root/'audit.json').read_bytes();a=json.loads(raw)
    assert a['pbs_job']==job and a['passed'] and not a['errors']
    key='derived_manifest_sha256' if label=='point_pair' else 'executed_gpu_derived_manifest_sha256'
    rows=a['raw_same_precision_fields' if label=='point_pair' else 'fields']
    assert a[key]==derived and len(rows)==len({x['field'] for x in rows})==345
    assert all(x['passed'] and x['bitwise_equal'] for x in rows)
    if label=='point_pair':
        assert all(len(v)==12 and all(x['passed'] for x in v) for v in a['original_module_science'].values())
        assert all(x['passed'] for x in a['original_hard_budgets'].values())
    else:
        assert a['raw_model_and_next_fields']==329 and a['additional_before_arrays']==16
        assert all(x['passed'] for x in a['budgets'].values()) and a['source_unchanged']
        assert a['maximum_absolute_difference']==0 and not a['failed']
        assert not (r/'actual-qstat.txt').exists()
        (r/'actual-qstat.txt').write_text(q)
    preflight[label+'-audit.json']=raw
    preflight[label+'-actual-qstat.txt']=q.encode()
    proofs[label]=dict(pbs_job=job,actual_pbs_exit=0,audit_sha256=sha(raw),qstat_sha256=sha(q.encode()))
ack=dict(passed=True,derived_manifest_sha256=derived,proofs=proofs)
preflight['ack.json']=(json.dumps(ack,indent=2)+'\n').encode()

def archive(path,payload):
    assert not path.exists()
    with tarfile.open(path,'w:gz') as tf:
        for name,raw in sorted(payload.items()):
            m=tarfile.TarInfo(name);m.size=len(raw);tf.addfile(m,io.BytesIO(raw))
    with tarfile.open(path) as tf:
        assert len(tf.getmembers())==len(payload)
        for m in tf:assert tf.extractfile(m).read()==payload[m.name]
    return dict(archive=path.name,sha256=sha(path.read_bytes()),artifacts=len(payload),bytes=path.stat().st_size)

p=Path('/tmp/surface-mx-preflight-nd.tar.gz')
meta=archive(p,preflight)
meta['scope']='Only actual MP1544/MV1550 F0 and their original unchanged gates; enables private 31-node MX, not full suite or release.'
p.with_name('surface-mx-preflight-nd-package.json').write_text(json.dumps(meta,indent=2)+'\n')
payload={x.relative_to(r).as_posix():x.read_bytes() for x in r.rglob('*') if x.is_file()}
for name in ['surface-root-ml-k78-export.tar.gz','surface-root-ml-k78-export.json']:
    payload['device-export/'+name]=(b/name).read_bytes()
assert sha(payload['device-export/surface-root-ml-k78-export.tar.gz'])=='3276a24cecd86befa2990b9b10d4d39149b9fa18dcbbbc1b971a685011f06412'
payload['controls/'+Path(__file__).name]=Path(__file__).read_bytes()
payload['controls/dispatch_surface_k78_mv.py']=(b/'dispatch_surface_k78_mv.py').read_bytes()
payload.update({'mx-preflight/'+k:v for k,v in preflight.items()})
a=Path('/tmp/surface-root-k78-mv-evidence.tar.gz')
meta=archive(a,payload)
meta['scope']='MV1550 actual F0 on private ML4 candidate. Original K78 input, field contract and all329 model/next plus16 before arrays unchanged; all345 bitwise equal, maximum difference0, original1e-6/int/dtype and independent MHCN/five impurity gates passed. Bound to actual MP1544. K78 CUDA2.579100s/JAX806.669740s actual0. Not production/full407/annual/science/release acceptance.'
a.with_name('surface-root-k78-mv-package.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta),flush=True)

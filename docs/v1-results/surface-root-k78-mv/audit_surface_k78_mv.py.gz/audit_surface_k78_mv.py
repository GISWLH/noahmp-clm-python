from pathlib import Path
import hashlib
import io
import json
import os
import re
import sys
import tarfile
import subprocess

import numpy as np

assert os.environ.get('PBS_JOBID')
expected_derived = '01d018d1adc6dff262a1c222b9a041efa7abe4daf5cea3855a8733b5e4e76027'
expected_changes = {
    'src/noahmp_clm/gpu/snow_evolution.py': 'f4724a3462d66caa8c4b93e20ca0022dabf6ed62cee9209de71c7ef4faeee297',
    'src/noahmp_clm/gpu/cuda/snow_evolution_kernel.cu': 'd8a7dcee2eb6a2243fd76fff26e65fe37b0509d0d011424918b1292a07705840',
    'src/noahmp_clm/gpu/canopy_surface.py': '4836ed4306c4d13c91e3c4860b738fc671a41293a70a1e6815459211cdf0f92a',
    'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu': 'a21741d4a4225cd7f4b132cb327da3f575e413d76e983970db000aa5aff06139',
}
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'surface-root-k78-mv'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = b / 'clm-ballberry-jn-source.tar.gz'
assert sha(source) == '44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(source) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert sha(s/'SOURCE_SHA256.json')=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
assert len(m) == 581 and all(sha(s / n) == v for n, v in m.items())
packet = b / 'surface-root-ml-k78-export.tar.gz'
metadata = json.loads((r / 'packet.json').read_text())
assert sha(packet) == metadata['sha256']
assert metadata['archive'] == packet.name and metadata['stage'] == 'k78'
assert metadata['required_actual_computations'] == ['point-cuda32', 'point-jax32', 'k78-cuda32', 'k78-jax32']
with tarfile.open(packet) as t:
    t.extractall(Path(os.environ['TMPDIR']) / 'device', filter='data')
d = Path(os.environ['TMPDIR']) / 'device'
assert (d / 'PARENT_SOURCE_SHA256.json').read_bytes() == (s / 'SOURCE_SHA256.json').read_bytes()
candidate = json.loads((d/'candidate.json').read_text())
derived = json.loads((d/'CANDIDATE_SHA256.json').read_text())
patch = json.loads((d/'patch.json').read_text())
assert sha(d/'CANDIDATE_SHA256.json') == candidate['derived_manifest_sha256'] == metadata['derived_manifest_sha256']
assert candidate['derived_manifest_sha256'] == expected_derived
assert candidate['parent_manifest_sha256'] == sha(s/'SOURCE_SHA256.json')
assert patch['parent_source_manifest_sha256'] == candidate['parent_manifest_sha256']
assert len(derived)==len(m)==581 and set(derived)==set(m)
assert {n for n in m if m[n]!=derived[n]} == set(patch['changes']) and len(patch['changes'])==4
assert set(patch['changes']) == set(expected_changes)
for n,change in patch['changes'].items():
    assert change['before_sha256']==m[n] and hashlib.sha256(change['after_text'].encode()).hexdigest()==change['after_sha256']==derived[n]
    assert change['after_sha256'] == expected_changes[n]
original = b/'k78-corrected-js-device-export.tar.gz'
assert sha(original)=='c669ab766e826dd668852d5b80b5a9226ecccaaa6a777836878642b99c9ccdc1'
with tarfile.open(original) as baseline:
    assert baseline.extractfile('binding.json').read() == (d/'k78-binding.json').read_bytes()
    assert baseline.extractfile('input.npz').read() == (d/'k78.npz').read_bytes()
    original_field_contract = {}
    for name in ['cuda32', 'jax32']:
        with np.load(io.BytesIO(baseline.extractfile(name + '/output.npz').read()), allow_pickle=False) as z:
            original_field_contract[name] = {key: (z[key].shape, z[key].dtype) for key in z.files}
        assert len(original_field_contract[name]) == 345
ack=json.loads((d/'point-pair-reference-ack.json').read_text())
assert ack['passed'] and ack['actual_pbs_exit']==0 and ack['derived_manifest_sha256']==candidate['derived_manifest_sha256']
assert ack['pbs_job'].endswith('.manager') and ack['pbs_job'].split('.')[0].isdigit()
status=subprocess.check_output(['qstat','-xf',ack['pbs_job']],text=True)
assert re.search(r'^Job Id: ' + re.escape(ack['pbs_job']) + r'\s*$', status, re.M)
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
(r/'point-pair-actual-pbs-qstat.txt').write_text(status)
# Bind the ACK to the actual closed MP audit, not only to a successful PBS ID.
pair_root = b / 'surface-root-pair-mp'
pair_path = pair_root / 'audit.json'
assert sha(pair_path) == ack['audit_sha256']
assert (pair_root / 'pbs-exit.txt').read_text().strip() == '0'
assert sha(pair_root / 'actual-qstat.txt') == ack['qstat_sha256']
pair = json.loads(pair_path.read_text())
assert pair['pbs_job'] == ack['pbs_job'] and pair['stage'] == 'pair'
assert pair['passed'] and not pair['errors'] and pair['independent_reference_source_unchanged']
assert pair['parent_manifest_sha256'] == candidate['parent_manifest_sha256']
assert pair['derived_manifest_sha256'] == expected_derived
assert pair['reference_input_sha256'] == sha(d / 'point.npz') == 'd40644c23c9b31feabd3032528157ef38b9bd54b694a9191862704ab1ac59ffb'
assert set(pair['original_module_science']) == set(pair['original_hard_budgets']) == {'cuda32', 'jax32'}
for name in ['cuda32', 'jax32']:
    reference_rows = pair['original_module_science'][name]
    assert len(reference_rows) == 12 and all(row['passed'] for row in reference_rows)
    assert pair['original_hard_budgets'][name]['passed']
assert len(pair['raw_same_precision_fields']) == 345
assert len({row['field'] for row in pair['raw_same_precision_fields']}) == 345
assert all(row['passed'] for row in pair['raw_same_precision_fields'])
pair_archive = b / 'surface-root-ml-pair-export.tar.gz'
assert sha(pair_archive) == pair['device_export_sha256']
with tarfile.open(pair_archive) as verified_pair:
    for name in ['point.npz', 'point-binding.json', 'CANDIDATE_SHA256.json', 'PARENT_SOURCE_SHA256.json', 'patch.json']:
        assert verified_pair.extractfile(name).read() == (d / name).read_bytes()
    for backend in ['cuda32', 'jax32']:
        for name in ['point-' + backend + '-exit.json', 'point-' + backend + '/receipt.json', 'point-' + backend + '/output.npz']:
            assert verified_pair.extractfile(name).read() == (d / name).read_bytes()
(r / 'point-pair-audit.json').write_bytes(pair_path.read_bytes())
(r / 'point-pair-ack-original-qstat.txt').write_bytes((pair_root / 'actual-qstat.txt').read_bytes())
assert sha(d / 'k78.npz') == '957049c10718278276967f5749ea392989f2fb99011d238a09046bcb8fe49a29'
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

with np.load(d / 'k78.npz', allow_pickle=False) as z:
    inputs = dict(z)
exports, budgets = {}, {}
errors = []
for name, prefix in [('cuda32', 'a'), ('jax32', 'shadow')]:
    receipt = json.loads((d / ('k78-'+name) / 'receipt.json').read_text())
    exit = json.loads((d / ('k78-' + name + '-exit.json')).read_text())
    assert receipt['mode'] == exit['mode'] == 'k78-' + name and receipt['backend'] == name
    assert receipt['parent_manifest_sha256'] == candidate['parent_manifest_sha256']
    assert receipt['result']['raw_fields'] == 345 and receipt['result']['columns'] == len(inputs['forcing'])
    assert receipt['device_barriers'] == (['cupy-complete'] if name == 'cuda32' else ['jax-complete'])
    assert exit['actual_parent_returncode'] == 0 and receipt['failure'] is None and receipt['candidate_source_unchanged'] and receipt['derived_manifest_sha256']==candidate['derived_manifest_sha256'] and receipt['device_barriers']
    assert sha(d / ('k78-'+name) / 'receipt.json') == exit['receipt_sha256']
    assert sha(d / ('k78-'+name) / 'output.npz') == receipt['result']['output_sha256']
    with np.load(d / ('k78-'+name) / 'output.npz', allow_pickle=False) as z:
        fields = dict(z)
    assert fields.keys() == original_field_contract[name].keys()
    assert all((value.shape, value.dtype) == original_field_contract[name][key] for key, value in fields.items())
    before = tuple(fields['before' + str(k)] for k in range(16))
    after = tuple(fields['next' + str(k)] for k in range(16))
    for k in range(16):
        expected = inputs[prefix + str(k)].copy()
        if k == 4:
            expected[:, 7:10] = inputs['environment']
        assert before[k].dtype == expected.dtype and before[k].shape == expected.shape and before[k].tobytes() == expected.tobytes(), (name, k)
    result = {}
    for key, value in fields.items():
        if re.fullmatch(r'(?:before|next)\d+', key):
            continue
        parts = key.split('/')
        one = result
        for part in parts[:-1]:
            one = one.setdefault(part, {})
        one[parts[-1]] = value
    try:
        incoming, residual, bound, tracer = driver.audit_step(before, after, inputs['forcing'], inputs['deposition'], inputs['nitrogen'], result)
        budgets[name] = dict(passed=True, residual_m_h_c_n=residual.tolist(), original_bounds=bound.tolist(), impurity_absolute_residual=tracer.tolist())
    except Exception as e:
        budgets[name] = dict(passed=False, failure=type(e).__name__ + ': ' + str(e))
        errors.append('Original independent MHCN/impurity audit failed: ' + name)
    assert receipt['input_sha256']==sha(d/'k78.npz') and receipt['binding_sha256']==sha(d/'k78-binding.json') and exit['passed']
    assert len(fields)==345
    exports[name] = fields
assert exports['cuda32'].keys() == exports['jax32'].keys()
rows = []
for name in exports['cuda32']:
    x, y = exports['cuda32'][name], exports['jax32'][name]
    assert x.shape == y.shape
    integer = x.dtype.kind in 'ibu'
    dtype_match = x.dtype == y.dtype
    finite = bool(np.all(np.isfinite(x)) and np.all(np.isfinite(y)))
    raw_difference = abs(x.astype(float) - y.astype(float))
    maximum = float(np.max(raw_difference)) if raw_difference.size else 0.
    equal = bool(x.dtype == y.dtype and x.tobytes() == y.tobytes())
    before_field = bool(re.fullmatch(r'before\d+', name))
    passed = dtype_match and (equal if integer or before_field else finite and x.dtype == np.dtype('float32') and bool(np.allclose(x, y, rtol=1e-6, atol=1e-6)))
    row = dict(field=name, dtype_cuda=str(x.dtype), dtype_jax=str(y.dtype), maximum_absolute=maximum, bitwise_equal=equal, passed=bool(passed), before_input_only=before_field)
    if maximum:
        index = np.unravel_index(np.argmax(raw_difference), raw_difference.shape)
        row.update(index=list(map(int, index)), cuda=float(x[index]), jax=float(y[index]))
    rows.append(row)
    if not passed:
        errors.append('Raw sameprecision gate failed: ' + name)
model_rows = [v for v in rows if not v['before_input_only']]
failed = [v for v in rows if not v['passed']]
assert len(rows)==345 and len(model_rows)==329
unchanged = all(sha(s / n) == v for n, v in m.items())
record = dict(scope='PRIVATE ML fourfile density+NumPy20round midpointfallback candidate originalK78 whole-step, afterpoint-pair originalscience/hardbudgets/raw1e-6 actualF0. Independent unchangedoriginalJN NumPy budgets and strictall329model/next plus16originalbefore arrays, rtol=atol1e-6/int/dtype/float32 andalloriginalMHCN/fiveimpuritygates. Originalinput andleafbinding exacttoimmutableJSexport. No failedtrajectory/source/production/gate/M1 edit or fullsuite/year/scientific/release acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=not errors and unchanged, errors=errors, budgets=budgets,
              raw_model_and_next_fields=len(model_rows), additional_before_arrays=16,
              maximum_absolute_difference=max(v['maximum_absolute'] for v in model_rows), fields=rows, failed=failed,
              independent_reference_parent_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), executed_gpu_derived_manifest_sha256=candidate['derived_manifest_sha256'], changed_gpu_source_files=list(patch['changes']), original_binding_sha256=sha(d/'k78-binding.json'), source_unchanged=unchanged,
              point_pair_pbs_job=pair['pbs_job'], point_pair_audit_sha256=sha(pair_path), point_pair_export_sha256=sha(pair_archive),
              original345_field_names_shapes_dtypes_exact=True,
              device_export_sha256=sha(packet), original_input_sha256=sha(d / 'k78.npz'))
(r / 'audit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: record[k] for k in ['pbs_job', 'passed', 'errors', 'raw_model_and_next_fields', 'maximum_absolute_difference', 'failed', 'budgets']}), flush=True)
raise SystemExit(0 if not errors and record['source_unchanged'] else 1)

"""Printf-only capture of failing joint-heat operands inside unchanged E."""
from pathlib import Path
import hashlib,json
import numpy as np
import cupy as cp
import noahmp_clm.gpu.cuda.canopy_phase_surface as module

root=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-e/failure-325-capture-a')
names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu',
    'enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu',
    'snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu')
source='\n'.join(Path(module.__file__).with_name(name).read_text() for name in names)
needle='joint_heat_device(cells,props,options,bc,heat);';assert source.count(needle)==1
trace='''
if(heat[75]<=0.f&&threadIdx.x==0&&blockIdx.x==0){
 printf("HEAT_FAILURE %.9g",temp);
 for(int i=0;i<45;++i)printf(" %.9g",cells[i]);
 for(int i=0;i<3;++i)printf(" %.9g",props[i]);
 for(int i=0;i<2;++i)printf(" %d",options[i]);
 for(int i=0;i<4;++i)printf(" %.9g",bc[i]);
 for(int i=0;i<77;++i)printf(" %.9g",heat[i]);
 printf("\\n");}
'''
source=source.replace(needle,needle+trace)
compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_canopy_phase_surface_vic',))
module._kernel=lambda extended=False,vic=False:compiled.get_function('run_canopy_phase_surface_vic')
with np.load(root/'failed-surface-inputs.npz',allow_pickle=False) as z:arrays={k:z[k][1:2] for k in z}
out=module.run_canopy_phase_surface_cuda(*[arrays[f'a{k}'] for k in range(9)],exchange_extension=arrays['exchange_extension'],vic=arrays['vic'],raise_on_failure=False)
cp.cuda.get_current_stream().synchronize()
flat={}
for key,value in out.items():
 if isinstance(value,dict):flat.update({key+'/'+k:cp.asnumpy(v) for k,v in value.items()})
 else:flat[key]=cp.asnumpy(value)
with np.load(root/'failed-surface-output.npz',allow_pickle=False) as z:
 for key,value in flat.items():np.testing.assert_array_equal(value,z[key][1:2],err_msg=key)
np.savez_compressed(root/'printf-replay-output.npz',**flat)
summary=dict(scope='Unchanged physical sourceE and compile flags, added printf only. All returned fields bitwise identical to retained failing Qia result.',
    diagnostic_cuda_source_sha256=hashlib.sha256(source.encode()).hexdigest(),all_fields_bitwise_equal=True)
(root/'printf-replay-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)

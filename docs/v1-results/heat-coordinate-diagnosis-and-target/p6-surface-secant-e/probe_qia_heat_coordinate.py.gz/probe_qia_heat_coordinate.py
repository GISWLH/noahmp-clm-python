"""Isolated device experiment: residual correction after a failed line search."""
from pathlib import Path
import hashlib,json
import numpy as np
import cupy as cp

base=Path('/home/lhwang/work/noahmp-v1');root=base/'fluxnet-first-climate-cycle-20261017-e'
rows=[line.split()[1:] for line in (root/'qia-325-joint-heat-capture.log').read_text().splitlines() if line.startswith('HEAT_FAILURE ')]
assert len(rows)==1
raw=np.asarray(rows[0],np.float32);assert raw.shape==(132,)
temperature=raw[0];raw=raw[1:];cells=raw[:45].reshape(1,9,5);props=raw[45:48].reshape(1,3)
options=raw[48:50].astype(np.int32).reshape(1,2);boundary=raw[50:54].reshape(1,4);retained=raw[54:].reshape(1,77)
dest=root/'heat-coordinate-probe-a';dest.mkdir(exist_ok=False)
np.savez_compressed(dest/'inputs.npz',cells=cells,props=props,options=options,boundary=boundary,original=retained)
cuda=base/'p6-surface-secant-e/src/noahmp_clm/gpu/cuda'
original='\n'.join((cuda/name).read_text() for name in ['enthalpy_kernel.cu','column_heat_kernel.cu'])
needle='        bool good=heat_evaluate(h,old,mass,z,solar,conduct,ns,props,bc,phase,residual,t,d,liq,flux,top,rounding);'
assert original.count(needle)==1
fallback='''
        if(!accepted) {
            int worst=0;float peak=-1.f;
            for(int i=0;i<ns+4;++i){float ratio=fabsf(residual[i])/weights[i];if(ratio>peak){peak=ratio;worst=i;}}
            float derivative=d[worst];
            if(at0[worst])derivative=residual[worst]>0.f?1.f/(2100.f*mass[worst]):0.f;
            if(at1[worst])derivative=residual[worst]<0.f?1.f/(4180.f*mass[worst]):0.f;
            float up=worst==0?0.f:conduct[worst-1],down=worst==8?0.f:conduct[worst];
            float diagonal=1.f+(bc[0]*((up+down)+(worst==0?bc[3]:0.f)))*derivative;
            float correction=-residual[worst]/diagonal;
            float scalar_step=1.f;
            float e0=-h[worst]/(correction!=0.f?correction:1.f),e1=(upperH[worst]-h[worst])/(correction!=0.f?correction:1.f);
            bool land0=worst<ns&&!at0[worst]&&correction!=0.f&&e0>0.f&&e0<=1.f;
            bool land1=worst<ns&&!at1[worst]&&correction!=0.f&&e1>0.f&&e1<=1.f;
            if(land0)scalar_step=fminf(scalar_step,e0);if(land1)scalar_step=fminf(scalar_step,e1);
            for(int search=0;search<40&&!accepted;++search) {
                for(int i=0;i<9;++i)candidate[i]=h[i];
                candidate[worst]=h[worst]+scalar_step*correction;
                if(land0&&scalar_step==e0)candidate[worst]=0.f;
                else if(land1&&scalar_step==e1)candidate[worst]=upperH[worst];
                bool good=heat_evaluate(candidate,old,mass,z,solar,conduct,ns,props,bc,phase,
                    trial_r,trial_t,trial_d,trial_liq,trial_f,trial_top,trial_rounding);
                float trial_merit=0.f;for(int i=0;i<9;++i)trial_merit+=fabsf(trial_r[i])/weights[i];
                accepted=good&&(trial_merit<merit||heat_norm(trial_r,candidate,tolerance,trial_rounding,conduct,bc)<=1.f);
                if(accepted)for(int i=0;i<9;++i)h[i]=candidate[i];
                scalar_step*=.5f;
            }
        }
'''
sources={'original':original,'coordinate':original.replace(needle,fallback+needle)}
outcomes={}
for name,source in sources.items():
    module=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_joint_heat',))
    result=cp.empty((1,77),cp.float32)
    module.get_function('run_joint_heat')((1,),(32,),(*[cp.asarray(a) for a in [cells,props,options,boundary]],result,np.int32(1)))
    value=cp.asnumpy(result);np.save(dest/(name+'.npy'),value,allow_pickle=False)
    if name=='original':np.testing.assert_array_equal(value,retained)
    outcomes[name]=dict(converged=bool(value[0,75]),iterations=float(value[0,74]),
        residual=value[0,45:54].tolist(),tolerance=value[0,62:71].tolist(),
        norm=float(np.max(abs(value[0,45:54])/value[0,62:71])),
        temperature=value[0,9:18].tolist(),enthalpy=value[0,:9].tolist(),
        source_sha256=hashlib.sha256(source.encode()).hexdigest())
summary=dict(scope='Isolated coordinate-Newton fallback after original failed line search. Every original acceptance bound and the80/40 iteration limits retained; no production change.',outcomes=outcomes)
(dest/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
(dest/'experimental-kernel.cu').write_text(sources['coordinate'])
print(json.dumps(summary),flush=True)

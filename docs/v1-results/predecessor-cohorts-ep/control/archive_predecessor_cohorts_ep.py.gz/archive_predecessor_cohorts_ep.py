from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[];records=[]
for name,manifest in [('bounded-coupled-de','c0cabf3002a8f8ed7960559d0352bc6529f46a20ce8d75aca406b20ff1efd166'),('wet-coupled-gpu-br','540040b608ea1ac6b517c3cfdecd81e31b67291566073015386618f67fc89d95')]:
    r=b/name;d=json.loads((r/'exit.json').read_text());assert d['passed'] and d['returncode']==0 and d['source_unchanged'] and d['source_manifest_sha256']==manifest and len(d['records'])==6;count=0
    for row in d['records']:
        stem=Path(row['file']).stem;p=r/(stem+'-receipt.json');q=json.loads(p.read_text());assert row['passed'] and row['actual_parent_returncode']==0 and row['receipt_sha256']==sha(p) and q['source_unchanged'] and q['source_manifest_sha256']==manifest and q['node_coverage_exact'] and q['all_setup_call_teardown_phases_passed'] and q['counts']['failures']==q['counts']['errors']==q['counts']['skipped']==0 and sha(r/(stem+'.xml'))==q['xml_sha256'];count+=q['counts']['tests']
    assert count==22;records.append(dict(root=name,source_manifest_sha256=manifest,actual_parent_returncode=0,tests=22,seconds=d['seconds'],scope='Predecessor execution only, not currentEC test credit'))
    items.extend((p,name+'/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file())
r=b/'qia-bounded-capacity-cuda-year-cy';e=json.loads((r/'year-exit.json').read_text());d=json.loads((r/'year-receipt.json').read_text());assert e['returncode']==1 and not e['passed'] and sha(r/'year-receipt.json')==e['receipt_sha256'] and d['failure'] and d['source_unchanged'] and d['source_manifest_sha256']=='c0cabf3002a8f8ed7960559d0352bc6529f46a20ce8d75aca406b20ff1efd166' and d['status']=='failed' and d['steps_completed']==16560 and d['steps_requested']==17520 and sha(r/'trajectory/batch.json')==d['report_sha256']
selected=set()
for pointer in [r/'trajectory/batch.json',r/'validated-prefix-report.json']:
    report=json.loads(pointer.read_text());selected.add(pointer);selected.add(r/'trajectory'/report['checkpoint_file'])
    assert sha(r/'trajectory'/report['checkpoint_file'])==report['checkpoint_sha256']
    for name,descriptor in report['case_reports'].items():
        p=r/'trajectory'/name/descriptor['file'];assert sha(p)==descriptor['sha256'];selected.add(p);case=json.loads(p.read_text());p=p.parent/case['model_npz'];assert sha(p)==case['model_npz_sha256'];selected.add(p)
inventory=[]
for p in sorted(r.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(r);preserved=rel.parts[0]!='trajectory' or p in selected
    inventory.append(dict(path=rel.as_posix(),sha256=sha(p),bytes=p.stat().st_size,in_evidence_snapshot=preserved))
    if preserved:items.append((p,'failed-capacity-year/'+rel.as_posix()))
inventory_path=b/'predecessor-capacity-year-ep-inventory.json';assert not inventory_path.exists();inventory_path.write_text(json.dumps(dict(immutable_remote_root=str(r),files=inventory,scope='Every originalrawfile hashed; original454MiB history remains onxuanze untouched. Git snapshot retains exactfailed16560 and validated48 generations, allprefixstepcaptures/inputs/logs/receipts/firstcontinuedstep and completeinventory, rather than duplicating everyintermediate cumulative trace.'),indent=2)+'\n');items.append((inventory_path,'failed-capacity-year/raw-inventory.json'))
items.append((b/Path(__file__).name,'control/'+Path(__file__).name));a=b/'predecessor-cohorts-ep-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),records=records,capacity_year_actual_parent_returncode=1,capacity_year_failed_steps=16560)),flush=True)

# BZ: user requested physical CUDA 1. Applied before any device imports.
from pathlib import Path as _RoutePath
import datetime as _rd, json as _rj, os as _ro, subprocess as _rsp, sys as _rs, time as _rt
_rr=_RoutePath('/home/lhwang/work/noahmp-v1/wet-coupled-gpu-br')
_rf=_RoutePath(_rs.argv[_rs.argv.index('--test-file')+1]).stem
_ru='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
_rb=_rt.monotonic()
while True:
    _free=int(_rsp.check_output(['nvidia-smi','--id='+_ru,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    _mem=int(next(v.split()[1] for v in _RoutePath('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
    _ready=_free>8192 and _mem>32*1024*1024
    _row=dict(utc=_rd.datetime.now(_rd.timezone.utc).isoformat(),pid=_ro.getpid(),test_file=_rf,physical_gpu_index=1,physical_gpu_uuid=_ru,logical_device_index=0,gpu_free_mib=_free,host_available_kib=_mem,resource_guards_unchanged=True,ready=_ready,wait_seconds=_rt.monotonic()-_rb)
    (_rr/(_rf+'-gpu-route-bz.json')).write_text(_rj.dumps(_row,indent=2)+'\n')
    if _ready:break
    _rt.sleep(20.)
_ro.environ['CUDA_VISIBLE_DEVICES']=_ru
from pathlib import Path
import hashlib,json,runpy
b=Path('/home/lhwang/work/noahmp-v1');r=b/'wet-coupled-gpu-br';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def blocked(*args,**kwargs):raise AssertionError('CoupledGPU validation must use EHPC offline references, no NumPy forward physics')
import noahmp_clm.clm_enthalpy_driver as column
import noahmp_clm.physics.richards as flow
import noahmp_clm.physics.canopy_phase_energy as phase
import run_fluxnet_column as runner
column.step_clm_enthalpy_column=blocked;flow.redistribute_soil_enthalpy=blocked;phase.solve_canopy_phase_energy=blocked;runner.step_clm_enthalpy_column=blocked
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';assert sha(s/'SOURCE_SHA256.json')=='540040b608ea1ac6b517c3cfdecd81e31b67291566073015386618f67fc89d95';runpy.run_path(str(worker),run_name='__main__')

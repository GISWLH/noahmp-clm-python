"""EHPC-only exact original training-year inputs, no forward model or cold state."""
from pathlib import Path
import argparse
import copy
import importlib.util
import io
import json
import os
import sys
import tarfile
import time
import traceback

from year_inputs_ou import compute_only, prefix_arrays, same_arrays, sha, validate_year, validate_continuity

HERE = Path(__file__).resolve().parent


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def read_tar(path, expected):
    raw = path.read_bytes()
    if sha(raw) != expected:
        raise ValueError('Archive identity mismatch: ' + str(path))
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: archive.extractfile(m).read() for m in members}


def second_metadata(original, site, year, npz_sha, full_spec, binding):
    # Full-container summaries are provenance only, never new annual statistics.
    value = copy.deepcopy(original)
    summaries = {key: value.pop(key) for key in ('qc_counts', 'total_precipitation_mm',
                 'low_sun_positive_shortwave_rows', 'low_sun_positive_shortwave_jm2') if key in value}
    all_repairs = value.pop('humidity_repairs', [])
    value.update(site=site, start=f'{year}-01-01', end_exclusive=f'{year + 1}-01-01', steps=17568,
                 prepared_npz_sha256=npz_sha,
                 scope='OU exact second training-year slice, no regeneration, repair, QC change, fitting or physical execution.',
                 humidity_repairs=[row for row in all_repairs if row['timestamp_start'].startswith(str(year))],
                 source_humidity_repairs=all_repairs,
                 source_full_period_summaries=summaries,
                 source_summary_scope='Unmodified original full-container statistics; not annual statistics for this slice.',
                 source_full_period=dict(start=original['start'], end_exclusive=original['end_exclusive']),
                 full_source_npz_sha256=full_spec['npz_sha256'], full_source_manifest_sha256=full_spec['manifest_sha256'],
                 original_archive_sha256=binding['full_archive']['sha256'],
                 original_rows=dict(start_inclusive=17520, stop_exclusive=35088),
                 preserved_array_policy='Every original field, dtype and payload retained by slice; no recalculation of CO2, solar, humidity, observations or QC.')
    return value


def run(args):
    compute_only()
    import numpy as np
    begun = time.monotonic()
    controls_raw = (HERE / 'CONTROLS_SHA256.json').read_bytes()
    controls = json.loads(controls_raw)
    assert all(sha((HERE / name).read_bytes()) == digest for name, digest in controls.items())
    binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
    root = args.output.resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    receipt = dict(passed=False, pbs_job=os.environ['PBS_JOBID'], node='compute002', model_steps=0,
                   cold_state_created=False, actual_spinup=False, actual_candidate_scoring=False,
                   controls_manifest_sha256=sha(controls_raw), decoded_later_rows=0)
    try:
        model = read_tar(args.source_archive, binding['source']['archive_sha256'])
        model_index = json.loads(model['SOURCE_SHA256.json'])
        assert sha(model['SOURCE_SHA256.json']) == binding['source']['manifest_sha256']
        assert model_index == binding['source']['members_sha256'] and len(model_index) == 584
        assert set(model) == set(model_index) | {'SOURCE_SHA256.json'}
        assert all(sha(model[name]) == digest for name, digest in model_index.items())
        source = root / 'private-source'
        for name, raw in model.items():
            target = source / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        sys.path[:0] = [str(source / 'benchmarks'), str(source / 'src')]
        spec = importlib.util.spec_from_file_location('ou_original_runner', source / 'benchmarks/run_fluxnet_column.py')
        runner = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(runner)
        assert Path(runner.__file__).resolve() == (source / 'benchmarks/run_fluxnet_column.py').resolve()
        jr = read_tar(args.jr_archive, binding['jr']['archive_sha256'])
        assert {name: sha(raw) for name, raw in jr.items()} == binding['jr']['members_sha256'] and len(jr) == 34
        jr_protocol = json.loads(jr['protocol.json'])
        assert jr_protocol['source_manifest_sha256'] == binding['jr']['original_JN_source_manifest_sha256']
        assert jr_protocol['source_unchanged'] is True and jr_protocol['case_count'] == 12
        assert sha(args.full_archive.read_bytes()) == binding['full_archive']['sha256']
        output = root / 'year-inputs'
        output.mkdir()
        rows = []
        with tarfile.open(args.full_archive) as archive:
            members = archive.getmembers()
            assert len(members) == 8 and all(m.isfile() for m in members)
            assert len({m.name for m in members}) == 8
            for site, full_spec in binding['training_sites'].items():
                full_raw = archive.extractfile(site + '.npz').read()
                meta_raw = archive.extractfile(site + '.json').read()
                assert sha(full_raw) == full_spec['npz_sha256'] and sha(meta_raw) == full_spec['manifest_sha256']
                metadata = json.loads(meta_raw)
                assert metadata['steps'] == full_spec['container_steps'] and metadata['prepared_npz_sha256'] == full_spec['npz_sha256']
                first_year, second_year = full_spec['years']
                assert metadata['start'] == f'{first_year}-01-01' and metadata['dt_seconds'] == 1800.
                arrays, prefix_sha = prefix_arrays(full_raw, binding['array_descriptors'][site], full_spec['container_steps'])
                first = {name: value[:17520] for name, value in arrays.items()}
                second = {name: value[17520:35088] for name, value in arrays.items()}
                with np.load(io.BytesIO(jr[site + '.npz']), allow_pickle=False) as original:
                    first_proof = same_arrays(first, dict(original))
                assert validate_year(site, first_year, first) == 17520
                assert validate_year(site, second_year, second) == 17568
                validate_continuity(first, second)
                first_npz, first_meta = output / f'{site}-{first_year}.npz', output / f'{site}-{first_year}.json'
                first_npz.write_bytes(jr[site + '.npz'])
                first_meta.write_bytes(jr[site + '.json'])
                first_metadata = json.loads(first_meta.read_bytes())
                assert first_metadata['full_source_npz_sha256'] == full_spec['npz_sha256']
                assert first_metadata['full_source_manifest_sha256'] == full_spec['manifest_sha256']
                assert len(runner.validate_input(first, first_metadata, first_npz)) == 17520
                second_npz = output / f'{site}-{second_year}.npz'
                with second_npz.open('wb') as stream:
                    np.savez_compressed(stream, **second)
                with np.load(second_npz, allow_pickle=False) as reread:
                    second_proof = same_arrays(dict(reread), second)
                second_meta = output / f'{site}-{second_year}.json'
                derived_metadata = second_metadata(metadata, site, second_year, sha(second_npz.read_bytes()), full_spec, binding)
                save(second_meta, derived_metadata)
                assert len(runner.validate_input(second, derived_metadata, second_npz)) == 17568
                for key in ['latitude', 'longitude', 'utc_offset_hours', 'timezone', 'dt_seconds', 'forcing_columns', 'environment_columns', 'solar_diagnostics_columns']:
                    assert first_metadata[key] == derived_metadata[key]
                for year, count, npz, meta, proof, reused in [
                    (first_year, 17520, first_npz, first_meta, first_proof, True),
                    (second_year, 17568, second_npz, second_meta, second_proof, False)]:
                    rows.append(dict(site=site, year=year, steps=count, first_year_reused_original_bytes=reused,
                        npz=npz.relative_to(root).as_posix(), npz_sha256=sha(npz.read_bytes()),
                        metadata=meta.relative_to(root).as_posix(), metadata_sha256=sha(meta.read_bytes()),
                        arrays=proof, full_training_prefix_payload_sha256=prefix_sha,
                        complete_calendar=True, original_validate_input_succeeded=True))
        source_proof = {name: sha((source / name).read_bytes()) for name in model_index}
        assert source_proof == model_index
        for path, digest in [(args.full_archive, binding['full_archive']['sha256']),
                             (args.jr_archive, binding['jr']['archive_sha256']),
                             (args.source_archive, binding['source']['archive_sha256'])]:
            assert sha(path.read_bytes()) == digest
        assert all(sha((HERE / name).read_bytes()) == digest for name, digest in controls.items())
        save(root / 'YEAR_IDENTITIES.json', dict(rows=rows, original_JN_input_identity=binding['jr']['original_JN_source_manifest_sha256'],
            source_manifest_sha256=binding['source']['manifest_sha256'], production_launch_allowed=False,
            reference_only=True, actual_spinup=False, configuration_year_rule='Original case and each candidate configuration SHA unchanged; only forcing and metadata pointers differ.'))
        save(root / 'CASE_YEAR_REFERENCE_ONLY.json', dict(original_cases=binding['original_training_cases'],
            original_OM_applied_configurations=binding['OM_applied_configuration_identities'],
            production_launch_allowed=False, executable_batch_created=False,
            notes='Not a native batch or initialized state. Configurations are not copied, renamed, generated or edited. Candidate own-state/spinup and original source/ledger delivery must be resolved separately.'))
        receipt.update(passed=True, training_site_years=4, fields_per_year=38, first_year_files_reused=4,
                       second_year_steps_each=17568, decoded_prefix_rows_each=35088, source_files_verified=584,
                       original_JR_members_verified=34, original_runner_validate_input_calls=4,
                       existing_configuration_changes=0, original_inputs_and_source_unchanged=True,
                       scope='Read-only original training prefixes to byte-bound annual input artifacts; no physical run, cold state, spinup or score.')
    except Exception:
        receipt['failure'] = traceback.format_exc()
        (root / 'failure.txt').write_text(receipt['failure'])
    receipt['seconds'] = time.monotonic() - begun
    save(root / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['passed'] else 1


def main():
    parser = argparse.ArgumentParser()
    for name in ['full-archive', 'jr-archive', 'source-archive', 'output']:
        parser.add_argument('--' + name, type=Path, required=True)
    return run(parser.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())

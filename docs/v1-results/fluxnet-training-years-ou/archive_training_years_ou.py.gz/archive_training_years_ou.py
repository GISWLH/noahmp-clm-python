"""Seal actual closed OU input-only PBS results, preserving failures and original bytes."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-fluxnet-training-years-ou')
STAGE = Path('/tmp/fluxnet-training-years-ou-stage.tar.gz')
STAGE_SHA = 'ad50bf892b0ba3ef70167309cb01a3a8ebeb60d534fa3bae979182ddbe406092'
PREP_SHA = 'a36f6dbda7ad18c86cda638865d2353187ae04605a8f47a3256e6853276fb9d6'
LABEL = 'fluxnet-training-years-ou'
SOURCE = 'inputs/climatology-final-candidate-nm-source.tar.gz'
JR = 'inputs/multisite-climatology-jr-inputs.tar.gz'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def files(raw):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for member in archive.getmembers():
            if member.isdir():
                continue
            name = member.name.removeprefix('./')
            assert member.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts
            assert '\\' not in name and name not in result
            result[name] = archive.extractfile(member).read()
    return result


def main():
    assert socket.gethostname() == 'manager'
    dispatch = json.loads((ROOT / 'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == '1600.manager' and dispatch['stage_archive_sha256'] == STAGE_SHA
    query = subprocess.run(['qstat', '-xf', dispatch['pbs_job']], capture_output=True)
    assert query.returncode == 0, query.stderr.decode()
    text = query.stdout.decode()
    assert re.search(r'^\s*job_state = F\s*$', text, re.M), text
    exit_code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', text, re.M).group(1))
    stage_raw = STAGE.read_bytes()
    assert sha(stage_raw) == STAGE_SHA
    stage = files(stage_raw)
    stage_index = json.loads(stage['stage-inventory.json'])
    assert set(stage_index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[name]) == value and (ROOT / name).read_bytes() == stage[name]
               for name, value in stage_index.items())
    compute_exit = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'pbs-exit.txt')], capture_output=True)
    assert compute_exit.returncode == 0 and int(compute_exit.stdout.strip()) == exit_code
    remote = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'result.tar.gz')], capture_output=True)
    assert remote.returncode == 0, remote.stderr.decode()
    result = files(remote.stdout)
    assert int(result['worker-exit.txt'].strip()) == exit_code
    receipt = json.loads(result['receipt.json'])
    assert receipt['pbs_job'] == dispatch['pbs_job'] and receipt['node'] == 'compute002'
    assert receipt['model_steps'] == 0 and receipt['cold_state_created'] is False
    assert receipt['actual_spinup'] is False and receipt['actual_candidate_scoring'] is False
    assert receipt['new_GPU_tasks'] == 0
    source_files = files(stage[SOURCE])
    private_prefix = 'prepared-inputs/private-source/'
    if exit_code == 0:
        assert receipt['passed'] and receipt['preparation_parent_returncode'] == receipt['unittest_parent_returncode'] == 0
        assert receipt['tests'] == 6 and receipt['training_years'] == 4 and receipt['field_byte_proofs'] == 152
        assert receipt['decoded_later_rows'] == 0 and receipt['source_files_verified'] == 584
        assert receipt['JR_members_verified'] == 34 and receipt['first_year_files_exactly_reused'] == 4
        assert receipt['original_validate_input_calls'] == 4 and receipt['source_and_controls_unchanged']
        assert receipt['controls_manifest_sha256'] == PREP_SHA
        assert receipt['execution_manifest_sha256'] == sha(stage['execution/CONTROLS_SHA256.json'])
        assert receipt['root_review_sha256'] == sha(stage['root-review.json'])
        assert 'Ran 6 tests' in result['unittest.stderr.txt'].decode() and '\nOK\n' in result['unittest.stderr.txt'].decode()
        for name in stage_index:
            if name.startswith(('preparation/', 'execution/')):
                assert result[name] == stage[name]
        assert {name.removeprefix(private_prefix): value for name, value in result.items()
                if name.startswith(private_prefix)} == source_files
        assert len(source_files) == 585
        assert sha(result['prepared-inputs/receipt.json']) == receipt['prepared_receipt_sha256']
        assert sha(result['prepared-inputs/YEAR_IDENTITIES.json']) == receipt['year_identities_sha256']
        identities = json.loads(result['prepared-inputs/YEAR_IDENTITIES.json'])
        rows = identities['rows']
        assert len(rows) == 4 and {(r['site'], r['year'], r['steps']) for r in rows} == {
            ('CN-Cng', 2007, 17520), ('CN-Cng', 2008, 17568), ('CN-Qia', 2003, 17520), ('CN-Qia', 2004, 17568)}
        for row in rows:
            assert len(row['arrays']) == 38 and row['complete_calendar'] and row['original_validate_input_succeeded']
            assert sha(result['prepared-inputs/' + row['npz']]) == row['npz_sha256']
            assert sha(result['prepared-inputs/' + row['metadata']]) == row['metadata_sha256']
    # Exact original result retains every extracted source byte without expanding 585 files into publication.
    artifacts = {'current/' + name: raw for name, raw in result.items() if not name.startswith(private_prefix)}
    artifacts.update({'original-stage.tar.gz': stage_raw, 'original-result.tar.gz': remote.stdout,
        'actual-pbs-qstat.txt': query.stdout, 'actual-pbs-qstat.stderr.txt': query.stderr,
        'pbs-exit.txt': compute_exit.stdout, 'archive_training_years_ou.py': Path(__file__).read_bytes(),
        'source-retention.json': blob(dict(private_source_prefix=private_prefix,
            original_source_archive_sha256=sha(stage[SOURCE]), original_source_archive_members=len(source_files),
            source_retained_in_original_result=True, source_bytes_checked_against_original_archive=exit_code == 0,
            no_model_execution=True))})
    for name in ['dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'compute-extract.stdout.txt',
                 'compute-extract.stderr.txt', 'compute-file-hashes.txt']:
        artifacts['manager/' + name] = (ROOT / name).read_bytes()
    output = ROOT / 'pbs-output.log'
    artifacts['manager/pbs-output-presence.json'] = blob(dict(path=str(output), exists=output.exists(),
        note='Worker stdout/stderr redirected into original controller.log; an absent PBS shell log is not fabricated.'))
    if output.exists():
        artifacts['manager/pbs-output.log'] = output.read_bytes()
    inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in artifacts.items()}
    artifacts['inventory.json'] = blob(inventory)
    destination = ROOT / (LABEL + '-evidence.tar.gz')
    assert not destination.exists()
    with tarfile.open(destination, 'w:gz') as archive:
        for name, raw in sorted(artifacts.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
    assert files(destination.read_bytes()) == artifacts
    package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
        artifacts=len(artifacts), pbs_job=dispatch['pbs_job'], actual_pbs_state='F', actual_pbs_exit=exit_code,
        actual_worker_exit=int(result['worker-exit.txt'].strip()), passed=receipt['passed'],
        stage_archive_sha256=STAGE_SHA, result_archive_sha256=sha(remote.stdout),
        tests=receipt.get('tests'), training_years=receipt.get('training_years'), field_byte_proofs=receipt.get('field_byte_proofs'),
        model_steps=0, decoded_later_rows=receipt.get('decoded_later_rows'), first_year_metadata_unchanged=exit_code == 0,
        source_archive_sha256=sha(stage[SOURCE]), source_files=584, JR_archive_sha256=sha(stage[JR]),
        controls_manifest_sha256=PREP_SHA,
        scope='OU original training-only input preparation: two exact JR first years and two complete original leap-year slices, 38 fields each, four original validate_input calls, six synthetic byte/time tests. No physical model, cold state, spinup, score, held-out numerical payload or scientific acceptance.')
    (ROOT / (LABEL + '-package.json')).write_bytes(blob(package))
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()

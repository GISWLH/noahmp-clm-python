"""Build minimal OU EHPC execution wrappers and a byte-bound stage; stdlib only."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
EXEC = ROOT / 'fluxnet-training-years-ou-execution'
PREP = ROOT / 'fluxnet-training-years-ou-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    review = (ROOT / 'fluxnet-training-years-ou-root-review.json').read_bytes()
    assert sha(review) == 'e16c1e42058ce08ad3c40b7122baff1e969774313ee61c0e0ca8abc926421118'
    manifest = (PREP / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(manifest) == 'a36f6dbda7ad18c86cda638865d2353187ae04605a8f47a3256e6853276fb9d6'
    origin = ROOT / 'spinup-seed-comparison-op-execution'
    dispatcher = (origin / 'dispatch_synthetic_op.py').read_text()
    replacements = [
        ('OP synthetic tests', 'OU original input slicing and tests'),
        ('noahmp-spinup-seed-comparison-op', 'noahmp-fluxnet-training-years-ou'),
        ('dispatch_synthetic_op.py', 'dispatch_inputs_ou.py'),
        ('dispatch_spinup_synthetic_op.py', 'dispatch_training_inputs_ou.py'),
        ('bfd6542662055fc37f0d0134c9c063b3ff0a30a54e3ae13cc819945261970dcd', sha(review)),
        ("review['controls'] == 6", "review['controls'] == 7"),
        ('synthetic_op.pbs', 'inputs_ou.pbs'),
        ('1CPU/2GB/5min', '1CPU/2GB/10min'),
    ]
    for old, new in replacements:
        assert old in dispatcher
        dispatcher = dispatcher.replace(old, new)
    (EXEC / 'dispatch_inputs_ou.py').write_bytes(dispatcher.encode())
    pbs = (origin / 'synthetic_op.pbs').read_text()
    for old, new in [('spinup-seed-op', 'training-years-ou'),
                     ('noahmp-spinup-seed-comparison-op', 'noahmp-fluxnet-training-years-ou'),
                     ('00:05:00', '00:10:00'), ('run_synthetic_op.py', 'run_inputs_ou.py'),
                     ('synthetic_op.pbs', 'inputs_ou.pbs')]:
        assert old in pbs
        pbs = pbs.replace(old, new)
    (EXEC / 'inputs_ou.pbs').write_bytes(pbs.encode())
    names = ['run_inputs_ou.py', 'dispatch_inputs_ou.py', 'inputs_ou.pbs']
    for name in names[:2]:
        ast.parse((EXEC / name).read_bytes(), filename=name)
    lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(EXEC)], capture_output=True, text=True)
    assert lint.returncode == 0, lint.stdout + lint.stderr
    controls = {name: sha((EXEC / name).read_bytes()) for name in names}
    (EXEC / 'CONTROLS_SHA256.json').write_bytes((json.dumps(controls, indent=2) + '\n').encode())
    prep_index = json.loads(manifest)
    assert len(prep_index) == 7 and all(sha((PREP / name).read_bytes()) == digest for name, digest in prep_index.items())
    files = {f'preparation/{name}': (PREP / name).read_bytes() for name in [*prep_index, 'CONTROLS_SHA256.json']}
    files.update({f'execution/{name}': (EXEC / name).read_bytes() for name in [*names, 'CONTROLS_SHA256.json']})
    files['root-review.json'] = review
    for name in ['climatology-final-candidate-nm-source.tar.gz', 'multisite-climatology-jr-inputs.tar.gz']:
        files['inputs/' + name] = (ROOT / name).read_bytes()
    for name in ['prepare_training_years_ou_metadata.py', 'fluxnet-training-years-ou-prepared.json',
                 'prepare_training_years_execution_ou.py']:
        files['provenance/' + name] = (ROOT / name).read_bytes()
    index = {name: sha(raw) for name, raw in files.items()}
    files['stage-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
    destination = ROOT / 'fluxnet-training-years-ou-stage.tar.gz'
    assert not destination.exists()
    with tarfile.open(destination, 'w:gz') as archive:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
    with tarfile.open(destination) as archive:
        actual = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
    assert actual == files
    result = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
        artifacts=len(files), inventory=index, controls_manifest_sha256=sha(manifest),
        execution_manifest_sha256=sha(files['execution/CONTROLS_SHA256.json']),
        wrapper_AST_F821_exit=0, model_steps=0, actual_input_slicing_executed=False,
        scope='Prepared minimal OU input-only EHPC execution stage. Original full observation archive stays read-only at its fixed EHPC path.')
    (ROOT / 'fluxnet-training-years-ou-stage-package.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'inventory'}))


if __name__ == '__main__':
    main()

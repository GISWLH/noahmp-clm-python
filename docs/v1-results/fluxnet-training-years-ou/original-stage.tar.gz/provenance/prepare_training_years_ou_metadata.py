"""Prepare OU frozen identities/header contracts using stdlib only, not arrays."""
from pathlib import Path
import ast
import hashlib
import io
import json
import struct
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
HERE = ROOT / 'fluxnet-training-years-ou-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, obj):
    (HERE / name).write_bytes((json.dumps(obj, indent=2, allow_nan=False) + '\n').encode())


def read_tar(name, expected):
    raw = (ROOT / name).read_bytes()
    assert sha(raw) == expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(m.isfile() for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: archive.extractfile(m).read() for m in members}


def headers(raw):
    result = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        for name in archive.namelist():
            assert name.endswith('.npy') and '/' not in name
            with archive.open(name) as member:
                assert member.read(6) == b'\x93NUMPY'
                version = tuple(member.read(2))
                assert version in [(1, 0), (2, 0)]
                width = 2 if version[0] == 1 else 4
                count = struct.unpack('<H' if width == 2 else '<I', member.read(width))[0]
                header = ast.literal_eval(member.read(count).decode('latin1'))
                assert header['fortran_order'] is False and header['shape'][0] == 17520
                result[name[:-4]] = dict(dtype=header['descr'], trailing_shape=list(header['shape'][1:]))
    return result


def main():
    HERE.mkdir(exist_ok=True)
    on_raw = (ROOT / 'fluxnet-training-reference-on-preparation/INPUT_BINDINGS.json').read_bytes()
    on = json.loads(on_raw)
    (HERE / 'ON_INPUT_BINDINGS.json').write_bytes(on_raw)
    source_raw = read_tar('climatology-final-candidate-nm-source.tar.gz', '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d')
    sources = json.loads(source_raw['SOURCE_SHA256.json'])
    assert len(sources) == 584 and all(sha(source_raw[name]) == value for name, value in sources.items())
    jr = read_tar('multisite-climatology-jr-inputs.tar.gz', 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b')
    assert len(jr) == 34
    jr_protocol = json.loads(jr['protocol.json'])
    assert jr_protocol['source_manifest_sha256'] == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
    assert jr_protocol['source_unchanged'] is True and jr_protocol['case_count'] == 12
    descriptors = {site: headers(jr[site + '.npz']) for site in on['training_sites']}
    assert all(len(v) == 38 for v in descriptors.values()) and descriptors['CN-Cng'] == descriptors['CN-Qia']
    om_binding_raw = (ROOT / 'fluxnet-calibration-om-preparation/SOURCE_BINDINGS.json').read_bytes()
    om_binding = json.loads(om_binding_raw)
    registry = [row for row in om_binding['allowed_original_configurations'] if row['site'] in on['training_sites']]
    assert len(registry) == 8
    for row in registry:
        assert sha(jr[row['member']]) == row['sha256']
        assert json.loads(jr[row['member']])['case'] == row['case']
    om = read_tar('fluxnet-calibration-om-evidence.tar.gz', '1581110dab18462127cb4baf54eef327de9bfd15eb3da72d3dc01670512ba7ac')
    applied = []
    for name, raw in om.items():
        path = Path(name)
        if name.startswith('result/applied/') and path.suffix == '.json' and not path.stem.endswith('-receipt'):
            config = json.loads(raw)
            registered, = [row for row in registry if row['case'] == config['case']]
            receipt = json.loads(om[name[:-5] + '-receipt.json'])
            assert receipt['original_config_sha256'] == registered['sha256']
            applied.append(dict(candidate=path.parent.name, case=config['case'], site=config['site'],
                original_config_sha256=registered['sha256'], candidate_config_sha256=sha(raw), original_OM_member=name,
                first_year=on['training_sites'][config['site']]['years'][0], second_year=on['training_sites'][config['site']]['years'][1],
                same_config_sha_required_both_years=True))
    assert len(applied) == 184 and len({r['candidate'] for r in applied}) == 23
    binding = dict(scope='OU prepare only: original four training-year input identities, no models/cold states/candidate configuration changes.',
        full_archive=dict(path=on['remote_archive'], sha256=on['original_archive_sha256'], bytes=on['original_archive_bytes']),
        training_sites=on['training_sites'], on_input_bindings_sha256=sha(on_raw),
        jr=dict(archive_sha256='deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b',
                members_sha256={name: sha(raw) for name, raw in jr.items()},
                original_JN_source_manifest_sha256=jr_protocol['source_manifest_sha256']),
        source=dict(archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',
                    manifest_sha256=sha(source_raw['SOURCE_SHA256.json']), members_sha256=sources,
                    validation_entry='benchmarks/run_fluxnet_column.py:validate_input', validation_entry_sha256=sources['benchmarks/run_fluxnet_column.py']),
        array_descriptors=descriptors, original_training_cases=registry,
        original_OM_archive_sha256='1581110dab18462127cb4baf54eef327de9bfd15eb3da72d3dc01670512ba7ac',
        original_OM_bindings_sha256=sha(om_binding_raw), OM_applied_configuration_identities=applied,
        production_launch_allowed=False, executable_batch_created=False, actual_spinup=False,
        first_year_original_metadata_note='Original JR files reused byte-for-byte. Existing qc_counts/precipitation/low-sun summaries retain original full-period scope, not annual recalculations.')
    save('BINDINGS.json', binding)
    static = {}
    for path in HERE.glob('*.py'):
        tree = ast.parse(path.read_bytes(), filename=path.name)
        static[path.name] = dict(sha256=sha(path.read_bytes()), tests=[n.name for n in ast.walk(tree)
            if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')])
    save('STATIC_REVIEW.json', dict(mode='Stdlib header/JSON/hash/AST only. No array payload decoded or NumPy imported.',
        source_files_verified=584, JR_members_verified=34, fields_per_site=38, original_case_references=8,
        original_OM_configuration_references=184, files=static, numerical_execution=False, tests_executed=False))
    controls = {path.name: sha(path.read_bytes()) for path in sorted(HERE.iterdir()) if path.is_file() and path.name != 'CONTROLS_SHA256.json'}
    save('CONTROLS_SHA256.json', controls)
    inventory = {str(path.relative_to(ROOT)).replace('\\', '/'): dict(sha256=sha(path.read_bytes()), bytes=path.stat().st_size)
                 for path in sorted(HERE.iterdir()) if path.is_file()}
    inventory[Path(__file__).name] = dict(sha256=sha(Path(__file__).read_bytes()), bytes=Path(__file__).stat().st_size)
    prepared = dict(status='prepared_only', controls=len(controls),
                    manifest_sha256=sha((HERE / 'CONTROLS_SHA256.json').read_bytes()), artifacts=inventory,
                    source_files=584, JR_members=34, original_years=4, prefix_rows_each=35088,
                    first_year_steps=17520, second_year_steps=17568, fields_per_site=38,
                    original_case_references=8, original_OM_configuration_references=184,
                    tests_prepared=sum(len(v['tests']) for v in static.values()),
                    actual_array_slicing_executed=False, tests_executed=False, model_steps=0, PBS_submitted=False,
                    source_identity='Exact NM584 source for original validate_input only; JR retains original JN provenance.',
                    pending=['Root independent static review', 'Separate EHPC1CPU2GB5-10min wrapper and actual execution',
                             'Actual F/parent status and complete artifact-byte audit before claiming annual input preparation'],
                    minimal_cli='python -B prepare_training_years_ou.py --full-archive ORIGINAL_FU --jr-archive ORIGINAL_JR --source-archive EXACT_NM584 --output NEW_PBS_TMPDIR_RESULT')
    (ROOT / 'fluxnet-training-years-ou-prepared.json').write_bytes((json.dumps(prepared, indent=2) + '\n').encode())
    print(json.dumps(dict(controls=len(controls), manifest_sha256=sha((HERE / 'CONTROLS_SHA256.json').read_bytes()),
                         source_files=584, JR_members=34, fields_per_site=38, OM_references=184, numerical_execution=False)))


if __name__ == '__main__':
    main()

# OU original continuous training-year inputs — prepared only

Only CN-Cng 2007/2008 and CN-Qia 2003/2004 are in scope. The full original archive remains SHA256 `6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c`; both sites decode only the first 35,088 original rows. The source and input archives are read-only. No held-out array payload is decoded or analyzed. Reading/hash-checking the compressed full container establishes identity and is not a statistic over later observations.

The fixed original JR archive (`deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b`) supplies 38 original field names, dtypes and trailing dimensions per site. NPY headers are inspected with the standard library during preparation; no payload is decoded locally. At runtime the reader checks every full-array descriptor, then reads precisely 35,088 rows. This includes forcing (8 columns), environment (3 columns, including existing CO2 and solar quantities), solar diagnostics, flags, all original observations and all original QC fields. No field is regenerated, repaired, imputed, normalized or selected by score.

For each site the first 17,520 rows must equal the original JR first-year arrays in field set, dtype, shape and payload bytes, including NaN payloads. Only after this check are the original first-year NPZ and metadata copied verbatim. The second 17,568 rows become the complete leap year: exact Jan1-to-Jan1 local standard time, positive intervals of exactly 1800 seconds, and the second-year first interval starts at the first-year final end. A saved second-year NPZ is read back and every array is byte-compared against its original prefix slice. Both years are also checked by the original NM `run_fluxnet_column.validate_input` function. The runner is imported from the exact verified NM584 source in PBS TMPDIR; neither `run`, `build_state`, native loading, CPU/GPU stepping nor a cold-state constructor is called.

JR's existing first-year metadata includes inherited full-container `qc_counts`, precipitation and low-sun summaries. Its original bytes remain untouched, and these summaries are not annual statistics. Second-year metadata keeps the stable geometry/time conventions, original archive/member/CO2 provenance and original preparation policy. It relocates those inherited summaries under `source_full_period_summaries`, explicitly labels their original full-period scope, and records original row boundaries and source hashes. Only the list of original humidity-repair records applicable to that year is filtered by timestamp; all original records remain under source provenance. This neither changes array values nor performs a new humidity repair. No new observational or forcing summary statistics are calculated.

The result `YEAR_IDENTITIES.json` records four actual prepared input identities and all 38 field payload identities. `CASE_YEAR_REFERENCE_ONLY.json` repeats the eight original training case/configuration identities and the 184 actually generated OM configuration hashes. Each candidate's case and configuration SHA must be identical across its two training years; only forcing and metadata references change. Nothing rewrites the year embedded in an existing case name. These are reference records, not a native batch specification, executable launch contract, initialized state, spinup result or score. The existing OM184 configurations and every active run are untouched.

`test_year_inputs_ou.py` prepares six meaningful tests: complete common/leap calendar and boundary; missing interval/held-out or noninteger year/wrong dtype; duplicated or shifted time, leap-day discontinuity and altered duration; field/dtype/shape/QC-byte changes; one-/two-dimensional prefix-only reads; and wrong descriptor/field set/overrun/truncated prefix. Synthetic inputs are explicit toy data, never model predictions.

The controls are **prepared only**. Local preparation is stdlib archive/header/JSON/hash/AST inspection. No actual annual slices or numerical tests have run. The root must review the frozen controls before a separate EHPC wrapper submits 1 CPU / 2 GB / 5–10 minutes. No scheduler, transfer or full execution framework is introduced here.

Minimal commands for a future isolated compute002 PBS job (all fresh outputs under `$TMPDIR`):

```sh
/home/zhangyq/venvs/noahmp-closeout/bin/python -B prepare_training_years_ou.py \
  --full-archive /home/zhangyq/noahmp-v1/multiyear-originals-fu.tar.gz \
  --jr-archive /path/to/exact/multisite-climatology-jr-inputs.tar.gz \
  --source-archive /path/to/exact/climatology-final-candidate-nm-source.tar.gz \
  --output "$TMPDIR/ou-inputs"
/home/zhangyq/venvs/noahmp-closeout/bin/python -B -m unittest -v test_year_inputs_ou
```

The resulting preparation can only be claimed after actual worker exit and terminal PBS status are captured. Synthetic tests or input validation alone do not establish candidate initial-state consistency, full-year model success, conservation, SOC equilibrium or scientific acceptance.

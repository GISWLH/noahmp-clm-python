"""OU time and byte negative controls; execute only on EHPC, never model code."""
from datetime import datetime, timedelta
import io
import unittest
import zipfile

import numpy as np
from year_inputs_ou import compute_only, prefix_arrays, same_arrays, validate_year, validate_continuity


def setUpModule():
    compute_only()


def year_arrays(year):
    start, end = datetime(year, 1, 1), datetime(year + 1, 1, 1)
    count = int((end - start).total_seconds() / 1800)
    starts = np.array([(start + timedelta(seconds=i * 1800)).strftime('%Y%m%d%H%M') for i in range(count)], dtype='<U12')
    ends = np.array([(start + timedelta(seconds=(i + 1) * 1800)).strftime('%Y%m%d%H%M') for i in range(count)], dtype='<U12')
    forcing = np.zeros((count, 8), dtype='<f8')
    forcing[:, 0] = 1800.
    return dict(time_start=starts, time_end=ends, forcing=forcing, environment=np.zeros((count, 3), dtype='<f8'))


def npz_raw(arrays):
    stream = io.BytesIO()
    np.savez_compressed(stream, **arrays)
    return stream.getvalue()


class YearInputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.first = year_arrays(2007)
        cls.second = year_arrays(2008)

    def test_complete_common_and_leap_years_and_contiguous_boundary(self):
        self.assertEqual(validate_year('CN-Cng', 2007, self.first), 17520)
        self.assertEqual(validate_year('CN-Cng', 2008, self.second), 17568)
        validate_continuity(self.first, self.second)

    def test_missing_interval_heldout_year_bool_year_and_wrong_time_dtype(self):
        for site, year in [('CN-Cng', 2009), ('CN-Cha', 2007), ('CN-Cng', True), ('CN-Cng', 2008.)]:
            with self.assertRaises(ValueError):
                validate_year(site, year, self.second)
        for arrays in [{k: v[:-1] for k, v in self.second.items()},
                       dict(self.second, time_start=self.second['time_start'].astype('S12'))]:
            with self.assertRaises(ValueError):
                validate_year('CN-Cng', 2008, arrays)

    def test_duplicate_shifted_calendar_leapday_loss_and_dt_mutation(self):
        for field, position, value in [('time_start', 1, self.second['time_start'][0]),
                                       ('time_end', 48 * 59, '200803010030')]:
            array = self.second[field].copy()
            array[position] = value
            with self.assertRaises(ValueError):
                validate_year('CN-Cng', 2008, dict(self.second, **{field: array}))
        forcing = self.second['forcing'].copy()
        forcing[-1, 0] = 3600.
        with self.assertRaises(ValueError):
            validate_year('CN-Cng', 2008, dict(self.second, forcing=forcing))
        bad_first = dict(self.first, time_end=np.array(['200801010030'], dtype='<U12'))
        with self.assertRaises(ValueError):
            validate_continuity(bad_first, self.second)

    def test_all_payloads_nan_bits_dtype_shape_and_field_set_are_bound(self):
        original = dict(forcing=np.arange(16, dtype='<f8').reshape(2, 8), obs=np.array([np.nan, 2.]), qc=np.array([3., 0.]))
        self.assertEqual(set(same_arrays(original, original)), set(original))
        changed = original['qc'].copy()
        changed[0] = 0.
        for arrays in [dict(original, qc=changed), dict(original, forcing=original['forcing'].astype('<f4')),
                       dict(original, forcing=original['forcing'].reshape(4, 4)),
                       {k: v for k, v in original.items() if k != 'obs'}]:
            with self.assertRaises(ValueError):
                same_arrays(arrays, original)

    def test_prefix_1d_and_2d_payloads_stop_before_later_rows(self):
        arrays = dict(forcing=np.arange(32, dtype='<f8').reshape(4, 8),
                      observations=np.array([1., np.nan, 987654321., -987654321.]))
        descriptors = dict(forcing=dict(dtype='<f8', trailing_shape=[8]), observations=dict(dtype='<f8', trailing_shape=[]))
        prefix, hashes = prefix_arrays(npz_raw(arrays), descriptors, 4, 2)
        same_arrays(prefix, {name: value[:2] for name, value in arrays.items()})
        self.assertEqual(len(prefix['observations']), 2)
        self.assertEqual(set(hashes), set(arrays))

    def test_wrong_prefix_descriptor_field_set_or_overrun_is_rejected(self):
        raw = npz_raw(dict(x=np.ones((4, 3))))
        for descriptions, rows in [({'x': dict(dtype='<f8', trailing_shape=[2])}, 2),
                                   ({'x': dict(dtype='<f4', trailing_shape=[3])}, 2),
                                   ({'missing': dict(dtype='<f8', trailing_shape=[3])}, 2),
                                   ({'x': dict(dtype='<f8', trailing_shape=[3])}, 5)]:
            with self.assertRaises(ValueError):
                prefix_arrays(raw, descriptions, 4, rows)
        # A complete header with a truncated payload must not silently return fewer rows.
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            member = archive.read('x.npy')[:-60]
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            archive.writestr('x.npy', member)
        with self.assertRaises(ValueError):
            prefix_arrays(stream.getvalue(), {'x': dict(dtype='<f8', trailing_shape=[3])}, 4, 2)


if __name__ == '__main__':
    unittest.main()

"""Training-prefix byte-preserving helpers. Numerical entry points are PBS-only."""
import ast
import calendar
from datetime import datetime, timedelta
import hashlib
import io
import os
import socket
import struct
import zipfile

TRAINING = {'CN-Cng': (2007, 2008), 'CN-Qia': (2003, 2004)}


def compute_only():
    if not os.environ.get('PBS_JOBID') or socket.gethostname() != 'compute002':
        raise RuntimeError('OU array operations require the EHPC compute002 PBS node')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def prefix_arrays(raw_npz, descriptors, full_steps, prefix_steps=35088):
    compute_only()
    import numpy as np
    if type(full_steps) is not int or type(prefix_steps) is not int or not 0 < prefix_steps <= full_steps:
        raise ValueError('Invalid prefix bounds')
    arrays, hashes = {}, {}
    with zipfile.ZipFile(io.BytesIO(raw_npz)) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != {name + '.npy' for name in descriptors}:
            raise ValueError('Every original field must be present exactly once')
        for name, expected in descriptors.items():
            with archive.open(name + '.npy') as member:
                if member.read(6) != b'\x93NUMPY':
                    raise ValueError('Unexpected NPY magic')
                version = tuple(member.read(2))
                if version not in [(1, 0), (2, 0)]:
                    raise ValueError('Unsupported original NPY header')
                width = 2 if version[0] == 1 else 4
                length = struct.unpack('<H' if width == 2 else '<I', member.read(width))[0]
                header = ast.literal_eval(member.read(length).decode('latin1'))
                shape = (full_steps, *expected['trailing_shape'])
                if header != dict(descr=expected['dtype'], fortran_order=False, shape=shape):
                    raise ValueError('Original field dtype/shape/order changed: ' + name)
                dtype = np.dtype(expected['dtype'])
                if dtype.hasobject:
                    raise ValueError('Object arrays are forbidden')
                width_items = 1
                for dimension in expected['trailing_shape']:
                    width_items *= dimension
                count = prefix_steps * width_items
                payload = member.read(count * dtype.itemsize)
                if len(payload) != count * dtype.itemsize:
                    raise ValueError('Truncated original training prefix: ' + name)
            arrays[name] = np.frombuffer(payload, dtype=dtype).reshape((prefix_steps, *expected['trailing_shape']))
            hashes[name] = sha(payload)
    return arrays, hashes


def same_arrays(actual, expected):
    compute_only()
    if set(actual) != set(expected):
        raise ValueError('Array field set changed')
    result = {}
    for name in sorted(expected):
        left, right = actual[name], expected[name]
        if left.dtype != right.dtype or left.shape != right.shape or left.tobytes() != right.tobytes():
            raise ValueError('Array bytes/dtype/shape differ: ' + name)
        result[name] = dict(dtype=left.dtype.str, shape=list(left.shape), payload_sha256=sha(left.tobytes()))
    return result


def validate_year(site, year, arrays):
    compute_only()
    import numpy as np
    if type(year) is not int or site not in TRAINING or year not in TRAINING[site]:
        raise ValueError('Only fixed original training years are supported')
    count = (366 if calendar.isleap(year) else 365) * 48
    for key in ('time_start', 'time_end'):
        value = arrays[key]
        if type(value) is not np.ndarray or value.dtype.str != '<U12' or value.shape != (count,):
            raise ValueError('Wrong complete year time dtype or length')
    if any(value.ndim < 1 or value.shape[0] != count for value in arrays.values()):
        raise ValueError('Every field must retain the complete year')
    if arrays['forcing'].shape != (count, 8) or arrays['environment'].shape != (count, 3):
        raise ValueError('Wrong original forcing/environment shape')
    if not np.all(np.isfinite(arrays['forcing'])) or not np.all(np.isfinite(arrays['environment'])):
        raise ValueError('Nonfinite prepared forcing; no repair allowed')
    if not np.all(arrays['forcing'][:, 0] == 1800.):
        raise ValueError('Every original step must be exactly1800s')
    start = datetime(year, 1, 1)
    for index in range(count):
        a = start + timedelta(seconds=1800 * index)
        b = a + timedelta(seconds=1800)
        if arrays['time_start'][index] != a.strftime('%Y%m%d%H%M') or arrays['time_end'][index] != b.strftime('%Y%m%d%H%M'):
            raise ValueError('Not an exact uninterrupted Jan1-to-Jan1 local-standard year')
    return count


def validate_continuity(first, second):
    compute_only()
    if first['time_end'][-1] != second['time_start'][0]:
        raise ValueError('Training years are not contiguous')

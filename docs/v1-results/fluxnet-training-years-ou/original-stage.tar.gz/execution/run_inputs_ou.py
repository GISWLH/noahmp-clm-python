"""Bounded EHPC OU input preparation plus six tests; no physical model run."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import traceback

STAGE = Path('/tmp/noahmp-fluxnet-training-years-ou')
FULL = Path('/home/zhangyq/noahmp-v1/multiyear-originals-fu.tar.gz')
PREP_SHA = 'a36f6dbda7ad18c86cda638865d2353187ae04605a8f47a3256e6853276fb9d6'
REVIEW_SHA = 'e16c1e42058ce08ad3c40b7122baff1e969774313ee61c0e0ca8abc926421118'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def execute(command, name, root, cwd, env, timeout):
    save(root / (name + '-command.json'), command)
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=timeout)
    (root / (name + '.stdout.txt')).write_bytes(result.stdout)
    (root / (name + '.stderr.txt')).write_bytes(result.stderr)
    return result


def main():
    assert sys.version_info >= (3, 10) and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    root = Path(sys.argv[1]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    begun = time.monotonic()
    receipt = dict(passed=False, error=None, pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
        python=sys.version, python_executable=sys.executable, preparation_parent_returncode=None,
        unittest_parent_returncode=None, model_steps=0, cold_state_created=False, actual_spinup=False,
        actual_candidate_scoring=False, new_GPU_tasks=0)
    try:
        stage_index = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / name).read_bytes()) == digest for name, digest in stage_index.items())
        prep_raw = (STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()
        assert sha(prep_raw) == PREP_SHA
        prep = json.loads(prep_raw)
        assert len(prep) == 7
        review_raw = (STAGE / 'root-review.json').read_bytes()
        assert sha(review_raw) == REVIEW_SHA
        review = json.loads(review_raw)
        assert review['passed'] and review['blocking_findings'] == [] and review['controls'] == 7
        assert review['controls_manifest_sha256'] == PREP_SHA and review['prepared_tests'] == 6
        controls_raw = (STAGE / 'execution/CONTROLS_SHA256.json').read_bytes()
        controls = json.loads(controls_raw)
        for folder, index in [('preparation', prep), ('execution', controls)]:
            target = root / folder
            target.mkdir()
            for name in [*index, 'CONTROLS_SHA256.json']:
                shutil.copyfile(STAGE / folder / name, target / name)
        shutil.copyfile(STAGE / 'root-review.json', root / 'root-review.json')
        binding = json.loads((root / 'preparation/BINDINGS.json').read_bytes())
        assert sha(FULL.read_bytes()) == binding['full_archive']['sha256']
        env = os.environ.copy()
        env.pop('PYTHONPATH', None)
        env.pop('PYTHONHOME', None)
        env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        prepared = execute([sys.executable, '-B', str(root / 'preparation/prepare_training_years_ou.py'),
            '--full-archive', str(FULL), '--jr-archive', str(STAGE / 'inputs/multisite-climatology-jr-inputs.tar.gz'),
            '--source-archive', str(STAGE / 'inputs/climatology-final-candidate-nm-source.tar.gz'),
            '--output', str(root / 'prepared-inputs')], 'prepare', root, root / 'preparation', env, 360)
        receipt['preparation_parent_returncode'] = prepared.returncode
        unit = execute([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(root / 'preparation'),
            '-p', 'test_year_inputs_ou.py', '-v'], 'unittest', root, root / 'preparation', env, 120)
        receipt['unittest_parent_returncode'] = unit.returncode
        assert prepared.returncode == 0, prepared.stderr.decode(errors='replace')
        assert unit.returncode == 0, unit.stderr.decode(errors='replace')
        assert b'Ran 6 tests' in unit.stderr and b'\nOK\n' in unit.stderr
        child = json.loads((root / 'prepared-inputs/receipt.json').read_bytes())
        assert child['passed'] and child['pbs_job'] == os.environ['PBS_JOBID']
        assert child['model_steps'] == 0 and child['cold_state_created'] is False and child['actual_spinup'] is False
        assert child['training_site_years'] == child['original_runner_validate_input_calls'] == 4
        assert child['fields_per_year'] == 38 and child['decoded_prefix_rows_each'] == 35088 and child['decoded_later_rows'] == 0
        identities = json.loads((root / 'prepared-inputs/YEAR_IDENTITIES.json').read_bytes())
        rows = identities['rows']
        assert {(v['site'], v['year'], v['steps']) for v in rows} == {
            ('CN-Cng', 2007, 17520), ('CN-Cng', 2008, 17568), ('CN-Qia', 2003, 17520), ('CN-Qia', 2004, 17568)}
        assert len(rows) == 4 and all(len(v['arrays']) == 38 and v['complete_calendar'] and v['original_validate_input_succeeded'] for v in rows)
        assert all(sha((root / 'prepared-inputs' / v['npz']).read_bytes()) == v['npz_sha256'] and
                   sha((root / 'prepared-inputs' / v['metadata']).read_bytes()) == v['metadata_sha256'] for v in rows)
        assert all(sha((root / 'preparation' / name).read_bytes()) == digest for name, digest in prep.items())
        assert all(sha((STAGE / name).read_bytes()) == digest for name, digest in stage_index.items())
        assert sha(FULL.read_bytes()) == binding['full_archive']['sha256']
        receipt.update(passed=True, tests=6, training_years=4, field_byte_proofs=152, decoded_later_rows=0,
            source_files_verified=584, JR_members_verified=34, first_year_files_exactly_reused=4,
            preparation_seconds=child['seconds'], original_validate_input_calls=4,
            controls_manifest_sha256=PREP_SHA, execution_manifest_sha256=sha(controls_raw), root_review_sha256=REVIEW_SHA,
            prepared_receipt_sha256=sha((root / 'prepared-inputs/receipt.json').read_bytes()),
            year_identities_sha256=sha((root / 'prepared-inputs/YEAR_IDENTITIES.json').read_bytes()),
            source_and_controls_unchanged=True,
            scope='Original training input preparation and synthetic byte/time tests only; no physical success, initial state, spinup, conservation or scoring claim.')
    except Exception:
        receipt['error'] = traceback.format_exc()
        (root / 'failure.txt').write_text(receipt['error'])
    receipt['seconds'] = time.monotonic() - begun
    save(root / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

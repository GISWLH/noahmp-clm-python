from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-cuda-3803-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((r/'capture-exit.json').read_text());d=json.loads((r/'surface-capture-a/receipt.json').read_text())
assert e['returncode']==0 and sha(r/'surface-capture-a/receipt.json')==e['receipt_sha256'] and d['source_unchanged'] and d['input_unchanged'] and d['device_barrier_complete']
assert sha(r/'surface-capture-a/failed-surface.npz')==d['failed_surface_sha256'] and len(d['calls'])==8 and not d['calls'][-1]['converged']
a=b/'qia-cuda-3803-capture-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['export_qia_cuda_3803_a.py','capture_qia_cuda_3803_a.py','control_qia3803_capture_a.py','launch_qia3803_capture_a.py',Path(__file__).name]:tf.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

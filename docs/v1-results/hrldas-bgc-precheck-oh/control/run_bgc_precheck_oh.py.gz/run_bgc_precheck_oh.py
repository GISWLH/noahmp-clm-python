"""PBS-only readback of the fixed sealed NY cold48 through the unmodified OF helper."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import tarfile
import time
import traceback

HERE = Path(__file__).resolve().parent
STAGE = Path(os.environ['OH_STAGE'])
OUT = Path(os.environ['OH_RESULT'])
SHA = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
SOURCE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
MANIFEST = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
DEVICE = '674b2f3f01e9ee35fbcdf35ba3221716944c2997b21ce30da60af5803703ed4c'
INPUTS = '044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e'
PRIOR = '6bb99c717288797ab4f3d1f8a3a7115343c6d9a520096340d21b0e460ffedbcc'
HELPER = '1a1da961c93c9c9648934c2ee2939658942e38150cd29751eb803fd3c98c4958'
CASES = ['CN-Qia-suction-climate-cycle', 'CN-Cha-suction-climate-cycle', 'CN-HaM-suction-climate-cycle']


def run():
    assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
    assert str(HERE).startswith(os.environ['TMPDIR'] + '/')
    controls = json.loads((HERE / 'CONTROLS_SHA256.json').read_text())
    assert all(SHA(HERE / n) == h for n, h in controls.items())
    assert SHA(HERE / 'audit_bgc_stream_of.py') == HELPER
    archives = {'candidate-source.tar.gz': SOURCE, 'cold48-evidence.tar.gz': DEVICE,
                'kg-inputs.tar.gz': INPUTS, 'prior1590-evidence.tar.gz': PRIOR}
    assert all(SHA(STAGE / n) == h for n, h in archives.items())
    with tarfile.open(STAGE / 'prior1590-evidence.tar.gz') as tf:
        prior = {m.name: tf.extractfile(m).read() for m in tf if m.isfile()}
    original = json.loads(prior['receipt.json'])
    assert original['pbs_job'] == '1590.manager' and original['passed']
    assert original['device_archive_sha256'] == DEVICE and original['source_manifest_sha256'] == MANIFEST
    assert original['physical_step_pairs'] == 144 and original['cold_fields_exact'] == 23
    assert original['all16state_chains_and_final_checkpoint_exact'] and original['returned_fields_per_batched_step'] == 313
    assert re.search(r'^\s*job_state = F\s*$', prior['actual-qstat.txt'].decode(), re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', prior['actual-qstat.txt'].decode(), re.M)
    assert int(prior['pbs-exit.txt']) == 0
    for name in ['receipt.json', 'actual-qstat.txt', 'pbs-exit.txt']:
        (OUT / ('prior1590-' + name)).write_bytes(prior[name])
    source = HERE / 'source'
    device = HERE / 'device'
    inputs = HERE / 'kg-inputs'
    for dest, archive in [(source, 'candidate-source.tar.gz'), (device, 'cold48-evidence.tar.gz'), (inputs, 'kg-inputs.tar.gz')]:
        dest.mkdir()
        with tarfile.open(STAGE / archive) as tf:
            tf.extractall(dest, filter='data')
    m = json.loads((source / 'SOURCE_SHA256.json').read_text())
    assert SHA(source / 'SOURCE_SHA256.json') == MANIFEST and len(m) == 584
    assert all(SHA(source / n) == h for n, h in m.items())
    p = device / 'current'
    reuse = json.loads((HERE / 'reference-reuse.json').read_text())
    expected = reuse['every_input_file_sha256']
    assert reuse['input_archive_sha256'] == INPUTS and len(expected) == 15
    for root in [inputs, p / 'inputs']:
        assert {v.relative_to(root).as_posix() for v in root.rglob('*') if v.is_file()} == set(expected)
        assert all(SHA(root / n) == h for n, h in expected.items())
    d = json.loads((p / 'receipt.json').read_text())
    e = json.loads((p / 'exit.json').read_text())
    assert e['passed'] and e['actual_parent_returncode'] == 0 and e['receipt_sha256'] == SHA(p / 'receipt.json')
    assert d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete']
    assert d['cold_fields_exact'] == 23 and d['primary_state_arrays'] == 16 and d['captured_step_calls'] == 48 and d['cases'] == 3
    assert d['source_manifest_sha256'] == MANIFEST and SHA(p / 'trajectory/batch.json') == d['report_sha256']
    sys.path[:0] = [str(source), str(source / 'src'), str(source / 'benchmarks'), '/home/zhangyq/noahmp-v1/test-deps']
    import numpy as np
    import run_fluxnet_native as native
    from audit_bgc_stream_of import cold_rows, audit_stream
    def forbidden(*args, **kwargs):
        raise AssertionError('OH must never run a forward model')
    native.run = forbidden
    report, final, rows = native.read_generation(p / 'trajectory')
    assert report['status'] == 'running' and report['steps_completed'] == 48 and report['steps_requested'] == 17520
    assert report['identity']['source_sha256'] == native.source_hashes() and report['identity']['compare_jax32'] is False
    assert report['checkpoint_sha256'] == '6c6211c81f2efac34db4ad2a07b856e83d6b0b277e8489b2a16b762be824df7f'
    loaded = native.load_batch(p / 'inputs/batch.json')
    assert [c['case'] for c in loaded] == CASES and [r['case'] for r, _ in rows] == CASES
    with np.load(inputs / 'cold-reference.npz', allow_pickle=False) as z:
        cold = dict(z)
    paths = list((p / 'trajectory').glob('state-0000000-*.npz'))
    assert len(paths) == 1 and SHA(paths[0]) == json.loads((p / 'cold-audit.json').read_text())['cold_checkpoint_sha256']
    with np.load(paths[0], allow_pickle=False) as z:
        assert set(z.files) == set(cold) and len(z.files) == 23
        assert all(z[k].dtype == cold[k].dtype and z[k].shape == cold[k].shape and z[k].tobytes() == cold[k].tobytes() for k in cold)
    audit = audit_stream(cold_rows(p), loaded, cold, final, [trace for _, trace in rows], 48)
    assert audit['steps'] == 48 and audit['physical_column_steps'] == 144 and audit['complete_calendar_year'] is False
    comparisons = []
    for case in audit['cases']:
        prior_case = json.loads(prior[case['case'] + '-verification.json'])
        (OUT / ('prior1590-' + case['case'] + '.json')).write_bytes(prior[case['case'] + '-verification.json'])
        comparisons.append(dict(case=case['case'],
            oh_maximum_independent_step_absolute_c_n=case['maximum_independent_step_absolute_c_n'],
            prior1590_maximum_independent_step_absolute_c_n=prior_case['maximum_independent_step_m_h_c_n'][2:],
            oh_maximum_independent_cumulative_absolute_c_n=case['maximum_independent_cumulative_absolute_c_n'],
            prior1590_maximum_independent_cumulative_absolute_c_n=prior_case['maximum_independent_cumulative_m_h_c_n'][2:]))
    assert all(SHA(source / n) == h for n, h in m.items())
    assert all(SHA(STAGE / n) == h for n, h in archives.items())
    return dict(passed=True, pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
                helper_sha256=HELPER, source_manifest_sha256=MANIFEST, source_file_count=584,
                source_unchanged=True, archives_sha256=archives, actual_input_files_sha256=expected,
                all15_inputs_original_kg_byte_exact=True, cold_fields_exact=23,
                final_checkpoint_sha256=report['checkpoint_sha256'], original_ny_parent_exit=0,
                prior_independent_audit=dict(job='1590.manager', actual_state='F', actual_exit=0,
                    physical_step_pairs=144, all16state_chains_exact=True, receipt_sha256=hashlib.sha256(prior['receipt.json']).hexdigest()),
                audit=audit, original1590_comparison=comparisons, forward_model_runs=0,
                annual_audit=False, scientific_acceptance=False,
                scope='Only fixed sealed NY cold48 actual C/N diagnostics through the exact OF three-case helper; original KG15 input bytes and23 cold fields,144 C/N transitions and final checkpoint checked. Original1590 full144 paired audit retained, not rerun. No forward model, annual audit, changed input/source/gate or scientific acceptance.')


if __name__ == '__main__':
    start = time.monotonic()
    try:
        result = run()
        code = 0
    except Exception:
        traceback.print_exc()
        result = dict(passed=False, pbs_job=os.environ.get('PBS_JOBID'), node=os.uname().nodename,
                      error=traceback.format_exc(), forward_model_runs=0, annual_audit=False, scientific_acceptance=False)
        code = 1
    result['seconds'] = time.monotonic() - start
    (OUT / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    raise SystemExit(code)

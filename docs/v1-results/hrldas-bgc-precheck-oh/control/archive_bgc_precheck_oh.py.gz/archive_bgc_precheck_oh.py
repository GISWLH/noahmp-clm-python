"""Manager terminal closure; failed results stay failed and are preserved."""
from pathlib import Path
import hashlib,io,json,os,re,subprocess,tarfile
ROOT=Path('/tmp/noahmp-hrldas-bgc-precheck-oh')
assert os.uname().nodename=='manager'
sha=lambda b:hashlib.sha256(b).hexdigest()
dispatch=json.loads((ROOT/'dispatch.json').read_text());job=dispatch['pbs_job']
qstat=subprocess.check_output(['qstat','-xf',job],text=True)
assert re.search(r'^\s*job_state = F\s*$',qstat,re.M),'Actual F required'
exitcode=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',qstat,re.M).group(1))
for name in ['result.tar.gz','pbs-exit.txt']:
    assert not (ROOT/name).exists()
    subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
assert int((ROOT/'pbs-exit.txt').read_text())==exitcode
with tarfile.open(ROOT/'result.tar.gz') as tf:
    data={m.name.removeprefix('./'):tf.extractfile(m).read() for m in tf if m.isfile()}
assert int(data['worker-exit.txt'])==exitcode
receipt=json.loads(data['receipt.json']) if 'receipt.json' in data else None
passed=bool(exitcode==0 and receipt and receipt['passed'])
if passed:
    assert receipt['pbs_job']==job and receipt['node']=='compute002'
    assert receipt['forward_model_runs']==0 and receipt['annual_audit'] is False
    assert receipt['helper_sha256']==dispatch['controls_sha256']['audit_bgc_stream_of.py']
    assert receipt['audit']['physical_column_steps']==144 and receipt['audit']['steps']==48
for name,h in dispatch['controls_sha256'].items():
    raw=(ROOT/'controls'/name).read_bytes();assert sha(raw)==h;data['control/'+name]=raw
for name in ['dispatch.json','qsub-stdout.txt','qsub-stderr.txt','input-manifest.json','result.tar.gz','pbs-exit.txt']:
    data['control/'+name]=(ROOT/name).read_bytes()
data['control/CONTROLS_SHA256.json']=(ROOT/'controls/CONTROLS_SHA256.json').read_bytes()
data['actual-qstat.txt']=qstat.encode()
if (ROOT/'pbs-output.log').exists():data['control/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
target=ROOT/'hrldas-bgc-precheck-oh-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(data.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
with tarfile.open(target) as tf:assert {m.name:tf.extractfile(m).read() for m in tf}==data
package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    pbs_job=job,actual_job_state='F',actual_exit=exitcode,passed=passed,
    worker_seconds=receipt.get('seconds') if receipt else None,forward_model_runs=0,
    physical_column_steps=144 if passed else None,annual_audit=False,scientific_acceptance=False,
    scope='Fixed sealed NY cold48, original KG15 inputs and NM584 read back through exact OF three-case C/N helper. Original1590 independent paired audit retained, no reference/model rerun. Exact input/CN chain and original float32 bounds, independent float64 residuals. This bounded48step helper precheck is not an annual audit or scientific acceptance.')
(ROOT/'hrldas-bgc-precheck-oh-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package),flush=True)

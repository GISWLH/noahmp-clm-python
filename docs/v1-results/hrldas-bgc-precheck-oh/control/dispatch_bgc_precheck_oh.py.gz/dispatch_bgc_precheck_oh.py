"""Manager-only one bounded, read-only PBS C/N audit dispatch."""
from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path('/tmp/noahmp-hrldas-bgc-precheck-oh')
assert os.uname().nodename=='manager'
assert not (ROOT/'dispatch.json').exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
controls=json.loads((ROOT/'controls/CONTROLS_SHA256.json').read_text())
inputs=json.loads((ROOT/'input-manifest.json').read_text())
assert all(sha(ROOT/'controls'/n)==h for n,h in controls.items())
assert all(sha(ROOT/n)==h for n,h in inputs.items())
subprocess.run(['ssh','compute002','test ! -e '+str(ROOT)+' && mkdir '+str(ROOT)],check=True)
subprocess.run(['scp','-r',str(ROOT/'controls'),'compute002:'+str(ROOT)+'/'],check=True)
subprocess.run(['scp',*[str(ROOT/n) for n in inputs],str(ROOT/'input-manifest.json'),'compute002:'+str(ROOT)+'/'],check=True)
cmd=['qsub','-v','OH_STAGE='+str(ROOT),'-o',str(ROOT/'pbs-output.log'),str(ROOT/'controls/bgc_precheck_oh.pbs')]
result=subprocess.run(cmd,text=True,capture_output=True)
(ROOT/'qsub-stdout.txt').write_text(result.stdout)
(ROOT/'qsub-stderr.txt').write_text(result.stderr)
assert result.returncode==0,result.stderr
job=result.stdout.strip();assert job.endswith('.manager') and job.split('.')[0].isdigit()
receipt=dict(pbs_job=job,controls_sha256=controls,inputs_sha256=inputs,
             requested_resources='1 CPU / 2 GB / 10 minutes / compute002',
             forward_model_runs=0,scope='OH fixed NY cold48 helper precheck only; no annual credit.')
(ROOT/'dispatch.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)

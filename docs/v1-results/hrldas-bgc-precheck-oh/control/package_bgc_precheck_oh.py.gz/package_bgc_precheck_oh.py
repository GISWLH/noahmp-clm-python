"""Stdlib-only publication wrapper preserving original closed OH bytes and dispatch history."""
from pathlib import Path
import hashlib,io,json,tarfile
ROOT=Path(__file__).resolve().parent
RAW=ROOT/'hrldas-bgc-precheck-oh-download'
sha=lambda b:hashlib.sha256(b).hexdigest()
package_raw=(RAW/'hrldas-bgc-precheck-oh-package.json').read_bytes()
package=json.loads(package_raw)
closed=(RAW/package['archive']).read_bytes()
assert sha(closed)==package['sha256']=='f55e98083b65b71cc7fe309d155ac305348a0cf709eb0b55123711ed32b2e152'
with tarfile.open(fileobj=io.BytesIO(closed)) as tf:
    original={m.name:tf.extractfile(m).read() for m in tf}
assert len(original)==package['artifacts']==27
inventory=json.loads(original['artifact-inventory.json'])
assert set(inventory)==set(original)-{'artifact-inventory.json'}
assert all(sha(original[n])==v['sha256'] and len(original[n])==v['bytes'] for n,v in inventory.items())
with tarfile.open(fileobj=io.BytesIO(original['control/result.tar.gz'])) as tf:
    inner={m.name.removeprefix('./'):tf.extractfile(m).read() for m in tf if m.isfile()}
assert all(original[n]==raw for n,raw in inner.items())
receipt=json.loads(original['receipt.json'])
assert package['actual_job_state']=='F' and package['actual_exit']==0 and receipt['passed']
assert receipt['helper_sha256']=='1a1da961c93c9c9648934c2ee2939658942e38150cd29751eb803fd3c98c4958'
assert receipt['audit']['physical_column_steps']==144 and receipt['audit']['steps']==48
for case in receipt['original1590_comparison']:
    assert case['oh_maximum_independent_step_absolute_c_n']==case['prior1590_maximum_independent_step_absolute_c_n']
    assert case['oh_maximum_independent_cumulative_absolute_c_n']==case['prior1590_maximum_independent_cumulative_absolute_c_n']
resume=(ROOT/'submit_staged_bgc_precheck_oh.py').read_bytes()
assert sha(resume)==json.loads(original['control/dispatch.json'])['resume_dispatch_sha256']
data={n:raw for n,raw in original.items() if n!='artifact-inventory.json'}
data['original/closed-evidence.tar.gz']=closed
data['original/closed-package.json']=package_raw
data['original/closed-artifact-inventory.json']=original['artifact-inventory.json']
data['control/submit_staged_bgc_precheck_oh.py']=resume
data['control/package_bgc_precheck_oh.py']=Path(__file__).read_bytes()
history=dict(original_closed_archive_sha256=sha(closed),original_closed_artifacts=27,
    initial_transport_attempt=dict(actual_returncode=1,submitted_job=False,forward_model_runs=0,
        error="TypeError: __init__() got an unexpected keyword argument 'text'",
        location='System Python3.6 subprocess.run(text=True,capture_output=True) before qsub; transport to compute002 had completed.'),
    resumed_dispatch=dict(python='/home/zhangyq/venvs/noahmp-closeout/bin/python',
        script_sha256=sha(resume),all_manager_and_compute_file_hashes_rechecked=True,original_PBS_helper_source_inputs_unchanged=True,
        job='1593.manager'),
    observation_history=['First observed E with actual worker exit0; no F0 claim then.',
        'Next SSH status refresh timed out, preserved last known E.',
        'Later bounded refresh observed F and Exit_status0; only then closed archive created.'],
    scope='Packaging and dispatch-history metadata only. Original closed bytes unchanged; no new model/array calculation.')
data['dispatch-history.json']=(json.dumps(history,indent=2)+'\n').encode()
data['README.md']=('''# OH original three-case C/N helper precheck

Actual PBS1593.manager completed F/Exit0 on compute002,1CPU/2GB/10min request; walltime3s, reader2.964860928s. The unmodified OF helper SHA1a1da961...c4958 read the sealed NYcold48, original KG15 inputs and fixed NM584 source, using original cold_rows and audit_stream(...,steps=48). No forward model ran.

All144 C/N column transitions, actual forcing/deposition/N inputs,23 cold fields and final C/N checkpoint are exact. The original float32 residuals/bounds were rederived without changing gates; independent float64 single-step and cumulative C/N remain inside those gates. All12 reported maximum C/N residual values exactly equal the original1590 paired-audit values retained here. That prior144 full reference audit was not repeated.

|Site|Max step C|Max step N|Max cumulative C|Max cumulative N|Max original step bound fraction C/N|
|---|---:|---:|---:|---:|---:|
|Qia|0.0004634391516447067|0.00005014394992031157|0.0021559549495577812|0.000599787337705493|0.0010056803821659017 / 0.0025707149877145187|
|Cha|0.00010210089385509491|0.0000008008464646991342|0.003922482952475548|0.000026635359972715378|0.00022157362571237447 / 0.000041056961723881584|
|HaM|0.000013210112228989601|0.0000003268396540079266|0.00008682906627655029|0.000002218414010712877|0.00006319317016833109 / 0.00001781439309528789|

C units are g C m^-2; N units are g N m^-2. Bound fractions are fractions, not percentages. Receipt includes all7 soilC pool changes, litter/N inputs, and original1590 side-by-side values.

This is a48step helper/API readback precheck, not an annual C/N audit, scientific acceptance, spinup or long-term SOC evidence. The annual OF source review and its runtime gates remain separate.

Original closed archive and its inventory/package are nested unchanged. The wrapper adds the actual resumed submission script and dispatch history, retaining the first Python3.6 pre-qsub failure. No failed numerical run was discarded or repeated.
''').encode()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(v),bytes=len(v)) for n,v in data.items()},indent=2)+'\n').encode()
target=ROOT/'hrldas-bgc-precheck-oh-evidence.tar.gz'
assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(data.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
with tarfile.open(target) as tf:assert {m.name:tf.extractfile(m).read() for m in tf}==data
published=dict(package,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(data),
    original_closed_archive_sha256=sha(closed),original_closed_artifacts=27,
    all_original1590_maximum_c_n_residual_values_exact=True,
    packaging_scope='All original closed bytes retained; resumed dispatcher and initial pre-qsub failure metadata added; no numerical rerun.')
(ROOT/'hrldas-bgc-precheck-oh-package.json').write_text(json.dumps(published,indent=2)+'\n')
(ROOT/'hrldas-bgc-precheck-oh-results.json').write_bytes(original['receipt.json'])
print(json.dumps(published))

"""Read-only C/N audits of archived native diagnostics, not a spinup solver."""
from datetime import datetime
from pathlib import Path
import hashlib
import numpy as np

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def _exact(a,b,label):
    a,b=np.asarray(a),np.asarray(b)
    assert a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes(),label

def _sum(a):
    value=np.zeros(a.shape[0],a.dtype)
    for k in range(a.shape[1]):value=value+a[:,k]
    return value

def totals(plant,soil,dtype):
    p,s=np.asarray(plant,dtype),np.asarray(soil,dtype)
    return np.stack(((_sum(p[:,:3])+p[:,6])+_sum(s[:,:7]),
        ((_sum(p[:,3:6])+p[:,7])+_sum(s[:,7:14]))+s[:,14]),axis=1)

def cold_rows(root):
    for k in range(48):
        path=Path(root)/'steps'/('call-'+str(k).zfill(5)+'.npz')
        with np.load(path,allow_pickle=False) as z:d=dict(z)
        row={key:d[key] for key in ['forcing','deposition','nitrogen']}
        for name,key in [('before_plant','before11'),('before_soil_cn','before13'),('after_plant','after11'),('after_soil_cn','after13')]:row[name]=d[key]
        row.update({'bgc/'+key[len('output/biogeochemistry/'):]:v for key,v in d.items() if key.startswith('output/biogeochemistry/')})
        yield k,row

def continued_rows(root,end):
    for begin in range(48,end,48):
        path=Path(root)/'year-bgc-diagnostics'/('steps-'+str(begin).zfill(7)+'-'+str(begin+48).zfill(7)+'.npz')
        with np.load(path,allow_pickle=False) as z:d=dict(z)
        assert all(v.shape[0]==48 for v in d.values()),str(path)
        for k in range(48):yield begin+k,{name:value[k] for name,value in d.items()}

def audit_stream(records,loaded,cold,final,traces,steps):
    from fluxnet_deposition import DepositionSchedule
    assert steps>0 and steps%48==0 and len(loaded)==3 and len(traces)==3
    schedules=[DepositionSchedule(c['config']) for c in loaded]
    previous=(cold['a11'],cold['a13']);first=totals(*previous,np.float64)
    initial=first.copy();net=np.zeros((3,2));bounds=net.copy();maximum=net.copy();cumulative_max=net.copy();ratio_max=net.copy()
    nf_min=np.ones(3);limited=np.zeros(3,np.int64);litter=np.zeros((3,7));gpp_total=np.zeros(3);npp_total=np.zeros(3);n_input=np.zeros(3);rh_total=np.zeros(3)
    consumed=0
    for index,row in records:
        assert index==consumed and index<steps
        before=(row['before_plant'],row['before_soil_cn']);after=(row['after_plant'],row['after_soil_cn'])
        for a,b,name in zip(before,previous,['plant','soil']):_exact(a,b,'C/N chain '+str(index)+' '+name)
        for a in before+after:assert a.dtype==np.dtype('float32') and np.isfinite(a).all() and np.all(a>=0)
        assert before[0].shape==(3,8) and before[1].shape==(3,15)
        forcing=np.asarray([c['data']['forcing'][index] for c in loaded],np.float32)
        nitrogen=np.asarray([s.nitrogen_rate for s in schedules],np.float32)*forcing[:,0]
        deposition=np.asarray([s.aerosol(datetime.strptime(str(c['data']['time_start'][index]),'%Y%m%d%H%M'),float(forcing[k,0])) for k,(c,s) in enumerate(zip(loaded,schedules))],np.float32)
        for key,value in [('forcing',forcing),('nitrogen',nitrogen),('deposition',deposition)]:_exact(row[key],value,key)
        gpp=row['bgc/allocation/gpp_gc_m2'];ra=row['bgc/allocation/autotrophic_respiration_gc_m2'];rh=row['bgc/decomposition/heterotrophic_respiration_gc_m2'];resp=ra+rh;nee=resp-gpp
        old32,new32=totals(*before,np.float32),totals(*after,np.float32)
        cb=np.float32(128*np.finfo(np.float32).eps)*np.maximum(((new32[:,0]+old32[:,0])+gpp)+resp,np.float32(1.))
        nb=np.float32(128*np.finfo(np.float32).eps)*np.maximum((new32[:,1]+old32[:,1])+nitrogen,np.float32(1.))
        for key,value in [('carbon_bound_gc_m2',cb),('nitrogen_bound_gn_m2',nb),('carbon_residual_gc_m2',(new32[:,0]-old32[:,0])+nee),('nitrogen_residual_gn_m2',(new32[:,1]-old32[:,1])-nitrogen)]:_exact(row['bgc/'+key],value,key)
        original_bound=np.stack((cb,nb),axis=1).astype(float)
        own_incoming=np.stack((gpp.astype(float)-ra.astype(float)-rh.astype(float),nitrogen.astype(float)),axis=1)
        residual=totals(*after,np.float64)-totals(*before,np.float64)-own_incoming
        assert np.all(abs(residual)<=original_bound),(index,'independent original C/N bounds')
        net+=own_incoming;bounds+=original_bound;cumulative=totals(*after,np.float64)-initial-net
        assert np.all(abs(cumulative)<=bounds),(index,'independent cumulative C/N bounds')
        maximum=np.maximum(maximum,abs(residual));cumulative_max=np.maximum(cumulative_max,abs(cumulative));ratio_max=np.maximum(ratio_max,abs(residual)/original_bound)
        for name,value in [('gpp_gc_m2',gpp),('autotrophic_respiration_gc_m2',ra),('heterotrophic_respiration_gc_m2',rh),('nee_gc_m2',nee)]:
            actual=np.asarray([trace[name][index] for trace in traces]);assert np.array_equal(actual,value),(index,name)
        factor=row['bgc/decomposition/nitrogen_limitation'];assert factor.shape==(3,) and np.isfinite(factor).all() and np.all((factor>=0)&(factor<=1))
        nf_min=np.minimum(nf_min,factor);limited+=factor<np.float32(1.)
        litter+=row['bgc/turnover/litter_carbon_gc_m2'].astype(float)
        gpp_total+=gpp.astype(float);npp_total+=(gpp.astype(float)-ra.astype(float));rh_total+=rh.astype(float);n_input+=nitrogen.astype(float)
        previous=after;consumed+=1
    assert consumed==steps
    for a,b,name in zip(previous,(final['a11'],final['a13']),['plant','soil']):_exact(a,b,'final '+name)
    cases=[]
    for k,c in enumerate(loaded):
        old=np.asarray(cold['a13'][k,:7],float);new=np.asarray(final['a13'][k,:7],float);soc_old=old[4:].sum();soc_new=new[4:].sum()
        cases.append(dict(case=c['config']['case'],steps=consumed,maximum_independent_step_absolute_c_n=maximum[k].tolist(),maximum_independent_cumulative_absolute_c_n=cumulative_max[k].tolist(),maximum_original_step_bound_fraction=ratio_max[k].tolist(),
            initial_seven_soil_carbon_pools_gc_m2=old.tolist(),final_seven_soil_carbon_pools_gc_m2=new.tolist(),soil_pool_change_gc_m2=(new-old).tolist(),
            initial_soc_gc_m2=float(soc_old),final_soc_gc_m2=float(soc_new),actual_window_soc_change_percent=None if soc_old<=1 else float(100*(soc_new-soc_old)/soc_old),
            minimum_actual_decomposition_n_factor=float(nf_min[k]),n_limited_intervals=int(limited[k]),unlimited_n_condition_for_conditional_linear_carbon_operator_met=bool(limited[k]==0),
            actual_litter_input_gc_m2=litter[k].tolist(),actual_gpp_gc_m2=float(gpp_total[k]),actual_npp_gc_m2=float(npp_total[k]),actual_rh_gc_m2=float(rh_total[k]),actual_n_deposition_gn_m2=float(n_input[k]),
            periodic_carbon_initialization_eligible=False,reason='Only original trajectory diagnostics audited. Stable repeated annual NPP/litter/environment and full C/N consistency have not been demonstrated; no conditional or replayed soil state is injected.'))
    return dict(steps=consumed,physical_column_steps=consumed*3,all_c_n_chains_actual_input_and_final_checkpoint_exact=True,all_original_c_n_bounds_rederived_float32_exact=True,
        all_independent_float64_step_and_cumulative_c_n_within_original_bounds=True,cases=cases,
        complete_calendar_year=bool(steps==17520),actual_100_year_soil_carbon_drift_measured=False,
        scope='Archived actualnative C/N only, withindependentfloat64storage/exchange ledgers andexactoriginalfloat32bound/residual reconstruction. No physical tendency, alteredrate/Ninput/state/trajectory, stationinitializer, coupledspinup/scientificacceptance or100yearclaim.')

# OH original three-case C/N helper precheck

Actual PBS1593.manager completed F/Exit0 on compute002,1CPU/2GB/10min request; walltime3s, reader2.964860928s. The unmodified OF helper SHA1a1da961...c4958 read the sealed NYcold48, original KG15 inputs and fixed NM584 source, using original cold_rows and audit_stream(...,steps=48). No forward model ran.

All144 C/N column transitions, actual forcing/deposition/N inputs,23 cold fields and final C/N checkpoint are exact. The original float32 residuals/bounds were rederived without changing gates; independent float64 single-step and cumulative C/N remain inside those gates. All12 reported maximum C/N residual values exactly equal the original1590 paired-audit values retained here. That prior144 full reference audit was not repeated.

|Site|Max step C|Max step N|Max cumulative C|Max cumulative N|Max original step bound fraction C/N|
|---|---:|---:|---:|---:|---:|
|Qia|0.0004634391516447067|0.00005014394992031157|0.0021559549495577812|0.000599787337705493|0.0010056803821659017 / 0.0025707149877145187|
|Cha|0.00010210089385509491|0.0000008008464646991342|0.003922482952475548|0.000026635359972715378|0.00022157362571237447 / 0.000041056961723881584|
|HaM|0.000013210112228989601|0.0000003268396540079266|0.00008682906627655029|0.000002218414010712877|0.00006319317016833109 / 0.00001781439309528789|

C units are g C m^-2; N units are g N m^-2. Bound fractions are fractions, not percentages. Receipt includes all7 soilC pool changes, litter/N inputs, and original1590 side-by-side values.

This is a48step helper/API readback precheck, not an annual C/N audit, scientific acceptance, spinup or long-term SOC evidence. The annual OF source review and its runtime gates remain separate.

Original closed archive and its inventory/package are nested unchanged. The wrapper adds the actual resumed submission script and dispatch history, retaining the first Python3.6 pre-qsub failure. No failed numerical run was discarded or repeated.

"""Frozen physics vs Newton prototype; independent calls from identical states."""
import importlib.util, sys, time, json, hashlib
from dataclasses import asdict
from pathlib import Path
import numpy as np
from datetime import datetime
from run_fluxnet_column import build_state, calendar, audit_step
from noahmp_clm.column import Forcing
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics import photosynthesis, canopy_energy, canopy_phase_energy
from test_molten_precipitation import ham_failure
original=photosynthesis.leaf_gas_exchange
p=Path(__file__).with_name('photosynthesis_newton_candidate.py');spec=importlib.util.spec_from_file_location('candidate',p);candidate=importlib.util.module_from_spec(spec);sys.modules['candidate']=candidate;spec.loader.exec_module(candidate)
base=Path.cwd();cases=[]
for site,case in [('CN-Cng','CN-Cng-tq6-w2'),('CN-Qia','CN-Qia-tq39.6-w39.6'),('CN-Cha','CN-Cha-tq61.8-w61.8')]:
 config=json.loads((base/f'inputs/configs/{case}.json').read_text());meta=json.loads((base/f'inputs/{site}.json').read_text());forcing=np.load(base/f'inputs/{site}.npz');i=24
 state=build_state(config);f=Forcing(*forcing['forcing'][i]);co2,mu,diffuse=forcing['environment'][i]
 env=calendar(datetime.strptime(str(forcing['time_start'][i]),'%Y%m%d%H%M'),meta,config['phenology'] is not None)
 kw=dict(co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),most_geometry=MOSTGeometry(**config['most_geometry']),phenology_environment=env,deposition_rates=np.asarray(config['aerosol_deposition_kg_m2_s']),nitrogen_deposition_gn_m2=config['nitrogen_deposition_gn_m2_s']*f.dt)
 cases.append((case,state,f,kw))
state,f,kw=ham_failure();cases.append(('HaM-molten-failure',state,f,kw))
def diff(a,b,path=''):
 result={}
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a: result.update(diff(a[k],b[k],path+'/'+k))
 elif isinstance(a,(np.ndarray,float,int,np.number)):
  aa=np.asarray(a,dtype=float);bb=np.asarray(b,dtype=float)
  assert aa.shape==bb.shape
  result[path]=float(np.max(abs(aa-bb),initial=0.))
 else: assert a==b,(path,a,b)
 return result
results=[]
for name,state,f,kw in cases:
 row={'case':name};outputs=[]
 for label,func in [('old_bisection',original),('newton_candidate',candidate.leaf_gas_exchange)]:
  for module in [photosynthesis,canopy_energy,canopy_phase_energy]:module.leaf_gas_exchange=func
  start=time.monotonic();after,d=step_clm_enthalpy_column(state,f,**kw);seconds=time.monotonic()-start
  _,residual,bound=audit_step(state,after,f,d,kw.get('nitrogen_deposition_gn_m2',0.))
  row[label]={'seconds':seconds,'m_h_c_n_residual':residual.tolist(),'m_h_c_n_bound':bound.tolist(),'most_iterations':d['most']['iterations']}
  outputs.append((after,d));print(name,label,row[label],flush=True)
 row['state_max_absolute']=diff(asdict(outputs[0][0]),asdict(outputs[1][0]))
 row['flux_max_absolute']=diff({k:outputs[0][1][k] for k in ['h','le','gpp_gc_m2','nee_gc_m2','et_mm','runoff_mm','surface_temperature']},{k:outputs[1][1][k] for k in ['h','le','gpp_gc_m2','nee_gc_m2','et_mm','runoff_mm','surface_temperature']})
 results.append(row)
 (base/'profile_output/newton-column-comparison.json').write_text(json.dumps({'scope':'single-step diagnostics, not trajectories; one timing per implementation on shared host','prototype_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':results},indent=2)+'\n')
 print(name,'maxflux',row['flux_max_absolute'],flush=True)
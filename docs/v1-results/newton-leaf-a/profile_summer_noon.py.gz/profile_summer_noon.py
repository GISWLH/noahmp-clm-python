"""One diagnostic summer-noon column call; not a trajectory or validation run."""
import cProfile, pstats, json, hashlib, time
from pathlib import Path
import numpy as np
from run_fluxnet_column import build_state, calendar, totals
from noahmp_clm.column import Forcing
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
base=Path.cwd(); case='CN-Cng-tq6-w2'
config=json.loads((base/f'inputs/configs/{case}.json').read_text())
meta=json.loads((base/'inputs/CN-Cng.json').read_text())
forcing=np.load(base/'inputs/CN-Cng.npz'); i=24
from datetime import datetime
state=build_state(config); f=Forcing(*forcing['forcing'][i]); co2,mu,diffuse=forcing['environment'][i]
env=calendar(datetime.strptime(str(forcing['time_start'][i]),'%Y%m%d%H%M'),meta,True)
profile=cProfile.Profile(); started=time.monotonic()
profile.enable()
after,d=step_clm_enthalpy_column(state,f,co2_ppm=float(co2),cosine_zenith=float(mu),diffuse_fraction=float(diffuse),leaf_dimension=config['leaf_dimension_m'],leaf_parameters=LeafParameters(**config['leaf_parameters']),most_geometry=MOSTGeometry(**config['most_geometry']),phenology_environment=env,deposition_rates=np.asarray(config['aerosol_deposition_kg_m2_s']),nitrogen_deposition_gn_m2=config['nitrogen_deposition_gn_m2_s']*f.dt)
profile.disable(); seconds=time.monotonic()-started
out=base/'profile_output'; profile.dump_stats(out/'summer-noon-cprofile.prof')
with (out/'summer-noon-cprofile.txt').open('w') as stream:
 pstats.Stats(profile,stream=stream).sort_stats('cumulative').print_stats(35)
(out/'summer-noon-cprofile.json').write_text(json.dumps({'scope':'single cold-start summer noon diagnostic; cProfile observer overhead; not a trajectory or benchmark','case':case,'forcing_index':i,'timestamp':str(forcing['time_start'][i]),'seconds':seconds,'h':d['h'],'le':d['le'],'gpp':d['gpp_gc_m2'],'source_photosynthesis_sha256':hashlib.sha256((base/'src/noahmp_clm/physics/photosynthesis.py').read_bytes()).hexdigest(),'initial_totals':totals(state).tolist(),'final_totals':totals(after).tolist()},indent=2)+'\n')
print('PROFILE COMPLETE',seconds,flush=True)
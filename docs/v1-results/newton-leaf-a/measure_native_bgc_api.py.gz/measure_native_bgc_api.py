"""Warmed native BGC/MOST API latency; repeated same state, no trajectory claim."""
from pathlib import Path
import json,time,hashlib,platform
import numpy as np
import cupy as cp
from test_gpu_molten_precipitation import actual_case
from noahmp_clm.gpu.cuda.clm_bgc_column import step_clm_bgc_columns_cuda
base=Path.cwd();rows=[]
for n in [1,16]:
    a,f,e,c,g=actual_case(np.float32)
    a=tuple(cp.asarray(np.repeat(x,n,axis=0)) for x in a)
    f,e,c,g=[cp.asarray(np.repeat(x,n,axis=0)) for x in [f,e,c,g]]
    def call():
        r=step_clm_bgc_columns_cuda(*a,f,environment=e,calendar=c,most_geometry=g,return_surface=True)
        cp.cuda.Device().synchronize()
        return r
    cp.cuda.Device().synchronize();start=time.perf_counter();r=call();warmup=time.perf_counter()-start
    reference={k:cp.asnumpy(r['diagnostics'][k]) for k in ['h','le','gpp_gc_m2','nee_gc_m2']}
    times=[]
    for _ in range(6):
        start=time.perf_counter();r=call();times.append(time.perf_counter()-start)
        for k,v in reference.items():np.testing.assert_array_equal(cp.asnumpy(r['diagnostics'][k]),v)
    row={'columns':n,'warmup_seconds':warmup,'repeated_seconds':times,'median_seconds':float(np.median(times)),'fixed_state_repeated_outputs_identical':True}
    rows.append(row);print(row,flush=True)
out=base/'profile_output';out.mkdir(exist_ok=True)
(out/'native-bgc-api-latency.json').write_text(json.dumps({'scope':'Warm, device-resident native CUDA BGC/MOST API latency on one repeated real HaM state; shared-host timings; not annual performance or multi-site accuracy','numpy':np.__version__,'cupy':cp.__version__,'python':platform.python_version(),'manifest_sha256':hashlib.sha256((base/'SOURCE_SHA256.json').read_bytes()).hexdigest(),'cases':rows},indent=2)+'\n')
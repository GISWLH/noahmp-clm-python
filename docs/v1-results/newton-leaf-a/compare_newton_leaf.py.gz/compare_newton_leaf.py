import importlib.util,sys,time,json
from pathlib import Path
import numpy as np
from noahmp_clm.physics import photosynthesis as reference
path=Path(__file__).with_name('photosynthesis_newton_candidate.py')
spec=importlib.util.spec_from_file_location('candidate',path); candidate=importlib.util.module_from_spec(spec);sys.modules['candidate']=candidate;spec.loader.exec_module(candidate)
rng=np.random.default_rng(171003)
results=[]
for minimum in [.001,.01,.2]:
 for slope in [0.,9.,20.]:
  n=8192; p=reference.LeafParameters(minimum_conductance=minimum,ball_berry_slope=slope)
  par=np.exp(rng.uniform(-10.,np.log(3000.),n));par[::8]=0.
  temp=rng.uniform(200.,350.,n)
  kw=dict(co2_ppm=rng.uniform(100.,1200.,n),relative_humidity=rng.uniform(0.,1.5,n),boundary_conductance=np.exp(rng.uniform(np.log(.001),np.log(10.),n)),nitrogen_factor=rng.uniform(0.,1.,n),water_stress=rng.uniform(0.,1.,n),parameters=p)
  start=time.perf_counter();a=reference.leaf_gas_exchange(par,temp,**kw);ta=time.perf_counter()-start
  start=time.perf_counter();b=candidate.leaf_gas_exchange(par,temp,**kw);tb=time.perf_counter()-start
  item=dict(n=n,minimum=minimum,slope=slope,iterations=candidate.LAST_ITERATIONS,fallback=candidate.LAST_FALLBACK,reference_seconds=ta,candidate_seconds=tb,max_absolute={k:float(np.max(abs(a[k]-b[k]))) for k in a},max_residual=float(np.max(abs(b['diffusion_residual']))))
  item['all_finite']=all(np.all(np.isfinite(v)) for v in b.values())
  item['all_output_close']=all(np.allclose(a[k],b[k],rtol=1e-10,atol=1e-10) for k in a)
  results.append(item);print(item,flush=True)
Path(__file__).with_name('newton-leaf-random.json').write_text(json.dumps(results,indent=2)+'\n')
# Actual canopy-sized repeated calls, temperate sunlit conditions.
par=np.geomspace(.1,1500.,20);temp=np.linspace(288.,303.,20)
for mod in [reference,candidate]:
 timing=[]
 for rep in range(5):
  start=time.perf_counter()
  for _ in range(200): mod.leaf_gas_exchange(par,temp)
  timing.append(time.perf_counter()-start)
 print(mod.__name__,timing,flush=True)
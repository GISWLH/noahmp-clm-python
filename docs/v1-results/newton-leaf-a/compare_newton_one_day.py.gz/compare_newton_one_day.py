"""Compare daily generations from two frozen, identical-input trajectories."""
from pathlib import Path
from dataclasses import asdict
import json,pickle,hashlib
import numpy as np
root=Path('/home/lhwang/work/noahmp-v1');old=root/'p6-molten-snow-gpu-a';new=root/'p6-newton-leaf-a'
rows=[]
def differences(a,b,prefix=''):
    result={}
    if isinstance(a,dict):
        assert a.keys()==b.keys()
        for key in a:result.update(differences(a[key],b[key],prefix+'/'+key))
    elif isinstance(a,(np.ndarray,float,int,np.number)):
        aa=np.asarray(a,dtype=float);bb=np.asarray(b,dtype=float)
        assert aa.shape==bb.shape and np.all(np.isfinite(aa)) and np.all(np.isfinite(bb))
        result[prefix]={'max_absolute':float(np.max(abs(aa-bb),initial=0.)),'identical':bool(np.array_equal(aa,bb))}
    else:assert a==b,(prefix,a,b)
    return result
for case in ['CN-Cng-tq6-w2','CN-Qia-tq39.6-w39.6','CN-Cha-tq61.8-w61.8']:
    a=old/'height-runs'/case;b=new/'continuity-checks'/case
    ma=json.loads((a/'report.json').read_text());mb=json.loads((b/'report.json').read_text())
    assert ma['steps_completed']>=48 and mb['steps_completed']==48
    for key in ['forcing_npz_sha256','forcing_manifest_sha256','configuration_sha256']:
        assert ma[key]==mb[key],key
    assert ma['source_sha256'].keys()==mb['source_sha256'].keys()
    changed=[k for k in ma['source_sha256'] if ma['source_sha256'][k]!=mb['source_sha256'][k]]
    assert changed==['src/noahmp_clm/physics/photosynthesis.py'],changed
    pa=a/'trace-0000048.npz';pb=b/'trace-0000048.npz'
    with np.load(pa,allow_pickle=False) as za,np.load(pb,allow_pickle=False) as zb:
        assert za.files==zb.files
        assert all(np.array_equal(za[k],zb[k]) for k in ['time_start','time_end'])
        traces=differences({k:za[k] for k in za.files if k not in ['time_start','time_end']}, {k:zb[k] for k in zb.files if k not in ['time_start','time_end']})
    sa=pickle.loads((a/'state-0000048.pkl').read_bytes());sb=pickle.loads((b/'state-0000048.pkl').read_bytes())
    assert sa[-1]==sb[-1]==48
    physical=differences(asdict(sa[0]),asdict(sb[0]))
    firstday=[json.loads(l) for l in (old/'height-runs'/f'{case}.log').read_text().splitlines() if l.startswith('{') and json.loads(l).get('steps')==48][0]
    row={'case':case,'steps':48,'changed_model_source':changed,'forcing_sha256':ma['forcing_npz_sha256'],'configuration_sha256':ma['configuration_sha256'],
         'trace_sha256':{'old':hashlib.sha256(pa.read_bytes()).hexdigest(),'new':hashlib.sha256(pb.read_bytes()).hexdigest()},
         'trace_max_absolute':traces,'final_physical_state_differences':physical,
         'old_seconds':firstday['seconds'],'new_seconds':mb['seconds'],
         'new_maximum_cumulative_residual_m_h_c_n':mb['maximum_cumulative_residual_m_h_c_n'],
         'new_cumulative_numerical_bounds_m_h_c_n':mb['cumulative_numerical_bounds_m_h_c_n']}
    rows.append(row)
    print(case,'flux',{k:v['max_absolute'] for k,v in traces.items() if k in ['/h_wm2','/le_wm2','/gpp_gc_m2','/nee_gc_m2']},'nonidentical_state',{k:v for k,v in physical.items() if not v['identical']},'timing',row['old_seconds'],row['new_seconds'],flush=True)
(new/'newton-one-day-comparison.json').write_text(json.dumps({'scope':'Three identical-input 48-step numerical regression pairs; not height sensitivity or station acceptance','cases':rows},indent=2)+'\n')
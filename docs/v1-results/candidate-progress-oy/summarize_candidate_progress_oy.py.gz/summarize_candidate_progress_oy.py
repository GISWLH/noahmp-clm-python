"""Planning arithmetic from saved remote metadata; no model execution."""
from pathlib import Path
import hashlib
import io
import json
import math
import tarfile

root = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
inputs = {name: (root / name).read_bytes() for name in
          ('candidate-progress-oy.json', 'GPU_ETA_NQ.json')}
snapshot, baseline = (json.loads(raw) for raw in inputs.values())
uuid = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
assert all(p['environment']['CUDA_VISIBLE_DEVICES'] == uuid
           for p in snapshot['second']['processes'])
closed = {row['file']: row for row in snapshot['closed']}
assert all(row['passed'] and row['actual_parent_returncode'] == 0
           for row in closed.values())
remaining = [row for row in baseline['modules_in_execution_order']
             if row['file'] not in closed]
recent = [row for row in remaining if row['timing_group'] in ('JO_recent', 'IV_recent')]
older = [row for row in remaining if row not in recent]
queue_hours = [(math.fsum(row['baseline_min_seconds'] for row in recent)
                + factor * math.fsum(row['baseline_' + bound + '_seconds'] for row in older)) / 3600
               for factor, bound in ((1.3, 'min'), (2.6, 'max'))]
credited = sum(row['expected_tests'] for row in closed.values()) + sum(
    row['tests'] for row in snapshot['progress']['reused'])
assert credited + sum(row['tests'] for row in remaining) == 408
annual = []
for name, year in snapshot['years'].items():
    rows = [json.loads(line) for line in year['log_tail']]
    first, last = rows[0], rows[-1]
    assert year['status'] == 'running' and last['steps'] == year['steps_completed']
    rate = (last['seconds'] - first['seconds']) / (last['steps'] - first['steps'])
    annual.append(dict(run=name, observed_step_range=[first['steps'], last['steps']],
                       seconds_per_batch_step=rate, completed_steps=last['steps'],
                       requested_steps=year['steps_requested'],
                       remaining_hours=(year['steps_requested'] - last['steps']) * rate / 3600))
result = dict(utc=snapshot['second']['utc'], physical_gpu=1, gpu_uuid=uuid,
              input_sha256={n: sha(raw) for n, raw in inputs.items()},
              credited_gpu_tests=credited, requested_gpu_tests=408,
              current_file=snapshot['progress']['file'], queue_remaining_hours=queue_hours,
              queue_elapsed_credit_seconds=0, annual_recent_window_estimates=annual,
              scope='Conditional planning estimates only. Annual runs are concurrent. Winter-prefix speed '
                    'does not establish full-season performance. Compilation, resource waits and failures '
                    'can change timing. Later spinup, calibration and release are not included.')
output = root / 'candidate-progress-oy-timing.json'
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
payload = dict(inputs)
payload[output.name] = output.read_bytes()
payload[Path(__file__).name] = Path(__file__).read_bytes()
payload['review_candidate_concurrency_nt.py'] = (root / 'review_candidate_concurrency_nt.py').read_bytes()
payload['index.json'] = (json.dumps({n: {'sha256': sha(raw), 'bytes': len(raw)}
                                    for n, raw in payload.items()}, indent=2) + '\n').encode()
label = 'candidate-progress-oy'
archive = root / (label + '-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for name, raw in payload.items():
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        tf.addfile(member, io.BytesIO(raw))
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), artifacts=len(payload),
               scope=result['scope'])
(root / (label + '-package.json')).write_text(json.dumps(package, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))

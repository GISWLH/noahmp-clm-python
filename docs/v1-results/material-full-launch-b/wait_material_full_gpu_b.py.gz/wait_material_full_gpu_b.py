from pathlib import Path
import datetime,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-material-event-b';r=s/'full-controller-b';target=s/'target-a/summary.json'
while not target.exists():time.sleep(15)
d=json.loads(target.read_text())
if d['status']!='complete':
 (r/'exit.json').write_text(json.dumps(dict(status='target-failed-no-full-worker-started',target_status=d['status'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(1)
with (r/'full.log').open('w') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'run_material_full_gpu_b.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='New exact493-source full GPU327 union; only verified current12 target nodes and exact EHPC808 evidence reused; previous source489 GPU325 not credited. Original per-file worker fixture phases/barriers/actual exits/source gates retained. Not a scientific annual/spinup/observation claim.'),indent=2)+'\n')
code=p.wait();(r/'exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(code)

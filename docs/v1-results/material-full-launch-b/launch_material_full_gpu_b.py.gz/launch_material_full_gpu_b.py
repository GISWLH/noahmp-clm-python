from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-material-event-b';r=s/'full-controller-b';r.mkdir(exist_ok=False)
m=json.loads((s/'SOURCE_SHA256.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert len(m)==493 and all(sha(s/n)==v for n,v in m.items())
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
with (r/'controller.log').open('w') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'wait_material_full_gpu_b.py')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
d=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Waits for actual current target12 complete success before full remaining315 GPU canonical nodes. EHPC current808 binding and all1135 exact union required. Waiting is not completed coverage, no GPU workers until targets pass; K/L source and states unchanged.')
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

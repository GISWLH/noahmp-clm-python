import sys,numpy as np,json,cupy as cp
sys.path.insert(0,'tests')
from test_gpu_canopy_surface import cases,reference,science,budgets
from noahmp_clm.gpu.cuda.canopy_surface import run_canopy_surface_cuda
x=cases(np.float32,40);r=run_canopy_surface_cuda(*x,raise_on_failure=False)
bad=np.flatnonzero(~cp.asnumpy(r['converged']));print('CUDA BAD',bad,flush=True)
for i in bad:
 print(json.dumps({k:cp.asnumpy(r[k][i]).tolist() for k in ['surface_temperature','surface_temperature_residual','surface_evaluations','iterations','layer_residual','canopy_humidity_change','thermal_layer_residual','thermal_layer_tolerance']}),flush=True)

"""Archive and reclaim only inactive manifest-verified extracted source duplicates."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1').resolve();scratch=Path('/var/tmp/zhangyq-noahmp-wet-inodes-av');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();names=['p6-soil-freezing-numpy-a','p6-phase-jacobian-numpy-a','p6-phase-jacobian-numpy-b','p6-public-clm-driver-a','p6-public-clm-driver-b','p6-dry-condensation-a','p6-dry-condensation-b','p6-spinup-assessment-a','p6-spinup-assessment-b'];archive=scratch/'inactive-source-duplicates-av.tar.gz';inventory=scratch/'inventory.json'
def safe(p):
    assert p.resolve().is_relative_to(b) and not p.is_symlink() and all(not q.is_symlink() for q in p.parents if q.is_relative_to(b));return p
if sys.argv[1]=='inventory':
    assert not scratch.exists();scratch.mkdir();assert scratch.stat().st_uid==os.getuid()
    jobs=subprocess.run(['qstat','-u','zhangyq'],capture_output=True,text=True,check=True).stdout;ids=[x.split()[0] for x in jobs.splitlines() if '.manager' in x];active=subprocess.check_output(['qstat','-f',*ids],text=True) if ids else ''
    rows=[];manifests=[]
    for name in names:
        assert name not in active,name
        root=safe(b/name);mp=safe(root/'SOURCE_SHA256.json')
        if not mp.exists():continue
        manifests.append(dict(path=str(mp),archive_path=name+'/SOURCE_SHA256.json',sha256=sha(mp)))
        for n,h in json.loads(mp.read_text()).items():
            rel=Path(n);assert not rel.is_absolute() and '..' not in rel.parts
            if rel.parts[0] not in ['src','tests','benchmarks','examples']:continue
            p=safe(root/rel)
            if not p.exists():continue
            assert p.is_file() and sha(p)==h;pstat=p.stat();rows.append(dict(path=str(p),archive_path=p.relative_to(b).as_posix(),sha256=h,bytes=pstat.st_size,mtime_ns=pstat.st_mtime_ns))
    assert len(rows)>1000
    with tarfile.open(archive,'w:gz') as tf:
        for row in [*rows,*manifests]:tf.add(row['path'],arcname=row['archive_path'],recursive=False)
    with tarfile.open(archive) as tf:
        for row in [*rows,*manifests]:assert hashlib.sha256(tf.extractfile(row['archive_path']).read()).hexdigest()==row['sha256']
    d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Inactive extracted source duplicates only, original source manifests/results/inputs/dependencies/controls/live trajectories retained. Active343/344/378 use different compute-local sources. Local backup verified before clean; archive makes removal reversible.',qstat=jobs,archive_sha256=sha(archive),files=rows,manifests=manifests)
    inventory.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(files=len(rows),bytes=sum(v['bytes'] for v in rows),archive_sha256=sha(archive),inventory_sha256=sha(inventory))))
elif sys.argv[1]=='clean':
    assert sha(inventory)==sys.argv[2] and sha(archive)==sys.argv[3];d=json.loads(inventory.read_text());removed=[]
    with tarfile.open(archive) as tf:
        for row in d['files']:
            p=safe(Path(row['path']));stat=p.stat();assert (stat.st_size,stat.st_mtime_ns)==(row['bytes'],row['mtime_ns']) and sha(p)==row['sha256']==hashlib.sha256(tf.extractfile(row['archive_path']).read()).hexdigest()
        for row in d['files']:safe(Path(row['path'])).unlink();removed.append(row['path'])
    dirs=[]
    for name in names:
        for part in ['src','tests','benchmarks','examples']:
            root=safe(b/name/part)
            if root.is_dir():
                for current,_,_ in os.walk(root,topdown=False,followlinks=False):
                    p=safe(Path(current))
                    if not any(p.iterdir()):p.rmdir();dirs.append(str(p))
    d=dict(scope=d['scope'],inventory_sha256=sys.argv[2],backup_archive_sha256=sys.argv[3],removed_files=len(removed),removed_empty_dirs=len(dirs),df_i=subprocess.check_output(['df','-i',str(b)],text=True));(scratch/'clean-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
else:raise ValueError(sys.argv)

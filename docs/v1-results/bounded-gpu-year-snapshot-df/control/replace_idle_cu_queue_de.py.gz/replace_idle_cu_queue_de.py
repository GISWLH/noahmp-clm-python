"""Cancel only a verified idle, childless superseded controller, never a model."""
from pathlib import Path
import datetime,hashlib,json,os,signal,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'bounded-coupled-cu';d=json.loads((r/'launch.json').read_text());pid=d['pid'];proc=Path('/proc')/str(pid);expected=str(r/'control_bounded_coupled_cu.py').encode();assert proc.exists() and expected in (proc/'cmdline').read_bytes();assert not (r/'queue-cancelled-de.json').exists();before=(proc/'cmdline').read_bytes();stopped=False;cancelled=False
try:
    os.kill(pid,signal.SIGSTOP);stopped=True
    for _ in range(20):
        state=(proc/'stat').read_text().split(') ',1)[1].split()[0]
        if state in ['T','t']:break
        time.sleep(.05)
    assert state in ['T','t'];assert expected in (proc/'cmdline').read_bytes();children=(proc/'task'/str(pid)/'children').read_text().strip();assert not children and not (r/'progress.json').exists() and not (r/'collection.json').exists(),'Controller has started work; resume it and do not cancel'
    os.kill(pid,signal.SIGTERM)
    try:os.kill(pid,signal.SIGCONT)
    except ProcessLookupError:pass
    stopped=False
    for _ in range(50):
        if not proc.exists():break
        state=(proc/'stat').read_text().split(') ',1)[1].split()[0]
        if state=='Z':break
        time.sleep(.1)
    terminal=not proc.exists() or state=='Z';assert terminal;cancelled=True;record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=pid,original_cmdline_sha256=hashlib.sha256(before).hexdigest(),childless_and_no_collection_or_model_progress=True,signal='SIGTERM',terminal_observed=True,scope='Only supersededidleCU controller cancelled after stopping/checkingchildlessness. No modelworker/oldBR/F/552/year/otherproject terminated. Originalsource/launch/controls retained; cancelled is not a testcompletion/pass. SuccessorDE sameCN original22 uses ownboundedruntimecache withoriginal32GiB/8GiB and alltest/numericalgates.');(r/'queue-cancelled-de.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
finally:
    if stopped and not cancelled:
        try:os.kill(pid,signal.SIGCONT)
        except ProcessLookupError:pass

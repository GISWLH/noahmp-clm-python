from pathlib import Path
import hashlib,json,os,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'bounded-coupled-cu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');start=time.monotonic();records=[]
def ready():
    free=int(subprocess.check_output(['nvidia-smi','--id=GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')));return free>8192 and mem>32*1024*1024,dict(gpu_free_mib=free,host_available_kib=mem)
def wait_for_ready(require_current_cpu):
    while True:
        good,state=ready();cpu=b/'bounded-numpy-ck-full-receipt.json'
        prior=b/'wet-coupled-gpu-br/exit.json'
        if not prior.exists():good=False;state['prior_queue']='wait oldBO original22 actualterminal to avoid concurrentlargecompilerheaps'
        else:
            old=json.loads(prior.read_text());assert old['returncode'] in [0,1] and old['source_unchanged'];state['prior_queue_returncode']=old['returncode'];state['prior_queue_passed']=old['passed']
        if require_current_cpu:
            if not cpu.exists():good=False;state['cpu']='waiting actual EHPC394 full1119/NumPycodeexactCK receipt transfer'
            else:
                d=json.loads(cpu.read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1119,failures=0,errors=0,skipped=0) and d['source_manifest_sha256']=='005c4a0e932d62427e3bb0c5f3a6bfa32428b1514482a8278b17b6adca4cdae4';state['cpu_receipt_sha256']=sha(cpu)
        (r/'waiting.json').write_text(json.dumps(dict(ready=good,state=state,seconds=time.monotonic()-start),indent=2)+'\n')
        if good:return
        time.sleep(20.)
wait_for_ready(False)
with (r/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(r/'collect_bounded_coupled_cu.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
collection=json.loads((r/'collection.json').read_text());assert code==0 and collection['passed'] and collection['source_manifest_sha256']==manifest
files=[('test_gpu_canopy_capacity_layers.py',3),('test_gpu_canopy_optics.py',5),('test_gpu_clm_richards_column.py',5),('test_gpu_fluxnet_richards_runner.py',3),('test_gpu_clm_capacity_column.py',3),('test_gpu_fluxnet_capacity_runner.py',3)]
for index,(name,count) in enumerate(files):
    wait_for_ready(index>=2);assert all(sha(s/n)==h for n,h in m.items());nodes=[Path(n.split('::')[0]).name+'::'+n.split('::',1)[1] for n in collection['nodes'] if Path(n.split('::')[0]).name==name];assert len(nodes)==count
    stem=Path(name).stem;expected=r/(stem+'-expected.json');expected.write_text(json.dumps(nodes,indent=2)+'\n');receipt=r/(stem+'-receipt.json');xml=r/(stem+'.xml');env=os.environ.copy();diag=r/(stem+'-diagnostics');diag.mkdir();env.update(NOAHMP_CAPACITY_COLUMN_DIAGNOSTICS=str(diag),NOAHMP_PFT_DIAGNOSTICS=str(diag),NOAHMP_RICHARDS_COLUMN_DIAGNOSTICS=str(diag),NOAHMP_RICHARDS_STATION_DIAGNOSTICS=str(diag),NOAHMP_CAPACITY_STATION_DIAGNOSTICS=str(diag));command=[sys.executable,'-u',str(r/'bounded_coupled_worker_cu.py'),'--source',str(s),'--test-file',str(s/'tests'/name),'--expected',str(expected),'--receipt',str(receipt),'--xml',str(xml)];begun=time.monotonic()
    with (r/(stem+'.log')).open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
    (r/'progress.json').write_text(json.dumps(dict(active_file=name,pid=p.pid,records=records),indent=2)+'\n');code=p.wait();d=json.loads(receipt.read_text()) if receipt.exists() else {};passed=bool(code==d.get('worker_exitcode')==d.get('pytest_returncode')==0 and d.get('passed') and d.get('source_unchanged') and d.get('node_coverage_exact') and d.get('all_setup_call_teardown_phases_passed') and d.get('counts')==dict(tests=count,failures=0,errors=0,skipped=0) and d.get('source_manifest_sha256')==manifest and d.get('xml_sha256')==sha(xml));row=dict(file=name,pid=p.pid,passed=passed,actual_parent_returncode=code,seconds=time.monotonic()-begun,receipt_sha256=sha(receipt) if receipt.exists() else None);records.append(row);(r/(stem+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
    if not passed:break
passed=len(records)==6 and all(q['passed'] for q in records) and all(sha(s/n)==h for n,h in m.items());d=dict(passed=passed,returncode=0 if passed else 1,records=records,seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=manifest,scope='FreshCN actualoriginalcoupled22 across6files, exact568source and1517collection, offline460input-preserved originalNumPyfixtures and actualCK1119/CO16. AllNumPycode exactCK. WaitoldBO22 actualterminal, no passcreditcopied. PhysicalGPU1UUID/privatecache, original8GiB/32GiB/resource/physics/raw1e-6/int/MHCN/restart/impurity gates retained. No NumPyforward onGPUhost. Not full398/1517/year/sciencepass.');(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');raise SystemExit(d['returncode'])

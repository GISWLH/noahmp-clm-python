from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'richards-current-flow-n';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text());assert e['returncode']==0 and e['passed'] and d['source_unchanged'] and all(d['final_outputs_byte_exact'].values()) and d['payload_sha256']==sha(r/'flow-and-systems.npz')
paths=sorted(p for p in (r/'xla-dump').rglob('*') if p.is_file());(r/'dump-SHA256.json').write_text(json.dumps({p.relative_to(r/'xla-dump').as_posix():sha(p) for p in paths},indent=2)+'\n')
with tarfile.open(r/'compiler-dump.tar.gz','w:gz') as t:
    for p in paths:t.add(p,arcname=p.relative_to(r/'xla-dump').as_posix(),recursive=False)
    t.add(r/'dump-SHA256.json',arcname='dump-SHA256.json',recursive=False)
a=b/'richards-current-flow-n-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():t.add(p,arcname=p.name,recursive=False)
    for n in ['phase-coordinate-native-b-source.tar.gz','probe_richards_current_flow_n.py','control_richards_current_flow_n.py','launch_richards_current_flow_n.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

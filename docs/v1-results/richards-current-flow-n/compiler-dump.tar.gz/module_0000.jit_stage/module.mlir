#loc1 = loc("args[0]")
module @jit_stage attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<1x4xf32> loc("args[0]")) -> (tensor<1x4xf32> {jax.result_info = "result"}) {
    return %arg0 : tensor<1x4xf32> loc(#loc7)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/lhwang/work/noahmp-v1/probe_richards_current_flow_n.py":46:18 to :31)
#loc3 = loc("/home/lhwang/work/noahmp-v1/probe_richards_current_flow_n.py":46:11 to :61)
#loc4 = loc("<genexpr>"(#loc2))
#loc5 = loc("<module>"(#loc3))
#loc6 = loc(callsite(#loc4 at #loc5))
#loc7 = loc("jit(stage)"(#loc6))

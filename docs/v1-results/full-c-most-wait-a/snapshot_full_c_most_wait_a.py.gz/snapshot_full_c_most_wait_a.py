from pathlib import Path
import datetime,hashlib,json,os,tarfile,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=base/'full-c-most-wait-a';root.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pid=4103014;process=Path('/proc')/str(pid)
assert process.stat().st_uid==os.getuid();command=[v.decode() for v in (process/'cmdline').read_bytes().split(b'\0') if v]
assert str(source/'full-by-file-c/run_pytest_worker_a.py') in command and str(source/'tests/test_gpu_clm_most_column.py') in command
stat=(process/'stat').read_text().rsplit(')',1)[1].split();ticks=os.sysconf('SC_CLK_TCK');elapsed=time.monotonic()-int(stat[19])/ticks;cpu=(int(stat[11])+int(stat[12]))/ticks
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='One read-only own-task progress/process snapshot while awaiting original full C MOST file. Not profiling all elapsed time, attributing a bottleneck, or test completion.',pid=pid,parent_pid=int(stat[1]),state=stat[0],wchan=(process/'wchan').read_text().strip(),elapsed_seconds=elapsed,cpu_seconds=cpu,command=command,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),source_unchanged=True)
(root/'snapshot.json').write_text(json.dumps(value,indent=2)+'\n');(root/'progress.json').write_bytes((source/'full-by-file-c/progress.json').read_bytes());(root/'active-file-log-tail.txt').write_text('\n'.join((source/'full-by-file-c/test_gpu_clm_most_column.log').read_text().splitlines()[-12:])+'\n');(root/'SOURCE_SHA256.json').write_bytes((source/'SOURCE_SHA256.json').read_bytes());(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
archive=base/'full-c-most-wait-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(root.iterdir()):t.add(p,arcname=p.name,recursive=False)
print(json.dumps(dict(snapshot=value,archive=str(archive),sha256=sha(archive),files=5)))

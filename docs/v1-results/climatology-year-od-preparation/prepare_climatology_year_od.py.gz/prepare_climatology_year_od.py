"""Static OD adapter preparation; never imports numerical code or launches jobs."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

OUT = Path(__file__).resolve().parent
DEST = OUT / 'climatology-year-od-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
original = (OUT / 'evaluate_climatology_year_kl.py').read_text()
value = original
replacements = [
    ('PBS-only all12 actual complete currentJN year stock/budget/FLUXNET audit.', 'PBS-only all12 actual complete NS/NM year stock/budget/FLUXNET audit.'),
    ("a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'", "a=Path('/tmp/noahmp-climatology-year-od/climatology-final-candidate-nm-source.tar.gz');assert sha(a)=='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'"),
    ("len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'", "len(m)==584 and manifest=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'"),
    ("a=b/plan['device_archive']", "a=Path('/tmp/noahmp-climatology-year-od')/plan['device_archive']"),
    ("package['source_manifest_sha256']==manifest", "package['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'"),
    ("protocol['source_manifest_sha256']==manifest", "protocol['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'"),
    ("operator=b/'height-observations-ea'", "operator=Path('/tmp/noahmp-climatology-year-od/soil-operators')"),
    ('ActualcurrentJN originaltwelve complete17520coldyears', 'ActualNS NM584 originaltwelve complete17520coldyears'),
    ('K78/full407 orreleaseclaim.', 'K78/full408 orreleaseclaim.'),
]
for old, new in replacements:
    assert value.count(old) == 1, old
    value = value.replace(old, new)
insertions = [
    ("import gzip,hashlib,itertools,json,os,subprocess,sys,tarfile,time,traceback\n", "import gzip,hashlib,io,itertools,json,os,subprocess,sys,tarfile,time,traceback\n"),
    ("s=tmp/'source';s.mkdir();sha=", "s=tmp/'source';assert os.uname().nodename.startswith('compute002') and str(tmp.resolve()).startswith('/tmp/') and r.resolve().is_relative_to(tmp.resolve());s.mkdir();sha="),
    ("results={}\n", "results={}\nfrom od_contract import verify_device_archive, load as od_load, TARGET, PARENT, PAIR_RECEIPT\nverify_device_archive(Path('/tmp/noahmp-climatology-year-od')/plan['device_archive'],od_load(Path('/tmp/noahmp-climatology-year-od/device-package.json')))\n"),
    ("loaded=native.load_batch(inputs/'batch.json');protocol=json.loads((inputs/'protocol.json').read_text())\n", "loaded=native.load_batch(inputs/'batch.json');protocol=json.loads((inputs/'protocol.json').read_text())\n    reuse=json.loads((device/'original-prefix-control/reference-reuse.json').read_text());expected=reuse['every_input_file_sha256']\n    assert {p.relative_to(inputs).as_posix() for p in inputs.rglob('*') if p.is_file()}==set(expected) and all(sha(inputs/n)==h for n,h in expected.items())\n    assert [c['case'] for c in loaded]==[c['case'] for c in protocol['cases']] and set(batch['case_reports'])=={c['case'] for c in loaded}\n    assert batch['ledger_steps']==17520 and batch['ledger_segments']==1\n"),
    ("with np.load(p/'first-continued-step.npz',allow_pickle=False) as z:first=dict(z)\n", "with np.load(p/'first-continued-step.npz',allow_pickle=False) as z:first=dict(z)\n    assert sha(p/'prefix-verification.json')==PAIR_RECEIPT and verification['returned_fields_per_batched_step']==313 and verification['cold_fields_exact']==23\n    assert verification['all16state_chains_and_final_checkpoint_exact'] and verification['source_unchanged']\n    start_audit=json.loads((p/'year-start-audit.json').read_text());assert start_audit['saved_fields_exact']==23 and start_audit['source_manifest_sha256']==manifest\n    assert start_audit['verified_prefix_checkpoint_sha256']==start_audit['current_checkpoint_sha256']==binding['prefix_checkpoint_sha256']\n    assert start_audit['cpu_verification_sha256']==sha(p/'prefix-verification.json')\n    with np.load(p/'steps/call-00000.npz',allow_pickle=False) as z:schema={n for n in z.files if n.startswith('output/')}\n    assert len(schema)==313 and {n for n in first if n.startswith('output/')}==schema\n    assert prefix_report['identity']==batch['identity'] and prefix_report['ledger_steps']==48 and prefix_report['ledger_segments']==1\n"),
    ("name=case['case'];site=case['config']['site'];sub=r/name;sub.mkdir()\n", "name=case['case'];site=case['config']['site'];sub=r/name;sub.mkdir()\n        from od_contract import NP_MEMBER, NP_DEVICE\n        assert sha(device/NP_MEMBER)==NP_DEVICE\n        with tarfile.open(device/NP_MEMBER) as original_np:\n            original_batch=json.loads(original_np.extractfile('current/trajectory/batch.json').read())\n            original_report=json.loads(original_np.extractfile('current/trajectory/'+name+'/'+original_batch['case_reports'][name]['file']).read())\n            original_raw=original_np.extractfile('current/trajectory/'+name+'/'+original_report['model_npz']).read()\n            assert hashlib.sha256(original_raw).hexdigest()==original_report['model_npz_sha256']\n            with np.load(io.BytesIO(original_raw),allow_pickle=False) as original_trace:\n                assert set(original_trace.files)==set(trace)\n                for key in original_trace.files:\n                    before=original_trace[key];after=trace[key][:48]\n                    assert before.shape==after.shape and before.dtype==after.dtype and before.tobytes()==after.tobytes(),('original NP48 trace',name,key)\n"),
]
for old, new in insertions:
    assert value.count(old) == 1
    value = value.replace(old, new)
# A reversible adapter proof: remove only listed metadata/identity additions,
# then every byte of the original KL science/QC/metric expressions is restored.
restored = value
for old, new in reversed(insertions):
    assert restored.count(new) == 1
    restored = restored.replace(new, old)
for old, new in reversed(replacements):
    assert restored.count(new) == 1
    restored = restored.replace(new, old)
assert restored == original
ast.parse(value)
(DEST / 'evaluate_climatology_year_od.py').write_text(value, newline='\n')
helper = (OUT / 'audit_bgc_stream_km.py').read_bytes()
assert b'\r\n' not in helper
(DEST / 'audit_bgc_stream_km.py').write_bytes(helper)
archives = {'current-year-preparation-ks-evidence.tar.gz': '4cfacb1d3fd9945457939cff61747ec70ccbac96cc3f4d6ddab6b167ff788a99',
            'current-year-export-readiness-kt-evidence.tar.gz': '6a540b4fcaa6ea4cf74af916c69e2b3dcdb37f37bd2cc58d89599b9b2b7d38f2'}
for name, digest in archives.items():
    assert sha((OUT / name).read_bytes()) == digest
with tarfile.open(OUT / 'current-year-preparation-ks-evidence.tar.gz') as tf:
    assert tf.extractfile('prepared-controls/evaluate_climatology_year_kl.py').read() == (OUT / 'evaluate_climatology_year_kl.py').read_bytes()
    assert tf.extractfile('prepared-controls/audit_bgc_stream_km.py').read() == helper
with tarfile.open(OUT / 'current-year-export-readiness-kt-evidence.tar.gz') as tf:
    assert tf.extractfile('export_climatology_year_kk.py').read() == (OUT / 'export_climatology_year_kk.py').read_bytes()
unchanged = {}
with tarfile.open(OUT / 'clm-ballberry-jn-source.tar.gz') as old, tarfile.open(OUT / 'climatology-final-candidate-nm-source.tar.gz') as new:
    for name in ['benchmarks/run_fluxnet_native.py', 'benchmarks/compare_hrldas_native_year.py', 'benchmarks/evaluate_fluxnet_series.py']:
        a, b = old.extractfile(name).read(), new.extractfile(name).read()
        assert a == b
        unchanged[name] = sha(a)
    frame = lambda raw: {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef)}
    a, b = frame(old.extractfile('benchmarks/assess_clm_spinup.py').read()), frame(new.extractfile('benchmarks/assess_clm_spinup.py').read())
    assert a['_frame'] == b['_frame']
    assert {n for n in a if a[n] != b[n]} == {'compare_endpoints', 'observed_carbon_century'}
proof = dict(preparation_only=True, submitted=False, numerical_execution=False,
    parent_evaluator_sha256=sha((OUT / 'evaluate_climatology_year_kl.py').read_bytes()),
    derived_evaluator_sha256=sha((DEST / 'evaluate_climatology_year_od.py').read_bytes()),
    exact_reverse_adapter_to_original_KL=True, original_science_expressions_qc_metrics_retained=True,
    replacements=[dict(old=a, new=b) for a,b in replacements],
    metadata_insertions=[dict(before=a, after=b) for a,b in insertions],
    helper_sha256=sha(helper), helper_byteexact_to_KS=True, original_KK_byteexact_to_KT=True,
    historical_archive_sha256=archives, unchanged_runtime_audit_observation_dependencies=unchanged,
    promoted_dependency_change='NM assess_clm_spinup uses already accepted NK strict abs(rate)<5%, not old <=5%. _frame AST unchanged; KL call unchanged.',
    scope='313 full-return schema applies to cold48 and first continued packet only. Remaining17472 preserve BGC subsets plus original13 traces/budgets; complete210240 C/N column-steps stream audited. Full-year M/H checks are stored-ledger/final-storage checks, not re-derived17520 heat tendencies.')
(DEST / 'static-adapter-proof.json').write_text(json.dumps(proof, indent=2) + '\n', newline='\n')
names = ['od_contract.py', 'export_climatology_year_od.py', 'evaluate_climatology_year_od.py',
         'audit_bgc_stream_km.py', 'dispatch_climatology_analysis_od.py', 'run_climatology_analysis_od.py',
         'climatology_analysis_od.pbs', 'static-adapter-proof.json', 'README.md']
for name in names:
    if name.endswith('.py'):
        ast.parse((DEST / name).read_text())
hashes = {n: sha((DEST / n).read_bytes()) for n in names}
(DEST / 'CONTROLS_SHA256.json').write_text(json.dumps(hashes, indent=2) + '\n', newline='\n')
print(json.dumps(dict(prepared=True, controls=len(hashes), evaluated=False, submitted=False,
                     exact_reverse_adapter=True, destination=str(DEST))))

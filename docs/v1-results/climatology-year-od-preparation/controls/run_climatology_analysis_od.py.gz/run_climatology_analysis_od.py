"""PBS compute002 wrapper; all output and source expansion remain under /tmp."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tarfile
import traceback
from od_contract import STAGE, SOURCE_ARCHIVE, TARGET, DEVICE_NAME, OPERATORS, controls, load, sha, verify_device_archive, verify_ks

assert os.environ.get('PBS_JOBID') and os.uname().nodename.startswith('compute002')
tmp = Path(os.environ['TMPDIR']).resolve()
assert str(tmp).startswith('/tmp/')
root = tmp / 'result'
assert not root.exists()
root.mkdir()
record = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
    actual_evaluator_parent_returncode=None, passed=False, failure=None, forward_model_runs=0)
try:
    hashes = controls(STAGE)
    plan = load(STAGE / 'plan.json')
    assert plan['controls_sha256'] == hashes and plan['source_manifest_sha256'] == TARGET
    assert plan['actual_year_parent_returncode'] == 0 and plan['requested_steps'] == 17520 and plan['cases'] == 12
    packet = load(STAGE / 'device-package.json')
    assert plan['device_archive_sha256'] == packet['sha256']
    verify_device_archive(STAGE / DEVICE_NAME, packet)
    assert sha(STAGE / 'climatology-final-candidate-nm-source.tar.gz') == SOURCE_ARCHIVE
    verify_ks(STAGE / 'current-year-preparation-ks-evidence.tar.gz', STAGE / 'audit_bgc_stream_km.py')
    assert plan['soil_operator_sha256'] == OPERATORS
    assert all(sha(STAGE / 'soil-operators' / (site + '-soil-operator.json')) == digest for site, digest in OPERATORS.items())
    for name in list(hashes) + ['CONTROLS_SHA256.json', 'plan.json', 'device-package.json']:
        (root / name).write_bytes((STAGE / name).read_bytes())
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    with (root / 'worker.log').open('x') as log:
        code = subprocess.run([sys.executable, '-B', str(root / 'evaluate_climatology_year_od.py')],
                              cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    record['actual_evaluator_parent_returncode'] = code
    result = load(root / 'receipt.json')
    assert code == 0 and result['evaluation_delivered'] and result['source_unchanged']
    assert result['failure'] is None and result['source_manifest_sha256'] == TARGET and len(result['cases']) == 12
    assert all(sha(STAGE / n) == digest for n, digest in hashes.items())
    record.update(passed=True, receipt_sha256=sha(root / 'receipt.json'))
except Exception as error:
    record['failure'] = type(error).__name__ + ': ' + str(error)
    (root / 'wrapper-traceback.txt').write_text(traceback.format_exc())
(root / 'worker-actual-exit.json').write_text(json.dumps(record, indent=2) + '\n')
target = STAGE / 'result.tar.gz'
assert not target.exists()
with tarfile.open(target, 'w:gz') as tf:
    for path in sorted(root.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            tf.add(path, arcname=path.relative_to(root).as_posix(), recursive=False)
(STAGE / 'result-package.json').write_text(json.dumps(dict(archive=target.name, sha256=sha(target),
    bytes=target.stat().st_size, **record), indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if record['passed'] else 1)

"""OD metadata-only identity/terminal gates. No model imports or task launch."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

TARGET = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
PARENT = 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
SOURCE_ARCHIVE = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
INPUT = 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
KS = '4cfacb1d3fd9945457939cff61747ec70ccbac96cc3f4d6ddab6b167ff788a99'
KT = '6a540b4fcaa6ea4cf74af916c69e2b3dcdb37f37bd2cc58d89599b9b2b7d38f2'
PAIR = 'a1a7b9703af3fc10683e2f3da5413426023297198603cbba65ee7dc3cf28be43'
PAIR_RECEIPT = 'c12d9acef4a7cf6940c36adeed8ed216c6878dc0d8b41faf83ce8d76e34f070e'
NP_DEVICE = 'ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416'
NP_MEMBER = 'original-cold48/cold48-evidence.tar.gz'
STAGE = Path('/tmp/noahmp-climatology-year-od')
DEVICE_NAME = 'climatology-year-od-device.tar.gz'
OPERATORS = {'CN-Cng':'0a9b838cc545e1976d55a00bf019b5ebc2ea086726f7ed993a1e0d07d2d7cd78',
             'CN-Qia':'49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095',
             'CN-Cha':'56b41a9c173f28c56f71b453a15626dac329d443582cdc2d5080428180ce91ac'}
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
load = lambda path: json.loads(Path(path).read_text())


def controls(folder):
    manifest = load(folder / 'CONTROLS_SHA256.json')
    assert all(sha(folder / name) == digest for name, digest in manifest.items())
    return manifest


def terminal(parent, receipt, receipt_sha256, batch):
    assert parent['passed'] and parent['actual_parent_returncode'] == 0 and parent['failure'] is None
    assert parent['source_manifest_sha256'] == TARGET and parent['receipt_sha256'] == receipt_sha256
    assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['source_manifest_sha256'] == TARGET
    assert receipt['status'] == 'complete' and receipt['steps_completed'] == receipt['steps_requested'] == 17520
    assert receipt['device_barrier_complete'] and receipt['continued_fields_exact'] == 23 and receipt['first_continued_step_captured']
    assert receipt['bgc_diagnostic_steps'] == 17472 and len(receipt['bgc_diagnostic_chunks']) == 364
    assert batch['status'] == 'complete' and batch['steps_completed'] == batch['steps_requested'] == 17520
    assert batch['source_unchanged'] and batch['columns'] == 12 and batch['ledger_steps'] == 17520 and batch['ledger_segments'] == 1
    assert batch['identity']['backend'] == 'cuda32' and batch['identity']['compare_jax32'] is False
    assert batch['identity'].get('native_state_arrays', 16) == 16 and batch['same_precision_max_absolute'] is None


def verify_np_members(raw):
    """Bind audit credit to the immutable original NP48 payload, not its schema."""
    original = raw(NP_MEMBER)
    assert hashlib.sha256(original).hexdigest() == NP_DEVICE
    with tarfile.open(fileobj=io.BytesIO(original)) as tf:
        names = tf.getnames()
        assert len(names) == len(set(names)) and all(m.isfile() for m in tf)
        prior = lambda name: tf.extractfile(name).read()
        batch = json.loads(prior('current/trajectory/batch.json'))
        assert batch['steps_completed'] == 48 and batch['steps_requested'] == 17520
        assert batch['columns'] == 12 and batch['status'] == 'running'
        mapping = {f'current/steps/call-{k:05d}.npz': f'current/steps/call-{k:05d}.npz' for k in range(48)}
        for name in ['cold-audit.json', 'prefix-report.json', 'receipt.json', 'exit.json']:
            mapping['current/' + name] = 'current/' + name
        mapping['current/validated-prefix-report.json'] = 'current/trajectory/batch.json'
        mapping['current/validated-prefix-state.npz'] = 'current/trajectory/' + batch['checkpoint_file']
        cold, = [n for n in names if n.startswith('current/trajectory/state-0000000-') and n.endswith('.npz')]
        mapping[cold] = cold
        generation = Path(cold).stem.removeprefix('state-')
        for case in batch['case_reports']:
            for name in ['report-' + generation + '.json', 'trace-' + generation + '.npz']:
                key = 'current/trajectory/' + case + '/' + name
                mapping[key] = key
        assert all(raw(name) == prior(old) for name, old in mapping.items())
        assert hashlib.sha256(raw('current/validated-prefix-state.npz')).hexdigest() == batch['checkpoint_sha256']
        return dict(original_archive_sha256=NP_DEVICE, exact_original_members=len(mapping),
                    mapping=mapping, prefix_case_reports=batch['case_reports'])


def verify_device_archive(path, packet):
    assert packet['source_manifest_sha256'] == TARGET and packet['steps'] == 17520 and packet['cases'] == 12
    assert packet['actual_year_parent_returncode'] == 0 and sha(path) == packet['sha256']
    with tarfile.open(path) as tf:
        names = tf.getnames()
        assert len(names) == len(set(names)) and all(m.isfile() for m in tf)
        raw = lambda name: tf.extractfile(name).read()
        receipt_raw = raw('current/year-receipt.json')
        receipt = json.loads(receipt_raw)
        batch_raw = raw('current/trajectory/batch.json')
        terminal(json.loads(raw('year-controller/exit.json')), receipt,
                 hashlib.sha256(receipt_raw).hexdigest(), json.loads(batch_raw))
        assert hashlib.sha256(batch_raw).hexdigest() == receipt['report_sha256']
        assert hashlib.sha256(raw('SOURCE_SHA256.json')).hexdigest() == TARGET
        audit = json.loads(raw('OD_EXPORT_AUDIT.json'))
        assert audit['output_fields_per_step'] == 313 and audit['cold_packets_checked'] == 48
        assert audit['first_continued_output_schema_exact'] and audit['checkpoint_fields'] == 23
        inventory = json.loads(raw('ARTIFACT_SHA256.json'))
        assert set(inventory) == set(names) - {'ARTIFACT_SHA256.json'}
        assert all(hashlib.sha256(raw(name)).hexdigest() == digest for name, digest in inventory.items())
        verify_np_members(raw)
    return receipt


def verify_ks(path, helper):
    assert sha(path) == KS
    with tarfile.open(path) as tf:
        raw = lambda name: tf.extractfile(name).read()
        assert raw('climatology-bgc-stream-kn/audit_bgc_stream_km.py') == helper.read_bytes()
        result = json.loads(raw('climatology-bgc-stream-kn/audit.json'))
        assert result['source_unchanged'] and result['result']['physical_column_steps'] == 1152
        assert raw('climatology-bgc-stream-kn/pbs-exit.txt').strip() == b'0'
        status = raw('climatology-bgc-stream-kn/actual-pbs-qstat.txt').decode()
        assert re.search(r'^\s*job_state = F\s*$', status, re.M) and re.search(r'^\s*Exit_status = 0\s*$', status, re.M)
    return dict(archive_sha256=KS, original_physical_column_steps=1152,
                scope='Historical KN1190 helper compatibility evidence only; no NM annual execution credit.')

"""KL-derived submission gate: only a verified true NS terminal export may submit."""
from pathlib import Path
import argparse
import json
import subprocess
from od_contract import STAGE, SOURCE_ARCHIVE, TARGET, DEVICE_NAME, OPERATORS, controls, load, sha, verify_device_archive, verify_ks

assert Path(__file__).resolve().parent == STAGE
hashes = controls(STAGE)
packet = load(STAGE / 'device-package.json')
assert packet['archive'] == DEVICE_NAME
receipt = verify_device_archive(STAGE / DEVICE_NAME, packet)
assert sha(STAGE / 'climatology-final-candidate-nm-source.tar.gz') == SOURCE_ARCHIVE
original_helper_proof = verify_ks(STAGE / 'current-year-preparation-ks-evidence.tar.gz', STAGE / 'audit_bgc_stream_km.py')
assert all(sha(STAGE / 'soil-operators' / (site + '-soil-operator.json')) == digest for site, digest in OPERATORS.items())
# Manager and compute002 stages must be explicitly copied beforehand. The PBS
# worker rechecks every transferred file on compute002 before numerical imports.
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--submit-existing-plan', action='store_true')
args = parser.parse_args()
assert not (STAGE / 'dispatch.json').exists()
assert not (STAGE / 'result.tar.gz').exists() and not (STAGE / 'pbs-exit.txt').exists()
plan = dict(device_archive=DEVICE_NAME, device_archive_sha256=packet['sha256'], controls_sha256=hashes,
    soil_operator_sha256=OPERATORS, source_manifest_sha256=TARGET,
    source_archive_sha256=SOURCE_ARCHIVE, original_helper_proof=original_helper_proof,
    actual_year_parent_returncode=0, requested_steps=17520, cases=12,
    scope='Independent post-terminal analysis only. No GPU model, no science pass from submission or analysis exit0.')
if not args.submit_existing_plan:
    assert not (STAGE / 'plan.json').exists()
    (STAGE / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps(dict(preflight_passed=True, plan_sha256=sha(STAGE / 'plan.json'),
        action='Copy this exact plan.json to compute002 at the same STAGE; then invoke this script with --submit-existing-plan.')))
else:
    assert load(STAGE / 'plan.json') == plan
    result = subprocess.run(['qsub', str(STAGE / 'climatology_analysis_od.pbs')],
                            cwd=STAGE, capture_output=True, text=True)
    (STAGE / 'qsub.stdout.txt').write_text(result.stdout)
    (STAGE / 'qsub.stderr.txt').write_text(result.stderr)
    (STAGE / 'qsub-actual-exit.json').write_text(json.dumps(dict(actual_parent_returncode=result.returncode)) + '\n')
    assert result.returncode == 0, result.stderr
    record = dict(pbs_job=result.stdout.strip(), plan_sha256=sha(STAGE / 'plan.json'),
        controls_sha256=hashes, source_manifest_sha256=TARGET, device_archive_sha256=packet['sha256'],
        scope='Submitted only after true NS17520 parent0. Submission is not analysis/science success.')
    (STAGE / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)

"""KK-derived read-only exporter; refuse before true NS17520 and actual parent0."""
from pathlib import Path
import hashlib
import io
import json
import os
import re
import tarfile
import zipfile
from od_contract import TARGET, PARENT, INPUT, PAIR_RECEIPT, DEVICE_NAME, NP_DEVICE, NP_MEMBER, controls, load, sha, terminal, verify_np_members

BASE = Path('/home/lhwang/work/noahmp-v1')
CONTROL = Path(__file__).resolve().parent
MODEL = BASE / 'climatology-cold48-np/cold48'
OLD = MODEL.parent
YEAR = BASE / 'climatology-year-ns'
SOURCE = Path('/tmp/noahmp-climatology-cold48-np/source')
DEST = Path('/tmp/noahmp-climatology-year-od-export')
control_hashes = controls(CONTROL)
# All terminal gates precede creation of output directories or any packaging.
parent, receipt = load(MODEL / 'year-exit.json'), load(MODEL / 'year-receipt.json')
folder = MODEL / 'trajectory'
raw = (folder / 'batch.json').read_bytes()
report = json.loads(raw)
terminal(parent, receipt, sha(MODEL / 'year-receipt.json'), report)
assert sha(folder / 'batch.json') == receipt['report_sha256']
manifest = load(SOURCE / 'SOURCE_SHA256.json')
assert sha(SOURCE / 'SOURCE_SHA256.json') == TARGET and len(manifest) == 584
assert all(sha(SOURCE / name) == digest for name, digest in manifest.items())
assert all(manifest[n] == h for n, h in report['identity']['source_sha256'].items())
assert sha(folder / report['checkpoint_file']) == report['checkpoint_sha256']
prefix = load(MODEL / 'validated-prefix-report.json')
assert report['identity'] == prefix['identity'] and prefix['steps_completed'] == 48
verification = load(MODEL / 'prefix-verification.json')
assert sha(MODEL / 'prefix-verification.json') == PAIR_RECEIPT
assert verification['passed'] and verification['source_unchanged'] and verification['source_manifest_sha256'] == TARGET
assert verification['physical_step_pairs'] == 576 and verification['returned_fields_per_batched_step'] == 313
assert verification['cold_fields_exact'] == 23 and verification['all16state_chains_and_final_checkpoint_exact']
assert all(case['passed'] for case in verification['cases']) and len(verification['cases']) == 12
assert (MODEL / 'prefix-verification-pbs-exit.txt').read_text().strip() == '0'
qstat = (MODEL / 'prefix-verification-actual-qstat.txt').read_text()
assert re.search(r'^Job Id: 1586\.manager\s*$', qstat, re.M)
assert re.search(r'^\s*job_state = F\s*$', qstat, re.M) and re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
year_plan = load(YEAR / 'plan.json')
assert year_plan['source_manifest_sha256'] == TARGET and year_plan['source'] == str(SOURCE)
assert year_plan['original_np_plan_sha256'] == sha(OLD / 'plan.json')
assert all(sha(YEAR / name) == digest for name, digest in year_plan['controls_sha256'].items())
binding = load(MODEL / 'year-prefix-binding.json')
assert binding['ns_plan_sha256'] == sha(YEAR / 'plan.json')
assert binding['original_np_plan_sha256'] == sha(OLD / 'plan.json')
assert binding['prefix_batch_report_sha256'] == sha(MODEL / 'validated-prefix-report.json')
assert binding['prefix_checkpoint_sha256'] == sha(MODEL / 'validated-prefix-state.npz')
assert binding['prefix_ledger_steps'] == 48 and binding['prefix_ledger_segments'] == 1
start = load(MODEL / 'year-start-audit.json')
assert start['saved_fields_exact'] == 23 and start['source_manifest_sha256'] == TARGET
assert start['current_checkpoint_sha256'] == start['verified_prefix_checkpoint_sha256'] == binding['prefix_checkpoint_sha256']
assert start['cpu_verification_sha256'] == PAIR_RECEIPT
cold_parent, cold_receipt = load(MODEL / 'exit.json'), load(MODEL / 'receipt.json')
assert cold_parent['passed'] and cold_parent['actual_parent_returncode'] == 0
assert cold_parent['receipt_sha256'] == sha(MODEL / 'receipt.json')
assert cold_receipt['source_manifest_sha256'] == TARGET and cold_receipt['source_unchanged']
assert cold_receipt['failure'] is None and cold_receipt['steps_completed'] == 48 and cold_receipt['device_barrier_complete']
assert cold_receipt['report_sha256'] == sha(MODEL / 'validated-prefix-report.json')
pairs = []


def add(path, name):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    pairs.append((path, name))


def array_names(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) and all(n.endswith('.npy') for n in names)
        return {n[:-4] for n in names}


for name in ['year-receipt.json', 'year-start-audit.json', 'year-prefix-binding.json',
             'prefix-verification.json', 'prefix-verification-pbs-exit.txt', 'prefix-verification-actual-qstat.txt',
             'validated-prefix-state.npz', 'validated-prefix-report.json', 'first-continued-step.npz',
             'cold-audit.json', 'prefix-report.json', 'receipt.json', 'exit.json']:
    add(MODEL / name, 'current/' + name)
for original, name in [('year-exit.json', 'exit.json'), ('year-launch.json', 'launch.json'), ('year-worker.json', 'worker.json')]:
    add(MODEL / original, 'year-controller/' + name)
add(YEAR / 'plan.json', 'year-controller/plan.json')
for name, digest in year_plan['controls_sha256'].items():
    if not name.endswith('.tar.gz'):
        add(YEAR / name, 'year-controller/controls/' + name)
for name in ['plan.json', 'launch.json', 'reference-reuse.json', 'source-dependencies.json', 'cold48-package.json']:
    add(OLD / name, 'original-prefix-control/' + name)
add(SOURCE / 'SOURCE_SHA256.json', 'SOURCE_SHA256.json')
add(folder / 'batch.json', 'current/trajectory/batch.json')
add(folder / report['checkpoint_file'], 'current/trajectory/' + report['checkpoint_file'])
cold = list(folder.glob('state-0000000-*.npz'))
assert len(cold) == 1
add(cold[0], 'current/trajectory/' + cold[0].name)
generation = cold[0].stem.removeprefix('state-')
assert len(array_names(cold[0])) == len(array_names(folder / report['checkpoint_file'])) == 23
assert array_names(cold[0]) == array_names(folder / report['checkpoint_file'])
for case, descriptor in report['case_reports'].items():
    sub = folder / case
    p = sub / descriptor['file']
    value = load(p)
    assert sha(p) == descriptor['sha256'] and value['status'] == 'complete'
    assert value['steps_completed'] == value['steps_requested'] == 17520 and value['batch_checkpoint_sha256'] == report['checkpoint_sha256']
    assert sha(sub / value['model_npz']) == value['model_npz_sha256']
    for path in [p, sub / value['model_npz'], sub / ('report-' + generation + '.json'), sub / ('trace-' + generation + '.npz')]:
        add(path, 'current/trajectory/' + case + '/' + path.name)
assert len(report['case_reports']) == 12
schema = None
for k in range(48):
    name = 'steps/call-' + str(k).zfill(5) + '.npz'
    fields = {n for n in array_names(MODEL / name) if n.startswith('output/')}
    assert len(fields) == 313 and (schema is None or fields == schema)
    schema = fields
    add(MODEL / name, 'current/' + name)
assert {n for n in array_names(MODEL / 'first-continued-step.npz') if n.startswith('output/')} == schema
for i, chunk in enumerate(receipt['bgc_diagnostic_chunks']):
    first, end = 48 + i * 48, 96 + i * 48
    assert chunk['first'] == first and chunk['end'] == end
    name = 'year-bgc-diagnostics/steps-' + str(first).zfill(7) + '-' + str(end).zfill(7) + '.npz'
    assert sha(MODEL / name) == chunk['sha256']
    add(MODEL / name, 'current/' + name)
inputs = load(BASE / 'multisite-climatology-jr-package.json')
assert inputs['source_manifest_sha256'] == PARENT and inputs['archive_sha256'] == INPUT
assert sha(BASE / inputs['archive']) == INPUT
reuse = load(OLD / 'reference-reuse.json')
assert reuse['reference_reusable'] and reuse['candidate_source_manifest_sha256'] == TARGET
assert reuse['reference_source_manifest_sha256'] == PARENT and reuse['input_archive_sha256'] == INPUT
expected = reuse['every_input_file_sha256']
assert {p.relative_to(MODEL / 'inputs').as_posix() for p in (MODEL / 'inputs').rglob('*') if p.is_file()} == set(expected)
assert all(sha(MODEL / 'inputs' / n) == h for n, h in expected.items())
with tarfile.open(BASE / inputs['archive']) as tf:
    files = {m.name: m for m in tf if m.isfile()}
    assert set(files) == set(expected)
    assert all(hashlib.sha256(tf.extractfile(files[n]).read()).hexdigest() == h for n, h in expected.items())
add(BASE / inputs['archive'], 'frozen-inputs/' + inputs['archive'])
add(BASE / 'multisite-climatology-jr-package.json', 'frozen-inputs/package.json')
for name in list(control_hashes) + ['CONTROLS_SHA256.json']:
    add(CONTROL / name, 'export-controls/' + name)
assert sha(OLD / 'cold48-evidence.tar.gz') == NP_DEVICE
add(OLD / 'cold48-evidence.tar.gz', NP_MEMBER)
locations = {name: path for path, name in pairs}
np_binding = verify_np_members(lambda name: locations[name].read_bytes())
assert not DEST.exists()
DEST.mkdir()
audit = dict(output_fields_per_step=313, output_schema=sorted(schema), cold_packets_checked=48,
    first_continued_output_schema_exact=True, checkpoint_fields=23, cases=12, source_manifest_sha256=TARGET,
    input_reference_parent_manifest_sha256=PARENT, all_original_input_files_byte_exact=True,
    bgc_continued_steps=17472, bgc_chunks=364, original_year_plan_sha256=sha(YEAR / 'plan.json'),
    original_np48_binding=np_binding,
    original_archive_references={name: digest for name, digest in year_plan['controls_sha256'].items() if name.endswith('.tar.gz')},
    scope='Read-only terminal export, not annual scientific acceptance or equilibrium.')
inventory = {}
target = DEST / DEVICE_NAME
with tarfile.open(target, 'w:gz') as tf:
    for path, name in pairs:
        assert name not in inventory
        inventory[name] = sha(path)
        tf.add(path, arcname=name, recursive=False)
        assert sha(path) == inventory[name]
    for name, value in [('OD_EXPORT_AUDIT.json', audit), ('ARTIFACT_SHA256.json', inventory)]:
        data = (json.dumps(value, indent=2) + '\n').encode()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        tf.addfile(info, io.BytesIO(data))
        if name != 'ARTIFACT_SHA256.json':
            inventory[name] = hashlib.sha256(data).hexdigest()
assert (folder / 'batch.json').read_bytes() == raw
assert all(sha(SOURCE / n) == h for n, h in manifest.items())
assert all(sha(path) == inventory[name] for path, name in pairs)
packet = dict(archive=target.name, sha256=sha(target), bytes=target.stat().st_size,
    artifacts=len(inventory) + 1, source_manifest_sha256=TARGET, steps=17520, cases=12,
    actual_year_parent_returncode=0, scope='Closed NS same NP trajectory only; independent EHPC audit still required.')
from od_contract import verify_device_archive
verify_device_archive(target, packet)
(DEST / 'device-package.json').write_text(json.dumps(packet, indent=2) + '\n')
print(json.dumps(packet), flush=True)

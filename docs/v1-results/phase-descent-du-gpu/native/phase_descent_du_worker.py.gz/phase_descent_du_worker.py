from pathlib import Path
import hashlib,json,runpy
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-descent-du-gpu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def blocked(*args,**kwargs):raise AssertionError('Native phase validation uses frozenEHPC reference, no NumPyforward physics')
import noahmp_clm.clm_enthalpy_driver as column
import noahmp_clm.physics.canopy_phase_energy as phase
import noahmp_clm.physics.richards as flow
import run_fluxnet_column as runner
column.step_clm_enthalpy_column=blocked;phase.solve_canopy_phase_energy=blocked;flow.redistribute_soil_enthalpy=blocked;runner.step_clm_enthalpy_column=blocked
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';meta=json.loads((r/'package.json').read_text());assert sha(s/'SOURCE_SHA256.json')==meta['manifest_sha256'];runpy.run_path(str(worker),run_name='__main__')

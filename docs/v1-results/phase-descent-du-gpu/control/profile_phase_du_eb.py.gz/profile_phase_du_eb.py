"""Read-only nonblocking Python stacks; no locals, worker stops or numerical evaluation."""
from pathlib import Path
import datetime,hashlib,json,subprocess
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-du-profile-eb';assert not r.exists();r.mkdir();pid=852511;p=Path('/proc')/str(pid);record=dict(pid=pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Readonly nonblocking py-spy dump withoutlocals on exactownDU worker; no targetstop/source/cache/systemsetting edit or physics/math evaluation.')
if p.exists():
    cmd=(p/'cmdline').read_bytes();assert b'phase-descent-du-gpu/phase_descent_du_worker.py' in cmd and b'test_gpu_canopy_phase_weak_descent.py' in cmd;record['cmdline_sha256']=hashlib.sha256(cmd).hexdigest();(r/'before-status.txt').write_bytes((p/'status').read_bytes());tool=b/'profile-tools-u/bin/py-spy';assert hashlib.sha256(tool.read_bytes()).hexdigest()=='e7c2de2dc54449ec88c086f1859555b4e34e63ccdcf3f8804496f9306cd44de6';result=subprocess.run([str(tool),'dump','--pid',str(pid),'--nonblocking'],capture_output=True,text=True,timeout=25);(r/'stack.txt').write_text(result.stdout);(r/'stderr.txt').write_text(result.stderr);record['observer_returncode']=result.returncode;record['target_still_exists_after']=p.exists()
    if p.exists():(r/'after-status.txt').write_bytes((p/'status').read_bytes())
else:record['observer_skipped']='Original worker alreadyterminal/missing, no replacement/restart inferred'
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

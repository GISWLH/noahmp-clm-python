from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'phase-descent-du-gpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'exit.json').read_text());assert d['returncode']==1 and not d['passed'] and d['source_unchanged'] and len(d['records'])==1 and d['records'][0]['actual_parent_returncode']==1;receipt=json.loads((r/'test_gpu_canopy_phase_weak_descent-receipt.json').read_text());assert receipt['counts']==dict(tests=3,failures=1,errors=0,skipped=0) and receipt['source_unchanged'] and receipt['node_coverage_exact'];items=[]
for root,prefix in [(r,'native'),(b/'phase-descent-dv-gpu','gated-original-tests'),(b/'phase-du-profile-eb','readonly-profile')]:items.extend((p,prefix+'/'+p.relative_to(root).as_posix()) for p in sorted(root.rglob('*')) if p.is_file())
for name in ['phase-descent-du-full-receipt.json','phase-descent-du-pbs-exit.txt','profile_phase_du_eb.py',Path(__file__).name]:items.append((b/name,'control/'+name))
a=b/'phase-descent-du-gpu-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

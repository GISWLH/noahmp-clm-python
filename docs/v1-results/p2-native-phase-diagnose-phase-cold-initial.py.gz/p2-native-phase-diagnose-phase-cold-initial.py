import numpy as np,jax,jax.numpy as j,cupy as cp
from jax import lax
s=lax.optimization_barrier
x=np.array([263.,265.,258.,270.],np.float32)
def old(x):return s(s(x-273.15)*2100./4180.)
def split(x):return s(s(s(x-273.15)*2100.)/4180.)
k=cp.RawKernel('extern "C" __global__ void init(const float* x,float* y){int i=threadIdx.x;y[i]=(x[i]-273.15f)*2100.f/4180.f;}','init',options=('--fmad=false','--prec-div=false'))
a=cp.asarray(x);b=cp.empty_like(a);k((1,),(4,),(a,b));cuda=cp.asnumpy(b)
print('air',x.tolist());print('CUDA',cuda.tolist());print('JAX unseparated',np.asarray(jax.jit(old)(x)).tolist());print('JAX split',np.asarray(jax.jit(split)(x)).tolist())
print(jax.jit(old).lower(j.asarray(x)).compile().as_text())

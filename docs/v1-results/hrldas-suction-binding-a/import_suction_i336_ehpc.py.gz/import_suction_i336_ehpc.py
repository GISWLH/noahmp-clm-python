from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');archive=base/'suction-i336-prefix-evidence.tar.gz';root=base/'suction-i336-prefix';assert not root.exists();root.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(archive)=='5ecf05d1b5ef0dcb81437b26653068e3d5f6d6a081eac92c5d3b055ee1a029ce'
with tarfile.open(archive) as t:
    members=t.getmembers();assert len(members)==13
    for m in members:
        p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
        dest=root/m.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(t.extractfile(m).read())
index=json.loads((root/'immutable-336-export.json').read_text());assert sha(root/index['checkpoint_file'])==index['checkpoint_sha256']
for row in index['cases']:
    assert sha(root/row['case']/row['report'])==row['report_sha256'] and sha(root/row['case']/row['trace'])==row['trace_sha256']
(root/'prefix-import.json').write_text(json.dumps(dict(archive_sha256=sha(archive),files=len(members),all_recorded_hashes_verified=True),indent=2)+'\n')
print(json.dumps(dict(files=len(members),all_hashes_verified=True)))

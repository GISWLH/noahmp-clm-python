from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();base=root.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in m.items())
target=json.loads((root/'binding-target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=28,failures=0,errors=0,skipped=0)
prefix=base/'suction-i336-prefix';gpu=json.loads((prefix/'gpu-SOURCE_SHA256.json').read_text())
assert all(v==gpu[k] for k,v in m.items() if k.startswith('src/'))
begin=time.monotonic()
command=[sys.executable,'-u',str(root/'benchmarks/compare_hrldas_suction_prefix.py'),'--model-root',str(prefix),
    '--configuration-root',str(base/'fluxnet-first-climate-cycle-20261017-h/inputs'),'--reference-root',str(base/'hrldas-three-climate-b'),
    '--reference-archive',str(base/'hrldas-three-climate-b-evidence.tar.gz'),'--output',str(root/'suction-week-comparison.json')]
with (root/'suction-week-comparison.log').open('w') as log:code=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
assert all(sha(root/k)==v for k,v in m.items())
(root/'suction-week-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begin,node=os.uname().nodename,pbs_job=os.environ.get('PBS_JOBID'),source_files=len(m),source_unchanged=True,runtime_identical_current_i=True,command=command),indent=2)+'\n')
assert code==0

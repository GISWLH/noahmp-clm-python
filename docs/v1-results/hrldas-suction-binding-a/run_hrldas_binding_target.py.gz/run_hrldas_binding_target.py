from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/k)==v for k,v in m.items())
files=sorted(str(p) for p in Path('tests').glob('test_hrldas*.py'));begin=time.monotonic()
code=subprocess.run([sys.executable,'-m','pytest','-q',*files,'--junitxml=binding-target.xml']).returncode
assert all(sha(root/k)==v for k,v in m.items())
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'binding-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
(root/'binding-target-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begin,counts=counts,source_unchanged=True,source_files=len(m),node=os.uname().nodename,pbs_job=os.environ.get('PBS_JOBID'),files=files),indent=2)+'\n')
assert code==0 and counts['failures']==counts['errors']==counts['skipped']==0

"""Read-only check of actual inputs consumed by the official generator.

This does not rewrite a prepared manifest, loosen a scoring guard, or claim
that an old output was generated from a new configuration file.
"""
from pathlib import Path
import hashlib,json
base=Path('/home/zhangyq/noahmp-v1');reference=base/'hrldas-three-climate-b';new=base/'fluxnet-first-climate-cycle-20261017-h/inputs';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
protocol=reference/'protocol.json';assert sha(protocol)=='a13336a71c3aad8ea612a0e85489959df8b7f568f834f866c6f5c3d8f71d3eff'
rows=[]
def differences(a,b,prefix=''):
    if isinstance(a,dict) and isinstance(b,dict):
        result=[]
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:result.append(dict(path=prefix+k,old=a.get(k),new=b.get(k)))
            else:result.extend(differences(a[k],b[k],prefix+k+'.'))
        return result
    return [] if a==b else [dict(path=prefix.rstrip('.'),old=a,new=b)]
def projection(c):
    # Mirrors the explicitly listed fields in the unchanged official input
    # generator, for an identity audit, not a numerical reference generator.
    return dict(latitude=c['latitude'],longitude=c['longitude'],utc_offset_hours=c['utc_offset_hours'],
        geometry={k:c['most_geometry'][k] for k in ['temperature_height','humidity_height','wind_height']},
        column={k:c['column'][k] for k in ['tsoil','ts','smc','dz','fveg','lai','swe','canw']})
for site in ['CN-Qia','CN-Cha','CN-HaM']:
    p=reference/site/'prepared-manifest.json';prepared=json.loads(p.read_text())
    old_paths=prepared['inputs_sha256'];assert all(sha(k)==v for k,v in old_paths.items())
    old_config=next(Path(k) for k in old_paths if k.endswith('-config.json'));current=new/(site+'-config.json')
    old=json.loads(old_config.read_text());fresh=json.loads(current.read_text())
    weather=next(Path(k) for k in old_paths if k.endswith('.npz'));new_weather=new/(site+'.npz')
    meta=next(Path(k) for k in old_paths if k.endswith('.json') and not k.endswith('-config.json'));new_meta=new/(site+'.json')
    rows.append(dict(site=site,official_prepared_sha256=sha(p),original_configuration_sha256=sha(old_config),new_configuration_sha256=sha(current),
        weather_bytes_identical=sha(weather)==sha(new_weather),weather_sha256=sha(new_weather),
        forcing_metadata_bytes_identical=sha(meta)==sha(new_meta),official_generation_input_projection_identical=projection(old)==projection(fresh),
        projected_inputs=projection(fresh),configuration_differences=differences(old,fresh)))
result=dict(scope='Read-only provenance probe only. Original reference/prepared/config identities are unchanged. An explicit new comparison binding or rerun is still needed before scoring new H/I configs.',
    original_protocol_sha256=sha(protocol),current_generator_sha256=sha(base/'prepare_hrldas_climate_reference.py'),
    recorded_generator_sha256=json.loads(protocol.read_text())['instrument_sha256'],cases=rows)
dest=base/'hrldas-h-input-projection-audit.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

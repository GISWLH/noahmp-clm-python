"""NumPy-first original48 of each predeclared17520 climate-year request."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import gzip,hashlib,io,json,os,pickle,sys,tarfile,time,traceback

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'ballberry-climatology-numpy-jr';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==v for n,v in m.items());a=b/'multisite-climatology-gm-inputs.tar.gz';assert sha(a)=='b33fba4f80f7cde8a7e127d27694dc7c2e370e7cd8a6b2142db211c86dccba0e';assert (b/'multisite-climatology-inputs-gm/pbs-exit.txt').read_text().strip()=='0';inputs=r/'inputs';inputs.mkdir()
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
# Every config/forcing byte stays originalGM. Rebuild all23cold arrays under
# ownIV source and require byteidentity before declaring this new-source input.
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import numpy as np
import run_fluxnet_column as cold_runner
import run_fluxnet_native as cold_native
parent_protocol=json.loads((inputs/'protocol.json').read_text());assert parent_protocol['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
loaded=cold_native.load_batch(inputs/'batch.json');assert len(loaded)==12 and cold_native.native_state_count(loaded)==16
states=[cold_runner.build_state(q['config']) for q in loaded];environment=np.asarray([q['data']['environment'][0] for q in loaded],np.float32)
arrays=cold_native.pack_station_arrays(states,16,dtype=np.float32,co2_ppm=environment[:,0],cosine_zenith=environment[:,1],diffuse_fraction=environment[:,2],leaf_dimension=np.asarray([q['config']['leaf_dimension_m'] for q in loaded],np.float32));zero=np.zeros((12,4));cold={f'a{k}':v for k,v in enumerate(arrays)};cold.update(index=np.array(0),initial=cold_native.totals(arrays),net=zero.copy(),bounds=zero.copy(),maximum=zero.copy(),stepmax=zero.copy(),tracermax=np.zeros((12,5)))
with np.load(inputs/'cold-reference.npz',allow_pickle=False) as z:
    assert set(z.files)==set(cold) and len(z.files)==23
    for k in cold:assert z[k].dtype==cold[k].dtype and z[k].shape==cold[k].shape and z[k].tobytes()==cold[k].tobytes(),k
inventory={p.relative_to(inputs).as_posix():sha(p) for p in inputs.rglob('*') if p.is_file() and p.name!='protocol.json'}
protocol=dict(parent_protocol,source_manifest_sha256=manifest,parent_protocol_historical=parent_protocol,original_GM_archive_sha256=sha(a),all23_cold_fields_rebuilt_from_current_source_byteexact_to_original_GM=True,unchanged_input_files_sha256=inventory,scope='OwnJN581 waterstress correction; sameall12 originalfactorial/config/forcing/deposition/inputmetadata/cold23 bytes asGM. No previoustrajectory seed or flux-basedselection. Newsource identity only, pending48 tendencies/independentaudit/year/spinup/science.')
cold_runner.atomic_json(inputs/'protocol.json',protocol)
new_archive=b/'multisite-climatology-jr-inputs.tar.gz';assert not new_archive.exists()
with tarfile.open(new_archive,'w:gz') as tf:
    for p in sorted(inputs.rglob('*')):
        if p.is_file():tf.add(p,arcname=p.relative_to(inputs).as_posix(),recursive=False)
cold_runner.atomic_json(b/'multisite-climatology-jr-package.json',dict(archive=new_archive.name,archive_sha256=sha(new_archive),source_manifest_sha256=manifest,case_count=12,cold_fields=23,parent_GM_archive_sha256=sha(a),unchanged_input_files_sha256=inventory))
protocol=json.loads((inputs/'protocol.json').read_text());assert protocol['source_manifest_sha256']==manifest and protocol['source_unchanged'] and protocol['case_count']==12 and protocol['native_state_arrays']==16 and protocol['cold_fields']==23
full=json.loads((b/'ballberry-jn-full/receipt.json').read_text());assert full['pytest_returncode']==0 and full['source_unchanged'] and full['source_manifest_sha256']==manifest and full['counts']==dict(tests=1156,failures=0,errors=0,skipped=0);sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
batch=json.loads((inputs/'batch.json').read_text());assert len(batch['cases'])==12;(r/'runs').mkdir();(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());started=time.monotonic()

def run_case(case):
    folder=r/'runs'/case['case'];folder.mkdir();captures=folder/'steps.tar.gz';packets=tarfile.open(captures,'w:gz');counter=0;original=runner.step_clm_enthalpy_column;start=time.monotonic();failure=None
    def capture(state,forcing,**kwargs):
        nonlocal counter
        try:after,d=original(state,forcing,**kwargs)
        except Exception:
            blob=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs),protocol=5),mtime=0);member=tarfile.TarInfo('failed-before-'+str(counter).zfill(5)+'.pkl.gz');member.size=len(blob);packets.addfile(member,io.BytesIO(blob));raise
        blob=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs,after=after,diagnostics=d),protocol=5),mtime=0);member=tarfile.TarInfo('call-'+str(counter).zfill(5)+'.pkl.gz');member.size=len(blob);packets.addfile(member,io.BytesIO(blob));counter+=1;return after,d
    try:
        runner.step_clm_enthalpy_column=capture;report=runner.run(inputs/case['input'],inputs/case['input_manifest'],inputs/case['configuration'],folder/'trajectory',stop_after=48);assert counter==48 and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['source_unchanged']
    except Exception as e:failure=type(e).__name__+': '+str(e);(folder/'traceback.txt').write_text(traceback.format_exc())
    finally:runner.step_clm_enthalpy_column=original;packets.close()
    path=folder/'trajectory/report.json';report=json.loads(path.read_text()) if path.exists() else {};record=dict(case=case['case'],failure=failure,captured_steps=counter,step_packet_archive_sha256=sha(captures),status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),configuration_sha256=sha(inputs/case['configuration']),report_sha256=sha(path) if path.exists() else None,seconds=time.monotonic()-start,scope='ActualcurrentJN581 NumPy originalcold48 of17520; allstate/forcing/diagnostics captured for independentdevice audit. All12 predeclaredsoilIC/BGCmappings remain, originalMHCN/impurity. Running48 is not year/spinup/scienceacceptance.');(folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');return record

records=[]
with ProcessPoolExecutor(max_workers=12) as pool:
    for record in pool.map(run_case,batch['cases']):
        records.append(record);(r/'progress.json').write_text(json.dumps(dict(completed_cases=len(records),requested_cases=12,cases=records),indent=2)+'\n');print(json.dumps(record),flush=True)
passed=all(q['failure'] is None and q['source_unchanged'] and q['captured_steps']==q['steps_completed']==48 and q['steps_requested']==17520 for q in records);result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=passed,cases=records,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),input_archive_sha256=sha(a),seconds=time.monotonic()-started,scope='ActualIV58112 independent NumPy48 prefixes and all576step input/output captures, Official2000nonzeroBC/dust/Ninputs, parentzeroCOLD23unchanged; eachcaseall48trustedpacketslosslesslytarred. No failedprefix resume, no newmath/test/gate changes. Readyfor nativecold48 comparison, not fullclimateyears/coupledspinup/observationalpass.');(r/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'}),flush=True);assert passed and result['source_unchanged']

"""Read one committed NS generation; copy immutable files without model imports."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import io
import json
import re
import tarfile

BASE = Path('/home/lhwang/work/noahmp-v1')
COLD = BASE / 'climatology-cold48-np/cold48'
TRAJECTORY = COLD / 'trajectory'
SOURCE = Path('/tmp/noahmp-climatology-cold48-np/source')
TARGET = Path('/tmp/noahmp-current-nm-months-pg-snapshot.tar.gz')
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda d: (json.dumps(d, indent=2, allow_nan=False) + '\n').encode()


def process(path):
    raw = path.read_bytes()
    worker = json.loads(raw)
    pid = worker['pid']
    stat = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    command = (Path('/proc') / str(pid) / 'cmdline').read_bytes().replace(b'\0', b' ').decode().strip()
    assert stat[0] != 'Z' and 'run_year_ns.py' in command
    return dict(pid=pid, state=stat[0], start_ticks=stat[19], command=command), raw


before, worker_raw = process(COLD / 'year-worker.json')
items = {'original-year-worker.json': worker_raw}
source_raw = (SOURCE / 'SOURCE_SHA256.json').read_bytes()
assert sha(source_raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
sources = json.loads(source_raw)
assert len(sources) == 584 and all(sha((SOURCE/name).read_bytes()) == digest for name, digest in sources.items())
items['SOURCE_SHA256.json'] = source_raw
batch_raw = (TRAJECTORY / 'batch.json').read_bytes()
batch = json.loads(batch_raw)
assert batch['status'] == 'running' and 2832 <= batch['steps_completed'] < batch['steps_requested'] == 17520
assert batch['source_unchanged'] and len(batch['identity']['cases']) == len(batch['case_reports']) == 12
assert batch['identity']['native_state_arrays'] == 23
assert all(sources[name] == digest for name, digest in batch['identity']['source_sha256'].items())
checkpoint_name = batch['checkpoint_file']
assert PurePosixPath(checkpoint_name).name == checkpoint_name
checkpoint = (TRAJECTORY / checkpoint_name).read_bytes()
assert sha(checkpoint) == batch['checkpoint_sha256']
items['trajectory/batch.json'] = batch_raw
items['trajectory/' + checkpoint_name] = checkpoint
for column, identity in enumerate(batch['identity']['cases']):
    name = identity['case']
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name)
    descriptor = batch['case_reports'][name]
    assert PurePosixPath(descriptor['file']).name == descriptor['file']
    folder = TRAJECTORY / name
    report_raw = (folder / descriptor['file']).read_bytes()
    assert sha(report_raw) == descriptor['sha256']
    report = json.loads(report_raw)
    assert report['case'] == name and report['batch_column'] == column
    assert report['status'] == 'running' and report['steps_completed'] == batch['steps_completed']
    assert report['batch_checkpoint_sha256'] == batch['checkpoint_sha256']
    trace_name = report['model_npz']
    assert PurePosixPath(trace_name).name == trace_name
    trace_raw = (folder / trace_name).read_bytes()
    assert sha(trace_raw) == report['model_npz_sha256']
    items['trajectory/' + name + '/' + descriptor['file']] = report_raw
    items['trajectory/' + name + '/' + trace_name] = trace_raw
after, _ = process(COLD / 'year-worker.json')
assert before['pid'] == after['pid'] and before['start_ticks'] == after['start_ticks']
assert all(sha((SOURCE/name).read_bytes()) == digest for name, digest in sources.items())
snapshot = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                original_status='running', steps_completed=batch['steps_completed'], requested_steps=17520,
                actual_live_worker_before=before, actual_live_worker_after=after,
                source_files_verified=584, source_manifest_sha256=sha(source_raw),
                original_batch_sha256=sha(batch_raw), original_checkpoint_sha256=sha(checkpoint),
                original_JR_archive_sha256='deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b',
                annual_parent_exit=None,
                scope='One original committed running NS generation for diagnostic complete-month evaluation. No task mutation, numerical model import, annual closure or spinup claim.')
items['snapshot.json'] = encode(snapshot)
items['snapshot_current_nm_months_pg.py'] = Path('/dev/stdin').read_bytes() if False else b''
items.pop('snapshot_current_nm_months_pg.py')
items['inventory.json'] = encode({name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in items.items()})
assert not TARGET.exists()
with TARGET.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name, raw in sorted(items.items()):
            member = tarfile.TarInfo(name); member.size = len(raw); member.mode = 0o644
            archive.addfile(member, io.BytesIO(raw))
print(json.dumps(dict(path=str(TARGET), sha256=sha(TARGET.read_bytes()), bytes=TARGET.stat().st_size,
                     artifacts=len(items), snapshot=snapshot)))

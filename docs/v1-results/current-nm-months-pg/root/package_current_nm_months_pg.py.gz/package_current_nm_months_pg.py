"""Seal original snapshot, actual EHPC evaluation and all scientific results."""
from pathlib import Path, PurePosixPath
import base64
import gzip
import hashlib
import io
import json
import re
import tarfile
import zipfile

OUT = Path(__file__).resolve().parent
LABEL = 'current-nm-months-pg'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, allow_nan=False)+'\n').encode()


def contents(path):
    result = {}
    with tarfile.open(path) as archive:
        for member in archive:
            if member.isdir():
                continue
            name = member.name.removeprefix('./')
            safe = PurePosixPath(name)
            assert member.isfile() and not safe.is_absolute() and '..' not in safe.parts and name not in result
            result[name] = archive.extractfile(member).read()
    return result


stage_binding = json.loads((OUT/(LABEL+'-stage-binding.json')).read_bytes())
snapshot_binding = json.loads((OUT/(LABEL+'-snapshot-binding.json')).read_bytes())
stage_archive, snapshot_archive = (OUT/(LABEL+suffix) for suffix in ['-stage.tar.gz', '-snapshot.tar.gz'])
assert sha(stage_archive.read_bytes()) == stage_binding['sha256']
assert sha(snapshot_archive.read_bytes()) == snapshot_binding['sha256']
stage, snapshot = contents(stage_archive), contents(snapshot_archive)
for files, index_name, structured in [(stage,'stage-inventory.json',False),(snapshot,'inventory.json',True)]:
    inventory = json.loads(files[index_name])
    assert set(inventory) == set(files)-{index_name}
    for name, item in inventory.items():
        assert sha(files[name]) == (item['sha256'] if structured else item)
        if structured:
            assert len(files[name]) == item['bytes']
with tarfile.open(OUT/'climatology-final-candidate-nm-source.tar.gz') as original:
    assert snapshot['SOURCE_SHA256.json'] == original.extractfile('SOURCE_SHA256.json').read()
source_index = json.loads(snapshot['SOURCE_SHA256.json'])
assert len(source_index) == 584
batch = json.loads(snapshot['trajectory/batch.json'])
assert batch['status'] == 'running' and batch['steps_completed'] == 3120 and batch['steps_requested'] == 17520
with zipfile.ZipFile(io.BytesIO(snapshot['trajectory/'+batch['checkpoint_file']])) as checkpoint:
    assert len(checkpoint.namelist()) == 23
    assert set(checkpoint.namelist()) == {f'a{k}.npy' for k in range(16)} | {
        n+'.npy' for n in ['index','initial','net','bounds','maximum','stepmax','tracermax']}
result = contents(OUT/(LABEL+'-original-result.tar.gz'))
receipt = json.loads(result['receipt.json'])
assert receipt['passed'] and receipt['pbs_job'] == '1617.manager' and receipt['node'] == 'compute002'
assert receipt['cases'] == 12 and receipt['complete_case_months'] == 24 and receipt['independent_integral_checks'] == 4556
assert receipt['original_source_files_unchanged'] == 584 and receipt['physical_tendency_calls'] == 0
assert not receipt['annual_complete'] and not receipt['accepted_spinup'] and result['worker-exit.txt'].strip() == b'0'
qstat = (OUT/(LABEL+'-qstat-final.txt')).read_bytes()
assert qstat.startswith(b'Job Id: 1617.manager\n')
for key, value in [('job_state','F'),('Exit_status','0'),('Stageout_status','0')]:
    assert re.search(r'^\s*'+key+r'\s*=\s*'+value+r'\s*$',qstat.decode(),re.M)
monthly, instantaneous = [], []
for column, row in enumerate(receipt['case_summaries']):
    name = row['case']
    assert row['annual']['status'] == 'unmeasured' and row['snapshot_steps'] == 3120
    assert len(row['complete_months']) == 2 and row['complete_days'] == 65
    descriptor = batch['case_reports'][name]
    report_raw = snapshot['trajectory/'+name+'/'+descriptor['file']]
    assert sha(report_raw) == descriptor['sha256']
    report = json.loads(report_raw)
    assert row['original_report'] == report and report['batch_column'] == column
    assert all(source_index[n] == h for n,h in report['source_sha256'].items())
    trace = snapshot['trajectory/'+name+'/'+report['model_npz']]
    assert sha(trace) == report['model_npz_sha256']
    assert sha(snapshot['trajectory/'+batch['checkpoint_file']]) == report['batch_checkpoint_sha256']
    assert json.loads(result[name+'/summary.json']) == row
    metrics_raw = gzip.decompress(result[name+'/observations.json.gz'])
    assert sha(metrics_raw) == row['evaluation_sha256']
    metrics = json.loads(metrics_raw)
    assert metrics['annual']['status'] == 'unmeasured'
    ledger = row['independent_stored_ledgers']
    assert all(abs(r)<=b for r,b in zip(ledger['maximum_cumulative_residual_m_h_c_n'],ledger['final_bounds_m_h_c_n'],strict=True))
    assert all(abs(r)<=b for r,b in zip(row['independent_final_stock']['residual_m_h_c_n'],ledger['final_bounds_m_h_c_n'],strict=True))
    for month, products in row['complete_months'].items():
        for product, value in products.items():
            assert value['calendar_period_complete']
            monthly.append(dict(case=name,site=row['site'],month=month,product=product,
                                own_qc_counts=value.get('own_qc_counts'),metrics=value['metrics'],
                                reference_kind=value.get('reference_kind')))
    for product,value in row['instantaneous'].items():
        instantaneous.append(dict(case=name,site=row['site'],product=product,metrics=value['metrics']))
quantified = dict(actual_job='1617:F0:Stageout0', seconds=receipt['seconds'], snapshot_steps=3120,
                  complete_days_per_case=65, complete_case_months=24, independent_integral_checks=4556,
                  monthly_all_original_products=monthly, instantaneous_original_own_qc0=instantaneous,
                  physical_tendency_calls=0, annual_complete=False, accepted_spinup=False,
                  scope='Raw original monthly product comparisons include filled intervals; instantaneous comparisons use each original own-QC0 mask. All products, failures and missingness retained.')
items = {'snapshot/'+n:b for n,b in snapshot.items()}
items.update({'evaluation/'+n:b for n,b in result.items()})
items.update({'controls/'+n:b for n,b in stage.items() if not n.startswith('inputs/')})
manager = json.loads((OUT/(LABEL+'-manager-raw.json')).read_bytes())
items.update({'actual-manager/'+n:base64.b64decode(b) for n,b in manager['files'].items()})
items['actual-manager/qstat-final.txt'] = qstat
for name in ['snapshot_current_nm_months_pg.py','snapshot_current_nm_months_pg_attempt_a.py',
             LABEL+'-snapshot-attempt-a.stderr.txt',LABEL+'-snapshot-binding.json',LABEL+'-stage-binding.json',
             LABEL+'-qstat.txt','package_current_nm_months_pg.py']:
    items['root/'+name] = (OUT/name).read_bytes()
items['quantified.json'] = encode(quantified)
items['source-input-reference.json'] = encode(json.loads(stage['BINDINGS.json']))
items['README.md'] = b'Original NS running generation3120, original16 physical arrays plus7 ledger/index arrays, all12 cases and all products retained. EHPC1617 F0/Stageout0 evaluates two complete months and65 complete days only. No physical advance, annual or spinup acceptance. Initial collector assumed a nonexistent identity field and failed before writing; corrected collector derives the actual23 NPZ member names without modifying the original trajectory. Source/input large archives are bound by exact SHA references; original snapshot/result members are flat in this archive.\n'
items['inventory.json'] = encode({n:dict(sha256=sha(b),bytes=len(b)) for n,b in sorted(items.items())})
target = OUT/(LABEL+'-evidence.tar.gz')
assert not target.exists()
with target.open('xb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz:
    with tarfile.open(fileobj=gz,mode='w') as archive:
        for name,raw in sorted(items.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o644
            archive.addfile(member,io.BytesIO(raw))
assert contents(target) == items
package = dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,
               artifacts=len(items),passed=True,actual_job='1617.manager',actual_state='F',actual_exit=0,
               Stageout_status=0,cases=12,complete_case_months=24,independent_integral_checks=4556,
               source_files_unchanged=584,physical_tendency_calls=0,
               scope='Original current NM running NS3120 prefix; actual complete January/February observations and original65-day ownQC0 instantaneous evaluation, with all scientific failures. Not annual, spinup, calibration or release acceptance.')
(OUT/(LABEL+'-package.json')).write_bytes(encode(package))
(OUT/(LABEL+'-quantified.json')).write_bytes(encode(quantified))
print(json.dumps(package))

"""Evaluate original committed NS prefix on EHPC; no physical model advance."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import json
import math
import os
import socket
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-current-nm-months-pg')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(Path(path).read_bytes())


def unpack(path, folder):
    folder.mkdir()
    with tarfile.open(path) as archive:
        seen = set()
        for member in archive:
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts
            assert member.name not in seen
            seen.add(member.name)
            target = folder / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.extractfile(member).read())


def evaluate(out):
    import numpy as np
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    frozen = read(STAGE / 'stage-inventory.json')
    assert all(sha((STAGE/name).read_bytes()) == digest for name, digest in frozen.items())
    inputs = read(STAGE / 'BINDINGS.json')
    work = out.parent
    source, observations, snapshot = (work / key for key in ['source', 'observations', 'snapshot'])
    for name, folder in [('source_archive', source), ('JR_archive', observations), ('snapshot_archive', snapshot)]:
        item = inputs[name]
        path = STAGE / item['path']
        assert sha(path.read_bytes()) == item['sha256']
        unpack(path, folder)
    source_index = read(source / 'SOURCE_SHA256.json')
    assert len(source_index) == 584 and all(sha((source/name).read_bytes()) == digest for name, digest in source_index.items())
    assert (snapshot / 'SOURCE_SHA256.json').read_bytes() == (source / 'SOURCE_SHA256.json').read_bytes()
    snapshot_index = read(snapshot / 'inventory.json')
    assert all(sha((snapshot/name).read_bytes()) == item['sha256'] for name, item in snapshot_index.items())
    original_snapshot = read(snapshot / 'snapshot.json')
    assert original_snapshot['original_status'] == 'running' and original_snapshot['annual_parent_exit'] is None
    sys.path[:0] = [str(source), str(source/'src'), str(source/'benchmarks'), '/home/zhangyq/noahmp-v1/test-deps']
    import run_fluxnet_native as native
    from compare_hrldas_native_year import check_ledgers, check_final_checkpoint
    from evaluate_fluxnet_series import evaluate as original_evaluate, PRODUCTS, CARBON_G_PER_UMOL
    from fluxnet_soil_operator import initial_soil_from_manifest
    cases = native.load_batch(observations / 'batch.json')
    batch, checkpoint_state, saved_cases = native.read_generation(snapshot / 'trajectory')
    count = batch['steps_completed']
    assert count == original_snapshot['steps_completed'] and batch['status'] == 'running' and len(cases) == len(saved_cases) == 12
    assert set(checkpoint_state) == {f'a{k}' for k in range(16)} | {'index', 'initial', 'net', 'bounds', 'maximum', 'stepmax', 'tracermax'}
    assert int(checkpoint_state['index']) == count
    results, checks = [], 0
    for column, (case, (report, trace)) in enumerate(zip(cases, saved_cases, strict=True)):
        name = case['case']
        assert name == report['case'] and report['batch_column'] == column and report['configuration'] == case['config']
        assert report['source_sha256'] == native.source_hashes() and report['source_unchanged']
        for field, input_name in [('forcing_npz_sha256', 'input'), ('forcing_manifest_sha256', 'input_manifest'), ('configuration_sha256', 'configuration')]:
            assert report[field] == sha(case['paths'][input_name].read_bytes())
        observed = {key: value[:count] for key, value in case['data'].items()}
        assert all(np.array_equal(trace[key], observed[key]) for key in ['time_start', 'time_end'])
        ledger = check_ledgers(trace, report)
        checkpoint = snapshot / 'trajectory' / name / report['batch_checkpoint_file']
        stocks = check_final_checkpoint(checkpoint, trace, report)
        operator_path = STAGE / 'operators' / (report['site'] + '-soil-operator.json')
        assert sha(operator_path.read_bytes()) == inputs['operators'][report['site']]
        operator = read(operator_path)
        metrics = original_evaluate(trace, observed, utc_offset_hours=8,
                                    soil_operator=operator, initial_soil=initial_soil_from_manifest(report))
        complete = {period: values for period, values in metrics['monthly'].items()
                    if all(value['calendar_period_complete'] for value in values.values())}
        assert len(complete) == 2 and all(period.endswith(('-01', '-02')) for period in complete)
        partial = {period: values for period, values in metrics['monthly'].items() if period not in complete}
        assert all(not value['calendar_period_complete'] and value['metrics']['status'] == 'unmeasured'
                   for values in partial.values() for value in values.values())
        independent_checks = 0
        labels = np.asarray(trace['time_start'], str)
        for frequency, width in [('daily', 8), ('monthly', 6)]:
            for period, records in metrics[frequency].items():
                selected = np.flatnonzero(np.asarray([label[:width] == period.replace('-', '') for label in labels]))
                for product, (key, _, carbon) in PRODUCTS.items():
                    row = records[product]
                    if 'model_integral' not in row:
                        continue
                    model = math.fsum(map(float, np.asarray(trace[key], float)[selected])) * (1. if carbon else 1800.)
                    reference = math.fsum(map(float, np.asarray(observed['obs_'+product], float)[selected])) * 1800. * (CARBON_G_PER_UMOL if carbon else 1.)
                    assert math.isclose(model, row['model_integral'], rel_tol=1e-12, abs_tol=1e-9)
                    assert math.isclose(reference, row['reference_integral'], rel_tol=1e-12, abs_tol=1e-9)
                    independent_checks += 1
        metrics['annual'] = dict(status='unmeasured', bias_pass=None, correlation_pass=None,
                                 reason='Original year running at immutable saved prefix; full year unavailable')
        folder = out / name
        folder.mkdir()
        raw = (json.dumps(metrics, indent=2, allow_nan=False) + '\n').encode()
        (folder/'observations.json.gz').write_bytes(gzip.compress(raw, mtime=0))
        summary = dict(case=name, site=report['site'], source_manifest_sha256=sha((source/'SOURCE_SHA256.json').read_bytes()),
                       snapshot_steps=count, requested_steps=17520, original_status='running', annual_parent_exit=None,
                       complete_days=len(metrics['daily']), complete_months=complete, partial_months=partial,
                       instantaneous=metrics['instantaneous'], annual=metrics['annual'],
                       original_report=report, independent_stored_ledgers=ledger, independent_final_stock=stocks,
                       independent_integral_checks=independent_checks, evaluation_sha256=sha(raw))
        (folder/'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False)+'\n')
        results.append(summary)
        checks += independent_checks
        print(json.dumps(dict(case=name, complete_months=list(complete), intervals=count,
                              independent_integral_checks=independent_checks)), flush=True)
    assert all(sha((source/name).read_bytes()) == digest for name, digest in source_index.items())
    assert all(sha((STAGE/name).read_bytes()) == digest for name, digest in frozen.items())
    return dict(passed=True, cases=12, snapshot_steps=count, complete_case_months=24,
                original_source_files_unchanged=584, independent_integral_checks=checks,
                case_summaries=results, original_snapshot=original_snapshot,
                physical_tendency_calls=0, annual_complete=False, accepted_spinup=False,
                scope='All 12 original NM NS configurations and original products/QC/soil operators on two complete months; running prefix diagnostic only. No scoring calibration or annual acceptance.')


def main():
    started = time.monotonic()
    out = Path(sys.argv[1]).resolve()
    assert out.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not out.exists()
    out.mkdir()
    result = dict(passed=False)
    try:
        result = evaluate(out)
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        (out/'traceback.txt').write_text(traceback.format_exc())
    result.update(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), seconds=time.monotonic()-started)
    (out/'receipt.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ['case_summaries', 'original_snapshot']}), flush=True)
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()

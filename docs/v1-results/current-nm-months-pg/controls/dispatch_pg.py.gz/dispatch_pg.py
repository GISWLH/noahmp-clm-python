"""Stage the immutable read-only evaluation once on manager and compute002."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import shlex
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-current-nm-months-pg')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--extract-only', action='store_true')
    args = parser.parse_args()
    assert socket.gethostname() == ('compute002' if args.extract_only else 'manager')
    assert sha(args.archive.read_bytes()) == args.sha256 and not ROOT.exists()
    with tarfile.open(args.archive) as archive:
        files = {}
        for member in archive:
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts and member.name not in files
            files[member.name] = archive.extractfile(member).read()
    index = json.loads(files['stage-inventory.json'])
    assert set(index) == set(files) - {'stage-inventory.json'} and all(sha(files[n]) == h for n, h in index.items())
    assert sha(Path(__file__).read_bytes()) == index['dispatch_pg.py']
    ROOT.mkdir()
    for name, raw in files.items():
        path = ROOT/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    if args.extract_only:
        print(json.dumps(dict(extracted=True, members=len(files), stage_sha256=args.sha256)))
        return
    remote_archive = '/tmp/noahmp-current-nm-months-pg-stage.tar.gz'
    remote_dispatcher = '/tmp/dispatch_current_nm_months_pg.py'
    for local, remote in [(args.archive, remote_archive), (Path(__file__), remote_dispatcher)]:
        subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', remote])], check=True)
        subprocess.run(['scp', str(local), 'compute002:'+remote], check=True)
    extraction = subprocess.run(['ssh', 'compute002', shlex.join([PYTHON, '-B', remote_dispatcher,
                                  '--archive', remote_archive, '--sha256', args.sha256, '--extract-only'])],
                                 capture_output=True, text=True)
    (ROOT/'compute-extract.stdout.txt').write_text(extraction.stdout)
    (ROOT/'compute-extract.stderr.txt').write_text(extraction.stderr)
    assert extraction.returncode == 0, extraction.stderr
    qsub = subprocess.run(['qsub', '-o', str(ROOT/'pbs-output.log'), str(ROOT/'job.pbs')], capture_output=True, text=True)
    (ROOT/'qsub.stdout.txt').write_text(qsub.stdout)
    (ROOT/'qsub.stderr.txt').write_text(qsub.stderr)
    (ROOT/'qsub-exit.json').write_text(json.dumps(dict(actual_parent_returncode=qsub.returncode))+'\n')
    assert qsub.returncode == 0, qsub.stderr
    record = dict(pbs_job=qsub.stdout.strip(), stage_sha256=args.sha256, stage_members=len(files),
                  source_sha256=index, physical_tendency_calls=0,
                  scope='Read original NS running generation and two complete months only; no model advance.')
    assert record['pbs_job'].endswith('.manager') and record['pbs_job'].split('.')[0].isdigit()
    (ROOT/'dispatch.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

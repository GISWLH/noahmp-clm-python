"""First full local day, actual CUDA vs NumPy with identical source/config."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
from noahmp_clm.validation import compare_series

def compare(root,native_name='cuda-day',numpy_name='numpy-day',*,allow_gpu_feedback_difference=False,allow_numpy_secant_difference=False):
    root=Path(root);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];failures=[]
    for row in json.loads((root/'batch.json').read_text())['cases']:
        case=row['case'];nr=root/native_name/case;pr=root/numpy_name/case
        a=json.loads((nr/'report.json').read_text());b=json.loads((pr/'report.json').read_text())
        assert a['steps_completed']==b['steps_completed']==48
        assert a['status'] in ('running','complete') and b['status'] in ('running','complete')
        for key in ('configuration_sha256','forcing_npz_sha256','forcing_manifest_sha256'):
            assert a[key]==b[key],(case,key)
        common={k:v for k,v in b['source_sha256'].items() if k.startswith('src/') or k.endswith('fluxnet_deposition.py')}
        source_differences={k:dict(native=a['source_sha256'][k],numpy=v) for k,v in common.items() if a['source_sha256'][k]!=v}
        expected=set()
        if allow_gpu_feedback_difference:expected.add('src/noahmp_clm/gpu/canopy_most_surface.py')
        if allow_numpy_secant_difference:expected.add('src/noahmp_clm/physics/canopy_column.py')
        assert set(source_differences)==expected,source_differences
        ap=nr/a['model_npz'];bp=pr/b['model_npz'];assert sha(ap)==a['model_npz_sha256'] and sha(bp)==b['model_npz_sha256']
        with np.load(ap,allow_pickle=False) as z:x=dict(z)
        with np.load(bp,allow_pickle=False) as z:y=dict(z)
        for k in ('time_start','time_end'):np.testing.assert_array_equal(x[k],y[k])
        assert str(x['time_start'][0]).endswith('0000') and str(x['time_end'][-1]).endswith('0000')
        metrics={}
        for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),
            ('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),
            ('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),
            ('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
            aa=x[key].astype(float)*factor+offset;bb=y[key].astype(float)*factor+offset
            values=[compare_series(aa[:,j],bb[:,j],var) for j in range(aa.shape[1])] if aa.ndim==2 else [compare_series(aa,bb,var)]
            for j,v in enumerate(values):
                if not v['bias_pass']:failures.append((case,key,j,'daily bias',v['bias']))
                if key in ('h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2') and v['correlation_pass'] is False:
                    failures.append((case,key,j,'instant correlation',v['r']))
            metrics[key]=values
        rows.append(dict(case=case,configuration_sha256=a['configuration_sha256'],forcing_npz_sha256=a['forcing_npz_sha256'],
            native_report_sha256=sha(nr/'report.json'),numpy_report_sha256=sha(pr/'report.json'),
            native_trace_sha256=sha(ap),numpy_trace_sha256=sha(bp),native_trace=str(ap),numpy_trace=str(bp),
            same_source_python_files=len(common)-len(source_differences),source_differences=source_differences,metrics=metrics,
            maximum_cumulative_m_h_c_n={k:r['maximum_cumulative_residual_m_h_c_n'] for k,r in [('cuda32',a),('numpy64',b)]},
            native_maximum_step_impurity_residual_kgm2=a['maximum_step_impurity_residual_kgm2']))
    scope=('Four-site first complete local day CUDA32 vs independent NumPy64, exact input/config identity. '
        +('Independent NumPy reference predates the scalar secant endpoint guard; that one NumPy physical source difference is explicitly recorded. ' if allow_numpy_secant_difference else 'All NumPy physical sources identical. ')
        +'Explicitly recorded GPU-only feedback source difference if enabled. Not observed flux scores, annual completion or spinup convergence')
    result=dict(scope=scope,
        instrument_sha256=sha(Path(__file__)),cases=rows,failures=failures,
        constant_series_correlation='undefined, separately reported as null; daily absolute/relative criteria still applied')
    (root/'backend-day-comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    for row in rows:print(row['case'],{k:dict(bias=v[0]['bias'],relative_bias=v[0]['relative_bias'],r=v[0]['r'],max_absolute=v[0]['max_absolute_difference']) for k,v in row['metrics'].items() if k in ('h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2','et_mm')},flush=True)
    if failures:raise RuntimeError(f'Daily backend validation failures: {failures}')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('--native',default='cuda-day');p.add_argument('--numpy',default='numpy-day');p.add_argument('--allow-gpu-feedback-difference',action='store_true');p.add_argument('--allow-numpy-secant-difference',action='store_true');a=p.parse_args();compare(a.root,a.native,a.numpy,allow_gpu_feedback_difference=a.allow_gpu_feedback_difference,allow_numpy_secant_difference=a.allow_numpy_secant_difference)

"""New-source single-step proof from retained old trajectory, not a resume."""
from pathlib import Path
import hashlib,json,time,traceback
import numpy as np
from run_fluxnet_native import Backend,source_hashes,audit_step
from noahmp_clm.gpu.clm_bgc_column import next_bgc_arrays
from noahmp_clm.physics.photosynthesis import LeafParameters
root=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-c')
dest=Path.cwd()/'cycle-262-whole-replay';dest.mkdir(exist_ok=False)
prior=json.loads((root/'cuda-year/batch.json').read_text())['identity']['source_sha256'];current=source_hashes()
differences={k:dict(old=v,new=current[k]) for k,v in prior.items() if current[k]!=v}
assert set(differences)=={'src/noahmp_clm/physics/canopy_column.py','src/noahmp_clm/gpu/canopy_surface.py','src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu'}
p=root/'failure-262-replay-a/whole-column-inputs.npz'
with np.load(p,allow_pickle=False) as z:x=dict(z)
before=tuple(x[f'a{k}'] for k in range(16));engine=Backend('cuda32');started=time.monotonic()
report=dict(scope='Four-column saved index262 under corrected numerical source. Same old state and forcing; not annual resume or observational acceptance.',
    input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_sha256=current,source_differences=differences)
def flatten(d,prefix=''):
    result={}
    for k,v in d.items():
        if isinstance(v,dict):result.update(flatten(v,prefix+k+'/'))
        else:result[prefix+k]=np.asarray(v)
    return result
try:
    device=tuple(engine.xp.asarray(v) for v in before)
    forced=engine.update_forcing(device,x['forcing_environment'])
    out_device=engine.step(*forced,x['forcing'],environment=x['environment'],calendar=x['calendar'],
        nitrogen_deposition_gn_m2=x['nitrogen'],deposition=x['deposition'],most_geometry=x['geometry'],
        leaf_parameters=LeafParameters(),return_surface=True)
    out=engine.host(out_device);after=tuple(engine.host(v) for v in next_bgc_arrays(forced,out_device))
    incoming,residual,bound,tracer=audit_step(before,after,x['forcing'],x['deposition'],x['nitrogen'],out)
    np.savez_compressed(dest/'outputs.npz',**flatten(out))
    np.savez_compressed(dest/'next-state.npz',**{f'a{k}':v for k,v in enumerate(after)})
    report.update(status='complete',residual=residual,bound=bound,tracer_residual=tracer,
        most_iterations=out['surface']['most']['iterations'],h=out['diagnostics']['h'],le=out['diagnostics']['le'])
except Exception:report.update(status='failed',failure=traceback.format_exc())
report['seconds']=time.monotonic()-started
def encode(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)
(dest/'summary.json').write_text(json.dumps(report,indent=2,default=encode,allow_nan=False)+'\n')
print(json.dumps(report,default=encode),flush=True)

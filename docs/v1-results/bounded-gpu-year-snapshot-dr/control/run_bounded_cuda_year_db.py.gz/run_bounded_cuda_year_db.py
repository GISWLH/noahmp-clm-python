from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
import resource
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');s=Path('/tmp/noahmp-bounded-cn-co/source');r=b/('qia-bounded-'+label+'-cuda-year-cy');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==568 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as numpy_runner
import noahmp_clm.clm_enthalpy_driver as numpy_driver
import noahmp_clm.physics.richards as numpy_flow
import cupy as cp
verification=json.loads((r/'prefix-verification.json').read_text());assert verification['passed'] and verification['source_unchanged'] and verification['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and verification['cold_fields_exact']==30 and verification['physical_step_pairs']==48 and verification['all23state_chains_and_final_checkpoint_exact'] and len(verification['all23physical_trace_metrics'])==24
assert sha(r/'trajectory/batch.json')==verification['prefix_batch_report_sha256'];report,saved,rows=native.read_generation(r/'trajectory');assert report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['checkpoint_sha256']==verification['prefix_checkpoint_sha256'] and report['same_precision_max_absolute'] is None and len(saved)==30
(r/'validated-prefix-state.npz').write_bytes((r/'trajectory'/report['checkpoint_file']).read_bytes());(r/'validated-prefix-report.json').write_bytes((r/'trajectory/batch.json').read_bytes())
start=time.monotonic();failure=None;checked_start=False;captured_first=False;original_step=native.Backend.step;original_audit=native.audit_step;original_forbidden=[numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy]
def forbidden(*a,**kw):raise AssertionError('Native climate year cannot use NumPy forward physics')
def check_start(self,*a,**kw):
    global checked_start
    if not checked_start:
        current=json.loads((r/'trajectory/batch.json').read_text());assert current['steps_completed']==48 and current['status']=='running'
        with np.load(r/'trajectory'/current['checkpoint_file'],allow_pickle=False) as z,np.load(r/'validated-prefix-state.npz',allow_pickle=False) as prior:
            assert set(z.files)==set(prior.files) and len(z.files)==30
            for key in z.files:assert z[key].dtype==prior[key].dtype and z[key].shape==prior[key].shape and z[key].tobytes()==prior[key].tobytes(),key
        native.atomic_json(r/'year-start-audit.json',dict(scope='Immediately before first continued tendency, all23primary+7ledger fields exact to own independently verified successful48. Same source/config/forcing/identity/request17520, no failedprefix or reset.',saved_fields_exact=30,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),verified_prefix_checkpoint_sha256=verification['prefix_checkpoint_sha256'],current_checkpoint_sha256=sha(r/'trajectory'/current['checkpoint_file']),cpu_verification_sha256=sha(r/'prefix-verification.json')));checked_start=True
    return original_step(self,*a,**kw)
def first_step(before,after,f,dep,nitrogen,out):
    global captured_first
    result=original_audit(before,after,f,dep,nitrogen,out)
    if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>4*1024*1024:raise RuntimeError('CUDA-onlyyear exceeded4GiB measuredhostpeak')
    if not captured_first:
        values=dict(forcing=np.asarray(f),deposition=np.asarray(dep),nitrogen=np.asarray(nitrogen))
        for prefix,arrays in [('before',before),('after',after)]:values.update({prefix+str(k):np.asarray(v) for k,v in enumerate(arrays)})
        def flat(d,prefix='output/'):
            for k,v in d.items():
                if isinstance(v,dict):flat(v,prefix+k+'/')
                else:values[prefix+k]=np.asarray(v)
        flat(out)
        for name,value in zip(['incoming','residual','bound','impurity'],result):values['recorded/'+name]=np.asarray(value)
        np.savez_compressed(r/'first-continued-step.npz',**values);captured_first=True
    return result
try:
    native.Backend.step=check_start;native.audit_step=first_step;numpy_runner.step_clm_enthalpy_column=forbidden;numpy_driver.step_clm_enthalpy_column=forbidden;numpy_flow.redistribute_soil_enthalpy=forbidden
    native.run(r/'inputs'/label/'batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,resume=True)
    report,saved,rows=native.read_generation(r/'trajectory');assert checked_start and captured_first and report['status']=='complete' and report['steps_completed']==report['steps_requested']==17520 and report['source_unchanged'] and report['same_precision_max_absolute'] is None
except Exception as error:
    failure=type(error).__name__+': '+str(error);(r/'year-traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    native.Backend.step=original_step;native.audit_step=original_audit;numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy=original_forbidden
cp.cuda.runtime.deviceSynchronize();p=r/'trajectory/batch.json';report=json.loads(p.read_text()) if p.exists() else {};unchanged=all(sha(s/n)==h for n,h in m.items())
d=dict(scope='CurrentCN full17520 CUDA-onlyyear from ownactualsuccessful48 after independentEHPC400 currentNumPy48/source/cold30/all23chains/MHCN/impurity/24trace audit. Originalforcing/config/source/ledgers retained, firstcontinuedcheckpoint exact30. No oldfailedprefix, NumPyforward/JAXshadow or fullcanonical/spinup/observedscienceclaim. Workload-specific16GiBhost initialguard/continuous4GiBmeasuredpeak; wholeJAX32GiBguards untouched. ExplicitCuPybarrier/durable receipt beforeatexit bypass.',case=label,failure=failure,maximum_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),continued_fields_exact=30 if checked_start else None,first_continued_step_captured=captured_first,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),same_precision_max_absolute=report.get('same_precision_max_absolute'),device_barrier_complete=True,seconds=time.monotonic()-start,report_sha256=sha(p) if p.exists() else None)
native.atomic_json(r/'year-receipt.json',d);print(json.dumps(d),flush=True);os._exit(0 if failure is None and unchanged else 1)

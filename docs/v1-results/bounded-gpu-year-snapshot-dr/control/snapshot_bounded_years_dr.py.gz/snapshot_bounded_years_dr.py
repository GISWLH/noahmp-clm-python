from pathlib import Path
import datetime,hashlib,io,json,subprocess,sys,tarfile
mode=sys.argv[1];assert mode in ['cpu','gpu'];b=Path('/home/zhangyq/noahmp-v1') if mode=='cpu' else Path('/home/lhwang/work/noahmp-v1');sha=lambda raw:hashlib.sha256(raw).hexdigest();data={};record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode=mode,years={})
def add(p,n,expected=None):
    raw=p.read_bytes()
    if expected:assert sha(raw)==expected
    data[n]=raw;return raw
for label in ['capacity','capacity_optics']:
    name='qia-bounded-'+label+('-numpy-year-dc' if mode=='cpu' else '-cuda-year-cy');r=b/name;p=r/'trajectory'/('report.json' if mode=='cpu' else 'batch.json');d=json.loads(add(p,name+'/trajectory/'+p.name));assert d['steps_requested']==17520 and d['source_unchanged'];row={k:d[k] for k in ['status','steps_completed','steps_requested','seconds','maximum_cumulative_residual_m_h_c_n','cumulative_numerical_bounds_m_h_c_n']};add(r/'trajectory'/d['checkpoint_file'],name+'/trajectory/'+d['checkpoint_file'],d['checkpoint_sha256'])
    if mode=='cpu':add(r/'trajectory'/d['model_npz'],name+'/trajectory/'+d['model_npz'],d['model_npz_sha256'])
    else:
        for case,q in d['case_reports'].items():
            p=r/'trajectory'/case/q['file'];report=json.loads(add(p,name+'/trajectory/'+case+'/'+p.name,q['sha256']));add(r/'trajectory'/case/report['model_npz'],name+'/trajectory/'+case+'/'+report['model_npz'],report['model_npz_sha256'])
        worker=json.loads(add(r/'year-worker.json',name+'/year-worker.json'));pid=worker['pid'];p=Path('/proc')/str(pid);row['worker_pid']=pid;row['worker_proc_exists']=p.exists()
        if p.exists():
            cmd=(p/'cmdline').read_bytes();row['worker_cmdline_matches']='run_bounded_cuda_year_db.py'.encode() in cmd;row['worker_cmdline_sha256']=sha(cmd);add(p/'status',name+'/current-proc-status.txt')
    for n in ['SOURCE_SHA256.json','year-launch.json','lineage.json','dispatch.json','prefix-launch.json','prefix-verification.json','year-start-audit.json','first-continued-step.npz','validated-prefix-state.npz','validated-prefix-report.json','run_bounded_numpy_year_dc.py','bounded_numpy_year_dc.pbs','year-exit.json','year-receipt.json','segment48-receipt.json','segment48-pbs-exit.txt']:
        if (r/n).is_file():add(r/n,name+'/'+n)
    record['years'][name]=row
if mode=='cpu':
    p=subprocess.run(['qstat','-a'],capture_output=True,text=True);record['actual_qstat']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);root=b/'height-matrix-bx';queue=json.loads(add(root/'height-runs/queue.json','height-matrix-bx/queue.json'));record['height_cases_by_status']={status:sum(v['status']==status for v in queue['cases'].values()) for status in sorted({v['status'] for v in queue['cases'].values()})}
    for n in ['dispatch.json','SOURCE_SHA256.json','package.json','receipt.json','pbs-exit.txt']:
        if (root/n).is_file():add(root/n,'height-matrix-bx/'+n)
else:
    p=subprocess.run(['ps','-o','pid,ppid,stat,etime,time,wchan:25,args','-p','524313,524314,525043,525044,375966,364028,3802990,4095585,543757'],capture_output=True,text=True);record['actual_ps']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    p=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,memory.used,memory.total,utilization.gpu','--format=csv'],capture_output=True,text=True);record['actual_gpu']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    for stem in ['bounded-coupled-cu','bounded-coupled-de']:
        root=b/stem
        for p in sorted(root.iterdir()):
            if p.is_file():add(p,'queues/'+stem+'/'+p.name)
    for n in ['run_bounded_cuda_year_db.py','control_bounded_cuda_year_db.py','launch_bounded_cuda_year_db.py','replace_idle_cu_queue_de.py']:add(b/n,'control/'+n)
record['scope']='Read-only hash-bound currentCN ownvalidated48 annualcontinuation snapshots. CUDAphysical1 and NumPyPBS; original17520request/ledgers retained, CPU boundedto2880. Source/currentgeneration and process/qstat metadata only; not fullannual/1517/spinup/sciencepass. DE resource-controlcandidate replacesonly idlechildlessCU, no modelworker stopped; original32GiB/8GiB/test/numericalgates unchanged. No physics or numericalevaluation onlogin/local.';data['record.json']=(json.dumps(record,indent=2)+'\n').encode();data['control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/('bounded-'+mode+'-year-snapshot-dr-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for n,raw in data.items():q=tarfile.TarInfo(n);q.size=len(raw);tf.addfile(q,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(data),utc=record['utc'],years=record['years'],height_cases=record.get('height_cases_by_status'))),flush=True)

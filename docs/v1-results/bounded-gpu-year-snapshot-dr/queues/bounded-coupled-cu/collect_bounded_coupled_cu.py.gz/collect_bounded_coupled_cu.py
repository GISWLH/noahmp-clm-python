from pathlib import Path
import hashlib,json,os,sys
import pytest
r=Path('/home/lhwang/work/noahmp-v1/bounded-coupled-cu');s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==h for n,h in m.items());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(v.nodeid for v in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];barriers=[]
for name in ['jax','cupy']:
    if name in sys.modules:
        if name=='jax':sys.modules[name].effects_barrier()
        else:sys.modules[name].cuda.runtime.deviceSynchronize()
        barriers.append(name)
good=code==0 and len(nodes)==len(set(nodes))==1517 and len(gpu)==398 and all(sha(s/n)==h for n,h in m.items());d=dict(passed=good,returncode=code,nodes=nodes,total_count=len(nodes),gpu_count=len(gpu),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),device_barriers=barriers,scope='CurrentCN canonical1517 collection only, no fullsuiteexecution.');(r/'collection.json').write_text(json.dumps(d,indent=2)+'\n');sys.stdout.flush();sys.stderr.flush();os._exit(0 if good else 71)

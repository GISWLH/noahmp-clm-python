from pathlib import Path
import hashlib,json,runpy
b=Path('/home/lhwang/work/noahmp-v1');r=b/'bounded-coupled-cu';s=Path(json.loads((r/'source-location.json').read_text())['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def blocked(*args,**kwargs):raise AssertionError('CoupledGPU validation must use EHPC offline references, no NumPy forward physics')
import noahmp_clm.clm_enthalpy_driver as column
import noahmp_clm.physics.richards as flow
import noahmp_clm.physics.canopy_phase_energy as phase
import run_fluxnet_column as runner
column.step_clm_enthalpy_column=blocked;flow.redistribute_soil_enthalpy=blocked;phase.solve_canopy_phase_energy=blocked;runner.step_clm_enthalpy_column=blocked
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';assert sha(s/'SOURCE_SHA256.json')=='c0cabf3002a8f8ed7960559d0352bc6529f46a20ce8d75aca406b20ff1efd166';runpy.run_path(str(worker),run_name='__main__')

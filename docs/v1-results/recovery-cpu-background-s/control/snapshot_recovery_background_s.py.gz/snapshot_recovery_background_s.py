from pathlib import Path
import datetime,hashlib,io,json,subprocess,sys,tarfile
mode=sys.argv[1];assert mode in ['cpu','gpu'];b=Path('/home/zhangyq/noahmp-v1') if mode=='cpu' else Path('/home/lhwang/work/noahmp-v1');data={};sha=lambda raw:hashlib.sha256(raw).hexdigest()
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only live/currentterminal metadata and hash-bound successful NumPy year generations. No local/login numerical physics; snapshots are not annual/canonical/integration/science pass. Source563B phase/point and563C waterheat kept distinct, all old failures/workers preserved.',roots={})
folders=(['qia-richards-capacity-numpy-year-a','qia-richards-capacity_optics-numpy-year-a','qia-kink-numpy-year-h','phase-coordinate-cpu-b','numerical-recovery-cpu-c','qia3803-paired-audit-b'] if mode=='cpu' else ['phase-coordinate-native-b/target-a','qia3803-full-cuda32-b','qia3803-full-jax32-b','clm-numerical-recovery-c/target-a','clm-numerical-recovery-c/integration-c','richards-column-native-a/target-a','richards-station-native-a/target-a','clm-capacity-final-f/full-bgc-f','capacity-station-final-c/target-c'])
files=['launch.json','worker.json','dispatch.json','waiting.json','waiting-events.jsonl','control.py','target-receipt.json','full-receipt.json','receipt.json','exit.json','deferred.json','pbs-exit.txt','SOURCE_SHA256.json','trajectory/report.json']
for folder in folders:
    r=b/folder;row={}
    for filename in files:
        p=r/filename
        if not p.exists():continue
        raw=p.read_bytes();data[folder+'/'+filename]=raw
        if filename.endswith('.json') and filename!='SOURCE_SHA256.json':
            v=json.loads(raw);row[filename]={k:x for k,x in v.items() if k in ['pid','pbs_job','returncode','passed','counts','status','steps_completed','steps_requested','source_unchanged','source_manifest_sha256','seconds','maximum_cumulative_residual_m_h_c_n','cumulative_numerical_bounds_m_h_c_n','state']}
        elif filename.endswith('.txt'):row[filename]=raw.decode().strip()
    if mode=='cpu' and (r/'trajectory/report.json').exists():
        report=json.loads(data[folder+'/trajectory/report.json']);root=(r/'trajectory').resolve()
        for field,key in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
            p=(root/report[field]).resolve();assert p.is_relative_to(root);raw=p.read_bytes();assert sha(raw)==report[key];data[folder+'/trajectory/'+p.name]=raw
    d['roots'][folder]=row
if mode=='cpu':
    p=subprocess.run(['qstat','-u','zhangyq'],capture_output=True,text=True);d['qstat']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
else:
    p=subprocess.run(['ps','-p','3802989,3802990,3850155,3864455,3547743,3622193,3662728,4095434,4095585,4122841,108025','-o','pid,stat,etime,pcpu,rss,args'],capture_output=True,text=True);d['actual_ps']=dict(returncode=p.returncode,stdout=p.stdout)
    d['devices']=subprocess.run(['nvidia-smi','--query-gpu=index,memory.used,memory.free','--format=csv,noheader'],capture_output=True,text=True).stdout
    for n in ['control_numerical_integration_c.py','queue_numerical_integration_c.py']:
        raw=(b/n).read_bytes();data['control/'+n]=raw
    for folder in ['p6-all-phase-final-b/full-by-file-a','pft-optics-final-d/full-by-file-d','qia1110-final-h/full-by-file-h','clm-capacity-final-f/full-by-file-f']:
        for n in ['progress.json','summary.json','selection.json']:
            p=b/folder/n
            if p.exists():data[folder+'/'+n]=p.read_bytes()
data['snapshot.json']=(json.dumps(d,indent=2)+'\n').encode();data['control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/('recovery-'+mode+'-background-s-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for name,raw in data.items():info=tarfile.TarInfo(name);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,snapshot=d)))

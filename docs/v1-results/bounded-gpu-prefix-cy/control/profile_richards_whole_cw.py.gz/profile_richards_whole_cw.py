"""Read-only live process snapshots; no locals, ptrace stop, reset or model edit."""
from pathlib import Path
import datetime,hashlib,json,subprocess,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'richards-whole-profile-cw';assert not r.exists();r.mkdir();tool=b/'profile-tools-u/bin/py-spy';assert tool.is_file();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for pid in [375966]:
    before=subprocess.run(['ps','-o','pid,ppid,stat,etime,time,wchan:30,args','-p',str(pid)],capture_output=True,text=True)
    assert before.returncode==0,'Only profile confirmed-live original handles'
    command=[str(tool),'dump','--pid',str(pid),'--json','--nonblocking'];start=time.monotonic()
    with (r/(str(pid)+'.json')).open('x') as out,(r/(str(pid)+'.stderr')).open('x') as err:
        try:code=subprocess.run(command,stdout=out,stderr=err,timeout=25).returncode
        except subprocess.TimeoutExpired:code='observer-timeout-only'
    after=subprocess.run(['ps','-o','pid,ppid,stat,etime,time,wchan:30,args','-p',str(pid)],capture_output=True,text=True)
    row=dict(pid=pid,command=command,before_ps=before.stdout,observer_returncode=code,seconds=time.monotonic()-start,after_ps=after.stdout,after_ps_returncode=after.returncode);rows.append(row);(r/(str(pid)+'-observer.json')).write_text(json.dumps(row,indent=2)+'\n')
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),py_spy_sha256=sha(tool),observations=rows,scope='Read-only nonblocking Python stack/no locals and OSmetadata. Confirmedlive handles beforeobservation; timeout is not modelterminal and no restart/kill. Folio page-lock waits observed, exact waitedfile/cause stillunproven. Originalmodels/sharedcache untouched. Newlycreated profilecontrol and outputfiles only.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

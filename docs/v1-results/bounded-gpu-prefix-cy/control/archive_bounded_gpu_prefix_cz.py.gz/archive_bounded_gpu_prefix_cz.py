from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[];records=[]
for label in ['capacity','capacity_optics']:
    r=b/('qia-bounded-'+label+'-cuda-year-cy');d=json.loads((r/'prefix-receipt.json').read_text());e=json.loads((r/'prefix-exit.json').read_text());assert e['returncode']==0 and e['passed'] and e['receipt_sha256']==sha(r/'prefix-receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['cold_fields_exact']==30 and d['captured_step_calls']==48 and d['steps_completed']==48 and d['steps_requested']==17520 and d['status']=='running' and sha(r/'trajectory/batch.json')==d['report_sha256'] and len(list((r/'prefix-steps').glob('call-*.npz')))==48 and d['maximum_host_rss_kib']<=4*1024*1024
    stamps=[p.stat().st_mtime for p in sorted((r/'prefix-steps').glob('call-*.npz'))];records.append(dict(case=label,actual_parent_returncode=0,maximum_host_rss_kib=d['maximum_host_rss_kib'],prefix_seconds=d['seconds'],last24_wall_seconds_per_step=(stamps[-1]-stamps[23])/24.,scope='Timing metadata only, not fullannual ETA or physicscomparison.'))
    for p in sorted(r.rglob('*')):
        if p.is_file():items.append((p,label+'/'+p.relative_to(r).as_posix()))
profile=b/'richards-whole-profile-cw'
for p in sorted(profile.rglob('*')):
    if p.is_file():items.append((p,'profile-cw/'+p.relative_to(profile).as_posix()))
record=b/'bounded-gpu-prefix-cy-record.json';assert not record.exists();record.write_text(json.dumps(dict(records=records,scope='CurrentCN actualtwoCUDA-only48 prefixes, source/cold/fullstep captures and peakmemory. BypasslargeJAXheapwait with16GiBhost/4GiBmeasuredpeak pilot; original32GiBwholeJAXguards/source/tests untouched. IndependentEHPCaudit requiredbeforeownprefixyearcontinuation. Not completedyear/sameprecision/fullcanonical/sciencepass.'),indent=2)+'\n');items.append((record,'record.json'));items.extend((b/n,'control/'+n) for n in ['clm-bounded-native-cn-source.tar.gz','clm-bounded-native-cn-package.json','qia-bounded-cold-cv-inputs.tar.gz','run_bounded_gpu_prefix_cy.py','control_bounded_gpu_prefix_cy.py','launch_bounded_gpu_prefix_cy.py','profile_richards_whole_cw.py',Path(__file__).name]);assert all(p.is_file() for p,n in items);a=b/'bounded-gpu-prefix-cy-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),records=records)),flush=True)

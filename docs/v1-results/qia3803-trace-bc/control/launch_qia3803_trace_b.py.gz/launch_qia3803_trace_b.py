from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=b/'qia3803-trace-device-b';assert not r.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>8192
mem=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')));assert mem>16*1024*1024
r.mkdir();env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false')
with (r/'model.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'trace_qia3803_device_b.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_gpu_mib=free,controls_sha256={n:sha(b/n) for n in ['trace_qia3803_device_b.py',Path(__file__).name]})
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

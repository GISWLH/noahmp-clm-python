from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=b/'qia3803-trace-device-c';old=b/'qia-cuda-3803-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and all(sha(s/n)==h for n,h in m.items())
cap=json.loads((old/'surface-capture-a/receipt.json').read_text());path=old/'surface-capture-a/failed-surface.npz';assert sha(path)==cap['failed_surface_sha256']
with np.load(path,allow_pickle=False) as z:packet=dict(z)
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import cupy as cp
import noahmp_clm.gpu.cuda.canopy_phase_surface as module
from noahmp_clm.physics.photosynthesis import LeafParameters
args=tuple(cp.asarray(packet['surface_a'+str(i)]) for i in range(9))
kwargs={k:cp.asarray(packet[k]) for k in ['exchange_extension','vic','stem_area'] if k in packet}
kwargs.update(parameters=LeafParameters(**json.loads((old/'surface-capture-a/leaf-parameters.json').read_text())),raise_on_failure=False)
raws=[];unpack=module.unpack_phase_surface
def observe(raw):raws.append(raw.copy());return unpack(raw)
module.unpack_phase_surface=observe;start=time.monotonic()
module.run_canopy_phase_surface_cuda(*args,**kwargs)
baseline=cp.asnumpy(raws[-1]);assert baseline.tobytes()==packet['raw'].tobytes()
names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu','enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu','snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu')
sources=[]
for name in names:
    text=Path(module.__file__).with_name(name).read_text()
    if name=='canopy_phase_energy_kernel.cu':
        marker='struct PhaseContext {';assert text.count(marker)==1;text=text.replace(marker,'extern "C" __device__ float phase_trace[5400];\n'+marker)
        marker='    int iteration=0,restarts=0;bool failed=false;';assert text.count(marker)==1
        text=text.replace(marker,'    for(int k=0;k<5400;++k)phase_trace[k]=__int_as_float(0x7fffffff);\n'+marker)
        marker='phase_evaluate(v,x,r,out);if(phase_max(r,12)<=tolerance)break;';assert text.count(marker)==1
        text=text.replace(marker,'''phase_evaluate(v,x,r,out);
        for(int k=0;k<12;++k){phase_trace[iteration*54+k]=x[k];phase_trace[iteration*54+12+k]=r[k];}
        for(int k=0;k<10;++k)phase_trace[iteration*54+24+k]=v.phase_active[k]?1.f:0.f;
        phase_trace[iteration*54+51]=phase_max(r,12);phase_trace[iteration*54+53]=float(iteration);
        if(phase_max(r,12)<=tolerance)break;''')
        marker='        bool retry=!accepted&&available;';assert text.count(marker)==1
        text=text.replace(marker,marker+'''
        for(int k=0;k<12;++k)phase_trace[iteration*54+34+k]=delta[k];
        phase_trace[iteration*54+46]=norm;phase_trace[iteration*54+47]=chosen_norm;
        phase_trace[iteration*54+48]=accepted?1.f:0.f;phase_trace[iteration*54+49]=retry?1.f:0.f;
        phase_trace[iteration*54+50]=float(restarts);''')
    sources.append(text)
source='\n'.join(sources);(r/'diagnostic-kernel.cu').write_text(source)
name='run_canopy_phase_surface_stems';compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=(name,))
fn=compiled.get_function(name);original=module._kernel
def traced(extended=False,vic=False,stems=False,profiled=False):
    assert stems and not profiled
    return fn
module._kernel=traced
try:module.run_canopy_phase_surface_cuda(*args,**kwargs)
finally:module._kernel=original;module.unpack_phase_surface=unpack
pointer=compiled.get_global('phase_trace')
trace=cp.asnumpy(cp.ndarray((100,54),cp.float32,memptr=pointer));variant=cp.asnumpy(raws[-1]);same=variant.tobytes()==baseline.tobytes()
np.savez_compressed(r/'trace-and-raw.npz',original_raw=baseline,instrumented_raw=variant,iteration_trace=trace)
cp.cuda.runtime.deviceSynchronize();unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged and sha(path)==cap['failed_surface_sha256']
d=dict(scope='Read-only private compilation of original519H rejected3803 surface. Original uninstrumented output first reproduced byte-exact. Global trace instrumentation has no physics/equation/tolerance changes; trace attribution requires instrumented raw741 also exact. No production edit or annual advancement; atexit bypass only after barrier/durable receipt.',
    original_raw_byte_exact=True,instrumented_raw_byte_exact=same,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(path),payload_sha256=sha(r/'trace-and-raw.npz'),compiled_diagnostic_source_sha256=sha(r/'diagnostic-kernel.cu'),device_barrier_complete=True,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[]
for label in ['capacity','capacity_optics']:
    r=b/('qia-bounded-'+label+'-numpy-cold-cx');d=json.loads((r/'receipt.json').read_text());report=json.loads((r/'trajectory/report.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['failure'] is None and d['source_unchanged'] and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and sha(r/'trajectory/report.json')==d['report_sha256'];snapshot=r/'cold48-report.json';assert not snapshot.exists();snapshot.write_bytes((r/'trajectory/report.json').read_bytes())
    for p in sorted(r.rglob('*')):
        if p.is_file():items.append((p,label+'/'+p.relative_to(r).as_posix()))
for stem in ['bounded-cold-inputs-cv']:
    assert (b/stem/'pbs-exit.txt').read_text().strip()=='0'
    for p in sorted((b/stem).rglob('*')):
        if p.is_file():items.append((p,stem+'/'+p.relative_to(b/stem).as_posix()))
items.extend((b/n,'control/'+n) for n in ['clm-bounded-native-cn-source.tar.gz','qia-bounded-cold-cv-inputs.tar.gz','dispatch_bounded_cold_inputs_cv.py','dispatch_bounded_numpy_prefix_cx.py',Path(__file__).name]);assert all(p.is_file() for p,n in items);a=b/'bounded-cpu-prefix-cx-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

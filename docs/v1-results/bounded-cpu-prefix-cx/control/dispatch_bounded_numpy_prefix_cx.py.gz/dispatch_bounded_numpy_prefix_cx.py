from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');p=b/'bounded-cold-inputs-cv';assert (p/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((p/'receipt.json').read_text());assert d['source_unchanged'] and d['all_numpy_code_byteexact_to_executed_ck'] and all(q['all30_cold_fields_byteexact_to_prior_physical_seed'] for q in d['cases']);records=[]
for label in ['capacity','capacity_optics']:
    r=b/('qia-bounded-'+label+'-numpy-cold-cx');assert not r.exists();r.mkdir();controls={}
    for n in ['run_bounded_numpy_prefix_cx.py','bounded_numpy_prefix_cx.pbs']:
        raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
    q=subprocess.run(['qsub','-v','CAPACITY_CASE='+label,str(r/'bounded_numpy_prefix_cx.pbs')],cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr;row=dict(case=label,pbs_job=q.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(row,indent=2)+'\n');records.append(row);print(json.dumps(row),flush=True)

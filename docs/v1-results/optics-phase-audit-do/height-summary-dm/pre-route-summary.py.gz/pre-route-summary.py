"""All predeclared literature-height scenarios, compute-node sensitivity only."""
from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'height-summary-dl';original=b/'height-matrix-bx';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((original/'package.json').read_text());a=b/'clm-wet-coupled-final-bo-source.tar.gz';assert sha(a)==package['source_archive_sha256'];start=time.monotonic()
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and sha(s/'SOURCE_SHA256.json')==package['source_manifest_sha256'] and all(sha(s/n)==h for n,h in m.items());inputs=tmp/'inputs';inputs.mkdir();a=b/'height-inputs-a.tar.gz';assert sha(a)==package['input_archive_sha256']
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
protocol=r/'protocol.json';assert sha(protocol)==package['protocol_sha256'];cases_path=inputs/'configs/cases.json';cases=json.loads(cases_path.read_text());assert len(cases['cases'])==27;terminal=(original/'pbs-exit.txt').read_text().strip();prior=json.loads((original/'receipt.json').read_text());assert prior['source_unchanged'] and prior['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
from summarize_fluxnet_height_sensitivity import summarize
summary=summarize(original/'height-runs',cases_path,protocol);assert summary['expected_cases']==27 and set(summary['cases'])=={q['case'] for q in cases['cases']};(r/'all27-sensitivity.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');(r/'cases.json').write_bytes(cases_path.read_bytes());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());ranges={}
for site in ['CN-Cng','CN-Qia','CN-Cha']:
    entries=[q for q in cases['cases'] if q['site']==site];assert len(entries)==9;complete=[(q,summary['cases'][q['case']]) for q in entries if summary['cases'][q['case']]['status']=='complete' and 'comparison_to_baseline' in summary['cases'][q['case']]];record=dict(expected_scenarios=9,compared_scenarios=len(complete),predeclared_baseline=[q['case'] for q in entries if q['baseline']],fields={})
    if complete:
        for field in complete[0][1]['comparison_to_baseline']['whole_window']:
            first=complete[0][1]['comparison_to_baseline']['whole_window'][field];width=len(first) if isinstance(first,list) else 1;columns=[]
            for k in range(width):
                rows=[(q['case'],data['comparison_to_baseline']['whole_window'][field][k] if isinstance(first,list) else data['comparison_to_baseline']['whole_window'][field]) for q,data in complete];item=dict(units=rows[0][1]['units'],scenarios=len(rows),baseline_role='Fixed literature assumption, never an optimized or observed reference')
                for metric in ['bias','relative_bias','rmse','max_absolute_difference','model_mean','reference_mean','model_integral','baseline_integral']:
                    kept=[(name,v[metric]) for name,v in rows if metric in v and v[metric] is not None]
                    if kept:item[metric]=dict(min=min(v for _,v in kept),max=max(v for _,v in kept),available_scenarios=len(kept))
                columns.append(item)
            record['fields'][field]=columns if isinstance(first,list) else columns[0]
    ranges[site]=record
(r/'all-scenario-ranges.json').write_text(json.dumps(ranges,indent=2,allow_nan=False)+'\n');d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,original_pbs_job=prior['pbs_job'],original_pbs_exit=terminal,original_all27_numerically_complete=prior['all27_numerically_complete'],expected=27,complete=summary['complete_cases'],scenario_statuses={status:sum(q['status']==status for q in summary['cases'].values()) for status in sorted({q['status'] for q in summary['cases'].values()})},all_declared_scenarios_retained=True,protocol_sha256=sha(protocol),cases_sha256=sha(cases_path),summary_sha256=sha(r/'all27-sensitivity.json'),ranges_sha256=sha(r/'all-scenario-ranges.json'),source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,scope='All original27 lockedliteratureheight scenarios and allresults, fixedbaseline neveroptimized. BO .05 legacyVIC/cold336 warmseason only, CN saturated-Richards correction inactive here, no sourceidentity relabel. Full perday/window flux/state sensitivity and allscenario min/max, notobservationalskill/spinup/multiyear/holdout/calibration/acceptance. Numericalanalysis only EHPCPBS, no localphysics.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);print(json.dumps(ranges),flush=True);assert d['source_unchanged']

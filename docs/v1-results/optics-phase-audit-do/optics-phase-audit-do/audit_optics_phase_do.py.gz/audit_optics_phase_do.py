"""Exact quantized GPU inner-context independent NumPy comparison, PBS only."""
from pathlib import Path
import hashlib,json,os,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'optics-phase-audit-do';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());source=b/'clm-bounded-native-cn-source.tar.gz';assert sha(source)=='9f28e8874c2a365fdb9c39764fc33e54a542c8aff4d0a5375906d6c22819e286'
with tarfile.open(source) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==568 and all(sha(s/n)==h for n,h in m.items());packet=tmp/'packet';packet.mkdir();a=b/'optics-phase-di-evidence.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(packet,filter='data')
probe=json.loads((packet/'probe/receipt.json').read_text());assert probe['source_unchanged'] and probe['records'][0]['all_original_surface_fields_byteexact']
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks'),str(s/'tests')]
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_optics import CanopyOptics
from noahmp_clm.physics.snowpack import Snowpack
from noahmp_clm.gpu.canopy_phase_energy import unpack_phase,validate_phase
from check_canopy_phase_gpu import science,ledgers
with np.load(packet/'inputs/original-failed-surface.npz',allow_pickle=False) as z:original=dict(z)
optical=original['control/canopy_optics'][0].reshape(4,2);optics=CanopyOptics(*(tuple(q) for q in optical));snow=original['input0'][0][:,[0,3,4,5,6,7,8]];n=int(original['input3'][0,0]);pack=Snowpack(snow[:n,0],np.zeros(n),snow[:n,0]/250.,snow[:n,1],snow[:n,2:]) if n else None
start=time.monotonic();rows=[];values={}
for label in ['instrumented-original','private-local-branch']:
    with np.load(packet/'probe'/(label+'-inner.npz'),allow_pickle=False) as z:inner=dict(z)
    ctx=inner['context'];leaf,u,f,soil,c,boundary,p,area,extra=(ctx[34:44],ctx[44:67],ctx[67:87].reshape(10,2),ctx[800:810],ctx[87:107].reshape(10,2),ctx[107:116],ctx[116:216].reshape(10,10),ctx[811:821],ctx[821:823]);stem=area.astype(float)-leaf.astype(float);assert np.all(stem>=0.)
    bad=np.flatnonzero(~np.isfinite(ctx));assert set(bad.tolist())<={59,60,61} and all(np.isposinf(ctx[k]) for k in bad),bad.tolist();arrays=tuple(v[None].astype(np.float32) for v in [leaf,u,f,soil,stem,c,boundary,snow])+(np.asarray([n],np.int32),);validate_phase(arrays,np);supply=SoilWaterSupply(soil[1:5].astype(float),soil[5:9].astype(float),float(soil[9])) if soil[0]>0. else None
    exchange=CanopyExchange(*u[:11].astype(float),atmosphere_water_velocity=float(extra[0]),potential_temperature=float(extra[1]))
    ref=solve_canopy_phase_energy(leaf.astype(float),float(u[11]),float(u[12]),exchange,CanopyCondensate(c[:,0].astype(float),c[:,1].astype(float)),float(boundary[4]),stem_area=stem,vegetated_fraction=float(u[13]),soil_supply=supply,root_enthalpy=boundary[5:9].astype(float) if supply is not None else None,transpiration_limit=float(u[16]),ground_evaporation_limit=float(u[17]),water_stress=f[:,1].astype(float),nitrogen_factor=f[:,0].astype(float),leaf_parameters=LeafParameters.from_layer_rows(p.astype(float)),ground_emissivity=float(u[18]),ground_albedo=u[19:21].astype(float),diffuse_fraction=float(u[21]),cosine_zenith=float(u[22]),fixed_ground_temperature=float(boundary[1]) if boundary[0]>0 else None,ground_is_ice=bool(boundary[2]),ground_shares_soil=bool(boundary[3]),snowpack=pack,tolerance=1e-7,canopy_optics=optics)
    got=unpack_phase(inner['phase_output'][None]);trace=inner['trace'];trace=trace[np.isfinite(trace[:,0])];record=dict(label=label,captured_nonfinite_slots=bad.tolist(),finite_context_scope='Original validate_phase domain applies, including explicitly allowed positive-infinite evaporationlimits u15:18; all other capturedfields finite. CPU independentlyrecomputesradiation.',reference_iterations=ref['iterations'],reference_max_solver_residual=float(np.max(abs(ref['solver_residual']))),reference_phase_coordinates=ref['phase_coordinates'].tolist(),native_converged=bool(got['converged'][0]),native_max_solver_residual=float(got['max_solver_residual'][0]),native_trace_rows=len(trace),trace_start_end=trace[[0,-1]][:,[0,1,11,23,13]].tolist(),scope='Supply10/rootenthalpy/leafprofile/exchange/boundary all copied from actualGPUinnercontext. NumPy independently evaluates its radiative/biochemical/phase laws in float64; not a byteexactarithmetic oracle.')
    if label=='private-local-branch':
        assert got['converged'][0] and np.all(np.isfinite(inner['phase_output']));record['science']=science(got,[ref]);arrays=tuple(v[None].astype(np.float32) for v in [leaf,u,f,soil,stem,c,boundary,snow])+(np.asarray([n],np.int32),);record['original_parcel_budgets']=ledgers(got,arrays)
    for key in ['leaf_temperature','h','le','gpp','phase_coordinates','solver_residual']:values[label+'/'+key]=np.asarray(ref[key])
    rows.append(record);print(json.dumps(record),flush=True)
np.savez_compressed(r/'reference.npz',**values);d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,rows=rows,seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_archive_sha256=package['archive_sha256'],scope='Privatecandidate only: actualoriginalbytes exact instrument, original100/.005 gate, exactGPUinner supply/root/profile independentNumPy original10percent/nearzero and originalparcelledger audit. No productionfix/JAXpair/wholecolumn/year/spinup/scienceclaim or failedyearresume.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert d['source_unchanged']

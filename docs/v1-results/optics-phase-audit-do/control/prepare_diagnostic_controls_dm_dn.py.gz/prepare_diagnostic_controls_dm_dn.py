"""Preserve failed preparatory audits; correct validation of retained metadata only."""
from pathlib import Path
import ast
o=Path(__file__).parent
for old,new in [('summarize_height_matrix_dl.py','summarize_height_matrix_dm.py'),('height_summary_dl.pbs','height_summary_dm.pbs'),('dispatch_height_summary_dl.py','dispatch_height_summary_dm.py')]:
    text=(o/old).read_text().replace('height-summary-dl','height-summary-dm').replace('height_summary_dl','height_summary_dm')
    if new.startswith('dispatch_'):
        text=text.replace("raw=(b/n).read_bytes();assert b'\\r\\n' not in raw;", "raw=(b/n).read_bytes();assert n.endswith('.json') or b'\\r\\n' not in raw;")
    if new.endswith('.py'):ast.parse(text)
    p=o/new;assert not p.exists();p.write_bytes(text.encode())
for old,new in [('audit_optics_phase_dk.py','audit_optics_phase_dn.py'),('optics_phase_dk.pbs','optics_phase_dn.pbs'),('dispatch_optics_phase_dk.py','dispatch_optics_phase_dn.py')]:
    text=(o/old).read_text().replace('optics-phase-audit-dk','optics-phase-audit-dn').replace('optics_phase_dk','optics_phase_dn').replace('optics-phase-dk-package','optics-phase-dn-package')
    if new.startswith('audit_'):
        text=text.replace("assert np.all(np.isfinite(ctx));supply=", "bad=np.flatnonzero(~np.isfinite(ctx));required=np.r_[np.arange(243),np.arange(800,810),np.arange(811,825)];assert np.all(np.isfinite(ctx[required])),bad.tolist();supply=")
        text=text.replace("record=dict(label=label,", "record=dict(label=label,captured_nonfinite_slots=bad.tolist(),finite_context_scope='All coordinates/residuals/physicalinputs/profile plus27kernel-readradiationfields checkedfinite. Otherunusedderivedradiation/padding retainedraw; CPU independentlyrecomputesradiation.',")
    if new.endswith('.py'):ast.parse(text)
    p=o/new;assert not p.exists();p.write_bytes(text.encode())
(o/'optics-phase-dn-package.json').write_bytes((o/'optics-phase-dk-package.json').read_bytes())
print('New DM/DN controls: locked CRLF protocol stays byteexact; only requiredGPUcontext fields get physicalfiniteassertions, allrawfields retained. Original DL preparation and404 exit1 not overwritten.')

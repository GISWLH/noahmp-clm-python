from pathlib import Path
import ast
o=Path(__file__).parent
for old,new in [('audit_optics_phase_dn.py','audit_optics_phase_do.py'),('optics_phase_dn.pbs','optics_phase_do.pbs'),('dispatch_optics_phase_dn.py','dispatch_optics_phase_do.py')]:
    text=(o/old).read_text().replace('optics-phase-audit-dn','optics-phase-audit-do').replace('optics_phase_dn','optics_phase_do').replace('optics-phase-dn-package','optics-phase-do-package')
    if new.startswith('audit_'):
        text=text.replace('from noahmp_clm.gpu.canopy_phase_energy import unpack_phase','from noahmp_clm.gpu.canopy_phase_energy import unpack_phase,validate_phase')
        old_check='bad=np.flatnonzero(~np.isfinite(ctx));required=np.r_[np.arange(243),np.arange(800,810),np.arange(811,825)];assert np.all(np.isfinite(ctx[required])),bad.tolist();supply='
        new_check="bad=np.flatnonzero(~np.isfinite(ctx));assert set(bad.tolist())<={59,60,61} and all(np.isposinf(ctx[k]) for k in bad),bad.tolist();arrays=tuple(v[None].astype(np.float32) for v in [leaf,u,f,soil,stem,c,boundary,snow])+(np.asarray([n],np.int32),);validate_phase(arrays,np);supply="
        assert old_check in text;text=text.replace(old_check,new_check).replace('All coordinates/residuals/physicalinputs/profile plus27kernel-readradiationfields checkedfinite. Otherunusedderivedradiation/padding retainedraw; CPU independentlyrecomputesradiation.','Original validate_phase domain applies, including explicitly allowed positive-infinite evaporationlimits u15:18; all other capturedfields finite. CPU independentlyrecomputesradiation.')
    if new.endswith('.py'):ast.parse(text)
    p=o/new;assert not p.exists();p.write_bytes(text.encode())
(o/'optics-phase-do-package.json').write_bytes((o/'optics-phase-dn-package.json').read_bytes())
print('Original validate_phase contract retained, positiveinf cap60 is legal unlimitedtranspiration; DK404/DN405 pre-reference falsefinite assertions remain preserved.')

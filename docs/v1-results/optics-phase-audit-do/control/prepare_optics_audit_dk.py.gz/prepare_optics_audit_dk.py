from pathlib import Path
import ast
o=Path(__file__).parent
for old,new in [('optics_surface_dh.pbs','optics_phase_dk.pbs'),('dispatch_optics_surface_dh.py','dispatch_optics_phase_dk.py')]:
    text=(o/old).read_text().replace('optics-surface-audit-dh','optics-phase-audit-dk').replace('optics_surface_dh','optics_phase_dk').replace('optics-surface-dh','optics-phase-dk')
    if new.endswith('.py'):ast.parse(text)
    p=o/new;assert not p.exists();p.write_bytes(text.encode())
print('Prepared independent exact-inner-context audit controls.')

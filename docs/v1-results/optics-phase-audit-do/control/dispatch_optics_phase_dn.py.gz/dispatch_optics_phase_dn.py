from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'optics-phase-audit-dn';assert not r.exists();r.mkdir();controls={}
for n in ['audit_optics_phase_dn.py','optics_phase_dn.pbs','optics-phase-dn-package.json']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/('package.json' if n.endswith('package.json') else n)).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'optics_phase_dn.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

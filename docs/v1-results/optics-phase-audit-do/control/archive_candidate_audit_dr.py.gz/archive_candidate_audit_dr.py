from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'optics-phase-audit-do';assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and len(d['rows'])==2 and d['rows'][1]['native_converged'] and d['rows'][1]['science'] and d['rows'][1]['original_parcel_budgets'];data={}
for name in ['optics-phase-audit-dk','optics-phase-audit-dn','optics-phase-audit-do','height-summary-dl','height-summary-dm']:
    root=b/name
    for p in sorted(root.rglob('*')):
        if p.is_file():data[name+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
for n in [Path(__file__).name,'prepare_diagnostic_controls_dm_dn.py','prepare_optics_original_contract_do.py','prepare_optics_audit_dk.py','route_held_height_dm.py','record_height_prelaunch_dl.py','dispatch_optics_phase_dk.py','dispatch_optics_phase_dn.py','dispatch_optics_phase_do.py','dispatch_height_summary_dl.py','dispatch_height_summary_dm.py']:
    data['control/'+n]=(b/n).read_bytes()
p=subprocess.run(['qstat','-a'],capture_output=True,text=True);record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_qstat=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),scope='EHPC407 actual0 privateCUDAcandidate exactGPUinnercontext originalreference/science/parcelbudgets; no production/JAXpair/fullcolumn/annual/scienceacceptance. Original404/405 falsefiniteasserts before reference retained; originalcontract permitspositiveinf transpirationlimit. DL prelaunchCRLF-protocol error and held406 route DL->DM old/new hashes retained, no science/source/gate edits or modelworkerstop. Height406 dependency390 pending unlessactualrecordshows terminal, all27 presetconditions preserved.');data['record.json']=(json.dumps(record,indent=2)+'\n').encode();a=b/'optics-phase-audit-do-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in data.items():q=tarfile.TarInfo(name);q.size=len(raw);tf.addfile(q,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,artifacts=len(data),utc=record['utc'])),flush=True)

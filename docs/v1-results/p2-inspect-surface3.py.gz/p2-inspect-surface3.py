import sys,numpy as np
sys.path.insert(0,'tests')
from test_gpu_canopy_surface import cases
from noahmp_clm.gpu.cuda.canopy_surface import run_canopy_surface_cuda,_kernel
import cupy as cp
from pathlib import Path
import noahmp_clm.gpu.cuda.canopy_surface as m
names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu','snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu')
source='\n'.join(Path(m.__file__).with_name(n).read_text() for n in names)
source=source.replace('__device__ void soil_transport_device','__device__ __noinline__ void soil_transport_device')
module=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=('run_canopy_surface',))
m._kernel=lambda:module.get_function('run_canopy_surface')
r=run_canopy_surface_cuda(*cases(np.float32,6),raise_on_failure=False)
print('converged',r['converged']);print('firstsoil',r['soil_cells'][0]);print('surface',r['surface_temperature'])

"""Actual CUDA three-site 6-step versus 3+(1+2)-step continuation."""
from pathlib import Path
import hashlib, json, time
import numpy as np
import run_fluxnet_native as runner

root = Path(__file__).resolve().parents[1]
base = root.parent
old = base/'p6-native-fluxnet-b'
out = root/'carry-check'; out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = json.loads((root/'SOURCE_SHA256.json').read_text())
assert all(sha(root/p) == h for p, h in sources.items())
names = ['CN-Cng-tq6-w2', 'CN-Qia-tq39.6-w39.6', 'CN-Cha-tq61.8-w61.8']
spec = json.loads((old/'height-batch.json').read_text())
rows = [next(row for row in spec['cases'] if row['case'] == name) for name in names]
for part, window in [('all',slice(0,6)), ('first',slice(0,3)), ('second',slice(3,6))]:
    folder = out/part; folder.mkdir()
    batch = []
    for row in rows:
        paths = {key: (old/row[key]).resolve() for key in ['input','input_manifest','configuration']}
        with np.load(paths['input'], allow_pickle=False) as archive:
            data = {key:value[window] for key,value in archive.items()}
        target = folder/(row['case']+'.npz')
        runner.write_npz(target, **data)
        meta = json.loads(paths['input_manifest'].read_text())
        meta.update(prepared_npz_sha256=sha(target), parent_prepared_npz_sha256=sha(paths['input']),
            execution_window=[str(data['time_start'][0]),str(data['time_end'][-1])],
            purpose='Exact native continuation instrument check, not climate spinup')
        manifest = folder/(row['case']+'.json'); runner.atomic_json(manifest,meta)
        batch.append(dict(case=row['case'],input=str(target),input_manifest=str(manifest),
                          configuration=str(paths['configuration'])))
    runner.atomic_json(folder/'batch-input.json',dict(cases=batch))
started = time.monotonic()
runner.run(out/'all/batch-input.json', out/'continuous')
runner.run(out/'first/batch-input.json', out/'first-run')
runner.run(out/'second/batch-input.json', out/'second-run', initial_run=out/'first-run',
           initial_mode='continue',stop_after=1)
# Simulate interrupted compatibility-alias publication. The immutable committed
# reports and batch pointer remain intact; this is not an OS power-failure test.
alias = out/'second-run'/names[0]/'report.json'
(out/'alias-before-interruption.json').write_bytes(alias.read_bytes())
alias.write_text('{simulated interrupted alias',encoding='utf-8')
runner.run(out/'second/batch-input.json', out/'second-run', initial_run=out/'first-run',
           initial_mode='continue',resume=True)
full,a,fa = runner.read_generation(out/'continuous')
part,b,fb = runner.read_generation(out/'second-run')
_,_,f0 = runner.read_generation(out/'first-run')
assert full['status'] == part['status'] == 'complete'
assert full['ledger_steps'] == part['ledger_steps'] == 6 and part['ledger_segments'] == 2
for key in a:
    if key != 'index': np.testing.assert_array_equal(a[key],b[key],err_msg=key)
for column in range(len(names)):
    for key in fa[column][1]:
        values = np.concatenate([f0[column][1][key],fb[column][1][key]])
        np.testing.assert_array_equal(fa[column][1][key],values,err_msg=names[column]+'/'+key)
assert all(sha(root/p) == h for p,h in sources.items())
result = dict(scope='Real CUDA32 segment state/ledger/trace continuity, not observed science acceptance or spinup',
    cases=names,steps=6,segment_steps=[3,1,2],native_arrays=16,checkpoint_fields_equal_except_local_index=len(a)-1,
    trace_fields_per_case=len(fa[0][1]),all_fields_bitwise_identical=True,
    recovered_from_simulated_incomplete_alias=True,elapsed_seconds=time.monotonic()-started,
    source_manifest_sha256=sha(root/'SOURCE_SHA256.json'),instrument_sha256=sha(Path(__file__)),
    maximum_cumulative_m_h_c_n=np.asarray(part['maximum_cumulative_residual_m_h_c_n']).max(0),
    minimum_cumulative_bounds_m_h_c_n=np.asarray(part['cumulative_numerical_bounds_m_h_c_n']).min(0))
runner.atomic_json(out/'summary.json',result)
print(json.dumps(result,default=lambda v:v.tolist(),indent=2),flush=True)

from pathlib import Path
import hashlib,json,os,sys,time,traceback
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-f';r=b/'qia-stem-cuda-year-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
start=time.monotonic();failure=None;result=None;barriers=[]
try:
 before,state,cases=native.read_generation(r/'trajectory');assert before['status']=='running' and before['steps_completed']==48 and before['steps_requested']==17520 and before['identity']['compare_jax32'] is False and len(state)==26
 native.run(r/'inputs/batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,resume=True)
 report,state,cases=native.read_generation(r/'trajectory');assert report['status']=='complete' and report['steps_completed']==17520 and report['steps_requested']==17520 and len(state)==26 and report['source_unchanged'] and report['same_precision_max_absolute'] is None
 import cupy as cp
 cp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete');result=dict(steps_completed=17520,steps_requested=17520,columns=1,native_checkpoint_arrays=26,maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],source_unchanged=True,same_precision_maximum_absolute=None)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
unchanged=all(sha(s/n)==v for n,v in m.items());report=json.loads((r/'trajectory/batch.json').read_text());receipt=dict(scope='Continue successfully validated own CUDA-only48 prefix to original17520 full Qia year,all26 arrays/initial/net/bounds carried exactly from archived first day. Original strictA independent JAX32 comparison still separate and not waived; no JAX shadow/same-precision result in this science trajectory. Original MHCN/source/physical solver gates unchanged. Full climate execution alone is not spinup/observation/official scientific acceptance. Interpreter atexit bypass only after device barrier/durable success receipt.',failure=failure,result=result,status=report['status'],steps_completed=report['steps_completed'],steps_requested=report['steps_requested'],source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barriers=barriers,seconds=time.monotonic()-start)
native.atomic_json(r/'receipt.json',receipt);print(json.dumps(receipt),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barriers==['cupy-complete'] else 1)

from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-station-c';r=b/'stem-station-device-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==504 and all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')];import run_fluxnet_native as native
start=time.monotonic();failure=None;result=None;barriers=[]
try:
 batch=r/'inputs/batch.json';native.run(batch,r/'continuous',backend='cuda32',compare_jax32=True)
 native.run(batch,r/'split',backend='cuda32',compare_jax32=True,stop_after=2)
 partial=json.loads((r/'split/batch.json').read_text());assert partial['status']=='running' and partial['steps_completed']==2
 native.run(batch,r/'split',backend='cuda32',compare_jax32=True,resume=True)
 full,a,fa=native.read_generation(r/'continuous');split,c,fc=native.read_generation(r/'split')
 assert full['status']==split['status']=='complete' and full['steps_completed']==split['steps_completed']==4
 assert full['identity']['native_state_arrays']==split['identity']['native_state_arrays']==19 and a.keys()==c.keys() and len(a)==48
 for key in a:
  assert a[key].dtype==c[key].dtype and a[key].shape==c[key].shape and a[key].tobytes()==c[key].tobytes(),key
 fields=[]
 for (report,left),(other,right) in zip(fa,fc):
  assert left.keys()==right.keys()
  for key in left:
   assert left[key].dtype==right[key].dtype and left[key].tobytes()==right[key].tobytes(),report['site']+'/'+key
  assert set(native.structure_trace_keys(report['configuration']))<=left.keys()
  fields.append(dict(case=report['configuration']['canopy_structure']['parameters']['scheme'],fields=len(left),sai=left['sai_m2m2'].tolist()))
 import jax,cupy as cp
 jax.effects_barrier();barriers.append('jax-complete');cp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
 result=dict(backend_primary='cuda32',independent_shadow='jax32',columns=2,steps_per_trajectory=4,
  full_and_split_checkpoint_arrays=48,all_state_trace_ledger_bytes_equal=True,fields=fields,
  same_precision_maximum_absolute=full['same_precision_max_absolute'],maximum_cumulative_m_h_c_n=full['maximum_cumulative_residual_m_h_c_n'],
  continuous_report_sha256=sha(r/'continuous/batch.json'),split_report_sha256=sha(r/'split/batch.json'))
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
unchanged=all(sha(s/n)==v for n,v in m.items());value=dict(scope='Actual new504C native station driver full4 and split2/resume2,2 structured columns, independent JAX32 shadow carried through every original1e-6 and MHCN audit. Synthetic inputs only, not a climate/observational/spinup result. Interpreter atexit is bypassed after final barriers and durable receipt; normal JAX shutdown unvalidated.',failure=failure,result=result,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barriers=barriers,seconds=time.monotonic()-start);native.atomic_json(r/'receipt.json',value);print(json.dumps(value),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and len(barriers)==2 else 1)

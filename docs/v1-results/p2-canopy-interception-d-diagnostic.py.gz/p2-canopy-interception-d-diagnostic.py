from pathlib import Path
import inspect,json
import numpy as np
import cupy as cp
import jax,jax.numpy as j
from test_gpu_canopy_interception import cases,host
from noahmp_clm.gpu.canopy_interception import run_canopy_water_jax,canopy_water_kernel_jax,canopy_phase_jax,_sum
from noahmp_clm.gpu.cuda.canopy_interception import run_canopy_water_cuda
a=cases(np.float32,400)
b=host(run_canopy_water_jax(*a));c=host(run_canopy_water_cuda(*a),cp.asnumpy)
fail=[]
for key in b:
    for field in b[key] if isinstance(b[key],dict) else [None]:
        x,y=(c[key][field],b[key][field]) if field else (c[key],b[key])
        bad=np.argwhere(abs(x-y)>1e-6+1e-6*abs(y))
        if len(bad):fail.append(dict(key=key,field=field,count=len(bad),samples=[dict(index=i.tolist(),cuda=float(x[tuple(i)]),jax=float(y[tuple(i)])) for i in bad[:8]]))
print('FAILURES',json.dumps(fail),flush=True)
names=['total','fi','fs','ri','si','rh','ih','ph','weights','m','h','ice','liquid','lh','hi','cap','icap','kept_liquid','kept','drip','fall','rate','unload','left','hl','hs','dh','sh','newm','newh']
source=inspect.getsource(canopy_water_kernel_jax).replace('def canopy_water_kernel_jax','def debug_jax')
start=source.index('        fields=j.stack(')
end=source.index('    def vapor():')
source=source[:start]+'        return j.stack(['+','.join('j.broadcast_to('+n+', (10,))' for n in names)+'])\n'+source[end:]
start=source.index('    m,h,fields,ledger=lax.cond')
source=source[:start]+'    return interception()\n'
namespace=dict(j=j,canopy_phase_jax=canopy_phase_jax,_sum=_sum)
exec(source,namespace)
debug=np.asarray(jax.jit(jax.vmap(namespace['debug_jax']))(*a))
cu=Path('src/noahmp_clm/gpu/cuda/canopy_interception_kernel.cu').read_text()
start=cu.index('            float ni,nl;')
end=cu.index('        }\n        float tr=',start)
cunames=['total','fi','fs','ri','si','rh','ih','ph','weight','mm','hh','ice','liq','lh','hi','cap','icap','kept_liquid','kept','drip[k]','fall','rate','unload','left','hl','hs','dh[k]','sh[k]','m[k]','h[k]']
cu=cu[:start]+'            float trace[30]={'+','.join(cunames)+'}; for(int z=0;z<30;++z) out[10*z+k]=trace[z];\n'+cu[end:]
start=cu.index('        float tr=')
end=cu.index('    }else{',start)
cu=cu[:start]+cu[end:]
start=cu.index('    for(int k=0;k<10;++k){float t,ice,liq;cw_phase(m[k]')
end=cu.index('\n}',start)
cu=cu[:start]+cu[end:]
cu=cu.replace('out+k*182','out+k*300')
kern=cp.RawKernel(cu,'canopy_water_columns',options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'))
ca=[cp.asarray(x) for x in a];out=cp.zeros((len(a[0]),300),cp.float32)
kern(((len(out)+127)//128,),(128,),(*ca,out,np.int32(len(out))))
cd=cp.asnumpy(out).reshape(-1,30,10)
for row,layer in [(14,2)]:
    print('TRACE',row,layer,json.dumps([dict(name=n,cuda=float(cd[row,k,layer]),jax=float(debug[row,k,layer])) for k,n in enumerate(names)]),flush=True)
Path('/home/lhwang/work/noahmp-v1/canopy-water-d-diagnostic.json').write_text(json.dumps(dict(failures=fail,trace_names=names,cuda=cd[14,:,2].tolist(),jax=debug[14,:,2].tolist()),indent=2))

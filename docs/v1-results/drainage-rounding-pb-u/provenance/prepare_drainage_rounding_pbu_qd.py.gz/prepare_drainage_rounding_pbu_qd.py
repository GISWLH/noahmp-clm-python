"""PB-u immutable existing-output diagnosis stage; metadata preparation only."""
from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'drainage-rounding-pb-u-preparation'
EXEC=BASE/'drainage-rounding-pb-u-execution'
OLD=BASE/'clm-drainage-device-pb-t-execution'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    assert not EXEC.exists();EXEC.mkdir()
    old=b'/tmp/noahmp-drainage-device-pb-t-compare';new=b'/tmp/noahmp-drainage-rounding-pb-u'
    for name in ('dispatch_compare_pbs.py','check_stage_pbs.py'):
        raw=(OLD/name).read_bytes().replace(old,new).replace(b'/tmp/dispatch_compare_pbt.py',b'/tmp/dispatch_rounding_pbu.py')
        if name=='dispatch_compare_pbs.py':
            raw=raw.replace(b"planned_comparison_children=1",b"planned_existing_output_analysis_children=1")
        compile(ast.parse(raw),name,'exec');(EXEC/name).write_bytes(raw)
    raw=(OLD/'compare_pbs.pbs').read_bytes().replace(old,new)
    raw=raw.replace(b'drainage-device-pbt-compare',b'drainage-rounding-pbu').replace(b'root="$TMPDIR/compare-result"',b'root="$TMPDIR/rounding-result"')
    original=b'"$py" -B "$stage/execution/run_compare_pbs.py" "$root/run" > "$root/worker.stdout" 2> "$root/worker.stderr"'
    replacement=b'"$py" -B "$stage/preparation/analyze_pbt_outputs.py" --input "$stage/gpu-result.tar.gz" --output "$root/diagnosis.json" > "$root/worker.stdout" 2> "$root/worker.stderr"'
    assert raw.count(original)==1
    raw=raw.replace(original,replacement);(EXEC/'compare_pbs.pbs').write_bytes(raw)
    binding=dict(prepared_only=True,launched=False,input_archive='gpu-result.tar.gz',
        input_sha256='69daf37ba4bdef8990de4325ba7bd3d8b38690adc4751fc0ae5f254cef669eea',
        original_device_evidence_sha256='4fed22ebbf2fdc417df2bce8f25647a151bbd69779ede101478351d2b99781aa',
        original_comparison_job='1828.manager',original_PBS_F_exit=1,original_Stageout_status=0,
        resource_budget='1CPU/2GiB/5min/compute002',physical_forward_calls=0,GPU_calls=0,
        cases=['frozen-float32','perched_stress-float32','option2-float32','two_bands-float32'],
        scope='Read only original closed numeric outputs on EHPC; source/physics/reference/gates unchanged, no trace or rerun')
    (PREP/'BINDINGS.json').write_bytes(encode(binding))
    for root in (PREP,EXEC):
        (root/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(root.iterdir()) if p.is_file()}))
    files={}
    for root,prefix in ((PREP,'preparation'),(EXEC,'execution')):
        for p in root.iterdir():
            if p.is_file():files[prefix+'/'+p.name]=p.read_bytes()
    files['gpu-result.tar.gz']=(BASE/'clm-drainage-device-pb-t-gpu-closed/gpu-result.tar.gz').read_bytes()
    assert sha(files['gpu-result.tar.gz'])==binding['input_sha256']
    files['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(files.items())})
    target=BASE/'drainage-rounding-pb-u-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,raw in sorted(files.items()):
                m=tarfile.TarInfo(n);m.size=len(raw);m.mode=0o644;archive.addfile(m,io.BytesIO(raw))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==files
    result=dict(stage=target.name,stage_sha256=sha(target.read_bytes()),stage_files=len(files),
        preparation_manifest_sha256=sha(files['preparation/CONTROLS_SHA256.json']),execution_manifest_sha256=sha(files['execution/CONTROLS_SHA256.json']),
        prepared_only=True,launched=False,numerical_executed=False)
    (BASE/'drainage-rounding-pb-u-stage-package.json').write_bytes(encode(result));print(json.dumps(result))

if __name__=='__main__':main()

"""Close original1839 diagnosis; no local array/pickle numeric decoding."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
LABEL='drainage-rounding-pb-u'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    stage_raw=(BASE/(LABEL+'-stage-b.tar.gz')).read_bytes();stage=files(stage_raw)
    assert sha(stage_raw)=='87574796cac2260a1dbfaaf744eab24f01d544b4c3c528886fdc33a47cf2846c'
    index=json.loads(stage['stage-inventory.json']);assert len(stage)==10 and set(index)==set(stage)-{'stage-inventory.json'}
    assert all(sha(stage[n])==h for n,h in index.items())
    original_raw=(BASE/(LABEL+'-closed/result.tar.gz')).read_bytes();original=files(original_raw)
    assert sha(original_raw)=='386a2c01af0f6399d3a0c57aa98b50e80bd5cd01bc03900340c42d94f1961cee'
    qstat=(BASE/(LABEL+'-closed/qstat.stdout')).read_text()
    assert all(v in qstat for v in ('Job Id: 1839.manager','job_state = F','Exit_status = 0','Stageout_status = 0','run_count = 1'))
    assert all(original[n].strip()==b'0' for n in ('worker-exit.txt','setup-exit.txt','pbs-command-exit.txt','stage-after-exit.txt'))
    assert original['worker.stderr']==b''
    for n in ('stage-before.json','stage-after.json'):
        r=json.loads(original[n]);assert r['passed'] and r['expected']==r['actual']==index
    for prefix,stored in (('preparation','preparation-controls'),('execution','execution-controls')):
        controls=json.loads(stage[prefix+'/CONTROLS_SHA256.json'])
        assert all(original[stored+'/'+n]==stage[prefix+'/'+n] for n in [*controls,'CONTROLS_SHA256.json'])
    r=json.loads(original['diagnosis.json'])
    assert r['completed'] and r['physical_forward_calls']==0 and len(r['cases'])==4
    assert all(all(c['initial_byte_exact'].values()) for c in r['cases'])
    assert len(original['diagnosis.pickle'])==63139
    readout=dict(actual_job='1839.manager',actual_PBS_state='F',actual_PBS_exit=0,Stageout_status=0,
        analysis_worker_exit=0,physical_forward_calls=0,new_GPU_calls=0,analysis_seconds=r['seconds'],
        complete_analysis_pickle_bytes=len(original['diagnosis.pickle']),complete_analysis_pickle_sha256=sha(original['diagnosis.pickle']),
        original_GPU_input_sha256=r['input_sha256'],cases=[dict(case=c['case'],initial_byte_exact=c['initial_byte_exact'],
        final_payload_byte_exact=c['final_payload_byte_exact'],initial_diagnosis_differences=c['diagnosis']['actual.diagnosis_before']) for c in r['cases']],
        scope='Closed existing PB-t output inspection only. Initial phase/parameters are exact, initial29-field diagnosis already differs, and stress/option2 trajectories differ. No operator/compile cause, repair, acceptance, trace rerun or new device validation established.')
    verification=dict(evidence_verified=True,original_job='1839.manager',F_exit=0,Stageout_status=0,
        stage_sha256=sha(stage_raw),original_result_sha256=sha(original_raw),stage_files=10,analysis_cases=4,
        complete_pickle_preserved_opaque=True,local_pickle_or_array_decode=False,local_model_runs=0,
        original_PBt_pair_failure_preserved=True)
    items={'executed-stage.tar.gz':stage_raw,'original-result.tar.gz':original_raw,
        'original-result-inventory.json':encode({n:dict(sha256=sha(raw),bytes=len(raw)) for n,raw in sorted(original.items())}),
        'readout.json':encode(readout),'verification.json':encode(verification)}
    for n,raw in stage.items():
        if n.startswith(('preparation/','execution/')):items[n]=raw
    for p in (BASE/(LABEL+'-closed')).iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['closure/'+p.name]=p.read_bytes()
    for n in (LABEL+'-stage-package.json',LABEL+'-stage-b-package.json',LABEL+'-deployment.json',
        'prepare_drainage_rounding_pbu_qd.py','deploy_drainage_rounding_pbu_qd.py','collect_drainage_rounding_pbu_closed_qd.py',Path(__file__).name):
        items['provenance/'+n]=(BASE/n).read_bytes()
    for p in BASE.glob(LABEL+'-deploy-*'):
        if p.is_file():items['deployment/'+p.name]=p.read_bytes()
    items['unexecuted-initial-stage.tar.gz']=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    assert sha(items['unexecuted-initial-stage.tar.gz'])=='e2e250f2fd188262350d92003962ccb255993ce0690b513edba4c1ed20432ca1'
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(raw),bytes=len(raw)) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for n,raw in sorted(items.items()):
                m=tarfile.TarInfo(n);m.size=len(raw);m.mode=0o644;archive.addfile(m,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='EHPC1839 F0/Stageout0 existing-output-only diagnosis of four PB-t failure cases; complete raw pickle/JSON,29-field numeric/bit/ULP evidence. No new physics/device calls, repair or scientific pass.')
    for suffix,value in (('readout',readout),('verification',verification),('package',package)):(BASE/(LABEL+'-'+suffix+'.json')).write_bytes(encode(value))
    print(json.dumps(package))

if __name__=='__main__':main()

"""One authorized comparison PBS submission; raw command exits preserved."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage=BASE/'drainage-rounding-pb-u-stage-b.tar.gz'
expected='87574796cac2260a1dbfaaf744eab24f01d544b4c3c528886fdc33a47cf2846c'
assert sha(stage.read_bytes())==expected
target=BASE/'drainage-rounding-pb-u-deployment.json'
assert not target.exists()
dispatcher=BASE/'drainage-rounding-pb-u-execution/dispatch_compare_pbs.py'
commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',
    'test ! -e /tmp/noahmp-drainage-rounding-pb-u && test ! -e /tmp/noahmp-drainage-rounding-pb-u-stage.tar.gz && test ! -e /tmp/dispatch_rounding_pbu.py'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(stage),'ehpc:/tmp/noahmp-drainage-rounding-pb-u-stage.tar.gz'],
    ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=10',str(dispatcher),'ehpc:/tmp/dispatch_rounding_pbu.py'],
    ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','ehpc',
     '/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_rounding_pbu.py --archive /tmp/noahmp-drainage-rounding-pb-u-stage.tar.gz --sha256 '+expected]]
record=dict(started_unix=time.time(),stage_sha256=expected,single_submit=True,actual_commands=[],actual_exit=None)
for number,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=180)
    (BASE/('drainage-rounding-pb-u-deploy-'+str(number)+'.stdout')).write_bytes(result.stdout)
    (BASE/('drainage-rounding-pb-u-deploy-'+str(number)+'.stderr')).write_bytes(result.stderr)
    record['actual_commands'].append(dict(command=command,actual_returncode=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
    record['actual_exit']=result.returncode
    target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
record['dispatch']=json.loads(result.stdout)
record['finished_unix']=time.time()
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['dispatch']))

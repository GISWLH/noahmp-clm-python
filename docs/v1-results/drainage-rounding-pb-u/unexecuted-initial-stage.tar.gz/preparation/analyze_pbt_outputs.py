"""EHPC-only numerical inspection of closed PB-t captures; no physical calls."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import socket
import tarfile
import time

import numpy as np

sha=lambda raw:hashlib.sha256(raw).hexdigest()
FIELDS=('main_theta_m','frost_m_or_zero','perched_m_or_zero','has_frost','has_perched',
    'transition_count','active_layers','main_rate_kg_m2_s','perched_rate_kg_m2_s',
    'main_ice_factor','perched_ice_factor','main_specific_yield','first_perched_donor_or_minus_one',
    *(f'main_weight[{k}]' for k in range(4)),*(f'perched_weight[{k}]' for k in range(4)),
    *(f'ice_fraction[{k}]' for k in range(4)),*(f'saturation[{k}]' for k in range(4)))
CASES=('frozen-float32','perched_stress-float32','option2-float32','two_bands-float32')

def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        return {m.name:archive.extractfile(m).read() for m in archive if m.isfile()}

def load(data,backend,case):
    prefix=backend+'/device/'+case+'/'
    meta=json.loads(data[prefix+'result.json']);raw=data[prefix+'result.npz']
    assert sha(raw)==meta['npz_sha256']
    with np.load(io.BytesIO(raw),allow_pickle=False) as packed:
        arrays={n:packed[n].copy() for n in packed.files}
    assert set(arrays)==set(meta['arrays'])
    for n,a in arrays.items():
        desc=meta['arrays'][n]
        assert a.dtype.str==desc['dtype'] and list(a.shape)==desc['shape']
        assert sha(a.tobytes(order='C'))==desc['c_order_sha256']
    return arrays

def differences(a,b):
    assert a.dtype==b.dtype==np.float32 and a.shape==b.shape and np.all(np.isfinite(a)) and np.all(np.isfinite(b))
    aa=a.reshape(-1);bb=b.reshape(-1);av=aa.view(np.uint32);bv=bb.view(np.uint32)
    rows=[]
    for k in np.flatnonzero(av!=bv):
        # Exact bit-distance on the monotone IEEE ordering, including signed zero.
        x=int(av[k]);y=int(bv[k]);ox=(~x&0xffffffff) if x&0x80000000 else x|0x80000000
        oy=(~y&0xffffffff) if y&0x80000000 else y|0x80000000
        rows.append(dict(flat_index=int(k),cuda=float(aa[k]),jax=float(bb[k]),
            cuda_bits=f'0x{x:08x}',jax_bits=f'0x{y:08x}',ulp_distance=abs(ox-oy),
            signed_difference=float(np.float64(aa[k])-np.float64(bb[k]))))
    return rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert socket.gethostname()=='compute002' and not a.output.exists()
    raw=a.input.read_bytes();assert sha(raw)=='69daf37ba4bdef8990de4325ba7bd3d8b38690adc4751fc0ae5f254cef669eea'
    data=unpack(raw);started=time.monotonic();rows=[]
    for case in CASES:
        cuda,jax=(load(data,b,case) for b in ('cuda','jax'))
        keys=('actual.phase_cells_before','actual.encoded_parameters','actual.phase_option','actual.duration_seconds')
        initial={n:cuda[n].dtype==jax[n].dtype and cuda[n].shape==jax[n].shape and cuda[n].tobytes()==jax[n].tobytes() for n in keys}
        assert all(initial.values())
        diagnoses={}
        for name in ('actual.diagnosis_before','actual.diagnosis_after_perched','actual.diagnosis_after'):
            assert cuda[name].shape==jax[name].shape==(1,29)
            dd=differences(cuda[name],jax[name])
            for d in dd:d['field']=FIELDS[d['flat_index']]
            diagnoses[name]=dd
        ledger={}
        for name in ('actual.layer_mass_kg_m2','actual.layer_enthalpy_j_m2','actual.energy_residual_j_m2',
            'actual.perched.layer_mass_kg_m2','actual.perched.layer_enthalpy_j_m2','actual.perched.energy_residual_j_m2',
            'actual.saturated.layer_mass_kg_m2','actual.saturated.layer_enthalpy_j_m2','actual.saturated.energy_residual_j_m2'):
            ledger[name]=differences(cuda[name],jax[name])
        final={n:cuda[n].tobytes()==jax[n].tobytes() for n in ('actual.cells','actual.phase_cells_after_perched','actual.phase_cells_final')}
        rows.append(dict(case=case,initial_byte_exact=initial,final_payload_byte_exact=final,diagnosis=diagnoses,ledger=ledger))
    report=dict(completed=True,seconds=time.monotonic()-started,input_sha256=sha(raw),physical_forward_calls=0,
        cases=rows,scope='Existing closed device outputs only: exact initial stock equality, earliest recorded29-field diagnosis differences and final ledger bit differences. This does not identify hidden intermediate operations or adaptive crossing cause.')
    a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(completed=True,cases=len(rows),physical_forward_calls=0)))

if __name__=='__main__':main()

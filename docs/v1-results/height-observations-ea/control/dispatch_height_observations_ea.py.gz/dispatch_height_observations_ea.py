from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'height-observations-ea';assert not r.exists();r.mkdir();controls={}
for name,target in [('evaluate_height_observations_ea.py','evaluate_height_observations_ea.py'),('height_observations_ea.pbs','height_observations_ea.pbs'),('height-observations-ea-package.json','package.json')]:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/target).write_bytes(raw);controls[target]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'height_observations_ea.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

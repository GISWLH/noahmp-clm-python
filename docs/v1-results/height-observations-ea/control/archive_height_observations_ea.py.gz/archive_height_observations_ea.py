from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'height-observations-ea';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and len(d['records'])==3 and all(v['predeclared_baseline'] and v['actual_returncode']==0 and sha(r/(v['site']+'-observations.json'))==v['result_sha256'] for v in d['records']);a=b/'height-observations-ea-evidence.tar.gz';assert not a.exists();items=[(p,'evaluation/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['height-observation-operators-ea.tar.gz','dispatch_height_observations_ea.py','prepare_height_observations_ea.py',Path(__file__).name])
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

"""Immutable export only after all actual targeted worker parents ended."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-iv-gpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'launch.json').read_text());assert all(sha(r/n)==h for n,h in launch['controls_sha256'].items());d=json.loads((r/'exit.json').read_text());assert d['failure'] is None and d['source_unchanged'] and len(d['records'])==5
for row in d['records']:
    stem=Path(row['file']).stem;p=r/(stem+'-receipt.json');q=json.loads(p.read_text());assert row['receipt_sha256']==sha(p) and q['source_unchanged'] and q['source_manifest_sha256']==d['source_manifest_sha256'] and q['xml_sha256']==sha(r/(stem+'.xml'))
    assert row['actual_parent_returncode']==q['worker_exitcode'] and q['expected_nodes_sha256']==sha(r/(stem+'-expected.json'))
s=Path(json.loads((r/'source-location.json').read_text())['source']);m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==581 and all(sha(s/n)==h for n,h in m.items());archive=b/'ballberry-iv-gpu-jd-evidence.tar.gz';assert not archive.exists();inventory={}
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(r.rglob('*')):
        if p.is_file():assert not p.is_symlink();n='gpu/'+p.relative_to(r).as_posix();inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
    for p,n in [(b/'clm-ballberry-iv-source.tar.gz','frozen-source/clm-ballberry-iv-source.tar.gz'),(Path(__file__),'control/'+Path(__file__).name)]:inventory[n]=sha(p);tf.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
value=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),passed=d['passed'],records=d['records'],scope='ActualownIV581 target37 allfivepytestfiles exactnodes/phases/XML/source/dtype/int/barriers, actualworkerparent exits preserved. RuntimeNumPyreferences deliveredfromEHPC1181,4historicalphasefixture referencecombinations unchanged. Originalscience10percent/raw1e-6/hardbudgets unchanged. Frozenallsource/control/rawlogs/XML/cacheinputs+references preserved; not full407/canonical1563/year/spinup/observational/release acceptance.');(b/'ballberry-iv-gpu-jd-package.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

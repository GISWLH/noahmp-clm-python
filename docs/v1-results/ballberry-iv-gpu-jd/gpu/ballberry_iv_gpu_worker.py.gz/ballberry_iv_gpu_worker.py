"""Unmodified original pytest nodes use exact EHPC references, never host physics."""
from pathlib import Path
import copy,hashlib,json,pickle,runpy,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-iv-gpu';s=Path(json.loads((r/'source-location.json').read_text())['source']);ref=r/'reference-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((r/'package.json').read_text());proof=json.loads((ref/'receipt.json').read_text());assert proof['passed'] and proof['source_unchanged'] and proof['source_manifest_sha256']==plan['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and (ref/'pbs-exit.txt').read_text().strip()=='0' and sha(ref/'references.pkl')==proof['references_sha256'] and sha(r/'ballberry_reference_key_iv.py')==proof['key_helper_sha256'];sys.path.insert(0,str(r))
from ballberry_reference_key_iv import key
cache=pickle.loads((ref/'references.pkl').read_bytes());assert len(cache)==proof['keys'];file=Path(sys.argv[sys.argv.index('--test-file')+1]).stem
def lookup(family,*args,**kwargs):
    signature=key(family,args,kwargs);assert signature in cache,(family,signature)
    with (r/(file+'-reference-requests.jsonl')).open('a') as f:f.write(json.dumps(dict(family=family,key=signature))+'\n')
    return copy.deepcopy(cache[signature])
def blocked(*args,**kwargs):raise AssertionError('NumPy forward physics belongs to EHPC1181, no GPUhost fallback')
if file=='test_gpu_photosynthesis':
    import test_gpu_photosynthesis as module
    module.ordinary=lambda *a,**k:lookup('leaf',*a,**k);module.leaf_gas_exchange=blocked
elif file=='test_gpu_canopy_energy':
    import test_gpu_canopy_energy as module
    module.numpy_reference=lambda *a,**k:lookup('canopy',*a,**k);module.solve_canopy_energy=blocked
elif file=='test_gpu_canopy_phase_energy':
    import test_gpu_canopy_phase_energy as module
    module.reference=lambda *a,**k:lookup('phase',*a,**k);module.solve_canopy_phase_energy=blocked
elif file=='test_gpu_clm_enthalpy_column':
    import test_gpu_clm_enthalpy_column as module
    module.reference=lambda *a,**k:lookup('enthalpy',*a,**k);module.step_clm_enthalpy_column=blocked
elif file=='test_gpu_clm_layered_column':
    import test_gpu_clm_layered_column as module
    module.reference=lambda *a,**k:lookup('layered',*a,**k);module.step_clm_enthalpy_column=blocked
else:raise AssertionError(file)
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076';runpy.run_path(str(worker),run_name='__main__')

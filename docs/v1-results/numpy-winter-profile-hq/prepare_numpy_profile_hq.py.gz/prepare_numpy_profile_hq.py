from pathlib import Path
import hashlib
import json
import subprocess
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'numpy-winter-profile-hq'
assert not root.exists()
root.mkdir()
controls = {}
for name in ['profile_winter_step_hq.py', 'numpy_winter_profile_hq.pbs']:
    raw = (base / name).read_bytes()
    assert b'\r\n' not in raw
    (root / name).write_bytes(raw)
    controls[name] = hashlib.sha256(raw).hexdigest()
p = subprocess.run(['qsub', str(root / 'numpy_winter_profile_hq.pbs')], cwd=root, capture_output=True, text=True)
assert p.returncode == 0, p.stderr
record = dict(pbs_job=p.stdout.strip(), controls_sha256=controls,
    scope='StandaloneonefixedJan3localnoonoriginalsuccessfulstep cProfile on PBScompute only, no inline/model/liveyear changes; rawreturnedstate/diagnostics mustmatchoriginalbytes.')
(root / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

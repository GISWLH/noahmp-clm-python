"""Standalone cProfile of a fixed recorded step; frozen model never modified."""
from pathlib import Path
from dataclasses import fields, is_dataclass
import cProfile
import gzip
import hashlib
import json
import os
import pickle
import pstats
import struct
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'numpy-winter-profile-hq'
output = root / 'profile_output'
output.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner

prior = base / 'multisite-winter-energy-he'
assert (prior / 'pbs-exit.txt').read_text().strip() == '0'
receipt = json.loads((prior / 'receipt.json').read_text())
case = 'CN-Qia-2003-field-capacity-hydraulic-clim'
row = next(q for q in receipt['cases'] if q['case'] == case)
assert receipt['passed'] and receipt['source_unchanged'] and row['failure'] is None
assert all(row['full_original_trace_fields_byteexact'].values())
archive = prior / case / 'steps.tar.gz'
assert sha(archive) == row['step_packet_archive_sha256']
with tarfile.open(archive) as tf:
    raw = tf.extractfile('call-00024.pkl.gz').read()
(root / 'original-step-input-output.pkl.gz').write_bytes(raw)
packet = pickle.loads(gzip.decompress(raw))
expected = dict(after=packet['after'], diagnostics=packet['diagnostics'])
profile = cProfile.Profile()
start = time.monotonic()
profile.enable()
after, diagnostics = runner.step_clm_enthalpy_column(packet['before'], packet['forcing'], **packet['kwargs'])
profile.disable()
elapsed = time.monotonic() - start
profile.dump_stats(output / 'step.cprofile')
with (output / 'cumulative.txt').open('x') as stream:
    pstats.Stats(profile, stream=stream).strip_dirs().sort_stats('cumulative').print_stats(35)
with (output / 'self-time.txt').open('x') as stream:
    pstats.Stats(profile, stream=stream).strip_dirs().sort_stats('tottime').print_stats(35)
leaves = 0


def equal(a, b, name='root'):
    global leaves
    if is_dataclass(a):
        assert type(a) is type(b), name
        for field in fields(a):
            equal(getattr(a, field.name), getattr(b, field.name), name + '/' + field.name)
    elif isinstance(a, dict):
        assert isinstance(b, dict) and a.keys() == b.keys(), name
        for key in a:
            equal(a[key], b[key], name + '/' + str(key))
    elif isinstance(a, (list, tuple)):
        assert type(a) is type(b) and len(a) == len(b), name
        for k, (x, y) in enumerate(zip(a, b)):
            equal(x, y, name + '/' + str(k))
    elif isinstance(a, (np.ndarray, np.generic)):
        x, y = np.asarray(a), np.asarray(b)
        assert x.dtype == y.dtype and x.shape == y.shape and x.tobytes() == y.tobytes(), name
        leaves += 1
    elif isinstance(a, float):
        assert isinstance(b, float) and struct.pack('d', a) == struct.pack('d', b), name
        leaves += 1
    else:
        assert type(a) is type(b) and a == b, name
        leaves += 1


equal(expected, dict(after=after, diagnostics=diagnostics))
stats = pstats.Stats(profile)
hotspots = []
for (filename, line, function), (primitive, calls, own, cumulative, _) in stats.stats.items():
    if 'noahmp' in filename or filename.endswith('run_fluxnet_column.py'):
        hotspots.append(dict(file=str(Path(filename).relative_to(source)) if str(filename).startswith(str(source)) else filename,
            line=line, function=function, primitive_calls=primitive, calls=calls,
            self_seconds=own, cumulative_seconds=cumulative))
hotspots.sort(key=lambda q: q['cumulative_seconds'], reverse=True)
result = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True,
    case=case, recorded_cycle_local_index=120, fixed_selection='Original Jan3 localnoon, recordedcall24, no observedscore selection',
    source_manifest_sha256=source_sha, source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    exact_returned_state_diagnostic_leaves=leaves, packet_sha256=sha(root / 'original-step-input-output.pkl.gz'),
    profiled_wall_seconds=elapsed, total_calls=stats.total_calls, primitive_calls=stats.prim_calls,
    profiler_total_seconds=stats.total_tt, hotspots=hotspots,
    instrumentation_changelog=[dict(file='profile_winter_step_hq.py', change='New standalone cProfile wrapper only'),
        dict(file='profile_output/step.cprofile', change='New profiler data'),
        dict(file='profile_output/cumulative.txt', change='New sorted cumulative report'),
        dict(file='profile_output/self-time.txt', change='New sorted self-time report')],
    scope='One independent originalsuccessful recordedphysicalstep on EHPCcompute node, allreturnedstate/diagnosticvalues checkedbyteexact to archivedoriginal. Timing includescProfileoverhead, not a controlled performance baseline/speedup/wholeyear or scientificacceptance claim. No inlineinstrumentation/model/source/inputs/state/ongoingyear modification; standaloneprofilecopy can be removed independently.')
(root / 'receipt.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'hotspots'}), flush=True)
print(json.dumps(hotspots[:12]), flush=True)
assert result['source_unchanged']

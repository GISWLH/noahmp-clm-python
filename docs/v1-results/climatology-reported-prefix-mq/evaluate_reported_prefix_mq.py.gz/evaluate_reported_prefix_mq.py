"""Diagnostic only: original running 2640 snapshot before a failed year.

Uses the existing evaluation function, never its complete-year CLI or a
rewritten manifest. Complete January and complete days retain all products;
partial February and the unfinished original year remain unmeasured.
"""
from pathlib import Path
import gzip,hashlib,json,math,os,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=Path.cwd();tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();d=tmp/'device';d.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();started=time.monotonic()
a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and len(m)==581 and all(sha(s/n)==h for n,h in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
from evaluate_fluxnet_series import evaluate,PRODUCTS,CARBON_G_PER_UMOL
from fluxnet_soil_operator import initial_soil_from_manifest
from compare_hrldas_native_year import check_ledgers,check_final_checkpoint
a=b/'climatology-failed-year-mh-export.tar.gz';assert sha(a)=='f728890bfe81cddae1d85ae2effa69e4eb541b6f1e9ba12b335f90374d098340'
with tarfile.open(a) as t:t.extractall(d,filter='data')
snap=json.loads((d/'snapshot.json').read_text());parent=json.loads((d/'actual-year-parent/exit.json').read_text());assert snap['actual_year_parent_returncode']==parent['actual_parent_returncode']==1 and not parent['passed'] and snap['failed_attempt_index']==2657
assert (d/'source/SOURCE_SHA256.json').read_bytes()==(s/'SOURCE_SHA256.json').read_bytes();cases=native.load_batch(d/'inputs/batch.json');assert len(cases)==12
operators={'CN-Cng':'0a9b838cc545e1976d55a00bf019b5ebc2ea086726f7ed993a1e0d07d2d7cd78','CN-Qia':'49ff2b416241d3f58bdbb73f4d91ba19a81f3b0357ba2cebbffed904415f7095','CN-Cha':'56b41a9c173f28c56f71b453a15626dac329d443582cdc2d5080428180ce91ac'}
results=[];failure=None
try:
    for k,case in enumerate(cases):
        name=case['case'];folder=d/'reported2640'/name;reports=list(folder.glob('report-0002640-*.json'));assert len(reports)==1;p=reports[0];raw=p.read_bytes();report=json.loads(raw);assert report['case']==name and report['batch_column']==k and report['status']=='running' and report['source_unchanged'] and report['steps_completed']==2640 and report['steps_requested']==17520 and report['source_sha256']==native.source_hashes() and report['configuration']==case['config']
        assert all(report[key]==sha(case['paths'][path]) for key,path in [('forcing_npz_sha256','input'),('forcing_manifest_sha256','input_manifest'),('configuration_sha256','configuration')])
        assert report['time_convention']=='local standard time' and report['utc_offset_hours']==case['metadata']['utc_offset_hours']==8
        trace_path=folder/report['model_npz'];checkpoint=folder/report['batch_checkpoint_file'];assert sha(trace_path)==report['model_npz_sha256'] and sha(checkpoint)==report['batch_checkpoint_sha256']
        with np.load(trace_path,allow_pickle=False) as z:trace=dict(z)
        with np.load(case['paths']['input'],allow_pickle=False) as z:observed={key:v[:2640] for key,v in z.items()}
        assert len(trace['time_start'])==2640 and str(trace['time_start'][0]).endswith('01010000') and str(trace['time_end'][-1]).endswith('02250000')
        ledgers=check_ledgers(trace,report);stocks=check_final_checkpoint(checkpoint,trace,report);op=b/'height-observations-ea'/(report['site']+'-soil-operator.json');assert sha(op)==operators[report['site']];operator=json.loads(op.read_text());initial=initial_soil_from_manifest(report)
        metrics=evaluate(trace,observed,utc_offset_hours=8,soil_operator=operator,initial_soil=initial)
        assert len(metrics['daily'])==55 and len(metrics['monthly'])==2
        january=next(key for key in metrics['monthly'] if key.endswith('-01'));february=next(key for key in metrics['monthly'] if key.endswith('-02'))
        assert all(v['calendar_period_complete'] for v in metrics['monthly'][january].values()) and all(not v['calendar_period_complete'] and v['metrics']['status']=='unmeasured' for v in metrics['monthly'][february].values())
        assert all(v['calendar_period_complete'] for day in metrics['daily'].values() for v in day.values())
        checks=0;labels=np.asarray(trace['time_start'],str)
        for frequency,width in [('daily',8),('monthly',6)]:
            for date,records in metrics[frequency].items():
                selected=np.flatnonzero(np.asarray([v[:width]==date.replace('-','') for v in labels]))
                for field,(key,_,carbon) in PRODUCTS.items():
                    row=records[field]
                    if 'model_integral' not in row:continue
                    model=math.fsum(map(float,np.asarray(trace[key],float)[selected]))*(1. if carbon else 1800.)
                    reference=math.fsum(map(float,np.asarray(observed['obs_'+field],float)[selected]))*1800.*(CARBON_G_PER_UMOL if carbon else 1.)
                    assert math.isclose(model,row['model_integral'],rel_tol=1e-12,abs_tol=1e-9) and math.isclose(reference,row['reference_integral'],rel_tol=1e-12,abs_tol=1e-9);checks+=1
        metrics.update(original_report_status='running',original_year_actual_parent_returncode=1,original_requested_steps=17520,snapshot_steps=2640,annual=dict(status='unmeasured',bias_pass=None,correlation_pass=None,reason='Original year failed at 2657; this immutable prior running snapshot is diagnostic only'),scope=__doc__)
        for month in range(3,13):metrics['monthly'][january[:4]+'-'+str(month).zfill(2)]={key:dict(metrics=dict(status='unmeasured',bias_pass=None,correlation_pass=None,reason='Future model intervals unavailable')) for key in metrics['instantaneous']}
        sub=r/name;sub.mkdir();(sub/'original-report.json').write_bytes(raw);(sub/'soil-operator.json').write_bytes(op.read_bytes());text=(json.dumps(metrics,indent=2,allow_nan=False)+'\n').encode();packed=gzip.compress(text,mtime=0);assert gzip.decompress(packed)==text;(sub/'observations.json.gz').write_bytes(packed)
        summary=dict(case=name,site=report['site'],original_report_status='running',original_year_actual_parent_returncode=1,snapshot_steps=2640,original_requested_steps=17520,complete_days=55,complete_months=1,annual_unmeasured=True,source_manifest_sha256=manifest,original_report_sha256=sha(p),original_trace_sha256=sha(trace_path),original_checkpoint_sha256=sha(checkpoint),forcing_sha256=sha(case['paths']['input']),configuration_sha256=sha(case['paths']['configuration']),soil_operator_sha256=sha(op),observation_results_sha256=hashlib.sha256(text).hexdigest(),independent_stored_m_h_c_n=ledgers,independent_final_extensive_stock=stocks,independent_raw_integral_checks=checks,january=metrics['monthly'][january],instantaneous={key:v['metrics'] for key,v in metrics['instantaneous'].items()},scope=__doc__)
        (sub/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');results.append(summary);print(json.dumps(dict(case=name,delivered=True,checks=checks)),flush=True)
except Exception as e:failure=type(e).__name__+': '+str(e);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,evaluation_delivered=failure is None and len(results)==12,failure=failure,cases=results,seconds=time.monotonic()-started,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),scope=__doc__);(r/'receipt.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True);raise SystemExit(0 if out['evaluation_delivered'] and out['source_unchanged'] else 1)

from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s, r = b / 'p6-most-physical-c', b / 'qia-cuda-3798-a'
out = r / 'general-edge-jax-f'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver
import noahmp_clm.gpu.canopy_phase_energy as module
import inspect
import jax

binding = json.loads((r / 'binding.json').read_text())
assert sha(r / 'input.npz') == binding['input_sha256']
with np.load(r / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
engine = driver.Backend('jax32')
before = engine.update_forcing(tuple(engine.xp.asarray(data['a' + str(k)]) for k in range(19)), data['environment'])
old = tuple(engine.host(v) for v in before)
original = module.phase_energy_kernel_jax
source = inspect.getsource(original)
marker = '        slow=(~accepted)|(chosen_norm>s(.999*norm))'
assert source.count(marker) == 1
addition = """        # Isolated all-phase-edge strict-descent numerical hypothesis F.
        edges=j.stack((j.zeros(10,u.dtype),j.full(10,plateau,u.dtype)),axis=1)
        direction=delta[:10]
        fractions=s(edges-x[:10,None])/j.where(direction[:,None]!=0.,direction[:,None],1.)
        eligible=phase_active[:,None]&(direction[:,None]!=0.)&(fractions>0.)&(fractions<=1.)
        scores=j.where(eligible,fractions,j.asarray(2.,u.dtype)).reshape(20)
        selected=j.argmin(scores);alpha=scores[selected]
        def phase_edge_trial(_):
            candidate=j.clip(s(x+s(delta*alpha)),lo_bound,hi_bound)
            candidate=candidate.at[selected//2].set(j.where(selected%2==0,j.asarray(0.,u.dtype),plateau))
            rr,_=evaluate(candidate,phase_active);event_norm=_dot(rr,rr)
            good=event_norm<chosen_norm
            return j.where(good,candidate,trial),accepted|good,j.where(good,event_norm,chosen_norm)
        trial,accepted,chosen_norm=lax.cond(alpha<=1.,phase_edge_trial,lambda _:(trial,accepted,chosen_norm),operand=None)
"""
candidate = source.replace(marker, addition + marker)
namespace = dict(original.__globals__)
exec(compile(candidate, '<isolated JAX general-phase-edge F>', 'exec'), namespace)
module.phase_energy_kernel_jax = namespace['phase_energy_kernel_jax']
(out / 'phase-original.py').write_text(source)
(out / 'phase-candidate.py').write_text(candidate)
start, failure, result = time.monotonic(), None, None
try:
    value = engine.step(*before, data['forcing'], environment=data['calendar_values'], calendar=data['calendar_flags'],
                        nitrogen_deposition_gn_m2=data['nitrogen'], deposition=data['deposition'], most_geometry=data['geometry'],
                        leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']), return_surface=True)
    host = engine.host(value)
    after = tuple(engine.host(v) for v in driver.next_station_arrays(before, value))
    flat = {}
    def flatten(value, prefix=''):
        for name, v in value.items():
            if isinstance(v, dict):
                flatten(v, prefix + name + '/')
            else:
                flat[prefix + name] = np.asarray(v)
    flatten(host)
    np.savez_compressed(out / 'output.npz', **flat)
    np.savez_compressed(out / 'state.npz', **{'a' + str(k): v for k, v in enumerate(after)})
    result = dict(fields=len(flat), diagnostics={k: np.asarray(v).tolist() for k, v in host['diagnostics'].items()},
                  output_sha256=sha(out / 'output.npz'), state_sha256=sha(out / 'state.npz'))
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (out / 'traceback.txt').write_text(traceback.format_exc())
finally:
    module.phase_energy_kernel_jax = original
jax.effects_barrier()
assert all(sha(s / n) == h for n, h in m.items()) and all(np.array_equal(v, engine.host(w)) for v, w in zip(old, before))
record = dict(scope='Isolated JAX32 counterpart of NumPy/CUDA F all-phase-edge strict-descent hypothesis. Exact original3798 input and original100/.005;allraw1e-6 comparison/independent budgets deferred EHPC. Original phase100/.005 and all production final checks retained; no production source change or acceptance of failed year. Full raw outputs exported for independent EHPC MHCN acceptance; no NumPy forward physics/audit on xuanze. Not JAX parity/current canonical/year/science pass. Atexit bypass after explicit barrier/receipt.',
              failure=failure, result=result, seconds=time.monotonic() - start, source_unchanged=True, input_unchanged=True,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), input_sha256=binding['input_sha256'],
              original_phase_sha256=sha(out / 'phase-original.py'), candidate_phase_sha256=sha(out / 'phase-candidate.py'), device_barrier_complete=True)
(out / 'receipt.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)
os._exit(0 if failure is None else 1)

from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'qia-cuda-3798-a'
start = time.monotonic()
with (r / 'general-edge-jax-f.log').open('x') as log:
    p = subprocess.Popen([sys.executable, '-u', str(b / 'probe_qia3798_general_edge_jax_f.py')], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    (r / 'general-edge-jax-worker-f.json').write_text(json.dumps(dict(pid=p.pid), indent=2) + '\n')
    code = p.wait()
receipt = r / 'general-edge-jax-f/receipt.json'
record = dict(actual_returncode=code, seconds=time.monotonic() - start, receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None)
(r / 'general-edge-jax-exit-f.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(code)

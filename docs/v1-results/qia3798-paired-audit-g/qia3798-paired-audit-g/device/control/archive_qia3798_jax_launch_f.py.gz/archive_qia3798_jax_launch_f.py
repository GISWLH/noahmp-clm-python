from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import subprocess
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'qia-cuda-3798-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
launch = json.loads((r / 'general-edge-jax-launch-f.json').read_text())
worker = json.loads((r / 'general-edge-jax-worker-f.json').read_text())
for n, digest in launch['control_sha256'].items():
    assert sha(b / n) == digest
ps = subprocess.run(['ps', '-p', str(worker['pid']), '-o', 'pid,stat,etime,args'], capture_output=True, text=True)
assert ps.returncode == 0 and 'probe_qia3798_general_edge_jax_f.py' in ps.stdout
assert not (r / 'general-edge-jax-exit-f.json').exists()
a = b / 'qia3798-jax-launch-f-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for n in ['general-edge-jax-launch-f.json', 'general-edge-jax-worker-f.json']:
        t.add(r / n, arcname=n, recursive=False)
    controls = {}
    for n in ['probe_qia3798_general_edge_jax_f.py', 'control_qia3798_jax_f.py', 'launch_qia3798_jax_f.py', 'archive_qia3798_jax_launch_f.py']:
        t.add(b / n, arcname='control/' + n, recursive=False); controls[n] = sha(b / n)
    for n in ['phase-original.py', 'phase-candidate.py']:
        t.add(r / 'general-edge-jax-f' / n, arcname='candidate/' + n, recursive=False)
    summary = dict(scope='Actual live JAX32 general-phase-edge F counterpart after NumPy reference/CUDA independent-hard-audit evidence. Exact originalfailed3798 input,source509C,original100/.005/no sourcefiles altered;allraw1e-6 and independent full budgets pending. No actual exit/canonical/year/science pass claimed. Background worker original candidate control files frozen after launch.',
                   utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), controller_pid=launch['pid'], worker_pid=worker['pid'], process_snapshot=ps.stdout,
                   controls_sha256=controls, original_input_sha256=sha(r / 'input.npz'), source_manifest_sha256='1c68b4f6f18c6b89610a1a53a4f2ba864dc0beb39e6c7f7dc4dc36a5a111f74a')
    raw = (json.dumps(summary, indent=2) + '\n').encode(); item = tarfile.TarInfo('summary.json'); item.size = len(raw); t.addfile(item, io.BytesIO(raw))
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size)))

#loc1 = loc("a")
module @jit__reduce_max attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<4xf32> loc("a")) -> (tensor<f32> {jax.result_info = "result"}) {
    %cst = stablehlo.constant dense<0xFF800000> : tensor<f32> loc(#loc4)
    %0 = stablehlo.reduce(%arg0 init: %cst) applies stablehlo.maximum across dimensions = [0] : (tensor<4xf32>, tensor<f32>) -> tensor<f32> loc(#loc4)
    return %0 : tensor<f32> loc(#loc5)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/lhwang/work/noahmp-v1/probe_richards_controller_p.py":20:30 to :46)
#loc3 = loc("<module>"(#loc2))
#loc4 = loc("jit(_reduce_max)/reduce_max"(#loc3))
#loc5 = loc("jit(_reduce_max)"(#loc3))

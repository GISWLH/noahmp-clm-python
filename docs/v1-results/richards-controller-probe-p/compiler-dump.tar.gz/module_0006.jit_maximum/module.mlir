#loc1 = loc("x")
#loc2 = loc("y")
module @jit_maximum attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<4xf32> loc("x"), %arg1: tensor<4xf32> loc("y")) -> (tensor<4xf32> {jax.result_info = "result"}) {
    %0 = stablehlo.maximum %arg0, %arg1 : tensor<4xf32> loc(#loc5)
    return %0 : tensor<4xf32> loc(#loc6)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc3 = loc("/home/lhwang/work/noahmp-v1/probe_richards_controller_p.py":18:111 to :168)
#loc4 = loc("<module>"(#loc3))
#loc5 = loc("jit(maximum)/max"(#loc4))
#loc6 = loc("jit(maximum)"(#loc4))

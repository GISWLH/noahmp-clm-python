#loc1 = loc("args[0]")
module @jit_stage attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<4xf32> loc("args[0]")) -> (tensor<4xf32> {jax.result_info = "result"}) {
    return %arg0 : tensor<4xf32> loc(#loc4)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/lhwang/work/noahmp-v1/probe_richards_controller_p.py":18:31 to :44)
#loc3 = loc("<module>"(#loc2))
#loc4 = loc("jit(stage)"(#loc3))

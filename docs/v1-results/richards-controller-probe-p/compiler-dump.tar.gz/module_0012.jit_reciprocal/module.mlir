#loc1 = loc("x")
module @jit_reciprocal attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<4xf32> loc("x")) -> (tensor<4xf32> {jax.result_info = "result"}) {
    %cst = stablehlo.constant dense<1.000000e+00> : tensor<f32> loc(#loc4)
    %0 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<4xf32> loc(#loc4)
    %1 = stablehlo.divide %0, %arg0 : tensor<4xf32> loc(#loc4)
    return %1 : tensor<4xf32> loc(#loc5)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/lhwang/work/noahmp-v1/probe_richards_controller_p.py":18:216 to :234)
#loc3 = loc("<module>"(#loc2))
#loc4 = loc("jit(reciprocal)/integer_pow"(#loc3))
#loc5 = loc("jit(reciprocal)"(#loc3))

#loc1 = loc("x")
module @jit_abs attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<4xf32> loc("x")) -> (tensor<4xf32> {jax.result_info = "result"}) {
    %0 = stablehlo.abs %arg0 : tensor<4xf32> loc(#loc4)
    return %0 : tensor<4xf32> loc(#loc5)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/lhwang/work/noahmp-v1/probe_richards_controller_p.py":18:80 to :101)
#loc3 = loc("<module>"(#loc2))
#loc4 = loc("jit(abs)/abs"(#loc3))
#loc5 = loc("jit(abs)"(#loc3))

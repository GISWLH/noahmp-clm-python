from pathlib import Path
import hashlib,json,sys,tarfile
cpu=Path('/home/zhangyq/noahmp-v1');b=cpu if cpu.exists() else Path('/home/lhwang/work/noahmp-v1');mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
options={
'p':('richards-controller-probe-p','richards-controller-probe-p',['probe_richards_controller_p.py','control_richards_controller_p.py','launch_richards_controller_p.py'],'phase-coordinate-native-b'),
'q':('richards-controller-candidate-q','richards-controller-candidate-q',['probe_richards_controller_q.py','control_richards_controller_q.py','launch_richards_controller_q.py'],'phase-coordinate-native-b'),
'phase-b':('phase-coordinate-native-b','phase-coordinate-native-b/target-a',['collect_phase_coordinate_b.py','control_phase_coordinate_b.py','launch_phase_coordinate_b.py'],'phase-coordinate-native-b'),
'native-c':('clm-numerical-recovery-c-native','clm-numerical-recovery-c/target-a',['collect_numerical_recovery_c.py','control_numerical_recovery_c.py','launch_numerical_recovery_c.py'],'clm-numerical-recovery-c'),
'cpu-b':('phase-coordinate-cpu-b','phase-coordinate-cpu-b',['dispatch_phase_coordinate_cpu_b.py'],'phase-coordinate-native-b'),
'cpu-c':('numerical-recovery-cpu-c','numerical-recovery-cpu-c',['dispatch_numerical_recovery_cpu_c.py'],'clm-numerical-recovery-c')}
name,folder,controls,source=options[mode];r=b/folder
if mode.startswith('cpu-'):
    d=json.loads((r/'full-receipt.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1071,failures=0,errors=0,skipped=0) and d['xml_sha256']==sha(r/'full.xml')
else:
    e=json.loads((r/'exit.json').read_text());assert e['returncode']==0 and e['passed']
    if mode=='native-c':assert e['source_unchanged'] and len(e['records'])==2 and all(x['passed'] for x in e['records'])
    else:
        d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and e['receipt_sha256']==sha(r/'receipt.json')
        if mode!='p':assert d['counts']==dict(tests=4,failures=0,errors=0,skipped=0) and d['passed'] and d['xml_sha256']==sha(r/'tests.xml')
if (r/'xla-dump').exists():
    paths=sorted(p for p in (r/'xla-dump').rglob('*') if p.is_file());(r/'dump-SHA256.json').write_text(json.dumps({p.relative_to(r/'xla-dump').as_posix():sha(p) for p in paths},indent=2)+'\n')
    with tarfile.open(r/'compiler-dump.tar.gz','w:gz') as t:
        for p in paths:t.add(p,arcname=p.relative_to(r/'xla-dump').as_posix(),recursive=False)
        t.add(r/'dump-SHA256.json',arcname='dump-SHA256.json',recursive=False)
a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file() and 'xla-dump' not in p.relative_to(r).parts:t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in [*controls,source+'-source.tar.gz',source+'-package.json',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,mode=mode)))

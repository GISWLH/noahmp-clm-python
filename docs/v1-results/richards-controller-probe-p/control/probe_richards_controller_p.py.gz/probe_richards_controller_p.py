from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'phase-coordinate-native-b';r=b/'richards-controller-probe-p';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s/'src')]
import cupy as cp
import jax
import jax.numpy as j
root=b/'richards-current-flow-n';d=json.loads((root/'receipt.json').read_text());assert d['source_unchanged'] and all(d['final_outputs_byte_exact'].values()) and sha(root/'flow-and-systems.npz')==d['payload_sha256']
with np.load(root/'flow-and-systems.npz',allow_pickle=False) as z:data=dict(z)
source='extern "C" __global__ void reciprocal_probe(const float* v,float* out){int i=threadIdx.x;if(i<4){out[i]=1.f/v[i];out[4+i]=__frcp_rn(v[i]);}}'
module=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false'),name_expressions=('reciprocal_probe',));kernel=module.get_function('reciprocal_probe');results={};records=[];start=time.monotonic()
for index in [0,3,6,9,12,15]:
    base=data['cuda/'+str(index)+'/old'];coarse=data['cuda/'+str(index)+'/raw'][:4];fine=data['cuda/'+str(index+2)+'/raw'][:4]
    for key in ['old','raw']:
        for k in ([index] if key=='old' else [index,index+2]):assert data['cuda/'+str(k)+'/'+key].tobytes()==data['jax/'+str(k)+'/'+key].tobytes()
    fields={}
    for backend,xp in [('cuda',cp),('jax',j)]:
        current,coarse_,fine_=[xp.asarray(x) for x in (base,coarse,fine)];error=xp.abs(fine_-coarse_);tendency=xp.maximum(xp.abs(fine_-current),xp.abs(coarse_-current));scaled=.01*tendency;tol=.002+scaled;reciprocal=xp.reciprocal(tol);weighted=error*reciprocal
        for key,value in [('error',error),('tendency',tendency),('scaled',scaled),('tolerance',tol),('reciprocal',reciprocal),('weighted',weighted)]:results[str(index)+'/'+backend+'/'+key]=value.get() if hasattr(value,'get') else np.asarray(value)
        fields[backend]=float(xp.max(weighted))
    probe=cp.empty(8,cp.float32);kernel((1,),(4,),(cp.asarray(results[str(index)+'/cuda/tolerance']),probe));error=cp.asarray(results[str(index)+'/cuda/error'])
    results[str(index)+'/cuda/approximate_reciprocal']=cp.asnumpy(probe[:4]);results[str(index)+'/cuda/rounded_reciprocal']=cp.asnumpy(probe[4:]);fields['cuda_explicit_approximate']=float(cp.max(error*probe[:4]));fields['cuda_explicit_rn']=float(cp.max(error*probe[4:]));records.append(dict(first_call=index,actual_device_ratios=fields))
np.savez_compressed(r/'controller.npz',**results);cp.cuda.runtime.deviceSynchronize();jax.effects_barrier();unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged
d=dict(scope='GPU-only read-only exact currentG common call0..17 adaptive error arithmetic; first later differing duration call18. Separate CUDA approximate/RN reciprocal probes are diagnostic only, no model edit, candidate trajectory or acceptance. Atexit bypass after barriers/durable receipt.',records=records,payload_sha256=sha(r/'controller.npz'),source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),device_barriers_complete=True,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

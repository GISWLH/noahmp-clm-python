"""Retain all64 reference calls, deduplicate only identical exactinput keys."""
from pathlib import Path
from dataclasses import fields,is_dataclass
import hashlib,json,os,pickle,sys,tarfile,xml.etree.ElementTree as ET
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'soil-stress-coupled-fq-reference';prior=b/'soil-stress-coupled-fl-cpu';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(a)=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==v for n,v in m.items());full=json.loads((prior/'full-receipt.json').read_text());assert full['returncode']==0 and full['source_unchanged'] and full['source_manifest_sha256']==manifest and full['counts']==dict(tests=1148,failures=0,errors=0,skipped=0) and sha(prior/'full.xml')==full['xml_sha256']=='862ff0e9563657047e2cd158b8da255d6afcb047c9d22472b29736640c29e6b5';assert (prior/'pbs-exit.txt').read_text().strip()=='1' and 'assert signature not in references' in (prior/'controller.log').read_text()
counts={k:sum(int(q.attrib[k]) for q in ET.parse(prior/'full.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};assert counts==full['counts']
for n in ['full-receipt.json','full.xml','full.log','full-collection.txt','targeted-receipt.json','targeted.xml','SOURCE_SHA256.json','package.json']:(r/n).write_bytes((prior/n).read_bytes())
(r/'original-full-job-exit.txt').write_bytes((prior/'pbs-exit.txt').read_bytes());(r/'original-cache-preparation-failure.log').write_bytes((prior/'controller.log').read_bytes());(r/'original-cache-preparation-control.py').write_bytes((prior/'run_water_stress_coupled_fl_cpu.py').read_bytes());assert (r/'SOURCE_SHA256.json').read_bytes()==(s/'SOURCE_SHA256.json').read_bytes()
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(r)]
from column_water_stress_key_fl import key
import test_gpu_clm_enthalpy_column as enthalpy
import test_gpu_clm_layered_column as layered

def equivalent(left,right):
    if is_dataclass(left):return type(left)==type(right) and all(equivalent(getattr(left,f.name),getattr(right,f.name)) for f in fields(left))
    if isinstance(left,dict):return left.keys()==right.keys() and all(equivalent(v,right[k]) for k,v in left.items())
    if isinstance(left,(tuple,list)):return type(left)==type(right) and len(left)==len(right) and all(equivalent(a,b) for a,b in zip(left,right))
    if left is None:return right is None
    x,y=np.asarray(left),np.asarray(right)
    return x.dtype==y.dtype and x.shape==y.shape and bool(np.array_equal(x,y,equal_nan=True) if x.dtype.kind in 'fc' else np.array_equal(x,y))

cache={};inputs={};requests=[]
for family,module in [('enthalpy',enthalpy),('layered',layered)]:
    for dtype in [np.float32,np.float64]:
        arrays,forcing,deposition=module.cases(dtype);assert len(forcing)==16;inputs[family+'-'+np.dtype(dtype).name]=dict(arrays=arrays,forcing=forcing,deposition=deposition)
        for k,row in enumerate(zip(*arrays)):
            signature=key(family,row,forcing[k],deposition[k]);value=module.reference(row,forcing[k],deposition[k]);duplicate=signature in cache
            if duplicate:assert equivalent(value,cache[signature]),'Identicalinput reference must be bitexact/dtypeexact, never silently replaced'
            else:cache[signature]=value
            requests.append(dict(family=family,dtype=np.dtype(dtype).name,index=k,key=signature,duplicate=duplicate,reference_actually_executed=True))
assert len(requests)==64 and set(cache)=={q['key'] for q in requests};target=r/'references.pkl';target.write_bytes(pickle.dumps(cache,protocol=5));(r/'reference-inputs.pkl').write_bytes(pickle.dumps(inputs,protocol=5));(r/'reference-requests.json').write_text(json.dumps(requests,indent=2)+'\n');result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),keys=len(cache),requests=64,all64_reference_calls_actually_executed=True,duplicates_bitexact_checked=True,reference_pickle_sha256=sha(target),input_pickle_sha256=sha(r/'reference-inputs.pkl'),request_inventory_sha256=sha(r/'reference-requests.json'),key_helper_sha256=sha(r/'column_water_stress_key_fl.py'),full_cpu_job='442.manager',full_pytest_returncode=0,full_cpu_job_wrapper_exit=1,scope='CurrentFL source unchanged. Actualfull1148 session0/XML/source verified; original442 wrapper1 was duplicatekey bookkeeping after successfultests. Newreferencejob executes all64 originalcalls, repeatedexactinputs re-evaluated and dtype/bytevalue checked, unique cacheentries explicitlycounted. No originaltest/input/science/1e-6 changes or repeatedfullCPU suite.');(r/'reference-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert result['source_unchanged']

from pathlib import Path
import datetime,hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=base/'full-worker-d-deferred-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
names=[(root/n,n) for n in ['launch.json','progress.json','launch_deferred_most_full_gpu_d.py','controller.log']]
names.extend([(source/'run_most_full_gpu_d.py','run_most_full_gpu_d.py'),(source/'full-worker-preflight-d/selection.json','preflight-selection.json'),(base/'archive_full_d_deferred_a.py','archive_full_d_deferred_a.py')])
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Deferred runner setup/preflight only. GPU C remains live; D has not executed a test. Original successful files will be reused only after original terminal receipts/XML/node/source checks. Repository root will be present in PYTHONPATH.',source_unchanged=True,runner_sha256=sha(source/'run_most_full_gpu_d.py'),preflight_sha256=sha(source/'full-worker-preflight-d/selection.json'))
(root/'archive-binding-a.json').write_text(json.dumps(value,indent=2)+'\n');names.append((root/'archive-binding-a.json','archive-binding-a.json'))
archive=base/'full-d-deferred-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,name in names:t.add(p,arcname=name,recursive=False)
print(json.dumps(dict(files=len(names),archive=str(archive),sha256=sha(archive))))

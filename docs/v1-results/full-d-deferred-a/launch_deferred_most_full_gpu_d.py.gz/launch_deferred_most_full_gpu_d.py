from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';root=base/'full-worker-d-deferred-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    command=[sys.executable,'-u',str(root/Path(__file__).name),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    value=dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Wait for full C terminal summary, then preserve successful exact original files and retry only missing files with repository root in PYTHONPATH. No physics/test/tolerance modifications.',command=command)
    (root/'launch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(0)
launch=json.loads((source/'full-worker-c-launch.json').read_text());pid=launch['pid'];assert pid==4093667
path=Path('/proc')/str(pid);begun=time.monotonic();start=None
if path.exists():
    command=(path/'cmdline').read_bytes().split(b'\0');assert str(source/'run_most_full_gpu_c.py').encode() in command
    start=(path/'stat').read_text().rsplit(')',1)[1].split()[19]
while path.exists():
    stat=(path/'stat').read_text().rsplit(')',1)[1].split()
    assert stat[19]==start
    if stat[0]=='Z':break
    temp=root/'progress.json.tmp';temp.write_text(json.dumps(dict(status='waiting-for-original-c',pid=pid,seconds=time.monotonic()-begun),indent=2)+'\n');os.replace(temp,root/'progress.json');time.sleep(10)
summary=source/'full-by-file-c/summary.json';assert summary.is_file()
value=json.loads(summary.read_text());assert value['source_unchanged'] and value['collected_nodes']==1129
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[source,source/'src',source/'tests',source/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
command=[sys.executable,'-u',str(source/'run_most_full_gpu_d.py')]
with (root/'worker-controller.log').open('w') as log:p=subprocess.Popen(command,cwd=source,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(status='running-d',pid=p.pid,gpu=1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,runner_sha256=sha(source/'run_most_full_gpu_d.py'),previous_summary_sha256=sha(summary),repository_root_added_to_pythonpath=True)
(root/'actual-launch.json').write_text(json.dumps(record,indent=2)+'\n');(root/'progress.json').write_text(json.dumps(record,indent=2)+'\n');code=p.wait()
(root/'exit.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun),indent=2)+'\n');raise SystemExit(code)

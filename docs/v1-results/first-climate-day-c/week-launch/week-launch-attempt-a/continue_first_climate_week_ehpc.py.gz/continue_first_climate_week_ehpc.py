"""Resume hash-checked, trusted first-day NumPy states on an EHPC PBS node."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, time

root=Path('/home/zhangyq/noahmp-v1/fluxnet-first-climate-cycle-20261017-b')
source=Path('/home/zhangyq/noahmp-v1/p6-dry-condensation-b')
sys.path[:0]=[str(source/'src'),str(source/'benchmarks')]
from run_fluxnet_column import source_hashes
exe='/home/zhangyq/venvs/noahmp-closeout/bin/python'
cases=json.loads((root/'batch.json').read_text())['cases']
hashes=source_hashes()
for case in cases:
    out=root/'numpy-day'/case['case']
    report=json.loads((out/'report.json').read_text())
    assert report['source_sha256']==hashes
    assert report['steps_completed']==48 and report['status']=='running'
    for key,field in [('input','forcing_npz_sha256'),('input_manifest','forcing_manifest_sha256'),('configuration','configuration_sha256')]:
        assert hashlib.sha256(Path(case[key]).read_bytes()).hexdigest()==report[field]
    for key,field in [('checkpoint_file','checkpoint_sha256'),('model_npz','model_npz_sha256')]:
        assert hashlib.sha256((out/report[key]).read_bytes()).hexdigest()==report[field]

jobs=[]
for case in cases:
    log=(root/(case['case']+'-week.log')).open('wb')
    command=[exe,'-u','benchmarks/run_fluxnet_column.py','--input',case['input'],
        '--input-manifest',case['input_manifest'],'--config',case['configuration'],
        '--output',str(root/'numpy-day'/case['case']),'--resume','--stop-after','288']
    process=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
    log.close()
    jobs.append((process,case['case'],command))
launch=dict(scope='First 7 cold local days only, continuing exact original first-day NumPy state and cumulative independent ledgers. Not annual completion, converged spinup or observation acceptance.',
    source_root=str(source),source_sha256=hashes,host=os.uname().nodename,pbs_job=os.environ.get('PBS_JOBID'),
    start_time_unix=time.time(),jobs=[dict(pid=p.pid,case=case,command=command) for p,case,command in jobs])
(root/'week-launch.json').write_text(json.dumps(launch,indent=2)+'\n')
results=[dict(case=case,returncode=p.wait()) for p,case,command in jobs]
(root/'week-exit.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(0 if all(row['returncode']==0 for row in results) else 1)

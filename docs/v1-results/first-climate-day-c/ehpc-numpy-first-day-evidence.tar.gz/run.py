from pathlib import Path
import subprocess,json,os
r=Path('/home/zhangyq/noahmp-v1/fluxnet-first-climate-cycle-20261017-b');source=Path('/home/zhangyq/noahmp-v1/p6-dry-condensation-b');exe='/home/zhangyq/venvs/noahmp-closeout/bin/python';jobs=[]
for c in json.loads((r/'batch.json').read_text())['cases']:
 with (r/(c['case']+'.log')).open('w') as log:p=subprocess.Popen([exe,'-u','benchmarks/run_fluxnet_column.py','--input',c['input'],'--input-manifest',c['input_manifest'],'--config',c['configuration'],'--output',str(r/'numpy-day'/c['case']),'--stop-after','48'],cwd=source,stdout=log,stderr=subprocess.STDOUT)
 jobs.append((p,c['case']))
(r/'launch.json').write_text(json.dumps([dict(pid=p.pid,case=c) for p,c in jobs],indent=2)+'\n')
results=[dict(case=c,returncode=p.wait()) for p,c in jobs];(r/'exit.json').write_text(json.dumps(results,indent=2)+'\n');raise SystemExit(0 if all(x['returncode']==0 for x in results) else 1)

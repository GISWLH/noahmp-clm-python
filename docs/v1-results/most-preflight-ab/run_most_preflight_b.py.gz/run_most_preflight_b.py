from pathlib import Path
import hashlib,json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-most-oscillation-a'
receipt=root/'full-preflight-b-launch.json';assert not receipt.exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=str(root/'src')+':'+str(root/'tests')+':'+str(root/'benchmarks'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
command=['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_most_full_gpu_b.py'),'--preflight-only']
value=dict(command=command,scope='Collection only with the same CUDA library isolation and paths as the running target; no model or pytest execution. Original failed collection A retained.')
receipt.write_text(json.dumps(value,indent=2)+'\n')
with (root/'full-preflight-b-controller.log').open('w') as stream:
    code=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT).returncode
print(json.dumps(dict(returncode=code)));raise SystemExit(code)

from pathlib import Path
import os,subprocess,json,time
root=Path(__file__).resolve().parent;base=root.parent;out=base/'qia-soil-diagnostic-20261017-b'
exe='/home/lhwang/venvs/noahmp-phase3b/bin/python';env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:tests:benchmarks',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',CUDA_VISIBLE_DEVICES='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with (root/'numpy-target.log').open('wb') as log:
 r=subprocess.run([exe,'-m','pytest','tests/test_most_stagnation.py','tests/test_canopy_most.py','tests/test_clm_most_column.py','tests/test_molten_precipitation.py','-q','-s'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'numpy-target.json').write_text(json.dumps(dict(exit_code=r.returncode,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))))
if r.returncode:raise SystemExit(r.returncode)
with (root/'gpu-target.log').open('wb') as log:
 p=subprocess.Popen([exe,'-m','pytest','tests/test_gpu_most_stagnation.py','tests/test_gpu_clm_most_column.py','tests/test_gpu_molten_precipitation.py','-q','-s'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'gpu-launch.json').write_text(json.dumps(dict(pid=p.pid)))
env['CUDA_VISIBLE_DEVICES']='0'
with (out/'native.log').open('wb') as log:
 p=subprocess.Popen([exe,'-u','benchmarks/run_fluxnet_native.py','--batch',str(out/'batch.json'),'--output',str(out/'native-run')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/'launch.json').write_text(json.dumps(dict(pid=p.pid,source_directory=str(root),started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))))
print('native',p.pid,flush=True)

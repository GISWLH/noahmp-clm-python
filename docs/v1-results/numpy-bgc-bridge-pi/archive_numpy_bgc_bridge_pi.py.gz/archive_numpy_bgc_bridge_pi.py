"""Read-only collection after a real terminal job; no scheduler submission."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-numpy-bgc-bridge-pi')
STAGE = Path('/tmp/numpy-bgc-bridge-pi-stage.tar.gz')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def contents(raw):
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for member in archive:
            if member.isdir():
                continue
            name = member.name.removeprefix('./')
            assert member.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts and name not in files
            files[name] = archive.extractfile(member).read()
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', required=True)
    parser.add_argument('--stage-sha256', required=True)
    parser.add_argument('--label', default='numpy-bgc-bridge-pi')
    args = parser.parse_args()
    assert socket.gethostname() == 'manager' and re.fullmatch(r'\d+\.manager', args.job)
    assert re.fullmatch(r'[a-z0-9-]+', args.label)
    dispatch = json.loads((ROOT/'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == args.job and dispatch['stage_archive_sha256'] == args.stage_sha256
    query = subprocess.run(['qstat', '-xf', args.job], capture_output=True)
    assert query.returncode == 0
    qstat = query.stdout.decode()
    assert qstat.splitlines()[0] == 'Job Id: '+args.job and re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
    assert re.search(r'^\s*Stageout_status = 0\s*$', qstat, re.M)
    stage_raw = STAGE.read_bytes()
    assert sha(stage_raw) == args.stage_sha256
    stage = contents(stage_raw)
    index = json.loads(stage['stage-inventory.json'])
    assert set(index) == set(stage)-{'stage-inventory.json'}
    assert all(sha(stage[n]) == h == sha((ROOT/n).read_bytes()) for n,h in index.items())
    status = subprocess.run(['ssh', 'compute002', 'cat '+str(ROOT/'pbs-exit.txt')], capture_output=True)
    assert status.returncode == 0 and int(status.stdout.strip()) == code
    fetch = subprocess.run(['ssh', 'compute002', 'cat '+str(ROOT/'result.tar.gz')], capture_output=True)
    assert fetch.returncode == 0
    result = contents(fetch.stdout)
    receipt = json.loads(result['receipt.json'])
    assert int(result['worker-exit.txt'].strip()) == code
    assert receipt['pbs_job'] == args.job and receipt['node'] == 'compute002'
    zero_fields = ('decomposition_module_steps', 'coupled_column_steps', 'gpu_steps', 'solver_calls',
                   'candidate_scores_computed', 'complete_training_years_read', 'raw_observation_arrays_read')
    assert all(receipt[k] == 0 for k in zero_fields)
    if code == 0:
        assert receipt['passed'] and receipt['actual_test_count'] == 11
        assert receipt['test_parent_returncode'] == int(result['unittest-parent-exit.txt']) == 0
        assert receipt['test_timed_out'] is False
        statuses = json.loads(result['unittest-statuses.json'])
        assert len(statuses['statuses']) == 11 and all(value == 'ok' for _,value in statuses['statuses'])
        assert statuses['summary'] == [['11', str(receipt['actual_test_seconds'])]]
        assert receipt['source_before_after_584_exact'] and receipt['original_inputs_and_controls_unchanged']
        diagnostics = json.loads(result['diagnostics.json'])
        assert diagnostics['positive'] == receipt['positive_diagnostics']
        assert len(diagnostics['negative_errors']) == receipt['actual_negative_errors'] == 11
        for folder in ('preparation', 'execution', 'dependencies/pf', 'dependencies/os', 'dependencies/oy'):
            manifest = json.loads(stage[folder+'/CONTROLS_SHA256.json'])
            assert receipt[folder.replace('/', '_')+'_manifest_sha256'] == sha(stage[folder+'/CONTROLS_SHA256.json'])
            for name in [*manifest, 'CONTROLS_SHA256.json']:
                assert result[folder+'/'+name] == stage[folder+'/'+name]
    artifacts = {'current/'+name: raw for name,raw in result.items()}
    artifacts.update({'original-stage-inventory.json':stage['stage-inventory.json'],
        'original-stage-binding.json':(json.dumps(dict(archive=STAGE.name, sha256=args.stage_sha256,
            bytes=len(stage_raw), members=len(stage)), indent=2)+'\n').encode(),
        'original-result-binding.json':(json.dumps(dict(archive='result.tar.gz',sha256=sha(fetch.stdout),
            bytes=len(fetch.stdout),files=len(result)), indent=2)+'\n').encode(),
        'actual-pbs-qstat.txt':query.stdout,'actual-pbs-qstat.stderr.txt':query.stderr,
        'pbs-exit.txt':status.stdout,'archive_numpy_bgc_bridge_pi.py':Path(__file__).read_bytes()})
    for name in ('dispatch.json','qsub.stdout.txt','qsub.stderr.txt','qsub-actual-exit.json',
                 'compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt'):
        artifacts['manager/'+name]=(ROOT/name).read_bytes()
    log=ROOT/'pbs-output.log'
    artifacts['manager/pbs-output-presence.json']=(json.dumps(dict(path=str(log),exists=log.exists()))+'\n').encode()
    if log.exists():
        artifacts['manager/pbs-output.log']=log.read_bytes()
    if code == 0:
        d = {v['test']:v for v in receipt['positive_diagnostics']}
        artifacts['RESULTS.md']=(
            '# Own NumPy BGC record bridge PI\n\n'
            f'EHPC {args.job}: actual F0/Stageout0/worker0/unittest0;11 tests in '
            f'{receipt["actual_test_seconds"]} s. This reads the existing eight PH cold48 windows, '
            '384 recorded original intervals; no new physical tendency or seasonal solve.\n\n'
            f'All {d["projection"]["fields"]} prescribed fields / {d["projection"]["scalar_values"]} scalar values '
            f'and {d["initial"]["original_inventory_values"]} original initial inventory values compare exactly '
            f'(maximum absolute differences {d["projection"]["maximum_absolute_difference"]} and '
            f'{d["initial"]["maximum_absolute_difference"]}). The16-field OS projection retains '
            f'{d["os_schema"]["original_diagnostic_fields_exact"]} exact diagnostic fields.\n\n'
            'Temperature stays K, matric potential MPa, litter C/N in gC/gN m-2 per1800s interval; '
            'mineral deposition remains gN m-2 per interval and potential plant demand is not replaced '
            'by funded uptake. Explicit initial C7/N7/mineral N comes from each own original zero '
            'checkpoint, with no ratio reconstruction or N supplementation.\n\n'
            'Original recorded soil C/N budgets and cumulative sums use original cb/nb bounds. '
            'All8 final BGC objects match original checkpoints exactly. The original full M/H/C/N '
            'ledger is rechecked without changing its tolerance. Actual per-root C/N maxima and '
            'original bounds are retained below and in current/diagnostics.json.\n\n'
            'All11 rejection paths include real exception text. NM584, PH archive and dependency '
            'controls remain exact before/after. Observations and QC arrays were not decoded. '
            'Decomposition/column/GPU/solver calls, new initialization, candidate scores and '
            'complete field years are all0. These are short48/17520 prefixes, not SOC equilibrium, '
            'spinup acceptance or representative annual forcings. Future complete-cycle extraction '
            'requires unchanged PF actual17520/F0/all8 own-root closure; no manual pass flag.\n\n'
            '| Root | Max step C/N | Max cumulative C/N | Original cumulative bounds C/N |\n'
            '|---|---|---|---|\n').encode()
        for row in d['budgets']['cases']:
            artifacts['RESULTS.md'] += ('| '+row['case']+' | '+json.dumps(row['independent_max_step_c_n'])+' | '+
                json.dumps(row['independent_max_cumulative_c_n'])+' | '+json.dumps(row['cumulative_original_c_n_bounds'])+' |\n').encode()
    artifacts['inventory.json']=(json.dumps({name:dict(sha256=sha(raw),bytes=len(raw))
        for name,raw in artifacts.items()},indent=2)+'\n').encode()
    dest=ROOT/(args.label+'-evidence.tar.gz')
    assert not dest.exists()
    with tarfile.open(dest,'w:gz') as tar:
        for name,raw in sorted(artifacts.items()):
            member=tarfile.TarInfo(name); member.size,member.mode=len(raw),0o644
            tar.addfile(member,io.BytesIO(raw))
    assert contents(dest.read_bytes()) == artifacts
    package=dict(label=args.label,archive=dest.name,sha256=sha(dest.read_bytes()),bytes=dest.stat().st_size,
        artifacts=len(artifacts),artifact_sha256={name:sha(raw) for name,raw in artifacts.items()},
        pbs_job=args.job,actual_pbs_state='F',actual_pbs_exit=code,actual_stageout_status=0,
        actual_worker_exit=int(result['worker-exit.txt']),passed=receipt['passed'],
        actual_unittest_count=receipt.get('actual_test_count'),actual_test_seconds=receipt.get('actual_test_seconds'),
        positive_diagnostics=receipt.get('positive_diagnostics'),actual_negative_errors=receipt.get('actual_negative_errors'),
        stage_archive_sha256=args.stage_sha256,result_archive_sha256=sha(fetch.stdout),
        **{key:receipt[key] for key in zero_fields},
        scope='Own NumPy BGC to OS/OY data inputs:11 tests,384 existing PH records. No new physics, solver, loss, full year or spinup acceptance.')
    (ROOT/(args.label+'-package.json')).write_text(json.dumps(package,indent=2)+'\n')
    print(json.dumps({key:value for key,value in package.items() if key!='artifact_sha256'}),flush=True)


if __name__ == '__main__':
    main()

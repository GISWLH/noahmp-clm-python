# Own NumPy BGC record bridge PI

EHPC 1630.manager: actual F0/Stageout0/worker0/unittest0;11 tests in 2.354 s. This reads the existing eight PH cold48 windows, 384 recorded original intervals; no new physical tendency or seasonal solve.

All 2304 prescribed fields / 6912 scalar values and 120 original initial inventory values compare exactly (maximum absolute differences 0.0 and 0.0). The16-field OS projection retains 4608 exact diagnostic fields.

Temperature stays K, matric potential MPa, litter C/N in gC/gN m-2 per1800s interval; mineral deposition remains gN m-2 per interval and potential plant demand is not replaced by funded uptake. Explicit initial C7/N7/mineral N comes from each own original zero checkpoint, with no ratio reconstruction or N supplementation.

Original recorded soil C/N budgets and cumulative sums use original cb/nb bounds. All8 final BGC objects match original checkpoints exactly. The original full M/H/C/N ledger is rechecked without changing its tolerance. Actual per-root C/N maxima and original bounds are retained below and in current/diagnostics.json.

All11 rejection paths include real exception text. NM584, PH archive and dependency controls remain exact before/after. Observations and QC arrays were not decoded. Decomposition/column/GPU/solver calls, new initialization, candidate scores and complete field years are all0. These are short48/17520 prefixes, not SOC equilibrium, spinup acceptance or representative annual forcings. Future complete-cycle extraction requires unchanged PF actual17520/F0/all8 own-root closure; no manual pass flag.

| Root | Max step C/N | Max cumulative C/N | Original cumulative bounds C/N |
|---|---|---|---|
| CN-Cng-2007-wilting-hydraulic-clim | [4.413466120345433e-13, 5.6279037419920686e-14] | [7.105427357601002e-14, 3.730349362740526e-14] | [9.072495550095266e-09, 8.10761558265027e-10] |
| CN-Cng-2007-wilting-legacy-clim | [4.413466120345433e-13, 5.6279037419920686e-14] | [7.105427357601002e-14, 3.730349362740526e-14] | [9.072495550095266e-09, 8.10761558265027e-10] |
| CN-Cng-2007-field-capacity-hydraulic-clim | [4.413466120345433e-13, 5.6279037419920686e-14] | [7.105427357601002e-14, 3.730349362740526e-14] | [9.072495550095266e-09, 8.10761558265027e-10] |
| CN-Cng-2007-field-capacity-legacy-clim | [4.413466120345433e-13, 5.6279037419920686e-14] | [7.105427357601002e-14, 3.730349362740526e-14] | [9.072495550095266e-09, 8.10761558265027e-10] |
| CN-Qia-2003-wilting-hydraulic-clim | [9.044015536474603e-13, 1.346169269805797e-13] | [1.2201073484874314e-12, 2.434133623829826e-13] | [8.936157522739662e-09, 8.071346726959777e-10] |
| CN-Qia-2003-wilting-legacy-clim | [1.2231153589947752e-12, 1.2677250742221258e-13] | [1.7400386687072e-12, 1.4308302806465e-13] | [8.93612651086348e-09, 8.071346726959776e-10] |
| CN-Qia-2003-field-capacity-hydraulic-clim | [9.88424619929873e-13, 1.4794350640390252e-13] | [2.625233364028645e-12, 3.3586230584886634e-13] | [8.936154963073401e-09, 8.071346791413206e-10] |
| CN-Qia-2003-field-capacity-legacy-clim | [1.2858984710373278e-12, 1.4538988502704742e-13] | [6.789402373641451e-12, 5.987901147141983e-13] | [8.936123871685953e-09, 8.071346791413202e-10] |

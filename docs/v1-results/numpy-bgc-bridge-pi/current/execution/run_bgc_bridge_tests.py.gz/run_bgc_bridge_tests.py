"""One-shot EHPC read-only CPU trajectory adaptation tests; no new tendencies."""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-numpy-bgc-bridge-pi')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    assert sys.version_info >= (3, 10) and os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    result = Path(sys.argv[1]).resolve()
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
    result.mkdir()
    began = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
        python_executable=sys.executable, passed=False, error=None, decomposition_module_steps=0,
        coupled_column_steps=0, gpu_steps=0, solver_calls=0, candidate_scores_computed=0,
        complete_training_years_read=0, raw_observation_arrays_read=0)
    folders = ('preparation', 'execution', 'dependencies/pf', 'dependencies/os', 'dependencies/oy')
    try:
        inventory = json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/n).read_bytes()) == h for n, h in inventory.items())
        run = json.loads((STAGE/'execution/RUN_BINDINGS.json').read_bytes())
        assert run['authorized'] is True and run['expected_tests'] == 11
        for folder in folders:
            raw = (STAGE/folder/'CONTROLS_SHA256.json').read_bytes()
            index = json.loads(raw)
            if folder != 'execution':
                assert sha(raw) == run['manifests'][folder]
            assert all(sha((STAGE/folder/n).read_bytes()) == h for n, h in index.items())
            dest = result/folder
            dest.mkdir(parents=True)
            for n in [*index, 'CONTROLS_SHA256.json']:
                target = dest/n
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(STAGE/folder/n, target)
            receipt[folder.replace('/', '_')+'_manifest_sha256'] = sha(raw)
        shutil.copyfile(STAGE/'preparation/STATIC_CHECK.json', result/'preparation/STATIC_CHECK.json')
        fixed = json.loads((result/'preparation/BINDINGS.json').read_bytes())
        for label, key in [('ph', 'original_ph_archive_sha256'), ('source', 'source_archive_sha256')]:
            spec = run['inputs'][label]
            assert sha((STAGE/'inputs'/spec['file']).read_bytes()) == spec['sha256'] == fixed[key]
        source = result.parent/'source-nm584'
        source.mkdir()
        with tarfile.open(STAGE/'inputs'/run['inputs']['source']['file']) as t:
            members = t.getmembers()
            assert len(members) == len({m.name for m in members}) == 585
            assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
            raw = t.extractfile('SOURCE_SHA256.json').read()
            assert sha(raw) == fixed['source_manifest_sha256']
            manifest = json.loads(raw)
            assert len(manifest) == 584 and {m.name for m in members} == set(manifest) | {'SOURCE_SHA256.json'}
            for n in [*manifest, 'SOURCE_SHA256.json']:
                data = t.extractfile(n).read()
                assert n == 'SOURCE_SHA256.json' or sha(data) == manifest[n]
                dest = source/n
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
        (result/'SOURCE_SHA256.json').write_bytes(raw)
        assert all(sha((source/n).read_bytes()) == h for n, h in manifest.items())
        work = result/'preparation'
        tree = ast.parse((work/'test_numpy_bgc_bridge_pi.py').read_bytes())
        expected_tests = {n.name + ' (test_numpy_bgc_bridge_pi.' + cls.name + '.' + n.name + ')'
            for cls in tree.body if isinstance(cls, ast.ClassDef)
            for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
        assert len(expected_tests) == 11
        env = os.environ.copy()
        env.pop('PYTHONHOME', None)
        env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
            MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='',
            PYTHONPATH=os.pathsep.join(['/home/zhangyq/noahmp-v1/test-deps', str(source), str(source/'src'), str(source/'benchmarks')]),
            PI_PF_CONTROLS=str(result/'dependencies/pf'), PI_OS_CONTROLS=str(result/'dependencies/os'),
            PI_OY_CONTROLS=str(result/'dependencies/oy'), PI_SOURCE=str(source), PI_PH_ARCHIVE=str(STAGE/'inputs'/run['inputs']['ph']['file']))
        command = [sys.executable, '-B', '-m', 'unittest', '-v', 'test_numpy_bgc_bridge_pi']
        save(result/'unittest-command.json', dict(argv=command, cwd=str(work),
            environment={k: env[k] for k in ('PYTHONPATH', 'PI_PF_CONTROLS', 'PI_OS_CONTROLS', 'PI_OY_CONTROLS', 'PI_SOURCE', 'PI_PH_ARCHIVE')}))
        tick = time.monotonic()
        with (result/'unittest.stdout.txt').open('w') as out, (result/'unittest.stderr.txt').open('w') as err:
            proc = subprocess.Popen(command, cwd=work, env=env, stdout=out, stderr=err)
            try:
                code = proc.wait(timeout=max(1., 510.-(time.monotonic()-began)))
                timeout = False
            except subprocess.TimeoutExpired:
                proc.kill(); code = proc.wait(); timeout = True
        receipt.update(test_parent_returncode=code, test_timed_out=timeout, child_pid=proc.pid,
                       test_controller_seconds=time.monotonic()-tick)
        (result/'unittest-parent-exit.txt').write_text(str(code)+'\n')
        stderr = (result/'unittest.stderr.txt').read_text()
        statuses = re.findall(r'^(test_\w+ \(test_numpy_bgc_bridge_pi\.\w+\.test_\w+\)) \.\.\. (.+)$', stderr, re.M)
        summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
        save(result/'unittest-statuses.json', dict(statuses=statuses, summary=summary, parent_returncode=code, timed_out=timeout))
        assert code == 0 and timeout is False, 'Tests failed; raw logs retained'
        assert len(statuses) == 11 and {n for n, _ in statuses} == expected_tests and all(s == 'ok' for _, s in statuses)
        assert len(summary) == 1 and summary[0][0] == '11' and re.findall(r'^OK.*$', stderr, re.M) == ['OK']
        assert not re.search(r'^(?:FAIL|ERROR|UNEXPECTED SUCCESS):|^FAILED\b', stderr, re.M)
        stdout = (result/'unittest.stdout.txt').read_text().splitlines()
        positives = [json.loads(line.removeprefix('PI_DIAGNOSTIC ')) for line in stdout if line.startswith('PI_DIAGNOSTIC ')]
        negatives = [json.loads(line.removeprefix('PI_NEGATIVE ')) for line in stdout if line.startswith('PI_NEGATIVE ')]
        assert len(positives) == 4 and len(negatives) == run['expected_negative_errors'] == 11
        d = {value['test']: value for value in positives}
        assert set(d) == {'projection', 'initial', 'os_schema', 'budgets'}
        assert d['projection']['records'] == 384 and d['projection']['fields'] == 2304
        assert d['projection']['scalar_values'] == 6912
        assert d['projection']['maximum_absolute_difference'] == d['initial']['maximum_absolute_difference'] == 0.
        assert d['initial']['original_inventory_values'] == 120
        assert d['os_schema']['fields_per_record'] == 16 and d['os_schema']['original_diagnostic_fields_exact'] == 4608
        assert len(d['budgets']['cases']) == 8 and all(v['final_bgc_exact'] == 0 for v in d['budgets']['cases'])
        save(result/'diagnostics.json', dict(positive=positives, negative_errors=negatives))
        assert all(sha((source/n).read_bytes()) == h for n, h in manifest.items())
        assert all(sha((STAGE/n).read_bytes()) == h for n, h in inventory.items())
        for folder in folders:
            m = json.loads((result/folder/'CONTROLS_SHA256.json').read_bytes())
            assert all(sha((result/folder/n).read_bytes()) == h for n, h in m.items())
        receipt.update(passed=True, actual_test_count=11, actual_test_seconds=float(summary[0][1]),
            source_before_after_584_exact=True, original_inputs_and_controls_unchanged=True,
            source_manifest_sha256=fixed['source_manifest_sha256'], source_archive_sha256=fixed['source_archive_sha256'],
            original_ph_archive_sha256=fixed['original_ph_archive_sha256'],
            positive_diagnostics=positives, actual_negative_errors=len(negatives), actual_recorded_intervals_read=384)
    except Exception as error:
        receipt['error'] = type(error).__name__+': '+str(error)
        (result/'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic()-began
    save(result/'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

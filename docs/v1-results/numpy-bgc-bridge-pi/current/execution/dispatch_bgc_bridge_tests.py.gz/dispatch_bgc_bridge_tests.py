"""Existing one-shot manager/compute002 staging pattern, CPU stored-trajectory tests only."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import socket
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/noahmp-numpy-bgc-bridge-pi')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def unpack(path, expected):
    assert sha(path.read_bytes()) == expected and not ROOT.exists()
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in members)
        assert len({m.name for m in members}) == len(members)
        raw = {m.name: archive.extractfile(m).read() for m in members}
    index = json.loads(raw['stage-inventory.json'])
    assert set(index) == set(raw) - {'stage-inventory.json'} and all(sha(raw[n]) == h for n, h in index.items())
    run = json.loads(raw['execution/RUN_BINDINGS.json'])
    assert run['authorized'] is True and run['expected_tests'] == 11
    assert sha(raw['preparation/CONTROLS_SHA256.json']) == run['manifests']['preparation']
    ROOT.mkdir()
    for name, value in raw.items():
        dest = ROOT / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(value)
    return index


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--extract-only', action='store_true')
    args = parser.parse_args()
    assert sys.version_info >= (3, 10)
    assert socket.gethostname() == ('compute002' if args.extract_only else 'manager')
    index = unpack(args.archive, args.sha256)
    assert sha(Path(__file__).read_bytes()) == index['execution/dispatch_bgc_bridge_tests.py']
    if args.extract_only:
        print(json.dumps(dict(stage_archive_sha256=args.sha256, members=len(index))), flush=True)
        return
    remote_archive = '/tmp/noahmp-numpy-bgc-bridge-pi-stage.tar.gz'
    remote_dispatcher = '/tmp/dispatch_numpy_bgc_bridge_pi.py'
    subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', str(ROOT)])], check=True)
    for local, remote in [(args.archive, remote_archive), (Path(__file__), remote_dispatcher)]:
        subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', remote])], check=True)
        subprocess.run(['scp', str(local), 'compute002:' + remote], check=True)
    extract = subprocess.run(['ssh', 'compute002', shlex.join([
        PYTHON, '-B', remote_dispatcher, '--archive', remote_archive, '--sha256', args.sha256, '--extract-only'])],
        capture_output=True, text=True)
    (ROOT / 'compute-extract.stdout.txt').write_text(extract.stdout)
    (ROOT / 'compute-extract.stderr.txt').write_text(extract.stderr)
    assert extract.returncode == 0, extract.stderr
    checked = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', *[str(ROOT / n) for n in index]])], capture_output=True, text=True)
    (ROOT / 'compute-file-hashes.txt').write_text(checked.stdout)
    assert checked.returncode == 0, checked.stderr
    assert {line.split()[1]: line.split()[0] for line in checked.stdout.splitlines()} == {str(ROOT / n): h for n, h in index.items()}
    assert not (ROOT / 'dispatch.json').exists() and not (ROOT / 'result.tar.gz').exists()
    result = subprocess.run(['qsub', '-o', str(ROOT / 'pbs-output.log'), str(ROOT / 'execution/bgc_bridge_tests.pbs')], capture_output=True, text=True)
    (ROOT / 'qsub.stdout.txt').write_text(result.stdout)
    (ROOT / 'qsub.stderr.txt').write_text(result.stderr)
    (ROOT / 'qsub-actual-exit.json').write_text(json.dumps(dict(actual_parent_returncode=result.returncode)) + '\n')
    assert result.returncode == 0, result.stderr
    job = result.stdout.strip()
    assert job.endswith('.manager') and job.split('.')[0].isdigit()
    run = json.loads((ROOT / 'execution/RUN_BINDINGS.json').read_bytes())
    record = dict(pbs_job=job, stage_archive_sha256=args.sha256, source_stage_members=index,
                  preparation_manifest_sha256=run['manifests']['preparation'],
                  execution_manifest_sha256=sha((ROOT / 'execution/CONTROLS_SHA256.json').read_bytes()),
                  requested_resources='1CPU/2GB/10min/compute002', python=PYTHON,
                  decomposition_module_steps=0, coupled_column_steps=0, gpu_steps=0, solver_calls=0,
                  scope='11 read-only BGC record extraction tests.384 existing records only; no tendency, solver, score or initialization.')
    (ROOT / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

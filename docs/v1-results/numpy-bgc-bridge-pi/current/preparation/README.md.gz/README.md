# PI: own NumPy records to OS/OY inputs

This is a read-only data bridge. `extract_ph48(source, ph_archive, destination)`
authenticates the original PH 325-file archive and eight actual F0/Stageout0
receipts, then reads the 384 original records. It does not advance the model,
decomposition module, conditional matrix, initialization or scoring.

Each returned case has its explicit original seven C stocks, seven organic N
stocks and mineral N, copied from the original zero checkpoint and independently
matched to the first recorded state. No C:N ratio or mineral N is substituted.
The eight OY record fields retain original timestamps, temperature K, matric
potential MPa, litter C7 in gC/m2 and N7 in gN/m2, interval deposition gN/m2 and
potential plant N demand gN/m2. Deposition is not multiplied by dt again; actual
uptake is a distinct diagnostic. The 16-field singleton-column OS projection
contains exactly the fields used by the unchanged `AnnualCase.add` contract,
including actual N limitation, leaf N factors and normal rate multiplier.

The bridge verifies the full BGC before/after object chain, immutable original
parameters, own case/config/source identity, real 1800s calendar and final
checkpoint. It independently audits each stored soil step and cumulative C/N:
delta C = litter C - Rh; delta organic+mineral N = litter N + deposition - uptake.
Only original returned cb/nb and their compensated sums are used. The unchanged
CPU full M/H/C/N ledger reader is also applied to the PH trajectories. No new
scientific tolerance is introduced. All original observation/QC payloads remain
opaque; only their enclosing archive/forcing hashes are read.

`extract_complete_cycles(source, assembly_archive, candidate, cases, streams)`
is the future complete-year entry. It directly reuses PF `verify_cycle` for all
eight own roots: actual original F0/Stageout0 for every segment, exact NM584,
original OM configuration and PA climate, complete17520 steps, cumulative ledger
and retained parent captures. `cases` uses unchanged four-key PF descriptors;
`streams[case]` lists original chronological relative BGC-stream directories
inside that packet's inventory. Original stream headers/blocks and calendars
must cover0..17520 without gaps or overlaps. No caller approval boolean grants
access and no new human approval is required. A PH48 endpoint cannot enter here
as a complete cycle. This API has no actual annual input yet; future PJ's original
stream index can supply the list directly.

Extraction does not call the frozen OS/OY production entry points or loosen their
existing binding rules. It supplies their ordinary inputs for subsequent normal
rate diagnostics. A conditional C candidate is not an adopted cold state, complete
plant/NPP feedback, SOC convergence or another candidate's spinup. First48 is a
short prefix, not a representative year. Calibration candidates, four families,
heldout policy, loss, execution budget and production physical source are unchanged.

The11 tests must run on EHPC compute002. They read original384 records and check
2304 prescribed fields/6912 scalar values and120 original initial stocks, the OS
projection and original C/N bounds, and real rejection paths. Local preparation
uses only stdlib AST/hash checks. Test counts and zero differences are expectations
until the actual PBS result is recorded. All original model/decomposition/solver
entry points reached by these tests are guarded against accidental invocation.

"""EHPC-only stored-record extraction; no model, decomposition or matrix solve."""
from pathlib import Path
import copy
import hashlib
import json
import os
import pickle
import socket
import sys
import tempfile
import unittest


def setUpModule():
    if not os.environ.get('PBS_JOBID') or socket.gethostname() != 'compute002':
        raise RuntimeError('PI numerical reads require EHPC compute002 PBS')
    fixed = json.loads((Path(__file__).parent/'BINDINGS.json').read_bytes())
    for env, digest in fixed['dependency_manifests'].items():
        root = Path(os.environ[env])
        if hashlib.sha256((root/'CONTROLS_SHA256.json').read_bytes()).hexdigest() != digest:
            raise RuntimeError('Dependency manifest differs')
        for name, expected in json.loads((root/'CONTROLS_SHA256.json').read_bytes()).items():
            if hashlib.sha256((root/name).read_bytes()).hexdigest() != expected:
                raise RuntimeError('Dependency source changed')
        sys.path.insert(0, str(root))


class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import numpy_bgc_bridge_pi as bridge
        cls.b = bridge
        cls.tmp = tempfile.TemporaryDirectory(dir=os.environ['TMPDIR'])
        cls.root = Path(cls.tmp.name)/'original-ph'
        # Runtime loader is original; replace tendency entry points before any
        # extraction. Any accidental model or solver invocation fails the job.
        cls.runner, _, _ = bridge.pf.runtime(os.environ['PI_SOURCE'])
        cls.forbidden_calls = []
        def forbid(*args, **kwargs):
            cls.forbidden_calls.append(True)
            raise AssertionError('No physics or solver may run during extraction')
        original_runtime = bridge.pf.runtime
        def runtime(source):
            r, a, p = original_runtime(source)
            r.run = r.step_clm_enthalpy_column = forbid
            return r, a, p
        bridge.pf.runtime = runtime
        import normal_cn_replay_oy as oy
        import soc_operator_os as operator
        oy.NormalAPI.step = forbid
        operator.interval_map = operator.solve_periodic = operator.AnnualCase.add = forbid
        cls.result = bridge.extract_ph48(os.environ['PI_SOURCE'], os.environ['PI_PH_ARCHIVE'], cls.root)
        cls.original = [list(bridge.saved_records(cls.root/'cases'/str(k)/'bgc-stream')) for k in range(8)]

    @classmethod
    def tearDownClass(cls):
        assert not cls.forbidden_calls
        cls.tmp.cleanup()

    def negative(self, name, fn):
        with self.assertRaises(ValueError) as caught:
            fn()
        print('PI_NEGATIVE '+json.dumps(dict(test=name, error=str(caught.exception))), flush=True)

    def test_all_384_prescribed_fields_exact(self):
        arrays, values, maximum = 0, 0, 0.
        for case, original in zip(self.result['cases'], self.original):
            self.assertEqual(case['intervals'], 48)
            for row, raw in zip(case['records'], original):
                for key, value in raw['prescribed'].items():
                    self.b.exact(row[key], value, 'Projected field differs')
                    a, b = self.b.np.asarray(row[key]), self.b.np.asarray(value)
                    maximum = max(maximum, float(self.b.np.max(abs(a-b))))
                    arrays += 1; values += a.size
        self.assertEqual(arrays, 2304)
        self.assertEqual(values, 6912)
        print('PI_DIAGNOSTIC '+json.dumps(dict(test='projection', records=384, fields=arrays,
              scalar_values=values, maximum_absolute_difference=maximum)), flush=True)

    def test_original_explicit_initial_120_values_exact(self):
        maximum = 0.
        for case, original in zip(self.result['cases'], self.original):
            wanted = self.b.explicit_soil(original[0]['before_bgc'].soil)
            for key, value in wanted.items():
                self.b.exact(case['initial'][key], value, 'Original initial inventory differs')
                maximum = max(maximum, float(self.b.np.max(abs(self.b.np.asarray(case['initial'][key])-self.b.np.asarray(value)))))
        print('PI_DIAGNOSTIC '+json.dumps(dict(test='initial', original_inventory_values=120,
              maximum_absolute_difference=maximum, no_nitrogen_derived=True)), flush=True)

    def test_os_schema_exact_without_solver(self):
        count = 0
        for case, originals in zip(self.result['cases'], self.original):
            for row, raw in zip(case['os_rows'], originals):
                self.assertEqual(len(row), 16)
                for path in self.b.OS_KEYS:
                    value = raw['original_bgc_diagnostic']
                    for part in path.split('/'):
                        value = value[part]
                    self.b.exact(row['bgc/'+path][0], value, 'OS diagnostic changed')
                    count += 1
                self.b.exact(row['before_soil_cn'][0], self.b.soil_vector(raw['before_bgc'].soil), 'OS before differs')
                self.b.exact(row['after_soil_cn'][0], self.b.soil_vector(raw['after_bgc'].soil), 'OS after differs')
        print('PI_DIAGNOSTIC '+json.dumps(dict(test='os_schema', fields_per_record=16,
              original_diagnostic_fields_exact=count, solver_calls=0)), flush=True)

    def test_original_cn_bounds_all_records(self):
        print('PI_DIAGNOSTIC '+json.dumps(dict(test='budgets', cases=[{k: c[k] for k in
              ('case', 'independent_max_step_c_n', 'independent_max_cumulative_c_n', 'cumulative_original_c_n_bounds', 'final_bgc_exact')}
              for c in self.result['cases']])), flush=True)
        self.assertEqual(self.result['complete_years'], 0)
        self.assertTrue(all(not c['complete_calendar_year'] for c in self.result['cases']))

    def test_potential_demand_is_not_uptake(self):
        row = copy.deepcopy(self.original[0][0])
        row['prescribed']['plant_n_demand_gn_m2'] = row['actual_plant_uptake_gn_m2'] + 1.
        self.negative('potential_demand', lambda: self.b.project_record(row))

    def test_deposition_not_rate_multiplied(self):
        row = copy.deepcopy(self.original[0][0])
        row['prescribed']['mineral_n_input_gn_m2'] *= 1800.
        self.negative('interval_deposition', lambda: self.b.project_record(row))

    def test_oxygen_or_dt_change_rejected(self):
        row = copy.deepcopy(self.original[0][0]); row['oxygen_factor'] = .9
        self.negative('oxygen', lambda: self.b.project_record(row))

    def test_negative_n_and_bad_time_rejected(self):
        for field, value in [('plant_n_demand_gn_m2', -1.), ('time_end', '200701010100')]:
            row = copy.deepcopy(self.result['cases'][0]['records'][0]); row[field] = value
            self.negative(field, lambda: self.b.validate_schedule([row]))

    def test_missing_annual_calendar_rejected(self):
        self.negative('incomplete_year', lambda: self.b.validate_schedule(self.result['cases'][0]['records'], expected_year=2007))

    def test_partial_ph_cannot_be_complete_cycle_parent(self):
        base = self.root/'cases/0'
        job = '1620.manager'
        terminal = dict(job=job, qstat=(self.root/'actual/manager'/f'{job}-qstat.stdout').read_bytes(),
                        parent_exit=(self.root/'actual/compute002/case-0-pbs-exit.txt').read_bytes(),
                        worker_exit=(base/'worker-exit.txt').read_bytes())
        self.negative('actual48_is_not_year', lambda: self.b.pf.adapter.verify_parent(self.runner, base/'run', self.result['cases'][0]['identity'], terminal))

    def test_exact_case_source_config_and_state_chain(self):
        base = self.root/'cases/0'
        config = json.loads((base/'inputs/configuration.json').read_bytes())
        with self.b.np.load(base/'inputs/forcing.npz', allow_pickle=False) as z:
            data = {k: z[k] for k in ('time_start', 'time_end')}
        initial = pickle.loads((base/'run/segment-0000000/start-originals/state-0000000.pkl').read_bytes())
        final = pickle.loads((base/'run/trajectory/state-0000048.pkl').read_bytes())
        identity = self.result['cases'][0]['identity']
        def run(rows, ident=identity, cfg=config):
            return self.b.extract_case(self.runner, ident, cfg, data, initial, final, rows, steps=48)
        bad = copy.deepcopy(identity); bad['source_manifest_sha256'] = '0'*64
        self.negative('source_identity', lambda: run(self.original[0], bad))
        badconfig = copy.deepcopy(config); badconfig['case'] = 'CN-Cha-2003-wilting-hydraulic-clim'
        self.negative('case_identity', lambda: run(self.original[0], cfg=badconfig))
        rows = copy.deepcopy(self.original[0]); rows[0]['index'] = 1
        self.negative('record_index', lambda: run(rows))
        rows = copy.deepcopy(self.original[0]); rows[1]['before_bgc'] = rows[0]['before_bgc']
        self.negative('original_state_chain', lambda: run(rows))


if __name__ == '__main__':
    unittest.main()

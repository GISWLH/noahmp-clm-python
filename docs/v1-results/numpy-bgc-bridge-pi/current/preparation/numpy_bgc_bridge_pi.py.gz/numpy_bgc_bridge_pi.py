"""Read actual own NumPy BGC records into existing OS/OY input schemas; no stepping."""
from pathlib import Path
from dataclasses import asdict
import io
import json
import math
import pickle
import tarfile
import numpy as np

import own_spinup_pf as pf
from capture_bgc_pf import records as saved_records
from cpu_trace_budget import audit_cpu_trace
from normal_cn_replay_oy import validate_schedule, CompensatedSum
from soc_operator_os import validate_year

require, sha = pf.require, pf.sha
PH_SHA = 'c378f53895c0ca618abef26eda431643ca5778dafbae22b2dc58a29cea459171'
MAP = {'temperature_k': ('environment', 'soil_temperature'),
       'water_potential_mpa': ('environment', 'water_potential_mpa'),
       'litter_carbon_gc_m2': ('turnover', 'litter_carbon_gc_m2'),
       'litter_nitrogen_gn_m2': ('turnover', 'litter_nitrogen_gn_m2'),
       'plant_n_demand_gn_m2': ('allocation', 'soil_n_demand_gn_m2')}
OS_KEYS = ('decomposition/nitrogen_limitation', 'nitrogen_factor_used', 'nitrogen_factor_after',
           'environment/soil_temperature', 'environment/water_potential_mpa', 'decomposition/rate_multiplier',
           'turnover/litter_carbon_gc_m2', 'turnover/litter_nitrogen_gn_m2',
           'allocation/gpp_gc_m2', 'allocation/autotrophic_respiration_gc_m2',
           'allocation/soil_n_demand_gn_m2', 'allocation/soil_n_uptake_gn_m2')


def exact(a, b, message):
    a, b = np.asarray(a), np.asarray(b)
    require(a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes(), message)


def explicit_soil(state):
    return dict(carbon_gc_m2=state.carbon.copy(), organic_nitrogen_gn_m2=state.nitrogen.copy(),
                mineral_nitrogen_gn_m2=state.mineral_nitrogen)


def soil_vector(state):
    return np.concatenate((state.carbon, state.nitrogen, [state.mineral_nitrogen]))


def project_record(record):
    """Copy exact recorded scalars/vectors. Never replace potential demand by uptake."""
    bgc, prescribed = record['original_bgc_diagnostic'], record['prescribed']
    require(set(prescribed) == set(MAP) | {'mineral_n_input_gn_m2'}, 'Prescribed schema differs')
    require(record['oxygen_factor'] == 1. and record['forcing'].dt == 1800., 'Normal dt/oxygen required')
    for key, (section, field) in MAP.items():
        exact(prescribed[key], bgc[section][field], 'Recorded prescribed field differs: ' + key)
    exact(prescribed['mineral_n_input_gn_m2'], record['original_kwargs']['nitrogen_deposition_gn_m2'], 'Interval deposition kwargs differ')
    exact(prescribed['mineral_n_input_gn_m2'], bgc['nitrogen_deposition_gn_m2'], 'Interval deposition diagnostic differs')
    exact(record['actual_plant_uptake_gn_m2'], bgc['decomposition']['plant_uptake_gn_m2'], 'Actual uptake differs')
    exact(bgc['allocation']['soil_n_uptake_gn_m2'], bgc['decomposition']['plant_uptake_gn_m2'], 'Internal uptake differs')
    schedule = dict(time_start=record['time_start'], time_end=record['time_end'],
                    **{k: v.copy() if isinstance(v, np.ndarray) else v for k, v in prescribed.items()})
    os_row = {}
    for path in OS_KEYS:
        value = bgc
        for part in path.split('/'):
            value = value[part]
        os_row['bgc/' + path] = np.asarray(value)[None].copy()
    os_row.update(before_soil_cn=soil_vector(record['before_bgc'].soil)[None],
                  after_soil_cn=soil_vector(record['after_bgc'].soil)[None],
                  forcing=np.asarray([[record['forcing'].dt]]),
                  nitrogen=np.asarray([prescribed['mineral_n_input_gn_m2']]))
    return schedule, os_row


def extract_case(runner, identity, config, data, initial_saved, final_saved, records, *, steps):
    """Pure record/ledger audit, usable for original48 or a verified complete year."""
    require(steps in (48, 17520) and identity['steps'] == 17520, 'Only original48 or complete17520')
    require(identity['case'] == config['case'] and identity['site'] == config['site'] in ('CN-Cng', 'CN-Qia'), 'Training case/site mismatch')
    require(identity == pf.contract.request(identity['candidate'], identity['case'], 'spinup', identity['cycle']), 'Own original cycle identity differs')
    require(initial_saved[-1] == 0 and final_saved[-1] == steps, 'Original local checkpoint indices differ')
    require(initial_saved[0].crop_state is None and initial_saved[0].wetland_state is None, 'Unsupported litter/oxygen alteration')
    validate_year(data['time_start'], data['time_end'], identity['year'])
    parameters = initial_saved[0].bgc_parameters
    # Parameters are complete original OM dictionaries, not a new constructor/state.
    plain = json.loads(json.dumps(asdict(parameters)))
    require(plain['decomposition'] == config['biogeochemistry']['decomposition_parameters'] and
            plain['plant'] == config['biogeochemistry']['plant_parameters'] and
            plain['maximum_lai'] == config['biogeochemistry']['maximum_lai'] and
            plain['saturated_potential_mpa'] == config['biogeochemistry']['saturated_potential_mpa'], 'Original BGC parameters/config differ')
    require(plain['decomposition']['turnover_years'] == [.066, .25, .25, 4.1, .17, 6.1, 270.], 'Normal turnover rates required')
    previous = initial_saved[0].bgc_state
    initial = explicit_soil(previous.soil)
    c0 = math.fsum(previous.soil.carbon)
    n0 = math.fsum([*previous.soil.nitrogen, previous.soil.mineral_nitrogen])
    netc, netn, boundc, boundn = (CompensatedSum() for _ in range(4))
    maxima = np.zeros(4)
    schedules, projected = [], []
    for index, row in enumerate(records):
        require(index < steps and row['index'] == index and row['identity'] == identity, 'Record order/count/identity differs')
        require(row['time_start'] == str(data['time_start'][index]) and row['time_end'] == str(data['time_end'][index]), 'Original forcing calendar differs')
        pf.adapter.assert_content_exact(row['before_bgc'], previous, np)
        pf.adapter.assert_content_exact(row['bgc_parameters'], parameters, np)
        schedule, os_row = project_record(row)
        sd = row['original_bgc_diagnostic']['decomposition']
        before, after = row['before_bgc'].soil, row['after_bgc'].soil
        cin = math.fsum(schedule['litter_carbon_gc_m2'])
        nin = math.fsum([*schedule['litter_nitrogen_gn_m2'], schedule['mineral_n_input_gn_m2']])
        rh, uptake = float(sd['heterotrophic_respiration_gc_m2']), float(sd['plant_uptake_gn_m2'])
        cr = math.fsum([*after.carbon, -math.fsum(before.carbon), -cin, rh])
        nr = math.fsum([*after.nitrogen, after.mineral_nitrogen, -math.fsum([*before.nitrogen, before.mineral_nitrogen]), -nin, uptake])
        cb, nb = float(sd['carbon_bound_gc_m2']), float(sd['nitrogen_bound_gn_m2'])
        require(math.isfinite(cb) and math.isfinite(nb) and cb > 0 and nb > 0 and abs(cr) <= cb and abs(nr) <= nb, 'Original step C/N bound exceeded')
        netc.add(math.fsum([cin, -rh])); netn.add(math.fsum([nin, -uptake]))
        boundc.add(cb); boundn.add(nb)
        cumulative_c = math.fsum([*after.carbon, -c0, -netc.value])
        cumulative_n = math.fsum([*after.nitrogen, after.mineral_nitrogen, -n0, -netn.value])
        require(abs(cumulative_c) <= boundc.value and abs(cumulative_n) <= boundn.value, 'Original cumulative C/N bounds exceeded')
        maxima = np.maximum(maxima, np.abs([cr, nr, cumulative_c, cumulative_n]))
        schedules.append(schedule); projected.append(os_row)
        previous = row['after_bgc']
    require(len(schedules) == steps, 'Truncated original BGC record stream')
    endpoint = pf.adapter.assert_content_exact(previous, final_saved[0].bgc_state, np)
    validate_schedule(schedules, expected_year=identity['year'] if steps == 17520 else None)
    return dict(case=identity['case'], identity=identity, initial=initial, final=explicit_soil(previous.soil),
                records=schedules, os_rows=projected, decomposition_parameters=plain['decomposition'],
                original_initial_inventory_preserved=True, final_bgc_exact=endpoint['max_abs_difference'],
                intervals=steps, complete_calendar_year=steps == 17520,
                independent_max_step_c_n=maxima[:2].tolist(), independent_max_cumulative_c_n=maxima[2:].tolist(),
                cumulative_original_c_n_bounds=[boundc.value, boundn.value],
                initializer_exported=False, scientific_acceptance_claim=False)


def extract_ph48(source, ph_archive, destination):
    """Only the existing actual8 F0 windows. No new state/constructor or physics."""
    archive_raw = Path(ph_archive).read_bytes()
    require(sha(archive_raw) == PH_SHA, 'Original closed PH archive required')
    with tarfile.open(fileobj=io.BytesIO(archive_raw)) as archive:
        names = archive.getnames()
        require(len(names) == len(set(names)) == 325 and all(m.isfile() for m in archive), 'PH complete325 schema')
        raw = {n: archive.extractfile(n).read() for n in names}
    inventory = json.loads(raw['INTEGRITY.json'])
    require(set(inventory) == set(raw)-{'INTEGRITY.json'} and all(sha(raw[n]) == h for n, h in inventory.items()), 'PH original inventory differs')
    root = Path(destination)
    require(not root.exists(), 'Preserve previous extraction')
    root.mkdir()
    for name, body in raw.items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name, 'Unsafe original member')
        target = root/name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(body)
    runner, _, _ = pf.runtime(source)
    results = []
    for i, expected in enumerate(pf.candidate_rows('om-baseline')):
        base = root/'cases'/str(i)
        rec = json.loads((base/'receipt.json').read_bytes())
        identity = rec['identity']; job = str(1620+i)+'.manager'
        require(identity == pf.contract.request('om-baseline', expected['case'], 'spinup', 1) and rec['pbs_job'] == job, 'PH own candidate identity')
        pf.contract.terminal(raw['actual/manager/'+job+'-qstat.stdout'], raw['actual/compute002/case-'+str(i)+'-pbs-exit.txt'], (base/'worker-exit.txt').read_bytes(), job)
        require(b'Stageout_status = 0' in raw['actual/manager/'+job+'-qstat.stdout'], 'Actual Stageout0 required')
        paths = dict(configuration=base/'inputs/configuration.json', input=base/'inputs/forcing.npz', input_manifest=base/'inputs/forcing.json')
        for path_key, hash_key in [('configuration', 'configuration_sha256'), ('input', 'forcing_npz_sha256'), ('input_manifest', 'forcing_manifest_sha256')]:
            require(sha(paths[path_key].read_bytes()) == identity[hash_key], 'Original PH input hash differs')
        config = pf.contract.validate_configuration(paths['configuration'].read_bytes(), identity)
        # Original PH validated the entire input. Decode only required calendar
        # fields here; do not load its bundled observation/QC payloads again.
        with np.load(paths['input'], allow_pickle=False) as z:
            data = {key: z[key] for key in ('time_start', 'time_end')}
        report = json.loads((base/'run/trajectory/report.json').read_bytes())
        _, final, trace = pf.adapter._generation(runner, base/'run/trajectory', report, complete=False)
        require(report['steps_completed'] == 48 and report['status'] == 'running', 'PH is48/17520 only')
        zero = base/'run/segment-0000000/start-originals'
        zr = json.loads((zero/'report.json').read_bytes())
        initial = pickle.loads((zero/zr['checkpoint_file']).read_bytes())
        require(sha((zero/zr['checkpoint_file']).read_bytes()) == zr['checkpoint_sha256'], 'Zero checkpoint hash')
        pf.adapter.assert_content_exact(initial, pickle.loads((base/'own-cold-seed/own-cold-state.pkl').read_bytes()), np)
        header = json.loads((base/'bgc-stream/BGC_STREAM.json').read_bytes())
        require(header['first_index'] == 0 and header['stop_index'] == 48 and header['original_call_completed_without_exception'] is True, 'Original48 stream closure')
        for key in ('time_start', 'time_end'):
            require(sha(data[key].tobytes()) == header['original_'+key+'_sha256'], 'Original complete time array hash')
        budget = audit_cpu_trace(runner, dict(saved=final, trace=trace), base/'run')
        result = extract_case(runner, identity, config, data, initial, final, saved_records(base/'bgc-stream'), steps=48)
        result.update(original_trace_budget=budget, original_job=job)
        results.append(result)
    pf.adapter.verify_source(source)
    require(sha(Path(ph_archive).read_bytes()) == PH_SHA, 'PH archive changed')
    return dict(cases=results, actual_records_read=384, complete_years=0, decomposition_module_steps=0,
                coupled_column_steps=0, solver_calls=0, gpu_steps=0, initializer_exported=False,
                scientific_acceptance_claim=False, candidate='om-baseline')


def extract_complete_cycles(source, assembly_archive, candidate, cases, streams):
    """Future real17520/F0 only: reuse PF's original annual closure, no human flag.

    streams[case] lists original relative BGC stream directories in chronological
    order, all inside the existing closed packet inventory. No separate approval.
    OS/OY numerical calls are intentionally outside this extraction function.
    """
    runner, _, _ = pf.runtime(source)
    assembly = pf.read_assembly(assembly_archive)
    order = [r['case'] for r in pf.candidate_rows(candidate)]
    require(set(cases) == set(streams) == set(order), 'All8 own roots required')
    output = []
    for case in order:
        descriptor = cases[case]
        _, run, _, _ = pf.closed_packet(descriptor)
        identity = json.loads((run/'receipt.json').read_bytes())['identity']
        closed = pf.verify_cycle(runner, descriptor, assembly, candidate, case, identity['cycle'])
        root, index = closed['packet_root'], closed['packet_inventory']
        _, config, _ = pf.original_configuration(assembly, candidate, case)
        with np.load(io.BytesIO(assembly['year-inputs/'+identity['site']+'-'+str(identity['year'])+'.npz']), allow_pickle=False) as z:
            data = {key: z[key] for key in ('time_start', 'time_end')}
        zero = run/'segment-0000000/start-originals'
        zr = json.loads((zero/'report.json').read_bytes())
        initial = pickle.loads((zero/zr['checkpoint_file']).read_bytes())
        def rows():
            stop = 0
            for relative in streams[case]:
                name = relative+'/BGC_STREAM.json'
                require(name in index and not Path(relative).is_absolute() and '..' not in Path(relative).parts, 'Unbound original stream')
                header = json.loads((root/name).read_bytes())
                require(header['identity'] == identity and header['first_index'] == stop and header['original_call_completed_without_exception'] is True, 'BGC windows gap/identity/failure')
                for key in ('time_start', 'time_end'):
                    require(sha(data[key].tobytes()) == header['original_'+key+'_sha256'], 'Original complete calendar identity')
                for block in header['blocks']:
                    require(index.get(relative+'/'+block['file']) == block['sha256'], 'Unbound BGC block')
                yield from saved_records(root/relative)
                stop = header['stop_index']
            require(stop == 17520, 'Actual complete17520 BGC stream required')
        output.append(extract_case(runner, identity, config, data, initial, closed['saved'], rows(), steps=17520))
        pf.closed_packet(descriptor)
    pf.adapter.verify_source(source)
    return dict(cases=output, complete_years=8, coupled_column_steps=0, decomposition_module_steps=0,
                solver_calls=0, gpu_steps=0, initializer_exported=False, scientific_acceptance_claim=False)

"""EHPC-only tests with independent scalar C/N oracles and original-step check."""
from datetime import datetime, timedelta
from dataclasses import replace
import copy
import json
import math
import os
import unittest
import numpy as np
from normal_cn_replay_oy import load_exact_nm, validate_schedule, _replay_case, replay_bound_training_year

API = None
DIAGNOSTICS = []
YEAR_SECONDS = 31536000.


def setUpModule():
    global API
    if not os.environ.get('PBS_JOBID') or not os.uname().nodename.startswith('compute002'):
        raise RuntimeError('OY numerical tests require actual EHPC compute002 PBS context')
    API = load_exact_nm(os.environ['OY_SOURCE_ROOT'])


def tearDownModule():
    if API is not None:
        print('OY_NUMERICAL_DIAGNOSTICS ' + json.dumps(dict(cases=DIAGNOSTICS,
            decomposition_module_steps=API.decomposition_module_steps,
            decomposition_module_successful_steps=API.decomposition_module_successful_steps,
            synthetic_schedule_steps=API.synthetic_schedule_steps,
            coupled_column_steps=0, gpu_steps=0, actual_field_years=0), allow_nan=False), flush=True)


def initial(carbon=None, nitrogen=None, mineral=0.):
    return dict(carbon_gc_m2=np.zeros(7) if carbon is None else carbon,
        organic_nitrogen_gn_m2=np.zeros(7) if nitrogen is None else nitrogen,
        mineral_nitrogen_gn_m2=mineral)


def rows(count, origin=datetime(2007, 1, 1), **updates):
    result = []
    for index in range(count):
        row = dict(time_start=(origin+timedelta(seconds=1800*index)).strftime('%Y%m%d%H%M'),
            time_end=(origin+timedelta(seconds=1800*(index+1))).strftime('%Y%m%d%H%M'),
            temperature_k=298.15, water_potential_mpa=-.002,
            litter_carbon_gc_m2=np.zeros(7), litter_nitrogen_gn_m2=np.zeros(7),
            mineral_n_input_gn_m2=0., plant_n_demand_gn_m2=0.)
        row.update(copy.deepcopy(updates)); result.append(row)
    return result


def run_case(start, schedule, **kwargs):
    return _replay_case(API, start, schedule, API.Parameters(), **kwargs)


class NormalReplayTests(unittest.TestCase):
    def test_low_mineral_competition_matches_independent_scalar_oracle(self):
        start = initial([100.,0,0,0,0,0,0], [1.,0,0,0,0,0,0], 1e-5)
        result = run_case(start, rows(1, plant_n_demand_gn_m2=.001))
        d = result['step_diagnostics'][0]
        decay = 100.*(-math.expm1(-1800./(.066*YEAR_SECONDS)))
        immobilization_potential = decay*(.45/8.-.01)
        limitation = 1e-5/(immobilization_potential+.001)
        expected_c = np.array([100.-decay*limitation,0,0,0,.45*decay*limitation,0,0])
        expected_n = np.array([1.-.01*decay*limitation,0,0,0,.45*decay*limitation/8.,0,0])
        np.testing.assert_allclose(result['final']['carbon_gc_m2'], expected_c, rtol=0, atol=2e-14)
        np.testing.assert_allclose(result['final']['organic_nitrogen_gn_m2'], expected_n, rtol=0, atol=2e-16)
        self.assertAlmostEqual(d['nitrogen_limitation'], limitation, places=15)
        self.assertAlmostEqual(d['plant_uptake_gn_m2'], .001*limitation, places=17)
        self.assertLess(result['final']['mineral_nitrogen_gn_m2'], 1e-18)
        DIAGNOSTICS.append(dict(case='small-mineral-N-competition', oracle_n_factor=limitation,
            actual_n_factor=d['nitrogen_limitation'], n_factor_absolute_error=abs(d['nitrogen_limitation']-limitation),
            maximum_c_pool_absolute_error=float(np.max(abs(np.array(result['final']['carbon_gc_m2'])-expected_c))),
            maximum_n_pool_absolute_error=float(np.max(abs(np.array(result['final']['organic_nitrogen_gn_m2'])-expected_n)))))

    def test_zero_mineral_and_zero_organic_n_do_not_invent_supply(self):
        start = initial([100.,0,0,0,0,0,0], np.zeros(7), 0.)
        result = run_case(start, rows(1, plant_n_demand_gn_m2=.1))
        d = result['step_diagnostics'][0]
        self.assertEqual(d['nitrogen_limitation'], 0.)
        self.assertEqual(d['plant_uptake_gn_m2'], 0.)
        np.testing.assert_array_equal(result['final']['carbon_gc_m2'], start['carbon_gc_m2'])
        self.assertEqual(result['final']['mineral_nitrogen_gn_m2'], 0.)

    def test_new_mineral_n_is_available_only_next_interval(self):
        start = initial([100.,0,0,0,0,0,0], [50.,0,0,0,0,0,0], 0.)
        result = run_case(start, rows(2, plant_n_demand_gn_m2=1.))
        first, second = result['step_diagnostics']
        decay = 100.*(-math.expm1(-1800./(.066*YEAR_SECONDS)))
        released = decay*(.5-.45/8.)
        self.assertEqual(first['plant_uptake_gn_m2'], 0.)
        self.assertEqual(first['immobilization_gn_m2'], 0.)
        self.assertAlmostEqual(first['gross_mineralization_gn_m2'], released, places=15)
        self.assertAlmostEqual(first['mineral_nitrogen_after_gn_m2'], released, places=15)
        self.assertAlmostEqual(second['plant_uptake_gn_m2'], released, places=15)
        DIAGNOSTICS.append(dict(case='new-mineralization-waits-one-step', oracle_release_gn_m2=released,
            first_uptake_gn_m2=first['plant_uptake_gn_m2'], second_uptake_gn_m2=second['plant_uptake_gn_m2'],
            second_uptake_absolute_error=abs(second['plant_uptake_gn_m2']-released)))

    def test_zero_litter_drought_keeps_organic_stores(self):
        start = initial(np.arange(1.,8.), np.arange(1.,8.)/10., .3)
        result = run_case(start, rows(2, water_potential_mpa=-3.))
        np.testing.assert_array_equal(result['final']['carbon_gc_m2'], start['carbon_gc_m2'])
        np.testing.assert_array_equal(result['final']['organic_nitrogen_gn_m2'], start['organic_nitrogen_gn_m2'])
        self.assertEqual(result['final']['mineral_nitrogen_gn_m2'], .3)
        self.assertTrue(all(d['heterotrophic_respiration_gc_m2'] == d['actual_normal_rate_multiplier'] == 0 for d in result['step_diagnostics']))

    def test_deposition_and_plant_export_close_independent_n_ledger(self):
        result = run_case(initial(), rows(1, water_potential_mpa=-3., mineral_n_input_gn_m2=.001, plant_n_demand_gn_m2=.003))
        d = result['step_diagnostics'][0]
        self.assertAlmostEqual(d['nitrogen_limitation'], 1./3., places=15)
        self.assertEqual(d['plant_uptake_gn_m2'], .001)
        self.assertEqual(result['final']['mineral_nitrogen_gn_m2'], 0.)
        self.assertEqual(result['cumulative_net_nitrogen_input_gn_m2'], 0.)
        self.assertEqual(d['independent_nitrogen_residual_gn_m2'], 0.)

    def test_litter_enters_before_normal_decay_and_carries_explicit_n(self):
        result = run_case(initial(), rows(1, litter_carbon_gc_m2=[2.,0,0,0,0,0,0],
                                        litter_nitrogen_gn_m2=[1.,0,0,0,0,0,0]))
        decay = 2.*(-math.expm1(-1800./(.066*YEAR_SECONDS)))
        self.assertAlmostEqual(result['final']['carbon_gc_m2'][0], 2.-decay, places=15)
        self.assertAlmostEqual(result['final']['carbon_gc_m2'][4], .45*decay, places=15)
        self.assertAlmostEqual(result['step_diagnostics'][0]['heterotrophic_respiration_gc_m2'], .55*decay, places=15)
        self.assertAlmostEqual(sum(result['final']['organic_nitrogen_gn_m2'])+result['final']['mineral_nitrogen_gn_m2'], 1., places=15)

    def test_received_fast_carbon_waits_until_following_step(self):
        start = initial([100.,0,0,0,0,0,0], [50.,0,0,0,0,0,0], 0.)
        first = run_case(start, rows(1))
        two = run_case(start, rows(2))
        received = .45*100.*(-math.expm1(-1800./(.066*YEAR_SECONDS)))
        fast_decay = received*(-math.expm1(-1800./(.17*YEAR_SECONDS)))
        self.assertEqual(first['final']['carbon_gc_m2'][5], 0.)
        self.assertEqual(first['final']['carbon_gc_m2'][6], 0.)
        self.assertAlmostEqual(two['final']['carbon_gc_m2'][5], fast_decay*(.826-.68*.4), places=15)
        self.assertAlmostEqual(two['final']['carbon_gc_m2'][6], fast_decay*.004, places=15)

    def test_wood_routes_its_explicit_n_without_soil_cn_replacement(self):
        start = initial([0,0,0,100.,0,0,0], [0,0,0,2.,0,0,0], 0.)
        result = run_case(start, rows(1))
        decay = 100.*(-math.expm1(-1800./(4.1*YEAR_SECONDS)))
        expected_c = [0,.76*decay,.24*decay,100.-decay,0,0,0]
        expected_n = [0,.76*.02*decay,.24*.02*decay,2.-.02*decay,0,0,0]
        np.testing.assert_allclose(result['final']['carbon_gc_m2'], expected_c, rtol=0, atol=2e-14)
        np.testing.assert_allclose(result['final']['organic_nitrogen_gn_m2'], expected_n, rtol=0, atol=3e-16)
        self.assertEqual(result['final']['mineral_nitrogen_gn_m2'], 0.)
        self.assertEqual(result['step_diagnostics'][0]['heterotrophic_respiration_gc_m2'], 0.)

    def test_multistep_matches_original_and_independent_endpoint_budget(self):
        start = initial([100.,50.,30.,10.,500.,1000.,2000.], [1.,.5,.3,.1,62.5,90.,180.], .002)
        schedule = rows(6)
        for index, row in enumerate(schedule):
            row.update(temperature_k=280.+index*3., water_potential_mpa=(-3.,-.1,-.002)[index%3],
                litter_carbon_gc_m2=np.array([.1,.02,0,0,0,0,0]), litter_nitrogen_gn_m2=np.array([.001,.0002,0,0,0,0,0]),
                mineral_n_input_gn_m2=.0001, plant_n_demand_gn_m2=.001)
        result = run_case(start, schedule)
        direct = API.state(start); direct_diagnostics = []
        for row in validate_schedule(schedule):
            direct, diagnostic = API.step(direct, row, API.Parameters())
            direct_diagnostics.append(diagnostic)
        np.testing.assert_array_equal(result['final']['carbon_gc_m2'], direct.carbon)
        np.testing.assert_array_equal(result['final']['organic_nitrogen_gn_m2'], direct.nitrogen)
        self.assertEqual(result['final']['mineral_nitrogen_gn_m2'], direct.mineral_nitrogen)
        carbon_net = math.fsum([*(float(x) for row in schedule for x in row['litter_carbon_gc_m2']),
                              *(-d['heterotrophic_respiration_gc_m2'] for d in direct_diagnostics)])
        nitrogen_net = math.fsum([*(float(x) for row in schedule for x in row['litter_nitrogen_gn_m2']),
            *(row['mineral_n_input_gn_m2'] for row in schedule), *(-d['plant_uptake_gn_m2'] for d in direct_diagnostics)])
        c_res = math.fsum([*direct.carbon, *(-float(x) for x in start['carbon_gc_m2']), -carbon_net])
        n_res = math.fsum([*direct.nitrogen, direct.mineral_nitrogen,
            *(-float(x) for x in start['organic_nitrogen_gn_m2']), -start['mineral_nitrogen_gn_m2'], -nitrogen_net])
        c_bound = math.fsum(d['carbon_bound_gc_m2'] for d in direct_diagnostics)
        n_bound = math.fsum(d['nitrogen_bound_gn_m2'] for d in direct_diagnostics)
        self.assertLessEqual(abs(c_res), c_bound); self.assertLessEqual(abs(n_res), n_bound)
        self.assertAlmostEqual(result['cumulative_original_carbon_bound_gc_m2'], c_bound, places=20)
        self.assertAlmostEqual(result['cumulative_original_nitrogen_bound_gn_m2'], n_bound, places=20)
        DIAGNOSTICS.append(dict(case='six-step-normal-replay', independent_endpoint_c_residual=c_res,
            independent_endpoint_n_residual=n_res, summed_original_c_bound=c_bound, summed_original_n_bound=n_bound,
            direct_original_endpoint_maximum_carbon_difference=float(np.max(abs(np.asarray(result['final']['carbon_gc_m2'])-direct.carbon))),
            direct_original_endpoint_maximum_organic_n_difference=float(np.max(abs(np.asarray(result['final']['organic_nitrogen_gn_m2'])-direct.nitrogen))),
            direct_original_endpoint_mineral_n_difference=abs(result['final']['mineral_nitrogen_gn_m2']-direct.mineral_nitrogen),
            maximum_step_c_n=result['maximum_independent_absolute_step_c_n'],
            maximum_cumulative_c_n=result['maximum_independent_absolute_cumulative_c_n']))

    def test_initial_stock_difference_is_not_an_external_flux(self):
        baseline = initial([1.,0,0,0,0,0,0], [.1,0,0,0,0,0,0], .02)
        proposed = initial([3.,0,0,0,0,0,0], [.4,0,0,0,0,0,0], .02)
        result = run_case(proposed, rows(1, water_potential_mpa=-3.), baseline_initial=baseline)
        self.assertEqual(result['initial_inventory_difference_from_explicit_baseline']['total_carbon_gc_m2'], 2.)
        self.assertAlmostEqual(result['initial_inventory_difference_from_explicit_baseline']['total_nitrogen_gn_m2'], .3, places=15)
        self.assertEqual(result['endpoint_stock_change']['total_carbon_gc_m2'], 0.)
        self.assertEqual(result['endpoint_stock_change']['total_nitrogen_gn_m2'], 0.)
        self.assertEqual(result['cumulative_net_carbon_input_gc_m2'], 0.)
        self.assertEqual(result['cumulative_net_nitrogen_input_gn_m2'], 0.)
        self.assertFalse(result['initial_inventory_difference_is_external_flux'])

    def test_missing_explicit_or_negative_n_and_carbonless_n_rejected(self):
        invalid = [dict(carbon_gc_m2=np.zeros(7), organic_nitrogen_gn_m2=np.zeros(7)),
            initial(mineral=-1.), initial([1.,0,0,0,0,0,0], [-.1,0,0,0,0,0,0]),
            initial(np.zeros(7), [.1,0,0,0,0,0,0])]
        old_calls = API.decomposition_module_steps
        for value in invalid:
            with self.assertRaises(ValueError):
                run_case(value, rows(1))
        for field in ('litter_nitrogen_gn_m2', 'mineral_n_input_gn_m2', 'plant_n_demand_gn_m2'):
            schedule = rows(2)
            schedule[1][field] = [-1.,0,0,0,0,0,0] if field.startswith('litter') else -1.
            with self.assertRaises(ValueError):
                run_case(initial(), schedule)
        self.assertEqual(API.decomposition_module_steps, old_calls)

    def test_bad_temporal_order_gap_and_timestep_rejected_before_calls(self):
        old_calls = API.decomposition_module_steps
        schedules = [rows(3)[::2], rows(2)[::-1], [*rows(1), *rows(1)]]
        wrong = rows(1); wrong[0]['time_end'] = '200701010100'; schedules.append(wrong)
        for value in schedules:
            with self.assertRaises(ValueError):
                run_case(initial(), value)
        self.assertEqual(API.decomposition_module_steps, old_calls)

    def test_twelve_month_coverage_and_full_year_requirement(self):
        # Calendar metadata only: this is not17520 physical module steps.
        self.assertEqual(len(validate_schedule(rows(17520), expected_year=2007)), 17520)
        self.assertEqual(len(validate_schedule(rows(17568, datetime(2008,1,1)), expected_year=2008)), 17568)
        with self.assertRaises(ValueError):
            validate_schedule(rows(17519), expected_year=2007)
        result = run_case(initial(), rows(2, datetime(2007,1,31,23,30), water_potential_mpa=-3.))
        self.assertEqual(len(result['months']), 12)
        self.assertEqual(result['months']['01']['intervals'], 1)
        self.assertEqual(result['months']['02']['intervals'], 1)
        self.assertTrue(all(result['months'][f'{m:02d}']['intervals'] == 0 for m in range(3,13)))
        self.assertFalse(result['complete_calendar_year'])

    def test_acceleration_oxygen_or_unknown_inputs_rejected(self):
        old_calls = API.decomposition_module_steps
        for field in ('dt', 'oxygen_factor', 'rate_multiplier'):
            bad = rows(1); bad[0][field] = 2.
            with self.assertRaises(ValueError):
                run_case(initial(), bad)
        parameters = replace(API.Parameters(), turnover_years=(.001,)*7)
        with self.assertRaises(ValueError):
            _replay_case(API, initial(), rows(1), parameters)
        self.assertEqual(API.decomposition_module_steps, old_calls)

    def test_unsealed_production_rejects_even_caller_true_before_array_access(self):
        class Poison:
            def __array__(self, *args, **kwargs):
                raise AssertionError('Production guard touched array')
        old_calls = API.decomposition_module_steps
        for value in (False, True):
            with self.assertRaisesRegex(ValueError, 'unsealed'):
                replay_bound_training_year(proof={'production_extraction_bound': value}, initial=Poison())
        self.assertEqual(API.decomposition_module_steps, old_calls)


if __name__ == '__main__':
    unittest.main(verbosity=2)

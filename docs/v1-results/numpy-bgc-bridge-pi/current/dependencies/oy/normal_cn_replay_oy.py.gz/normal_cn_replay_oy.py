"""Normal-rate soil C/N replay core; no column model or initializer export."""
from pathlib import Path
from datetime import datetime, timedelta
import calendar
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
INITIAL_KEYS = {'carbon_gc_m2', 'organic_nitrogen_gn_m2', 'mineral_nitrogen_gn_m2'}
RECORD_KEYS = {'time_start', 'time_end', 'temperature_k', 'water_potential_mpa',
               'litter_carbon_gc_m2', 'litter_nitrogen_gn_m2',
               'mineral_n_input_gn_m2', 'plant_n_demand_gn_m2'}
POOLS = ('metabolic_litter', 'cellulose_litter', 'lignin_litter', 'coarse_wood', 'fast', 'slow', 'passive')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def vector(value):
    result = np.asarray(value, dtype=float)
    require(result.shape == (7,) and np.isfinite(result).all() and np.all(result >= 0), 'Invalid explicit seven-pool stock/input')
    return result.copy()


def scalar(value, *, nonnegative=True):
    require(np.ndim(value) == 0, 'Scalar input required')
    result = float(value)
    require(math.isfinite(result) and (not nonnegative or result >= 0), 'Invalid scalar input')
    return result


class NormalAPI:
    """Count every actual call to the exact original decomposition function."""
    def __init__(self, module, identity):
        self.module = module
        self.State = module.DecompositionState
        self.Parameters = module.DecompositionParameters
        self.identity = identity
        self.decomposition_module_steps = 0
        self.decomposition_module_successful_steps = 0
        self.synthetic_schedule_steps = 0

    def state(self, explicit):
        require(isinstance(explicit, dict) and set(explicit) == INITIAL_KEYS, 'All initial C7/N7/mineral N must be explicit')
        return self.State(vector(explicit['carbon_gc_m2']), vector(explicit['organic_nitrogen_gn_m2']),
                          scalar(explicit['mineral_nitrogen_gn_m2']))

    def step(self, state, row, parameters):
        require(type(parameters) is self.Parameters and
                parameters.turnover_years == self.Parameters().turnover_years,
                'Require exact normal turnover times; no accelerated rates')
        self.decomposition_module_steps += 1
        result = self.module.step_decomposition(state, row['temperature_k'], row['water_potential_mpa'], 1800.,
            carbon_input=row['litter_carbon_gc_m2'], nitrogen_input=row['litter_nitrogen_gn_m2'],
            mineral_n_input=row['mineral_n_input_gn_m2'], plant_n_demand=row['plant_n_demand_gn_m2'],
            oxygen_factor=1., parameters=parameters)
        self.decomposition_module_successful_steps += 1
        return result


def load_exact_nm(source_root):
    """Verify the frozen source as bytes, then load only its original module."""
    binding = json.loads((HERE/'BINDINGS.json').read_bytes())
    root = Path(source_root)
    digest = lambda raw: hashlib.sha256(raw).hexdigest()
    raw = (root/'SOURCE_SHA256.json').read_bytes()
    require(digest(raw) == binding['source_manifest_sha256'], 'Wrong NM source manifest')
    manifest = json.loads(raw)
    require(len(manifest) == 584 and all(digest((root/name).read_bytes()) == value for name, value in manifest.items()),
            'NM source differs from frozen584 files')
    path = root/binding['decomposition_path']
    require(digest(path.read_bytes()) == binding['decomposition_sha256'], 'Wrong decomposition implementation')
    name = '_oy_exact_nm_decomposition'
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return NormalAPI(module, dict(source_manifest_sha256=binding['source_manifest_sha256'],
        decomposition_sha256=binding['decomposition_sha256'], source_files_verified=584))


def validate_schedule(records, expected_year=None):
    """Reject gaps/duplicates/negative N before the first physical step."""
    rows = []
    previous = None
    for source in records:
        require(isinstance(source, dict) and set(source) == RECORD_KEYS, 'Unexpected/missing schedule field or multiplier')
        row = dict(source)
        stamps = []
        for key in ('time_start', 'time_end'):
            require(isinstance(row[key], str) and len(row[key]) == 12, 'Require YYYYmmddHHMM timestamps')
            stamp = datetime.strptime(row[key], '%Y%m%d%H%M')
            require(stamp.strftime('%Y%m%d%H%M') == row[key], 'Noncanonical timestamp')
            stamps.append(stamp)
        require(stamps[1]-stamps[0] == timedelta(seconds=1800) and
                (previous is None or stamps[0] == previous), 'Non-1800s, missing, repeated or reordered interval')
        previous = stamps[1]
        row['temperature_k'] = scalar(row['temperature_k'])
        row['water_potential_mpa'] = scalar(row['water_potential_mpa'], nonnegative=False)
        require(150 <= row['temperature_k'] <= 350 and row['water_potential_mpa'] <= 0, 'Invalid T or matric-potential convention')
        for key in ('litter_carbon_gc_m2', 'litter_nitrogen_gn_m2'):
            row[key] = vector(row[key])
        for key in ('mineral_n_input_gn_m2', 'plant_n_demand_gn_m2'):
            row[key] = scalar(row[key])
        rows.append(row)
    require(bool(rows), 'Empty schedule')
    if expected_year is not None:
        require(isinstance(expected_year, int) and 1 <= expected_year < 9999, 'Invalid year')
        require(len(rows) == (366 if calendar.isleap(expected_year) else 365)*48 and
                rows[0]['time_start'] == f'{expected_year:04d}01010000' and
                rows[-1]['time_end'] == f'{expected_year+1:04d}01010000', 'Incomplete calendar year')
    return rows


def snapshot(state):
    return dict(carbon_gc_m2=state.carbon.tolist(), organic_nitrogen_gn_m2=state.nitrogen.tolist(),
                mineral_nitrogen_gn_m2=float(state.mineral_nitrogen))


def stock_delta(new, old):
    return dict(carbon_gc_m2=(new.carbon-old.carbon).tolist(),
        organic_nitrogen_gn_m2=(new.nitrogen-old.nitrogen).tolist(),
        mineral_nitrogen_gn_m2=float(new.mineral_nitrogen-old.mineral_nitrogen),
        total_carbon_gc_m2=math.fsum(new.carbon)-math.fsum(old.carbon),
        total_nitrogen_gn_m2=math.fsum([*new.nitrogen, new.mineral_nitrogen])-math.fsum([*old.nitrogen, old.mineral_nitrogen]))


class CompensatedSum:
    def __init__(self):
        self.value = 0.
        self.correction = 0.

    def add(self, value):
        adjusted = value-self.correction
        updated = self.value+adjusted
        self.correction = (updated-self.value)-adjusted
        self.value = updated


def _replay_case(api, explicit_initial, records, parameters, *, baseline_initial=None, expected_year=None):
    """Private mathematical core. Current use is synthetic-only on EHPC.

    Prescribed litter and plant demand are external forcing to this soil module.
    Full plant/leaf/NPP feedback is absent. Initial inventory changes are metadata.
    """
    rows = validate_schedule(records, expected_year)
    initial = api.state(explicit_initial)
    baseline = None if baseline_initial is None else api.state(baseline_initial)
    state = initial
    initial_c = math.fsum(initial.carbon)
    initial_n = math.fsum([*initial.nitrogen, initial.mineral_nitrogen])
    net_c, net_n, bounds_c, bounds_n = (CompensatedSum() for _ in range(4))
    ledger = []
    start_calls = api.decomposition_module_steps
    months = {str(m).zfill(2): dict(intervals=0, litter_carbon_gc_m2=[0.]*7, litter_nitrogen_gn_m2=[0.]*7,
              mineral_n_input_gn_m2=0., plant_n_demand_gn_m2=0., plant_uptake_gn_m2=0.,
              heterotrophic_respiration_gc_m2=0., immobilization_gn_m2=0., gross_mineralization_gn_m2=0.) for m in range(1,13)}
    min_mineral = float(initial.mineral_nitrogen)
    for index, row in enumerate(rows):
        old = state
        state, d = api.step(old, row, parameters)
        api.synthetic_schedule_steps += 1
        rh = float(d['heterotrophic_respiration_gc_m2'])
        uptake = float(d['plant_uptake_gn_m2'])
        carbon_input = math.fsum(row['litter_carbon_gc_m2'])
        nitrogen_input = math.fsum([*row['litter_nitrogen_gn_m2'], row['mineral_n_input_gn_m2']])
        c_net = math.fsum([carbon_input, -rh])
        n_net = math.fsum([nitrogen_input, -uptake])
        carbon_after = math.fsum(state.carbon)
        nitrogen_after = math.fsum([*state.nitrogen, state.mineral_nitrogen])
        cr = math.fsum([carbon_after, -math.fsum(old.carbon), -carbon_input, rh])
        nr = math.fsum([nitrogen_after, -math.fsum([*old.nitrogen, old.mineral_nitrogen]), -nitrogen_input, uptake])
        cb, nb = float(d['carbon_bound_gc_m2']), float(d['nitrogen_bound_gn_m2'])
        require(math.isfinite(cb) and math.isfinite(nb) and cb > 0 and nb > 0, 'Invalid original budget bounds')
        require(abs(cr) <= cb and abs(nr) <= nb, 'Independent step budget exceeds original bound')
        net_c.add(c_net); net_n.add(n_net); bounds_c.add(cb); bounds_n.add(nb)
        cumulative_c = math.fsum([carbon_after, -initial_c, -net_c.value])
        cumulative_n = math.fsum([nitrogen_after, -initial_n, -net_n.value])
        sum_cb, sum_nb = bounds_c.value, bounds_n.value
        require(abs(cumulative_c) <= sum_cb and abs(cumulative_n) <= sum_nb, 'Cumulative budget exceeds sum of original bounds')
        min_mineral = min(min_mineral, float(state.mineral_nitrogen))
        record = dict(index=index, time_start=row['time_start'], time_end=row['time_end'],
            independent_carbon_residual_gc_m2=cr, independent_nitrogen_residual_gn_m2=nr,
            original_carbon_residual_gc_m2=float(d['carbon_residual_gc_m2']),
            original_nitrogen_residual_gn_m2=float(d['nitrogen_residual_gn_m2']),
            original_carbon_bound_gc_m2=cb, original_nitrogen_bound_gn_m2=nb,
            cumulative_carbon_residual_gc_m2=cumulative_c, cumulative_nitrogen_residual_gn_m2=cumulative_n,
            cumulative_original_carbon_bound_gc_m2=sum_cb, cumulative_original_nitrogen_bound_gn_m2=sum_nb,
            mineral_nitrogen_before_gn_m2=float(old.mineral_nitrogen), mineral_nitrogen_after_gn_m2=float(state.mineral_nitrogen),
            nitrogen_limitation=float(d['nitrogen_limitation']),
            potential_immobilization_gn_m2=float(d['potential_immobilization_gn_m2']),
            immobilization_gn_m2=float(d['immobilization_gn_m2']), gross_mineralization_gn_m2=float(d['gross_mineralization_gn_m2']),
            plant_uptake_gn_m2=uptake, heterotrophic_respiration_gc_m2=rh,
            temperature_factor=float(d['temperature_factor']), moisture_factor=float(d['moisture_factor']),
            actual_normal_rate_multiplier=float(d['rate_multiplier']))
        ledger.append(record)
        month = months[row['time_start'][4:6]]
        month['intervals'] += 1
        for key in ('litter_carbon_gc_m2', 'litter_nitrogen_gn_m2'):
            month[key] = [math.fsum([a, float(b)]) for a, b in zip(month[key], row[key])]
        for key in ('mineral_n_input_gn_m2', 'plant_n_demand_gn_m2'):
            month[key] = math.fsum([month[key], row[key]])
        for key in ('plant_uptake_gn_m2', 'heterotrophic_respiration_gc_m2', 'immobilization_gn_m2', 'gross_mineralization_gn_m2'):
            month[key] = math.fsum([month[key], record[key]])
    for key, month in months.items():
        month['expected_intervals'] = None if expected_year is None else calendar.monthrange(expected_year, int(key))[1]*48
        month['complete'] = expected_year is not None and month['intervals'] == month['expected_intervals']
    return dict(source=api.identity, pool_order=list(POOLS), initial=snapshot(initial), final=snapshot(state),
        endpoint_stock_change=stock_delta(state, initial),
        initial_inventory_difference_from_explicit_baseline=None if baseline is None else stock_delta(initial, baseline),
        initial_inventory_difference_is_external_flux=False,
        initial_inventory_policy='Explicit C7/N7/mineral N; no derived/increased N and no fabricated compensating flux.',
        minimum_mineral_nitrogen_gn_m2=min_mineral,
        minimum_nitrogen_limitation=min(x['nitrogen_limitation'] for x in ledger),
        n_limited_intervals=sum(x['nitrogen_limitation'] < 1 for x in ledger),
        maximum_independent_absolute_step_c_n=[max(abs(x[k]) for x in ledger) for k in ('independent_carbon_residual_gc_m2', 'independent_nitrogen_residual_gn_m2')],
        maximum_independent_absolute_cumulative_c_n=[max(abs(x[k]) for x in ledger) for k in ('cumulative_carbon_residual_gc_m2', 'cumulative_nitrogen_residual_gn_m2')],
        cumulative_net_carbon_input_gc_m2=net_c.value, cumulative_net_nitrogen_input_gn_m2=net_n.value,
        cumulative_original_carbon_bound_gc_m2=bounds_c.value, cumulative_original_nitrogen_bound_gn_m2=bounds_n.value,
        months=months, complete_calendar_year=expected_year is not None and all(x['complete'] for x in months.values()),
        step_diagnostics=ledger, decomposition_module_steps=api.decomposition_module_steps-start_calls,
        synthetic_schedule_steps=len(rows), prescribed_soil_module_only=True, coupled_column_steps=0, gpu_steps=0,
        actual_field_years=0, usable_cold_configuration=False, scientific_acceptance_claim=False,
        scope='Normal1800s original soil decomposition with prescribed litter/N deposition/plant demand and oxygen1. No full plant/NPP feedback, cold export, field-year claim or SOC/spinup acceptance.')


def replay_bound_training_year(*args, **kwargs):
    binding = json.loads((HERE/'BINDINGS.json').read_bytes())
    require(binding['production_binding_sealed'] is True, 'OY production binding is unsealed; caller proof cannot override it')
    raise NotImplementedError('A reviewed OS-closed full-year byte binding for exactly eight training roots is still required')

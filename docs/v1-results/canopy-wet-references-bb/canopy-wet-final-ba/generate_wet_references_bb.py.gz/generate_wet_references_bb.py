from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,json,os,pickle,sys,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');s=Path(sys.argv[1]);r=Path(sys.argv[2]);r.mkdir();b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and all(sha(s/n)==h for n,h in m.items());start=time.monotonic();sys.path[:0]=[str(b),str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
target=json.loads((r.parent/'target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=4,failures=0,errors=0,skipped=0) and target['source_unchanged'] and target['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
from wet_reference_key_ap import reference_key
import test_gpu_canopy_interception as water
import test_gpu_canopy_phase_energy as phase
from noahmp_clm.physics.photosynthesis import LeafParameters
cache={};records=[];failure=None
def add(family,row,kwargs,label):
    key=reference_key(family,row,kwargs)
    if key in cache:records.append(dict(label=label,key=key,duplicate=True));return
    value=copy.deepcopy(water.reference(row) if family=='water' else phase.reference(row,**kwargs))
    if family=='phase':
        c=value['condensate'];value['condensate']=SimpleNamespace(mass=c.mass.copy(),enthalpy=c.enthalpy.copy(),temperature=c.temperature.copy(),ice=c.ice.copy(),liquid=c.liquid.copy())
    cache[key]=value;records.append(dict(label=label,key=key,duplicate=False))
try:
    for dtype in [np.float32,np.float64]:
        for family,module in [('water',water),('phase',phase)]:
            arrays=module.cases(dtype) if family=='water' else module.batch(dtype)
            for k,row in enumerate(zip(*arrays)):add(family,tuple(row),{},family+str(np.dtype(dtype))+':'+str(k))
    for name in ['canopy_phase_humidity_bound.json','canopy_phase_humidity_slow.json']:
        v=json.loads((s/'tests/fixtures'/name).read_text());row=tuple(np.asarray(x,np.int32 if k==8 else np.float64) for k,x in enumerate(v['arrays']));add('phase',row,dict(tolerance=1e-7),'humidity:'+name)
    for name in ['qia_479_phase_jacobian.npz','phase_edge_float64_stencil.npz']:
        with np.load(s/'tests/fixtures'/name,allow_pickle=False) as z:row=tuple(z['a'+str(k)] for k in range(9));extension=z['extension']
        add('phase',row,dict(exchange_extension=extension,tolerance=1e-7,max_iterations=80),'float64-jacobian:'+name)
    for name in ['qia_735_phase_oldwet.json','qia_1110_phase_kink.json']:
        for precision in ['32','64']:
            c=phase.oldwet_case(precision,name);add('phase',tuple(c['arrays']),dict(exchange_extension=c['extension'],leaf_parameters=LeafParameters(*np.asarray(c['parameters'],float)),tolerance=1e-7,max_iterations=80),'saved-existing:'+name+':'+precision)
except Exception as err:failure=type(err).__name__+': '+str(err);(r/'traceback.txt').write_text(traceback.format_exc())
(r/'references.pkl').write_bytes(pickle.dumps(cache,protocol=5));identical=sha(r/'references.pkl')=='38b31c59baa3266fa08cd21b4cd0b6c5021e15b6a4346824425e10d9e6e2e4c8';record=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,failure=failure,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),reference_model_and_test_bytes_sha256={n:h for n,h in m.items() if n.startswith('src/') or n in ['tests/test_gpu_canopy_interception.py','tests/test_gpu_canopy_phase_energy.py','tests/test_canopy_phase_energy.py','tests/test_gpu_snicar.py']},keys=len(cache),requested_records=records,reference_pickle_sha256=sha(r/'references.pkl'),all188_reference_results_pickle_byteidentical_to_AP=identical,seconds=time.monotonic()-start,scope='NewAZ actualEHPC NumPyreference188, original physicalinputs/results byteidenticalAP; two testexpectations corrected after observedphysicschange and two actual CPU recoverycoverage cases. Productioncode/adaptermath unchanged. No cachedfixture refreshed again, historicalcap1 values preserved. No GPU/canonical/year/sciencepass.')
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(failure=failure,keys=len(cache),results_byteidentical=identical,seconds=record['seconds'])),flush=True);assert failure is None and record['source_unchanged'] and len(cache)==188 and identical

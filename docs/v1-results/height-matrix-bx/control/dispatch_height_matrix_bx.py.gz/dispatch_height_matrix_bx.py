from pathlib import Path
import hashlib,json,os,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'height-matrix-bx';assert not r.exists();assert os.statvfs(b).f_favail>1000;r.mkdir();controls={}
for name in ['run_height_matrix_bx.py','height_matrix_bx.pbs','run_height_queue_bx.py','height-matrix-bx-package.json']:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/('package.json' if name.endswith('package.json') else name)).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'height_matrix_bx.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

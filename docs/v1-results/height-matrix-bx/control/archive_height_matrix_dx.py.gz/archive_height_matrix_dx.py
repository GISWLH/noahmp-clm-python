from pathlib import Path
import datetime,hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'height-matrix-bx';s=b/'height-summary-dm';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert (r/'pbs-exit.txt').read_text().strip()==(s/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());v=json.loads((s/'receipt.json').read_text());assert d['all27_numerically_complete'] and d['source_unchanged'] and v['complete']==v['expected']==27 and v['all_declared_scenarios_retained'] and v['source_unchanged'];queue=json.loads((r/'height-runs/queue.json').read_text());assert len(queue['cases'])==27
for case,row in queue['cases'].items():
    assert row['status']=='complete' and row['exit_code']==0;report=json.loads((r/'height-runs'/case/'report.json').read_text());assert report['source_unchanged'] and report['steps_completed']==report['steps_requested']==336
    for key in ['model_npz','checkpoint_file']:assert sha(r/'height-runs'/case/report[key])==report[key+'_sha256']
items=[]
for root,prefix in [(r,'matrix'),(s,'summary'),(b/'height-summary-dl','original-preparation')]:items.extend((p,prefix+'/'+p.relative_to(root).as_posix()) for p in sorted(root.rglob('*')) if p.is_file())
for n in ['height-inputs-a.tar.gz','clm-wet-coupled-final-bo-source.tar.gz','dispatch_height_matrix_bx.py','dispatch_height_summary_dm.py','route_held_height_dm.py',Path(__file__).name]:items.append((b/n,'control/'+n))
a=b/'height-matrix-bx-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),utc=datetime.datetime.now(datetime.timezone.utc).isoformat())),flush=True)

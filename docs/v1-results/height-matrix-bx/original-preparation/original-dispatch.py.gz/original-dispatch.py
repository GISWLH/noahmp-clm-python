from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'height-summary-dl';assert not r.exists();r.mkdir();controls={}
for n in ['summarize_height_matrix_dl.py','height_summary_dl.pbs','height-protocol-dl.json']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/('protocol.json' if n=='height-protocol-dl.json' else n)).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
assert controls['height-protocol-dl.json']=='d58c7c3151a258e13aa67ac50892e76781a1662ca9b78f49de535b5fde83b3a0'
dependency=[] if (b/'height-matrix-bx/pbs-exit.txt').exists() else ['-W','depend=afterany:390.manager'];command=['qsub',*dependency,str(r/'height_summary_dl.pbs')];p=subprocess.run(command,cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),depends_on='390.manager' if dependency else None,command=command,controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

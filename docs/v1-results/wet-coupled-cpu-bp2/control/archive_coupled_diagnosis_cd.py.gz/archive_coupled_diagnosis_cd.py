from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();groups=[('wet-coupled-cpu-bp2',['wet-coupled-cpu-bp'],['clm-wet-coupled-final-bo-source.tar.gz','dispatch_wet_coupled_cpu_bp.py']),('richards-producer-audit-by',['richards-invalid-audit-bv','richards-invalid-audit-bv2','richards-producer-audit-by'],['clm-wet-coupled-final-bo-source.tar.gz','dispatch_richards_invalid_bv.py','dispatch_richards_invalid_bv2.py','dispatch_richards_producer_by.py'])]
partial=b/'wet-coupled-cpu-bp-evidence.tar.gz';assert partial.exists();failure=b/'archive-preparation-ca-failure.json';assert not failure.exists();failure.write_text(json.dumps(dict(failure='CA archive preparation failed: missing prepare_wet_coupled_cpu_bp.py on EHPC; no numerical test failed',partial_archive_sha256=sha(partial),original_script_sha256=sha(b/'archive_coupled_diagnosis_ca.py'),partial_archive_retained=True),indent=2)+'\n')
for name,roots,controls in groups:
    for stem in roots:
        root=b/stem;assert (root/'pbs-exit.txt').read_text().strip()=='0'
        d=json.loads((root/('full-receipt.json' if stem=='wet-coupled-cpu-bp' else 'receipt.json')).read_text())
        if stem=='wet-coupled-cpu-bp':assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1093,failures=0,errors=0,skipped=0)
    items=[(p,stem+'/'+p.relative_to(b/stem).as_posix()) for stem in roots for p in sorted((b/stem).rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in [*controls,'archive_coupled_diagnosis_ca.py','archive-preparation-ca-failure.json',Path(__file__).name]);a=b/(name+'-evidence.tar.gz');assert not a.exists();assert all(p.is_file() for p,n in items)
    with tarfile.open(a,'w:gz') as tf:
        for p,n in items:tf.add(p,arcname=n,recursive=False)
    print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

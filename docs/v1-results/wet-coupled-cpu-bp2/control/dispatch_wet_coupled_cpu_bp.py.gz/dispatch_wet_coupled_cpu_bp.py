from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'wet-coupled-cpu-bp';assert not r.exists();r.mkdir();controls={}
for n in ['run_wet_coupled_cpu_bp.py','wet_coupled_cpu_bp.pbs','clm-wet-coupled-final-bo-package.json']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/('package.json' if n.endswith('package.json') else n)).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'wet_coupled_cpu_bp.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

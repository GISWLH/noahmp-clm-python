from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1'); r = b / 'all-phase-cpu-final-b'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
package = json.loads((r / 'package.json').read_text())
a = b / 'p6-all-phase-final-b-source.tar.gz'; assert sha(a) == package['archive_sha256'] == '1456f86a97f1a744da13d0a1805d3dfa815ef810d4c386799f47ac233b6ffef4'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text()); assert len(m) == 511 and all(sha(s / n) == h for n, h in m.items())
prior = b / 'all-phase-numpy-target-a'
q = json.loads((prior / 'phase-target-receipt.json').read_text())
assert (prior / 'pbs-exit.txt').read_text().strip() == '0' and q['returncode'] == 0 and q['counts'] == dict(tests=26, failures=0, errors=0, skipped=0)
(r / 'SOURCE_SHA256.json').write_bytes((s / 'SOURCE_SHA256.json').read_bytes())
env = os.environ.copy(); env.update(PYTHONPATH=':'.join(map(str, [b / 'test-deps', s, s / 'src', s / 'tests', s / 'benchmarks'])),
      PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1'); env.pop('NOAHMP_REQUIRE_GPU', None)
files = sorted(p.relative_to(s).as_posix() for p in (s / 'tests').glob('test_*.py') if not p.name.startswith(('test_gpu', 'test_jax', 'test_cuda')))
xml = r / 'cpu-full.xml'; start = time.monotonic()
with (r / 'cpu-full.log').open('x') as log:
    code = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-s', *files, '--junitxml=' + str(xml)], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
tree = ET.parse(xml).getroot(); counts = {k: sum(int(x.attrib[k]) for x in tree.iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
unchanged = all(sha(s / n) == h for n, h in m.items())
record = dict(scope='Final three-backend all-phase-edge source511 fullCPU911 exact originalpytest and solver/MHCN gates;NumPy26 reference prerequisite. No GPU/currentfull1254/year/science completion claimed.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, returncode=code, counts=counts, source_unchanged=unchanged, source_files=511,
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), seconds=time.monotonic() - start, xml_sha256=sha(xml))
(r / 'cpu-full-receipt.json').write_text(json.dumps(record, indent=2) + '\n'); print(json.dumps(record), flush=True)
assert code == 0 and unchanged and counts == dict(tests=911, failures=0, errors=0, skipped=0)
with (r / 'point735-controller.log').open('x') as log:
    code = subprocess.run([sys.executable, '-u', str(r / 'probe_all_phase735_final_b.py')], cwd=s, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
assert code == 0 and json.loads((r / 'point735-probe.json').read_text())['failure'] is None

"""Local metadata/hash/AST audit only; no model, pytest or numerical analysis."""
from pathlib import Path
import ast,datetime,gzip,hashlib,json,subprocess,tarfile

r=Path(__file__).resolve().parents[2];o=r/'outputs/v1';e=r/'docs/v1-results'
sha=lambda v:hashlib.sha256(v).hexdigest()
groups={
'ctsm-qia-copyall-o':'5e2639a82c893b66c8d6b327bafc55206777bed8648d513d61cebca9f0ab6ec7',
'qia-stem-cuda-year-terminal-c':'9c95ab9e033e10c0e8af9204fc31749f0dfbd37c05ae4602a70cddc25475ed21',
'qia163-warm-probes-a':'83261b17c7cf1e94704ceeec742e2cf9b371a23270542cd04d825e249af8c0a8',
'qia1519-probes-a':'352097db2fdaf56b8a875b0bf39b2f48590672073dbd6e2c334076859eb2a2bf',
'most-warm-cpu-c':'15d44099440f09798fe88f766de4854fe7dfc565a6e9d3dd54084b209e685391',
'most-full-deferred-c':'fb3a5062ed751f5ec6dd9e3e93cc46af91091f00b9ee367f64196e3fc3d6c1a0',
'qia-physical-numpy-launch-c':'f3ee43f2dc8c6e110b4a412188dd37532f715e2c5aa36cbb1c846c9f90868906',
'most-physical-gpu-c':'00d0be8461d623ab1bdde5f0f37c99e01c7ba7907175b202914bb677d1afdb88',
'qia-physical-cuda-launch-c':'09fdd67a0220fd3420c0161459b05b471f024a1e540a6645f46a3bed23831aaf'}
original={};count=0
for group,digest in groups.items():
    m=json.loads((e/group/'manifest.json').read_text());assert m['archive_sha256']==digest
    assert sha((o/(group+'-evidence.tar.gz')).read_bytes())==digest
    for item in m['artifacts']:
        stored=(e/group/item['path']).read_bytes();assert sha(stored)==item['stored_sha256']
        raw=gzip.decompress(stored) if item['path']==item['source']+'.gz' else stored
        assert sha(raw)==item['source_sha256'];original[group,item['source']]=raw;count+=1
        if item['source'].endswith('.py'):ast.parse(raw.decode('utf-8-sig'))
assert count==339
read=lambda group,name:json.loads(original[group,name])
m=json.loads((o/'p6-most-physical-c-source.json').read_text())
assert len(m)==509 and sha((o/'p6-most-physical-c-source.json').read_bytes())=='1c68b4f6f18c6b89610a1a53a4f2ba864dc0beb39e6c7f7dc4dc36a5a111f74a'
runtime={n:h for n,h in m.items() if n.startswith(('src/','tests/','benchmarks/'))}
assert all(sha((r/n).read_bytes())==h for n,h in runtime.items())
for n in runtime:
    if n.endswith('.py'):ast.parse((r/n).read_text(encoding='utf-8-sig'),filename=n)
with tarfile.open(o/'p6-phase-final-check-a-source.tar.gz') as t:
    old=json.loads(t.extractfile('SOURCE_SHA256.json').read())
    baseline=t.extractfile('src/noahmp_clm/physics/canopy_phase_energy.py').read()
changed=sorted(n for n,h in m.items() if old.get(n)!=h)
expected=sorted(['src/noahmp_clm/clm_enthalpy_driver.py','src/noahmp_clm/gpu/canopy_most_surface.py','src/noahmp_clm/physics/canopy_column.py','src/noahmp_clm/physics/canopy_most.py','src/noahmp_clm/physics/canopy_phase_energy.py','src/noahmp_clm/physics/most_physical_check.py','tests/test_canopy_phase_energy.py','tests/test_most_physical_check.py','tests/test_most_stagnation.py','tests/fixtures/qia_163_phase_warm.json'])
assert changed==expected
def phase_nodes(raw):
    f=next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name=='solve_canopy_phase_energy')
    functions={n.name:ast.dump(n,include_attributes=False) for n in f.body if isinstance(n,ast.FunctionDef)}
    defaults={a.arg:ast.dump(v,include_attributes=False) for a,v in zip(f.args.kwonlyargs,f.args.kw_defaults) if v is not None}
    return functions,defaults
oldfunctions,olddefaults=phase_nodes(baseline)
newfunctions,newdefaults=phase_nodes((r/'src/noahmp_clm/physics/canopy_phase_energy.py').read_bytes())
assert oldfunctions==newfunctions and all(newdefaults[k]==v for k,v in olddefaults.items())
assert newdefaults['max_iterations']==ast.dump(ast.Constant(80)) and newdefaults['initial_guess']==ast.dump(ast.Constant(None))
cpu=read('most-warm-cpu-c','cpu-full-receipt.json');assert cpu['returncode']==0 and cpu['counts']==dict(tests=909,failures=0,errors=0,skipped=0) and cpu['source_unchanged']
assert read('most-warm-cpu-c','SOURCE_SHA256.json')==m
assert original['most-warm-cpu-c','pbs-exit.txt'].strip()==b'0'
assert sha(original['most-warm-cpu-c','cpu-full.xml'])==cpu['xml_sha256']
for name,n in [('most-physical-regression',14),('phase-regression',24)]:
    d=read('most-warm-cpu-c',name+'-receipt.json');assert d['returncode']==0 and d['counts']==dict(tests=n,failures=0,errors=0,skipped=0)
for root,name,tests,failures in [('phase-warm-check-a','cpu-full',905,1),('most-physical-check-a','most-physical-regression',9,1),('most-physical-check-b','cpu-full',909,2)]:
    d=read('most-warm-cpu-c','prior/'+root+'/'+name+'-receipt.json');assert d['returncode']==1 and d['counts']==dict(tests=tests,failures=failures,errors=0,skipped=0)
probe=read('most-warm-cpu-c','probe.json');assert probe['failure'] is None and probe['source_unchanged'] and probe['pbs_job']=='209.manager'
for label in ('b','c'):
    prefix='p6-most-physical-'+label
    for backend in ('cuda32','jax32'):
        d=read('most-physical-gpu-c',prefix+'/production1519-'+label+'/'+backend+'/receipt.json')
        assert d['failure'] is None and d['source_unchanged'] and d['input_unchanged'] and d['device_barrier_complete'] and d['result']['fields']==361
        x=read('most-physical-gpu-c',prefix+'/production1519-controller-'+label+'/'+backend+'-exit.json');assert x['actual_returncode']==0
        if label=='c':assert d['source_manifest_sha256']=='1c68b4f6f18c6b89610a1a53a4f2ba864dc0beb39e6c7f7dc4dc36a5a111f74a'
    p=read('most-physical-gpu-c',prefix+'/production1519-'+label+'/jax32/same-precision.json');assert p['fields']==361 and not p['failures'] and all(v==0. for v in p['maximum_absolute'].values())
failed=read('qia-stem-cuda-year-terminal-c','trajectory/batch.json');assert failed['status']=='failed' and failed['steps_completed']==1519 and failed['same_precision_max_absolute'] is None
assert read('qia-stem-cuda-year-terminal-c','exit.json')['returncode']==1
official=read('ctsm-qia-copyall-o','summary.json');assert official['model_and_pbs_returncode']==0 and official['last_nstep']==17520
observation=read('most-full-deferred-c','observation.json');assert not observation['worker_exists'] and not observation['exit_exists']
for group,name in [('qia-physical-numpy-launch-c','report-snapshot.json'),('qia-physical-cuda-launch-c','batch-snapshot.json')]:
    d=read(group,name);assert d['status']=='running' and d['steps_requested']==17520 and d['steps_completed']==0
result=dict(scope='Local metadata/hash/AST only; all numerical tests,physics and analysis executed on EHPC PBS or xuanze. Runtime source exact frozen509C; packaged README/ROADMAP intentionally retained from earlier frozen base,latest repo docs separate. No model,pytest or numerical analysis on Windows; not science or complete canonical/year acceptance.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),archive_sha256=groups,artifacts_verified=count,source_files=509,runtime_files_verified=len(runtime),changed=changed,phase_nested_equations_and_original_defaults_unchanged=True,cpu909_actual_returncode=0,raw_gpu_fields=361,maximum_same_precision_difference=0.,official_intervals=17520,original_cuda_year_status='failed/1519',new_cold_launch_snapshot_steps=0,canonical1249_status='CPU909 passed; all340GPU deferred',script_sha256=sha(Path(__file__).read_bytes()))
(e/'most-warm-static-audit-c.json').write_text(json.dumps(result,indent=2)+'\n')
(e/'most-warm-static-audit-c.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(result))

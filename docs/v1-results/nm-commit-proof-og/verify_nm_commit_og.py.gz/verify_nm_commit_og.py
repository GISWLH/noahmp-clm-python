"""Verify actual committed NM code and newly published evidence, metadata only."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
COMMIT = sys.argv[1]
assert len(COMMIT) == 40 and all(c in '0123456789abcdef' for c in COMMIT)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
assert git('rev-parse', COMMIT + '^{commit}').decode().strip() == COMMIT
names = git('diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT).decode().splitlines()
rows = []
for name in names:
    if name.startswith('docs/v1-results/') and name.endswith('/manifest.json'):
        for item in json.loads(git('show', COMMIT + ':' + name))['artifacts']:
            path = (Path(name).parent / item['path']).as_posix()
            rows.append((path, item))
archive = ROOT / 'outputs/v1/climatology-final-candidate-nm-source.tar.gz'
assert sha(archive.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(archive) as tf:
    raw = tf.extractfile('SOURCE_SHA256.json').read()
    assert sha(raw) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    manifest = json.loads(raw)
    assert len(manifest) == 584
    frozen = {name: tf.extractfile(name).read() for name in manifest}
    assert all(sha(frozen[name]) == value for name, value in manifest.items())
tracked = git('ls-tree', '-r', '--name-only', COMMIT).decode().splitlines()
models = {n for n in frozen if n.startswith(('src/', 'tests/', 'benchmarks/'))}
assert len(models) == 569
assert models == {n for n in tracked if n.startswith(('src/', 'tests/', 'benchmarks/'))}
requested = [name for name, _ in rows] + list(frozen)
stream = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT,
    input=''.join(COMMIT + ':' + n + '\n' for n in requested).encode(),
    capture_output=True, check=True).stdout
cursor = 0
blobs = []
for name in requested:
    end = stream.index(b'\n', cursor)
    fields = stream[cursor:end].decode().split()
    assert len(fields) == 3 and fields[1] == 'blob', name
    size = int(fields[2]); cursor = end + 1
    blobs.append(stream[cursor:cursor + size]); cursor += size
    assert stream[cursor:cursor + 1] == b'\n'
    cursor += 1
assert cursor == len(stream)
for (name, item), raw in zip(rows, blobs):
    assert sha(raw) == item['stored_sha256'], name
    decoded = gzip.decompress(raw) if item['path'] == item['source'] + '.gz' else raw
    assert sha(decoded) == item['source_sha256'], name
allowed_documents = {'README.md', 'ROADMAP.md', 'docs/CLM_RICHARDS.md'}
line_endings, documentation = [], []
for (name, expected), raw in zip(frozen.items(), blobs[len(rows):]):
    if raw == expected:
        continue
    if name in allowed_documents:
        assert name not in models
        documentation.append(dict(path=name, committed_sha256=sha(raw), frozen_sha256=sha(expected)))
        continue
    assert name.endswith(('.py', '.cu', '.sh', '.md', '.json', '.toml', '.yml', '.yaml', '.txt', '.csv', '.tsv'))
    assert raw.replace(b'\r\n', b'\n') == expected.replace(b'\r\n', b'\n'), name
    if name.endswith('.json'):
        assert json.loads(raw) == json.loads(expected), name
    line_endings.append(name)
print(json.dumps(dict(commit=COMMIT, raw_artifacts_verified=len(rows), frozen_files_checked=584,
    model_test_benchmark_files_exact=569, documentation_divergence=documentation,
    text_line_ending_only_differences=line_endings,
    scope='Actual committed bytes; all569 runtime/test/benchmark files match frozen NM. '
          'Three named documentation progress files may differ; no physical execution or full-suite credit.')))

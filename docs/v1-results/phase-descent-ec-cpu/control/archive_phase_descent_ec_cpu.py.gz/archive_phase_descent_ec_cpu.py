from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-descent-ec-cpu';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'pbs-exit.txt').read_text().strip()=='0'
meta=json.loads((r/'package.json').read_text());d=json.loads((r/'full-receipt.json').read_text())
assert meta['manifest_sha256']==d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1120,failures=0,errors=0,skipped=0) and sha(r/'full.xml')==d['xml_sha256']
items=[(p,'cpu/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()]
items.extend((b/n,'control/'+n) for n in ['clm-phase-descent-ec-source.tar.gz','dispatch_phase_descent_ec_cpu.py',Path(__file__).name])
a=b/'phase-descent-ec-cpu-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

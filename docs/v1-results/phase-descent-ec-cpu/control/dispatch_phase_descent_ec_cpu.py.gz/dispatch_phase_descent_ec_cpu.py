from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'phase-descent-ec-cpu';assert not r.exists();r.mkdir();controls={}
for name,target in [('run_phase_descent_ec_cpu.py','run_phase_descent_ec_cpu.py'),('phase_descent_ec_cpu.pbs','phase_descent_ec_cpu.pbs'),('clm-phase-descent-ec-package.json','package.json')]:
    raw=(b/name).read_bytes();assert b'\r\n' not in raw;(r/target).write_bytes(raw);controls[target]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'phase_descent_ec_cpu.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr;d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

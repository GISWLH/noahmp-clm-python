from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-cuda-audit-b';sha=lambda raw:hashlib.sha256(raw).hexdigest();d=json.loads((r/'audit.json').read_text());assert (r/'pbs-exit.txt').read_text().strip()=='0' and d['passed'] and d['source_unchanged'] and d['source_manifest_sha256']=='d9205b75c2baa2eb4afef8f8f26cf961118d396d63b959f0af89435ee997eab6'
correction=dict(scope='352 original scope prose inherited1110/511B from template, retained unchanged. Actual numeric code asserts original3803 and uses563B source and exact original519H checkpoint. This is a metadata correction only, not a repeated physics result.',actual_step_index=3803,actual_source_manifest_sha256=d['source_manifest_sha256'],actual_original_checkpoint_sha256=d['original_checkpoint_sha256'],original_audit_sha256=sha((r/'audit.json').read_bytes()))
(r/'scope-correction.json').write_text(json.dumps(correction,indent=2)+'\n');a=b/'qia3803-cuda-audit-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    terminal=b/'qia-kink-cuda-year-h-failure-evidence.tar.gz';assert sha(terminal.read_bytes())=='97a00af253db5c23c5beca9f8bb26da7d805c04775572423318fbf8734862924'
    with tarfile.open(terminal) as tf:
        report=json.load(tf.extractfile('original-run/trajectory/batch.json'));assert report['status']=='failed' and report['steps_completed']==3803
        for name in ['original-run/trajectory/batch.json','original-run/trajectory/'+report['checkpoint_file']]:
            raw=tf.extractfile(name).read()
            if name.endswith(report['checkpoint_file']):assert sha(raw)==d['original_checkpoint_sha256']
            info=tarfile.TarInfo('original-ledger/'+Path(name).name);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    for n in ['full-reference.npz','receipt.json']:t.add(b/'qia3803-whole-reference-a'/n,arcname='numpy-reference/'+n,recursive=False)
    for n in ['dispatch_qia3803_cuda_audit_b.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,json,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-cuda-audit-b';assert not r.exists();r.mkdir();a=b/'qia3803-full-cuda32-b-evidence.tar.gz';digest=hashlib.sha256(a.read_bytes()).hexdigest()
with tarfile.open(a) as t:t.extractall(r/'device',filter='data')
assert json.loads((r/'device/exit.json').read_text())['passed'];controls={}
for n in ['audit_qia3803_cuda_b.py','qia3803_cuda_audit_b.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
job=subprocess.check_output(['qsub',str(r/'qia3803_cuda_audit_b.pbs')],cwd=r,text=True).strip();(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=job,device_archive_sha256=digest,controls_sha256=controls),indent=2)+'\n');print(job)

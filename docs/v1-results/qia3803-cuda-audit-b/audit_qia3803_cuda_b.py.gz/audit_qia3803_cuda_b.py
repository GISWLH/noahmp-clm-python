from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia3803-cuda-audit-b'
s = Path(os.environ['TMPDIR']) / 'source'; s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'phase-coordinate-native-b-source.tar.gz'
assert sha(a) == '4ccc9752ab61b6c3ddc3e66c667c0e6da4e8a868b3235000930c1cadb15c1c91'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 563 and all(sha(s / n) == h for n, h in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver

terminal = b / 'qia-kink-cuda-year-h-failure-evidence.tar.gz'
assert sha(terminal) == '97a00af253db5c23c5beca9f8bb26da7d805c04775572423318fbf8734862924'
td = Path(os.environ['TMPDIR']) / 'original-terminal'; td.mkdir()
with tarfile.open(terminal) as t:
    t.extractall(td, filter='data')
report = json.loads((td / 'original-run/trajectory/batch.json').read_text())
assert report['status'] == 'failed' and report['steps_completed'] == 3803
checkpoint = td / 'original-run/trajectory' / report['checkpoint_file']
assert sha(checkpoint) == report['checkpoint_sha256']
with np.load(checkpoint, allow_pickle=False) as z:
    saved = dict(z)
device = r / 'device'
binding = json.loads((device / 'binding.json').read_text())
receipt = json.loads((device / 'receipt.json').read_text())
assert receipt['failure'] is None and receipt['source_unchanged'] and receipt['device_barrier_complete']
assert binding['original_checkpoint_sha256'] == report['checkpoint_sha256'] and sha(device / 'input.npz') == binding['input_sha256']
with np.load(device / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
before = tuple(data['a' + str(k)] for k in range(19))
for k in range(19):
    np.testing.assert_array_equal(before[k], saved['a' + str(k)])
assert sha(device / 'output.npz') == receipt['result']['output_sha256']
assert sha(device / 'after.npz') == receipt['result']['state_sha256']
with np.load(device / 'output.npz', allow_pickle=False) as z:
    flat = dict(z)
with np.load(device / 'after.npz', allow_pickle=False) as z:
    after = tuple(z['a' + str(k)] for k in range(19))
out = {}
for name, value in flat.items():
    parts = name.split('/'); target = out
    for part in parts[:-1]:
        target = target.setdefault(part, {})
    target[parts[-1]] = value
assert receipt['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
with np.load(device/'before.npz',allow_pickle=False) as z:actual_before=tuple(z['a'+str(k)] for k in range(19))
for k in range(19):
    if k!=4:np.testing.assert_array_equal(actual_before[k],before[k])
    else:
        np.testing.assert_array_equal(actual_before[k][:,:7],before[k][:,:7]);np.testing.assert_array_equal(actual_before[k][:,10:],before[k][:,10:]);np.testing.assert_array_equal(actual_before[k][:,7:10],data['environment'])
before=actual_before
incoming, residual, bound, tracer = driver.audit_step(before, after, data['forcing'], data['deposition'], data['nitrogen'], out)
cumulative = driver.totals(after) - saved['initial'] - (saved['net'] + incoming)
cbound = saved['bounds'] + bound
assert np.all(abs(cumulative) <= cbound)
with np.load(b/'qia3803-whole-reference-a/full-reference.npz',allow_pickle=False) as z:reference=dict(z)
differences={}
for name in ['h','le','gpp_gc_m2','nee_gc_m2']:
    value=np.asarray(out['diagnostics'][name],float).reshape(-1);target=np.asarray(reference[name],float).reshape(-1)
    difference=float(np.max(abs(value-target)));differences[name]=difference
    absolute,near=(.0001,.001) if name.endswith('gc_m2') else (1.,10.)
    assert np.all(abs(value-target)<=np.where(abs(target)<=near,absolute,.1*abs(target)))
record = dict(scope='EHPC PBS original511B independent unchanged production MHCN/impurity audit of uninstrumented519H CUDA whole1110 step361raw/19next arrays. Exact originalfailed19state/initial/ledger verified; originalsoil/snow laws retained. NumPy reference on samequantizedphysicalstate computed independently onEHPC with normalroot normalization disclosed. All original step/cumulative bounds required;not accepted into failedyear,not JAX parity/fullcanonical/NumPy-whole-step/science acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=True, numpy_reference_absolute_differences=differences,
              step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(),
              cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=cbound.tolist(), impurity_residual=tracer.tolist(),
              source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'), source_unchanged=all(sha(s / n) == h for n, h in m.items()),
              original_checkpoint_sha256=report['checkpoint_sha256'], candidate_receipt_sha256=sha(device / 'receipt.json'),
              raw_fields=len(flat), next_state_arrays=19)
(r / 'audit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

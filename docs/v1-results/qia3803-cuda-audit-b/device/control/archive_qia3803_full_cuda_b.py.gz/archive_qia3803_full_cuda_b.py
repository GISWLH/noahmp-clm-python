from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia3803-full-cuda32-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text());assert e['returncode']==0 and e['passed'] and e['receipt_sha256']==sha(r/'receipt.json') and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['result']['output_sha256']==sha(r/'output.npz') and d['result']['state_sha256']==sha(r/'after.npz')
a=b/'qia3803-full-cuda32-b-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['phase-coordinate-native-b-source.tar.gz','phase-coordinate-native-b-package.json','run_qia3803_full_b.py','control_qia3803_full_b.py','launch_qia3803_full_b.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path('/home/lhwang/work/noahmp-v1/surface-root-ml');b=r.parent;stage=sys.argv[1];assert stage in ['cuda','pair','k78'];required=['point-cuda32'] if stage=='cuda' else (['point-cuda32','point-jax32'] if stage=='pair' else ['point-cuda32','point-jax32','k78-cuda32','k78-jax32']);sha=lambda raw:hashlib.sha256(raw).hexdigest();meta=json.loads((r/'candidate.json').read_text());m=json.loads((r/'CANDIDATE_SHA256.json').read_text());s=Path(meta['source']);assert all(sha((s/n).read_bytes())==h for n,h in m.items())
for mode in required:
    receipt=json.loads((r/mode/'receipt.json').read_text());exit=json.loads((r/(mode+'-exit.json')).read_text());assert exit['passed'] and exit['actual_parent_returncode']==0 and sha((r/mode/'receipt.json').read_bytes())==exit['receipt_sha256'] and receipt['failure'] is None and receipt['candidate_source_unchanged'] and receipt['device_barriers'] and sha((r/mode/'output.npz').read_bytes())==receipt['result']['output_sha256']
payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file() and (p.parent==r or p.parent.name in required)};payload['export-control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/('surface-root-ml-'+stage+'-export.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(a) as tf:
    assert len(tf.getmembers())==len(payload)
    for member in tf:assert tf.extractfile(member).read()==payload[member.name]
out=dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(payload),stage=stage,derived_manifest_sha256=meta['derived_manifest_sha256'],required_actual_computations=required,scope='PRIVATE ML originalNumPy20round midpointfallback port, frozen4filecandidate. RequiredactualGPU0/345raw/barriers/sourceunchanged only; stage-specific independentNumPy10percent/hardbudgets andpair1e-6 audit stillrequired. No failedyearresume, production/fullsuite/annual/scientific/release pass fromcompute0.');(b/('surface-root-ml-'+stage+'-export.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

from pathlib import Path
import hashlib,json,os,sys,time,traceback
import numpy as np
r=Path(__file__).resolve().parent;meta=json.loads((r/'candidate.json').read_text());s=Path(meta['source']);mode=sys.argv[1];point=mode.startswith('point-');backend_name=mode.split('-',1)[1];out=r/mode;out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((r/'CANDIDATE_SHA256.json').read_text());assert mode in ['point-cuda32','point-jax32','k78-cuda32','k78-jax32'] and len(m)==581 and all(sha(s/n)==h for n,h in m.items());prefix='point' if point else 'k78';assert sha(r/(prefix+'.npz'))==meta['inputs_sha256'][prefix];sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as runner
with np.load(r/(prefix+'.npz'),allow_pickle=False) as z:data=dict(z)
binding=json.loads((r/(prefix+'-binding.json')).read_text());engine=native.Backend(backend_name);source_prefix='a' if point or backend_name=='cuda32' else 'shadow';devices=tuple(engine.xp.asarray(np.ascontiguousarray(data[source_prefix+str(k)])) for k in range(16));devices=engine.update_forcing(devices,data['environment']);before=tuple(engine.host(v) for v in devices);kwargs=dict(environment=data['calendar_values'],calendar=data['calendar_flags'],nitrogen_deposition_gn_m2=data['nitrogen'],deposition=data['deposition'],most_geometry=data['geometry'],leaf_parameters=runner.LeafParameters(**binding['leaf_parameters']),return_surface=True)
if 'canopy_optics' in data:kwargs['canopy_optics']=data['canopy_optics']
if point:
    hydrology=runner.hydrology_configuration(binding['cases'][0]['configuration'])
    if hydrology is not None:kwargs['soil_hydrology']=hydrology
started=time.monotonic();failure=None;barriers=[];result_meta=None
try:
    device_result=engine.step(*devices,data['forcing'],**kwargs);result=engine.host(device_result);after=tuple(engine.host(v) for v in native.next_bgc_arrays(devices,device_result));flat={}
    def flatten(value,path=''):
        for key,item in value.items():
            if isinstance(item,dict):flatten(item,path+key+'/')
            else:flat[path+key]=np.asarray(item)
    flatten(result);flat.update({'before'+str(k):v for k,v in enumerate(before)});flat.update({'next'+str(k):v for k,v in enumerate(after)});assert len(flat)==345;np.savez_compressed(out/'output.npz',**flat)
    if backend_name=='cuda32':engine.xp.cuda.runtime.deviceSynchronize();barriers.append('cupy-complete')
    else:
        import jax
        jax.effects_barrier();barriers.append('jax-complete')
    result_meta=dict(raw_fields=345,columns=len(data['forcing']),output_sha256=sha(out/'output.npz'))
except Exception as e:failure=type(e).__name__+': '+str(e);(out/'traceback.txt').write_text(traceback.format_exc())
unchanged=all(sha(s/n)==h for n,h in m.items());receipt=dict(mode=mode,backend=backend_name,failure=failure,candidate_source_unchanged=unchanged,parent_manifest_sha256=meta['parent_manifest_sha256'],derived_manifest_sha256=meta['derived_manifest_sha256'],input_sha256=sha(r/(prefix+'.npz')),binding_sha256=sha(r/(prefix+'-binding.json')),device_barriers=barriers,result=result_meta,seconds=time.monotonic()-started,scope='PRIVATE ML fixedinput single-step only, point2657 or originalK78. OriginalNumPy after20 midpoint strategy synchronized to2 GPUroots, MDdensity retained, gates/60cap/physics/ABI unchanged. No failedyear continuation, NumPyforwardphysics onxuanze or production/scientific/release credit from computation0; independentfullfields/10percent/hardbudgets required.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);sys.stdout.flush();sys.stderr.flush();os._exit(0 if failure is None and unchanged and barriers else 1)

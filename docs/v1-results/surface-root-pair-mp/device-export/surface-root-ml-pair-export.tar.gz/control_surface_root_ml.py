from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[];meta=json.loads((r/'candidate.json').read_text())
for mode in ['point-cuda32','point-jax32','k78-cuda32','k78-jax32']:
    ack_name='point-cuda-reference-ack.json' if mode=='point-jax32' else ('point-pair-reference-ack.json' if mode=='k78-cuda32' else None)
    if ack_name:
        while not (r/ack_name).exists():time.sleep(20.)
        ack=json.loads((r/ack_name).read_text());assert ack['passed'] and ack['actual_pbs_exit']==0 and ack['derived_manifest_sha256']==meta['derived_manifest_sha256']
    while True:
        free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
        if free>8192 and mem>32*1024*1024:break
        time.sleep(20.)
    with (r/(mode+'-worker.log')).open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(r/'replay_surface_root_ml.py'),mode],stdout=log,stderr=subprocess.STDOUT)
    (r/(mode+'-worker.json')).write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();path=r/mode/'receipt.json';d=json.loads(path.read_text()) if path.exists() else {};row=dict(mode=mode,actual_parent_returncode=code,passed=bool(code==0 and d.get('failure') is None and d.get('candidate_source_unchanged') and d.get('device_barriers')),receipt_sha256=sha(path) if path.exists() else None);records.append(row);(r/(mode+'-exit.json')).write_text(json.dumps(row,indent=2)+'\n');assert row['passed'],mode
(r/'exit.json').write_text(json.dumps(dict(records=records,passed=True),indent=2)+'\n')

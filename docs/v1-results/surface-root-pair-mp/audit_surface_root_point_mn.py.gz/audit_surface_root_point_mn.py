"""Unchanged module science gates + original hard budgets for the fixed point."""
from pathlib import Path
import gzip,hashlib,json,os,pickle,re,subprocess,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=Path.cwd();stage=sys.argv[1];assert stage in ['cuda','pair'];tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();device=tmp/'device';device.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
parent=json.loads((s/'SOURCE_SHA256.json').read_text());parent_manifest=sha(s/'SOURCE_SHA256.json');assert len(parent)==581 and parent_manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in parent.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
import run_fluxnet_native as native
from test_gpu_clm_bgc_column import science,assert_science_close
package=json.loads((b/('surface-root-ml-'+stage+'-export.json')).read_text());archive=b/package['archive'];assert sha(archive)==package['sha256']
with tarfile.open(archive) as tf:tf.extractall(device,filter='data')
meta=json.loads((device/'candidate.json').read_text());patch=json.loads((device/'patch.json').read_text());derived=json.loads((device/'CANDIDATE_SHA256.json').read_text());assert sha(device/'CANDIDATE_SHA256.json')==meta['derived_manifest_sha256']==package['derived_manifest_sha256'] and meta['parent_manifest_sha256']==parent_manifest and set(derived)==set(parent) and len(patch['changes'])==4 and {n for n in parent if parent[n]!=derived[n]}==set(patch['changes'])
for name,d in patch['changes'].items():assert d['before_sha256']==parent[name] and hashlib.sha256(d['after_text'].encode()).hexdigest()==d['after_sha256']==derived[name]
refroot=b/'climatology-failed-reference-mi';ref=json.loads((refroot/'receipt.json').read_text());assert ref['passed'] and ref['all12_attempts_completed'] and ref['source_unchanged'];q=subprocess.check_output(['qstat','-xf','1537.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);(r/'reference-actual-qstat.txt').write_text(q);assert sha(device/'point.npz')==ref['diagnostic_input_sha256'] and (device/'point-binding.json').read_bytes()==(refroot/'binding.json').read_bytes()
with np.load(device/'point.npz',allow_pickle=False) as z:inputs=dict(z)
binding=json.loads((device/'point-binding.json').read_text());backends=['cuda32'] if stage=='cuda' else ['cuda32','jax32'];exports={};budgets={};results={};errors=[];started=time.monotonic()
for name in backends:
    mode='point-'+name;receipt=json.loads((device/mode/'receipt.json').read_text());exit=json.loads((device/(mode+'-exit.json')).read_text());assert exit['passed'] and exit['actual_parent_returncode']==0 and sha(device/mode/'receipt.json')==exit['receipt_sha256'] and receipt['failure'] is None and receipt['candidate_source_unchanged'] and receipt['device_barriers'] and receipt['derived_manifest_sha256']==meta['derived_manifest_sha256'] and sha(device/mode/'output.npz')==receipt['result']['output_sha256']
    with np.load(device/mode/'output.npz',allow_pickle=False) as z:flat=dict(z)
    assert len(flat)==345;before=tuple(flat['before'+str(k)] for k in range(16));after=tuple(flat['next'+str(k)] for k in range(16))
    for k in range(16):assert before[k].shape==inputs['a'+str(k)].shape and before[k].dtype==inputs['a'+str(k)].dtype and before[k].tobytes()==inputs['a'+str(k)].tobytes()
    out={}
    for key,value in flat.items():
        if re.fullmatch(r'(before|next)\d+',key):continue
        one=out;parts=key.split('/')
        for part in parts[:-1]:one=one.setdefault(part,{})
        one[parts[-1]]=value
    try:
        _,residual,bound,tracer=native.audit_step(before,after,inputs['forcing'],inputs['deposition'],inputs['nitrogen'],out);budgets[name]=dict(passed=True,residual_m_h_c_n=residual.tolist(),original_bounds_m_h_c_n=bound.tolist(),impurity_absolute_residual=tracer.tolist())
    except Exception as e:budgets[name]=dict(passed=False,failure=type(e).__name__+': '+str(e));errors.append(name+' originalhardbudget failed')
    rows=[]
    for k in range(12):
        reference=ref['results'][k];assert reference['passed'] and sha(refroot/reference['reference_file'])==reference['reference_sha256'];packet=pickle.loads(gzip.decompress((refroot/reference['reference_file']).read_bytes()));expected=packet['result'];failure=None;metrics={}
        try:
            one={key:({a:v[k] for a,v in value.items()} if key=='diagnostics' else value[k]) for key,value in out.items() if key in ['snow_cells','soil_cells','options','storage','diagnostics','impurity_output_kgm2','condensate']};metrics.update(science(one,expected,np.float32))
            for key in ['plant_state','soil_cn_state']:
                actual=out[key][k];value=expected[key];ci=[0,1,2,6] if key=='plant_state' else list(range(7));ni=[3,4,5,7] if key=='plant_state' else list(range(7,15));assert_science_close(actual[ci],value[ci],relative=.1,zero_floor=.001,absolute=.0001);assert_science_close(actual[ni],value[ni],relative=.1,zero_floor=.0001,absolute=.00001);metrics[key]=float(abs(actual-value).max())
            for key in ['gpp_gc_m2','npp_gc_m2','nee_gc_m2','autotrophic_respiration_gc_m2','heterotrophic_respiration_gc_m2','soil_respiration_gc_m2']:assert_science_close(out['diagnostics'][key][k],expected['diagnostics'][key],relative=.1,zero_floor=.001,absolute=.0001)
            for key in ['lai_used','lai_after','nitrogen_factor_used','nitrogen_factor_after']:assert_science_close(out['biogeochemistry'][key][k],expected['biogeochemistry'][key],relative=.1,zero_floor=.001,absolute=.0001)
            np.testing.assert_array_equal(out['phenology_flags'][k],expected['phenology_flags']);np.testing.assert_allclose(out['phenology_state'][k],expected['phenology_state'],rtol=.1,atol=1e-4);np.testing.assert_allclose(out['condensate'][k,:,0],expected['condensate'][:,0],rtol=.1,atol=1e-4);np.testing.assert_allclose(out['condensate'][k,:,1],expected['condensate'][:,1],rtol=.1,atol=1800.)
        except Exception as e:failure=type(e).__name__+': '+str(e);errors.append(name+' '+reference['case']+' originalsciencegate failed');(r/(name+'-case-'+str(k)+'-traceback.txt')).write_text(traceback.format_exc())
        rows.append(dict(column=k,case=reference['case'],passed=failure is None,failure=failure,maximum_absolute_differences=metrics,h_wm2=dict(gpu=float(out['diagnostics']['h'][k]),numpy=float(expected['diagnostics']['h'])),le_wm2=dict(gpu=float(out['diagnostics']['le'][k]),numpy=float(expected['diagnostics']['le'])),ground_root_residual_k=float(out['surface']['surface_temperature_residual'][k]),ground_root_bracket_k=out['surface']['surface_root_bracket_k'][k].tolist(),surface_evaluations=int(out['surface']['surface_evaluations'][k])))
    results[name]=rows;exports[name]=flat
same=[]
if stage=='pair':
    assert exports['cuda32'].keys()==exports['jax32'].keys()
    for key,x in exports['cuda32'].items():
        y=exports['jax32'][key];integer=x.dtype.kind in 'ibu';input_only=bool(re.fullmatch(r'before\d+',key));equal=x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes();good=x.dtype==y.dtype and x.shape==y.shape and (equal if integer or input_only else x.dtype==np.dtype('float32') and np.isfinite(x).all() and np.isfinite(y).all() and np.allclose(x,y,rtol=1e-6,atol=1e-6));difference=abs(x.astype(float)-y.astype(float));row=dict(field=key,passed=bool(good),bitwise_equal=equal,maximum_absolute_difference=float(difference.max(initial=0.)))
        if not good:errors.append('Original1e-6/int/dtype gate failed: '+key)
        same.append(row)
unchanged=all(sha(s/n)==h for n,h in parent.items());assert unchanged;record=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stage=stage,passed=not errors,errors=errors,seconds=time.monotonic()-started,parent_manifest_sha256=parent_manifest,derived_manifest_sha256=meta['derived_manifest_sha256'],independent_reference_source_unchanged=unchanged,device_export_sha256=sha(archive),reference_input_sha256=ref['diagnostic_input_sha256'],original_module_science=results,original_hard_budgets=budgets,raw_same_precision_fields=same,scope='ML originalNumPy20-round midpointfallback port onfixedfailed2657 point only. All12 savedindependentNumPyreference1537 precedeGPU; originalexistingmodule10percent/nearzero/soilabsolute/CN/condensate checks andalloriginalMHCN/fiveimpuritygates unchanged. Pair alsoall329model-next/16before raw1e-6/int/dtype. Physicalsteponly, no failedyear continuation, fullsuite/annual/observational/SOC orproductionpromotion credit.');(r/'audit.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps({k:record[k] for k in ['pbs_job','stage','passed','errors','seconds','derived_manifest_sha256']}),flush=True);raise SystemExit(0 if record['passed'] else 1)

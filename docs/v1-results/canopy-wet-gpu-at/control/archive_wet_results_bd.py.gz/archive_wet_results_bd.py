from pathlib import Path
import hashlib,json,sys,tarfile
mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[]
if mode=='gpu-at':
    b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-canopy-wet-final-aq';root=s/'gpu-at';d=json.loads((root/'exit.json').read_text());assert not d['passed'] and d['returncode']==1 and d['source_unchanged'];q=json.loads((root/'test_gpu_canopy_phase_energy-receipt.json').read_text());assert q['counts']==dict(tests=14,failures=2,errors=0,skipped=0) and q['node_coverage_exact'];assert json.loads((root/'test_gpu_canopy_interception-receipt.json').read_text())['passed'];roots=[root];controls=['clm-canopy-wet-final-aq-source.tar.gz','gpu-worker-lifecycle-a/run_pytest_worker_a.py'];name='canopy-wet-gpu-at'
    items.append((s/'SOURCE_SHA256.json','SOURCE_SHA256.json'))
else:
    b=Path('/home/zhangyq/noahmp-v1')
    if mode=='cpu-aq':
        roots=[b/'canopy-wet-final-aq',b/'canopy-wet-final-ar'];d=json.loads((roots[1]/'full-receipt.json').read_text());assert (roots[0]/'pbs-exit.txt').read_text().strip()=='1' and (roots[1]/'pbs-exit.txt').read_text().strip()=='0' and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=1091,failures=0,errors=0,skipped=0);controls=['clm-canopy-wet-final-aq-source.tar.gz','clm-canopy-wet-final-aq-package.json','dispatch_canopy_wet_final_aq.py','dispatch_canopy_wet_final_ar.py'];name='canopy-wet-cpu-ar'
    elif mode=='probe':
        root=b/'wet-humidity-probe-ay';d=json.loads((root/'receipt.json').read_text());assert (root/'pbs-exit.txt').read_text().strip()=='0' and d['source_unchanged'] and all(q['default']['restarts']==0 and any(v.get('restarts',0)>0 and v['failure'] is None for v in q['probes']) for q in d['records']);roots=[root];controls=['dispatch_wet_humidity_ay.py'];name='wet-humidity-probe-ay'
    elif mode=='refs-bb':
        root=b/'canopy-wet-final-ba';d=json.loads((root/'references/receipt.json').read_text());t=json.loads((root/'target-receipt.json').read_text());assert (root/'references-exit.txt').read_text().strip()=='0' and d['failure'] is None and d['source_unchanged'] and d['keys']==188 and d['all188_reference_results_pickle_byteidentical_to_AP'] and t['returncode']==0 and t['counts']==dict(tests=4,failures=0,errors=0,skipped=0);roots=[];items.extend((p,'canopy-wet-final-ba/references/'+p.name) for p in sorted((root/'references').iterdir()) if p.is_file());items.extend((root/n,'canopy-wet-final-ba/'+n) for n in ['references-exit.txt','references.log','target-receipt.json','target.xml','target.log','target-expected.json','SOURCE_SHA256.json','generate_wet_references_bb.py']);controls=['clm-canopy-wet-final-az-source.tar.gz','clm-canopy-wet-final-az-package.json','wet_reference_key_ap.py'];name='canopy-wet-references-bb'
    else:raise ValueError(mode)
for root in roots:
    for p in sorted(root.rglob('*')):
        if p.is_file():items.append((p,root.name+'/'+p.relative_to(root).as_posix()))
items.extend((b/n,'control/'+n) for n in [*controls,Path(__file__).name]);a=b/(name+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))))

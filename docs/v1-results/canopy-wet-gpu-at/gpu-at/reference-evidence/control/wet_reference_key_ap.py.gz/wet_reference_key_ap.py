import dataclasses,hashlib,json
import numpy as np

def reference_key(family,row,kwargs=None):
    h=hashlib.sha256();h.update(family.encode());kwargs=dict(kwargs or {})
    def array(value):
        a=np.asarray(value);h.update(a.dtype.str.encode());h.update(json.dumps(a.shape).encode());h.update(np.ascontiguousarray(a).tobytes())
    for value in row:array(value)
    if family=='phase':
        from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
        p=kwargs.pop('leaf_parameters',None)
        array(pack_leaf_parameters(dtype=row[0].dtype).astype(float) if p is None else np.asarray(dataclasses.astuple(p),float))
        extension=kwargs.pop('exchange_extension',None);h.update(b'none' if extension is None else b'extension')
        if extension is not None:array(np.asarray(extension,float))
        kwargs['tolerance']=kwargs.get('tolerance',1e-7);kwargs['max_iterations']=kwargs.get('max_iterations',80)
    h.update(json.dumps(kwargs,sort_keys=True,allow_nan=False).encode());return h.hexdigest()

from pathlib import Path
import numpy as np,jax,jax.numpy as j,cupy as cp
from check_canopy_phase_gpu import packed,cases,random_cases
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase,phase_energy_kernel_jax
from noahmp_clm.gpu.cuda.canopy_phase_energy import _kernel
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as rk
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.snicar import _jax_tables
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
indices=[41,48,56,58,67,68];raw=[*cases(),*random_cases(60)];arrays=packed([pack_canopy_phase(a,sw,lw,e,c,1800.,dtype=np.float32,**kw) for _,a,sw,lw,e,c,kw in [raw[i] for i in indices]],np.float32)

import inspect
import noahmp_clm.gpu.canopy_phase_energy as phase
source=inspect.getsource(phase.phase_energy_kernel_jax)
source=source.replace('iteration,x,restarts,avail,failed=state','iteration,x,restarts,avail,failed,trace=state')
source=source.replace('delta=delta/scale;norm=', 'rawdelta=delta;delta=delta/scale;norm=')
source=source.replace('retry=(~accepted)&avail','trace=trace.at[iteration].set(j.concatenate((x,r,jac.ravel(),rawdelta,delta,trial)))\n        retry=(~accepted)&avail')
source=source.replace('avail&(~retry),~(accepted|retry)','avail&(~retry),~(accepted|retry),trace')
source=source.replace('it,x,_,_,failed=state','it,x,_,_,failed,_=state')
source=source.replace('it,x,restarts,_,failed=lax.while_loop','it,x,restarts,_,failed,trace=lax.while_loop')
source=source.replace('available,j.asarray(False)))','available,j.asarray(False),j.zeros((100,204),u.dtype)))')
source=source.replace('return out.at[67].set(it+1).at[68].set(good.astype(u.dtype)).at[291].set(restarts)','return j.concatenate((out.at[67].set(it+1).at[68].set(good.astype(u.dtype)).at[291].set(restarts),trace.ravel()))')
ns=vars(phase).copy();exec(source,ns)
jp=j.asarray(pack_leaf_parameters(dtype=np.float32));tabs=_jax_tables('float32')
jrun=jax.jit(jax.vmap(lambda *row:ns['phase_energy_kernel_jax'](*row,jp,*tabs)))
ja=np.asarray(jrun(*tuple(map(j.asarray,arrays))))
a,u,f,soil,stem,c,b,snow,n=[cp.asarray(x) for x in arrays];area=cp.ascontiguousarray(a+stem);ru=cp.ascontiguousarray(radiation_inputs(area,u,cp));rad=cp.empty((len(a),584),cp.float32);rk(True)((1,),(32,),(area,snow,n,ru,*_tables(),rad,np.int32(len(a))))
base=Path(phase.__file__).parent/'cuda';src=(base/'canopy_phase_energy_kernel.cu').read_text()
src=src.replace('float x[12],ambient','float* trace=out+298;for(int i=0;i<20400;++i)trace[i]=0.f;\n    float x[12],ambient')
src=src.replace('for(int i=0;i<12;++i)rhs[i]=-r[i];phase_linear', 'for(int i=0;i<12;++i){trace[204*iteration+i]=x[i];trace[204*iteration+12+i]=r[i];}for(int i=0;i<144;++i)trace[204*iteration+24+i]=jac[i];\n        for(int i=0;i<12;++i)rhs[i]=-r[i];phase_linear')
src=src.replace('float scale=1.f;for(int i=0;i<12;++i)scale=', 'for(int i=0;i<12;++i)trace[204*iteration+168+i]=delta[i];\n        float scale=1.f;for(int i=0;i<12;++i)scale=')
src=src.replace('bool retry=!accepted&&available;', 'for(int i=0;i<12;++i){trace[204*iteration+180+i]=delta[i];trace[204*iteration+192+i]=chosen[i];}\n        bool retry=!accepted&&available;')
src=src.replace('out+row*298','out+row*20698')
source='\n'.join((base/p).read_text() for p in ('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu'))+'\n'+src
k=cp.RawKernel(source,'run_canopy_phase',options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'))
out=cp.empty((len(a),20698),cp.float32);params=cp.asarray(pack_leaf_parameters(dtype=np.float32));k((1,),(32,),(a,u,f,soil,stem,c,b,rad,params,out,np.int32(len(a)),np.int32(100),np.float32(.005)))
cu=cp.asnumpy(out);np.savez('phase-real-iteration.npz',jax=ja,cuda=cu)
for i,original in enumerate(indices):
 jtrace=ja[i,298:].reshape(100,204);ctrace=cu[i,298:].reshape(100,204)
 for iteration in range(min(int(ja[i,67]),int(cu[i,67]))-1):
  idx=np.where(jtrace[iteration]!=ctrace[iteration])[0]
  if len(idx):
   print('row',original,'first iteration',iteration,'diff',[(int(k),float(jtrace[iteration,k]),float(ctrace[iteration,k])) for k in idx[:40]],flush=True);break
 else:print('row',original,'identical trace',flush=True)
 print('row',original,'final max',float(np.max(abs(ja[i,:298]-cu[i,:298]))),flush=True)

"""CUDA-only first48 of all12 predeclared complete climate-year requests."""
from pathlib import Path
import hashlib,json,os,resource,sys,time,traceback
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');r=b/'ballberry-climatology-cuda-jt';s=Path('/tmp/noahmp-ballberry-climatology-cuda-jt/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_native as native
import run_fluxnet_column as numpy_runner
import noahmp_clm.clm_enthalpy_driver as numpy_driver
import noahmp_clm.physics.richards as numpy_flow
import cupy as cp
q=r/'inputs';protocol=json.loads((q/'protocol.json').read_text());assert protocol['source_manifest_sha256']==manifest and protocol['source_unchanged'] and protocol['case_count']==12 and protocol['native_state_arrays']==16 and protocol['cold_fields']==23 and sha(q/'cold-reference.npz')==protocol['cold_reference_sha256'] and sha(q/'batch.json')==protocol['batch_sha256'];assert all(sha(q/'configs'/(c['case']+'.json'))==c['configuration_sha256'] for c in protocol['cases'])
steps=r/'steps';steps.mkdir();captured=0;cold_checked=False;original_step=native.Backend.step;original_audit=native.audit_step;forbidden_originals=[numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy]
def no_cpu_forward(*a,**kw):raise AssertionError('CUDA climate integration cannot execute NumPy forward physics')
def check_cold(self,*args,**kwargs):
    global cold_checked
    if not cold_checked:
        report=json.loads((r/'trajectory/batch.json').read_text());assert report['status']=='running' and report['steps_completed']==0 and report['steps_requested']==17520 and report['identity'].get('native_state_arrays',16)==16 and not report['identity']['compare_jax32'];p=r/'trajectory'/report['checkpoint_file'];assert sha(p)==report['checkpoint_sha256']
        with np.load(p,allow_pickle=False) as a,np.load(q/'cold-reference.npz',allow_pickle=False) as ref:
            assert set(a.files)==set(ref.files) and len(a.files)==23
            for key in a.files:assert a[key].dtype==ref[key].dtype and a[key].shape==ref[key].shape and a[key].tobytes()==ref[key].tobytes(),key
        native.atomic_json(r/'cold-audit.json',dict(cold_fields_exact=23,primary_state_arrays=16,cases=12,cold_checkpoint_sha256=sha(p),cpu_reference_sha256=protocol['cold_reference_sha256'],source_manifest_sha256=manifest,scope='Every coldfield byteexact to owncurrentEHPC1184 beforefirsttendency; no previous/failed trajectory seed.'));cold_checked=True
    return original_step(self,*args,**kwargs)
def observe(before,after,forcing,deposition,nitrogen,out):
    global captured
    checked=original_audit(before,after,forcing,deposition,nitrogen,out);peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if peak>4*1024*1024:raise RuntimeError('CUDA-only validation exceeded4GiB measuredhostpeak')
    values=dict(forcing=np.asarray(forcing),deposition=np.asarray(deposition),nitrogen=np.asarray(nitrogen))
    for prefix,arrays in [('before',before),('after',after)]:
        assert len(arrays)==16;values.update({prefix+str(k):np.asarray(v) for k,v in enumerate(arrays)})
    def flatten(x,prefix='output/'):
        for k,v in x.items():
            if isinstance(v,dict):flatten(v,prefix+k+'/')
            else:values[prefix+k]=np.asarray(v)
    flatten(out)
    for name,v in zip(['incoming','residual','bound','impurity'],checked):values['recorded/'+name]=np.asarray(v)
    np.savez_compressed(steps/('call-'+str(captured).zfill(5)+'.npz'),**values);captured+=1;return checked
start=time.monotonic();failure=None;report={}
try:
    native.Backend.step=check_cold;native.audit_step=observe;numpy_runner.step_clm_enthalpy_column=no_cpu_forward;numpy_driver.step_clm_enthalpy_column=no_cpu_forward;numpy_flow.redistribute_soil_enthalpy=no_cpu_forward
    native.run(q/'batch.json',r/'trajectory',backend='cuda32',compare_jax32=False,stop_after=48)
    report,state,rows=native.read_generation(r/'trajectory');assert cold_checked and captured==48 and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['same_precision_max_absolute'] is None and report['source_unchanged'] and len(state)==23;native.atomic_json(r/'prefix-report.json',report)
except Exception as error:failure=type(error).__name__+': '+str(error);(r/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    native.Backend.step=original_step;native.audit_step=original_audit;numpy_runner.step_clm_enthalpy_column,numpy_driver.step_clm_enthalpy_column,numpy_flow.redistribute_soil_enthalpy=forbidden_originals
cp.cuda.runtime.deviceSynchronize();path=r/'trajectory/batch.json';report=json.loads(path.read_text()) if path.exists() else {};unchanged=all(sha(s/n)==h for n,h in m.items());d=dict(failure=failure,cold_fields_exact=23 if cold_checked else None,primary_state_arrays=16,cases=12,captured_step_calls=captured,maximum_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),source_unchanged=unchanged,source_manifest_sha256=manifest,device_barrier_complete=True,report_sha256=sha(path) if path.exists() else None,seconds=time.monotonic()-start,scope='ActualCUDA-only12x48 originalcoldprefixes of17520, physical1, aftercurrentGPU37+NumPy1156+NumPy12x48. All16before/after/fulloutputs, originalMHCN/impurity. No JAXshadow/NumPyforward. Independentcompute audit required, no year/spinup/sciencecredit. CuPybarrier anddurable receipt beforeprocess-localatexit bypass.');native.atomic_json(r/'receipt.json',d);print(json.dumps(d),flush=True);os._exit(0 if failure is None and unchanged else 1)

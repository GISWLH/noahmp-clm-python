"""GPU array equality audit only; no model integration or input modification."""
from pathlib import Path
import hashlib,json,os,sys
import numpy as np
import cupy as cp

b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-physical-cuda-year-c';s=b/'p6-most-physical-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==509 and all(sha(s/n)==v for n,v in m.items())
assert json.loads((r/'exit.json').read_text())['returncode']==1
report=json.loads((r/'trajectory/batch.json').read_text());assert report['status']=='running' and report['steps_completed']==48 and report['source_unchanged'] and report['same_precision_max_absolute'] is None
assert sha(r/'trajectory'/report['checkpoint_file'])==report['checkpoint_sha256']
cold=list((r/'trajectory').glob('state-0000000-*.npz'));assert len(cold)==1
with np.load(cold[0],allow_pickle=False) as a,np.load(r/'strict-cold-reference.npz',allow_pickle=False) as ref:
    assert len(a.files)==26 and set(a.files)<=set(ref.files)
    omitted=sorted(set(ref.files)-set(a.files));assert omitted and all(k.startswith('shadow') for k in omitted)
    for k in a.files:
        assert a[k].dtype==ref[k].dtype and bool(cp.array_equal(cp.asarray(a[k]),cp.asarray(ref[k]))),k
old=b/'qia-stem-cuda-day-b/trajectory';previous=json.loads((old/'batch.json').read_text());assert previous['status']=='running' and previous['steps_completed']==48
assert set(report['case_reports'])==set(previous['case_reports']) and len(report['case_reports'])==1
count=0
for case,desc in report['case_reports'].items():
    p=r/'trajectory'/case/desc['file'];assert sha(p)==desc['sha256'];d=json.loads(p.read_text())
    op=old/case/previous['case_reports'][case]['file'];assert sha(op)==previous['case_reports'][case]['sha256'];od=json.loads(op.read_text())
    p=p.parent/d['model_npz'];op=op.parent/od['model_npz'];assert sha(p)==d['model_npz_sha256'] and sha(op)==od['model_npz_sha256']
    with np.load(p,allow_pickle=False) as a,np.load(op,allow_pickle=False) as ref:
        assert set(a.files)==set(ref.files)
        for k in a.files:assert a[k].dtype==ref[k].dtype and bool(cp.array_equal(cp.asarray(a[k]),cp.asarray(ref[k]))),k
        count+=len(a.files)
cp.cuda.runtime.deviceSynchronize()
assert all(sha(s/n)==v for n,v in m.items())
d=dict(scope='Read-only GPU equality audit of new C successful48 after original parent postprocessor failed on strict-vs-CUDA-only field sets. Physical model status remains running/48,source unchanged. All26 primary/index/ledger fields exact against original strict cold input; only22 shadow-prefixed extra fields omitted. All22 trace fields exactly replay previous CUDA48,not a new-source NumPy/GPP/FLUXNET science claim. No model integration or original failure record edited.',source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),model_status='running',steps_completed=48,original_parent_returncode=1,primary_cold_fields_exact=26,excluded_reference_shadow_fields=omitted,previous_cuda48_trace_fields_exact=count,report_sha256=sha(r/'trajectory/batch.json'),checkpoint_sha256=report['checkpoint_sha256'],maximum_cumulative_m_h_c_n=report['maximum_cumulative_residual_m_h_c_n'],device_barrier_complete=True)
(r/'day48-primary-audit.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.stdout.flush();os._exit(0)

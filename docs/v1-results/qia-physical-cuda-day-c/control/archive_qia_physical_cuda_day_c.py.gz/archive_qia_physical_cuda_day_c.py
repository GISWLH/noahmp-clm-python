from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-physical-cuda-year-c';a=b/'qia-physical-cuda-day-c-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((r/'exit.json').read_text())['returncode']==1
d=json.loads((r/'day48-primary-audit-b.json').read_text());assert d['source_unchanged'] and d['primary_cold_fields_exact']==26 and d['previous_cuda48_trace_fields_exact']==22
assert json.loads((r/'day48-primary-audit-exit.json').read_text())['actual_returncode']==1
assert json.loads((r/'day48-primary-audit-b-exit.json').read_text())['actual_returncode']==0
assert sha(r/'trajectory/batch.json')==d['report_sha256']
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['run_qia_physical_cuda_year_c.py','control_qia_physical_cuda_year_c.py','launch_qia_physical_cuda_year_c.py','audit_qia_physical_cuda_day_c.py','control_qia_physical_day_audit_c.py','audit_qia_physical_cuda_day_b.py','control_qia_physical_day_audit_b.py','archive_qia_physical_cuda_day_c.py']:
        t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='New frozen509C successful ownCUDA48,originalparent1 solely on strict-shadow field-set postcheck. Original array-audit1 on ISO text dtype retained; corrected read-only GPU numeric/string metadata audit actual0,primary26 and previousCUDA48 trace22exact. Full MHCN model prefix valid running48,same_precisionNone,not full year/science.')))

from pathlib import Path
import json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia-physical-cuda-year-c';env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with (r/'day48-primary-audit.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(b/'audit_qia_physical_cuda_day_c.py')],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(r/'day48-primary-audit-exit.json').write_text(json.dumps(dict(actual_returncode=code))+'\n');print(json.dumps(dict(actual_returncode=code)));raise SystemExit(code)

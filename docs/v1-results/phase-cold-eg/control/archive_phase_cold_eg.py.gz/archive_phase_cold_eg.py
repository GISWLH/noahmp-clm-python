from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[]
for name in ['phase-cold-inputs-ef','qia-phase-capacity-numpy-cold-eg','qia-phase-capacity_optics-numpy-cold-eg']:
    r=b/name;assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and d['source_manifest_sha256']=='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
    if 'numpy-cold' in name:
        assert d['failure'] is None and d['status']=='running' and d['steps_completed']==48 and d['steps_requested']==17520 and sha(r/'trajectory/report.json')==d['report_sha256']
        report=json.loads((r/'trajectory/report.json').read_text())
        for k,h in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:assert sha(r/'trajectory'/report[k])==report[h]
    items.extend((p,name+'/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file())
for name in ['qia-phase-cold-ef-inputs.tar.gz','qia-phase-cold-ef-package.json',Path(__file__).name]:items.append((b/name,'control/'+name))
a=b/'phase-cold-eg-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

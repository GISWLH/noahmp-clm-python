"""NumPy-first original48 of each predeclared17520 climate-year request."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import gzip,hashlib,io,json,os,pickle,sys,tarfile,time,traceback

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-numpy-cold-gl';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(a)=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and all(sha(s/n)==v for n,v in m.items());a=b/'multisite-climatology-gk-inputs.tar.gz';assert sha(a)=='58681704d4a88d47c6b0eaf00403d1f870f4ce7887337cb1b39bf2453b7a19cc';assert (b/'multisite-climatology-inputs-gk/pbs-exit.txt').read_text().strip()=='0';inputs=r/'inputs';inputs.mkdir()
with tarfile.open(a) as tf:tf.extractall(inputs,filter='data')
protocol=json.loads((inputs/'protocol.json').read_text());assert protocol['source_manifest_sha256']==manifest and protocol['source_unchanged'] and protocol['case_count']==12 and protocol['native_state_arrays']==16 and protocol['cold_fields']==23
full=json.loads((b/'soil-stress-coupled-fl-cpu/full-receipt.json').read_text());assert full['returncode']==0 and full['source_unchanged'] and full['source_manifest_sha256']==manifest and full['counts']==dict(tests=1148,failures=0,errors=0,skipped=0);sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
batch=json.loads((inputs/'batch.json').read_text());assert len(batch['cases'])==12;(r/'runs').mkdir();(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());started=time.monotonic()

def run_case(case):
    folder=r/'runs'/case['case'];folder.mkdir();captures=folder/'steps.tar.gz';packets=tarfile.open(captures,'w:gz');counter=0;original=runner.step_clm_enthalpy_column;start=time.monotonic();failure=None
    def capture(state,forcing,**kwargs):
        nonlocal counter
        try:after,d=original(state,forcing,**kwargs)
        except Exception:
            blob=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs),protocol=5),mtime=0);member=tarfile.TarInfo('failed-before-'+str(counter).zfill(5)+'.pkl.gz');member.size=len(blob);packets.addfile(member,io.BytesIO(blob));raise
        blob=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs,after=after,diagnostics=d),protocol=5),mtime=0);member=tarfile.TarInfo('call-'+str(counter).zfill(5)+'.pkl.gz');member.size=len(blob);packets.addfile(member,io.BytesIO(blob));counter+=1;return after,d
    try:
        runner.step_clm_enthalpy_column=capture;report=runner.run(inputs/case['input'],inputs/case['input_manifest'],inputs/case['configuration'],folder/'trajectory',stop_after=48);assert counter==48 and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and report['source_unchanged']
    except Exception as e:failure=type(e).__name__+': '+str(e);(folder/'traceback.txt').write_text(traceback.format_exc())
    finally:runner.step_clm_enthalpy_column=original;packets.close()
    path=folder/'trajectory/report.json';report=json.loads(path.read_text()) if path.exists() else {};record=dict(case=case['case'],failure=failure,captured_steps=counter,step_packet_archive_sha256=sha(captures),status=report.get('status'),steps_completed=report.get('steps_completed'),steps_requested=report.get('steps_requested'),source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),configuration_sha256=sha(inputs/case['configuration']),report_sha256=sha(path) if path.exists() else None,seconds=time.monotonic()-start,scope='Actualcurrent579 NumPy originalcold48 of17520; allstate/forcing/diagnostics captured for independentdevice audit. All12 predeclaredsoilIC/BGCmappings remain, originalMHCN/impurity. Running48 is not year/spinup/scienceacceptance.');(folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');return record

records=[]
with ProcessPoolExecutor(max_workers=12) as pool:
    for record in pool.map(run_case,batch['cases']):
        records.append(record);(r/'progress.json').write_text(json.dumps(dict(completed_cases=len(records),requested_cases=12,cases=records),indent=2)+'\n');print(json.dumps(record),flush=True)
passed=all(q['failure'] is None and q['source_unchanged'] and q['captured_steps']==q['steps_completed']==48 and q['steps_requested']==17520 for q in records);result=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=passed,cases=records,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),input_archive_sha256=sha(a),seconds=time.monotonic()-started,scope='Actual12 independent NumPy48 prefixes and all576step input/output captures, Official2000nonzeroBC/dust/Ninputs, parentzeroCOLD23unchanged; eachcaseall48trustedpacketslosslesslytarred. No failedprefix resume, no newmath/test/gate changes. Readyfor nativecold48 comparison, not fullclimateyears/coupledspinup/observationalpass.');(r/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'}),flush=True);assert passed and result['source_unchanged']

"""Allactualcoldvalidationartifacts after625/628/641, fullrawtrustedpackets."""
from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'climatology-cuda-cold-go-evidence.tar.gz';assert sha(a)=='4951cdec8cb97417c61a471afa8ed9064595b7f9dc1b8e7eaa8f28c7fe6e1c37';out=b/'climatology-cold-validation-gu-evidence.tar.gz';assert not out.exists();items=[]
for name in ['climatology-numpy-cold-gl','climatology-numpy-cold-gn','climatology-cold-audit-gp','climatology-cold-summary-gv']:
    root=b/name;assert (root/'pbs-exit.txt').read_text().strip()=='0'
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if rel.parts[0]=='inputs' and p.suffix=='.npz' and p.name!='cold-reference.npz':continue
        items.append((p,name+'/'+rel.as_posix()))
d=json.loads((b/'climatology-cold-audit-gp/receipt.json').read_text());assert d['passed'] and d['source_unchanged'] and len(d['cases'])==12 and all(q['passed'] and q['all48_actual_deposition_inputs_byteexact_to_declared_climatology'] for q in d['cases']);inventory=[]
with tarfile.open(out,'w:gz') as t:
    with tarfile.open(a) as original:
        for member in original:
            assert member.isfile();raw=original.extractfile(member).read();inventory.append(dict(path=member.name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
            if member.name.startswith('current/inputs/CN-') and member.name.endswith('.npz'):continue
            t.addfile(member,io.BytesIO(raw))
    for p,n in items:t.add(p,arcname=n,recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False);raw=(json.dumps(dict(original_device_archive_sha256=sha(a),all_original_device_members=inventory,scope='OnlythreefullweatherNPZmembersleftinoriginalfrozenarchive; all48devicepackets/currentstates/control/configs andbothGL/GNall576trustedNumPypackets/receipts/trajectories preservedhere. GL/GNidentitieskeptseparate, metadataequivalenceverified627.'),indent=2)+'\n').encode();info=tarfile.TarInfo('device-original-inventory.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(out) as t:count=len(t.getnames());assert count==len(set(t.getnames()))
print(json.dumps(dict(name='climatology-cold-validation-gu',sha256=sha(out),bytes=out.stat().st_size,artifacts=count,scope='Actualcurrent579 nonzeroGM625NumPy12x48+GOphysical1CUDAparent0+628all576independentpairs0+641numericreadback0. EachactualquantizedBC/dust/N/weatherinput byteexact todeclaredschedule, originalMHCN/impurity/science/nearzero/r andC/Npoolgates. Allrawstepdata preserved, no fullJAXshadow/sameprecision/year/spinup/FLUXNETscientificacceptance.')),flush=True)

"""Actual first-day CUDA32 vs independent NumPy64; no observational claim."""
from pathlib import Path
import json,hashlib
import numpy as np
from noahmp_clm.validation import compare_series
base=Path('/home/lhwang/work/noahmp-v1')
root=base/'p6-native-fluxnet-b'
source=base/'p6-newton-leaf-a/continuity-checks'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for case in ['CN-Cng-tq6-w2','CN-Qia-tq39.6-w39.6','CN-Cha-tq61.8-w61.8']:
    native=root/'height-cuda-a'/case; reference=source/case
    a=json.loads((native/'report.json').read_text());b=json.loads((reference/'report.json').read_text())
    assert a['steps_completed']>=48 and b['steps_completed']==48
    for k in ['forcing_npz_sha256','forcing_manifest_sha256','configuration_sha256']:
        assert a[k]==b[k],(case,k)
    common={k:v for k,v in b['source_sha256'].items() if k.startswith('src/')}
    assert all(a['source_sha256'][k]==v for k,v in common.items())
    ap=native/'trace-0000048.npz';bp=reference/'trace-0000048.npz'
    assert sha(bp)==b['model_npz_sha256']
    with np.load(ap) as x,np.load(bp) as y:
        for k in ['time_start','time_end']:np.testing.assert_array_equal(x[k],y[k])
        assert str(x['time_start'][0]).endswith('0000') and str(x['time_end'][-1]).endswith('0000')
        variables={}
        for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),
            ('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),
            ('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),
            ('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
            aa=x[key].astype(float)*factor+offset;bb=y[key].astype(float)*factor+offset
            metrics=[compare_series(aa[:,j],bb[:,j],var) for j in range(4)] if aa.ndim==2 else [compare_series(aa,bb,var)]
            assert all(v['bias_pass'] for v in metrics),(case,key,metrics)
            if key in ('h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2'):
                assert all(v['correlation_pass'] for v in metrics),(case,key,metrics)
            variables[key]=metrics
        rows.append({'case':case,'configuration_sha256':a['configuration_sha256'],
            'forcing_npz_sha256':a['forcing_npz_sha256'],'native_trace_sha256':sha(ap),'numpy_trace_sha256':sha(bp),
            'shared_model_python_files_identical':len(common),'metrics':variables})
report={'scope':'First complete local day, three predeclared baseline stations, CUDA32 versus independent continuous NumPy64; input/config identities exact, native input quantization explicit. Not FLUXNET observation acceptance or spinup.',
    'instrument_sha256':sha(Path(__file__)),'source_manifest_sha256':sha(root/'SOURCE_SHA256.json'),'steps_per_station':48,'cases':rows}
(root/'native-numpy-day-comparison.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
for row in rows:
    print(row['case'],{k:{'bias':v[0]['bias'],'relative_bias_percent':None if v[0]['relative_bias'] is None else 100*v[0]['relative_bias'],'r':v[0]['r'],'maximum_absolute':v[0]['max_absolute_difference']} for k,v in row['metrics'].items() if k in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2']},flush=True)

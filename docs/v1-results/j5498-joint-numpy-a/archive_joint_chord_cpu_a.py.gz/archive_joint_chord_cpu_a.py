from pathlib import Path
import hashlib,io,json,tarfile
base=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,folder,files in [
 ('j5498-joint-numpy-a','j5498-joint-numpy-a',['probe_j5498_joint_numpy_a.py','j5498_joint_numpy_a.pbs','reference.json','reference.log','pbs-exit.txt','node.txt']),
 ('joint-chord-cpu-a','joint-chord-cpu-a',['run_joint_chord_cpu_a.py','joint_chord_cpu_a.pbs','receipt.json','cpu-full.log','cpu-full.xml','pbs-exit.txt','node.txt','SOURCE_SHA256.json'])]:
    root=base/folder;archive=base/(name+'-evidence.tar.gz');assert not archive.exists()
    assert (root/'pbs-exit.txt').read_text().strip()=='0'
    paths=[(n,root/n) for n in files]
    if name=='j5498-joint-numpy-a':paths.append(('SOURCE_SHA256.json',base/'p6-spinup-assessment-c/SOURCE_SHA256.json'))
    with tarfile.open(archive,'w:gz') as t:
        for n,p in paths:assert p.is_file();t.add(p,arcname=n,recursive=False)
        t.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
    print(json.dumps(dict(name=name,sha256=sha(archive),files=len(paths)+1)))

from pathlib import Path
import hashlib,json,os,time
import numpy as np
from test_gpu_column_heat import numpy_reference
assert os.environ.get('PBS_JOBID');root=Path.cwd();source=Path('/home/zhangyq/noahmp-v1/p6-spinup-assessment-c');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
path=root/'joint-inputs.npz';assert sha(path)=='992c7371ed87da40ae00bd8cbfa99fbba97c8afa83578420e433fbcc72a6d3b0'
with np.load(path,allow_pickle=False) as z:c,p,o,b=[z[k] for k in ['cells','props','options','boundary']]
begun=time.monotonic();h,t,d=numpy_reference(c[0],p[0],o[0],b[0]);assert all(sha(source/n)==v for n,v in m.items())
value=dict(scope='Independent NumPy64 exact inner joint-heat reference for original fixed HaM boundary; no source/forcing/parameter/iteration/tolerance change.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,input_sha256=sha(path),source_unchanged=True,enthalpy_jm2=h.tolist(),temperature_k=t.tolist(),ledger={k:np.asarray(v).tolist() for k,v in d.items()},seconds=time.monotonic()-begun)
(root/'reference.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

"""PBSreadback: correctingcurrentmetadata mustnotchangeonephysicalvalue."""
from pathlib import Path
from dataclasses import fields,is_dataclass
from enum import Enum
import gzip,hashlib,json,os,pickle,struct,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'climatology-metadata-verification-gr';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(a)=='6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(a) as t:t.extractall(s,filter='data')
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')];manifest=sha(s/'SOURCE_SHA256.json');m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==579 and all(sha(s/n)==h for n,h in m.items());count=0
def exact(a,b,path=''):
    global count
    assert type(a) is type(b),(path,type(a),type(b))
    if isinstance(a,np.ndarray):assert a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes(),path;count+=1
    elif isinstance(a,np.generic):assert a.dtype==b.dtype and a.tobytes()==b.tobytes(),path;count+=1
    elif is_dataclass(a):
        for f in fields(a):exact(getattr(a,f.name),getattr(b,f.name),path+'/'+f.name)
    elif isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for k in a:exact(a[k],b[k],path+'/'+str(k))
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b),path
        for k,(x,y) in enumerate(zip(a,b)):exact(x,y,path+'/'+str(k))
    elif isinstance(a,float):assert struct.pack('>d',a)==struct.pack('>d',b),path;count+=1
    elif isinstance(a,Enum):assert a.value==b.value,path;count+=1
    else:assert a==b,path;count+=1
old=b/'climatology-numpy-cold-gl';new=b/'climatology-numpy-cold-gn';left=json.loads((old/'receipt.json').read_text());right=json.loads((new/'receipt.json').read_text());assert (old/'pbs-exit.txt').read_text().strip()==(new/'pbs-exit.txt').read_text().strip()=='0' and left['passed'] and right['passed'] and left['source_manifest_sha256']==right['source_manifest_sha256']==manifest and len(left['cases'])==len(right['cases'])==12;rows=[]
for la,rb in zip(left['cases'],right['cases']):
    name=la['case'];assert name==rb['case'] and la['failure'] is rb['failure'] is None and la['configuration_sha256']!=rb['configuration_sha256'];folders=[root/'runs'/name for root in [old,new]];reports=[json.loads((p/'trajectory/report.json').read_text()) for p in folders];assert all(q['status']=='running' and q['steps_completed']==48 and q['steps_requested']==17520 for q in reports);assert reports[0]['source_sha256']==reports[1]['source_sha256'] and reports[0]['forcing_npz_sha256']==reports[1]['forcing_npz_sha256'] and reports[0]['forcing_manifest_sha256']==reports[1]['forcing_manifest_sha256']
    with np.load(folders[0]/'trajectory'/reports[0]['model_npz'],allow_pickle=False) as a,np.load(folders[1]/'trajectory'/reports[1]['model_npz'],allow_pickle=False) as z:
        assert set(a.files)==set(z.files) and len(a.files)==18
        for k in a.files:exact(a[k],z[k],name+'/trace/'+k)
    saved=[pickle.loads((p/'trajectory'/q['checkpoint_file']).read_bytes()) for p,q in zip(folders,reports)];assert len(saved[0])==len(saved[1])==7;exact(saved[0],saved[1],name+'/checkpoint')
    archives=[p/'steps.tar.gz' for p in folders];assert sha(archives[0])==la['step_packet_archive_sha256'] and sha(archives[1])==rb['step_packet_archive_sha256']
    with tarfile.open(archives[0]) as t,tarfile.open(archives[1]) as u:
        assert t.getnames()==u.getnames() and len(t.getnames())==48
        for member in t.getnames():exact(pickle.loads(gzip.decompress(t.extractfile(member).read())),pickle.loads(gzip.decompress(u.extractfile(member).read())),name+'/'+member)
    rows.append(dict(case=name,old_configuration_sha256=la['configuration_sha256'],current_configuration_sha256=rb['configuration_sha256'],all18_trajectory_fields_byteexact=True,all7_checkpoint_fields_physical_values_byteexact=True,all48_input_output_packet_fields_exact=True,scope='ActualoldGLandcurrentGNareseparateexecutions/identities; no relabellingoldhash/currentrun. Metadatafixed, allphysicalvalues unchanged.'))
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,cases=rows,checked_exact_leaves=count,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==h for n,h in m.items()),physical_step_pairs=576,scope='Actualreadback ofall12old/currentmetadataNumPycold48 executions, allrawtrustedpackets/18traces/7tuple exact. Bothactualreturncodes0, currentconfigurationhashesdifferentandexplicitlyretained. No physics/inputrate/date/state/testgatechanges; notdevice/year/spinup/observationalpass.');(r/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(passed=True,cases=12,physical_step_pairs=576,checked_exact_leaves=count,source_unchanged=out['source_unchanged'])),flush=True)

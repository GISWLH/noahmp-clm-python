"""Metadata-onlyprovenance/independentinputauditarchive, no modelcalculation."""
from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=[('multisite-climatology-inputs-gj','1'),('multisite-climatology-inputs-gk','0'),('multisite-climatology-inputs-gm','0'),('climatology-metadata-verification-gr','0')];items=[]
for name,exitcode in roots:
    root=b/name;assert (root/'pbs-exit.txt').read_text().strip()==exitcode
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if rel.parts[0]=='inputs' and p.suffix=='.npz' and p.name!='cold-reference.npz':continue
        items.append((p,name+'/'+rel.as_posix()))
root=b/'climatology-metadata-verification-gq';assert (root/'superseded-unstarted.json').exists();items.extend((p,root.name+'/'+p.name) for p in sorted(root.iterdir()) if p.is_file());current=json.loads((b/'multisite-climatology-inputs-gm/receipt.json').read_text());assert current['source_unchanged'] and current['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69' and current['case_count']==12 and current['all_cold_fields_byteexact_to_parent_zero_input'];comparison=json.loads((b/'climatology-metadata-verification-gr/receipt.json').read_text());assert comparison['passed'] and comparison['source_unchanged'] and len(comparison['cases'])==12 and comparison['physical_step_pairs']==576 and comparison['checked_exact_leaves']==357372
names=['deposition-official-gi-package.json','multisite-climatology-gm-package.json','release_satisfied_analysis_dependency_gq.py','dispatch_climatology_metadata_gr.py','dispatch_climatology_gj.py','dispatch_climatology_gk.py','dispatch_climatology_gm.py',Path(__file__).name];items.extend((b/n,'control/'+n) for n in names);a=b/'climatology-inputs-gs-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p,n in items:t.add(p,arcname=n,recursive=False)
print(json.dumps(dict(name='climatology-inputs-gs',sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),scope='Actualrawofficialgrid/unit/spatial/annualtimeinputaudit6240; exactall23parentcoldfields,12configspluscorrectcurrentmetadata/historicalparentnotes. Original465SciPyorderfailure,622oldermetadata0,and626staleunstartedwait/failedqalter/cancellation retained;627comparesall576GL/GNpackets357372leavesexact, no physicschangefrommetadatacorrection. RawofficialNetCDF andfullforcingremainfrozenbydeclaredhashoutsideGit; independentnumericmetrics/provenance/configsallincluded. Notyear/spinup/observationalpass.')),flush=True)

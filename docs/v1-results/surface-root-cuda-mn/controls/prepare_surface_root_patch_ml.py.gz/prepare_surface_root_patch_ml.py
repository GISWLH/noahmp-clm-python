"""Static private port of the existing NumPy safeguarded-root fallback."""
from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;md=json.loads((r/'snow-candidate-md-patch.json').read_text());changes=dict(md['changes'])
with tarfile.open(r/'clm-ballberry-jn-source.tar.gz') as tf:
    parent=json.loads(tf.extractfile('SOURCE_SHA256.json').read());numpy_code=tf.extractfile('src/noahmp_clm/physics/canopy_column.py').read().decode().replace('\r\n','\n');assert 'material_bracket or iteration>=20' in numpy_code
    rules={
        'src/noahmp_clm/gpu/cuda/canopy_surface_kernel.cu':('float span=right-left,trial=left-(fl*span)/(fr!=fl?fr-fl:1.f);','''float span=right-left;
        // Match the NumPy reference: after20 secants, bisect the same
        // bracket. This guarantees progress within the unchanged60 rounds.
        float trial=k<20?left-(fl*span)/(fr!=fl?fr-fl:1.f):left+.5f*span;'''),
        'src/noahmp_clm/gpu/canopy_surface.py':('width=s(right-left);trial=s(left-s(fl*width)/j.where(fr!=fl,s(fr-fl),1.))','''width=s(right-left);secant=s(left-s(fl*width)/j.where(fr!=fl,s(fr-fl),1.))
        # Match the NumPy fallback without changing root or budget gates.
        trial=j.where(k<20,secant,s(left+s(.5*width)))''')}
    for name,(before,after) in rules.items():
        raw=tf.extractfile(name).read();assert hashlib.sha256(raw).hexdigest()==parent[name];text=raw.decode().replace('\r\n','\n');assert text.count(before)==1;text=text.replace(before,after);changes[name]=dict(before_sha256=parent[name],after_sha256=hashlib.sha256(text.encode()).hexdigest(),after_text=text)
for name,d in changes.items():
    assert d['before_sha256']==parent[name] and hashlib.sha256(d['after_text'].encode()).hexdigest()==d['after_sha256'];p=r/'surface-root-ml'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(d['after_text'],encoding='utf-8',newline='\n')
out=dict(parent_source_manifest_sha256=md['parent_source_manifest_sha256'],density_parent_derived_manifest_sha256='5118b142c11de8e788a2eaf452e067e435337510bc371d3c9db8bb0d4bbe805b',changes=changes,reference_numpy_root_file='src/noahmp_clm/physics/canopy_column.py',reference_numpy_root_sha256=parent['src/noahmp_clm/physics/canopy_column.py'],original_iteration_cap=60,secant_rounds_before_bisection=20,original_gates_unchanged=True,scope='PRIVATE ML: MD2 densityfiles plus2 GPU sharedsurface root functions. Port existingNumPy iteration>=20 midpointfallback, same originalbracket/materialbranch setup/60cap/residual-width stopping/hardbudgets andABI. No wholeDeltaT/Thomas/AHC/sourceproduction/liveyear changes. ActualMI12 NumPyreferences/MF MDK78strict/MKsamefailedinputs precedeGPUvalidation; not acceptancefromstaticpatch.')
(r/'surface-root-ml-patch.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print({n:v['after_sha256'] for n,v in changes.items()})

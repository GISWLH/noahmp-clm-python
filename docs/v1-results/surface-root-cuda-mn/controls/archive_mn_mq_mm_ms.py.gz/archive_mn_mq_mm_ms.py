"""Pack closed controls/results with actual terminal job proof; no model run."""
from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,job,extra in [('surface-root-cuda-mn','1540.manager',['surface-root-ml-cuda-export.json','surface-root-ml-cuda-export.tar.gz']),('climatology-reported-prefix-mq','1541.manager',[])]:
    r=b/label;q=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M) and (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/('audit.json' if 'cuda-mn' in label else 'receipt.json')).read_text());assert d.get('passed',d.get('evaluation_delivered'))
    (r/'actual-qstat.txt').write_text(q);payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()}
    for name in extra:payload['device/'+name]=(b/name).read_bytes()
    if 'cuda-mn' in label:
        for name in ['prepare_surface_root_patch_ml.py','replay_surface_root_ml.py','control_surface_root_ml.py','launch_surface_root_ml.py','surface-root-ml-patch.json','export_surface_root_ml.py']:
            p=b/name;assert p.is_file();payload['controls/'+name]=p.read_bytes()
    payload['controls/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/(label+'-evidence.tar.gz');assert not a.exists()
    with tarfile.open(a,'w:gz') as t:
        for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);t.addfile(member,io.BytesIO(raw))
    with tarfile.open(a) as t:
        assert len(t.getmembers())==len(payload)
        for member in t:assert t.extractfile(member).read()==payload[member.name]
    out=dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(payload),scope=d['scope']);(b/(label+'-package.json')).write_text(json.dumps(out,indent=2)+'\n');print(label,json.dumps(out),flush=True)
label='closed-diagnostic-archive-mm';receipt=Path('/tmp/noahmp-closed-winter-mm/receipt.json');pointer=b/'multisite-winter-energy-he/closed-file-archive-mm.json';assert receipt.is_file() and pointer.is_file();hj=b/'winter-energy-hj-evidence.tar.gz';assert sha(hj)=='9cc5d5154de32ff44bf06e27cd0e50473c7f4b686cca2cc2dce8e8ac9811f3dc';payload={'receipt.json':receipt.read_bytes(),'preserved-pointer.json':pointer.read_bytes(),'control/compact_completed_winter_mm.py':Path('/tmp/compact_completed_winter_mm.py').read_bytes(),'control/'+Path(__file__).name:Path(__file__).read_bytes()};a=b/(label+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);t.addfile(member,io.BytesIO(raw))
with tarfile.open(a) as t:
    for member in t:assert t.extractfile(member).read()==payload[member.name]
out=dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(payload),scope='168 terminal diagnostic duplicates exacttoexisting completeHJarchive andfullTMPrestore beforeunlink; latest144reports/states/traces/receipts plus inputs/source/livework retained. Parent fullarchive remains unchanged; metadata packing isnot a physical/scientific pass.');(b/(label+'-package.json')).write_text(json.dumps(out,indent=2)+'\n');print(label,json.dumps(out),flush=True)

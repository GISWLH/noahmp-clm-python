from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'audit_ctsm_qia_year_boundary_a.py').read_text()
old = "for name in ['DZSOI', 'ZSOI', 'levgrnd', 'levsoi']:"
assert p.count(old) == 1
p = p.replace(old, "for name in ['DZSOI', 'ZSOI'] + [n for n in ['levgrnd', 'levsoi'] if n in d.variables]:")
ast.parse(p)
(r / 'audit_ctsm_qia_year_boundary_b.py').write_bytes(p.encode())
p = (r / 'compare_ctsm_qia_native_firstday_a.py').read_text().replace("r = b / 'ctsm-qia-native-firstday-a'", "r = b / 'ctsm-qia-native-firstday-b'")
p = p.replace("audit = json.loads((official / 'year-boundary.json').read_text())", "analysis = b / 'ctsm-qia-year-inspection-b'\naudit = json.loads((analysis / 'year-boundary.json').read_text())\nrecovered = json.loads((analysis / 'receipt.json').read_text())\nassert (analysis / 'pbs-exit.txt').read_text().strip() == '0' and all(s['returncode'] == 0 for s in recovered['stages'])\nassert sha(analysis / 'year-boundary.json') == recovered['audit_sha256']")
p = p.replace("(official / 'pbs-exit.txt').read_text().strip() == '0'", "(official / 'pbs-exit.txt').read_text().strip() == '1'")
p = p.replace("all(s['returncode'] == 0 for s in case['stages'])", "all(s['returncode'] == 0 for s in case['stages'] if s['stage'] != 'year-boundary-audit')\nassert [s['returncode'] for s in case['stages'] if s['stage'] == 'year-boundary-audit'] == [1]")
p = p.replace("official / 'official-year-fields.npz'", "analysis / 'official-year-fields.npz'")
p = p.replace("official_configuration_sha256=sha(official / 'configuration.json'),", "official_configuration_sha256=sha(official / 'configuration.json'), original_official_model_returncode=0, original_parent_pbs_returncode=1, postread_receipt_sha256=sha(analysis / 'receipt.json'),")
ast.parse(p)
(r / 'compare_ctsm_qia_native_firstday_b.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_native_firstday_a.pbs').read_text().replace('ctsm-qia-native-firstday-a', 'ctsm-qia-native-firstday-b').replace('compare_ctsm_qia_native_firstday_a.py', 'compare_ctsm_qia_native_firstday_b.py').replace('clm-qia-native-day-a', 'clm-qia-native-day-b')
(r / 'ctsm_qia_native_firstday_b.pbs').write_bytes(p.encode())

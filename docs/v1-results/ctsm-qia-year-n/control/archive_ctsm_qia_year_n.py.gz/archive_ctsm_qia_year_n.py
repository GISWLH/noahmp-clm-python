from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

b = Path('/home/zhangyq/noahmp-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
case = b / 'ctsm-qia-run-n'
d = json.loads((case / 'configuration.json').read_text())
assert (case / 'pbs-exit.txt').read_text().strip() == '1' and d['official_model_returncode'] == 0 and d['upstream_original_bytes_unchanged']
assert all(s['returncode'] == 0 for s in d['stages'] if s['stage'] != 'year-boundary-audit')
assert [s['returncode'] for s in d['stages'] if s['stage'] == 'year-boundary-audit'] == [1]
inspection = b / 'ctsm-qia-year-inspection-c'
receipt = json.loads((inspection / 'receipt.json').read_text())
audit = json.loads((inspection / 'year-boundary.json').read_text())
assert (inspection / 'pbs-exit.txt').read_text().strip() == '0' and all(s['returncode'] == 0 for s in receipt['stages'])
assert sha(inspection / 'year-boundary.json') == receipt['audit_sha256'] and sha(inspection / 'official-year-fields.npz') == receipt['fields_sha256']
assert audit['positive_intervals'] == 17520 and all(audit['first48_M_physical_arrays_byte_value_equal'].values())
comparison = b / 'ctsm-qia-native-firstday-c'
diagnosis = json.loads((comparison / 'diagnosis.json').read_text())
assert (comparison / 'pbs-exit.txt').read_text().strip() == '0' and diagnosis['scientific_acceptance'] is False
assert diagnosis['official_fields_sha256'] == receipt['fields_sha256']
private = case / 'case-configuration-private.tar.gz'
assert sha(private) == receipt['original_private_sha256']
a = b / 'ctsm-qia-year-n-evidence.tar.gz'
assert not a.exists()
samples, steps = 0, []
with tarfile.open(a, 'w:gz') as t:
    for name in ['ctsm-qia-run-n', 'ctsm-qia-year-inspection-b', 'ctsm-qia-year-inspection-c', 'ctsm-qia-native-firstday-a', 'ctsm-qia-native-firstday-b', 'ctsm-qia-native-firstday-c']:
        r = b / name
        for p in sorted(r.iterdir()):
            if p.is_file() and p.name != 'case-configuration-private.tar.gz':
                t.add(p, arcname=name + '/' + p.name, recursive=False)
    with tarfile.open(private) as original:
        for m in original:
            if m.isfile() and (m.name.endswith(('.stdout.txt', '.stderr.txt', '-adaptation.json', '.stream')) or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in', 'drv_in', 'lnd_in'])) or m.name.startswith('case/user_nl_')):
                raw = original.extractfile(m).read()
                info = tarfile.TarInfo(case.name + '/workspace/' + m.name)
                info.size = len(raw)
                t.addfile(info, io.BytesIO(raw))
                if 'lnd.log.' in m.name:
                    text = raw.decode(errors='replace')
                    samples += text.count('Writing current time sample')
                    steps.extend(map(int, re.findall(r'clm: completed timestep\s+(\d+)', text)))
    assert samples == 17521 and max(steps) == 17520
    summary = dict(scope='Actual pinned official N complete17520 requested intervals model0,55.515s; original parentPBS1 because postreader wrongly required levsoi coordinate. B also wrongly required static DZSOI in later history file. C actual inventory/read-only postanalysis0 verifies complete original calendar,all common first48 physical fields exactly replay M and preserves full17520 output fields. No official model rerun/source edits, all failures retained. Native48 cold-state/SP-CN mismatches and raw numeric differences reported, no science acceptance.',
                   official_model_returncode=0, original_parent_pbs_returncode=1, official_seconds=d['seconds'],
                   official_model_seconds=next(s['seconds'] for s in d['stages'] if s['stage'] == 'official-model'),
                   upstream_original_bytes_unchanged=True, written_history_samples=samples, last_nstep=max(steps),
                   original_configuration_sha256=sha(case / 'configuration.json'), original_private_sha256=sha(private),
                   inspection_receipt=receipt, year_boundary_audit=audit, cold_firstday_diagnosis=diagnosis,
                   canceled_dependents='PBS188 and190 afterok dependencies canceled after postreader failure; neither ran a model or comparison.')
    raw = (json.dumps(summary, indent=2) + '\n').encode()
    info = tarfile.TarInfo('summary.json')
    info.size = len(raw)
    t.addfile(info, io.BytesIO(raw))
    t.add(Path(__file__), arcname='control/' + Path(__file__).name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=sha(a), bytes=a.stat().st_size, model_returncode=0, original_parent_pbs_returncode=1, complete_intervals=17520, history_samples=samples, last_nstep=max(steps))))

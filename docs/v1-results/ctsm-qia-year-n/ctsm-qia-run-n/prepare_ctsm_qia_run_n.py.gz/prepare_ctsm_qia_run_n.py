from pathlib import Path
import ast
import hashlib
import json

r = Path(__file__).resolve().parent
original = r / 'run_ctsm_qia_m.py'
p = original.read_text().replace('ctsm-qia-run-m', 'ctsm-qia-run-n')
assert p.count('STOP_N=48,') == p.count('hist_mfilt = 48') == 1
p = p.replace('STOP_N=48,', 'STOP_N=17520,').replace('hist_mfilt = 48', 'hist_mfilt = 17520')
old = "child.communicate(timeout=1200 if label=='case-build' else 180)"
assert p.count(old) == 1
p = p.replace(old, "child.communicate(timeout=1200 if label=='case-build' else (600 if label=='official-model' else 180))")
marker = "            value['official_model_returncode']=model_code"
assert p.count(marker) == 1
p = p.replace(marker, marker + "\n            if model_code==0:\n                assert run('year-boundary-audit',[py,str(root/'audit_ctsm_qia_year_boundary_a.py'),str(scratch),str(root)],rundir)==0\n                value['year_boundary_audit']=json.loads((root/'year-boundary.json').read_text())")
p = p.replace('first-execution attempt,5 snow', 'full17520-step engineering reference,5 snow')
ast.parse(p)
(r / 'run_ctsm_qia_n.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_run_m.pbs').read_text().replace('ctsm-qia-run-m', 'ctsm-qia-run-n').replace('run_ctsm_qia_m.py', 'run_ctsm_qia_n.py').replace('clm-qia-official-m', 'clm-qia-official-n')
(r / 'ctsm_qia_run_n.pbs').write_bytes(p.encode())
record = dict(scope='M to N only extends original SP engineering experiment from48 to original17520 intervals and history file capacity,adds read-only year-boundary audit and declared600s annual-model time bound. Same common meteorology/PFT/geometry/soil/initial state and unchanged2930 upstream source; not matched-soil/CN/scientific acceptance.',
              original_controller_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
              changed_controller_sha256=hashlib.sha256((r / 'run_ctsm_qia_n.py').read_bytes()).hexdigest(),
              audit_sha256=hashlib.sha256((r / 'audit_ctsm_qia_year_boundary_a.py').read_bytes()).hexdigest())
(r / 'ctsm-qia-run-n-control.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

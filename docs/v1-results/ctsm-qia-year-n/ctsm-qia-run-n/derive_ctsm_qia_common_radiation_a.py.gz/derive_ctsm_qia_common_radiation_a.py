"""Create standard DATM direct/diffuse fields from fixed native input on PBS."""
from pathlib import Path
import hashlib
import json
import os
import sys

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
met, native_root = map(Path, sys.argv[1:3])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original_sha = sha(met)
protocol = json.loads((native_root.parent / 'protocol.json').read_text())
assert all(sha(native_root / n) == v for n, v in protocol['inputs_sha256'].items())
with np.load(native_root / 'CN-Qia.npz', allow_pickle=False) as z:
    forcing = np.asarray(z['forcing'], float)
    environment = np.asarray(z['environment'], float)
assert forcing.shape == (17520, 8) and environment.shape == (17520, 3)

def attributes(value):
    return {n: repr(value.getncattr(n)) for n in value.ncattrs()}

def fingerprint(d):
    rows = {}
    for n, v in d.variables.items():
        a = np.ma.asarray(v[:])
        assert not np.any(np.ma.getmaskarray(a)), n
        a = np.asarray(a)
        rows[n] = dict(dtype=str(a.dtype), dimensions=v.dimensions, shape=a.shape,
                       attributes=attributes(v), data_sha256=hashlib.sha256(a.tobytes(order='C')).hexdigest())
    return rows

with Dataset(met, 'r+') as d:
    before, before_attrs = fingerprint(d), attributes(d)
    sw = np.asarray(d['FSDS'][:], float)
    assert np.array_equal(sw.reshape(17520), forcing[:, 5])
    fraction = environment[:, 2].reshape(sw.shape)
    assert np.all((fraction >= 0) & (fraction <= 1)) and np.all(np.isfinite(fraction))
    direct, diffuse = sw * (1 - fraction), sw * fraction
    assert np.max(abs(direct + diffuse - sw)) <= 1.e-10
    for name, value, label in [('SWDNDIR_COMMON', direct, 'direct'), ('SWDNDF_COMMON', diffuse, 'diffuse')]:
        assert name not in d.variables
        v = d.createVariable(name, 'f8', d['FSDS'].dimensions)
        v.units = 'W m-2'
        v.long_name = 'Common fixed native Erbs ' + label + ' downwelling shortwave'
        v[:] = value
    assert attributes(d) == before_attrs
    after = fingerprint(d)
    assert {n: after[n] for n in before} == before
with Dataset(met) as d:
    assert all(fingerprint(d)[n] == v for n, v in before.items())
    assert np.array_equal(np.asarray(d['SWDNDIR_COMMON'][:]), direct)
    assert np.array_equal(np.asarray(d['SWDNDF_COMMON'][:]), diffuse)
record = dict(scope='Only add two standard CLMNCEP SW direct/diffuse inputs from original frozen native Erbs fractions. All original17520 meteorology variables, CF time and attributes are byte-value/metadata identical; upstream DATM code and native model inputs unchanged. Both models use fixed0.5 visible/0.5 NIR bands. No fit to flux scores.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              original_met_sha256=original_sha, derived_met_sha256=sha(met),
              original_native_npz_sha256=sha(native_root / 'CN-Qia.npz'), original_protocol_sha256=sha(native_root.parent / 'protocol.json'),
              original_variable_fingerprints=before, original_global_attributes=before_attrs,
              original_variables_unchanged=True, time_samples=17520, visible_fraction=.5,
              maximum_total_shortwave_reconstruction_Wm2=float(np.max(abs(direct + diffuse - sw))),
              diffuse_fraction_min=float(fraction.min()), diffuse_fraction_max=float(fraction.max()))
print(json.dumps(record), flush=True)

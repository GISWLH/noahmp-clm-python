from pathlib import Path
import hashlib,json,os,sys
import numpy as np
from netCDF4 import Dataset

p=Path(sys.argv[1]);expected=sys.argv[2];sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();assert sha(p)==expected
new=p.with_suffix('.with-time.nc');assert not new.exists()
with Dataset(p) as old,Dataset(new,'w',format='NETCDF3_64BIT_OFFSET') as d:
 assert 'time' not in old.dimensions and old['TOPO'].dimensions==('lat','lon')
 d.setncatts({k:old.getncattr(k) for k in old.ncattrs()})
 for n,dim in old.dimensions.items():d.createDimension(n,len(dim))
 d.createDimension('time',1)
 for n,v in old.variables.items():
  attrs={k:v.getncattr(k) for k in v.ncattrs()};kw={}
  if '_FillValue' in attrs:kw['fill_value']=attrs.pop('_FillValue')
  w=d.createVariable(n,v.dtype,('time',)+v.dimensions if n=='TOPO' else v.dimensions,**kw);w.setncatts(attrs)
  w[:]=np.asarray(v[:])[None,...] if n=='TOPO' else v[:]
 v=d.createVariable('time','f8',('time',));v[:]=[0.];v.long_name='time';v.units='days since 0001-01-01 00:00:00';v.calendar='noleap'
with Dataset(p) as old,Dataset(new) as d:
 for n in old.variables:np.testing.assert_array_equal(old[n][:],d[n][0] if n=='TOPO' else d[n][:])
 assert d['TOPO'].dimensions==('time','lat','lon') and d['time'][0]==0. and d['time'].calendar=='noleap'
os.replace(new,p)
print(json.dumps(dict(scope='Restore original official static topography singleton time axis/value/units/calendar after F actual shr_stream_getCalendar failure. All original point coordinates/mask/area/TOPO values exactly unchanged. No meteorology/soil/physics change.',original_point_sha256=expected,new_point_sha256=sha(p),time_value=0.,time_units='days since 0001-01-01 00:00:00',calendar='noleap')))

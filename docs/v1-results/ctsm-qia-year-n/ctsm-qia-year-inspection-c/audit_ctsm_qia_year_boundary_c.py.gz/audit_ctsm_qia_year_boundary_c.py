"""Full fixed local-calendar-year input audit; executed only inside PBS."""
from pathlib import Path
import hashlib
import json
import os
import sys

import numpy as np
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
workspace, root = map(Path, sys.argv[1:3])
base = Path('/home/zhangyq/noahmp-v1')
input_root = base / 'qia-stem-inputs-a/inputs'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
protocol = json.loads((input_root.parent / 'protocol.json').read_text())
assert all(sha(input_root / n) == v for n, v in protocol['inputs_sha256'].items())
with np.load(input_root / 'CN-Qia.npz', allow_pickle=False) as z:
    forcing, environment = np.asarray(z['forcing'], float), np.asarray(z['environment'], float)
assert forcing.shape == (17520, 8) and environment.shape == (17520, 3)
assert np.all(forcing[:, 0] == 1800.)
parts, bounds, source_files, static = {}, [], [], {}
names = ['TBOT', 'QBOT', 'WIND', 'ZBOT', 'PBOT', 'PCO2', 'FSDS', 'FLDS', 'RAIN', 'SNOW', 'RAIN_FROM_ATM', 'SNOW_FROM_ATM', 'FSDSND', 'FSDSNI', 'FSDSVD', 'FSDSVI', 'FSH', 'EFLX_LH_TOT', 'QFLX_EVAP_TOT', 'QRUNOFF', 'FPSN', 'H2OSNO', 'TSOI', 'H2OSOI', 'FGR', 'TLAI', 'TSAI']
time_error = 0.
for path in sorted((workspace / 'output/case/run').glob('*.clm2.h0.*.nc')):
    with Dataset(path) as d:
        assert d['time'].units == 'days since 2002-12-31 16:00:00'
        raw = np.asarray(d['time_bounds'][:], float) * 86400.
        time_error = max(time_error, float(abs(raw - np.rint(raw)).max()))
        assert time_error <= .01
        bounds.append(np.rint(raw).astype(np.int64))
        metadata = {}
        for name in names:
            v = d[name]
            a = np.ma.asarray(v[:])
            assert not np.any(np.ma.getmaskarray(a)) and np.isfinite(a).all(), name
            a = np.asarray(a).reshape(len(raw), -1)
            parts.setdefault(name, []).append(a)
            metadata[name] = dict(units=v.units, dimensions=v.dimensions, dtype=str(a.dtype))
        for name in [n for n in ['DZSOI', 'ZSOI', 'levgrnd', 'levsoi'] if n in d.variables]:
            value = np.asarray(d[name][:])
            if name in static:
                assert np.array_equal(static[name], value)
            static[name] = value
    source_files.append(dict(file=path.name, sha256=sha(path), samples=len(raw), variables=metadata))
assert 'DZSOI' in static and 'ZSOI' in static
allbounds = np.concatenate(bounds)
order = np.argsort(allbounds[:, 0], kind='stable')
allbounds = allbounds[order]
valid = (allbounds[:, 0] >= 0) & (allbounds[:, 1] <= 31536000)
expected = np.arange(17520)[:, None] * 1800 + np.array([[0, 1800]])
assert len(allbounds) == 17521 and valid.sum() == 17520
assert np.array_equal(allbounds[valid], expected) and np.array_equal(allbounds[~valid], [[-1800, 0]])
fields = {n: np.concatenate(p)[order][valid] for n, p in parts.items()}
assert all(len(v) == 17520 for v in fields.values())
metrics = {}

def compare(name, actual, reference):
    a = np.asarray(actual).reshape(17520)
    v = np.asarray(reference, float).reshape(17520)
    delta = a.astype(float) - v
    worst = int(abs(delta).argmax())
    metrics[name] = dict(max_absolute=float(abs(delta).max()), mean_bias=float(delta.mean()),
                         rms_difference=float(np.sqrt(np.mean(delta ** 2))), worst_interval_index=worst,
                         actual_at_worst=float(a[worst]), original_at_worst=float(v[worst]),
                         actual_mean=float(a.astype(float).mean()), original_mean=float(v.mean()),
                         history_dtype=str(a.dtype), exact_at_history_dtype=bool(np.array_equal(a, v.astype(a.dtype))),
                         nonmatching_at_history_dtype=int(np.count_nonzero(a != v.astype(a.dtype))))

for name, column in [('TBOT', 1), ('QBOT', 2), ('WIND', 3), ('PBOT', 4), ('FSDS', 5), ('FLDS', 6)]:
    compare(name, fields[name], forcing[:, column])
compare('ZBOT', fields['ZBOT'], np.full(17520, 39.6))
compare('PCO2_Pa', fields['PCO2'], forcing[:, 4] * environment[:, 0] * 1.e-6)
compare('CO2_derived_ppm', fields['PCO2'].reshape(17520).astype(float) / fields['PBOT'].reshape(17520).astype(float) * 1.e6, environment[:, 0])
compare('land_RAIN_plus_SNOW_mm_s', fields['RAIN'].astype(float) + fields['SNOW'].astype(float), forcing[:, 7] * 1000.)
compare('atmosphere_RAIN_plus_SNOW_mm_s', fields['RAIN_FROM_ATM'].astype(float) + fields['SNOW_FROM_ATM'].astype(float), forcing[:, 7] * 1000.)
for name, fraction_expected in [('FSDSND', .5 * (1 - environment[:, 2])), ('FSDSVD', .5 * (1 - environment[:, 2])), ('FSDSNI', .5 * environment[:, 2]), ('FSDSVI', .5 * environment[:, 2])]:
    compare(name + '_common_Wm2', fields[name], forcing[:, 5] * fraction_expected)
land_total = sum(fields[n].reshape(17520).astype(float) for n in ['FSDSND', 'FSDSNI', 'FSDSVD', 'FSDSVI'])
compare('land_four_band_total_Wm2', land_total, forcing[:, 5])
day = forcing[:, 5] > 1.
fraction = np.divide(fields['FSDSNI'].reshape(17520).astype(float) + fields['FSDSVI'].reshape(17520).astype(float), land_total, out=np.zeros(17520), where=land_total > 0)
rad = dict(daylight_intervals=int(day.sum()), original_fraction_mean=float(environment[day, 2].mean()),
           actual_fraction_mean=float(fraction[day].mean()), maximum_daylight_fraction_difference=float(abs(fraction[day] - environment[day, 2]).max()))

# Prefix replay compares actual decoded arrays from an independently executed M,
# including every field shared with its first48 diagnostic. No score-selected bins.
prefix_root = base / 'ctsm-qia-boundary-m-c'
prefix_receipt = json.loads((prefix_root / 'receipt.json').read_text())
assert (prefix_root / 'pbs-exit.txt').read_text().strip() == '0'
assert sha(prefix_root / 'official-first48.npz') == prefix_receipt['positive48_sha256']
with np.load(prefix_root / 'official-first48.npz', allow_pickle=False) as z:
    common = sorted(set(fields).intersection(z.files))
    prefix_exact = {n: bool(np.array_equal(fields[n][:48], z[n])) for n in common}
assert common and all(prefix_exact.values())

saved = {**fields, **static, 'time_bounds_seconds': expected}
np.savez_compressed(root / 'official-year-fields.npz', **saved)
record = dict(scope='Actual complete fixed2003 local-calendar meteorology boundary and raw physical outputs of official SP column on EHPC PBS only. Exact original17520 half-hour bins, discard only startup[-1800,0]. Raw differences and history-dtype comparisons are diagnostic; no output retagging and no scientific/soil/cold-state/SP-CN acceptance.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, positive_intervals=17520,
              original_samples=17521, maximum_time_quantization_seconds=time_error,
              original_input_protocol_sha256=sha(input_root.parent / 'protocol.json'),
              common_band_fraction=.5, input_field_differences=metrics, land_radiation=rad,
              first48_M_physical_arrays_byte_value_equal=prefix_exact,
              all_direct_met_fields_exact_at_history_dtype=all(metrics[n]['exact_at_history_dtype'] for n in ['TBOT', 'QBOT', 'WIND', 'PBOT', 'FSDS', 'FLDS', 'ZBOT']),
              source_files=source_files, fields_sha256=sha(root / 'official-year-fields.npz'),
              rain_snow_scope='Report both atmospheric and land total precipitation. DATM and CLM phase partition may differ from native wet-bulb physics; total agreement does not certify rain/snow component agreement.',
              comparability='Official original coarse soil/15 thermal layers10 hydrologic layers/default cold stores and fixed SP canopy remain unmatched to native4-layer/prognostic CN. FPSN source is gross canopy CO2 assimilation; SP has no NEE/CN acceptance.')
(root / 'year-boundary.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'source_files'}), flush=True)

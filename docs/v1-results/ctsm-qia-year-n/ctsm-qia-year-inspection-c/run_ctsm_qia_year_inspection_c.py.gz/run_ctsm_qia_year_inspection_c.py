from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile
import time

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-year-inspection-c'
case = b / 'ctsm-qia-run-n'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
prefix, workspace = scratch / 'toolchain', scratch / 'workspace'
prefix.mkdir()
workspace.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start = time.monotonic()
d = json.loads((case / 'configuration.json').read_text())
assert (case / 'pbs-exit.txt').read_text().strip() == '1' and d['official_model_returncode'] == 0 and d['upstream_original_bytes_unchanged']
assert [s['returncode'] for s in d['stages'] if s['stage'] == 'year-boundary-audit'] == [1]
assert all(s['returncode'] == 0 for s in d['stages'] if s['stage'] != 'year-boundary-audit')
a = b / 'ctsm-portable-env-b.tar.gz'
assert sha(a) == '6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(a) as t:
    t.extractall(prefix, filter='data')
private = case / 'case-configuration-private.tar.gz'
private_sha = sha(private)
with tarfile.open(private) as t:
    error = t.extractfile('year-boundary-audit.stderr.txt').read()
    assert b'IndexError: levsoi not found' in error
    (r / 'original-year-audit.stderr.txt').write_bytes(error)
    members = [m for m in t if m.isfile() and (m.name.startswith('output/case/run/') and m.name.endswith('.nc') or m.name == 'inputdata/CN-Qia.datm.2003.nc')]
    t.extractall(workspace, members=members, filter='data')
assert sha(workspace / 'inputdata/CN-Qia.datm.2003.nc') == d['common_radiation_derivation']['derived_met_sha256']
env = os.environ.copy()
env.pop('PYTHONPATH', None)
env.update(PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
stages = []
for name, cmd in [('relocate', [str(prefix / 'bin/python'), str(prefix / 'bin/conda-unpack')]), ('inventory', [str(prefix / 'bin/python'), str(r / 'inspect_ctsm_qia_year_inventory_c.py'), str(workspace), str(r)]), ('year-boundary-inspect', [str(prefix / 'bin/python'), str(r / 'audit_ctsm_qia_year_boundary_c.py'), str(workspace), str(r)])]:
    p = subprocess.run(cmd, env=env, cwd=scratch, capture_output=True, text=True, timeout=180)
    (r / (name + '.stdout.txt')).write_text(p.stdout)
    (r / (name + '.stderr.txt')).write_text(p.stderr)
    stages.append(dict(stage=name, returncode=p.returncode))
    assert p.returncode == 0, p.stderr
audit = json.loads((r / 'year-boundary.json').read_text())
receipt = dict(scope='Original official N17520 execution model0 but parent1 because postreader incorrectly required a levsoi coordinate variable; actual levsoi dimension exists without coordinate. Reread unchanged original NC on EHPC PBS only, no model rerun/source/output/time change. Original failure retained. Positive17520 bins and prefix replay require actual audit output; no scientific acceptance.',
               pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, seconds=time.monotonic() - start,
               official_model_returncode=0, original_parent_pbs_returncode=1, upstream_original_bytes_unchanged=True,
               original_configuration_sha256=sha(case / 'configuration.json'), original_private_sha256=private_sha,
               stages=stages, audit_sha256=sha(r / 'year-boundary.json'), fields_sha256=sha(r / 'official-year-fields.npz'), positive_intervals=audit['positive_intervals'])
(r / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)

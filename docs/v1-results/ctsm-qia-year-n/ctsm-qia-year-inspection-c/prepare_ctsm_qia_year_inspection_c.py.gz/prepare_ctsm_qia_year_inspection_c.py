from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'audit_ctsm_qia_year_boundary_b.py').read_text()
old = "for name in ['DZSOI', 'ZSOI'] + [n for n in ['levgrnd', 'levsoi'] if n in d.variables]:"
assert p.count(old) == 1
p = p.replace(old, "for name in [n for n in ['DZSOI', 'ZSOI', 'levgrnd', 'levsoi'] if n in d.variables]:")
p = p.replace('allbounds = np.concatenate(bounds)', "assert 'DZSOI' in static and 'ZSOI' in static\nallbounds = np.concatenate(bounds)")
ast.parse(p)
(r / 'audit_ctsm_qia_year_boundary_c.py').write_bytes(p.encode())
p = (r / 'run_ctsm_qia_year_inspection_b.py').read_text().replace('ctsm-qia-year-inspection-b', 'ctsm-qia-year-inspection-c').replace('audit_ctsm_qia_year_boundary_b.py', 'audit_ctsm_qia_year_boundary_c.py')
old = "('year-boundary-inspect', [str(prefix / 'bin/python'), str(r / 'audit_ctsm_qia_year_boundary_c.py'), str(workspace), str(r)])"
assert p.count(old) == 1
p = p.replace(old, "('inventory', [str(prefix / 'bin/python'), str(r / 'inspect_ctsm_qia_year_inventory_c.py'), str(workspace), str(r)]), " + old)
ast.parse(p)
(r / 'run_ctsm_qia_year_inspection_c.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_year_inspection_b.pbs').read_text().replace('ctsm-qia-year-inspection-b', 'ctsm-qia-year-inspection-c').replace('run_ctsm_qia_year_inspection_b.py', 'run_ctsm_qia_year_inspection_c.py').replace('clm-qia-year-read-b', 'clm-qia-year-read-c')
(r / 'ctsm_qia_year_inspection_c.pbs').write_bytes(p.encode())
p = (r / 'compare_ctsm_qia_native_firstday_b.py').read_text().replace('ctsm-qia-native-firstday-b', 'ctsm-qia-native-firstday-c').replace('ctsm-qia-year-inspection-b', 'ctsm-qia-year-inspection-c')
ast.parse(p)
(r / 'compare_ctsm_qia_native_firstday_c.py').write_bytes(p.encode())
p = (r / 'ctsm_qia_native_firstday_b.pbs').read_text().replace('ctsm-qia-native-firstday-b', 'ctsm-qia-native-firstday-c').replace('compare_ctsm_qia_native_firstday_b.py', 'compare_ctsm_qia_native_firstday_c.py').replace('clm-qia-native-day-b', 'clm-qia-native-day-c')
(r / 'ctsm_qia_native_firstday_c.pbs').write_bytes(p.encode())

from pathlib import Path
import hashlib
import json
import os
import sys
from netCDF4 import Dataset

assert os.environ.get('PBS_JOBID')
workspace, r = map(Path, sys.argv[1:3])
rows = []
for p in sorted((workspace / 'output/case/run').glob('*.clm2.h0.*.nc')):
    with Dataset(p) as d:
        rows.append(dict(file=p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
                         dimensions={n: len(v) for n, v in d.dimensions.items()},
                         variables={n: dict(dimensions=v.dimensions, units=getattr(v, 'units', None)) for n, v in d.variables.items()},
                         time_units=d['time'].units))
record = dict(scope='Actual official N history metadata inventory on EHPC PBS. Distinguish dimensions, coordinate variables and static fields omitted from later history files; no inferred coordinate arrays or model changes.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, files=rows)
(r / 'inventory.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps([dict(file=x['file'], samples=x['dimensions'].get('time'), static_fields_present=[n for n in ['DZSOI', 'ZSOI', 'levgrnd', 'levsoi'] if n in x['variables']]) for x in rows]), flush=True)

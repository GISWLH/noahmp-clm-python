"""Cold, unmatched-initial-state diagnosis, never a science acceptance."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import tarfile

import numpy as np

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'ctsm-qia-native-firstday-c'
official = b / 'ctsm-qia-run-n'
native = b / 'qia-stem-numpy-day-a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
case = json.loads((official / 'configuration.json').read_text())
analysis = b / 'ctsm-qia-year-inspection-c'
audit = json.loads((analysis / 'year-boundary.json').read_text())
recovered = json.loads((analysis / 'receipt.json').read_text())
assert (analysis / 'pbs-exit.txt').read_text().strip() == '0' and all(s['returncode'] == 0 for s in recovered['stages'])
assert sha(analysis / 'year-boundary.json') == recovered['audit_sha256']
assert (official / 'pbs-exit.txt').read_text().strip() == '1' and case['official_model_returncode'] == 0
assert case['upstream_original_bytes_unchanged'] and all(s['returncode'] == 0 for s in case['stages'] if s['stage'] != 'year-boundary-audit')
assert [s['returncode'] for s in case['stages'] if s['stage'] == 'year-boundary-audit'] == [1]
assert sha(analysis / 'official-year-fields.npz') == audit['fields_sha256'] and audit['positive_intervals'] == 17520
receipt = json.loads((native / 'receipt.json').read_text())
report = json.loads((native / 'trajectory/report.json').read_text())
assert (native / 'pbs-exit.txt').read_text().strip() == '0' and receipt['returncode'] == 0 and report['source_unchanged']
assert sha(native / 'trajectory/report.json') == receipt['report_sha256']
assert report['status'] == 'running' and report['steps_completed'] == 48 and report['steps_requested'] == 17520
npz = native / 'trajectory' / report['model_npz']
assert sha(npz) == report['model_npz_sha256']
with np.load(npz, allow_pickle=False) as z:
    model = dict(z)
with np.load(analysis / 'official-year-fields.npz', allow_pickle=False) as z:
    reference = dict(z)
assert str(model['time_start'][0]) == '200301010000' and str(model['time_end'][-1]) == '200301020000'
assert np.array_equal(reference['time_bounds_seconds'][:48], np.arange(48)[:, None] * 1800 + [[0, 1800]])

archive = b / 'p6-stem-assessment-b-source.tar.gz'
assert sha(archive) == '8a378a471cd163958ca01cb9184343e79624af5f05e427b9397eaffd17cb2ca0'
with tarfile.open(archive) as t:
    manifest = json.loads(t.extractfile('SOURCE_SHA256.json').read())
    code = t.extractfile('src/noahmp_clm/validation.py').read()
assert hashlib.sha256(code).hexdigest() == manifest['src/noahmp_clm/validation.py']
helper = Path(os.environ['TMPDIR']) / 'fixed_validation.py'
helper.write_bytes(code)
spec = importlib.util.spec_from_file_location('fixed_validation', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
compare = module.compare_series

metrics = {}
for out, source, factor, key in [('h_wm2', 'FSH', 1., 'h_wm2'), ('le_wm2', 'EFLX_LH_TOT', 1., 'le_wm2'),
                                 ('et_mm', 'QFLX_EVAP_TOT', 86400., 'et_mm_day'), ('runoff_mm', 'QRUNOFF', 86400., 'runoff_mm_day'),
                                 ('gpp_gc_m2', 'FPSN', 12.0107e-6 * 86400., 'gpp_gc_day'), ('swe_m', 'H2OSNO', .001, 'swe_m')]:
    actual = np.asarray(model[out], float)
    if out in ['et_mm', 'runoff_mm', 'gpp_gc_m2']:
        actual = actual * 48.
    expected = np.asarray(reference[source][:48], float).reshape(48) * factor
    metrics[out] = compare(actual, expected, key, weights=np.full(48, 1800.))

config = json.loads((b / 'qia-stem-inputs-a/inputs/CN-Qia-stem-config.json').read_text())
target_dz = np.asarray(config['column']['dz'], float)
official_dz = np.asarray(reference['DZSOI'], float).reshape(-1)
assert target_dz.shape == (4,) and len(official_dz) == 15 and np.all(official_dz > 0)
te, se = np.r_[0., np.cumsum(target_dz)], np.r_[0., np.cumsum(official_dz)]
weights = np.maximum(0., np.minimum(te[1:, None], se[None, 1:]) - np.maximum(te[:-1, None], se[None, :-1])) / target_dz[:, None]
assert np.max(abs(weights.sum(1) - 1.)) < 1.e-14
tsoil = np.asarray(reference['TSOI'][:48], float).reshape(48, 15) @ weights.T
theta = np.asarray(reference['H2OSOI'][:48], float).reshape(48, 10)
assert np.max(abs(weights[:, 10:])) == 0.
theta = theta @ weights[:, :10].T
for field, expected, key, offset in [('tsoil_k', tsoil, 'tsoil_c', 273.15), ('smc_m3m3', theta, 'smc', 0.)]:
    assert model[field].shape == (48, 4)
    for layer in range(4):
        metrics[field + '/' + str(layer)] = compare(model[field][:, layer] - offset, expected[:, layer] - offset, key, weights=np.full(48, 1800.))

record = dict(scope='Raw unmatched-cold-state diagnostic only: native NumPy48 vs official N first48 with independently audited common meteorology/radiation. Predeclared near-zero metrics reported mechanically, never credited as scientific acceptance. Official coarse soil/default cold stores/SP fixed canopy differ from native nominal-loam4-layer/prognostic CN; no spinup or fit.',
              pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, samples=48,
              official_configuration_sha256=sha(official / 'configuration.json'), original_official_model_returncode=0, original_parent_pbs_returncode=1, postread_receipt_sha256=sha(analysis / 'receipt.json'), official_fields_sha256=audit['fields_sha256'],
              native_report_sha256=sha(native / 'trajectory/report.json'), native_trace_sha256=sha(npz),
              fixed_metric_helper_sha256=hashlib.sha256(code).hexdigest(), metrics=metrics,
              scientific_acceptance=False, nee='unmeasured: official SP has no NEE or prognostic CN',
              gpp_operator='FPSN gross canopy assimilation from pinned PhotosynthesisMod ag/psn_z/psn canopy aggregation; common12.0107gC/mol conversion,not An or NEE.',
              soil_operator=dict(scope='Geometric depth-overlap means of actual official layer profiles; temperature compared in Celsius. This operator does not match soil parameters/initial stores or thermal capacities.', target_interfaces_m=te.tolist(), official_interfaces_m=se.tolist(), overlap_weights=weights.tolist()),
              official_forcing_audit_all_direct_met_exact_at_history_dtype=audit['all_direct_met_fields_exact_at_history_dtype'])
(r / 'diagnosis.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)

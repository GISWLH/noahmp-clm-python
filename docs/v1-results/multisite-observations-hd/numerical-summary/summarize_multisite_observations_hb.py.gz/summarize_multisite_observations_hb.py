"""Summarize all completed observation periods, retaining every failed gate."""
from pathlib import Path
import hashlib
import json
import os
import time

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'multisite-observations-summary-hb'
prior = base / 'multisite-observations-ha'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert (prior / 'pbs-exit.txt').read_text().strip() == '0'
receipt = json.loads((prior / 'receipt.json').read_text())
assert receipt['evaluation_delivered'] and receipt['source_unchanged'] and len(receipt['cases']) == 24
begun = time.monotonic()
rows = []
for case in receipt['cases']:
    folder = prior / case['cohort'] / case['case']
    assert sha(folder / 'model-report.json') == case['original_report_sha256']
    assert sha(folder / 'model-trace.npz') == case['original_trace_sha256']
    assert sha(folder / 'observations.json') == case['observations_sha256']
    data = json.loads((folder / 'observations.json').read_text())
    assert data['annual']['status'] == 'unmeasured' and len(data['monthly']) == 12
    monthly = {}
    for date, products in data['monthly'].items():
        available = {name: product for name, product in products.items()
                     if product.get('calendar_period_complete') is True}
        if available:
            monthly[date] = {name: dict(metrics=p['metrics'],
                model_integral=p.get('model_integral'), reference_integral=p.get('reference_integral'),
                integral_units=p.get('integral_units'), own_qc_counts=p['own_qc_counts'])
                for name, p in available.items()}
    row = dict(case=case['case'], cohort=case['cohort'], site=case['site'],
               steps_completed=case['steps_completed'], complete_days=case['complete_days'],
               complete_calendar_months=monthly,
               original_observations_sha256=case['observations_sha256'],
               prefix_instantaneous_metrics={name: p['metrics'] for name, p in data['instantaneous'].items()},
               prefix_warning='Different case prefixes are not an aligned sensitivity comparison; only identical full calendar months can be compared here')
    rows.append(row)
    for date, products in monthly.items():
        print(json.dumps(dict(cohort=case['cohort'], case=case['case'], month=date,
            values={name: p['metrics'] for name, p in products.items()})), flush=True)
result = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
              source_manifest_sha256=receipt['source_manifest_sha256'],
              original_evaluation_receipt_sha256=sha(prior / 'receipt.json'), cases=rows,
              original_raw_interval_integral_checks=sum(q['independent_raw_integral_checks'] for q in receipt['cases']),
              seconds=time.monotonic() - begun,
              scope='All24 original cases and every available complete calendar month, scientific failures retained. Partial/future months and all unfinished annual requests remain unmeasured. Prefixes explicitly not aligned case sensitivity; no bestcase selection, calibration, spinup or observational acceptance certificate.')
(root / 'summary.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
(root / 'receipt.json').write_text(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
    passed=len(rows) == 24, cases=24, summary_sha256=sha(root / 'summary.json'),
    original_evaluation_receipt_sha256=result['original_evaluation_receipt_sha256'], scope=result['scope']), indent=2) + '\n')

"""Evaluate one original, actually completed 17520-step year after its parent0."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = Path.cwd()
plan = json.loads((root / 'plan.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(root / name) == digest for name, digest in plan['controls_sha256'].items())
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 579 and sha(source / 'SOURCE_SHA256.json') == plan['source_manifest_sha256']
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner

begun = time.monotonic()
failure = None
try:
    case_root = base / plan['year_root'] / plan['case']
    assert plan['final_segment_start'] == 17280
    terminal = json.loads((case_root / 'segment-017280-receipt.json').read_text())
    assert (case_root / 'segment-017280-pbs-exit.txt').read_text().strip() == '0'
    assert terminal['failure'] is None and terminal['source_unchanged'] and terminal['model_completed_segment']
    assert terminal['status'] == 'complete' and terminal['steps_completed'] == terminal['steps_requested'] == 17520
    assert terminal['source_manifest_sha256'] == plan['source_manifest_sha256']
    history = subprocess.check_output(['qstat', '-xf', plan['depends_on_actual_success']], text=True)
    assert re.search(r'^\s*job_state = F\s*$', history, re.M) and re.search(r'^\s*Exit_status = 0\s*$', history, re.M)
    (root / 'actual-year-parent-qstat.txt').write_text(history)
    report_path = case_root / 'trajectory/report.json'
    raw_report = report_path.read_bytes()
    report = json.loads(raw_report)
    assert sha(report_path) == terminal['report_sha256'] and report['status'] == 'complete'
    assert report['steps_completed'] == report['steps_requested'] == 17520 and report['source_unchanged']
    assert report['source_sha256'] == runner.source_hashes() and report['configuration_sha256'] == plan['configuration_sha256']
    trace = case_root / 'trajectory' / report['model_npz']
    assert sha(trace) == report['model_npz_sha256']
    inputs = Path(os.environ['TMPDIR']) / 'inputs'
    inputs.mkdir()
    archive = base / plan['input_archive']
    assert sha(archive) == plan['input_archive_sha256']
    with tarfile.open(archive) as tf:
        tf.extractall(inputs, filter='data')
    assert sha(inputs / plan['configuration']) == report['configuration_sha256']
    (root / 'model-report.json').write_bytes(raw_report)
    (root / 'model-trace.npz').write_bytes(trace.read_bytes())
    (root / 'actual-year-parent-receipt.json').write_bytes((case_root / 'segment-017280-receipt.json').read_bytes())
    (root / 'actual-year-parent-exit.txt').write_bytes((case_root / 'segment-017280-pbs-exit.txt').read_bytes())
    operator = base / 'height-observations-ea' / (report['site'] + '-soil-operator.json')
    assert sha(operator) == plan['soil_operator_sha256']
    (root / 'soil-operator.json').write_bytes(operator.read_bytes())
    env = os.environ.copy()
    env['PYTHONPATH'] = ':'.join(map(str, [base / 'test-deps', source, source / 'src', source / 'benchmarks']))
    command = [sys.executable, str(source / 'benchmarks/evaluate_fluxnet_series.py'),
               '--model', str(root / 'model-trace.npz'), '--model-manifest', str(root / 'model-report.json'),
               '--observations', str(inputs / plan['input']), '--observation-manifest', str(inputs / plan['input_manifest']),
               '--soil-operator', str(root / 'soil-operator.json'), '--output', str(root / 'observations.json')]
    with (root / 'observations.log').open('x') as log:
        code = subprocess.run(command, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    assert code == 0, 'Original evaluation execution failed; raw output retained'
    data = json.loads((root / 'observations.json').read_text())
    assert len(data['daily']) == 365 and len(data['monthly']) == 12
    assert all(p['calendar_period_complete'] for frequency in ['daily', 'monthly']
               for products in data[frequency].values() for p in products.values())
except Exception as exc:
    failure = type(exc).__name__ + ': ' + str(exc)
    (root / 'traceback.txt').write_text(traceback.format_exc())
    print(traceback.format_exc(), flush=True)
receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename,
    case=plan['case'], cohort=plan['cohort'], source_manifest_sha256=plan['source_manifest_sha256'],
    source_unchanged=all(sha(source / name) == digest for name, digest in manifest.items()),
    controls_unchanged=all(sha(root / name) == digest for name, digest in plan['controls_sha256'].items()),
    evaluation_delivered=failure is None, failure=failure, seconds=time.monotonic() - begun,
    output_sha256={name: sha(root / name) for name in ['model-report.json', 'model-trace.npz', 'observations.json'] if (root / name).exists()},
    scope=plan['scope'])
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
print(json.dumps(receipt), flush=True)
assert receipt['evaluation_delivered'] and receipt['source_unchanged'] and receipt['controls_unchanged']

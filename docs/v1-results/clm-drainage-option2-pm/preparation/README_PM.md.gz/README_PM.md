# PM option2 full adaptive coverage

Only test_option2_pm.py is collected: warm and frozen option2, each one NumPy32
full adaptive integration and one unchanged original G NumPy64 integration.
The exact I fixture/run/phase/core and all original files are copied unchanged;
I's existing 18 tests are not collected again. Same nominal theta=.4, four .5m
layers, slope=.2, front=.5m, bottom=2m, dt=1800s and default controls. Warm T=290K;
frozen T=[280,270,270,270]K. These are quantized-initial-condition physical
comparisons; they are not pure-dtype-only equivalence or an official site run.

All input cell/parameter quantization and both actual outlet/temperature/front
results are retained. Mass criterion max(.001 kg/m2,10% of original64), heat
max(.05 J/m2,10%); .05 is the existing absolute integration scale used explicitly
for the new heat comparison. No relative percentage is assigned where the
absolute criterion dominates. Temperature/front retain .001 K/m criteria.
Each original hard M/H bound remains 64*eps(its explicit dtype)*original scale,
independently re-summed in float64. This is separate from science comparison.

A read-only spy calls the original phase function and returns its same object;
every actual core inverse must use option2 and float32 inputs/outputs and converge.
Original barrier dtype checks remain. Accepted/rejected steps and exact interval
clock are reported for both backends. Four component integrations are real
physical executions; coupled columns, actual field years, GPU and production
registration remain zero. No physical source or I controls are modified.

The frozen original I README retains an acknowledged pre-execution saturated
water-quantization prediction error, corrected in its original public readout.
PM reports its own measured inputs; it makes no prediction of their differences.

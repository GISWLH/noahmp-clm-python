"""Ten actual NumPy32 component cases. Numerical execution only on EHPC PBS."""
import os
import socket
if os.name=='nt' or not os.environ.get('PBS_JOBID') or socket.gethostname()!='compute002':
    raise RuntimeError('PB-i requires EHPC compute002 PBS')

from dataclasses import replace
from pathlib import Path
import hashlib
import json
import math
import numpy as np
import pytest
from scipy.integrate import quad,solve_ivp
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState,enthalpy_and_capacity
import saturated_drainage_pb as pb
import drainage_primitives_pbf as primitive
import adaptive_main_pbg as reference
import adaptive_main_pbi as candidate
from phase_numpy32_pbi import run_numpy32,PHASE_AUDIT

F=np.float32
HERE=Path(__file__).resolve().parent


def fixture(theta=.45,temperature=290.,bedrock=2.,slope=.2,option=1):
    dz=np.full(4,.5);p=SoilParams();theta=np.broadcast_to(theta,(4,));t=np.broadcast_to(temperature,(4,))
    w=1000*dz*theta;h=enthalpy_and_capacity(w,t,dz,p,option=option)[0]
    s=SoilEnthalpyState(w,h,dz,p,option);pars=pb.DrainageParameters(bedrock,slope)
    c64,p64,_=primitive.pack(s,pars,1800.,.5,bedrock)
    p32=p64.astype(F);z32=dz.astype(F)
    # Explicit input quantization in native precision, not clipping a stock.
    # At theta=porosity=.45, phi32*500 is 224.9999847, not float64's 225.
    w32=F(1000)*z32*theta.astype(F)
    u=np.column_stack((w32,t.astype(F)-F(273.15),z32,np.full(4,p32[0],F),
                      np.full(4,p32[2],F),np.full(4,p32[1],F)))
    forward=run_numpy32(u,np.full(4,option,np.int32));u[:,1]=forward['enthalpy_jm2']
    phase=run_numpy32(u,np.full(4,option,np.int32),inverse=True)
    c32=np.column_stack((phase['liquid_kgm2'],w32-phase['liquid_kgm2'],z32,
                         phase['temperature_k'],w32,forward['enthalpy_jm2']))
    assert c32.dtype==p32.dtype==F
    return c32,p32,c64,p64,option


def run(case,duration=1800.,front=.5,controls=pb.IntegrationControls()):
    c,p,c64,p64,option=case;before=(c.tobytes(),p.tobytes())
    out,z,d=candidate.advance_main_band(c,p,option,duration,front,float(p[4]),controls)
    assert out.dtype==F and np.asarray(z).dtype==F
    assert all(d[key].dtype==F for key in ('layer_mass_kg_m2','layer_enthalpy_j_m2'))
    assert before==(c.tobytes(),p.tobytes())
    assert np.all(out[:,4]>=0) and np.all(out[:,4]<=c[:,4])
    assert abs(d['water_residual_kg_m2'])<=d['water_bound_kg_m2']
    assert abs(d['energy_residual_j_m2'])<=d['energy_bound_j_m2']
    # Independent float64 sum of the original float32 ledger, not a different state.
    rm=float(np.sum(out[:,4].astype(float)-c[:,4].astype(float)+d['layer_mass_kg_m2'].astype(float)))
    rh=float(np.sum(out[:,5].astype(float)-c[:,5].astype(float)+d['layer_enthalpy_j_m2'].astype(float)))
    assert abs(rm)<=float(d['water_bound_kg_m2']) and abs(rh)<=float(d['energy_bound_j_m2'])
    assert d['clock_residual_seconds']==0 and d['elapsed_seconds']==float(F(duration))
    packed=np.column_stack((out[:,4],out[:,5],out[:,2],np.full(4,p[0],F),np.full(4,p[2],F),np.full(4,p[1],F)))
    inverse=run_numpy32(packed,np.full(4,option,np.int32),inverse=True)
    np.testing.assert_array_equal(out[:,3],inverse['temperature_k'])
    np.testing.assert_array_equal(out[:,0],inverse['liquid_kgm2'])
    d['independent_water_residual']=rm;d['independent_heat_residual']=rh
    return out,z,d


def emit(name,case,out,z,d,**extra):
    c,p,c64,p64,_=case
    record=dict(test=name,backend='numpy',precision='float32',front_m=float(z),
        layer_water=out[:,4].tolist(),layer_temperature=out[:,3].tolist(),layer_ice=out[:,1].tolist(),
        layer_mass=d['layer_mass_kg_m2'].tolist(),layer_heat=d['layer_enthalpy_j_m2'].tolist(),
        water_residual=float(d['water_residual_kg_m2']),water_bound=float(d['water_bound_kg_m2']),
        heat_residual=float(d['energy_residual_j_m2']),heat_bound=float(d['energy_bound_j_m2']),
        independent_water_residual=d['independent_water_residual'],independent_heat_residual=d['independent_heat_residual'],
        accepted=d['accepted_substeps'],rejected=d['rejected_substeps'],maximum_error=d['maximum_accepted_error_ratio'],
        input_stock_quantization=(c[:,4].astype(float)-c64[:,4]).tolist(),
        input_heat_quantization=(c[:,5].astype(float)-c64[:,5]).tolist(),
        input_parameter_quantization=(p.astype(float)-p64).tolist(),
        clock_residual=d['clock_residual_seconds'],**extra)
    print('PB_I_DIAGNOSTIC '+json.dumps(record,allow_nan=False),flush=True)


@pytest.mark.parametrize('option',[1,2])
def test_phase_original_equations_dtype_convergence_and_reference(option):
    case=fixture(.4,[290.,273.149,270.,260.],option=option);c,p,c64,_,_=case
    assert PHASE_AUDIT['barrier_calls']>0 and PHASE_AUDIT['floating_values_checked']>0
    assert np.max(abs(c[:,3].astype(float)-c64[:,3]))<.001
    assert np.max(abs(c[:,0].astype(float)-c64[:,0]))<.01
    bindings=json.loads((HERE/'BINDINGS.json').read_bytes())
    for name,digest in bindings['frozen_dependencies'].items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest
    print('PB_I_DIAGNOSTIC '+json.dumps(dict(test='phase',option=option,phase_temperature_error=(c[:,3].astype(float)-c64[:,3]).tolist(),
        liquid_error=(c[:,0].astype(float)-c64[:,0]).tolist(),barrier_checks=dict(PHASE_AUDIT),precision='float32')),flush=True)


@pytest.mark.parametrize('temperature',[290.,[280.,270.,270.,270.]])
def test_warm_frozen_complete32_vs_original64(temperature):
    case=fixture(.4,temperature);out,z,d=run(case)
    _,_,c64,p64,option=case
    r,rz,rd=reference.advance_main_band(c64,p64,option,1800.,.5,2.)
    diff=d['layer_mass_kg_m2'].astype(float)-rd['layer_mass_kg_m2']
    assert np.all(abs(diff)<=np.maximum(.001,.1*abs(rd['layer_mass_kg_m2'])))
    assert np.max(abs(out[:,3].astype(float)-r[:,3]))<.001
    assert abs(float(z)-float(rz))<.001
    emit('warm_frozen',case,out,z,d,reference64_layer=rd['layer_mass_kg_m2'].tolist(),difference64=diff.tolist(),
         temperature_difference64=(out[:,3].astype(float)-r[:,3]).tolist(),reference64_front=float(rz))


def test_crosslayer_ode_official_and_time_refinement():
    case=fixture();duration=172800.;out,z,d=run(case,duration)
    refined,rz,rd=run(case,duration,controls=replace(pb.IntegrationControls(),maximum_step_seconds=900.,relative_tendency_tolerance=.00025))
    original=json.loads((HERE/'reference-pb-e-comparisons.json').read_bytes())
    official=next(r for r in original['main_refinement_vs_reused_pb_d'] if r['official_steps']==256)
    actual=np.asarray(official['original_official_layer_export_kg_m2']);ref64=np.asarray(official['pb_layer_export_from_original_stock_kg_m2'])
    def sy(depth):return max(.02,.45*(1-(1+depth/.355)**(-1/5.5)))
    def rhs(_,y):return [.001*math.tan(.2)*max(2-y[0],0)/(1000*sy(y[0]))]
    ode=solve_ivp(rhs,(0,duration),[.5],rtol=2e-11,atol=1e-12,max_step=300.);assert ode.success
    oz=float(ode.y[0,-1]);om=np.zeros(4)
    for k in range(4):
        lo=max(.5,.5*k);hi=min(oz,.5*(k+1))
        if hi>lo:om[k]=1000*quad(sy,lo,hi,epsabs=1e-12,epsrel=1e-11)[0]
    for label,a,front,ledger in (('default',out,z,d),('refined',refined,rz,rd)):
        mass=ledger['layer_mass_kg_m2'].astype(float)
        for ref in (actual,om,ref64):assert np.all(abs(mass-ref)<=np.maximum(.001,.1*abs(ref)))
        assert abs(float(front)-oz)<.001
        emit('crosslayer_'+label,case,a,front,ledger,official256=actual.tolist(),ode_layer=om.tolist(),reference64=ref64.tolist(),
             official_difference=(mass-actual).tolist(),ode_difference=(mass-om).tolist(),difference64=(mass-ref64).tolist(),ode_front=oz)
    assert d['rejected_substeps']>0


def test_rejection_and_attempt_limit_no_partial_success():
    case=fixture();out,z,d=run(case,1800.,controls=replace(pb.IntegrationControls(),relative_tendency_tolerance=.0001))
    assert d['rejected_substeps']>0
    with pytest.raises(RuntimeError,match='attempt budget'):
        run(case,1800.,controls=replace(pb.IntegrationControls(),maximum_step_seconds=1.,maximum_attempts=1))
    emit('rejection',case,out,z,d)


def test_zero_slope_preserves_exact_stocks():
    case=fixture(slope=0.);out,z,d=run(case,86400.)
    np.testing.assert_array_equal(out[:,4:],case[0][:,4:]);assert d['drained_kg_m2']==0 and d['accepted_substeps']==0
    emit('zero_slope',case,out,z,d)


def test_zero_liquid_donor_does_not_mine_deeper_layer():
    case=fixture([.45,0.,.45,.45]);out,z,d=run(case,86400.)
    np.testing.assert_array_equal(out[:,4:],case[0][:,4:]);assert z==F(.5) and d['drained_kg_m2']==0
    assert d['unavailable_liquid_kg_m2']>0
    emit('zero_liquid',case,out,z,d,unavailable=float(d['unavailable_liquid_kg_m2']))


def test_shallow_bedrock_clips_front_and_preserves_lower_layers():
    case=fixture(bedrock=1.5);out,z,d=run(case,86400.)
    np.testing.assert_array_equal(out[3],case[0][3]);assert .5<=z<=1.5 and d['layer_mass_kg_m2'][3]==0
    emit('bedrock',case,out,z,d)


def test_dtype_and_phase_input_rejected_and_duration_explicitly_quantized():
    case=fixture();c,p,_,_,_=case
    with pytest.raises(ValueError,match='same-precision'):
        candidate.advance_main_band(c,p.astype(float),1,1800.,.5,2.)
    broken=c.copy();broken[0,3]+=F(1)
    with pytest.raises(ValueError,match='inconsistent'):
        candidate.advance_main_band(broken,p,1,1800.,.5,2.)
    out,z,d=run(case,1800.00001)
    assert d['quantized_requested_duration_seconds']==1800.
    emit('explicit_time_quantization',case,out,z,d,requested_python_duration=1800.00001,quantized_duration=1800.)

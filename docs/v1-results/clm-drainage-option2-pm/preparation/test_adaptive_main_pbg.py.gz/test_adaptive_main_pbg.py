"""Prepared actual main-band integration tests; remote execution only."""
import os
import socket
if os.name=='nt' or not os.environ.get('PBS_JOBID') or socket.gethostname()!='compute002':
    raise RuntimeError('PB-g NumPy numerical tests require EHPC compute002 PBS')

from dataclasses import replace
from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pytest
from scipy.integrate import quad,solve_ivp
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState,enthalpy_and_capacity
import noahmp_clm
import saturated_drainage_pb as pb
import drainage_primitives_pbf as primitives
import adaptive_main_pbg as candidate

HERE=Path(__file__).resolve().parent


def state(theta=.45,temperature=290.):
    dz=np.full(4,.5);p=SoilParams();water=1000*dz*np.broadcast_to(theta,(4,))
    t=np.broadcast_to(temperature,(4,));h=enthalpy_and_capacity(water,t,dz,p)[0]
    return SoilEnthalpyState(water,h,dz,p)


def run(s,p,duration=1800.,front=.5,controls=pb.IntegrationControls()):
    c,pars,_=primitives.pack(s,p,duration,front,p.bedrock_depth_m)
    before=(c.tobytes(),pars.tobytes())
    after,z,d=candidate.advance_main_band(c,pars,s.freezing_option,duration,front,p.bedrock_depth_m,controls)
    assert before==(c.tobytes(),pars.tobytes())
    assert abs(d['water_residual_kg_m2'])<=d['water_bound_kg_m2']
    assert abs(d['energy_residual_j_m2'])<=d['energy_bound_j_m2']
    assert d['elapsed_seconds']==duration and d['clock_residual_seconds']==0
    assert np.all(after[:,4]>=0) and np.all(after[:,4]<=s.water)
    return after,z,d


def emit(name,after,z,d,**kw):
    record=dict(test=name,backend='numpy',precision='float64',front_m=float(z),
        layer_water=after[:,4].tolist(),layer_temperature=after[:,3].tolist(),
        layer_mass=d['layer_mass_kg_m2'].tolist(),layer_heat=d['layer_enthalpy_j_m2'].tolist(),
        water_residual=float(d['water_residual_kg_m2']),water_bound=float(d['water_bound_kg_m2']),
        heat_residual=float(d['energy_residual_j_m2']),heat_bound=float(d['energy_bound_j_m2']),
        accepted=d['accepted_substeps'],rejected=d['rejected_substeps'],**kw)
    print('PB_G_DIAGNOSTIC '+json.dumps(record,allow_nan=False),flush=True)


def test_exact_source_and_prior_evidence_bindings():
    b=json.loads((HERE/'BINDINGS.json').read_text())
    for name,h in b['frozen_dependencies'].items():
        assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==h
    source=Path(noahmp_clm.__file__).resolve().parents[2]
    raw=(source/'SOURCE_SHA256.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==b['source_manifest_sha256']
    manifest=json.loads(raw);assert len(manifest)==584
    for n,h in manifest.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h


@pytest.mark.parametrize('temperature',[290.,[280.,270.,270.,270.]])
def test_short_actual_phase_adaptive_result_matches_frozen_pb_c(temperature):
    s=state(.4,temperature);p=pb.DrainageParameters(2.,.2)
    a,z,d=run(s,p)
    reference,rz,r=pb.advance_saturated_band(s,1800.,.5,2.,'saturated',p)
    np.testing.assert_allclose(a[:,4],reference.water,rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(a[:,5],reference.enthalpy,rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(a[:,3],reference.temperature,rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(d['layer_mass_kg_m2'],r['layer_mass_kg_m2'],rtol=1e-6,atol=1e-6)
    assert abs(z-rz)<=1e-6
    emit('short_phase',a,z,d,reference_front=float(rz),
        layer_mass_difference=(d['layer_mass_kg_m2']-r['layer_mass_kg_m2']).tolist(),
        max_stock_difference=float(np.max(abs(a[:,4]-reference.water))),
        max_heat_stock_difference=float(np.max(abs(a[:,5]-reference.enthalpy))))


def test_crosslayer_against_actual_1616_and_independent_continuous_ode():
    s=state();p=pb.DrainageParameters(2.,.2);duration=172800.
    a,z,d=run(s,p,duration)
    original=json.loads((HERE/'reference-pb-e-comparisons.json').read_text())
    ref=next(r for r in original['main_refinement_vs_reused_pb_d'] if r['official_steps']==256)
    official=np.asarray(ref['original_official_layer_export_kg_m2'])
    old=np.asarray(ref['pb_layer_export_from_original_stock_kg_m2'])
    np.testing.assert_allclose(d['layer_mass_kg_m2'],old,rtol=1e-6,atol=1e-6)
    assert abs(z-ref['pb_front_m'])<=1e-6
    assert np.all(abs(d['layer_mass_kg_m2']-official)<=np.maximum(.001,.1*abs(official)))
    def sy(depth):return max(.02,.45*(1-(1+depth/.355)**(-1/5.5)))
    def rhs(_,y):return [.001*math.tan(.2)*max(2-y[0],0)/(1000*sy(y[0]))]
    ode=solve_ivp(rhs,(0,duration),[.5],rtol=2e-11,atol=1e-12,max_step=300.)
    assert ode.success;oz=float(ode.y[0,-1]);om=np.zeros(4)
    for k in range(4):
        lo=max(.5,.5*k);hi=min(oz,.5*(k+1))
        if hi>lo:om[k]=1000*quad(sy,lo,hi,epsabs=1e-12,epsrel=1e-11)[0]
    assert abs(z-oz)<=max(.001,.1*abs(oz))
    assert np.all(abs(d['layer_mass_kg_m2']-om)<=np.maximum(.001,.1*abs(om)))
    emit('crosslayer_1616_and_ode',a,z,d,official_256_layer=official.tolist(),ode_layer=om.tolist(),
         official_difference=(d['layer_mass_kg_m2']-official).tolist(),ode_difference=(d['layer_mass_kg_m2']-om).tolist(),
         official_front=ref['original_official_front_m'],ode_front=oz,original_reference_job='1616.manager:F0')


def test_dry_front_accounting_preserves_zero_liquid_and_deeper_stock():
    s=state([.45,0.,.45,.45]);p=pb.DrainageParameters(2.,.2)
    a,z,d=run(s,p,86400.)
    np.testing.assert_array_equal(a[:,4],s.water)
    np.testing.assert_array_equal(a[:,5],s.enthalpy)
    assert z==.5 and d['drained_kg_m2']==0 and d['unavailable_liquid_kg_m2']>0
    emit('blocked_front',a,z,d,unavailable=float(d['unavailable_liquid_kg_m2']))


def test_zero_slope_exact_stocks_and_complete_clock():
    s=state();a,z,d=run(s,pb.DrainageParameters(2.,0.),86400.)
    np.testing.assert_array_equal(a[:,4],s.water);np.testing.assert_array_equal(a[:,5],s.enthalpy)
    assert z==.5 and d['drained_kg_m2']==0 and d['accepted_substeps']==0
    emit('zero_slope',a,z,d)


def test_attempt_limit_remains_failure_not_partial_success():
    s=state();p=pb.DrainageParameters(2.,.2)
    with pytest.raises(RuntimeError,match='attempt budget'):
        run(s,p,1800.,controls=replace(pb.IntegrationControls(),maximum_step_seconds=1.,maximum_attempts=1))


def test_no_numpy32_mixed_precision_reference_and_inconsistent_phase_rejected():
    s=state();p=pb.DrainageParameters(2.,.2)
    c,pars,_=primitives.pack(s,p,1800.,.5,2.)
    with pytest.raises(ValueError,match='NumPy phase reference'):
        candidate.advance_main_band(c.astype(np.float32),pars.astype(np.float32),1,1800.,.5,2.)
    c[0,3]+=1
    with pytest.raises(ValueError,match='inconsistent'):
        candidate.advance_main_band(c,pars,1,1800.,.5,2.)

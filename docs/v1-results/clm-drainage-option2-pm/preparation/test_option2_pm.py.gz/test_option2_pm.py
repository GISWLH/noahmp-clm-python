"""Exactly two additional full adaptive option-2 comparisons, EHPC only."""
import os
import socket
if os.name == 'nt' or not os.environ.get('PBS_JOBID') or socket.gethostname() != 'compute002':
    raise RuntimeError('PM numerical execution requires EHPC compute002 PBS')

from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import json
import numpy as np
import pytest
import test_adaptive_main_pbi as original
import phase_numpy32_pbi as phase


def audit(out, cells, ledger):
    """Independently sum original stores/outlets; preserve the 64*eps bounds."""
    entries = {}
    for name,k,outlet,residual,bound in [
        ('water',4,'layer_mass_kg_m2','water_residual_kg_m2','water_bound_kg_m2'),
        ('enthalpy',5,'layer_enthalpy_j_m2','energy_residual_j_m2','energy_bound_j_m2')]:
        flow=ledger[outlet]
        expected=64*np.finfo(cells.dtype).eps*np.maximum(np.sum(np.abs(cells[:,k])+np.abs(out[:,k])+np.abs(flow)),1)
        assert ledger[bound] == expected
        separate=float(np.sum(out[:,k].astype(np.float64)-cells[:,k].astype(np.float64)+flow.astype(np.float64)))
        assert abs(separate) <= float(expected) and abs(float(ledger[residual])) <= float(expected)
        entries[name]=dict(native_residual=float(ledger[residual]),independently_summed_residual=separate,
            original_hard_bound=float(expected),factor=64,epsilon=float(np.finfo(cells.dtype).eps))
    assert ledger['clock_residual_seconds'] == 0 and ledger['elapsed_seconds'] == 1800.
    return entries


def comparison(actual, reference, absolute):
    difference=actual.astype(np.float64)-reference.astype(np.float64)
    bound=np.maximum(absolute,.1*np.abs(reference))
    # No relative percentage is assigned where the absolute criterion dominates.
    percent=[100*float(d)/abs(float(r)) if abs(float(r))>absolute/.1 else None
             for d,r in zip(difference,reference)]
    return dict(difference=difference.tolist(),absolute_floor=absolute,relative_fraction=.1,
                bound=bound.tolist(),percent_where_relative_applies=percent,passed=bool(np.all(np.abs(difference)<=bound)))


@pytest.mark.parametrize('name,temperature',[
    ('warm',290.),('frozen',[280.,270.,270.,270.])],ids=['warm-option2','frozen-option2'])
def test_complete_option2_numpy32_vs_original_numpy64(name,temperature):
    controls=original.pb.IntegrationControls()
    case=original.fixture(.4,temperature,bedrock=2.,slope=.2,option=2)
    cells,parameters,cells64,parameters64,option=case
    assert option == 2
    calls=[]
    original_phase=phase.run_numpy32
    before_audit=dict(phase.PHASE_AUDIT)

    def observed(inputs,options,*,inverse=False):
        assert inputs.dtype == np.float32 and np.all(options == 2) and inverse is True
        value=original_phase(inputs,options,inverse=inverse)
        assert all(v.dtype == np.float32 for v in value.values()) and np.all(value['converged']>0)
        calls.append(dict(input_dtype=str(inputs.dtype),output_dtypes={k:str(v.dtype) for k,v in value.items()},
            option=2,inverse=True,all_converged=True,iterations=value['iterations'].tolist(),
            maximum_reconstruction_residual=float(np.max(np.abs(value['reconstruction_residual_jm2'])))))
        return value

    with patch.object(phase,'run_numpy32',observed):
        out,front,ledger=original.run(case,1800.,.5,controls)
    # Separate unchanged original G float64 phase/integrator, same fixture recipe and controls.
    reference,reference_front,reference_ledger=original.reference.advance_main_band(
        cells64,parameters64,2,1800.,.5,2.,controls)
    assert out.dtype == np.float32 and reference.dtype == np.float64
    assert calls and all(phase.PHASE_AUDIT[k]>before_audit[k] for k in before_audit)
    hard32=audit(out,cells,ledger);hard64=audit(reference,cells64,reference_ledger)
    mass=comparison(ledger['layer_mass_kg_m2'],reference_ledger['layer_mass_kg_m2'],.001)
    # Explicit near-zero heat comparison uses the existing 0.05 J/m2 absolute scale;
    # it is a cross-reference comparison, never a replacement for either hard ledger.
    heat=comparison(ledger['layer_enthalpy_j_m2'],reference_ledger['layer_enthalpy_j_m2'],controls.energy_absolute_tolerance_j_m2)
    temperature_difference=out[:,3].astype(np.float64)-reference[:,3]
    front_difference=float(front)-float(reference_front)
    result=dict(case=name,freezing_option=2,duration_seconds=1800.,controls=asdict(controls),
        same_nominal_initial_recipe=True,input_quantization_explicit=True,pure_dtype_only_comparison=False,
        initial_cells32=cells.tolist(),initial_cells64=cells64.tolist(),
        input_cells_quantization=(cells.astype(np.float64)-cells64).tolist(),
        input_parameters_quantization=(parameters.astype(np.float64)-parameters64).tolist(),
        input_requested_temperature=temperature,phase_audit_increment={k:phase.PHASE_AUDIT[k]-before_audit[k] for k in before_audit},
        actual_numpy32_inverse_calls=len(calls),all_numpy32_inverse_returns_float32=True,
        actual_full_integrations=dict(numpy32=1,original_numpy64=1),actual_phase_calls=calls,
        water_outlet_comparison=mass,enthalpy_outlet_comparison=heat,
        temperature_difference_k=temperature_difference.tolist(),temperature_absolute_limit_k=.001,
        front_difference_m=front_difference,front_absolute_limit_m=.001,
        numpy32=dict(front_m=float(front),outlet_water=ledger['layer_mass_kg_m2'].tolist(),
            outlet_enthalpy=ledger['layer_enthalpy_j_m2'].tolist(),temperature_k=out[:,3].tolist(),
            hard_ledgers=hard32,accepted=ledger['accepted_substeps'],rejected=ledger['rejected_substeps'],
            maximum_error_ratio=ledger['maximum_accepted_error_ratio'],clock_residual_seconds=ledger['clock_residual_seconds']),
        numpy64=dict(front_m=float(reference_front),outlet_water=reference_ledger['layer_mass_kg_m2'].tolist(),
            outlet_enthalpy=reference_ledger['layer_enthalpy_j_m2'].tolist(),temperature_k=reference[:,3].tolist(),
            hard_ledgers=hard64,accepted=reference_ledger['accepted_substeps'],rejected=reference_ledger['rejected_substeps'],
            maximum_error_ratio=reference_ledger['maximum_accepted_error_ratio'],clock_residual_seconds=reference_ledger['clock_residual_seconds']),
        coupled_columns=0,actual_field_years=0,GPU_calls=0,production_registered=False)
    Path('option2-'+name+'.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    np.savez('option2-'+name+'-original-arrays.npz',initial32=cells,parameters32=parameters,
        initial64=cells64,parameters64=parameters64,final32=out,final64=reference,
        outlet_water32=ledger['layer_mass_kg_m2'],outlet_heat32=ledger['layer_enthalpy_j_m2'],
        outlet_water64=reference_ledger['layer_mass_kg_m2'],outlet_heat64=reference_ledger['layer_enthalpy_j_m2'])
    print('PM_OPTION2_DIAGNOSTIC '+json.dumps(result,allow_nan=False),flush=True)
    assert mass['passed'] and heat['passed']
    assert np.max(np.abs(temperature_difference)) < .001 and abs(front_difference) < .001

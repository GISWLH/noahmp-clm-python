"""Stdlib-only freezing of two additional option2 tests and existing I controls."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
OUT=BASE/'clm-drainage-option2-pm-preparation'
EXE=BASE/'clm-drainage-option2-pm-execution'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()


def archive(path,digest):
    assert sha(path.read_bytes())==digest
    with tarfile.open(path) as tar:
        members=tar.getmembers()
        assert all(m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute() for m in members)
        raw={m.name:tar.extractfile(m).read() for m in members}
    assert len(raw)==len(members)
    index=json.loads(raw['artifact-inventory.json'])
    assert all(sha(raw[n])==(h if isinstance(h,str) else h['sha256']) for n,h in index.items())
    return raw


def main():
    OUT.mkdir(exist_ok=True);EXE.mkdir(exist_ok=True)
    iar=BASE/'clm-drainage-adaptive-pb-i-evidence.tar.gz'
    gar=BASE/'clm-drainage-adaptive-pb-g-evidence.tar.gz'
    iraw=archive(iar,'5d520f1615d8ec7b460954a3e3f32c3588528b6839151b8b1198c35cd8cf8bc8')
    graw=archive(gar,'902fc52c7450c1472dba2c3649e67b6ed38a6e57eb0ba1c451a839acf47dcd93')
    assert len(iraw)==42
    im=iraw['preparation/CONTROLS_SHA256.json']
    assert sha(im)=='0b4737c3c127da407f96796424fcd3287b4aa4eb164a6bd9caf270cb1066269d'
    for n,h in json.loads(im).items():
        assert sha(iraw['preparation/'+n])==h
        (OUT/n).write_bytes(iraw['preparation/'+n])
    assert iraw['preparation/adaptive_main_pbg.py']==graw['preparation/adaptive_main_pbg.py']
    (OUT/'ORIGINAL_I_CONTROLS_SHA256.json').write_bytes(im)
    binding=dict(original_I_archive_sha256=sha(iar.read_bytes()),original_I_members=42,
        original_I_manifest_sha256=sha(im),original_I_job='1641.manager',
        original_G_archive_sha256=sha(gar.read_bytes()),
        source_archive_sha256='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d',
        source_manifest_sha256='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f',source_files=584,
        new_collected_cases=2,original_tests_collected=0,expected_full_adaptive_integrations=4,
        case_names=['warm-option2','frozen-option2'],freezing_option=2,duration_seconds=1800,
        mass_comparison=dict(relative=.1,absolute_kg_m2=.001),
        heat_comparison=dict(relative=.1,absolute_j_m2=.05,absolute_provenance='Original IntegrationControls energy absolute scale, used explicitly for this new comparison, separate from hard budgets'),
        temperature_absolute_k=.001,front_absolute_m=.001,hard_budget_factor=64,
        production_registered=False,GPU_runs=0,coupled_columns=0,actual_field_years=0)
    (OUT/'PM_BINDINGS.json').write_bytes(js(binding))
    (OUT/'README_PM.md').write_text('''# PM option2 full adaptive coverage

Only test_option2_pm.py is collected: warm and frozen option2, each one NumPy32
full adaptive integration and one unchanged original G NumPy64 integration.
The exact I fixture/run/phase/core and all original files are copied unchanged;
I's existing 18 tests are not collected again. Same nominal theta=.4, four .5m
layers, slope=.2, front=.5m, bottom=2m, dt=1800s and default controls. Warm T=290K;
frozen T=[280,270,270,270]K. These are quantized-initial-condition physical
comparisons; they are not pure-dtype-only equivalence or an official site run.

All input cell/parameter quantization and both actual outlet/temperature/front
results are retained. Mass criterion max(.001 kg/m2,10% of original64), heat
max(.05 J/m2,10%); .05 is the existing absolute integration scale used explicitly
for the new heat comparison. No relative percentage is assigned where the
absolute criterion dominates. Temperature/front retain .001 K/m criteria.
Each original hard M/H bound remains 64*eps(its explicit dtype)*original scale,
independently re-summed in float64. This is separate from science comparison.

A read-only spy calls the original phase function and returns its same object;
every actual core inverse must use option2 and float32 inputs/outputs and converge.
Original barrier dtype checks remain. Accepted/rejected steps and exact interval
clock are reported for both backends. Four component integrations are real
physical executions; coupled columns, actual field years, GPU and production
registration remain zero. No physical source or I controls are modified.

The frozen original I README retains an acknowledged pre-execution saturated
water-quantization prediction error, corrected in its original public readout.
PM reports its own measured inputs; it makes no prediction of their differences.
''',encoding='utf8',newline='\n')
    # Reuse the original bounded lifecycle, changing only stage/test selection and scope.
    original=(BASE/'clm-drainage-adaptive-pb-i-execution/run_component_pb.py').read_text()
    code=original.replace('/tmp/noahmp-clm-drainage-adaptive-pb-i','/tmp/noahmp-clm-drainage-option2-pm')
    code=code.replace("str(root / 'preparation/test_adaptive_main_pbg.py'),str(root / 'preparation/test_adaptive_main_pbi.py')", "str(root / 'preparation/test_option2_pm.py')")
    code=code.replace("('PB_G_DIAGNOSTIC ','PB_I_DIAGNOSTIC ')","('PM_OPTION2_DIAGNOSTIC ',)")
    code=code.replace("len(cases) == 18", "len(cases) == 2")
    code=code.replace("official_fixture_regression_passed=False", "option2_full_adaptive_comparison_passed=False")
    code=code.replace("receipt['official_fixture_regression_passed'] = True", "receipt['option2_full_adaptive_comparison_passed'] = True")
    code=code.replace("        receipt['passed'] = True", """        assert all(c.find('skipped') is None for c in cases)
        assert len(diagnostics) == 2 and {d['case'] for d in diagnostics} == {'warm','frozen'}
        assert all(d['freezing_option'] == 2 and d['actual_full_integrations'] == dict(numpy32=1,original_numpy64=1) for d in diagnostics)
        assert all(d['water_outlet_comparison']['passed'] and d['enthalpy_outlet_comparison']['passed'] for d in diagnostics)
        receipt.update(actual_full_adaptive_integrations=4,NumPy32_integrations=2,original_NumPy64_integrations=2,
            original_I_tests_reexecuted=0,actual_numpy32_inverse_calls=sum(d['actual_numpy32_inverse_calls'] for d in diagnostics))
        receipt['passed'] = True""")
    old="        binding = json.loads((root / 'preparation/BINDINGS.json').read_bytes())"
    new=old+"""
        pm = json.loads((root / 'preparation/PM_BINDINGS.json').read_bytes())
        assert sha((root / 'preparation/ORIGINAL_I_CONTROLS_SHA256.json').read_bytes()) == pm['original_I_manifest_sha256']
        original_index = json.loads((root / 'preparation/ORIGINAL_I_CONTROLS_SHA256.json').read_bytes())
        assert all(sha((root / 'preparation'/n).read_bytes()) == h for n,h in original_index.items())
        for name, digest in [('original-I-evidence.tar.gz',pm['original_I_archive_sha256']),('original-G-evidence.tar.gz',pm['original_G_archive_sha256'])]:
            assert sha((STAGE/name).read_bytes()) == digest
        receipt.update(original_I_archive_sha256=pm['original_I_archive_sha256'],original_G_archive_sha256=pm['original_G_archive_sha256'],original_I_manifest_sha256=pm['original_I_manifest_sha256'])"""
    assert code.count(old)==1;code=code.replace(old,new)
    code=code.replace("Original NumPy64 eight cases plus ten explicit NumPy32 phase/adaptive main-band cases, original hard budgets, actual 1616 and independent ODE; JAX/CUDA unexecuted; no device acceptance; no new official call, coupled column, annual, GPU or release acceptance.",
        "Two added full adaptive option2 warm/frozen comparisons: actual NumPy32 and unchanged original G NumPy64, explicit input quantization, original hard budgets. No old18 tests, new official calls, coupled column, field year, GPU or production acceptance.")
    (EXE/'run_component_pb.py').write_text(code,encoding='utf8',newline='\n')
    for name in ['component_pb.pbs','dispatch_component_pb.py']:
        code=(BASE/'clm-drainage-adaptive-pb-i-execution'/name).read_text()
        code=code.replace('noahmp-clm-drainage-adaptive-pb-i','noahmp-clm-drainage-option2-pm').replace('dispatch_drainage_adaptive_pbi.py','dispatch_drainage_option2_pm.py').replace('drainage-adaptive-pbi','drainage-option2-pm')
        code=code.replace('PB-i NumPy32 and unchanged NumPy64 main band against frozen PB-c, actual 1616 and independent ODE; no coupled column, annual or GPU execution.',
                          'PM two additional full option2 NumPy32 vs original NumPy64 component cases only; no old18 tests, coupled column, field year or GPU.')
        (EXE/name).write_text(code,encoding='utf8',newline='\n')
    files={}
    for folder in [OUT,EXE]:
        index={p.name:sha(p.read_bytes()) for p in folder.iterdir() if p.is_file() and p.name!='CONTROLS_SHA256.json'}
        (folder/'CONTROLS_SHA256.json').write_bytes(js(index))
        for n in [*index,'CONTROLS_SHA256.json']:
            raw=(folder/n).read_bytes()
            if n.endswith('.py'):ast.parse(raw)
            files[('preparation/' if folder==OUT else 'execution/')+n]=raw
    source=BASE/'climatology-final-candidate-nm-source.tar.gz'
    assert sha(source.read_bytes())==binding['source_archive_sha256']
    files.update({'source.tar.gz':source.read_bytes(),'original-I-evidence.tar.gz':iar.read_bytes(),'original-G-evidence.tar.gz':gar.read_bytes()})
    files['stage-inventory.json']=js({n:sha(b) for n,b in sorted(files.items())})
    result=subprocess.run(['E:/miniconda3/Scripts/ruff.exe','check','--select','F821',str(OUT),str(EXE),str(Path(__file__))],capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    target=BASE/'clm-drainage-option2-pm-stage.tar.gz';assert not target.exists()
    with tarfile.open(target,'w:gz') as tar:
        for n,b in sorted(files.items()):
            m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==files
    record=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,members=len(files),
        preparation_manifest_sha256=sha((OUT/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((EXE/'CONTROLS_SHA256.json').read_bytes()),
        original_I_all_controls_byteexact=True,old_tests_collected=0,new_planned_tests=2,full_adaptive_integrations=4,
        ruff_exit=0,local_numerical_execution=False,submitted=False)
    (BASE/'clm-drainage-option2-pm-stage-package.json').write_bytes(js(record));print(json.dumps(record))


if __name__=='__main__':main()

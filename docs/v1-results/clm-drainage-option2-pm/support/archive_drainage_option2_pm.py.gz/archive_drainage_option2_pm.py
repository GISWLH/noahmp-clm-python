"""Preserve actual PM terminal outcome and every non-source original result byte."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile
import xml.etree.ElementTree as ET

ROOT=Path('/tmp/noahmp-clm-drainage-option2-pm')
JOB='1642.manager'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()


def main():
    assert socket.gethostname()=='manager'
    qstat=subprocess.check_output(['qstat','-xf',JOB])
    assert re.search(rb'^Job Id: '+re.escape(JOB.encode())+rb'\s*$',qstat,re.M)
    for field,value in [('job_state','F'),('Stageout_status','0')]:
        assert re.search(rb'^\s*'+field.encode()+rb' = '+value.encode()+rb'\s*$',qstat,re.M)
    status=int(re.search(rb'^\s*Exit_status = (-?\d+)\s*$',qstat,re.M).group(1))
    for name in ['result.tar.gz','pbs-exit.txt']:
        digest=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
        assert not (ROOT/name).exists()
        subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
        assert sha((ROOT/name).read_bytes())==digest
    assert int((ROOT/'pbs-exit.txt').read_text())==status
    with tarfile.open(ROOT/'result.tar.gz') as tar:
        members=[m for m in tar if m.isfile()]
        raw={m.name.removeprefix('./'):tar.extractfile(m).read() for m in members}
    assert len(raw)==len(members)
    receipt=json.loads(raw['receipt.json'])
    assert receipt['pbs_job']==JOB and receipt['pytest_parent_returncode']==status==int(raw['worker-exit.txt'])
    source_raw=raw['source/SOURCE_SHA256.json']
    assert sha(source_raw)=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    source=json.loads(source_raw);assert len(source)==584
    assert all(sha(raw['source/'+n])==h for n,h in source.items())
    for folder,digest in [('preparation','e577f473f57b67fa1dc4fb2980d281a4d5bd231f2643731130458ba3b65a9de4'),
                          ('execution','7ff4fa2accab6eadf9d11961abe7c27475b67f95c64e59bf9d944795b9f4ef1c')]:
        manifest=raw[folder+'/CONTROLS_SHA256.json'];assert sha(manifest)==digest
        assert all(sha(raw[folder+'/'+n])==h for n,h in json.loads(manifest).items())
    im=raw['preparation/ORIGINAL_I_CONTROLS_SHA256.json']
    assert sha(im)=='0b4737c3c127da407f96796424fcd3287b4aa4eb164a6bd9caf270cb1066269d'
    assert all(sha(raw['preparation/'+n])==h for n,h in json.loads(im).items())
    tests=list(ET.fromstring(raw['pytest.xml']).iter('testcase'))
    assert len(tests)==2
    assert {c.attrib['name'] for c in tests}=={'test_complete_option2_numpy32_vs_original_numpy64[warm-option2]',
                                            'test_complete_option2_numpy32_vs_original_numpy64[frozen-option2]'}
    diagnostics=json.loads(raw['diagnostics.json'])
    stdout=[json.loads(line.split('PM_OPTION2_DIAGNOSTIC ',1)[1]) for line in raw['pytest.stdout.txt'].decode().splitlines() if 'PM_OPTION2_DIAGNOSTIC ' in line]
    assert stdout==diagnostics
    if status==0:
        assert receipt['passed'] and receipt['source_and_controls_unchanged'] and receipt['actual_full_adaptive_integrations']==4
        assert all(c.find(x) is None for c in tests for x in ['failure','error','skipped'])
        assert len(diagnostics)==2 and b'2 passed' in raw['pytest.stdout.txt']
        for d in diagnostics:
            assert d['freezing_option']==2 and d['water_outlet_comparison']['passed'] and d['enthalpy_outlet_comparison']['passed']
            assert all(abs(v)<.001 for v in d['temperature_difference_k']) and abs(d['front_difference_m'])<.001
            for backend in ['numpy32','numpy64']:
                ledger=d[backend]
                assert ledger['clock_residual_seconds']==0
                for account in ledger['hard_ledgers'].values():
                    assert account['factor']==64 and abs(account['native_residual'])<=account['original_hard_bound']
                    assert abs(account['independently_summed_residual'])<=account['original_hard_bound']
            assert d['actual_numpy32_inverse_calls']==len(d['actual_phase_calls'])>0
            assert all(c['option']==2 and c['inverse'] and c['all_converged'] and c['input_dtype']=='float32'
                and set(c['output_dtypes'].values())=={'float32'} for c in d['actual_phase_calls'])
    data={n:b for n,b in raw.items() if not n.startswith('source/') or n=='source/SOURCE_SHA256.json'}
    for name in ['dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt',
                 'compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt']:
        data['scheduler/'+name]=(ROOT/name).read_bytes()
    data['scheduler/actual-qstat.txt']=qstat
    present=(ROOT/'pbs-output.log').exists()
    if present:data['scheduler/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
    data['original-result-members.json']=js({n:dict(sha256=sha(b),bytes=len(b),included=n in data) for n,b in raw.items()})
    result=dict(actual_job=JOB,actual_job_state='F',actual_exit=status,Stageout_status=0,
        pytest_tests=len(tests),pytest_seconds=receipt.get('pytest_seconds'),worker_seconds=receipt['seconds'],
        actual_full_adaptive_integrations=receipt.get('actual_full_adaptive_integrations'),original_I_tests_reexecuted=0,
        original_I_archive_sha256=receipt['original_I_archive_sha256'],original_G_archive_sha256=receipt['original_G_archive_sha256'],
        source_archive_sha256=receipt['source_archive_sha256'],source_files_verified=584,
        raw_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),raw_result_members=len(raw),omitted_verified_source_members=584,
        pbs_output_log_present=present,coupled_columns=0,actual_field_years=0,GPU_runs=0,production_registered=False,
        diagnostics=diagnostics,
        scope='Only two additional option2 full adaptive cases; four real component integrations with explicit input quantization. No old18 tests, new official or coupled/year/GPU execution.')
    data['closed-run.json']=js(result)
    data['support/archive_drainage_option2_pm.py']=Path(__file__).read_bytes()
    for name in ['prepare_drainage_option2_pm.py','clm-drainage-option2-pm-stage-package.json']:
        data['support/'+name]=(ROOT/name).read_bytes()
    data['INTEGRITY.json']=js({n:sha(b) for n,b in sorted(data.items())})
    target=ROOT/'clm-drainage-option2-pm-evidence.tar.gz';assert not target.exists()
    with tarfile.open(target,'w:gz') as tar:
        for n,b in sorted(data.items()):
            m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
    with tarfile.open(target) as tar:assert {m.name:tar.extractfile(m).read() for m in tar}==data
    package={k:v for k,v in result.items() if k!='diagnostics'}
    package.update(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,
        artifacts=len(data),inventory_files=len(data)-1)
    (ROOT/'clm-drainage-option2-pm-package.json').write_bytes(js(package))
    (ROOT/'clm-drainage-option2-pm-readout.json').write_bytes(js(result))
    print(json.dumps(package))


if __name__=='__main__':main()

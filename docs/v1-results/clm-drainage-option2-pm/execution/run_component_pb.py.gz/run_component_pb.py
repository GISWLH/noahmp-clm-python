"""One bounded PBS numerical test run of the isolated PB component."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-clm-drainage-option2-pm')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    assert os.name != 'nt' and socket.gethostname() == 'compute002' and os.environ.get('PBS_JOBID')
    root = Path(sys.argv[1]).resolve()
    assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not root.exists()
    root.mkdir()
    started = time.monotonic()
    receipt = dict(passed=False, error=None, pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
        python=sys.version, python_executable=sys.executable, pytest_parent_returncode=None,
        coupled_column_runs=0, site_inputs_read=0, GPU_tasks=0, production_integrated=False,
        option2_full_adaptive_comparison_passed=False)
    try:
        stage_index = json.loads((STAGE / 'stage-inventory.json').read_bytes())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        for folder in ('preparation', 'execution'):
            shutil.copytree(STAGE / folder, root / folder)
            index = json.loads((root / folder / 'CONTROLS_SHA256.json').read_bytes())
            assert set(p.name for p in (root / folder).iterdir()) == set(index) | {'CONTROLS_SHA256.json'}
            assert all(sha((root / folder / n).read_bytes()) == h for n, h in index.items())
        binding = json.loads((root / 'preparation/BINDINGS.json').read_bytes())
        pm = json.loads((root / 'preparation/PM_BINDINGS.json').read_bytes())
        assert sha((root / 'preparation/ORIGINAL_I_CONTROLS_SHA256.json').read_bytes()) == pm['original_I_manifest_sha256']
        original_index = json.loads((root / 'preparation/ORIGINAL_I_CONTROLS_SHA256.json').read_bytes())
        assert all(sha((root / 'preparation'/n).read_bytes()) == h for n,h in original_index.items())
        for name, digest in [('original-I-evidence.tar.gz',pm['original_I_archive_sha256']),('original-G-evidence.tar.gz',pm['original_G_archive_sha256'])]:
            assert sha((STAGE/name).read_bytes()) == digest
        receipt.update(original_I_archive_sha256=pm['original_I_archive_sha256'],original_G_archive_sha256=pm['original_G_archive_sha256'],original_I_manifest_sha256=pm['original_I_manifest_sha256'])
        source_archive = STAGE / 'source.tar.gz'
        assert sha(source_archive.read_bytes()) == binding['source_archive_sha256']
        source = root / 'source'
        source.mkdir()
        with tarfile.open(source_archive) as archive:
            members = archive.getmembers()
            assert len({v.name for v in members}) == len(members)
            assert all(v.isfile() and not Path(v.name).is_absolute() and '..' not in Path(v.name).parts and '\\' not in v.name for v in members)
            raw_manifest = archive.extractfile('SOURCE_SHA256.json').read()
            assert sha(raw_manifest) == binding['source_manifest_sha256']
            index = json.loads(raw_manifest)
            assert len(index) == 584 and set(index) | {'SOURCE_SHA256.json'} == {v.name for v in members}
            for item in members:
                raw = archive.extractfile(item).read()
                if item.name != 'SOURCE_SHA256.json':
                    assert sha(raw) == index[item.name]
                target = source / item.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
        env = os.environ.copy()
        env.pop('PYTHONHOME', None)
        env.update(PB_F_BACKEND='numpy', JAX_PLATFORMS='cpu', CUDA_VISIBLE_DEVICES='')
        env.update(PYTHONPATH=str(source / 'src') + ':' + str(root / 'preparation') + ':/home/zhangyq/noahmp-v1/test-deps',
                   PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        dependency_root = Path('/home/zhangyq/noahmp-v1/test-deps')
        dependencies = {}
        for distribution in ('numpy-2.2.6.dist-info', 'scipy-1.16.3.dist-info', 'pytest-9.1.1.dist-info'):
            metadata = dependency_root / distribution / 'METADATA'
            dependencies[distribution] = dict(metadata_sha256=sha(metadata.read_bytes()), path=str(metadata))
        save(root / 'test-dependencies.json', dependencies)
        receipt['test_dependencies'] = dependencies
        command = [sys.executable, '-B', '-m', 'pytest', '-q', '-s', '-p', 'no:cacheprovider',
                   '--junitxml=' + str(root / 'pytest.xml'), str(root / 'preparation/test_option2_pm.py')]
        save(root / 'pytest-command.json', command)
        test_started = time.monotonic()
        with (root / 'pytest.stdout.txt').open('wb') as out, (root / 'pytest.stderr.txt').open('wb') as err:
            result = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=530)
        receipt.update(pytest_parent_returncode=result.returncode, pytest_seconds=time.monotonic() - test_started)
        # Preserve actual diagnostics even when a test fails.
        diagnostics = [json.loads(line.split(marker, 1)[1]) for line in
            (root / 'pytest.stdout.txt').read_text().splitlines() for marker in ('PM_OPTION2_DIAGNOSTIC ',) if marker in line]
        save(root / 'diagnostics.json', diagnostics)
        import xml.etree.ElementTree as ET
        suites = ET.parse(root / 'pytest.xml').getroot()
        cases = list(suites.iter('testcase'))
        receipt.update(tests=len(cases), diagnostic_records=len(diagnostics),
            failures=sum(1 for c in cases if c.find('failure') is not None),
            errors=sum(1 for c in cases if c.find('error') is not None),
            source_files_verified=len(index), source_archive_sha256=binding['source_archive_sha256'],
            source_manifest_sha256=binding['source_manifest_sha256'],
            preparation_manifest_sha256=sha((root / 'preparation/CONTROLS_SHA256.json').read_bytes()),
            execution_manifest_sha256=sha((root / 'execution/CONTROLS_SHA256.json').read_bytes()))
        assert all(sha((source / n).read_bytes()) == h for n, h in index.items())
        assert all(sha((STAGE / n).read_bytes()) == h for n, h in stage_index.items())
        receipt['source_and_controls_unchanged'] = True
        assert result.returncode == 0 and len(cases) == 2 and receipt['failures'] == receipt['errors'] == 0
        assert all(c.find('skipped') is None for c in cases)
        assert len(diagnostics) == 2 and {d['case'] for d in diagnostics} == {'warm','frozen'}
        assert all(d['freezing_option'] == 2 and d['actual_full_integrations'] == dict(numpy32=1,original_numpy64=1) for d in diagnostics)
        assert all(d['water_outlet_comparison']['passed'] and d['enthalpy_outlet_comparison']['passed'] for d in diagnostics)
        receipt.update(actual_full_adaptive_integrations=4,NumPy32_integrations=2,original_NumPy64_integrations=2,
            original_I_tests_reexecuted=0,actual_numpy32_inverse_calls=sum(d['actual_numpy32_inverse_calls'] for d in diagnostics))
        receipt['passed'] = True
        receipt['option2_full_adaptive_comparison_passed'] = True
        receipt['official_calls_executed'] = 0
    except Exception:
        receipt['error'] = traceback.format_exc()
        (root / 'failure.txt').write_text(receipt['error'])
    receipt['seconds'] = time.monotonic() - started
    receipt['scope'] = 'Two added full adaptive option2 warm/frozen comparisons: actual NumPy32 and unchanged original G NumPy64, explicit input quantization, original hard budgets. No old18 tests, new official calls, coupled column, field year, GPU or production acceptance.'
    save(root / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

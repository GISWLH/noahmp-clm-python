"""Seal QT actual same-subproblem algebra; heavy original inputs referenced."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-analysis-qt'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def contents(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=[m for m in t if m.isfile()];names=[m.name.removeprefix('./') for m in members]
        assert len(set(names))==len(names) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        return {n:t.extractfile(m).read() for n,m in zip(names,members)}


def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes()
    assert sha(stage_raw)=='d0322d0dba902e163d3e75510e69849d26bd4704aca67b5685a73a47debf6b9a'
    stage=contents(stage_raw);index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==17 and set(index)==set(stage)-{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    result_raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes()
    assert sha(result_raw)=='631759a5acd21ddbbd0145e12853ba643cbbc49c617fdaf5ce8d1ee53620de64'
    result=contents(result_raw);assert len(result)==28
    for folder,copy in [('preparation','preparation-controls'),('execution','execution-controls')]:
        manifest=json.loads(stage[folder+'/CONTROLS_SHA256.json'])
        for name in [*manifest,'CONTROLS_SHA256.json']:
            original=stage[folder+'/'+name]
            if name in manifest:assert sha(original)==manifest[name]
            assert result[copy+'/'+name]==original
    for name in ('setup-exit.txt','worker-exit.txt','stage-after-exit.txt','pbs-command-exit.txt'):assert result[name].strip()==b'0'
    before=json.loads(result['stage-before.json']);after=json.loads(result['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']==index
    qstat=(BASE/(LABEL+'-closure/initial-qstat.stdout')).read_bytes()
    assert re.search(rb'^Job Id: 1875.manager\s*$',qstat,re.M)
    for field,value in [('job_state','F'),('Exit_status','0'),('Stageout_status','0')]:
        assert re.search(rb'^\s*'+field.encode()+rb' = '+value.encode()+rb'\s*$',qstat,re.M)
    report=json.loads((BASE/(LABEL+'-readout.json')).read_bytes())
    assert report['analysis_completed'] and report['actual_analysis_exit']==0 and report['immutable_before_after_exact']
    assert report['iterations_analyzed']==36 and report['final_iteration']['iteration']==66
    assert report['last_return_prediction_and_trial_not_reused_as_iteration66']
    assert report['new_lambda_or_radius_or_trial_evaluations']==0 and report['original_QR_model_exit']==1
    assert report['model_calls']==report['evaluate_calls']==report['new_Jacobian_computations']==0
    closure=dict(pbs_job='1875.manager',job_state='F',PBS_exit=0,Stageout_status=0,actual_analysis_exit=0,
        result_sha256=sha(result_raw),stage_sha256=sha(stage_raw),result_files=28,stage_files=17,
        own_point_and_age_verified=True,iterations_analyzed=36,prediction_trial_age65_not66=True,
        original_QR_model_failure_preserved=True,same_original_lambda_only=True,new_lambda_or_radius_or_trial_evaluations=0,
        model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,nonlinear_basin_or_minimum_proved=False,
        physical_degeneracy_proved=False,scientific_acceptance=False,production_source_changed=False,
        array_gauge_note=report['readout_array_gauge_note'])
    (BASE/(LABEL+'-closure.json')).write_bytes(encode(closure))
    items={'original-result.tar.gz':result_raw,'stage-inventory.json':stage['stage-inventory.json']}
    items.update({'actual-result/'+name:raw for name,raw in result.items()})
    items.update({'executed-controls/'+name:raw for name,raw in stage.items() if name.startswith(('preparation/','execution/'))})
    references={name:dict(sha256=sha(raw),bytes=len(raw),included=False,
        scope='Original prior result archive already sealed separately; original bytes retained unchanged locally and in corresponding evidence package.')
        for name,raw in stage.items() if name.endswith('-result.tar.gz')}
    items['HEAVY-INPUT-REFERENCES.json']=encode(references)
    for folder in (BASE/(LABEL+'-closure'),BASE/(LABEL+'-deployment')):
        for p in sorted(folder.rglob('*')):
            if p.is_file():items[folder.name+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
    for name in (LABEL+'-readout.json',LABEL+'-closure.json',LABEL+'-stage-package.json',
        'surface-lm-hard-ground-qr-independent-review-qc.json','review_surface_hard_ground_qr_qc.py',
        'prepare_surface_lm_hard_ground_analysis_qt.py','deploy_surface_lm_hard_ground_analysis_qt.py',
        'collect_surface_lm_hard_ground_analysis_qt.py','package_surface_lm_hard_ground_analysis_qt.py'):
        items['local-evidence/'+name]=(BASE/name).read_bytes()
    items['README.md']=b'QT1875 actualF0/Stageout0 offline algebra only, zero model/evaluate/newJ/newlambda/radius/trial. Full raw28result members, stage17 hash/inventory/exact controls, actual command exits/typed data and late independent source review for originalQR included. QR/PW heavy original archives explicitly hash-referenced, not duplicated. OriginalQR1870 failure remains failure. Each original direction uses own-point J11/r/scale/gradient and defining age. SVD direction comparison uses exactly originalr/JS/lambda and is not a new physical trial or accepted repair. Last66 no-feasible cannot reuse65 pred/actual. Ground rowK distinct from other11/physical11Wm2. Full12 off-ground intermediate iterates are solver paths, not accepted physical states. Neither weak mode/small gradient nor near points proves a nonlinear minimum or physical degeneracy. Raw full-U projection signs differ from gauged weakest pair. Windows reads only JSON scalars and opaque payload bytes, no NumPy/unpickle/numerical decode.\n'
    items['artifact-inventory.json']=encode({name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    assert contents(target.read_bytes())==items
    package=dict(archive=target.name,label=LABEL,artifacts=len(items),bytes=target.stat().st_size,sha256=sha(target.read_bytes()),
        actual_PBS_job='1875.manager',actual_PBS_exit=0,Stageout_status=0,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        original_QR_model_exit=1,scientific_or_solver_acceptance=False,
        scope='1875 F0/Stageout0 same-original-lambda savedQR/PW11x11 subproblem analysis only; zero new model/eval/J/lambda/trial. OriginalQR F1 preserved; no repair/minimum/physical-degeneracy claim.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

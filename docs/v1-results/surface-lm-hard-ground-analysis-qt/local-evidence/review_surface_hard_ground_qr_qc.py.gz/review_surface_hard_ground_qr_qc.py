"""Static independent QR elimination/source review only; no model import."""
import ast
import json
from pathlib import Path

from package_surface_reference_pt import files,sha,encode

BASE=Path(__file__).resolve().parent


def main():
    old_raw=(BASE/'surface-lm-merit-qn-source.tar.gz').read_bytes();new_raw=(BASE/'surface-lm-hard-ground-qr-source.tar.gz').read_bytes()
    assert sha(old_raw)=='adc1a56065a74cbfb9121908fd0a28743d77047280eb059d0e068830b6cf225c' and sha(new_raw)=='3cbf7962a927f0a7da7c47cbccd7b1813db5b248199b4a4c8aecf0fa16d679da'
    old=files(old_raw);new=files(new_raw);om=json.loads(old['SOURCE_SHA256.json']);nm=json.loads(new['SOURCE_SHA256.json']);assert len(om)==len(nm)==584 and set(om)==set(nm)
    assert all(sha(old[n])==h for n,h in om.items()) and all(sha(new[n])==h for n,h in nm.items())
    path='src/noahmp_clm/physics/canopy_phase_energy.py';changed=[n for n in nm if old[n]!=new[n]];assert changed==[path]
    assert new[path]==(BASE/'surface-lm-hard-ground-qr-preparation/candidate_phase.py').read_bytes()
    a=old[path].decode();b=new[path].decode();ta=ast.parse(a);tb=ast.parse(b)
    old_helper=next(n for n in ta.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_rescue');wrapper=next(n for n in tb.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_rescue');fixed=next(n for n in tb.body if isinstance(n,ast.FunctionDef) and n.name=='_dry_lm_fixed_ground_rescue')
    assert isinstance(wrapper.body[1],ast.If) and ast.unparse(wrapper.body[1].test)=='fixed_ground_temperature is not None'
    def body_tail(text,node,start):return ''.join(text.splitlines(keepends=True)[node.body[start].lineno-1:node.end_lineno])
    assert body_tail(a,old_helper,1)==body_tail(b,wrapper,2)
    eval_a=[n for n in ast.walk(ta) if isinstance(n,ast.FunctionDef) and n.name=='evaluate'];eval_b=[n for n in ast.walk(tb) if isinstance(n,ast.FunctionDef) and n.name=='evaluate'];assert len(eval_a)==len(eval_b)==1
    assert ast.get_source_segment(a,eval_a[0])==ast.get_source_segment(b,eval_b[0])
    code=ast.get_source_segment(b,fixed)
    required=['x[n]=float(fixed_ground_temperature)','free=np.r_[np.arange(n),n+1]','jac=np.empty((n+1,n+1))','call(hi)[free]-call(lo)[free]','gradient=scaled.T@residual[free]','matrix=normal+damping*np.eye(n+1)','direction=np.zeros(n+2)','direction[free]=','trial[n]=float(fixed_ground_temperature);displacement=trial-x','np.max(abs(residual))<=tolerance','np.max(abs(trial_residual))<=tolerance','range(used_iterations+1,max_iterations+1)']
    assert all(s in code for s in required)
    report=dict(passed=True,blocking_findings=[],scope='Independent readonly stdlib archive/source/AST/static review only; no model/NumPy import, numerical execution, pytest or deployment',parent_source_sha256=sha(old_raw),candidate_source_sha256=sha(new_raw),unchanged_source_files=583,changed_paths=changed,parent_phase_sha256=sha(old[path]),candidate_phase_sha256=sha(new[path]),no_fixed_ground_original_body_bytes_exact=True,physical_evaluate_source_bytes_exact=True,
                checks=[
                    'Free coordinates0..n-1,n+1 exclude ground coordinate n; reduced Jacobian uses matching free residual rows and columns and has(n+1)x(n+1) shape.',
                    'Full direction has n+2 entries, ground direction stays0, original cap vector/alpha/full bounds remain; humidity derivative still1e-7 and leaves1e-6.',
                    'Only ground seed coordinate is overwritten with prescribedTf; other ambient coordinates are copied unchanged. Nonfinite/out-of-boundsTf uses original seed eligibility check.',
                    'Each nested evaluate call checks exact binary64 ground bytes. Each trial restoresTf before displacement, preserving zero ground displacement.',
                    'Original shared used_iterations..max_iterations budget, rejected/unsolvable attempts, remaining caller budget and final permitted trial root check stay intact.',
                    'Convergence checks the full original residual envelope; stable actual merit uses full residuals. Only linear problem/prediction use free rows, whose omitted ground constraint is identically0 whenTf invariant holds.',
                    'No extra physical acceptance tolerance is introduced. Added invariant is the explicit prescribed-ground equality; an invariant violation remains a real failure.',
                    'None branch body after the new dispatch is byte exact, and complete physical evaluate plus all583other source files are exact.',
                    'Copy-only trace plan requires all actual detail/trial/finite-difference calls fixedTf, free coordinate/shape/caps/source/kwargs identity and complete original48node validation; no success is inferred from elimination.'
                ],limits='Static consistency does not prove convergence or scientific acceptance. Actual original48nodes/physical parcel gates and immutable-input trace must execute after separate root authorization.')
    (BASE/'surface-lm-hard-ground-qr-independent-review-qc.json').write_bytes(encode(report));print(json.dumps({k:v for k,v in report.items() if k!='checks'}))


if __name__=='__main__':main()

"""Freeze one root-authorized5min existing QR/PW subproblem algebra job."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-analysis-qt'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def main():
    prep=BASE/(LABEL+'-preparation');execution=BASE/(LABEL+'-execution');assert not execution.exists();execution.mkdir()
    original=BASE/'surface-lm-path-comparison-qp-preparation'
    decoder=(original/'analyze_saved_paths_qp.py').read_bytes();assert sha(decoder)=='5c4e82fe3c27f9febdc2aa3ea28293009d447923b71f0e0d7baf2f27f3ddd96f'
    (prep/'saved_qp_decoder.py').write_bytes(decoder);(prep/'serialization_pt.py').write_bytes((original/'serialization_pt.py').read_bytes())
    (prep/'PLAN.md').write_bytes((BASE/(LABEL+'-PLAN.md')).read_bytes())
    (prep/'original-record-inventory.json').write_bytes((BASE/(LABEL+'-inventory.json')).read_bytes())
    expected={
        'qr':('surface-lm-hard-ground-qr-result.tar.gz','f0459848984f75e7e9d66bbaffd6791bfb409e33bd61f296d501a2a9e3bc16cd'),
        'pw':('surface-7275-feasible-root-pw-result.tar.gz','44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')}
    inputs={name+'-result.tar.gz':(BASE/path).read_bytes() for name,(path,_) in expected.items()}
    assert all(sha(inputs[name+'-result.tar.gz'])==digest for name,(_,digest) in expected.items())
    (prep/'BINDINGS.json').write_bytes(encode(dict(input_archives=expected,decoder_sha256=sha(decoder),original_QR_model_exit=1,
        model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,new_lambda_or_radius_or_trial_evaluations=0,
        only_same_recorded_regularized_subproblem_SVD_comparison=True,physical_source_imported=False)))
    (prep/'README.md').write_bytes(b'One authorized1CPU2GiB5min existingQR382events/542originalcall inputs and originalPW own-point matrix analysis. Zero model/evaluate/newJ/newlambda/radius/physicaltrial. Each direction uses its recorded J_age and exact own x/r/J/scale/gradient; groundK versus other11/physical11Wm2. SVD step uses exactly original recordedr/JS/lambda, compared algebraically only, not physically evaluated or accepted. Stored normal eigenspectrum, representable step/ULP, fresh pred/actual and PW own-point ground-deleted matrix, no invented PW accepted path. Full12 intermediate off-ground iterates are solver paths, not accepted physical states. No local-minimum/physical-degeneracy cause claim. Original exceptions unchanged, raw pickle before typedNPZ/JSON, input/control hashes preserved.\n')
    for path in prep.glob('*.py'):ast.parse(path.read_bytes())
    (prep/'STATIC_CHECKS.json').write_bytes(encode(dict(AST_parse_exit=0,numerical_execution=0,physical_imports=0)))
    (prep/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(prep.iterdir()) if p.is_file()}))
    old=BASE/'surface-lm-event-analysis-qm-execution';patches=[]
    for name in ('check_stage_qm.py','dispatch_analysis_qm.py'):
        raw=(old/name).read_bytes();changed=raw.replace(b'noahmp-surface-lm-event-analysis-qm',b'noahmp-surface-lm-hard-ground-analysis-qt').replace(b'analysis_qm',b'analysis_qt')
        target=name.replace('stage_qm','stage_qt').replace('analysis_qm','analysis_qt')
        (execution/target).write_bytes(changed)
        patches.append(''.join(difflib.unified_diff(raw.decode().splitlines(True),changed.decode().splitlines(True),fromfile='QM/'+name,tofile='QT/'+target)))
    raw=(old/'analysis_qm.pbs').read_bytes()
    pbs=raw.replace(b'surface-lm-event-qm',b'surface-lm-algebra-qt').replace(b'noahmp-surface-lm-event-analysis-qm',b'noahmp-surface-lm-hard-ground-analysis-qt')
    pbs=pbs.replace(b'qm-result',b'qt-result').replace(b'check_stage_qm',b'check_stage_qt').replace(b'analyze_saved_lm_events_qm.py',b'analyze_saved_hard_ground_qt.py')
    pbs=pbs.replace(b'--qf "$stage/qf-result.tar.gz"',b'--qr "$stage/qr-result.tar.gz"')
    assert pbs.startswith(b'#!/bin/bash\n') and b'\r' not in pbs
    (execution/'analysis_qt.pbs').write_bytes(pbs)
    patches.append(''.join(difflib.unified_diff(raw.decode().splitlines(True),pbs.decode().splitlines(True),fromfile='QM/analysis_qm.pbs',tofile='QT/analysis_qt.pbs')))
    (execution/'wrapper.diff').write_bytes('\n'.join(patches).encode())
    (execution/'CONTROLS_SHA256.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in sorted(execution.iterdir()) if p.is_file()}))
    items={directory+'/'+p.name:p.read_bytes() for directory,folder in [('preparation',prep),('execution',execution)] for p in folder.iterdir() if p.is_file()}
    items.update(inputs);items['stage-inventory.json']=encode({name:sha(raw) for name,raw in sorted(items.items())})
    for name,raw in items.items():
        if name.endswith('.py'):ast.parse(raw)
    target=BASE/(LABEL+'-stage.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    out=dict(archive=target.name,scope='One authorized existing-array subproblem SVD algebra, zero new model/eval/J/lambda/trial.',
        stage_sha256=sha(target.read_bytes()),stage_members=len(items),bytes=target.stat().st_size,
        preparation_manifest_sha256=sha((prep/'CONTROLS_SHA256.json').read_bytes()),execution_manifest_sha256=sha((execution/'CONTROLS_SHA256.json').read_bytes()),
        worker_sha256=sha((prep/'analyze_saved_hard_ground_qt.py').read_bytes()),numerical_execution=0,submitted=False)
    (BASE/(LABEL+'-stage-package.json')).write_bytes(encode(out));print(json.dumps(out))


if __name__=='__main__':main()

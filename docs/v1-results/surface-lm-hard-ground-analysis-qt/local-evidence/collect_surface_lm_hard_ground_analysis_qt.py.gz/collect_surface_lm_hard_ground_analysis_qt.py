"""Capture QP raw result and JSON-only readout; PBS final is a separate fact."""
from pathlib import Path
import hashlib
import json
import math
import re
import subprocess
import tarfile
import time
from package_surface_feasible_root_pw import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='surface-lm-hard-ground-analysis-qt'
OUT=BASE/(LABEL+'-closure')
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def scalar(node):
    kind=node['kind']
    if kind=='dict':return {key:scalar(value) for key,value in node['items'].items()}
    if kind in ('list','tuple'):return [scalar(value) for value in node['items']]
    if kind=='float':
        value=float.fromhex(node['hex'])
        return value if math.isfinite(value) else dict(finite=False,hex=node['hex'])
    if kind=='array':return {key:value for key,value in node.items() if key!='kind'}
    assert kind in ('NoneType','bool','int','str')
    return node['value']


def main():
    assert not OUT.exists();OUT.mkdir()
    def run(label,command):
        start=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=90)
        (OUT/(label+'.stdout')).write_bytes(result.stdout);(OUT/(label+'.stderr')).write_bytes(result.stderr)
        (OUT/(label+'-exit.json')).write_text(json.dumps(dict(command=command,actual_exit=result.returncode,
            seconds=time.monotonic()-start,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)),indent=2)+'\n')
        assert result.returncode==0
        return result.stdout
    qstat=run('initial-qstat',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','qstat -fx 1875.manager'])
    remote='/tmp/noahmp-surface-lm-hard-ground-analysis-qt'
    raw_hash=run('result-hash',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','sha256sum '+remote+'/result.tar.gz']).decode().split()[0]
    external=run('external-pbs-exit',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2','cat '+remote+'/pbs-exit.txt'])
    target=BASE/(LABEL+'-result.tar.gz');assert not target.exists()
    run('download-result',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc-c2:'+remote+'/result.tar.gz',str(target)])
    assert sha(target.read_bytes())==raw_hash
    with tarfile.open(target) as t:files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
    before=json.loads(files['stage-before.json']);after=json.loads(files['stage-after.json'])
    assert before['passed'] and after['passed'] and before['actual']==after['actual']
    meta=json.loads(files['probe/analysis.json'])
    assert sha(files['probe/analysis.pkl'])==meta['pickle_sha256']
    arrays,fortran=opaque_packet(files['probe/analysis.npz'],meta)
    report=scalar(meta['tree'])
    report['readout_array_gauge_note']='raw_U_projection_signs_not_gauged retains raw NumPy SVD U basis signs. Only reported weak_left/right and their scalar residual_projection use the dominant-left-row-positive gauge.'
    report['readout_scope']='Only already-computed JSON scalar/float.hex values read locally; arrays remain dtype/shape/C-hash descriptors. No NPZ numerical decode or unpickle.'
    (BASE/(LABEL+'-readout.json')).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    for name,raw in files.items():
        if name.endswith(('.json','.log','.txt','.stdout','.stderr')):
            out=OUT/'readable'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
    state=re.search(rb'^\s*job_state = (\w+)\s*$',qstat,re.M).group(1).decode()
    result=dict(pbs_job='1875.manager',initial_job_state=state,initial_terminal_closed=state=='F',
        external_PBS_command_exit=external.decode().strip(),actual_analysis_exit=report['actual_analysis_exit'],
        analysis_completed=report['analysis_completed'],result_sha256=raw_hash,result_files=len(files),opaque_arrays_verified=arrays,fortran_arrays=fortran,
        original_QR_physical_failure_preserved=True,model_calls=report['model_calls'],evaluate_calls=report['evaluate_calls'],new_Jacobian_computations=report['new_Jacobian_computations'])
    (OUT/'initial-result-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result));print(json.dumps(dict(exception=report.get('exception'))))


if __name__=='__main__':main()

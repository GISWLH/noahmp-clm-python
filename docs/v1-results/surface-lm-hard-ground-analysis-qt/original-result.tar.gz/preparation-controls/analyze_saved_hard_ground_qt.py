"""PBS-only original QR11x11 subproblem algebra,0model/eval/newJ/newlambda."""
from pathlib import Path
import argparse
import hashlib
import os
import socket
import sys
import time
import traceback

if os.name=='nt' or not os.environ.get('PBS_JOBID') or socket.gethostname().split('.')[0]!='compute002':
    raise RuntimeError('Saved hard-ground algebra requires compute002 PBS')
import numpy as np
from saved_qp_decoder import archive,unpack,exact
from serialization_pt import dump_return

sha=lambda raw:hashlib.sha256(raw).hexdigest()


def modes(matrix,r,scale,caps,free):
    u,s,vh=np.linalg.svd(matrix,full_matrices=False)
    left=u[:,-1].copy();right=vh[-1].copy();pivot=int(np.argmax(abs(left)))
    if left[pivot]<0.:left=-left;right=-right
    physical=scale*right;factor=float(np.max(abs(physical)/caps));physical=physical/factor if factor>0. else physical
    projection=float(left@r);total=float(r@r)
    return dict(singular_values=s.tolist(),condition=float(s[0]/s[-1]) if s[-1]!=0. else float('inf'),
        weak_left=left,weak_right=right,physical_right_normalized_to_original_caps=physical,
        residual_projection=projection,projection_squared_fraction=projection*projection/total if total>0. else None,
        residual_orthogonal_component_norm=float(np.linalg.norm(r-projection*left)),
        gradient_norm=float(np.linalg.norm(matrix.T@r)),
        dominant_rows=[dict(reduced_row=int(k),original_row=int(free[k]),coefficient=float(left[k]),residual_Wm2=float(r[k])) for k in np.argsort(-abs(left))],
        dominant_coordinates=[dict(reduced_coordinate=int(k),original_coordinate=int(free[k]),cap_fraction=float(physical[k]/caps[k])) for k in np.argsort(-abs(physical/caps))],
        raw_U_projection_signs_not_gauged=u.T@r)


def units(x,detail,fixed,n):
    r=np.asarray(detail['solver_residual']);free=np.r_[np.arange(n),n+1]
    k=int(free[int(np.argmax(abs(r[free])))])
    out=dict(ground_constraint_K=float(r[n]),prescribed_ground_K=float(fixed),solution_ground_K=float(x[n]),
        ground_exact=exact(np.asarray(x[n]),np.asarray(float(fixed))),other11_max_abs_Wm2=float(abs(r[k])),other11_argmax_original_row=k,
        solver_r12_values=r.tolist(),solver_r12_units=['W/m2']*n+['K','W/m2'])
    if 'layer_residual' in detail:
        physical=np.asarray(detail['layer_residual']);row=int(np.argmax(abs(physical)))
        out['physical11']=dict(values_Wm2=physical.tolist(),max_abs_Wm2=float(abs(physical[row])),argmax_row=row)
    else:out['physical11']=dict(missing=True,reason='Original array not stored; no model replay.')
    return out


def main():
    p=argparse.ArgumentParser()
    for name in ('qr','pw'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert sys.dont_write_bytecode and np.__version__=='2.2.6' and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    output=args.output.resolve();assert output.is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not output.exists();output.mkdir()
    immutable={str(path):sha(path.read_bytes()) for path in (args.qr,args.pw,Path(__file__),Path(__file__).with_name('saved_qp_decoder.py'),Path(__file__).with_name('serialization_pt.py'))}
    report=dict(pbs_job=os.environ['PBS_JOBID'],analysis_completed=False,model_calls=0,evaluate_calls=0,new_Jacobian_computations=0,
        new_lambda_or_radius_or_trial_evaluations=0,source_or_gate_changes=False,nonlinear_minimum_or_physical_degeneracy_proved=False,
        original_QR_model_exit=1,original_QR_failure_preserved=True)
    start=time.monotonic();status=1
    try:
        qr=archive(args.qr,'f0459848984f75e7e9d66bbaffd6791bfb409e33bd61f296d501a2a9e3bc16cd')
        pw=archive(args.pw,'44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef')
        observed=unpack(qr,'probe/external-lm-trace-qr/observed')
        assert not observed['observer_errors'] and len(observed['calls'])==1
        events=observed['calls'][0]['events'];assert len(events)==382 and len(observed['nested_original_physical_calls'])==542
        refreshed={event['iteration']:event for event in events if event['anchor']=='J_scaling_normal_gradient_complete'}
        final=[event for event in events if event['event']=='return'][-1];values=final['locals'];n=values['n'];free=values['free'];caps=values['cap'][free]
        assert n==10 and free.tolist()==list(range(n))+[n+1]
        assert np.all(values['active']) and not np.any(values['phase_active'])
        fixed=values['fixed_ground_temperature'];rows=[]
        selected=[event for event in events if event['anchor']=='trial_and_displacement_complete']
        for event in selected:
            iteration=event['iteration'];v=event['locals'];ages=event['field_ages'];point=refreshed[ages['J_iteration']]['locals']
            assert ages['direction_iteration']==iteration
            for key in ('x','residual','jac','scale','scaled','normal','gradient'):
                assert exact(v[key],point[key]),'Point/age mismatch:'+key
            assert exact(v['scaled'],v['jac']*v['scale']) and v['jac'].shape==(11,11)
            assert exact(v['matrix'],v['normal']+v['damping']*np.eye(11))
            assert exact(v['displacement'],v['trial']-v['x'])
            assert exact(np.asarray(v['x'][n]),np.asarray(float(fixed))) and exact(np.asarray(v['trial'][n]),np.asarray(float(fixed)))
            r=v['residual'][free];jac=v['jac'];scaled=v['scaled'];scale=v['scale'];direction=v['direction'];displacement=v['displacement']
            assert np.all(np.isfinite(r)) and np.all(np.isfinite(jac)) and np.all(np.isfinite(direction))
            u,s,vh=np.linalg.svd(scaled,full_matrices=False);damping=float(v['damping'])
            # Same stored r, A and lambda only. No new trial or acceptance claim.
            p_svd=-(vh.T@((s/(s*s+damping))*(u.T@r)))
            direction_svd=np.zeros(n+2);direction_svd[free]=scale*p_svd
            p_saved_reconstructed=direction[free]/scale
            with np.errstate(over='ignore',divide='ignore',invalid='ignore'):
                ulps=abs(np.spacing(v['x']));step_ulps=abs(direction)/ulps;displacement_ulps=abs(displacement)/ulps
                comparison_ulps=abs(direction_svd-direction)/ulps
            linear_change=jac@displacement[free]
            stable_prediction=-2.*float(r@linear_change)-float(linear_change@linear_change)
            group=[e for e in events if e['iteration']==iteration]
            prediction=[e for e in group if e['anchor']=='linear_prediction_complete'];trial=[e for e in group if e['anchor']=='actual_reduction_and_ratio_complete']
            fresh_prediction=None;fresh_trial=None
            if prediction:
                assert len(prediction)==1 and prediction[0]['field_ages']['prediction_iteration']==iteration
                fresh_prediction=float(prediction[0]['locals']['predicted'])
            if trial:
                assert len(trial)==1 and trial[0]['field_ages']['trial_iteration']==iteration
                w=trial[0]['locals'];assert exact(w['x'],v['x']) and exact(w['residual'],v['residual'])
                fresh_trial=dict(original_actual=float(w['actual']),original_ratio=float(w['ratio']),
                    stable_actual=float((w['residual']-w['trial_residual'])@(w['residual']+w['trial_residual'])),
                    trial_residual=w['trial_residual'].copy())
            row=dict(iteration=iteration,J_age=ages['J_iteration'],direction_age=ages['direction_iteration'],original_lambda=damping,
                original_alpha=float(v['alpha']),x=v['x'].copy(),residual12=v['residual'].copy(),J=jac.copy(),scale=scale.copy(),
                direction=direction.copy(),actual_displacement=displacement.copy(),local_ULPs=ulps,
                direction_max_abs=float(np.max(abs(direction))),direction_max_local_ULPs=float(np.max(step_ulps)),
                nonzero_actual_displacement_components=int(np.count_nonzero(displacement)),
                actual_displacement_max_local_ULPs=float(np.max(displacement_ulps)),
                original_scaled_step_norm=float(np.linalg.norm(p_saved_reconstructed)),original_caps_radius_in_scaled_coordinates=float(np.linalg.norm(caps/scale)),
                original_scaled_gradient_norm=float(np.linalg.norm(v['gradient'])),
                recomputed_scaled_gradient_max_difference=float(np.max(abs(v['gradient']-scaled.T@r))),
                original_J=modes(jac,r,np.ones(11),caps,free),scaled_J=modes(scaled,r,scale,caps,free),
                stored_normal_eigenvalues=np.linalg.eigvalsh(v['normal']).tolist(),
                same_recorded_lambda_SVD_step_comparison=dict(direction=direction_svd,
                    max_abs_direction_difference=float(np.max(abs(direction_svd-direction))),max_direction_difference_in_state_ULPs=float(np.max(comparison_ulps)),
                    SVD_regularized_equation_residual_norm=float(np.linalg.norm(v['matrix']@p_svd+v['gradient'])),
                    saved_physical_step_reconstructed_regularized_equation_residual_norm=float(np.linalg.norm(v['matrix']@p_saved_reconstructed+v['gradient'])),
                    original_scaled_vector_scope='Reconstructed by dividing saved actual physical direction by saved scale; the original temporary scaled solve vector was not stored.',
                    proposed_direction_not_physically_evaluated=True),
                original_predicted_fresh=fresh_prediction,stable_prediction_for_actual_displacement=stable_prediction,
                actual_trial_fresh=fresh_trial,
                original_branch_anchors=[e['anchor'] for e in group if e['anchor'].startswith(('accept_','reject_'))])
            rows.append(row)
        assert len(rows)==36 and rows[-1]['iteration']==66
        last_point=refreshed[final['field_ages']['J_iteration']]['locals']
        for key in ('x','residual','jac','scale','scaled','gradient'):assert exact(values[key],last_point[key])
        assert exact(final['already_computed_detail']['solver_residual'],values['residual'])
        report.update(rows=rows,iterations_analyzed=len(rows),final_iteration=rows[-1],
            final_return_field_ages=final['field_ages'],final_units=units(values['x'],final['already_computed_detail'],fixed,n),
            last_return_prediction_and_trial_not_reused_as_iteration66=final['field_ages']['prediction_iteration']==65 and final['field_ages']['trial_iteration']==65)
        pw_results={}
        for seed in ('stalled_x','stored_ambient'):
            original=unpack(pw,'probe/diagnostic/'+seed+'-diagnostic');opt=original['optimizer_result']
            assert exact(opt['x'],original['last_attempted_x']) and exact(opt['fun'],original['original_detail']['solver_residual'])
            reduced=opt['jac'][np.ix_(free,free)];residual=opt['fun'][free]
            pw_results[seed]=dict(units=units(opt['x'],original['original_detail'],fixed,n),
                reduced_original_J=modes(reduced,residual,np.ones(11),caps,free),
                QR_minus_PW_max_coordinate_difference=float(np.max(abs(values['x']-opt['x']))),
                QR_minus_PW_max_free_difference_in_caps=float(np.max(abs(values['x'][free]-opt['x'][free])/caps)),
                own_original_optimizer_point_verified=True,
                original_ground_matches_prescribed=exact(np.asarray(opt['x'][n]),np.asarray(float(fixed))),
                Jacobian_scope='Original final PW optimizer J at its own saved x/fun; row/column10 removed algebraically only. Stalled PW point has off-root ground, not a new constrained derivative evaluation.',
                used_as_model_seed=False)
        report.update(PW_posthoc=pw_results,analysis_completed=True,
            interpretation_limits=[
                'Original full12 TRF/Newton/LM intermediate off-ground iterates are root-finding paths, not accepted physical model states. Final original12 residual gate still applies.',
                'Neither near-singular finite-difference J nor a small stored gradient proves a nonlinear local minimum or physical/derivative cause.',
                'SVD same-lambda algebra is not an evaluated trial or a successful trust-region solver.',
                'PW lacks accepted-path/radius/lambda/scaling history; QR lacks full per-point gas/uptake/limiter margins.'],
            original_error_message_bytes_changed=False)
        status=0
    except BaseException:report['exception']=traceback.format_exc()
    finally:
        report['immutable_before_after_exact']=all(sha(Path(name).read_bytes())==digest for name,digest in immutable.items())
        if not report['immutable_before_after_exact']:status=1
        report.update(actual_analysis_exit=status,seconds=time.monotonic()-start)
        dump_return(output/'analysis',report)
    return status


if __name__=='__main__':sys.exit(main())

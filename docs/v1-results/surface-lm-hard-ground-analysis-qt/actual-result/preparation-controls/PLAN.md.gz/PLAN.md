# Existing hard-ground QR path diagnosis — prepared only

QR1870 remains originalF1/Stageout0,47/48, with542 original evaluate calls and no observer errors. Every physical-call input and trial retained the exact prescribed Tf, all free-index/J-shape checks succeeded, and the other ambient seed coordinates were unchanged. Its remaining failure at total66/80 is therefore preserved; hard ground elimination alone is not a repair. The source is private and unpromoted.

The proposed next computation is one1CPU/2GiB/5min EHPC PBS pure-algebra analysis. It does not import or call a model, recompute a Jacobian, evaluate gas/limiter formulas, run a reference solver, change a seed or create a new physical candidate. Root reads the worker before authorizing that new job.

Bind the exact QR raw result `f0459848984f75e7e9d66bbaffd6791bfb409e33bd61f296d501a2a9e3bc16cd`, PW raw `44fdf25ef9b29b364989b41e786424cade9ef78bab0553cfb38fff212eba46ef`, and prior QP/unit evidence by hash. Read only lossless saved typed packets. The full state/residual has12 entries; the current QR linear matrix and scale have11, with free indices0–9 and11. Select every actual J-refresh and direction event using its original iteration ages, requiring byte-exact x/residual/J/scale/gradient consistency. Full12 ground residual is reported separately inK; the other11 equations and saved physical11 are reported inW/m2.

For each recorded direction, report the current original lambda, caps/common alpha, actually representable displacement, original/stable predicted and actual decrease where fresh, residual/gradient norm, SVD spectrum/weak left/right directions of the existing11×11 J and JS, residual projections, and component steps inULPs. Last no-movement evidence is read from its actual defining event, without stale prediction/trial values. Point closeness or small gradient must not be called a nonlinear local minimum.

To isolate arithmetic at a **fixed recorded subproblem**, optionally compare the original saved Cholesky direction with the SVD solution of exactly the same existing JS/r/lambda:

\[
p=-V\,\mathrm{diag}\!\left(\frac{\sigma}{\sigma^2+\lambda}\right)U^Tr_{free},\qquad d_{free}=S p,\quad d_{ground}=0.
\]

This uses no new lambda, radius, seed or physical trial. Report algebraic direction and linear-system residual differences only; do not infer that the alternative would be accepted or converge. Normal-equation roundoff must be demonstrated on its own recorded subproblem rather than attributed from condition number alone. The stored normal matrix may be inspected for lost small modes, but no new physical Jacobian is constructed.

At PW's own stored final root and stalled outcomes, remove the prescribed-ground row/column from its already-saved optimizer Jacobian and retain its own matching x/fun. Compare spectra/mode projections and point distances explicitly as different-point diagnostics. PW evaluation records still lack accepted-step/radius/lambda/scale histories; no exact first accepted-path divergence can be invented. The saved PW root stays posthoc and is never used as a model seed.

Original QR full gas, transpiration/uptake and limiter-margin histories were not saved by the observer, so those remain unavailable. QP's same-input exchange/supply constants can be cited as already captured context; they do not establish the active limiter or derivative source at every new QR point. Neither a near-singular recorded finite-difference matrix nor its weak mode alone proves physical degeneracy or numerical-derivative error.

The analysis returns raw pickle before lossless typed JSON/NPZ, explicit nonfinite tags, before/after hashes and actual child/PBS exits. A diagnostic failure is preserved without re-running a model or silently extending the analysis. A production trust-region design, SVD implementation, new root tolerance, parameter change or model validation still requires a separate concrete review and authorization.

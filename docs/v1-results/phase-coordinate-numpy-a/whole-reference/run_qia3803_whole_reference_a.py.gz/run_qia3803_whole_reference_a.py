from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-whole-reference-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'phase-coordinate-native-a-source.tar.gz';assert sha(a)=='a459efb718fbad46e397873d3326f74eca22b11749ea221eb8657438f6295aef'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==563 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
import test_gpu_clm_bgc_column as bgc
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
from run_fluxnet_column import audit_step
binding=json.loads((r/'binding.json').read_text());assert sha(r/'input.npz')==binding['input_sha256']
with np.load(r/'input.npz',allow_pickle=False) as z:data=dict(z)
arrays=[data['a'+str(k)].copy() for k in range(19)];arrays[4][:,7:10]=data['environment'];captured={};original=bgc.step_clm_enthalpy_column
def observe(state,forcing,**controls):
    after,d=original(state,forcing,**controls);_,residual,bound=audit_step(state,after,forcing,d,float(data['nitrogen'][0]));captured.update(before=state,after=after,forcing=forcing,diagnostics=d,residual=residual,bound=bound);return after,d
bgc.step_clm_enthalpy_column=observe;start=time.monotonic()
try:full=bgc.reference(tuple(v[0] for v in arrays[:16]),data['forcing'][0],data['deposition'][0],data['calendar_values'][0],data['calendar_flags'][0],float(data['nitrogen'][0]),1.,canopy_structure=tuple(v[0] for v in arrays[16:]),most_geometry=MOSTGeometry(*data['geometry'][0].astype(float)),leaf_parameters=LeafParameters(**binding['leaf_parameters']))
finally:bgc.step_clm_enthalpy_column=original
assert np.all(abs(captured['residual'])<=captured['bound'])
np.savez_compressed(r/'full-reference.npz',**{k:np.asarray(full['diagnostics'][k]) for k in ['h','le','gpp_gc_m2','nee_gc_m2']},tsoil_k=full['soil_temperature'],smc_m3m3=full['soil_cells'][:,0]/(1000.*full['soil_cells'][:,2]))
(r/'full-reference-state.pkl').write_bytes(pickle.dumps(captured));assert all(sha(s/n)==h for n,h in m.items())
d=dict(scope='563-coordinate-A NumPy reference of exact original519H3803 whole19-state including structure/MOST/CN; oldstores/input/leafparameters and hardMHCN unchanged. Existing dataclass normalization of quantizedrootweights disclosed. Independent reference only, no failed-year advance or GPU/fullscience pass.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,input_sha256=sha(r/'input.npz'),full_original_MHCN_residual=captured['residual'].tolist(),full_original_MHCN_bound=captured['bound'].tolist(),full_reference_sha256=sha(r/'full-reference.npz'))
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

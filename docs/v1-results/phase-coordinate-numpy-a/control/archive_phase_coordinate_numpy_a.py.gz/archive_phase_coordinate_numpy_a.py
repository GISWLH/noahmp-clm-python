from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=b/'phase-coordinate-cpu-a';d=json.loads((r/'target-receipt.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=5,failures=0,errors=0,skipped=0) and sha(r/'target.xml')==d['xml_sha256']
q=b/'qia3803-whole-reference-a';ref=json.loads((q/'receipt.json').read_text());assert (q/'pbs-exit.txt').read_text().strip()=='0' and ref['source_unchanged'] and sha(q/'full-reference.npz')==ref['full_reference_sha256'] and ref['source_manifest_sha256']==d['source_manifest_sha256']
a=b/'phase-coordinate-numpy-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n in ['dispatch.json','SOURCE_SHA256.json','package.json','node.txt','run_phase_coordinate_cpu_a.py','phase_coordinate_cpu_a.pbs','target.log','target.xml','target-receipt.json']:t.add(r/n,arcname='target5/'+n,recursive=False)
    for p in sorted(q.rglob('*')):
        if p.is_file():t.add(p,arcname='whole-reference/'+p.relative_to(q).as_posix(),recursive=False)
    for n in ['phase-coordinate-native-a-source.tar.gz','phase-coordinate-native-a-package.json','dispatch_phase_coordinate_cpu_a.py','dispatch_qia3803_whole_reference_a.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

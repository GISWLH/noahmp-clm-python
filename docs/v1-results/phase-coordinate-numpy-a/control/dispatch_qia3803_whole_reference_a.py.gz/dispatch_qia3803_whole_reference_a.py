from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-whole-reference-a';assert not r.exists();r.mkdir();controls={}
for n in ['run_qia3803_whole_reference_a.py','qia3803_whole_reference_a.pbs']:
    raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=hashlib.sha256(raw).hexdigest()
for src,dst in [('qia3803-original-input.npz','input.npz'),('qia3803-original-binding.json','binding.json')]:
    raw=(b/src).read_bytes();(r/dst).write_bytes(raw);controls[src]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'qia3803_whole_reference_a.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
d=dict(pbs_job=p.stdout.strip(),controls_sha256=controls);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
assert all(sha(root/n)==v for n,v in manifest.items())
files=sorted(str(p) for p in Path('tests').glob('test_*most*.py') if not p.name.startswith('test_gpu'))
(root/'most-target-selection.json').write_text(json.dumps(dict(files=files),indent=2)+'\n')
begun=time.monotonic()
code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml=most-target.xml']).returncode
assert all(sha(root/n)==v for n,v in manifest.items())
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'most-target.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
(root/'most-target-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun,counts=counts,source_files=len(manifest),source_unchanged=True,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename),indent=2)+'\n')
assert code==0 and all(counts[k]==0 for k in ['failures','errors','skipped'])

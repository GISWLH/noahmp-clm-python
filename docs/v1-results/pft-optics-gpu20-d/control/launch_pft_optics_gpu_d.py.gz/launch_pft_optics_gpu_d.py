from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-d';assert not s.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'pft-optics-final-d-source.tar.gz';package=json.loads((b/'pft-optics-final-d-package.json').read_text());assert sha(a)==package['archive_sha256']=='6e844fa6f6c573b51a5241b6b76a26564c9249d9716604070d718e9c083a4c63'
cpu=b/'pft-optics-cpu-final-b-evidence.tar.gz';assert cpu.exists()
with tarfile.open(cpu) as t:
    rec=json.load(t.extractfile('receipt.json'));m=json.load(t.extractfile('SOURCE_SHA256.json'))
    assert t.extractfile('pbs-exit.txt').read().strip()==b'0' and rec['counts']==dict(tests=940,failures=0,errors=0,skipped=0) and rec['returncode']==0 and rec['source_unchanged']
probe=json.loads((b/'pft-optics-order-probe-d/receipt.json').read_text());assert probe['failure'] is None and probe['source_unchanged'] and probe['candidate_sha256']=='77e9a939780b8bb7a542a2cb67d82ea0a436b547b143f5428baa2db892eaa727'
free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip());assert free>6144
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());assert int(mem['MemAvailable'].split()[0])>12*1024*1024
s.mkdir()
with tarfile.open(a) as t:t.extractall(s,filter='data')
current=json.loads((s/'SOURCE_SHA256.json').read_text());assert set(n for n,h in current.items() if m.get(n)!=h)=={'tests/test_gpu_canopy_optics.py','src/noahmp_clm/gpu/cuda/radiation_kernel.cu'} and all(sha(s/n)==h for n,h in current.items());r=s/'targets-d';r.mkdir()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
controls={n:sha(b/n) for n in ['launch_pft_optics_gpu_d.py','control_pft_optics_gpu_d.py','collect_pft_optics_gpu_d.py']}
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_pft_optics_gpu_d.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d=dict(scope='Frozen518D CUDAorder correction verified by isolated allfive originaltestfunctions, GPUhostnoNumPyphysics; after actual B EHPC940: allNumPy/nonCUDA runtime/CPUtests/fixture byteidentical verified. D full940 also scheduled for canonical exactsource. Actual collect1291/targets20 all624 raw1e-6/ints/science/hardgates; no oldA credit/full/year/science acceptance. Original A BGC and old506 models left running.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,device=0,free_memory_mib=free,source_archive_sha256=sha(a),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),cpu_archive_sha256=sha(cpu),controls_sha256=controls)
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

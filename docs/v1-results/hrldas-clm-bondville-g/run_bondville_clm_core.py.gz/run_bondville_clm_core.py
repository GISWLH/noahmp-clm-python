"""CLM core cold-start comparison execution using official generated forcing.
No heldout calibration. Scoring is a separate, time-aligned read-only step.
"""
import argparse
from dataclasses import asdict
from datetime import datetime,timedelta
import hashlib,json,time,traceback,pickle
from pathlib import Path
import numpy as np
from scipy.io import netcdf_file
from noahmp_clm.column import ColumnState,SoilParams,Forcing
from noahmp_clm.clm_state import CLMColumnState,clm_options
from noahmp_clm.clm_enthalpy_driver import step_clm_enthalpy_column
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.physics.photosynthesis import LeafParameters
from fluxnet_solar import solar_geometry

parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
units={'T2D':'K','Q2D':'kg/kg','PSFC':'Pa','U2D':'m/s','V2D':'m/s','LWDOWN':'W/m2','SWDOWN':'W/m2','RAINRATE':'mm/s'}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source={str(p).replace('\\','/'):sha(p) for p in sorted(Path('src/noahmp_clm').rglob('*.py'))}
setup=args.directory/'forcing/hrldas_setup_single_point.nc'
with netcdf_file(setup,mmap=False) as nc:
 initial={k:np.asarray(v.data,dtype=float).ravel().copy() for k,v in nc.variables.items()}
v=lambda name:float(initial[name][0])
soil=SoilParams(name='STAS-8-silty-clay-loam',smcmax=.464,smcwlt=.120,smcref=.387,satdk=2.03e-6,bexp=8.72,quartz=.1)
old=ColumnState(soil=soil,dz=initial['DZS'],tsoil=initial['TSLB'],smc=initial['SMOIS'],ts=v('TSK'),
 swe=v('SNOW')/1000.,snow_t=v('TSK'),snow_density_layers=np.array([v('SNOW')/v('SNODEP')]),
 canw=0.,lai=v('LAI'),fveg=v('SHDMAX')/100.,z0m=.15,options=clm_options(),root_frac=np.array([.1,.3,.6,0.]))
state=CLMColumnState.from_column(old,options=old.options).with_layered_canopy()
geometry=MOSTGeometry(wind_height=10.,temperature_height=10.,humidity_height=10.,displacement=2.*2./3.,
                     momentum_roughness=.15,heat_roughness=.015,water_roughness=.015)
leaf=LeafParameters(vcmax25=80.,respiration25=1.,minimum_conductance=.002,ball_berry_slope=9.)
report={'scope':'Bondville CLM core cold-start versus official fixed-LAI profile C; NOT station validation',
 'source_sha256':source,'instrument_sha256':sha(__file__),'setup_sha256':sha(setup),'initial_state':asdict(state),
 'leaf_parameters':asdict(leaf),'most_geometry':asdict(geometry),'forcing_sha256':{},'intervals':[],
 'initialization_notes':[
 'Official generated float32 meteorology is read exactly at interval right endpoints, as upstream READFORC_HRLDAS does at equal forcing/model dt.',
 'Both columns use the same 4 soil layer depths, total water, temperatures, snow mass/depth/temperature, LAI=2 and vegetation cover=0.96.',
 'Canopy storage zero matches official initialized CANLIQ/CANICE, not unused setup CANWAT.',
 'Upper three layers have uniform root density by layer thickness (Noah-MP MODIS-12 NROOT=3).',
 'Soil STAS-8 table values; leaf Vcmax25=80/Rd25=1/g0=0.002/slope9 from official MODIS-12. CLM Jmax/TPU/optical and temperature response defaults remain.',
 'Official and Python use insulated bottom and explicit input LAI. Official BATS versus Python SNICAR snow optics; official SAI=0.2 absent in Python.',
 'MOST heights 10m match official ZLVL; Python d=2/3 height and thermal roughness=0.1 z0m are provisional, not exact official aerodynamics.',
 'Official direct/diffuse fractions 0.7/0.3 and CO2=395 ppm used explicitly. NOAA solar geometry at interval right endpoint, UTC, differs slightly from upstream CALC_DECLIN.',
 'No BGC/spinup/crop management; bare-soil spectral albedo and canopy leaf optical constants remain CLM defaults.'],
 'status':'running','steps_completed':0}
initial_state=state;net=np.zeros(2);bounds=np.zeros(2);maximum=np.zeros(2);stepmax=np.zeros(2);started=time.perf_counter()
def encode(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 raise TypeError(type(x).__name__)
def save(status):
 report.update(status=status,seconds=time.perf_counter()-started,maximum_cumulative_residual_m_h=maximum,
  maximum_step_residual_m_h=stepmax,cumulative_numerical_bounds_m_h=bounds)
 args.output.write_text(json.dumps(report,indent=2,default=encode,allow_nan=False)+'\n',encoding='utf-8')
save('running')
for index in range(48):
 end=datetime(1998,1,2)+timedelta(seconds=(index+1)*1800)
 path=args.directory/'forcing'/(end.strftime('%Y%m%d%H%M')+'.LDASIN_DOMAIN1')
 raw={}
 with netcdf_file(path,mmap=False) as nc:
  for key,u in units.items():
   var=nc.variables[key];assert var.units.decode()==u and var.data.size==1
   raw[key]=float(var.data.ravel()[0]);assert np.isfinite(raw[key])
 report['forcing_sha256'][path.name]=sha(path)
 f=Forcing(1800.,raw['T2D'],raw['Q2D'],np.hypot(raw['U2D'],raw['V2D']),raw['PSFC'],raw['SWDOWN'],raw['LWDOWN'],raw['RAINRATE']/1000.)
 mu=max(.001,solar_geometry(end,v('XLAT'),v('XLONG'),0)['cosine_zenith'])
 try:
  after,d=step_clm_enthalpy_column(state,f,co2_ppm=395.,cosine_zenith=mu,diffuse_fraction=.3,leaf_parameters=leaf,most_geometry=geometry)
  inputs=np.array([f.prcp*f.dt*1000.-d['et_mm']-d['runoff_mm'],d['precipitation_enthalpy_jm2']+
   (f.swdown+f.lwdown-d['outgoing_shortwave']-d['outgoing_longwave']-d['h']-d['le'])*f.dt-d['advected_enthalpy_jm2']-d['runoff_enthalpy_jm2']])
  totals=lambda s:np.array([s.water_kgm2,s.enthalpy_jm2]);residual=totals(after)-totals(state)-inputs
  eps=np.finfo(float).eps
  mb=32*eps*max(state.water_kgm2+after.water_kgm2+f.prcp*f.dt*1000.+abs(d['et_mm'])+d['runoff_mm'],1.)
  storage=sum(float(abs(a).sum()) for s in (state,after) for a in (s.ground.enthalpy,s.snow.enthalpy,s.canopy_condensate.enthalpy))
  hb=float(np.sum(d['thermal']['convergence_tolerance_jm2']))+f.dt*float(np.sum(abs(d['layer_residual'])))
  hb+=32*eps*max(storage+abs(d['precipitation_enthalpy_jm2'])+abs(d['atmospheric_energy_jm2'])+abs(d['advected_enthalpy_jm2'])+abs(d['runoff_enthalpy_jm2']),1.)+1e-5
  bound=np.array([mb,hb]);assert np.all(abs(residual)<=bound),(residual,bound)
  net+=inputs;bounds+=bound;cumulative=totals(after)-totals(initial_state)-net
  assert np.all(abs(cumulative)<=bounds),(cumulative,bounds)
  maximum=np.maximum(maximum,abs(cumulative));stepmax=np.maximum(stepmax,abs(residual))
  report['intervals'].append({'time_start':(end-timedelta(seconds=1800)).isoformat(),'time_end':end.isoformat(),
   'et_mm':d['et_mm'],'h_wm2':d['h'],'le_wm2':d['le'],'runoff_mm':d['runoff_mm'],
   'soil_temperature_k':after.tsoil,'soil_total_water_m3m3':after.smc,'swe_mm':after.swe*1000.,
   'independent_residual_m_h':residual,'numerical_bound_m_h':bound,'forcing':asdict(f),'cosine_zenith':mu})
  state=after;report['steps_completed']=index+1
  if (index+1)%12==0:
   save('running');print(json.dumps({'steps':index+1,'max_cumulative':maximum.tolist(),'seconds':time.perf_counter()-started}),flush=True)
 except Exception:
  report['failure']=traceback.format_exc();report['failed_index']=index
  args.output.with_suffix('.failure.pkl').write_bytes(pickle.dumps((state,f,geometry,mu,leaf)))
  save('failed');raise
assert source=={str(p).replace('\\','/'):sha(p) for p in sorted(Path('src/noahmp_clm').rglob('*.py'))}
report['source_unchanged']=True;report['final_state']=asdict(state);save('complete')
print(json.dumps({'status':'complete','steps':48,'seconds':time.perf_counter()-started}),flush=True)

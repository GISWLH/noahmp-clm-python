from pathlib import Path,PurePosixPath
import hashlib,json,os,tarfile
import numpy as np
from noahmp_clm.validation import compare_series
assert os.environ.get('PBS_JOBID')
base=Path('/home/zhangyq/noahmp-v1');root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=base/'first-climate-week-g-prefix-evidence.tar.gz'
assert sha(archive)=='0aa61126f234489d4f6b2a0ed44f2fecacf1eed3b34667ddd9be60820315debe'
native=root/'original-g';native.mkdir(exist_ok=False)
with tarfile.open(archive) as t:
    for m in t:
        p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
        out=native/m.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(m).read())
rows=[];failures=[]
for site in ['CN-Cng','CN-Qia','CN-Cha','CN-HaM']:
    case=site+'-initial-climate-cycle';folders=[native/case,base/'fluxnet-first-climate-cycle-20261017-f/numpy-day'/case]
    paths=[next(folders[0].glob('report-0000336-*.json')),folders[1]/'report.json']
    reports=[json.loads(p.read_text()) for p in paths]
    assert all(r['status']=='running' and r['steps_requested']==17520 and r['steps_completed']==336 and r['source_unchanged'] for r in reports)
    for name in ['forcing_npz_sha256','forcing_manifest_sha256','configuration_sha256']:assert reports[0][name]==reports[1][name]
    sources=[{k:v for k,v in r['source_sha256'].items() if k.startswith('src/')} for r in reports]
    assert sources[0].keys()==sources[1].keys()
    diffs={k:[sources[0][k],sources[1][k]] for k in sources[0] if sources[0][k]!=sources[1][k]}
    assert set(diffs)=={'src/noahmp_clm/gpu/column_heat.py'},diffs
    for directory,source in zip([base/'p6-heat-phase-event-a',base/'p6-heat-coordinate-d'],sources):
        assert all(sha(directory/k)==v for k,v in source.items())
    traces=[folder/r['model_npz'] for folder,r in zip(folders,reports)]
    for p,r in zip(traces,reports):assert sha(p)==r['model_npz_sha256']
    data=[]
    for p in traces:
        with np.load(p,allow_pickle=False) as z:data.append(dict(z))
    a,b=data
    for k in ['time_start','time_end']:np.testing.assert_array_equal(a[k],b[k]);assert len(a[k])==336
    for trace in data:
        assert np.all(abs(trace['step_residual_m_h_c_n'])<=trace['step_bound_m_h_c_n'])
    metrics={}
    for key,var,factor,offset in [('h_wm2','h_wm2',1.,0.),('le_wm2','le_wm2',1.,0.),('et_mm','et_mm_day',48.,0.),('runoff_mm','runoff_mm_day',48.,0.),('gpp_gc_m2','gpp_gc_day',48.,0.),('nee_gc_m2','nee_gc_day',48.,0.),('swe_m','swe_m',1.,0.),('tsoil_k','tsoil_c',1.,-273.15),('smc_m3m3','smc',1.,0.),('liquid_m3m3','smc',1.,0.)]:
        x,y=(np.asarray(d[key],float)*factor+offset for d in data)
        if x.ndim==1:x=x[:,None];y=y[:,None]
        instant=[compare_series(x[:,j],y[:,j],var) for j in range(x.shape[1])]
        daily=[[compare_series(x[d*48:(d+1)*48,j],y[d*48:(d+1)*48,j],var) for j in range(x.shape[1])] for d in range(7)]
        for d,values in enumerate(daily):
            for j,value in enumerate(values):
                if not value['bias_pass']:failures.append([site,key,d,j,'bias',value['bias']])
        if key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2']:
            for j,value in enumerate(instant):
                if value['correlation_pass'] is False:failures.append([site,key,j,'r',value['r']])
        metrics[key]=dict(instantaneous=instant,daily=daily)
    rows.append(dict(site=site,steps_each=336,original_status='running',original_steps_requested=17520,
        source_differences=diffs,matched_runtime_files=len(sources[0])-len(diffs),
        reports_sha256=[sha(p) for p in paths],traces_sha256=[sha(p) for p in traces],metrics=metrics))
result=dict(scope='Historical physical source: original G336 CUDA32 versus independent EHPC PBS26 NumPy336. Disclosed GPU heat source difference only; no new suction physics, annual, spinup or observation acceptance.',cases=rows,failures=failures,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,instrument_sha256=sha(Path(__file__)))
(root/'comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
for key in rows[0]['metrics']:
    day=[v for r in rows for values in r['metrics'][key]['daily'] for v in values]
    print(key,dict(max_daily_absolute_bias=max(v['absolute_bias'] for v in day),max_daily_relative_percent=max([100*abs(v['relative_bias']) for v in day if v['relative_bias'] is not None],default=None)),flush=True)
print('failures',failures,flush=True)
assert not failures,failures

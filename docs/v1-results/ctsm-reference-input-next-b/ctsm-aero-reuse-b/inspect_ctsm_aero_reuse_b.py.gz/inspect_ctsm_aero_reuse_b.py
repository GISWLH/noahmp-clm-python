from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time,urllib.request,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-aero-reuse-b';scratch=Path(os.environ['TMPDIR']).resolve()/'inspection';scratch.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic()
archive=b/'ctsm-portable-env-b.tar.gz';assert sha(archive)=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
prefix=scratch/'environment';prefix.mkdir()
with tarfile.open(archive) as t:t.extractall(prefix,filter='data')
env=os.environ.copy()
for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
stages=[]
def run(name,command,timeout=60):
 start=time.monotonic();p=subprocess.run(command,cwd=r,env=env,capture_output=True,text=True,timeout=timeout);(r/(name+'.stdout.txt')).write_text(p.stdout);(r/(name+'.stderr.txt')).write_text(p.stderr);stages.append(dict(stage=name,returncode=p.returncode,seconds=time.monotonic()-start));return p
assert run('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]).returncode==0
run('nc-config',[str(prefix/'bin/nc-config'),'--all'])
upstream=b/'ctsm-forcing-contract-a/selected-upstream/CTSM/cime/src/components/data_comps/datm/cime_config/namelist_definition_datm.xml';tree=ET.parse(upstream);mapping=[];contract=[]
for entry in tree.getroot().iter('entry'):
 for value in entry.iter('value'):
  stream=value.get('stream')
  if stream in ['presaero','presaero.clim_2000']:
   if stream=='presaero' and entry.get('id')=='strm_datvar':mapping=[line.split() for line in (value.text or '').splitlines() if line.strip()]
   contract.append(dict(entry=entry.get('id'),attrs=value.attrib,text=(value.text or '').strip()))
assert len(mapping)==14
payload=dict(mapping=mapping,contract=contract,upstream_xml_sha256=sha(upstream),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename)
(r/'contract.json').write_text(json.dumps(payload,indent=2)+'\n')
script='''from pathlib import Path
import hashlib,json
import numpy as np
from netCDF4 import Dataset
r=Path.cwd();source=r/'aerosoldep_monthly_2000_mean_1.9x2.5_c090421.nc'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='2e920f2558685c790e904185bd3a9150435f31e3dca2d2ebb1aa1f6b60ae61ff'
contract=json.loads((r/'contract.json').read_text());rows=[]
with Dataset(source) as d:
 for name,target in contract['mapping']:
  v=d.variables[name];a=np.asarray(v[:],float);assert a.shape==(12,96,144) and np.isfinite(a).all() and (a>=0).all() and v.units=='kg/m2/s'
  rows.append(dict(source_field=name,datm_field=target,shape=list(a.shape),units=v.units,minimum=float(a.min()),maximum=float(a.max())))
 time=d.variables['time'];date=d.variables['date']
 record=dict(scope='Actual original climate file data/units/time versus pinned DATM14 field contract, no interpolation/model execution or runnable-case acceptance. Original file has no area/mask domain fields; an explicitly valid common domain/stream is still required. Filename/date2000 versus case/history1850 discrepancy retained.',fields=rows,time=dict(units=getattr(time,'units',None),calendar=getattr(time,'calendar',None),values=np.asarray(time[:]).tolist(),date=np.asarray(date[:]).tolist()),domain_variables={name:name in d.variables for name in ['lat','lon','area','mask']},global_case=getattr(d,'case',None),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_bytes=source.stat().st_size)
(r/'climate-file.json').write_text(json.dumps(record,indent=2)+'\\n');print(json.dumps(dict(fields=len(rows),shape=rows[0]['shape'],missing_domain_fields=[k for k,v in record['domain_variables'].items() if not v])))
'''
(r/'inspect_climate.py').write_text(script);assert run('inspect-climate',[str(prefix/'bin/python'),str(r/'inspect_climate.py')]).returncode==0
heads=json.loads((r/'original-heads.json').read_text());ranges=[]
for row in heads['results']:
 if not any(key in row['path'] for key in ['aerosoldep_WACCM','urbanparams']):continue
 result=dict(path=row['path'],url=row['url'])
 try:
  request=urllib.request.Request(row['url'],headers={'Range':'bytes=0-511'})
  with urllib.request.urlopen(request,timeout=15) as response:
   raw=response.read(512);result.update(status=response.status,content_range=response.headers.get('Content-Range'),accept_ranges=response.headers.get('Accept-Ranges'),etag=response.headers.get('ETag'),bytes_read=len(raw),magic_hex=raw[:8].hex(),sample_sha256=hashlib.sha256(raw).hexdigest())
  result['range_supported']=result['status']==206 and result['content_range'] is not None
 except Exception as e:result.update(range_supported=False,error=type(e).__name__+': '+str(e))
 ranges.append(result)
(r/'http-ranges.json').write_text(json.dumps(dict(scope='Bounded first512-byte HTTP preflight only, no full file/NetCDF validation.',results=ranges),indent=2)+'\n')
record=dict(scope='EHPC preparation only: actual climate14 fields/units and missing domain fields checked; fixed upstream original, environment inspected, large-file header reads bounded512B. No CTSM model output, matched surface/domain or scientific acceptance.',stages=stages,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-begun,original_climate_file_unchanged=sha(r/'aerosoldep_monthly_2000_mean_1.9x2.5_c090421.nc')=='2e920f2558685c790e904185bd3a9150435f31e3dca2d2ebb1aa1f6b60ae61ff')
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

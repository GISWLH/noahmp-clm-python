from pathlib import Path
import hashlib,json
import numpy as np
from netCDF4 import Dataset
r=Path.cwd();source=r/'aerosoldep_monthly_2000_mean_1.9x2.5_c090421.nc'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='2e920f2558685c790e904185bd3a9150435f31e3dca2d2ebb1aa1f6b60ae61ff'
contract=json.loads((r/'contract.json').read_text());rows=[]
with Dataset(source) as d:
 for name,target in contract['mapping']:
  v=d.variables[name];a=np.asarray(v[:],float);assert a.shape==(12,96,144) and np.isfinite(a).all() and (a>=0).all() and v.units=='kg/m2/s'
  rows.append(dict(source_field=name,datm_field=target,shape=list(a.shape),units=v.units,minimum=float(a.min()),maximum=float(a.max())))
 time=d.variables['time'];date=d.variables['date']
 record=dict(scope='Actual original climate file data/units/time versus pinned DATM14 field contract, no interpolation/model execution or runnable-case acceptance. Original file has no area/mask domain fields; an explicitly valid common domain/stream is still required. Filename/date2000 versus case/history1850 discrepancy retained.',fields=rows,time=dict(units=getattr(time,'units',None),calendar=getattr(time,'calendar',None),values=np.asarray(time[:]).tolist(),date=np.asarray(date[:]).tolist()),domain_variables={name:name in d.variables for name in ['lat','lon','area','mask']},global_case=getattr(d,'case',None),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_bytes=source.stat().st_size)
(r/'climate-file.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(fields=len(rows),shape=rows[0]['shape'],missing_domain_fields=[k for k,v in record['domain_variables'].items() if not v])))

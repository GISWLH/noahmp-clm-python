from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-global-surface-a';scratch=Path(os.environ['TMPDIR']).resolve()/'surface-inspection';scratch.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic()
fetch=json.loads((r/'fetch.json').read_text());selection=json.loads((r/'selection.json').read_text());assert fetch['download_complete'] and fetch['failure'] is None and fetch['path'] in {row['path'] for row in selection['matching_entries']}
data=r/fetch['file'];assert data.stat().st_size==fetch['bytes']==123325700 and sha(data)==fetch['file_sha256']
prefix=scratch/'environment';prefix.mkdir();archive=b/'ctsm-portable-env-b.tar.gz';assert sha(archive)=='6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20'
with tarfile.open(archive) as t:t.extractall(prefix,filter='data')
env=os.environ.copy()
for key in ['PYTHONPATH','LD_LIBRARY_PATH','PYTHONHOME']:env.pop(key,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
script='''from pathlib import Path
import hashlib,json
import numpy as np
from netCDF4 import Dataset
r=Path.cwd();fetch=json.loads((r/'fetch.json').read_text());records=json.loads((r/'site-mapping.json').read_text())['sites'];rows=[]
selected_names=['LATIXY','LONGXY','AREA','LANDFRAC_PFT','PCT_NATVEG','PCT_NAT_PFT','PCT_CROP','PCT_URBAN','PCT_LAKE','PCT_WETLAND','PCT_GLACIER','PCT_SAND','PCT_CLAY','ORGANIC','SOIL_COLOR','MONTHLY_LAI','MONTHLY_SAI','MONTHLY_HEIGHT_TOP','MONTHLY_HEIGHT_BOT']
with Dataset(r/fetch['file']) as d:
 latxy=d.variables['LATIXY'];lonxy=d.variables['LONGXY'];assert len(latxy.dimensions)==2 and lonxy.dimensions==latxy.dimensions
 latdim,londim=latxy.dimensions;latitude=np.asarray(latxy[:,0],float);longitude=np.asarray(lonxy[0,:],float)
 np.testing.assert_array_equal(latxy[:],np.broadcast_to(latitude[:,None],latxy.shape));np.testing.assert_array_equal(lonxy[:],np.broadcast_to(longitude[None,:],lonxy.shape));assert np.all(np.diff(latitude)>0) and np.all(np.diff(longitude)>0)
 for saved in records:
  path=r/(saved['site']+'.json');assert hashlib.sha256(path.read_bytes()).hexdigest()==saved['sha256'];site=json.loads(path.read_text());y,x=site['latitude'],site['longitude']%360
  i,j=int(np.searchsorted(latitude,y)-1),int(np.searchsorted(longitude,x)-1);assert 0<=i<len(latitude)-1 and 0<=j<len(longitude)-1
  fy=(y-latitude[i])/(latitude[i+1]-latitude[i]);fx=(x-longitude[j])/(longitude[j+1]-longitude[j]);weights=[(1-fy)*(1-fx),(1-fy)*fx,fy*(1-fx),fy*fx];assert abs(sum(weights)-1)<1e-14
  nodes=[]
  for (ii,jj),weight in zip([(i,j),(i,j+1),(i+1,j),(i+1,j+1)],weights):
   values={}
   for name in selected_names:
    if name not in d.variables:continue
    v=d.variables[name]
    if latdim not in v.dimensions or londim not in v.dimensions:continue
    index=tuple(ii if dim==latdim else jj if dim==londim else slice(None) for dim in v.dimensions)
    values[name]=dict(dimensions=[dim for dim in v.dimensions if dim not in [latdim,londim]],units=getattr(v,'units',None),values=np.ma.asarray(v[index]).tolist())
   nodes.append(dict(latitude=float(latitude[ii]),longitude=float(longitude[jj]),weight=float(weight),values=values))
  rows.append(dict(site=site['site'],latitude=y,longitude=x,original_site_record_sha256=saved['sha256'],nodes=nodes))
 schema=dict(dimensions={k:len(v) for k,v in d.dimensions.items()},variables={k:dict(dimensions=list(v.dimensions),dtype=str(v.dtype),units=getattr(v,'units',None)) for k,v in d.variables.items()})
record=dict(scope='Actual pinned CLM5 official global surface NetCDF metadata and original four-neighbor physical fields at locked four station coordinates. Bilinear geometric weights only; categorical PFT/landunits/soil/LAI not silently averaged/adopted. This is not a matched point dataset, model run or scientific acceptance.',schema=schema,sites=rows,source_sha256=fetch['file_sha256'],source_url=fetch['url'])
(r/'point-inspection.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\\n');print(json.dumps(dict(sites=len(rows),grid=[len(latitude),len(longitude)],fields_per_node=[len(v['nodes'][0]['values']) for v in rows])))
'''
(r/'inspect_points.py').write_text(script);stages=[]
for stage,command in [('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]),('inspect-points',[str(prefix/'bin/python'),str(r/'inspect_points.py')])]:
 start=time.monotonic();p=subprocess.run(command,cwd=r,env=env,capture_output=True,text=True,timeout=120);(r/(stage+'.stdout.txt')).write_text(p.stdout);(r/(stage+'.stderr.txt')).write_text(p.stderr);stages.append(dict(stage=stage,returncode=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,p.stderr
record=dict(scope='EHPC official global surface input inspection only, original selected static fields and domain/PFT matching remain separate from model/scientific acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_bytes=data.stat().st_size,source_sha256=sha(data),stages=stages,seconds=time.monotonic()-begun)
(r/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

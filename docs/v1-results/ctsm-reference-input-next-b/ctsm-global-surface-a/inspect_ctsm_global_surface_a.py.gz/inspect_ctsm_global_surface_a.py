from pathlib import Path
import hashlib,json,tarfile,urllib.request,xml.etree.ElementTree as ET
b=Path('/home/zhangyq/noahmp-v1');out=b/'ctsm-global-surface-a';out.mkdir(exist_ok=False);archive=b/'ctsm-reference-source-bundle-a.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(archive)=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
rows=[];sources={}
with tarfile.open(archive) as t:
 for member in t:
  if not member.isfile() or 'namelist_defaults' not in member.name or not member.name.endswith('.xml'):continue
  raw=t.extractfile(member).read()
  try:tree=ET.fromstring(raw)
  except ET.ParseError:continue
  found=[]
  for element in tree.iter('fsurdat'):
   text=(element.text or '').strip()
   if '1.9x2.5' in text and ('simyr2000' in text or 'simyr2005' in text):
    row=dict(source_xml=member.name,attributes=element.attrib,path=text);rows.append(row);found.append(row)
  if found:
   p=out/'selected-upstream'/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);sources[member.name]=hashlib.sha256(raw).hexdigest()
paths=sorted(set(r['path'] for r in rows));heads=[]
for path in paths:
 if '16pfts' not in path or 'simyr2000' not in path:continue
 # Static metadata/HEAD only; never download an unknown-size global file.
 url='https://svn-ccsm-inputdata.cgd.ucar.edu/trunk/inputdata/'+path
 row=dict(path=path,url=url)
 try:
  with urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=15) as response:row.update(status=response.status,content_length=response.headers.get('Content-Length'),etag=response.headers.get('ETag'))
 except Exception as e:row['error']=type(e).__name__+': '+str(e)
 heads.append(row)
value=dict(scope='Pinned upstream global surface input selection and bounded HEAD only. No global dataset fetched, station matched, physical model or scientific acceptance implied.',source_bundle_sha256=sha(archive),source_xml_sha256=sources,matching_entries=rows,heads=heads)
(out/'selection.json').write_text(json.dumps(value,indent=2)+'\n');(out/Path(__file__).name).write_bytes(Path(__file__).read_bytes());print(json.dumps(dict(matches=len(rows),heads=heads)))

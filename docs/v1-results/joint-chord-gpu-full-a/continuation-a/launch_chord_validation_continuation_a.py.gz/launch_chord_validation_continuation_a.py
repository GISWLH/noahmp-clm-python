from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-joint-chord-a';root=source/'continuation-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--run' not in sys.argv:
    root.mkdir(exist_ok=False);(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes());command=[sys.executable,'-u',str(root/Path(__file__).name),'--run']
    with (root/'controller.log').open('w') as log:p=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
    value=dict(pid=p.pid,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Wait for actual target terminal success, then supersede obsolete own486 GPU work; start new489 fullGPU0 and fresh K first48 with independent JAX32 shadow onGPU1. CPU804 actual126 required. No changed-source checkpoint resume.');(root/'launch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(0)
begun=time.monotonic();target=source/'target-a/summary.json'
while not target.exists():
    p=Path('/proc/4166718');assert p.exists() and 'run_joint_chord_gpu_targets_a.py' in (p/'cmdline').read_bytes().decode()
    tmp=root/'progress.json.tmp';tmp.write_text(json.dumps(dict(status='waiting-for-actual-new489-target',seconds=time.monotonic()-begun))+'\n');os.replace(tmp,root/'progress.json');time.sleep(10)
r=json.loads(target.read_text());assert r['status']=='complete' and r['source_unchanged'] and all(v['returncode']==0 and v['receipt']['passed'] for v in r['results'])
subprocess.run([sys.executable,str(base/'supersede_old_full_for_chord_a.py')],check=True)
def env(gpu):
    e=os.environ.copy();e.pop('LD_LIBRARY_PATH',None);e.update(PYTHONPATH=':'.join(map(str,[source,source/'src',source/'tests',source/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES=str(gpu),CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1');return e
launched=[]
for gpu,script,folder,label in [(0,source/'run_joint_chord_full_gpu_a.py',source,'full-gpu-a'),(1,base/'fluxnet-first-climate-cycle-20261017-k/run_gpu_chord_k_day_a.py',base/'fluxnet-first-climate-cycle-20261017-k','cuda-day')]:
    command=[sys.executable,'-u',str(script)]
    with (folder/(label+'-controller.log')).open('w') as log:p=subprocess.Popen(command,cwd=source,env=env(gpu),stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
    value=dict(pid=p.pid,gpu=gpu,command=command,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runner_sha256=sha(script),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'));(folder/(label+'-launch.json')).write_text(json.dumps(value,indent=2)+'\n');launched.append(value)
(root/'progress.json').write_text(json.dumps(dict(status='launched-new489',launched=launched,seconds=time.monotonic()-begun),indent=2)+'\n');print(json.dumps(launched),flush=True)

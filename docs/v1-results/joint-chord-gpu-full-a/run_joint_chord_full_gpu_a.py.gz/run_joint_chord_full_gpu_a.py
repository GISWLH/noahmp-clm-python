from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-joint-chord-a';out=source/'full-by-file-a';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());begun=time.monotonic()
def verify():assert len(m)==489 and all(sha(source/n)==v for n,v in m.items())
def xml_nodes(raw):
    nodes=[]
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(k) is None for k in ['failure','error','skipped'])
        parts=c.attrib['classname'].split('.');ix=[k for k,p in enumerate(parts) if p.startswith('test_')];assert len(ix)==1;k=ix[0];nodes.append('tests/'+parts[k]+'.py::'+'::'.join(parts[k+1:]+[c.attrib['name']]))
    assert len(nodes)==len(set(nodes));return set(nodes)
verify();original=json.loads((base/'p6-spinup-assessment-c/current-collection-receipt.json').read_text());allnodes=set(original['nodes']);assert len(allnodes)==1129
isgpu=lambda n:Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'));gpu={n for n in allnodes if isgpu(n)};cpu=allnodes-gpu;assert len(gpu)==325 and len(cpu)==804
archive=base/'joint-chord-cpu-a-evidence.tar.gz';assert sha(archive)=='d4b8c6b1177f03ef2b6c88f384fae885f6ca5aa8225d2760156af048325f5548'
with tarfile.open(archive) as t:
    assert json.load(t.extractfile('SOURCE_SHA256.json'))==m;receipt=json.load(t.extractfile('receipt.json'));assert receipt['returncode']==0 and receipt['source_unchanged'] and receipt['counts']==dict(tests=804,failures=0,errors=0,skipped=0) and xml_nodes(t.extractfile('cpu-full.xml').read())==cpu
covered=set(cpu);rows=[];seen=set();target=source/'target-a';summary=json.loads((target/'summary.json').read_text());assert summary['status']=='complete'
for row in summary['results']:
    file='tests/'+row['file']
    if file not in {n.split('::')[0] for n in gpu}:continue
    r=row['receipt'];expected={n for n in gpu if n.split('::')[0]==file};actual=xml_nodes((target/(Path(file).stem+'.xml')).read_bytes())
    assert row['returncode']==r['worker_exitcode']==r['pytest_returncode']==0 and r['passed'] and r['source_unchanged'] and r['source_manifest_sha256']==sha(source/'SOURCE_SHA256.json') and r['xml_sha256']==sha(target/(Path(file).stem+'.xml')) and r['test_sha256']==sha(source/file) and actual==expected
    seen.add(file);covered.update(actual);rows.append(dict(file=file,origin='new489-target-only',result=row))
worker=base/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
files={n.split('::')[0] for n in gpu};assert files=={p.relative_to(source).as_posix() for p in (source/'tests').glob('test_*.py') if isgpu(p.name)}
pending=sorted(files-seen,key=lambda n:('_column' in n or 'surface' in n,n));scope='Fresh489 exact1129 distributed regression: actual new489 EHPC804 plus only new489 target canonical GPU prefix, then every remaining325 GPU node. Original486 GPU107 and diagnostic extra2 are not credited. All pytest phases/device barriers/worker exits/source hashes retained. Interpreter atexit bypass scope remains explicit; no science/year/spinup acceptance.'
(out/'selection.json').write_text(json.dumps(dict(scope=scope,all_nodes=sorted(allnodes),cpu_nodes=804,gpu_nodes=325,verified_gpu_prefix_nodes=len(covered)-804,prefix_results=rows,pending_files=pending,cpu_archive_sha256=sha(archive),source_manifest_sha256=sha(source/'SOURCE_SHA256.json')),indent=2)+'\n');results=[]
def save(active=None):
    r=dict(scope=scope,status='running',covered_nodes=len(covered),covered_gpu_nodes=len(covered)-804,collected_nodes=1129,active=active,results=results,seconds=time.monotonic()-begun);tmp=out/'progress.json.tmp';tmp.write_text(json.dumps(r,indent=2)+'\n');os.replace(tmp,out/'progress.json')
save()
for file in pending:
    verify();stem=Path(file).stem;nodes={n for n in gpu if n.split('::')[0]==file};expected=out/(stem+'-expected.json');expected.write_text(json.dumps(sorted(Path(n.split('::')[0]).name+'::'+n.split('::',1)[1] for n in nodes),indent=2)+'\n');dest=out/(stem+'-receipt.json');xml=out/(stem+'.xml');command=[sys.executable,'-u',str(worker),'--source',str(source),'--test-file',str(source/file),'--expected',str(expected),'--receipt',str(dest),'--xml',str(xml)];start=time.monotonic()
    with (out/(stem+'.log')).open('w') as log:p=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT);save(dict(file=file,pid=p.pid));code=p.wait()
    row=dict(file=file,pid=p.pid,returncode=code,seconds=time.monotonic()-start,passed=False)
    if dest.exists():
        r=json.loads(dest.read_text());row['receipt']=r
        if code==r['worker_exitcode']==r['pytest_returncode']==0 and r['passed'] and r['source_unchanged'] and r['source_manifest_sha256']==sha(source/'SOURCE_SHA256.json') and r['xml_sha256']==sha(xml) and xml_nodes(xml.read_bytes())==nodes:row['passed']=True;covered.update(nodes)
    results.append(row);save();print(json.dumps({k:v for k,v in row.items() if k!='receipt'}),flush=True)
verify();complete=covered==allnodes and all(r['passed'] for r in results);(out/'summary.json').write_text(json.dumps(dict(scope=scope,status='complete' if complete else 'failed',collected_nodes=1129,covered_nodes=len(covered),source_unchanged=True,all_node_coverage_exact=covered==allnodes,prefix_results=rows,results=results,seconds=time.monotonic()-begun),indent=2)+'\n');raise SystemExit(0 if complete else 1)

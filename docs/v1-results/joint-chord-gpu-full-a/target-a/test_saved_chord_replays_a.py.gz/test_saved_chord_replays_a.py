from pathlib import Path
import json,hashlib
import numpy as np
root=Path(__file__).parent;source=root.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def test_j5498_joint_reference_original_bounds_and_same_precision():
    import cupy as cp
    from noahmp_clm.gpu.column_heat import run_joint_heat_jax
    from noahmp_clm.gpu.cuda.column_heat import run_joint_heat_cuda
    from test_gpu_column_heat import numpy_reference
    with np.load(source/'tests/fixtures/j5498_joint_stagnation.npz',allow_pickle=False) as z:inputs=tuple(z[k] for k in ['cells','props','options','boundary'])
    a=run_joint_heat_cuda(*inputs);b=run_joint_heat_jax(*inputs);maximum=0.
    for k in a:
        left,right=cp.asnumpy(a[k]),np.asarray(b[k])
        if left.dtype.kind in 'iub':np.testing.assert_array_equal(left,right)
        else:np.testing.assert_allclose(left,right,rtol=1e-6,atol=1e-6,err_msg=k);maximum=max(maximum,float(abs(left.astype(float)-right.astype(float)).max()))
    reference=json.loads((root/'joint-reference.json').read_text());assert reference['pbs_job']=='125.manager' and reference['input_sha256']==sha(source/'tests/fixtures/j5498_joint_stagnation.npz')
    c,p,o,bc=inputs;n=int(o[0,0])+4;h=cp.asnumpy(a['enthalpy_jm2']);t=cp.asnumpy(a['temperature_k']);res=cp.asnumpy(a['layer_residual_jm2']);tol=cp.asnumpy(a['layer_tolerance_jm2'])
    np.testing.assert_allclose(t[0,:n],reference['temperature_k'],rtol=0.,atol=.01);np.testing.assert_allclose(h[0,:n],reference['enthalpy_jm2'],rtol=.1,atol=.1);assert np.all(abs(res)<=tol)
    incoming=float(bc[0,0])*(float(cp.asnumpy(a['top_flux_wm2'])[0])+c[0,:n,4].astype(float).sum());budget=float((h[0,:n].astype(float)-c[0,:n,1].astype(float)).sum()-incoming);bound=float(tol[0,:n].astype(float).sum())+16*np.finfo(np.float32).eps*max(abs(incoming),1.)+1e-5;assert abs(budget)<=bound
    print('J5498 joint original bounds',json.dumps(dict(same_precision_max_absolute=maximum,independent_heat_residual_jm2=budget,original_heat_bound_jm2=bound,max_layer_ratio=float(np.max(abs(res)/tol)),temperature_max_difference_k=float(abs(t[0,:n]-reference['temperature_k']).max()),iterations=cp.asnumpy(a['iterations']).tolist())),flush=True)
def test_j5498_whole_cuda_reference_and_original_budgets():
    import run_fluxnet_native as native
    from noahmp_clm.physics.photosynthesis import LeafParameters
    path=root/'whole-inputs.npz';assert sha(path)=='fc8869bccf3ff62ccceb27d06c654501180c6277927503d9e571ce8a3a650848'
    with np.load(path,allow_pickle=False) as z:v=dict(z)
    original=Path('/home/lhwang/work/noahmp-v1/fluxnet-first-climate-cycle-20261017-j');batch=json.loads((original/'batch.json').read_text());config=Path(batch['cases'][0]['configuration']);config=config if config.is_absolute() else original/config;leaf=LeafParameters(**json.loads(config.read_text())['leaf_parameters'])
    arrays=tuple(v[f'a{k}'] for k in range(16));engine=native.Backend('cuda32');device=engine.update_forcing(tuple(engine.xp.asarray(x) for x in arrays),v['forcing_environment'])
    out_device=engine.step(*device,v['forcing'],environment=v['environment'],calendar=v['calendar'],nitrogen_deposition_gn_m2=v['nitrogen'],deposition=v['deposition'],most_geometry=v['geometry'],leaf_parameters=leaf,return_surface=True);out=engine.host(out_device);after=tuple(engine.host(x) for x in native.next_bgc_arrays(device,out_device));incoming,res,bound,tracer=native.audit_step(arrays,after,v['forcing'],v['deposition'],v['nitrogen'],out)
    reference=json.loads((root/'whole-reference.json').read_text());assert reference['pbs_job']=='124.manager';h=np.asarray(out['diagnostics']['h']);le=np.asarray(out['diagnostics']['le']);expected_h=np.array([r['h'] for r in reference['rows']]);expected_le=np.array([r['le'] for r in reference['rows']]);np.testing.assert_allclose(h,expected_h,rtol=.1,atol=.1);np.testing.assert_allclose(le,expected_le,rtol=.1,atol=.1)
    print('J5498 full original budgets',json.dumps(dict(h_wm2=h.tolist(),le_wm2=le.tolist(),h_absolute_difference=abs(h-expected_h).tolist(),le_absolute_difference=abs(le-expected_le).tolist(),independent_m_h_c_n=res.tolist(),original_bounds=bound.tolist(),impurity_residual=tracer.tolist())),flush=True)

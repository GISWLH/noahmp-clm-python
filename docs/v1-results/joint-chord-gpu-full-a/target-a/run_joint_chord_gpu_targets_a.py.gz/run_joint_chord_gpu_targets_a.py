from pathlib import Path
import hashlib,json,subprocess,sys,time
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-joint-chord-a';out=source/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in m.items())
collection=json.loads((base/'p6-spinup-assessment-c/current-collection-receipt.json').read_text());worker=base/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
files=['tests/test_gpu_column_heat.py','tests/test_gpu_heat_coordinate_rounding.py','tests/test_gpu_heat_phase_event_rounding.py','tests/test_gpu_canopy_phase_surface.py'];rows=[(out/'test_saved_chord_replays_a.py',['test_saved_chord_replays_a.py::test_j5498_joint_reference_original_bounds_and_same_precision','test_saved_chord_replays_a.py::test_j5498_whole_cuda_reference_and_original_budgets'])]
for file in files:rows.append((source/file,sorted(Path(n.split('::')[0]).name+'::'+n.split('::',1)[1] for n in collection['nodes'] if n.split('::')[0]==file)))
results=[];begun=time.monotonic()
for test,nodes in rows:
    assert nodes;stem=test.stem;expected=out/(stem+'-expected.json');expected.write_text(json.dumps(nodes,indent=2)+'\n');receipt=out/(stem+'-receipt.json');command=[sys.executable,'-u',str(worker),'--source',str(source),'--test-file',str(test),'--expected',str(expected),'--receipt',str(receipt),'--xml',str(out/(stem+'.xml'))];start=time.monotonic()
    with (out/(stem+'.log')).open('w') as log:p=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT);(out/'progress.json').write_text(json.dumps(dict(active_file=test.name,pid=p.pid,results=results),indent=2)+'\n');code=p.wait()
    r=json.loads(receipt.read_text()) if receipt.exists() else None;row=dict(file=test.name,pid=p.pid,returncode=code,seconds=time.monotonic()-start,receipt=r);results.append(row);print(json.dumps({k:v for k,v in row.items() if k!='receipt'}),flush=True)
assert all(sha(source/n)==v for n,v in m.items());passed=all(v['returncode']==0 and v['receipt'] and v['receipt']['passed'] for v in results)
(out/'summary.json').write_text(json.dumps(dict(status='complete' if passed else 'failed',results=results,source_unchanged=True,seconds=time.monotonic()-begun),indent=2)+'\n');raise SystemExit(0 if passed else 1)

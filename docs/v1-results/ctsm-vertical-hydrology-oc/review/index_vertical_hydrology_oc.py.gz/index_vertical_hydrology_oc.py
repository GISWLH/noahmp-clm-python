"""Stdlib-only text/hash/config evidence index; never imports model or array libraries."""
from pathlib import Path
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'outputs/v1'
sha = lambda b: hashlib.sha256(b).hexdigest()
FILES = {
    'src/noahmp_clm/physics/richards.py': [[1,19],[170,180],[277,300]],
    'src/noahmp_clm/clm_enthalpy_driver.py': [[30,54],[238,285]],
    'src/noahmp_clm/physics/soil_drainage.py': [[12,37]],
    'src/noahmp_clm/physics/vic.py': [[54,87]],
    'src/noahmp_clm/physics/runoff.py': [[16,44],[63,83]],
    'src/noahmp_clm/physics/tile_drainage.py': [[1,73]],
    'src/noahmp_clm/clm_state.py': [[30,46],[276,290]],
    'src/noahmp_clm/gpu/clm_richards_column.py': [[9,52]],
    'src/noahmp_clm/gpu/clm_enthalpy_column.py': [[17,20],[240,264]],
    'src/noahmp_clm/gpu/cuda/clm_enthalpy_column.py': [[10,18],[21,49]],
    'benchmarks/run_fluxnet_column.py': [[54,72]],
    'benchmarks/run_fluxnet_native.py': [[35,63],[85,92],[488,488]],
}
record = dict(scope='Read-only current hydrology code and frozen R/S/KG/NP evidence. No forward run, new test, array evaluation, calibration, config/source/docs/Git mutation or causal/science pass.',
              local_array_evaluations=0, forward_model_runs=0, source_files={}, documents={}, configurations={})
nm = OUT/'climatology-final-candidate-nm-source.tar.gz'
assert sha(nm.read_bytes()) == '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
with tarfile.open(nm) as tf:
    record['nm_source_manifest_sha256'] = sha(tf.extractfile('SOURCE_SHA256.json').read())
    for name, lines in FILES.items():
        current = (ROOT/name).read_bytes(); frozen = tf.extractfile(name).read()
        assert current == frozen, name
        assert all(1 <= a <= b <= len(current.decode().splitlines()) for a,b in lines), name
        record['source_files'][name] = dict(sha256=sha(current), bytes=len(current), same_bytes_as_nm=True,
            lines=lines, line_count=len(current.decode().splitlines()))
for name in ['docs/CTSM_REFERENCE_BOUNDARIES.md','docs/CTSM_BOUNDARY_FIELDS.md','docs/CLM_RICHARDS.md','docs/KNOWN_LIMITATIONS.md','README.md','ROADMAP.md']:
    raw = (ROOT/name).read_bytes(); record['documents'][name] = dict(sha256=sha(raw), bytes=len(raw))

def selected_configuration(archive, expected, prefix):
    assert sha(archive.read_bytes()) == expected
    selected = []
    with tarfile.open(archive) as tf:
        batchraw = tf.extractfile(prefix+'batch.json').read(); batch = json.loads(batchraw)
        for case in batch['cases']:
            name = prefix+case['configuration']; raw = tf.extractfile(name).read(); config = json.loads(raw)
            column = config['column']; opts = column['options']
            selected.append(dict(case=case['case'], member=name, sha256=sha(raw),
                soil_hydrology_explicit='soil_hydrology' in config, soil_hydrology=config.get('soil_hydrology'),
                runoff_options={k:opts.get(k) for k in ['OptRunoffSurface','OptRunoffSubsurface','OptTileDrainage']},
                dz_m=column['dz'], root_frac=column['root_frac'],
                groundwater_depth_explicit='groundwater_depth' in column,
                groundwater_depth=column.get('groundwater_depth')))
    return dict(archive=archive.name, sha256=expected, batch_sha256=sha(batchraw), selected_cases=selected,
                all_selected_vic6=all(x['runoff_options']['OptRunoffSurface']==x['runoff_options']['OptRunoffSubsurface']==6 for x in selected),
                all_selected_legacy_hydrology=all(x['soil_hydrology'] is None for x in selected))

record['configurations']['KG3'] = selected_configuration(OUT/'hrldas-current-kg-inputs.tar.gz',
    '044959702bb888999528e51f8dbd5589f2d93db04299947306d5eb8f8cfa0f2e','')
record['configurations']['NP12'] = selected_configuration(OUT/'climatology-cold48-np-download/cold48-evidence.tar.gz',
    'ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416','current/inputs/')
assert len(record['configurations']['KG3']['selected_cases']) == 3
assert len(record['configurations']['NP12']['selected_cases']) == 12
oa = OUT/'ctsm-boundary-fields-oa-evidence.tar.gz'
assert sha(oa.read_bytes()) == 'b8f1fcb78e7a849ab349240918115e7d7c6ad405a5366e3063acbee8ede878cd'
with tarfile.open(oa) as tf:
    name='original-results/1589/readback/boundary-fields.json'; raw=tf.extractfile(name).read(); data=json.loads(raw)
    record['original_oa'] = dict(archive_sha256=sha(oa.read_bytes()), member=name, result_sha256=sha(raw), files=[])
    for item in data['files']:
        selected = {k:{n:v for n,v in item['selected_values'][k].items() if n!='values' or item['selected_values'][k].get('shape')==[1]}
            for k in ['WA','ZWT','ZWT_PERCH','QDRAI','QCHARGE'] if k in item.get('selected_values',{})}
        if selected: record['original_oa']['files'].append(dict(case=item['case'], member=item['member'], sha256=item['sha256'], selected_original_summary=selected))
with tarfile.open(OUT/'qia-runoff-diagnosis-ab-evidence.tar.gz') as tf:
    name='ctsm-runoff-partition-b/diagnosis.json'; raw=tf.extractfile(name).read(); data=json.loads(raw)
    record['original_313'] = dict(member=name, sha256=sha(raw), pbs_job=data['pbs_job'],
        fields={k:data['fields']['history'][k] for k in ['QDRAI','QOVER','QRUNOFF']},
        scope='Original first48 only; not a current NM rerun or a full-year zero-drainage claim.')
target=OUT/'clm-vertical-groundwater-oc-index.json'
target.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(index=str(target),sha256=sha(target.read_bytes()),source_files=len(FILES),selected_cases=15,local_array_evaluations=0)))

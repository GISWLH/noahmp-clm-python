"""PBS-only integration of frozen original R hydrology history; no model imports."""
import datetime
import hashlib
import json
import os
import re
import sys
import tarfile
import time
import traceback
from pathlib import Path

assert os.environ.get('PBS_JOBID') and os.uname().nodename == 'compute002'
import numpy as np
from netCDF4 import Dataset, date2num, num2date

BASE = Path('/home/zhangyq/noahmp-v1')
OUT = Path(sys.argv[1]); OUT.mkdir()
ARCHIVE = BASE/'ctsm-qia-run-r/case-configuration-private.tar.gz'
EXPECTED = '14891786b9c492d4f34f3077476181333f6e0ccb6c3209663ad0a5194f77b1b0'
SOURCE = BASE/'ctsm-reference-source-bundle-a.tar.gz'
SOURCE_SHA = 'f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
UNITS = 'days since 2002-12-31 16:00:00'
CORE = ['QDRAI', 'QOVER', 'QRUNOFF', 'QCHARGE']
OPTIONAL = ['QDRAI_PERCH', 'QH2OSFC', 'QRGWL']
RATIO_MINIMUM_DENOMINATOR_MM = 0.05
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def value(v):
    if isinstance(v, (np.ndarray, np.generic)): return value(v.tolist())
    if isinstance(v, list): return [value(x) for x in v]
    if isinstance(v, float) and not np.isfinite(v): return str(v)
    return v


def metadata(v):
    return dict(dimensions=v.dimensions, shape=v.shape, dtype=str(v.dtype),
                attributes={n: value(v.getncattr(n)) for n in v.ncattrs()})


def read(v):
    a = np.ma.asarray(v[:]); data = np.ma.getdata(a); mask = np.ma.getmaskarray(a)
    info = metadata(v)
    info.update(original_masked_count=int(mask.sum()), original_nonfinite_count=int((~np.isfinite(data)).sum()))
    return data, mask, info


def summarize(data, mask, dt, select):
    x = data[select]; m = mask[select]; valid = ~m & np.isfinite(x)
    return dict(intervals=len(x), valid_intervals=int(valid.sum()), original_masked_count=int(m.sum()),
                original_nonfinite_count=int((~np.isfinite(x)).sum()),
                nonzero_valid_intervals=int(np.count_nonzero(x[valid])),
                positive_valid_intervals=int(np.count_nonzero(x[valid] > 0)),
                negative_valid_intervals=int(np.count_nonzero(x[valid] < 0)),
                minimum_valid_rate_mm_s=float(x[valid].min()) if valid.any() else None,
                maximum_valid_rate_mm_s=float(x[valid].max()) if valid.any() else None,
                complete=bool(valid.all()), total_mm=float(np.sum(x.astype(float)*dt[select])) if valid.all() else None,
                masked_values_filled=False)


def ratio(fields):
    a = fields['QDRAI']['total_mm']; b = fields['QRUNOFF']['total_mm']
    if a is None or b is None: return dict(percent=None, reason='incomplete_original_data')
    if abs(b) <= RATIO_MINIMUM_DENOMINATOR_MM:
        return dict(percent=None, reason='near_zero_total_runoff', absolute_qdrai_mm=a, absolute_qrunoff_mm=b)
    return dict(percent=100.*a/b, reason='complete_non_near_zero_denominator')


def source_index():
    assert sha(SOURCE.read_bytes()) == SOURCE_SHA
    definitions = {
        'SoilWaterMovementMod.F90': ([[44,55],[196,211],[1184,1185],[1354,1375],[1405,1412]],
            'Boundary 2 is zero flux; aquifer is used only by boundary 3 or 4; R boundary 2 contributes zero bottom QCHARGE.'),
        'HydrologyNoDrainageMod.F90': ([[201,229]],
            'Without aquifer, actual driver calls perched and theta-based water-table diagnostics, not the prognostic aquifer WaterTable routine.'),
        'HydrologyDrainageMod.F90': ([[129,147],[203,211]],
            'Without aquifer, local column drainage calls PerchedLateralFlow and LateralFlowPowerLaw; runoff includes distinct perched/surface-water outlets.'),
        'SoilHydrologyMod.F90': ([[1747,1812],[1865,1915],[2074,2128],[2147,2161],[2219,2226]],
            'Perched and saturation-zone outlets remove liquid from actual soil layers; diagnostic water table and ice/soil/topography control these outlets, not a separate active aquifer in R.'),
        'BalanceCheckMod.F90': ([[143,153]],
            'Before water balance, hydrologically active columns with water table at/above soil bottom reset WA to the aquifer baseline.'),
        'TotalWaterAndHeatMod.F90': ([[254,266],[525,541]],
            'Water and heat accounting subtract the 5000 mm virtual baseline; WA alone is not total column water or an observed recharge tendency.'),
        'SoilHydrologyInitTimeConstMod.F90': ([[85,111]],
            'Initial nonurban cold WA is 4000 mm with geometry-derived ZWT; initialization values are not evidence of an active aquifer boundary.'),
    }
    result = {}
    with tarfile.open(SOURCE) as tf:
        for name, (lines, semantics) in definitions.items():
            member = 'CTSM/src/biogeophys/'+name; raw = tf.extractfile(member).read()
            result[member] = dict(sha256=sha(raw), lines=lines, semantics=semantics,
                primary_url='https://github.com/ESCOMP/CTSM/blob/fdfc03a0abec838ec0b66663a6a2f5e619cd2611/src/biogeophys/'+name)
        member = 'CTSM/src/main/clm_varcon.F90'; raw = tf.extractfile(member).read()
        result[member] = dict(sha256=sha(raw), lines=[[128,128]], semantics='aquifer_water_baseline=5000 mm')
    assert sha(SOURCE.read_bytes()) == SOURCE_SHA
    return dict(bundle_sha256=SOURCE_SHA, files=result, fortran_implementation_copied=False)


start = time.monotonic()
record = dict(pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, passed=False, failure=None,
    forward_model_runs=0, archive_sha256=EXPECTED, files=[], scientific_acceptance=False,
    scope='Read original R fluxes only. Full original 17520 positive half-hour bins, original masks/units, fixed daily/monthly/yearly grouping. No model, calibration, input/QC mutation or attribution of model bias.')
try:
    assert sha(ARCHIVE.read_bytes()) == EXPECTED
    arrays = {}; parts = {}; masks = {}; allbounds = []; rawbounds = []; rowfiles = []
    with tarfile.open(ARCHIVE) as tf:
        names = [m.name for m in tf if m.isfile()]
        histories = sorted(n for n in names if '/run/' in n and '.clm2.h0.' in n and n.endswith('.nc'))
        assert len(histories) == 2
        for file_index, name in enumerate(histories):
            raw = tf.extractfile(name).read(); entry = dict(member=name, sha256=sha(raw), bytes=len(raw), variables={})
            with Dataset('original-R-history', mode='r', memory=raw) as ds:
                assert ds['time'].units == UNITS
                bounds, bmask, bmeta = read(ds['time_bounds'])
                assert not bmask.any() and np.isfinite(bounds).all()
                seconds = bounds.astype(float)*86400.; assert abs(seconds-np.rint(seconds)).max() <= .01
                rawbounds.append(seconds); allbounds.append(np.rint(seconds).astype(np.int64)); rowfiles.extend([file_index]*len(seconds))
                entry.update(time_bounds=bmeta, stored_rows=len(seconds), time=metadata(ds['time']))
                for field in CORE+OPTIONAL:
                    if field not in ds.variables:
                        assert field not in CORE
                        entry['variables'][field] = dict(status='unmeasured_absent_actual_history_field'); continue
                    v = ds[field]; data, mask, meta = read(v)
                    assert v.units == 'mm/s' and v.dimensions[0] == 'time' and np.prod(data.shape[1:]) == 1
                    assert getattr(v, 'cell_methods', None) == 'time: mean'
                    parts.setdefault(field, []).append(data.reshape(len(seconds)))
                    masks.setdefault(field, []).append(mask.reshape(len(seconds)))
                    entry['variables'][field] = meta
            record['files'].append(entry)
        combined = np.concatenate(allbounds); order = np.argsort(combined[:,0], kind='stable'); combined = combined[order]
        valid = (combined[:,0] >= 0) & (combined[:,1] <= 31536000)
        expected = np.arange(17520)[:,None]*1800+np.array([[0,1800]])
        assert len(combined) == 17521 and valid.sum() == 17520 and np.array_equal(combined[valid], expected)
        assert np.array_equal(combined[~valid], [[-1800,0]])
        dt = expected[:,1]-expected[:,0]
        arrays.update(all_time_bounds_seconds=combined, all_raw_time_bounds_seconds=np.concatenate(rawbounds)[order],
            all_history_file_index=np.asarray(rowfiles,dtype=np.int32)[order], positive_selector=valid, positive_time_bounds_seconds=expected)
        met_name = 'inputdata/CN-Qia.datm.2003.nc'; met = tf.extractfile(met_name).read()
        with Dataset('original-R-met-time-only', mode='r', memory=met) as ds:
            bounds, mask, meta = read(ds['time_bounds']); assert not mask.any() and len(bounds) == 17520
            calendar = getattr(ds['time'],'calendar','standard')
            seconds = np.asarray(date2num(num2date(bounds, ds['time'].units, calendar), UNITS, calendar),float)*86400.
            assert abs(seconds-expected).max() <= .01
            record['original_meteorology_time_binding'] = dict(member=met_name, sha256=sha(met), time=metadata(ds['time']),
                time_bounds=meta, positive_intervals=17520, maximum_time_error_seconds=float(abs(seconds-expected).max()), driver_values_not_substituted=True)
        nl = tf.extractfile('output/case/run/lnd_in').read()
        record['actual_configuration'] = dict(member='output/case/run/lnd_in', sha256=sha(nl),
            matching_lines=[dict(line=i,text=line.strip()) for i,line in enumerate(nl.decode().splitlines(),1)
                if re.search('lower_boundary|soilwater_movement|baseflow|use_bedrock|use_cn|use_hydrstress',line)])
    measured = {}; missing = []
    for field in CORE+OPTIONAL:
        if len(parts.get(field,[])) != 2: missing.append(field); continue
        a = np.concatenate(parts[field])[order]; m = np.concatenate(masks[field])[order]
        arrays['all_land_'+field] = a; arrays['all_original_mask_'+field] = m
        arrays['all_nonfinite_mask_'+field] = ~np.isfinite(a)
        measured[field] = (a[valid],m[valid])
    assert all(field in measured for field in CORE)
    dates = [datetime.datetime(2003,1,1)+datetime.timedelta(seconds=int(x)) for x in expected[:,0]]
    day_ids = np.asarray([d.strftime('%Y-%m-%d') for d in dates]); month_ids = np.asarray([d.strftime('%Y-%m') for d in dates])
    def period(select):
        fields = {name:summarize(a,m,dt,select) for name,(a,m) in measured.items()}
        return dict(fields=fields, qdrai_fraction_of_total_runoff=ratio(fields))
    record.update(stored_rows=17521, positive_intervals=17520, excluded_bounds_seconds=[[-1800,0]],
        annual=period(np.ones(17520,dtype=bool)),
        monthly={key:period(month_ids==key) for key in sorted(set(month_ids))},
        daily={key:period(day_ids==key) for key in sorted(set(day_ids))}, unmeasured_optional_fields=missing,
        ratio_denominator_absolute_threshold_mm=RATIO_MINIMUM_DENOMINATOR_MM,
        ratio_rule='Diagnostic fraction only, not error or new acceptance gate; denominator absolute total <=0.05 mm reports null and absolute totals.',
        grouping='Original 2003 nominal local experimental year (UTC+8); daily/monthly bins use original start-relative intervals, not calendar regrouping in UTC.',
        source_semantic_index=source_index())
    assert len(record['daily']) == 365 and len(record['monthly']) == 12
    np.savez_compressed(OUT/'vertical-hydrology-original-intervals.npz', **arrays)
    record['array_archive_sha256'] = sha((OUT/'vertical-hydrology-original-intervals.npz').read_bytes())
    assert sha(ARCHIVE.read_bytes()) == EXPECTED
    record.update(passed=True, original_archive_unchanged=True)
except Exception as error:
    record['failure'] = type(error).__name__+': '+str(error)
    (OUT/'traceback.txt').write_text(traceback.format_exc())
record['seconds'] = time.monotonic()-start
(OUT/'vertical-hydrology.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:record[k] for k in ['pbs_job','passed','failure','forward_model_runs','seconds']}),flush=True)
raise SystemExit(0 if record['passed'] else 1)

"""Change only the next worker launch wrapper; never touch an active worker."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess
b=Path('/home/lhwang/work/noahmp-v1');r=b/'wet-coupled-gpu-br';p=r/'wet_coupled_worker_br.py';sha=lambda raw:hashlib.sha256(raw).hexdigest();old=p.read_bytes();launch=json.loads((r/'launch.json').read_text());assert sha(old)==launch['controls_sha256']['wet_coupled_worker_br.py'];progress=json.loads((r/'progress.json').read_text());pid=progress['pid'];assert progress['active_file']=='test_gpu_clm_richards_column.py' and Path('/proc/'+str(pid)).exists();active_env=Path('/proc/'+str(pid)+'/environ').read_bytes();assert b'CUDA_VISIBLE_DEVICES=0\0' in active_env
uuid=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=uuid','--format=csv,noheader'],text=True).strip();assert uuid=='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
prefix='''# BZ: user requested physical CUDA 1. Applied before any device imports.
from pathlib import Path as _RoutePath
import datetime as _rd, json as _rj, os as _ro, subprocess as _rsp, sys as _rs, time as _rt
_rr=_RoutePath('/home/lhwang/work/noahmp-v1/wet-coupled-gpu-br')
_rf=_RoutePath(_rs.argv[_rs.argv.index('--test-file')+1]).stem
_ru='GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
_rb=_rt.monotonic()
while True:
    _free=int(_rsp.check_output(['nvidia-smi','--id='+_ru,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    _mem=int(next(v.split()[1] for v in _RoutePath('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))
    _ready=_free>8192 and _mem>32*1024*1024
    _row=dict(utc=_rd.datetime.now(_rd.timezone.utc).isoformat(),pid=_ro.getpid(),test_file=_rf,physical_gpu_index=1,physical_gpu_uuid=_ru,logical_device_index=0,gpu_free_mib=_free,host_available_kib=_mem,resource_guards_unchanged=True,ready=_ready,wait_seconds=_rt.monotonic()-_rb)
    (_rr/(_rf+'-gpu-route-bz.json')).write_text(_rj.dumps(_row,indent=2)+'\\n')
    if _ready:break
    _rt.sleep(20.)
_ro.environ['CUDA_VISIBLE_DEVICES']=_ru
'''
backup=r/'wet_coupled_worker_br-before-bz.py';assert not backup.exists() and not (r/'gpu-routing-bz.json').exists();backup.write_bytes(old);raw=prefix.encode()+old;temp=r/'wet_coupled_worker_br.py.bz-tmp';temp.write_bytes(raw);os.replace(temp,p)
d=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),user_preference='Prefer physical CUDA 1 for new GPU work',active_worker_pid=pid,active_worker_retains_gpu=0,active_worker_environ_sha256=sha(active_env),original_wrapper_sha256=sha(old),updated_wrapper_sha256=sha(raw),physical_gpu_index=1,physical_gpu_uuid=uuid,scope='External launch wrapper only, before imports for future subprocesses. Running whole5 stays unchanged on0; following original station3/capacity3/station3 use physical1 mapped logical0 with original8GiB/32GiB guards. Controller/source/tests/cases/gates and original launch record unchanged. Not a test completion or speedup claim.');(r/'gpu-routing-bz.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'wet-coupled-gpu-br';sha=lambda raw:hashlib.sha256(raw).hexdigest();s=Path(json.loads((r/'source-location.json').read_text())['source']);m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==564 and all(sha((s/n).read_bytes())==h for n,h in m.items());items=[]
for p in sorted(r.iterdir()):
    if p.is_file():items.append((p.read_bytes(),'wet-coupled-gpu-br/'+p.name))
for p in sorted((b/'wet-coupled-profile-bq').rglob('*')):
    if p.is_file():items.append((p.read_bytes(),'wet-coupled-profile-bq/'+p.relative_to(b/'wet-coupled-profile-bq').as_posix()))
progress=json.loads((r/'progress.json').read_text());pid=progress['pid'];records={}
for name,cmd in [('processes',['ps','-o','pid,ppid,stat,etime,time,wchan:26,args','-p',str(pid)+',364028,4095585,3802990']),('gpus',['nvidia-smi','--query-gpu=index,name,uuid,memory.used,memory.total,utilization.gpu','--format=csv']),('gpu_processes',['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv'])]:
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=25);records[name]=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
for name in ['status','environ']:
    p=Path('/proc')/str(pid)/name
    if p.exists():
        raw=p.read_bytes();records['active_'+name]=raw.decode(errors='replace') if name=='status' else dict(sha256=sha(raw),cuda_visible_devices=[v.decode() for v in raw.split(b'\0') if v.startswith(b'CUDA_VISIBLE_DEVICES=')])
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_unchanged=True,source_manifest_sha256=sha((s/'SOURCE_SHA256.json').read_bytes()),progress=progress,observations=records,scope='LiveBO currentGPU snapshot only. Completedfile receipt/actualparent exits maycount; activefiles/partiallogs/XML are not completion. Canonical1483 collection notexecution. BZ wrapperuserrequested routing appliesfutureworkers physical1/UUID logical0, runningwhole5 unchanged0. OldBQ nonblocking stack and swappedheaps metadata retained; no resets/kill/globalsettings/productioninstrumentation. Exactwaitedfile/finishETA unproven. Not full22/390/1483/year/sciencepass.')
items.extend([((json.dumps(record,indent=2)+'\n').encode(),'record.json'),(Path(__file__).read_bytes(),'control/'+Path(__file__).name),((b/'route_pending_gpu_one_bz.py').read_bytes(),'control/route_pending_gpu_one_bz.py')]);a=b/'wet-coupled-gpu-snapshot-cf-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for raw,name in items:info=tarfile.TarInfo(name);info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(archive=a.name,sha256=sha(a.read_bytes()),bytes=a.stat().st_size,artifacts=len(items),utc=record['utc'],progress=progress)),flush=True)

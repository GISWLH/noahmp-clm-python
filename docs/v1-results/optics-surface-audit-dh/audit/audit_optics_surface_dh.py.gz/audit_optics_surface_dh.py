"""Independent NumPy reference on actual quantized failed surface inputs, PBS only."""
from pathlib import Path
from dataclasses import replace
import hashlib,json,os,sys,tarfile,time,traceback
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'optics-surface-audit-dh';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();package=json.loads((r/'package.json').read_text());source=b/'clm-bounded-native-cn-source.tar.gz';assert sha(source)=='9f28e8874c2a365fdb9c39764fc33e54a542c8aff4d0a5375906d6c22819e286'
with tarfile.open(source) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==568 and all(sha(s/n)==h for n,h in m.items());packet=tmp/'packet';packet.mkdir();a=b/'optics-surface-dg-evidence.tar.gz';assert sha(a)==package['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(packet,filter='data')
probe=json.loads((packet/'probe/receipt.json').read_text());assert probe['expected_failure_reproduced'] and probe['raw_surface_captured'] and probe['source_unchanged'] and probe['failed_zero_based_step']==356
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.snowpack import Snowpack,TF
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.canopy_interception import CanopyCondensate
from noahmp_clm.physics.canopy_energy import CanopyExchange
from noahmp_clm.physics.canopy_column import surface_step
from noahmp_clm.physics.canopy_phase_energy import solve_canopy_phase_energy
from noahmp_clm.physics.soil_uptake import SoilWaterSupply
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_optics import CanopyOptics
from noahmp_clm.physics.vic import VICParameters
with np.load(packet/'probe/failed-surface-input-output.npz',allow_pickle=False) as z:raw=dict(z)
c,g,p,o,a,u,f,v,condensate=[raw['input'+str(k)][0].astype(float) for k in range(9)];n=int(o[0]);pack=Snowpack(c[:n,0],c[:n,1],c[:n,2],c[:n,3],c[:n,4:]);props=SoilParams(smcmax=p[0],bexp=p[1],smcref=p[2],satdk=p[3],quartz=p[4],smcwlt=p[5],saturated_suction_m=p[6]);soil=SoilEnthalpyState(g[:,0],g[:,1],g[:,2],props,int(o[1]));water=CanopyCondensate(condensate[:,0],condensate[:,1]);exchange=CanopyExchange(*u[:11]);extra=raw.get('control/exchange_extension')
if extra is not None:exchange=replace(exchange,atmosphere_water_velocity=float(extra[0,0]),potential_temperature=float(extra[0,1]))
coeff=raw['control/parameters'];coeff=coeff[0] if coeff.ndim>1 and len(coeff)==1 else coeff;leaf=LeafParameters.from_layer_rows(coeff) if coeff.ndim==2 else LeafParameters(*coeff)
optical=raw['control/canopy_optics'][0].reshape(4,2);optics=CanopyOptics(*(tuple(row) for row in optical));stem=raw.get('control/stem_area',np.zeros((1,10)))[0].astype(float)
options=dict(stem_area=stem,vegetated_fraction=u[13],transpiration_limit=u[16],ground_emissivity=u[18],ground_albedo=u[19:21],diffuse_fraction=u[21],cosine_zenith=u[22],nitrogen_factor=f[:,0],water_stress=f[:,1],leaf_parameters=leaf,canopy_optics=optics)
infiltration=None
if 'control/vic' in raw:
    vic=raw['control/vic'][0];assert vic.shape==(8,)
    if vic[0]>0:infiltration=VICParameters(*vic[2:].astype(float))
start=time.monotonic();records=[];outputs={}
def collect(name,call):
    begun=time.monotonic()
    try:
        result=call();d=result[-1] if isinstance(result,tuple) else result;row=dict(name=name,returned=True,seconds=time.monotonic()-begun,diagnostics={})
        for key in ['iterations','restarts','leaf_temperature','ground_temperature','canopy_humidity','h','le','gpp','layer_residual','solver_residual','phase_coordinates','canopy_water_residual','energy_residual_jm2','water_residual_kgm2']:
            if key in d:
                value=np.asarray(d[key]);row['diagnostics'][key]=value.tolist();outputs[name+'/'+key]=value
    except Exception as error:
        row=dict(name=name,returned=False,seconds=time.monotonic()-begun,failure=type(error).__name__+': '+str(error));(r/(name+'-traceback.txt')).write_text(traceback.format_exc())
    records.append(row);print(json.dumps(row),flush=True)
collect('surface',lambda:surface_step(pack,soil,v[0],a,u[11],u[12],exchange,canopy_condensate=water,root_weights=v[3:],infiltration_parameters=infiltration,**options))
liquid=soil.liquid;supply=SoilWaterSupply(np.maximum(liquid-props.smcwlt*1000.*soil.dz,0.)/v[0],v[3:],liquid[0]/v[0]);ground=float(raw['output/ground_temperature'][0])
collect('fixed-ground-phase',lambda:solve_canopy_phase_energy(a,u[11],u[12],exchange,water,v[0],soil_supply=supply,root_enthalpy=334000.+4180.*(soil.temperature-TF),fixed_ground_temperature=ground,ground_is_ice=bool(ground<TF),ground_shares_soil=not n,snowpack=pack,ground_evaporation_limit=pack.mass[0]/v[0] if n else np.inf,tolerance=1e-7,**options))
np.savez_compressed(r/'numpy-diagnostics.npz',**outputs);d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,records=records,seconds=time.monotonic()-start,source_unchanged=all(sha(s/n)==h for n,h in m.items()),source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_archive_sha256=package['archive_sha256'],scope='Independent NumPy currentCN on originalquantized failedCUDA356 surfaceinput/profile/optics/stem/extension. Fullsurface and prescribed actualCUDAgroundtemperature phase reference; CPU derives its ownfloat64 soil supply/rootenthalpy from samecellinputs, not identicalGPUinnercontext. Exceptions retained, no input/gate/source edit, failedyear notresumed. Diagnostic delivery not annual/science/convergencepass.');(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert d['source_unchanged']

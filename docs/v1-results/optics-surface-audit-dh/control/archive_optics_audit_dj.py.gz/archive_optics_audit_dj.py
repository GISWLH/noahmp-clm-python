from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'optics-surface-audit-dh';assert (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and len(d['records'])==2 and all(v['returned'] for v in d['records']);a=b/'optics-surface-audit-dh-evidence.tar.gz';assert not a.exists();items=[(p,'audit/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['dispatch_optics_surface_dh.py',Path(__file__).name])
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

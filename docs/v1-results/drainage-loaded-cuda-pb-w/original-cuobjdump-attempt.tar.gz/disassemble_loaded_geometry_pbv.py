"""Static cuobjdump on exact archived ELF bytes; no CUDA execution or compile."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

ROOT=Path('/tmp/noahmp-geometry-pbv-disassembly-qd')
TOOL='/usr/local/cuda-12.4/bin/cuobjdump'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main():
    assert Path(__file__).resolve()==ROOT/'disassemble_loaded_geometry_pbv.py'
    proof=json.loads((ROOT/'EXTRACTION_PROOF.json').read_bytes())
    index={r['extracted_file']:r['extracted_ELF_sha256'] for r in proof['extracted'].values()}
    assert all(sha((ROOT/n).read_bytes())==h for n,h in index.items())
    receipt=dict(static_disassembly=True,recompiled=False,GPU_calls=0,NumPy_imports=0,commands=[])
    for label,command in [('cuobjdump-version',[TOOL,'--version'])]+[(name.removesuffix('.cubin')+'-'+kind,
            [TOOL,flag,str(ROOT/name)]) for name in index for kind,flag in (('sass','--dump-sass'),('ptx','--dump-ptx'))]:
        started=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=120)
        (ROOT/(label+'.stdout.txt')).write_bytes(r.stdout);(ROOT/(label+'.stderr.txt')).write_bytes(r.stderr)
        receipt['commands'].append(dict(label=label,command=command,actual_exit=r.returncode,seconds=time.monotonic()-started,
            stdout_sha256=sha(r.stdout),stdout_bytes=len(r.stdout),stderr_sha256=sha(r.stderr),stderr_bytes=len(r.stderr)))
    receipt['input_ELF_hashes_unchanged']=all(sha((ROOT/n).read_bytes())==h for n,h in index.items())
    (ROOT/'DISASSEMBLY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    target=ROOT/'disassembly-result.tar.gz';assert not target.exists()
    paths=sorted(p for p in ROOT.iterdir() if p.is_file())
    with tarfile.open(target,'w:gz') as archive:
        for p in paths:archive.add(p,arcname=p.name,recursive=False)
    print(json.dumps(dict(archive_sha256=sha(target.read_bytes()),archive_bytes=target.stat().st_size,receipt=receipt)))

if __name__=='__main__':main()

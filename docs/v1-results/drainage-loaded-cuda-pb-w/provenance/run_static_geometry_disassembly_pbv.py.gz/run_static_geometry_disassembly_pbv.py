"""Unique remote static disassembly lifecycle; retain all real command exits."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
DEST=BASE/'drainage-geometry-pb-v-loaded-cuda-disassembly'
REMOTE='/tmp/noahmp-geometry-pbv-disassembly-qd'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main():
    target=DEST/'DEPLOYMENT.json';assert not target.exists()
    files=[DEST/n for n in ('original-diagnosis.cubin','geometry-probe.cubin','EXTRACTION_PROOF.json')]
    files.append(BASE/'disassemble_loaded_geometry_pbv.py')
    commands=[['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang',
        'test ! -e '+REMOTE+' && mkdir '+REMOTE],
        ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12',*[str(p) for p in files],'xuanze-neiwang:'+REMOTE+'/'],
        ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang',
         '/home/lhwang/venvs/noahmp-phase3b/bin/python -B '+REMOTE+'/disassemble_loaded_geometry_pbv.py'],
        ['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12','xuanze-neiwang:'+REMOTE+'/disassembly-result.tar.gz',str(DEST)]]
    receipt=dict(static_only=True,GPU_calls=0,recompiled=False,actual_commands=[])
    expected=None
    for k,command in enumerate(commands):
        r=subprocess.run(command,capture_output=True,timeout=180)
        (DEST/(f'deploy-{k}.stdout')).write_bytes(r.stdout);(DEST/(f'deploy-{k}.stderr')).write_bytes(r.stderr)
        receipt['actual_commands'].append(dict(command=command,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr)))
        target.write_text(json.dumps(receipt,indent=2)+'\n')
        assert r.returncode==0,r.stderr.decode(errors='replace')
        if k==2:expected=json.loads(r.stdout)
    assert sha((DEST/'disassembly-result.tar.gz').read_bytes())==expected['archive_sha256']
    receipt['result']=expected;target.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(expected))

if __name__=='__main__':main()

"""Actual cache-ELF extraction and failed available-tool disassembly, stdlib only."""
from pathlib import Path
import gzip
import io
import json
import tarfile
from verify_drainage_1704_pc import files,sha

BASE=Path(__file__).resolve().parent
ROOT=BASE/'drainage-geometry-pb-v-loaded-cuda-disassembly'
LABEL='drainage-loaded-cuda-pb-w'
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()

def main():
    original_raw=(ROOT/'disassembly-result.tar.gz').read_bytes();original=files(original_raw)
    nv_raw=(ROOT/'nvdisasm-result.tar.gz').read_bytes();nv=files(nv_raw)
    assert sha(original_raw)=='ab23c05d02582509518ff88a4d02b9252459798d02a89e5e8e52e13f267f11f0'
    assert sha(nv_raw)=='b4fbf689c60cdc0a6ff87020b22c19907b98e7912ad2c1206b192ffaf2f74946'
    receipt=json.loads(original['DISASSEMBLY_RECEIPT.json']);nr=json.loads(nv['NVDISASM_RECEIPT.json'])
    assert [r['actual_exit'] for r in receipt['commands']]==[0,255,255,255,255]
    assert [r['actual_exit'] for r in nr['commands']]==[0,1,1]
    assert receipt['input_ELF_hashes_unchanged'] and nr['input_ELF_hashes_unchanged']
    assert receipt['GPU_calls']==nr['GPU_calls']==0 and not receipt['recompiled'] and not nr['recompiled']
    proof=json.loads((ROOT/'EXTRACTION_PROOF.json').read_bytes())
    assert original['EXTRACTION_PROOF.json']==(ROOT/'EXTRACTION_PROOF.json').read_bytes()
    for r in proof['extracted'].values():
        assert r['outer_sha1_checksum_verified']
        assert sha(original[r['extracted_file']])==r['extracted_ELF_sha256']
    readout=dict(static_work_completed=True,actual_disassembly_succeeded=False,GPU_calls=0,recompiled=False,
        original_GPU_source_sha256=proof['original_GPU_result_sha256'],actual_named_module_ELF_extracted=True,
        ELF_hashes_unchanged=True,extraction=proof['extracted'],
        cuobjdump_version=original['cuobjdump-version.stdout.txt'].decode(),cuobjdump_actual_returncodes=[255,255,255,255],
        cuobjdump_original_error=original['original-diagnosis-sass.stderr.txt'].decode(),
        cuobjdump_probe_error=original['geometry-probe-sass.stderr.txt'].decode(),
        nvdisasm_version=nv['nvdisasm-version.stdout.txt'].decode(),nvdisasm_actual_returncodes=[1,1],
        nvdisasm_original_error=nv['nvdisasm-original.stderr.txt'].decode(),nvdisasm_probe_error=nv['nvdisasm-probe.stderr.txt'].decode(),
        scope='Exact original successful PB-v CUDA-worker cache bytes were extracted by verified checksum/name header, without numerical decoding, compilation or GPU calls. Available12.4 tools could not disassemble the ELF bytes; failures remain unavailable evidence, not proof of archive corruption or a specific tool-version cause. Supplementary PTX remains not loaded and no correct-rounding result is asserted.')
    verification=dict(evidence_verified=True,disassembly_succeeded=False,local_or_remote_NumPy_imports=0,
        original_disassembly_result_sha256=sha(original_raw),nvdisasm_result_sha256=sha(nv_raw),
        original_GPU_result_sha256=proof['original_GPU_result_sha256'],actual_inputs_unchanged=True,
        tool_failures_preserved=True,model_or_scientific_acceptance=False)
    items={'original-cuobjdump-attempt.tar.gz':original_raw,'original-nvdisasm-attempt.tar.gz':nv_raw,
        'readout.json':encode(readout),'verification.json':encode(verification)}
    for p in ROOT.iterdir():
        if p.is_file() and not p.name.endswith('.tar.gz'):items['local-closure/'+p.name]=p.read_bytes()
    for n in ('extract_loaded_geometry_cubin_pbv.py','disassemble_loaded_geometry_pbv.py','run_static_geometry_disassembly_pbv.py',
        'disassemble_nvdisasm_geometry_pbv.py',Path(__file__).name):items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(sha256=sha(raw),bytes=len(raw)) for n,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for n,raw in sorted(items.items()):
                member=tarfile.TarInfo(n);member.size=len(raw);member.mode=0o644;archive.addfile(member,io.BytesIO(raw))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='Actual PB-v named-module cache ELF extraction with source/checksum/name/hash proof; existing cuobjdump4×255/nvdisasm2×1 retained. No GPU/compile/model/NumPy calls, successful disassembly, repair or numerical cause credit.')
    for suffix,value in (('readout',readout),('verification',verification),('package',package)):(BASE/(LABEL+'-'+suffix+'.json')).write_bytes(encode(value))
    print(json.dumps(package))

if __name__=='__main__':main()

"""Try the existing nvdisasm on exact captured ELF bytes; no GPU or compilation."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

ROOT=Path('/tmp/noahmp-geometry-pbv-disassembly-qd')
TOOL='/usr/local/cuda-12.4/bin/nvdisasm'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
proof=json.loads((ROOT/'EXTRACTION_PROOF.json').read_bytes());rows=[];outputs=[]
for label,args in [('version',['--version']),('original',['original-diagnosis.cubin']),('probe',['geometry-probe.cubin'])]:
    command=[TOOL,*[str(ROOT/x) if x.endswith('.cubin') else x for x in args]]
    if label!='version':
        original=proof['extracted']['original-diagnosis' if label=='original' else 'geometry-probe']
        assert sha((ROOT/original['extracted_file']).read_bytes())==original['extracted_ELF_sha256']
    r=subprocess.run(command,capture_output=True,timeout=120)
    for kind,raw in (('stdout',r.stdout),('stderr',r.stderr)):
        path=ROOT/(f'nvdisasm-{label}.{kind}.txt');assert not path.exists();path.write_bytes(raw);outputs.append(path)
    rows.append(dict(label=label,command=command,actual_exit=r.returncode,stdout_sha256=sha(r.stdout),stdout_bytes=len(r.stdout),
        stderr_sha256=sha(r.stderr),stderr_bytes=len(r.stderr)))
record=dict(static_disassembly=True,GPU_calls=0,recompiled=False,commands=rows,
    input_ELF_hashes_unchanged=all(sha((ROOT/r['extracted_file']).read_bytes())==r['extracted_ELF_sha256'] for r in proof['extracted'].values()))
path=ROOT/'NVDISASM_RECEIPT.json';assert not path.exists();path.write_text(json.dumps(record,indent=2)+'\n');outputs.append(path)
target=ROOT/'nvdisasm-result.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as archive:
    for p in outputs:archive.add(p,arcname=p.name,recursive=False)
print(json.dumps(dict(archive_sha256=sha(target.read_bytes()),archive_bytes=target.stat().st_size,receipt=record)))

"""Opaque ELF extraction from the actually captured CuPy named-module cache."""
from pathlib import Path
import hashlib
import json
import struct
import tarfile

BASE=Path(__file__).resolve().parent
DEST=BASE/'drainage-geometry-pb-v-loaded-cuda-disassembly'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def main():
    assert not DEST.exists();DEST.mkdir()
    path=BASE/'drainage-geometry-pb-v-gpu-closed/gpu-result.tar.gz'
    assert sha(path.read_bytes())=='f5221539e4ab7371171b1b67e4b488317e5157d62ddec002dd3d6792e0b6c9b9'
    with tarfile.open(path) as archive:data={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
    info=json.loads(data['cuda/device/compiler/compiler-info.json']);found={}
    for r in info['actual_private_cache_files']:
        if not r['path'].endswith('.cubin'):continue
        name='cuda/device/compiler/'+r['path'];raw=data[name]
        assert sha(raw)==r['sha256'] and len(raw)==r['bytes']
        assert hashlib.sha1(raw[40:]).hexdigest().encode()==raw[:40]
        payload=raw[40:]
        if not payload.startswith(b'\x93CUPYNE\0'):continue
        pos=8;count=struct.unpack_from('<I',payload,pos)[0];pos+=4;names=[]
        for _ in range(count):
            size=struct.unpack_from('<I',payload,pos)[0];pos+=4
            names.append(payload[pos:pos+size].decode());pos+=size
        if names==['geometry_probe']:label='geometry-probe'
        elif any('drainage_diagnosis' in n for n in names):label='original-diagnosis'
        else:continue
        assert label not in found;elf=payload[pos:];assert elf.startswith(b'\x7fELF')
        (DEST/(label+'-original-cache.bin')).write_bytes(raw)
        (DEST/(label+'.cubin')).write_bytes(elf)
        found[label]=dict(original_gpu_archive_path=name,original_cache_sha256=sha(raw),original_cache_bytes=len(raw),
            outer_sha1_checksum_verified=True,cache_names=names,ELF_absolute_byte_offset=40+pos,
            extracted_ELF_sha256=sha(elf),extracted_ELF_bytes=len(elf),extracted_file=label+'.cubin')
    assert set(found)=={'geometry-probe','original-diagnosis'}
    proof=dict(original_GPU_result_sha256=sha(path.read_bytes()),extracted=found,numerical_decoding=False,
        GPU_calls=0,recompilation=False,source='Exactly the cache files snapshotted by the actual successful CUDA worker; named module functions were called by its original diagnosis/probe paths')
    (DEST/'EXTRACTION_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof))

if __name__=='__main__':main()

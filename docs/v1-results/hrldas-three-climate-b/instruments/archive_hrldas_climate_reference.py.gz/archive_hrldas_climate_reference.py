"""Pack completed compute-local official runs into a few shared-home files."""
from pathlib import Path
import argparse,hashlib,json,shutil,tarfile
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('destination',type=Path);a=p.parse_args()
root=a.root.resolve();assert root.is_relative_to(Path('/tmp')) and root.name.startswith('noahmp-hrldas-three-climate-b-')
completed=json.loads((root/'completed.json').read_text());assert completed['runtime_unchanged']
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
packed=[]
for result in completed['results']:
    assert result['returncode']==0 and result['ldasout_files']==17521
    site=result['site'];directory=root/site
    for kind in ['forcing','output']:
        files=sorted((directory/kind).iterdir());archive=root/(site+'-'+kind+'.tar.gz')
        assert not archive.exists() and all(f.is_file() and not f.is_symlink() for f in files)
        manifest={f.name:sha(f) for f in files}
        with tarfile.open(archive,'w:gz') as t:
            for f in files:t.add(f,arcname=f.name,recursive=False)
        # Check every packed byte before relying on a compute-local archive.
        with tarfile.open(archive) as t:
            assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}==manifest
        packed.append(dict(site=site,kind=kind,file=archive.name,sha256=sha(archive),members=manifest))
(root/'packed-files.json').write_text(json.dumps(packed,indent=2)+'\n')
selected=[root/n for n in ['protocol.json','completed.json','packed-files.json']]
for result in completed['results']:
    directory=root/result['site'];selected += [directory/n for n in ['namelist.hrldas','prepared-manifest.json','run-receipt.json','audit.json','official.log']]
selected += [root/x['file'] for x in packed]
for name in ['prepare_hrldas_climate_reference.py','audit_hrldas_point_output.py','hrldas_three_climate_b.pbs','archive_hrldas_climate_reference.py']:
    selected.append(Path('/home/zhangyq/noahmp-v1')/name)
temporary=root/'hrldas-three-climate-b-evidence.tar.gz'
with tarfile.open(temporary,'w:gz') as t:
    for f in selected:t.add(f,arcname=f.relative_to(root).as_posix() if f.is_relative_to(root) else 'instruments/'+f.name,recursive=False)
assert not a.destination.exists();shutil.copyfile(temporary,a.destination);assert sha(temporary)==sha(a.destination)
print(json.dumps(dict(archive=str(a.destination),sha256=sha(a.destination),files=len(selected),bytes=a.destination.stat().st_size)))

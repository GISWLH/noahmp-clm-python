from pathlib import Path
import hashlib,json,os,sys
import pytest
b=Path('/home/lhwang/work/noahmp-v1');s=b/'canopy-capacity-gpu-a';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==527 and all(sha(s/n)==h for n,h in m.items());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(v.nodeid for v in session.items)
code=int(pytest.main(['--collect-only','-q','tests'],plugins=[Capture()]));assert code==0 and len(nodes)==len(set(nodes))==1326
gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];assert len(gpu)==357 and len(nodes)-len(gpu)==969
expected=[n.split('/',1)[1] for n in gpu if Path(n.split('::')[0]).name=='test_gpu_canopy_capacity.py'];assert len(expected)==3
barriers=[]
for name in ['jax','cupy']:
    if name in sys.modules:
        if name=='jax':sys.modules[name].effects_barrier()
        else:sys.modules[name].cuda.runtime.deviceSynchronize()
        barriers.append(name)
assert all(sha(s/n)==h for n,h in m.items());d=dict(returncode=code,nodes=nodes,expected=expected,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),source_unchanged=True,device_barriers=barriers,scope='Actual collect-only1326=969CPU357GPU, not executionpass. Interpreteratexit bypass only after pytestreturn/barriers/durable receipt.')
with (r/'collection.json').open('x') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
(r/'expected.json').write_text(json.dumps(expected,indent=2)+'\n');sys.stdout.flush();sys.stderr.flush();os._exit(0)

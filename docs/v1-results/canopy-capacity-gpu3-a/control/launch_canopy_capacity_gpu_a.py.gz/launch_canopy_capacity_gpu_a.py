from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import tarfile

base = Path('/home/lhwang/work/noahmp-v1'); source = base / 'canopy-capacity-gpu-a'
assert not source.exists()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
package = json.loads((base / 'canopy-capacity-gpu-a-package.json').read_text())
archive = base / 'canopy-capacity-gpu-a-source.tar.gz'; assert sha(archive) == package['archive_sha256']
numpy_receipt = base / 'canopy-capacity-numpy-b-receipt.json'
assert sha(numpy_receipt) == package['numpy_receipt_sha256']
receipt = json.loads(numpy_receipt.read_text())
assert receipt['returncode'] == 0 and receipt['source_unchanged'] and receipt['counts'] == dict(tests=41, failures=0, errors=0, skipped=0)
assert sha(base / 'canopy-capacity-reference-b.json') == package['reference_receipt_sha256']
free = int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
assert free > 6144
memory = dict(row.split(':',1) for row in Path('/proc/meminfo').read_text().splitlines())
assert int(memory['MemAvailable'].split()[0]) > 12*1024*1024
source.mkdir()
with tarfile.open(archive) as tf: tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 527 and all(sha(source / name) == h for name,h in manifest.items())
assert sha(source / 'SOURCE_SHA256.json') == package['manifest_sha256']
root = source / 'target-a'; root.mkdir()
env = os.environ.copy(); env.pop('LD_LIBRARY_PATH', None)
env.update(PYTHONPATH=':'.join(map(str,[source, source/'src', source/'tests', source/'benchmarks'])),
           PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='0', CUDA_PATH='/usr/local/cuda-12.4',
           PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true', XLA_PYTHON_CLIENT_PREALLOCATE='false',
           JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NOAHMP_REQUIRE_GPU='1')
with (root/'controller.log').open('x') as log:
    child = subprocess.Popen([sys.executable,'-u',str(base/'control_canopy_capacity_gpu_a.py')],cwd=source,env=env,
                             stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record = dict(scope=package['scope'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=child.pid,
              device=0,free_gpu_mib=free,source_archive_sha256=sha(archive),source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),
              controls_sha256={name:sha(base/name) for name in ['collect_canopy_capacity_gpu_a.py','control_canopy_capacity_gpu_a.py',Path(__file__).name]})
(root/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

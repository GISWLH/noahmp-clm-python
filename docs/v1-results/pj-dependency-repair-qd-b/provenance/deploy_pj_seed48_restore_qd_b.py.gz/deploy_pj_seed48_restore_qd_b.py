"""Execute one authorized dependency-byte restore per independent TMP filesystem."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'pj-seed48-restore-qd-b-deployment'
PAYLOAD=BASE/'pj-seed48-restore-qd-b.tar.gz'
EXPECTED='ad952e1f5b5071e50595b2adc53b97281dc99a777a2a7bfc1d749ae6ae25faae'
REMOTE='/tmp/pj-seed48-restore-qd-b.tar.gz'
PYTHON='/home/zhangyq/venvs/noahmp-closeout/bin/python'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    assert not OUT.exists() and sha(PAYLOAD.read_bytes())==EXPECTED;OUT.mkdir()
    script=(BASE/'restore_pj_seed48_and_archive_zero_step_qd_b.py').read_bytes()
    def run(host):
        folder=OUT/host;folder.mkdir()
        def call(label,command,body=None):
            start=time.monotonic();result=subprocess.run(command,input=body,capture_output=True,timeout=240)
            (folder/(label+'.stdout')).write_bytes(result.stdout);(folder/(label+'.stderr')).write_bytes(result.stderr)
            receipt=dict(command=command,actual_exit=result.returncode,seconds=time.monotonic()-start,
                stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr),script_sha256=sha(body) if body else None)
            (folder/(label+'-exit.json')).write_text(json.dumps(receipt,indent=2)+'\n')
            assert result.returncode==0,(host,label,result.stderr.decode(errors='replace'))
            return result.stdout
        ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12',host]
        call('preflight',ssh+['test ! -e '+REMOTE+' && test ! -e /tmp/noahmp-pj-capacity-failure-qd-audit-1831-1838'])
        call('upload',['scp','-O','-o','BatchMode=yes','-o','ConnectTimeout=12',str(PAYLOAD),host+':'+REMOTE])
        remote_sha=call('payload-hash',ssh+['sha256sum '+REMOTE]).decode().split()[0];assert remote_sha==EXPECTED
        output=call('restore-and-preserve',ssh+[shlex.join([PYTHON,'-B','-'])],script)
        report=json.loads(output);assert report['passed'] and len(report['restored_seeds'])==8 and len(report['preserved_failure_directories'])==8
        return dict(host=host,actual_exit=0,receipt_sha256=sha(output),original36_stage_files_exact=report['original36_stage_files_exact'],
            free_bytes=report['free_bytes'],free_inodes=report['free_inodes'])
    with ThreadPoolExecutor(max_workers=2) as pool:
        for receipt in pool.map(run,['ehpc','ehpc-c2']):print(json.dumps(receipt),flush=True)


if __name__=='__main__':main()

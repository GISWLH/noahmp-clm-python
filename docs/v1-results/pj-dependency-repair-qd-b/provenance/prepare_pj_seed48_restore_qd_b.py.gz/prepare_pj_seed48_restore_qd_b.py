"""Select eight original opaque seed archives and prove both independent copies."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='pj-seed48-restore-qd-b'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    stage=BASE/'numpy-baseline-resume-pj-stage-b.tar.gz'
    assert sha(stage.read_bytes())=='9b5af7ba849d9101c1f7455e27342db945066ed022a4f58e1e2cb2329d7441bb'
    proof=json.loads((BASE/'pj-closed-archives-20261026-qa-verified.json').read_bytes())
    assert proof['passed'] and proof['opaque_containers_verified']==174
    assert proof['archive_sha256']=='e45de1899393b010dcc81691cd9eb86323e5e410c9d4a67ec79c4c4fffd03cf4'
    backup=Path(proof['archive']);assert backup.stat().st_size==proof['archive_bytes']
    audits={host:json.loads((BASE/'pj-zero-step-failures-qd-b-audit'/name).read_bytes()) for host,name in [('manager','ehpc.json'),('compute002','ehpc-c2.json')]}
    items={};records={}
    with tarfile.open(stage) as t,backup.open('rb') as independent:
        index_raw=t.extractfile('STAGE_SHA256.json').read();index=json.loads(index_raw);assert len(index)==36
        assert all(a['stage_index_sha256']==sha(index_raw) and a['original_stage_index']==index for a in audits.values())
        for i in range(8):
            name='closed/case-'+str(i)+'/stop-0000048.tar.gz';raw=t.extractfile(name).read()
            digest=sha(raw);prior=proof['containers'][name]
            assert len(raw)==prior['bytes'] and digest==index[name]==prior['sha256']
            independent.seek(prior['tar_payload_offset']);copied=independent.read(prior['bytes'])
            assert copied==raw and sha(copied)==digest
            items[name]=raw
            records[name]=dict(sha256=digest,bytes=len(raw),independent_backup_payload_offset=prior['tar_payload_offset'],
                original_stage_index_exact=True,independent_35GB_backup_payload_byte_exact=True)
    assert audits['manager']['latest_parents']==audits['compute002']['latest_parents']
    items['manager-audit.json']=(BASE/'pj-zero-step-failures-qd-b-audit/ehpc.json').read_bytes()
    items['compute002-audit.json']=(BASE/'pj-zero-step-failures-qd-b-audit/ehpc-c2.json').read_bytes()
    binding=dict(original_stage_archive_sha256=sha(stage.read_bytes()),original_stage_index_sha256=sha(index_raw),
        original_backup_archive_sha256=proof['archive_sha256'],original_backup_proof_sha256=sha((BASE/'pj-closed-archives-20261026-qa-verified.json').read_bytes()),
        original_progress_sha256=audits['manager']['original_progress_sha256'],seeds=records,
        audits={host:sha(items[host+'-audit.json']) for host in audits},latest_parents=audits['manager']['latest_parents'],
        authorized_scope='Restore only original eight closed initial48 files, preserve/rename only eight verified0-step1831--1838 failure directories per host, keep all latest parents/source/control/gates unchanged.')
    items['RESTORE_BINDINGS.json']=encode(binding)
    items['PAYLOAD_SHA256.json']=encode({n:sha(b) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,members=len(items),binding=binding)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps({k:package[k] for k in ('archive','sha256','bytes','members')}))


if __name__=='__main__':main()

"""Use authenticated already-observed terminal receipts for offline manager repair."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

BASE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    original=(BASE/'restore_pj_seed48_and_archive_zero_step_qd_b.py').read_bytes()
    before=b"    host=socket.gethostname();assert host in ('manager','compute002')"
    after=b"    host=socket.gethostname();assert host=='manager'"
    assert original.count(before)==1
    changed=original.replace(before,after)
    oldcheck=b"            result=subprocess.run(['qstat','-fx',case['job']],capture_output=True);assert result.returncode==0\n            for key,value in (('job_state','F'),('Exit_status','1'),('Stageout_status','0')):\n                assert re.search(rb'^\\s*'+key.encode()+rb' = '+value.encode()+rb'\\s*$',result.stdout,re.M)"
    newcheck=b"            terminal_stdout=case['qstat_stdout'].encode()\n            assert sha(terminal_stdout)==case['qstat_sha256']\n            for key,value in (('job_state','F'),('Exit_status','1'),('Stageout_status','0')):\n                assert re.search(rb'^\\s*'+key.encode()+rb' = '+value.encode()+rb'\\s*$',terminal_stdout,re.M)"
    assert changed.count(oldcheck)==1
    changed=changed.replace(oldcheck,newcheck)
    assert changed.replace(after,before).replace(newcheck,oldcheck)==original
    target=BASE/'restore_pj_manager_seed48_qd_b.py';assert not target.exists();target.write_bytes(changed);ast.parse(changed)
    (BASE/'restore_pj_manager_seed48_qd_b.diff').write_bytes(''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile='initial-two-host-metadata-repair',tofile='manager-only-already-verified-terminals')).encode())
    proof=dict(original_sha256=sha(original),manager_only_sha256=sha(changed),other_metadata_restore_algorithm_byte_exact=True,
        scope='Manager only. PBS service refused connection before original repair wrote anything. Already executed/hash-bound original1831--1838F1/Stageout0 qstat receipts authorize metadata-only restore. Live /proc guards, all per-file hashes, exclusive seed writes and full36 stage checks unchanged. Physical resume preflight still requires restored PBS originalF0 parent observations.')
    (BASE/'restore_pj_manager_seed48_qd_b-static.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))


if __name__=='__main__':main()

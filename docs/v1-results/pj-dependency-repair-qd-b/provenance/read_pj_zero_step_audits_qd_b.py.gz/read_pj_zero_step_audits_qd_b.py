"""Read both hosts' immutable failure metadata in parallel, no mutation."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import shlex
import subprocess
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/'pj-zero-step-failures-qd-b-audit'
PYTHON='/home/zhangyq/venvs/noahmp-closeout/bin/python'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    assert not OUT.exists();OUT.mkdir()
    script=(BASE/'audit_pj_zero_step_failures_qd_b.py').read_bytes()
    def run(host):
        command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12',host,shlex.join([PYTHON,'-B','-'])]
        begin=time.monotonic();result=subprocess.run(command,input=script,capture_output=True,timeout=180)
        (OUT/(host+'.json')).write_bytes(result.stdout);(OUT/(host+'.stderr')).write_bytes(result.stderr)
        receipt=dict(actual_exit=result.returncode,command=command,script_sha256=sha(script),
            seconds=time.monotonic()-begin,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
        (OUT/(host+'-exit.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        assert result.returncode==0,(host,result.stderr.decode(errors='replace'))
        parsed=json.loads(result.stdout);assert len(parsed['cases'])==8
        return dict(host=host,**receipt)
    with ThreadPoolExecutor(max_workers=2) as pool:
        for receipt in pool.map(run,['ehpc','ehpc-c2']):print(json.dumps(receipt),flush=True)


if __name__=='__main__':main()

"""Continue capacity-stopped PJ windows; retain original progress and controls."""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import re
import socket
import subprocess
import time
import traceback

OLD = Path('/tmp/noahmp-numpy-baseline-resume-pj')
ROOT = Path('/tmp/noahmp-pj-capacity-resume-qd-b')
PROGRESS_SHA = '159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'
CONTROLLER_SHA = '6abd686c1f841660d7320354bd60ccd264f9632741df5792f799ea272e3db7ab'
CONTROLS_SHA = '0f044fd60a1c870396075f63e1f87ff724ada6362072fe882fcd43fe1e7c3770'
SOURCE_SHA = 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
sha = lambda b: hashlib.sha256(b).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4*1024**2), b''):
            h.update(block)
    return h.hexdigest()


def main(run):
    assert socket.gethostname() == 'manager'
    assert not Path('/proc/48727').exists(), 'Old controller must be absent'
    assert not (ROOT / 'CONTROLLER_STARTED.json').exists(), 'Never duplicate a resume'
    raw = (OLD / 'PROGRESS.json').read_bytes()
    assert sha(raw) == PROGRESS_SHA
    state = json.loads(raw)
    assert state['source_manifest_sha256'] == SOURCE_SHA
    backup = json.loads((ROOT / 'BACKUP_PROOF.json').read_bytes())
    assert backup['passed'] and backup['opaque_containers_verified'] == 174
    assert backup['archive_sha256'] == 'e45de1899393b010dcc81691cd9eb86323e5e410c9d4a67ec79c4c4fffd03cf4'
    original_stage = json.loads((OLD / 'STAGE_SHA256.json').read_bytes())
    for name, digest in original_stage.items():
        path = OLD / name
        if name.startswith('closed/') and not path.exists():
            assert backup['containers'][name]['sha256'] == digest
        else:
            assert file_sha(path) == digest, name
    controls_raw = (OLD / 'preparation/CONTROLS_SHA256.json').read_bytes()
    assert sha(controls_raw) == CONTROLS_SHA
    for name, digest in json.loads(controls_raw).items():
        assert file_sha(OLD / 'preparation' / name) == digest, name
    control = OLD / 'preparation/controller_pj.py'
    assert file_sha(control) == CONTROLLER_SHA
    spec = importlib.util.spec_from_file_location('unchanged_pj_controller', str(control))
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    fixed = json.loads((OLD / 'preparation/PJ_BINDINGS.json').read_bytes())
    cases = copy.deepcopy(state['cases'])
    assert len(cases) == 8 and len(fixed['identities']) == 8
    parents = []
    for i, case in enumerate(cases):
        assert case['case_index'] == i and case['identity'] == fixed['identities'][i]
        assert case['status'] == 'stopped' and case['error'].startswith("AssertionError: {'manager': {'available_bytes':")
        assert case['steps'] == [13488,13488,13008,13008,6768,6768,6768,6768][i]
        last = case['history'][-1]
        assert last['stop'] == case['steps'] and last['job'] == case['job']
        assert last['closed_archive_sha256'] == case['parent_archive_sha256']
        status = old.terminal(case['job'])
        assert status is not None, case['job']
        for key in ('Exit_status', 'Stageout_status'):
            assert re.search(rb'^\s*' + key.encode() + rb' = 0\s*$', status[0], re.M)
        parent = OLD / 'closed' / ('case-' + str(i)) / ('stop-' + str(case['steps']).zfill(7) + '.tar.gz')
        assert file_sha(parent) == case['parent_archive_sha256'] == backup['containers'][parent.relative_to(OLD).as_posix()]['sha256']
        assert not (OLD / 'actual' / ('case-' + str(i)) / ('start-' + str(case['steps']).zfill(7))).exists()
        # Original worker also refuses existing outputs. Check compute before any submission.
        future = OLD / 'raw' / ('case-' + str(i)) / ('start-' + str(case['steps']))
        check = subprocess.run(['ssh', 'compute002', 'test', '!', '-e', str(future)])
        assert check.returncode == 0, str(future)
        parents.append(dict(case=i, steps=case['steps'], sha256=case['parent_archive_sha256'], job=case['job']))
        case['capacity_resume'] = dict(previous_status=case['status'], previous_error=case.pop('error'),
            progress_sha256=PROGRESS_SHA, wrapper_sha256=file_sha(Path(__file__)))
        case['status'] = 'ready'
    available = old.capacity()  # Original 12GiB/20000inode assertion, unchanged.
    proof = dict(preflight_passed=True, parents=parents, capacity=available,
        original_progress_sha256=PROGRESS_SHA, original_controller_sha256=CONTROLLER_SHA,
        original_controls_sha256=CONTROLS_SHA, wrapper_sha256=file_sha(Path(__file__)),
        source_manifest_sha256=SOURCE_SHA, run_authorized=run,
        no_model_imports=True, original_progress_untouched=True)
    print(json.dumps(proof), flush=True)
    if not run:
        return
    with (ROOT / 'CONTROLLER_STARTED.json').open('x') as stream:
        json.dump(dict(pid=os.getpid(), start_ticks=int(Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]),
            preflight=proof, started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
            stop_at=17520, automatic_retry=False, automatic_cycle2=False),stream,indent=2)
    (ROOT / 'ORIGINAL_PROGRESS.json').write_bytes(raw)
    while any(c['status'] in ('ready', 'running') for c in cases):
        for case in cases:
            try:
                if case['status'] == 'running':
                    status = old.terminal(case['job'])
                    if status:
                        old.close(case, *status)
                if case['status'] == 'ready':
                    assert len(case['history']) < 37
                    old.submit(case)
            except Exception as exc:
                case.update(status='stopped', error=type(exc).__name__+': '+str(exc))
                (ROOT / ('case-' + str(case['case_index']) + '-error.txt')).write_text(traceback.format_exc())
                print(json.dumps(dict(event='stopped',case_index=case['case_index'],error=case['error'])),flush=True)
            old.save(ROOT / 'PROGRESS.json', dict(cases=cases, source_manifest_sha256=SOURCE_SHA,
                original_progress_sha256=PROGRESS_SHA, no_auto_retry=True, auto_cycle2=False,
                score_executed=False, actual_complete_years=sum(c['steps']==17520 for c in cases),
                snapshot_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
        if any(c['status'] in ('ready', 'running') for c in cases):
            time.sleep(60)
    done = all(c['steps'] == 17520 for c in cases)
    old.save(ROOT / 'CONTROLLER_FINISHED.json', dict(all_eight_complete=done, cases=cases,
        complete_original_years=sum(c['steps']==17520 for c in cases), score_executed=False, auto_cycle2=False))
    raise SystemExit(0 if done else 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true')
    main(parser.parse_args().run)

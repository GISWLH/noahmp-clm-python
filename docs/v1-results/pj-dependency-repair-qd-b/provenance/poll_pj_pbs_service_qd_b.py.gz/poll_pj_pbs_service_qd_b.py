"""Read the same two terminal handles without restarting any PBS service/job."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    out=BASE/'pj-pbs-service-qd-b'/sys.argv[1];assert not out.exists();out.mkdir(parents=True)
    code="""import subprocess,json,hashlib,time
results={}
for job in ('1831.manager','1813.manager'):
 r=subprocess.run(['qstat','-fx',job],capture_output=True,timeout=20)
 results[job]=dict(actual_exit=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest())
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),jobs=results,PBS_available=all(r['actual_exit']==0 for r in results.values())),indent=2))
"""
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc',shlex.join(['/home/zhangyq/venvs/noahmp-closeout/bin/python','-B','-'])]
    start=time.monotonic();result=subprocess.run(command,input=code.encode(),capture_output=True,timeout=60)
    (out/'snapshot.json').write_bytes(result.stdout);(out/'stderr').write_bytes(result.stderr)
    (out/'remote-reader.py').write_bytes(code.encode())
    receipt=dict(actual_ssh_exit=result.returncode,command=command,seconds=time.monotonic()-start,
        code_sha256=sha(code.encode()),stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
    (out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n');assert result.returncode==0
    snapshot=json.loads(result.stdout)
    print(json.dumps(dict(snapshot=out.name,PBS_available=snapshot['PBS_available'],jobs={j:r['actual_exit'] for j,r in snapshot['jobs'].items()},**receipt)))


if __name__=='__main__':main()

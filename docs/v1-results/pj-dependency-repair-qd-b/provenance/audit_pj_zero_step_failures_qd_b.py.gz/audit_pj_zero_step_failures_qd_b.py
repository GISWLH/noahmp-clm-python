"""Read original PJ1831--1838 failures and immutable metadata; no model imports."""
from pathlib import Path
import base64
import hashlib
import json
import os
import re
import socket
import subprocess
import sys
import tarfile

OLD=Path('/tmp/noahmp-numpy-baseline-resume-pj')
QD=Path('/tmp/noahmp-pj-capacity-resume-qd')
STEPS=[13488,13488,13008,13008,6768,6768,6768,6768]
PROGRESS_SHA='159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def file_sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def inventory(folder):
    assert folder.is_dir() and not folder.is_symlink()
    result={}
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            raw=path.read_bytes()
            result[path.relative_to(folder).as_posix()]=dict(bytes=len(raw),sha256=sha(raw),base64=base64.b64encode(raw).decode())
        else:assert path.is_dir()
    return result


def main():
    host=socket.gethostname();assert host in ('manager','compute002')
    assert not Path('/proc/48727').exists()
    if host=='manager':assert not Path('/proc/69080').exists()
    live=[]
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if proc.stat().st_uid!=os.getuid():continue
            command=(proc/'cmdline').read_bytes()
            if b'run_window_job_pj.py' in command or b'resume_capacity_pj_qd.py' in command:
                live.append(dict(pid=int(proc.name),cmdline=command.replace(b'\0',b' ').decode()))
        except (FileNotFoundError,PermissionError,ProcessLookupError):pass
    assert live==[],live
    index_raw=(OLD/'STAGE_SHA256.json').read_bytes();index=json.loads(index_raw);assert len(index)==36
    actual={n:file_sha(OLD/n) if (OLD/n).exists() else None for n in index}
    missing=[n for n,h in actual.items() if h is None]
    expected_missing=['closed/case-'+str(i)+'/stop-0000048.tar.gz' for i in range(8)]
    assert sorted(missing)==expected_missing
    assert all(actual[n]==h for n,h in index.items() if actual[n] is not None)
    parents={}
    for i,start in enumerate(STEPS):
        name='closed/case-'+str(i)+'/stop-'+str(start).zfill(7)+'.tar.gz'
        parents[name]=dict(sha256=file_sha(OLD/name),bytes=(OLD/name).stat().st_size)
    output=dict(host=host,old_controllers_absent=True,live_PJ_processes=live,stage_index_sha256=sha(index_raw),
        original_stage_index=index,original_stage_actual=actual,missing_initial48_archives=missing,latest_parents=parents,
        free_bytes=os.statvfs(OLD).f_bavail*os.statvfs(OLD).f_frsize,free_inodes=os.statvfs(OLD).f_favail,cases=[])
    if host=='manager':
        progress=(OLD/'PROGRESS.json').read_bytes();assert sha(progress)==PROGRESS_SHA
        current=json.loads((QD/'PROGRESS.json').read_bytes());finished=json.loads((QD/'CONTROLLER_FINISHED.json').read_bytes())
        assert not finished['all_eight_complete'] and len(current['cases'])==8
        output.update(original_progress_sha256=sha(progress),qd_progress_sha256=file_sha(QD/'PROGRESS.json'),
            qd_finished_sha256=file_sha(QD/'CONTROLLER_FINISHED.json'),qd_controller_sha256=file_sha(QD/'resume_capacity_pj_qd.py'))
        for i,case in enumerate(current['cases']):
            job=str(1831+i)+'.manager';assert case['case_index']==i and case['job']==job and case['status']=='stopped'
            assert case['steps']==case['start']==STEPS[i] and case['error']=='AssertionError: Actual nonzero Exit_status'
            qstat=subprocess.run(['qstat','-fx',job],capture_output=True);assert qstat.returncode==0
            for key,value in (('job_state','F'),('Exit_status','1'),('Stageout_status','0')):
                assert re.search(rb'^\s*'+key.encode()+rb' = '+value.encode()+rb'\s*$',qstat.stdout,re.M)
            folder=OLD/'actual'/('case-'+str(i))/('start-'+str(STEPS[i]).zfill(7))
            assert Path(case['actual_folder'])==folder
            output['cases'].append(dict(case_index=i,job=job,steps=STEPS[i],directory=str(folder),files=inventory(folder),
                qstat_stdout=qstat.stdout.decode(),qstat_stderr=qstat.stderr.decode(),qstat_sha256=sha(qstat.stdout)))
    else:
        for i,start in enumerate(STEPS):
            job=str(1831+i)+'.manager';folder=OLD/'raw'/('case-'+str(i))/('start-'+str(start))
            files=inventory(folder);assert (folder/'pbs-exit.txt').read_bytes().strip()==b'1'
            with tarfile.open(folder/'result.tar.gz') as t:
                originals={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
            receipt=json.loads(originals['receipt.json'])
            assert receipt['pbs_job']==job and receipt['case_index']==i and receipt['start']==start
            assert receipt['original_steps_started']==receipt['original_steps_completed']==0 and not receipt['passed']
            expected="FileNotFoundError: [Errno 2] No such file or directory: '/tmp/noahmp-numpy-baseline-resume-pj/closed/case-0/stop-0000048.tar.gz'"
            assert receipt['error']==expected,receipt['error']
            assert b'run_window_job_pj.py' in originals['PJ-traceback.txt'] and b'stage_index.items()' in originals['PJ-traceback.txt']
            assert originals['worker-exit.txt'].strip()==b'1'
            output['cases'].append(dict(case_index=i,job=job,steps=start,directory=str(folder),files=files,
                receipt=receipt,result_sha256=sha((folder/'result.tar.gz').read_bytes()),
                original_result_members={n:dict(bytes=len(b),sha256=sha(b)) for n,b in originals.items()}))
    print(json.dumps(output,indent=2,allow_nan=False))


if __name__=='__main__':main()

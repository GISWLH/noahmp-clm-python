"""Restore original dependency bytes and atomically retain eight zero-step failures."""
from pathlib import Path
import hashlib
import io
import json
import os
import re
import socket
import subprocess
import tarfile
import traceback

OLD=Path('/tmp/noahmp-numpy-baseline-resume-pj')
AUDIT=Path('/tmp/noahmp-pj-capacity-failure-qd-audit-1831-1838')
PAYLOAD=Path('/tmp/pj-seed48-restore-qd-b.tar.gz')
EXPECTED='ad952e1f5b5071e50595b2adc53b97281dc99a777a2a7bfc1d749ae6ae25faae'
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def file_sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def inventory(folder):
    assert folder.is_dir() and not folder.is_symlink()
    result={}
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():result[path.relative_to(folder).as_posix()]=dict(bytes=path.stat().st_size,sha256=file_sha(path))
        else:assert path.is_dir()
    return result


def no_live_processes(host):
    assert not Path('/proc/48727').exists()
    if host=='manager':assert not Path('/proc/69080').exists()
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if proc.stat().st_uid!=os.getuid():continue
            command=(proc/'cmdline').read_bytes()
            assert b'run_window_job_pj.py' not in command and b'resume_capacity_pj_qd.py' not in command,(proc.name,command)
        except (FileNotFoundError,PermissionError,ProcessLookupError):pass


def main():
    host=socket.gethostname();assert host=='manager'
    assert OLD.resolve()==OLD and not AUDIT.exists() and AUDIT.parent.resolve()==Path('/tmp')
    no_live_processes(host)
    raw=PAYLOAD.read_bytes();assert sha(raw)==EXPECTED
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        members=t.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        files={m.name:t.extractfile(m).read() for m in members};assert len(files)==len(members)==12
    index=json.loads(files['PAYLOAD_SHA256.json']);assert set(index)==set(files)-{'PAYLOAD_SHA256.json'}
    assert all(sha(files[n])==h for n,h in index.items())
    binding=json.loads(files['RESTORE_BINDINGS.json']);audit=json.loads(files[host+'-audit.json'])
    assert sha(files[host+'-audit.json'])==binding['audits'][host]
    stage_raw=(OLD/'STAGE_SHA256.json').read_bytes();stage=json.loads(stage_raw);assert len(stage)==36
    assert sha(stage_raw)==binding['original_stage_index_sha256'] and stage==audit['original_stage_index']
    assert host==audit['host'] and len(audit['cases'])==8
    for name,digest in stage.items():
        if name in binding['seeds']:assert not (OLD/name).exists()
        else:assert file_sha(OLD/name)==digest
    for name,metadata in binding['latest_parents'].items():
        assert file_sha(OLD/name)==metadata['sha256'] and (OLD/name).stat().st_size==metadata['bytes']
    if host=='manager':
        assert file_sha(OLD/'PROGRESS.json')==binding['original_progress_sha256']
        for case in audit['cases']:
            terminal_stdout=case['qstat_stdout'].encode()
            assert sha(terminal_stdout)==case['qstat_sha256']
            for key,value in (('job_state','F'),('Exit_status','1'),('Stageout_status','0')):
                assert re.search(rb'^\s*'+key.encode()+rb' = '+value.encode()+rb'\s*$',terminal_stdout,re.M)
    for case in audit['cases']:
        source=Path(case['directory']);relative=source.relative_to(OLD)
        assert source.resolve()==source and relative.parts[0]==('actual' if host=='manager' else 'raw')
        expected={n:dict(bytes=r['bytes'],sha256=r['sha256']) for n,r in case['files'].items()}
        assert inventory(source)==expected
        if host=='compute002':
            assert case['receipt']['original_steps_started']==case['receipt']['original_steps_completed']==0
    report=dict(host=host,payload_sha256=EXPECTED,restored_seeds=[],preserved_failure_directories=[],
        latest_parent_hashes_unchanged=False,original36_stage_files_exact=False,source_or_control_changes=0,
        physical_calls=0,deletions=0,overwrite_operations=0,passed=False)
    AUDIT.mkdir()
    (AUDIT/'BEFORE_AUDIT.json').write_bytes(files[host+'-audit.json'])
    (AUDIT/'RESTORE_BINDINGS.json').write_bytes(files['RESTORE_BINDINGS.json'])
    try:
        for name,metadata in sorted(binding['seeds'].items()):
            target=OLD/name
            assert target.parent.resolve().is_relative_to(OLD/'closed') and not target.exists() and not target.is_symlink()
            assert sha(files[name])==metadata['sha256']==stage[name] and len(files[name])==metadata['bytes']
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:
                stream.write(files[name]);stream.flush();os.fsync(stream.fileno())
            assert file_sha(target)==metadata['sha256']
            report['restored_seeds'].append(dict(path=str(target),**metadata))
        assert all(file_sha(OLD/name)==digest for name,digest in stage.items())
        report['original36_stage_files_exact']=True
        no_live_processes(host)
        for case in audit['cases']:
            source=Path(case['directory']);relative=source.relative_to(OLD)
            target=AUDIT/'original-failure-directories'/relative
            expected={n:dict(bytes=r['bytes'],sha256=r['sha256']) for n,r in case['files'].items()}
            assert inventory(source)==expected and not target.exists()
            target.parent.mkdir(parents=True,exist_ok=True)
            assert source.resolve().is_relative_to(OLD/relative.parts[0])
            assert target.parent.resolve().is_relative_to(AUDIT) and target.parent.stat().st_dev==source.parent.stat().st_dev
            source.rename(target)
            assert not source.exists() and inventory(target)==expected
            report['preserved_failure_directories'].append(dict(case_index=case['case_index'],job=case['job'],
                original_path=str(source),new_audit_path=str(target),files=expected,rename_same_filesystem=True,byte_exact_after=True))
        for name,metadata in binding['latest_parents'].items():assert file_sha(OLD/name)==metadata['sha256']
        report['latest_parent_hashes_unchanged']=True
        report['original36_stage_files_exact']=all(file_sha(OLD/name)==digest for name,digest in stage.items())
        available=os.statvfs(OLD)
        report.update(free_bytes=available.f_bavail*available.f_frsize,free_inodes=available.f_favail)
        assert report['free_bytes']>=12*1024**3 and report['free_inodes']>=20000
        report['passed']=True
    except BaseException:
        report['exception']=traceback.format_exc()
        raise
    finally:
        (AUDIT/'REPAIR_RECEIPT.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
        print(json.dumps(report,indent=2,allow_nan=False),flush=True)


if __name__=='__main__':main()

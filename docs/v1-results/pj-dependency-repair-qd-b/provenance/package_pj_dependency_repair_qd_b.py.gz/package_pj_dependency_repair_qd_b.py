"""Seal zero-step original failures, byte restoration, renames and live PBS outage."""
from pathlib import Path
import base64
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='pj-dependency-repair-qd-b'
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,indent=2)+'\n').encode()


def main():
    proof=json.loads((BASE/'pj-capacity-resume-qd-b-preparation/METADATA_REPAIR_PROOF.json').read_bytes())
    assert proof['passed'] and not proof['controller_launched']
    for host in ('manager','compute002'):
        row=proof[host]
        assert row['passed'] and row['original36_stage_files_exact'] and row['latest_parent_hashes_unchanged']
        assert len(row['restored_seeds'])==len(row['preserved_failure_directories'])==8
        assert row['deletions']==row['overwrite_operations']==row['physical_calls']==0
    audits={host:json.loads((BASE/'pj-zero-step-failures-qd-b-audit'/name).read_bytes()) for host,name in [('manager','ehpc.json'),('compute002','ehpc-c2.json')]}
    items={'readout.json':encode(proof),
        'SCOPE.md':b'Original1831--1838 all actualF1/Stageout0 and0 started/completed physical steps: original worker attempted its unconditional36-entry stage inventory and found original initial48 seed archive missing. Complete failed directories are retained in original bytes. Restore only8 original opaque closed48 containers, each matching original stage index and direct independent35GB backup payload. Both hosts now verify36/36 original entries, latest8 parent SHA unchanged and original capacity gate met. Per-host8 original failed folders were hashed then atomically renamed under a fresh audit root; no deletion/overwrite/source/control/gate change. Original first manager attempt stopped before writes when PBS server refused connection; compute success was never repeated. Manager subsequently used hash-bound already-observed terminal receipts for metadata only. New qd-b wrapper is prepared, not deployed/launched; actual PBS availability and original8F0 parents remain mandatory before any new physical submission.\n'}
    for host,audit in audits.items():
        for case in audit['cases']:
            for name,metadata in case['files'].items():
                raw=base64.b64decode(metadata['base64']);assert len(raw)==metadata['bytes'] and sha(raw)==metadata['sha256']
                items['original-failure-directories/'+host+'/case-'+str(case['case_index'])+'/'+name]=raw
            if host=='manager':
                qstat=case['qstat_stdout'].encode();assert sha(qstat)==case['qstat_sha256']
                items['original-terminals/'+case['job']+'/qstat.stdout']=qstat
            else:assert case['receipt']['original_steps_started']==case['receipt']['original_steps_completed']==0
    for foldername in ('pj-zero-step-failures-qd-b-audit','pj-seed48-restore-qd-b-deployment','pj-capacity-resume-qd-b-preparation','pj-pbs-service-qd-b'):
        folder=BASE/foldername
        items.update({foldername+'/'+p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file()})
    filenames=['pj-seed48-restore-qd-b.tar.gz','pj-seed48-restore-qd-b-package.json','numpy-baseline-resume-pj-stage-b.tar.gz',
        'pj-capacity-resume-qd-status-second.json','resume_capacity_pj_qd.py','resume_capacity_pj_qd_b.py','resume_capacity_pj_qd_b.diff',
        'resume_capacity_pj_qd_b-static.json','review_resume_capacity_pj_qd_surface_agent.json','review_resume_capacity_pj_qd_surface_agent_correction.json',
        'audit_pj_zero_step_failures_qd_b.py','read_pj_zero_step_audits_qd_b.py','prepare_pj_seed48_restore_qd_b.py',
        'restore_pj_seed48_and_archive_zero_step_qd_b.py','deploy_pj_seed48_restore_qd_b.py','prepare_pj_manager_seed48_qd_b.py',
        'restore_pj_manager_seed48_qd_b.py','restore_pj_manager_seed48_qd_b.diff','restore_pj_manager_seed48_qd_b-static.json',
        'poll_pj_pbs_service_qd_b.py',Path(__file__).name]
    for name in filenames:items['provenance/'+name]=(BASE/name).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,data in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data);t.addfile(entry,io.BytesIO(data))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),
        scope='All8 original zero-stepF1/Stageout0 failures retained; only original8 seed dependencies restored on both hosts;36stage entries exact/latest parents unchanged,16 failure folders byte-exact renamed; PBS connection refused, new qd-b physical controller not yet launched. No physical retry credit or scientific acceptance.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

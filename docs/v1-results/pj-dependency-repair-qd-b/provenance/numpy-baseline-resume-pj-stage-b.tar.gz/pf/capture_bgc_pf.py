"""Read-only observation of original CPU BGC returns, in immutable48-step blocks."""
from pathlib import Path
import hashlib
import json
import pickle
import zipfile

import own_spinup_pf as pf


class BGCRecorder:
    """Wrap one existing runner call; preserve original input and returned objects."""
    def __init__(self, runner, identity, starts, ends, output, *, start_index=0):
        pf.require(type(start_index) is int and 0 <= start_index < identity['steps'], 'Explicit original interval index required')
        pf.require(identity['backend'] == 'numpy64' and identity['source_manifest_sha256'] == pf.bindings()['source_manifest_sha256'],
                   'Capture source/backend differs')
        pf.require(len(starts) == len(ends) == identity['steps'], 'Capture needs the exact full requested calendar')
        pf.contract.calendar_summary(starts, ends, 1800, full_year=not identity['test_only'])
        self.runner, self.identity = runner, identity
        self.starts, self.ends = starts, ends
        self.output = Path(output)
        pf.require(not self.output.exists(), 'Preserve previous BGC stream')
        self.output.mkdir(parents=True)
        self.index, self.start = start_index, start_index
        self.pending, self.blocks = [], []
        self.original = None
        self.previous_bgc = None

    def _flush(self):
        if not self.pending:
            return
        name = 'bgc-' + str(self.pending[0][0]).zfill(7) + '-' + str(self.pending[-1][0] + 1).zfill(7) + '.zip'
        path = self.output / name
        with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED) as archive:
            for index, body in self.pending:
                archive.writestr(str(index).zfill(7) + '.pkl', body)
        self.blocks.append(dict(file=name, sha256=pf.sha(path.read_bytes()), count=len(self.pending),
                               first_index=self.pending[0][0], stop_index=self.pending[-1][0] + 1))
        self.pending = []

    def _call(self, before, forcing, **kwargs):
        after, diagnostics = self.original(before, forcing, **kwargs)
        pf.require(self.index < self.identity['steps'] and forcing.dt == 1800, 'Capture count/dt differs')
        pf.require(before.bgc_state is not None and after.bgc_state is not None, 'Normal BGC state required')
        pf.require(before.crop_state is None and before.wetland_state is None,
                   'Current original OM stream has no crop/wetland litter or oxygen alteration')
        bgc = diagnostics['biogeochemistry']
        prescribed = dict(temperature_k=bgc['environment']['soil_temperature'],
            water_potential_mpa=bgc['environment']['water_potential_mpa'],
            litter_carbon_gc_m2=bgc['turnover']['litter_carbon_gc_m2'],
            litter_nitrogen_gn_m2=bgc['turnover']['litter_nitrogen_gn_m2'],
            mineral_n_input_gn_m2=kwargs['nitrogen_deposition_gn_m2'],
            plant_n_demand_gn_m2=bgc['allocation']['soil_n_demand_gn_m2'])
        pf.adapter.assert_content_exact(prescribed['mineral_n_input_gn_m2'], bgc['nitrogen_deposition_gn_m2'], self.runner.np)
        if self.previous_bgc is not None:
            pf.adapter.assert_content_exact(before.bgc_state, self.previous_bgc, self.runner.np)
        record = dict(index=self.index, time_start=str(self.starts[self.index]), time_end=str(self.ends[self.index]),
            identity=self.identity, before_bgc=before.bgc_state, after_bgc=after.bgc_state,
            bgc_parameters=before.bgc_parameters, forcing=forcing, original_kwargs=kwargs,
            original_bgc_diagnostic=bgc, prescribed=prescribed,
            actual_plant_uptake_gn_m2=bgc['decomposition']['plant_uptake_gn_m2'],
            original_exchanges={key: diagnostics[key] for key in ('gpp_gc_m2', 'autotrophic_respiration_gc_m2',
                'heterotrophic_respiration_gc_m2', 'nee_gc_m2')}, oxygen_factor=1.)
        self.pending.append((self.index, pickle.dumps(record, protocol=5)))
        self.previous_bgc = after.bgc_state
        self.index += 1
        if len(self.pending) == 48:
            self._flush()
        return after, diagnostics  # return the exact original objects, without numerical changes

    def __enter__(self):
        self.original = self.runner.step_clm_enthalpy_column
        self.runner.step_clm_enthalpy_column = self._call
        return self

    def __exit__(self, kind, error, trace):
        self.runner.step_clm_enthalpy_column = self.original
        self._flush()
        header = dict(identity=self.identity, first_index=self.start, stop_index=self.index,
            successful_original_tendencies_recorded=self.index - self.start, blocks=self.blocks,
            original_call_completed_without_exception=kind is None,
            error=None if kind is None else kind.__name__ + ': ' + str(error),
            complete_requested_window=kind is None and self.index == self.identity['steps'],
            original_time_start_sha256=hashlib.sha256(self.starts.tobytes()).hexdigest(),
            original_time_end_sha256=hashlib.sha256(self.ends.tobytes()).hexdigest(),
            deposition_units='gN/m2 per original interval; never multiplied by dt again',
            demand_is_potential_not_uptake=True, new_initial_inventory_created=False,
            spinup_accepted=False, scientific_acceptance_claim=False)
        (self.output / 'BGC_STREAM.json').write_bytes(pf.contract.json_bytes(header))
        return False


def records(path):
    """Inspect exact saved records; no source stepping or reconstruction of demand."""
    root = Path(path)
    header = json.loads((root / 'BGC_STREAM.json').read_bytes())
    index = header['first_index']
    for block in header['blocks']:
        raw = (root / block['file']).read_bytes()
        pf.require(pf.sha(raw) == block['sha256'], 'BGC immutable block changed')
        with zipfile.ZipFile(root / block['file']) as archive:
            names = archive.namelist()
            pf.require(names == [str(k).zfill(7) + '.pkl' for k in range(block['first_index'], block['stop_index'])],
                       'BGC block sequence differs')
            for name in names:
                row = pickle.loads(archive.read(name))
                pf.require(row['index'] == index and row['identity'] == header['identity'], 'BGC record chain identity differs')
                yield row
                index += 1
    pf.require(index == header['stop_index'] and index - header['first_index'] == header['successful_original_tendencies_recorded'],
               'BGC stream incomplete or count differs')

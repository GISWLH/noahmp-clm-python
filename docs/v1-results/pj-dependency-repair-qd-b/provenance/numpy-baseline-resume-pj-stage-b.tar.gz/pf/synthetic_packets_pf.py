"""Explicit nonphysical parser fixtures; never a candidate run or scheduler proof."""
from pathlib import Path
import io
import json
import pickle

import own_spinup_pf as pf


def write(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def jwrite(path, value):
    write(path, pf.contract.json_bytes(value))


def seal(root):
    index = {p.relative_to(root).as_posix(): pf.sha(p.read_bytes()) for p in sorted(root.rglob('*'))
             if p.is_file() and p != root / 'ARTIFACT_SHA256.json'}
    jwrite(root / 'ARTIFACT_SHA256.json', index)
    return dict(directory=str(root), inventory_sha256=pf.sha((root / 'ARTIFACT_SHA256.json').read_bytes()),
                run='run', terminals='terminals.json')


def full_cycle(runner, assembly, candidate, case, cycle, root, previous=None):
    """Constant-state/zero-flux full-calendar fixture: no normal model is run."""
    np = runner.np
    root = Path(root)
    identity = pf.contract.request(candidate, case, 'spinup', cycle)
    _, config, _ = pf.original_configuration(assembly, candidate, case)
    state = runner.build_state(config)
    saved = (state, runner.totals(state), np.zeros(4), np.zeros(4), np.zeros(4), np.zeros(4), identity['steps'])
    zero = saved[:6] + (0,)
    n = identity['steps']
    with np.load(io.BytesIO(assembly['year-inputs/' + identity['site'] + '-' + str(identity['year']) + '.npz'])) as z:
        time_start, time_end = z['time_start'], z['time_end']
    keys = (*runner.TRACE, *runner.structure_trace_keys(config), *runner.capacity_trace_keys(config),
            'swe_m', 'lai', 'tsoil_k', 'smc_m3m3', 'liquid_m3m3', 'step_residual_m_h_c_n',
            'step_bound_m_h_c_n', 'cumulative_residual_m_h_c_n')
    trace = {key: np.zeros(n) for key in keys}
    for key in ('step_residual_m_h_c_n', 'step_bound_m_h_c_n', 'cumulative_residual_m_h_c_n'):
        trace[key] = np.zeros((n, 4))
    for key, value in [('tsoil_k', state.tsoil), ('smc_m3m3', state.smc),
                       ('liquid_m3m3', state.ground.liquid / (1000. * state.ground.dz))]:
        trace[key] = np.broadcast_to(value, (n, len(value))).copy()
    trace['swe_m'][:] = state.swe
    trace.update(time_start=time_start, time_end=time_end)
    run = root / 'run'
    trajectory = run / 'trajectory'
    trajectory.mkdir(parents=True)
    cp = 'state-' + str(n).zfill(7) + '.pkl'
    tp = 'trace-' + str(n).zfill(7) + '.npz'
    write(trajectory / cp, pickle.dumps(saved))
    np.savez_compressed(trajectory / tp, **trace)
    report = dict(configuration=config, source_sha256=runner.source_hashes(), source_unchanged=True,
        status='complete', steps_completed=n, steps_requested=n, checkpoint_file=cp,
        checkpoint_sha256=pf.sha((trajectory / cp).read_bytes()), model_npz=tp,
        model_npz_sha256=pf.sha((trajectory / tp).read_bytes()),
        cumulative_numerical_bounds_m_h_c_n=[0.] * 4, maximum_cumulative_residual_m_h_c_n=[0.] * 4,
        maximum_step_residual_m_h_c_n=[0.] * 4,
        **{key: identity[key] for key in ('configuration_sha256', 'forcing_npz_sha256', 'forcing_manifest_sha256')})
    jwrite(trajectory / 'report.json', report)
    first = run / 'segment-0000000/start-originals'
    first.mkdir(parents=True)
    write(first / 'state-0000000.pkl', pickle.dumps(zero))
    np.savez_compressed(first / 'trace-0000000.npz', **{k: v[:0].copy() for k, v in trace.items()})
    zr = dict(report, status='running', steps_completed=0, checkpoint_file='state-0000000.pkl',
              checkpoint_sha256=pf.sha((first / 'state-0000000.pkl').read_bytes()), model_npz='trace-0000000.npz',
              model_npz_sha256=pf.sha((first / 'trace-0000000.npz').read_bytes()))
    jwrite(first / 'report.json', zr)
    jwrite(first / 'SHA256.json', {p.name: pf.sha(p.read_bytes()) for p in sorted(first.iterdir())})
    write(first.parent / 'first-call-input.pkl', pickle.dumps(dict(before=state, forcing=None, kwargs={})))
    write(first.parent / 'first-call.pkl', pickle.dumps(dict(before=state, forcing=None, kwargs={}, after=state, diagnostics={})))
    capture = {p.relative_to(first.parent).as_posix(): pf.sha(p.read_bytes())
               for p in sorted(first.parent.rglob('*')) if p.is_file()}
    jwrite(first.parent / 'capture-SHA256.json', capture)
    context = dict(identity=identity, mode='cold' if previous is None else 'cycle',
                   previous_ledger_steps=(cycle - 1) * n, ledger_segments=cycle)
    if previous is not None:
        old = Path(previous['directory']) / 'run'
        old_report = pf.contract.read_json(old / 'trajectory/report.json')
        retained = run / 'parent-originals'
        retained.mkdir()
        for name, origin, key in [('parent-state.pkl', old / 'trajectory' / old_report['checkpoint_file'], 'parent_checkpoint_sha256'),
                                 ('parent-report.json', old / 'trajectory/report.json', 'parent_report_sha256'),
                                 ('parent-chain-state.json', old / 'chain-state.json', 'parent_chain_sha256'),
                                 ('parent-receipt.json', old / 'receipt.json', 'parent_receipt_sha256')]:
            body = origin.read_bytes()
            write(retained / name, body)
            context[key] = pf.sha(body)
    jwrite(run / 'start-context.json', context)
    chain = dict(context, report_sha256=pf.sha((trajectory / 'report.json').read_bytes()),
                 start_context_sha256=pf.sha((run / 'start-context.json').read_bytes()), ledger_steps=cycle * n)
    jwrite(run / 'chain-state.json', chain)
    job = '98765.manager'
    receipt = dict(identity=identity, pbs_job=job, failure=None, worker_completed=True, source_unchanged=True,
        first_start_exact=True, report_sha256=pf.sha((trajectory / 'report.json').read_bytes()),
        chain_sha256=pf.sha((run / 'chain-state.json').read_bytes()),
        chain_start_capture_sha256=pf.sha((first.parent / 'capture-SHA256.json').read_bytes()),
        start_index=0, stop_index=n, successful_tendency_calls=n)
    jwrite(run / 'receipt.json', receipt)
    jwrite(first.parent / 'receipt.json', receipt)
    write(root / 'terminal/qstat.txt', b'Job Id: 98765.manager\n    job_state = F\n    Exit_status = 0\n    Stageout_status = 0\n')
    write(root / 'terminal/parent.txt', b'0\n')
    write(root / 'terminal/worker.txt', b'0\n')
    jwrite(root / 'terminals.json', {job: dict(qstat='terminal/qstat.txt', parent_exit='terminal/parent.txt', worker_exit='terminal/worker.txt')})
    jwrite(root / 'SYNTHETIC_ONLY.json', dict(actual_model_steps=0, actual_model_years=0,
        description='Fabricated constant-state parser fixture, including invented receipt/call counts and terminal strings. No physical execution credit.'))
    return seal(root)

"""EHPC-only tests: metadata negatives plus ten original CPU tendency calls.

The short windows are explicitly test-only. Their synthetic terminal text does
not claim an actual closed physical year, spinup, or candidate score.
"""
from copy import deepcopy
from datetime import datetime, timedelta
import json
import os
from pathlib import Path
import pickle
import shutil
import tarfile
import unittest

import chain_contract_pb as c
import numpy_chain_pb as a

CASE = 'CN-Cng-2007-wilting-hydraulic-clim'


def full_calendar(year):
    start = datetime(year, 1, 1)
    stop = datetime(year + 1, 1, 1)
    count = int((stop - start).total_seconds() // 1800)
    return ([int((start + timedelta(minutes=30 * i)).strftime('%Y%m%d%H%M')) for i in range(count)],
            [int((start + timedelta(minutes=30 * (i + 1))).strftime('%Y%m%d%H%M')) for i in range(count)])


def synthetic_terminal(name='closed'):
    job = 'pb-test-' + name
    return dict(job=job, qstat=('Job Id: ' + job + '\n    job_state = F\n    Exit_status = 0\n').encode(),
                parent_exit=b'0\n', worker_exit=b'0\n')


class MetadataTests(unittest.TestCase):
    def test_all_184_original_config_identities_and_four_years(self):
        fixed = c.registry()
        self.assertEqual(len(fixed['configurations']), 184)
        self.assertEqual(len(fixed['candidate_order']), 23)
        self.assertEqual(len(fixed['years']), 4)
        for row in fixed['configurations']:
            one = c.request(row['candidate'], row['case'], 'train1')
            two = c.request(row['candidate'], row['case'], 'train2')
            self.assertEqual(one['configuration_sha256'], two['configuration_sha256'])
            self.assertEqual((one['steps'], two['steps']), (17520, 17568))
            self.assertEqual(one['stop'], two['first'])

    def test_candidate_case_alias_holdout_rejected(self):
        for candidate, case in [('unknown', CASE), ('om-baseline', CASE + '-alias'),
                                ('om-baseline', 'CN-Cha-2004-wilting-hydraulic-clim')]:
            with self.assertRaises(ValueError):
                c.request(candidate, case, 'train1')

    def test_complete_regular_and_leap_calendar(self):
        for year, expected in [(2007, 17520), (2008, 17568), (2003, 17520), (2004, 17568)]:
            starts, stops = full_calendar(year)
            self.assertEqual(c.calendar_summary(starts, stops, 1800, full_year=True)['steps'], expected)

    def test_missing_interval_partial_year_and_wrong_dt_rejected(self):
        starts, stops = full_calendar(2008)
        for x, y, dt in [(starts[:-1], stops[:-1], 1800), (starts[:50] + starts[51:], stops[:50] + stops[51:], 1800),
                         (starts, stops, 3600), (starts, stops, True)]:
            with self.assertRaises(ValueError):
                c.calendar_summary(x, y, dt, full_year=True)

    def test_cycle_and_continue_phase_sequence(self):
        one = c.request('om-baseline', CASE, 'spinup', 1)
        two = c.request('om-baseline', CASE, 'spinup', 2)
        train1 = c.request('om-baseline', CASE, 'train1')
        train2 = c.request('om-baseline', CASE, 'train2')
        self.assertEqual(c.transition(one, two), 'cycle')
        self.assertEqual(c.transition(two, train1), 'cycle')
        self.assertEqual(c.transition(train1, train2), 'continue')

    def test_cross_candidate_case_source_backend_rejected(self):
        one = c.request('om-baseline', CASE, 'spinup', 1)
        two = c.request('om-baseline', CASE, 'spinup', 2)
        for key, value in [('candidate', 'om-oat-b_s-low'), ('case', 'alias'), ('configuration_sha256', '0' * 64),
                           ('source_manifest_sha256', '0' * 64), ('backend', 'cuda32'), ('test_only', True)]:
            changed = {**two, key: value}
            with self.assertRaises(ValueError):
                c.transition(one, changed)

    def test_cycle_must_reuse_exact_forcing_and_no_skipped_phase(self):
        one = c.request('om-baseline', CASE, 'spinup', 1)
        two = c.request('om-baseline', CASE, 'spinup', 2)
        for key in ('forcing_npz_sha256', 'forcing_manifest_sha256', 'first', 'stop', 'steps'):
            with self.assertRaises(ValueError):
                c.transition(one, {**two, key: 'changed'})
        with self.assertRaises(ValueError):
            c.transition(one, c.request('om-baseline', CASE, 'spinup', 3))
        with self.assertRaises(ValueError):
            c.transition(one, c.request('om-baseline', CASE, 'train2'))

    def test_continue_gap_and_reversed_year_rejected(self):
        one = c.request('om-baseline', CASE, 'train1')
        two = c.request('om-baseline', CASE, 'train2')
        for changed in ({**two, 'first': '200801010030'}, {**two, 'year': 2006}):
            with self.assertRaises(ValueError):
                c.transition(one, changed)

    def test_real_f0_parser_requires_identity_and_both_exits(self):
        raw = b'Job Id: 1234.manager\n    job_state = F\n    Exit_status = 0\n'
        self.assertFalse(c.terminal(raw, b'0', b'0', '1234.manager')['synthetic_terminal'])
        for q, p, w, job in [(raw.replace(b'= F', b'= E'), b'0', b'0', '1234.manager'),
                              (raw, b'1', b'0', '1234.manager'), (raw, b'0', b'1', '1234.manager'),
                              (raw, b'0', b'0', '1235.manager')]:
            with self.assertRaises(ValueError):
                c.terminal(q, p, w, job)

    def test_synthetic_terminal_cannot_be_actual_pbs(self):
        t = synthetic_terminal()
        with self.assertRaises(ValueError):
            c.terminal(t['qstat'], t['parent_exit'], t['worker_exit'], t['job'])

    def test_cycle_cap_and_bool_rejected(self):
        for cycle in (0, 21, True, 1.0):
            with self.assertRaises(ValueError):
                c.request('om-baseline', CASE, 'spinup', cycle)

    def test_production_disabled_without_self_reported_spinup_bypass(self):
        for claim in (False, True):
            with self.assertRaisesRegex(ValueError, 'production disabled'):
                c.production_entrypoint(spun_up=claim, passed=True, backend='numpy64')


class OriginalRunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # No skip: missing EHPC inputs/environment must fail the planned execution.
        cls.source = Path(os.environ['PB_SOURCE'])
        cls.root = Path(os.environ['PB_TEST_OUTPUT'])
        c.require(not cls.root.exists(), 'Use a new test output directory')
        cls.root.mkdir(parents=True)
        cls.runner = a.load_runtime(cls.source)
        cls.np = cls.runner.np
        om = Path(os.environ['PB_OM_ARCHIVE'])
        ou = Path(os.environ['PB_OU_ARCHIVE'])
        c.require(c.sha(om.read_bytes()) == c.bindings()['OM_archive_sha256'], 'Original OM archive changed')
        c.require(c.sha(ou.read_bytes()) == c.bindings()['OU_archive_sha256'], 'Original OU archive changed')
        with tarfile.open(om, 'r:gz') as t:
            raw = t.extractfile('result/applied/om-baseline/' + CASE + '.json').read()
        cls.config = cls.root / 'original-config.json'
        cls.config.write_bytes(raw)
        with tarfile.open(ou, 'r:gz') as t:
            full_npz = t.extractfile('current/prepared-inputs/year-inputs/CN-Cng-2007.npz').read()
            full_meta = t.extractfile('current/prepared-inputs/year-inputs/CN-Cng-2007.json').read()
        full_path = cls.root / 'original-full-input.npz'
        full_path.write_bytes(full_npz)
        expected = c.request('om-baseline', CASE, 'spinup', 1)
        c.require(c.sha(full_npz) == expected['forcing_npz_sha256']
                  and c.sha(full_meta) == expected['forcing_manifest_sha256'], 'Original annual bytes mismatch')
        with cls.np.load(full_path, allow_pickle=False) as z:
            full_data = dict(z)
        cls.windows = []
        for start in (0, 2):
            path = cls.root / ('bounded-' + str(start) + '.npz')
            cls.np.savez_compressed(path, **{k: v[start:start + 2].copy() for k, v in full_data.items()})
            meta = json.loads(full_meta)
            meta.update(prepared_npz_sha256=c.sha(path.read_bytes()), PB_test_only=True,
                        PB_original_annual_sha256=c.sha(full_npz), PB_slice=[start, start + 2])
            mp = path.with_suffix('.json')
            mp.write_bytes(c.json_bytes(meta))
            cls.windows.append(dict(input=path, input_manifest=mp, configuration=cls.config))
        cls.identities = []
        for phase, cycle, index in [('spinup', 1, 0), ('spinup', 2, 0), ('train1', 0, 0), ('train2', 0, 1)]:
            identity = c.request('om-baseline', CASE, phase, cycle)
            paths = cls.windows[index]
            with cls.np.load(paths['input'], allow_pickle=False) as z:
                summary = c.calendar_summary(z['time_start'], z['time_end'], 1800, full_year=False)
            identity.update(summary, test_only=True, test_scope='PB bounded adapter test', year=2007,
                            forcing_npz_sha256=c.sha(paths['input'].read_bytes()),
                            forcing_manifest_sha256=c.sha(paths['input_manifest'].read_bytes()))
            cls.identities.append(identity)
        cls.runs = [cls.root / name for name in ('cold', 'spinup-cycle', 'train1-cycle', 'train2-continue')]
        cls.receipts = []
        cls.receipts.append(a._run_segment(cls.runner, cls.source, cls.windows[0], cls.identities[0],
                                           cls.runs[0], stop_after=1))
        cls.receipts.append(a._run_segment(cls.runner, cls.source, cls.windows[0], cls.identities[0],
                                           cls.runs[0], stop_after=1, resume=True))
        for index in range(1, 4):
            paths = cls.windows[int(index == 3)]
            a.derive_start(cls.runner, cls.runs[index - 1], cls.identities[index - 1], cls.identities[index],
                           paths, cls.runs[index], synthetic_terminal())
            cls.receipts.append(a._run_segment(cls.runner, cls.source, paths, cls.identities[index],
                                               cls.runs[index], stop_after=2, resume=True))
        # Unmodified runner reference: independent uninterrupted execution of the same two cold intervals.
        cls.reference = cls.root / 'unmodified-runner-reference'
        p = cls.windows[0]
        cls.runner.run(p['input'], p['input_manifest'], p['configuration'], cls.reference)

    def test_cold_split_equals_unmodified_uninterrupted_runner(self):
        one = c.read_json(self.runs[0] / 'trajectory/report.json')
        two = c.read_json(self.reference / 'report.json')
        saved_one = pickle.loads((self.runs[0] / 'trajectory' / one['checkpoint_file']).read_bytes())
        saved_two = pickle.loads((self.reference / two['checkpoint_file']).read_bytes())
        exact = a.assert_content_exact(saved_one, saved_two, self.np)
        trace_fields = {}
        with self.np.load(self.runs[0] / 'trajectory' / one['model_npz']) as x, \
                self.np.load(self.reference / two['model_npz']) as y:
            self.assertEqual(set(x.files), set(y.files))
            for key in x.files:
                self.assertEqual((x[key].dtype.str, x[key].shape, x[key].tobytes()),
                                 (y[key].dtype.str, y[key].shape, y[key].tobytes()))
                trace_fields[key] = dict(dtype=x[key].dtype.str, shape=list(x[key].shape), bytes_exact=True,
                                        max_abs_difference=0.0 if x[key].dtype.kind in 'biufc' else None)
        print('PB_DIAGNOSTIC ' + json.dumps(dict(test='cold_split_vs_original', seven_tuple_exact=True,
                                                all_trace_fields_exact=True, max_abs_difference=0.0,
                                                state_and_ledger_fields=exact, trace_fields=trace_fields)))

    def test_all_three_carries_keep_six_objects_and_zero_originals(self):
        for index in range(1, 4):
            folder = self.runs[index]
            parent = pickle.loads((folder / 'parent-originals/parent-state.pkl').read_bytes())
            start = folder / 'segment-0000000/start-originals'
            report = c.read_json(start / 'report.json')
            seed = pickle.loads((start / report['checkpoint_file']).read_bytes())
            self.assertEqual(seed[-1], 0)
            a.assert_content_exact(seed[:6], parent[:6], self.np)
            self.assertEqual(report['steps_completed'], 0)
            packet = pickle.loads((folder / 'segment-0000000/first-call.pkl').read_bytes())
            a.assert_content_exact(packet['before'], seed[0], self.np)
            self.assertEqual(set(packet), {'before', 'forcing', 'kwargs', 'after', 'diagnostics'})
            self.assertTrue((folder / 'derived-start-report.json').is_file())

    def test_cumulative_step_chain_and_original_hard_bounds(self):
        diagnostic = []
        for i, folder in enumerate(self.runs):
            result = a.verify_parent(self.runner, folder, self.identities[i], synthetic_terminal())
            chain, saved = result['chain'], result['saved']
            self.assertEqual((chain['ledger_steps'], chain['ledger_segments']), (2 * (i + 1), i + 1))
            residual = self.runner.totals(saved[0]) - saved[1] - saved[2]
            self.assertTrue(self.np.all(abs(residual) <= saved[3]))
            diagnostic.append(dict(phase=self.identities[i]['phase'], cycle=self.identities[i]['cycle'],
                                   residual_m_h_c_n=residual.tolist(), bounds_m_h_c_n=saved[3].tolist(),
                                   ledger_steps=chain['ledger_steps']))
        self.assertEqual(sum(r['successful_tendency_calls'] for r in self.receipts), 8)
        print('PB_DIAGNOSTIC ' + json.dumps(dict(test='bounded_chain', original_tendency_calls=10,
                                                adapter_calls=8, untouched_reference_calls=2,
                                                actual_years=0, actual_spinup=False, rows=diagnostic)))

    def test_partial_parent_nonzero_exit_and_configuration_tamper_rejected(self):
        parent = self.runs[0]
        t = synthetic_terminal()
        for key in ('parent_exit', 'worker_exit'):
            bad = dict(t)
            bad[key] = b'1\n'
            with self.assertRaises(ValueError):
                a.verify_parent(self.runner, parent, self.identities[0], bad)
        partial = self.root / 'negative-partial-parent'
        shutil.copytree(parent, partial)
        report = c.read_json(partial / 'trajectory/report.json')
        report.update(status='running', steps_completed=1)
        (partial / 'trajectory/report.json').write_bytes(c.json_bytes(report))
        chain = c.read_json(partial / 'chain-state.json')
        chain.update(report_sha256=c.sha((partial / 'trajectory/report.json').read_bytes()), ledger_steps=1)
        (partial / 'chain-state.json').write_bytes(c.json_bytes(chain))
        r = c.read_json(partial / 'receipt.json')
        r.update(report_sha256=chain['report_sha256'], chain_sha256=c.sha((partial / 'chain-state.json').read_bytes()))
        (partial / 'receipt.json').write_bytes(c.json_bytes(r))
        with self.assertRaisesRegex(ValueError, 'Full parent year required'):
            a.verify_parent(self.runner, partial, self.identities[0], t)
        config = json.loads(self.config.read_bytes())
        config['biogeochemistry']['soil_state']['mineral_nitrogen'] += 1.0
        raw = c.json_bytes(config)
        forged = {**self.identities[0], 'configuration_sha256': c.sha(raw)}
        with self.assertRaises(ValueError):
            c.validate_configuration(raw, forged)

    def test_checkpoint_start_packet_and_receipt_tamper_rejected(self):
        for name in ('checkpoint', 'first-input', 'receipt'):
            copy = self.root / ('negative-' + name)
            shutil.copytree(self.runs[1], copy)
            report = c.read_json(copy / 'trajectory/report.json')
            if name == 'checkpoint':
                p = copy / 'trajectory' / report['checkpoint_file']
                saved = list(pickle.loads(p.read_bytes()))
                saved[2] = saved[2].copy()
                saved[2][0] += 1.0
                p.write_bytes(pickle.dumps(tuple(saved)))
                # Even consistent replacement hashes cannot waive the original hard endpoint ledger.
                report['checkpoint_sha256'] = c.sha(p.read_bytes())
                (copy / 'trajectory/report.json').write_bytes(c.json_bytes(report))
                chain = c.read_json(copy / 'chain-state.json')
                chain['report_sha256'] = c.sha((copy / 'trajectory/report.json').read_bytes())
                (copy / 'chain-state.json').write_bytes(c.json_bytes(chain))
                r = c.read_json(copy / 'receipt.json')
                r['report_sha256'] = chain['report_sha256']
                r['chain_sha256'] = c.sha((copy / 'chain-state.json').read_bytes())
                (copy / 'receipt.json').write_bytes(c.json_bytes(r))
            elif name == 'first-input':
                p = copy / 'segment-0000000/first-call-input.pkl'
                p.write_bytes(p.read_bytes() + b'tampered')
            else:
                r = c.read_json(copy / 'receipt.json')
                r['identity']['candidate'] = 'om-oat-b_s-high'
                (copy / 'receipt.json').write_bytes(c.json_bytes(r))
            expression = 'Endpoint M/H/C/N ledger failed' if name == 'checkpoint' else (
                'Original start/first-call bytes changed' if name == 'first-input' else 'Parent chain identity mismatch')
            with self.assertRaisesRegex(ValueError, expression):
                a.verify_parent(self.runner, copy, self.identities[1], synthetic_terminal())

    def test_full_input_identity_cannot_be_faked_from_short_window(self):
        short = deepcopy(self.identities[0])
        short['test_only'] = False
        with self.assertRaises(ValueError):
            a.validate_inputs(self.runner, self.windows[0], short)
        with self.assertRaisesRegex(ValueError, 'production execution disabled'):
            a._run_segment(self.runner, self.source, self.windows[0], short,
                           self.root / 'must-not-run', stop_after=1)

    def test_exact_content_rejects_one_bit_signed_zero_dtype_shape_and_alias_changes(self):
        np = self.np
        for x, y in [(0.0, -0.0), (np.array([0.0]), np.array([-0.0])),
                     (np.zeros(2, dtype='float64'), np.zeros(2, dtype='float32')),
                     (np.zeros((2, 1)), np.zeros((1, 2))), (False, 0)]:
            with self.assertRaises(ValueError):
                a.assert_content_exact(x, y, np)
        x = np.array([1.0])
        with self.assertRaisesRegex(ValueError, 'alias graph'):
            a.assert_content_exact((x, x), (x.copy(), x.copy()), np)
        report = c.read_json(self.runs[0] / 'trajectory/report.json')
        original = pickle.loads((self.runs[0] / 'trajectory' / report['checkpoint_file']).read_bytes())
        changed = pickle.loads(pickle.dumps(original))
        changed[0].ground.water[0] = np.nextafter(changed[0].ground.water[0], np.inf)
        with self.assertRaisesRegex(ValueError, 'array bytes mismatch'):
            a.assert_content_exact(original, changed, np)


if __name__ == '__main__':
    unittest.main(verbosity=2)

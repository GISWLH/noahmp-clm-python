"""CPU chain identities and transitions; no array imports or scheduler actions."""
from __future__ import annotations

from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_bytes())


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def bindings():
    return read_json(HERE / 'BINDINGS.json')


def registry():
    raw = (HERE / 'IDENTITIES.json').read_bytes()
    require(sha(raw) == bindings()['identities_sha256'], 'Frozen identity registry changed')
    return json.loads(raw)


def production_entrypoint(*args, **kwargs):
    """There is no production launcher until initialization/spinup evidence is sealed."""
    require(bindings()['production_launch_allowed'] is True,
            'PB production disabled: own initialization/spinup and total execution contract unsealed')
    raise NotImplementedError('Production scheduler/seed eligibility integration is not implemented')


def request(candidate, case, phase, cycle=0):
    r = registry()
    found = [v for v in r['configurations'] if (v['candidate'], v['case']) == (candidate, case)]
    require(len(found) == 1, 'Unknown candidate/original case; aliases are forbidden')
    require(phase in ('spinup', 'train1', 'train2'), 'Unsupported phase')
    require(type(cycle) is int, 'Cycle must be an integer, not bool')
    require((phase == 'spinup' and 1 <= cycle <= 20) or (phase != 'spinup' and cycle == 0),
            'Spinup cycle outside existing 20-cycle cap or training cycle is nonzero')
    config = found[0]
    year = config['second_year'] if phase == 'train2' else config['first_year']
    annual = next(v for v in r['years'] if (v['site'], v['year']) == (config['site'], year))
    return dict(backend='numpy64', candidate=candidate, case=case, site=config['site'],
                configuration_sha256=config['configuration_sha256'], phase=phase, cycle=cycle,
                year=year, steps=annual['steps'], forcing_npz_sha256=annual['npz_sha256'],
                forcing_manifest_sha256=annual['metadata_sha256'],
                source_manifest_sha256=bindings()['source']['manifest_sha256'],
                first=annual['first'], stop=annual['stop'], dt_seconds=1800,
                test_only=False, spinup_accepted=False, score_eligible=False)


def validate_configuration(raw, identity):
    require(sha(raw) == identity['configuration_sha256'], 'Configuration bytes changed')
    config = json.loads(raw)
    require((config['case'], config['site']) == (identity['case'], identity['site']),
            'Configuration case/site mismatch')
    original = request(identity['candidate'], identity['case'], identity['phase'], identity['cycle'])
    require(original['configuration_sha256'] == identity['configuration_sha256'],
            'Configuration is not original OM candidate bytes')
    return config


def calendar_summary(starts, stops, dt, *, full_year):
    require(type(full_year) is bool and type(dt) in (int, float) and dt == 1800,
            'Require explicit half-hour calendar')
    a = [datetime.strptime(str(x), '%Y%m%d%H%M') for x in starts]
    b = [datetime.strptime(str(x), '%Y%m%d%H%M') for x in stops]
    require(len(a) > 0 and len(a) == len(b), 'Missing calendar')
    require(all(y - x == timedelta(seconds=dt) for x, y in zip(a, b)), 'Interval duration mismatch')
    require(all(x == y for x, y in zip(b[:-1], a[1:])), 'Calendar gap/overlap')
    if full_year:
        require(a[0] == datetime(a[0].year, 1, 1) and b[-1] == datetime(a[0].year + 1, 1, 1),
                'Require a complete calendar year')
        expected = (datetime(a[0].year + 1, 1, 1) - a[0]).total_seconds() / dt
        require(len(a) == expected, 'Full annual interval count mismatch')
    return dict(first=a[0].strftime('%Y%m%d%H%M'), stop=b[-1].strftime('%Y%m%d%H%M'),
                steps=len(a), dt_seconds=1800)


def transition(parent, child):
    for key in ('backend', 'candidate', 'case', 'site', 'configuration_sha256',
                'source_manifest_sha256', 'test_only'):
        require(parent[key] == child[key], 'Cross-chain identity mismatch: ' + key)
    require(parent['backend'] == child['backend'] == 'numpy64', 'CPU source cannot be labelled GPU')
    if child['phase'] == 'spinup':
        require(parent['phase'] == 'spinup' and child['cycle'] == parent['cycle'] + 1,
                'Spinup must continue its own immediately preceding cycle')
        mode = 'cycle'
    elif child['phase'] == 'train1':
        require(parent['phase'] == 'spinup' and child['cycle'] == 0, 'Train1 requires own spinup parent')
        mode = 'cycle'
    elif child['phase'] == 'train2':
        require(parent['phase'] == 'train1' and child['cycle'] == 0, 'Train2 requires own train1 parent')
        mode = 'continue'
    else:
        raise ValueError('Unsupported child phase')
    if mode == 'cycle':
        for key in ('forcing_npz_sha256', 'forcing_manifest_sha256', 'first', 'stop', 'steps'):
            require(parent[key] == child[key], 'Cycle must reuse identical forcing/calendar: ' + key)
    else:
        require(parent['stop'] == child['first'], 'Continue calendar is not contiguous')
        if not child['test_only']:
            require(child['year'] == parent['year'] + 1, 'Training years must be consecutive')
    return mode


def terminal(qstat, parent_exit, worker_exit, expected_job, *, synthetic=False):
    """Parse original terminal bytes; synthetic test terminals have an explicit namespace."""
    require(type(synthetic) is bool, 'Synthetic flag must be bool')
    require(bool(re.fullmatch(r'pb-test-[a-z0-9-]+', expected_job)) if synthetic
            else bool(re.fullmatch(r'\d+\.manager', expected_job)), 'PBS identity namespace mismatch')
    text = qstat.decode()
    require(text.splitlines()[0] == 'Job Id: ' + expected_job, 'PBS job mismatch')
    for key in ('job_state', 'Exit_status'):
        expected = 'F' if key == 'job_state' else '0'
        require(re.search(r'^\s*' + key + r'\s*=\s*' + expected + r'\s*$', text, re.M),
                'Actual parent terminal required: ' + key)
    require(parent_exit.strip() == worker_exit.strip() == b'0', 'Parent/worker exit is not zero')
    return dict(job=expected_job, qstat_sha256=sha(qstat), parent_exit_sha256=sha(parent_exit),
                worker_exit_sha256=sha(worker_exit), synthetic_terminal=synthetic)

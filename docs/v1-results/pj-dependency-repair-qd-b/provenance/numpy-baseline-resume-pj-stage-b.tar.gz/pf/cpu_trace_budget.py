"""Shared read-only original CPU trace/checkpoint budget audit; no tendency."""
from pathlib import Path
import pickle
import numpy as np
import numpy_chain_pb as pb
from chain_contract_pb import require, sha

def _exact(left, right, label):
    a, b = np.asarray(left), np.asarray(right)
    require(a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes(), label)


def _check_cumulative_trace(runner, trace, start, saved):
    """Audit original arithmetic/bounds from carried zero ledger, not a new tolerance."""
    require(type(start) is tuple and len(start) == 7 and start[-1] == 0, 'Original zero-step seven-tuple required')
    require(type(saved) is tuple and len(saved) == 7, 'Original final seven-tuple required')
    count = saved[-1]
    for key in ('step_residual_m_h_c_n', 'step_bound_m_h_c_n', 'cumulative_residual_m_h_c_n'):
        value = trace[key]
        require(type(value) is np.ndarray and value.dtype == np.dtype('float64') and
                value.shape == (count, 4) and np.isfinite(value).all(), 'Original ledger trace layout: ' + key)
    bounds, maximum, stepmax = (start[k].copy() for k in (3, 4, 5))
    require(all(x.shape == (4,) and x.dtype == np.dtype('float64') and np.isfinite(x).all() and np.all(x >= 0)
                for x in (bounds, maximum, stepmax)), 'Original carried bounds/maximum')
    carbon_net = start[2][2]
    for i in range(count):
        residual, bound = trace['step_residual_m_h_c_n'][i], trace['step_bound_m_h_c_n'][i]
        cumulative = trace['cumulative_residual_m_h_c_n'][i]
        require(np.all(bound >= 0) and np.all(abs(residual) <= bound), 'Original step budget failed')
        bounds = bounds + bound
        require(np.all(abs(cumulative) <= bounds), 'Original cumulative budget failed')
        maximum = np.maximum(maximum, abs(cumulative))
        stepmax = np.maximum(stepmax, abs(residual))
        # Original run_fluxnet_column incoming[2] is exactly -d['nee_gc_m2'].
        carbon_net = carbon_net + (-trace['nee_gc_m2'][i])
    for value, key in ((bounds, 3), (maximum, 4), (stepmax, 5)):
        _exact(value, saved[key], 'Trace/final carried ledger differs')
    _exact(carbon_net, saved[2][2], 'Original NEE/carbon exchange ledger differs')
    endpoint = runner.totals(saved[0]) - saved[1] - saved[2]
    _exact(trace['cumulative_residual_m_h_c_n'][-1], endpoint, 'Trace/final residual differs')
    return dict(intervals=count, original_bounds_preserved=True,
        maximum_step_absolute_m_h_c_n=np.max(abs(trace['step_residual_m_h_c_n']), axis=0).tolist(),
        maximum_cumulative_absolute_m_h_c_n=np.max(abs(trace['cumulative_residual_m_h_c_n']), axis=0).tolist(),
        final_global_bounds_m_h_c_n=bounds.tolist(), original_nee_carbon_exchange_exact=True)


def _start_tuple(root):
    folder = Path(root)/'segment-0000000/start-originals'
    report = pb.read_json(folder/'report.json')
    raw = pb._member(folder, report['checkpoint_file']).read_bytes()
    require(sha(raw) == report['checkpoint_sha256'], 'Original zero checkpoint hash')
    return pickle.loads(raw)  # only the already hash-verified, internally produced PB evidence


def audit_cpu_trace(runner, verified_pb_result, run_path):
    """Input is the unchanged PB.verify_parent return; preserve original bounds."""
    return _check_cumulative_trace(runner, verified_pb_result['trace'],
                                   _start_tuple(run_path), verified_pb_result['saved'])

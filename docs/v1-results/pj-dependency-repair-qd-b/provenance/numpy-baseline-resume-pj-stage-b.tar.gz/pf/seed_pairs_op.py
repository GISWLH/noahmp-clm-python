"""Fixed JR dry/wet identities and same-cycle endpoint diagnostics only."""
import hashlib
import json
import os
import socket

LIMITS = {'soil_temperature_k': .1, 'soil_water_m3m3': .001, 'swe_m': .0005}
PAIR_KEYS = {(site, mapping) for site in ('CN-Cng', 'CN-Qia', 'CN-Cha')
             for mapping in ('hydraulic-consistent', 'legacy-nominal-control')}
ALLOWED_CONFIG_DIFFERENCES = {('case',), ('column', 'smc', 1),
                              ('column', 'smc', 2), ('column', 'smc', 3)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def compute_only():
    require(bool(os.environ.get('PBS_JOBID')) and socket.gethostname() == 'compute002',
            'Numerical endpoint decoding/comparison requires EHPC compute002 PBS')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def differences(before, after, path=()):
    if type(before) is dict and type(after) is dict and before.keys() == after.keys():
        return [change for key in before for change in differences(before[key], after[key], path + (key,))]
    if type(before) is list and type(after) is list and len(before) == len(after):
        return [change for i, (a, b) in enumerate(zip(before, after)) for change in differences(a, b, path + (i,))]
    return [] if canonical(before) == canonical(after) else [dict(path=list(path), dry=before, wet=after)]


def validate_pair_set(binding, configurations):
    """No observation/score argument and no subset/best-seed selection API."""
    pairs = binding['pairs']
    require(len(pairs) == 6 and {(p['site'], p['bgc_potential_mapping']) for p in pairs} == PAIR_KEYS,
            'All six distinct fixed station/BGC pairs are required')
    cases = [p[side]['case'] for p in pairs for side in ('dry', 'wet')]
    require(len(cases) == len(set(cases)) == 12 and set(configurations) == set(cases),
            'All twelve distinct original cases are required; no missing/repeated/extra seed')
    for pair in pairs:
        dry, wet = (json.loads(configurations[pair[side]['case']]) for side in ('dry', 'wet'))
        for side, config in [('dry', dry), ('wet', wet)]:
            identity = pair[side]
            require(sha(configurations[identity['case']]) == identity['configuration_sha256'],
                    'Configuration bytes differ from fixed original JR identity')
            require(config['case'] == identity['case'] and config['site'] == pair['site'],
                    'Case/site label differs from its original configuration')
            require(config['biogeochemistry']['saturated_potential_mpa'] == pair['bgc_saturated_potential_mpa'],
                    'Dry/wet pair changed its fixed BGC potential mapping')
        for field in ('input_member', 'input_manifest_member', 'forcing_npz_sha256', 'forcing_manifest_sha256'):
            require(pair['dry'][field] == pair['wet'][field], 'Different forcing/metadata within seed pair')
        changes = differences(dry, wet)
        require({tuple(v['path']) for v in changes} == ALLOWED_CONFIG_DIFFERENCES,
                'Only case and original deep total-water layers1:4 may differ')
        require(canonical(changes) == canonical(pair['original_configuration_differences']),
                'Initial seed values differ from exact original JR dry/wet values')
    return pairs


def compare_seed_endpoints(dry, wet, limits):
    """Compare stocks at the SAME climate-cycle end; never calculate C drift."""
    compute_only()
    import numpy as np
    require({key: limits[key] for key in LIMITS} == LIMITS, 'Original cross-seed thresholds must not change')
    result = {}
    layer_shape = None
    for key in ('soil_temperature_k', 'soil_water_m3m3'):
        a, b = (np.asarray(frame[key], dtype=float) for frame in (dry, wet))
        require(a.ndim == b.ndim == 1 and a.shape == b.shape and a.size > 0
                and np.isfinite(a).all() and np.isfinite(b).all(), 'Finite matching layer vectors required: ' + key)
        require(layer_shape is None or a.shape == layer_shape, 'Temperature/water layer dimensions differ')
        layer_shape = a.shape
        if key == 'soil_water_m3m3':
            require(np.all(a >= 0) and np.all(b >= 0), 'Total volumetric water must be nonnegative')
        delta = b - a
        difference = np.abs(delta)
        result[key] = dict(dry_by_layer=a.tolist(), wet_by_layer=b.tolist(),
            signed_wet_minus_dry_by_layer=delta.tolist(), absolute_difference_by_layer=difference.tolist(),
            maximum_absolute_difference=float(difference.max()), tolerance=limits[key],
            layer_criteria_met=(difference <= limits[key]).tolist(), criterion_met=bool(np.all(difference <= limits[key])))
    a, b = (np.asarray(frame['swe_m'], dtype=float) for frame in (dry, wet))
    require(a.shape == b.shape == () and np.isfinite(a) and np.isfinite(b) and a >= 0 and b >= 0,
            'Finite nonnegative scalar SWE required')
    difference = float(abs(b - a))
    result['swe_m'] = dict(dry=float(a), wet=float(b), signed_wet_minus_dry=float(b-a),
        absolute_difference=difference, tolerance=limits['swe_m'], criterion_met=difference <= limits['swe_m'])
    carbon_a, carbon_b = (np.asarray(frame['soil_carbon_gc_m2'], dtype=float) for frame in (dry, wet))
    require(carbon_a.shape == carbon_b.shape == (7,) and np.isfinite(carbon_a).all()
            and np.isfinite(carbon_b).all() and np.all(carbon_a >= 0) and np.all(carbon_b >= 0),
            'Finite nonnegative seven-pool carbon stocks required')
    result['soil_carbon_stock_difference'] = dict(dry_seven_pools_gc_m2=carbon_a.tolist(),
        wet_seven_pools_gc_m2=carbon_b.tolist(), signed_wet_minus_dry_seven_pools_gc_m2=(carbon_b-carbon_a).tolist(),
        dry_soc_gc_m2=float(carbon_a[4:].sum()), wet_soc_gc_m2=float(carbon_b[4:].sum()),
        signed_wet_minus_dry_soc_gc_m2=float((carbon_b[4:]-carbon_a[4:]).sum()),
        meaning='Same-cycle cross-seed stock differences only; no time interval, annualization, SOC convergence or scientific pass.')
    result['cross_seed_water_heat_criteria_met'] = all(result[key]['criterion_met'] for key in LIMITS)
    return result

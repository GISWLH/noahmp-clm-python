"""EHPC only: own constructor states, original packet reads, explicit synthetic cycles."""
from copy import deepcopy
import io
import json
import os
from pathlib import Path
import pickle
import shutil
import tarfile
import unittest

import own_spinup_pf as pf
import synthetic_packets_pf as fixtures


class OwnInitializationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = Path(os.environ['PF_SOURCE'])
        cls.pa_archive = Path(os.environ['PF_PA_ARCHIVE'])
        cls.root = Path(os.environ['PF_OUTPUT'])
        cls.root.mkdir()
        cls.runner, cls.assessor, cls.pairs = pf.runtime(cls.source)
        cls.assembly = pf.read_assembly(cls.pa_archive)
        cls.forward_attempts = []
        cls.constructor_calls = []
        cls.original_run = staticmethod(cls.runner.run)
        cls.original_step = staticmethod(cls.runner.step_clm_enthalpy_column)
        original_constructor = cls.runner.build_state

        def construct(config):
            cls.constructor_calls.append(config['case'])
            return original_constructor(config)

        def forbidden(*args, **kwargs):
            cls.forward_attempts.append(True)
            raise AssertionError('PF tests must not run a physical model')

        cls.runner.build_state = construct
        cls.runner.run = forbidden
        cls.runner.step_clm_enthalpy_column = forbidden
        cls.forbidden = staticmethod(forbidden)
        cls.materialized = []
        for candidate in pf.contract.registry()['candidate_order']:
            for row in pf.candidate_rows(candidate):
                path = cls.root / 'own-cold' / candidate / row['case']
                record = pf.make_own_cold_seed(cls.runner, cls.assembly, candidate, row['case'], path)
                checked = pf.verify_own_cold_seed(cls.runner, cls.assembly, candidate, row['case'], path)
                cls.materialized.append(dict(candidate=candidate, case=row['case'], seed=record, proof=checked))
        cls.cases = {}
        for row in pf.candidate_rows('om-baseline'):
            one = fixtures.full_cycle(cls.runner, cls.assembly, 'om-baseline', row['case'], 1,
                                      cls.root / 'synthetic' / row['case'] / 'cycle1')
            two = fixtures.full_cycle(cls.runner, cls.assembly, 'om-baseline', row['case'], 2,
                                      cls.root / 'synthetic' / row['case'] / 'cycle2', one)
            cls.cases[row['case']] = [one, two]

    @classmethod
    def tearDownClass(cls):
        pf.require(not cls.forward_attempts, 'No forward calls allowed')
        pf.adapter.verify_source(cls.source)
        (cls.root / 'own-cold-inventory.json').write_bytes(pf.contract.json_bytes(cls.materialized))
        record = dict(own_nominal_seeds=184, independent_constructor_comparisons=184,
            all_constructor_calls=len(cls.constructor_calls), synthetic_complete_calendar_packets=16,
            synthetic_packet_receipts_have_no_physical_credit=True, actual_new_physical_steps=cls.capture_calls,
            actual_model_years=0, actual_spinup=False, score_eligible=False, forward_attempts=0)
        (cls.root / 'execution-counts.json').write_bytes(pf.contract.json_bytes(record))
        print('PF_DIAGNOSTIC ' + json.dumps(record))

    def baseline(self):
        row = self.materialized[0]
        return row, self.root / 'own-cold' / row['candidate'] / row['case']

    def original_pb(self):
        root = self.root / 'original-pb'
        if root.exists():
            return root
        archive_path = Path(os.environ['PF_PB_ARCHIVE'])
        self.assertEqual(pf.sha(archive_path.read_bytes()), pf.bindings()['PB_actual_closed_package_sha256'])
        root.mkdir()
        with tarfile.open(archive_path) as archive:
            prefix = 'attempt-1607/result/short-model-output/'
            for name in archive.getnames():
                if name.startswith(prefix):
                    fixtures.write(root / name.removeprefix(prefix), archive.extractfile(name).read())
        return root

    def copy_seed(self, label):
        row, original = self.baseline()
        target = self.root / ('negative-seed-' + label)
        shutil.copytree(original, target)
        return row, target

    def copy_cycle(self, label):
        case = next(iter(self.cases))
        old = self.cases[case][0]
        target = self.root / ('negative-cycle-' + label)
        shutil.copytree(old['directory'], target)
        return case, target, fixtures.seal(target)

    def test_all_184_actual_own_zero_states(self):
        self.assertEqual(len(self.materialized), 184)
        self.assertEqual(len({(r['candidate'], r['case']) for r in self.materialized}), 184)
        for row in self.materialized:
            self.assertEqual(row['seed']['original_mineral_nitrogen'], 2.)
            self.assertEqual(row['proof']['comparison']['max_abs_difference'], 0.)
            self.assertFalse(row['proof']['spinup_accepted'])

    capture_calls = 0

    def test_capture_actual_two_steps_and_prescribed_cn_inputs(self):
        from capture_bgc_pf import BGCRecorder, records
        original = self.original_pb()
        identity = pf.contract.read_json(original / 'cold/receipt.json')['identity']
        paths = dict(input=original / 'bounded-0.npz', input_manifest=original / 'bounded-0.json',
                     configuration=original / 'original-config.json')
        np = self.runner.np
        with np.load(paths['input']) as z:
            starts, ends = z['time_start'], z['time_end']
        self.runner.run = self.original_run
        self.runner.step_clm_enthalpy_column = self.original_step
        target = self.root / 'new-capture-two-steps'
        try:
            with BGCRecorder(self.runner, identity, starts, ends, self.root / 'new-bgc-stream'):
                receipt = pf.adapter._run_segment(self.runner, self.source, paths, identity, target, stop_after=2)
            type(self).capture_calls = receipt['successful_tendency_calls']
        finally:
            self.runner.run = self.forbidden
            self.runner.step_clm_enthalpy_column = self.forbidden
        self.assertEqual(self.capture_calls, 2)
        rows = list(records(self.root / 'new-bgc-stream'))
        self.assertEqual(len(rows), 2)
        pairs = [original / 'cold/segment-0000000/first-call.pkl', original / 'cold/segment-0000001/first-call.pkl']
        differences = []
        for row, packet_path in zip(rows, pairs):
            packet = pickle.loads(packet_path.read_bytes())
            for new, old in [(row['before_bgc'], packet['before'].bgc_state), (row['after_bgc'], packet['after'].bgc_state),
                             (row['original_bgc_diagnostic'], packet['diagnostics']['biogeochemistry']),
                             (row['original_kwargs'], packet['kwargs'])]:
                differences.append(pf.adapter.assert_content_exact(new, old, np)['max_abs_difference'])
            self.assertEqual(row['prescribed']['plant_n_demand_gn_m2'], row['original_bgc_diagnostic']['allocation']['soil_n_demand_gn_m2'])
            self.assertEqual(row['prescribed']['mineral_n_input_gn_m2'], row['original_kwargs']['nitrogen_deposition_gn_m2'])
            self.assertEqual(row['actual_plant_uptake_gn_m2'], row['original_bgc_diagnostic']['decomposition']['plant_uptake_gn_m2'])
        current_report = pf.contract.read_json(target / 'trajectory/report.json')
        original_report = pf.contract.read_json(original / 'unmodified-runner-reference/report.json')
        a = pf.adapter._generation(self.runner, target / 'trajectory', current_report, complete=True)
        b = pf.adapter._generation(self.runner, original / 'unmodified-runner-reference', original_report, complete=True)
        state = pf.adapter.assert_content_exact(a[1], b[1], np)
        trace = {key: pf.adapter.assert_content_exact(a[2][key], b[2][key], np) for key in a[2]}
        result = dict(actual_new_original_tendencies=2, complete_bgc_records=2, actual_reference_reruns=0,
            original_bgc_and_kwargs_max_abs_difference=max(differences), state=state, trace=trace,
            potential_demand_and_actual_uptake_distinct_fields=True, deposition_is_interval_amount=True)
        (self.root / 'bgc-capture-comparison.json').write_bytes(pf.contract.json_bytes(result))
        print('PF_DIAGNOSTIC ' + json.dumps(dict(test='new_capture_actual_two_steps', new_original_tendencies=2,
            original_bgc_and_kwargs_max_abs_difference=max(differences), entire_state_and18trace_max_abs_difference=0.)))

    def test_same_state_cannot_be_relabelled_to_another_candidate(self):
        row, path = self.baseline()
        with self.assertRaisesRegex(ValueError, 'not this candidate'):
            pf.verify_own_cold_seed(self.runner, self.assembly, 'om-oat-b_s-low', row['case'], path)

    def test_rehashed_modified_initial_mineral_n_is_rejected(self):
        row, path = self.copy_seed('nitrogen')
        config = json.loads((path / 'configuration.json').read_bytes())
        config['biogeochemistry']['soil_state']['mineral_nitrogen'] += 1.
        (path / 'configuration.json').write_bytes(pf.contract.json_bytes(config))
        side = pf.contract.read_json(path / 'OWN_COLD_SEED.json')
        side['configuration_sha256'] = pf.sha((path / 'configuration.json').read_bytes())
        (path / 'OWN_COLD_SEED.json').write_bytes(pf.contract.json_bytes(side))
        with self.assertRaisesRegex(ValueError, 'differs from original OM'):
            pf.verify_own_cold_seed(self.runner, self.assembly, row['candidate'], row['case'], path)

    def test_rehashed_nonzero_cold_ledger_is_rejected(self):
        row, path = self.copy_seed('ledger')
        saved = pickle.loads((path / 'own-cold-state.pkl').read_bytes())
        saved[2][0] = 1.
        (path / 'own-cold-state.pkl').write_bytes(pickle.dumps(saved))
        side = pf.contract.read_json(path / 'OWN_COLD_SEED.json')
        side['checkpoint_sha256'] = pf.sha((path / 'own-cold-state.pkl').read_bytes())
        (path / 'OWN_COLD_SEED.json').write_bytes(pf.contract.json_bytes(side))
        with self.assertRaisesRegex(ValueError, 'array bytes'):
            pf.verify_own_cold_seed(self.runner, self.assembly, row['candidate'], row['case'], path)

    def test_initial_seed_cannot_claim_spinup_or_boolean_counter(self):
        row, path = self.copy_seed('credit')
        original = pf.contract.read_json(path / 'OWN_COLD_SEED.json')
        for key, value in [('spinup_accepted', True), ('score_eligible', True), ('local_index', False)]:
            (path / 'OWN_COLD_SEED.json').write_bytes(pf.contract.json_bytes({**original, key: value}))
            with self.assertRaisesRegex(ValueError, 'cannot claim'):
                pf.verify_own_cold_seed(self.runner, self.assembly, row['candidate'], row['case'], path)

    def test_all_eight_roots_and_same_cycle_count_required(self):
        missing = dict(self.cases)
        missing.pop(next(iter(missing)))
        unequal = deepcopy(self.cases)
        unequal[next(iter(unequal))].pop()
        for cases in (missing, unequal):
            with self.assertRaises(ValueError):
                pf.audit_own_cycles(self.source, self.pa_archive, 'om-baseline', cases)

    def test_positive_synthetic_full_lineage_preserves_science_limits(self):
        result = pf.audit_own_cycles(self.source, self.pa_archive, 'om-baseline', self.cases)
        self.assertEqual(result['complete_cycles'], 2)
        self.assertEqual(len(result['final_cycles']), 8)
        self.assertTrue(result['all_roots_water_heat_converged'])
        self.assertFalse(result['all_four_cross_seed_water_heat_criteria_met'])
        self.assertFalse(result['score_eligible'])
        self.assertFalse(result['soil_c_long_term_equilibrium_claim'])
        self.assertTrue(result['unresolved_requirements'])
        for row in result['roots'].values():
            self.assertIsNone(row['observed_century'][0]['actual_100_cycle_soc_change_percent'])
        (self.root / 'synthetic-assessment.json').write_bytes(pf.contract.json_bytes(result))

    def test_actual_failed_parent_1607_cannot_supply_eligibility(self):
        case, root, _ = self.copy_cycle('real-failure')
        with tarfile.open(os.environ['PF_PB_ARCHIVE']) as archive:
            actual = archive.extractfile('actual/manager/1607.manager/qstat.stdout.txt').read()
        (root / 'terminal/qstat.txt').write_bytes(actual)
        with self.assertRaises(ValueError):
            pf.verify_cycle(self.runner, fixtures.seal(root), self.assembly, 'om-baseline', case, 1)

    def test_partial_year_and_parent_exit_are_rejected(self):
        case, root, _ = self.copy_cycle('partial')
        receipt = pf.contract.read_json(root / 'run/receipt.json')
        receipt['identity']['steps'] = 48
        fixtures.jwrite(root / 'run/receipt.json', receipt)
        with self.assertRaises(ValueError):
            pf.verify_cycle(self.runner, fixtures.seal(root), self.assembly, 'om-baseline', case, 1)
        case, root, _ = self.copy_cycle('exit')
        (root / 'terminal/parent.txt').write_bytes(b'1\n')
        with self.assertRaisesRegex(ValueError, 'exit is not zero'):
            pf.verify_cycle(self.runner, fixtures.seal(root), self.assembly, 'om-baseline', case, 1)

    def test_frozen_inventory_rejects_changed_and_extra_files(self):
        _, root, descriptor = self.copy_cycle('inventory')
        (root / 'extra.txt').write_bytes(b'extra')
        with self.assertRaisesRegex(ValueError, 'inventory'):
            pf.closed_packet(descriptor)

    def test_cross_candidate_complete_packet_is_rejected(self):
        case = next(iter(self.cases))
        with self.assertRaisesRegex(ValueError, 'identity mismatch'):
            pf.verify_cycle(self.runner, self.cases[case][0], self.assembly, 'om-oat-b_s-low', case, 1)

    def test_real_pb_zero_and_four_traces_read_without_forward(self):
        from cpu_trace_budget import audit_cpu_trace
        root = self.original_pb()
        case = 'CN-Cng-2007-wilting-hydraulic-clim'
        seed = self.root / 'own-cold/om-baseline' / case / 'own-cold-state.pkl'
        zero = root / 'cold/segment-0000000/start-originals/state-0000000.pkl'
        exact = pf.adapter.assert_content_exact(pickle.loads(seed.read_bytes()), pickle.loads(zero.read_bytes()), self.runner.np)
        diagnostics = []
        for name in ('cold', 'spinup-cycle', 'train1-cycle', 'train2-continue'):
            run = root / name
            report = pf.contract.read_json(run / 'trajectory/report.json')
            raw, saved, trace = pf.adapter._generation(self.runner, run / 'trajectory', report, complete=True)
            diagnostics.append(audit_cpu_trace(self.runner, dict(saved=saved, trace=trace), run))
        (self.root / 'original-pb-read-diagnostics.json').write_bytes(pf.contract.json_bytes(dict(
            source='Original1607 failed wrapper / actual child0; only read original successful short arrays.',
            original_zero_comparison=exact, original_four_trace_audits=diagnostics,
            additional_forward_steps=0, score_eligible=False)))
        print('PF_DIAGNOSTIC ' + json.dumps(dict(test='original_pb_zero_and_trace_read', max_abs_difference=exact['max_abs_difference'],
                                                old_steps_read=8, new_forward_steps=0)))


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Generated original PB segment body; only name/docstring/entry gate differ."""
import contextlib
import os
from pathlib import Path
import pickle
import socket
import time
import traceback
import zipfile
from chain_contract_pb import require, request, read_json, json_bytes, sha
from numpy_chain_pb import verify_source, validate_inputs, _generation, _write, _snapshot, _member, assert_content_exact

def run_window(runner, source, paths, identity, output, *, stop_after, resume=False):
    """Same-year original baseline resume: <=480 steps, never reset/cycle/train."""
    require(type(stop_after) is int and stop_after > 0, 'Positive integer segment length required')
    require(identity == request(identity['candidate'], identity['case'], 'spinup', 1) and identity['candidate'] == 'om-baseline' and (identity['steps'] == 17520) and (identity['test_only'] is False) and (resume is True) and (48 <= read_json(Path(output) / 'trajectory/report.json')['steps_completed'] < 17520) and ((read_json(Path(output) / 'trajectory/report.json')['steps_completed'] - 48) % 480 == 0) and (stop_after == min(480, 17520 - read_json(Path(output) / 'trajectory/report.json')['steps_completed'])), 'PJ only resumes the original baseline partial first year in fixed bounded windows')
    source = Path(source)
    verify_source(source)
    validate_inputs(runner, paths, identity)
    output = Path(output)
    trajectory = output / 'trajectory'
    if not resume:
        require(identity['phase'] == 'spinup' and identity['cycle'] == 1, 'Only own spinup cycle1 may start cold')
        require(not output.exists(), 'Cold run must use a fresh directory')
        output.mkdir(parents=True)
        context = dict(identity=identity, mode='cold', previous_ledger_steps=0, ledger_segments=1, parent_report_sha256=None, parent_checkpoint_sha256=None, spinup_accepted=False, score_eligible=False)
        _write(output / 'start-context.json', json_bytes(context))
        start = 0
    else:
        context = read_json(output / 'start-context.json')
        require(context['identity'] == identity, 'Resume identity differs from frozen start')
        report = read_json(trajectory / 'report.json')
        _, saved, _ = _generation(runner, trajectory, report, complete=False)
        start = saved[-1]
        require(report['status'] == 'running' and start < identity['steps'], 'No failed/complete resume')
    require(start + stop_after <= identity['steps'], 'Segment exceeds fixed window')
    segment = output / ('segment-' + str(start).zfill(7))
    require(not segment.exists(), 'Segment attempt already exists; retain failures')
    segment.mkdir()
    original_json, original_step = (runner.atomic_json, runner.step_clm_enthalpy_column)
    captured = False
    first_state_exact = False
    first_content_comparison = None
    calls = 0
    expected_state = None
    failure = None
    source_unchanged = False
    began = time.monotonic()

    def observe(path, value):
        nonlocal captured, expected_state
        original_json(path, value)
        if Path(path).resolve() != (trajectory / 'report.json').resolve():
            return
        raw = Path(path).read_bytes()
        chain = dict(context, report_sha256=sha(raw), start_context_sha256=sha((output / 'start-context.json').read_bytes()), ledger_steps=context['previous_ledger_steps'] + value['steps_completed'])
        original_json(output / 'chain-state.json', chain)
        with zipfile.ZipFile(output / 'generations.zip', 'a', zipfile.ZIP_DEFLATED) as z:
            prefix = f'{start:07d}-{len(z.namelist()):07d}/'
            for name in ('report.json', value['checkpoint_file'], value['model_npz']):
                z.writestr(prefix + name, (trajectory / name).read_bytes())
        if not captured:
            require(value['steps_completed'] == start, 'First saved generation is not original segment start')
            _snapshot(trajectory, path, segment / 'start-originals')
            expected_state = pickle.loads(_member(trajectory, value['checkpoint_file']).read_bytes())[0]
            captured = True

    def first(state, forcing, **kwargs):
        nonlocal calls, first_state_exact, first_content_comparison
        if calls == 0:
            require(captured, 'Original start was not captured')
            first_content_comparison = assert_content_exact(state, expected_state, runner.np)
            first_state_exact = True
            _write(segment / 'first-call-input.pkl', pickle.dumps(dict(before=state, forcing=forcing, kwargs=kwargs), protocol=5))
        after, diagnostics = original_step(state, forcing, **kwargs)
        if calls == 0:
            _write(segment / 'first-call.pkl', pickle.dumps(dict(before=state, forcing=forcing, kwargs=kwargs, after=after, diagnostics=diagnostics), protocol=5))
        calls += 1
        return (after, diagnostics)
    with (segment / 'model.log').open('x') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        try:
            runner.atomic_json, runner.step_clm_enthalpy_column = (observe, first)
            report = runner.run(*(paths[k] for k in ('input', 'input_manifest', 'configuration')), trajectory, resume=resume, stop_after=stop_after)
            require(captured and calls == stop_after and (report['steps_completed'] == start + stop_after), 'Original runner did not complete the requested segment')
            _generation(runner, trajectory, report, complete=report['status'] == 'complete')
        except Exception as exc:
            failure = type(exc).__name__ + ': ' + str(exc)
            traceback.print_exc()
        finally:
            runner.atomic_json, runner.step_clm_enthalpy_column = (original_json, original_step)
    try:
        verify_source(source)
        source_unchanged = True
        validate_inputs(runner, paths, identity)
    except Exception as exc:
        failure = (failure + '; ' if failure else '') + type(exc).__name__ + ': ' + str(exc)
    capture_files = {p.relative_to(segment).as_posix(): sha(p.read_bytes()) for p in sorted(segment.rglob('*')) if p.is_file()}
    _write(segment / 'capture-SHA256.json', json_bytes(capture_files))
    chain_start_capture = output / 'segment-0000000/capture-SHA256.json'
    report_raw = (trajectory / 'report.json').read_bytes() if (trajectory / 'report.json').exists() else b''
    chain_raw = (output / 'chain-state.json').read_bytes() if (output / 'chain-state.json').exists() else b''
    receipt = dict(identity=identity, pbs_job=os.environ.get('PBS_JOBID'), node=socket.gethostname(), start_index=start, stop_index=start + calls, successful_tendency_calls=calls, worker_completed=failure is None, failure=failure, source_unchanged=source_unchanged, report_sha256=sha(report_raw), chain_sha256=sha(chain_raw), chain_start_capture_sha256=sha(chain_start_capture.read_bytes()), seconds=time.monotonic() - began, first_start_exact=first_state_exact, first_content_comparison=first_content_comparison, actual_pbs_terminal_claimed=False, spinup_accepted=False, score_eligible=False)
    original_json(segment / 'receipt.json', receipt)
    original_json(output / 'receipt.json', receipt)
    if failure is not None:
        raise RuntimeError(failure)
    return receipt

"""Deploy exact once, then launch the finite manager controller without a terminal."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shlex
import socket
import subprocess
import tarfile

ROOT=Path('/tmp/noahmp-numpy-baseline-resume-pj')
PYTHON='/home/zhangyq/venvs/noahmp-closeout/bin/python'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--archive',type=Path,required=True)
    parser.add_argument('--sha256',required=True)
    parser.add_argument('--extract-only',action='store_true')
    args=parser.parse_args()
    assert socket.gethostname()==('compute002' if args.extract_only else 'manager')
    assert sha(args.archive.read_bytes())==args.sha256 and not ROOT.exists()
    with tarfile.open(args.archive) as archive:
        members=archive.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len(members)==len({m.name for m in members})
        raw={m.name:archive.extractfile(m).read() for m in members}
    index=json.loads(raw['STAGE_SHA256.json'])
    assert set(index)==set(raw)-{'STAGE_SHA256.json'} and all(sha(raw[n])==h for n,h in index.items())
    assert sha(Path(__file__).read_bytes())==index['preparation/deploy_pj.py']
    ROOT.mkdir()
    for name,body in raw.items():
        path=ROOT/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
    if args.extract_only:
        print(json.dumps(dict(stage_sha256=args.sha256,files=len(index))));return
    remote_archive,remote_script='/tmp/numpy-baseline-resume-pj-stage.tar.gz','/tmp/deploy_resume_pj.py'
    for path in [str(ROOT),remote_archive,remote_script]:
        subprocess.run(['ssh','compute002',shlex.join(['test','!','-e',path])],check=True)
    for origin,target in [(args.archive,remote_archive),(Path(__file__),remote_script)]:
        subprocess.run(['scp',str(origin),'compute002:'+target],check=True)
    proc=subprocess.run(['ssh','compute002',shlex.join([PYTHON,'-B',remote_script,'--archive',remote_archive,
        '--sha256',args.sha256,'--extract-only'])],capture_output=True)
    (ROOT/'compute-extract.stdout').write_bytes(proc.stdout)
    (ROOT/'compute-extract.stderr').write_bytes(proc.stderr)
    assert proc.returncode==0
    # Long-lived controller logs to its own file and has no inherited interactive window.
    with (ROOT/'controller.log').open('xb') as log:
        child=subprocess.Popen([PYTHON,'-B',str(ROOT/'preparation/controller_pj.py'),'--run'],
            cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    stat=(Path('/proc')/str(child.pid)/'stat').read_text()
    ticks=int(stat[stat.rfind(')')+2:].split()[19])
    record=dict(controller_pid=child.pid,controller_start_ticks=ticks,
        controller_cmdline=(Path('/proc')/str(child.pid)/'cmdline').read_bytes().replace(b'\0',b' ').decode(),
        stage_sha256=args.sha256,deploy_pid=os.getpid(),windows_per_case=37,total_case_windows=296,
        max_concurrent_physical_jobs=8,maximum_continuation_tendencies=139776,
        terminal_stop=17520,automatic_cycle2=False,automatic_scoring=False)
    (ROOT/'LAUNCH.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))


if __name__=='__main__':main()

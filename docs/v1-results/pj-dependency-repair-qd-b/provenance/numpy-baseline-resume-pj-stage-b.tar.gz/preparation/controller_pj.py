"""Eight bounded chains; submit next same-year window only after actual closure."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import tarfile
import time
import traceback

ROOT = Path('/tmp/noahmp-numpy-baseline-resume-pj')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_bytes(js(value))
    tmp.replace(path)


def remote(argv, **kwargs):
    return subprocess.run(['ssh', 'compute002', shlex.join(argv)], check=True, **kwargs)


def capacity():
    here = os.statvfs(ROOT)
    command = "import os,json; s=os.statvfs('/tmp'); print(json.dumps(dict(available_bytes=s.f_bavail*s.f_frsize,available_inodes=s.f_favail)))"
    there = json.loads(remote([PYTHON, '-B', '-c', command], capture_output=True).stdout)
    result = dict(manager=dict(available_bytes=here.f_bavail*here.f_frsize, available_inodes=here.f_favail), compute002=there)
    assert all(v['available_bytes'] >= 12*1024**3 and v['available_inodes'] >= 20000 for v in result.values()), result
    return result


def submit(case):
    case['resource_before_submit'] = capacity()
    i, start = case['case_index'], case['steps']
    assert 48 <= start < 17520 and (start-48) % 480 == 0
    parent = ROOT / 'closed' / ('case-' + str(i)) / ('stop-' + str(start).zfill(7) + '.tar.gz')
    assert sha(parent.read_bytes()) == case['parent_archive_sha256']
    # The controller sends only the new closed window, never the large source again.
    remote(['mkdir', '-p', str(parent.parent)])
    check = subprocess.run(['ssh', 'compute002', shlex.join(['test', '-e', str(parent)])])
    if check.returncode != 0:
        subprocess.run(['scp', str(parent), 'compute002:' + str(parent)], check=True)
    remote_sha = remote(['sha256sum', str(parent)], capture_output=True).stdout.decode().split()[0]
    assert remote_sha == case['parent_archive_sha256']
    folder = ROOT / 'actual' / ('case-' + str(i)) / ('start-' + str(start).zfill(7))
    folder.mkdir(parents=True)
    env = 'PJ_CASE_INDEX=' + str(i) + ',PJ_START=' + str(start) + ',PJ_PARENT_SHA=' + case['parent_archive_sha256']
    proc = subprocess.run(['qsub', '-v', env, '-o', str(folder / 'pbs-output.log'), str(ROOT / 'preparation/window_pj.pbs')], capture_output=True)
    (folder / 'qsub.stdout').write_bytes(proc.stdout)
    (folder / 'qsub.stderr').write_bytes(proc.stderr)
    (folder / 'qsub-exit.txt').write_text(str(proc.returncode) + '\n')
    assert proc.returncode == 0, proc.stderr
    job = proc.stdout.decode().strip()
    assert re.fullmatch(r'\d+\.manager', job)
    case.update(status='running', job=job, start=start, stop=min(start+480,17520), actual_folder=str(folder),
                submitted_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    print(json.dumps(dict(event='submitted', case_index=i, job=job, start=start, stop=case['stop'])), flush=True)


def terminal(job):
    proc = subprocess.run(['qstat', '-xf', job], capture_output=True)
    if proc.returncode != 0:
        return None
    match = re.search(rb'^\s*job_state = (\w+)\s*$', proc.stdout, re.M)
    if not match or match.group(1) != b'F':
        return None
    assert re.search(rb'^Job Id: ' + re.escape(job.encode()) + rb'\s*$', proc.stdout, re.M)
    return proc.stdout, proc.stderr


def close(case, qstat, stderr):
    i, start, stop, job = case['case_index'], case['start'], case['stop'], case['job']
    folder = Path(case['actual_folder'])
    (folder / 'qstat.stdout').write_bytes(qstat)
    (folder / 'qstat.stderr').write_bytes(stderr)
    for field in ('Exit_status', 'Stageout_status'):
        assert re.search(rb'^\s*' + field.encode() + rb' = 0\s*$', qstat, re.M), 'Actual nonzero ' + field
    remote_root = ROOT / 'raw' / ('case-' + str(i)) / ('start-' + str(start))
    original = folder / 'result.tar.gz'
    remote_hash = remote(['sha256sum', str(remote_root / 'result.tar.gz')], capture_output=True).stdout.decode().split()[0]
    subprocess.run(['scp', 'compute002:' + str(remote_root / 'result.tar.gz'), str(original)], check=True)
    assert sha(original.read_bytes()) == remote_hash
    exit_raw = remote(['cat', str(remote_root / 'pbs-exit.txt')], capture_output=True).stdout
    (folder / 'pbs-exit.txt').write_bytes(exit_raw)
    assert exit_raw.strip() == b'0'
    with tarfile.open(original) as archive:
        members = [m for m in archive if m.isfile()]
        assert len(members) == len({m.name for m in members})
        raw = {m.name.removeprefix('./'): archive.extractfile(m).read() for m in members}
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in raw)
    receipt = json.loads(raw['receipt.json'])
    audit = json.loads(raw['window-audit.json'])
    run_receipt = json.loads(raw['run/receipt.json'])
    assert receipt['passed'] is True and receipt['error'] is None and receipt['source_unchanged'] is True
    assert receipt['pbs_job'] == run_receipt['pbs_job'] == job and raw['worker-exit.txt'].strip() == b'0'
    assert receipt['identity'] == case['identity'] == audit['identity']
    assert receipt['parent_archive_sha256'] == case['parent_archive_sha256']
    assert receipt['source_files'] == 584 and receipt['saved_intervals'] == receipt['full_BGC_records'] == stop
    assert receipt['start'] == start and receipt['stop'] == stop
    assert receipt['original_steps_started'] == receipt['original_steps_completed'] == stop-start
    assert receipt['controls_manifest_sha256'] == sha((ROOT / 'preparation/CONTROLS_SHA256.json').read_bytes())
    assert receipt['window_audit_sha256'] == sha(raw['window-audit.json'])
    assert receipt['run_receipt_sha256'] == sha(raw['run/receipt.json'])
    assert audit['full_seven_tuple_at_original_resume_exact']['max_abs_difference'] == 0.
    assert len(audit['original_trace_prefix_exact']) == 18 and all(v['max_abs_difference'] == 0. for v in audit['original_trace_prefix_exact'].values())
    assert audit['full_BGC_chain']['records'] == stop and audit['full_BGC_chain']['final_BGC_exact']['max_abs_difference'] == 0.
    assert all(abs(r) <= b for r,b in zip(audit['residual_m_h_c_n'],audit['bounds_m_h_c_n']))
    original_members = {n: sha(b) for n,b in raw.items()}
    term_root = 'terminals/' + job
    raw[term_root + '/qstat.stdout'] = qstat
    raw[term_root + '/parent-exit.txt'] = exit_raw
    raw[term_root + '/worker-exit.txt'] = raw['worker-exit.txt']
    terms = json.loads(raw['terminals.json'])
    assert job not in terms
    terms[job] = dict(qstat=term_root+'/qstat.stdout', parent_exit=term_root+'/parent-exit.txt', worker_exit=term_root+'/worker-exit.txt')
    raw['terminals.json'] = js(terms)
    # This record preserves the exact raw container/member identity; raw archive remains retained.
    raw['closure-records/stop-' + str(stop).zfill(7) + '.json'] = js(dict(job=job, start=start, stop=stop,
        parent_archive_sha256=case['parent_archive_sha256'], original_result_archive_sha256=remote_hash,
        original_result_members=original_members, actual_F0=True, actual_stageout0=True,
        controller_source_sha256=sha(Path(__file__).read_bytes())))
    raw['ARTIFACT_SHA256.json'] = js({n: sha(b) for n,b in sorted(raw.items()) if n != 'ARTIFACT_SHA256.json'})
    target = ROOT / 'closed' / ('case-' + str(i)) / ('stop-' + str(stop).zfill(7) + '.tar.gz')
    assert not target.exists()
    with tarfile.open(target, 'w:gz') as archive:
        for name, body in sorted(raw.items()):
            item = tarfile.TarInfo(name)
            item.size = len(body)
            archive.addfile(item, io.BytesIO(body))
    with tarfile.open(target) as archive:
        assert {m.name: archive.extractfile(m).read() for m in archive} == raw
    case['history'].append(dict(job=job,start=start,stop=stop,seconds=receipt['seconds'],
        maximum_rss_kib=receipt['maximum_rss_kib'], closed_archive_sha256=sha(target.read_bytes()),
        closed_archive_bytes=target.stat().st_size, original_result_archive_sha256=remote_hash,
        residual_m_h_c_n=audit['residual_m_h_c_n'], bounds_m_h_c_n=audit['bounds_m_h_c_n']))
    case.update(steps=stop, parent_archive_sha256=sha(target.read_bytes()), status='complete' if stop == 17520 else 'ready')
    print(json.dumps(dict(event='closed',case_index=i,job=job,steps=stop,seconds=receipt['seconds'],closed_archive_bytes=target.stat().st_size)),flush=True)


def run():
    assert socket.gethostname() == 'manager'
    assert not (ROOT / 'CONTROLLER_STARTED.json').exists(), 'Never duplicate a controller/chain'
    index = json.loads((ROOT / 'STAGE_SHA256.json').read_bytes())
    assert all(sha((ROOT/n).read_bytes()) == h for n,h in index.items())
    save(ROOT / 'CONTROLLER_STARTED.json',dict(pid=os.getpid(),source_sha256=sha(Path(__file__).read_bytes()),
        started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()), maximum_windows_per_case=37,
        stop_at=17520, automatic_retry=False, automatic_cycle2=False))
    fixed = json.loads((ROOT / 'preparation/PJ_BINDINGS.json').read_bytes())
    cases = [dict(case_index=i, identity=identity, steps=48, status='ready', history=[],
        parent_archive_sha256=fixed['initial_archives'][str(i)]['sha256']) for i,identity in enumerate(fixed['identities'])]
    while any(c['status'] in ('ready','running') for c in cases):
        for case in cases:
            try:
                if case['status'] == 'running':
                    state = terminal(case['job'])
                    if state:
                        close(case,*state)
                if case['status'] == 'ready':
                    assert len(case['history']) < 37
                    submit(case)
            except Exception as exc:
                case.update(status='stopped',error=type(exc).__name__+': '+str(exc))
                (ROOT / ('case-'+str(case['case_index'])+'-controller-error.txt')).write_text(traceback.format_exc())
                print(json.dumps(dict(event='stopped',case_index=case['case_index'],error=case['error'])),flush=True)
            save(ROOT/'PROGRESS.json',dict(cases=cases,snapshot_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
                source_manifest_sha256=fixed['source_manifest_sha256'], no_auto_retry=True,
                actual_complete_years=sum(c['steps']==17520 for c in cases),score_executed=False,auto_cycle2=False))
        if any(c['status'] in ('ready','running') for c in cases):
            time.sleep(60)
    save(ROOT/'CONTROLLER_FINISHED.json',dict(all_eight_complete=all(c['steps']==17520 for c in cases),cases=cases,
        complete_original_years=sum(c['steps']==17520 for c in cases),score_executed=False,auto_cycle2=False))
    raise SystemExit(0 if all(c['steps']==17520 for c in cases) else 1)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--run',action='store_true',required=True)
    parser.parse_args()
    run()

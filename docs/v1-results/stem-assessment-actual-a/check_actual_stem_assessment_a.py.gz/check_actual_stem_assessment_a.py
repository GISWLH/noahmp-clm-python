from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-assessment-actual-a';scratch=Path(os.environ['TMPDIR']);s=scratch/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();archive=b/'p6-stem-assessment-a-source.tar.gz';assert sha(archive)=='214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5';s.mkdir()
with tarfile.open(archive) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import assess_clm_spinup as audit
import run_fluxnet_native as native
from compare_hrldas_native_year import check_final_checkpoint,check_ledgers
a=b/'stem-station-device-e-evidence.tar.gz';assert sha(a)=='bdbeecea739eb2e23238984b0cf19b9d0e3ff40a6550b951e203d79841bc6339';data=scratch/'original';data.mkdir()
with tarfile.open(a) as t:t.extractall(data,filter='data')
report,saved,cases=native.read_generation(data/'continuous');assert report['identity']['native_state_arrays']==19 and report['identity']['source_sha256']==native.source_hashes() and len(saved)==48;rows=[]
for k,(case,trace) in enumerate(cases):
 frame=audit._frame(saved,k,report['identity']);storage=check_final_checkpoint(data/'continuous'/report['checkpoint_file'],trace,case);ledgers=check_ledgers(trace,case)
 assert frame['canopy_sai_m2m2']==trace['sai_m2m2'][-1]
 error=float(abs(frame['soil_temperature_k']-trace['tsoil_k'][-1]).max());assert error<=audit.LIMITS['soil_temperature_k']
 rows.append(dict(case=report['identity']['cases'][k]['case'],sai_m2m2=frame['canopy_sai_m2m2'],maximum_temperature_decode_difference_k=error,final_checkpoint=storage,ledgers=ledgers))
manifest=scratch/'model-source.json';native.atomic_json(manifest,m)
try:audit.assess_cycles(data/'inputs/batch.json',data/'inputs/prescribed',[data/'continuous'],manifest)
except ValueError as e:rejection=str(e);assert rejection=='Exactly one complete original forcing calendar year required'
else:raise AssertionError('Four actual steps were falsely accepted as an annual climate cycle')
value=dict(scope='Assessment instruments only, on EHPC PBS compute node. Original xuanze GPU0 actual synthetic4-step/2-column checkpoint and48 arrays are unchanged; all19 primary states/SAI aliases, original conservation ledgers and independent temperature decoding audited, full-calendar assessor explicitly rejects short trajectory. No new forward model/GPU execution or actual spinup/observational acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,original_archive_sha256=sha(a),source_archive_sha256=sha(archive),cases=rows,actual_prefix_rejection=rejection,source_unchanged=all(sha(s/n)==v for n,v in m.items()))
(r/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-assessment-actual-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'receipt.json').read_text());assert d['source_unchanged'] and len(d['cases'])==2 and (r/'pbs-exit.txt').read_text().strip()=='0';a=b/'stem-assessment-actual-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname=p.name,recursive=False)
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

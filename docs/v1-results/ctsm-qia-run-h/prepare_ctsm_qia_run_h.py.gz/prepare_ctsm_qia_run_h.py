from pathlib import Path
import ast
r=Path(__file__).resolve().parent;p=(r/'run_ctsm_qia_g.py').read_text().replace('ctsm-qia-run-g','ctsm-qia-run-h')
marker="    value['topography_time_metadata_restore']=json.loads((scratch/'topo-time-coordinate.stdout.txt').read_text())";assert p.count(marker)==1
p=p.replace(marker,marker+"\n    assert run('urban-auxiliary-point',[py,str(root/'make_ctsm_urbantv_point_b.py'),str(root/'urbantv-selection.json'),str(inputs/'CN-Qia.urbantv.1999-2001.nc')])==0\n    value['urban_auxiliary_point']=json.loads((scratch/'urban-auxiliary-point.stdout.txt').read_text())")
old='"stream_fldfilename_urbantv = \'\'"';assert p.count(old)==1;p=p.replace(old,'"stream_fldfilename_urbantv = \'"+str(inputs/\'CN-Qia.urbantv.1999-2001.nc\')+"\'", "megan_factors_file = \'"+str(inputs/\'megan21_emis_factors_78pft_c20161108.nc\')+"\'"')
ast.parse(p);(r/'run_ctsm_qia_h.py').write_text(p)
p=(r/'ctsm_qia_run_g.pbs').read_text().replace('ctsm-qia-run-g','ctsm-qia-run-h').replace('run_ctsm_qia_g.py','run_ctsm_qia_h.py').replace('clm-qia-official-g','clm-qia-official-h');(r/'ctsm_qia_run_h.pbs').write_bytes(p.encode())

from pathlib import Path
import hashlib,json,re,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-run-h';available=set();requested=None
with tarfile.open(r/'case-configuration-private.tar.gz') as t:
 for m in t:
  if m.isfile() and 'lnd.log.' in m.name:
   text=t.extractfile(m).read().decode();available.update(re.findall(r'^\s+\d+\s+([A-Za-z0-9_]+)\s+',text,re.M))
  if m.isfile() and m.name=='case/user_nl_clm':
   line=next(x for x in t.extractfile(m).read().decode().splitlines() if x.startswith('hist_fincl1'));requested=re.findall(r"'([^']+)'",line)
print(json.dumps(dict(available_count=len(available),requested=requested,missing=sorted(set(requested or [])-available),fpsn_available='FPSN' in available)),flush=True)
assert requested is not None and set(requested)-available=={'GPP'} and 'FPSN' in available
value=dict(scope='Actual H/PBS175 SP run history catalog,not all-physics source-name scan. SP does not register CN GPP/NEE; available FPSN photosynthesis diagnostic meaning must be audited before a GPP mapping.',available=sorted(available),original_requested=requested,original_missing=['GPP'],revised_requested=['FPSN' if n=='GPP' else n for n in requested]);assert set(value['revised_requested'])<=available
(r/'history-capability.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(dict(available=len(available),missing=['GPP'],revised_requested=value['revised_requested'])))
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 for m in t:
  if m.isfile() and m.name.startswith('CTSM/src/') and m.name.endswith('.F90'):
   raw=t.extractfile(m).read().decode(errors='replace');lines=raw.splitlines();wanted=set()
   for i,line in enumerate(lines):
    if re.search(r"fname\s*=\s*'FPSN'",line):wanted.update(range(max(0,i-3),min(len(lines),i+10)))
   if wanted:print(m.name,hashlib.sha256(raw.encode()).hexdigest());print('\n'.join(str(i+1)+':'+lines[i] for i in sorted(wanted)))

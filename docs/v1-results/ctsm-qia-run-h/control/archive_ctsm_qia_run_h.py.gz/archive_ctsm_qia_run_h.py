from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-qia-run-h';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'configuration.json').read_text());codes={x['stage']:x['returncode'] for x in d['stages']}
assert d['upstream_original_bytes_unchanged'] and d['official_model_returncode']==233 and codes['case-build']==codes['topo-time-coordinate']==codes['urban-auxiliary-point']==0 and (r/'pbs-exit.txt').read_text().strip()=='1'
a=b/'ctsm-qia-run-h-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.name!='case-configuration-private.tar.gz':t.add(p,arcname=p.name,recursive=False)
 with tarfile.open(r/'case-configuration-private.tar.gz') as original:
  for m in original:
   if m.isfile() and (m.name.endswith(('.stdout.txt','.stderr.txt','-adaptation.json','.stream')) or (m.name.startswith('output/case/run/') and ('.log.' in m.name or Path(m.name).name in ['datm_in','drv_in','lnd_in'])) or m.name.startswith('case/user_nl_')):
    data=original.extractfile(m).read();info=tarfile.TarInfo('workspace/'+m.name);info.size=len(data);t.addfile(info,io.BytesIO(data))
 summary=dict(scope='Actual H/PBS175 met/aerosol/topography and auxiliary input initialization completed; actual history catalog rejects CN-only GPP in SP before first physical time step. No physical time integration or scientific/annual acceptance. Static TOPO time restoration passed with all original coordinate/height values unchanged; original upstream2930 files unchanged.',codes=codes,seconds=d['seconds'],topography_restore=d['topography_time_metadata_restore'],urban_auxiliary=d['urban_auxiliary_point'],private_workspace_sha256=sha(r/'case-configuration-private.tar.gz'))
 data=(json.dumps(summary,indent=2)+'\n').encode();info=tarfile.TarInfo('summary.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
 for p in [Path(__file__),b/'inspect_original_ctsm_topo_time_a.py',b/'inspect_ctsm_urbantv_contract_a.py',b/'read_ctsm_model_failure_b.py',b/'inspect_ctsm_qia_history_h.py']:t.add(p,arcname='control/'+p.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

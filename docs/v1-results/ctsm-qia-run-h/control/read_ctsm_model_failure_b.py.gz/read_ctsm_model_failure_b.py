from pathlib import Path
import json,sys,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/sys.argv[1]
d=json.loads((r/'configuration.json').read_text());print(json.dumps({k:d.get(k) for k in ['pbs_job','failure','seconds','official_model_returncode','topography_time_metadata_restore','upstream_original_bytes_unchanged']}));print(json.dumps([dict(stage=x['stage'],returncode=x['returncode'],seconds=x['seconds']) for x in d['stages']]))
with tarfile.open(r/'case-configuration-private.tar.gz') as t:
 for m in t:
  if m.isfile() and (m.name.endswith('official-model.stderr.txt') or any(s in m.name for s in ['atm.log.','lnd.log.'])):
   print('FILE',m.name);print(t.extractfile(m).read().decode(errors='replace')[-6000:])

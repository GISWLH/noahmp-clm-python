from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile,time

assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-stem-numpy-week-a';scratch=Path(os.environ['TMPDIR'])/'qia-stem-numpy-week-a';scratch.mkdir();s=scratch/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'p6-stem-assessment-a-source.tar.gz';assert sha(a)=='214a0c3c44f523f4d9e514c135c80fb7bb799d5503b60c03c212b795d341b6c5'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items())
a=b/'qia-stem-numpy-day-a-evidence.tar.gz';assert sha(a)=='a7dfdd99e9258a626047d9361a63020563961395ef42470c53caeae9a30382b5';seed=scratch/'original-day';seed.mkdir()
with tarfile.open(a) as t:t.extractall(seed,filter='data')
old=json.loads((seed/'receipt.json').read_text());report=json.loads((seed/'trajectory/report.json').read_text());assert old['returncode']==0 and old['source_unchanged'] and report['status']=='running' and report['steps_completed']==48 and report['steps_requested']==17520 and (seed/'pbs-exit.txt').read_text().strip()=='0'
assert json.loads((seed/'SOURCE_SHA256.json').read_text())==m
assert sha(seed/'trajectory/report.json')==old['report_sha256']
for file,digest in [('model_npz','model_npz_sha256'),('checkpoint_file','checkpoint_sha256')]:assert sha(seed/'trajectory'/report[file])==report[digest]
shutil.copytree(seed/'trajectory',r/'trajectory')
inputs=b/'qia-stem-inputs-a/inputs';protocol=json.loads((b/'qia-stem-inputs-a/protocol.json').read_text());assert all(sha(inputs/n)==v for n,v in protocol['inputs_sha256'].items())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
cmd=[sys.executable,'-u',str(s/'benchmarks/run_fluxnet_column.py'),'--input',str(inputs/'CN-Qia.npz'),'--input-manifest',str(inputs/'CN-Qia.json'),'--config',str(inputs/'CN-Qia-stem-config.json'),'--output',str(r/'trajectory'),'--resume','--stop-after','288']
launch=dict(scope='Continue the successfully completed own Qia NumPy48 prefix with identical frozen source/input and original17520 request toward336 (one week). Original archived day and all old failed years remain immutable. CPU-only physics on EHPC PBS compute node,not a GPU/scientific/spinup/year pass.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),original_day_archive_sha256=sha(a),original_report_sha256=sha(seed/'trajectory/report.json'),command=cmd)
(r/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());start=time.monotonic()
with (r/'model.log').open('x') as log:code=subprocess.run(cmd,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
d=json.loads((r/'trajectory/report.json').read_text());unchanged=all(sha(s/n)==v for n,v in m.items());receipt=dict(returncode=code,source_unchanged=unchanged,seconds=time.monotonic()-start,status=d['status'],steps_completed=d['steps_completed'],steps_requested=d['steps_requested'],report_sha256=sha(r/'trajectory/report.json'),scope=launch['scope'])
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert code==0 and unchanged and d['status']=='running' and d['steps_completed']==336 and d['steps_requested']==17520

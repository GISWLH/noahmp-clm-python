from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile

b=Path('/home/zhangyq/noahmp-v1');r=b/'qia-stem-numpy-week-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (r/'receipt.json').exists() and not (r/'pbs-exit.txt').exists()
q=subprocess.run(['qstat','174.manager'],capture_output=True,text=True);assert q.returncode==0,q.stderr
launch=json.loads((r/'launch.json').read_text());raw=(r/'trajectory/report.json').read_bytes();report=json.loads(raw)
assert launch['pbs_job']=='174.manager' and launch['node']=='compute002' and report['status']=='running' and report['steps_requested']==17520 and report['steps_completed']>=48
value=dict(scope='Actual EHPC PBS174 launch/active snapshot continuing successful own NumPy48 toward336,not a completed week/year or a resumed failed year. Original archived day immutable; exact source/input/seed gates in controller and original17520 request retained.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),qstat=q.stdout,steps_committed=report['steps_completed'],original_day_archive_sha256=launch['original_day_archive_sha256'],launch_sha256=sha(r/'launch.json'))
a=b/'qia-stem-numpy-week-launch-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for name in ['run_qia_stem_numpy_week_a.py','qia_stem_numpy_week_a.pbs','node.txt','launch.json','SOURCE_SHA256.json']:t.add(r/name,arcname=name,recursive=False)
 t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
 for name,data in [('observation.json',(json.dumps(value,indent=2)+'\n').encode()),('captured-report.json',raw)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=a.name,sha256=sha(a),observation=value)))

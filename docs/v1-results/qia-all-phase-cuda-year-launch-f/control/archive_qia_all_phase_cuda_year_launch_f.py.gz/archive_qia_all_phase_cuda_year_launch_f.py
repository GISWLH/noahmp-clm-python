from pathlib import Path
import datetime,hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-all-phase-final-b';r=b/'qia-all-phase-cuda-year-f';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'launch.json').read_text());seed=r/'seed-own-e';m=json.loads((seed/'SOURCE_SHA256.json').read_text());assert json.loads((s/'SOURCE_SHA256.json').read_text())==m and all(sha(s/n)==h for n,h in m.items())
for n,h in launch['exact_copied_prefix_files'].items():assert sha(seed/n)==h
worker=json.loads((r/'worker.json').read_text());processes={}
for role,pid in [('controller',launch['pid']),('worker',worker['pid'])]:
    p=Path('/proc')/str(pid);processes[role]=dict(pid=pid,present=p.exists(),cmdline=(p/'cmdline').read_bytes().decode().split('\0') if p.exists() else None,stat=(p/'stat').read_text() if p.exists() else None)
raw_report=(r/'trajectory/batch.json').read_bytes()
summary=dict(scope='CurrentB511 CUDA-only validown48 continuation after corrected read-only26cold/nativegeneration/tracehash audit0. OriginalEparent1 only strictshadowfieldset postcheck retained in immutable1670763B archive;allcopiedinputs/checkpoint/state/trace/ledgers exact. NewF stillnotterminal/year/science/fullJAX acceptance,same_precisionNone. Scopecorrection: inherited F runreceipt text says original E error/audit1;E parent1 is real but E corrected audit actual0,no separatefailedEarrayaudit is claimed. Production physics/source/guardsunchanged.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),launch=launch,worker=worker,processes=processes,current_report=json.loads(raw_report),controls_sha256={n:sha(b/n) for n in ['run_qia_all_phase_cuda_year_f.py','control_qia_all_phase_cuda_year_f.py','launch_qia_all_phase_cuda_year_f.py']})
a=b/'qia-all-phase-cuda-year-launch-f-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():t.add(p,arcname=p.name,recursive=False)
    for n in summary['controls_sha256']:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    i=tarfile.TarInfo('captured-batch.json');i.size=len(raw_report);t.addfile(i,io.BytesIO(raw_report))
    raw=(json.dumps(summary,indent=2)+'\n').encode();i=tarfile.TarInfo('snapshot.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,steps=summary['current_report']['steps_completed'],processes=processes)))

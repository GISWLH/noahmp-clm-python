"""Collect immutable prepared inputs and compare precipitation resolutions."""
from pathlib import Path
import csv,gzip,hashlib,io,json,zipfile,tarfile
from collections import Counter
import numpy as np
root=Path.cwd();dest=root/'outputs/v1/multiyear-inputs-final';dest.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=[('CN-Cng','outputs/v1/multiyear-inputs-b'),('CN-Qia','outputs/v1/multiyear-inputs-a'),
        ('CN-Cha','outputs/v1/multiyear-inputs-a'),('CN-HaM','outputs/v1/multiyear-inputs-a')]
archives={'CN-Cng':'outputs/k6/FLX_CN-Cng_FLUXNET2015_FULLSET_2007-2010_1-4.zip',
 'CN-Qia':'outputs/v1/fluxnet-inputs/FLX_CN-Qia_FLUXNET2015_FULLSET_2003-2005_1-4.zip',
 'CN-Cha':'outputs/v1/fluxnet-inputs/FLX_CN-Cha_FLUXNET2015_FULLSET_2003-2005_1-4.zip',
 'CN-HaM':'outputs/v1/fluxnet-inputs/ICOS_CN-HaM_FLUXNET_2001-2014_322158204.zip'}
rows=[]
with tarfile.open(dest/'inputs.tar.gz','w:gz') as tar:
 for site,folder in source:
    path=root/folder/(site+'.npz');mp=path.with_suffix('.json');m=json.loads(mp.read_text())
    assert sha(path)==m['prepared_npz_sha256']
    with np.load(path,allow_pickle=False) as z:arrays=dict(z)
    labels=np.asarray([str(t)[:4] for t in arrays['time_start']]);daily=np.asarray([str(t)[:8] for t in arrays['time_start']])
    prcp=arrays['forcing'][:,7]*arrays['forcing'][:,0]*1000.
    archive=root/archives[site];assert sha(archive)==m['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        members=[n for n in z.namelist() if n.endswith('.csv') and ('_FULLSET_YY_' in n or '_FLUXMET_YY_' in n)]
        assert len(members)==1
        yyname=members[0];raw=z.read(yyname);yearrows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
        annual={r['TIMESTAMP']:float(r['P_F']) for r in yearrows}
        ddname=next(n for n in z.namelist() if n.endswith('.csv') and ('_FULLSET_DD_' in n or '_FLUXMET_DD_' in n))
        dd_raw=z.read(ddname);ddrows=list(csv.DictReader(io.StringIO(dd_raw.decode('utf-8-sig'))))
        daily_reported={r['TIMESTAMP']:float(r['P_F']) for r in ddrows}
    years=[]
    for year in sorted(set(labels)):
        keep=labels==year
        years.append({'year':int(year),'intervals':int(keep.sum()),'precipitation_hh_sum_mm':float(prcp[keep].sum()),
            'precipitation_original_yy_mm':annual[year], 'hh_minus_original_yy_mm':float(prcp[keep].sum()-annual[year]),
            'humidity_repaired_intervals':int(arrays['humidity_repaired'][keep].sum()),
            'own_qc_counts':{k:dict(Counter('missing' if not np.isfinite(v) else str(v) for v in a[keep])) for k,a in arrays.items() if k.startswith('qc_')},
            'finite_observation_intervals':{k:int(np.isfinite(a[keep]).sum()) for k,a in arrays.items() if k.startswith('obs_')}})
    # Prepared arrays have contiguous days already verified by the loader;
    # reduce by day index without reweighting precipitation units.
    days,first=np.unique(daily,return_index=True);sums=np.add.reduceat(prcp,first)
    dd=np.array([daily_reported[d] for d in days]);good=dd!=-9999.
    residual=sums[good]-dd[good]
    record={'site':site,'prepared_npz_sha256':sha(path),'prepared_manifest_sha256':sha(mp),'source_prepared_directory':folder,
        'start':m['start'],'end_exclusive':m['end_exclusive'],'steps':len(labels),'humidity_policy':m['humidity_policy'],
        'humidity_repairs':m['humidity_repairs'],'archive_sha256':m['archive_sha256'],'member_sha256':m['member_sha256'],
        'yearly_member':yyname,'yearly_member_sha256':hashlib.sha256(raw).hexdigest(),
        'daily_member':ddname,'daily_member_sha256':hashlib.sha256(dd_raw).hexdigest(),
        'precipitation_cross_resolution':{'daily_matched_count':int(good.sum()),'daily_missing_count':int((~good).sum()),
            'maximum_absolute_daily_difference_mm':float(np.max(abs(residual))),
            'maximum_absolute_annual_difference_mm':max(abs(y['hh_minus_original_yy_mm']) for y in years),
            'interpretation':'Raw HH precipitation sums versus original DD/YY P_F. Differences retained; agreement is internal aggregation evidence, not independent validation of precipitation source.'},
        'years':years}
    rows.append(record)
    (dest/(site+'-prepared.json')).write_bytes(mp.read_bytes())
    for p in [path,mp]:tar.add(p,arcname=site+p.suffix)
report={'scope':'All 24 station-years, original forcing/QC and frozen CO2/humidity preprocessing; no model score or spinup claim',
    'instrument_sha256':sha(Path(__file__)),'sites':rows,'total_intervals':sum(r['steps'] for r in rows),
    'total_station_years':sum(len(r['years']) for r in rows),'input_tar_sha256':sha(dest/'inputs.tar.gz'),
    'limitations':['CN-HaM precipitation remains unverified as a meteorological source. Internal DD/YY agreement does not resolve the high amount.',
        'Prior CN-Cng strict-policy failure remains retained. Its two finite negative-vapor-pressure rows use the already defined bounded inferred-RH interpolation; original QC is unchanged.',
        'Calibration/holdout station-year split unchanged; no year was omitted according to model skill.']}
(dest/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
for r in rows:print(r['site'],r['steps'],'repairs',len(r['humidity_repairs']),'rain min/max',min(y['precipitation_hh_sum_mm'] for y in r['years']),max(y['precipitation_hh_sum_mm'] for y in r['years']),'cross',r['precipitation_cross_resolution'],flush=True)
print('total',report['total_station_years'],report['total_intervals'],'tar',report['input_tar_sha256'],flush=True)

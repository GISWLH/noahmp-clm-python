"""Prepare every predeclared station year, without land-model scores."""
from pathlib import Path
import hashlib,json,time,traceback
import numpy as np
from fluxnet_station_data import prepare_archive
import fluxnet_station_data,fluxnet_solar
ROOT=Path.cwd();dest=ROOT/'outputs/v1/multiyear-inputs-a';dest.mkdir(exist_ok=False)
co2=ROOT/'docs/v1-results/noaa-global-co2-monthly-2000-2015.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[];started=time.monotonic()
settings=[('CN-Cng','outputs/k6/FLX_CN-Cng_FLUXNET2015_FULLSET_2007-2010_1-4.zip','2007-01-01','2011-01-01','strict'),
 ('CN-Qia','outputs/v1/fluxnet-inputs/FLX_CN-Qia_FLUXNET2015_FULLSET_2003-2005_1-4.zip','2003-01-01','2006-01-01','strict'),
 ('CN-Cha','outputs/v1/fluxnet-inputs/FLX_CN-Cha_FLUXNET2015_FULLSET_2003-2005_1-4.zip','2003-01-01','2006-01-01','rh-interpolate-3h'),
 ('CN-HaM','outputs/v1/fluxnet-inputs/ICOS_CN-HaM_FLUXNET_2001-2014_322158204.zip','2001-01-01','2015-01-01','rh-interpolate-3h')]
sources={str(Path(p).relative_to(ROOT)).replace('\\','/'):sha(p) for p in [Path(__file__).resolve(),Path(fluxnet_station_data.__file__).resolve(),Path(fluxnet_solar.__file__).resolve()]}
for site,archive,start,end,policy in settings:
    previous=ROOT/('outputs/v1/fluxnet-ham-2002-prepared.json' if site=='CN-HaM' else 'outputs/v1/height-sensitivity-a/'+site+'.json')
    prior=json.loads(previous.read_text())
    try:
        arrays,report=prepare_archive(ROOT/archive,co2_path=co2,start=start,end=end,humidity_policy=policy,
            **{k:prior[k] for k in ['latitude','longitude','utc_offset_hours']})
        assert report['archive_sha256']==prior['archive_sha256']
        assert report['member_sha256']==prior['member_sha256']
        out=dest/(site+'.npz');np.savez_compressed(out,**arrays)
        report.update(site=site,prepared_npz_sha256=sha(out),preparation_source_sha256=sources)
        (dest/(site+'.json')).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        years=[];labels=np.array([str(t)[:4] for t in arrays['time_start']])
        for year in sorted(set(labels)):
            keep=labels==year;f=arrays['forcing'][keep]
            q={k:{'zero':int(np.sum(v[keep]==0)), 'nonzero':int(np.sum(np.isfinite(v[keep])&(v[keep]!=0))),
                'missing':int(np.sum(~np.isfinite(v[keep])))} for k,v in arrays.items() if k.startswith('qc_')}
            years.append({'year':int(year),'intervals':int(keep.sum()),'precipitation_mm':float(np.sum(f[:,7]*f[:,0]*1000.)),
                'humidity_repaired_rows':int(arrays['humidity_repaired'][keep].sum()),'qc_counts':q,
                'low_sun_positive_shortwave_rows':int(np.sum(arrays['low_sun_all_diffuse'][keep]&(f[:,5]>0)))})
        row={'site':site,'status':'prepared','steps':len(arrays['time_start']),'npz_sha256':sha(out),'manifest_sha256':sha(dest/(site+'.json')),
            'archive_sha256':report['archive_sha256'],'member_sha256':report['member_sha256'],'humidity_policy':policy,
            'humidity_repairs':report['humidity_repairs'],'years':years}
        rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['years','humidity_repairs']}),flush=True)
    except Exception:
        rows.append({'site':site,'status':'failed','failure':traceback.format_exc()});print(rows[-1],flush=True)
    result={'scope':'Complete original station-year forcing preparation/QC; no model score, calibration, spinup or holdout claim',
        'source_sha256':sources,'co2_sha256':sha(co2),'seconds':time.monotonic()-started,'sites':rows}
    (dest/'preparation-report.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
assert all(sha(ROOT/p)==h for p,h in sources.items())
assert len(rows)==4 and all(r['status']=='prepared' for r in rows)

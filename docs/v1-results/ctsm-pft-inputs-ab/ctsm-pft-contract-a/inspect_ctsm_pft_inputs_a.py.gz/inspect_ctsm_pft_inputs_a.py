from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-pft-contract-a';scratch=Path(os.environ['TMPDIR'])/'pft-inspection';scratch.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
for archive,digest,dest in [(b/'ctsm-portable-env-b.tar.gz','6c535c3391287f26e49ec1089bc71c255651ab0de97983c1dc5c2b6a1e978a20',scratch/'environment'),(b/'ctsm-static-inputs-a.tar.gz','c821ed102415bddacf0fd55f7cce4e914d57ca8d02e1284437d70bc3b4ee221d',scratch)]:
 assert sha(archive)==digest;dest.mkdir(exist_ok=True)
 with tarfile.open(archive) as t:t.extractall(dest,filter='data')
script=r'''from pathlib import Path
import hashlib,json,re,tarfile
import numpy as np
from netCDF4 import Dataset,chartostring
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-pft-contract-a';cwd=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'ctsm-reference-source-bundle-a.tar.gz';assert sha(a)=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6'
with tarfile.open(a) as t:raw=t.extractfile('CTSM/src/main/pftconMod.F90').read()
expected={int(k):name.strip() for k,name in re.findall(r"expected_pftnames\((\d+)\)\s*=\s*'([^']+)'",raw.decode())};assert set(range(17))<=expected.keys()
p=cwd/'inputdata/lnd/clm2/paramdata/clm5_params.c171117.nc';assert sha(p)=='f255cceecfcdffbd44bc2a4e1fe6777193751baff30688389dd04c56029cbf0f'
with Dataset(p) as d:
 v=d.variables['pftname'];names=[str(x).strip() for x in chartostring(v[:])];assert all(names[k]==v for k,v in expected.items())
 schema=dict(dimensions={k:len(v) for k,v in d.dimensions.items()},variables={k:dict(dimensions=list(v.dimensions),units=getattr(v,'units',None)) for k,v in d.variables.items()})
 selected={}
 for key,v in d.variables.items():
  if v.dimensions==('pft',) and any(word in key.lower() for word in ['sai','slope','sla','vcmax','displ','z0','leafcn','root']):selected[key]=dict(units=getattr(v,'units',None),first17=np.ma.asarray(v[:17]).tolist())
point=json.loads((b/'ctsm-global-surface-a/point-inspection.json').read_text());assert point['source_sha256']=='276a7e886ba8c0b35233d644e300c74a7c15cdd1d3c409334b6297a001c49fde';rows=[]
# Candidate labels are inventory only; no PFT/fraction/height/SAI is adopted.
candidate={'CN-Cng':[13],'CN-Qia':[1],'CN-Cha':[1,7],'CN-HaM':[12,13]}
for site in point['sites']:
 nodes=[]
 for n in site['nodes']:
  pct=n['values']['PCT_NAT_PFT'];assert pct['dimensions']==['natpft'];fraction=np.asarray(pct['values'],float);assert fraction.shape==(15,)
  one=[]
  for k in candidate[site['site']]:
   fields={}
   for name in ['MONTHLY_LAI','MONTHLY_SAI','MONTHLY_HEIGHT_TOP','MONTHLY_HEIGHT_BOT']:
    field=n['values'][name];assert field['dimensions']==['time','lsmpft'];values=np.asarray(field['values'],float);assert values.shape==(12,17);fields[name]=values[:,k].tolist()
   one.append(dict(pft_index=k,pft_name=names[k],natural_vegetation_percent=float(fraction[k]),monthly=fields))
  nodes.append(dict(latitude=n['latitude'],longitude=n['longitude'],geometric_weight=n['weight'],dominant_pft_index=int(np.argmax(fraction)),dominant_pft_name=names[int(np.argmax(fraction))],dominant_percent=float(fraction.max()),candidates=one))
 rows.append(dict(site=site['site'],nodes=nodes))
value=dict(scope='Pinned upstream expected PFT names exactly matched actual official parameter NetCDF. Original monthly area/height series for explicit candidate PFTs and original four grid neighbors only; no categorical averaging, station parameter adoption, physical model run or scientific acceptance.',parameter_sha256=sha(p),upstream_pftcon_sha256=hashlib.sha256(raw).hexdigest(),parameter_names=names,first17_expected_names=expected,schema=schema,selected_parameters=selected,global_surface_sha256=point['source_sha256'],sites=rows)
(r/'pft-inputs.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(pfts=len(names),expected_names_matched=len(expected),sites=len(rows),parameter_fields=list(selected))))
'''
(scratch/'read.py').write_text(script);prefix=scratch/'environment';env=os.environ.copy()
for key in ['PYTHONPATH','PYTHONHOME','LD_LIBRARY_PATH']:env.pop(key,None)
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');stages=[]
for name,cmd in [('relocate',[str(prefix/'bin/python'),str(prefix/'bin/conda-unpack')]),('pft-netcdf',[str(prefix/'bin/python'),str(scratch/'read.py')])]:
 with (r/(name+'.log')).open('x') as log:code=subprocess.run(cmd,cwd=scratch,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 stages.append(dict(stage=name,returncode=code));assert code==0,name
(r/'inputs-receipt.json').write_text(json.dumps(dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,stages=stages,seconds=time.monotonic()-start,pft_inputs_sha256=sha(r/'pft-inputs.json')),indent=2)+'\n')

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');a=b/'ctsm-pft-contract-a';r=b/'ctsm-pft-contract-b';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'inputs-receipt.json').read_text());assert all(v['returncode']==0 for v in d['stages']) and (r/'inputs-pbs-exit.txt').read_text().strip()=='0' and (a/'inputs-pbs-exit.txt').read_text().strip()=='1';p=r/'pft-inputs.json';assert sha(p)==d['pft_inputs_sha256'];value=json.loads(p.read_text());rows=[]
for site in value['sites']:
 rows.append(dict(site=site['site'],dominant=[dict(name=n['dominant_pft_name'],percent=n['dominant_percent']) for n in site['nodes']],candidates=[dict(pft_index=one['pft_index'],pft_name=one['pft_name'],natveg_percent_range=[min(n['candidates'][k]['natural_vegetation_percent'] for n in site['nodes']),max(n['candidates'][k]['natural_vegetation_percent'] for n in site['nodes'])],monthly_all_neighbor_ranges={name:[min(x for n in site['nodes'] for x in n['candidates'][k]['monthly'][name]),max(x for n in site['nodes'] for x in n['candidates'][k]['monthly'][name])] for name in one['monthly']}) for k,one in enumerate(site['nodes'][0]['candidates'])]))
summary=dict(scope='Raw same-PFT neighbor/month inventory only, not adopted site parameters or causal explanation of flux errors. Candidate13 Cng;1 Qia;1+7 Cha;12/13 HaM are provisional literature/ecosystem labels, no mixed-forest fractions/alpine classification resolved.',rows=rows);(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive=b/'ctsm-pft-inputs-ab-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for folder in [a,r]:
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.name!='contract.json':t.add(p,arcname=folder.name+'/'+p.name,recursive=False)
 for n in ['inspect_ctsm_pft_contract_a.py','read_ctsm_pft_name_contract_a.py','archive_ctsm_pft_inputs_ab.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,summary=summary)))

from pathlib import Path
import hashlib,json,re,tarfile,xml.etree.ElementTree as ET
b=Path('/home/zhangyq/noahmp-v1');r=b/'ctsm-pft-contract-a';r.mkdir(exist_ok=False);a=b/'ctsm-reference-source-bundle-a.tar.gz';sha=lambda v:hashlib.sha256(v).hexdigest();assert sha(a.read_bytes())=='f97d96f23df98bd9b783d4eadb35f6ff716945a82fa55b27d9883cdcbed6e8f6';rows=[];parameter_entries=[]
with tarfile.open(a) as t:
 for m in t:
  if not m.isfile():continue
  if m.name.endswith('.F90') and ('pftcon' in m.name.lower() or 'pftvar' in m.name.lower()):
   raw=t.extractfile(m).read();lines=raw.decode().splitlines();selected=[]
   for i,line in enumerate(lines):
    if re.search(r'(?i)\b(?:ivt|nc3|nc4|nemb|nemp|nebd|numpft|pftname|pftnames|c3_grass|c4_grass|pft_type)\b',line):selected.append(dict(line=i+1,text=line.strip()))
   rows.append(dict(path=m.name,sha256=sha(raw),selected=selected))
  if 'namelist_defaults' in m.name and m.name.endswith('.xml'):
   raw=t.extractfile(m).read()
   try:tree=ET.fromstring(raw)
   except ET.ParseError:continue
   for e in tree.iter('paramfile'):parameter_entries.append(dict(source=m.name,source_sha256=sha(raw),attributes=e.attrib,path=(e.text or '').strip()))
v=dict(scope='Read-only metadata/parameter interface inspection of pinned upstream source only; no copied implementation, parameter adoption or physical model run.',source_bundle_sha256=sha(a.read_bytes()),pft_interfaces=rows,parameter_defaults=parameter_entries);(r/'contract.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(dict(files=[dict(path=x['path'],selected=x['selected'][:35]) for x in rows],parameter_defaults=parameter_entries)))

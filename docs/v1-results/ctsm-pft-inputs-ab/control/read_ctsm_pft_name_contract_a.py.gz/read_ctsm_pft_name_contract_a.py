from pathlib import Path
import json,tarfile
b=Path('/home/zhangyq/noahmp-v1')
with tarfile.open(b/'ctsm-reference-source-bundle-a.tar.gz') as t:
 raw=t.extractfile('CTSM/src/main/pftconMod.F90').read().decode()
print(json.dumps([dict(line=i+1,text=v.strip()) for i,v in enumerate(raw.splitlines()) if 'expected_pftnames(' in v and '=' in v][:85]))

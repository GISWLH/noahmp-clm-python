from pathlib import Path
import hashlib,json,subprocess,sys,time
label=sys.argv[1];assert label in ['capacity','capacity_optics'];b=Path('/home/lhwang/work/noahmp-v1');r=b/('qia-richards-'+label+'-cuda-year-c');start=time.monotonic();cmd=[sys.executable,'-u',str(b/'run_qia_cuda_prefix_u.py'),label]
with (r/'prefix-model.log').open('x') as log:p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
(r/'prefix-worker.json').write_text(json.dumps(dict(pid=p.pid,command=cmd),indent=2)+'\n');code=p.wait();path=r/'prefix-receipt.json';d=json.loads(path.read_text()) if path.exists() else {}
passed=bool(code==0 and d and d['failure'] is None and d['source_unchanged'] and d['device_barrier_complete'] and d['cold_fields_exact']==30 and d['captured_step_calls']==48 and d['status']=='running' and d['steps_completed']==48 and d['steps_requested']==17520)
record=dict(returncode=code if code else (0 if passed else 1),passed=passed,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest() if d else None,scope='Actual first48 parentexit only, completeyear17520 not reached; no failedprefix continuation or scientific acceptance.')
(r/'prefix-exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['returncode'])

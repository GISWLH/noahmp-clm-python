from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'stem-station-device-e';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'exit.json').read_text());v=json.loads((r/'receipt.json').read_text())
assert d['returncode']==0 and d['passed'] and v['failure'] is None and v['source_unchanged'] and v['result']['all_state_trace_ledger_bytes_equal'] and v['result']['full_and_split_checkpoint_arrays']==48
a=b/'stem-station-device-e-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.rglob('*')):
  if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
 for n in ['run_stem_station_device_e.py','control_stem_station_device_e.py','launch_stem_station_device_e.py','compare_stem_station_numpy_e.py','compare_stem_station_numpy_e2.py','archive_stem_device_e.py']:t.add(b/n,arcname='control/'+n,recursive=False)
 t.add(b/'p6-stem-split-e/SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

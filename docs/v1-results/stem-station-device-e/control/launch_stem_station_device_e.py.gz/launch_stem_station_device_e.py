from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-e';r=b/'stem-station-device-e';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'p6-stem-split-e-source.tar.gz';inputs=b/'stem-station-device-inputs-c.tar.gz';assert sha(a)=='a04bd6ca23058a00ca521659b8b018c4aa17d78fd127903a1156edea83d67fde' and sha(inputs)=='c1e496377c3d23660a34ed48ea50bec1ab81db9eec74371a5e4f2d2fc3d26be0' and s.exists() and not r.exists();r.mkdir()
(r/'inputs').mkdir()
with tarfile.open(inputs) as t:t.extractall(r/'inputs',filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==506 and all(sha(s/n)==v for n,v in m.items())
d=json.loads((r/'inputs/receipt.json').read_text());assert d['source_unchanged']
old=json.loads((r/'inputs/SOURCE_SHA256.json').read_text());changed=[n for n in old if old[n]!=m[n]]
assert changed==['src/noahmp_clm/gpu/clm_layered_column.py','src/noahmp_clm/gpu/cuda/clm_layered_column.py','src/noahmp_clm/gpu/cuda/clm_layered_column_kernel.cu']
for name,expected in d['files'].items():
 if name=='batch.json' or name.endswith(('/config.json','/meta.json','/forcing.npz')):assert sha(r/'inputs'/name)==expected
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='0',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'))
with (r/'controller.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'control_stem_station_device_e.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,source_archive_sha256=sha(a),input_archive_sha256=sha(inputs),scope='New506E station integration on GPU0, both physical sources and NumPy input fixtures prepared/target45 verified on EHPC. Running502 original19 and493 full validation on GPU1 untouched; no full/science claim.');(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

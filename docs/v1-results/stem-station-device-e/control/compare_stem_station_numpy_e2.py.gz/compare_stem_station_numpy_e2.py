from pathlib import Path
import hashlib,json,sys,tarfile
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-e';sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks'),str(s/'tests')]
import run_fluxnet_native as native
from test_gpu_snicar import assert_science_close
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'stem-station-cpu-c-evidence.tar.gz';assert sha(a)=='a661f25c9e4f7c79ecbc31ad4aeee43defbf891ab0f326d13fc28bf3cb585f66';r=b/'stem-station-device-e';dest=r/'numpy-comparison';dest.mkdir(exist_ok=True)
with tarfile.open(a) as t:
 for member in t:
  if member.name.startswith('stem-station-full-c/numpy-reference/') and member.isfile():t.extract(member,dest,filter='data')
report,_,cases=native.read_generation(r/'continuous');references=dest/'stem-station-full-c/numpy-reference';rows=[]
for device,got in cases:
 cfg=device['configuration'];scheme=cfg['canopy_structure']['parameters']['scheme'];matches=[p for p in references.iterdir() if json.loads((p/'config.json').read_text())['canopy_structure']['parameters']['scheme']==scheme];assert len(matches)==1;folder=matches[0]
 case='prescribed' if scheme=='PRESCRIBED' else 'cn-noncrop'
 for name in ['config.json','forcing.npz','meta.json']:assert sha(folder/name)==sha(r/'inputs'/case/name)
 p=folder/'continuous/report.json';ref=json.loads(p.read_text());assert ref['status']=='complete' and ref['steps_completed']==4;trace=folder/'continuous'/ref['model_npz'];assert sha(trace)==ref['model_npz_sha256']
 with np.load(trace,allow_pickle=False) as z:expected=dict(z)
 assert expected.keys()==got.keys();errors={}
 for trajectory in [expected,got]:
  assert np.all(abs(trajectory['step_residual_m_h_c_n'])<=trajectory['step_bound_m_h_c_n'])
  assert np.all(abs(trajectory['cumulative_residual_m_h_c_n'])<=np.cumsum(trajectory['step_bound_m_h_c_n'],axis=0))
 for key in expected:
  x=np.asarray(got[key]);y=np.asarray(expected[key]);assert x.shape==y.shape
  if key.startswith('time_'):np.testing.assert_array_equal(x,y);continue
  maximum=float(abs(x-y).max(initial=0.));errors[key]=dict(maximum_absolute=maximum)
  if key in ['dt_seconds','lai',*native.structure_trace_keys(cfg)]:assert_science_close(x,y,relative=.1,zero_floor=.0001,absolute=1e-6)
  elif key in ['h_wm2','le_wm2']:assert_science_close(x,y,relative=.1,zero_floor=10.,absolute=1.)
  elif key in ['gpp_gc_m2','nee_gc_m2','autotrophic_respiration_gc_m2','heterotrophic_respiration_gc_m2','et_mm','runoff_mm']:
   # These trace fields are per-step amounts; compare equivalent daily rates.
   with np.load(folder/'forcing.npz',allow_pickle=False) as z:dt=z['forcing'][:,0]
   x=x*86400./dt;y=y*86400./dt
   carbon=key.endswith('gc_m2');assert_science_close(x,y,relative=.1,zero_floor=1. if carbon else .5,absolute=.1 if carbon else .05)
  elif key=='tsoil_k':assert_science_close(x-273.15,y-273.15,relative=.1,zero_floor=5.,absolute=.5)
  elif key in ['smc_m3m3','liquid_m3m3']:assert_science_close(x,y,relative=.1,zero_floor=.02,absolute=.002)
  elif key=='swe_m':assert_science_close(x,y,relative=.1,zero_floor=.001,absolute=.0001)
  elif key in ['water_residual_mm','step_residual_m_h_c_n','step_bound_m_h_c_n','cumulative_residual_m_h_c_n']:pass # Independent original numerical audits are already mandatory, not 10% quantities.
  else:raise AssertionError('Unmapped trace field '+key)
 rows.append(dict(scheme=scheme,fields=errors,numpy_report_sha256=sha(p),device_report_sha256=sha(r/'continuous'/case/'report.json')))
v=dict(scope='Cross-backend engineering comparison of exact identical two synthetic structured-column inputs, four actual steps. NumPy physics ran on EHPC PBS155; device physics ran on xuanze GPU0. Fixed V1 near-zero tolerances, temperatures in Celsius, amounts compared as equivalent daily rates. Not daily/annual FLUXNET/observational acceptance. Original independent per-backend MHCN gates and all380 sameprecision tests remain separate.',passed=True,cases=rows);(r/'numpy-comparison.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))

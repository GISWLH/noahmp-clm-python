"""Read-only terminal archive of NS extraction1613; no physics or new jobs."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-ns-seasonal-input-extraction')
STAGE = Path('/tmp/ns-seasonal-input-extraction-stage.tar.gz')
STAGE_SHA = 'e9ef944fa6aa14ef30135c0fd947f2d3d332ae27569ea24ba071c3b796cbb815'
JOB = '1613.manager'
LABEL = 'ns-seasonal-input-extraction'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def contents(raw):
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for m in archive.getmembers():
            if m.isdir():
                continue
            name = m.name.removeprefix('./')
            assert m.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts and name not in files
            files[name] = archive.extractfile(m).read()
    return files


def main():
    assert socket.gethostname() == 'manager'
    dispatch = json.loads((ROOT / 'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == JOB and dispatch['stage_archive_sha256'] == STAGE_SHA
    query = subprocess.run(['qstat', '-xf', JOB], capture_output=True)
    assert query.returncode == 0
    qstat = query.stdout.decode()
    assert qstat.splitlines()[0] == 'Job Id: ' + JOB and re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
    assert re.search(r'^\s*Stageout_status = 0\s*$', qstat, re.M)
    stage_raw = STAGE.read_bytes()
    assert sha(stage_raw) == STAGE_SHA
    stage = contents(stage_raw)
    index = json.loads(stage['stage-inventory.json'])
    assert set(index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[n]) == h == sha((ROOT / n).read_bytes()) for n, h in index.items())
    status = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'pbs-exit.txt')], capture_output=True)
    assert status.returncode == 0 and int(status.stdout.strip()) == code
    fetch = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'result.tar.gz')], capture_output=True)
    assert fetch.returncode == 0
    result = contents(fetch.stdout)
    receipt = json.loads(result['receipt.json'])
    assert int(result['worker-exit.txt'].strip()) == code
    assert receipt['pbs_job'] == JOB and receipt['node'] == 'compute002'
    assert receipt['decomposition_module_steps'] == receipt['coupled_column_steps'] == receipt['gpu_steps'] == receipt['solver_calls'] == 0
    assert receipt['actual_full_year_extractions'] == 0
    if code == 0:
        assert receipt['passed'] and receipt['actual_test_count'] == 13
        assert receipt['test_parent_returncode'] == int(result['unittest-parent-exit.txt']) == 0
        assert receipt['test_timed_out'] is False
        statuses = json.loads(result['unittest-statuses.json'])
        assert len(statuses['statuses']) == 13 and all(value == 'ok' for _, value in statuses['statuses'])
        assert statuses['summary'] == [['13', str(receipt['actual_test_seconds'])]]
        assert receipt['source_before_after_584_exact'] and receipt['original_inputs_and_controls_unchanged']
        diagnostics = json.loads(result['diagnostics.json'])
        assert diagnostics['positive'] == receipt['positive_diagnostic']
        assert len(diagnostics['negative_errors']) == receipt['actual_negative_errors'] == 18
        assert diagnostics['positive']['exact_field_checks'] == 2304 and diagnostics['positive']['initial_components'] == 120
        assert diagnostics['positive']['maximum_extraction_difference'] == diagnostics['positive']['maximum_initial_component_difference'] == 0.0
        for folder in ('preparation', 'execution', 'dependencies/os', 'dependencies/oy'):
            manifest = json.loads(stage[folder + '/CONTROLS_SHA256.json'])
            assert receipt[folder.replace('/', '_') + '_manifest_sha256'] == sha(stage[folder + '/CONTROLS_SHA256.json'])
            for name in [*manifest, 'CONTROLS_SHA256.json']:
                assert result[folder + '/' + name] == stage[folder + '/' + name]
    artifacts = {'current/' + n: raw for n, raw in result.items()}
    artifacts.update({'original-stage-inventory.json': stage['stage-inventory.json'],
                      'original-stage-binding.json': (json.dumps(dict(archive=STAGE.name,
                          sha256=STAGE_SHA, bytes=len(stage_raw), members=len(stage)), indent=2) + '\n').encode(),
                      'original-result-binding.json': (json.dumps(dict(archive='result.tar.gz',
                          sha256=sha(fetch.stdout), bytes=len(fetch.stdout), files=len(result)), indent=2) + '\n').encode(),
                      'actual-pbs-qstat.txt': query.stdout, 'actual-pbs-qstat.stderr.txt': query.stderr,
                      'pbs-exit.txt': status.stdout, 'archive_ns_seasonal_extraction.py': Path(__file__).read_bytes()})
    for name in ('dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'qsub-actual-exit.json',
                 'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt'):
        artifacts['manager/' + name] = (ROOT / name).read_bytes()
    output = ROOT / 'pbs-output.log'
    artifacts['manager/pbs-output-presence.json'] = (json.dumps(dict(path=str(output), exists=output.exists(),
        note='Original controller and all child stdout/stderr retained.')) + '\n').encode()
    if output.exists():
        artifacts['manager/pbs-output.log'] = output.read_bytes()
    if code == 0:
        artifacts['RESULTS.md'] = ("# NS recorded-input extraction checks\n\n"
            "EHPC1613.manager on compute002 reached actualF0, Stageout0 and worker0. "
            "All13 extraction tests passed in " + str(receipt['actual_test_seconds']) + "s; controller " + str(receipt['seconds']) + "s.\n\n"
            "The original NP48 archive ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416 and JR archive "
            "deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b supplied the unchanged eight Cng2007/Qia2003 roots. "
            "The83-field records produced384 extracted intervals (8x48), with2304 numeric-field comparisons and120 original initial-stock components. "
            "Measured maximum differences are both0 in the respective original units; dtype/shape/value bytes are also exact. "
            "Potential plantN demand is distinct from granted uptake, and nitrogen deposition is used as an interval amount without multiplying dt again.\n\n"
            "All18 expected negative error paths were actually exercised and are retained in current/diagnostics.json and raw stdout. "
            "They include missing potential demand, bad sequence/calendar,48 presented as a full year, initial/final stock changes, bad field values/layout, "
            "unprojected or wrong-site data and inventory changes. Heldout poison was removed before mapping. "
            "The original NM584 source, NP/JR inputs and OS/OY controls remained byte-identical before/after.\n\n"
            "Decomposition steps, coupled-column steps, OS/OY solver calls and GPU steps are all0. Full-year extractions are0. "
            "These are data extraction tests, not new physical intervals, a usable initialized cold state or SOC/spinup acceptance. "
            "Future annual extraction still directly requires original NS17520/parent0 and original OD actualF0; original solver gates remain unchanged.\n").encode()
    inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in artifacts.items()}
    artifacts['inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
    dest = ROOT / (LABEL + '-evidence.tar.gz')
    assert not dest.exists()
    with tarfile.open(dest, 'w:gz') as archive:
        for name, raw in sorted(artifacts.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(raw), 0o644
            archive.addfile(member, io.BytesIO(raw))
    assert contents(dest.read_bytes()) == artifacts
    package = dict(label=LABEL, archive=dest.name, sha256=sha(dest.read_bytes()), bytes=dest.stat().st_size,
                   artifacts=len(artifacts), artifact_sha256={n: sha(raw) for n, raw in artifacts.items()},
                   pbs_job=JOB, actual_pbs_state='F', actual_pbs_exit=code, actual_stageout_status=0,
                   actual_worker_exit=int(result['worker-exit.txt']), passed=receipt['passed'],
                   actual_unittest_count=receipt.get('actual_test_count'), actual_test_seconds=receipt.get('actual_test_seconds'),
                   positive_diagnostic=receipt.get('positive_diagnostic'), actual_negative_errors=receipt.get('actual_negative_errors'),
                   stage_archive_sha256=STAGE_SHA, result_archive_sha256=sha(fetch.stdout),
                   decomposition_module_steps=0, coupled_column_steps=0, gpu_steps=0, solver_calls=0,
                   actual_full_year_extractions=0,
                   scope='Original NP48/JR8-training-root extraction checks only:13 tests,2304 exact field checks,120 original initial-stock components,18 true negative errors. No physical tendency, OS/OY solver, full year, initialized cold state or scientific acceptance.')
    (ROOT / (LABEL + '-package.json')).write_text(json.dumps(package, indent=2) + '\n')
    print(json.dumps({k: v for k, v in package.items() if k != 'artifact_sha256'}), flush=True)


if __name__ == '__main__':
    main()

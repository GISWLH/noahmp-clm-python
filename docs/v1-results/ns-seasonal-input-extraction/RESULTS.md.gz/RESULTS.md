# NS recorded-input extraction checks

EHPC1613.manager on compute002 reached actualF0, Stageout0 and worker0. All13 extraction tests passed in 2.658s; controller 3.0818343160208315s.

The original NP48 archive ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416 and JR archive deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b supplied the unchanged eight Cng2007/Qia2003 roots. The83-field records produced384 extracted intervals (8x48), with2304 numeric-field comparisons and120 original initial-stock components. Measured maximum differences are both0 in the respective original units; dtype/shape/value bytes are also exact. Potential plantN demand is distinct from granted uptake, and nitrogen deposition is used as an interval amount without multiplying dt again.

All18 expected negative error paths were actually exercised and are retained in current/diagnostics.json and raw stdout. They include missing potential demand, bad sequence/calendar,48 presented as a full year, initial/final stock changes, bad field values/layout, unprojected or wrong-site data and inventory changes. Heldout poison was removed before mapping. The original NM584 source, NP/JR inputs and OS/OY controls remained byte-identical before/after.

Decomposition steps, coupled-column steps, OS/OY solver calls and GPU steps are all0. Full-year extractions are0. These are data extraction tests, not new physical intervals, a usable initialized cold state or SOC/spinup acceptance. Future annual extraction still directly requires original NS17520/parent0 and original OD actualF0; original solver gates remain unchanged.

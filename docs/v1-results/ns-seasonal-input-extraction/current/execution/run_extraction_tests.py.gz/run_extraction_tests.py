"""One-shot EHPC original NP48 extraction tests; no physical/solver calls."""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-ns-seasonal-input-extraction')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    assert sys.version_info >= (3, 10) and os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    result = Path(sys.argv[1]).resolve()
    assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
    result.mkdir()
    began = time.monotonic()
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), python=sys.version,
        python_executable=sys.executable, passed=False, error=None, decomposition_module_steps=0,
        coupled_column_steps=0, gpu_steps=0, solver_calls=0, actual_full_year_extractions=0)
    try:
        inventory = json.loads((STAGE/'stage-inventory.json').read_bytes())
        assert all(sha((STAGE/n).read_bytes()) == h for n, h in inventory.items())
        run = json.loads((STAGE/'execution/RUN_BINDINGS.json').read_bytes())
        assert run['authorized'] is True and run['expected_tests'] == 13
        for folder, expected, count in [('preparation', run['preparation_manifest_sha256'], 4),
                                         ('execution', None, 4), ('dependencies/os', None, 8),
                                         ('dependencies/oy', None, 4)]:
            raw = (STAGE/folder/'CONTROLS_SHA256.json').read_bytes()
            index = json.loads(raw)
            assert len(index) == count and (expected is None or sha(raw) == expected)
            assert all(sha((STAGE/folder/n).read_bytes()) == h for n, h in index.items())
            dest = result/folder
            dest.mkdir(parents=True)
            for n in [*index, 'CONTROLS_SHA256.json']:
                shutil.copyfile(STAGE/folder/n, dest/n)
            receipt[folder.replace('/', '_') + '_manifest_sha256'] = sha(raw)
        shutil.copyfile(STAGE/'preparation/STATIC_CHECK.json', result/'preparation/STATIC_CHECK.json')
        shutil.copyfile(STAGE/'execution/preparation-diagnostic-diff.txt', result/'execution/preparation-diagnostic-diff.txt')
        fixed = json.loads((result/'preparation/BINDINGS.json').read_bytes())
        for label in ('np48', 'jr', 'source'):
            spec = run['inputs'][label]
            assert sha((STAGE/'inputs'/spec['file']).read_bytes()) == spec['sha256']
        assert run['inputs']['np48']['sha256'] == fixed['original_np48_archive_sha256']
        assert run['inputs']['jr']['sha256'] == fixed['original_jr_archive_sha256']
        assert run['inputs']['source']['sha256'] == fixed['source_archive_sha256']
        source = result.parent/'source-nm584'
        source.mkdir()
        with tarfile.open(STAGE/'inputs'/run['inputs']['source']['file']) as t:
            members = t.getmembers()
            assert len(members) == len({m.name for m in members}) == 585
            assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
            raw = t.extractfile('SOURCE_SHA256.json').read()
            assert sha(raw) == fixed['source_manifest_sha256']
            manifest = json.loads(raw)
            assert len(manifest) == 584 and {m.name for m in members} == set(manifest) | {'SOURCE_SHA256.json'}
            for n in [*manifest, 'SOURCE_SHA256.json']:
                data = t.extractfile(n).read()
                assert n == 'SOURCE_SHA256.json' or sha(data) == manifest[n]
                dest = source/n
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
        (result/'SOURCE_SHA256.json').write_bytes(raw)
        assert all(sha((source/n).read_bytes()) == h for n, h in manifest.items())
        work = result/'preparation'
        tree = ast.parse((work/'test_extract_ns_seasonal.py').read_bytes())
        expected_tests = {n.name + ' (test_extract_ns_seasonal.' + cls.name + '.' + n.name + ')'
            for cls in tree.body if isinstance(cls, ast.ClassDef)
            for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
        assert len(expected_tests) == 13
        env = os.environ.copy()
        env.pop('PYTHONHOME', None)
        env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
            MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='',
            PYTHONPATH=os.pathsep.join(['/home/zhangyq/noahmp-v1/test-deps', str(source), str(source/'src'), str(source/'benchmarks')]),
            EXTRACT_OS_CONTROLS=str(result/'dependencies/os'), EXTRACT_OY_CONTROLS=str(result/'dependencies/oy'),
            EXTRACT_NP48_ARCHIVE=str(STAGE/'inputs'/run['inputs']['np48']['file']),
            EXTRACT_JR_ARCHIVE=str(STAGE/'inputs'/run['inputs']['jr']['file']))
        command = [sys.executable, '-B', '-m', 'unittest', '-v', 'test_extract_ns_seasonal']
        save(result/'unittest-command.json', dict(argv=command, cwd=str(work),
            environment={k: env[k] for k in ('PYTHONPATH', 'EXTRACT_OS_CONTROLS', 'EXTRACT_OY_CONTROLS', 'EXTRACT_NP48_ARCHIVE', 'EXTRACT_JR_ARCHIVE')}))
        tick = time.monotonic()
        with (result/'unittest.stdout.txt').open('w') as out, (result/'unittest.stderr.txt').open('w') as err:
            proc = subprocess.Popen(command, cwd=work, env=env, stdout=out, stderr=err)
            try:
                code = proc.wait(timeout=max(1., 510.-(time.monotonic()-began)))
                timeout = False
            except subprocess.TimeoutExpired:
                proc.kill(); code = proc.wait(); timeout = True
        receipt.update(test_parent_returncode=code, test_timed_out=timeout, child_pid=proc.pid,
                       test_controller_seconds=time.monotonic()-tick)
        (result/'unittest-parent-exit.txt').write_text(str(code)+'\n')
        stderr = (result/'unittest.stderr.txt').read_text()
        statuses = re.findall(r'^(test_\w+ \(test_extract_ns_seasonal\.\w+\.test_\w+\)) \.\.\. (.+)$', stderr, re.M)
        summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M)
        save(result/'unittest-statuses.json', dict(statuses=statuses, summary=summary,
            parent_returncode=code, timed_out=timeout))
        assert code == 0 and timeout is False, 'Tests failed; raw logs retained'
        assert len(statuses) == 13 and {n for n, _ in statuses} == expected_tests and all(s == 'ok' for _, s in statuses)
        assert len(summary) == 1 and summary[0][0] == '13' and re.findall(r'^OK.*$', stderr, re.M) == ['OK']
        assert not re.search(r'^(?:FAIL|ERROR|UNEXPECTED SUCCESS):|^FAILED\b', stderr, re.M)
        stdout = (result/'unittest.stdout.txt').read_text().splitlines()
        diagnostics = [json.loads(line.removeprefix('EXTRACT_DIAGNOSTIC ')) for line in stdout if line.startswith('EXTRACT_DIAGNOSTIC ')]
        negatives = [json.loads(line.removeprefix('EXTRACT_NEGATIVE ')) for line in stdout if line.startswith('EXTRACT_NEGATIVE ')]
        assert len(diagnostics) == 1 and len(negatives) == 18
        d = diagnostics[0]
        assert d['np48_sha256'] == fixed['original_np48_archive_sha256']
        assert d['exact_field_checks'] == 2304 and d['initial_components'] == 120
        assert d['maximum_extraction_difference'] == d['maximum_initial_component_difference'] == 0.0
        assert d['original_row_fields'] == 83 and d['intervals_per_case'] == 48 and len(d['selected_cases']) == 8
        assert not d['complete_calendar_year'] and d['decomposition_module_steps'] == d['coupled_column_steps'] == d['gpu_steps'] == d['solver_calls'] == 0
        save(result/'diagnostics.json', dict(positive=d, negative_errors=negatives))
        assert all(sha((source/n).read_bytes()) == h for n, h in manifest.items())
        assert all(sha((STAGE/n).read_bytes()) == h for n, h in inventory.items())
        for folder in ('preparation', 'execution', 'dependencies/os', 'dependencies/oy'):
            m = json.loads((result/folder/'CONTROLS_SHA256.json').read_bytes())
            assert all(sha((result/folder/n).read_bytes()) == h for n, h in m.items())
        receipt.update(passed=True, actual_test_count=13, actual_test_seconds=float(summary[0][1]),
            source_before_after_584_exact=True, original_inputs_and_controls_unchanged=True,
            source_manifest_sha256=fixed['source_manifest_sha256'], source_archive_sha256=fixed['source_archive_sha256'],
            np48_archive_sha256=fixed['original_np48_archive_sha256'], jr_archive_sha256=fixed['original_jr_archive_sha256'],
            positive_diagnostic=d, actual_negative_errors=len(negatives), actual_extracted_training_intervals=384)
    except Exception as error:
        receipt['error'] = type(error).__name__+': '+str(error)
        (result/'traceback.txt').write_text(traceback.format_exc())
    receipt['seconds'] = time.monotonic()-began
    save(result/'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()

"""Authenticated NS records to prescribed OS/OY inputs; never advance physics."""
from pathlib import Path
import hashlib
import io
import json
import tarfile
import numpy as np

from training_stream_os import select_registry, selected_records, verify_closed_od
from soc_operator_os import require, validate_year
from normal_cn_replay_oy import validate_schedule

JR_SHA = 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
NP_SHA = 'ebc6f9f56aba76cf9e7ceba2c4d51b2b7823aea598237fc2133689963db5a416'
MAP = {
    'temperature_k': 'bgc/environment/soil_temperature',
    'water_potential_mpa': 'bgc/environment/water_potential_mpa',
    'litter_carbon_gc_m2': 'bgc/turnover/litter_carbon_gc_m2',
    'litter_nitrogen_gn_m2': 'bgc/turnover/litter_nitrogen_gn_m2',
    'mineral_n_input_gn_m2': 'nitrogen',
    'plant_n_demand_gn_m2': 'bgc/allocation/soil_n_demand_gn_m2',
}
INPUT_KEYS = ('forcing', 'environment', 'time_start', 'time_end')
TRACE_KEYS = ('time_start', 'time_end', 'gpp_gc_m2', 'autotrophic_respiration_gc_m2',
              'heterotrophic_respiration_gc_m2', 'nee_gc_m2')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def exact(a, b, label):
    a, b = np.asarray(a), np.asarray(b)
    require(a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes(), label)


def arrays(raw, keys):
    """Decode only named payloads; observation fields are never requested."""
    with np.load(io.BytesIO(raw), allow_pickle=False) as z:
        require(set(keys) <= set(z.files), 'Missing required NPZ member')
        return {key: z[key] for key in keys}


def load_training_inputs(jr_raw, expected_files, identity):
    """All34 original files hashed opaquely; only two sites' four input keys decoded."""
    require(sha(jr_raw) == JR_SHA, 'Original JR input archive required')
    with tarfile.open(fileobj=io.BytesIO(jr_raw)) as t:
        names = t.getnames()
        require(len(names) == len(set(names)) == 34 and all(m.isfile() for m in t), 'JR member schema')
        raw = {n: t.extractfile(n).read() for n in names}
    require(set(raw) == set(expected_files) and all(sha(v) == expected_files[n] for n, v in raw.items()), 'JR file identity')
    batch, protocol = json.loads(raw['batch.json']), json.loads(raw['protocol.json'])
    require(sha(raw['batch.json']) == identity['batch_sha256'] == protocol['batch_sha256'], 'Batch identity')
    rows = batch['cases']
    require([r['case'] for r in rows] == [r['case'] for r in protocol['cases']] ==
            [r['case'] for r in identity['cases']], 'Original all12 order')
    registry = []
    for row, item, prior in zip(rows, identity['cases'], protocol['cases']):
        for field, pathkey in [('forcing_npz_sha256', 'input'), ('forcing_manifest_sha256', 'input_manifest'),
                               ('configuration_sha256', 'configuration')]:
            require(sha(raw[row[pathkey]]) == item[field], 'Original input/config hash')
        require(item['configuration_sha256'] == prior['configuration_sha256'], 'Protocol config hash')
        registry.append(dict(case=row['case'], config=json.loads(raw[row['configuration']])))
    selected = select_registry(registry)
    loaded, cache = [], {}
    for k in selected:
        row, c = rows[k], registry[k]
        if row['input'] not in cache:
            cache[row['input']] = arrays(raw[row['input']], INPUT_KEYS)
        data = cache[row['input']]
        year = 2007 if c['config']['site'] == 'CN-Cng' else 2003
        validate_year(data['time_start'], data['time_end'], year)
        require(data['forcing'].shape[0] == data['environment'].shape[0] == 17520, 'Complete original forcing')
        loaded.append(dict(case=c['case'], config=c['config'], data=data))
    return registry, selected, loaded


def select_state(raw, selected):
    values = arrays(raw, ('a11', 'a13'))
    for key, shape in [('a11', (12, 8)), ('a13', (12, 15))]:
        require(values[key].shape == shape and values[key].dtype == np.dtype('float32'), 'Original state layout')
    return {key: np.take(value, selected, axis=0) for key, value in values.items()}


def map_interval(row, loaded, index):
    """Six recorded quantities, copied without unit conversion or inferred N."""
    require(len(loaded) == 8, 'Exactly eight training roots')
    forcing = np.asarray([c['data']['forcing'][index] for c in loaded], np.float32)
    exact(row['forcing'], forcing, 'Original forcing mismatch')
    require(np.all(forcing[:, 0] == np.float32(1800)), 'Normal1800s required')
    exact(row['nitrogen'], row['bgc/nitrogen_deposition_gn_m2'], 'Recorded N deposition mismatch')
    for target, source in MAP.items():
        value = np.asarray(row[source])
        shape = (8, 7) if target.startswith('litter_') else (8,)
        require(value.shape == shape and value.dtype == np.dtype('float32'), 'Recorded field layout: ' + source)
        require(np.isfinite(value).all(), 'Nonfinite field: ' + source)
        if target not in ('temperature_k', 'water_potential_mpa'):
            require(np.all(value >= 0), 'Negative amount: ' + source)
    result = []
    for k, c in enumerate(loaded):
        item = {target: np.asarray(row[source])[k].copy() for target, source in MAP.items()}
        item.update(time_start=str(c['data']['time_start'][index]), time_end=str(c['data']['time_end'][index]))
        result.append(item)
    return result


def _collect_inputs(records, loaded, cold, final, steps):
    """Pure extraction/chain check; short48 is a prefix, never an annual claim."""
    require(steps in (48, 17520), 'Only original cold48 or complete NS year')
    require(len(loaded) == 8 and len({c['case'] for c in loaded}) == 8, 'Training roots/order')
    for c in loaded:
        require(c['config']['site'] in ('CN-Cng', 'CN-Qia') and c['case'] == c['config']['case'], 'Training-only case')
    for state in (cold, final):
        for name, shape in [('a11', (8, 8)), ('a13', (8, 15))]:
            a = np.asarray(state[name])
            require(a.shape == shape and a.dtype == np.dtype('float32') and np.isfinite(a).all() and np.all(a >= 0), 'Selected state layout')
    previous = cold
    cases = [dict(case=c['case'], initial=dict(carbon_gc_m2=cold['a13'][k, :7].copy(),
                 organic_nitrogen_gn_m2=cold['a13'][k, 7:14].copy(),
                 mineral_nitrogen_gn_m2=cold['a13'][k, 14].copy()), records=[]) for k, c in enumerate(loaded)]
    count, schema = 0, None
    for index, row in records:
        require(index == count and count < steps, 'Gap/duplicate/reordered/extra interval')
        require(all(np.asarray(v).ndim >= 1 and np.asarray(v).shape[0] == 8 for v in row.values()), 'Projected eight-column stream required')
        current_schema = tuple(sorted(row))
        require(schema is None or current_schema == schema, 'BGC record schema changed')
        schema = current_schema
        for key, part in [('a11', 'plant'), ('a13', 'soil_cn')]:
            exact(row['before_' + part], previous[key], 'Original before/after chain: ' + part)
        for case, record in zip(cases, map_interval(row, loaded, index)):
            case['records'].append(record)
        previous = {'a11': row['after_plant'], 'a13': row['after_soil_cn']}
        count += 1
    require(count == steps, 'Truncated stream')
    for key in ('a11', 'a13'):
        exact(previous[key], final[key], 'Final original checkpoint mismatch')
    for case in cases:
        validate_schedule(case['records'], expected_year=int(case['records'][0]['time_start'][:4]) if steps == 17520 else None)
    return dict(cases=cases, intervals_per_case=steps, record_fields=list(schema),
                record_field_count=len(schema), training_intervals_extracted=steps*8,
                complete_calendar_year=steps == 17520, decomposition_module_steps=0,
                coupled_column_steps=0, gpu_steps=0, initializer_exported=False,
                scientific_acceptance_claim=False)


class BoundFiles:
    """Only verifies the existing OD inventory, without a new provenance format."""
    def __init__(self, root, inventory):
        self.root, self.inventory, self.used = Path(root).resolve(), inventory, {}

    def path(self, name):
        path = (self.root / name).resolve()
        require(path.is_relative_to(self.root) and name in self.inventory and not path.is_symlink(), 'Unbound member path')
        require(sha(path.read_bytes()) == self.inventory[name], 'Extracted member hash mismatch: ' + name)
        self.used[name] = self.inventory[name]
        return path

    def read(self, name):
        raw = self.path(name).read_bytes()
        require(sha(raw) == self.inventory[name], 'Member changed during read')
        return raw

    def recheck(self):
        for name in list(self.used):
            self.path(name)


def extract_closed_year(*, device_root, device_archive, device_packet, od_archive,
                        od_package, dispatch, qstat, pbs_exit, source_root):
    """Future complete actual NS+OD only; directly reuse the original closure gate.

    No invented terminal identity or extra human approval flag. This entry never
    calls OS matrices, OY replay, a physical tendency, observations or a scorer.
    Existing OS/OY production solver gates remain unchanged and disabled.
    """
    proof = verify_closed_od(device_archive=device_archive, device_packet=device_packet,
        od_archive=od_archive, od_package=od_package, dispatch=dispatch, qstat=qstat,
        pbs_exit=pbs_exit, source_root=source_root)
    with tarfile.open(device_archive) as t:
        inventory = json.load(t.extractfile('ARTIFACT_SHA256.json'))
    files = BoundFiles(device_root, inventory)
    batch = json.loads(files.read('current/trajectory/batch.json'))
    reuse = json.loads(files.read('original-prefix-control/reference-reuse.json'))
    package = json.loads(files.read('frozen-inputs/package.json'))
    jr_raw = files.read('frozen-inputs/' + package['archive'])
    require(package['archive_sha256'] == JR_SHA, 'Original JR package')
    registry, selected, loaded = load_training_inputs(jr_raw, reuse['every_input_file_sha256'], batch['identity'])
    cold_names = [n for n in inventory if n.startswith('current/trajectory/state-0000000-') and n.endswith('.npz')]
    require(len(cold_names) == 1, 'Unique original cold generation')
    cold = select_state(files.read(cold_names[0]), selected)
    final_name = 'current/trajectory/' + batch['checkpoint_file']
    final = select_state(files.read(final_name), selected)
    require(inventory[final_name] == batch['checkpoint_sha256'], 'Final checkpoint identity')
    traces = []
    for c in loaded:
        descriptor = batch['case_reports'][c['case']]
        base = 'current/trajectory/' + c['case'] + '/'
        report_raw = files.read(base + descriptor['file'])
        require(sha(report_raw) == descriptor['sha256'], 'Case report identity')
        report = json.loads(report_raw)
        trace_raw = files.read(base + report['model_npz'])
        require(sha(trace_raw) == report['model_npz_sha256'] and report['configuration'] == c['config'], 'Trace/config identity')
        trace = arrays(trace_raw, TRACE_KEYS)
        for name in ('time_start', 'time_end'):
            exact(trace[name], c['data'][name], 'Trace/input calendar')
        traces.append(trace)
    for i in range(48):
        files.path('current/steps/call-' + str(i).zfill(5) + '.npz')
    for chunk in proof['year_receipt']['bgc_diagnostic_chunks']:
        name = 'current/year-bgc-diagnostics/steps-' + str(chunk['first']).zfill(7) + '-' + str(chunk['end']).zfill(7) + '.npz'
        require(inventory[name] == chunk['sha256'], 'Chunk receipt/inventory mismatch')
        files.path(name)
    result = _collect_inputs(selected_records(Path(device_root)/'current', proof['year_receipt'], selected),
                             loaded, cold, final, 17520)
    files.recheck()
    require(sha(Path(device_archive).read_bytes()) == device_packet['sha256'], 'Device archive changed')
    source = Path(source_root)
    source_manifest = json.loads((source/'SOURCE_SHA256.json').read_bytes())
    require(sha((source/'SOURCE_SHA256.json').read_bytes()) == proof['source_manifest_sha256'] and
            all(sha((source/n).read_bytes()) == h for n, h in source_manifest.items()), 'NM source changed')
    proof = dict(proof, production_extraction_bound=True)
    result.update(proof=proof, registry=registry, selected=selected, loaded_training=loaded,
                  cold_training=cold, final_training=final, traces_training=traces,
                  extracted_member_sha256=dict(files.used), source_fields=dict(MAP),
                  all12_integrity_credit='Unchanged original OD actual F0, whole inventory, NS parent0 and original NP48',
                  raw_container_boundary='Only hashes and column projection touch all12 containers. No Cha/HaM numerical arrays, observations or scores enter analysis.')
    return result

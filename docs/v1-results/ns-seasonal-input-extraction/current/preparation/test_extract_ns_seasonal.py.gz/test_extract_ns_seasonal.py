"""EHPC-only original NP48 extraction tests; no tendencies or seasonal solvers."""
from pathlib import Path
import copy
from contextlib import contextmanager
import hashlib
import json
import os
import socket
import sys
import tarfile
import tempfile
import unittest


def setUpModule():
    if not os.environ.get('PBS_JOBID') or not socket.gethostname().startswith('compute002'):
        raise RuntimeError('Numerical array extraction tests require an EHPC compute002 PBS job')
    here = Path(__file__).resolve().parent
    bindings = json.loads((here/'BINDINGS.json').read_bytes())
    for env, manifest in bindings['dependency_controls'].items():
        folder = Path(os.environ[env])
        for name, digest in manifest.items():
            if hashlib.sha256((folder/name).read_bytes()).hexdigest() != digest:
                raise RuntimeError('Frozen dependency changed: ' + name)
        sys.path.insert(0, str(folder))
    sys.path.insert(0, str(here))


class ExtractionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import numpy as np
        import extract_ns_seasonal as a
        from audit_bgc_stream_km_original import cold_rows
        from training_stream_os import project_row
        cls.np, cls.a = np, a
        cls.tmp = tempfile.TemporaryDirectory(dir=os.environ['TMPDIR'])
        root = Path(cls.tmp.name)
        archive = Path(os.environ['EXTRACT_NP48_ARCHIVE'])
        cls.archive_sha = a.sha(archive.read_bytes())
        if cls.archive_sha != a.NP_SHA:
            raise RuntimeError('Exact original successful NP48 archive required')
        with tarfile.open(archive) as t:
            if len(t.getnames()) != 183 or any(not m.isfile() for m in t):
                raise RuntimeError('Original NP48 member schema')
            t.extractall(root, filter='data')
        cls.current = root/'current'
        batch = json.loads((cls.current/'trajectory/batch.json').read_bytes())
        receipt = json.loads((cls.current/'receipt.json').read_bytes())
        parent = json.loads((cls.current/'exit.json').read_bytes())
        if not (parent['passed'] and parent['actual_parent_returncode'] == 0 and
                receipt['steps_completed'] == 48 and receipt['device_barrier_complete'] and
                receipt['failure'] is None and receipt['source_unchanged']):
            raise RuntimeError('Original actual NP48 parent/receipt')
        if parent['receipt_sha256'] != a.sha((cls.current/'receipt.json').read_bytes()):
            raise RuntimeError('Original parent/receipt hash')
        reuse = json.loads((root/'control/reference-reuse.json').read_bytes())
        cls.registry, cls.selected, cls.loaded = a.load_training_inputs(
            Path(os.environ['EXTRACT_JR_ARCHIVE']).read_bytes(), reuse['every_input_file_sha256'], batch['identity'])
        cold, = (cls.current/'trajectory').glob('state-0000000-*.npz')
        cls.cold = a.select_state(cold.read_bytes(), cls.selected)
        cls.final = a.select_state((cls.current/'trajectory'/batch['checkpoint_file']).read_bytes(), cls.selected)
        cls.rows = [(i, project_row(row, cls.selected)) for i, row in cold_rows(cls.current)]

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    @contextmanager
    def expect_error(self, exception, pattern=None):
        check = self.assertRaises(exception) if pattern is None else self.assertRaisesRegex(exception, pattern)
        with check as caught:
            yield
        print('EXTRACT_NEGATIVE ' + json.dumps(dict(test=self.id(),
            error_type=type(caught.exception).__name__, message=str(caught.exception))), flush=True)

    def collect(self, rows=None, cold=None, final=None, loaded=None, steps=48):
        return self.a._collect_inputs(self.rows if rows is None else rows,
            self.loaded if loaded is None else loaded, self.cold if cold is None else cold,
            self.final if final is None else final, steps)

    def test_original_48_all_eight_roots_and_each_mapped_value_bitexact(self):
        result = self.collect()
        self.assertEqual(self.selected, list(range(8)))
        self.assertEqual(result['record_field_count'], 83)
        self.assertEqual(result['training_intervals_extracted'], 384)
        self.assertFalse(result['complete_calendar_year'])
        field_max = initial_max = 0.0
        for k, case in enumerate(result['cases']):
            self.assertEqual(case['case'], self.loaded[k]['case'])
            for key, value in [('carbon_gc_m2', self.cold['a13'][k, :7]),
                               ('organic_nitrogen_gn_m2', self.cold['a13'][k, 7:14]),
                               ('mineral_nitrogen_gn_m2', self.cold['a13'][k, 14])]:
                self.a.exact(case['initial'][key], value, 'Original initial stock')
                initial_max = max(initial_max, float(self.np.max(self.np.abs(self.np.asarray(case['initial'][key], self.np.float64)-self.np.asarray(value, self.np.float64)))))
            for i, item in enumerate(case['records']):
                self.assertEqual(set(item), set(self.a.MAP) | {'time_start', 'time_end'})
                for target, source in self.a.MAP.items():
                    value = self.rows[i][1][source][k]
                    self.a.exact(item[target], value, 'Raw mapped value')
                    field_max = max(field_max, float(self.np.max(self.np.abs(self.np.asarray(item[target], self.np.float64)-self.np.asarray(value, self.np.float64)))))
        print('EXTRACT_DIAGNOSTIC ' + json.dumps(dict(np48_sha256=self.archive_sha,
            selected_cases=[c['case'] for c in result['cases']], intervals_per_case=48,
            original_row_fields=83, mapped_numeric_fields=6, exact_field_checks=48*8*6,
            initial_components=8*15, maximum_extraction_difference=field_max,
            maximum_initial_component_difference=initial_max,
            complete_calendar_year=False, decomposition_module_steps=0,
            coupled_column_steps=0, gpu_steps=0, solver_calls=0)), flush=True)

    def test_demand_is_potential_and_deposition_is_amount_without_dt_scaling(self):
        row = copy.deepcopy(self.rows[0][1])
        row['bgc/allocation/soil_n_demand_gn_m2'][:] = self.np.float32(.25)
        row['bgc/allocation/soil_n_uptake_gn_m2'][:] = self.np.float32(.03125)
        row['bgc/decomposition/plant_uptake_gn_m2'][:] = self.np.float32(.03125)
        row['nitrogen'][:] = self.np.float32(.125)
        row['bgc/nitrogen_deposition_gn_m2'][:] = self.np.float32(.125)
        for item in self.a.map_interval(row, self.loaded, 0):
            self.assertEqual(float(item['plant_n_demand_gn_m2']), .25)
            self.assertEqual(float(item['mineral_n_input_gn_m2']), .125)

    def test_missing_potential_demand_cannot_fall_back_to_uptake(self):
        row = copy.deepcopy(self.rows[0][1])
        del row['bgc/allocation/soil_n_demand_gn_m2']
        with self.expect_error(KeyError):
            self.a.map_interval(row, self.loaded, 0)

    def test_record_index_gap_duplicate_and_order_rejected(self):
        for first in [1, -1]:
            with self.expect_error(ValueError, 'interval'):
                self.collect([(first, self.rows[0][1])])
        with self.expect_error(ValueError, 'interval'):
            self.collect([self.rows[0], self.rows[0]])

    def test_partial_prefix_or_prefix_presented_as_full_year_rejected(self):
        with self.expect_error(ValueError, 'Truncated'):
            self.collect(self.rows[:-1])
        with self.expect_error(ValueError, 'Truncated'):
            self.collect(steps=17520)

    def test_changed_initial_stock_is_not_replaced_or_broadcast(self):
        cold = copy.deepcopy(self.cold)
        cold['a13'][0, 14] = self.np.nextafter(cold['a13'][0, 14], self.np.float32('inf'))
        with self.expect_error(ValueError, 'chain'):
            self.collect(cold=cold)

    def test_changed_final_checkpoint_rejected(self):
        final = copy.deepcopy(self.final)
        final['a13'][0, 0] = self.np.nextafter(final['a13'][0, 0], self.np.float32('inf'))
        with self.expect_error(ValueError, 'Final'):
            self.collect(final=final)

    def test_bad_shape_dtype_negative_and_nonfinite_amounts_rejected(self):
        name = 'bgc/turnover/litter_nitrogen_gn_m2'
        for value in [self.np.zeros((8, 6), self.np.float32), self.np.zeros((8, 7), self.np.float64),
                      self.np.full((8, 7), -1, self.np.float32), self.np.full((8, 7), self.np.nan, self.np.float32)]:
            row = copy.deepcopy(self.rows[0][1]); row[name] = value
            with self.expect_error(ValueError):
                self.a.map_interval(row, self.loaded, 0)

    def test_calendar_gap_rejected_without_fill(self):
        loaded = copy.deepcopy(self.loaded)
        loaded[0]['data']['time_start'][1] = loaded[0]['data']['time_start'][2]
        with self.expect_error(ValueError, '1800|contiguous'):
            self.collect(loaded=loaded)

    def test_non1800_forcing_cannot_be_accepted(self):
        row = copy.deepcopy(self.rows[0][1]); row['forcing'][0, 0] = self.np.float32(3600)
        with self.expect_error(ValueError, 'forcing'):
            self.a.map_interval(row, self.loaded, 0)

    def test_heldout_poison_is_removed_before_any_mapping(self):
        from training_stream_os import project_row
        raw = {}
        for name, value in self.rows[0][1].items():
            raw[name] = self.np.empty((12,)+value.shape[1:], dtype=value.dtype)
            raw[name][:8] = value
            raw[name][8:] = self.np.nan if value.dtype.kind == 'f' else False
        projected = project_row(raw, self.selected)
        for name in projected:
            self.a.exact(projected[name], self.rows[0][1][name], 'Selected data changed')
        self.a.map_interval(projected, self.loaded, 0)

    def test_unprojected_columns_and_wrong_training_identity_rejected(self):
        rows = copy.deepcopy(self.rows[:1]); rows[0][1]['nitrogen'] = self.np.zeros(12, self.np.float32)
        with self.expect_error(ValueError, 'eight-column'):
            self.collect(rows)
        loaded = copy.deepcopy(self.loaded); loaded[0]['config']['site'] = 'CN-Cha'
        with self.expect_error(ValueError, 'Training-only'):
            self.collect(loaded=loaded)

    def test_existing_inventory_rejects_changed_bytes_and_outside_path(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as name:
            root = Path(name); (root/'member').write_bytes(b'original')
            bound = self.a.BoundFiles(root, {'member': self.a.sha(b'original')})
            self.assertEqual(bound.read('member'), b'original')
            (root/'member').write_bytes(b'changed')
            with self.expect_error(ValueError, 'hash mismatch'):
                bound.recheck()
            with self.expect_error(ValueError, 'Unbound'):
                bound.path('../outside')


if __name__ == '__main__':
    unittest.main(verbosity=2)

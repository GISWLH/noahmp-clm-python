"""Conditional normal-rate C algebra; no column stepping or cold-state export."""
import calendar
from datetime import datetime, timedelta
import numpy as np

POOLS = ('metabolic_litter', 'cellulose_litter', 'lignin_litter', 'coarse_wood', 'fast', 'slow', 'passive')
YEAR_SECONDS = 31536000.0


def require(ok, message):
    if not ok:
        raise ValueError(message)


def finite(value, shape=None, nonnegative=False):
    a = np.asarray(value, dtype=np.float64)
    require((shape is None or a.shape == shape) and np.isfinite(a).all(), 'Invalid shape/nonfinite input')
    require(not nonnegative or np.all(a >= 0), 'Negative nonnegative input')
    return a


def routing(parameters):
    sand = float(parameters['sand_fraction'])
    wood = float(parameters['wood_cellulose_fraction'])
    require(np.isfinite([sand, wood]).all() and 0 <= sand <= 1 and 0 <= wood <= 1, 'Invalid routing parameters')
    r = np.zeros((7, 7))
    r[4, 0] = .45; r[4, 1] = .5; r[5, 2] = .5
    r[1, 3] = wood; r[2, 3] = 1. - wood
    r[5, 4] = 1. - (.17 + .68 * sand) - .004; r[6, 4] = .004
    r[4, 5] = .42; r[6, 5] = .03; r[4, 6] = .45
    require(np.all(r >= 0) and np.all(r.sum(axis=0) <= 1), 'Invalid transfer fractions')
    return r


def interval_map(modifier, litter, parameters, dt=1800.):
    """Amounts enter before decay; newly received cascade C waits one step."""
    require(np.isfinite(modifier) and modifier >= 0 and dt == 1800., 'Require normal 1800s interval')
    tau = finite(parameters['turnover_years'], (7,), True)
    require(np.all(tau > 0), 'Turnover times must be positive')
    ci = finite(litter, (7,), True)
    loss = -np.expm1(-float(modifier) * dt / (tau * YEAR_SECONDS))
    a = np.eye(7) - np.diag(loss) + routing(parameters) * loss[None, :]
    return a, a @ ci


def solve_periodic(a, b):
    """Report a conditional solution, including singular/negative outcomes."""
    a = finite(a, (7, 7)); b = finite(b, (7,))
    system = np.eye(7) - a
    eigenvalues = np.linalg.eigvals(a)
    condition = float(np.linalg.cond(system))
    result = dict(annual_matrix=a.tolist(), annual_input_gc_m2=b.tolist(),
                  eigenvalues=[dict(real=float(v.real), imaginary=float(v.imag)) for v in eigenvalues],
                  spectral_radius=float(np.max(abs(eigenvalues))),
                  condition_number=None if not np.isfinite(condition) else condition,
                  condition_number_finite=bool(np.isfinite(condition)),
                  candidate_carbon_gc_m2=None, nonnegative=None,
                  algebraic_residual_gc_m2=None, relative_backward_residual=None,
                  solution_status='unresolved', usable_cold_configuration=False,
                  scientific_acceptance_claim=False)
    try:
        candidate = np.linalg.solve(system, b)
    except np.linalg.LinAlgError:
        result['solution_status'] = 'singular'
        return result
    if not np.isfinite(candidate).all():
        result['solution_status'] = 'nonfinite_solution'
        return result
    residual = system @ candidate - b
    scale = np.linalg.norm(system, np.inf) * np.linalg.norm(candidate, np.inf) + np.linalg.norm(b, np.inf)
    result.update(candidate_carbon_gc_m2=candidate.tolist(), nonnegative=bool(np.all(candidate >= 0)),
                  solution_status='finite_conditional_solution', algebraic_residual_gc_m2=residual.tolist(),
                  relative_backward_residual=float(np.linalg.norm(residual, np.inf) / max(scale, np.finfo(float).tiny)))
    return result


def validate_year(starts, ends, expected_year):
    starts = np.asarray(starts); ends = np.asarray(ends)
    require(starts.shape == ends.shape == (17520,), 'Require all17520 nonleap intervals')
    require(not calendar.isleap(expected_year), 'This NS binding is nonleap only')
    origin = datetime(expected_year, 1, 1)
    for i, (a, b) in enumerate(zip(starts, ends)):
        require(str(a) == (origin + timedelta(seconds=1800*i)).strftime('%Y%m%d%H%M') and
                str(b) == (origin + timedelta(seconds=1800*(i+1))).strftime('%Y%m%d%H%M'), 'Missing, reordered or wrong-year interval')
    return starts.astype(str)


class AnnualCase:
    """Stream the eight selected historical records only; never advance N."""
    def __init__(self, name, parameters, starts):
        self.name = name; self.parameters = parameters; self.starts = np.asarray(starts, str)
        self.a = np.eye(7); self.b = np.zeros(7); self.count = 0
        self.months = {}; self.limited = 0; self.one_step_count = 0; self.one_step_max = np.zeros(7)
        self.ranges = {key: [float('inf'), -float('inf')] for key in (
            'decomposition_n_factor', 'leaf_n_factor_used', 'leaf_n_factor_after',
            'temperature_k', 'water_potential_mpa', 'normal_rate_multiplier', 'mineral_n_gn_m2')}

    def add(self, index, row, column):
        require(index == self.count and index < 17520, 'Noncontiguous record index')
        k = column
        scalar_keys = {
            'decomposition_n_factor': 'bgc/decomposition/nitrogen_limitation',
            'leaf_n_factor_used': 'bgc/nitrogen_factor_used', 'leaf_n_factor_after': 'bgc/nitrogen_factor_after',
            'temperature_k': 'bgc/environment/soil_temperature',
            'water_potential_mpa': 'bgc/environment/water_potential_mpa',
            'normal_rate_multiplier': 'bgc/decomposition/rate_multiplier'}
        values = {name: float(finite(row[key][k], ())) for name, key in scalar_keys.items()}
        require(all(0 <= values[n] <= 1 for n in ('decomposition_n_factor', 'leaf_n_factor_used', 'leaf_n_factor_after')), 'Invalid N factor')
        before = finite(row['before_soil_cn'][k], (15,), True)
        after = finite(row['after_soil_cn'][k], (15,), True)
        for name, value in values.items():
            self.ranges[name][0] = min(self.ranges[name][0], value)
            self.ranges[name][1] = max(self.ranges[name][1], value)
        self.ranges['mineral_n_gn_m2'][0] = min(self.ranges['mineral_n_gn_m2'][0], before[14], after[14])
        self.ranges['mineral_n_gn_m2'][1] = max(self.ranges['mineral_n_gn_m2'][1], before[14], after[14])
        ci = finite(row['bgc/turnover/litter_carbon_gc_m2'][k], (7,), True)
        ni = finite(row['bgc/turnover/litter_nitrogen_gn_m2'][k], (7,), True)
        dt = float(row['forcing'][k, 0])
        a, b = interval_map(values['normal_rate_multiplier'], ci, self.parameters, dt)
        self.b = a @ self.b + b; self.a = a @ self.a
        if values['decomposition_n_factor'] == 1.:
            self.one_step_max = np.maximum(self.one_step_max, abs(a @ before[:7] + b - after[:7]))
            self.one_step_count += 1
        else:
            self.limited += 1
        month = self.starts[index][:6]
        if month not in self.months:
            self.months[month] = dict(intervals=0, npp_gc_m2=0., gpp_gc_m2=0., ra_gc_m2=0.,
                n_deposition_gn_m2=0., plant_n_demand_gn_m2=0., plant_n_uptake_gn_m2=0.,
                litter_carbon_gc_m2=np.zeros(7), litter_nitrogen_gn_m2=np.zeros(7))
        m = self.months[month]; m['intervals'] += 1
        for name, key in [('gpp_gc_m2', 'bgc/allocation/gpp_gc_m2'), ('ra_gc_m2', 'bgc/allocation/autotrophic_respiration_gc_m2'),
                          ('n_deposition_gn_m2', 'nitrogen'), ('plant_n_demand_gn_m2', 'bgc/allocation/soil_n_demand_gn_m2'),
                          ('plant_n_uptake_gn_m2', 'bgc/allocation/soil_n_uptake_gn_m2')]:
            amount = float(finite(row[key][k], (), True)); m[name] += amount
        m['npp_gc_m2'] += float(row['bgc/allocation/gpp_gc_m2'][k]) - float(row['bgc/allocation/autotrophic_respiration_gc_m2'][k])
        m['litter_carbon_gc_m2'] += ci; m['litter_nitrogen_gn_m2'] += ni
        self.count += 1

    def finish(self):
        require(self.count == 17520 and len(self.months) == 12, 'Incomplete actual year')
        monthly = []
        for name, m in sorted(self.months.items()):
            expected = 48 * calendar.monthrange(int(name[:4]), int(name[4:]))[1]
            require(m['intervals'] == expected, 'Incomplete month')
            monthly.append(dict(month=name, expected_intervals=expected,
                **{n: v.tolist() if isinstance(v, np.ndarray) else v for n, v in m.items()}))
        annual = {n: sum((np.asarray(m[n], float) for m in monthly), start=np.zeros(7)).tolist()
                  if n.startswith('litter_') else sum(m[n] for m in monthly)
                  for n in ('npp_gc_m2', 'gpp_gc_m2', 'ra_gc_m2', 'n_deposition_gn_m2',
                            'plant_n_demand_gn_m2', 'plant_n_uptake_gn_m2', 'litter_carbon_gc_m2', 'litter_nitrogen_gn_m2')}
        return dict(case=self.name, intervals=self.count, dt_seconds=1800, pool_names=list(POOLS),
            monthly=monthly, actual_annual_integrals=annual,
            ranges={n: dict(minimum=v[0], maximum=v[1]) for n, v in self.ranges.items()},
            n_limited_intervals=self.limited, recorded_unlimited_n_condition_met=self.limited == 0,
            periodic_carbon=solve_periodic(self.a, self.b),
            one_step_actual_n_unlimited_comparison=dict(intervals=self.one_step_count,
                maximum_per_pool_difference_gc_m2=self.one_step_max.tolist(), new_pass_threshold=False),
            stable_repeated_annual_inputs_demonstrated=False, normal_cn_replay_performed=False,
            source='Actual normal-rate multiplier and1800s litter inputs; no multiplier acceleration.',
            limitation='N limitation scales selected immobilizing pathways, not the whole C matrix. This conditional unlimited-N map is not the nonlinear C/N map; even no historical N limitation does not prove applicability at the candidate stocks.',
            initializer_exported=False, actual_spinup_years_added=0, scientific_acceptance_claim=False)

"""Independent synthetic tests. Execute only on an EHPC compute node."""
from pathlib import Path
from datetime import datetime, timedelta
import ast
import copy
import json
import os
import unittest
import numpy as np
from soc_operator_os import AnnualCase, interval_map, solve_periodic, validate_year
from training_stream_os import select_registry, project_row, require_f0, selected_records, audit_and_diagnose, SITE_YEARS, TARGET

P = dict(turnover_years=[.066, .25, .25, 4.1, .17, 6.1, 270.], sand_fraction=.4, wood_cellulose_fraction=.76)


def setUpModule():
    if not os.environ.get('PBS_JOBID') or not os.uname().nodename.startswith('compute002'):
        raise RuntimeError('OS numerical tests require actual EHPC compute002 PBS context')


def registry():
    names = [(site, f'{site}-{year}-{seed}-{mapping}-clim') for site, year in SITE_YEARS.items()
             for seed in ('wilting', 'field-capacity') for mapping in ('hydraulic', 'legacy')]
    return [dict(case=name, config=dict(case=name, site=site)) for site, name in names]


def times(year=2007):
    origin = datetime(year, 1, 1)
    stamps = [(origin + timedelta(seconds=1800*k)).strftime('%Y%m%d%H%M') for k in range(17521)]
    return np.asarray(stamps[:-1]), np.asarray(stamps[1:])


def one_row(nfactor):
    row = {'forcing': np.zeros((8, 8)), 'before_soil_cn': np.ones((8, 15)), 'after_soil_cn': np.ones((8, 15)),
           'nitrogen': np.zeros(8), 'bgc/turnover/litter_carbon_gc_m2': np.zeros((8, 7)),
           'bgc/turnover/litter_nitrogen_gn_m2': np.zeros((8, 7))}
    row['forcing'][:, 0] = 1800.
    for name, value in {'decomposition/nitrogen_limitation': nfactor, 'nitrogen_factor_used': 1.,
                        'nitrogen_factor_after': 1., 'environment/soil_temperature': 285.,
                        'environment/water_potential_mpa': -.1, 'decomposition/rate_multiplier': 1.,
                        'allocation/gpp_gc_m2': 0., 'allocation/autotrophic_respiration_gc_m2': 0.,
                        'allocation/soil_n_demand_gn_m2': 0., 'allocation/soil_n_uptake_gn_m2': 0.}.items():
        row['bgc/' + name] = np.full(8, value)
    return row


class OperatorTests(unittest.TestCase):
    def test_metabolic_decay_and_receiving_material_waits(self):
        a, b = interval_map(1., np.zeros(7), P)
        old = np.zeros(7); old[0] = 1.
        new = a @ old + b
        survival = np.exp(-1800. / (.066 * 31536000.))
        self.assertAlmostEqual(new[0], survival, places=14)
        self.assertAlmostEqual(new[4], .45 * (1. - survival), places=14)
        self.assertEqual(new[5], 0.)
        self.assertEqual(new[6], 0.)
        self.assertAlmostEqual(1. - new.sum(), .55 * (1. - survival), places=14)

    def test_litter_enters_before_same_interval_decay(self):
        ci = np.zeros(7); ci[0] = 2.
        _, b = interval_map(1., ci, P)
        survival = np.exp(-1800. / (.066 * 31536000.))
        self.assertAlmostEqual(b[0], 2. * survival, places=14)
        self.assertAlmostEqual(b[4], .9 * (1. - survival), places=14)

    def test_two_season_fixed_point_matches_scalar_closed_form(self):
        c1 = np.zeros(7); c1[0] = 3.
        c2 = np.zeros(7); c2[0] = 1.
        a1, b1 = interval_map(.3, c1, P); a2, b2 = interval_map(2., c2, P)
        result = solve_periodic(a2 @ a1, a2 @ b1 + b2)
        s1 = np.exp(-.3 * 1800. / (.066 * 31536000.)); s2 = np.exp(-2. * 1800. / (.066 * 31536000.))
        expected = s2 * (s1 * 3. + 1.) / (1. - s1 * s2)
        self.assertAlmostEqual(result['candidate_carbon_gc_m2'][0] / expected, 1., places=11)
        actual = AnnualCase('synthetic-two-season', P, ['200701010000', '200701010030'])
        for index, modifier, litter in [(0, .3, c1), (1, 2., c2)]:
            row = one_row(1.)
            row['bgc/decomposition/rate_multiplier'][:] = modifier
            row['bgc/turnover/litter_carbon_gc_m2'][:] = litter
            actual.add(index, row, 0)
        accumulated = solve_periodic(actual.a, actual.b)
        expected_input = s2 * (s1 * 3. + 1.)
        self.assertAlmostEqual(actual.a[0, 0], s1 * s2, places=14)
        self.assertAlmostEqual(actual.b[0], expected_input, places=14)
        self.assertAlmostEqual(accumulated['candidate_carbon_gc_m2'][0] / expected, 1., places=11)
        print('OS_NUMERICAL_DIAGNOSTIC ' + json.dumps(dict(
            case='two-season-metabolic-scalar', oracle_carbon_gc_m2=float(expected),
            accumulated_carbon_gc_m2=accumulated['candidate_carbon_gc_m2'][0],
            absolute_carbon_error_gc_m2=abs(accumulated['candidate_carbon_gc_m2'][0] - float(expected)),
            relative_carbon_error=abs(accumulated['candidate_carbon_gc_m2'][0] / float(expected) - 1.),
            multiplier_absolute_error=float(abs(actual.a[0, 0] - s1 * s2)),
            accumulated_input_absolute_error_gc_m2=float(abs(actual.b[0] - expected_input)))))
        reversed_result = solve_periodic(a1 @ a2, a1 @ b2 + b1)
        self.assertNotEqual(result['candidate_carbon_gc_m2'][0], reversed_result['candidate_carbon_gc_m2'][0])

    def test_known_coupled_linear_system(self):
        a = np.eye(7) * .5; a[4, 0] = .25
        b = np.zeros(7); b[0] = 1.; b[4] = 2.
        r = solve_periodic(a, b)
        self.assertEqual(r['candidate_carbon_gc_m2'][0], 2.)
        self.assertEqual(r['candidate_carbon_gc_m2'][4], 5.)
        self.assertEqual(r['spectral_radius'], .5)
        self.assertEqual(r['relative_backward_residual'], 0.)
        self.assertFalse(r['usable_cold_configuration'])
        oracle = np.zeros(7); oracle[0] = 2.; oracle[4] = 5.
        print('OS_NUMERICAL_DIAGNOSTIC ' + json.dumps(dict(
            case='known-coupled-seven-pool-system', oracle_carbon_gc_m2=oracle.tolist(),
            computed_carbon_gc_m2=r['candidate_carbon_gc_m2'],
            maximum_absolute_pool_error_gc_m2=float(np.max(abs(np.asarray(r['candidate_carbon_gc_m2']) - oracle))),
            spectral_radius_absolute_error=abs(r['spectral_radius'] - .5),
            relative_backward_residual=r['relative_backward_residual'])))

    def test_singular_dry_year_has_no_invented_solution(self):
        r = solve_periodic(np.eye(7), np.ones(7))
        self.assertEqual(r['solution_status'], 'singular')
        self.assertIsNone(r['candidate_carbon_gc_m2'])
        self.assertIsNone(r['condition_number'])

    def test_negative_solution_is_reported_without_clipping(self):
        r = solve_periodic(np.eye(7) * .5, -np.ones(7))
        self.assertFalse(r['nonnegative'])
        self.assertEqual(r['candidate_carbon_gc_m2'], [-2.] * 7)

    def test_invalid_rate_litter_and_dt_rejected(self):
        for modifier, litter, dt in [(-1., np.zeros(7), 1800.), (np.nan, np.zeros(7), 1800.),
                                     (1., -np.ones(7), 1800.), (1., np.zeros(7), 3600.)]:
            with self.subTest(modifier=modifier, dt=dt), self.assertRaises(ValueError):
                interval_map(modifier, litter, P, dt)

    def test_n_limited_interval_not_used_as_linear_actual_match(self):
        x = AnnualCase('synthetic', P, ['200701010000'])
        x.add(0, one_row(.5), 0)
        self.assertEqual(x.limited, 1)
        self.assertEqual(x.one_step_count, 0)
        a, _ = interval_map(1., np.zeros(7), P)
        np.testing.assert_array_equal(x.a, a)
        with self.assertRaises(ValueError):
            x.finish()


class ExtractionTests(unittest.TestCase):
    def test_all8_selected_and_heldout_poison_never_enters_analysis(self):
        reg = registry(); selected = select_registry(reg)
        a = np.arange(12 * 7, dtype=float).reshape(12, 7)
        for k, c in enumerate(reg):
            if c['config']['site'] == 'CN-Cha': a[k] = np.nan
        projected = project_row({'pool': a}, selected)['pool']
        self.assertEqual(projected.shape, (8, 7))
        self.assertTrue(np.isfinite(projected).all())
        self.assertTrue(all(reg[k]['config']['site'] in ('CN-Cng', 'CN-Qia') for k in selected))

    def test_missing_duplicate_or_changed_family_rejected(self):
        reg = registry()
        changed = copy.deepcopy(reg); changed[0] = copy.deepcopy(changed[1])
        changed2 = copy.deepcopy(reg); changed2[0]['config']['site'] = 'CN-Qia'
        for value in [reg[:-1], changed, changed2]:
            with self.assertRaises(ValueError): select_registry(value)

    def test_projection_rejects_duplicate_or_short_indices(self):
        for indices in [[0] * 8, list(range(7)), list(range(7)) + [12]]:
            with self.assertRaises(ValueError): project_row({'x': np.zeros((12, 2))}, indices)

    def test_full_calendar_and_end_exclusive(self):
        for year in (2007, 2003):
            starts, ends = times(year)
            self.assertEqual(len(validate_year(starts, ends, year)), 17520)
            self.assertEqual(str(ends[-1]), f'{year+1}01010000')

    def test_time_gap_reordering_wrong_year_and_truncation_rejected(self):
        starts, ends = times()
        reordered = starts.copy(); reordered[2] = reordered[1]
        gap = ends.copy(); gap[0] = gap[1]
        for a, b, year in [(starts[:-1], ends[:-1], 2007), (reordered, ends, 2007),
                           (starts, gap, 2007), (starts, ends, 2003)]:
            with self.assertRaises(ValueError): validate_year(a, b, year)

    def test_unclosed_bgc_year_rejected_before_opening_packets(self):
        bad = dict(steps_completed=17472, steps_requested=17520, bgc_diagnostic_steps=17424,
                   bgc_diagnostic_chunks=[{}] * 363)
        with self.assertRaises(ValueError): next(selected_records('/nonexistent', bad, list(range(8))))

    def test_actual_f0_and_job_identity_required(self):
        q = 'Job Id: 999.manager\n    job_state = F\n    Exit_status = 0\n'
        require_f0(q, '999.manager')
        for text, job in [(q.replace(' = F', ' = E'), '999.manager'),
                          (q.replace('status = 0', 'status = 1'), '999.manager'), (q, '998.manager')]:
            with self.assertRaises(ValueError): require_f0(text, job)

    def test_closed_metadata_does_not_bypass_unsealed_extraction(self):
        for claimed in (False, True):
            proof = dict(verified_ns17520_od_f0=True, source_manifest_sha256=TARGET,
                         production_extraction_bound=claimed)
            with self.subTest(caller_claim=claimed), self.assertRaisesRegex(ValueError, 'extraction adapter'):
                audit_and_diagnose(proof=proof, registry=[], loaded_training=[], cold_training={},
                                   final_training={}, traces_training=[], projected_records=iter(()))

    def test_km_adapter_changes_only14_column_constants(self):
        here = Path(__file__).parent
        tree = ast.parse((here / 'audit_bgc_stream_km_original.py').read_text())
        changed = []
        class Count(ast.NodeTransformer):
            def visit_Constant(self, node):
                if type(node.value) is int and node.value == 12:
                    changed.append(node.lineno)
                    return ast.copy_location(ast.Constant(value=8), node)
                return node
        expected = Count().visit(tree)
        actual = ast.parse((here / 'audit_bgc_stream_os8.py').read_text())
        self.assertEqual(len(changed), 14)
        self.assertEqual(ast.dump(expected, include_attributes=False), ast.dump(actual, include_attributes=False))


if __name__ == '__main__':
    unittest.main(verbosity=2)

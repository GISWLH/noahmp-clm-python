"""Verify closed zero-call QG, opaque private fixtures and original source binds."""
import base64
import gzip
import io
import json
from pathlib import Path
import tarfile
from package_surface_reference_pt import files,sha,encode
from package_nm_richards_reference_qc import opaque_packet

BASE=Path(__file__).resolve().parent
LABEL='nq-reference-values-qg'
STAGE='38575e1a7746d3124143ec60c4aa3145b4ab36ebe0c3026b1b433b341f853a41'
RESULT='beb10ca757e1757383d5e692d8b6f5457180cc69ecf9aa55f32a61dca121bc9c'

def main():
    stage_raw=(BASE/(LABEL+'-stage.tar.gz')).read_bytes();raw=(BASE/(LABEL+'-result.tar.gz')).read_bytes()
    assert sha(stage_raw)==STAGE and sha(raw)==RESULT
    stage=files(stage_raw);result=files(raw,directories=True);index=json.loads(stage['stage-inventory.json'])
    assert len(stage)==15 and set(stage)==set(index)|{'stage-inventory.json'} and all(sha(stage[n])==h for n,h in index.items())
    for n in ('stage-before.json','stage-after.json'):
        d=json.loads(result[n]);assert d['passed'] and d['expected']==d['actual']==index and not d['mismatches']
    for n in ('setup-exit.txt','stage-after-exit.txt','worker-exit.txt','pbs-command-exit.txt'):assert result[n].strip()==b'0'
    assert result['stage-inventory.json']==stage['stage-inventory.json']
    for n in [*json.loads(stage['execution/CONTROLS_SHA256.json']),'CONTROLS_SHA256.json']:assert stage['execution/'+n]==result['execution-controls/'+n]
    closure=BASE/(LABEL+'-closure')
    for name in ('manager','compute'):
        d=json.loads((closure/(name+'.stdout')).read_bytes());assert d['all_stage_immutable'] and d['stage_files_before']==d['stage_files_after']==index
        if name=='compute':assert d['result_archive_sha256']==RESULT and base64.b64decode(d['files']['pbs-exit.txt']).strip()==b'0'
    terminal=[p.read_bytes() for p in closure.glob('poll-*.stdout') if b'job_state = F' in p.read_bytes()];assert len(terminal)==1
    assert all(x in terminal[0] for x in (b'Exit_status = 0',b'Stageout_status = 0',b'run_count = 1'))
    receipt=json.loads(result['values/receipt.json']);assert receipt['pbs_job']=='1841.manager' and receipt['physical_calls']==receipt['GPU_calls']==0 and receipt['controls_exact'] and not receipt['checkout_fixtures_modified'] and not receipt['scientific_acceptance']
    assert receipt['source_archive_sha256']==sha(stage['source.tar.gz']) and receipt['qc_result_archive_sha256']==sha(stage['qc-result.tar.gz'])
    doc=json.loads(result['values/reference-values.json']);assert doc['pbs_job']=='1841.manager' and doc['physical_calls']==doc['GPU_calls']==0 and doc['QC_physical_calls_reused']==44
    assert len(doc['columns'])==404 and doc['column_original_input_arrays_unchanged']==250 and len(doc['stations'])==2
    assert doc['source_manifest_sha256']=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    opaque={}
    for filename,meta in doc['proposed_fixture_files'].items():
        value=result['values/'+filename];assert sha(value)==meta['sha256'] and len(value)==meta['bytes']
        packet=dict(npz_sha256=meta['sha256'],array_count=meta['arrays'],tree=dict(kind='dict',items={n:dict(kind='array',key=n,**v) for n,v in meta['identities'].items()}))
        opaque[filename]=opaque_packet(value,packet)[0]
        target=BASE/(LABEL+'-'+filename);assert not target.exists();target.write_bytes(value)
    assert len([n for n in result if n.endswith('analysis-input-arrays.pkl')])==3
    verification=dict(passed=True,pbs_job='1841.manager',actual_PBS_exit=0,actual_Stageout_status=0,resources='1CPU/2GiB/5min/compute002',stage_files=15,stage_sha256=STAGE,result_sha256=RESULT,new_physical_calls=0,reused_QC_physical_calls=44,GPU_calls=0,original_input_arrays_unchanged=250,private_proposed_opaque_arrays=opaque,source584_unchanged=True,checkout_fixture_or_test_or_model_changes=False,scientific_acceptance=False)
    (BASE/(LABEL+'-verification.json')).write_bytes(encode(verification))
    items={'executed-stage.tar.gz':stage_raw,'raw-result.tar.gz':raw,'verification.json':encode(verification)}
    items.update({'actual-result/'+n:b for n,b in result.items()})
    for directory in (closure,BASE/(LABEL+'-deployment')):
        for p in sorted(directory.iterdir()):
            if p.is_file():items['observations/'+directory.name+'/'+p.name]=p.read_bytes()
    for directory in (BASE/'nq-reference-values-qg-preparation-unexecuted-before-nonfinite-recording',):
        for p in sorted(directory.iterdir()):
            if p.is_file():items['unexecuted-original-controls/'+p.name]=p.read_bytes()
    for n in ('prepare_reference_values_qg_execution.py','deploy_reference_values_qg.py','read_reference_values_qg_closed.py','collect_reference_values_qg_closed.py','package_reference_values_qg.py',LABEL+'-execution.diff',LABEL+'-stage-package.json'):
        items['provenance/'+n]=(BASE/n).read_bytes()
    items['artifact-inventory.json']=encode({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as t:
        for n,b in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
    assert files(target.read_bytes())==items
    package=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(items),scope='EHPC1841 actual F0/Stageout0 posthoc current/BF values from original QC44;0 new physical/GPU calls. Complete original/source/input binding and private proposed fixtures only. No checkout fixture/model/test/gate change, no acceptance credit or original failure removal.')
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(dict(package=package,verification=verification)))

if __name__=='__main__':main()

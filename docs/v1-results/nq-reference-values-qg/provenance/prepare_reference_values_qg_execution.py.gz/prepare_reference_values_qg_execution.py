"""Mechanical QC/PW PBS wrapper reuse for authorized zero-call QG analysis."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'nq-reference-values-qg-preparation'
OLD=BASE/'nq-current-reference-qc-execution'
NEW=BASE/'nq-reference-values-qg-execution'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()

def main():
    assert sha((PREP/'CONTROLS_SHA256.json').read_bytes())=='89bda241171d1e901a380b89d27e2ab4ddd80c888328be4d384447d1e7ff2ded'
    controls=json.loads((PREP/'CONTROLS_SHA256.json').read_bytes());assert all(sha((PREP/n).read_bytes())==h for n,h in controls.items())
    assert not NEW.exists();NEW.mkdir();diff=[]
    names={'check_stage_qc.py':'check_stage_qg.py','dispatch_reference_qc.py':'dispatch_reference_qg.py','reference_qc.pbs':'reference_qg.pbs'}
    for old,new in names.items():
        before=(OLD/old).read_text();after=before.replace('current-reference-qc','reference-values-qg').replace('check_stage_qc','check_stage_qg').replace('dispatch_reference_qc','dispatch_reference_qg').replace('reference_qc.pbs','reference_qg.pbs').replace('QC stage','QG stage').replace('qc-result','qg-result').replace('1CPU/2GiB/10min','1CPU/2GiB/5min').replace('planned_surface_calls=0, full_column_calls=44','planned_surface_calls=0, full_column_calls=0').replace('walltime=00:10:00','walltime=00:05:00')
        if old.endswith('.pbs'):
            oldcmd='"$py" -B "$stage/preparation/run_nm_richards_reference_qc.py" --source "$stage/source.tar.gz" --station "$stage/station.tar.gz" --nq "$stage/nq.tar.gz" --output "$root/reference"'
            newcmd='"$py" -B "$stage/preparation/reference_values_qg.py" --source "$stage/source.tar.gz" --qc "$stage/qc-result.tar.gz" --output "$root/values"'
            assert oldcmd in after;after=after.replace(oldcmd,newcmd).replace("--exclude='./reference/source' ",'')
        else:ast.parse(after)
        (NEW/new).write_text(after,encoding='utf-8',newline='\n');diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old,tofile=new))
    (NEW/'README.md').write_text('QG reuses original QC/PW lifecycle controls. One EHPC compute002 PBS1CPU/2GiB/5min posthoc child reads already completed QC44;0 physical/GPU calls. It emits original/current values and private candidate NPZ only, preserving original inputs/config/metadata and historical failures. Actual PBS/worker/Stageout statuses remain separate. Root authorized one submission, no retry.\n',encoding='utf-8')
    (NEW/'EXECUTION_BINDINGS.json').write_bytes(encode(dict(preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),planned_physical_calls=0,GPU_calls=0,resources='1CPU/2GiB/5min/compute002',root_authorized=True)))
    manifest={p.name:sha(p.read_bytes()) for p in sorted(NEW.iterdir())};(NEW/'CONTROLS_SHA256.json').write_bytes(encode(manifest))
    (BASE/'nq-reference-values-qg-execution.diff').write_text(''.join(diff),encoding='utf-8')
    items={'preparation/'+p.name:p.read_bytes() for p in PREP.iterdir() if p.is_file()}
    items.update({'execution/'+p.name:p.read_bytes() for p in NEW.iterdir() if p.is_file()})
    for new,old,expected in [('source.tar.gz','climatology-final-candidate-nm-source.tar.gz','39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'),('qc-result.tar.gz','nq-current-reference-qc-result.tar.gz','925f44a18f501652f6050409895adf4f1fb2a81ff441d0e19a0241108cef55c1')]:
        raw=(BASE/old).read_bytes();assert sha(raw)==expected;items[new]=raw
    items['stage-inventory.json']=encode({n:sha(raw) for n,raw in sorted(items.items())})
    target=BASE/'nq-reference-values-qg-stage.tar.gz';assert not target.exists()
    with target.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
        for n,raw in sorted(items.items()):
            m=tarfile.TarInfo(n);m.size=len(raw);m.mode=0o644;archive.addfile(m,io.BytesIO(raw))
    with tarfile.open(target) as archive:assert {m.name:archive.extractfile(m).read() for m in archive}==items
    stage_sha=sha(target.read_bytes())
    deploy=(BASE/'deploy_nm_richards_reference_qc.py').read_text().replace('nq-current-reference-qc','nq-reference-values-qg').replace('noahmp-current-reference-qc','noahmp-reference-values-qg').replace('dispatch_reference_qc','dispatch_reference_qg').replace('fc32c805f013f46d0d10cc6ebda741bc263c4dfd129dd69db06018a48b9c4d3f',stage_sha)
    ast.parse(deploy);(BASE/'deploy_reference_values_qg.py').write_text(deploy,encoding='utf-8',newline='\n')
    record=dict(stage_sha256=stage_sha,stage_files=len(items),execution_controls=len(manifest),execution_manifest_sha256=sha((NEW/'CONTROLS_SHA256.json').read_bytes()),preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),numerical_execution=False)
    (BASE/'nq-reference-values-qg-stage-package.json').write_bytes(encode(record));print(json.dumps(record))

if __name__=='__main__':main()

"""EHPC-only read-only analysis of completed QC44; no physical calls."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import sys
import tarfile

HERE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def unpack(path,expected):
    raw=path.read_bytes();assert sha(raw)==expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        out={}
        for m in t:
            if m.isdir():continue
            n=m.name.removeprefix('./');assert m.isfile() and n not in out and not n.startswith('/') and '..' not in Path(n).parts and '\\' not in n
            out[n]=t.extractfile(m).read()
    return out

def main():
    parser=argparse.ArgumentParser()
    for n in ('source','qc','output'):parser.add_argument('--'+n,type=Path,required=True)
    a=parser.parse_args()
    assert os.name!='nt' and socket.gethostname()=='compute002' and os.environ.get('PBS_JOBID') and sys.dont_write_bytecode
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(n)=='1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
    assert a.output.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()) and not a.output.exists();a.output.mkdir()
    controls=json.loads((HERE/'CONTROLS_SHA256.json').read_bytes());before={n:sha((HERE/n).read_bytes()) for n in controls};assert before==controls
    binding=json.loads((HERE/'BINDINGS.json').read_bytes());source=unpack(a.source,binding['source_archive_sha256']);qc=unpack(a.qc,binding['qc_result_archive_sha256'])
    manifest=json.loads(source['SOURCE_SHA256.json']);assert len(manifest)==584 and all(sha(source[n])==h for n,h in manifest.items())
    receipt=json.loads(qc['reference/receipt.json']);assert receipt['physical_calls']==dict(started=44,returned=44) and receipt['source584_exact'] and receipt['controls_exact'] and receipt['retained_inputs_exact'] and receipt['nq_inputs_exact']
    assert qc['worker-exit.txt'].strip()==qc['pbs-command-exit.txt'].strip()==b'0'
    import numpy as np
    def arrays(raw):
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:return {n:z[n].copy() for n in z.files}
    def identity(x):return dict(dtype=x.dtype.str,shape=list(x.shape),c_order_sha256=sha(x.tobytes(order='C')))
    def difference(a,b):
        assert a.dtype==b.dtype and a.shape==b.shape
        return dict(old=b.tolist(),current=a.tolist(),maximum_absolute=float(np.max(abs(a.astype(float)-b.astype(float)),initial=0.)),same_bytes=a.tobytes()==b.tobytes(),old_identity=identity(b),current_identity=identity(a))
    old=arrays(source['tests/fixtures/clm_richards_reference.npz']);new=arrays(qc['reference/current-column-reference-values.npz'])
    expected={n for n in old if '/expected/' in n};assert set(new)==expected and len(new)==404
    columns={n:difference(new[n],old[n]) for n in new}
    candidate={n:new[n] if n in expected else v for n,v in old.items()}
    assert len(old)==len(candidate)==654
    assert all(identity(candidate[n])==identity(old[n]) for n in old if n not in expected)
    # Private candidate artifacts only: no checkout fixture is accessed or modified.
    np.savez_compressed(a.output/'proposed-clm_richards_reference.npz',**candidate)
    station_old=arrays(source['tests/fixtures/clm_richards_station_reference.npz']);station_candidate=dict(station_old);stations={}
    for s in (0,1):
        report=json.loads(qc['reference/station-run-'+str(s)+'/report.json']);assert report['status']=='complete' and report['steps_completed']==4
        trace=arrays(qc['reference/station-run-'+str(s)+'/'+report['model_npz']]);prefix=str(s)+'/trace/'
        names={n[len(prefix):] for n in station_old if n.startswith(prefix)};assert names==set(trace)
        stations[str(s)]={}
        for n in sorted(names):
            key=prefix+n;v=trace[n];before_v=station_old[key]
            assert v.dtype==before_v.dtype and v.shape==before_v.shape
            stations[str(s)][n]=(difference(v,before_v) if v.dtype.kind in 'biuf' else dict(old=before_v.tolist(),current=v.tolist(),same_bytes=v.tobytes()==before_v.tobytes(),old_identity=identity(before_v),current_identity=identity(v)))
            station_candidate[key]=v
        station_candidate[str(s)+'/report_json']=np.asarray(json.dumps(report,sort_keys=True))
    immutable={n for n in station_old if '/input/' in n or n.endswith(('/config_json','/metadata_json'))}
    assert all(identity(station_candidate[n])==identity(station_old[n]) for n in immutable)
    np.savez_compressed(a.output/'proposed-clm_richards_station_reference.npz',**station_candidate)
    proposed={}
    for filename in ('proposed-clm_richards_reference.npz','proposed-clm_richards_station_reference.npz'):
        raw=(a.output/filename).read_bytes();values=arrays(raw);proposed[filename]=dict(sha256=sha(raw),bytes=len(raw),arrays=len(values),identities={n:identity(v) for n,v in values.items()})
    readout=dict(pbs_job=os.environ['PBS_JOBID'],host=socket.gethostname(),physical_calls=0,GPU_calls=0,source_manifest_sha256=sha(source['SOURCE_SHA256.json']),QC_physical_calls_reused=44,columns=columns,stations=stations,proposed_fixture_files=proposed,column_original_input_arrays_unchanged=250,station_original_inputs_config_metadata_unchanged=sorted(immutable),scope='Posthoc analysis only of immutable QC1827 raw outputs. Private proposed fixtures are review artifacts, not applied or accepted. Historical BF and all nine NQ failures retained; no source/tests/gates changed.')
    save(a.output/'reference-values.json',readout)
    after={n:sha((HERE/n).read_bytes()) for n in controls};assert after==before
    save(a.output/'receipt.json',dict(pbs_job=os.environ['PBS_JOBID'],physical_calls=0,GPU_calls=0,controls_exact=True,source_archive_sha256=sha(a.source.read_bytes()),qc_result_archive_sha256=sha(a.qc.read_bytes()),checkout_fixtures_modified=False,scientific_acceptance=False))

if __name__=='__main__':main()

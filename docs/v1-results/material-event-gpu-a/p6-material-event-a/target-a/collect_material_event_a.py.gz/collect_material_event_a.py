from pathlib import Path
import hashlib,json,os,sys
import pytest
source=Path('/home/lhwang/work/noahmp-v1/p6-material-event-a');out=source/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((source/'SOURCE_SHA256.json').read_text());nodes=[]
class Capture:
    def pytest_collection_finish(self,session):nodes.extend(v.nodeid for v in session.items)
code=int(pytest.main(['tests','--collect-only','-q'],plugins=[Capture()]));unchanged=all(sha(source/n)==v for n,v in m.items());gpu=[n for n in nodes if Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))];passed=code==0 and unchanged and len(nodes)==len(set(nodes))==1134 and len(gpu)==326
(out/'collection.json').write_text(json.dumps(dict(scope='Collection metadata only; no test, model or device validation.',returncode=code,nodes=nodes,collected=len(nodes),cpu_nodes=len(nodes)-len(gpu),gpu_nodes=len(gpu),source_unchanged=unchanged,source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),passed=passed),indent=2)+'\n');sys.stdout.flush();sys.stderr.flush();os._exit(0 if passed else 71)

from pathlib import Path
import hashlib,io,json,os,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'richards-functions-analysis-i';a=b/'richards-functions-h-evidence.tar.gz'
with tarfile.open(a) as tf:
    receipt=json.load(tf.extractfile('richards-functions-h/receipt.json'));raw=tf.extractfile('richards-functions-h/functions.npz').read()
    assert receipt['source_unchanged'] and hashlib.sha256(raw).hexdigest()==receipt['payload_sha256']
    with np.load(io.BytesIO(raw),allow_pickle=False) as z:data=dict(z)
c,j=data['cuda'],data['jax'];diff=abs(c.astype(float)-j.astype(float))
d=dict(scope='EHPC compute analysis of native common finalcoordinate function probes only; no new candidate, physical solve or acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,
    fields='first3 q, next3 integratedq, then dt/coefficient1000dt, then each of4 cells: pow/exp-log/log/exponentlog',
    cuda=c.tolist(),jax=j.tolist(),absolute_differences=diff.tolist(),original_cuda_transfer=data['original_cuda_transfer'].tolist(),original_jax_transfer=data['original_jax_transfer'].tolist(),
    original_cuda_transfer_reproduced=bool(np.array_equal(c[3:6],data['original_cuda_transfer'])),original_jax_transfer_reproduced=bool(np.array_equal(j[3:6],data['original_jax_transfer'])),
    source_manifest_sha256=receipt['source_manifest_sha256'],input_archive_sha256=hashlib.sha256(a.read_bytes()).hexdigest())
(r/'analysis.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

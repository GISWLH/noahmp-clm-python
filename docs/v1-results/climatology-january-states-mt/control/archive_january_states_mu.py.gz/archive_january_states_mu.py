from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');label='climatology-january-states-mt';r=b/label;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();q=subprocess.check_output(['qstat','-xf','1542.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M) and (r/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((r/'diagnostic.json').read_text());assert d['diagnostic_delivered'] and len(d['cases'])==12;(r/'actual-qstat.txt').write_text(q);payload={p.relative_to(r).as_posix():p.read_bytes() for p in r.rglob('*') if p.is_file()};payload['control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/(label+'-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);t.addfile(member,io.BytesIO(raw))
with tarfile.open(a) as t:
    assert len(t.getmembers())==len(payload)
    for member in t:assert t.extractfile(member).read()==payload[member.name]
out=dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(payload),scope=d['scope']+' Original year failed; all twelve fixed January state/forcing/closedBGC and prespecified SW>10 day/night statistics only. No causal attribution, parameter fit, failedyear continuation or scientific acceptance.');(b/(label+'-package.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

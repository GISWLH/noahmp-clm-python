"""All twelve January states and day/night fluxes; read-only diagnostics."""
from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=Path.cwd();tmp=Path(os.environ['TMPDIR']);d=tmp/'device';d.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();q=subprocess.check_output(['qstat','-xf','1541.manager'],text=True);assert re.search(r'^\s*job_state = F\s*$',q,re.M) and re.search(r'^\s*Exit_status = 0\s*$',q,re.M);prior=b/'climatology-reported-prefix-mq';receipt=json.loads((prior/'receipt.json').read_text());assert receipt['evaluation_delivered'] and receipt['source_unchanged'] and len(receipt['cases'])==12;(r/'prior-actual-qstat.txt').write_text(q)
a=b/'climatology-failed-year-mh-export.tar.gz';assert sha(a)=='f728890bfe81cddae1d85ae2effa69e4eb541b6f1e9ba12b335f90374d098340'
with tarfile.open(a) as t:t.extractall(d,filter='data')
batch=json.loads((d/'inputs/batch.json').read_text());assert len(batch['cases'])==12;chunks=sorted((d/'closed-bgc-chunks').glob('steps-*.npz'));assert len(chunks)==54;bgc={};keys=['bgc/lai_used','bgc/target_lai','bgc/nitrogen_factor_used','bgc/decomposition/nitrogen_limitation','bgc/decomposition/temperature_factor','bgc/decomposition/moisture_factor','bgc/environment/water_potential_mpa']
for p in chunks:
    begin,end=map(int,p.stem.split('-')[1:]);assert end-begin==48
    with np.load(p,allow_pickle=False) as z:
        for key in keys:bgc.setdefault(key,[]).append(z[key])
bgc={key:np.concatenate(value,axis=0) for key,value in bgc.items()};assert all(v.shape==(2592,12) for v in bgc.values())
summarize=lambda x:dict(mean=np.asarray(x,float).mean(0).tolist(),minimum=np.asarray(x,float).min(0).tolist(),maximum=np.asarray(x,float).max(0).tolist())
rows=[]
for k,case in enumerate(batch['cases']):
    folder=d/'reported2640'/case['case'];p=next(folder.glob('report-0002640-*.json'));report=json.loads(p.read_text());proof=receipt['cases'][k];assert proof['case']==case['case'] and proof['original_report_sha256']==sha(p) and report['batch_column']==k
    trace_path=folder/report['model_npz'];forcing_path=d/'inputs'/case['input'];config_path=d/'inputs'/case['configuration'];assert sha(trace_path)==proof['original_trace_sha256'] and sha(forcing_path)==proof['forcing_sha256'] and sha(config_path)==proof['configuration_sha256']
    with np.load(trace_path,allow_pickle=False) as z:t=dict(z)
    with np.load(forcing_path,allow_pickle=False) as z:f={key:v[:2640] for key,v in z.items()}
    mask=np.asarray([str(v)[4:6]=='01' for v in t['time_start']]);assert mask.sum()==1488;force=np.asarray(f['forcing'],np.float32).astype(float);day=mask&(force[:,5]>10.);night=mask&~day;stats={}
    for label,selected in [('january',mask),('sw_above_10wm2',day),('sw_at_most_10wm2',night)]:
        stats[label]=dict(intervals=int(selected.sum()),forcing_quantization='Original float32 producer values cast to float64 for diagnostics',forcing=dict(tair_c=summarize(force[selected,1]-273.15),qair=summarize(force[selected,2]),wind=summarize(force[selected,3]),swdown_wm2=summarize(force[selected,5]),lwdown_wm2=summarize(force[selected,6])),states={key:summarize(np.asarray(t[key])[selected]-(273.15 if key=='tsoil_k' else 0.)) for key in ['swe_m','lai','tsoil_k','smc_m3m3','liquid_m3m3']},model_flux={key:summarize(np.asarray(t[key])[selected]*(48. if key.endswith('gc_m2') else 1.)) for key in ['h_wm2','le_wm2','gpp_gc_m2','nee_gc_m2','autotrophic_respiration_gc_m2','heterotrophic_respiration_gc_m2']})
    # Only closed BGC samples 48..1488: never invent the cold first 48 records.
    january_bgc={key:summarize(v[:1440,k]) for key,v in bgc.items()}
    row=dict(case=case['case'],site=report['site'],original_year_exit=1,original_report_status='running',snapshot_steps=2640,closed_january_bgc_start=48,closed_january_bgc_end=1488,all_predeclared_daynight_groups=stats,closed_january_bgc=january_bgc,source_manifest_sha256=receipt['source_manifest_sha256'],original_report_sha256=sha(p),scope=__doc__+' Carbon flux statistics are gC/m2/day; soil temperature is Celsius. Day/night split fixed at incoming shortwave 10 W/m2, no observation masking, parameter fitting or selected-case acceptance. No failedyear continuation or spinup/annual/scientific pass.');rows.append(row)
    print(json.dumps(dict(case=case['case'],lai=row['all_predeclared_daynight_groups']['january']['states']['lai'],swe=row['all_predeclared_daynight_groups']['january']['states']['swe_m'])),flush=True)
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,diagnostic_delivered=len(rows)==12,cases=rows,seconds=time.monotonic()-start,scope=__doc__);(r/'diagnostic.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');assert out['diagnostic_delivered']

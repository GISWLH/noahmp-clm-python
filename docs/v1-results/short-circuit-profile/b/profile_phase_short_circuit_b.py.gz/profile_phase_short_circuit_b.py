"""Controlled uninstrumented CUDA timing; Nsight runs separately.

Only the two backtracking loop conditions differ. No running model or frozen
source is edited. Save every300-field result and both exact CUDA sources.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,time
import numpy as np
import cupy as cp
from test_gpu_canopy_phase_energy import batch
from test_gpu_phase_jacobian_boundary import arrays as actual_arrays,operands
from noahmp_clm.gpu.canopy_boundary import radiation_inputs
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.gpu.cuda.canopy_snow_radiation import _kernel as radiation_kernel
from noahmp_clm.gpu.cuda.snicar import _tables
from noahmp_clm.gpu.cuda.canopy_phase_energy import _kernel as production_kernel

parser=argparse.ArgumentParser();parser.add_argument('--trace-only',action='store_true');args=parser.parse_args()
root=Path.cwd();output=root/'profile_output';output.mkdir(exist_ok=True)
source=Path('/home/lhwang/work/noahmp-v1/p6-phase-jacobian-gpu-a')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items())
names=['leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu']
original='\n'.join((source/'src/noahmp_clm/gpu/cuda'/name).read_text() for name in names)
adapter=r'''
extern "C" __global__ void profile_saved_phase(const float* a,const float* u,const float* f,const float* soil,
 const float* stem,const float* c,const float* b,const float* radiation,const float* p,const float* extension,float* out,int n) {
 for(int row=blockIdx.x*blockDim.x+threadIdx.x;row<n;row+=blockDim.x*gridDim.x){
  PhaseContext v;phase_prepare(a+10*row,u+23*row,f+20*row,soil+10*row,stem+10*row,c+20*row,b+9*row,p,radiation+584*row,v);
  v.water_velocity=extension[2*row];v.heat_temperature=extension[2*row+1];phase_solve(v,out+300*row,100,.005f);
 }
}
'''
modules={};kernels={};compile_times={}
for mode in ['baseline','candidate']:
    code=original
    if mode=='candidate':
        assert code.count('for(int k=0;k<24;++k) {')==1 and code.count('for(int k=0;k<24;++k){')==1
        code=code.replace('for(int k=0;k<24;++k) {','for(int k=0;k<24&&!accepted;++k) {').replace('for(int k=0;k<24;++k){','for(int k=0;k<24&&!accepted;++k){')
    code+=adapter
    code=code.replace('void run_canopy_phase(','void profile_phase_batch_'+mode+'(').replace('void profile_saved_phase(','void profile_phase_saved_'+mode+'(')
    path=output/(mode+'.cu')
    if path.exists():assert path.read_text()==code
    else:path.write_text(code)
    begun=time.monotonic();exports=('profile_phase_batch_'+mode,'profile_phase_saved_'+mode)
    modules[mode]=cp.RawModule(code=code,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=exports)
    kernels[mode]=[modules[mode].get_function(name) for name in exports];compile_times[mode]=time.monotonic()-begun

def prepare(label):
    if label=='original23':
        host=batch(np.float32);parameters=pack_leaf_parameters(dtype=np.float32);extension=None
    else:
        host=tuple(v[None,...] for v in actual_arrays(np.float32));v,_,_=operands();parameters=v['leaf_parameters'].astype(np.float32);extension=v['extension'][None,:].astype(np.float32)
    a,u,f,soil,stem,c,b,snow,n=tuple(cp.ascontiguousarray(cp.asarray(v)) for v in host)
    count=len(a);rad=cp.empty((count,584),cp.float32)
    radiation_kernel(True)((1,),(32,),(cp.ascontiguousarray(a+stem),snow,n,cp.ascontiguousarray(radiation_inputs(a+stem,u,cp)),*_tables(),rad,np.int32(count)))
    common=(a,u,f,soil,stem,c,b,rad,cp.asarray(parameters));outputs={mode:cp.empty((count,300),cp.float32) for mode in kernels}
    index=0 if extension is None else 1
    extension_device=None if extension is None else cp.asarray(extension)
    def invoke(mode):
        tail=(outputs[mode],np.int32(count),np.int32(100),np.float32(.005)) if extension is None else (extension_device,outputs[mode],np.int32(count))
        kernels[mode][index]((1,),(32,),(*common,*tail))
    for mode in kernels:
        for _ in range(3):invoke(mode)
    cp.cuda.get_current_stream().synchronize()
    first={mode:cp.asnumpy(v) for mode,v in outputs.items()}
    assert all(np.all(np.isfinite(v)) and np.all(v[:,68]==1.) for v in first.values())
    np.testing.assert_array_equal(first['baseline'],first['candidate'])
    if extension is None:
        control=cp.empty_like(outputs['baseline']);production_kernel()((1,),(32,),(*common,control,np.int32(count),np.int32(100),np.float32(.005)))
        np.testing.assert_array_equal(cp.asnumpy(control),first['baseline'])
    else:
        from test_gpu_phase_jacobian_boundary import cuda_result
        np.testing.assert_array_equal(cuda_result(),first['baseline'][0])
    payload={f'a{k}':v for k,v in enumerate(host)};payload.update(parameters=parameters,baseline=first['baseline'],candidate=first['candidate'])
    if extension is not None:payload['extension']=extension
    np.savez_compressed(output/(label+('-trace' if args.trace_only else '')+'.npz'),**payload)
    return invoke,count,outputs

rows=[];pairs=2 if args.trace_only else 20;repeats=2 if args.trace_only else 5
for label in ['original23','actual_g614']:
    invoke,count,buffers=prepare(label);samples={mode:[] for mode in kernels};cpu={mode:[] for mode in kernels};wall={mode:[] for mode in kernels}
    for pair in range(pairs):
        for mode in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
            event0,event1=cp.cuda.Event(),cp.cuda.Event();begun=time.perf_counter();cpu0=time.process_time()
            if args.trace_only:cp.cuda.nvtx.RangePush(label+'/'+mode)
            event0.record()
            for _ in range(repeats):invoke(mode)
            event1.record();event1.synchronize()
            if args.trace_only:cp.cuda.nvtx.RangePop()
            samples[mode].append(cp.cuda.get_elapsed_time(event0,event1)/repeats)
            wall[mode].append(1000*(time.perf_counter()-begun)/repeats);cpu[mode].append(1000*(time.process_time()-cpu0)/repeats)
    final={mode:cp.asnumpy(value) for mode,value in buffers.items()};np.testing.assert_array_equal(final['baseline'],final['candidate'])
    row=dict(case=label,columns=count,source='Original23 synthetic/regression inputs' if label=='original23' else 'Actual saved old G614 phase operands',pairs=pairs,repeats=repeats,
        gpu_ms=samples,cpu_process_ms=cpu,wall_ms=wall,same_precision_max_absolute=0.,all300_fields_bitwise_equal=True,
        gpu_summary={mode:dict(median_ms=float(np.median(v)),p10_ms=float(np.percentile(v,10)),p90_ms=float(np.percentile(v,90))) for mode,v in samples.items()},
        paired_speedup_median=float(np.median(np.asarray(samples['baseline'])/np.asarray(samples['candidate']))))
    rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['gpu_ms','cpu_process_ms','wall_ms']}),flush=True)
assert all(sha(source/k)==v for k,v in manifest.items())
result=dict(scope='Uninstrumented kernel A/B timing with alternating order, concurrent server workloads disclosed; no whole-column/annual speed claim. Nsight trace runs separately.',
    timing_inputs_resident=True,trace_only=args.trace_only,finished_utc=datetime.now(timezone.utc).isoformat(),source_files=len(manifest),source_unchanged=True,
    compile_seconds_excluded=compile_times,cupy_version=cp.__version__,device_name=str(cp.cuda.runtime.getDeviceProperties(0)['name']),
    logical_device=0,physical_gpu=1,instrument_sha256=sha(Path(__file__)),source_sha256={name:sha(output/(name+'.cu')) for name in modules},cases=rows)
(output/('trace-result.json' if args.trace_only else 'timing-result.json')).write_text(json.dumps(result,indent=2)+'\n')

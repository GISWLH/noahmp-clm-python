from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys,time
root=Path.cwd();output=root/'profile_output';output.mkdir(exist_ok=True)
commands=[('timing',[sys.executable,'-u',str(root/'profile_phase_short_circuit.py')]),
    ('nsys',['/usr/local/cuda-12.4/bin/nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','-o',str(output/'phase-trace'),sys.executable,'-u',str(root/'profile_phase_short_circuit.py'),'--trace-only']),
    ('stats',['/usr/local/cuda-12.4/bin/nsys','stats','--report','cuda_gpu_kern_sum,cuda_api_sum','--format','csv',str(output/'phase-trace.nsys-rep')])]
results=[]
for label,command in commands:
    begun=time.monotonic()
    with (output/(label+'.log')).open('w') as log:code=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    result=dict(stage=label,returncode=code,seconds=time.monotonic()-begun,command=command);results.append(result);print(json.dumps(result),flush=True)
    if code!=0:break
(output/'controller.json').write_text(json.dumps(dict(finished_utc=datetime.now(timezone.utc).isoformat(),stages=results),indent=2)+'\n')
assert results[0]['returncode']==0

"""Pure four-layer CLM drainage diagnosis; no trial, phase step or outflow.

The input phase is explicit, with the same contract as the original F trial.
This API does not repair T/liquid/ice or invent a duration to call a trial.
"""
from functools import lru_cache
import numpy as np
from ._clm_drainage_input_guard import _group, require_jax_precision
from . import clm_drainage_primitives as primitives


def _require_inputs(cells, parameters, backend):
    size, information = _group((('cells', cells), ('parameters', parameters)), backend)
    shape = information['cells'][1]
    if (len(shape) != 3 or shape[0] < 1 or shape[1:] != (4, 6)
            or information['parameters'][1] != (shape[0], 12)):
        raise ValueError('Pure drainage diagnosis requires [B,4,6] and [B,12]')
    return size


def _validate(cells, pars, xp):
    # The stock/material checks from the original primitive, with no invented
    # interval and no trial. Raw shapes and dtype were checked before conversion.
    if not all(bool(xp.all(xp.isfinite(a))) for a in (cells, pars)):
        raise ValueError('Finite drainage diagnosis inputs required')
    edges = xp.cumsum(cells[:, :, 2], axis=1)
    eps = xp.finfo(cells.dtype).eps
    matches = xp.sum(xp.abs(edges-pars[:, 4, None]) <= 16*eps*xp.maximum(edges[:, -1, None], 1), axis=1)
    bad = xp.any((cells[:, :, 0] < 0) | (cells[:, :, 1] < 0) | (cells[:, :, 2] <= 0)
        | (cells[:, :, 3] < 150) | (cells[:, :, 3] > 400) | (cells[:, :, 4] < 0)
        | (cells[:, :, 4] > 1000*cells[:, :, 2]*pars[:, 0, None]), axis=1)
    bad |= xp.any(xp.abs(cells[:, :, 0]+cells[:, :, 1]-cells[:, :, 4])
                  > 16*eps*xp.maximum(cells[:, :, 4], 1), axis=1)
    bad |= ((pars[:, 0] <= 0) | (pars[:, 0] >= 1) | (pars[:, 1] <= 0) | (pars[:, 2] <= 0)
        | (pars[:, 3] < 0) | (pars[:, 4] <= 0) | (matches != 1) | (pars[:, 5] < 0) | (pars[:, 5] >= xp.pi/2)
        | (pars[:, 6] < 0) | (pars[:, 7] < 0) | (pars[:, 8] <= 0) | (pars[:, 8] >= 1)
        | (pars[:, 9] <= 0) | (pars[:, 9] >= pars[:, 0]) | (pars[:, 10] < 0) | (pars[:, 11] < 0))
    if bool(xp.any(bad)):
        raise ValueError('Invalid drainage diagnosis stocks, phase, geometry or parameters')


@lru_cache(maxsize=1)
def _jax_diagnosis():
    import jax
    import jax.numpy as j
    return jax.jit(jax.vmap(lambda c, p: primitives._diagnosis(c, p, j, jax.lax.optimization_barrier)))


def diagnose_clm_drainage(cells6, drainage_parameters12, *, backend='numpy'):
    """Return original F's 29 diagnostics, in the explicit input precision."""
    size = _require_inputs(cells6, drainage_parameters12, backend)
    if backend == 'numpy':
        xp = np
    elif backend == 'jax':
        require_jax_precision(size)
        import jax.numpy as xp
    else:
        import cupy as xp
    cells, pars = (xp.asarray(value) for value in (cells6, drainage_parameters12))
    _validate(cells, pars, xp)
    if backend == 'numpy':
        result = xp.stack([primitives._diagnosis(c, p, xp, lambda x: x) for c, p in zip(cells, pars)])
    elif backend == 'jax':
        result = _jax_diagnosis()(cells, pars)
    else:
        cells, pars = xp.ascontiguousarray(cells), xp.ascontiguousarray(pars)
        result = xp.empty((len(cells), 29), cells.dtype)
        primitives._cuda_module().get_function('drainage_diagnosis<float>')(
            ((len(cells)+127)//128,), (128,), (cells, pars, result, np.int32(len(cells))))
    if result.dtype != cells.dtype or not bool(xp.all(xp.isfinite(result))):
        raise RuntimeError('Pure drainage diagnosis changed precision or returned nonfinite values')
    return result

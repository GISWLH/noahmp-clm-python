"""Prepared EHPC-only CPU tests, not executed while authoring the candidate."""
import os
import socket
if os.name == 'nt' or not os.environ.get('PBS_JOBID') or socket.gethostname() != 'compute002':
    raise RuntimeError('PB-p numerical tests require an authorized EHPC compute002 PBS job')

from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import hashlib
import io
import json
import math
import tarfile
import numpy as np
import pytest
from noahmp_clm.column import SoilParams
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState, enthalpy_and_capacity
from noahmp_clm.physics.clm_hydrology import CLMVerticalHydrology, advance_clm_hydrology
from noahmp_clm.physics.richards import redistribute_soil_enthalpy
from noahmp_clm.physics.clm_saturated_drainage import DrainageParameters, drain_saturated_soil, diagnose_water_tables
from noahmp_clm.gpu import clm_drainage_primitives as primitive
from noahmp_clm.gpu import clm_perched_drainage_primitives as perched
from noahmp_clm.gpu import clm_drainage_column as adapter
from noahmp_clm.gpu import clm_drainage_diagnosis as diagnosis


HERE = Path(__file__).resolve().parent
PROFILES = ('warm', 'frozen', 'perched_micro', 'perched_stress', 'zero_slope',
            'option2', 'nonuniform_dz', 'two_bands')
sha = lambda b: hashlib.sha256(b).hexdigest()


def fixture(name, dtype=np.float64):
    theta = np.full(4, .44); temperature = np.full(4, 290.); dz = np.full(4, .5)
    params = SoilParams(); option = 1; slope = .2; seconds = 1800.
    if name == 'frozen': temperature[:] = 270.; theta[:] = .4
    if name in ('perched_micro', 'perched_stress', 'option2'):
        theta = np.array([.39, .43, .4, .2]); temperature = np.array([280., 280., 270., 280.])
        if name == 'perched_micro': theta[0] = .2
        if name in ('perched_stress', 'option2'): params = replace(params, satdk=10.)
        if name == 'option2': option = 2
    if name == 'zero_slope': slope = 0.
    if name == 'nonuniform_dz': dz = np.array([.125, .375, .5, 1.])
    if name == 'two_bands':
        theta = np.array([.43, .4, .2, .44]); temperature = np.array([280., 270., 280., 280.])
        params = replace(params, satdk=10.)
    if name == 'dry': theta[:] = 0.
    water = 1000*theta*dz
    heat = enthalpy_and_capacity(water, temperature, dz, params, option)[0]
    cells = np.stack((water, heat, dz), axis=1).astype(dtype)[None]
    properties = np.asarray([[params.smcmax, params.bexp, params.smcref, params.satdk,
                              params.quartz, params.smcwlt, params.saturated_suction_m]], dtype)
    options = np.asarray([option], np.int32); dt = np.asarray([seconds], dtype)
    configuration = CLMVerticalHydrology(DrainageParameters(2., slope))
    return cells, properties, options, dt, configuration


def reference_from_encoded(c, p, o, configuration):
    # All seven material fields are reconstructed from the actual raw ABI;
    # even float32 reference inputs are widened exactly, not regenerated.
    material = SoilParams(smcmax=float(p[0]), bexp=float(p[1]), smcref=float(p[2]), satdk=float(p[3]),
                          quartz=float(p[4]), smcwlt=float(p[5]), saturated_suction_m=float(p[6]))
    d = configuration.drainage
    # Python config scalars have an explicit encoding boundary in the adapter.
    # The reference receives those same representable values, not nominal 64s.
    scalar = c.dtype.type
    d = replace(d, **{k: float(scalar(v)) for k, v in vars(d).items()})
    ground = SoilEnthalpyState(c[:, 0].astype(float), c[:, 1].astype(float), c[:, 2].astype(float), material, int(o))
    return ground, replace(configuration, drainage=d)


def flatten(tree, prefix=''):
    result = {}
    for k, v in tree.items():
        name = prefix+k
        if isinstance(v, dict): result.update(flatten(v, name+'.'))
        else:
            a = np.asarray(v)
            assert a.dtype.kind in 'biuf' and np.all(np.isfinite(a)), name
            result[name] = a
    return result


def json_value(value):
    if isinstance(value, dict): return {k: json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [json_value(v) for v in value]
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.generic): return value.item()
    return value


def emit(name, arrays, rows):
    out = Path(os.environ['PBP_RESULTS']); out.mkdir(parents=True, exist_ok=True)
    target = out/(name+'.npz'); np.savez(target, **arrays)
    proof = {k: dict(dtype=v.dtype.str, shape=list(v.shape), c_order_sha256=sha(v.tobytes())) for k, v in arrays.items()}
    record = dict(case=name, file=target.name, sha256=sha(target.read_bytes()), arrays=proof, comparisons=rows)
    (out/(name+'.json')).write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print('PB_P_DIAGNOSTIC '+json.dumps(dict(case=name, comparisons=rows), allow_nan=False), flush=True)


def comparison(actual, expected, absolute, relative=.1):
    a, b = np.asarray(actual, float), np.asarray(expected, float)
    delta = a-b; bound = np.maximum(absolute, relative*np.abs(b))
    result = dict(actual=a.tolist(), reference=b.tolist(), signed_difference=delta.tolist(),
        absolute_tolerance=absolute, relative_fraction=relative, bound=bound.tolist(),
        maximum_absolute_difference=float(np.max(np.abs(delta), initial=0)), passed=bool(np.all(abs(delta) <= bound)))
    # No NaN near-zero ratios in the persisted JSON.
    result['relative_percent'] = [float(100*x/abs(y)) if abs(y) > absolute/max(relative, 1e-300) else None
                                  for x, y in zip(delta.ravel(), b.ravel())]
    return result


def checked_reference(name, values):
    c, p, o, dt, config = values
    original = [a.tobytes() for a in values[:4]]
    ground, effective = reference_from_encoded(c[0], p[0], o[0], config)
    expected, ledger = drain_saturated_soil(ground, float(dt[0]), effective.drainage, effective.integration)
    actual = adapter.run_clm_drainage(*values)
    assert original == [a.tobytes() for a in values[:4]]
    assert actual['cells'].dtype == c.dtype
    records = {}
    for key, value, absolute, relative in (
        ('water', expected.water, .001, .1), ('enthalpy', expected.enthalpy, .5, .1),
        ('temperature', expected.temperature, .001, 0), ('liquid', expected.liquid, .001, .1),
        ('ice', expected.ice, .001, .1)):
        candidate = {'water': actual['cells'][0, :, 0], 'enthalpy': actual['cells'][0, :, 1],
            'temperature': actual['temperature_k'][0], 'liquid': actual['liquid_kg_m2'][0], 'ice': actual['ice_kg_m2'][0]}[key]
        records[key] = comparison(candidate, value, absolute, relative)
    for kind in ('saturated', 'perched'):
        assert 'backend_code' not in actual[kind]
        original_band = next((b for b in ledger['bands'] if b['kind'] == kind), None)
        for key, absolute in (('layer_mass_kg_m2', .001), ('layer_enthalpy_j_m2', .05 if kind == 'saturated' else .5),
                              ('drained_kg_m2', .001), ('drained_enthalpy_j_m2', .05 if kind == 'saturated' else .5)):
            ref = original_band[key] if original_band is not None else np.zeros_like(actual[kind][key][0], dtype=float)
            records[kind+'.'+key] = comparison(actual[kind][key][0], ref, absolute)
        if bool(actual[kind]['invoked'][0]):
            assert original_band is not None
            records[kind+'.migrated_front_m'] = comparison(actual[kind]['migrated_front_m'][0], original_band['migrated_front_m'], 1e-6)
            assert actual[kind]['elapsed_seconds'][0] == float(dt[0])
            assert actual[kind]['clock_residual_seconds'][0] == 0
        else:
            assert actual[kind]['elapsed_seconds'][0] == actual[kind]['accepted_substeps'][0] == 0
    for stage, ref in (('diagnosis_before', ledger['diagnosis_before']),
                       ('diagnosis_after_perched', ledger['diagnosis_after_perched']), ('diagnosis_after', ledger['diagnosis_after'])):
        for index, key in ((0, 'water_table_m'), (1, 'frost_table_m'), (2, 'perched_water_table_m')):
            records[stage+'.'+key] = comparison(actual[stage][0, index], 0. if ref[key] is None else ref[key], 1e-6)
        assert bool(actual[stage][0, 3]) == (ref['frost_table_m'] is not None)
        assert bool(actual[stage][0, 4]) == (ref['perched_water_table_m'] is not None)
    for tree in (actual, actual['saturated'], actual['perched']):
        for residual, bound in (('water_residual_kg_m2', 'water_bound_kg_m2'), ('energy_residual_j_m2', 'energy_bound_j_m2')):
            assert abs(tree[residual][0]) <= tree[bound][0]
    for residual, bound in (('water_residual_kg_m2', 'water_bound_kg_m2'), ('energy_residual_j_m2', 'energy_bound_j_m2')):
        assert abs(ledger[residual]) <= ledger[bound]
    reference_path = Path(os.environ['PBP_RESULTS'])/(name+'-original-reference.json')
    reference_path.parent.mkdir(parents=True, exist_ok=True)
    reference_path.write_text(json.dumps(json_value(ledger), indent=2, allow_nan=False)+'\n')
    # Sum represented stocks/exports independently at Python float precision.
    mass = actual['layer_mass_kg_m2'][0]; heat = actual['layer_enthalpy_j_m2'][0]
    mr = math.fsum([*map(float, actual['cells'][0, :, 0]), *map(float, -c[0, :, 0]), *map(float, mass)])
    hr = math.fsum([*map(float, actual['cells'][0, :, 1]), *map(float, -c[0, :, 1]), *map(float, heat)])
    assert abs(mr) <= actual['water_bound_kg_m2'][0] and abs(hr) <= actual['energy_bound_j_m2'][0]
    records['hard_budget'] = dict(water_residual=mr, heat_residual=hr, water_bound=float(actual['water_bound_kg_m2'][0]),
                                 heat_bound=float(actual['energy_bound_j_m2'][0]), passed=True)
    records['reference_hard_budget'] = {k: float(ledger[k]) for k in ('water_residual_kg_m2', 'energy_residual_j_m2',
                                                                    'water_bound_kg_m2', 'energy_bound_j_m2')}
    records['reference_hard_budget']['passed'] = True
    arrays = {'input.cells': c, 'input.properties': p, 'input.options': o, 'input.dt': dt,
              'reference.water': expected.water, 'reference.enthalpy': expected.enthalpy,
              'reference.temperature': expected.temperature, 'reference.liquid': expected.liquid, 'reference.ice': expected.ice}
    arrays.update({'actual.'+k: v for k, v in flatten(actual).items()})
    emit(name, arrays, records)
    assert all(r['passed'] for r in records.values()), name
    return actual, ground, effective, expected


@pytest.mark.parametrize('dtype', [np.float64, np.float32])
@pytest.mark.parametrize('profile', PROFILES)
def test_adapter_independent_physics_reference(dtype, profile):
    actual, _, _, _ = checked_reference(profile+'-'+np.dtype(dtype).name, fixture(profile, dtype))
    if profile in ('warm', 'nonuniform_dz', 'two_bands'):
        assert actual['saturated']['invoked'][0] and actual['saturated']['drained_kg_m2'][0] > 0
    if profile in ('perched_micro', 'perched_stress', 'option2', 'two_bands'):
        assert actual['perched']['invoked'][0] and actual['perched']['drained_kg_m2'][0] > 0
    if profile == 'zero_slope':
        assert actual['saturated']['invoked'][0] and actual['drained_kg_m2'][0] == 0


def test_original_twenty_gold_diagnosis_and_trial_preserved():
    binding = json.loads((HERE/'GOLD32_BINDINGS.json').read_bytes())
    path = Path(os.environ['PBP_GOLD_ARCHIVE'])
    assert sha(path.read_bytes()) == binding['archive_sha256']
    checked = 0
    with tarfile.open(path) as t:
        recipes = json.loads(t.extractfile('gold/case-recipes.json').read())
        assert len(recipes) == 20
        for row in recipes:
            name = row['name']; prefix = 'gold/'+name+'/'
            def read(leaf):
                name = prefix+leaf; raw = t.extractfile(name).read()
                assert sha(raw) == binding['members'][name]
                meta = json.loads(t.extractfile(name+'.json').read())
                assert sha(t.extractfile(name+'.json').read()) == binding['members'][name+'.json']
                with np.load(io.BytesIO(raw), allow_pickle=False) as store: values = {k: store[k].copy() for k in store.files}
                assert set(values) == set(meta['arrays']) and sha(raw) == meta['npz_sha256']
                for k, v in values.items():
                    d = meta['arrays'][k]
                    assert (v.dtype.str, list(v.shape), v.nbytes, sha(v.tobytes())) == (d['dtype'], d['shape'], d['bytes'], d['c_order_sha256'])
                return values
            inputs, original = read('input32.npz'), read('numpy32.npz')
            c, p, u = (inputs[k] for k in ('cells', 'parameters', 'interval'))
            original_bytes = [v.tobytes() for v in (c, p, u)]
            d = diagnosis.diagnose_clm_drainage(c[None], p[None])[0]
            call = primitive.run_numpy if row['kind'] == 'main' else perched.run_numpy_perched
            old_d, trial = call(c[None], p[None], u[None]); trial = trial[0]
            assert d.dtype == old_d.dtype and d.tobytes() == old_d[0].tobytes()
            values = {'diagnosis.'+k: np.asarray(d[i]) for i, k in enumerate(primitive.DIAGNOSTIC_FIELDS)}
            for start, field in ((13, 'main_weights'), (17, 'perched_weights'), (21, 'ice_fraction'), (25, 'saturation')):
                values['diagnosis.'+field] = d[start:start+4]
            names = ('front', 'potential_requested_kg_m2', 'drained_kg_m2', 'unavailable_liquid_kg_m2',
                     'band_exhaustion_kg_m2', 'liquid_limited', 'water_residual_kg_m2', 'energy_residual_j_m2',
                     'water_bound_kg_m2', 'energy_bound_j_m2')
            values.update({'trial.'+k: np.asarray(trial[i]) for i, k in enumerate(names)})
            for start, field in ((10, 'layer_mass_kg_m2'), (14, 'layer_enthalpy_j_m2'), (18, 'water_after'), (22, 'enthalpy_after')):
                values['trial.'+field] = trial[start:start+4]
            if row['kind'] == 'perched':
                values.update({'trial.'+k: np.asarray(trial[i]) for i, k in enumerate(('main_depth_for_Sy', 'specific_yield', 'first_donor'), 26)})
            assert set(values) == {k for k in original if k.startswith(('diagnosis.', 'trial.'))}
            for k, v in values.items():
                ref = original[k]
                assert v.dtype == ref.dtype and v.shape == ref.shape and v.tobytes() == ref.tobytes(), (name, k)
                checked += 1
            assert original_bytes == [v.tobytes() for v in (c, p, u)]
    print('PB_P_GOLD '+json.dumps(dict(cases=20, diagnostic_trial_fields_byteexact=checked, full_integrations=0)), flush=True)


def test_actual_post_richards_state_matches_original_combined_operator():
    c, p, o, dt, config = fixture('warm')
    # A real water gradient makes zero-flux transport nontrivial.
    initial, effective = reference_from_encoded(c[0], p[0], o[0], config)
    w = initial.water*np.asarray([.8, .9, 1., 1.])
    h = enthalpy_and_capacity(w, initial.temperature, initial.dz, initial.params, int(o[0]))[0]
    initial = SoilEnthalpyState(w, h, initial.dz, initial.params, int(o[0]))
    transported, transport = redistribute_soil_enthalpy(initial, float(dt[0]), **config.transport.controls())
    expected, independent_transport, full = advance_clm_hydrology(initial, float(dt[0]), effective)
    assert transported.water.tobytes() == full['water_after_transport_kg_m2'].tobytes()
    assert transported.enthalpy.tobytes() == full['enthalpy_after_transport_j_m2'].tobytes()
    c = np.stack((transported.water, transported.enthalpy, transported.dz), axis=1)[None]
    result, _, _, direct_reference = checked_reference('post-richards', (c, p, o, dt, config))
    assert expected.water.tobytes() == direct_reference.water.tobytes()
    assert expected.enthalpy.tobytes() == direct_reference.enthalpy.tobytes()
    assert full['zero_flux_bottom_mass_kg_m2'] == full['zero_flux_bottom_enthalpy_j_m2'] == 0.
    assert full['operator_order'] == ('richards_zero_flux', 'perched', 'saturated')
    assert result['cells'].shape == (1, 4, 3) and transport and independent_transport


def test_missing_bands_do_not_call_a_fake_trial_or_complete_a_clock():
    values = fixture('dry')
    with patch.object(adapter.main, 'advance_main_band', side_effect=AssertionError('absent main called')):
        with patch.object(adapter.perched, 'advance_perched_band', side_effect=AssertionError('absent perched called')):
            result = adapter.run_clm_drainage(*values)
    for kind in ('saturated', 'perched'):
        assert not result[kind]['invoked'][0]
        assert result[kind]['elapsed_seconds'][0] == result[kind]['quantized_requested_duration_seconds'][0] == 0.
    assert result['cells'].tobytes() == values[0].tobytes()


def test_pure_diagnosis_never_calls_a_trial():
    c, p, o, _, config = fixture('warm')
    ground, effective = reference_from_encoded(c[0], p[0], o[0], config)
    cell, pars, _ = primitive.pack(ground, effective.drainage, 1., .5, 2.)
    with patch.object(primitive, '_trial', side_effect=AssertionError('trial reached')):
        actual = diagnosis.diagnose_clm_drainage(cell[None], pars[None])
    assert actual[0, 0] == diagnose_water_tables(ground, effective.drainage)['water_table_m']


def test_raw_dtype_rejected_before_backend_phase_or_gpu_import():
    c, p, o, dt, config = fixture('warm', np.float32)
    with patch.object(adapter.main, '_backend', side_effect=AssertionError('backend reached')):
        for bad in (c.astype(np.float64), c.astype(np.float16), c.astype(np.int32), c.astype(np.bool_), c.tolist()):
            with pytest.raises(ValueError): adapter.run_clm_drainage(bad, p, o, dt, config, backend='cuda')
        with pytest.raises(ValueError): adapter.run_clm_drainage(c, p, o.astype(np.int64), dt, config)
        with pytest.raises(ValueError): adapter.run_clm_drainage(c.astype(np.float64), p.astype(np.float64), o, dt.astype(np.float64), config, backend='cuda')


def test_shapes_phase_and_bedrock_contract_reject_before_inverse():
    c, p, o, dt, config = fixture('warm')
    with patch.object(adapter, '_phase_from_stocks', side_effect=AssertionError('inverse reached')):
        for layers in (3, 6):
            bad = np.zeros((1, layers, 3), c.dtype)
            with pytest.raises(ValueError): adapter.run_clm_drainage(bad, p, o, dt, config)
        with pytest.raises(ValueError): adapter.run_clm_drainage(c, p, np.asarray([3], np.int32), dt, config)
        bad_config = replace(config, drainage=replace(config.drainage, bedrock_depth_m=1.5))
        with pytest.raises(ValueError): adapter.run_clm_drainage(c, p, o, dt, bad_config)


def test_explicit_public_float32_encoding_is_valid_metadata():
    c, p, o, dt, config = fixture('warm')
    # This is an explicit application encoding, not an implicit raw-API cast.
    encoded = tuple(a.astype(np.float32) if a.dtype.kind == 'f' else a for a in (c, p, o, dt))
    adapter._require_inputs(*encoded, config, 'cuda')
    assert all(a.dtype == np.float32 for a in (encoded[0], encoded[1], encoded[3]))


def test_nonfinite_budget_residual_or_bound_never_passes():
    # Direct independent boundary test, no model/phase/GPU calculation. NaN
    # comparisons alone are false, so each nonfinite channel must raise.
    original = np.zeros((4, 6), dtype=np.float64)
    zero = np.zeros(4, dtype=np.float64)
    for value in (np.nan, np.inf, -np.inf):
        for channel in ('water', 'heat', 'water_export', 'heat_export'):
            before = original.copy(); after = original.copy(); mass = zero.copy(); heat = zero.copy()
            if channel == 'water': after[0, 4] = value
            if channel == 'heat': after[0, 5] = value
            if channel == 'water_export': mass[0] = value
            if channel == 'heat_export': heat[0] = value
            with np.errstate(invalid='ignore'):
                with pytest.raises(RuntimeError, match='Nonfinite'):
                    adapter._budget(before, after, mass, heat, np)
    for column in (4, 5):
        before = original.copy(); before[0, column] = 1e308
        with np.errstate(over='ignore'):
            with pytest.raises(RuntimeError, match='Nonfinite'):
                adapter._budget(before, before.copy(), zero, zero, np)

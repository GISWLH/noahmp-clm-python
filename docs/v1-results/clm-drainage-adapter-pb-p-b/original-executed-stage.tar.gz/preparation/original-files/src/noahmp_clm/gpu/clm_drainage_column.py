"""Isolated post-Richards outlets, without complete-column registration.

Raw floating inputs retain their explicit precision. Configuration scalars are
encoded once into the returned 12-parameter ABI. The adapter never transports
water between layers: the caller must supply the actual post-Richards W/H.
"""
import numpy as np
from ._clm_drainage_input_guard import _group
from .clm_drainage_diagnosis import diagnose_clm_drainage
from . import clm_drainage_adaptive as main
from . import clm_perched_drainage_adaptive as perched
from ..physics.clm_hydrology import CLMVerticalHydrology


_PHYSICAL_FIELDS = (
    'layer_mass_kg_m2', 'layer_enthalpy_j_m2', 'drained_kg_m2', 'drained_enthalpy_j_m2',
    'water_residual_kg_m2', 'energy_residual_j_m2', 'water_bound_kg_m2', 'energy_bound_j_m2',
    'migrated_front_m', 'potential_requested_kg_m2', 'unavailable_liquid_kg_m2', 'band_exhaustion_kg_m2')
_HOST_FLOAT_FIELDS = (
    'initial_front_m', 'band_bottom_m', 'elapsed_seconds', 'maximum_accepted_error_ratio',
    'quantized_requested_duration_seconds', 'clock_residual_seconds')
_HOST_INT_FIELDS = ('accepted_substeps', 'rejected_substeps')
_BOOL_FIELDS = ('perched_evolution', 'production_registered', 'float32_physical_accuracy_validated')
_LABEL_FIELDS = ('kind', 'backend', 'precision', 'local_error_basis')


def _require_inputs(cells, parameters, phase_options, duration, configuration, backend):
    _, information = _group((('cells', cells), ('soil_parameters', parameters), ('duration', duration)), backend)
    shape = information['cells'][1]
    options_dtype = getattr(phase_options, 'dtype', None)
    if (len(shape) != 3 or shape[0] < 1 or shape[1:] != (4, 3)
            or information['soil_parameters'][1] != (shape[0], 7)
            or information['duration'][1] != (shape[0],)
            or tuple(getattr(phase_options, 'shape', ())) != (shape[0],)
            or getattr(options_dtype, 'kind', None) != 'i'
            or getattr(options_dtype, 'itemsize', None) != 4
            or not getattr(options_dtype, 'isnative', False)):
        raise ValueError('Drainage adapter requires [B,4,3], [B,7], native int32[B], duration[B]')
    if not isinstance(configuration, CLMVerticalHydrology):
        raise TypeError('Explicit CLMVerticalHydrology configuration required')


def _encode_parameters(properties, configuration, xp):
    d = configuration.drainage
    scalars = (d.bedrock_depth_m, d.slope_radians, d.baseflow_mm_s_per_m, d.perched_scale_per_m,
               d.saturation_threshold, d.minimum_specific_yield, d.retained_liquid_kg_m2, d.ice_impedance_exponent)
    return xp.stack((properties[:, 0], properties[:, 6], properties[:, 1], properties[:, 3],
                     *(xp.full(len(properties), value, properties.dtype) for value in scalars)), axis=1)


def _validate_values(cells, properties, options, duration, parameters, xp):
    if not all(bool(xp.all(xp.isfinite(v))) for v in (cells, properties, duration, parameters)):
        raise ValueError('Finite post-Richards drainage inputs required')
    if bool(xp.any((options != 1) & (options != 2))):
        raise ValueError('Original freezing option 1 or 2 required')
    invalid = ((properties[:, 0] <= 0) | (properties[:, 0] >= 1) | (properties[:, 1] <= 0)
        | (properties[:, 2] < 0) | (properties[:, 2] > properties[:, 0]) | (properties[:, 3] < 0)
        | (properties[:, 4] < 0) | (properties[:, 4] > 1) | (properties[:, 5] < 0)
        | (properties[:, 5] > properties[:, 2]) | (properties[:, 6] <= 0) | (duration <= 0))
    invalid |= xp.any((cells[:, :, 2] <= 0) | (cells[:, :, 0] < 0)
                       | (cells[:, :, 0] > 1000*cells[:, :, 2]*properties[:, 0, None]), axis=1)
    # The explicit native adapter supports only a bedrock at the full column
    # bottom, unlike the separate arbitrary-layer NumPy drainage component.
    depth = xp.sum(cells[:, :, 2], axis=1)
    invalid |= xp.abs(depth-parameters[:, 4]) > 16*xp.finfo(cells.dtype).eps*xp.maximum(depth, 1)
    if bool(xp.any(invalid)):
        raise ValueError('Illegal stocks/material/duration or bedrock not at the full four-layer column bottom')


def _phase_from_stocks(cells, parameters, option, xp, backend):
    zero = xp.zeros(4, cells.dtype)
    placeholders = xp.stack((zero, zero, cells[:, 2], zero, cells[:, 0], cells[:, 1]), axis=1)
    # Uses the unchanged I/K phase inversion, including typed NumPy32 and the
    # original device convergence check. No prescribed temperature or ice.
    return main._phase(placeholders, parameters, option, xp, backend)


def _budget(before, after, mass, heat, xp):
    mr = xp.sum((after[:, 4]-before[:, 4])+mass)
    hr = xp.sum((after[:, 5]-before[:, 5])+heat)
    mb = 64*xp.finfo(before.dtype).eps*xp.maximum(xp.sum(xp.abs(before[:, 4])+xp.abs(after[:, 4])+xp.abs(mass)), 1)
    hb = 64*xp.finfo(before.dtype).eps*xp.maximum(xp.sum(xp.abs(before[:, 5])+xp.abs(after[:, 5])+xp.abs(heat)), 1)
    if bool(xp.abs(mr) > mb) or bool(xp.abs(hr) > hb):
        raise RuntimeError('Post-Richards drainage combined hard M/H budget failed')
    return dict(water_residual_kg_m2=mr, energy_residual_j_m2=hr, water_bound_kg_m2=mb, energy_bound_j_m2=hb)


def _not_called(state, front, bottom, kind, backend, xp):
    # Explicitly absent geometry: there was no trial, no phase loop and no
    # completed-duration credit. Caller duration remains in the outer result.
    zero = xp.zeros(4, state.dtype)
    ledger = dict(layer_mass_kg_m2=zero, layer_enthalpy_j_m2=zero.copy(),
        drained_kg_m2=xp.asarray(0., state.dtype), drained_enthalpy_j_m2=xp.asarray(0., state.dtype),
        initial_front_m=float(front), migrated_front_m=xp.asarray(front, state.dtype), band_bottom_m=float(bottom),
        elapsed_seconds=0., potential_requested_kg_m2=xp.asarray(0., state.dtype),
        unavailable_liquid_kg_m2=xp.asarray(0., state.dtype), band_exhaustion_kg_m2=xp.asarray(0., state.dtype),
        accepted_substeps=0, rejected_substeps=0, maximum_accepted_error_ratio=0.,
        quantized_requested_duration_seconds=0., clock_residual_seconds=0., kind=kind, backend=backend,
        precision=str(state.dtype), perched_evolution=kind == 'perched', production_registered=False,
        local_error_basis='actual outlet increments plus front representability' if state.dtype == xp.float32 else 'original PB-c stock differences',
        float32_physical_accuracy_validated=False)
    ledger.update(_budget(state, state, zero, zero, xp))
    return ledger


def _numeric_ledger(ledger, invoked, kind, backend, dtype, xp):
    # Preserve every old adaptive field; schema additions must fail here rather
    # than disappear in an adapter. Physical arrays keep the backend precision.
    expected = set(_PHYSICAL_FIELDS+_HOST_FLOAT_FIELDS+_HOST_INT_FIELDS+_BOOL_FIELDS+_LABEL_FIELDS)
    if set(ledger) != expected:
        raise RuntimeError('Adaptive drainage ledger schema changed; audit adapter explicitly')
    result = {k: xp.asarray(ledger[k]) for k in _PHYSICAL_FIELDS}
    if any(value.dtype != dtype for value in result.values()):
        raise RuntimeError('Adaptive physical ledger changed precision')
    # Host loop metadata already are Python float/int. Keep their original
    # float64/int64 values, separate from scientific float32 arrays on devices.
    result.update({k: np.asarray(ledger[k], dtype=np.float64) for k in _HOST_FLOAT_FIELDS})
    result.update({k: np.asarray(ledger[k], dtype=np.int64) for k in _HOST_INT_FIELDS})
    result.update({k: np.asarray(ledger[k], dtype=np.bool_) for k in _BOOL_FIELDS})
    if (ledger['kind'] != kind or ledger['backend'] != backend or ledger['precision'] != str(dtype)
            or ledger['local_error_basis'] != ('actual outlet increments plus front representability'
                if dtype == xp.float32 else 'original PB-c stock differences')):
        raise RuntimeError('Unexpected adaptive audit labels')
    result.update(invoked=np.asarray(invoked, np.bool_), kind_code=np.asarray(kind == 'perched', np.int32),
        backend_code=np.asarray(('numpy', 'jax', 'cuda').index(backend), np.int32),
        precision_bits=np.asarray(dtype.itemsize*8, np.int32),
        local_error_outlet_basis=np.asarray(dtype == xp.float32, np.bool_))
    return result


def _stack_ledger(rows, xp):
    return {key: (xp.stack([row[key] for row in rows]) if key in _PHYSICAL_FIELDS
                  else np.stack([row[key] for row in rows])) for key in rows[0]}


def run_clm_drainage(soil_cells, soil_parameters, phase_options, dt, configuration, *, backend='numpy'):
    """Return actual two-band exports and final phase from post-Richards W/H.

    No Richards call, full-column dispatch, tile step, BGC step or legacy
    runoff reclassification occurs here. Missing bands have invoked=False.
    """
    _require_inputs(soil_cells, soil_parameters, phase_options, dt, configuration, backend)
    xp, _ = main._backend(backend)
    cells, properties, options, duration = (xp.asarray(v) for v in (soil_cells, soil_parameters, phase_options, dt))
    parameters = _encode_parameters(properties, configuration, xp)
    _validate_values(cells, properties, options, duration, parameters, xp)
    rows = []; perched_rows = []; main_rows = []
    for i in range(len(cells)):
        p = parameters[i]; option = int(options[i]); seconds = float(duration[i])
        initial = _phase_from_stocks(cells[i], p, option, xp, backend)
        before = diagnose_clm_drainage(initial[None], p[None], backend=backend)[0]
        perched_active = bool(before[4])
        if perched_active:
            current, _, lp = perched.advance_perched_band(initial, p, option, seconds,
                float(before[2]), float(before[1]), configuration.integration, backend)
        else:
            current = initial
            lp = _not_called(initial, before[2], before[1], 'perched', backend, xp)
        after_perched = diagnose_clm_drainage(current[None], p[None], backend=backend)[0]
        main_active = bool(after_perched[0] < p[4])
        if main_active:
            final, _, lm = main.advance_main_band(current, p, option, seconds,
                float(after_perched[0]), float(p[4]), configuration.integration, backend)
        else:
            final = current
            lm = _not_called(current, after_perched[0], p[4], 'saturated', backend, xp)
        after = diagnose_clm_drainage(final[None], p[None], backend=backend)[0]
        mass = lp['layer_mass_kg_m2']+lm['layer_mass_kg_m2']
        heat = lp['layer_enthalpy_j_m2']+lm['layer_enthalpy_j_m2']
        budget = _budget(initial, final, mass, heat, xp)
        if not bool(xp.all(xp.isfinite(final))):
            raise RuntimeError('Nonfinite final post-Richards drainage state')
        rows.append(dict(cells=xp.stack((final[:, 4], final[:, 5], final[:, 2]), axis=1),
            temperature_k=final[:, 3], liquid_kg_m2=final[:, 0], ice_kg_m2=final[:, 1],
            encoded_parameters=p, phase_option=options[i], duration_seconds=duration[i],
            phase_cells_before=initial, phase_cells_after_perched=current, phase_cells_final=final,
            diagnosis_before=before, diagnosis_after_perched=after_perched, diagnosis_after=after,
            layer_mass_kg_m2=mass, layer_enthalpy_j_m2=heat,
            drained_kg_m2=xp.sum(mass), drained_enthalpy_j_m2=xp.sum(heat), **budget))
        perched_rows.append(_numeric_ledger(lp, perched_active, 'perched', backend, cells.dtype, xp))
        main_rows.append(_numeric_ledger(lm, main_active, 'saturated', backend, cells.dtype, xp))
    output = {key: xp.stack([row[key] for row in rows]) for key in rows[0]}
    output['perched'] = _stack_ledger(perched_rows, xp)
    output['saturated'] = _stack_ledger(main_rows, xp)
    return output

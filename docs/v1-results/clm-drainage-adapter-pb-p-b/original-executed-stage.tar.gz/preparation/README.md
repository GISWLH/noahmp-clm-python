# PB-p-b：纯诊断与 Richards 后排水适配候选

状态是 prepared-only。本机只做标准库 source/tar/hash/AST 检查，不导入 NumPy，不执行模型，不提交 PBS，不编译 CUDA。父源 PB-o594 已有 1678 CPU guard/parity 信用；本候选新增适配器不继承数值通过。生产、NM、PB-l/n/o 和原 1665 金样都不变。

新增两个包内模块：`gpu/clm_drainage_diagnosis.py` 与 `gpu/clm_drainage_column.py`。父源唯一两个修改是 `gpu/clm_drainage_primitives.py` 的 CUDA kernel 名单增加一个名字，以及其 CUDA 源中原诊断代码移入共享 helper、新增仅诊断 kernel。原诊断算式/顺序和 trial 正文可通过 `DIFF_PROOF.json` 的逆变换恢复；CUDA 文本是新身份，未编译、未执行。PB-o 的 adaptive 两模块、typed32 phase、输入 guard、perched primitive，以及全部 PB-l586 文件保持原字节。

## 接口与真实作用范围

`diagnose_clm_drainage(cells6, parameters12, backend=...)` 输入 `[B,4,6]` 的 liquid/ice/dz/T/W/H 与 `[B,12]` 原 F 参数，返回原 `[B,29]` 全诊断。NumPy/JAX 直接调用原 `_diagnosis`；CUDA 直接调用新纯诊断 kernel。它不构造试步时间、不调用 trial、不求相平衡。显式相输入沿原 F 的值域/库存一致性合同，不能当成该接口已经独立证明 T/H 相平衡。

`run_clm_drainage(soil_cells, soil_parameters, phase_options, dt, configuration, backend=...)` 只接受实际 post-Richards 的 `[B,4,3]` W/H/dz、原 `[B,7]` porosity/B/field/Ksat/quartz/wilt/suction、native int32 `[B]` option 1/2、同浮点 dtype `[B]` 秒。配置必须是 `CLMVerticalHydrology`，其 transport 不在本函数执行。Python 配置标量在显式边界编码成十二参并返回；状态、七土参、dt 不重编码。全部原 metadata dtype 检查先于 backend 转换、相逆算或 kernel；CUDA raw64、混精度及非法 dtype 早拒绝，显式应用 pack32 仍有效。

仅四层，并显式要求 bedrock 等于全柱底。原 NumPy 任意层 `physics.clm_hydrology` 与 `clm_saturated_drainage` 不受影响。当前按实际 input dtype 的 16eps 几何表示容差比较总深与编码 bedrock，不截层、不改深度。输入 W 不得超原液体当量孔隙库；所有七参数保留并检查值域，drainage/phase 真正使用 p0/p1/p3/p6。quartz/field/wilt 在本纯出口没有额外作用，不能由这些参数已传入宣称热传导/根系过程已连接。

实际顺序为原相逆算 → 纯初诊断 → 有滞水几何则 K 完整 adaptive → 从真实新 W/H/T/ice 重新诊断 → 有主带则 I 完整 adaptive → 真实末相与纯末诊断。每个已启用带保留其连续迁移 front；子步不重置。无带跳过积分，`invoked=False`、实际 elapsed/call counters 为零，未调用 requested-clock 也为零；外层原 `duration_seconds` 保留。零坡但有几何的带仍经过真实原积分，可完成零流量 clock，不能与 absent band 混称。

返回完整 numeric tree：末 W/H/dz/T/liquid/ice，原 option/dt、编码十二参，初/滞水后/末三份 phase cells 和诊断，两路逐层 M/H、所有原限制量、迁移 front、原硬预算、完整计数/clock/error ratio。原 ledger 字段集合严格校验；字符串 kind/precision/error basis 转成数值枚举（kind 0 main/1 perched，precision 32/64，error basis bool）。backend 字符串仍核对实际 dispatch，但不放入要求跨后端相同的 numeric tree；身份由独立 observer/receipt 记录。物理数组维持 backend/dtype；原 Python 控制浮点与计数以单独 NumPy float64/int64 metadata 保留，设备后续比较亦须包括，不能把它们当 scientific arrays 转32。相逆算仍使用原模块抛错/收敛语义，本适配器不虚构未暴露的 inverse iterations 或原始标志。

两路出口相加一次形成合计；独立 64eps M/H 原操作界不放松。无 WA、无补负水、无 Richards 重跑、无事后删除 legacy 出口。完整柱 dispatch/finish、tile、末 surface T、BGC 与 16/19/20/23 ABI pre-cast guard **尚未连接**，当前不能公开作为完整 native 新水文。

## CPU 待审验证

见 `CPU_REFERENCE_PLAN.md` 与 `test_adapter_pbp.py`：8 个物理 profile × NumPy64/显式 NumPy32，共 16 个参数化案；另 8 项实际原金样/真实 post-Richards/接口测试，静态预计 24 pytest nodes（未 collect、未执行）。NumPy32 输入是明确一次编码，参考从同 W/H/dz、七土参、dt 和编码配置 widen 到原 NumPy64，绝不从名义温度重造参考 W/H。真实相差和编码差会完整报出。

原 1665 的 20 个 frozen input32 仅重放纯诊断和单 trial，逐字段 dtype/shape/bytes 比原 gold；不重跑 17 个完整金样，也不给 JAX/CUDA 信用。新增 adapter 的科学比较用原 `physics.clm_saturated_drainage.drain_saturated_soil`，并有一例与原 `physics.clm_hydrology.advance_clm_hydrology` 的实际零底通量 Richards 后态配对。参考与原 G/I/K 有共同物理基础，属于独立 API/实现闭包与接线验证，不是新官方 CTSM 耦合真值。

NumPy/P0 门沿已有 PO：质量/水/液冰 `max(.001 kg/m²,10%)`；逐层主携焓 `max(.05 J/m²,10%)`、滞水携焓 `max(.5 J/m²,10%)`；末 H `max(.5 J/m²,10%)`；T 既有 `.001 K` 对照诊断；非近零 front/water-table `max(1e-6 m,10%)`，不增加 1mm 门。T 档是原 PO 局部对照尺度，不是用户全部气候态统一验收新门。几何/flag 精确，所有绝对/相对实际数字和失败原件都保存；硬 M/H 是独立必须条件。未来 CUDA32/JAX32 同精度所有连续字段仍 1e-6、离散精确，目前未执行。

## PB-p-b 提交前修订

原 PB-p source4efbd7d6 与15控 d74f6c35 均作为未执行原件保留。此版只在新 adapter 增加 mr/hr/mb/hb 的显式有限性拒绝（原公式/64eps不变），并将 backend_code 移出可比较数值树；测试另加 NaN/±Inf 残差及溢出 bound 的负控。kind/precision/clock/counters/errorratio 仍完整比较。四项 xp.sum 在不同后端近零残差上的同精度风险仍待实测，不先修算序、不放宽1e−6。原CUDA抽helper相对PB-o的来源继续由parent-candidate.patch/PARENT_DIFF_PROOF保存，新candidate.patch只显示两项收窄。

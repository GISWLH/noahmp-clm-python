# PB-p-b 最小 CPU 验证计划（未经执行）

独立 EHPC compute002 / PBS / TMPDIR，预期 1 CPU、2 GiB、10 分钟。先 root 审核 source/controls；本准备没有 launcher、qsub 或已执行 receipt。后续 wrapper 按已经成功 1678 的单层 stage/source/gold 摘要流程，固定 source596、父 PB-o594 SHA、controls 和原 1665 archive SHA，全部 before/after 核验；不包重复全源，不修改原 1665 原件。

计划命令（仅说明，尚无执行包装）：

```
PBP_GOLD_ARCHIVE=<exact sealed 1665 archive>
PBP_RESULTS=$TMPDIR/results
PYTHONPATH=<candidate596/src>:<existing test-deps>
<existing closeout Python> -m pytest -q -s test_adapter_pbp.py --junitxml=<new result>/pytest.xml
```

共 9 个 test functions，静态参数展开预期 24 nodes；收集/实际完成数以后据原 XML 与 stdout 认定。

1. 八物理 profile 各 float64/明确输入32：暖饱和主流、冻主带、普通 Ks 微滞水、既有 Ks=10 机制压力滞水、零坡、完整 option2 滞水、非均匀 dz、上下分隔的双带出口。双带案为 theta=[.43,.4,.2,.44]、T=[280,270,280,280]、dz=.5：浅冻层滞水与更深饱和带同时存在；Ks=10 仅压力机制案，不作为常见土壤科学代表，不调参拟合。全64/32参考从同编码输入建立，不给仅 warm/no-flow 案替代 active 主/滞水信用。保存实际 `invoked`、真实总/逐层量、计数；指定暖/非均匀/双带 main 和微/压力/option2/双带 perched 均须实际正出口，否则测试失败，不按名称算覆盖。另有全干无带边界案。
2. 固定原金样 20× input32：原 npz/meta/SHA、每数组 dtype/shape/C-order SHA 核验；纯诊断直接等于原 29 字段，原 trial 全 26 或 29 字段逐值 bytes exact。仅这二类已有结果，未假装新 adapter 是原固定 front 的 gold。所有 20 案保留，包括内部床岩1.5的原 primitive 案；adapter 另拒该配置，不篡改原金样。
3. 原 `advance_clm_hydrology` 独立连接对照：给暖土真实水梯度；原 Richards 生成实际 post-state，并与原整体接口返回的 transported 库逐字节核验；adapter只读取这个 post-state。原整体接口再执行一次自己的 Richards 是独立 reference，不是 adapter 内双 transport。仅此局部调用不是完整雪/冠层/BGC 列。
4. 全干无带明确不调用任何 full loop、clock零；纯诊断在 trial mock fail 下仍计算真实原诊断。这些 mock 只证明调用边界，不提供科学流量证据。
5. CUDA raw64/mixed/float16/int/bool/list、phase int64 和非法 option3、3/6层、床岩1.5都在允许的相/后端边界前拒绝；仅 metadata 显式 pack32 合法。没有 CUDA import/kernel 调用。

每个科学案输出完整输入/实际 numeric tree NPZ + dtype/shape/C-order SHA、原完整参考 ledger JSON、比较 JSON/stdout。保存每层 W/H/T/liquid/ice、两路 M/H/迁移front、初/滞水后/末诊断、实际相/全部限制量与原预算。近零相对比用 null；不把零参考量变成相对失败。独立 `math.fsum` 用确实存储的数组核 M/H，原64eps界原样；另外保留参考自己的硬预算。失败数据在 assert 前保存；不把其他成功案平均掉失败。

当前 source/controls 准备仅静态 AST/hash/F821。实际收敛/激活覆盖、正负控执行、原金样字节比较、数值守恒与物理10%、CUDA编译/JAX设备/完整 native 路由全都待测。若实际错，应先保留 failed receipt/log/data，不静默改源重投。

6. 新增一个有限性预算负控方法：NaN/正负Inf分别注入水/热残差和出口，另用有限1e308库存构造有限零残差但溢出的bound；均必须在原64eps数值比较前拒绝。只测试预算入口，不作物理流量证据。原backend标签从返回可比树移至实际dispatch的外层observer/receipt，kind/precision及所有控制计数不删。

"""CPU pytest observer only: call counters and module identity, no equations."""
from pathlib import Path
import functools
import hashlib
import importlib
import inspect
import json
import os
import sys

ROOT = Path(os.environ['PBP_RUN_ROOT'])
MODE = os.environ['PBP_OBSERVER_MODE']
COUNTS = {}
MODULES = {}
NODES = []


def save(name, value):
    (ROOT/(MODE+'-'+name)).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def persist():
    save('observation.json', dict(calls=COUNTS, module_paths=MODULES,
        cupy_imported='cupy' in sys.modules, jax_imported='jax' in sys.modules,
        scope='Named API attempts/returns, not all NumPy operations; no equations or outputs changed.'))


def wrapped(label, function, *, checkpoint=False):
    COUNTS[label] = dict(attempted=0, returned=0, raised=0, requested_backend_counts={}, returned_backend_counts={})
    signature = inspect.signature(function)
    @functools.wraps(function)
    def call(*args, **kwargs):
        COUNTS[label]['attempted'] += 1
        bound = signature.bind(*args, **kwargs); bound.apply_defaults()
        requested = bound.arguments.get('backend', 'numpy')
        requested_counts = COUNTS[label]['requested_backend_counts']
        requested_counts[requested] = requested_counts.get(requested, 0)+1
        try:
            result = function(*args, **kwargs)
        except BaseException:
            COUNTS[label]['raised'] += 1
            persist()
            raise
        COUNTS[label]['returned'] += 1
        returned_counts = COUNTS[label]['returned_backend_counts']
        returned_counts[requested] = returned_counts.get(requested, 0)+1
        if checkpoint: persist()
        return result
    return call


def pytest_configure(config):
    assert os.name != 'nt' and os.environ.get('PBS_JOBID')
    source = (ROOT/'source').resolve()
    index = json.loads((source/'SOURCE_SHA256.json').read_bytes())
    names = ('gpu.clm_drainage_column', 'gpu.clm_drainage_diagnosis', 'gpu.clm_drainage_primitives',
             'gpu.clm_perched_drainage_primitives', 'gpu.clm_drainage_adaptive', 'gpu.clm_perched_drainage_adaptive',
             'physics.clm_saturated_drainage', 'physics.clm_hydrology', 'physics.richards', 'physics.soil_enthalpy')
    modules = {}
    for name in names:
        module = importlib.import_module('noahmp_clm.'+name)
        path = Path(module.__file__).resolve()
        relative = path.relative_to(source).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == index[relative]
        MODULES[name] = dict(path=str(path), source_member=relative, sha256=digest)
        modules[name] = module
    pairs = (
        ('adapter', 'gpu.clm_drainage_column', 'run_clm_drainage'),
        ('pure_diagnosis', 'gpu.clm_drainage_diagnosis', 'diagnose_clm_drainage'),
        ('main_trial', 'gpu.clm_drainage_primitives', 'run_numpy'),
        ('perched_trial', 'gpu.clm_perched_drainage_primitives', 'run_numpy_perched'),
        ('main_full', 'gpu.clm_drainage_adaptive', 'advance_main_band'),
        ('perched_full', 'gpu.clm_perched_drainage_adaptive', 'advance_perched_band'),
        ('reference_drainage', 'physics.clm_saturated_drainage', 'drain_saturated_soil'),
        ('reference_combined', 'physics.clm_hydrology', 'advance_clm_hydrology'),
        ('reference_richards', 'physics.richards', 'redistribute_soil_enthalpy'))
    for label, module_name, attribute in pairs:
        module = modules[module_name]
        wrapper = wrapped(label, getattr(module, attribute), checkpoint=label in ('adapter', 'reference_combined', 'reference_drainage'))
        setattr(module, attribute, wrapper)
        # Preserve existing aliases, so the same real function is counted once.
        if label == 'pure_diagnosis': modules['gpu.clm_drainage_column'].diagnose_clm_drainage = wrapper
        if label == 'reference_drainage': modules['physics.clm_hydrology'].drain_saturated_soil = wrapper
        if label == 'reference_richards': modules['physics.clm_hydrology'].redistribute_soil_enthalpy = wrapper
    phase = wrapped('adaptive_phase', modules['gpu.clm_drainage_adaptive']._phase)
    modules['gpu.clm_drainage_adaptive']._phase = phase
    modules['gpu.clm_perched_drainage_adaptive']._phase = phase
    persist()


def pytest_collection_finish(session):
    NODES.extend(item.nodeid for item in session.items)
    save('nodes.json', NODES)


def pytest_runtest_logreport(report):
    if report.when == 'call': persist()


def pytest_sessionfinish(session, exitstatus):
    persist()
    save('session.json', dict(exitstatus=int(exitstatus), collected=len(session.items),
        test_failures=int(session.testsfailed), collectonly=bool(session.config.option.collectonly)))

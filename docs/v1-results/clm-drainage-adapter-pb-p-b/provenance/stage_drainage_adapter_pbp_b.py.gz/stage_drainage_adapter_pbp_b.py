"""Prepared-only stdlib stage, no remote operations or scientific imports."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
PREP = ROOT/'clm-drainage-adapter-pb-p-b-preparation'
EXEC = ROOT/'clm-drainage-adapter-pb-p-b-execution'
sha = lambda b: hashlib.sha256(b).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False)+'\n').encode()


def save(path, value): path.write_bytes(json_bytes(value))


def read_archive(path, digest):
    assert sha(path.read_bytes()) == digest
    with tarfile.open(path) as t:
        items = t.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and '\\' not in m.name for m in items)
        assert len({m.name for m in items}) == len(items)
        return {m.name: t.extractfile(m).read() for m in items}


def main():
    assert sha((PREP/'CONTROLS_SHA256.json').read_bytes()) == 'd6df8c230b91f7b960c27a7304ce78b4dcc2ab51637f02e24f9f4fe49796422b'
    prep_index = json.loads((PREP/'CONTROLS_SHA256.json').read_bytes())
    assert len(prep_index) == 19 and all(sha((PREP/n).read_bytes()) == h for n, h in prep_index.items())
    binding = json.loads((PREP/'BINDINGS.json').read_bytes())
    source = ROOT/binding['source_archive']
    source_raw = read_archive(source, binding['source_archive_sha256'])
    source_index = json.loads(source_raw['SOURCE_SHA256.json'])
    assert len(source_index) == 596 and len(source_raw) == 597
    assert sha(source_raw['SOURCE_SHA256.json']) == binding['source_manifest_sha256']
    assert all(sha(source_raw[k]) == h for k, h in source_index.items())
    base_bytes = (ROOT/'clm-drainage-package-pb-n-preparation/BASE_PBL_SOURCE_SHA256.json').read_bytes()
    base = json.loads(base_bytes)
    assert len(base) == 586 and all(source_index[k] == h for k, h in base.items())
    parent_archive = ROOT/'clm-drainage-guard-pb-o-evidence.tar.gz'
    parent = read_archive(parent_archive, 'e53c2cb8d5b79059e9784b3a33b9f79e48096b9957a32d272de1460d4a84ced2')
    parent_index = json.loads(parent['artifact-inventory.json'])
    assert set(parent_index) == set(parent)-{'artifact-inventory.json'}
    assert all(set(h) == {'sha256', 'bytes'} and sha(parent[n]) == h['sha256'] and len(parent[n]) == h['bytes'] for n, h in parent_index.items())
    diff = []
    for name in ('dispatch_component_pb.py', 'component_pb.pbs'):
        old = parent['execution/'+name].decode()
        new = old.replace('clm-drainage-guard-pb-o', 'clm-drainage-adapter-pb-p-b').replace('drainage-guard-pbo', 'drainage-adapter-pbp-b')
        new = new.replace('dispatch_drainage_guard_pbo.py', 'dispatch_drainage_adapter_pbp_b.py')
        new = new.replace('PB-o12 CPU guard tests plus actual1673 exact32 parity controls, source594. No64/JAX/CUDA/coupled/site/annual execution.',
            'PB-p isolated CPU diagnosis/adapter versus original physics and20gold diagnosis/trial, source596. Expected24nodes await actual collect. NoGPU/full-column/site/annual execution.')
        (EXEC/name).write_text(new, encoding='utf8', newline='\n')
        diff.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='actual1678/execution/'+name, tofile='preparedPB-p/execution/'+name))
    diff.extend(difflib.unified_diff(parent['execution/run_component_pb.py'].decode().splitlines(True),
        (EXEC/'run_component_pb.py').read_text().splitlines(True), fromfile='actual1678/execution/run_component_pb.py',
        tofile='preparedPB-p/execution/run_component_pb.py'))
    (EXEC/'wrapper.patch').write_text(''.join(diff), encoding='utf8', newline='\n')
    official_path = ROOT/'clm-drainage-common-thermal-pb-j-evidence.tar.gz'
    official = read_archive(official_path, '1360fb8305ddf55fd18a941416a0dbec8da112735ddb3fcef5d5b7dc28077b16')
    official_index = json.loads(official['artifact-inventory.json'])
    assert len(official) == 58 and set(official_index) == set(official)-{'artifact-inventory.json'}
    assert all(set(h) == {'sha256', 'bytes'} and sha(official[n]) == h['sha256'] and len(official[n]) == h['bytes'] for n, h in official_index.items())
    closed = json.loads(official['closed-run.json'])
    assert closed['pbs_job'] == '1647.manager' and closed['actual_state'] == 'F'
    assert closed['actual_exit'] == closed['Stageout_status'] == 0
    original_test = (PREP/'test_adapter_pbp.py').read_bytes()
    tree = ast.parse(original_test)
    reference_function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'checked_reference')
    names = [ast.unparse(n.func) for n in ast.walk(reference_function) if isinstance(n, ast.Call)]
    assert names.count('drain_saturated_soil') == names.count('adapter.run_clm_drainage') == 1
    imports = [n for n in tree.body if isinstance(n, ast.ImportFrom)]
    assert any(n.module == 'noahmp_clm.physics.clm_saturated_drainage' and any(a.name == 'drain_saturated_soil' for a in n.names) for n in imports)
    assert any(n.module == 'noahmp_clm.physics.clm_hydrology' and any(a.name == 'advance_clm_hydrology' for a in n.names) for n in imports)
    reference_binding = dict(original_physics_sha256=binding['source_reference_exact'],
        original_reference_not_adapter_self_call=True,
        official_archive=official_path.name, official_archive_sha256=sha(official_path.read_bytes()), official_members=58,
        official_actual_closed=closed, official_shared_NM64_thermal_boundary=True,
        official_reference_scope='Historical pinned public hydrology plus shared NM64 thermal operator; not rerun, not direct oracle for the new profile matrix, not official full thermal/column truth.',
        official_reference_rerun=False, original_1mm_diagnostic_flag_preserved=True, original_front_1mm_passed=False,
        pbo_parent_archive_sha256=sha(parent_archive.read_bytes()), pbo_parent_actual_job='1678.manager',
        planned_actual_tests=0, expected_nodes_only=24)
    reference = {'REFERENCE_BINDINGS.json': json_bytes(reference_binding), 'BASE_PBL_SOURCE_SHA256.json': base_bytes,
        'parent1678-closed-run.json': parent['closed-run.json'],
        'official-package.json': (ROOT/'clm-drainage-common-thermal-pb-j-package.json').read_bytes()}
    reference['CONTROLS_SHA256.json'] = json_bytes({n: sha(b) for n, b in sorted(reference.items())})
    save(EXEC/'REFERENCE_PROOF.json', reference_binding)
    for path in EXEC.glob('*.py'): ast.parse(path.read_bytes())
    exec_index = {p.name: sha(p.read_bytes()) for p in sorted(EXEC.iterdir()) if p.is_file() and p.name != 'CONTROLS_SHA256.json'}
    save(EXEC/'CONTROLS_SHA256.json', exec_index)
    gold_binding = json.loads((PREP/'GOLD32_BINDINGS.json').read_bytes()); gold_path = ROOT/gold_binding['archive']
    gold = read_archive(gold_path, gold_binding['archive_sha256'])
    assert len(gold) == 345 and all(sha(gold[n]) == h for n, h in gold_binding['members'].items())
    raw = {'source.tar.gz': source.read_bytes(), 'gold.tar.gz': gold_path.read_bytes(), 'official-reference.tar.gz': official_path.read_bytes()}
    raw.update({'reference/'+n: b for n, b in reference.items()})
    for folder, label in ((PREP, 'preparation'), (EXEC, 'execution')):
        raw.update({label+'/'+p.relative_to(folder).as_posix(): p.read_bytes() for p in sorted(folder.rglob('*')) if p.is_file()})
    raw['stage-inventory.json'] = json_bytes({n: sha(b) for n, b in sorted(raw.items())})
    target = ROOT/'clm-drainage-adapter-pb-p-b-stage.tar.gz'
    with target.open('wb') as f, gzip.GzipFile(filename='', fileobj=f, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as t:
        for n, b in sorted(raw.items()):
            info = tarfile.TarInfo(n); info.size = len(b); t.addfile(info, io.BytesIO(b))
    report = dict(actual_static_exit=0, stage_sha256=sha(target.read_bytes()), stage_members=len(raw),
        preparation_controls=len(prep_index), preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        execution_controls=len(exec_index), execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()),
        source_files=596, source_archive_sha256=binding['source_archive_sha256'], source_manifest_sha256=binding['source_manifest_sha256'],
        gold_archive_sha256=gold_binding['archive_sha256'], historical_official_archive_sha256=sha(official_path.read_bytes()),
        expected_test_nodes_only=24, actual_collected_nodes=None, actual_executed_nodes=0,
        all_source_controls_and_archives_verified=True, original_physics_reference_direct_and_exact=True,
        source_preparation_originals_modified=False, numerical_executed=False, PBS_submitted=False, awaiting_review=True)
    save(ROOT/'clm-drainage-adapter-pb-p-b-stage-preparation.json', report)
    print(json.dumps(report))


if __name__ == '__main__': main()

"""Authorized one-shot deployment, no model execution on the local host."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
stage = ROOT/'clm-drainage-adapter-pb-p-b-stage.tar.gz'
digest = '166e8c3fde630e87e448a5d09a05480cecd3fcb4efff9b8df7036926b2fba997'
assert hashlib.sha256(stage.read_bytes()).hexdigest() == digest
record_path = ROOT/'clm-drainage-adapter-pb-p-b-deployment.json'
assert not record_path.exists(), 'Do not retry this deployment automatically'
record = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              stage_sha256=digest, actual_exit=None, commands=[], single_submit_authorized=True)


def save(): record_path.write_text(json.dumps(record, indent=2)+'\n', encoding='utf8')


save()
commands = [
    ['scp', '-O', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', str(stage),
     'ehpc:/tmp/noahmp-clm-drainage-adapter-pb-p-b-stage.tar.gz'],
    ['scp', '-O', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20',
     str(ROOT/'clm-drainage-adapter-pb-p-b-execution/dispatch_component_pb.py'),
     'ehpc:/tmp/dispatch_drainage_adapter_pbp_b.py'],
    ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'ehpc',
     '/home/zhangyq/venvs/noahmp-closeout/bin/python -B /tmp/dispatch_drainage_adapter_pbp_b.py '
     '--archive /tmp/noahmp-clm-drainage-adapter-pb-p-b-stage.tar.gz --sha256 '+digest]]
for i, command in enumerate(commands):
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    (ROOT/f'clm-drainage-adapter-pb-p-b-deploy-{i}.stdout.txt').write_text(result.stdout, encoding='utf8')
    (ROOT/f'clm-drainage-adapter-pb-p-b-deploy-{i}.stderr.txt').write_text(result.stderr, encoding='utf8')
    record['commands'].append(dict(command=command, returncode=result.returncode))
    save()
    if result.returncode:
        record['actual_exit'] = result.returncode; save(); raise SystemExit(result.returncode)
    if i == 2:
        record['dispatch'] = json.loads(result.stdout)
record.update(actual_exit=0, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
print(json.dumps(dict(actual_exit=0, stage_sha256=digest, pbs_job=record['dispatch']['pbs_job'])))
sys.exit(0)

"""Close actual failed1695 using only stdlib/raw bytes; never execute physics."""
from pathlib import Path
from collections import Counter
import hashlib
import io
import json
import re
import shlex
import subprocess
import tarfile
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
LABEL = 'clm-drainage-adapter-pb-p-b'
REMOTE = '/tmp/noahmp-' + LABEL
JOB = '1695.manager'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda o: (json.dumps(o, indent=2, allow_nan=False) + '\n').encode()
data = {}


def remote(command, label):
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20', 'ehpc', command],
                            capture_output=True, timeout=50)
    data['closure/' + label + '.stdout.txt'] = result.stdout
    data['closure/' + label + '.stderr.txt'] = result.stderr
    assert result.returncode == 0, (label, result.stderr)
    return result.stdout


def read_tar(blob):
    with tarfile.open(fileobj=io.BytesIO(blob)) as t:
        members = [m for m in t if m.isfile()]
        assert len(set(m.name.removeprefix('./') for m in members)) == len(members)
        assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        return {m.name.removeprefix('./'): t.extractfile(m).read() for m in members}


qstat = remote('qstat -xf ' + JOB, 'actual-qstat')
status = qstat.decode()
assert re.search(r'^\s*job_state = F\s*$', status, re.M)
assert re.search(r'^\s*Stageout_status = 0\s*$', status, re.M)
assert re.search(r'^\s*Exit_status = 1\s*$', status, re.M)
result_blob = (OUT / (LABEL + '-1695-original-result.tar.gz')).read_bytes()
result_sha = sha(result_blob)
assert remote('sha256sum ' + REMOTE + '/result.tar.gz', 'manager-result-hash').decode().split()[0] == result_sha
assert remote("ssh compute002 " + shlex.quote('sha256sum ' + REMOTE + '/result.tar.gz'), 'compute-result-hash').decode().split()[0] == result_sha
assert int(remote("ssh compute002 " + shlex.quote('cat ' + REMOTE + '/pbs-exit.txt'), 'compute-pbs-exit')) == 1
for name in ('dispatch.json', 'stage-inventory.json', 'qsub.stdout.txt', 'qsub.stderr.txt',
             'compute-extract.stdout.txt', 'compute-extract.stderr.txt', 'compute-file-hashes.txt'):
    data['scheduler/' + name] = remote('cat ' + shlex.quote(REMOTE + '/' + name), 'read-' + name)
data['scheduler/optional-pbs-output-status.txt'] = remote(
    'if test -f ' + REMOTE + '/pbs-output.log; then cat ' + REMOTE + '/pbs-output.log; else printf "Optional manager pbs-output.log absent; raw controller/stdout/XML retained in result.tar.gz\\n"; fi',
    'optional-pbs-output')
raw = read_tar(result_blob)
receipt = json.loads(raw['receipt.json'])
assert receipt['pbs_job'] == JOB and receipt['node'] == 'compute002'
assert not receipt['passed'] and receipt['numerical_parent_returncode'] == 1
assert receipt['collect_parent_returncode'] == 0 and receipt['actual_collected_nodes'] == 24
assert (receipt['actual_tests'], receipt['failures'], receipt['errors'], receipt['skipped']) == (24, 1, 0, 0)
assert int(raw['worker-exit.txt']) == 1
cases = list(ET.fromstring(raw['tests.xml']).iter('testcase'))
failed = [dict(node=c.attrib['classname'] + '::' + c.attrib['name'], message=c.find('failure').attrib['message'],
               traceback=c.find('failure').text) for c in cases if c.find('failure') is not None]
assert len(cases) == 24 and len(failed) == 1 and 'nonuniform_dz-float64' in failed[0]['node']
assert all(c.find('error') is None and c.find('skipped') is None for c in cases)
assert json.loads(raw['collect-nodes.json']) == json.loads(raw['run-nodes.json'])
before = json.loads(raw['immutable-before.json']); after = json.loads(raw['immutable-after.json'])
assert before == after and len(before) == 1033 and all(sha(raw[n]) == h for n, h in before.items())
source = json.loads(raw['source/SOURCE_SHA256.json'])
assert len(source) == 596 and all(sha(raw['source/' + n]) == h for n, h in source.items())
base = json.loads(raw['reference/BASE_PBL_SOURCE_SHA256.json'])
assert len(base) == 586 and all(source[n] == h for n, h in base.items())
binding = json.loads(raw['preparation/BINDINGS.json'])
assert sha(raw['source/SOURCE_SHA256.json']) == binding['source_manifest_sha256']
for folder, count in (('preparation', 19), ('execution', 7), ('reference', 4)):
    index = json.loads(raw[folder + '/CONTROLS_SHA256.json'])
    assert len(index) == count and all(sha(raw[folder + '/' + n]) == h for n, h in index.items())
    assert {n.removeprefix(folder + '/') for n in raw if n.startswith(folder + '/')} == set(index) | {'CONTROLS_SHA256.json'}
for folder, count in (('sealed-gold', 345), ('sealed-official-reference', 58)):
    members = {n.removeprefix(folder + '/'): b for n, b in raw.items() if n.startswith(folder + '/')}
    assert len(members) == count
    index = json.loads(members['artifact-inventory.json'])
    assert set(index) == set(members) - {'artifact-inventory.json'}
    for n, h in index.items():
        expected = h if isinstance(h, str) else h['sha256']
        assert sha(members[n]) == expected
        if isinstance(h, dict): assert len(members[n]) == h['bytes']
diagnostics = json.loads(raw['parsed-diagnostics.json'])
parsed = [json.loads(line.split('PB_P_DIAGNOSTIC ', 1)[1]) for line in raw['numerical.stdout.txt'].decode().splitlines() if 'PB_P_DIAGNOSTIC ' in line]
assert diagnostics == parsed and len(diagnostics) == 16
assert all(all(v['passed'] for v in row['comparisons'].values()) for row in diagnostics)
gold = json.loads(raw['parsed-gold-records.json'])
assert len(gold) == 1 and gold[0]['cases'] == 20
assert not receipt['cupy_imported'] and not receipt['jax_imported']
observation = json.loads(raw['run-observation.json'])
assert observation['calls'] == receipt['actual_calls']
rows = []
for record in diagnostics:
    name = record['case']; v = record['comparisons']
    saved = json.loads(raw['results/' + name + '.json'])
    assert saved['comparisons'] == v
    assert sha(raw['results/' + saved['file']]) == saved['sha256']
    rows.append(dict(case=name,
        saturated_mass_kg_m2=v['saturated.drained_kg_m2']['actual'],
        perched_mass_kg_m2=v['perched.drained_kg_m2']['actual'],
        largest_layer_mass_difference_kg_m2=max(x['maximum_absolute_difference'] for k, x in v.items() if 'layer_mass' in k),
        largest_layer_enthalpy_difference_j_m2=max(x['maximum_absolute_difference'] for k, x in v.items() if 'layer_enthalpy' in k),
        largest_temperature_difference_k=v['temperature']['maximum_absolute_difference'],
        independent_represented_stock_budget=v['hard_budget'], reference_hard_budget=v['reference_hard_budget']))
scope = ('Actual1695 F1/Stageout0:24 CPU tests,23passed/1failed nonuniform_dz-float64 at original main trial input-domain validation. '
         'Sixteen completed independent-reference records and20sealed-gold diagnosis/trials retained; no rerun or changed gate. '
         'No GPU/JAX/full-column/official-new-caller/annual/production credit. Failed profile has no final budget or comparison result.')
readout = dict(actual_job=JOB, actual_job_state='F', actual_exit=1, Stageout_status=0, passed=False,
    tests=24, passed_tests=23, failures=failed, receipt=receipt, successful_diagnostic_records=rows,
    original_gold_record=gold, immutable_prefix_counts=dict(Counter(n.split('/')[0] for n in before)),
    raw_result_sha256=result_sha, raw_result_members=len(raw), source_files=596, parent586_exact=True,
    CPU_only=True, GPU_executed=False, JAX_executed=False, scope=scope,
    failure_interpretation=dict(observed='Original reference returned before adapter exception; strict original primitive input-domain predicate raised during second half trial, before scientific comparison/combined hard-budget assertions.',
       unconfirmed_static_hypothesis='NumPy64 _phase uses SoilEnthalpyState.liquid volume-to-mass roundtrip without warm-state W canonicalization, unlike32/device; tiny negative derived ice is possible. Original XML truncates middle cells, so exact rejecting predicate/value is not established.',
       followup_not_executed='Capture complete failing trial input and individual original predicates with a transparent diagnostic wrapper on this single unchanged case; no guard relaxation or automatic retry.'))
data['original-result.tar.gz'] = result_blob
data['source-manifest.json'] = raw['source/SOURCE_SHA256.json']
data['run-readout.json'] = encode(readout)
data['failure-case.txt'] = failed[0]['traceback'].encode()
data['original-result-inventory.json'] = encode({n: dict(sha256=sha(b), bytes=len(b)) for n, b in raw.items()})
for n, b in raw.items():
    if '/' not in n or n.startswith(('preparation/', 'execution/', 'reference/')) or (n.startswith('results/') and n.endswith('.json')):
        data['actual/' + n] = b
stage_blob = (OUT / (LABEL + '-stage.tar.gz')).read_bytes()
assert sha(stage_blob) == '166e8c3fde630e87e448a5d09a05480cecd3fcb4efff9b8df7036926b2fba997'
stage = read_tar(stage_blob)
stage_index = json.loads(stage['stage-inventory.json'])
assert len(stage) == 37 and all(sha(stage[n]) == h for n, h in stage_index.items())
assert json.loads(data['scheduler/dispatch.json'])['stage_archive_sha256'] == sha(stage_blob)
assert sha(stage['source.tar.gz']) == binding['source_archive_sha256']
data['original-executed-stage.tar.gz'] = stage_blob
for name in (LABEL + '-readme-only-delta.json', LABEL + '-deployment.json',
             LABEL + '-stage-preparation.json', LABEL + '-execution-author-review.json',
             LABEL + '-stage-first-static-failure.json', LABEL + '-stage-first-static-failure.py',
             'clm-drainage-adapter-pb-p-static-independent-review-wo.json',
             'stage_drainage_adapter_pbp_b.py', 'deploy_drainage_adapter_pbp_b.py',
             'archive_drainage_adapter_pbp_b_first_attempt.py', LABEL + '-archive-first-failure.json'):
    data['provenance/' + name] = (OUT / name).read_bytes()
data['archive_drainage_adapter_pbp_b.py'] = Path(__file__).read_bytes()
data['closed-run.json'] = encode(dict(job=JOB, actual_job_state='F', actual_exit=1, Stageout_status=0,
    source_archive_sha256=binding['source_archive_sha256'], raw_result_sha256=result_sha,
    raw_result_members=len(raw), executed_stage_sha256=sha(stage_blob), no_retry=True))
data['artifact-inventory.json'] = encode({n: dict(sha256=sha(b), bytes=len(b)) for n, b in data.items()})
archive = OUT / (LABEL + '-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for name, blob in sorted(data.items()):
        item = tarfile.TarInfo(name); item.size = len(blob); t.addfile(item, io.BytesIO(blob))
assert read_tar(archive.read_bytes()) == data
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
    artifacts=len(data), actual_job=JOB, actual_job_state='F', actual_exit=1, Stageout_status=0,
    tests=24, passed_tests=23, failed_tests=1, raw_result_sha256=result_sha, scope=scope)
(OUT / (LABEL + '-package.json')).write_bytes(encode(package))
(OUT / (LABEL + '-readout.json')).write_bytes(encode(readout))
print(json.dumps(package), flush=True)

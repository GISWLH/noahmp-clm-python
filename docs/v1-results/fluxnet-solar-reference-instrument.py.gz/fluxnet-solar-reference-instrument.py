from pathlib import Path
import sys, json, hashlib
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path('outputs/v1/solar-reference-deps').resolve()))
sys.path.insert(0,str(Path('benchmarks').resolve()))
import pvlib
from fluxnet_solar import solar_geometry, diffuse_fraction_erbs

# Fixed BEFORE evaluating: approximate NOAA harmonics must stay within one
# degree of the independent NREL SPA geometric zenith; Erbs numeric agreement
# to published library implementation at 1e-12 fraction absolute tolerance.
zenith_tolerance_degrees=1.
erbs_tolerance=1e-12
cases=[]
for year in (2003,2004):
 for month in range(1,13):
  for lat,lon,offset in [(37.607432,101.332,8),(44.5934,123.5092,8),
                          (26.7414,115.0581,8),(42.4025,128.0958,8),(-35.,149.,10),(0.,0.,0)]:
   times=[datetime(year,month,15)+timedelta(minutes=15+30*k) for k in range(48)]
   utc=pd.DatetimeIndex([t-timedelta(hours=offset) for t in times]).tz_localize('UTC')
   reference=pvlib.solarposition.spa_python(utc,lat,lon)
   for t,stamp,z in zip(times,utc,reference.zenith):
    got=solar_geometry(t,lat,lon,offset)
    cases.append({'local_time':t.isoformat(),'latitude':lat,'longitude':lon,'utc_offset':offset,
                  'reference_zenith_degrees':float(z),'actual_zenith_degrees':got['zenith_degrees'],
                  'signed_difference_degrees':got['zenith_degrees']-float(z)})
errors=np.array([r['signed_difference_degrees'] for r in cases])
assert abs(errors).max()<=zenith_tolerance_degrees
diffuse_error=0.;energy_error=0.;orbital_error=0.;count=0
for doy in (1,60,172,266,365,366):
 stamp=datetime(2004,1,1,12)+timedelta(days=doy-1)
 extra=solar_geometry(stamp,0,0,0)['extraterrestrial_normal_wm2']
 ref_extra=float(pvlib.irradiance.get_extra_radiation(doy))
 orbital_error=max(orbital_error,abs(extra-ref_extra))
 for zenith in (0.,20.,60.,85.,86.9,87.1,90.,120.):
  mu=float(np.cos(np.deg2rad(zenith)))
  for ghi in (1.,20.,100.,400.,800.,1200.):
   actual=diffuse_fraction_erbs(ghi,mu,extra)
   reference=pvlib.irradiance.erbs(ghi,zenith,doy)
   diffuse_error=max(diffuse_error,abs(actual['diffuse_fraction']-float(reference['dhi'])/ghi))
   energy_error=max(energy_error,abs(actual['diffuse_horizontal_wm2']+actual['direct_horizontal_wm2']-ghi))
   count+=1
assert diffuse_error<=erbs_tolerance
result={'scope':'Station forcing geometry/decomposition check only; not observed diffuse radiation or land-model validation',
 'pvlib_version':pvlib.__version__,'solar_cases':len(cases),'erbs_cases':count,
 'predeclared_zenith_tolerance_degrees':zenith_tolerance_degrees,'predeclared_erbs_fraction_tolerance':erbs_tolerance,
 'zenith_max_absolute_degrees':float(abs(errors).max()),'zenith_signed_mean_degrees':float(errors.mean()),
 'zenith_rmse_degrees':float(np.sqrt(np.mean(errors**2))),
 'worst_geometry_case':cases[int(np.argmax(abs(errors)))],
 'erbs_fraction_max_absolute':diffuse_error,'shortwave_closure_max_wm2':energy_error,
 'extraterrestrial_normal_max_absolute_wm2':orbital_error,
 'sources':{'NOAA':'https://www.gml.noaa.gov/grad/solcalc/solareqns.PDF',
            'Erbs':'https://pvpmc.sandia.gov/modeling-guide/1-weather-design-inputs/irradiance-insolation/direct-normal-irradiance/piecewise-decomposition-models/',
            'independent_position':'https://pvlib-python.readthedocs.io/en/v0.13.1/reference/generated/pvlib.solarposition.spa_python.html'},
 'instrument_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'implementation_sha256':hashlib.sha256(Path('benchmarks/fluxnet_solar.py').read_bytes()).hexdigest(),
 'reference_source_sha256':{name:hashlib.sha256((Path(pvlib.__file__).parent/name).read_bytes()).hexdigest() for name in ['spa.py','solarposition.py','irradiance.py']}}
Path('docs/v1-results/fluxnet-solar-reference.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))

from pathlib import Path
import hashlib,json,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inventory={};proof=[];archive=b/'leaf-numpy-iw-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for label,exitcode,failures in [('it',1,1),('iu',0,0)]:
        r=b/('leaf-numpy-'+label);launch=json.loads((r/'dispatch.json').read_text());raw=subprocess.check_output(['qstat','-xf',launch['pbs_job']],text=True);assert re.search(r'^\s*job_state = F\s*$',raw,re.M) and re.search(r'^\s*Exit_status = '+str(exitcode)+r'\s*$',raw,re.M) and (r/'pbs-exit.txt').read_text().strip()==str(exitcode);(r/'actual-pbs-qstat.txt').write_text(raw);rec=json.loads((r/'receipt.json').read_text());assert rec['source_unchanged'] and rec['counts']==dict(tests=86,failures=failures,errors=0,skipped=0) and rec['pytest_returncode']==exitcode
        plan=json.loads((r/'plan.json').read_text());source=b/plan['archive'];assert sha(source)==plan['archive_sha256'];proof.append(dict(stage=label,pbs_job=launch['pbs_job'],actual_exit=exitcode,counts=rec['counts'],receipt_sha256=sha(r/'receipt.json')))
        for p in [*sorted(r.rglob('*')),source,b/('dispatch_leaf_numpy_'+label+'.py')]:
            if not p.is_file():continue
            assert not p.is_symlink();name=label+'/'+(p.relative_to(r).as_posix() if p.is_relative_to(r) else p.name);assert name not in inventory;inventory[name]=sha(p);tf.add(p,arcname=name,recursive=False)
    inventory[Path(__file__).name]=sha(Path(__file__));tf.add(Path(__file__),arcname=Path(__file__).name,recursive=False)
with tarfile.open(archive) as tf:
    assert len(tf.getmembers())==len(inventory)
    for member in tf:assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==inventory[member.name]
d=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,artifacts=len(inventory),proof=proof,scope='NumPyfirst IT1178 actualF1 preserved: onlynewtest humidityiterate pairing error, alloriginal675/540 references0exceed. IU1179 actualF0 same86nodes/sameproduction andindependentoracle, correctedactualRHrecovery test withoriginalrtol/atol. No GPU/fullcanonical/year/observational acceptance. Bothfullfrozensourcearchives andallactualcontrols/log/XML/NPZ retained.');(b/'leaf-numpy-iw-package.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

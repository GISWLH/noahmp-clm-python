from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'leaf-numpy-it';plan=json.loads((r/'plan.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=Path(os.environ['TMPDIR'])/'source';s.mkdir();archive=b/plan['archive'];assert sha(archive)==plan['archive_sha256']=='350f095783f99836a9a956811ca4c3dd893080341999a1a46c5bca291cb04b77'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==581 and sha(s/'SOURCE_SHA256.json')==plan['source_manifest_sha256']=='5c4e4b6d11b710caf5324c9e339c0fcb14d60bc5dc344482359cf8c9c17b501b' and all(sha(s/n)==h for n,h in m.items())
env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
start=time.monotonic()
with (r/'collection.log').open('x') as log:collect=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q',*plan['targets']],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
nodes=[line.strip() for line in (r/'collection.log').read_text().splitlines() if line.startswith('tests/') and '::' in line]
assert collect==0 and len(nodes)==len(set(nodes)) and len(nodes)>=8
with (r/'pytest.log').open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q',*plan['targets'],'--junitxml='+str(r/'junit.xml')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
xml=ET.parse(r/'junit.xml').getroot();cases=list(xml.iter('testcase'));counts=dict(tests=len(cases),failures=sum(len(c.findall('failure')) for c in cases),errors=sum(len(c.findall('error')) for c in cases),skipped=sum(len(c.findall('skipped')) for c in cases))
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src')]
from noahmp_clm.physics.photosynthesis import ball_berry_conductance,leaf_gas_exchange
fixture=json.loads((s/'tests/fixtures/leaf_clm5_water_stress.json').read_text());assert fixture['origin_archive_sha256']==plan['reference_archive_sha256']
rows=fixture['ball_berry'];expected=np.asarray([float(q['reference_decimal']) for q in rows]);actual=ball_berry_conductance(*[np.asarray([q[k] for q in rows]) for k in ['net','cs','rh','gb']],water_stress=np.asarray([q['beta'] for q in rows]));assert len(rows)==675
near=abs(expected)<=1e-4;difference=abs(actual-expected);bb=dict(cases=675,maximum_absolute=float(difference.max()),maximum_non_nearzero_relative=float(np.max(np.divide(difference,abs(expected),out=np.zeros_like(expected),where=~near))),exceedances=int(np.count_nonzero(difference>np.where(near,1e-6,.1*abs(expected)))))
np.savez_compressed(r/'ball-berry-reference.npz',actual=actual,reference=expected)
rows=fixture['leaf'];assert len(rows)==540
out=leaf_gas_exchange(np.asarray([q['par'] for q in rows]),298.15,co2_ppm=np.asarray([q['ca'] for q in rows]),relative_humidity=np.asarray([q['rh'] for q in rows]),boundary_conductance=np.asarray([q['gb'] for q in rows]),nitrogen_factor=1.,water_stress=np.asarray([q['beta'] for q in rows]))
fields={};data={}
for name in ['ci_ppm','gs_mol','gross','net','respiration','rubisco','rubp','tpu']:
 expected=np.asarray([float(q['decimal80'][name]) for q in rows]);actual=np.asarray(out[name]);difference=abs(actual-expected)
 near_limit,tolerance=(1e-4,1e-6) if name=='gs_mol' else ((1.,.1) if name=='ci_ppm' else (.1,.01))
 near=abs(expected)<=near_limit;fields[name]=dict(maximum_absolute=float(difference.max()),maximum_non_nearzero_relative=float(np.max(np.divide(difference,abs(expected),out=np.zeros_like(expected),where=~near))),exceedances=int(np.count_nonzero(difference>np.where(near,tolerance,.1*abs(expected)))))
 data['actual_'+name]=actual;data['reference_'+name]=expected
np.savez_compressed(r/'coupled-reference.npz',**data)
unchanged=all(sha(s/n)==h for n,h in m.items())
passed=code==0 and len(cases)==len(nodes) and counts['failures']==counts['errors']==counts['skipped']==0 and bb['exceedances']==0 and all(v['exceedances']==0 for v in fields.values()) and unchanged
value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=passed,pytest_returncode=code,collection_returncode=collect,counts=counts,collected_nodes=nodes,source_manifest_sha256=plan['source_manifest_sha256'],source_unchanged=unchanged,ball_berry=bb,coupled_fields=fields,maximum_diffusion_residual=float(np.max(abs(out['diffusion_residual']))),seconds=time.monotonic()-start,
 scope='NumPy-first581source original675BB/540Decimal80references unchanged, originalleaf/canopy/phase independentenergytests and newN/W/rootcontracts. Physicalbeta placement corrected, originalsolver/budgettolerances unchanged. GPUstillprechange/notvalidatedbythisstage; no fullcanonical/year/spinup/scienceacceptance.')
(r/'receipt.json').write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps(value),flush=True);raise SystemExit(0 if passed else 1)

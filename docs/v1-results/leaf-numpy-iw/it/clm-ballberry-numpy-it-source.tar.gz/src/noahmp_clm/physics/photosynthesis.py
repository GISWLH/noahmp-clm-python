"""C3 Farquhar leaf biochemistry and coupled Ball--Berry gas exchange.

Original implementation of published equations, not a translation of CTSM.
References and scope: docs/CLM_PHOTOSYNTHESIS.md. Rates are micromol CO2 per
m虏 leaf per second; CO2 is ppm (micromol/mol), PAR is absorbed micromol photons
per m虏 leaf per second, conductance is mol H2O per m虏 leaf per second.
Used by the multilayer canopy energy and biogeochemistry column paths.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

R_GAS = 8.314462618
T_REFERENCE = 298.15


@dataclass(frozen=True)
class LeafParameters:
    vcmax25: float = 60.0
    jmax25: float = 100.0
    tpu25: float = 10.0
    respiration25: float = 0.9
    quantum_yield_psii: float = 0.85
    curvature: float = 0.7
    ball_berry_slope: float = 9.0
    minimum_conductance: float = 0.01
    growth_temperature: float = 298.15
    oxygen_ppm: float = 210000.0

    def __post_init__(self):
        names=list(self.__dataclass_fields__)
        values=np.broadcast_arrays(*(np.asarray(getattr(self,name),float) for name in names))
        if not all(np.all(np.isfinite(v)) and np.all(v>=0.) for v in values):
            raise ValueError("Leaf parameters must be finite and nonnegative")
        for name,value in zip(names,values):
            if value.ndim:
                value=value.copy();value.setflags(write=False);object.__setattr__(self,name,value)
        if not (np.all((self.curvature>0.)&(self.curvature<=1.))
                and np.all((self.quantum_yield_psii>0.)&(self.quantum_yield_psii<=1.))
                and np.all(self.minimum_conductance>0.)
                and np.all((self.growth_temperature>=250.)&(self.growth_temperature<=320.))):
            raise ValueError("Invalid leaf efficiency, conductance, or growth temperature")

    @classmethod
    def from_layer_rows(cls, rows):
        """Validated per-leaf coefficient rows for vectorized NumPy physics."""
        rows=np.asarray(rows,float)
        if rows.ndim!=2 or rows.shape[1]!=len(cls.__dataclass_fields__) or not len(rows):
            raise ValueError('Leaf coefficient rows require a nonempty n by10 array')
        return cls(**{name:rows[:,k] for k,name in enumerate(cls.__dataclass_fields__)})


def _arrhenius(temperature, activation):
    return np.exp(activation / (R_GAS * T_REFERENCE) * (1.0 - T_REFERENCE / temperature))


def _peaked(temperature, activation, deactivation, entropy):
    numerator = 1.0 + np.exp((T_REFERENCE * entropy - deactivation) / (R_GAS * T_REFERENCE))
    denominator = 1.0 + np.exp((temperature * entropy - deactivation) / (R_GAS * temperature))
    return _arrhenius(temperature, activation) * numerator / denominator


def farquhar_rates(ci_ppm, absorbed_par, leaf_temperature, parameters=None, *, nitrogen_factor=1.0):
    """Rubisco/RuBP/TPU limitation, gross uptake and net uptake at specified ci.

    Use the requested minimum of the three limitations. Electron transport
    uses the stable small quadratic root, including exactly zero light.
    Nitrogen scales biochemical capacities, not the separately supplied Rd.
    """
    p = parameters or LeafParameters()
    ci, par, temperature, nitrogen = np.broadcast_arrays(
        np.asarray(ci_ppm, float), np.asarray(absorbed_par, float),
        np.asarray(leaf_temperature, float), np.asarray(nitrogen_factor, float))
    if not all(np.all(np.isfinite(x)) for x in (ci, par, temperature, nitrogen)):
        raise ValueError("Nonfinite photosynthesis input")
    if np.any((ci < 0) | (par < 0) | (temperature < 200) | (temperature > 350)
              | (nitrogen < 0) | (nitrogen > 1)):
        raise ValueError("Unphysical photosynthesis input")
    return _rates_at_ci(ci, _biochemical_coefficients(par, temperature, nitrogen, p))


def _biochemical_coefficients(par, temperature, nitrogen, p, water_stress=1.0):
    """Coefficients fixed during the ci root solve; inputs validated by caller."""
    growth_c = np.clip(p.growth_temperature - 273.15, 11.0, 35.0)
    vc_factor = _peaked(temperature, 72000., 200000., 668.39 - 1.07 * growth_c)
    vcmax = p.vcmax25 * nitrogen * vc_factor * water_stress
    jmax = p.jmax25 * nitrogen * _peaked(temperature, 50000., 200000., 659.70 - .75 * growth_c)
    tpu = p.tpu25 * nitrogen * vc_factor
    rd = p.respiration25 * _peaked(temperature, 46390., 150650., 490.) * water_stress
    kc = 404.9 * _arrhenius(temperature, 79430.)
    ko = 278400. * _arrhenius(temperature, 36380.)
    gamma = 42.75 * _arrhenius(temperature, 37830.)
    light = .5 * p.quantum_yield_psii * par
    total = light + jmax
    disc = np.maximum(total * total - 4.0 * p.curvature * light * jmax, 0.0)
    denominator = total + np.sqrt(disc)
    electron_transport = np.divide(2.0 * light * jmax, denominator,
        out=np.zeros_like(denominator), where=denominator > 0.0)
    return vcmax, kc*(1.+p.oxygen_ppm/ko), gamma, 3.*tpu, rd, electron_transport


def _rates_at_ci(ci, coefficients):
    vcmax, michaelis, gamma, tpu, rd, electron_transport = coefficients
    carbon = np.maximum(ci - gamma, 0.0)
    rubisco = vcmax * carbon / (ci + michaelis)
    rubp = electron_transport * carbon / (4.0 * ci + 8.0 * gamma)
    product = tpu + np.zeros_like(ci)
    gross = np.minimum(np.minimum(rubisco, rubp), product)
    return {"gross": gross, "net": gross-rd, "rubisco": rubisco,
            "rubp": rubp, "tpu": product, "respiration": rd, "electron_transport": electron_transport}


def ball_berry_conductance(net_assimilation, surface_co2_ppm, relative_humidity,
                           boundary_conductance, parameters=None, *, water_stress=1.0):
    """Positive root of Ball--Berry with leaf-surface humidity feedback.

    ``relative_humidity`` is ambient vapor pressure / leaf saturation pressure.
    The boundary conductance includes the leaf boundary layer, not stomata.
    """
    p = parameters or LeafParameters()
    a, cs, rh, gb, stress = np.broadcast_arrays(np.asarray(net_assimilation, float),
        np.asarray(surface_co2_ppm, float), np.asarray(relative_humidity, float),
        np.asarray(boundary_conductance, float), np.asarray(water_stress, float))
    if not all(np.all(np.isfinite(x)) for x in (a, cs, rh, gb, stress)):
        raise ValueError("Nonfinite gas-exchange input")
    if np.any((cs <= 0) | (gb <= 0) | (rh < 0) | (stress < 0) | (stress > 1)):
        raise ValueError("Unphysical gas-exchange input")
    return _ball_berry(a,cs,rh,gb,stress,p)


def _minimum_conductance(stress, p):
    # CLM's 1 umol H2O m-2 s-1 floor, expressed in this module's mol units.
    return np.maximum(p.minimum_conductance * stress, 1e-6)


def _ball_berry(a,cs,rh,gb,stress,p):
    minimum = _minimum_conductance(stress, p)
    x = p.ball_berry_slope * np.maximum(a, 0.0) / cs
    b = gb - minimum - x
    c = gb * (minimum + x * np.minimum(rh, 1.0))
    root = np.sqrt(b*b + 4.0*c)
    # Both forms are algebraically identical; choose the non-cancelling one.
    positive = 2.0*c / np.maximum(b + root, 1e-30)
    return np.where(b >= 0.0, positive, .5*(root-b))


def leaf_gas_exchange(absorbed_par, leaf_temperature, *, co2_ppm=420.0,
                      relative_humidity=0.7, boundary_conductance=1.0,
                      parameters=None, nitrogen_factor=1.0, water_stress=1.0):
    """Solve biochemical demand = diffusive supply with safeguarded Newton steps.

    The fixed bracket allows ci above ambient (outward respiration).
    Newton steps stay inside it; unresolved entries retain a bisection fallback.
    Return the actual diffusion residual, not a convergence flag alone.
    Water stress scales Vcmax, Rd and minimum conductance independently of N;
    it does not additionally scale Jmax, TPU or the Ball--Berry slope.
    """
    p = parameters or LeafParameters()
    par, temp, ca, rh, gb, nitrogen, stress = np.broadcast_arrays(np.asarray(absorbed_par, float),
        np.asarray(leaf_temperature, float), np.asarray(co2_ppm, float),
        np.asarray(relative_humidity, float), np.asarray(boundary_conductance, float),
        np.asarray(nitrogen_factor,float),np.asarray(water_stress,float))
    if not all(np.all(np.isfinite(x)) for x in (par,temp,ca,rh,gb,nitrogen,stress)):
        raise ValueError("Nonfinite leaf input")
    if np.any((par<0)|(temp<200)|(temp>350)|(ca<=0)|(rh<0)|(gb<=0)
              |(nitrogen<0)|(nitrogen>1)|(stress<0)|(stress>1)):
        raise ValueError("Unphysical leaf input")
    coefficients = _biochemical_coefficients(par,temp,nitrogen,p,stress)
    minimum = _minimum_conductance(stress, p)
    rd = coefficients[4]
    lo = np.zeros_like(ca)
    hi = ca + rd * (1.4 / gb + 1.6 / minimum) + 1.0

    def evaluate(ci):
        rates = _rates_at_ci(ci,coefficients)
        cs = np.maximum(ca - 1.4 * rates["net"] / gb, 1e-9)
        gs = _ball_berry(rates["net"],cs,rh,gb,stress,p)
        residual = rates["net"] - (ca-ci) / (1.4/gb + 1.6/gs)
        return rates, cs, gs, residual

    if np.all(par == 0.0):
        # In darkness electron transport and gross uptake are exactly zero.
        # Net uptake is -Rd, independent of ci, and Ball--Berry reduces to
        # its minimum conductance. Retain the ordinary floating-point gs
        # calculation, then invert the same diffusion equation analytically.
        # This avoids 48 identical biochemical evaluations at every canopy
        # Jacobian and nested surface/MOST trial; no tolerance is changed.
        _, _, gs, _ = evaluate(ca)
        ci = ca + rd * (1.4 / gb + 1.6 / gs)
    else:
        # Differentiate the active biochemical branch and the implicit
        # Ball--Berry quadratic. This saves repeated ci evaluations inside
        # the canopy energy Jacobian without changing the physical equations.
        ci = np.clip(.7*ca,lo,hi)
        done = np.zeros_like(ca,dtype=bool)
        vcmax,michaelis,gamma,tpu,_,electron = coefficients
        eps = np.finfo(float).eps
        for _ in range(16):
            rates,cs,gs,residual = evaluate(ci)
            d_rubisco = vcmax*(michaelis+gamma)/(ci+michaelis)**2
            d_rubp = 12.*electron*gamma/(4.*ci+8.*gamma)**2
            da = np.where(rates['rubisco'] <= rates['rubp'],d_rubisco,d_rubp)
            da = np.where((ci<=gamma)|(rates['gross']==rates['tpu']),0.,da)
            a = rates['net']
            cs_slope = np.where(ca-1.4*a/gb>1e-9,-1.4/gb,0.)
            x = p.ball_berry_slope*np.maximum(a,0.)/cs
            dx = p.ball_berry_slope*(cs-a*cs_slope)/(cs*cs)
            dx = np.where(a>0.,dx,0.)
            dg = (gs+gb*np.minimum(rh,1.))/(2.*gs+gb-minimum-x)*dx*da
            resistance = 1.4/gb+1.6/gs
            derivative = da+1./resistance-(ca-ci)*1.6*dg/(gs*gs*resistance*resistance)
            delta = np.divide(residual,derivative,out=np.full_like(residual,np.inf),where=derivative>0.)
            # Require both the ci correction and diffusion residual to reach
            # rounding scale. Near compensation, subtraction of ca and ci
            # contributes more roundoff than the small assimilation itself.
            residual_roundoff = 16.*eps*(rates['gross']+rd+(np.abs(ca)+np.abs(ci))/resistance+1.)
            done = done | ((np.abs(delta) <= 8.*eps*np.maximum(np.abs(ci),1.)) &
                           (np.abs(residual)<=residual_roundoff))
            if np.all(done): break
            lo=np.where((residual<0.) & ~done,ci,lo)
            hi=np.where((residual>=0.) & ~done,ci,hi)
            proposal=ci-delta
            valid=np.isfinite(proposal)&(proposal>lo)&(proposal<hi)
            proposal=np.where(valid,proposal,.5*(lo+hi))
            ci=np.where(done,ci,proposal)
        if not np.all(done):
            # Finish unresolved entries with the original bisection; preserve
            # roots which already converged. No leaf is silently dropped.
            for _ in range(48):
                mid=.5*(lo+hi)
                _,_,_,residual=evaluate(mid)
                lo=np.where(residual<0.,mid,lo)
                hi=np.where(residual>=0.,mid,hi)
            ci=np.where(done,ci,.5*(lo+hi))
    rates, cs, gs, residual = evaluate(ci)
    return {**rates, "ci_ppm": ci, "cs_ppm": cs, "gs_mol": gs,
        "surface_relative_humidity": (gb * np.minimum(rh, 1.0) + gs) / (gb+gs),
        "diffusion_residual": residual}

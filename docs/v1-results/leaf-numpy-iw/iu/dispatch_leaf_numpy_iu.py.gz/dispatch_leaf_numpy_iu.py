from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'leaf-numpy-iu';assert not r.exists();r.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((b/'clm-ballberry-numpy-iu-package.json').read_text());assert sha(b/plan['archive'])==plan['archive_sha256']
controls={}
for n in ['run_leaf_numpy_iu.py','leaf_numpy_iu.pbs']:
 raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw);controls[n]=sha(r/n)
plan['controls_sha256']=controls;(r/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
p=subprocess.run(['qsub',str(r/'leaf_numpy_iu.pbs')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
value=dict(pbs_job=p.stdout.strip(),controls_sha256=controls,plan_sha256=sha(r/'plan.json'),scope=plan['stage']);(r/'dispatch.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))

from pathlib import Path
import hashlib
import json
import tarfile

b = Path('/home/lhwang/work/noahmp-v1')
r = b / 'qia-cuda-1110-a'
d = json.loads((r / 'surface-capture-a/receipt.json').read_text())
assert d['source_unchanged'] and d['input_unchanged'] and d['device_barrier_complete']
assert d['failure'] == 'RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False'
a = b / 'qia-cuda-1110-capture-a-evidence.tar.gz'
assert not a.exists()
with tarfile.open(a, 'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():
            t.add(p, arcname=p.relative_to(r).as_posix(), recursive=False)
    for name in ['export_qia_cuda_1110_a.py', 'capture_qia_cuda_1110_a.py', 'launch_qia1110_capture_a.py', 'export_qia1110_capture_a.py']:
        t.add(b / name, arcname='control/' + name, recursive=False)
print(json.dumps(dict(archive=a.name, sha256=hashlib.sha256(a.read_bytes()).hexdigest(), bytes=a.stat().st_size)))

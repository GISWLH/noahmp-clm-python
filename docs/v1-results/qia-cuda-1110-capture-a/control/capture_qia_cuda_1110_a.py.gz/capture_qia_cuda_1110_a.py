from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback

import numpy as np

b = Path('/home/lhwang/work/noahmp-v1')
s, r = b / 'p6-all-phase-final-b', b / 'qia-cuda-1110-a'
out = r / 'surface-capture-a'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(m) == 511 and all(sha(s / n) == v for n, v in m.items())
sys.path[:0] = [str(s), str(s / 'src'), str(s / 'benchmarks')]
import run_fluxnet_native as driver
import noahmp_clm.gpu.cuda.canopy_phase_surface as module

binding = json.loads((r / 'binding.json').read_text())
assert sha(r / 'input.npz') == binding['input_sha256']
with np.load(r / 'input.npz', allow_pickle=False) as z:
    data = dict(z)
engine = driver.Backend('cuda32')
xp = engine.xp
before = engine.update_forcing(tuple(xp.asarray(data['a' + str(k)]) for k in range(19)), data['environment'])
before_host = tuple(engine.host(v) for v in before)
original, unpack = module.run_canopy_phase_surface_cuda, module.unpack_phase_surface
calls, captured = [], {}


def observe_raw(raw):
    result = unpack(raw)
    if not bool(xp.all(result['converged'])) or not bool(xp.all(xp.isfinite(raw))):
        captured['raw'] = engine.host(raw)
    return result


def observe(*arrays, **kwargs):
    result = original(*arrays, **{**kwargs, 'raise_on_failure': False})
    good = bool(xp.all(result['converged']))
    calls.append(dict(call=len(calls) + 1, converged=good,
                      canopy_converged=engine.host(result['canopy_converged']).tolist(),
                      max_solver_residual=engine.host(result['max_solver_residual']).tolist()))
    if not good or 'raw' in captured:
        payload = {'surface_a' + str(k): engine.host(v) for k, v in enumerate(arrays)}
        for name in ['exchange_extension', 'vic', 'stem_area']:
            if kwargs.get(name) is not None:
                payload[name] = engine.host(kwargs[name])
        payload['raw'] = captured['raw']
        np.savez_compressed(out / 'failed-surface.npz', **payload)
        (out / 'leaf-parameters.json').write_text(json.dumps(vars(kwargs['parameters']), indent=2) + '\n')
        raise RuntimeError('CUDA layered phase surface failed; inspect with raise_on_failure=False')
    return result


module.run_canopy_phase_surface_cuda, module.unpack_phase_surface = observe, observe_raw
start, failure = time.monotonic(), None
try:
    engine.step(*before, data['forcing'], environment=data['calendar_values'], calendar=data['calendar_flags'],
                nitrogen_deposition_gn_m2=data['nitrogen'], deposition=data['deposition'],
                most_geometry=data['geometry'], leaf_parameters=driver.LeafParameters(**binding['leaf_parameters']), return_surface=True)
except Exception as e:
    failure = type(e).__name__ + ': ' + str(e)
    (out / 'traceback.txt').write_text(traceback.format_exc())
finally:
    module.run_canopy_phase_surface_cuda, module.unpack_phase_surface = original, unpack
xp.cuda.runtime.deviceSynchronize()
unchanged = all(sha(s / n) == v for n, v in m.items())
same = all(np.array_equal(v, engine.host(w)) for v, w in zip(before_host, before))
assert unchanged and same and sha(r / 'input.npz') == binding['input_sha256']
record = dict(scope='Read-only exact original1110 CUDA32 failed-step replay. Original production kernel/raw741 and exact rejected surface inputs exported,then identical original failure raised. No source/tolerance/iteration or failed-year advancement; not an accepted model step. NumPy reference work deferred to EHPC PBS. Interpreter shutdown bypass after barrier/durable receipt only.',
              failure=failure, calls=calls, seconds=time.monotonic() - start, source_unchanged=unchanged,
              input_unchanged=same, device_barrier_complete=True, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json'),
              input_sha256=sha(r / 'input.npz'), failed_surface_sha256=sha(out / 'failed-surface.npz') if (out / 'failed-surface.npz').exists() else None)
(out / 'receipt.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps(record, allow_nan=False), flush=True)
os._exit(0 if captured and failure == 'RuntimeError: CUDA layered phase surface failed; inspect with raise_on_failure=False' else 1)

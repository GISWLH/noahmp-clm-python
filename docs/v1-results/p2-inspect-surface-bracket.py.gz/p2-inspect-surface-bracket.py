import sys,numpy as np,json,cupy as cp
sys.path.insert(0,'tests')
from test_gpu_canopy_surface import cases,reference,budgets
from noahmp_clm.gpu.cuda.canopy_surface import run_canopy_surface_cuda
x=cases(np.float32,40);r=run_canopy_surface_cuda(*x);i=24
ref=reference(tuple(a[i] for a in x))
keys=['surface_temperature','surface_temperature_residual','surface_root_bracket_k','surface_evaluations','h','le','ground_heat','et_kgm2','snow_cells','soil_cells']
report={'index':i,'inputs':[a[i].tolist() for a in x],'cuda':{k:cp.asnumpy(r[k][i]).tolist() for k in keys},'numpy':{k:np.asarray(ref[k]).tolist() for k in keys if k in ref}}
open('bracket-example.json','w').write(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report['cuda'].items() if k not in ('snow_cells','soil_cells')}),flush=True)

from pathlib import Path
import hashlib,json,subprocess,re,tarfile,zipfile,datetime
b=Path('/home/zhangyq/noahmp-v1');r=b/'numpy-leaf-reuse-hw';sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert (r/'pbs-exit.txt').read_text().strip()=='0'
status=subprocess.check_output(['qstat','-xf','1169.manager'],text=True)
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
(r/'actual-pbs-qstat.txt').write_text(status)
raw=(r/'profile_output/receipt.json').read_text()
d,end=json.JSONDecoder().raw_decode(raw)
assert raw[end:]=='\n',repr(raw[end:])
assert d['passed'] and d['source_unchanged'] and len(d['trials'])==24 and len(d['summary'])==6
assert d['pbs_job']=='1169.manager' and d['source_manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
archive=r/'profile_output/fixed-packets-and-returns.zip'
assert sha(archive.read_bytes())==d['raw_archive_sha256']
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==30
 for q in d['trials']:
  assert sha(z.read(q['return_member']))==q['return_sha256'] and q['returned_leaves_byteexact']>400
  packet=q['case']+('/call-%05d.pkl.gz'%q['recorded_day3_step'])
  assert sha(z.read(packet))==q['expected_packet_sha256']
 for q in d['summary']:
  matches=[v for v in d['trials'] if v['case']==q['case'] and v['recorded_day3_step']==q['recorded_day3_step']]
  assert len(matches)==4 and len({v['return_sha256'] for v in matches})==1
controls=json.loads((r/'dispatch.json').read_text())['controls_sha256']
assert all(sha((r/n).read_bytes())==h for n,h in controls.items())
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_pbs_exit_zero=True,
 original_receipt_sha256=sha(raw.encode()),original_receipt_trailer=raw[end:],
 original_receipt_valid_json=True,original_numeric_worker_unchanged=True,
 parsed_original_result=d,all_30_zip_members_crc_valid=True,all_24_return_bytes_same_as_own_original=True,
 scope='Static archival verification only after actualPBSF0. Independent original worker performed all six input/24fullstep physical computations and returnedstate/diagnostic bytechecks on compute node.')
(r/'archive-verification.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
output=b/'numpy-leaf-reuse-hw-evidence.tar.gz';assert not output.exists()
with tarfile.open(output,'w:gz') as tf:
 for q in sorted(r.rglob('*')):
  if q.is_file():tf.add(q,arcname='current/'+q.relative_to(r).as_posix(),recursive=False)
 for name in ['prepare_numpy_leaf_reuse_hw.py','export_numpy_leaf_reuse_hw.py',Path(__file__).name]:tf.add(b/name,arcname=name,recursive=False)
print(json.dumps(dict(archive=output.name,sha256=sha(output.read_bytes()),bytes=output.stat().st_size,summary=d['summary'])))

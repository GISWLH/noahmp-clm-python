"""Standalone cProfile of a fixed recorded step; frozen model never modified."""
from pathlib import Path
from dataclasses import fields, is_dataclass
import collections
import copy
import resource
import statistics
import zipfile
import cProfile
import gzip
import hashlib
import json
import os
import pickle
import pstats
import struct
import sys
import tarfile
import time
import numpy as np

assert os.environ.get('PBS_JOBID')
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'numpy-leaf-reuse-hw'
output = root / 'profile_output'
output.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = Path(os.environ['TMPDIR']) / 'source'
source.mkdir()
archive = base / 'clm-soil-stress-coupled-fl-source.tar.gz'
assert sha(archive) == '6ffc397afdc9df68aee469e7d74950372fa4433af15e1a01959ae5eed909236e'
with tarfile.open(archive) as tf:
    tf.extractall(source, filter='data')
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
source_sha = sha(source / 'SOURCE_SHA256.json')
assert len(manifest) == 579 and source_sha == 'ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69'
assert all(sha(source / name) == digest for name, digest in manifest.items())
sys.path[:0] = [str(base / 'test-deps'), str(source), str(source / 'src'), str(source / 'benchmarks')]
import run_fluxnet_column as runner

leaves = 0


def equal(a, b, name='root'):
    global leaves
    if is_dataclass(a):
        assert type(a) is type(b), name
        for field in fields(a):
            equal(getattr(a, field.name), getattr(b, field.name), name + '/' + field.name)
    elif isinstance(a, dict):
        assert isinstance(b, dict) and a.keys() == b.keys(), name
        for key in a:
            equal(a[key], b[key], name + '/' + str(key))
    elif isinstance(a, (list, tuple)):
        assert type(a) is type(b) and len(a) == len(b), name
        for k, (x, y) in enumerate(zip(a, b)):
            equal(x, y, name + '/' + str(k))
    elif isinstance(a, (np.ndarray, np.generic)):
        x, y = np.asarray(a), np.asarray(b)
        assert x.dtype == y.dtype and x.shape == y.shape and x.tobytes() == y.tobytes(), name
        leaves += 1
    elif isinstance(a, float):
        assert isinstance(b, float) and struct.pack('d', a) == struct.pack('d', b), name
        leaves += 1
    else:
        assert type(a) is type(b) and a == b, name
        leaves += 1



import noahmp_clm.physics.canopy_phase_energy as phase
original = phase.leaf_gas_exchange
prior = base / 'multisite-winter-energy-he'
assert (prior / 'pbs-exit.txt').read_text().strip() == '0'
receipt = json.loads((prior / 'receipt.json').read_text())
assert receipt['passed'] and receipt['source_unchanged']
selected = [f'CN-{site}-{year}-field-capacity-hydraulic-clim' for site,year in [('Cng',2007),('Qia',2003),('Cha',2003)]]
trials = []
with zipfile.ZipFile(output / 'fixed-packets-and-returns.zip', 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    for case in selected:
        row = next(q for q in receipt['cases'] if q['case'] == case)
        assert row['failure'] is None and all(row['full_original_trace_fields_byteexact'].values())
        archive = prior / case / 'steps.tar.gz'
        assert sha(archive) == row['step_packet_archive_sha256']
        with tarfile.open(archive) as tf:
            for index in [0,24]:
                member = f'call-{index:05d}.pkl.gz'
                raw = tf.extractfile(member).read()
                packet = pickle.loads(gzip.decompress(raw))
                bundle.writestr(case+'/'+member, raw)
                expected = dict(after=packet['after'], diagnostics=packet['diagnostics'])
                # Fixed ABBA sequence, all independent original physical-step inputs.
                # Cache always starts empty and is capped at128 full serialized keys.
                for repeat,mode in enumerate(['original','reuse','reuse','original']):
                    cache = collections.OrderedDict()
                    counts = dict(calls=0,hits=0,misses=0,evictions=0,max_entries=0)
                    def cached(*args,**kwargs):
                        counts['calls'] += 1
                        key = pickle.dumps((args,kwargs),protocol=5)
                        if key in cache:
                            counts['hits'] += 1
                            value=cache.pop(key);cache[key]=value
                            # Preserve fresh return ownership even though physical code only reads it.
                            return copy.deepcopy(value)
                        counts['misses'] += 1
                        result=original(*args,**kwargs)
                        cache[key]=copy.deepcopy(result)
                        if len(cache)>128:
                            cache.popitem(last=False);counts['evictions'] += 1
                        counts['max_entries']=max(counts['max_entries'],len(cache))
                        return result
                    assert phase.leaf_gas_exchange is original
                    phase.leaf_gas_exchange = cached if mode=='reuse' else original
                    wall,cpu=time.monotonic(),time.process_time()
                    try:
                        after,diagnostics=runner.step_clm_enthalpy_column(packet['before'],packet['forcing'],**packet['kwargs'])
                    finally:
                        phase.leaf_gas_exchange=original
                    wall,cpu=time.monotonic()-wall,time.process_time()-cpu
                    before_leaves=leaves
                    equal(expected,dict(after=after,diagnostics=diagnostics))
                    result_raw=pickle.dumps(dict(after=after,diagnostics=diagnostics),protocol=5)
                    output_name=f'{case}/{index:02d}-{repeat}-{mode}.pkl'
                    bundle.writestr(output_name,result_raw)
                    trials.append(dict(case=case,recorded_day3_step=index,order=repeat,mode=mode,
                        wall_seconds=wall,cpu_seconds=cpu,returned_leaves_byteexact=leaves-before_leaves,
                        expected_packet_sha256=hashlib.sha256(raw).hexdigest(),return_member=output_name,
                        return_sha256=hashlib.sha256(result_raw).hexdigest(),cache=counts if mode=='reuse' else None))
                    print(json.dumps(trials[-1]),flush=True)
summary=[]
for case in selected:
    for index in [0,24]:
        these=[q for q in trials if q['case']==case and q['recorded_day3_step']==index]
        base_times=[q['wall_seconds'] for q in these if q['mode']=='original']
        reuse_times=[q['wall_seconds'] for q in these if q['mode']=='reuse']
        summary.append(dict(case=case,recorded_day3_step=index,original_wall_seconds=base_times,
            reuse_wall_seconds=reuse_times,median_ratio_original_over_reuse=statistics.median(base_times)/statistics.median(reuse_times)))
result=dict(passed=True,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,
    source_manifest_sha256=source_sha,source_unchanged=all(sha(source/name)==digest for name,digest in manifest.items()),
    trials=trials,summary=summary,maximum_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    raw_archive_sha256=sha(output/'fixed-packets-and-returns.zip'),
    instrumentation_changelog=[dict(file='profile_leaf_reuse_hw.py',change='New standalone bounded exact-key cache experiment; runtime wrapper restored after each trial'),
        dict(file='profile_output/fixed-packets-and-returns.zip',change='All six trusted original packets and all24 actual full returns'),
        dict(file='profile_output/receipt.json',change='All actual timings, byte-equality and cache counters')],
    scope='EHPCcompute-only fixed three sites Jan3 midnight/noon predeterminedABBA fullstep experiment, all returnedstate/diagnostics byteexact to own trustworthy recorded original. Full-input pickle key,128-entry bound, deep-copied return ownership. No production/source/input/forcing/gate/liveyear changes; no performance extrapolation to year, no acceleration or scientificacceptance claim from this local sample.')
(output/'receipt.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(passed=result['passed'],source_unchanged=result['source_unchanged'],summary=summary)),flush=True)
assert result['source_unchanged']

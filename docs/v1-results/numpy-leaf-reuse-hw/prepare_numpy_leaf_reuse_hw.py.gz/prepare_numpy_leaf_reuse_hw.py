from pathlib import Path
import hashlib
import json
import subprocess
base = Path('/home/zhangyq/noahmp-v1')
root = base / 'numpy-leaf-reuse-hw'
assert not root.exists()
root.mkdir()
controls = {}
for name in ['profile_leaf_reuse_hw.py', 'numpy_leaf_reuse_hw.pbs']:
    raw = (base / name).read_bytes()
    assert b'\r\n' not in raw
    (root / name).write_bytes(raw)
    controls[name] = hashlib.sha256(raw).hexdigest()
p = subprocess.run(['qsub', str(root / 'numpy_leaf_reuse_hw.pbs')], cwd=root, capture_output=True, text=True)
assert p.returncode == 0, p.stderr
record = dict(pbs_job=p.stdout.strip(), controls_sha256=controls,
    scope='Standaloneoriginalsixfixedthree-siteJan3midnight/noon ABBA exact-key128-entry reuse feasibility experiment on PBScompute only, no inline/model/liveyear changes; rawreturnedstate/diagnostics mustmatchoriginalbytes.')
(root / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';out=source/'full-by-file-c';root=base/'full-c-import-failure-a';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/n)==v for n,v in manifest.items())
names=['progress.json','selection.json','test_gpu_clm_layered_column.log','test_gpu_clm_layered_column.xml','test_gpu_clm_layered_column-receipt.json','test_gpu_clm_layered_column-expected.json','run_pytest_worker_a.py']
for name in names:(root/name).write_bytes((out/name).read_bytes())
for name in ['run_most_full_gpu_c.py','SOURCE_SHA256.json']:(root/name).write_bytes((source/name).read_bytes())
probes=[]
for with_root in [False,True]:
    env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);parts=[source/'src',source/'tests',source/'benchmarks']
    if with_root:parts.insert(0,source)
    env.update(PYTHONPATH=':'.join(map(str,parts)),PYTHONDONTWRITEBYTECODE='1')
    command=[sys.executable,'-c',"import importlib.util,json; s=importlib.util.find_spec('benchmarks');print(json.dumps(None if s is None else dict(origin=s.origin,locations=list(s.submodule_search_locations or []))))"]
    p=subprocess.run(command,cwd=out,env=env,text=True,capture_output=True)
    probes.append(dict(repository_root_in_pythonpath=with_root,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
assert probes[0]['returncode']==probes[1]['returncode']==0 and json.loads(probes[0]['stdout']) is None
assert str(source/'benchmarks') in json.loads(probes[1]['stdout'])['locations']
value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only preservation of actual full-worker C import failure and import-resolution probe; no physics/test execution or acceptance.',source_unchanged=True,probes=probes)
(root/'diagnostic.json').write_text(json.dumps(value,indent=2)+'\n');(root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
archive=base/'full-c-import-failure-a-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(root.iterdir()):t.add(p,arcname=p.name)
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),files=len(list(root.iterdir())))))

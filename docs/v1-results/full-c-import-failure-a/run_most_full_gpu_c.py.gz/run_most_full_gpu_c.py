"""Exact current1129 distributed coverage; verified prefixes plus isolated workers."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
base=Path('/home/lhwang/work/noahmp-v1');source=base/'p6-most-oscillation-a';current=base/'p6-spinup-assessment-c';trial=base/'gpu-worker-lifecycle-a';preflight='--preflight-only' in sys.argv
out=source/('full-worker-preflight-c' if preflight else 'full-by-file-c');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();begun=time.monotonic()
old_manifest=json.loads((source/'SOURCE_SHA256.json').read_text());current_manifest=json.loads((current/'SOURCE_SHA256.json').read_text())
def verify():
    assert all(sha(source/n)==v for n,v in old_manifest.items())
    assert all(sha(current/n)==v for n,v in current_manifest.items())
verify()
old_code=[n for n in old_manifest if n.startswith(('src/','tests/','benchmarks/','examples/'))];assert len(old_code)==483 and all(old_manifest[n]==current_manifest[n] for n in old_code)
collection=json.loads((current/'current-collection-receipt.json').read_text());all_nodes=collection['nodes'];assert len(all_nodes)==len(set(all_nodes))==1129 and collection['source_unchanged'] and collection['gpu_node_identity_exact']
is_gpu=lambda n:Path(n.split('::')[0]).name.startswith(('test_gpu','test_jax','test_cuda'))
gpu_nodes={n for n in all_nodes if is_gpu(n)};cpu_nodes=set(all_nodes)-gpu_nodes;assert len(gpu_nodes)==325 and len(cpu_nodes)==804
def xml_nodes(raw):
    values=[]
    for case in ET.fromstring(raw).iter('testcase'):
        assert all(case.find(k) is None for k in ['error','failure','skipped'])
        parts=case.attrib['classname'].split('.');indices=[k for k,v in enumerate(parts) if v.startswith('test_')];assert len(indices)==1;k=indices[0]
        values.append('tests/'+parts[k]+'.py::'+'::'.join(parts[k+1:]+[case.attrib['name']]))
    assert len(values)==len(set(values));return set(values)
old_cpu=source/'most-oscillation-cpu-a-evidence.tar.gz';assert sha(old_cpu)=='a1d40d43bac51cc0408f42207bd44cc2f4a33e8b8831016f3404b7d47b851c54'
with tarfile.open(old_cpu) as archive:
    assert json.load(archive.extractfile('SOURCE_SHA256.json'))==old_manifest
    receipt=json.load(archive.extractfile('cpu-full-receipt.json'));old_cpu_nodes=xml_nodes(archive.extractfile('cpu-full.xml').read())
assert len(old_cpu_nodes)==780 and receipt['returncode']==0 and receipt['source_unchanged']
new_cpu=base/'gpu-full-worker-c-spinup-proof.tar.gz';assert sha(new_cpu)=='ec541bedf2a9f353879c9c9a0e02c8b531a55cd8e62a57fa7ac7e448b798e7d4'
with tarfile.open(new_cpu) as archive:
    assert json.load(archive.extractfile('SOURCE_SHA256.json'))==current_manifest
    target=json.load(archive.extractfile('spinup-target-receipt.json'));coverage=json.load(archive.extractfile('cpu-coverage-receipt.json'));target_nodes=xml_nodes(archive.extractfile('spinup-target.xml').read())
assert target['pbs_job']=='99.manager' and target['returncode']==0 and target['source_unchanged'] and len(target_nodes)==79
assert coverage['pbs_job']=='100.manager' and coverage['all_current_cpu_nodes_covered'] and old_cpu_nodes|target_nodes==cpu_nodes and len(target_nodes-old_cpu_nodes)==24
prior=json.loads((source/'full-by-file-a/progress.json').read_text());rows=[];seen=set();covered=set(cpu_nodes)
for row in prior['results']:
    assert row['returncode']==0 and row['passed'] and row['node_coverage_exact']
    file=row['file'];name=Path(file).stem;actual=xml_nodes((source/'full-by-file-a'/(name+'.xml')).read_bytes());expected={n for n in gpu_nodes if n.split('::')[0]==file}
    assert actual==expected==set(row['nodes']) and file not in seen
    rows.append(dict(file=file,origin='original-canonical-normal-exit',result=row,xml_sha256=sha(source/'full-by-file-a'/(name+'.xml'))));seen.add(file);covered.update(actual)
prototype=json.loads((trial/'summary.json').read_text());assert prototype['status']=='complete' and len(prototype['results'])==2
worker=trial/'run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
for row in prototype['results']:
    file=row['file'];name=Path(file).stem;r=row['receipt'];actual=xml_nodes((trial/(name+'.xml')).read_bytes());expected={n for n in gpu_nodes if n.split('::')[0]==file}
    assert row['returncode']==r['pytest_returncode']==r['worker_exitcode']==0 and r['passed'] and r['source_unchanged'] and r['node_coverage_exact'] and r['all_setup_call_teardown_phases_passed'] and all(v['status']=='complete' for v in r['device_barriers'])
    assert r['worker_sha256']==sha(worker) and r['xml_sha256']==sha(trial/(name+'.xml')) and r['test_sha256']==sha(source/file) and actual==expected
    if file not in seen:rows.append(dict(file=file,origin='verified-isolated-worker',result=row,xml_sha256=sha(trial/(name+'.xml'))));seen.add(file);covered.update(actual)
files=sorted({n.split('::')[0] for n in gpu_nodes});pending=[f for f in files if f not in seen]
scope='Exact current1129 distributed pytest nodes: original same-source780 CPU plus24 EHPC CPU nodes, original terminal device prefix and actual terminal isolated-worker files, followed by every remaining original device node. Interpreter atexit is explicitly bypassed only after full pytest phases/barriers/receipt; no physics/test/tolerance changes and no scientific/annual acceptance.'
selection=dict(scope=scope,collected_nodes=1129,cpu_nodes=804,gpu_nodes=325,all_nodes=all_nodes,verified_gpu_prefix_files=len(rows),verified_gpu_prefix_nodes=len(covered)-804,remaining_gpu_files=pending,remaining_gpu_nodes=1129-len(covered),prefix_results=rows,
    source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),current_source_manifest_sha256=sha(current/'SOURCE_SHA256.json'),unchanged_existing_code_test_benchmark_files=len(old_code),old_cpu_archive_sha256=sha(old_cpu),new_cpu_archive_sha256=sha(new_cpu),current_collection_receipt_sha256=sha(current/'current-collection-receipt.json'),worker_sha256=sha(worker),runner_sha256=sha(Path(__file__)))
(out/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
if preflight:print(json.dumps({k:v for k,v in selection.items() if k not in ['all_nodes','prefix_results','scope']}));raise SystemExit(0)
supersession=json.loads((source/'full-controller-superseded-c.json').read_text());assert supersession['source_unchanged'] and supersession['annual_identity_unchanged'] and supersession['old_controller_terminal']
(out/'run_pytest_worker_a.py').write_bytes(worker.read_bytes());results=[]
def save(active=None):
    report=dict(scope=scope,status='running',collected_nodes=1129,covered_nodes=len(covered),gpu_files_completed=len(rows)+len(results),gpu_files_total=len(files),active=active,results=results,seconds=time.monotonic()-begun)
    temp=out/'progress.json.tmp';temp.write_text(json.dumps(report,indent=2)+'\n');os.replace(temp,out/'progress.json')
save()
for file in pending:
    verify();name=Path(file).stem;nodes={n for n in gpu_nodes if n.split('::')[0]==file};expected=out/(name+'-expected.json');expected.write_text(json.dumps(sorted(Path(n.split('::',1)[0]).name+'::'+n.split('::',1)[1] for n in nodes),indent=2)+'\n')
    receipt_path=out/(name+'-receipt.json');xml=out/(name+'.xml');command=[sys.executable,'-u',str(out/'run_pytest_worker_a.py'),'--source',str(source),'--test-file',str(source/file),'--expected',str(expected),'--receipt',str(receipt_path),'--xml',str(xml)]
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        child=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT);save(dict(file=file,pid=child.pid,started_unix=time.time()));code=child.wait()
    row=dict(file=file,pid=child.pid,returncode=code,seconds=time.monotonic()-start,passed=False)
    if receipt_path.exists():
        r=json.loads(receipt_path.read_text());row['receipt']=r
        if code==r['worker_exitcode']==r['pytest_returncode']==0 and r['passed'] and r['source_unchanged'] and r['node_coverage_exact'] and r['worker_sha256']==sha(out/'run_pytest_worker_a.py') and r['xml_sha256']==sha(xml) and xml_nodes(xml.read_bytes())==nodes:
            row['passed']=True;covered.update(nodes)
    results.append(row);save();print(json.dumps({k:v for k,v in row.items() if k!='receipt'}),flush=True)
verify();complete=covered==set(all_nodes) and all(v['passed'] for v in results)
(out/'summary.json').write_text(json.dumps(dict(scope=scope,status='complete' if complete else 'failed',collected_nodes=1129,covered_nodes=len(covered),source_unchanged=True,all_node_coverage_exact=covered==set(all_nodes),prefix_results=rows,results=results,seconds=time.monotonic()-begun),indent=2)+'\n')
raise SystemExit(0 if complete else 1)

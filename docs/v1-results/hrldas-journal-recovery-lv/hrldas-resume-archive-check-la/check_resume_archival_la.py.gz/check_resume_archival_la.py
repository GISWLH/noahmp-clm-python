"""Real resume-save serialization regression, on copied checkpoints only."""
from pathlib import Path
from types import SimpleNamespace
from dataclasses import fields,is_dataclass
import ast,hashlib,json,os,pickle,struct,sys,tarfile,types,zipfile,zlib
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-resume-archive-check-la';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda raw:hashlib.sha256(raw).hexdigest();digest=lambda p:sha(Path(p).read_bytes());archive=b/'clm-ballberry-jn-source.tar.gz';assert digest(archive)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==581 and all(digest(s/n)==h for n,h in m.items());sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
control=b/'run_hrldas_year_kz.py';tree=ast.parse(control.read_text());names={'append_history','preserve_generation','observed_json','identical'};nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(nodes)==4
scope=types.ModuleType('resume_archiver_under_test');scope.__dict__.update(Path=Path,json=json,os=os,zipfile=zipfile,zlib=zlib,sha=sha,np=np,struct=struct,fields=fields,is_dataclass=is_dataclass,runner=runner,original_json=runner.atomic_json)
trajectory=tmp/'trajectory';trajectory.mkdir();scope.trajectory=trajectory;scope.history=tmp/'history.zip';scope.index_path=tmp/'index.json';exec(compile(ast.Module(body=nodes,type_ignores=[]),str(control),'exec'),scope.__dict__)
original=b/'hrldas-current-kg/runs/CN-HaM-suction-climate-cycle/trajectory';source_report=(original/'report.json').read_bytes();report=json.loads(source_report);assert report['status']=='running' and report['steps_completed']==336 and report['steps_requested']==17520;source_files={n:(original/n).read_bytes() for n in ['report.json',report['checkpoint_file'],report['model_npz']]};before=pickle.loads(source_files[report['checkpoint_file']])
for n,raw in source_files.items():(trajectory/n).write_bytes(raw)
scope.preserve_generation(report);original_step=runner.step_clm_enthalpy_column;original_json=runner.atomic_json;calls=[]
def forbidden(*a,**kw):calls.append(True);raise AssertionError('No physical tendency permitted in archive-only test')
try:
    runner.step_clm_enthalpy_column=forbidden;runner.atomic_json=scope.observed_json;inputs=b/'hrldas-current-kg/inputs'
    try:runner.run(inputs/'CN-HaM.npz',inputs/'CN-HaM.json',inputs/'CN-HaM-config.json',trajectory,resume=True,stop_after=0)
    except ValueError as e:assert str(e)=='stop_after must advance at least one interval'
    else:raise AssertionError('Expected zero-step stop guard')
finally:runner.step_clm_enthalpy_column=original_step;runner.atomic_json=original_json
assert not calls;repacked_report=json.loads((trajectory/'report.json').read_text());after=pickle.loads((trajectory/repacked_report['checkpoint_file']).read_bytes());scope.identical(before,after,'all7 resumed checkpoint fields')
assert repacked_report['steps_completed']==336 and repacked_report['steps_requested']==17520 and repacked_report['status']=='running'
index=json.loads(scope.index_path.read_text());snapshots=[key for key in index if key.endswith('/report.json')];assert len(snapshots)>=2
with zipfile.ZipFile(scope.history) as z:
    for key in snapshots:
        d=json.loads(z.read(key));prefix=key.removesuffix('report.json');assert sha(z.read(prefix+d['checkpoint_file']))==d['checkpoint_sha256'] and sha(z.read(prefix+d['model_npz']))==d['model_npz_sha256']
checks=['real frozen runner resume-save observed before zero-step guard; no physics call','all7 loaded checkpoints exactly equal despite reserialization','distinct original/resume336 report identities retained with matching state/trace hashes']
# Real384 files from the earlier wrapper-failed run are storage fixtures ONLY;
# no state is used for any new physical integration.
endpoint=b/'hrldas-current-year-kq/CN-HaM/trajectory';raw_report=(endpoint/'report.json').read_bytes();endpoint_report=json.loads(raw_report);assert endpoint_report['steps_completed']==384 and endpoint_report['status']=='running' and endpoint_report['source_unchanged'];endpoint_files={n:(endpoint/n).read_bytes() for n in ['report.json',endpoint_report['checkpoint_file'],endpoint_report['model_npz']]}
for n,raw in endpoint_files.items():(trajectory/n).write_bytes(raw)
scope.preserve_generation(endpoint_report)
assert not (trajectory/report['checkpoint_file']).exists() and not (trajectory/report['model_npz']).exists()
with zipfile.ZipFile(scope.history) as z:
    for n,raw in source_files.items():assert any(key.endswith('/'+n) and z.read(key)==raw for key in z.namelist())
checks.append('real384 storage fixture permits safe removal of both original/reserialized closed336 bytes only after verified snapshots')
name='state-0000288.pkl';older=(original/name).read_bytes();(trajectory/name).write_bytes(older)
try:scope.preserve_generation(endpoint_report)
except AssertionError:pass
else:raise AssertionError('Unknown closed file was removed')
assert (trajectory/name).read_bytes()==older;checks.append('unobserved real288 file remains rejected and intact')
try:scope.append_history({snapshots[0]:b'not the original committed report'})
except AssertionError:pass
else:raise AssertionError('Existing archive identity collision accepted')
with zipfile.ZipFile(scope.history) as z:assert z.testzip() is None
checks.append('archive identity collisions still rejected; full archive CRC intact')
assert all((original/n).read_bytes()==raw for n,raw in source_files.items()) and all((endpoint/n).read_bytes()==raw for n,raw in endpoint_files.items()) and all(digest(s/n)==h for n,h in m.items())
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,checks=checks,physical_tendency_calls=len(calls),year_control_sha256=digest(control),all_original_model_and_frozen_source_files_unchanged=True,
    original336_checkpoint_sha256=sha(source_files[report['checkpoint_file']]),reserialized336_checkpoint_sha256=repacked_report['checkpoint_sha256'],
    scope='CopiedrealKG336, originalJN runner actualresume-save withstop_after0, realKQ384 onlyasstoragefixture. Tests genuineproducer repeatedindex/serializedbyte changes andnewcontent-addressed report observer; all7 state/ledgers semantically exact, zero physicalsteps. No failed384state becomes aseed, no scientific/year/continuationpass.')
(r/'check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

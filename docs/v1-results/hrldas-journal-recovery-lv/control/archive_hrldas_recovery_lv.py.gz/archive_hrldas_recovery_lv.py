"""Closed failures, verified compaction and stable append-journal prefixes."""
from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,sys,tarfile,time
b=Path('/home/zhangyq/noahmp-v1');payload={};sha=lambda raw:hashlib.sha256(raw).hexdigest();completed=[]
for name,job,receipt in [('hrldas-resume-archive-check-la','1305.manager','check.json'),('hrldas-journal-check-lr','1420.manager','check.json')]:
    root=b/name;status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M) and (root/'pbs-exit.txt').read_text().strip()=='0';d=json.loads((root/receipt).read_text());assert d['passed'] and d['physical_tendency_calls']==0
    for p in sorted(root.rglob('*')):
        if p.is_file():assert not p.is_symlink();payload[name+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
    payload[name+'/actual-pbs-qstat.txt']=status.encode();completed.append(dict(root=name,job=job,actual_exit=0))
for name,retired in [('hrldas-current-year-kq',108),('hrldas-current-year-kz',105)]:
    root=b/name;retirement=json.loads((root/'retirement.json').read_text());assert retirement['unstarted_tail_jobs_retired']==retired and retirement['actual_qdel_exit']==0
    for p in sorted(root.rglob('*')):
        if p.is_file():assert not p.is_symlink();payload['retired/'+name+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
for folder,name,digest in [('noahmp-hrldas-inode-lm','closed-generations.tar.gz','e81f8a92e1a1d7fff831f6cfef90d191e0d12bd5d940e1c3976eac118c19cc77'),('noahmp-height-inode-ln','closed-height-generations.tar.gz','c84866b933a8b03f468774141033a9c54b775f27370f7a8b4b8a615b32ef98d6')]:
    root=Path('/tmp')/folder;raw=(b/(folder+'-'+name)).read_bytes();assert sha(raw)==digest;payload['compaction/'+folder+'/'+name]=raw;d=json.loads((root/'receipt.json').read_text());assert d['sha256']==digest and d.get('full_tmp_restore_byteexact',d.get('all_complete_tmp_restore_bytes_verified'));payload['compaction/'+folder+'/receipt.json']=(root/'receipt.json').read_bytes()
root=b/'hrldas-current-year-lq';sys.path.insert(0,str(root))
from append_journal_lp import Journal
plan=json.loads((root/'protocol.json').read_text());assert all(sha((root/n).read_bytes())==h for n,h in plan['controls_sha256'].items());first=[]
for p in sorted(root.iterdir()):
    if p.is_file():payload['current-chain/'+p.name]=p.read_bytes()
heads=json.loads((root/'dispatch-complete.json').read_text())['first_jobs']
for row in heads:
    site=row['site'];p=root/site/'journal.bin'
    for attempt in range(5):
        try:j=Journal(p);break
        except AssertionError:
            if attempt==4:raise
            time.sleep(.2)
    label='origin';status=subprocess.check_output(['qstat','-xf',row['pbs_job']],text=True);state=re.search(r'^\s*job_state = (\w+)\s*$',status,re.M).group(1);exit_match=re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M);exit_status=int(exit_match.group(1)) if exit_match else None
    if state=='F' and exit_status==0:
        label='segment/384';d=json.loads(j.read(label)['receipt.json']);assert d['pbs_job']==row['pbs_job'] and d['actual_stop']==432 and d['failure'] is None and d['source_unchanged']
    offset,n,_=j.index[label];end=offset+n
    with p.open('rb') as stream:raw=stream.read(end)
    assert len(raw)==end;payload['current-chain/'+site+'/stable-journal-prefix.bin']=raw;payload['current-chain/'+site+'/first-job-actual-qstat.txt']=status.encode();first.append(dict(site=site,job=row['pbs_job'],actual_state=state,actual_exit=exit_status,archived_through_label=label,stable_prefix_sha256=sha(raw),bytes=len(raw)))
for n in ['compact_completed_hrldas_lm.py','compact_closed_height_ln.py']:
    location=Path('/tmp/noahmp-hrldas-inode-lm')/n;payload['control/'+n]=location.read_bytes()
for n in ['retire_idle_hrldas_kq_lb.py','retire_hrldas_kz_ls.py',Path(__file__).name]:payload['control/'+n]=(b/n).read_bytes()
snapshot=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_storage_regressions=completed,current_chain_heads=first,closed_files_losslessly_archived=426,actual_inode_snapshot=subprocess.check_output(['df','-i',str(b)],text=True),scope='KQ archival-only actualF1 andKZ first384actualF0/secondactualF1 retained;108+105 unexecutedtails retired, actualqdel105+102, remainderautoF/noexec. LA/LR realproducerzero-step regressions actualF0. LM48/LN378 fullrestore/SHAverified closedfiles archivedbeforeunlink, allfinalprotected. NewLQ111segments use node-localtrajectory andpreexistingappend-onlyHOMEjournals, proven successful384 only; stablecapturedprefix labels andactualPBSstatus explicit. No failedstate advancement or physics/source/sciencegatechange, queue/segment0 not annualacceptance.')
payload['snapshot.json']=(json.dumps(snapshot,indent=2)+'\n').encode();target=b/'hrldas-journal-recovery-lv-evidence.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as tf:
    for name,raw in sorted(payload.items()):member=tarfile.TarInfo(name);member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    assert len(tf.getmembers())==len(payload)
    for m in tf:assert tf.extractfile(m).read()==payload[m.name]
out=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,artifacts=len(payload),scope=snapshot['scope']);(b/'hrldas-journal-recovery-lv-package.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

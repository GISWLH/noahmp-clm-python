"""Losslessly compact terminal height-run generations below the final state."""
from pathlib import Path
import datetime, hashlib, io, json, os, re, subprocess, tarfile

b = Path('/home/zhangyq/noahmp-v1').resolve()
r = Path('/tmp/noahmp-height-inode-ln')
r.mkdir(mode=0o700, exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
status = subprocess.check_output(['qstat', '-xf', '390.manager'], text=True)
assert re.search(r'^\s*job_state = F\s*$', status, re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', status, re.M)
(r / '390-actual-qstat.txt').write_text(status)
root = b / 'height-matrix-bx'
receipt = json.loads((root / 'receipt.json').read_text())
assert receipt['all27_numerically_complete'] and receipt['source_unchanged']
protected = {str(root / 'receipt.json'): sha(root / 'receipt.json')}
files = []
cases = [p for p in (root / 'height-runs').iterdir() if p.is_dir()]
assert len(cases) == 27
for folder in sorted(cases):
    report_path = folder / 'report.json'
    report = json.loads(report_path.read_text())
    assert report['status'] == 'complete'
    assert report['steps_completed'] == report['steps_requested'] == 336
    protected[str(report_path)] = sha(report_path)
    for key, digest in [('checkpoint_file', 'checkpoint_sha256'), ('model_npz', 'model_npz_sha256')]:
        p = folder / report[key]
        assert sha(p) == report[digest]
        protected[str(p)] = report[digest]
    for p in sorted(list(folder.glob('state-*.pkl')) + list(folder.glob('trace-*.npz'))):
        match = re.fullmatch(r'(state|trace)-(\d{7})\.(pkl|npz)', p.name)
        assert match and p.resolve().is_relative_to(root.resolve())
        assert p.stat().st_uid == os.getuid() and not p.is_symlink()
        if int(match.group(2)) < 336:
            files.append((p, 'closed/' + folder.name + '/' + p.name))
assert len(files) == 378
inventory = {n: {'original_absolute_path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size} for p, n in files}
before = subprocess.check_output(['df', '-i', str(b)], text=True)
meta = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': inventory,
        'protected_final_files_sha256': protected, 'actual_parent_job': '390.manager',
        'actual_parent_exit_status': 0, 'before_df_i': before,
        'scope': 'Only closed height-matrix-bx state/trace generations strictly below successful final336. All27 final reports/checkpoints/traces, metadata, inputs and sources remain. Full archive and restored bytes verified before unlink. No physics or acceptance change.'}
target = r / 'closed-height-generations.tar.gz'
with tarfile.open(target, 'w:gz') as tf:
    for p, name in files:
        tf.add(p, arcname=name, recursive=False)
    raw = (json.dumps(meta, indent=2) + '\n').encode()
    member = tarfile.TarInfo('inventory.json')
    member.size = len(raw)
    tf.addfile(member, io.BytesIO(raw))
with tarfile.open(target) as tf:
    for name, value in inventory.items():
        assert hashlib.sha256(tf.extractfile(name).read()).hexdigest() == value['sha256']
    tf.extractall(r / 'restore', filter='data')
for name, value in inventory.items():
    assert sha(r / 'restore' / name) == value['sha256']
    assert (r / 'restore' / name).read_bytes() == Path(value['original_absolute_path']).read_bytes()
for p, name in files:
    assert sha(p) == inventory[name]['sha256'] and p.resolve().is_relative_to(root)
    p.unlink()
assert all(sha(Path(p)) == h for p, h in protected.items())
out = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), archive=target.name,
           sha256=sha(target), bytes=target.stat().st_size, closed_files_archived_and_removed=len(files),
           full_tmp_restore_byteexact=True, all_final_files_unchanged=True,
           before_df_i=before, after_df_i=subprocess.check_output(['df', '-i', str(b)], text=True), scope=meta['scope'])
(r / 'receipt.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out), flush=True)

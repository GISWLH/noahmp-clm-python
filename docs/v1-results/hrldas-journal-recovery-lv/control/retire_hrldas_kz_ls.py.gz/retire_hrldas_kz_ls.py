"""Retire only never-executed KZ tails; preserve successful and failed jobs."""
from pathlib import Path
import datetime,json,re,subprocess
r=Path('/home/zhangyq/noahmp-v1/hrldas-current-year-kz');assert not (r/'retirement.json').exists();jobs=json.loads((r/'jobs.json').read_text());heads=[x for x in jobs if x['begin'] in [336,384]];tails=[x for x in jobs if x['begin'] not in [336,384]];assert len(heads)==6 and len(tails)==105;headproof=[]
for row in heads:
    status=subprocess.check_output(['qstat','-xf',row['pbs_job']],text=True);expected=0 if row['begin']==336 else 1;assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = '+str(expected)+r'\s*$',status,re.M);headproof.append(dict(job=row['pbs_job'],site=row['site'],begin=row['begin'],actual_exit=expected,qstat=status))
status=subprocess.check_output(['qstat','-xf',*[x['pbs_job'] for x in tails]],text=True);matches=list(re.finditer(r'Job Id: (\S+)\n(.*?)(?=\nJob Id: |\Z)',status,re.S));assert len(matches)==105;cancel=[];terminal=[]
for match in matches:
    body=match.group(2);assert not re.search(r'^\s*(stime|exec_host|exec_vnode) =',body,re.M);state=re.search(r'^\s*job_state = (\w+)\s*$',body,re.M).group(1);assert state in ['H','F'];(cancel if state=='H' else terminal).append(match.group(1))
(r/'retired-tail-before-qstat.txt').write_text(status)
q=subprocess.run(['qdel',*cancel],capture_output=True,text=True);assert q.returncode==0,q.stderr
after=subprocess.check_output(['qstat','-xf',*[x['pbs_job'] for x in tails]],text=True)
for match in re.finditer(r'Job Id: (\S+)\n(.*?)(?=\nJob Id: |\Z)',after,re.S):assert not re.search(r'^\s*(stime|exec_host|exec_vnode) =',match.group(2),re.M)
(r/'retired-tail-after-qstat.txt').write_text(after);out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_actual_status=headproof,unstarted_tail_jobs_retired=105,actual_qdel_jobs=len(cancel),already_terminal_without_execution=len(terminal),actual_qdel_exit=q.returncode,scope='Three first384 producer segments actualF0, three later segments actualF1 under HOME inode exhaustion. Retire only105 unexecuted tails, preserve all successful384 and failedlater bytes/receipts/logs. No failedstate continuation, scientific/source/gate change.');(r/'retirement.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='head_actual_status'}),flush=True)

"""Verified lossless archival of closed generations, never live latest state."""
from pathlib import Path
import datetime,hashlib,io,json,os,re,subprocess,tarfile
b=Path('/home/zhangyq/noahmp-v1').resolve();r=Path(__file__).resolve().parent;assert r.parent==Path('/tmp') and r.name=='noahmp-hrldas-inode-lm';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not (r/'closed-generations.tar.gz').exists();before=subprocess.check_output(['df','-i',str(b)],text=True);files=[];protected={}
for job in ['1188.manager','1189.manager']:
    status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M);(r/(job+'-actual-qstat.txt')).write_text(status)
model=json.loads((b/'hrldas-current-kg/receipt.json').read_text());assert model['passed'] and model['source_unchanged']
for site,job in [('CN-Qia','1191.manager'),('CN-Cha','1228.manager'),('CN-HaM','1265.manager')]:
    status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 1\s*$',status,re.M);(r/(job+'-actual-qstat.txt')).write_text(status)
    failed=json.loads((b/'hrldas-current-year-kq'/site/'segment-current.json').read_text());assert failed['actual_stop']==384 and failed['source_unchanged'] and failed['failure']=='AssertionError: Never unlink an unarchived generation'
    for label,folder,cutoff in [('KG',b/'hrldas-current-kg/runs'/(site+'-suction-climate-cycle')/'trajectory',336),('KQ',b/'hrldas-current-year-kq'/site/'trajectory',384)]:
        report_path=folder/'report.json';report=json.loads(report_path.read_text());assert report['steps_completed']==cutoff and report['steps_requested']==17520 and report['status']=='running' and report['source_unchanged'];protected[str(report_path)]=sha(report_path)
        for name,key in [(report['checkpoint_file'],'checkpoint_sha256'),(report['model_npz'],'model_npz_sha256')]:assert sha(folder/name)==report[key];protected[str(folder/name)]=report[key]
        for p in sorted(list(folder.glob('state-*.pkl'))+list(folder.glob('trace-*.npz'))):
            match=re.fullmatch(r'(state|trace)-(\d{7})\.(pkl|npz)',p.name);assert match
            if int(match.group(2))>=cutoff:continue
            assert p.resolve().parent==folder.resolve() and folder.resolve().is_relative_to(b) and p.stat().st_uid==os.getuid() and not p.is_symlink();files.append((p,'closed/'+label+'/'+site+'/'+p.name))
assert len(files)>=42 and len({str(p) for p,_ in files})==len(files);inventory={n:dict(original_absolute_path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p,n in files};meta=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=inventory,protected_live_or_latest_files_sha256=protected,before_df_i=before,scope='Only KG closedgenerations strictlybelow ownsuccessful336 andKQclosedgenerations below wrapper-failed384. Current336seed/latest384 reports/state/traces andallinputs/source/receipts remain. CompleteverifiedTAR+TMPrestore beforeunlink, no runningmodel/priorfailureadvancement or physical/source/gate change.')
target=r/'closed-generations.tar.gz'
with tarfile.open(target,'w:gz') as tf:
    for p,name in files:tf.add(p,arcname=name,recursive=False)
    raw=(json.dumps(meta,indent=2)+'\n').encode();member=tarfile.TarInfo('inventory.json');member.size=len(raw);tf.addfile(member,io.BytesIO(raw))
with tarfile.open(target) as tf:
    for name,value in inventory.items():assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==value['sha256']
    tf.extractall(r/'restore',filter='data')
for name,value in inventory.items():assert sha(r/'restore'/name)==value['sha256'] and (r/'restore'/name).read_bytes()==Path(value['original_absolute_path']).read_bytes()
for p,name in files:
    assert sha(p)==inventory[name]['sha256'] and p.resolve().is_relative_to(b);p.unlink()
assert all(sha(Path(p))==h for p,h in protected.items());after=subprocess.check_output(['df','-i',str(b)],text=True)
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=target.name,sha256=sha(target),bytes=target.stat().st_size,closed_files_archived_and_removed=len(files),all_complete_tmp_restore_bytes_verified=True,all_protected_files_unchanged=True,before_df_i=before,after_df_i=after,scope=meta['scope']);(r/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

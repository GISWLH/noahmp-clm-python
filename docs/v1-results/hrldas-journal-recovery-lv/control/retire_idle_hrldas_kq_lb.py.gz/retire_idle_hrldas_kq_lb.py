"""Retire H tails plus already-terminal unexecuted dependency children."""
from pathlib import Path
import datetime,json,re,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-year-kq';jobs=json.loads((r/'jobs.json').read_text());first=[x for x in jobs if x['begin']==336];tail=[x for x in jobs if x['begin']!=336];assert len(first)==3 and len(tail)==108 and not (r/'retirement.json').exists();records=[]
for row in first:
    status=subprocess.check_output(['qstat','-xf',row['pbs_job']],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 1\s*$',status,re.M);q=r/row['site'];d=json.loads((q/'segment-current.json').read_text());assert d['pbs_job']==row['pbs_job'] and d['actual_stop']==384 and d['status']=='running' and d['source_unchanged'] and d['failure']=='AssertionError: Never unlink an unarchived generation';(q/'actual-wrapper-failure-qstat.txt').write_text(status);records.append(dict(site=row['site'],actual_parent_exit=1,actual_physical_stop=384,failure=d['failure']))
status=subprocess.check_output(['qstat','-xf',*[x['pbs_job'] for x in tail]],text=True);blocks=list(re.finditer(r'Job Id: (\S+)\n(.*?)(?=\nJob Id: |\Z)',status,re.S));assert len(blocks)==108;to_cancel=[];already_terminal=[]
for match in blocks:
    body=match.group(2);assert not re.search(r'^\s*(stime|exec_host|exec_vnode) =',body,re.M)
    state=re.search(r'^\s*job_state = (\w+)\s*$',body,re.M).group(1);assert state in ['H','F'];(to_cancel if state=='H' else already_terminal).append(match.group(1))
(r/'retired-tail-before-qstat.txt').write_text(status);q=subprocess.run(['qdel',*to_cancel],capture_output=True,text=True);assert q.returncode==0,q.stderr
after=subprocess.check_output(['qstat','-xf',*[x['pbs_job'] for x in tail]],text=True);(r/'retired-tail-after-qstat.txt').write_text(after)
for match in re.finditer(r'Job Id: (\S+)\n(.*?)(?=\nJob Id: |\Z)',after,re.S):assert not re.search(r'^\s*(stime|exec_host|exec_vnode) =',match.group(2),re.M)
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),failed_actual_wrappers=records,unstarted_tail_jobs_retired=108,actual_qdel_jobs=len(to_cancel),already_terminal_without_execution=len(already_terminal),jobs=[x['pbs_job'] for x in tail],actual_qdel_exit=q.returncode,
    first_observer_exit=1,first_observer_reason='AllH assertion rejected three alreadyF dependencies beforeanyqdel; LB separatelyrecordsF/noexec andonlycancelsH/noexec.',
    scope='ThreeKQ actualwrapperF1 AFTER sourceunchangedphysical384 retained. Guardrefused unarchivedreserialization; neverresume those384states. All108 unexecutedtails retired: onlycurrentH qdel, alreadyF/noexec identitieskept. CorrectedKZstartsoriginalKG336 afterrealserializationregression0. No source/forcing/config/physicalformula/gate change or cancelledjobsciencecredit.')
(r/'retirement.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='jobs'}),flush=True)

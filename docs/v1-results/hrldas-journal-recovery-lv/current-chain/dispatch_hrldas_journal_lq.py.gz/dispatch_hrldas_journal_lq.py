"""Seed from only KZ actual-success384 archives, release fully prepared chains."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-year-lq';assert not r.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();check=b/'hrldas-journal-check-lr';proof=json.loads((check/'check.json').read_text());assert proof['passed'] and proof['physical_tendency_calls']==0 and proof['source_unchanged'] and proof['journal_control_sha256']==sha(b/'append_journal_lp.py');job=json.loads((check/'dispatch.json').read_text())['pbs_job'];qstat=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',qstat,re.M) and re.search(r'^\s*Exit_status = 0\s*$',qstat,re.M);old=b/'hrldas-current-year-kz';assert json.loads((old/'retirement.json').read_text())['unstarted_tail_jobs_retired']==105;r.mkdir();sys.path.insert(0,str(b))
from append_journal_lp import Journal
names=['run_hrldas_year_lq.py','append_journal_lp.py',Path(__file__).name]
for n in names:raw=(b/n).read_bytes();assert b'\r\n' not in raw;(r/n).write_bytes(raw)
script='''#!/bin/bash
#PBS -N clm-jn-hrldas-journal
#PBS -q workq
#PBS -l select=1:ncpus=1:mem=4gb
#PBS -l walltime=04:00:00
#PBS -j oe
#PBS -o /dev/null
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /home/zhangyq/noahmp-v1/hrldas-current-year-lq
/home/zhangyq/venvs/noahmp-closeout/bin/python -u run_hrldas_year_lq.py >>"$CASE_SITE/control.log" 2>&1
exit "$?"
'''
(r/'job.pbs').write_text(script);sites=['CN-Qia','CN-Cha','CN-HaM'];parents={'CN-Qia':'1306.manager','CN-Cha':'1343.manager','CN-HaM':'1380.manager'};oldplan=json.loads((old/'protocol.json').read_text());starts=[384]+list(range(432,17520,480));assert len(starts)==37;locked=dict(source_manifest_sha256=oldplan['source_manifest_sha256'],sites=sites,segment_starts=starts,successful384_jobs=parents,input_protocol_sha256=oldplan['input_protocol_sha256'],input_sha256=oldplan['input_sha256'],controls_sha256={n:sha(r/n) for n in names+['job.pbs']},scope='OriginalJN threeofficialpaired years, originalsource/forcing/config/coldledgers and successful384 state only. Provenappend-onlyexistingjournal, trajectory/source inPBS TMPDIR. No failedsecondKZstate or alteredphysics; actualF0 chain required. Queue isnot scientific acceptance.')
(r/'protocol.json').write_text(json.dumps(locked,indent=2)+'\n');(r/'storage-regression.json').write_bytes((check/'check.json').read_bytes());(r/'storage-regression-actual-qstat.txt').write_text(qstat)
for site in sites:
    own=r/site;own.mkdir();(own/'journal.bin').touch();(own/'control.log').touch();status=subprocess.check_output(['qstat','-xf',parents[site]],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M)
    with zipfile.ZipFile(old/site/'history.zip') as z:
        key='segments/0000336/receipt.json';receipt_raw=z.read(key) if key in z.namelist() else (old/site/'segment-current.json').read_bytes();receipt=json.loads(receipt_raw);assert receipt['pbs_job']==parents[site] and receipt['begin']==336 and receipt['actual_stop']==384 and receipt['failure'] is None and receipt['source_unchanged'];prefix='0000384/'+receipt['report_sha256']+'/';report_raw=z.read(prefix+'report.json');assert hashlib.sha256(report_raw).hexdigest()==receipt['report_sha256'];d=json.loads(report_raw);assert d['steps_completed']==384 and d['steps_requested']==17520 and d['status']=='running' and d['source_unchanged'];rows={'report.json':report_raw,'successful-parent-receipt.json':receipt_raw,'actual-successful-parent-qstat.txt':status.encode(),'source-manifest.json':(b/'hrldas-current-kg/SOURCE_SHA256.json').read_bytes()}
        for name,key in [(d['checkpoint_file'],'checkpoint_sha256'),(d['model_npz'],'model_npz_sha256')]:rows[name]=z.read(prefix+name);assert hashlib.sha256(rows[name]).hexdigest()==d[key]
    Journal(own/'journal.bin').append('origin',rows)
jobs=[]
for site in sites:
    parent=None;parent_begin=None
    for begin in starts:
        args=['qsub']+(['-h'] if parent is None else ['-W','depend=afterok:'+parent])+['-v','CASE_SITE='+site+',BEGIN_INDEX='+str(begin),str(r/'job.pbs')];q=subprocess.run(args,cwd=r,capture_output=True,text=True);assert q.returncode==0,q.stderr;jobs.append(dict(site=site,begin=begin,stop=min(begin+(48 if begin==384 else 480),17520),pbs_job=q.stdout.strip(),depends_on=parent,parent_begin=parent_begin));parent=q.stdout.strip();parent_begin=begin;(r/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
out=dict(jobs=len(jobs),first_jobs=[next(x for x in jobs if x['site']==site) for site in sites],last_jobs=[next(x for x in reversed(jobs) if x['site']==site) for site in sites],protocol_sha256=sha(r/'protocol.json'),scope=locked['scope']);assert len(jobs)==111;(r/'dispatch-complete.json').write_text(json.dumps(out,indent=2)+'\n')
heads=[x['pbs_job'] for x in out['first_jobs']];release=subprocess.run(['qrls','-h','u',*heads],capture_output=True,text=True);assert release.returncode==0,release.stderr;out['actual_user_hold_release_returncode']=release.returncode;(r/'release.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

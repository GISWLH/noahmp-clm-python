"""Unchanged JN physics in node TMPDIR; durable evidence uses existing inodes."""
from pathlib import Path
import contextlib,gzip,hashlib,json,os,pickle,re,subprocess,sys,tarfile,time,traceback
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-year-lq';site=os.environ['CASE_SITE'];begin=int(os.environ['BEGIN_INDEX']);own=r/site;sha=lambda raw:hashlib.sha256(raw).hexdigest();digest=lambda p:sha(Path(p).read_bytes());plan=json.loads((r/'protocol.json').read_text());assert (r/'dispatch-complete.json').exists() and all(digest(r/n)==h for n,h in plan['controls_sha256'].items());sys.path.insert(0,str(r))
from append_journal_lp import Journal,checkpoint_identical
journal=Journal(own/'journal.bin');jobs=json.loads((r/'jobs.json').read_text());entry=next(x for x in jobs if x['site']==site and x['begin']==begin);assert entry['pbs_job']==os.environ['PBS_JOBID'];tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();a=b/'clm-ballberry-jn-source.tar.gz';assert digest(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=digest(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest==plan['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(digest(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
inputs=b/'hrldas-current-kg/inputs';assert digest(inputs/'protocol.json')==plan['input_protocol_sha256'] and all(digest(inputs/n)==h for n,h in plan['input_sha256'].items())
def actual_parent(job):
    status=subprocess.check_output(['qstat','-xf',job],text=True);assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M),job;return status
if begin==384:
    origin=journal.read('origin');parent=json.loads(origin['successful-parent-receipt.json']);assert parent['pbs_job']==plan['successful384_jobs'][site] and parent['actual_stop']==384 and parent['failure'] is None and parent['source_unchanged'];status=actual_parent(parent['pbs_job']);raw_report=origin['report.json'];assert sha(raw_report)==parent['report_sha256'];seed_rows=origin
else:
    label='segment/'+str(entry['parent_begin']);previous=journal.read(label);parent=json.loads(previous['receipt.json']);assert parent['pbs_job']==entry['depends_on'] and parent['actual_stop']==begin and parent['failure'] is None and parent['source_unchanged'];status=actual_parent(parent['pbs_job']);seed_rows=journal.read(parent['final_generation_label']);raw_report=seed_rows['report.json'];assert sha(raw_report)==parent['report_sha256']
report=json.loads(raw_report);assert report['steps_completed']==begin and report['steps_requested']==17520 and report['status']=='running' and report['source_unchanged'] and report['source_sha256']==runner.source_hashes() and report['configuration_sha256']==plan['input_sha256'][site+'-config.json'];assert sha(seed_rows[report['checkpoint_file']])==report['checkpoint_sha256'] and sha(seed_rows[report['model_npz']])==report['model_npz_sha256'];saved=pickle.loads(seed_rows[report['checkpoint_file']]);assert len(saved)==7 and saved[-1]==begin
trajectory=tmp/'trajectory';trajectory.mkdir()
for name in ['report.json',report['checkpoint_file'],report['model_npz']]:(trajectory/name).write_bytes(seed_rows[name])
journal.append('parent-proof/'+str(begin),{'actual-parent-qstat.txt':status.encode(),'successful-parent-receipt.json':(json.dumps(parent,indent=2)+'\n').encode(),'seed-report.json':raw_report})
original_json=runner.atomic_json;original_step=runner.step_clm_enthalpy_column;first=True;first_packet=None;last_generation=None;started=time.monotonic();failure=None;stop=entry['stop'];seed_sha=sha(seed_rows[report['checkpoint_file']]);assert stop==min(begin+(48 if begin==384 else 480),17520)
def preserve(value):
    global last_generation
    raw=(trajectory/'report.json').read_bytes();d=json.loads(raw);rows={'report.json':raw}
    for name,key in [(d['checkpoint_file'],'checkpoint_sha256'),(d['model_npz'],'model_npz_sha256')]:
        rows[name]=(trajectory/name).read_bytes();assert sha(rows[name])==d[key]
    if d['steps_completed']==begin:checkpoint_identical(saved,pickle.loads(rows[d['checkpoint_file']]))
    label='generation/'+str(d['steps_completed'])+'/'+sha(raw);journal.append(label,rows);last_generation=label
def observed_json(path,value):
    original_json(path,value)
    if Path(path).resolve()==(trajectory/'report.json').resolve():preserve(value)
def observe(state,forcing,**kwargs):
    global first,first_packet
    if first:checkpoint_identical(saved[0],state,'first physical state')
    try:after,diagnostics=original_step(state,forcing,**kwargs)
    except Exception:
        (tmp/'failed-before.pkl.gz').write_bytes(gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs),protocol=5),mtime=0));raise
    if first:first_packet=gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs,after=after,diagnostics=diagnostics),protocol=5),mtime=0);first=False
    return after,diagnostics
try:
    preserve(report);runner.atomic_json=observed_json;runner.step_clm_enthalpy_column=observe
    with (tmp/'worker.log').open('w') as log,contextlib.redirect_stdout(log):report=runner.run(inputs/(site+'.npz'),inputs/(site+'.json'),inputs/(site+'-config.json'),trajectory,resume=True,stop_after=stop-begin)
    assert not first and report['steps_completed']==stop and report['status']==('complete' if stop==17520 else 'running') and report['source_unchanged'];preserve(report)
except Exception as e:
    failure=type(e).__name__+': '+str(e);(tmp/'traceback.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:runner.atomic_json=original_json;runner.step_clm_enthalpy_column=original_step
current=json.loads((trajectory/'report.json').read_text());value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,site=site,begin=begin,requested_stop=stop,actual_stop=current['steps_completed'],steps_requested=17520,status=current['status'],failure=failure,source_manifest_sha256=manifest,source_unchanged=all(digest(s/n)==h for n,h in m.items()),report_sha256=digest(trajectory/'report.json'),final_generation_label=last_generation,all7_seed_fields_carried_sha256=seed_sha,first_tendency_fullstate_exact=not first,seconds=time.monotonic()-started,scope='UnchangedJN originalHRLDASpaired year, only actualF0 predecessor, all7 fields/coldglobalMHCN/forcing/config/source unchanged. Every original report/state/trace commit archived with distinct reporthash identity; node-local trajectory, append-only preexisting HOME journal readback/fsync/SHA. Infrastructure failed KZsecond states neverseed. Segment0 isnot annual/scientific/spinup/releasepass.')
rows={'receipt.json':(json.dumps(value,indent=2)+'\n').encode()}
for name in ['worker.log','traceback.txt','failed-before.pkl.gz']:
    if (tmp/name).exists():rows[name]=(tmp/name).read_bytes()
if first_packet is not None:rows['first-step.pkl.gz']=first_packet
journal.append('segment/'+str(begin),rows);print(json.dumps(value),flush=True);raise SystemExit(0 if failure is None and value['source_unchanged'] else 1)

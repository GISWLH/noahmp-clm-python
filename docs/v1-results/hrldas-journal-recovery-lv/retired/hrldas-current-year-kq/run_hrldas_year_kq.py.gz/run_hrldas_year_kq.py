"""One bounded segment of an unchanged currentJN official-paired NumPy year."""
from pathlib import Path
from dataclasses import fields,is_dataclass
import gzip,hashlib,json,os,pickle,re,struct,subprocess,sys,tarfile,time,traceback,zipfile,zlib
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-current-year-kq';site=os.environ['CASE_SITE'];begin=int(os.environ['BEGIN_INDEX']);own=r/site;sha=lambda raw:hashlib.sha256(raw).hexdigest();digest=lambda p:sha(Path(p).read_bytes());plan=json.loads((r/'protocol.json').read_text())
assert (r/'dispatch-complete.json').exists() and site in plan['sites'] and begin in plan['segment_starts']
assert all(digest(r/n)==h for n,h in plan['controls_sha256'].items());jobs=json.loads((r/'jobs.json').read_text());entry=next(x for x in jobs if x['site']==site and x['begin']==begin);assert entry['pbs_job']==os.environ['PBS_JOBID']
s=Path(os.environ['TMPDIR'])/'source';s.mkdir();archive=b/'clm-ballberry-jn-source.tar.gz';assert digest(archive)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(archive) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=digest(s/'SOURCE_SHA256.json');assert len(m)==581 and manifest==plan['source_manifest_sha256']=='e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5' and all(digest(s/n)==h for n,h in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'benchmarks')]
import run_fluxnet_column as runner
root=b/'hrldas-current-kg';inputs=root/'inputs';case=site+'-suction-climate-cycle';trajectory=own/'trajectory';history=own/'history.zip';index_path=own/'history-index.json'
assert digest(inputs/'protocol.json')==plan['input_protocol_sha256'] and all(digest(inputs/n)==h for n,h in plan['input_sha256'].items())
def append_history(rows):
    index=json.loads(index_path.read_text()) if index_path.exists() else {}
    with zipfile.ZipFile(history,'a',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
        assert len(z.namelist())==len(set(z.namelist()))
        for name,raw in rows.items():
            if name in index:assert index[name]['sha256']==sha(raw) and z.read(name)==raw
            else:
                assert name not in z.namelist();z.writestr(name,raw);index[name]=dict(sha256=sha(raw),bytes=len(raw))
    with history.open('r+b') as stream:os.fsync(stream.fileno())
    with zipfile.ZipFile(history) as z:
        for name,raw in rows.items():assert z.getinfo(name).CRC==zlib.crc32(raw) and z.read(name)==raw and sha(z.read(name))==index[name]['sha256']
    runner.atomic_json(index_path,index)
def actual_parent(job):
    status=subprocess.check_output(['qstat','-xf',job],text=True)
    assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Exit_status = 0\s*$',status,re.M),job
    return status
def identical(a,b,path='state'):
    assert type(a) is type(b),(path,type(a),type(b))
    if isinstance(a,np.ndarray):assert a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes(),path
    elif is_dataclass(a):
        for f in fields(a):identical(getattr(a,f.name),getattr(b,f.name),path+'.'+f.name)
    elif isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for key in a:identical(a[key],b[key],path+'.'+str(key))
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b),path
        for k,(x,y) in enumerate(zip(a,b)):identical(x,y,path+'.'+str(k))
    elif isinstance(a,float):assert struct.pack('d',a)==struct.pack('d',b),path
    elif isinstance(a,np.generic):assert a.dtype==b.dtype and a.tobytes()==b.tobytes(),path
    else:assert a==b,path
if begin==336:
    parent=actual_parent('1189.manager');model_parent=actual_parent('1188.manager');audit=json.loads((b/'hrldas-current-kh/comparison.json').read_text());assert audit['source_unchanged'] and audit['source_manifest_sha256']==manifest and audit['independent_audits'][site]['steps']==336
    model=json.loads((root/'receipt.json').read_text());assert model['passed'] and model['source_unchanged'] and model['source_manifest_sha256']==manifest and (root/'pbs-exit.txt').read_text().strip()=='0'
    previous=root/'runs'/case;receipt=next(x for x in model['cases'] if x['site']==site);report_path=previous/'trajectory/report.json';report=json.loads(report_path.read_text());assert digest(report_path)==receipt['report_sha256'] and report['steps_completed']==336 and report['steps_requested']==17520 and report['status']=='running'
    assert not trajectory.exists();trajectory.mkdir()
    for name in ['report.json',report['model_npz'],report['checkpoint_file']]:(trajectory/name).write_bytes((report_path.parent/name).read_bytes())
    append_history({'origin/model-qstat.txt':model_parent.encode(),'origin/audit-qstat.txt':parent.encode(),'origin/model-case-receipt.json':(json.dumps(receipt,indent=2)+'\n').encode(),'origin/prefix-report.json':report_path.read_bytes(),'origin/source-manifest.json':(s/'SOURCE_SHA256.json').read_bytes()})
else:
    previous=json.loads((own/'segment-current.json').read_text());assert previous['failure'] is None and previous['source_unchanged'] and previous['actual_stop']==begin and previous['source_manifest_sha256']==manifest and (own/'pbs-exit-current.txt').read_text().strip()=='0'
    assert previous['pbs_job']==entry['depends_on'];status=actual_parent(previous['pbs_job']);assert digest(trajectory/'report.json')==previous['report_sha256']
    bootstrap=own/('worker-bootstrap-'+str(previous['begin'])+'.log')
    rows={'segments/'+str(previous['begin']).zfill(7)+'/receipt.json':(own/'segment-current.json').read_bytes(),'segments/'+str(previous['begin']).zfill(7)+'/actual-pbs-qstat.txt':status.encode(),'segments/'+str(previous['begin']).zfill(7)+'/worker.log':(own/'worker-current.log').read_bytes(),'segments/'+str(previous['begin']).zfill(7)+'/bootstrap.log':bootstrap.read_bytes(),'segments/'+str(previous['begin']).zfill(7)+'/pbs-exit.txt':(own/'pbs-exit-current.txt').read_bytes()}
    for name in ['first-step.pkl.gz','first-step-start-audit.json']:
        if (own/name).exists():rows['segments/'+str(previous['begin']).zfill(7)+'/'+name]=(own/name).read_bytes()
    append_history(rows)
    assert bootstrap.resolve().parent==own.resolve()
    with zipfile.ZipFile(history) as z:assert z.read('segments/'+str(previous['begin']).zfill(7)+'/bootstrap.log')==bootstrap.read_bytes()
    bootstrap.unlink()
report=json.loads((trajectory/'report.json').read_text());assert report['source_unchanged'] and report['source_sha256']==runner.source_hashes() and report['steps_completed']==begin and report['steps_requested']==17520 and report['status']=='running' and report['configuration_sha256']==plan['input_sha256'][site+'-config.json']
assert digest(trajectory/report['checkpoint_file'])==report['checkpoint_sha256'] and digest(trajectory/report['model_npz'])==report['model_npz_sha256']
seed=(trajectory/report['checkpoint_file']).read_bytes();saved=pickle.loads(seed);assert len(saved)==7 and saved[-1]==begin
seed_sha=sha(seed);expected=saved[0];original=runner.step_clm_enthalpy_column;first=True;failure=None;started=time.monotonic();stop=entry['stop'];assert stop==min(begin+(48 if begin==336 else 480),17520)
def observe(state,forcing,**kwargs):
    global first
    if first:
        identical(state,expected);runner.atomic_json(own/'first-step-start-audit.json',dict(begin=begin,full_physical_state_and_c_n_exact_before_first_tendency=True,original_all7_checkpoint_fields_carried_sha256=seed_sha,source_manifest_sha256=manifest))
    try:after,diagnostics=original(state,forcing,**kwargs)
    except Exception:
        (own/'failed-before.pkl.gz').write_bytes(gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs),protocol=5),mtime=0));raise
    if first:
        (own/'first-step.pkl.gz').write_bytes(gzip.compress(pickle.dumps(dict(before=state,forcing=forcing,kwargs=kwargs,after=after,diagnostics=diagnostics),protocol=5),mtime=0));first=False
    return after,diagnostics
def preserve_generation(report):
    generation=str(report['steps_completed']).zfill(7);rows={generation+'/report.json':(trajectory/'report.json').read_bytes()}
    for name,key in [(report['checkpoint_file'],'checkpoint_sha256'),(report['model_npz'],'model_npz_sha256')]:
        raw=(trajectory/name).read_bytes();assert sha(raw)==report[key];rows[generation+'/'+name]=raw
    append_history(rows)
    current={report['checkpoint_file'],report['model_npz']}
    inventory=json.loads(index_path.read_text())
    for path in list(trajectory.glob('state-*.pkl'))+list(trajectory.glob('trace-*.npz')):
        if path.name in current:continue
        assert path.resolve().parent==trajectory.resolve();raw=path.read_bytes();keys=[n for n,v in inventory.items() if n.endswith('/'+path.name) and v['sha256']==sha(raw)]
        assert keys,'Never unlink an unarchived generation'
        with zipfile.ZipFile(history) as z:assert z.read(keys[0])==raw
        path.unlink()
try:
    preserve_generation(report)
    runner.step_clm_enthalpy_column=observe
    with (own/'worker-current.log').open('w') as log:
        import contextlib
        with contextlib.redirect_stdout(log):
            while report['steps_completed']<stop:
                amount=min(48,stop-report['steps_completed']);report=runner.run(inputs/(site+'.npz'),inputs/(site+'.json'),inputs/(site+'-config.json'),trajectory,resume=True,stop_after=amount)
                assert report['source_unchanged'] and report['steps_requested']==17520 and report['steps_completed']<=stop;preserve_generation(report)
    assert not first and report['steps_completed']==stop and report['status']==('complete' if stop==17520 else 'running')
except Exception as e:failure=type(e).__name__+': '+str(e);(own/'traceback-current.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:runner.step_clm_enthalpy_column=original
value=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,site=site,case=case,begin=begin,requested_stop=stop,actual_stop=report.get('steps_completed'),steps_requested=17520,status=report.get('status'),failure=failure,source_manifest_sha256=manifest,source_unchanged=all(digest(s/n)==h for n,h in m.items()),report_sha256=digest(trajectory/'report.json'),all7_seed_fields_carried_sha256=seed_sha,first_tendency_fullstate_exact=not first,seconds=time.monotonic()-started,
    scope='CurrentJN unchangedoriginalHRLDASpaired NumPyyear continuation onlyfrom own1188successful336 after1189actualindependentaudit0. Originalwhole17520request/source/forcing/config/coldglobalMHCN preserved. Completeoriginalgenerations SHA/CRC/readback/fsync archivedbeforeonlyclosedfilesunlinked toboundinodeuse. Segment0 isnot annualcompletion/scientific/GPU/spinup/SOC/1e-6/releaseacceptance.')
runner.atomic_json(own/'segment-current.json',value);print(json.dumps(value),flush=True);raise SystemExit(0 if failure is None and value['source_unchanged'] else 1)

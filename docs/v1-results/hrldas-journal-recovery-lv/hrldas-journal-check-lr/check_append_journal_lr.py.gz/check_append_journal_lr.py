"""Real runner reserialization + quota simulation, zero physical tendencies."""
from pathlib import Path
import hashlib,json,os,pickle,sys,tarfile
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'hrldas-journal-check-lr';tmp=Path(os.environ['TMPDIR']);s=tmp/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=b/'clm-ballberry-jn-source.tar.gz';assert sha(a)=='44f173014315f06a96e214806c43aff6ca647583565bc690854885fa0d723ab5'
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==581 and all(sha(s/n)==h for n,h in m.items());sys.path[:0]=[str(r),str(s),str(s/'src'),str(s/'benchmarks')]
from append_journal_lp import Journal,checkpoint_identical
import run_fluxnet_column as runner
sim=tmp/'home-simulation';sim.mkdir();p=sim/'journal.bin';p.touch();j=Journal(p);original_open=Path.open;calls=[];trajectory=tmp/'trajectory';trajectory.mkdir();original=b/'hrldas-current-kg/runs/CN-HaM-suction-climate-cycle/trajectory';report=json.loads((original/'report.json').read_text());assert report['steps_completed']==336 and report['status']=='running';seed={n:(original/n).read_bytes() for n in ['report.json',report['checkpoint_file'],report['model_npz']]};saved=pickle.loads(seed[report['checkpoint_file']]);assert len(saved)==7
for n,raw in seed.items():(trajectory/n).write_bytes(raw)
def quota_open(path,mode='r',*args,**kwargs):
    if path.parent==sim and any(c in mode for c in ['w','a','x']) and not path.exists():raise OSError(28,'Simulated HOME inode quota')
    return original_open(path,mode,*args,**kwargs)
def preserve(value):
    rows={n:(trajectory/n).read_bytes() for n in ['report.json',value['checkpoint_file'],value['model_npz']]};assert hashlib.sha256(rows[value['checkpoint_file']]).hexdigest()==value['checkpoint_sha256'] and hashlib.sha256(rows[value['model_npz']]).hexdigest()==value['model_npz_sha256'];j.append('generation/'+str(value['steps_completed'])+'/'+hashlib.sha256(rows['report.json']).hexdigest(),rows)
original_json=runner.atomic_json;original_step=runner.step_clm_enthalpy_column
def observed(path,value):
    original_json(path,value)
    if path==trajectory/'report.json':preserve(value)
def forbidden(*args,**kwargs):calls.append(True);raise AssertionError('No physical tendency in storage regression')
try:
    Path.open=quota_open
    try:(sim/'must-fail').write_bytes(b'x')
    except OSError as e:assert e.errno==28
    else:raise AssertionError('Quota simulation not active')
    preserve(report);runner.atomic_json=observed;runner.step_clm_enthalpy_column=forbidden;inputs=b/'hrldas-current-kg/inputs'
    try:runner.run(inputs/'CN-HaM.npz',inputs/'CN-HaM.json',inputs/'CN-HaM-config.json',trajectory,resume=True,stop_after=0)
    except ValueError as e:assert str(e)=='stop_after must advance at least one interval'
    else:raise AssertionError('Missing zero-step guard')
    after=json.loads((trajectory/'report.json').read_text());checkpoint_identical(saved,pickle.loads((trajectory/after['checkpoint_file']).read_bytes()));assert not calls and len(j.index)==2
    first=next(iter(j.index));size=p.stat().st_size;assert not j.append(first,j.read(first)) and p.stat().st_size==size
    try:j.append(first,{'different':b'collision'})
    except AssertionError:pass
    else:raise AssertionError('Identity collision accepted')
finally:Path.open=original_open;runner.atomic_json=original_json;runner.step_clm_enthalpy_column=original_step
assert len(Journal(p).index)==2 and len(list(sim.iterdir()))==1
for label in j.index:
    rows=j.read(label);d=json.loads(rows['report.json']);assert hashlib.sha256(rows[d['checkpoint_file']]).hexdigest()==d['checkpoint_sha256'] and hashlib.sha256(rows[d['model_npz']]).hexdigest()==d['model_npz_sha256']
corrupt=tmp/'corrupt.bin';raw=p.read_bytes();corrupt.write_bytes(raw[:-1])
try:Journal(corrupt)
except AssertionError:pass
else:raise AssertionError('Truncated tail accepted')
changed=bytearray(raw);changed[-1]^=1;corrupt.write_bytes(changed)
try:Journal(corrupt)
except AssertionError:pass
else:raise AssertionError('Corrupt payload accepted')
assert all((original/n).read_bytes()==raw for n,raw in seed.items()) and all(sha(s/n)==h for n,h in m.items())
out=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,passed=True,physical_tendency_calls=0,source_unchanged=True,journal_control_sha256=sha(r/'append_journal_lp.py'),checks=['real original/reserialized336 generation preserved and full7 exact','append/readback/fsync works while new HOME inode creation raises E28','only one persistent file; duplicate idempotent, collision rejected','full scanner rejects truncated frame and corrupt payload','all original seed/source bytes unchanged'],scope='OriginalJN runner zero-step resume-save on copied KG successful336 only. Pure persistence regression, no physical/year/scientific/K78 acceptance.')
(r/'check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=['qia3803-jacobian-analysis-d','qia3803-physical-analysis-e']
for n in roots:
    r=b/n;assert (r/'pbs-exit.txt').read_text().strip()=='0'
    d=json.loads((r/'analysis.json').read_text());assert d['node'].startswith('compute')
a=b/'qia3803-analysis-de-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for n in roots:
        for p in sorted((b/n).rglob('*')):
            if p.is_file():t.add(p,arcname=n+'/'+p.relative_to(b/n).as_posix(),recursive=False)
    for n in ['dispatch_qia3803_jacobian_analysis_d.py','dispatch_qia3803_physical_analysis_e.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    for n,h in [('qia3803-trace-device-d-evidence.tar.gz','369e26431176bec9146ea92be5741a5afedd291243cfb3a87765fb94c969af4b'),('qia3803-probe-device-e-evidence.tar.gz','2517483faffb170ec450d775f3ab9db4915c122da35a52f775a40d3a516a4b01')]:
        assert sha(b/n)==h;t.add(b/n,arcname='input/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

from pathlib import Path
import hashlib,io,json,os,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-jacobian-analysis-d';a=b/'qia3803-trace-device-d-evidence.tar.gz';sha=lambda raw:hashlib.sha256(raw).hexdigest();start=time.monotonic()
with tarfile.open(a) as t:
    d=json.load(t.extractfile('receipt.json'));e=json.load(t.extractfile('exit.json'));raw=t.extractfile('trace-and-raw.npz').read()
assert d['source_unchanged'] and d['original_raw_byte_exact'] and d['instrumented_raw_byte_exact'] and d['device_barrier_complete'] and e['returncode']==0 and sha(raw)==d['payload_sha256']
with np.load(io.BytesIO(raw),allow_pickle=False) as z:
    assert z['original_raw'].tobytes()==z['instrumented_raw'].tobytes();trace=z['jacobian_trace'];baseline=z['original_raw']
valid=trace[np.isfinite(trace[:,220])];assert len(valid)==100
def clean(v):
    if isinstance(v,np.ndarray):return clean(v.tolist())
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
    if isinstance(v,(float,np.floating)):return float(v) if np.isfinite(v) else None
    if isinstance(v,np.integer):return int(v)
    return v
rows=[];weights=np.r_[np.full(10,20.),5.,5.]
for number,one in enumerate(valid):
    x=one[:12].astype(float);res=one[12:24].astype(float);jac=one[34:178].reshape(12,12).astype(float);direction=one[178:190].astype(float);scaled=one[191:203].astype(float);chosen=one[205:217].astype(float)
    singular=np.linalg.svd(jac,compute_uv=False);condition=float(singular[0]/singular[-1]) if singular[-1]>0. else float('inf')
    failure=None
    try:independent=np.linalg.solve(jac,-res)
    except np.linalg.LinAlgError as error:failure=str(error);independent=np.linalg.lstsq(jac,-res,rcond=None)[0]
    linear=jac@direction+res;independent_linear=jac@independent+res
    changed=np.flatnonzero(chosen!=x).tolist();movement=chosen-x
    row=dict(iteration=int(one[220]),maximum_original_residual=float(abs(res).max()),norm=float(one[203]),chosen_norm=float(one[204]),global_scale=float(one[190]),condition=condition,singular_values=singular.tolist(),jacobian_column_maximum=abs(jac).max(0).tolist(),
        represented_changed_coordinates=changed,represented_delta=movement.tolist(),actual_backtrack_fractions=np.divide(movement,scaled,out=np.full_like(movement,np.nan),where=scaled!=0.).tolist(),
        raw_direction=direction.tolist(),scaled_direction=scaled.tolist(),independent_double_solve_direction=independent.tolist(),independent_solve_failure=failure,
        maximum_linear_system_residual_of_gpu_direction=float(abs(linear).max()),maximum_linear_system_residual_of_independent_direction=float(abs(independent_linear).max()),
        phase_active=one[24:34].tolist(),current=x.tolist(),residual=res.tolist(),chosen=chosen.tolist(),accepted=float(one[217]),retry=float(one[218]),restarts=float(one[219]))
    if number+1<len(valid):row.update(chosen_equals_next_state=bool(np.array_equal(one[205:217],valid[number+1,:12])),next_actual_norm=float(np.dot(valid[number+1,12:24].astype(float),valid[number+1,12:24].astype(float))))
    if number in [0,1,2,5,10,20,50,90,95,96,97,98,99]:rows.append(row)
record=clean(dict(scope='EHPC compute-only independent linear algebra and represented-step audit of exact raw741-preserving519H3803 GPU trace. No model candidate, no acceptance/precision/tolerance change. Double solve diagnoses captured Jacobian only, not an independent full nonlinear physical solution.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,input_archive_sha256=sha(a.read_bytes()),original_payload_sha256=d['payload_sha256'],source_manifest_sha256=d['source_manifest_sha256'],rows=len(valid),selected_rows=rows,last_jacobian=valid[-1,34:178].reshape(12,12),original_final_phase_coordinate=baseline[0,441+275:441+285],seconds=time.monotonic()-start))
(r/'analysis.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(rows=len(valid),tail=record['selected_rows'][-2:]),allow_nan=False),flush=True)

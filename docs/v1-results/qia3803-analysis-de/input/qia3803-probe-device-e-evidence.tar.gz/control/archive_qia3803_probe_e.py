from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia3803-probe-device-e';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((r/'exit.json').read_text());d=json.loads((r/'receipt.json').read_text());assert e['returncode']==0 and e['receipt_sha256']==sha(r/'receipt.json') and d['source_unchanged'] and d['device_barrier_complete'] and sha(r/'trace-and-raw.npz')==d['payload_sha256']
source=b/'qia1110-final-h-source.tar.gz';assert sha(source)=='ffa30e87bc515d0694c9135c8b77d14286112e6da2cf7f4ef6467417319132a0'
a=b/'qia3803-probe-device-e-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    for n in ['probe_qia3803_device_e.py','control_qia3803_probe_e.py','launch_qia3803_probe_e.py',Path(__file__).name]:t.add(b/n,arcname='control/'+n,recursive=False)
    t.add(source,arcname='source/'+source.name,recursive=False)
    for n in ['failed-surface.npz','leaf-parameters.json','receipt.json']:t.add(b/'qia-cuda-3803-a/surface-capture-a'/n,arcname='original-capture/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,instrumented_raw_byte_exact=d['instrumented_raw_byte_exact'])))

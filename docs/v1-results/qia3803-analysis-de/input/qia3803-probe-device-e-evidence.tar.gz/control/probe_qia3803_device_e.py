from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
b=Path('/home/lhwang/work/noahmp-v1');s=b/'qia1110-final-h';r=b/'qia3803-probe-device-e';old=b/'qia-cuda-3803-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==519 and all(sha(s/n)==h for n,h in m.items())
cap=json.loads((old/'surface-capture-a/receipt.json').read_text());path=old/'surface-capture-a/failed-surface.npz';assert sha(path)==cap['failed_surface_sha256']
with np.load(path,allow_pickle=False) as z:packet=dict(z)
sys.path[:0]=[str(s),str(s/'src'),str(s/'benchmarks')]
import cupy as cp
import noahmp_clm.gpu.cuda.canopy_phase_surface as module
from noahmp_clm.physics.photosynthesis import LeafParameters
args=tuple(cp.asarray(packet['surface_a'+str(i)]) for i in range(9))
kwargs={k:cp.asarray(packet[k]) for k in ['exchange_extension','vic','stem_area'] if k in packet}
kwargs.update(parameters=LeafParameters(**json.loads((old/'surface-capture-a/leaf-parameters.json').read_text())),raise_on_failure=False)
raws=[];unpack=module.unpack_phase_surface
def observe(raw):raws.append(raw.copy());return unpack(raw)
module.unpack_phase_surface=observe;start=time.monotonic()
module.run_canopy_phase_surface_cuda(*args,**kwargs)
baseline=cp.asnumpy(raws[-1]);assert baseline.tobytes()==packet['raw'].tobytes()
names=('leaf_kernel.cu','radiation_kernel.cu','canopy_energy_kernel.cu','canopy_phase_energy_kernel.cu','enthalpy_kernel.cu','column_heat_kernel.cu','snow_mass_kernel.cu','snow_vapor_kernel.cu','snow_evolution_kernel.cu','soil_transport_kernel.cu','canopy_surface_kernel.cu','canopy_phase_surface_kernel.cu')
sources=[]
for name in names:
    text=Path(module.__file__).with_name(name).read_text()
    if name=='canopy_phase_energy_kernel.cu':
        marker='struct PhaseContext {';assert text.count(marker)==1;text=text.replace(marker,'extern "C" __device__ float physical_probe[13776];\n'+marker)
        marker='    out[291]=restarts;\n}';assert text.count(marker)==1
        text=text.replace(marker,"""    out[291]=restarts;
    const float offsets[16]={-1.f,-.25f,-.1f,-.05f,-.02f,-.005f,0.f,.005f,.02f,.05f,.1f,.25f,1.f,4.f,8.f,-8.f};
    for(int row=0;row<41;++row){
        float trial[12],rr[12],detail[300];for(int k=0;k<12;++k)trial[k]=x[k];
        if(row>=1&&row<=20){int layer=(row-1)/2,side=(row-1)%2;if(v.phase_active[layer])trial[layer]=side?plateau:0.f;}
        else if(row>=21&&row<=36)trial[4]+=offsets[row-21];
        else if(row>=37){const float dq[4]={-.001f,-.0001f,.0001f,.001f};trial[11]+=dq[row-37];}
        phase_evaluate(v,trial,rr,detail);
        for(int k=0;k<12;++k){physical_probe[row*336+k]=trial[k];physical_probe[row*336+12+k]=rr[k];}
        for(int k=0;k<300;++k)physical_probe[row*336+24+k]=detail[k];
        float t=detail[4],tc=t-273.15f,es=611.2f*expf((17.67f*tc)/(tc+243.5f));
        float ql=(.622f*es)/(v.u[2]-.378f*es);
        float esi=expf(((9.550426f-5723.265f/t)+3.53068f*logf(t))-.00728332f*t);
        float qi=(.622f*esi)/(v.u[2]-.378f*esi),m=v.c[8];
        float thermal=(m*4180.f)*trial[4];
        float frac=m>0.f?fminf(m,fmaxf(0.f,thermal/334000.f))/m:fminf(1.f,fmaxf(0.f,(trial[4]*4180.f)/334000.f));
        float sat=frac*ql+(1.f-frac)*qi,q=trial[11]*.001f;
        float fraction=sat>q?v.fw[4]:1.f,amount=v.b[4]*((v.vc[4]*fraction)*(sat-q));
        float vapor=fminf(fmaxf(amount,0.f),m)-fmaxf(-amount,0.f);
        float dqs=(ql-qi)*(4180.f/334000.f);
        float dv=amount<0.f?v.b[4]*(v.vc[4]*dqs):(amount<m?v.b[4]*((v.vc[4]*v.fw[4])*dqs):0.f);
        float deriv=-(((2.5e6f+334000.f*(1.f-frac))*dv-334000.f*vapor*(4180.f/334000.f))/v.b[4])-(m*4180.f)/v.b[4];
        float aux[12]={ql,qi,frac,sat,q,fraction,amount,dv,deriv,(2.5e6f*dv)/v.b[4],m,ca_dot(rr,rr,12)};
        for(int k=0;k<12;++k)physical_probe[row*336+324+k]=aux[k];
    }
}""")
    sources.append(text)
source='\n'.join(sources);(r/'diagnostic-kernel.cu').write_text(source)
name='run_canopy_phase_surface_stems';compiled=cp.RawModule(code=source,options=('--std=c++14','--fmad=false','--prec-div=false','--prec-sqrt=false'),name_expressions=(name,))
fn=compiled.get_function(name);original=module._kernel
def traced(extended=False,vic=False,stems=False,profiled=False):
    assert stems and not profiled
    return fn
module._kernel=traced
try:module.run_canopy_phase_surface_cuda(*args,**kwargs)
finally:module._kernel=original;module.unpack_phase_surface=unpack
pointer=compiled.get_global('physical_probe')
trace=cp.asnumpy(cp.ndarray((41,336),cp.float32,memptr=pointer));variant=cp.asnumpy(raws[-1]);same=variant.tobytes()==baseline.tobytes()
np.savez_compressed(r/'trace-and-raw.npz',original_raw=baseline,instrumented_raw=variant,physical_probe=trace)
cp.cuda.runtime.deviceSynchronize();unchanged=all(sha(s/n)==h for n,h in m.items());assert unchanged and sha(path)==cap['failed_surface_sha256']
d=dict(scope='Read-only private compilation of original519H rejected3803 surface. Original uninstrumented output first reproduced byte-exact. Physical residual probes run after the original solve at twenty exact phase edges, sixteen localphase offsets and four humidity offsets; include same-device saturation/vapour and conditional analytic plateau partials. No change to solve or original accepted/rejected outputs; interpretation requires all741 original fields exact. No production edit or annual advancement; atexit bypass only after barrier/durable receipt.',
    original_raw_byte_exact=True,instrumented_raw_byte_exact=same,source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(path),payload_sha256=sha(r/'trace-and-raw.npz'),compiled_diagnostic_source_sha256=sha(r/'diagnostic-kernel.cu'),device_barrier_complete=True,seconds=time.monotonic()-start)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);os._exit(0)

from pathlib import Path
import hashlib,json,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');r=b/'qia3803-probe-device-e';start=time.monotonic()
with (r/'worker.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'probe_qia3803_device_e.py')],stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid))+'\n');code=p.wait();receipt=r/'receipt.json'
d=dict(returncode=code,seconds=time.monotonic()-start,receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None)
(r/'exit.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);sys.exit(code)

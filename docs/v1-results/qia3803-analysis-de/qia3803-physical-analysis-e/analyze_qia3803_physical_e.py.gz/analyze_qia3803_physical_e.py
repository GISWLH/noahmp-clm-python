from pathlib import Path
import hashlib,io,json,os,tarfile,time
import numpy as np
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia3803-physical-analysis-e';a=b/'qia3803-probe-device-e-evidence.tar.gz';sha=lambda raw:hashlib.sha256(raw).hexdigest();start=time.monotonic()
with tarfile.open(a) as t:
    d=json.load(t.extractfile('receipt.json'));e=json.load(t.extractfile('exit.json'));raw=t.extractfile('trace-and-raw.npz').read();original=t.extractfile('original-capture/failed-surface.npz').read()
assert d['source_unchanged'] and d['original_raw_byte_exact'] and d['instrumented_raw_byte_exact'] and d['device_barrier_complete'] and e['returncode']==0 and sha(raw)==d['payload_sha256'] and sha(original)==d['input_sha256']
with np.load(io.BytesIO(raw),allow_pickle=False) as z:
    assert z['original_raw'].tobytes()==z['instrumented_raw'].tobytes();probe=z['physical_probe'].astype(float)
with np.load(io.BytesIO(original),allow_pickle=False) as z:packet=dict(z)
dt=float(packet['surface_a7'][0,0]);old_mass=packet['surface_a8'][0,:,0].astype(float)
aux_names=['qliq','qice','liquid_fraction','surface_saturation','canopy_humidity','wet_exchange_fraction','requested_vapor_kg_m2','analytic_vapor_derivative','analytic_leaf_residual_derivative','analytic_humidity_residual_derivative','old_mass_kg_m2','original_device_norm']
rows=[]
for number,one in enumerate(probe):
    rows.append(dict(row=number,phase4=float(one[4]),humidity_g_kg=float(one[11]),residual=one[12:24].tolist(),maximum_original_residual=float(abs(one[12:24]).max()),**dict(zip(aux_names,map(float,one[324:336]))),new_mass_kg_m2=float(one[24+195+4]),wet_evaporation_kg_m2_s=float(one[24+30+4])))
derivatives=[]
for lo,hi in [(26,28),(25,29),(24,30),(23,31),(22,32),(21,33)]:
    width=probe[hi,4]-probe[lo,4];value=(probe[hi,12:24]-probe[lo,12:24])/width
    derivatives.append(dict(actual_stencil_width=float(width),leaf4=float(value[4]),humidity=float(value[11]),all_residuals=value.tolist()))
reference_archive=b/'qia3803-numpy-guess-j-evidence.tar.gz';assert sha(reference_archive.read_bytes())=='611acb2fefb6bd9e8399a7fabfb1f6bb9d85a5a23c5cebdcda045960ef4938f5'
with tarfile.open(reference_archive) as t:
    original_ref=t.extractfile('qia3803-numpy-guess-j/fixed-from-gpu-stagnation-reference.npz').read()
with np.load(io.BytesIO(original_ref),allow_pickle=False) as z:
    reference={k:z[k].tolist() for k in ['phase_coordinates','leaf_temperature','canopy_humidity','solver_residual','wet_evaporation','h','le','iterations','max_solver_residual'] if k in z.files}
    reference['mass4_after_from_retained_vapor_budget_kg_m2']=float(old_mass[4]-dt*z['wet_evaporation'][4])
record=dict(scope='EHPC compute-only unchanged GPU nonlinear residual/conditional analytic phase-plateau probe audit; original741 exactly reproduced and unchanged. All41 candidates/local offsets retained, no accepted step or model edit. Original immutable NumPy323 root is a double-precision physical reference, not assumed byte-equivalent device arithmetic.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,input_archive_sha256=sha(a.read_bytes()),source_manifest_sha256=d['source_manifest_sha256'],dt=dt,all_probes=rows,finite_difference_stencils=derivatives,independent_numpy323_reference=reference,original_reference_archive_sha256=sha(reference_archive.read_bytes()),original_reference_payload_sha256=sha(original_ref),seconds=time.monotonic()-start)
(r/'analysis.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(selected=[rows[k] for k in [0,9,10,25,29,37,40]],finite_difference_stencils=derivatives,numpy_reference=reference),allow_nan=False),flush=True)

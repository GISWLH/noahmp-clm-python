"""EHPC integration: really read the original ON archive; no model predictions.

OO_OBSERVATION_ARCHIVE is required. Absence fails, never silently skips the
reference integration. Predictions below are explicitly synthetic constants.
"""
from dataclasses import replace
import math
import os
from pathlib import Path
import unittest
import numpy as np

from authority_oo import EvidenceError, FAMILIES, ON_SHA, authorities, canonical, digest, load_json
from reference_oo import freeze_reference, complete_calendar
from scorer_oo import _score_family_math, _score_four_math
from score_math_oo import InvalidScore, FLOORS, YEARS


class OriginalReferenceIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        name = os.environ.get('OO_OBSERVATION_ARCHIVE')
        if not name or not Path(name).is_file():
            raise RuntimeError('Actual original ON observation archive is mandatory for EHPC integration')
        cls.reference = freeze_reference(name)
        cls.by_year = {(cell.site, cell.year): cell for cell in cls.reference.cells}
        cls.predictions = {
            key: dict(time_start=cell.starts.copy(), time_end=cell.ends.copy(),
                      h_wm2=np.zeros(len(cell.starts)), le_wm2=np.zeros(len(cell.starts)),
                      nee_gc_m2=np.zeros(len(cell.starts))) for key, cell in cls.by_year.items()}

    def test_original_archive_twelve_cells_144_months_and_immutable_payloads(self):
        self.assertEqual(self.reference.reference_sha256, ON_SHA)
        on, _, _ = authorities()
        self.assertEqual(len(self.reference.cells), 12)
        self.assertEqual(sum(len(cell.checked_record()['months']) for cell in self.reference.cells), 144)
        for cell in self.reference.cells:
            self.assertFalse(cell.observed.flags.writeable)
            self.assertFalse(cell.starts.flags.writeable)
            row = cell.checked_record()
            self.assertEqual(digest(cell.observed.tobytes()), row['original_observation_payload_sha256'])
            self.assertEqual(row, next(r for r in on['cells'] if (r['site'], r['year'], r['product']) ==
                                      (cell.site, cell.year, cell.product)))
            self.assertIn(len(cell.starts), [17520, 17568])

    def test_cng2007_zero_qc0_january_april_is_retained_not_dropped(self):
        rows = [cell.checked_record() for cell in self.reference.cells if (cell.site, cell.year) == ('CN-Cng', 2007)]
        self.assertEqual(len(rows), 3)
        self.assertTrue(all(month['finite_own_qc0_samples'] == 0 for row in rows for month in row['months'][:4]))
        self.assertTrue(all(len(row['months']) == 12 for row in rows))

    def test_actual_on_reference_math_matches_independent_population_moment_identity(self):
        result = _score_four_math(self.reference, {name: self.predictions for name in FAMILIES})
        expected = []
        for cell in self.reference.cells:
            record = cell.checked_record()
            mean, std = record['statistics']['mean'], record['statistics']['population_std']
            # Independent analytic identity for a zero synthetic prediction:
            # E[(X-0)^2] = population variance + population mean squared.
            expected.append(math.hypot(std, mean) / max(std, FLOORS[cell.product]))
        oracle = math.fsum(expected) / 12
        self.assertAlmostEqual(result['loss'], oracle, places=12)
        self.assertTrue(result['test_only'])
        self.assertFalse(result['physical_candidate_evidence'])
        self.assertEqual(set(result['families']), set(FAMILIES))
        self.assertTrue(all(len(row['cells']) == 12 for row in result['families'].values()))
        self.assertIn('zero QC0', result['coverage_caveat'])

    def test_shifted_duplicate_missing_or_heldout_calendar_is_invalid(self):
        cell = self.by_year[('CN-Cng', 2008)]
        self.assertEqual(len(cell.starts), 17568)
        for starts, ends in [(cell.starts[:-1], cell.ends[:-1]), (cell.ends, cell.starts),
                              (np.roll(cell.starts, 1), cell.ends)]:
            with self.assertRaises(EvidenceError):
                complete_calendar(cell.site, cell.year, starts, ends)
        for site, year in [('CN-Cng', 2009), ('CN-Cha', 2003), ('CN-HaM', 2008), ('CN-Cng', 2008.0)]:
            with self.assertRaises(EvidenceError):
                complete_calendar(site, year, cell.starts, cell.ends)
        changed = dict(self.predictions)
        changed[('CN-Cng', 2008)] = dict(changed[('CN-Cng', 2008)], time_start=np.roll(cell.starts, 1))
        with self.assertRaises(InvalidScore):
            _score_family_math(self.reference, changed)

    def test_tampered_reference_mask_statistic_dtype_or_count_cannot_be_refrozen(self):
        cell = self.reference.cells[0]
        changed = cell.observed.copy()
        changed[0] = 999999.0
        for candidate in [replace(cell, observed=changed), replace(cell, observed=cell.observed.view('<i8')),
                          replace(cell, qc=np.zeros_like(cell.qc)), replace(cell, year=2009)]:
            with self.assertRaises(EvidenceError):
                replace(self.reference, cells=(candidate, *self.reference.cells[1:])).validate()
        with self.assertRaises(EvidenceError):
            replace(self.reference, cells=self.reference.cells[:-1]).validate()
        for field in ['mean', 'finite_own_qc0_samples']:
            record = load_json(cell.original_record_json)
            if field == 'mean':
                record['statistics']['mean'] += 1.0
            else:
                record[field] += 1
            candidate = replace(cell, original_record_json=canonical(record))
            with self.assertRaises(EvidenceError):
                replace(self.reference, cells=(candidate, *self.reference.cells[1:])).validate()

    def test_nonfinite_predictions_outside_qc0_still_invalidate_whole_year(self):
        for product, field in [('H_F_MDS', 'h_wm2'), ('LE_F_MDS', 'le_wm2'), ('NEE_VUT_REF', 'nee_gc_m2')]:
            cell = next(c for c in self.reference.cells if (c.site, c.year, c.product) == ('CN-Cng', 2007, product))
            self.assertFalse(bool(np.isfinite(cell.observed[0]) and cell.qc[0] == 0))
            changed = {key: dict(value) for key, value in self.predictions.items()}
            array = changed[('CN-Cng', 2007)][field].copy()
            array[0] = np.nan
            changed[('CN-Cng', 2007)][field] = array
            with self.assertRaises(InvalidScore):
                _score_family_math(self.reference, changed)

    def test_missing_training_year_or_product_never_renormalizes(self):
        for key in YEARS:
            changed = dict(self.predictions)
            del changed[key]
            with self.assertRaises(InvalidScore):
                _score_family_math(self.reference, changed)
        changed = {key: dict(value) for key, value in self.predictions.items()}
        del changed[YEARS[0]]['le_wm2']
        with self.assertRaises(InvalidScore):
            _score_family_math(self.reference, changed)
        changed = dict(self.predictions)
        changed[(YEARS[0][0], float(YEARS[0][1]))] = changed.pop(YEARS[0])
        with self.assertRaises(InvalidScore):
            _score_family_math(self.reference, changed)


if __name__ == '__main__':
    unittest.main()

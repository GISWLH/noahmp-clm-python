"""Read-only EHPC tests of actual closed PB short data; never a candidate score."""
from contextlib import contextmanager
from pathlib import Path
import copy
import hashlib
import io
import json
import os
import pickle
import socket
import sys
import tarfile
import tempfile
import unittest


def setUpModule():
    if not os.environ.get('PBS_JOBID') or socket.gethostname().split('.')[0] != 'compute002':
        raise RuntimeError('Read-only numerical tests require EHPC compute002 PBS')
    fixed = json.loads((Path(__file__).parent/'BINDINGS.json').read_bytes())
    for env, expected in fixed['dependency_manifests'].items():
        root = Path(os.environ[env])
        if hashlib.sha256((root/'CONTROLS_SHA256.json').read_bytes()).hexdigest() != expected:
            raise RuntimeError('Frozen dependency manifest differs')
        for name, digest in json.loads((root/'CONTROLS_SHA256.json').read_bytes()).items():
            if hashlib.sha256((root/name).read_bytes()).hexdigest() != digest:
                raise RuntimeError('Frozen dependency bytes differ: '+name)
        sys.path.insert(0, str(root))
    sys.path.insert(0, str(Path(__file__).parent))


class CPUScoreInputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import numpy as np
        import cpu_score_inputs as a
        import cpu_trace_budget as budget
        cls.a, cls.budget, cls.np = a, budget, np
        cls.fixed = json.loads((Path(__file__).parent/'BINDINGS.json').read_bytes())
        cls.runner = a.pb.load_runtime(Path(os.environ['CPU_SCORE_SOURCE']))
        cls.forbidden = []
        def forbid(*args, **kwargs):
            cls.forbidden.append(True)
            raise AssertionError('Read-only adapter tests cannot run physics')
        cls.runner.run = cls.runner.step_clm_enthalpy_column = forbid
        source = Path(os.environ['CPU_SCORE_PB_ARCHIVE'])
        if a.sha(source.read_bytes()) != cls.fixed['original_pb_archive_sha256']:
            raise RuntimeError('Original PB closed archive required')
        cls.tmp = tempfile.TemporaryDirectory(dir=os.environ['TMPDIR'])
        cls.root = Path(cls.tmp.name)
        with tarfile.open(source) as t:
            names = t.getnames()
            if len(names) != len(set(names)) or any(not m.isfile() for m in t):
                raise RuntimeError('Original PB archive layout')
            index = json.load(t.extractfile('INTEGRITY.json'))
            if set(index) != set(names)-{'INTEGRITY.json'}:
                raise RuntimeError('Original PB complete inventory')
            for name in names:
                raw = t.extractfile(name).read()
                if name != 'INTEGRITY.json' and a.sha(raw) != index[name]:
                    raise RuntimeError('Original PB archive member changed')
                target = cls.root/name
                target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        cls.current = cls.root/'attempt-1607/result/short-model-output'
        closure = json.loads((cls.root/'readonly-1612/result/receipt.json').read_bytes())
        qstat = (cls.root/'actual/manager/1612.manager/qstat.stdout.txt').read_bytes()
        zero = (cls.root/'actual/compute002/1612.manager/pbs-exit.txt').read_bytes()
        a.pb.terminal(qstat, zero, zero, '1612.manager')
        if not (closure['passed'] and closure['actual_original_physical_tendencies'] == 10 and
                closure['readonly_closure_tendency_calls'] == 0 and closure['original_pbs_exit'] == 1):
            raise RuntimeError('Original true PB closure scope')
        cls.rows = {}
        for name in ('cold', 'spinup-cycle', 'train1-cycle', 'train2-continue'):
            folder = cls.current/name
            rec = a.pb.read_json(folder/'receipt.json')
            report_raw = (folder/'trajectory/report.json').read_bytes()
            report = json.loads(report_raw)
            state_raw, saved, trace = a.pb._generation(cls.runner, folder/'trajectory', report, complete=True)
            cls.rows[name] = dict(root=str(folder), identity=rec['identity'],
                prediction=a._project_trace(trace, rec['identity'], full_year=False),
                verified=dict(trace=trace, saved=saved, state_raw=state_raw, report_raw=report_raw,
                    receipt_raw=(folder/'receipt.json').read_bytes(), chain_raw=(folder/'chain-state.json').read_bytes()))

    @classmethod
    def tearDownClass(cls):
        if cls.forbidden:
            raise AssertionError('A prohibited physical call was attempted')
        cls.tmp.cleanup()

    @contextmanager
    def rejects(self, pattern):
        with self.assertRaisesRegex(ValueError, pattern) as caught:
            yield
        print('CPU_SCORE_NEGATIVE '+json.dumps(dict(test=self.id(), error=str(caught.exception))), flush=True)

    def test_original_eight_intervals_projection_is_bitexact_without_unit_conversion(self):
        maximum = 0.0
        for row in self.rows.values():
            for key in self.a.PREDICTION_FIELDS:
                original = row['verified']['trace'][key]
                self.budget._exact(row['prediction'][key], original, 'Raw projection')
                if key not in ('time_start', 'time_end'):
                    maximum = max(maximum, float(self.np.max(abs(row['prediction'][key]-original))))
        print('CPU_SCORE_DIAGNOSTIC '+json.dumps(dict(test='projection', actual_recorded_intervals_read=8,
            field_arrays_exact=20, numeric_values_compared=24, maximum_absolute_difference=maximum,
            candidate_scores_computed=0, physical_tendencies_added=0)), flush=True)

    def test_actual_first_packets_agree_with_original_h_le_nee_trace(self):
        count, maximum = 0, 0.0
        for row in self.rows.values():
            root = Path(row['root'])
            for segment in sorted(root.glob('segment-*')):
                rec = self.a.pb.read_json(segment/'receipt.json')
                packet = pickle.loads((segment/'first-call.pkl').read_bytes())
                for key, original in [('h_wm2', 'h'), ('le_wm2', 'le'), ('nee_gc_m2', 'nee_gc_m2')]:
                    a = row['prediction'][key][rec['start_index']]
                    b = float(packet['diagnostics'][original])
                    self.assertEqual(float(a).hex(), b.hex())
                    maximum = max(maximum, abs(float(a)-b)); count += 1
        self.assertEqual(count, 15)
        print('CPU_SCORE_DIAGNOSTIC '+json.dumps(dict(test='original_first_packets', actual_fields_compared=count,
            maximum_absolute_difference=maximum, nee_positive_to_atmosphere=True, nee_unit='gC m-2 per actual interval')), flush=True)

    def test_original_all_step_cumulative_and_carbon_exchange_ledgers(self):
        results = {name: self.budget.audit_cpu_trace(self.runner, row['verified'], row['root'])
                   for name, row in self.rows.items()}
        self.assertTrue(all(r['intervals'] == 2 and r['original_nee_carbon_exchange_exact'] for r in results.values()))
        print('CPU_SCORE_DIAGNOSTIC '+json.dumps(dict(test='original_budgets', results=results,
            new_tolerance=False, model_calls_added=0)), flush=True)

    def test_original_train1_to_train2_retained_parent_is_exact(self):
        self.a._check_training_link(self.rows['train1-cycle'], self.rows['train2-continue'])

    def test_all23_candidates_keep16_years_and_all_four_families(self):
        candidate_order = self.a.registry()['candidate_order']
        self.assertEqual(len(candidate_order), 23)
        for candidate in candidate_order:
            layout = self.a.training_layout(candidate)
            self.assertEqual(len(layout), 16)
            self.assertEqual({r['family'] for r in layout}, set(self.a.FAMILIES))
            self.assertEqual({r['identity']['steps'] for r in layout}, {17520, 17568})
            self.assertEqual(sum(r['identity']['steps'] for r in layout), 280704)
            for r in layout:
                self.assertEqual(r['identity']['case'], r['case'])
                self.assertFalse(r['identity']['test_only'])

    def test_real_short_evidence_is_not_an_annual_prediction(self):
        row = self.rows['train1-cycle']
        with self.rejects('Short test evidence'):
            self.a._project_trace(row['verified']['trace'], row['identity'], full_year=True)
        fake = dict(row['identity'], test_only=False)
        with self.rejects('complete calendar year'):
            self.a._project_trace(row['verified']['trace'], fake, full_year=True)

    def test_original_f1_is_not_relabelled_by_later_readonly_f0(self):
        q = (self.root/'actual/manager/1607.manager/qstat.stdout.txt').read_bytes()
        one = (self.root/'actual/compute002/1607.manager/pbs-exit.txt').read_bytes()
        with self.rejects('Actual parent terminal'):
            self.a.pb.terminal(q, one, one, '1607.manager')
        later = (self.root/'actual/manager/1612.manager/qstat.stdout.txt').read_bytes()
        with self.rejects('PBS job mismatch'):
            self.a.pb.terminal(later, b'0', b'0', '1607.manager')

    def test_missing_roots_and_missing_year_are_invalid_before_source_loading(self):
        with self.rejects('All eight roots'):
            self.a.load_candidate_predictions('/not-used', '/not-used', 'om-baseline', {})
        cases = {r['case']: {'train1': {}, 'train2': {}} for r in self.a.training_layout('om-baseline')}
        del next(iter(cases.values()))['train2']
        with self.rejects('All eight roots'):
            self.a.load_candidate_predictions('/not-used', '/not-used', 'om-baseline', cases)

    def test_heldout_site_nonfinite_and_changed_scalar_layout_are_rejected(self):
        row = self.rows['cold']
        with self.rejects('training CPU identity'):
            self.a._project_trace(row['verified']['trace'], dict(row['identity'], site='CN-Cha'), full_year=False)
        for value in [self.np.array([self.np.nan, 0.]), self.np.zeros((2, 1))]:
            trace = dict(row['verified']['trace'], h_wm2=value)
            with self.rejects('Nonfinite/non-scalar'):
                self.a._project_trace(trace, row['identity'], full_year=False)

    def test_cumulative_residual_above_original_bound_is_rejected(self):
        row = self.rows['cold']; changed = copy.deepcopy(row['verified'])
        changed['trace']['cumulative_residual_m_h_c_n'][0, 0] = 1e6
        with self.rejects('Original cumulative budget failed'):
            self.budget.audit_cpu_trace(self.runner, changed, row['root'])

    def test_altered_final_ledger_and_nee_sign_are_rejected(self):
        row = self.rows['cold']; changed = copy.deepcopy(row['verified'])
        changed['saved'][3][0] = self.np.nextafter(changed['saved'][3][0], self.np.inf)
        with self.rejects('Trace/final carried ledger differs'):
            self.budget.audit_cpu_trace(self.runner, changed, row['root'])
        changed = copy.deepcopy(row['verified']); changed['trace']['nee_gc_m2'] *= -1
        with self.rejects('NEE/carbon exchange'):
            self.budget.audit_cpu_trace(self.runner, changed, row['root'])

    def test_train2_cannot_link_to_other_train1_receipt(self):
        first = dict(self.rows['train1-cycle']); first['verified'] = dict(first['verified'], receipt_raw=b'changed')
        with self.rejects('another train1'):
            self.a._check_training_link(first, self.rows['train2-continue'])

    def test_original_oo_production_score_remains_invalid_without_qualification(self):
        from scorer_oo import score_candidate
        result = score_candidate(None, None)
        self.assertFalse(result['candidate_valid']); self.assertFalse(result['production_scoring_enabled'])
        self.assertIsNone(result['loss']); self.assertTrue(result['reasons'])


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Original NumPy trajectories to OO input arrays; no loss or physics execution."""
from pathlib import Path
import io
import json
import pickle
import numpy as np

import own_spinup_pf as pf
from chain_contract_pb import calendar_summary, registry, request, require, sha
from authority_oo import FAMILIES
from reference_oo import complete_calendar
from score_math_oo import MODEL_FIELDS, YEARS
from cpu_trace_budget import _exact, audit_cpu_trace

pb = pf.adapter

PREDICTION_FIELDS = ('time_start', 'time_end', 'h_wm2', 'le_wm2', 'nee_gc_m2')




def _project_trace(trace, identity, *, full_year):
    """Identity-preserving projection; OO retains sole ownership of unit conversion."""
    require(type(full_year) is bool and type(identity['test_only']) is bool, 'Explicit calendar mode')
    require((identity['test_only'] is False) if full_year else (identity['test_only'] is True),
            'Short test evidence cannot become a complete training year')
    require(identity['backend'] == 'numpy64' and identity['site'] in ('CN-Cng', 'CN-Qia'), 'Original training CPU identity')
    require(set(PREDICTION_FIELDS) <= set(trace), 'Missing original OO prediction fields')
    info = calendar_summary(trace['time_start'], trace['time_end'], 1800, full_year=full_year)
    require(all(identity[k] == value for k, value in info.items()), 'Original trace/calendar identity')
    if full_year:
        require((identity['site'], identity['year']) in YEARS, 'Heldout or unknown training year')
        complete_calendar(identity['site'], identity['year'], trace['time_start'], trace['time_end'])
    for key in MODEL_FIELDS.values():
        value = trace[key]
        require(type(value) is np.ndarray and value.shape == (identity['steps'],) and
                value.dtype.kind == 'f' and np.isfinite(value).all(), 'Nonfinite/non-scalar complete model field: ' + key)
    # No rounding, casting, sign changes, dt division or observation-based filtering.
    projected = {key: trace[key].copy() for key in PREDICTION_FIELDS}
    for key in projected:
        _exact(projected[key], trace[key], 'Projection changed original field: ' + key)
    return projected






def training_layout(candidate):
    """Fixed23 candidates, eight case labels and sixteen actual annual identities."""
    rows = [r for r in registry()['configurations'] if r['candidate'] == candidate]
    require(len(rows) == 8 and len({r['case'] for r in rows}) == 8, 'Unknown candidate or incomplete eight roots')
    layout = []
    for row in rows:
        case = row['case']
        prefix = row['site']+'-'+str(row['first_year'])+'-'
        require(case.startswith(prefix) and case.endswith('-clim'), 'Original case naming')
        family = case[len(prefix):-len('-clim')]
        require(family in FAMILIES, 'Unknown original family')
        for phase in ('train1', 'train2'):
            identity = request(candidate, case, phase)
            layout.append(dict(case=case, phase=phase, family=family, identity=identity))
    require(len({(x['family'], x['identity']['site'], x['identity']['year']) for x in layout}) == 16,
            'Missing/repeated original family/site/year')
    return layout


def load_training_year(runner, assembly, candidate, case, phase, descriptor):
    """Complete actual CPU year only. A successful later audit cannot turn F1 into F0."""
    require(phase in ('train1', 'train2'), 'Only actual training phases')
    expected = request(candidate, case, phase)
    packet_root, root, inventory, terminals = pf.closed_packet(descriptor)
    receipt = pb.read_json(root/'receipt.json')
    actual = receipt['identity']
    require(actual == expected and actual['test_only'] is False, 'Whole original annual identity required; no short/test relabeling')
    require(receipt['pbs_job'] in terminals, 'Final actual worker terminal missing')
    terminal = {k: terminals[receipt['pbs_job']][k] for k in ('job', 'qstat', 'parent_exit', 'worker_exit')}
    result = pb.verify_parent(runner, root, expected, terminal)
    _, config, _ = pf.original_configuration(assembly, candidate, case)
    base = 'year-inputs/'+expected['site']+'-'+str(expected['year'])
    require(sha(assembly[base+'.npz']) == expected['forcing_npz_sha256'] and
            sha(assembly[base+'.json']) == expected['forcing_manifest_sha256'], 'Fixed OU input identity')
    with np.load(io.BytesIO(assembly[base+'.npz']), allow_pickle=False) as z:
        data = {key: z[key] for key in ('time_start', 'time_end')}
    report, trace = result['report'], result['trace']
    require(report['configuration'] == config and report['site'] == expected['site'] and
            report['time_convention'] == 'local standard time' and report['utc_offset_hours'] == 8,
            'Report/actual configuration/site/time semantics')
    for name in ('time_start', 'time_end'):
        _exact(trace[name], data[name], 'Original OU forcing/trace calendar')
    projected = _project_trace(trace, expected, full_year=True)
    budgets = audit_cpu_trace(runner, result, root)
    calls, segments = 0, []
    for segment in sorted(root.glob('segment-*')):
        rec = pb.read_json(segment/'receipt.json')
        require(rec['pbs_job'] in terminals and rec['identity'] == expected and rec['failure'] is None and
                rec['worker_completed'] is True and rec['source_unchanged'] is True and rec['first_start_exact'] is True,
                'Every original training segment needs actual F0 and successful state capture')
        require(type(rec['successful_tendency_calls']) is int and rec['successful_tendency_calls'] > 0 and
                rec['start_index'] == calls and rec['stop_index'] == calls+rec['successful_tendency_calls'],
                'Training segment sequence/call count differs')
        calls = rec['stop_index']
        for name, digest in pb.read_json(segment/'capture-SHA256.json').items():
            target = (segment/name).resolve()
            require(target.is_relative_to(segment.resolve()) and sha(target.read_bytes()) == digest, 'Training segment capture changed')
        before = pickle.loads((segment/'first-call-input.pkl').read_bytes())
        packet = pickle.loads((segment/'first-call.pkl').read_bytes())
        require(set(packet) == {'before', 'forcing', 'kwargs', 'after', 'diagnostics'}, 'Complete first original call required')
        pb.assert_content_exact(before, {key: packet[key] for key in before}, runner.np)
        for field, diagnostic in (('h_wm2', 'h'), ('le_wm2', 'le'), ('nee_gc_m2', 'nee_gc_m2')):
            require(float(projected[field][rec['start_index']]).hex() == float(packet['diagnostics'][diagnostic]).hex(),
                    'Original first-call diagnostic and projected trace differ: '+field)
        segments.append(dict(path=segment.relative_to(packet_root).as_posix(), job=rec['pbs_job'],
            receipt_sha256=sha((segment/'receipt.json').read_bytes()), calls=rec['successful_tendency_calls']))
    require(calls == expected['steps'] and set(terminals) == {r['job'] for r in segments}, 'Complete actual training segments required')
    context_raw = (root/'start-context.json').read_bytes()
    context = json.loads(context_raw)
    return dict(identity=expected, prediction=projected, budget_audit=budgets, verified=result,
        root=str(root), provenance=dict(receipt_sha256=sha(result['receipt_raw']),
        report_sha256=sha(result['report_raw']), checkpoint_sha256=sha(result['state_raw']),
        chain_sha256=sha(result['chain_raw']), trace_sha256=report['model_npz_sha256'],
        packet_inventory_sha256=descriptor['inventory_sha256'], start_context_sha256=sha(context_raw),
        retained_parent={key: context[key] for key in ('parent_checkpoint_sha256', 'parent_report_sha256',
            'parent_chain_sha256', 'parent_receipt_sha256', 'previous_ledger_steps', 'ledger_segments')},
        segments=segments, terminal=result['terminal']))


def _check_training_link(first, second):
    """The second year must retain this exact first year's original objects and receipts."""
    require(pb.transition(first['identity'], second['identity']) == 'continue', 'Consecutive original training years')
    root = Path(second['root'])/'parent-originals'
    for name, raw in [('parent-state.pkl', first['verified']['state_raw']),
                      ('parent-report.json', first['verified']['report_raw']),
                      ('parent-receipt.json', first['verified']['receipt_raw']),
                      ('parent-chain-state.json', first['verified']['chain_raw'])]:
        require((root/name).read_bytes() == raw, 'Train2 belongs to another train1: '+name)
    require(second['prediction']['time_start'][0] == first['prediction']['time_end'][-1], 'Real calendar discontinuity')


def load_candidate_predictions(source_root, assembly_archive, candidate, deliveries):
    """Data adapter, never a candidate score or initialization/eligibility assertion.

    deliveries[original_case]['train1'/'train2'] uses the same PF closed descriptor:
    {directory, inventory_sha256, run, terminals}; actual terminal bytes are in
    that complete original inventory. PA supplies original OU/OM input bytes.
    The downstream own-cycle validator must bind each train1 retained parent to
    its own final spinup cycle, scientific eligibility and fixed total budget.
    """
    layout = training_layout(candidate)
    cases = list(dict.fromkeys(row['case'] for row in layout))
    require(type(deliveries) is dict and set(deliveries) == set(cases) and
            all(type(v) is dict and set(v) == {'train1', 'train2'} for v in deliveries.values()),
            'All eight roots and both years are mandatory')
    runner = pb.load_runtime(source_root)
    initial_source = pb.verify_source(source_root)
    pf.verify_controls()
    assembly = pf.read_assembly(assembly_archive)
    values, evidence, rows = {family: {} for family in FAMILIES}, [], {}
    for item in layout:
        case, phase = item['case'], item['phase']
        row = load_training_year(runner, assembly, candidate, case, phase, deliveries[case][phase])
        rows[(case, phase)] = row
        identity = row['identity']
        values[item['family']][(identity['site'], identity['year'])] = row['prediction']
        evidence.append(dict(case=case, phase=phase, identity=identity, **row['provenance'], budget_audit=row['budget_audit']))
        if phase == 'train2':
            _check_training_link(rows[(case, 'train1')], row)
    require(all(set(v) == set(YEARS) for v in values.values()), 'All four site-years per family required')
    for case in cases:
        for descriptor in deliveries[case].values():
            pf.closed_packet(descriptor)
    pf.read_assembly(assembly_archive)
    require(pb.verify_source(source_root) == initial_source, 'Original NM source changed')
    return dict(candidate=candidate, backend='numpy64', predictions_by_family=values,
        training_year_evidence=evidence, loss=None, scored=False, score_eligible=False,
        scientific_acceptance_claim=False, coupled_column_steps_added=0, gpu_steps=0,
        qualification='This is authenticated training delivery only. Own-parameter initialization/spinup, all dry/wet roots and total budget remain separate mandatory gates; no caller flag enables scoring.')

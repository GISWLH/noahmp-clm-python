# Read-only NumPy training input adaptation

EHPC 1618.manager reached actual F0, Stageout0, worker0 and unittest parent0 on compute002. All 13 tests passed in 0.762 s; controller 1.1461950968950987 s.

The original PB evidence archive e0a7291f8b6fab86d48e3ce492d5a56fa97fdb832b1f76a92774c1f5708834e0 supplied four two-interval records (eight recorded intervals). Twenty original arrays and 24 numeric H/LE/NEE values projected exactly, with maximum absolute difference 0; five original first-call packets provided 15 additional field comparisons, also maximum difference 0. The unchanged sequential M/H/C/N bounds/maxima and NEE-to-carbon exchange ledger all match the original checkpoints. Actual residuals and original bounds for all four records are retained in current/diagnostics.json, without new tolerances.

All 13 expected rejection paths were exercised with actual exception text. The 23-candidate metadata keeps eight original roots, four families and sixteen annual identities per candidate. This count does not represent executed physical intervals. H/LE stay W m-2; NEE stays gC m-2 per actual interval, positive to the atmosphere. The original OO conversion, QC masks and loss mathematics are unchanged and no loss is computed.

PB1607 remains an actual F1 wrapper result after its successful physical child tests; PB1612 is the separate successful read-only closure. This adapter rejects using either to invent an actual F0 full-year worker. The short fixtures remain test-only. NM584 and all original inputs and dependency controls were checked unchanged before/after.

Added physical tendencies, decomposition/solver/GPU calls, candidate scores, raw observation arrays and complete training years are all 0. The adapter returns loss=null and score_eligible=false. Own-parameter initial states, genuine full spinup convergence, complete train1/train2 delivery and observance of the existing finite PF execution plan remain required before production scoring.

Original cumulative magnitudes and final carried bounds are in the order M/H/C/N (kg m-2, J m-2, gC m-2, gN m-2). These are stored numerical results from compute002, not newly calculated scores.

| Original short record | Maximum cumulative absolute residual | Original final global bounds |
|---|---|---|
| cold | [4.242266260501282e-15, 3.958120942115784e-09, 6.821392409261939e-13, 4.271969334269238e-14] | [7.048509346893287e-12, 2.15936456363887e-05, 7.844389057810115e-10, 6.857507526288983e-11] |
| spinup-cycle | [7.0811412289373266e-15, 6.810296326875687e-09, 5.246220124988099e-13, 5.719193564915348e-14] | [1.4096720654926187e-11, 4.3182456901377566e-05, 1.5688767194257596e-09, 1.3715016573323634e-10] |
| train1-cycle | [1.1907141939104804e-14, 5.529727786779404e-09, 3.489881994500621e-13, 1.4263129522948392e-13] | [2.114463439855041e-11, 6.47676508225999e-05, 2.353313450136436e-09, 2.0572527141103953e-10] |
| train2-continue | [7.716050021144838e-15, 3.2014213502407074e-09, 2.5780072521186526e-13, 1.1438387129830696e-13] | [2.81922510502514e-11, 8.634983289786234e-05, 3.13774910467858e-09, 2.7430039229629945e-10] |

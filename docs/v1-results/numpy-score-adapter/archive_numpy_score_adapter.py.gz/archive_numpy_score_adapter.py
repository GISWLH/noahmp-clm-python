"""Read-only collection after a real terminal job; no scheduler submission."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-numpy-score-adapter')
STAGE = Path('/tmp/numpy-score-adapter-stage.tar.gz')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def contents(raw):
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for member in archive:
            if member.isdir():
                continue
            name = member.name.removeprefix('./')
            assert member.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts and name not in files
            files[name] = archive.extractfile(member).read()
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', required=True)
    parser.add_argument('--stage-sha256', required=True)
    parser.add_argument('--label', default='numpy-score-adapter')
    args = parser.parse_args()
    assert socket.gethostname() == 'manager' and re.fullmatch(r'\d+\.manager', args.job)
    assert re.fullmatch(r'[a-z0-9-]+', args.label)
    dispatch = json.loads((ROOT/'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == args.job and dispatch['stage_archive_sha256'] == args.stage_sha256
    query = subprocess.run(['qstat', '-xf', args.job], capture_output=True)
    assert query.returncode == 0
    qstat = query.stdout.decode()
    assert qstat.splitlines()[0] == 'Job Id: '+args.job and re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', qstat, re.M).group(1))
    assert re.search(r'^\s*Stageout_status = 0\s*$', qstat, re.M)
    stage_raw = STAGE.read_bytes()
    assert sha(stage_raw) == args.stage_sha256
    stage = contents(stage_raw)
    index = json.loads(stage['stage-inventory.json'])
    assert set(index) == set(stage)-{'stage-inventory.json'}
    assert all(sha(stage[n]) == h == sha((ROOT/n).read_bytes()) for n,h in index.items())
    status = subprocess.run(['ssh', 'compute002', 'cat '+str(ROOT/'pbs-exit.txt')], capture_output=True)
    assert status.returncode == 0 and int(status.stdout.strip()) == code
    fetch = subprocess.run(['ssh', 'compute002', 'cat '+str(ROOT/'result.tar.gz')], capture_output=True)
    assert fetch.returncode == 0
    result = contents(fetch.stdout)
    receipt = json.loads(result['receipt.json'])
    assert int(result['worker-exit.txt'].strip()) == code
    assert receipt['pbs_job'] == args.job and receipt['node'] == 'compute002'
    zero_fields = ('decomposition_module_steps', 'coupled_column_steps', 'gpu_steps', 'solver_calls',
                   'candidate_scores_computed', 'complete_training_years_read', 'raw_observation_arrays_read')
    assert all(receipt[k] == 0 for k in zero_fields)
    if code == 0:
        assert receipt['passed'] and receipt['actual_test_count'] == 13
        assert receipt['test_parent_returncode'] == int(result['unittest-parent-exit.txt']) == 0
        assert receipt['test_timed_out'] is False
        statuses = json.loads(result['unittest-statuses.json'])
        assert len(statuses['statuses']) == 13 and all(value == 'ok' for _,value in statuses['statuses'])
        assert statuses['summary'] == [['13', str(receipt['actual_test_seconds'])]]
        assert receipt['source_before_after_584_exact'] and receipt['original_inputs_and_controls_unchanged']
        diagnostics = json.loads(result['diagnostics.json'])
        assert diagnostics['positive'] == receipt['positive_diagnostics']
        assert len(diagnostics['negative_errors']) == receipt['actual_negative_errors'] == 13
        for folder in ('preparation', 'execution', 'dependencies/pf', 'dependencies/oo'):
            manifest = json.loads(stage[folder+'/CONTROLS_SHA256.json'])
            assert receipt[folder.replace('/', '_')+'_manifest_sha256'] == sha(stage[folder+'/CONTROLS_SHA256.json'])
            for name in [*manifest, 'CONTROLS_SHA256.json']:
                assert result[folder+'/'+name] == stage[folder+'/'+name]
    artifacts = {'current/'+name: raw for name,raw in result.items()}
    artifacts.update({'original-stage-inventory.json':stage['stage-inventory.json'],
        'original-stage-binding.json':(json.dumps(dict(archive=STAGE.name, sha256=args.stage_sha256,
            bytes=len(stage_raw), members=len(stage)), indent=2)+'\n').encode(),
        'original-result-binding.json':(json.dumps(dict(archive='result.tar.gz',sha256=sha(fetch.stdout),
            bytes=len(fetch.stdout),files=len(result)), indent=2)+'\n').encode(),
        'actual-pbs-qstat.txt':query.stdout,'actual-pbs-qstat.stderr.txt':query.stderr,
        'pbs-exit.txt':status.stdout,'archive_numpy_score_adapter.py':Path(__file__).read_bytes()})
    for name in ('dispatch.json','qsub.stdout.txt','qsub.stderr.txt','qsub-actual-exit.json',
                 'compute-extract.stdout.txt','compute-extract.stderr.txt','compute-file-hashes.txt'):
        artifacts['manager/'+name]=(ROOT/name).read_bytes()
    log=ROOT/'pbs-output.log'
    artifacts['manager/pbs-output-presence.json']=(json.dumps(dict(path=str(log),exists=log.exists()))+'\n').encode()
    if log.exists():
        artifacts['manager/pbs-output.log']=log.read_bytes()
    if code == 0:
        artifacts['RESULTS.md']=(
            '# Read-only NumPy training input adaptation\n\n'
            f'EHPC {args.job} reached actual F0, Stageout0, worker0 and unittest parent0 on compute002. '
            f'All 13 tests passed in {receipt["actual_test_seconds"]} s; controller {receipt["seconds"]} s.\n\n'
            'The original PB evidence archive e0a7291f8b6fab86d48e3ce492d5a56fa97fdb832b1f76a92774c1f5708834e0 '
            'supplied four two-interval records (eight recorded intervals). Twenty original arrays and 24 numeric '
            'H/LE/NEE values projected exactly, with maximum absolute difference 0; five original first-call packets '
            'provided 15 additional field comparisons, also maximum difference 0. The unchanged sequential M/H/C/N '
            'bounds/maxima and NEE-to-carbon exchange ledger all match the original checkpoints. Actual residuals '
            'and original bounds for all four records are retained in current/diagnostics.json, without new tolerances.\n\n'
            'All 13 expected rejection paths were exercised with actual exception text. The 23-candidate metadata '
            'keeps eight original roots, four families and sixteen annual identities per candidate. This count '
            'does not represent executed physical intervals. H/LE stay W m-2; NEE stays gC m-2 per actual interval, '
            'positive to the atmosphere. The original OO conversion, QC masks and loss mathematics are unchanged '
            'and no loss is computed.\n\n'
            'PB1607 remains an actual F1 wrapper result after its successful physical child tests; PB1612 is '
            'the separate successful read-only closure. This adapter rejects using either to invent an actual '
            'F0 full-year worker. The short fixtures remain test-only. NM584 and all original inputs and '
            'dependency controls were checked unchanged before/after.\n\n'
            'Added physical tendencies, decomposition/solver/GPU calls, candidate scores, raw observation '
            'arrays and complete training years are all 0. The adapter returns loss=null and score_eligible=false. '
            'Own-parameter initial states, genuine full spinup convergence, complete train1/train2 delivery '
            'and observance of the existing finite PF execution plan remain required before production scoring.\n').encode()
        original_budgets = next(d for d in receipt['positive_diagnostics'] if d['test'] == 'original_budgets')['results']
        table = '\nOriginal cumulative magnitudes and final carried bounds are in the order M/H/C/N (kg m-2, J m-2, gC m-2, gN m-2). These are stored numerical results from compute002, not newly calculated scores.\n\n| Original short record | Maximum cumulative absolute residual | Original final global bounds |\n|---|---|---|\n'
        for name, row in original_budgets.items():
            table += '| '+name+' | '+json.dumps(row['maximum_cumulative_absolute_m_h_c_n'])+' | '+json.dumps(row['final_global_bounds_m_h_c_n'])+' |\n'
        artifacts['RESULTS.md'] += table.encode()
    artifacts['inventory.json']=(json.dumps({name:dict(sha256=sha(raw),bytes=len(raw))
        for name,raw in artifacts.items()},indent=2)+'\n').encode()
    dest=ROOT/(args.label+'-evidence.tar.gz')
    assert not dest.exists()
    with tarfile.open(dest,'w:gz') as tar:
        for name,raw in sorted(artifacts.items()):
            member=tarfile.TarInfo(name); member.size,member.mode=len(raw),0o644
            tar.addfile(member,io.BytesIO(raw))
    assert contents(dest.read_bytes()) == artifacts
    package=dict(label=args.label,archive=dest.name,sha256=sha(dest.read_bytes()),bytes=dest.stat().st_size,
        artifacts=len(artifacts),artifact_sha256={name:sha(raw) for name,raw in artifacts.items()},
        pbs_job=args.job,actual_pbs_state='F',actual_pbs_exit=code,actual_stageout_status=0,
        actual_worker_exit=int(result['worker-exit.txt']),passed=receipt['passed'],
        actual_unittest_count=receipt.get('actual_test_count'),actual_test_seconds=receipt.get('actual_test_seconds'),
        positive_diagnostics=receipt.get('positive_diagnostics'),actual_negative_errors=receipt.get('actual_negative_errors'),
        stage_archive_sha256=args.stage_sha256,result_archive_sha256=sha(fetch.stdout),
        **{key:receipt[key] for key in zero_fields},
        scope='Read-only CPU-to-original-OO input adapter: 13 tests of eight recorded intervals, original cumulative conservation bounds and explicit rejection paths. No new physics, loss, complete year or spinup acceptance.')
    (ROOT/(args.label+'-package.json')).write_text(json.dumps(package,indent=2)+'\n')
    print(json.dumps({key:value for key,value in package.items() if key!='artifact_sha256'}),flush=True)


if __name__ == '__main__':
    main()

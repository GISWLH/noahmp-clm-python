from pathlib import Path
from dataclasses import astuple
from datetime import datetime,timezone
import hashlib,inspect,json,sys,time,traceback
import numpy as np
import run_fluxnet_native as native
import noahmp_clm.gpu.canopy_most_surface as most
from noahmp_clm.physics.photosynthesis import LeafParameters
from noahmp_clm.physics.canopy_most import MOSTGeometry
from noahmp_clm.gpu.clm_bgc_column import pack_bgc_environment
from fluxnet_deposition import DepositionSchedule
root=Path.cwd();base=root.parent;original=base/'fluxnet-first-climate-cycle-20261017-j';folder=original/'cuda-day';source=native.ROOT;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in manifest.items());report=json.loads((folder/'batch.json').read_text())
assert report['status']=='failed' and report['steps_completed']>5472 and 'CUDA layered phase surface failed' in report['failure']
checkpoint=folder/report['checkpoint_file'];assert sha(checkpoint)==report['checkpoint_sha256']
with np.load(checkpoint,allow_pickle=False) as z:saved=dict(z)
index=report['steps_completed'];assert saved['index'].item()==index;cases=native.load_batch(original/'batch.json');dtype=np.float32
f=np.asarray([c['data']['forcing'][index] for c in cases],dtype);env=np.asarray([c['data']['environment'][index] for c in cases],dtype)
e,cal=pack_bgc_environment([native.calendar(c['stamps'][index],c['metadata'],c['config']['phenology'] is not None) for c in cases],dtype=dtype)
schedules=[DepositionSchedule(c['config']) for c in cases];nitrogen=np.asarray([s.nitrogen_rate for s in schedules],dtype)*f[:,0]
deposition=np.asarray([s.aerosol(c['stamps'][index],f[k,0]) for k,(c,s) in enumerate(zip(cases,schedules))],dtype)
geometry=np.asarray([astuple(MOSTGeometry(**c['config']['most_geometry'])) for c in cases],dtype)
leaf=LeafParameters(**cases[0]['config']['leaf_parameters']);engine=native.Backend('cuda32');cp=engine.xp
arrays=tuple(saved[f'a{k}'] for k in range(16));device=engine.update_forcing(tuple(cp.asarray(v) for v in arrays),env)
payload={f'a{k}':v for k,v in enumerate(arrays)};payload.update(forcing=f,forcing_environment=env,environment=e,calendar=cal,nitrogen=nitrogen,deposition=deposition,geometry=geometry)
np.savez_compressed(root/'whole-inputs.npz',**payload)

import math
import noahmp_clm.gpu.cuda.canopy_phase_surface as phase
real=phase.run_canopy_phase_surface_cuda;calls=0;captured=False
def host_tree(value):
    if isinstance(value,dict):return {k:host_tree(v) for k,v in value.items()}
    if isinstance(value,float):return value if math.isfinite(value) else repr(value)
    if isinstance(value,(bool,int,str)):return value
    if isinstance(value,(list,tuple)):return [host_tree(v) for v in value]
    return host_tree(cp.asnumpy(value).tolist())
def capture(*a,**kwargs):
    global calls,captured
    calls+=1
    try:return real(*a,**kwargs)
    except RuntimeError:
        payload={f'a{k}':cp.asnumpy(v) for k,v in enumerate(a)}
        for key in ['exchange_extension','vic']:
            if kwargs.get(key) is not None:payload[key]=cp.asnumpy(kwargs[key])
        np.savez_compressed(root/'failed-surface-inputs.npz',**payload)
        debug=real(*a,**{**kwargs,'raise_on_failure':False})
        (root/'failed-surface-output.json').write_text(json.dumps(host_tree(debug),indent=2,allow_nan=False)+'\n');captured=True
        raise
phase.run_canopy_phase_surface_cuda=capture;started=time.monotonic();failure=None;status='unexpected_success'
try:engine.step(*device,f,environment=e,calendar=cal,nitrogen_deposition_gn_m2=nitrogen,deposition=deposition,most_geometry=geometry,leaf_parameters=leaf,return_surface=True)
except Exception:status='reproduced_failure';failure=traceback.format_exc()
finally:phase.run_canopy_phase_surface_cuda=real
assert all(sha(source/k)==v for k,v in manifest.items())
result=dict(scope='Exact original failed J complete CUDA32 step; wrapper captures only failed surface arrays and recomputes that same surface once with diagnostic raising disabled. Invalid result never advances the column. No source/parameter/limit/tolerance edits.',status=status,failure=failure,index=index,node='xuanze',backend='cuda32',source_unchanged=True,original_checkpoint_sha256=sha(checkpoint),original_batch_sha256=sha(folder/'batch.json'),surface_calls=calls,failed_surface_captured=captured,seconds=time.monotonic()-started,cases=[dict(case=c['case'],local_time=c['stamps'][index].isoformat()) for c in cases],instrument_sha256=sha(__file__))
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
assert status=='reproduced_failure' and captured and 'CUDA layered phase surface failed' in failure

from pathlib import Path
import hashlib,json,tarfile
base=Path('/home/lhwang/work/noahmp-v1');root=base/'failure-j-phase-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((root/'summary.json').read_text());assert r['status']=='reproduced_failure' and r['index']==5498 and r['failed_surface_captured'] and r['source_unchanged']
names=['original-failure-binding.json','launch.json','replay.log','capture_j_phase_failure_a.py','summary.json','whole-inputs.npz','failed-surface-inputs.npz','failed-surface-output.json'];pairs=[(root/n,n) for n in names]+[(Path(__file__),Path(__file__).name)];archive=base/'j-phase-capture-a-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p,n in pairs:t.add(p,arcname=n,recursive=False)
print(json.dumps(dict(path=str(archive),sha256=sha(archive),files=len(pairs),whole_inputs_sha256=sha(root/'whole-inputs.npz'),failed_surface_inputs_sha256=sha(root/'failed-surface-inputs.npz'),seconds=r['seconds'])))

"""Fixed training-only original-observation statistics on an EHPC PBS node."""
from pathlib import Path
from datetime import datetime, timedelta, timezone
import ast
import calendar
import hashlib
import json
import os
import socket
import struct
import tarfile
import time
import traceback
import zipfile

ROOT = Path('/tmp/noahmp-fluxnet-training-reference-on')
ARCHIVE = Path('/home/zhangyq/noahmp-v1/multiyear-originals-fu.tar.gz')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def run():
    assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
    import numpy as np
    begun = time.monotonic()
    binding = json.loads((ROOT / 'INPUT_BINDINGS.json').read_text())
    assert {s: v['years'] for s, v in binding['training_sites'].items()} == {'CN-Cng': [2007, 2008], 'CN-Qia': [2003, 2004]}
    assert set(binding['products']) == {'H_F_MDS', 'LE_F_MDS', 'NEE_VUT_REF'}
    old_coverage = json.loads((ROOT / 'HM_TRAINING_COVERAGE.json').read_text())
    assert old_coverage['original_hm_receipt_sha256'] == binding['authority']['receipt_sha256']
    assert len(old_coverage['months']) == 48
    controls = json.loads((ROOT / 'CONTROLS_SHA256.json').read_text())
    assert all(sha((ROOT / n).read_bytes()) == h for n, h in controls.items())
    archive_before = sha(ARCHIVE.read_bytes())
    assert archive_before == binding['original_archive_sha256']
    scratch = Path(os.environ['TMPDIR']) / 'on-training-only'
    scratch.mkdir()
    result = dict(scope=binding['scope'], pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
        utc=datetime.now(timezone.utc).isoformat(), original_archive_sha256=archive_before,
        selection='isfinite(original observation) AND its own original QC == 0',
        statistics_population='Each full training site-year-product cell; population std uses ddof=0',
        empty_or_constant_policy='Keep every year/month; empty samples give null statistics; zero std remains zero. No substitute normalization.',
        carbon_conversion={'original_units': 'umol CO2 m-2 s-1', 'gC_m2_s_per_original_unit': 12.0107e-6,
            'explanation': '1 umol CO2 contains 1e-6 mol carbon; multiply by 12.0107 gC/mol. No conversion applied to reported NEE.'},
        input_identities=[], cells=[])

    def prefix_array(path, name, expected_dtype, full_steps, training_steps):
        # Decode only the leading two original training years, never later observations.
        with zipfile.ZipFile(path) as z, z.open(name + '.npy') as member:
            assert member.read(6) == b'\x93NUMPY'
            version = tuple(member.read(2))
            assert version in [(1, 0), (2, 0)]
            width = 2 if version[0] == 1 else 4
            header_length = struct.unpack('<H' if width == 2 else '<I', member.read(width))[0]
            header = ast.literal_eval(member.read(header_length).decode('latin1'))
            assert header == {'descr': expected_dtype, 'fortran_order': False, 'shape': (full_steps,)}
            dtype = np.dtype(expected_dtype)
            raw = member.read(training_steps * dtype.itemsize)
            assert len(raw) == training_steps * dtype.itemsize
        values = np.frombuffer(raw, dtype=dtype)
        assert values.shape == (training_steps,)
        return values, sha(raw)

    def summarize(values, qc):
        finite = np.isfinite(values)
        qc_finite = np.isfinite(qc)
        eligible = finite & (qc == 0)
        chosen = values[eligible]
        n = int(chosen.size)
        statistics = dict(mean=None, population_std=None, minimum=None, maximum=None)
        if n:
            statistics = dict(mean=float(np.mean(chosen, dtype=np.float64)),
                population_std=float(np.std(chosen, ddof=0, dtype=np.float64)),
                minimum=float(np.min(chosen)), maximum=float(np.max(chosen)))
            assert all(np.isfinite(v) for v in statistics.values())
        return dict(total_samples=int(values.size), finite_observation_samples=int(finite.sum()),
            missing_observation_samples=int((~finite).sum()), own_qc0_samples=int((qc == 0).sum()),
            finite_own_qc0_samples=n, finite_own_qc_nonzero_samples=int((finite & qc_finite & (qc != 0)).sum()),
            finite_observation_missing_qc_samples=int((finite & ~qc_finite).sum()),
            qc0_missing_observation_samples=int((~finite & (qc == 0)).sum()),
            own_qc_missing_samples=int((~qc_finite).sum()),
            normalization_status='unmeasured' if n == 0 else ('zero_population_std' if statistics['population_std'] == 0 else 'positive_population_std'),
            statistics=statistics, finite_own_qc0_mask_sha256=sha(eligible.astype(np.uint8).tobytes()))

    with tarfile.open(ARCHIVE) as tf:
        names = tf.getnames()
        assert len(names) == len(set(names)) == 8
        for site, spec in binding['training_sites'].items():
            years = spec['years']
            assert len(years) == 2 and years[1] == years[0] + 1
            meta_raw = tf.extractfile(site + '.json').read()
            data_raw = tf.extractfile(site + '.npz').read()
            assert sha(meta_raw) == spec['manifest_sha256'] and sha(data_raw) == spec['npz_sha256']
            meta = json.loads(meta_raw)
            assert meta['prepared_npz_sha256'] == spec['npz_sha256']
            assert meta['start'] == str(years[0]) + '-01-01' and meta['dt_seconds'] == 1800.0
            assert meta['steps'] == spec['container_steps']
            (scratch / (site + '.json')).write_bytes(meta_raw)
            npz = scratch / (site + '.npz')
            npz.write_bytes(data_raw)
            del data_raw
            count = sum((366 if calendar.isleap(y) else 365) * 48 for y in years)
            assert count == 35088
            arrays, prefix_sha = {}, {}
            for name in ['time_start', 'time_end', *[p + f for f in binding['products'] for p in ['obs_', 'qc_']]]:
                dtype = '<U12' if name.startswith('time_') else '<f8'
                arrays[name], prefix_sha[name] = prefix_array(npz, name, dtype, meta['steps'], count)
            begin = datetime(years[0], 1, 1)
            for i in range(count):
                expected = begin + timedelta(seconds=1800 * i)
                assert arrays['time_start'][i] == expected.strftime('%Y%m%d%H%M')
                assert arrays['time_end'][i] == (expected + timedelta(seconds=1800)).strftime('%Y%m%d%H%M')
            result['input_identities'].append(dict(site=site, npz_sha256=spec['npz_sha256'],
                manifest_sha256=spec['manifest_sha256'], original_fluxnet_archive_sha256=meta['archive_sha256'],
                original_fluxnet_member=meta['member'], original_fluxnet_member_sha256=meta['member_sha256'],
                decoded_training_prefix_rows=count, original_container_rows=meta['steps'],
                decoded_npy_prefix_payload_sha256=prefix_sha, timezone=meta['timezone'], utc_offset_hours=meta['utc_offset_hours'],
                read_fields=list(arrays), predictions_read=False, decoded_later_observation_rows=0))
            offset = 0
            for year in years:
                steps = (366 if calendar.isleap(year) else 365) * 48
                part = slice(offset, offset + steps)
                times = arrays['time_start'][part]
                for field in binding['products']:
                    values, qc = arrays['obs_' + field][part], arrays['qc_' + field][part]
                    cell = dict(site=site, year=year, product=field, locked_role='training',
                        original_units=binding['products'][field]['units'], own_qc_field=field + '_QC',
                        original_record_start_inclusive=offset, original_record_stop_exclusive=offset + steps,
                        expected_calendar_samples=steps, calendar_complete=True,
                        first_time_start=str(times[0]), last_time_end=str(arrays['time_end'][part][-1]),
                        time_start_payload_sha256=sha(times.tobytes()),
                        original_observation_payload_sha256=sha(values.tobytes()), original_qc_payload_sha256=sha(qc.tobytes()),
                        **summarize(values, qc), months=[])
                    for month in range(1, 13):
                        selected = np.char.startswith(times, str(year) + str(month).zfill(2))
                        expected = calendar.monthrange(year, month)[1] * 48
                        assert int(selected.sum()) == expected
                        month_stats = dict(month=month, expected_calendar_samples=expected,
                            calendar_complete=True, **summarize(values[selected], qc[selected]))
                        old, = [r for r in old_coverage['months'] if (r['site'], r['year'], r['month']) == (site, year, month)]
                        assert old['calendar_month_complete'] and old['provided_intervals'] == old['expected_intervals'] == expected
                        old_product = old['products'][field]
                        for new_key, old_key in {
                            'finite_observation_samples': 'finite_reference_intervals',
                            'missing_observation_samples': 'missing_reference_intervals',
                            'finite_own_qc0_samples': 'finite_own_qc0_intervals',
                            'finite_own_qc_nonzero_samples': 'finite_own_qc_nonzero_intervals',
                            'finite_observation_missing_qc_samples': 'finite_reference_without_qc_intervals',
                            'qc0_missing_observation_samples': 'qc0_with_missing_reference_intervals',
                        }.items():
                            assert month_stats[new_key] == old_product[old_key], (site, year, month, field, new_key)
                        month_stats['original_HM831_coverage_reproduced_exactly'] = True
                        cell['months'].append(month_stats)
                    assert sum(m['total_samples'] for m in cell['months']) == steps
                    assert sum(m['finite_own_qc0_samples'] for m in cell['months']) == cell['finite_own_qc0_samples']
                    result['cells'].append(cell)
                offset += steps
            assert offset == count
            assert sha(npz.read_bytes()) == spec['npz_sha256']
    assert len(result['cells']) == 12 and sum(len(c['months']) for c in result['cells']) == 144
    archive_after = sha(ARCHIVE.read_bytes())
    assert archive_after == archive_before
    assert all(sha((ROOT / n).read_bytes()) == h for n, h in controls.items())
    result['source_inputs_unchanged'] = True
    result['seconds'] = time.monotonic() - begun
    out = ROOT / 'results/reference-scales.json'
    out.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(), passed=True,
        actual_statistics_delivered=True, source_inputs_unchanged=True, original_archive_sha256=archive_before,
        cells=12, months=144, training_site_years=4, reference_scales_sha256=sha(out.read_bytes()),
        controls_sha256=controls, seconds=result['seconds'], scope=binding['scope'])
    (ROOT / 'results/receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    try:
        run()
    except BaseException:
        failure = dict(pbs_job=os.environ.get('PBS_JOBID'), node=socket.gethostname(), passed=False,
            failure=traceback.format_exc(), scope='Failed read-only original training-reference statistics; no model or parameter selection.')
        (ROOT / 'results/failure.json').write_text(json.dumps(failure, indent=2) + '\n')
        raise

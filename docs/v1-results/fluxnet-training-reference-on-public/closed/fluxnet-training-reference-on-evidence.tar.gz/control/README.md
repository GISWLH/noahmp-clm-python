# ON：训练参考归一尺度的事前统计

固定原 24 年输入归档 SHA `6121548b05699356f5e6ece4560fe0d4ff37dfde6322ad22af4205212ff67f9c`，只解码 CN-Cng 2007/2008、CN-Qia 2003/2004 的 H_F_MDS、LE_F_MDS、NEE_VUT_REF 与各自原 QC。两站 NPZ/manifest 身份来自已实际 F0 的 HM831 原归档；不依赖尚未冻结的 OM 控制。计算不导入任何模型代码。

每站 NPZ 只解码前两个训练年的 35,088 行；全部时间戳逐条核对固定本地标准时，无 DST、1800 秒间隔。其后留出观测不解码；CN-Cha/CN-HaM 成员不提取，无任何预测文件入口。对原完整压缩归档/所选站 NPZ 做字节 SHA 核验不会读取或评价留出预测。

固定 12 个 site-year-product cell，统计子样本仅为 `isfinite(obs) & (own_QC == 0)`。每 cell 输出完整日历总数、有限观测数、QC0总数、有限且QC0数、非0/缺QC/缺观测交叉计数，QC0观测均值、population std（ddof=0）、min/max；全部 12 个月同样保留，包括无样本月。空样本统计为 null，std=0保持0，不补数据、不丢月、不回退到其它产品或自定尺度。

H/LE 单位 W/m²；NEE 保持原 µmol CO₂/m²/s，正负号原样。`12.0107e-6` 将该数值转为 gC/m²/s（每 µmol CO₂ 对应 1e−6 mol C）；本任务只说明系数，不转换统计值。结果只是拟固定等权 NRMSE 目标的参考尺度预审，不运行目标函数、不冻结/选择参数、不读取模型或留出预测。

接口：根审查后，将本目录所有控制原字节部署到 EHPC manager `/tmp/noahmp-fluxnet-training-reference-on`；执行 `python -B dispatch_reference_on.py`，控制会显式复制到 compute002 私有同名 `/tmp` 并 qsub。PBS 固定 compute002_00260924、1 CPU、2 GiB、10 分钟；仅所选两站原文件解包到 PBS TMPDIR。`reference-scales.json` 输出12 cell/144月和原输入/训练时间/obs/QC/mask SHA；`receipt.json` 绑定实际 PBS ID、节点、控制 SHA、源前后不变。真实 F0 后执行 `python -B archive_reference_on.py`，封存实际 qstat/worker0/数据/控制/输入绑定和通用 package。证据包引用原固定完整输入归档，不复制40MB原件。

Windows 只允许 AST/Ruff/元数据和字节核验。本目录准备完成不代表已 qsub；须先给根代理复核接口。

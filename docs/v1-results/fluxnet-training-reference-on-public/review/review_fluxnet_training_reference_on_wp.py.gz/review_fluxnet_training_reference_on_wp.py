"""Reproduce ON source/metadata checks; never decode arrays or recalculate stats."""
from pathlib import Path
import ast
import hashlib
import json
import re
import tarfile

B = Path(__file__).resolve().parent
P = B / 'fluxnet-training-reference-on-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda name: (P / name).read_bytes()
j = lambda name: json.loads(read(name))
m = j('CONTROLS_SHA256.json')
assert len(m) == 7 and sha(read('CONTROLS_SHA256.json')) == '11542acd6de7340e8d997b748215c67ddd67ac98d8d24a2e9f21d0884abe6402'
assert all(sha(read(n)) == h for n, h in m.items())
b, coverage = j('INPUT_BINDINGS.json'), j('HM_TRAINING_COVERAGE.json')
hm = B / b['authority']['archive']
assert sha(hm.read_bytes()) == b['authority']['archive_sha256']
with tarfile.open(hm) as archive:
    raw = archive.extractfile('current/receipt.json').read()
    receipt = json.loads(raw)
    assert sha(raw) == b['authority']['receipt_sha256'] == coverage['original_hm_receipt_sha256']
    qstat = archive.extractfile('current/actual-pbs-qstat.txt').read()
    assert sha(qstat) == b['authority']['actual_qstat_sha256']
    assert b'job_state = F' in qstat and b'Exit_status = 0' in qstat
    assert archive.extractfile('current/pbs-exit.txt').read().strip() == b'0'
assert receipt['pbs_job'] == '831.manager' and receipt['passed'] and receipt['source_unchanged']
assert receipt['original_archive_sha256'] == b['original_archive_sha256']
rows = [r for r in receipt['months'] if r['site'] in b['training_sites'] and r['year'] in b['training_sites'][r['site']]['years']]
assert len(rows) == len(coverage['months']) == 48
for row, actual in zip(rows, coverage['months']):
    assert dict(row, products={key: row['products'][key] for key in b['products']}) == actual
for site, item in b['training_sites'].items():
    original, = [r for r in receipt['site_identities'] if r['site'] == site]
    assert original['original_prepared_npz_sha256'] == item['npz_sha256']
    assert original['original_manifest_sha256'] == item['manifest_sha256']
    assert all(receipt['locked_splits'][site][str(year)] == 'training' for year in item['years'])
for name in m:
    if name.endswith('.py'):
        ast.parse(read(name))
worker = read('stats_reference_on.py').decode()
assert 'np.load(' not in worker and 'member.read(training_steps * dtype.itemsize)' in worker
assert 'ddof=0, dtype=np.float64' in worker

package = json.loads((B / 'fluxnet-training-reference-on-package.json').read_bytes())
path = B / package['archive']
assert sha(path.read_bytes()) == package['sha256'] == 'f57464a206b6a672762f33c583cf9d27dcc53b4dfb134b843e6316cc4df25a03'
assert path.stat().st_size == package['bytes'] == 31730
with tarfile.open(path) as archive:
    entries = archive.getmembers()
    assert len(entries) == len({v.name for v in entries}) == package['artifacts'] == 18
    files = {v.name: archive.extractfile(v).read() for v in entries}
inv = json.loads(files['artifact-inventory.json'])
assert len(inv) == 17 and set(inv) == set(files) - {'artifact-inventory.json'}
assert all(sha(files[n]) == v['sha256'] and len(files[n]) == v['bytes'] for n, v in inv.items())
assert all(files['control/' + n] == read(n) for n in [*m, 'CONTROLS_SHA256.json'])
qstat = files['actual-qstat.txt'].decode()
assert 'Job Id: 1597.manager' in qstat and re.search(r'job_state\s*=\s*F\b', qstat)
assert re.search(r'Exit_status\s*=\s*0\b', qstat) and files['result/pbs-exit.txt'].strip() == b'0'
r = json.loads(files['result/receipt.json'])
d = json.loads(files['manager/dispatch.json'])
scales = json.loads(files['result/reference-scales.json'])
assert r['pbs_job'] == d['pbs_job'] == scales['pbs_job'] == '1597.manager'
assert r['node'] == scales['node'] == 'compute002'
assert r['passed'] and r['actual_statistics_delivered'] and r['source_inputs_unchanged'] and scales['source_inputs_unchanged']
assert r['controls_sha256'] == d['controls_sha256'] == m
assert d['controls_manifest_sha256'] == sha(read('CONTROLS_SHA256.json'))
assert r['reference_scales_sha256'] == sha(files['result/reference-scales.json'])
assert r['original_archive_sha256'] == scales['original_archive_sha256'] == d['original_archive_sha256'] == b['original_archive_sha256']
assert r['cells'] == len(scales['cells']) == 12 and r['months'] == 144 and r['training_site_years'] == 4
expected = {(s, y, product) for s, spec in b['training_sites'].items() for y in spec['years'] for product in b['products']}
assert {(c['site'], c['year'], c['product']) for c in scales['cells']} == expected
for c in scales['cells']:
    assert c['locked_role'] == 'training' and c['calendar_complete'] is True
    assert c['original_units'] == b['products'][c['product']]['units']
    assert len(c['months']) == 12 and {v['month'] for v in c['months']} == set(range(1, 13))
    assert all(v['calendar_complete'] and v['original_HM831_coverage_reproduced_exactly'] for v in c['months'])
for site in scales['input_identities']:
    assert site['decoded_training_prefix_rows'] == 35088 and site['decoded_later_observation_rows'] == 0
    assert site['predictions_read'] is False
out = B / 'fluxnet-training-reference-on-actual-review-wp.json'
value = dict(scope='Stdlib byte/metadata/AST checks only, no physical array decode or statistics recomputation.',
    original_review_sha256=sha((B / 'fluxnet-training-reference-on-independent-review-wp.json').read_bytes()),
    archive_sha256=package['sha256'], members=18, inventory=17, actual_job='1597.manager', actual_state='F', actual_exit=0,
    controls_manifest_sha256=sha(read('CONTROLS_SHA256.json')), receipt_dispatch_controls_exact=True,
    original_HM_month_metadata_exact=48, result_cells=12, result_months=144,
    reference_scales_sha256=r['reference_scales_sha256'], seconds=r['seconds'],
    blocking_findings=[], verdict='0 blocking for publication of original training-only reference statistics; not objective freezing or calibration.')
out.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(review=str(out), sha256=sha(out.read_bytes()), verdict=value['verdict'])))

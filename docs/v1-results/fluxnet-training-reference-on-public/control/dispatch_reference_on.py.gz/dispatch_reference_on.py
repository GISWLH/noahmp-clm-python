"""Stage immutable controls in compute-private /tmp, then submit one PBS audit."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess

root = Path('/tmp/noahmp-fluxnet-training-reference-on')
assert os.uname().nodename == 'manager'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
controls = json.loads((root / 'CONTROLS_SHA256.json').read_text())
binding = json.loads((root / 'INPUT_BINDINGS.json').read_text())
assert all(sha(root / n) == h for n, h in controls.items())
assert sha(Path(binding['remote_archive'])) == binding['original_archive_sha256']
assert not (root / 'manager').exists()
code = "from pathlib import Path; p=Path(" + repr(str(root)) + "); assert not p.exists(); (p/'results').mkdir(parents=True)"
subprocess.run(['ssh', 'compute002', 'python3 -B -c ' + shlex.quote(code)], check=True)
subprocess.run(['scp', *[str(root / n) for n in [*controls, 'CONTROLS_SHA256.json']], 'compute002:' + str(root) + '/'], check=True)
code = "from pathlib import Path; import json,hashlib; r=Path(" + repr(str(root)) + "); c=json.loads((r/'CONTROLS_SHA256.json').read_text()); assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in c.items())"
subprocess.run(['ssh', 'compute002', 'python3 -B -c ' + shlex.quote(code)], check=True)
manager = root / 'manager'
manager.mkdir()
submitted = subprocess.run(['qsub', str(root / 'reference_on.pbs')], cwd=manager, capture_output=True, text=True)
(manager / 'qsub-stdout.txt').write_text(submitted.stdout)
(manager / 'qsub-stderr.txt').write_text(submitted.stderr)
assert submitted.returncode == 0, submitted.stderr
record = dict(pbs_job=submitted.stdout.strip(), original_archive_sha256=binding['original_archive_sha256'],
    controls_sha256=controls, controls_manifest_sha256=sha(root / 'CONTROLS_SHA256.json'), scope=binding['scope'])
(manager / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

"""Archive an actual closed training-reference audit and its immutable bindings."""
from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

root = Path('/tmp/noahmp-fluxnet-training-reference-on')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
controls = json.loads((root / 'CONTROLS_SHA256.json').read_text())
binding = json.loads((root / 'INPUT_BINDINGS.json').read_text())
assert all(sha((root / n).read_bytes()) == h for n, h in controls.items())
assert sha(Path(binding['remote_archive']).read_bytes()) == binding['original_archive_sha256']
dispatch = json.loads((root / 'manager/dispatch.json').read_text())
job = dispatch['pbs_job']
qstat = subprocess.check_output(['qstat', '-xf', job], text=True)
assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
closed = root / 'closed'
assert not closed.exists()
subprocess.run(['scp', '-r', 'compute002:' + str(root / 'results'), str(closed)], check=True)
assert (closed / 'pbs-exit.txt').read_text().strip() == '0'
receipt = json.loads((closed / 'receipt.json').read_text())
result = json.loads((closed / 'reference-scales.json').read_text())
assert receipt['passed'] and receipt['source_inputs_unchanged'] and receipt['node'] == 'compute002'
assert receipt['pbs_job'] == job and receipt['cells'] == 12 and receipt['months'] == 144
assert receipt['reference_scales_sha256'] == sha((closed / 'reference-scales.json').read_bytes())
assert result['original_archive_sha256'] == receipt['original_archive_sha256'] == binding['original_archive_sha256']
assert len(result['cells']) == 12 and all(len(c['months']) == 12 for c in result['cells'])
payload = {'actual-qstat.txt': qstat.encode()}
for directory, prefix in [(closed, 'result'), (root / 'manager', 'manager')]:
    for p in directory.rglob('*'):
        if p.is_file():
            assert not p.is_symlink()
            payload[prefix + '/' + p.relative_to(directory).as_posix()] = p.read_bytes()
for n in [*controls, 'CONTROLS_SHA256.json']:
    payload['control/' + n] = (root / n).read_bytes()
if (root / 'pbs-output.log').is_file():
    payload['scheduler-output.log'] = (root / 'pbs-output.log').read_bytes()
inventory = {n: dict(sha256=sha(raw), bytes=len(raw)) for n, raw in payload.items()}
payload['artifact-inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
archive = root / 'fluxnet-training-reference-on-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for n, raw in sorted(payload.items()):
        member = tarfile.TarInfo(n)
        member.size = len(raw)
        tf.addfile(member, io.BytesIO(raw))
with tarfile.open(archive) as tf:
    assert {m.name: tf.extractfile(m).read() for m in tf} == payload
package = dict(archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
    artifacts=len(payload), pbs_job=job, actual_pbs_state='F', actual_pbs_exit=0,
    original_archive_sha256=binding['original_archive_sha256'], scope=binding['scope'])
(root / 'fluxnet-training-reference-on-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tarfile,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'capacity-station-final-c';r=s/'target-c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();launch=json.loads((r/'launch.json').read_text())
while not (r/'cpu-ready.json').exists():time.sleep(30)
ticket=json.loads((r/'cpu-ready.json').read_text());archive=b/'capacity-station-cpu-c-evidence.tar.gz'
assert sha(archive)==ticket['archive_sha256']
with tarfile.open(archive) as tf:
    rec=json.load(tf.extractfile('receipt.json'));assert tf.extractfile('pbs-exit.txt').read().strip()==b'0'
    assert json.load(tf.extractfile('SOURCE_SHA256.json'))==json.loads((s/'SOURCE_SHA256.json').read_text())
    assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=1009,failures=0,errors=0,skipped=0)
    assert rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and rec['xml_sha256']==hashlib.sha256(tf.extractfile('cpu-full.xml').read()).hexdigest()
whole=b/'clm-capacity-final-f/full-bgc-f/exit.json'
while not whole.exists():
    assert Path('/proc/3802989').exists(),'Original capacity full3 parent missing without actual exit'
    time.sleep(30)
prerequisite=json.loads(whole.read_text());assert prerequisite['passed'] and prerequisite['returncode']==0
while True:
    free=int(subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    mem=dict(v.split(':',1) for v in Path('/proc/meminfo').read_text().splitlines())
    if free>8192 and int(mem['MemAvailable'].split()[0])>16*1024*1024:break
    time.sleep(30)
for name,h in launch['controls_sha256'].items():assert sha(b/name)==h
with (r/'targets-controller.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-u',str(b/'control_capacity_station_target_c.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'controller-worker.json').write_text(json.dumps(dict(pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=1,
    cpu_evidence_sha256=sha(archive),priorwhole_exit_sha256=sha(whole),scope='Actual535C native station3 execution after realEHPC1009 and oldFwhole3 actual0; not full1375/year/science acceptance.'),indent=2)+'\n')
code=p.wait();(r/'parent-exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
raise SystemExit(code)

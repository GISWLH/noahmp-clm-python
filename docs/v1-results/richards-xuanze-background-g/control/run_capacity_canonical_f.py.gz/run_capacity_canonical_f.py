from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

b = Path('/home/lhwang/work/noahmp-v1')
s = b / 'clm-capacity-final-f'
r = s / 'full-by-file-f'
r.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((s / 'SOURCE_SHA256.json').read_text())
begun = time.monotonic()

def verify():
    assert len(m) == 532 and all(sha(s / n) == v for n, v in m.items())

def nodes(raw):
    result = []
    for c in ET.fromstring(raw).iter('testcase'):
        assert all(c.find(k) is None for k in ['failure', 'error', 'skipped'])
        parts = c.attrib['classname'].split('.')
        where = [i for i, n in enumerate(parts) if n.startswith('test_')]
        assert len(where) == 1
        i = where[0]
        result.append('tests/' + parts[i] + '.py::' + '::'.join(parts[i+1:] + [c.attrib['name']]))
    assert len(result) == len(set(result))
    return set(result)

verify()
with (r / 'collection.log').open('x') as log:
    code = subprocess.run([sys.executable, '-u', str(b / 'collect_capacity_canonical_f.py')], cwd=s, stdout=log, stderr=subprocess.STDOUT).returncode
assert code == 0
collection = json.loads((r / 'collection.json').read_text())
allnodes = set(collection['nodes'])
assert len(allnodes) == 1344 and collection['source_unchanged'] and collection['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json')
gpu = {n for n in allnodes if Path(n.split('::')[0]).name.startswith(('test_gpu', 'test_jax', 'test_cuda'))}
cpu = allnodes - gpu
assert len(cpu) == 981 and len(gpu) == 363

archives={}
for label,digest in [('clm-capacity-cpu-f','e0a86665b5cf09e554bdc2660ef2919875efadc53ac14bdc647113989451dd65'),
                     ('clm-capacity-target20-f','ef100ab1f6978b5e654d5ab56e4096d0a68a2e4633c2dcf0e56d79bab91c1761')]:
    archive=b/(label+'-evidence.tar.gz');assert sha(archive)==digest
    with tarfile.open(archive) as t:archives[label]={v.name:t.extractfile(v).read() for v in t if v.isfile()}
a,g=archives['clm-capacity-cpu-f'],archives['clm-capacity-target20-f']
assert json.loads(a['SOURCE_SHA256.json'])==json.loads(g['SOURCE_SHA256.json'])==m
rec=json.loads(a['receipt.json'])
assert rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=981,failures=0,errors=0,skipped=0)
assert nodes(a['cpu-full.xml'])==cpu and hashlib.sha256(a['cpu-full.xml']).hexdigest()==rec['xml_sha256']
ex=json.loads(g['exit.json']);assert ex['passed'] and ex['returncode']==0 and ex['source_unchanged'] and ex['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json')
prefix=set();prefix_files=set()
for row in ex['results']:
    file='tests/'+row['file'];stem=Path(file).stem;rec=json.loads(g[stem+'-receipt.json'])
    expected={n for n in gpu if n.split('::')[0]==file};raw=g[stem+'.xml']
    assert row['passed'] and row['returncode']==rec['worker_exitcode']==rec['pytest_returncode']==0
    assert hashlib.sha256(g[stem+'-receipt.json']).hexdigest()==row['receipt_sha256']
    assert rec['passed'] and rec['source_unchanged'] and rec['node_coverage_exact'] and rec['all_setup_call_teardown_phases_passed']
    assert rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and rec['test_sha256']==m[file]
    assert nodes(raw)==expected and hashlib.sha256(raw).hexdigest()==rec['xml_sha256']
    assert not prefix&expected;prefix|=expected;prefix_files.add(file)
assert len(prefix)==20 and len(prefix_files)==3
w=s/'full-bgc-f';rec=json.loads((w/'receipt.json').read_text());ex=json.loads((w/'exit.json').read_text())
file='tests/test_gpu_clm_capacity_column.py';whole={n for n in gpu if n.split('::')[0]==file}
assert len(whole)==3 and ex['passed'] and ex['returncode']==rec['worker_exitcode']==rec['pytest_returncode']==0
assert ex['receipt_sha256']==sha(w/'receipt.json') and rec['passed'] and rec['source_unchanged']
assert rec['node_coverage_exact'] and rec['all_setup_call_teardown_phases_passed'] and rec['counts']==dict(tests=3,failures=0,errors=0,skipped=0)
assert rec['source_manifest_sha256']==sha(s/'SOURCE_SHA256.json') and rec['test_sha256']==m[file] and rec['xml_sha256']==sha(w/'targets.xml')
assert nodes((w/'targets.xml').read_bytes())==whole and not prefix&whole
prefix|=whole;prefix_files.add(file);covered=cpu|prefix
worker = b / 'gpu-worker-lifecycle-a/run_pytest_worker_a.py'
assert sha(worker) == '68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
pending = sorted({n.split('::')[0] for n in gpu} - prefix_files, key=lambda n: ('_column' in n or 'surface' in n, n))
scope = 'Frozen532F exactcanonical1344: EHPC981, component/layer/legacy20 and whole20/23-array3 actual0; remaining340GPU after actual511 and ownwhole3 exits. Original phases/barriers/raw1e-6/int/MHCN/atexit disclosure retained. No prior519H/518D/511/506 credit; not station/year/spinup/science acceptance.'
(r / 'selection.json').write_text(json.dumps(dict(scope=scope, collected_nodes=sorted(allnodes), cpu_nodes=981, gpu_nodes=363, same_source_gpu_prefix_nodes=sorted(prefix), pending_files=pending, source_manifest_sha256=sha(s / 'SOURCE_SHA256.json')), indent=2) + '\n')
results = []

def save(active=None):
    d = dict(scope=scope, status='running', covered_nodes=len(covered), covered_gpu_nodes=len(covered) - 981, collected_nodes=1344, active=active, results=results, seconds=time.monotonic() - begun)
    tmp = r / 'progress.json.tmp'
    tmp.write_text(json.dumps(d, indent=2) + '\n')
    os.replace(tmp, r / 'progress.json')

save()
for file in pending:
    verify()
    name = Path(file).stem
    expected = {n for n in gpu if n.split('::')[0] == file}
    expected_path = r / (name + '-expected.json')
    expected_path.write_text(json.dumps(sorted(Path(n.split('::')[0]).name + '::' + n.split('::', 1)[1] for n in expected), indent=2) + '\n')
    receipt_path, xml = r / (name + '-receipt.json'), r / (name + '.xml')
    start = time.monotonic()
    with (r / (name + '.log')).open('x') as log:
        p = subprocess.Popen([sys.executable, '-u', str(worker), '--source', str(s), '--test-file', str(s / file), '--expected', str(expected_path), '--receipt', str(receipt_path), '--xml', str(xml)], cwd=s, stdout=log, stderr=subprocess.STDOUT)
        save(dict(file=file, pid=p.pid))
        code = p.wait()
    row = dict(file=file, pid=p.pid, returncode=code, seconds=time.monotonic() - start, passed=False)
    if receipt_path.exists():
        rec = json.loads(receipt_path.read_text())
        row['receipt'] = rec
        if code == rec['worker_exitcode'] == rec['pytest_returncode'] == 0 and rec['passed'] and rec['source_unchanged'] and rec['source_manifest_sha256'] == sha(s / 'SOURCE_SHA256.json') and rec['test_sha256'] == m[file] and rec['xml_sha256'] == sha(xml) and nodes(xml.read_bytes()) == expected:
            row['passed'] = True
            covered.update(expected)
    results.append(row)
    save()
    print(json.dumps({k: v for k, v in row.items() if k != 'receipt'}), flush=True)
verify()
complete = covered == allnodes and all(x['passed'] for x in results)
(r / 'summary.json').write_text(json.dumps(dict(scope=scope, status='complete' if complete else 'failed', source_unchanged=True, collected_nodes=1344, covered_nodes=len(covered), all_node_coverage_exact=covered == allnodes, results=results, same_source_gpu_prefix_nodes=sorted(prefix), seconds=time.monotonic() - begun), indent=2) + '\n')
raise SystemExit(0 if complete else 1)

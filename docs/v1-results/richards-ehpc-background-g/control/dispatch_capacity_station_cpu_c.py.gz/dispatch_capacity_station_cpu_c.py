from pathlib import Path
import hashlib,json,subprocess
b=Path('/home/zhangyq/noahmp-v1');r=b/'capacity-station-cpu-c';assert not r.exists()
prior=b/'capacity-station-numpy-b';rec=json.loads((prior/'receipt.json').read_text())
assert (prior/'pbs-exit.txt').read_text().strip()=='0' and rec['returncode']==0 and rec['source_unchanged'] and rec['counts']==dict(tests=154,failures=0,errors=0,skipped=0)
assert rec['source_manifest_sha256']=='7a12144ab3efa992374cefc56cbf670a8139d49ec3b91933c99194de8569cd34'
r.mkdir();controls={}
for name in ['run_capacity_station_cpu_c.py','capacity_station_cpu_c.pbs','capacity-station-final-c-package.json']:
    raw=(b/name).read_bytes()
    if name.endswith(('.py','.pbs')):assert b'\r\n' not in raw
    (r/('package.json' if name.endswith('package.json') else name)).write_bytes(raw);controls[name]=hashlib.sha256(raw).hexdigest()
p=subprocess.run(['qsub',str(r/'capacity_station_cpu_c.pbs')],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr
(r/'dispatch.json').write_text(json.dumps(dict(pbs_job=p.stdout.strip(),controls_sha256=controls,scope='Actual NumPy154 prerequisite0; current535C completeCPU1009 submitted on PBS compute, not a result.'),indent=2)+'\n')
print(p.stdout.strip())

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'fresh-phase-edge-cpu-a';scratch=Path(os.environ['TMPDIR']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=json.loads((r/'package.json').read_text());roots={}
for label,name,digest in [('baseline','p6-most-physical-c-source.tar.gz','bbaedd27b61ec7754864667d960313ca552d575535dba30f000e59d91561c8fe'),('candidate','p6-fresh-phase-edge-a-source.tar.gz',package['archive_sha256'])]:
    a=b/name;assert sha(a)==digest;s=scratch/label;s.mkdir()
    with tarfile.open(a) as t:t.extractall(s,filter='data')
    m=json.loads((s/'SOURCE_SHA256.json').read_text());assert all(sha(s/n)==v for n,v in m.items());roots[label]=(s,m)
new,m=roots['candidate'];old,om=roots['baseline'];assert len(m)==510 and len(om)==509
assert sorted(n for n,v in m.items() if om.get(n)!=v)==sorted(package['changed'])
for n in ['tests/test_canopy_phase_energy.py','tests/fixtures/qia_182_phase_edge.json']:(old/n).write_bytes((new/n).read_bytes())
observed={n:sha(old/n) for n in m};(r/'baseline-observed-manifest.json').write_text(json.dumps(observed,indent=2)+'\n');(r/'SOURCE_SHA256.json').write_bytes((new/'SOURCE_SHA256.json').read_bytes())


def env(s):
    e=os.environ.copy();e.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');e.pop('NOAHMP_REQUIRE_GPU',None);return e


def run(label,s,manifest,files,expected,expected_failures=0):
    start=time.monotonic();xml=r/(label+'.xml')
    with (r/(label+'.log')).open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env(s),stdout=log,stderr=subprocess.STDOUT).returncode
    tree=ET.parse(xml).getroot();counts={k:sum(int(v.attrib[k]) for v in tree.iter('testsuite')) for k in ('tests','failures','errors','skipped')};unchanged=all(sha(s/n)==v for n,v in manifest.items())
    rec=dict(scope='Exact fresh-condensate phase-edge regression on original182,baseline failure retained and never counted as pass;candidate25 phase cases and fullCPU910,original physical equations/80/tolerances/independent budgets unchanged. Not GPU/year/science acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,label=label,returncode=code,counts=counts,expected_failures=expected_failures,source_files=len(manifest),source_unchanged=unchanged,seconds=time.monotonic()-start,xml_sha256=sha(xml))
    (r/(label+'-receipt.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
    assert code==(1 if expected_failures else 0) and unchanged and counts==dict(tests=expected,failures=expected_failures,errors=0,skipped=0)


node='tests/test_canopy_phase_energy.py::test_new_condensate_phase_edge_reaches_same_root_within_original_budget'
run('baseline-regression',old,observed,[node],1,1)
run('phase-target',new,m,['tests/test_canopy_phase_energy.py'],25)
for index in (163,182):
    with (r/('point'+str(index)+'-controller.log')).open('x') as log:code=subprocess.run([sys.executable,'-u',str(r/('probe_fresh_edge_'+str(index)+'_a.py'))],env=env(new),stdout=log,stderr=subprocess.STDOUT).returncode
    d=json.loads((r/('point'+str(index)+'-probe.json')).read_text());assert code==0 and d['failure'] is None and d['source_unchanged']
files=sorted(p.relative_to(new).as_posix() for p in (new/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
run('cpu-full',new,m,files,910)

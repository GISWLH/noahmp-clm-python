"""EHPC only: exact original182 boundary and quantized NumPy references."""
from pathlib import Path
from dataclasses import replace
import hashlib,json,os,sys,tarfile
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'qia182-device-input-a';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=b/'p6-fresh-phase-edge-a-source.tar.gz';assert sha(a)=='04a0e5976139f3ac8d9ceb9d73c205eb5550a5b5e4ad09d8d0e42440abdbf8a0'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==510 and all(sha(s/n)==v for n,v in m.items())
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests')]
import numpy as np
from test_canopy_phase_energy import saved_phase_call
from test_gpu_canopy_phase_energy import reference
from noahmp_clm.gpu.canopy_phase_energy import pack_canopy_phase
from noahmp_clm.gpu.photosynthesis import pack_leaf_parameters
from noahmp_clm.physics.photosynthesis import LeafParameters
saved=saved_phase_call('qia_182_phase_edge.json');args=saved['args'];kw=saved['kwargs'].copy();e=args[3];p=kw.pop('leaf_parameters')
assert vars(p)==vars(LeafParameters())
for key in ('tolerance','max_iterations'):kw.pop(key,None)
base=replace(e,atmosphere_water_velocity=None,potential_temperature=None)
packet={};runs=[]
for label,dtype in [('64',np.float64),('32',np.float32)]:
    row=pack_canopy_phase(*args[:3],base,*args[4:],dtype=dtype,**kw)
    ext=np.asarray([e.water_velocity,e.heat_temperature],dtype)
    result=reference(row,exchange_extension=ext,tolerance=1e-7,max_iterations=80)
    assert np.max(abs(result['solver_residual']))<=1e-7 and np.max(abs(result['layer_residual']))<=1.01e-7
    for i,v in enumerate(row):packet['a'+label+'_'+str(i)]=np.asarray(v)
    packet['extension'+label]=ext;packet['parameters'+label]=pack_leaf_parameters(p,dtype)
    for key in ('leaf_temperature','ground_temperature','canopy_temperature','h','le','gpp','ground_heat'):
        packet['reference'+label+'_'+key]=np.asarray(result[key])
    runs.append(dict(precision=label,iterations=result['iterations'],maximum_solver_residual=float(np.max(abs(result['solver_residual']))),h=result['h'],le=result['le'],gpp=result['gpp']))
np.savez_compressed(r/'input.npz',**packet)
assert all(sha(s/n)==v for n,v in m.items())
d=dict(scope='Actual original182 fixed MOST boundary packed with separate water velocity/potential temperature extension. Only packing resets their legacy aliases; actual physical extension preserved. NumPy references use same quantized inputs and default leaf parameters,originaltol1e-7/80,not GPU/science/year acceptance.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),input_sha256=sha(r/'input.npz'),fixture_sha256=sha(s/'tests/fixtures/qia_182_phase_edge.json'),runs=runs)
(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)

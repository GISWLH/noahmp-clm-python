from pathlib import Path
import hashlib,io,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');r=b/'fresh-phase-edge-cpu-b';a=b/'fresh-phase-edge-cpu-b-evidence.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((r/'cpu-full-receipt.json').read_text());assert d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=910,failures=0,errors=0,skipped=0) and (r/'pbs-exit.txt').read_text().strip()=='0'
assert sha(r/'cpu-full.xml')==d['xml_sha256']
for index in (163,182):assert json.loads((r/('point'+str(index)+'-probe.json')).read_text())['failure'] is None
with tarfile.open(a,'w:gz') as t:
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
    old=b/'fresh-phase-edge-cpu-a';assert (old/'pbs-exit.txt').read_text().strip()=='1'
    for p in sorted(old.rglob('*')):
        if p.is_file():t.add(p,arcname='prior-harness-a/'+p.relative_to(old).as_posix(),recursive=False)
    ref=b/'qia182-device-input-a';assert (ref/'pbs-exit.txt').read_text().strip()=='0'
    for p in sorted(ref.rglob('*')):
        if p.is_file():t.add(p,arcname='device-reference/'+p.relative_to(ref).as_posix(),recursive=False)
    with tarfile.open(b/'p6-fresh-phase-edge-a-source.tar.gz') as source:
        m=json.loads(source.extractfile('SOURCE_SHA256.json').read());assert len(m)==510 and m==json.loads((r/'SOURCE_SHA256.json').read_text())
        for n in ['src/noahmp_clm/physics/canopy_phase_energy.py','tests/test_canopy_phase_energy.py','tests/fixtures/qia_182_phase_edge.json']:
            raw=source.extractfile(n).read();assert hashlib.sha256(raw).hexdigest()==m[n];info=tarfile.TarInfo('source/'+n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Exact510 source fullCPU9100/phase250/original182+previous163 hardMHCN;baseline regression intentional1 retained. Prior222 overall1 was duplicate scratch directory in second replay,not physics failure;all artifacts retained. EHPC224 quantized NumPy refs included,no GPU/year/science pass.')))

from pathlib import Path
import ast
import gzip
import hashlib
import json
import re

root = Path(__file__).resolve().parents[2]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
group = 'ctsm-qia-daylength-uv-a'
base = root / 'docs/v1-results' / group
manifest = json.loads((base / 'manifest.json').read_text())
expected = '72ed39cdfdb5756bb8b82488d2e832d5a9e108a03c61aa81cf19b795f7afe116'
assert manifest['archive_sha256'] == sha((root / 'outputs/v1' / (group + '-evidence.tar.gz')).read_bytes()) == expected
python_files = 0
for item in manifest['artifacts']:
    stored = (base / item['path']).read_bytes(); assert sha(stored) == item['stored_sha256']
    raw = gzip.decompress(stored) if item['path'] == item['source'] + '.gz' else stored
    assert sha(raw) == item['source_sha256']
    if item['source'].endswith('.py'):
        ast.parse(raw.decode('utf-8-sig')); python_files += 1
source = json.loads(gzip.decompress((base / 'control/ctsm-qia-daylength-registration-a.json.gz').read_bytes()))
assert all('if (use_cn) then' in row['excerpt'] for row in source['source_matches'])
assert source['original_U_V']['ctsm-qia-run-v']['official_model_returncode'] == 233
for row in source['original_U_V']['ctsm-qia-run-v']['selected_logs'].values():
    assert not row['any_completed_timestep'] and not row['any_history_current_sample']
prior = json.loads((root / 'docs/v1-results/qia-physiology-3798-static-a.json').read_text())
assert prior['artifacts'] == 434 and prior['runtime_files_matching_frozen510'] == 497
ssh_path = root / 'outputs/v1/xuanze-ssh-metadata-a.json'
ssh = json.loads(ssh_path.read_text())
assert ssh['ssh_returncode'] is None and ssh['owned_metadata_client_timeout_seconds'] == 20.
assert any('Authenticated to ' in line for line in ssh['connection_stage_lines'])
for source_path, target in [(ssh_path, 'xuanze-ssh-metadata-a.json.gz'), (root / 'outputs/v1/probe_xuanze_ssh_metadata_a.py', 'xuanze-ssh-metadata-a.py.gz')]:
    (root / 'docs/v1-results' / target).write_bytes(gzip.compress(source_path.read_bytes(), mtime=0))
links = []
for name in ['docs/CLM_QIA3798_PHASE.md', 'docs/CLM_CTSM_PHYSIOLOGY_INPUTS.md']:
    p = root / name
    for link in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
        assert not link.startswith(('http:', 'https:'))
        assert (p.parent / link.split('#', 1)[0]).exists(), link
        links.append(dict(document=name, target=link))
result = dict(scope='Additional local raw/stored hash/AST/Markdown-link and persisted connection metadata audit only. No model/tests/scientific-array computation on local machine. DAYL unavailable in officialSP registration,not measured or source-modified;SSH publickey authentication succeeds but owned metadata client session times out,remote-model status not inferred. Earlier434-artifact audit remains immutable.',
              group=group, archive_sha256=expected, artifacts=len(manifest['artifacts']), python_artifacts_ast_checked=python_files,
              earlier_artifacts=prior['artifacts'], total_artifacts=prior['artifacts'] + len(manifest['artifacts']),
              new_document_links=links, probe_sha256=sha(ssh_path.read_bytes()), audit_control_sha256=sha(Path(__file__).read_bytes()))
(root / 'docs/v1-results/qia-daylength-closeout-static-b.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
(root / 'docs/v1-results/qia-daylength-closeout-static-b.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({k: v for k, v in result.items() if k != 'new_document_links'}))

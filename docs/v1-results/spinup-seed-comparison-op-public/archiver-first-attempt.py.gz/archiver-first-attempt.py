"""Archive closed OP PBS results, including failures, without rerunning anything."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

ROOT = Path('/tmp/noahmp-spinup-seed-comparison-op')
STAGE = Path('/tmp/spinup-seed-comparison-op-stage.tar.gz')
STAGE_SHA = '2f6b85d09905a1b76bd25e1b46201a82d2cc84feba43d2935afe3cabb2118c1e'
LABEL = 'spinup-seed-comparison-op'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def tar_bytes(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        result = {}
        for item in archive.getmembers():
            if item.isdir():
                continue
            name = item.name.removeprefix('./')
            assert item.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts
            assert name not in result
            result[name] = archive.extractfile(item).read()
        return result


def main():
    assert socket.gethostname() == 'manager'
    dispatch = json.loads((ROOT / 'dispatch.json').read_bytes())
    assert dispatch['pbs_job'] == '1598.manager' and dispatch['stage_archive_sha256'] == STAGE_SHA
    query = subprocess.run(['qstat', '-xf', dispatch['pbs_job']], capture_output=True)
    assert query.returncode == 0, query.stderr.decode()
    text = query.stdout.decode()
    assert re.search(r'^\s*job_state = F\s*$', text, re.M), text
    exit_code = int(re.search(r'^\s*Exit_status = (-?\d+)\s*$', text, re.M).group(1))
    stage_raw = STAGE.read_bytes()
    assert sha(stage_raw) == STAGE_SHA
    stage = tar_bytes(stage_raw)
    stage_index = json.loads(stage['stage-inventory.json'])
    assert set(stage_index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[name]) == digest for name, digest in stage_index.items())
    assert all(sha((ROOT / name).read_bytes()) == digest for name, digest in stage_index.items())
    compute_exit = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'pbs-exit.txt')], capture_output=True)
    assert compute_exit.returncode == 0
    assert int(compute_exit.stdout.strip()) == exit_code
    remote = subprocess.run(['ssh', 'compute002', 'cat ' + str(ROOT / 'result.tar.gz')], capture_output=True)
    assert remote.returncode == 0, remote.stderr.decode()
    result = tar_bytes(remote.stdout)
    assert int(result['worker-exit.txt'].strip()) == exit_code
    receipt = json.loads(result['receipt.json'])
    assert receipt['pbs_job'] == dispatch['pbs_job'] and receipt['node'] == 'compute002'
    assert receipt['model_steps'] == 0 and receipt['actual_endpoint_assessment_executed'] is False
    assert receipt['physical_model_arrays_decoded'] is False and receipt['synthetic_test_run'] is True
    if exit_code == 0:
        assert receipt['passed'] and receipt['unittest_parent_returncode'] == 0 and receipt['actual_unittest_count'] == 12
        assert receipt['source_files_byteverified'] == 584 and receipt['original_JR_members_byteverified'] == 34
        assert receipt['original_configuration_count'] == 12 and receipt['fixed_pair_count'] == 6
        assert receipt['preparation_and_source_unchanged']
        assert receipt['preparation_manifest_sha256'] == '2f411ba6fd9f50ef8f2b36701d1f9e7cec40b76877513b9b64648db5e3d5d51b'
        assert receipt['execution_manifest_sha256'] == sha(stage['execution/CONTROLS_SHA256.json'])
        assert receipt['root_review_sha256'] == sha(stage['root-review.json'])
        assert 'Ran 12 tests' in result['unittest.stderr.txt'].decode()
        assert '\nOK\n' in result['unittest.stderr.txt'].decode()
        for name in stage_index:
            if name.startswith(('preparation/', 'execution/')):
                assert result[name] == stage[name]
    artifacts = {'current/' + name: raw for name, raw in result.items()}
    artifacts.update({'original-stage.tar.gz': stage_raw, 'original-result.tar.gz': remote.stdout,
                      'actual-pbs-qstat.txt': query.stdout, 'actual-pbs-qstat.stderr.txt': query.stderr,
                      'pbs-exit.txt': compute_exit.stdout,
                      'archive_spinup_synthetic_op.py': Path(__file__).read_bytes()})
    for name in ['dispatch.json', 'qsub.stdout.txt', 'qsub.stderr.txt', 'compute-extract.stdout.txt',
                 'compute-extract.stderr.txt', 'compute-file-hashes.txt', 'pbs-output.log']:
        artifacts['manager/' + name] = (ROOT / name).read_bytes()
    inventory = {name: dict(sha256=sha(raw), bytes=len(raw)) for name, raw in artifacts.items()}
    artifacts['inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
    destination = ROOT / (LABEL + '-evidence.tar.gz')
    assert not destination.exists()
    with tarfile.open(destination, 'w:gz') as archive:
        for name, raw in sorted(artifacts.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    assert tar_bytes(destination.read_bytes()) == artifacts
    package = dict(archive=destination.name, sha256=sha(destination.read_bytes()), bytes=destination.stat().st_size,
                   artifacts=len(artifacts), pbs_job=dispatch['pbs_job'], actual_pbs_state='F', actual_pbs_exit=exit_code,
                   actual_worker_exit=int(result['worker-exit.txt'].strip()), passed=receipt['passed'],
                   stage_archive_sha256=STAGE_SHA, result_archive_sha256=sha(remote.stdout),
                   actual_unittest_count=receipt.get('actual_unittest_count'), model_steps=0,
                   actual_endpoint_assessment_executed=False,
                   scope='OP isolated synthetic identity and T/total-water/SWE threshold tests. Exact original NM584 source and JN-origin JR34 input archives retained as byte evidence. No model, real endpoint, cycle, spinup convergence or scientific acceptance.')
    (ROOT / (LABEL + '-package.json')).write_text(json.dumps(package, indent=2) + '\n')
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()

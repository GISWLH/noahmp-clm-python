"""Root's independent read-only review of the actually delivered OP run."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import re
import tarfile

root = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def untar(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        members = archive.getmembers()
        assert all(item.isfile() for item in members)
        assert len({item.name for item in members}) == len(members)
        for item in members:
            p = PurePosixPath(item.name)
            assert not p.is_absolute() and '..' not in p.parts
        return {item.name: archive.extractfile(item).read() for item in members}


package = json.loads((root / 'spinup-seed-comparison-op-package.json').read_bytes())
raw = (root / package['archive']).read_bytes()
assert sha(raw) == package['sha256'] == '7ee8abeda4c2612c987e24971a0d18b86b83f5fa06af48983b00cb0fdf104acf'
files = untar(raw)
assert len(files) == package['artifacts'] == 35
index = json.loads(files['inventory.json'])
assert set(index) == set(files) - {'inventory.json'}
assert all(sha(files[name]) == entry['sha256'] and len(files[name]) == entry['bytes']
           for name, entry in index.items())
receipt = json.loads(files['current/receipt.json'])
assert receipt['pbs_job'] == '1598.manager' and receipt['node'] == 'compute002'
assert receipt['passed'] is True and receipt['error'] is None
assert receipt['unittest_parent_returncode'] == 0
assert receipt['model_steps'] == 0 and receipt['physical_model_arrays_decoded'] is False
assert receipt['actual_endpoint_assessment_executed'] is False
qstat = files['actual-pbs-qstat.txt'].decode()
for pattern in (r'^Job Id: 1598\.manager\s*$', r'^\s*job_state = F\s*$',
                r'^\s*Exit_status = 0\s*$', r'^\s*Stageout_status = 0\s*$'):
    assert re.search(pattern, qstat, re.M), pattern
stage = untar(files['original-stage.tar.gz'])
assert sha(files['original-stage.tar.gz']) == package['stage_archive_sha256']
stage_index = json.loads(stage['stage-inventory.json'])
assert set(stage) == set(stage_index) | {'stage-inventory.json'}
assert all(sha(stage[name]) == value for name, value in stage_index.items())
assert sha(stage['preparation/CONTROLS_SHA256.json']) == '2f411ba6fd9f50ef8f2b36701d1f9e7cec40b76877513b9b64648db5e3d5d51b'
for folder in ('preparation', 'execution'):
    manifest = json.loads(stage[folder + '/CONTROLS_SHA256.json'])
    for name, value in manifest.items():
        assert sha(stage[folder + '/' + name]) == value
        assert stage[folder + '/' + name] == files['current/' + folder + '/' + name]
tests = stage['preparation/test_seed_pairs_op.py']
methods = [node.name for node in ast.walk(ast.parse(tests))
           if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
log = files['current/unittest.stderr.txt'].decode()
actual = re.findall(r'^(test_\w+) \(.*\) \.\.\. ok$', log, re.M)
assert len(methods) == len(actual) == 12 and set(methods) == set(actual)
assert re.search(r'Ran 12 tests in 0\.110s\s+OK\s*$', log)
result = untar(files['original-result.tar.gz'])
assert sha(files['original-result.tar.gz']) == package['result_archive_sha256']
assert all(files['current/' + name] == data for name, data in result.items())
summary = dict(passed=True, blocking_findings=[], archive_sha256=package['sha256'],
               artifacts=35, stage_members=len(stage), result_members=len(result),
               actual_job='1598.manager', actual_state='F', actual_exit=0, stageout_status=0,
               actual_test_names=actual, unittest_seconds=0.110, worker_seconds=receipt['seconds'],
               original_preparation_unchanged=True, model_steps=0,
               actual_endpoint_assessment_executed=False,
               review='Independent root stdlib byte/AST/log review; no numerical execution.',
               manual_review=[
                   'Worker executes only unittest with fixed preparation and original source/input byte verification.',
                   'T, total water and SWE threshold tests preserve original inclusive boundaries.',
                   'Cross-seed SOC differences remain stock diagnostics, not temporal drift or convergence.',
                   'Absent shell log is explicitly recorded; original controller/test logs and archive-attempt failure remain.',
               ])
output = root / 'spinup-seed-comparison-op-closed-root-review.json'
assert not output.exists()
output.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))

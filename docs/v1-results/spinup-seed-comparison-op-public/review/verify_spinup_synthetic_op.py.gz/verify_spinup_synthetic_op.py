"""Read-only standard-library verification of OP closed evidence, no arrays."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parent
LABEL = 'spinup-seed-comparison-op'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_tar(raw):
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        result = {}
        for item in archive.getmembers():
            if item.isdir():
                continue
            name = item.name.removeprefix('./')
            assert item.isfile() and name not in result
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            result[name] = archive.extractfile(item).read()
        return result


def main():
    package = json.loads((ROOT / (LABEL + '-package.json')).read_bytes())
    raw = (ROOT / package['archive']).read_bytes()
    assert sha(raw) == package['sha256'] and len(raw) == package['bytes']
    evidence = read_tar(raw)
    assert len(evidence) == package['artifacts']
    inventory = json.loads(evidence['inventory.json'])
    assert set(inventory) == set(evidence) - {'inventory.json'}
    assert all(sha(evidence[name]) == info['sha256'] and len(evidence[name]) == info['bytes'] for name, info in inventory.items())
    assert package['actual_pbs_state'] == 'F' and package['actual_pbs_exit'] == package['actual_worker_exit'] == 0
    qstat = evidence['actual-pbs-qstat.txt'].decode()
    assert 'Job Id: 1598.manager' in qstat
    assert re.search(r'^\s*job_state = F\s*$', qstat, re.M)
    assert re.search(r'^\s*Exit_status = 0\s*$', qstat, re.M)
    receipt = json.loads(evidence['current/receipt.json'])
    assert receipt['pbs_job'] == '1598.manager' and receipt['node'] == 'compute002'
    assert receipt['passed'] and receipt['unittest_parent_returncode'] == 0
    assert receipt['model_steps'] == 0 and receipt['actual_endpoint_assessment_executed'] is False
    assert receipt['physical_model_arrays_decoded'] is False and receipt['synthetic_test_run']
    tests = evidence['current/unittest.stderr.txt'].decode()
    assert 'Ran 12 tests' in tests and '\nOK\n' in tests
    assert len(re.findall(r'^test_.* \.\.\. ok$', tests, re.M)) == receipt['actual_unittest_count'] == 12
    assert sha(evidence['original-stage.tar.gz']) == package['stage_archive_sha256'] == '2f6b85d09905a1b76bd25e1b46201a82d2cc84feba43d2935afe3cabb2118c1e'
    assert sha(evidence['original-result.tar.gz']) == package['result_archive_sha256']
    result = read_tar(evidence['original-result.tar.gz'])
    assert all(evidence['current/' + name] == value for name, value in result.items())
    stage = read_tar(evidence['original-stage.tar.gz'])
    index = json.loads(stage['stage-inventory.json'])
    assert set(index) == set(stage) - {'stage-inventory.json'}
    assert all(sha(stage[name]) == digest for name, digest in index.items())
    for folder in ['preparation', 'execution']:
        manifest = json.loads(stage[folder + '/CONTROLS_SHA256.json'])
        assert all(sha(stage[folder + '/' + name]) == digest for name, digest in manifest.items())
        assert all(evidence['current/' + folder + '/' + name] == stage[folder + '/' + name] for name in [*manifest, 'CONTROLS_SHA256.json'])
    assert sha(stage['preparation/CONTROLS_SHA256.json']) == receipt['preparation_manifest_sha256']
    assert sha(stage['execution/CONTROLS_SHA256.json']) == receipt['execution_manifest_sha256']
    assert sha(stage['root-review.json']) == receipt['root_review_sha256']
    binding = json.loads(stage['preparation/BINDINGS.json'])
    model_raw = stage['inputs/climatology-final-candidate-nm-source.tar.gz']
    inputs_raw = stage['inputs/multisite-climatology-jr-inputs.tar.gz']
    assert sha(model_raw) == binding['model_source_archive_sha256']
    assert sha(inputs_raw) == binding['original_JR_archive_sha256']
    model = read_tar(model_raw)
    inputs = read_tar(inputs_raw)
    assert sha(model['SOURCE_SHA256.json']) == binding['model_source_manifest_sha256']
    model_index = json.loads(model['SOURCE_SHA256.json'])
    assert model_index == binding['model_source_members_sha256'] and len(model_index) == 584
    assert set(model) == set(model_index) | {'SOURCE_SHA256.json'}
    assert all(sha(model[name]) == digest for name, digest in model_index.items())
    assert len(inputs) == 34 and {name: sha(value) for name, value in inputs.items()} == binding['original_JR_members_sha256']
    dispatch = json.loads(evidence['manager/dispatch.json'])
    assert dispatch['source_stage_members'] == index and dispatch['pbs_job'] == receipt['pbs_job']
    assert dispatch['stage_archive_sha256'] == package['stage_archive_sha256']
    summary = dict(passed=True, blocking_findings=[], archive_sha256=package['sha256'], artifacts=len(evidence),
                   inventory_count=len(inventory), nested_stage_members=len(stage), nested_result_members=len(result),
                   original_source_files=584, original_JR_members=34, fixed_pairs=6, original_configurations=12,
                   pbs_job=receipt['pbs_job'], actual_state='F', actual_exit=0, tests=12,
                   unittest_seconds_from_original_log=0.110, worker_seconds=receipt['seconds'],
                   preparation_manifest_sha256=receipt['preparation_manifest_sha256'],
                   root_review_sha256=receipt['root_review_sha256'],
                   local_verification='stdlib tar/hash/JSON/text only; no numerical execution',
                   model_steps=0, actual_endpoint_assessment_executed=False,
                   scope=package['scope'])
    (ROOT / (LABEL + '-local-verification.json')).write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()

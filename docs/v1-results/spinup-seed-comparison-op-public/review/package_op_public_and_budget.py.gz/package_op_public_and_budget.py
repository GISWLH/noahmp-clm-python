"""Archive closed OP tests and the separate metadata-only workload review."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def publish(label, files, scope):
    assert 'artifact-inventory.json' not in files
    files['artifact-inventory.json'] = (json.dumps({name: dict(bytes=len(raw), sha256=sha(raw))
                                                   for name, raw in files.items()}, indent=2) + '\n').encode()
    target = root / (label + '-evidence.tar.gz')
    package_path = root / (label + '-package.json')
    assert not target.exists() and not package_path.exists()
    with tarfile.open(target, 'w:gz') as archive:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            archive.addfile(member, io.BytesIO(raw))
    package = dict(archive=target.name, sha256=sha(target.read_bytes()), artifacts=len(files), scope=scope)
    package_path.write_text(json.dumps(package, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(package))


old_package_raw = (root / 'spinup-seed-comparison-op-package.json').read_bytes()
old_package = json.loads(old_package_raw)
original = (root / old_package['archive']).read_bytes()
assert sha(original) == old_package['sha256']
with tarfile.open(fileobj=io.BytesIO(original)) as archive:
    members = archive.getmembers()
    assert len(members) == 35 and all(member.isfile() for member in members)
    files = {member.name: archive.extractfile(member).read() for member in members}
assert len(files) == 35
files['closed-original-package.json'] = old_package_raw
for name in ('review_spinup_synthetic_op_root.py', 'review_spinup_synthetic_op_root_attempt1.py',
             'spinup-seed-comparison-op-closed-root-review.json', 'verify_spinup_synthetic_op.py',
             'spinup-seed-comparison-op-local-verification.json', 'SPINUP_SEED_COMPARISON_OP_RESULTS.md',
             'package_op_public_and_budget.py'):
    files['review/' + name] = (root / name).read_bytes()
files['review/first-root-review-attempt.json'] = (json.dumps(dict(
    actual_exit=1, scope='Static archive reviewer, not model or unittest execution',
    failure='AssertionError at all(item.isfile() for item in members) while opening original-result.tar.gz',
    cause='The legitimate result tar also contains directory headers.',
    correction='Accept directory headers, continue rejecting special members and unsafe/duplicate paths; hash every file.',
    unchanged='Original evidence, stage, source, controls and actual successful test run were not modified.',
    provenance='Transcribed from the actual local exec tool result; not a redirected original process log.'
), indent=2) + '\n').encode()
review = json.loads(files['review/spinup-seed-comparison-op-closed-root-review.json'])
assert review['passed'] and review['blocking_findings'] == [] and review['actual_exit'] == 0
publish('spinup-seed-comparison-op-public', files,
        'EHPC1598 actual F0: 12 synthetic seed-comparison tests; original 35 artifacts plus independent root review. No real endpoints or spinup convergence.')

report = json.loads((root / 'CALIBRATION_EXECUTION_BUDGET_REVIEW.json').read_bytes())
assert report['actual_metadata']['candidates'] == 23
assert report['actual_metadata']['columns'] == len(report['configurations']) == 184
assert len(report['groups']) == 19 and sum(row['columns'] for row in report['groups']) == 184
assert report['grouping_status']['default_candidate_batches'] == 23
budget = report['budgets']['twenty_initial_plus_two_separate_training_years']
assert budget['column_years'] == 184 * 22 == 4048
assert budget['column_steps'] == 184 * (21 * 17520 + 17568) == 70929792
assert budget['batch_years_23_groups'] == 506 and budget['batch_years_19_groups'] == 418
assert report['budgets']['scientific_total_budget_frozen'] is False
assert report['production_or_existing_controls_changed'] is False and report['model_or_pbs_started'] is False
for row in report['source_files']:
    assert sha((root.parents[1] / row['path']).read_bytes()) == row['sha256']
assert report['code_sha256'] == sha((root / 'review_calibration_execution_budget_metadata.py').read_bytes())
items = {name: (root / name).read_bytes() for name in (
    'CALIBRATION_EXECUTION_BUDGET_REVIEW.md', 'CALIBRATION_EXECUTION_BUDGET_REVIEW.json',
    'review_calibration_execution_budget_metadata.py', 'package_op_public_and_budget.py')}
items['root-review.json'] = (json.dumps(dict(
    passed=True, blocking_findings=[], mode='Static metadata and source review; no numerical model execution.',
    original_report_sha256=sha(items['CALIBRATION_EXECUTION_BUDGET_REVIEW.md']),
    original_metadata_sha256=sha(items['CALIBRATION_EXECUTION_BUDGET_REVIEW.json']),
    checks=['Original native same-source/config/case-order carry requirement inspected.',
            '16-state shared leaf restriction and unique outer case labels inspected.',
            '23 groups default; 19 groups require new explicit transport identity adapter.',
            'Conditional 4048 column-years/70929792 column-steps arithmetic verified.',
            'New cold initialization is a research proposal, not an adopted state or observed spinup.',
            'N inventory and feedback limitations remain; existing checkpoints unchanged.']
), indent=2) + '\n').encode()
publish('calibration-execution-budget-review', items,
        'Read-only candidate grouping and conditional workload review; no candidate physics, adopted initialization, spinup, calibration or wall-time promise.')

"""Build OP execution wrappers/stage with stdlib byte and AST checks only."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
EXEC = ROOT / 'spinup-seed-comparison-op-execution'
PREP = ROOT / 'spinup-seed-comparison-op-preparation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, obj):
    path.write_bytes((json.dumps(obj, indent=2, allow_nan=False) + '\n').encode())


def main():
    EXEC.mkdir(exist_ok=True)
    review_raw = (ROOT / 'spinup-seed-comparison-op-root-review.json').read_bytes()
    review = json.loads(review_raw)
    assert review['passed'] and review['blocking_findings'] == []
    prep_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
    assert sha(prep_raw) == review['controls_manifest_sha256'] == '2f411ba6fd9f50ef8f2b36701d1f9e7cec40b76877513b9b64648db5e3d5d51b'
    prep_index = json.loads(prep_raw)
    assert len(prep_index) == 6
    assert all(sha((PREP / name).read_bytes()) == digest for name, digest in prep_index.items())
    origin = ROOT / 'fluxnet-calibration-om-execution'
    dispatcher = (origin / 'dispatch_metadata_om.py').read_text()
    for old, new in [
        ('OM metadata work', 'OP synthetic tests'),
        ('noahmp-fluxnet-calibration-om', 'noahmp-spinup-seed-comparison-op'),
        ('dispatch_metadata_om.py', 'dispatch_synthetic_op.py'),
        ('dispatch_fluxnet_calibration_om.py', 'dispatch_spinup_synthetic_op.py'),
        ('independent-review.json', 'root-review.json'),
        ('65c7a3ab5692bd3b296a621be5bdf09ff32ff4cc2b073764f14beac2e5ff77d7', sha(review_raw)),
        ("review['controls'] == 9", "review['controls'] == 6"),
        ('metadata_om.pbs', 'synthetic_op.pbs'),
        ('OM metadata only; no physics or calibration.', 'OP synthetic tests only; no actual endpoints or forward model.')]:
        assert old in dispatcher, old
        dispatcher = dispatcher.replace(old, new)
    (EXEC / 'dispatch_synthetic_op.py').write_bytes(dispatcher.encode())
    pbs = (origin / 'metadata_om.pbs').read_text()
    for old, new in [('fluxnet-meta-om', 'spinup-seed-op'),
                     ('noahmp-fluxnet-calibration-om', 'noahmp-spinup-seed-comparison-op'),
                     ('run_metadata_om.py', 'run_synthetic_op.py'),
                     ('metadata_om.pbs', 'synthetic_op.pbs')]:
        assert old in pbs
        pbs = pbs.replace(old, new)
    (EXEC / 'synthetic_op.pbs').write_bytes(pbs.encode())
    for name in ['run_synthetic_op.py', 'dispatch_synthetic_op.py']:
        ast.parse((EXEC / name).read_bytes())
    assert 'assess_seed_pairs_op.py' not in (EXEC / 'run_synthetic_op.py').read_text()
    lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821',
                           str(EXEC / 'run_synthetic_op.py'), str(EXEC / 'dispatch_synthetic_op.py')],
                          capture_output=True, text=True)
    assert lint.returncode == 0, lint.stdout + lint.stderr
    execution_names = ['run_synthetic_op.py', 'dispatch_synthetic_op.py', 'synthetic_op.pbs']
    save(EXEC / 'CONTROLS_SHA256.json', {name: sha((EXEC / name).read_bytes()) for name in execution_names})
    payload = {f'preparation/{name}': (PREP / name).read_bytes() for name in [*prep_index, 'CONTROLS_SHA256.json']}
    payload.update({f'execution/{name}': (EXEC / name).read_bytes() for name in [*execution_names, 'CONTROLS_SHA256.json']})
    payload['root-review.json'] = review_raw
    for name in ['prepare_spinup_seed_comparison_op.py', 'spinup-seed-comparison-op-static-verification.json',
                 'spinup-seed-comparison-op-prepared.json', 'review_spinup_seed_comparison_op_root.py',
                 'prepare_spinup_synthetic_execution_op.py']:
        payload['provenance/' + name] = (ROOT / name).read_bytes()
    for name in ['climatology-final-candidate-nm-source.tar.gz', 'multisite-climatology-jr-inputs.tar.gz']:
        payload['inputs/' + name] = (ROOT / name).read_bytes()
    binding = json.loads(payload['preparation/BINDINGS.json'])
    assert sha(payload['inputs/climatology-final-candidate-nm-source.tar.gz']) == binding['model_source_archive_sha256']
    assert sha(payload['inputs/multisite-climatology-jr-inputs.tar.gz']) == binding['original_JR_archive_sha256']
    index = {name: sha(raw) for name, raw in payload.items()}
    payload['stage-inventory.json'] = (json.dumps(index, indent=2) + '\n').encode()
    archive_path = ROOT / 'spinup-seed-comparison-op-stage.tar.gz'
    assert not archive_path.exists()
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name, raw in sorted(payload.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(archive_path) as archive:
        actual = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
    assert actual == payload
    metadata = dict(archive=archive_path.name, sha256=sha(archive_path.read_bytes()), bytes=archive_path.stat().st_size,
                    artifacts=index, stage_members=len(payload), preparation_manifest_sha256=sha(prep_raw),
                    execution_manifest_sha256=sha(payload['execution/CONTROLS_SHA256.json']),
                    root_review_sha256=sha(review_raw), static_AST_F821_exit=0,
                    numerical_tests_executed=False, model_steps=0,
                    scope='Prepared OP PBS synthetic tests stage; exact original NM/JR archives retained as bytes.')
    save(ROOT / 'spinup-seed-comparison-op-stage-package.json', metadata)
    print(json.dumps({key: value for key, value in metadata.items() if key != 'artifacts'}))


if __name__ == '__main__':
    main()

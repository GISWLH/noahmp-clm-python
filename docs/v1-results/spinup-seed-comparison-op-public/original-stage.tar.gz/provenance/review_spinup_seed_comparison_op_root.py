"""Independent static identities/AST review; no numerical imports or endpoints."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parent
PREP = ROOT / 'spinup-seed-comparison-op-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())
manifest_raw = (PREP / 'CONTROLS_SHA256.json').read_bytes()
assert sha(manifest_raw) == '2f411ba6fd9f50ef8f2b36701d1f9e7cec40b76877513b9b64648db5e3d5d51b'
manifest = json.loads(manifest_raw)
assert len(manifest) == 6 and all(sha((PREP / n).read_bytes()) == h for n, h in manifest.items())
binding = read(PREP / 'BINDINGS.json')


def archive(path, expected_sha):
    assert sha(path.read_bytes()) == expected_sha
    with tarfile.open(path) as stream:
        members = stream.getmembers()
        assert len(members) == len({m.name for m in members}) and all(m.isfile() for m in members)
        return {m.name: stream.extractfile(m).read() for m in members}


model = archive(ROOT / 'climatology-final-candidate-nm-source.tar.gz',
                '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d')
assert sha(model['SOURCE_SHA256.json']) == binding['model_source_manifest_sha256']
frozen = json.loads(model['SOURCE_SHA256.json'])
assert frozen == binding['model_source_members_sha256'] and len(frozen) == 584
assert all(sha(model[n]) == h for n, h in frozen.items())
assert frozen['benchmarks/assess_clm_spinup.py'] == '3f2abd00e775ec7028e4cd14e58c18cf6146d4d1c16ca7427a66cf0b5286b47b'
originals = archive(ROOT / 'multisite-climatology-jr-inputs.tar.gz',
                    'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b')
assert len(originals) == 34 and {n: sha(raw) for n, raw in originals.items()} == binding['original_JR_members_sha256']
batch = json.loads(originals['batch.json'])
cases = {row['case']: row for row in batch['cases']}
assert len(cases) == 12
configurations = read(PREP / 'ORIGINAL_CONFIGS.json')
assert set(configurations) == set(cases)
assert all(configurations[name].encode() == originals[row['configuration']] for name, row in cases.items())
assert len(binding['pairs']) == 6
assert {(p['site'], p['bgc_potential_mapping']) for p in binding['pairs']} == {
    (site, mapping) for site in ['CN-Cng', 'CN-Qia', 'CN-Cha']
    for mapping in ['hydraulic-consistent', 'legacy-nominal-control']}


def changed(a, b, path=()):
    if type(a) is dict and type(b) is dict and a.keys() == b.keys():
        return {v for key in a for v in changed(a[key], b[key], path + (key,))}
    if type(a) is list and type(b) is list and len(a) == len(b):
        return {v for i, (x, y) in enumerate(zip(a, b)) for v in changed(x, y, path + (i,))}
    return set() if json.dumps(a) == json.dumps(b) else {path}


for pair in binding['pairs']:
    for side in ['dry', 'wet']:
        entry = pair[side]
        row = cases[entry['case']]
        assert sha(originals[row['configuration']]) == entry['configuration_sha256']
        assert sha(originals[row['input']]) == entry['forcing_npz_sha256']
        assert sha(originals[row['input_manifest']]) == entry['forcing_manifest_sha256']
    dry, wet = [json.loads(configurations[pair[side]['case']]) for side in ['dry', 'wet']]
    assert changed(dry, wet) == {('case',), ('column', 'smc', 1), ('column', 'smc', 2), ('column', 'smc', 3)}
    assert dry['column']['smc'][1:] == [.12] * 3 and wet['column']['smc'][1:] == [.28] * 3
worker = ast.parse((PREP / 'assess_seed_pairs_op.py').read_text())
calls = [n for n in ast.walk(worker) if isinstance(n, ast.Call)]
audit = [n for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == 'assess_cycles']
decode = [n for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == '_frame']
assert len(audit) == len(decode) == 1 and audit[0].lineno < decode[0].lineno
tests = ast.parse((PREP / 'test_seed_pairs_op.py').read_text())
assert len([n for n in ast.walk(tests) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]) == 12
result = dict(controls_manifest_sha256=sha(manifest_raw), controls=6, passed=True, blocking_findings=[],
              mode='Standard-library byte/JSON/AST inspection plus manual source review, no numerical execution.',
              verified_source_files=584, original_JR_files=34, original_configurations=12, fixed_pairs=6,
              original_assessor_sha256=frozen['benchmarks/assess_clm_spinup.py'],
              original_complete_cycle_audit_call_precedes_endpoint_decode=True,
              manual_review=['Original source/input/cold/all-cycle/ledger checks delegated unchanged to original assessor.',
                             'Only exact original case plus three deep total-water seed entries differ.',
                             'All layer T/total-water/SWE and six pairs retained; thresholds unchanged.',
                             'Cross-seed carbon is stock difference, never a time drift or SOC convergence.',
                             'Original per-case minimum-cycle/consecutive checks remain separate; no science pass.',
                             'PBS-only, new result path, read-only closed model evidence, source/evidence rechecked.'],
              synthetic_tests_prepared=12, synthetic_tests_executed=False, actual_endpoint_assessment_executed=False,
              model_steps=0, next_action='Isolated EHPC synthetic tests; real assessment waits for complete NS/cycle evidence.')
path = ROOT / 'spinup-seed-comparison-op-root-review.json'
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))

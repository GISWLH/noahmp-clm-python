"""Prepare OP original metadata bindings; AST/hash only, no numerical imports."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tarfile

B = Path(__file__).resolve().parent
P = B / 'spinup-seed-comparison-op-preparation'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def read_archive(name, digest):
    path = B / name
    assert sha(path.read_bytes()) == digest
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(m.isfile() for m in members) and len(members) == len({m.name for m in members})
        return {m.name: archive.extractfile(m).read() for m in members}


def differences(a, b, path=()):
    if type(a) is dict and type(b) is dict and a.keys() == b.keys():
        return [v for key in a for v in differences(a[key], b[key], path + (key,))]
    if type(a) is list and type(b) is list and len(a) == len(b):
        return [v for i, (x, y) in enumerate(zip(a, b)) for v in differences(x, y, path + (i,))]
    return [] if type(a) is type(b) and a == b else [dict(path=list(path), dry=a, wet=b)]


def save(name, value):
    (P / name).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')


source_sha = '39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
source = read_archive('climatology-final-candidate-nm-source.tar.gz', source_sha)
manifest = json.loads(source['SOURCE_SHA256.json'])
assert len(manifest) == 584 and all(sha(source[n]) == h for n, h in manifest.items())
assert sha(source['SOURCE_SHA256.json']) == 'a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert source['benchmarks/assess_clm_spinup.py'] == (B.parents[1] / 'benchmarks/assess_clm_spinup.py').read_bytes()
jr_sha = 'deb9cf5a72134ea773be54843857eefb9f00bcc650aadde7d444cc0f18663e0b'
jr = read_archive('multisite-climatology-jr-inputs.tar.gz', jr_sha)
assert len(jr) == 34
batch = json.loads(jr['batch.json'])
protocol = json.loads(jr['protocol.json'])
assert protocol['source_manifest_sha256'] == 'e29944bea36767f6d12b42b6ffcabeec278d3983e6ef864068c04fefbd7205a5'
rows = {r['case']: r for r in batch['cases']}
declared = {r['case']: r for r in protocol['cases']}
assert len(rows) == len(declared) == 12 and rows.keys() == declared.keys()
configs = {case: jr[row['configuration']] for case, row in rows.items()}
allowed = {('case',), ('column', 'smc', 1), ('column', 'smc', 2), ('column', 'smc', 3)}
pairs = []
for site in ('CN-Cng', 'CN-Qia', 'CN-Cha'):
    for mapping in ('hydraulic-consistent', 'legacy-nominal-control'):
        pair = dict(site=site, bgc_potential_mapping=mapping)
        decoded = {}
        for side, seed in [('dry', 'wilting'), ('wet', 'field-capacity')]:
            item, = [r for r in declared.values() if r['site'] == site and r['bgc_potential_mapping'] == mapping and r['deep_seed'] == seed]
            row = rows[item['case']]
            cfg = json.loads(configs[item['case']])
            assert cfg['case'] == item['case'] and cfg['site'] == site and sha(configs[item['case']]) == item['configuration_sha256']
            pair[side] = dict(case=item['case'], configuration_member=row['configuration'], configuration_sha256=sha(configs[item['case']]),
                input_member=row['input'], input_manifest_member=row['input_manifest'], forcing_npz_sha256=sha(jr[row['input']]),
                forcing_manifest_sha256=sha(jr[row['input_manifest']]))
            decoded[side] = cfg
        for key in ('input_member', 'input_manifest_member', 'forcing_npz_sha256', 'forcing_manifest_sha256'):
            assert pair['dry'][key] == pair['wet'][key]
        delta = differences(decoded['dry'], decoded['wet'])
        assert {tuple(v['path']) for v in delta} == allowed
        assert all(v['dry'] == .12 and v['wet'] == .28 for v in delta if v['path'] != ['case'])
        pair['original_configuration_differences'] = delta
        pair['bgc_saturated_potential_mpa'] = decoded['dry']['biogeochemistry']['saturated_potential_mpa']
        pairs.append(pair)
binding = dict(status='prepared_only_no_complete_year_available_no_endpoint_execution',
    model_source_archive_sha256=source_sha, model_source_manifest_sha256=sha(source['SOURCE_SHA256.json']), model_source_members_sha256=manifest,
    original_assessor_sha256=manifest['benchmarks/assess_clm_spinup.py'], original_JR_archive_sha256=jr_sha,
    original_JR_members_sha256={n: sha(raw) for n, raw in jr.items()}, original_JN_manifest_sha256=protocol['source_manifest_sha256'],
    original_batch_sha256=sha(jr['batch.json']), pairs=pairs,
    thresholds=dict(soil_temperature_k=.1, soil_water_m3m3=.001, swe_m=.0005),
    original_temporal_requirements=dict(minimum_cycles=2, consecutive_endpoint_checks=2, authority='Unchanged original assess_cycles only'),
    cross_seed_SOC_annualization=False, observation_selection=False, model_executed=False, synthetic_tests_executed=False)
save('BINDINGS.json', binding)
save('ORIGINAL_CONFIGS.json', {n: raw.decode('utf-8') for n, raw in configs.items()})
names = ['seed_pairs_op.py', 'assess_seed_pairs_op.py', 'test_seed_pairs_op.py', 'BINDINGS.json', 'ORIGINAL_CONFIGS.json', 'README.md']
trees = {name: ast.parse((P / name).read_bytes()) for name in names if name.endswith('.py')}
worker = trees['assess_seed_pairs_op.py']
calls = [n for n in ast.walk(worker) if isinstance(n, ast.Call)]
assert sum(isinstance(n.func, ast.Attribute) and n.func.attr == 'assess_cycles' for n in calls) == 1
assert sum(isinstance(n.func, ast.Attribute) and n.func.attr == '_frame' for n in calls) == 1
assert not any(isinstance(n.func, ast.Attribute) and n.func.attr in ('compare_endpoints', 'observed_carbon_century', 'run') for n in calls)
test_count = sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(trees['test_seed_pairs_op.py']))
assert test_count == 12
controls = {n: sha((P / n).read_bytes()) for n in names}
save('CONTROLS_SHA256.json', controls)
lint = subprocess.run(['E:/miniconda3/Scripts/ruff.exe', 'check', '--select', 'F821', str(P), str(Path(__file__))], capture_output=True, text=True)
proof = dict(mode='stdlib_metadata_hash_AST_and_static_lint_only', controls=len(controls), controls_manifest_sha256=sha((P / 'CONTROLS_SHA256.json').read_bytes()),
    original_source_files_hashed=584, original_JR_members_hashed=34, fixed_pairs=6, original_configs=12,
    original_assessor_byteequal_frozen_NM_and_current=True, original_assessor_called_once=True, original_frame_decoder_reused=True,
    new_cross_seed_carbon_rate_calculations=False, prepared_synthetic_tests=test_count, tests_executed=False,
    endpoint_assessment_executed=False, physical_arrays_decoded=False, model_steps=0, PBS_submitted=False,
    actual_ruff_returncode=lint.returncode, ruff_stdout=lint.stdout, ruff_stderr=lint.stderr)
(B / 'spinup-seed-comparison-op-static-verification.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
assert lint.returncode == 0, proof
print(json.dumps(proof, indent=2))

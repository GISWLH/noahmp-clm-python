# OP fixed dry/wet endpoint comparison — preparation only

No complete endpoint has been evaluated. No model, GPU or PBS job has been started by this preparation; synthetic tests remain pending on EHPC. The frozen NM584 source, original JR34 inputs and active NQ/NS/NZ tasks are untouched.

The six pairs are all three original stations × both original BGC saturated-potential mappings. Each pair retains the original wilting and field-capacity seed, without using observations to select either. The actual original JSON differences are exactly `case` and `column.smc[1]`, `[2]`, `[3]` (0.12 versus 0.28). The first layer, temperature, carbon/nitrogen stocks, all parameters, geometry and forcing match. These are **total-water** seeds; liquid water is not substituted, especially in frozen soil. `BINDINGS.json` records both case/configuration/forcing identities and the exact permitted differences. All six pairs and twelve cases are mandatory.

The worker authenticates all 584 frozen source members and all 34 original JR members, retaining the original JN input provenance. In PBS TMPDIR it creates only a flat, byte-exact view of the required original input files; `batch.json` remains unchanged. It calls the original `assess_clm_spinup.assess_cycles` once. That unmodified assessor validates the full original cold state, all completed cycles in order, source/input/configuration identities, native state and cumulative ledger links, complete calendar times, original stored M/H/C/N bounds and final extensive storage. Running or failed prefixes are not cycles. Both the original minimum two cycles and two consecutive per-case endpoint requirements, canopy criterion when applicable, and strict SOC drift criterion remain entirely with that assessor.

Only after that audit succeeds does the wrapper reopen each exact authenticated complete-cycle checkpoint and call the original assessor `_frame` / `SoilEnthalpyState.temperature`. For every pair at the **same** cycle end it reports dry/wet temperatures and total volumetric water in every layer, signed and absolute differences, individual layer outcomes and maxima. Thresholds are the original ≤0.1 K, ≤0.001 m³/m³ and SWE ≤0.0005 m. Scientific failures produce explicit false fields, not dropped pairs. Seven C pools and the three-pool SOC stock difference may be reported; a cross-seed stock difference has no elapsed-time denominator and is never annualized or called a percent-per-century drift.

The output embeds the original complete assessor result unchanged and lists all six comparisons for every complete cycle. Cross-seed agreement and original temporal convergence are separate booleans. Neither overrides SOC, nitrogen, observation, calibration or release requirements; no combined scientific acceptance or seed selection is produced. A one-cycle report may show cross-seed agreement while the original temporal convergence remains false.

Minimal future CLI, **only on compute002 in a real EHPC PBS job**:

```sh
/home/zhangyq/venvs/noahmp-closeout/bin/python -B assess_seed_pairs_op.py \
  --source-root /tmp/EXACT_NM584_SOURCE \
  --original-input-archive /path/to/multisite-climatology-jr-inputs.tar.gz \
  --segments /path/to/CLOSED_NS_TRAJECTORY /path/to/CLOSED_CYCLE02_TRAJECTORY \
  --output /tmp/NEW_RESULTS/seed-comparison.json
```

The segment folders must be the actual complete native trajectories (the first NS trajectory remains inside its original NP parent tree; later OK cycles have their own folders). This worker does not launch or resume cycles, acquire live GPU state, flatten an annual state chain, or infer completion from a queue entry. Supply every complete cycle from the original cold root, in order. Output must be new. Temporary input paths in the embedded assessor evidence are restorable from the fixed JR archive; their original bytes/hashes are preserved, not renamed as NM-generated input.

Pending EHPC synthetic checks:

```sh
/home/zhangyq/venvs/noahmp-closeout/bin/python -B -m unittest discover -s . -p test_seed_pairs_op.py -v
```

The 12 prepared tests use original configuration metadata and synthetic endpoint vectors. They cover missing/repeated/cross-mapping pairs, case/forcing identity, non-whitelisted initial-state/parameter/height changes, changed deep-seed values, individual-layer temperature and total-water failures, SWE and inclusive thresholds, malformed/nonfinite stocks, and prohibition of cross-seed C drift/convergence labels. They do not replace the future actual full-cycle assessment. Windows verification is limited to stdlib archive/JSON/hash/AST and static lint; tests and numerical decoder are not run there.

"""Synthetic identity/threshold checks, to run only on an EHPC PBS node."""
from pathlib import Path
import copy
import json
import unittest

import seed_pairs_op as p

HERE = Path(__file__).resolve().parent


def setUpModule():
    p.compute_only()


class SeedIdentityTests(unittest.TestCase):
    def setUp(self):
        self.binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
        self.configs = {k: v.encode('utf-8') for k, v in json.loads((HERE / 'ORIGINAL_CONFIGS.json').read_bytes()).items()}

    def test_all_six_original_pairs_and_both_mappings_retained(self):
        pairs = p.validate_pair_set(self.binding, self.configs)
        self.assertEqual(len(pairs), 6)
        self.assertEqual({(v['site'], v['bgc_potential_mapping']) for v in pairs}, p.PAIR_KEYS)
        self.assertEqual(len({v[side]['case'] for v in pairs for side in ('dry', 'wet')}), 12)
        for pair in pairs:
            self.assertEqual({tuple(v['path']) for v in pair['original_configuration_differences']}, p.ALLOWED_CONFIG_DIFFERENCES)

    def test_missing_seed_or_pair_is_failure_not_silently_skipped(self):
        del self.configs[self.binding['pairs'][0]['wet']['case']]
        with self.assertRaisesRegex(ValueError, 'twelve'):
            p.validate_pair_set(self.binding, self.configs)
        self.setUp()
        self.binding['pairs'].pop()
        with self.assertRaisesRegex(ValueError, 'six'):
            p.validate_pair_set(self.binding, self.configs)

    def test_cross_mapping_and_duplicate_pair_are_rejected(self):
        self.binding['pairs'][0]['wet'] = copy.deepcopy(self.binding['pairs'][1]['wet'])
        with self.assertRaisesRegex(ValueError, 'twelve'):
            p.validate_pair_set(self.binding, self.configs)
        self.setUp()
        self.binding['pairs'][1] = copy.deepcopy(self.binding['pairs'][0])
        with self.assertRaisesRegex(ValueError, 'six'):
            p.validate_pair_set(self.binding, self.configs)

    def test_case_label_and_forcing_identity_must_match(self):
        pair = self.binding['pairs'][0]
        pair['wet']['forcing_npz_sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'forcing'):
            p.validate_pair_set(self.binding, self.configs)
        self.setUp()
        pair = self.binding['pairs'][0]
        name = pair['wet']['case']
        config = json.loads(self.configs[name])
        config['case'] = 'wrong-case'
        raw = json.dumps(config).encode()
        self.configs[name] = raw
        pair['wet']['configuration_sha256'] = p.sha(raw)
        with self.assertRaisesRegex(ValueError, 'Case/site'):
            p.validate_pair_set(self.binding, self.configs)

    def test_extra_temperature_carbon_parameter_differences_are_rejected(self):
        mutations = [lambda v: v['column']['tsoil'].__setitem__(0, 280.0),
                     lambda v: v['biogeochemistry']['plant_state']['carbon'].__setitem__(0, 123.0),
                     lambda v: v['leaf_parameters'].__setitem__('ball_berry_slope', 10.0),
                     lambda v: v['most_geometry'].__setitem__('wind_height', 999.0)]
        for mutate in mutations:
            self.setUp()
            pair = self.binding['pairs'][0]
            name = pair['wet']['case']
            config = json.loads(self.configs[name])
            mutate(config)
            raw = json.dumps(config).encode()
            self.configs[name] = raw
            # Exercise the structural whitelist independently of the exact-byte gate.
            pair['wet']['configuration_sha256'] = p.sha(raw)
            with self.assertRaisesRegex(ValueError, 'Only case'):
                p.validate_pair_set(self.binding, self.configs)

    def test_changed_seed_values_or_unregistered_bytes_are_rejected(self):
        pair = self.binding['pairs'][0]
        name = pair['dry']['case']
        config = json.loads(self.configs[name])
        config['column']['smc'][1] = .13
        raw = json.dumps(config).encode()
        self.configs[name] = raw
        with self.assertRaisesRegex(ValueError, 'bytes'):
            p.validate_pair_set(self.binding, self.configs)
        pair['dry']['configuration_sha256'] = p.sha(raw)
        with self.assertRaisesRegex(ValueError, 'seed values'):
            p.validate_pair_set(self.binding, self.configs)


class EndpointTests(unittest.TestCase):
    def setUp(self):
        self.dry = dict(soil_temperature_k=[270., 271., 272., 273.],
                        soil_water_m3m3=[.1, .2, .3, .4], swe_m=.002,
                        soil_carbon_gc_m2=[1., 2., 3., 4., 300., 3000., 3000.])
        self.wet = copy.deepcopy(self.dry)

    def compare(self):
        return p.compare_seed_endpoints(self.dry, self.wet, p.LIMITS)

    def test_equal_endpoints_pass_and_all_actual_layers_are_reported(self):
        out = self.compare()
        self.assertTrue(out['cross_seed_water_heat_criteria_met'])
        self.assertEqual(out['soil_temperature_k']['dry_by_layer'], self.dry['soil_temperature_k'])
        self.assertEqual(out['soil_water_m3m3']['wet_by_layer'], self.wet['soil_water_m3m3'])
        self.assertEqual(out['soil_temperature_k']['absolute_difference_by_layer'], [0.] * 4)

    def test_single_hidden_temperature_layer_failure_is_retained(self):
        self.wet['soil_temperature_k'][2] += .125
        out = self.compare()
        self.assertFalse(out['cross_seed_water_heat_criteria_met'])
        self.assertEqual(out['soil_temperature_k']['layer_criteria_met'], [True, True, False, True])
        self.assertEqual(out['soil_temperature_k']['maximum_absolute_difference'], .125)

    def test_total_water_failure_is_not_replaced_by_liquid_water(self):
        self.dry['soil_water_liquid_m3m3'] = [.1] * 4
        self.wet['soil_water_liquid_m3m3'] = [.1] * 4
        self.wet['soil_water_m3m3'][3] += .002
        out = self.compare()
        self.assertFalse(out['cross_seed_water_heat_criteria_met'])
        self.assertFalse(out['soil_water_m3m3']['layer_criteria_met'][3])

    def test_swe_failure_and_inclusive_predeclared_boundaries(self):
        self.wet['swe_m'] += .001
        self.assertFalse(self.compare()['swe_m']['criterion_met'])
        # Exact synthetic arithmetic isolates <= thresholds, not a physical cold state.
        self.dry.update(soil_temperature_k=[0.], soil_water_m3m3=[0.], swe_m=0.)
        self.wet.update(soil_temperature_k=[.1], soil_water_m3m3=[.001], swe_m=.0005)
        self.assertTrue(self.compare()['cross_seed_water_heat_criteria_met'])

    def test_nonfinite_dimension_and_negative_stock_fail_closed(self):
        for key, value in [('soil_temperature_k', [float('nan')] * 4),
                           ('soil_water_m3m3', [.1, .2]), ('soil_water_m3m3', [-.1] * 4),
                           ('swe_m', float('inf')), ('swe_m', -.001),
                           ('soil_carbon_gc_m2', [-1.] * 7)]:
            self.setUp()
            self.wet[key] = value
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                self.compare()

    def test_cross_seed_carbon_difference_never_becomes_drift_or_convergence(self):
        self.wet['soil_carbon_gc_m2'][4] += 1000.
        out = self.compare()
        self.assertTrue(out['cross_seed_water_heat_criteria_met'])
        self.assertEqual(out['soil_carbon_stock_difference']['signed_wet_minus_dry_soc_gc_m2'], 1000.)
        def keys(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    yield key
                    yield from keys(item)
            elif isinstance(value, list):
                for item in value:
                    yield from keys(item)
        self.assertFalse(any('rate' in key or 'converged' in key or 'century' in key for key in keys(out)))
        with self.assertRaisesRegex(ValueError, 'thresholds'):
            p.compare_seed_endpoints(self.dry, self.wet, dict(p.LIMITS, soil_temperature_k=1.))


if __name__ == '__main__':
    unittest.main()

"""Add fixed six-pair seed endpoints AFTER the unchanged NM cycle assessor."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys
import tarfile
import tempfile

from seed_pairs_op import compute_only, compare_seed_endpoints, require, sha, validate_pair_set, LIMITS

HERE = Path(__file__).resolve().parent


def controls_identity():
    raw = (HERE / 'CONTROLS_SHA256.json').read_bytes()
    controls = json.loads(raw)
    require(all(Path(name).name == name and sha((HERE / name).read_bytes()) == digest
                for name, digest in controls.items()), 'OP preparation control identity mismatch')
    return sha(raw)


def verify_source(root, binding):
    root = Path(root).resolve()
    raw = (root / 'SOURCE_SHA256.json').read_bytes()
    manifest = json.loads(raw)
    require(sha(raw) == binding['model_source_manifest_sha256'] and len(manifest) == 584,
            'Exact frozen NM584 source required')
    require(manifest == binding['model_source_members_sha256'], 'NM source manifest membership mismatch')
    require(all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items()),
            'Frozen NM source bytes changed')
    return root


def original_inputs(archive, binding, target):
    raw = Path(archive).read_bytes()
    require(sha(raw) == binding['original_JR_archive_sha256'], 'Exact original JR34 archive required')
    with tarfile.open(archive) as tf:
        members = tf.getmembers()
        require(all(m.isfile() for m in members) and len(members) == 34 and len({m.name for m in members}) == 34,
                'Exact original JR34 membership required')
        blobs = {m.name: tf.extractfile(m).read() for m in members}
    require({n: sha(v) for n, v in blobs.items()} == binding['original_JR_members_sha256'],
            'Original JR member bytes changed')
    require(json.loads(blobs['protocol.json'])['source_manifest_sha256'] == binding['original_JN_manifest_sha256'],
            'Original inputs must retain their JN provenance')
    batch = json.loads(blobs['batch.json'])
    configs = {r['case']: blobs[r['configuration']] for r in batch['cases']}
    pairs = validate_pair_set(binding, configs)
    needed = {'batch.json'} | {r[key] for r in batch['cases'] for key in ('input', 'input_manifest', 'configuration')}
    require(len({Path(n).name for n in needed}) == len(needed), 'Flattened original input names collide')
    for name in needed:
        (target / Path(name).name).write_bytes(blobs[name])
    return target / 'batch.json', pairs


def unchanged(evidence):
    require(all(sha(Path(path).read_bytes()) == digest for path, digest in evidence.items()),
            'Previously authenticated cycle/input evidence changed')


def assess(source_root, input_archive, segments):
    compute_only()
    sys.dont_write_bytecode = True
    control_sha = controls_identity()
    binding = json.loads((HERE / 'BINDINGS.json').read_bytes())
    source = verify_source(source_root, binding)
    folders = [Path(p).resolve() for p in segments]
    require(folders and len(folders) == len(set(folders)), 'Distinct ordered complete cycle folders required')
    sys.path[:0] = [str(source), str(source / 'src'), str(source / 'benchmarks')]
    spec = importlib.util.spec_from_file_location('_original_assessor_op', source / 'benchmarks/assess_clm_spinup.py')
    assessor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(assessor)
    require(Path(assessor.native.__file__).resolve() == source / 'benchmarks/run_fluxnet_native.py',
            'Native reader must come from the exact frozen source')
    require({key: assessor.LIMITS[key] for key in LIMITS} == LIMITS, 'Original endpoint thresholds changed')
    import numpy as np
    with tempfile.TemporaryDirectory(prefix='spinup-seed-op-', dir=os.environ['TMPDIR']) as temporary:
        inputs = Path(temporary)
        batch_path, pairs = original_inputs(input_archive, binding, inputs)
        # The original complete-source/input/cold/cycle/ledger/temporal-C checks run unchanged.
        original = assessor.assess_cycles(batch_path, inputs, folders, source / 'SOURCE_SHA256.json')
        unchanged(original['evidence_sha256'])
        cycles = []
        for number, folder in enumerate(folders, 1):
            batch = json.loads((folder / 'batch.json').read_bytes())
            checkpoint = folder / batch['checkpoint_file']
            require(sha(checkpoint.read_bytes()) == batch['checkpoint_sha256']
                    == original['evidence_sha256'][str(checkpoint)], 'Validated endpoint checkpoint changed')
            with np.load(checkpoint, allow_pickle=False) as saved:
                frames = {row['case']: assessor._frame(saved, k, batch['identity'])
                          for k, row in enumerate(batch['identity']['cases'])}
            originals = {row['case']: row for row in original['cycles'][number-1]['cases']}
            require(len(frames) == len(originals) == 12, 'All original twelve endpoints required')
            results = []
            for pair in pairs:
                dry, wet = pair['dry']['case'], pair['wet']['case']
                result = compare_seed_endpoints(frames[dry], frames[wet], assessor.LIMITS)
                result.update(site=pair['site'], bgc_potential_mapping=pair['bgc_potential_mapping'],
                    bgc_saturated_potential_mpa=pair['bgc_saturated_potential_mpa'], dry_case=dry, wet_case=wet,
                    complete_cycle=number, checkpoint_sha256=batch['checkpoint_sha256'],
                    original_case_temporal_water_heat_converged={name: originals[name]['water_heat_converged'] for name in (dry, wet)},
                    original_case_temporal_soc_rate_criterion_met={name: originals[name]['soc_rate_criterion_met'] for name in (dry, wet)})
                results.append(result)
            cycles.append(dict(complete_cycle=number, pairs=results,
                all_six_cross_seed_water_heat_criteria_met=all(row['cross_seed_water_heat_criteria_met'] for row in results)))
        unchanged(original['evidence_sha256'])
        verify_source(source, binding)
        require(controls_identity() == control_sha, 'OP controls changed during assessment')
        return dict(scope='Original NM complete repeated-cycle assessment plus six prespecified same-cycle dry/wet endpoint comparisons. No selection, forward model or observation scoring.',
            original_assessment=original, cross_seed_cycles=cycles, complete_cycles=len(cycles),
            all_six_cross_seed_water_heat_criteria_met_at_last_cycle=cycles[-1]['all_six_cross_seed_water_heat_criteria_met'],
            original_all_columns_water_heat_converged=original['all_columns_water_heat_converged'],
            temperature_decoder='Unmodified frozen assess_clm_spinup._frame / SoilEnthalpyState.temperature',
            original_JR_archive_sha256=binding['original_JR_archive_sha256'], original_JN_manifest_sha256=binding['original_JN_manifest_sha256'],
            model_source_manifest_sha256=binding['model_source_manifest_sha256'], controls_manifest_sha256=control_sha,
            limits=LIMITS, soil_c_long_term_equilibrium_claim=False, scientific_acceptance_claim=False,
            seed_selection_performed=False, actual_endpoint_assessment_executed=True, new_model_steps=0,
            not_certified=['Cross-seed C stock differences are not percent-per-century drift',
                           'Cross-seed agreement cannot replace original minimum2cycles/2consecutive temporal checks or SOC criteria',
                           'No observational, calibration, holdout or release acceptance'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('source-root', 'original-input-archive', 'output'):
        p.add_argument('--' + key, type=Path, required=True)
    p.add_argument('--segments', nargs='+', type=Path, required=True)
    args = p.parse_args()
    compute_only()
    require(not args.output.exists(), 'Preserve prior assessment')
    result = assess(args.source_root, args.original_input_archive, args.segments)
    result['pbs_job'] = os.environ['PBS_JOBID']
    with args.output.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(dict(complete_cycles=result['complete_cycles'],
        cross_seed_only=result['all_six_cross_seed_water_heat_criteria_met_at_last_cycle'],
        original_temporal_only=result['original_all_columns_water_heat_converged'], scientific_acceptance_claim=False)))


if __name__ == '__main__':
    main()

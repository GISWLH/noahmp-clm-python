"""Stage byte-bound OP synthetic tests in manager/compute002 /tmp and submit once."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shlex
import socket
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/noahmp-spinup-seed-comparison-op')
PYTHON = '/home/zhangyq/venvs/noahmp-closeout/bin/python'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unpack(archive_path, expected):
    assert sha(archive_path.read_bytes()) == expected and not ROOT.exists()
    with tarfile.open(archive_path) as archive:
        items = archive.getmembers()
        assert all(item.isfile() and not Path(item.name).is_absolute() and
                   '..' not in Path(item.name).parts and '\\' not in item.name for item in items)
        assert len({item.name for item in items}) == len(items)
        raw = {item.name: archive.extractfile(item).read() for item in items}
    index = json.loads(raw['stage-inventory.json'])
    assert set(index) == set(raw) - {'stage-inventory.json'}
    assert all(sha(raw[name]) == digest for name, digest in index.items())
    ROOT.mkdir()
    for name, value in raw.items():
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value)
    return index


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--extract-only', action='store_true')
    args = parser.parse_args()
    assert sys.version_info >= (3, 10)
    assert socket.gethostname() == ('compute002' if args.extract_only else 'manager')
    index = unpack(args.archive, args.sha256)
    assert sha(Path(__file__).read_bytes()) == index['execution/dispatch_synthetic_op.py']
    if args.extract_only:
        print(json.dumps(dict(stage_archive_sha256=args.sha256, members=len(index))), flush=True)
        return
    # The same controls are copied explicitly; no shared-/tmp assumption.
    remote_archive = '/tmp/noahmp-spinup-seed-comparison-op-stage.tar.gz'
    remote_dispatcher = '/tmp/dispatch_spinup_synthetic_op.py'
    command = ['ssh', 'compute002', shlex.join(['test', '!', '-e', str(ROOT)])]
    subprocess.run(command, check=True)
    for local, remote in [(args.archive, remote_archive), (Path(__file__), remote_dispatcher)]:
        subprocess.run(['ssh', 'compute002', shlex.join(['test', '!', '-e', remote])], check=True)
        subprocess.run(['scp', str(local), 'compute002:' + remote], check=True)
    extract = subprocess.run(['ssh', 'compute002', shlex.join([
        PYTHON, '-B', remote_dispatcher, '--archive', remote_archive, '--sha256', args.sha256, '--extract-only'])],
        capture_output=True, text=True)
    (ROOT / 'compute-extract.stdout.txt').write_text(extract.stdout)
    (ROOT / 'compute-extract.stderr.txt').write_text(extract.stderr)
    assert extract.returncode == 0, extract.stderr
    remote = subprocess.run(['ssh', 'compute002', shlex.join(['sha256sum', *[str(ROOT / name) for name in index]])],
                            capture_output=True, text=True)
    (ROOT / 'compute-file-hashes.txt').write_text(remote.stdout)
    assert remote.returncode == 0, remote.stderr
    assert {line.split()[1]: line.split()[0] for line in remote.stdout.splitlines()} == {
        str(ROOT / name): digest for name, digest in index.items()}
    review_raw = (ROOT / 'root-review.json').read_bytes()
    assert sha(review_raw) == 'bfd6542662055fc37f0d0134c9c063b3ff0a30a54e3ae13cc819945261970dcd'
    review = json.loads(review_raw)
    assert review['blocking_findings'] == [] and review['controls'] == 6
    manifest_sha = sha((ROOT / 'preparation/CONTROLS_SHA256.json').read_bytes())
    assert review['controls_manifest_sha256'] == manifest_sha
    assert not (ROOT / 'dispatch.json').exists()
    result = subprocess.run(['qsub', '-o', str(ROOT / 'pbs-output.log'), str(ROOT / 'execution/synthetic_op.pbs')],
                            capture_output=True, text=True)
    (ROOT / 'qsub.stdout.txt').write_text(result.stdout)
    (ROOT / 'qsub.stderr.txt').write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    job = result.stdout.strip()
    assert job.endswith('.manager') and job.split('.')[0].isdigit()
    record = dict(pbs_job=job, stage_archive_sha256=args.sha256, source_stage_members=index,
                  preparation_manifest_sha256=manifest_sha, requested_resources='1CPU/2GB/5min/compute002',
                  python=PYTHON, process=os.getpid(), model_runs=0, scope='OP synthetic tests only; no actual endpoints or forward model.')
    (ROOT / 'dispatch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()

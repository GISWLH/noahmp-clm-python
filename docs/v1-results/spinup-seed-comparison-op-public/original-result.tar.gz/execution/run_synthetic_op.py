"""Run frozen OP synthetic tests only on a PBS compute002 node."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import traceback

STAGE = Path('/tmp/noahmp-spinup-seed-comparison-op')
PREP_SHA = '2f411ba6fd9f50ef8f2b36701d1f9e7cec40b76877513b9b64648db5e3d5d51b'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


def read_archive(path, digest):
    assert sha(path.read_bytes()) == digest
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        assert all(m.isfile() for m in members)
        assert len({m.name for m in members}) == len(members)
        return {m.name: archive.extractfile(m).read() for m in members}


assert sys.version_info >= (3, 10)
assert os.environ.get('PBS_JOBID') and socket.gethostname() == 'compute002'
result = Path(sys.argv[1]).resolve()
assert result.is_relative_to(Path(os.environ['TMPDIR']).resolve())
result.mkdir()
started = time.monotonic()
receipt = dict(pbs_job=os.environ['PBS_JOBID'], node=socket.gethostname(),
               python=sys.version, python_executable=sys.executable, passed=False,
               unittest_parent_returncode=None, error=None, model_steps=0,
               actual_endpoint_assessment_executed=False,
               physical_model_arrays_decoded=False, synthetic_test_run=True)
try:
    stage_index = json.loads((STAGE / 'stage-inventory.json').read_bytes())
    assert all(sha((STAGE / name).read_bytes()) == digest for name, digest in stage_index.items())
    controls_raw = (STAGE / 'execution/CONTROLS_SHA256.json').read_bytes()
    controls = json.loads(controls_raw)
    assert all(sha((STAGE / 'execution' / name).read_bytes()) == digest for name, digest in controls.items())
    prep_raw = (STAGE / 'preparation/CONTROLS_SHA256.json').read_bytes()
    assert sha(prep_raw) == PREP_SHA
    prep_index = json.loads(prep_raw)
    assert len(prep_index) == 6
    review_raw = (STAGE / 'root-review.json').read_bytes()
    review = json.loads(review_raw)
    assert review['passed'] and review['blocking_findings'] == [] and review['controls'] == 6
    assert review['controls_manifest_sha256'] == PREP_SHA
    assert review['original_complete_cycle_audit_call_precedes_endpoint_decode'] is True
    assert review['synthetic_tests_prepared'] == 12
    for folder, index in [('preparation', prep_index), ('execution', controls)]:
        destination = result / folder
        destination.mkdir()
        for name in [*index, 'CONTROLS_SHA256.json']:
            shutil.copyfile(STAGE / folder / name, destination / name)
    shutil.copyfile(STAGE / 'root-review.json', result / 'root-review.json')
    binding = json.loads((STAGE / 'preparation/BINDINGS.json').read_bytes())
    model = read_archive(STAGE / 'inputs/climatology-final-candidate-nm-source.tar.gz',
                         binding['model_source_archive_sha256'])
    assert sha(model['SOURCE_SHA256.json']) == binding['model_source_manifest_sha256']
    model_index = json.loads(model['SOURCE_SHA256.json'])
    assert model_index == binding['model_source_members_sha256'] and len(model_index) == 584
    assert set(model) == set(model_index) | {'SOURCE_SHA256.json'}
    assert all(sha(model[name]) == digest for name, digest in model_index.items())
    originals = read_archive(STAGE / 'inputs/multisite-climatology-jr-inputs.tar.gz',
                             binding['original_JR_archive_sha256'])
    assert len(originals) == 34
    assert {name: sha(raw) for name, raw in originals.items()} == binding['original_JR_members_sha256']
    configs = json.loads((STAGE / 'preparation/ORIGINAL_CONFIGS.json').read_bytes())
    registry = [pair[side] for pair in binding['pairs'] for side in ('dry', 'wet')]
    assert len(registry) == len(configs) == 12
    assert set(configs) == {row['case'] for row in registry}
    assert all(configs[row['case']].encode('utf-8') == originals[row['configuration_member']] for row in registry)
    receipt.update(source_files_byteverified=584, original_JR_members_byteverified=34,
                   original_configuration_count=12, fixed_pair_count=6,
                   preparation_manifest_sha256=PREP_SHA,
                   execution_manifest_sha256=sha(controls_raw), root_review_sha256=sha(review_raw),
                   model_source_manifest_sha256=binding['model_source_manifest_sha256'],
                   original_JN_manifest_sha256=binding['original_JN_manifest_sha256'])
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    preparation = result / 'preparation'
    command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(preparation),
               '-p', 'test_seed_pairs_op.py', '-v']
    save(result / 'unittest-command.json', command)
    unit = subprocess.run(command, cwd=preparation, env=env, capture_output=True, text=True, timeout=120)
    (result / 'unittest.stdout.txt').write_text(unit.stdout)
    (result / 'unittest.stderr.txt').write_text(unit.stderr)
    receipt['unittest_parent_returncode'] = unit.returncode
    assert unit.returncode == 0, unit.stderr
    assert 'Ran 12 tests' in unit.stderr and '\nOK\n' in unit.stderr
    assert all(sha((preparation / name).read_bytes()) == digest for name, digest in prep_index.items())
    assert all(sha((STAGE / name).read_bytes()) == digest for name, digest in stage_index.items())
    receipt.update(passed=True, actual_unittest_count=12, preparation_and_source_unchanged=True,
                   scope='OP synthetic identities and thresholds only; no actual endpoint, forward model, cycle, GPU, spinup convergence or scientific acceptance.')
except Exception as error:
    receipt['error'] = type(error).__name__ + ': ' + str(error)
    (result / 'traceback.txt').write_text(traceback.format_exc())
receipt['seconds'] = time.monotonic() - started
save(result / 'receipt.json', receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if receipt['passed'] else 1)

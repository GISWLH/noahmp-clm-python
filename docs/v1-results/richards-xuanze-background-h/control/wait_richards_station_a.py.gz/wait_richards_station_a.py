from pathlib import Path
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
b=Path('/home/lhwang/work/noahmp-v1');r=b/'richards-station-native-a/target-a';prior=b/'richards-column-native-a/target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
    if (prior/'exit.json').exists():
        e=json.loads((prior/'exit.json').read_text());d=json.loads((prior/'receipt.json').read_text())
        valid=(e['returncode']==d['worker_exitcode']==d['pytest_returncode']==0 and e['passed'] and d['passed'] and e['source_unchanged'] and d['source_unchanged'] and d['node_coverage_exact'] and d['all_setup_call_teardown_phases_passed'] and d['counts']==dict(tests=5,failures=0,errors=0,skipped=0) and e['receipt_sha256']==sha(prior/'receipt.json') and d['xml_sha256']==sha(prior/'tests.xml') and d['source_manifest_sha256']=='4bf009f3fe23f05df5e241757e5b70063432ed39e84e8160c9f3738457fcb79a')
        if not valid:
            record=dict(status='not_started_upstream_failed',prior_exit=e,prior_counts=d.get('counts'),utc=datetime.now(timezone.utc).isoformat())
            (r/'deferred.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);sys.exit(1)
        free=int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
        available=int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
        if free>8192 and available>16*1024*1024:
            record=dict(status='starting after actual upstream5 pass and resource guards',prior_exit_sha256=sha(prior/'exit.json'),prior_receipt_sha256=sha(prior/'receipt.json'),free_gpu_mib=free,host_available_kib=available,utc=datetime.now(timezone.utc).isoformat())
            (r/'prerequisite.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
            with (r/'controller.log').open('x') as log:
                code=subprocess.run([sys.executable,'-u',str(b/'control_richards_station_a.py')],cwd=r.parent,stdout=log,stderr=subprocess.STDOUT).returncode
            (r/'waiter-exit.json').write_text(json.dumps(dict(returncode=code,utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n');sys.exit(code)
    time.sleep(30)

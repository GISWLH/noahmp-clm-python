from pathlib import Path
import hashlib,json,os,subprocess,sys,time
b=Path('/home/lhwang/work/noahmp-v1');s=b/'richards-column-native-a';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==552 and all(sha(s/n)==v for n,v in m.items())
with (r/'collection.log').open('x') as log:code=subprocess.run([sys.executable,'-u',str(b/'collect_richards_column_a.py')],cwd=s,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0;expected=json.loads((r/'collection.json').read_text())['expected'];(r/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
worker=b/'gpu-worker-lifecycle-a/run_pytest_worker_a.py';assert sha(worker)=='68799c7617871b3b316f5ff7f913e0622fd2f55321292bcbf80946dbb4bbc076'
env=os.environ.copy();env['NOAHMP_RICHARDS_COLUMN_DIAGNOSTICS']=str(r/'diagnostics')
command=[sys.executable,'-u',str(worker),'--source',str(s),'--test-file',str(s/'tests/test_gpu_clm_richards_column.py'),'--expected',str(r/'expected.json'),'--receipt',str(r/'receipt.json'),'--xml',str(r/'tests.xml')]
with (r/'tests.log').open('x') as log:p=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/'worker.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2)+'\n');code=p.wait()
d=json.loads((r/'receipt.json').read_text()) if (r/'receipt.json').exists() else {};unchanged=all(sha(s/n)==v for n,v in m.items())
passed=bool(code==d.get('worker_exitcode')==d.get('pytest_returncode')==0 and d.get('passed') and d.get('source_unchanged') and d.get('all_setup_call_teardown_phases_passed') and d.get('node_coverage_exact') and d.get('counts')==dict(tests=5,failures=0,errors=0,skipped=0) and d.get('xml_sha256')==sha(r/'tests.xml') and d.get('source_manifest_sha256')==sha(s/'SOURCE_SHA256.json') and unchanged)
record=dict(scope='552R-column-A wholecolumns native5 exact node/XML/source/original1e-6 integer/science/M guards, actual worker exits and stable-worker atexit disclosure. Production-column/full1428/year/spinup/science acceptance pending.',
    passed=passed,returncode=code if code else (0 if passed else 1),source_unchanged=unchanged,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),seconds=time.monotonic()-start,receipt_sha256=sha(r/'receipt.json') if d else None)
(r/'exit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);sys.exit(record['returncode'])

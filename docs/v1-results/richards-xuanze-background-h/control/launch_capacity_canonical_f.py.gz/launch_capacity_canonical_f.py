from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
b=Path('/home/lhwang/work/noahmp-v1');s=b/'clm-capacity-final-f';r=s/'full-controller-f';assert not r.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((s/'SOURCE_SHA256.json').read_text())
assert len(m)==532 and sha(s/'SOURCE_SHA256.json')=='b19fbf81e7afaef4aaeaabc0fddc5104690c782849a8c9a832b61b2b5beaba7b'
assert all(sha(s/n)==h for n,h in m.items())
assert sha(b/'clm-capacity-cpu-f-evidence.tar.gz')=='e0a86665b5cf09e554bdc2660ef2919875efadc53ac14bdc647113989451dd65'
assert sha(b/'clm-capacity-target20-f-evidence.tar.gz')=='ef100ab1f6978b5e654d5ab56e4096d0a68a2e4633c2dcf0e56d79bab91c1761'
controls={n:sha(b/n) for n in ['launch_capacity_canonical_f.py','wait_capacity_canonical_f.py','run_capacity_canonical_f.py','collect_capacity_canonical_f.py']}
r.mkdir();env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='1',
    CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
    JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),
    PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1')
d=dict(scope='Deferred frozen532F canonical1344: exact981CPU/target20 actual0, wait original511 parent exit and ownwhole3 actual0 before remaining340GPU. Source533 station edits, year, spinup and scientific acceptance remain separate; queueing is not execution.',
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),device=1,controls_sha256=controls,source_manifest_sha256=sha(s/'SOURCE_SHA256.json'),
    wait_for_actual_exits=[str(b/'p6-all-phase-final-b/full-controller-a/exit.json'),str(s/'full-bgc-f/exit.json')])
(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n')
with (r/'controller.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-u',str(b/'wait_capacity_canonical_f.py')],cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d['pid']=p.pid;(r/'launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

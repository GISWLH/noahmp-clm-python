from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile
from datetime import datetime,timezone
b=Path('/home/lhwang/work/noahmp-v1');s=b/'richards-station-native-a';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=json.loads((b/'richards-station-native-a-package.json').read_text());a=b/'richards-station-native-a-source.tar.gz'
assert sha(a)==package['archive_sha256'] and not s.exists()
prior=b/'richards-station-numpy-a-receipt.json';d=json.loads(prior.read_text())
assert sha(prior)==package['numpy_receipt_sha256'] and d['returncode']==0 and d['source_unchanged'] and d['counts']==dict(tests=55,failures=0,errors=0,skipped=0)
s.mkdir()
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==555 and sha(s/'SOURCE_SHA256.json')==package['manifest_sha256'] and all(sha(s/n)==h for n,h in m.items())
r.mkdir();controls={}
for name in ['collect_richards_station_a.py','control_richards_station_a.py','wait_richards_station_a.py','launch_richards_station_a.py']:
    controls[name]=sha(b/name)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PATH='/usr/local/cuda-12.4/bin:'+env.get('PATH',''),CUDA_VISIBLE_DEVICES='0',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(b/'jax-surface-cache'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONPATH=':'.join(map(str,[s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',NOAHMP_REQUIRE_GPU='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
with (r/'waiter.log').open('x') as log:p=subprocess.Popen([sys.executable,'-u',str(b/'wait_richards_station_a.py')],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(scope=package['scope'],utc=datetime.now(timezone.utc).isoformat(),pid=p.pid,device=0,status='waiting for actual552R-A wholeGPU5 exit0 and resource guards; no stationGPU pass',source_archive_sha256=package['archive_sha256'],source_manifest_sha256=package['manifest_sha256'],controls_sha256=controls)
(r/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

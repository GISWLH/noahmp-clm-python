from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'l6198-failure-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt=json.loads((r/'most-trace-a/receipt.json').read_text());assert receipt['source_unchanged'] and receipt['input_unchanged'] and receipt['iterations']==50
for file,key in [('history.json','history_sha256'),('last-surfaces.npz','surfaces_sha256')]:assert sha(r/'most-trace-a'/file)==receipt[key]
a=b/'l6198-most-trace-a-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(r.rglob('*')):
  if p.is_file():t.add(p,arcname='l6198-failure-a/'+p.relative_to(r).as_posix(),recursive=False)
 for n in ['trace_l6198_most_a.py','launch_l6198_trace_a.py','archive_l6198_trace_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

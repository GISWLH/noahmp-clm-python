"""Archive the complete immutable closed-generation preservation evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import tarfile
import zipfile

base = Path('/home/zhangyq/noahmp-v1')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
receipt_raw = (base / 'ec-closed-generation-archival-hi.json').read_bytes()
receipt = json.loads(receipt_raw)
assert len(receipt['cases']) == 2
items = {'receipt.json': receipt_raw,
    'archive_ec_closed_generations_hi.py': (base / 'archive_ec_closed_generations_hi.py').read_bytes(),
    'archive_reference_inode_evidence_hi.py': Path(__file__).read_bytes()}
for row in receipt['cases']:
    archive = base / row['root'] / row['archive']
    data = archive.read_bytes()
    assert sha(data) == row['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        raw = z.read('ARCHIVE_MANIFEST.json')
        manifest = json.loads(raw)
        assert sha(raw) == row['manifest_sha256']
        assert len(manifest['members']) == row['closed_files_losslessly_archived_and_unlinked'] == 66
        for member in manifest['members']:
            assert sha(z.read(member['name'])) == member['sha256']
    job = subprocess.check_output(['qstat', '-f', row['original_pbs_job']], text=True)
    assert re.search(r'^\s*job_state = R\s*$', job, re.M)
    items[row['root'] + '/' + row['archive']] = data
    items[row['root'] + '/actual-still-running-pbs.txt'] = job.encode()
items['snapshot.json'] = (json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    closed_files=132, original_source_manifest_sha256='96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20',
    source_scope='OriginalEC571 two independentNumPyyears, not currentFL579 science/fulltest credit',
    scope=receipt['scope']), indent=2) + '\n').encode()
archive = base / 'reference-inode-archival-hi-evidence.tar.gz'
assert not archive.exists()
import io
with tarfile.open(archive, 'w:gz') as tf:
    for name, raw in items.items():
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tf.addfile(info, io.BytesIO(raw))
with tarfile.open(archive) as tf:
    assert len(tf.getmembers()) == len(items)
    for member in tf:
        assert tf.extractfile(member).read() == items[member.name]
package = dict(archive_sha256=sha(archive.read_bytes()), artifacts=len(items), bytes=archive.stat().st_size,
    source_scope='EC571 originalreferencebytes132closedfiles, not currentFL579 numerical acceptance', scope=receipt['scope'])
(base / 'reference-inode-archival-hi-package.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps(package), flush=True)

"""One-off lossless archival of old inactive EC NumPy generation files only."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os
import re
import subprocess
import zipfile

base = Path('/home/zhangyq/noahmp-v1').resolve(strict=True)
output = base / 'ec-closed-generation-archival-hi.json'
assert not output.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
lock = (base / 'ec-closed-generation-archival-hi.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
records = []


def active_snapshot(folder):
    for _ in range(5):
        raw = (folder / 'report.json').read_bytes()
        report = json.loads(raw)
        protected = {}
        try:
            for key, digest in [('checkpoint_file', 'checkpoint_sha256'), ('model_npz', 'model_npz_sha256')]:
                path = folder / report[key]
                assert path.resolve(strict=True).parent == folder and not path.is_symlink()
                data = path.read_bytes()
                if sha(data) != report[digest]:
                    break
                protected[path.name] = report[digest]
            else:
                if (folder / 'report.json').read_bytes() == raw:
                    return raw, report, protected
        except FileNotFoundError:
            continue
    raise RuntimeError('No stable current generation; no file pruning allowed')


for name, job in [('qia-phase-capacity-numpy-year-em', '418.manager'),
                  ('qia-phase-capacity_optics-numpy-year-em', '424.manager')]:
    root = (base / name).resolve(strict=True)
    folder = (root / 'trajectory').resolve(strict=True)
    assert root.parent == base and folder.parent == root and not (base / name).is_symlink()
    source_manifest = (root / 'SOURCE_SHA256.json').read_bytes()
    assert sha(source_manifest) == '96f14894c91373e027eeeb334b3cf9965462216c9703a579d2d3428943e69a20'
    status = subprocess.check_output(['qstat', '-f', job], text=True)
    assert re.search(r'^\s*job_state = R\s*$', status, re.M)
    raw_report, report, protected = active_snapshot(folder)
    assert report['status'] == 'running' and 'failure' not in report and report['source_unchanged']
    assert report['steps_requested'] == 17520
    config_raw = (root / 'config.json').read_bytes()
    assert sha(config_raw) == report['configuration_sha256']
    index = report['steps_completed']
    selected = []
    for path in sorted(folder.iterdir()):
        match = re.fullmatch(r'(state|trace)-([0-9]{7})\.(pkl|npz)', path.name)
        if not match or int(match[2]) >= index - 96:
            continue
        assert path.name not in protected and path.resolve(strict=True).parent == folder and not path.is_symlink()
        assert path.suffix == ('.pkl' if match[1] == 'state' else '.npz')
        raw = path.read_bytes()
        selected.append(dict(name=path.name, index=int(match[2]), sha256=sha(raw), bytes=len(raw)))
    assert selected and len(selected) % 2 == 0
    generations = {q['index'] for q in selected}
    assert all({q['name'].split('-')[0] for q in selected if q['index'] == i} == {'state', 'trace'} for i in generations)
    archive = root / ('closed-generation-hi-before-' + str(index).zfill(7) + '.zip')
    assert not archive.exists() and archive.resolve().parent == root
    manifest = dict(source_manifest_sha256=sha(source_manifest), original_report_sha256=sha(raw_report),
                    active_index_at_selection=index, retained_buffer_steps=96, protected_at_selection=protected,
                    members=selected, original_pbs_job=job,
                    scope='Lossless closed EC reference generation archival, never currentFL579 science credit. Only literal generation pairs strictly older than currentindex minus96 may be unlinked after every byte SHA/CRC/fsync readback; current report/checkpoint/trace and lasttwo day generations retained. No model/source/control/config/state/ledger modification or restart.')
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        z.writestr('ARCHIVE_MANIFEST.json', manifest_raw)
        z.writestr('active-report-at-selection.json', raw_report)
        z.writestr('SOURCE_SHA256.json', source_manifest)
        z.writestr('config.json', config_raw)
        z.writestr('actual-pbs-status-at-selection.txt', status)
        for row in selected:
            data = (folder / row['name']).read_bytes()
            assert sha(data) == row['sha256']
            z.writestr(row['name'], data)
    with archive.open('rb') as stream:
        os.fsync(stream.fileno())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and z.read('ARCHIVE_MANIFEST.json') == manifest_raw
        for row in selected:
            assert sha(z.read(row['name'])) == row['sha256']
    current_raw, current, active = active_snapshot(folder)
    assert current['status'] == 'running' and current['steps_completed'] >= index
    for row in selected:
        path = folder / row['name']
        assert row['index'] < current['steps_completed'] - 96
        assert path.resolve(strict=True).parent == folder and path.name not in active and not path.is_symlink()
        assert sha(path.read_bytes()) == row['sha256']
    for row in selected:
        (folder / row['name']).unlink()
    _, final, final_active = active_snapshot(folder)
    assert final['status'] == 'running' and final['steps_completed'] >= index
    assert (root / 'SOURCE_SHA256.json').read_bytes() == source_manifest and (root / 'config.json').read_bytes() == config_raw
    records.append(dict(root=name, original_pbs_job=job, archive=archive.name,
        archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
        manifest_sha256=sha(manifest_raw), closed_files_losslessly_archived_and_unlinked=len(selected),
        first_archived_index=min(generations), last_archived_index=max(generations),
        selected_active_index=index, final_active_index=final['steps_completed'], active_files_after=final_active,
        original_report_at_selection_sha256=sha(raw_report), literal_targets_verified_inside_named_root=True,
        every_archive_member_sha_crc_fsync_verified_before_unlink=True))
result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), cases=records,
              scope='Metadata/archive I/O only on EHPC login; original two EC NumPy processes remain running, no numerical execution/restart/source/controls/config/initialstate/ledgers changed. All archived physical bytes remain restorable in verified ZIPs; current and buffered generations remain live.')
with output.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result), flush=True)

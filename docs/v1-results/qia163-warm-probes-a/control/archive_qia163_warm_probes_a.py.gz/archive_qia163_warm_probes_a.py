from pathlib import Path
import hashlib
import json
import tarfile

b=Path('/home/zhangyq/noahmp-v1');a=b/'qia163-warm-probes-a-evidence.tar.gz';assert not a.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(a,'w:gz') as t:
    for name in ['qia-stem-numpy-163-warm-a','qia-stem-numpy-163-warm-b','qia-stem-numpy-163-warm-fixture-a','qia163-warm-fixture-export-a']:
        r=b/name
        for p in sorted(r.rglob('*')):
            if p.is_file():t.add(p,arcname=name+'/'+p.relative_to(r).as_posix(),recursive=False)
    t.add(Path(__file__),arcname='control/'+Path(__file__).name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,scope='Actual PBS202 failed lower-initial-residual seed selection,203 successful causal prior-root preference,204 real-call capture,205 typed JSON serialization. No changed original failed year,extra iteration budget or conservation waiver.')))

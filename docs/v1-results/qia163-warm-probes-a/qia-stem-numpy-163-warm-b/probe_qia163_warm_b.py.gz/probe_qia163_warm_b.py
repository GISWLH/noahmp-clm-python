from pathlib import Path
import hashlib
import inspect
import json
import os
import pickle
import sys
import tarfile
import time
import traceback

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia-stem-numpy-163-warm-b'
scratch = Path(os.environ['TMPDIR']) / r.name
scratch.mkdir()
s = scratch / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-phase-final-check-a-source.tar.gz'
assert sha(a) == '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
manifest = json.loads((s / 'SOURCE_SHA256.json').read_text())
assert len(manifest) == 506 and all(sha(s / n) == h for n, h in manifest.items())
sys.path[:0] = [str(b / 'test-deps'), str(s), str(s / 'src'), str(s / 'benchmarks')]
import numpy as np
import run_fluxnet_column as original
from noahmp_clm.physics import canopy_phase_energy as phase

old = b / 'qia-stem-numpy-week-a'
receipt = json.loads((old / 'receipt.json').read_text())
report = json.loads((old / 'trajectory/report.json').read_text())
assert receipt['returncode'] == 1 and receipt['source_unchanged'] and report['steps_completed'] == report['failed_index'] == 163
assert sha(old / 'trajectory/report.json') == receipt['report_sha256']
assert sha(old / 'trajectory' / report['checkpoint_file']) == report['checkpoint_sha256']
old_manifest = json.loads((old / 'SOURCE_SHA256.json').read_text())
assert [n for n in manifest if n.startswith('src/') and old_manifest[n] != manifest[n]] == ['src/noahmp_clm/physics/canopy_phase_energy.py']
state, initial, net, bounds, maximum, stepmax, index = pickle.loads((old / 'trajectory' / report['checkpoint_file']).read_bytes())
assert index == 163
inputs = b / 'qia-stem-inputs-a/inputs'
protocol = json.loads((inputs.parent / 'protocol.json').read_text())
assert all(sha(inputs / n) == h for n, h in protocol['inputs_sha256'].items())
config = json.loads((inputs / 'CN-Qia-stem-config.json').read_text())
metadata = json.loads((inputs / 'CN-Qia.json').read_text())
with np.load(inputs / 'CN-Qia.npz', allow_pickle=False) as z:
    data = dict(z)
stamps = original.validate_input(data, metadata, inputs / 'CN-Qia.npz')
f = original.Forcing(*data['forcing'][index])
co2, mu, diffuse = data['environment'][index]
environment = original.calendar(stamps[index], metadata, config['phenology'] is not None)
schedule = original.DepositionSchedule(config)
dep = schedule.aerosol(stamps[index], f.dt)
nitrogen = schedule.nitrogen_rate * f.dt
geometry = original.MOSTGeometry(**config['most_geometry'])
leaf = original.LeafParameters(**config['leaf_parameters'])
import inspect
real = phase.solve_canopy_phase_energy
source = inspect.getsource(real)
marker = '    restart_available=not np.array_equal(x,alternative);restarts=0'
assert source.count(marker) == 1
injection = "    if warm_seed is not None:\n        seeded=np.asarray(warm_seed,float).copy()\n        if fixed_ground_temperature is not None:seeded[n]=fixed_ground_temperature\n        if seeded.shape==x.shape and np.all(np.isfinite(seeded)) and np.all((seeded>=lower)&(seeded<=upper)):\n            seeded_res=evaluate(seeded)\n            warm_guess_audit.append(dict(original_norm=float(evaluate(x)@evaluate(x)),seed_norm=float(seeded_res@seeded_res)))\n            alternative=x.copy();x=seeded\n"
instrumented = source.replace(marker, injection + marker)
guess_audit=[]
namespace = dict(real.__globals__, warm_seed=None, warm_guess_audit=guess_audit)
exec(compile(instrumented, '<Qia163 causal phase warm guess>', 'exec'), namespace)
solve = namespace['solve_canopy_phase_energy']
cache = dict(key=None, seed=None)
calls = []

def wrapped(*args, **kwargs):
    old = args[4]
    key = (np.asarray(args[0]).tobytes(), old.mass.tobytes(), old.enthalpy.tobytes(), float(args[5]))
    hit = key == cache['key']
    namespace['warm_seed'] = cache['seed'] if hit else None
    try:
        result = solve(*args, **kwargs)
    except Exception:
        (r / 'failed-phase-call.pkl').write_bytes(pickle.dumps(dict(args=args, kwargs=kwargs, causal_seed=namespace['warm_seed'])))
        raise
    # Old dry layers use temperature offsets, not a newly activated wet
    # plateau coordinate. Old extensive water/enthalpy is never replaced.
    seed = np.r_[np.where(old.mass>0., result['phase_coordinates'], result['leaf_temperature']-phase.TF), result['ground_temperature'], result['canopy_humidity']*1000.]
    cache.update(key=key, seed=seed)
    calls.append(dict(causal_same_old_store_cache_hit=hit, iterations=result['iterations'], solver_residual_max=float(np.max(abs(result['solver_residual']))), parcel_energy_residual_max=float(np.max(abs(result['layer_residual'])))))
    return result

phase.solve_canopy_phase_energy = wrapped
start = time.monotonic()
failure, result = None, None
try:
    after, d = original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
    incoming, residual, bound = original.audit_step(state, after, f, d, nitrogen)
    cumulative = original.totals(after) - initial - (net + incoming)
    assert np.all(abs(residual)<=bound) and np.all(abs(cumulative)<=bounds+bound)
    (r / 'diagnostic-step164.pkl').write_bytes(pickle.dumps((state, after, f, d)))
    result = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=(bounds+bound).tolist(), diagnostics={k:float(d[v]) for k,v in original.TRACE.items()}, diagnostic_state_sha256=sha(r/'diagnostic-step164.pkl'))
except Exception as e:
    failure = type(e).__name__+': '+str(e)
    (r/'traceback.txt').write_text(traceback.format_exc())
finally:
    phase.solve_canopy_phase_energy = real
assert all(sha(s/n)==v for n,v in manifest.items())
record = dict(scope='EHPC original failed NumPy163 one-step numerical warm-start hypothesis, source files unchanged. First phase uses original guess, later calls may use only an already solved root from same current step/old leaf area/mass/enthalpy; Valid prior same-step root is preferred; best original/ambient root retained as the original stalled-step alternative. Raw starting norms retained: a lower initial residual alone does not determine the correct phase basin. No new state/heat, future-state input, extra iteration budget or tolerance/gate changes. Original failed year stays immutable; this is not production or scientific acceptance.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, failure=failure, result=result, calls=calls, guess_audit=guess_audit, source_unchanged=True, original_failed_checkpoint_sha256=report['checkpoint_sha256'], instrumented_function_sha256=hashlib.sha256(instrumented.encode()).hexdigest(), seconds=time.monotonic()-start)
(r/'probe.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='calls'}, allow_nan=False), flush=True)
assert failure is None

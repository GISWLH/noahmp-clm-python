from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'probe_qia163_warm_a.py').read_text().replace('qia-stem-numpy-163-warm-a', 'qia-stem-numpy-163-warm-b')
old = '            if seeded_res@seeded_res<evaluate(x)@evaluate(x):alternative=x.copy();x=seeded'
new = '            warm_guess_audit.append(dict(original_norm=float(evaluate(x)@evaluate(x)),seed_norm=float(seeded_res@seeded_res)))\\n            alternative=x.copy();x=seeded'
assert p.count(old) == 1
p = p.replace(old, new)
p = p.replace('namespace = dict(real.__globals__, warm_seed=None)', 'guess_audit=[]\nnamespace = dict(real.__globals__, warm_seed=None, warm_guess_audit=guess_audit)')
p = p.replace('result = solve(*args, **kwargs)', "try:\n        result = solve(*args, **kwargs)\n    except Exception:\n        (r / 'failed-phase-call.pkl').write_bytes(pickle.dumps(dict(args=args, kwargs=kwargs, causal_seed=namespace['warm_seed'])))\n        raise")
p = p.replace('calls=calls, source_unchanged=True', 'calls=calls, guess_audit=guess_audit, source_unchanged=True')
p = p.replace('best original/ambient guess retained unless seed has lower complete residual.', 'Valid prior same-step root is preferred; best original/ambient root retained as the original stalled-step alternative. Raw starting norms retained: a lower initial residual alone does not determine the correct phase basin.')
ast.parse(p)
(r / 'probe_qia163_warm_b.py').write_bytes(p.encode())
p = (r / 'qia163_warm_a.pbs').read_text().replace('qia-stem-numpy-163-warm-a', 'qia-stem-numpy-163-warm-b').replace('probe_qia163_warm_a.py', 'probe_qia163_warm_b.py').replace('clm-qia-163-warm-a', 'clm-qia-163-warm-b')
(r / 'qia163_warm_b.pbs').write_bytes(p.encode())

from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'probe_qia_stem_numpy_163_c.py').read_text().split('start = time.monotonic()', 1)[0]
p = p.replace('qia-stem-numpy-163-c', 'qia-stem-numpy-163-warm-a')
p += '''import inspect
real = phase.solve_canopy_phase_energy
source = inspect.getsource(real)
marker = '    restart_available=not np.array_equal(x,alternative);restarts=0'
assert source.count(marker) == 1
injection = "    if warm_seed is not None:\\n        seeded=np.asarray(warm_seed,float).copy()\\n        if fixed_ground_temperature is not None:seeded[n]=fixed_ground_temperature\\n        if seeded.shape==x.shape and np.all(np.isfinite(seeded)) and np.all((seeded>=lower)&(seeded<=upper)):\\n            seeded_res=evaluate(seeded)\\n            if seeded_res@seeded_res<evaluate(x)@evaluate(x):alternative=x.copy();x=seeded\\n"
instrumented = source.replace(marker, injection + marker)
namespace = dict(real.__globals__, warm_seed=None)
exec(compile(instrumented, '<Qia163 causal phase warm guess>', 'exec'), namespace)
solve = namespace['solve_canopy_phase_energy']
cache = dict(key=None, seed=None)
calls = []

def wrapped(*args, **kwargs):
    old = args[4]
    key = (np.asarray(args[0]).tobytes(), old.mass.tobytes(), old.enthalpy.tobytes(), float(args[5]))
    hit = key == cache['key']
    namespace['warm_seed'] = cache['seed'] if hit else None
    result = solve(*args, **kwargs)
    # Old dry layers use temperature offsets, not a newly activated wet
    # plateau coordinate. Old extensive water/enthalpy is never replaced.
    seed = np.r_[np.where(old.mass>0., result['phase_coordinates'], result['leaf_temperature']-phase.TF), result['ground_temperature'], result['canopy_humidity']*1000.]
    cache.update(key=key, seed=seed)
    calls.append(dict(causal_same_old_store_cache_hit=hit, iterations=result['iterations'], solver_residual_max=float(np.max(abs(result['solver_residual']))), parcel_energy_residual_max=float(np.max(abs(result['layer_residual'])))))
    return result

phase.solve_canopy_phase_energy = wrapped
start = time.monotonic()
failure, result = None, None
try:
    after, d = original.step_clm_enthalpy_column(state, f, co2_ppm=float(co2), cosine_zenith=float(mu), diffuse_fraction=float(diffuse), leaf_dimension=config['leaf_dimension_m'], leaf_parameters=leaf, most_geometry=geometry, phenology_environment=environment, deposition_rates=dep, nitrogen_deposition_gn_m2=nitrogen)
    incoming, residual, bound = original.audit_step(state, after, f, d, nitrogen)
    cumulative = original.totals(after) - initial - (net + incoming)
    assert np.all(abs(residual)<=bound) and np.all(abs(cumulative)<=bounds+bound)
    (r / 'diagnostic-step164.pkl').write_bytes(pickle.dumps((state, after, f, d)))
    result = dict(step_residual_m_h_c_n=residual.tolist(), original_step_bounds_m_h_c_n=bound.tolist(), cumulative_residual_m_h_c_n=cumulative.tolist(), original_cumulative_bounds_m_h_c_n=(bounds+bound).tolist(), diagnostics={k:float(d[v]) for k,v in original.TRACE.items()}, diagnostic_state_sha256=sha(r/'diagnostic-step164.pkl'))
except Exception as e:
    failure = type(e).__name__+': '+str(e)
    (r/'traceback.txt').write_text(traceback.format_exc())
finally:
    phase.solve_canopy_phase_energy = real
assert all(sha(s/n)==v for n,v in manifest.items())
record = dict(scope='EHPC original failed NumPy163 one-step numerical warm-start hypothesis, source files unchanged. First phase uses original guess, later calls may use only an already solved root from same current step/old leaf area/mass/enthalpy; best original/ambient guess retained unless seed has lower complete residual. No new state/heat, future-state input, extra iteration budget or tolerance/gate changes. Original failed year stays immutable; this is not production or scientific acceptance.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, failure=failure, result=result, calls=calls, source_unchanged=True, original_failed_checkpoint_sha256=report['checkpoint_sha256'], instrumented_function_sha256=hashlib.sha256(instrumented.encode()).hexdigest(), seconds=time.monotonic()-start)
(r/'probe.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\\n')
print(json.dumps({k:v for k,v in record.items() if k!='calls'}, allow_nan=False), flush=True)
assert failure is None
'''
ast.parse(p)
(r / 'probe_qia163_warm_a.py').write_bytes(p.encode())
p = (r / 'qia_stem_numpy_163_c.pbs').read_text().replace('qia-stem-numpy-163-c', 'qia-stem-numpy-163-warm-a').replace('probe_qia_stem_numpy_163_c.py', 'probe_qia163_warm_a.py').replace('clm-qia-163-fixed-c', 'clm-qia-163-warm-a')
(r / 'qia163_warm_a.pbs').write_bytes(p.encode())

from pathlib import Path
from dataclasses import fields, is_dataclass
import hashlib
import json
import math
import os
import pickle
import sys
import tarfile

assert os.environ.get('PBS_JOBID')
b = Path('/home/zhangyq/noahmp-v1')
r = b / 'qia163-warm-fixture-export-a'
s = Path(os.environ['TMPDIR']) / 'source'
s.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = b / 'p6-phase-final-check-a-source.tar.gz'
assert sha(a) == '0a79196145ac51692e27c72f0b689c4ee631e41420313e808bc278a703904f87'
with tarfile.open(a) as t:
    t.extractall(s, filter='data')
sys.path[:0] = [str(b / 'test-deps'), str(s / 'src')]
import numpy as np

old = b / 'qia-stem-numpy-163-warm-fixture-a'
assert (old / 'pbs-exit.txt').read_text().strip() == '0'
record = json.loads((old / 'probe.json').read_text())
assert record['failure'] is None and any(v['seed_norm'] > v['original_norm'] for v in record['guess_audit'])
p = old / 'higher-residual-call.pkl'
call = pickle.loads(p.read_bytes())

def clean(value):
    if is_dataclass(value):
        return dict(__type__=type(value).__name__, data={f.name: clean(getattr(value, f.name)) for f in fields(value)})
    if isinstance(value, np.ndarray):
        return dict(__array__=clean(value.tolist()), dtype=str(value.dtype))
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        assert not math.isnan(value)
        return dict(__float__='inf' if value > 0 else '-inf')
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value

result = dict(scope='Actual Qia163 same-step phase call where the causal prior root has a larger initial residual than the old/ambient guess. Typed data only; no pickled executable in test fixture. Original step/call in archived probes, not a fitted or future-step seed.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, original_call_sha256=sha(p), original_probe_sha256=sha(old / 'probe.json'), call=clean(call))
output = r / 'qia_163_phase_warm.json'
output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(scope='Metadata serialization only on EHPC PBS,no physics/model execution.', pbs_job=os.environ['PBS_JOBID'], node=os.uname().nodename, fixture_sha256=sha(output), original_call_sha256=sha(p), bytes=output.stat().st_size)), flush=True)

from pathlib import Path
import ast

r = Path(__file__).resolve().parent
p = (r / 'probe_qia163_warm_b.py').read_text().replace('qia-stem-numpy-163-warm-b', 'qia-stem-numpy-163-warm-fixture-a')
marker = '    result = solve(*args, **kwargs)'
assert p.count(marker) == 1
p = p.replace("    try:\n    " + marker, "    prior_guess=None if namespace['warm_seed'] is None else np.asarray(namespace['warm_seed']).copy()\n    prior_audits=len(guess_audit)\n    try:\n    " + marker)
marker = '    # Old dry layers use temperature offsets, not a newly activated wet'
assert p.count(marker) == 1
p = p.replace(marker, "    if len(guess_audit)>prior_audits and guess_audit[-1]['seed_norm']>guess_audit[-1]['original_norm'] and not (r/'higher-residual-call.pkl').exists():\n        (r/'higher-residual-call.pkl').write_bytes(pickle.dumps(dict(args=args,kwargs=kwargs,initial_guess=prior_guess)))\n" + marker)
ast.parse(p)
(r / 'probe_qia163_warm_fixture_a.py').write_bytes(p.encode())
p = (r / 'qia163_warm_b.pbs').read_text().replace('qia-stem-numpy-163-warm-b', 'qia-stem-numpy-163-warm-fixture-a').replace('probe_qia163_warm_b.py', 'probe_qia163_warm_fixture_a.py').replace('clm-qia-163-warm-b', 'clm-qia-163-fixture')
(r / 'qia163_warm_fixture_a.pbs').write_bytes(p.encode())

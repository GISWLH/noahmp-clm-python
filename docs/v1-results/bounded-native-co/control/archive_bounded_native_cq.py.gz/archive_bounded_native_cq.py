from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');r=b/'bounded-native-co';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((r/'exit.json').read_text());assert d['passed'] and d['returncode']==0 and d['source_unchanged'] and len(d['records'])==3 and all(q['passed'] and q['actual_parent_returncode']==0 for q in d['records']);c=json.loads((r/'collection.json').read_text());assert c['passed'] and c['total_count']==1517 and c['gpu_count']==398
for name,count in [('test_gpu_finite_volume',8),('test_gpu_richards',4),('test_gpu_richards_enthalpy',4)]:
    q=json.loads((r/(name+'-receipt.json')).read_text());assert q['passed'] and q['worker_exitcode']==q['pytest_returncode']==0 and q['node_coverage_exact'] and q['all_setup_call_teardown_phases_passed'] and q['source_unchanged'] and q['counts']==dict(tests=count,failures=0,errors=0,skipped=0) and q['xml_sha256']==sha(r/(name+'.xml')) and all(p['status']=='complete' for p in q['device_barriers'])
items=[(p,'bounded-native-co/'+p.relative_to(r).as_posix()) for p in sorted(r.rglob('*')) if p.is_file()];items.extend((b/n,'control/'+n) for n in ['clm-bounded-native-cn-source.tar.gz','clm-bounded-native-cn-package.json','clm-bounded-numpy-ck-source.tar.gz','bounded-numpy-ck-full-receipt.json',Path(__file__).name]);assert all(p.is_file() for p,n in items);a=b/'bounded-native-co-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for p,n in items:tf.add(p,arcname=n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items),records=d['records'])),flush=True)

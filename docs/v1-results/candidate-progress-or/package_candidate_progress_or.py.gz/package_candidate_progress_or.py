"""Preserve the requested GPU status and reproducible metadata ETA arithmetic."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path(__file__).resolve().parent
names = ['candidate-progress-or.json', 'candidate-progress-or.stderr',
         'review_candidate_concurrency_nt.py', 'GPU_ETA_NQ.json',
         'GPU_ETA_NQ_OO_REFRESH.json', 'GPU_ETA_NQ_OR_REFRESH.json',
         'refresh_gpu_eta_or.py', 'estimate_annual_progress_or.py',
         'candidate-progress-or-annual-timing.json', 'GPU_ETA_NQ_OR_REFRESH.md',
         'package_candidate_progress_or.py']
files = {name: (root / name).read_bytes() for name in names}
sha = lambda raw: hashlib.sha256(raw).hexdigest()
eta = json.loads(files['GPU_ETA_NQ_OR_REFRESH.json'])
annual = json.loads(files['candidate-progress-or-annual-timing.json'])
assert eta['accounting']['credited_total'] == 127
assert all(sha(files[name]) == value for name, value in eta['input_sha256'].items())
assert sha(files['candidate-progress-or.json']) == annual['snapshot_sha256']
assert sha(files['refresh_gpu_eta_or.py']) == eta['script_sha256']
assert sha(files['estimate_annual_progress_or.py']) == annual['script_sha256']
assert files['candidate-progress-or.stderr'] == b''
files['artifact-inventory.json'] = (json.dumps({name: dict(bytes=len(raw), sha256=sha(raw))
                                             for name, raw in files.items()}, indent=2) + '\n').encode()
target = root / 'candidate-progress-or-evidence.tar.gz'
package = root / 'candidate-progress-or-package.json'
assert not target.exists() and not package.exists()
with tarfile.open(target, 'w:gz') as archive:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
result = dict(archive=target.name, sha256=sha(target.read_bytes()), artifacts=len(files),
              scope='Read-only CUDA1 status at 09:12 UTC; regression 127/408 and conditional ETA, no model/test execution or source modification.')
package.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))

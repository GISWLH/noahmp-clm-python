# CUDA1 progress and conditional completion estimate

Snapshot: 2026-10-25 09:12:30 UTC. All six task controller/worker processes
remain bound to physical CUDA1, UUID
`GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452`.

The NQ regression has completed 18 fresh whole files / 95 nodes. Adding the
32 previously completed specialist nodes with checked dependency identities
gives **127/408**, with 54 files / 281 nodes remaining. The irrigation module
is running and is not counted as completed. All closed parent return codes
are zero; no active module's elapsed time is subtracted from its estimate.

The original timing formula gives **23.2088–45.6652 hours remaining** for the
regression queue. Its older-history factors remain 1.3 and 2.6; no favorable
refit is made from the newly completed modules. This is a planning range,
not a confidence interval or promised completion time.

| Concurrent annual run | Saved steps | Measured prefix used | Seconds / batch step | Straight-line remaining hours |
|---|---:|---:|---:|---:|
| NS: 12 climatology configurations | 624 / 17520 | 240–624 | 9.84367 | 46.1996 |
| NZ: three HRLDAS configurations | 720 / 17520 | 240–720 | 9.09681 | 42.4518 |

These annual projections use the workers' existing elapsed-time logs, not
additional model runs or verified annual throughput. They describe a winter
prefix under concurrent regression load. Seasonal changes, new compilation,
resource contention or failures can alter them substantially. The annual
runs are concurrent, so their hours must not be added as sequential wall time.

For the currently running GPU work, approximately two days is a conditional
planning allowance. Later climate/SOC spinup, calibration, held-out evaluation
and the v1.0.0 release are not included. The old EC optical year completed
normally and its scientific discrepancies remain documented separately.

The raw read-only snapshot, original timing basis, and the two metadata-only
calculation scripts accompany this note. No production source, queue, cache,
checkpoint, input or physics threshold was changed for this estimate.

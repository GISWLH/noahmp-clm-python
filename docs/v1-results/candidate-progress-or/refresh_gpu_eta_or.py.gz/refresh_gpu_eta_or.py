"""Metadata-only ETA refresh; retain the original per-module timing formula."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math

root = Path(__file__).resolve().parent
names = ('GPU_ETA_NQ.json', 'GPU_ETA_NQ_OO_REFRESH.json', 'candidate-progress-or.json')
raw = {name: (root / name).read_bytes() for name in names}
original, prior, snapshot = (json.loads(raw[name]) for name in names)
modules = {row['file']: row for row in original['modules_in_execution_order']}
closed = snapshot['closed']
assert len({row['file'] for row in closed}) == len(closed)
for row in closed:
    assert row['actual_parent_returncode'] == 0 and row['passed'] is True
    assert row['expected_tests'] == modules[row['file']]['tests']
    assert math.isfinite(row['seconds']) and row['seconds'] > 0
closed_names = {row['file'] for row in closed}
assert set(prior['removed_actual_closed_files_in_execution_order']) <= closed_names
remaining = [row for name, row in modules.items() if name not in closed_names]
recent = [row for row in remaining if row['timing_group'] in ('JO_recent', 'IV_recent')]
older = [row for row in remaining if row not in recent]
assert len(older) == 49  # No older-history tail has completed in this snapshot.
recent_seconds = math.fsum(row['baseline_min_seconds'] for row in recent)
assert all(row['baseline_min_seconds'] == row['baseline_max_seconds'] for row in recent)
older_seconds = [math.fsum(row['baseline_' + key + '_seconds'] for row in older)
                 for key in ('min', 'max')]
hours = [(recent_seconds + factor * seconds) / 3600
         for factor, seconds in zip((1.3, 2.6), older_seconds)]
retained = sum(row['tests'] for row in snapshot['progress']['reused'])
new = sum(row['expected_tests'] for row in closed)
assert retained == 32 and new + sum(row['tests'] for row in remaining) + retained == 408
assert snapshot['progress']['file'] not in closed_names
workers = snapshot['second']['processes']
expected_uuid = 'GPU-cf7322ad-e2e0-ddd3-76d7-a07e2dd73452'
assert all(row['environment']['CUDA_VISIBLE_DEVICES'] == expected_uuid for row in workers)
output = dict(
    sample_utc=datetime.fromisoformat(snapshot['second']['utc']).astimezone(timezone.utc).isoformat(),
    scope='Metadata-only refresh; no new remote sample, model, parameter or timing-factor change.',
    input_sha256={name: hashlib.sha256(value).hexdigest() for name, value in raw.items()},
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    physical_gpu=1, gpu_uuid=expected_uuid,
    accounting=dict(completed_new_files=len(closed), completed_new_nodes=new,
                    retained_actual_nodes=retained, credited_total=new + retained,
                    total_gpu_nodes=408, remaining_files=len(remaining),
                    remaining_nodes=sum(row['tests'] for row in remaining),
                    current_file=snapshot['progress']['file'],
                    current_module_elapsed_subtracted_seconds=0),
    formula=original['estimate']['formula'],
    remaining_recent_baseline_hours=recent_seconds / 3600,
    remaining_older_baseline_hours=[seconds / 3600 for seconds in older_seconds],
    remaining_hours=hours,
    newly_closed=[row for row in closed if row['file'] not in
                  prior['removed_actual_closed_files_in_execution_order']],
    actual_closed_parent_seconds=math.fsum(row['seconds'] for row in closed),
    removed_actual_closed_files_in_execution_order=[row['file'] for row in closed],
    annual_progress={key: {field: value[field] for field in
                          ('status', 'steps_completed', 'steps_requested', 'ledger_steps', 'ledger_segments')}
                     for key, value in snapshot['years'].items()},
    limitations=[
        'A conditional planning range, not a guaranteed interval or release date.',
        'All 49 older-history modules remain; the original heavy-tail factors are unchanged.',
        'The running irrigation module retains its full baseline; its elapsed time is not credited.',
        'Fresh compilation, contention, failures, retries and resource waits can exceed this range.',
        'NS/NZ annual simulations, subsequent spinup and calibration are outside this test-queue ETA.',
    ],
)
path = root / 'GPU_ETA_NQ_OR_REFRESH.json'
assert not path.exists()
path.write_text(json.dumps(output, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps({key: output[key] for key in ('sample_utc', 'accounting', 'remaining_hours', 'annual_progress')}))

"""Read existing progress metadata only; this is not model throughput validation."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
source = root / 'candidate-progress-or.json'
raw = source.read_bytes()
snapshot = json.loads(raw)
rows = []
for name, year in snapshot['years'].items():
    logs = [json.loads(line) for line in year['log_tail']]
    first = next(row for row in logs if row['steps'] == 240)
    last = logs[-1]
    assert last['steps'] == year['steps_completed'] and year['status'] == 'running'
    rate = (last['seconds'] - first['seconds']) / (last['steps'] - first['steps'])
    rows.append(dict(run=name, observed_steps=[first['steps'], last['steps']],
                     observed_worker_seconds=[first['seconds'], last['seconds']],
                     observed_seconds_per_batch_step=rate,
                     remaining_steps=year['steps_requested'] - last['steps'],
                     straight_line_remaining_hours=rate * (year['steps_requested'] - last['steps']) / 3600))
result = dict(sample_time=snapshot['second']['utc'], snapshot_sha256=hashlib.sha256(raw).hexdigest(),
              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), runs=rows,
              scope='Metadata arithmetic from original worker elapsed timestamps, no model execution.',
              limitations=[
                  'Only winter prefix under concurrent GPU regression; not measured full-year performance.',
                  'Seasonal physics, compilation, contention and failures can change throughput substantially.',
                  'Runs execute concurrently; their hours must not be added as sequential wall time.',
                  'No later climate cycles, SOC spinup, calibration or release ETA is included.',
              ])
out = root / 'candidate-progress-or-annual-timing.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(result))

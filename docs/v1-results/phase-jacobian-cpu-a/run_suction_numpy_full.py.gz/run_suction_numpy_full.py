"""Full CPU-file collection under frozen integrated NumPy source on PBS."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text());assert all(sha(root/n)==v for n,v in manifest.items())
files=sorted(str(p) for p in Path('tests').glob('test_*.py') if not p.name.startswith('test_gpu'))
assert len(files)>=80
(root/'cpu-full-selection.json').write_text(json.dumps(dict(scope='All CPU test files; GPU-named files execute separately on xuanze.',files=files),indent=2)+'\n')
begun=time.monotonic()
code=subprocess.run([sys.executable,'-m','pytest','-q',*files,'--junitxml=cpu-full.xml']).returncode
assert all(sha(root/n)==v for n,v in manifest.items())
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'cpu-full.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
(root/'cpu-full-receipt.json').write_text(json.dumps(dict(returncode=code,seconds=time.monotonic()-begun,counts=counts,source_files=len(manifest),source_unchanged=True,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename),indent=2)+'\n')
assert code==0 and all(counts[k]==0 for k in ['failures','errors','skipped'])

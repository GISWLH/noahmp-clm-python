from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess
base=Path('/home/lhwang/work/noahmp-v1');root=base/'p6-phase-short-circuit-gpu-a';legacy=base/'p6-short-circuit-legacy-replay-a'
control=json.loads((legacy/'cuda-replay.json').read_text());assert control['status']=='complete' and control['pre_change_baseline_bitwise_equal']
target=json.loads((root/'phase-target-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=9,failures=0,errors=0,skipped=0)
shadow_path=legacy/'jax-replay.json';shadow=json.loads(shadow_path.read_text()) if shadow_path.exists() else None
assert shadow is None or shadow['status']=='complete'
receipt=root/'full-by-file-launch.json';assert not receipt.exists()
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(PYTHONPATH='src:tests:benchmarks',CUDA_VISIBLE_DEVICES='1',CUDA_PATH='/usr/local/cuda-12.4',PATH='/usr/local/cuda-12.4/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',NOAHMP_REQUIRE_GPU='1',JAX_PLATFORMS='cuda',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_COMPILATION_CACHE_DIR=str(base/'jax-surface-cache'))
with (root/'full-by-file-controller.log').open('w') as log:p=subprocess.Popen(['/home/lhwang/venvs/noahmp-phase3b/bin/python','-u',str(root/'run_short_circuit_full_gpu.py')],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
data=dict(pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat(),gpu=1,extra_jax_whole_step_status='pending' if shadow is None else shadow['status'],scope='Current complete collection with EHPC PBS55 CPU710 receipt identity checked, every current GPU file freshly runs on xuanze. Target9 and exact CUDA whole-step complete; extra JAX whole-step can run concurrently, still separately pending. No pass/skip/convergence gate changed. Completion pending.')
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))

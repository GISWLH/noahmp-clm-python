"""Current collected suite: verified EHPC CPU receipt plus fresh xuanze GPU files."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
preflight='--preflight-only' in sys.argv
root=Path.cwd();out=root/('full-preflight-a' if preflight else 'full-by-file-a');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
def verify():
    assert all(sha(root/k)==v for k,v in manifest.items())
verify();started=time.monotonic()
def nodes(data):
    result=[];counts=dict(tests=0,failures=0,errors=0,skipped=0)
    for test in ET.fromstring(data).iter('testcase'):
        parts=test.attrib['classname'].split('.');indices=[k for k,v in enumerate(parts) if v.startswith('test_')];assert len(indices)==1
        k=indices[0];result.append('tests/'+parts[k]+'.py::'+'::'.join(parts[k+1:]+[test.attrib['name']]))
        counts['tests']+=1
        for key,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]:counts[key]+=int(test.find(tag) is not None)
    return result,counts
collection=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q'],capture_output=True,text=True)
(out/'collection.log').write_text(collection.stdout+collection.stderr);assert collection.returncode==0
all_nodes=[s.strip() for s in collection.stdout.splitlines() if s.startswith('tests/') and '::' in s]
assert all_nodes and len(set(all_nodes))==len(all_nodes)
gpu=lambda n:Path(n.split('::')[0]).name.startswith(('test_gpu','test_cuda','test_jax'))
cpu_expected={n for n in all_nodes if not gpu(n)};gpu_expected=set(all_nodes)-cpu_expected
archive=root/'phase-jacobian-cpu-b-evidence.tar.gz';assert sha(archive)=='d33b6bd646e63938a47bb72ee99bfdd703d27d8197e0cdb737f98d3d4b99ef1b'
with tarfile.open(archive) as t:
    old=json.load(t.extractfile('SOURCE_SHA256.json'));receipt=json.load(t.extractfile('cpu-full-receipt.json'))
    cpu_nodes,cpu_counts=nodes(t.extractfile('cpu-full.xml').read())
assert set(old)==set(manifest)
differences={n for n in manifest if old[n]!=manifest[n]}
code_differences={n for n in differences if n.startswith(('src/','tests/','benchmarks/','examples/'))}
assert code_differences=={'src/noahmp_clm/gpu/canopy_phase_energy.py','src/noahmp_clm/gpu/cuda/canopy_phase_energy_kernel.cu'},code_differences
assert set(cpu_nodes)==cpu_expected and len(cpu_nodes)==len(cpu_expected)
assert cpu_counts==dict(tests=710,failures=0,errors=0,skipped=0)
assert receipt['returncode']==0 and receipt['source_unchanged']
files=sorted({n.split('::')[0] for n in gpu_expected});covered=set(cpu_nodes);rows=[]
scope='Every current collected node: unchanged NumPy CPU/tests verified against EHPC PBS55 complete CPU receipt; current device tests each in fresh xuanze process. This is distributed coverage, not one-process pytest.'
selection=dict(scope=scope,all_nodes=all_nodes,gpu_files=files,cpu_counts=cpu_counts,cpu_receipt=receipt,cpu_archive_sha256=sha(archive),source_differences=sorted(differences),code_differences=sorted(code_differences),source_manifest_sha256=sha(root/'SOURCE_SHA256.json'),tool_sha256=sha(Path(__file__)))
(out/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
def save(active=None):
    report=dict(scope=scope,status='running',seconds=time.monotonic()-started,collected_nodes=len(all_nodes),covered_nodes=len(covered),gpu_files_completed=len(rows),gpu_files_total=len(files),active=active,results=rows,cpu_counts=cpu_counts)
    temp=out/'progress.json.tmp';temp.write_text(json.dumps(report,indent=2)+'\n');os.replace(temp,out/'progress.json')
save()
if preflight:
    print(json.dumps(dict(collected_nodes=len(all_nodes),cpu_nodes=len(cpu_nodes),gpu_nodes=len(gpu_expected),gpu_files=len(files),cpu_source_code_differences=sorted(code_differences))),flush=True)
    raise SystemExit(0)
for file in files:
    verify();name=Path(file).stem;begin=time.monotonic();xml=out/(name+'.xml')
    command=[sys.executable,'-m','pytest',file,'-q','-s','--junitxml='+str(xml)]
    with (out/(name+'.log')).open('wb') as log:
        child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        save(dict(file=file,pid=child.pid,started_unix=time.time(),command=command));code=child.wait()
    row=dict(file=file,pid=child.pid,returncode=code,seconds=time.monotonic()-begin)
    try:
        actual,counts=nodes(xml.read_bytes());expected={n for n in gpu_expected if n.split('::')[0]==file}
        exact=set(actual)==expected and len(actual)==len(expected)
        row.update(counts=counts,node_coverage_exact=exact,nodes=actual,passed=code==0 and exact and counts['failures']==counts['errors']==counts['skipped']==0)
        if exact:covered.update(actual)
    except Exception as e:row.update(passed=False,report_error=repr(e))
    rows.append(row);save();print(json.dumps({k:v for k,v in row.items() if k!='nodes'}),flush=True)
verify();complete=covered==set(all_nodes) and all(r['passed'] for r in rows)
report=dict(scope=scope,status='complete' if complete else 'failed',seconds=time.monotonic()-started,source_unchanged=True,all_node_coverage_exact=covered==set(all_nodes),collected_nodes=len(all_nodes),covered_nodes=len(covered),cpu_counts=cpu_counts,results=rows)
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if complete else 1)

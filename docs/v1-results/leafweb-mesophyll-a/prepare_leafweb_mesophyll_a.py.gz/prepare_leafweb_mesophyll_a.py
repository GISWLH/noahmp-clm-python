from pathlib import Path
import hashlib,json,shutil
base=Path('/home/zhangyq/noahmp-v1');root=base/'leafweb-mesophyll-a';assert not root.exists();root.mkdir()
source=base/'p6-phase-jacobian-gpu-b';old=base/'leafweb-electrons-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((source/'SOURCE_SHA256.json').read_text());assert all(sha(source/k)==v for k,v in m.items())
baseline=json.loads((old/'diagnostic.json').read_text());assert baseline['model_sha256']==sha(source/'src/noahmp_clm/physics/photosynthesis.py')
shutil.copyfile(old/'diagnostic.json',root/'electron-diagnostic.json')
(root/'source-identity.json').write_text(json.dumps(dict(source_manifest_sha256=sha(source/'SOURCE_SHA256.json'),model_sha256=baseline['model_sha256'],archive_sha256=sha(source/'tests/fixtures/leafweb_c3_grass.zip'),baseline_sha256=sha(root/'electron-diagnostic.json'),source_files=len(m)),indent=2)+'\n')
print(json.dumps(dict(root=str(root),source_files=len(m),model_matches_original_diagnostic=True)))

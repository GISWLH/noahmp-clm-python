"""Bounded non-PATH checks supplementing the existing-runtime read-only probe."""
from pathlib import Path
import datetime
import glob
import json
import re
import socket
import subprocess

known=['/usr/local/apptainer/bin/apptainer','/opt/apptainer/bin/apptainer',
       '/usr/local/singularity/bin/singularity','/opt/singularity/bin/singularity',
       '/usr/share/Modules/bin/modulecmd','/usr/share/lmod/lmod/libexec/lmod',
       '/opt/ohpc/admin/lmod/lmod/libexec/lmod','/etc/profile.d/modules.sh','/etc/profile.d/lmod.sh']
patterns=['/opt/*/bin/apptainer','/opt/*/bin/singularity','/opt/*/bin/podman','/opt/*/bin/docker',
    '/opt/*/bin/python3.12','/opt/*/bin/python3.13','/opt/*/bin/python3.14',
    '/usr/local/*/bin/python3.12','/usr/local/*/bin/python3.13',
    '/usr/share/Modules/modulefiles/*python*','/usr/share/modulefiles/*python*',
    '/opt/modulefiles/*python*','/apps/modulefiles/*python*',
    '/home/zhangyq/noahmp-v1/*python3.12*','/home/zhangyq/noahmp-v1/*py312*']
run=subprocess.run(['rpm','-qa','--qf','%{NAME}\t%{VERSION}-%{RELEASE}\n'],capture_output=True,text=True,timeout=15)
selected=[line for line in run.stdout.splitlines() if re.search(
    r'apptainer|singularity|podman|docker|containerd|^runc$|lmod|environment-modules|^python3[.-]?1[234]',line.split('\t')[0],re.I)]
sysctl={str(p):p.read_text().strip() for p in map(Path,['/proc/sys/user/max_user_namespaces','/proc/sys/kernel/unprivileged_userns_clone']) if p.exists()}
print(json.dumps(dict(node=socket.gethostname(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    known_paths={p:Path(p).exists() for p in known},matched_paths={p:glob.glob(p) for p in patterns},
    package_query_exit=run.returncode,matching_runtime_or_modern_python_packages=selected,package_query_stderr=run.stderr,
    user_namespace_metadata=sysctl,remote_mutations=False,container_starts=0,downloads=0,installations=0,
    scientific_imports=0,scope='Known-path existence and RPM metadata only; no exhaustive filesystem search.'),indent=2))

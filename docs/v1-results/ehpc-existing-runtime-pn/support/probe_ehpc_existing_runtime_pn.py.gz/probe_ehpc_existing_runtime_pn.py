"""Bounded read-only runtime/module/image metadata; no installation or containers."""
from pathlib import Path
import datetime
import glob
import hashlib
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import time


def command(argv, timeout=15):
    start=time.monotonic()
    try:
        run=subprocess.run(argv,capture_output=True,text=True,timeout=timeout)
        return dict(argv=argv,exit=run.returncode,stdout=run.stdout,stderr=run.stderr,seconds=time.monotonic()-start)
    except (OSError,subprocess.TimeoutExpired) as exc:
        return dict(argv=argv,error=type(exc).__name__+': '+str(exc),seconds=time.monotonic()-start)


node=socket.gethostname()
assert node in ('manager','compute002')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
names=['apptainer','singularity','podman','docker','module','modulecmd','python3.12','python3.13','python3.14','python3','conda']
available={n:shutil.which(n) for n in names}
versions={n:command([available[n],'--version']) for n in ['apptainer','singularity','podman','docker'] if available[n]}
module=command(['/bin/bash','-lc',"if type module >/dev/null 2>&1; then module -t avail 2>&1; elif command -v modulecmd >/dev/null 2>&1; then modulecmd bash avail 2>&1; else printf 'NO_MODULE_COMMAND\n'; fi"])
# No arbitrary shell/environment/configuration dumping and no auth-file reads.
patterns=['/usr/bin/python3*','/usr/local/bin/python3*','/opt/python*/bin/python3*',
    '/opt/conda/bin/python3*','/home/zhangyq/miniconda3/bin/python3*',
    '/home/zhangyq/anaconda3/bin/python3*','/home/zhangyq/.conda/envs/*/bin/python3*',
    '/home/zhangyq/venvs/*/bin/python3*']
candidates={str(Path(p).resolve()) for pattern in patterns for p in glob.glob(pattern)
            if Path(p).is_file() and re.fullmatch(r'python3(?:\.\d+)?',Path(p).name) and os.access(p,os.X_OK)}
for name in ['python3.12','python3.13','python3.14','python3']:
    if available[name]:candidates.add(str(Path(available[name]).resolve()))
assert len(candidates)<=50
python_checks=[command([p,'-I','-S','-c','import sys,platform,json; print(json.dumps(dict(executable=sys.executable,version=sys.version,libc=platform.libc_ver())))']) for p in sorted(candidates)]
image_patterns=['/home/zhangyq/containers/*.sif','/home/zhangyq/containers/*.simg',
    '/home/zhangyq/.cache/apptainer/cache/*.sif','/home/zhangyq/.cache/singularity/*.sif',
    '/opt/containers/*.sif','/opt/images/*.sif','/tmp/*.sif','/tmp/*.simg']
images=[dict(path=p,bytes=Path(p).stat().st_size) for pattern in image_patterns for p in glob.glob(pattern) if Path(p).is_file()]
container_queries=[]
if available['docker'] and Path('/var/run/docker.sock').exists():
    container_queries.append(command([available['docker'],'image','ls','--no-trunc','--format','{{.Repository}}\t{{.Tag}}\t{{.ID}}\t{{.Size}}']))
podman_storage=Path('/home/zhangyq/.local/share/containers/storage')
if available['podman'] and podman_storage.exists():
    container_queries.append(command([available['podman'],'images','--no-trunc','--format','{{.Repository}}\t{{.Tag}}\t{{.ID}}\t{{.Size}}']))
packages=command(['rpm','-qa','--qf','%{NAME}\t%{VERSION}-%{RELEASE}\n'])
if packages.get('exit')==0:
    packages['stdout']='\n'.join(line for line in packages['stdout'].splitlines() if re.search(r'(^|[-_])(python|apptainer|singularity|podman|docker|containerd|runc|lmod|modules)([-_\d]|$)',line,re.I))+'\n'
stat=os.statvfs('/tmp')
result=dict(started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),node=node,
    uid=os.getuid(),kernel=platform.release(),architecture=platform.machine(),
    os_release=Path('/etc/os-release').read_text() if Path('/etc/os-release').exists() else None,
    glibc=command(['getconf','GNU_LIBC_VERSION']),command_availability=available,container_versions=versions,
    module_inventory=module,python_search_patterns=patterns,python_checks=python_checks,
    image_search_patterns=image_patterns,existing_image_files=images,container_image_queries=container_queries,
    filtered_runtime_packages=packages,
    resources=dict(logical_cpus=os.cpu_count(),memory_info=Path('/proc/meminfo').read_text(),
        tmp_available_bytes=stat.f_bavail*stat.f_frsize,tmp_available_inodes=stat.f_favail),
    rootless_storage_present=podman_storage.exists(),docker_socket_present=Path('/var/run/docker.sock').exists(),
    scope='Read-only bounded known-path metadata. No installation, downloads, pulls, container start, scientific import, model execution or credentials read.',
    exhaustive_filesystem_search=False,source_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest() if Path(__file__).is_file() else None)
print(json.dumps(result,indent=2,allow_nan=False))

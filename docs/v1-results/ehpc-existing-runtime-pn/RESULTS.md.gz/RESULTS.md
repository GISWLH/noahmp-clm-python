# EHPC 同版本 JAX CPU 环境只读盘点

2026-10-25 13:03:58–13:04:56 UTC 对 manager 和 compute002 的检查均实际退出0。
两端是 CentOS7、getconf 确认 glibc2.17；现有可调用 Python 仅系统3.6.8和
closeout3.11.9。原xuanze软件元数据记录 jax/jaxlib0.11.2 均要求 Python>=3.12。

PATH、固定非PATH目录、RPM和login-shell模块查询均未找到
apptainer/singularity/podman/docker、module/modulecmd/Lmod或Python>=3.12。
限定镜像目录无SIF，Docker socket、用户rootless存储均不存在，user namespace
上限均为0。不是全文件系统穷举，不能排除未公开的自定义环境；当前没有可立即
使用且身份明确的同版本JAX CPU路径，保持“未测”。

最小后续路径是提供受支持的现有容器运行时和兼容目标binary的Python>=3.12镜像，
或相应现代计算环境/模块，再核实确切包版本和CPU-only短测。本次未安装、下载、
拉镜像、起容器、运行模型或读取凭据，也没有在xuanze执行任何动作。
旧JAX不能代替同环境验证；即使以后容器CPU测试通过，也不增加GPU验证信用。
GPU验证仍需xuanze CUDA1。

资源快照只表示48逻辑CPU及当时内存/临时盘余量，不代表全部CPU空闲。
原Python3.6的platform.libc_ver启发式返回2.3.4，与getconf的权威host版本不同；
原值保留，结论采用getconf实际2.17。没有自制glibc或扩展环境改造。

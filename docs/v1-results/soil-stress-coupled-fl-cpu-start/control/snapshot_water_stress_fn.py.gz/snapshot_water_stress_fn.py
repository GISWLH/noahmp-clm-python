"""Read-only point-in-time start/targeted proofs; not a completed campaign."""
from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,sys,tarfile
kind=sys.argv[1];assert kind in ('cpu','gpu');b=Path('/home/zhangyq/noahmp-v1' if kind=='cpu' else '/home/lhwang/work/noahmp-v1');r=b/('soil-stress-coupled-fl-'+kind);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());assert meta['manifest_sha256']=='ed7ad0396492b1401ea71cdb9c3291ad25c80042a095c4485f083760ce2b8d69';items={}
for p in sorted(r.iterdir()):
    if p.is_file():items['campaign/'+p.name]=p.read_bytes()
if kind=='cpu':
    target=json.loads((r/'targeted-receipt.json').read_text());assert target['returncode']==0 and target['counts']==dict(tests=30,failures=0,errors=0,skipped=0) and target['source_unchanged'];status=subprocess.run(['qstat','-f','442.manager'],capture_output=True,text=True);items['qstat-442.txt']=(status.stdout+status.stderr).encode();live=None
else:
    launch=json.loads((r/'launch.json').read_text());pid=launch['pid'];proc=Path('/proc')/str(pid);assert proc.exists() and b'control_water_stress_gpu_fl.py' in (proc/'cmdline').read_bytes();items['controller-process-status.txt']=(proc/'status').read_bytes();live=dict(pid=pid,cmdline_sha256=sha(proc/'cmdline'),exists=True);status=subprocess.run(['nvidia-smi','--id=1','--query-gpu=index,uuid,memory.used,memory.free','--format=csv,noheader'],capture_output=True,text=True);items['physical-gpu1.txt']=(status.stdout+status.stderr).encode()
items['snapshot.json']=(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind=kind,source_manifest_sha256=meta['manifest_sha256'],free_home_inodes=os.statvfs(b).f_favail,live_controller=live,scope='Point-in-time currentFL579 source/control/target30 proof and liveCPU442 or dependentGPU12 controller. No full1148/404/1552 or64reference/GPUyear/sciencepass from thisstart snapshot. ExistingEC annual workers continue ownfrozen source, no failedresume.'),indent=2)+'\n').encode();items['control/'+Path(__file__).name]=Path(__file__).read_bytes();a=b/('soil-stress-coupled-fl-'+kind+'-start-evidence.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as tf:
    for name,raw in items.items():q=tarfile.TarInfo(name);q.size=len(raw);tf.addfile(q,io.BytesIO(raw))
print(json.dumps(dict(group=a.name.removesuffix('-evidence.tar.gz'),sha256=sha(a),bytes=a.stat().st_size,artifacts=len(items))),flush=True)

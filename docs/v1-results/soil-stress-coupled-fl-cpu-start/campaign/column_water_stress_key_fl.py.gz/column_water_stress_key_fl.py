"""Exact array signatures for two unchanged original whole-column test families."""
import hashlib,json
import numpy as np

def key(family,row,forcing,deposition):
    h=hashlib.sha256();h.update(family.encode())
    for value in [*row,forcing,deposition]:
        a=np.asarray(value);h.update(a.dtype.str.encode());h.update(json.dumps(a.shape).encode());h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()

from pathlib import Path
import hashlib,json,os,pickle,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
import numpy as np

assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'soil-stress-coupled-fl-cpu';s=Path(os.environ['TMPDIR'])/'source';s.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((r/'package.json').read_text());a=b/'clm-soil-stress-coupled-fl-source.tar.gz';assert sha(a)==meta['archive_sha256']
with tarfile.open(a) as tf:tf.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());manifest=sha(s/'SOURCE_SHA256.json');assert len(m)==579 and manifest==meta['manifest_sha256'] and all(sha(s/n)==v for n,v in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None);files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
for label,selected,expected in [('targeted',['tests/test_clm_water_stress.py','tests/test_stress.py'],30),('full',files,1148)]:
    start=time.monotonic();collect=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q',*selected],cwd=s,env=env,capture_output=True,text=True);(r/(label+'-collection.txt')).write_text(collect.stdout+collect.stderr);assert collect.returncode==0;nodes=[v for v in collect.stdout.splitlines() if v.startswith('tests/') and '::' in v];assert len(nodes)==len(set(nodes))==expected;xml=r/(label+'.xml')
    with (r/(label+'.log')).open('x') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*selected,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    counts={k:sum(int(q.attrib[k]) for q in ET.parse(xml).getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']};record=dict(returncode=code,counts=counts,pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=all(sha(s/n)==v for n,v in m.items()),source_manifest_sha256=manifest,xml_sha256=sha(xml),seconds=time.monotonic()-start,scope=meta['scope']);(r/(label+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert code==0 and record['source_unchanged'] and counts==dict(tests=expected,failures=0,errors=0,skipped=0)
sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(r)]
from column_water_stress_key_fl import key
import test_gpu_clm_enthalpy_column as enthalpy
import test_gpu_clm_layered_column as layered
references={};inputs={};start=time.monotonic()
for family,module in [('enthalpy',enthalpy),('layered',layered)]:
    for dtype in [np.float32,np.float64]:
        arrays,forcing,dep=module.cases(dtype)
        inputs[family+'-'+np.dtype(dtype).name]=dict(arrays=arrays,forcing=forcing,deposition=dep)
        for k,row in enumerate(zip(*arrays)):
            signature=key(family,row,forcing[k],dep[k]);assert signature not in references;references[signature]=module.reference(row,forcing[k],dep[k])
assert len(references)==64
target=r/'references.pkl';target.write_bytes(pickle.dumps(references,protocol=5));(r/'reference-inputs.pkl').write_bytes(pickle.dumps(inputs,protocol=5))
d=dict(pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_manifest_sha256=manifest,source_unchanged=all(sha(s/n)==v for n,v in m.items()),keys=len(references),reference_pickle_sha256=sha(target),input_pickle_sha256=sha(r/'reference-inputs.pkl'),key_helper_sha256=sha(r/'column_water_stress_key_fl.py'),seconds=time.monotonic()-start,scope='Ownintegratedsource579 fullCPU1148 actual0 then everyoriginal16case/2dtype/2family NumPyreference at exactinputbytes, no physicsreference onGPUhost. Cachedreference delivery is not GPUyear or scientificacceptance.');(r/'reference-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);assert d['source_unchanged']

"""True-F flattened PB-l candidate test evidence; actual failures retained."""
from pathlib import Path
import hashlib
import io
import json
import re
import socket
import subprocess
import tarfile

assert socket.gethostname()=='manager'
ROOT=Path('/tmp/noahmp-clm-drainage-column-pb-l')
JOB='1654.manager';LABEL='clm-drainage-column-pb-l'
sha=lambda b:hashlib.sha256(b).hexdigest()
qstat=subprocess.check_output(['qstat','-xf',JOB]);status=qstat.decode()
assert re.search(r'^\s*job_state = F\s*$',status,re.M) and re.search(r'^\s*Stageout_status = 0\s*$',status,re.M)
code=int(re.search(r'^\s*Exit_status = (-?\d+)\s*$',status,re.M).group(1))
for name in ('result.tar.gz','pbs-exit.txt'):
    digest=subprocess.check_output(['ssh','compute002','sha256sum',str(ROOT/name)]).decode().split()[0]
    if not (ROOT/name).exists():subprocess.run(['scp','compute002:'+str(ROOT/name),str(ROOT/name)],check=True)
    assert sha((ROOT/name).read_bytes())==digest
assert int((ROOT/'pbs-exit.txt').read_text())==code
with tarfile.open(ROOT/'result.tar.gz') as t:
    items=[m for m in t if m.isfile()];assert len({m.name.removeprefix('./') for m in items})==len(items)
    raw={m.name.removeprefix('./'):t.extractfile(m).read() for m in items}
receipt=json.loads(raw['receipt.json']);binding=json.loads(raw['preparation/BINDINGS.json'])
assert receipt['pbs_job']==JOB and receipt['node']=='compute002' and int(raw['worker-exit.txt'])==code
assert receipt['pytest_parent_returncode']==code
index=json.loads(raw['source/SOURCE_SHA256.json']);assert len(index)==586
assert sha(raw['source/SOURCE_SHA256.json'])==binding['source_manifest_sha256']
assert all(sha(raw['source/'+n])==h for n,h in index.items())
old=json.loads(raw['preparation/ORIGINAL_NM_SOURCE_SHA256.json']);assert len(old)==584
assert sum(index[n]==h for n,h in old.items())==583
assert set(index)-set(old)==set(binding['added'])
for folder in ('preparation','execution'):
    manifest=json.loads(raw[folder+'/CONTROLS_SHA256.json'])
    assert all(sha(raw[folder+'/'+n])==h for n,h in manifest.items())
diag=[json.loads(line.split('PB_L_DIAGNOSTIC ',1)[1]) for line in raw['pytest.stdout.txt'].decode().splitlines() if 'PB_L_DIAGNOSTIC ' in line]
assert diag==json.loads(raw['diagnostics.json'])
calls=json.loads(raw['component-call-counts.json']);assert calls==receipt['actual_call_counts']
if code==0:
    assert receipt['passed'] and receipt['tests']==12 and receipt['failures']==receipt['errors']==0
    assert len(diag)==13 and b'12 passed' in raw['pytest.stdout.txt']
    assert calls==dict(completed_coupled_column_steps=15,candidate_column_steps=13,original_NM_column_steps=2,
        BGC_coupled_steps=2,new_CLM_physical_steps=10,independent_transport_replays=10,
        independent_drainage_replays=10,independent_tile_replays=1,expected_invalid_calls=7)
    assert receipt['source_and_controls_unchanged'] and receipt['official_calls_executed']==receipt['GPU_tasks']==0
else:assert not receipt['passed']
data={n:b for n,b in raw.items() if not n.startswith('source/')}
data['candidate-source-manifest.json']=raw['source/SOURCE_SHA256.json']
for name in ('dispatch.json','stage-inventory.json','qsub.stdout.txt','qsub.stderr.txt','compute-extract.stdout.txt',
    'compute-extract.stderr.txt','compute-file-hashes.txt','pbs-exit.txt'):
    data['scheduler/'+name]=(ROOT/name).read_bytes()
data['scheduler/actual-qstat.txt']=qstat
if (ROOT/'pbs-output.log').exists():data['scheduler/pbs-output.log']=(ROOT/'pbs-output.log').read_bytes()
data['original-result-members.json']=(json.dumps({n:dict(sha256=sha(b),bytes=len(b),included=not n.startswith('source/')) for n,b in raw.items()},indent=2)+'\n').encode()
data['closed-run.json']=(json.dumps(dict(job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,receipt=receipt,
    raw_result_archive=str(ROOT/'result.tar.gz'),raw_result_sha256=sha((ROOT/'result.tar.gz').read_bytes()),
    original_members=len(raw),omitted_source_members=587,candidate_source_archive_sha256=binding['source_archive_sha256'],
    original_NM_archive_sha256=binding['base_archive_sha256'],source_derivation=binding),indent=2)+'\n').encode()
readout=dict(actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,actual_tests=receipt['tests'],
    diagnostics=len(diag),pytest_seconds=receipt['pytest_seconds'],worker_seconds=receipt['seconds'],actual_call_counts=calls,
    candidate_source_archive_sha256=binding['source_archive_sha256'],candidate_source_files=586,unchanged_original_NM_files=583,
    original_Component64eps=True,original_Richards32eps=True,original_runner_MHCN_bounds=True,
    real_column_connected=True,production_integrated=False,official_coupled_validation=False,annual_validation=False,
    JAX_executed=False,CUDA_executed=False,cases=diag,
    limitations=['BGC cases exercised actual final-soil environment and original C/N audit, but both potential plant N demand and uptake were zero; nonzero N-demand/limitation response is not established.',
        'Frozen perched outlet in this connected-column fixture is near zero and is reported absolutely; nonzero mechanism reference remains the separately scoped PB-j/k component evidence.',
        'Bedrock must be the complete soil-column bottom in this initial connection; native/GPU new configuration is unsupported and explicitly rejected.'],
    scope='Actual isolated NumPy column coupling, arbitrary soil layers and disabled regression. No official coupled/annual/device acceptance.')
budgeted=[d for d in diag if 'water_bound' in d]
if budgeted:
    readout.update(maximum_water_residual_record=max(budgeted,key=lambda d:abs(d['water_residual'])),
        maximum_heat_residual_record=max(budgeted,key=lambda d:abs(d['heat_residual'])))
data['run-readout.json']=(json.dumps(readout,indent=2,allow_nan=False)+'\n').encode()
for name in ('prepare_drainage_column_pbl.py','freeze_drainage_column_pbl.py','stage_drainage_column_pbl.py',
    'clm-drainage-column-pb-l-static-preparation.json','clm-drainage-column-pb-l-stage-preparation.json',
    'clm-drainage-column-pb-l-root-preexecution-review.json'):
    data['preparation-provenance/'+name]=(ROOT/name).read_bytes()
data['archive_drainage_column_pbl.py']=Path(__file__).read_bytes()
data['artifact-inventory.json']=(json.dumps({n:dict(sha256=sha(b),bytes=len(b)) for n,b in data.items()},indent=2)+'\n').encode()
archive=ROOT/(LABEL+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for n,b in sorted(data.items()):ti=tarfile.TarInfo(n);ti.size=len(b);t.addfile(ti,io.BytesIO(b))
with tarfile.open(archive) as t:assert {m.name:t.extractfile(m).read() for m in t}==data
package=dict(archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,artifacts=len(data),
    actual_job=JOB,actual_job_state='F',actual_exit=code,Stageout_status=0,tests=receipt['tests'],diagnostics=len(diag),
    actual_call_counts=calls,candidate_source_archive_sha256=binding['source_archive_sha256'],production_integrated=False,
    scope='Actual12-case isolated new586-source NumPy column candidate: original zero-flux Richards then real perched/main liquid heat outlets, tile/final phase/BGC; old None/Richards exact replay. Original source/control/budget identities and actual failure status preserved. No official coupled, annual, production or device acceptance.')
(ROOT/(LABEL+'-package.json')).write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(package),flush=True)

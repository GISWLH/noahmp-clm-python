"""Stdlib-only candidate source and planned12-case inventory verification."""
from pathlib import Path
import ast
import hashlib
import json
import tarfile

ROOT=Path(__file__).resolve().parent
PREP=ROOT/'clm-drainage-column-pb-l-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    binding=json.loads((PREP/'BINDINGS.json').read_bytes())
    with tarfile.open(ROOT/binding['source_archive']) as t:
        raw={m.name:t.extractfile(m).read() for m in t}
    assert sha((ROOT/binding['source_archive']).read_bytes())==binding['source_archive_sha256']
    assert sha(raw['SOURCE_SHA256.json'])==binding['source_manifest_sha256']
    index=json.loads(raw['SOURCE_SHA256.json']);assert len(index)==586 and set(raw)==set(index)|{'SOURCE_SHA256.json'}
    assert all(sha(raw[n])==h for n,h in index.items())
    with tarfile.open(ROOT/binding['base_archive']) as t:
        original={m.name:t.extractfile(m).read() for m in t}
    old=json.loads(original['SOURCE_SHA256.json']);assert len(old)==584
    changed=[n for n in old if raw[n]!=original[n]];assert changed==list(binding['changed'])
    assert set(index)-set(old)==set(binding['added'])
    assert (PREP/'nm_original_clm_enthalpy_driver.py').read_bytes()==original['src/noahmp_clm/clm_enthalpy_driver.py']
    for p in PREP.glob('*.py'):ast.parse(p.read_bytes())
    tree=ast.parse((PREP/'test_column_pbl.py').read_bytes());count=0;cases=[]
    for f in tree.body:
        if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
            n=1
            for d in f.decorator_list:n*=len(ast.literal_eval(d.args[1]))
            count+=n;cases.append(dict(function=f.name,cases=n))
    assert count==12
    controls={p.name:sha(p.read_bytes()) for p in sorted(PREP.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'}
    (PREP/'CONTROLS_SHA256.json').write_text(json.dumps(controls,indent=2)+'\n',encoding='utf8',newline='\n')
    report=dict(actual_static_exit=0,source_files=586,base_source_files=584,unchanged_original_files=583,
        changed=list(binding['changed']),added=list(binding['added']),original_driver_bytes_retained=True,
        candidate_archive_sha256=binding['source_archive_sha256'],candidate_manifest_sha256=binding['source_manifest_sha256'],
        controls=len(controls),control_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        planned_tests=count,test_functions=cases,numerical_execution=False,local_scientific_imports=False,
        PBS_submitted=False,GPU_executed=False,scope='Prepared isolated NumPy column candidate; root review pending.')
    (ROOT/'clm-drainage-column-pb-l-static-preparation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8',newline='\n')
    print(json.dumps(report))


if __name__=='__main__':main()

"""Minimal private EHPC12-case wrapper; no numerical imports or launch."""
from pathlib import Path
import ast
import hashlib
import io
import json
import tarfile

ROOT=Path(__file__).resolve().parent
PREP=ROOT/'clm-drainage-column-pb-l-preparation'
EXEC=ROOT/'clm-drainage-column-pb-l-execution'
OLD=ROOT/'clm-drainage-perched-pb-k-execution'
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf8',newline='\n')


def main():
    EXEC.mkdir(exist_ok=True)
    for name in ('run_component_pb.py','component_pb.pbs','dispatch_component_pb.py'):
        code=(OLD/name).read_text(encoding='utf8').replace('clm-drainage-perched-pb-k','clm-drainage-column-pb-l')
        code=code.replace('drainage-perched-pbk','drainage-column-pbl').replace('dispatch_drainage_perched_pbk.py','dispatch_drainage_column_pbl.py')
        code=code.replace('test_perched_pbk.py','test_column_pbl.py').replace('PB_K_DIAGNOSTIC','PB_L_DIAGNOSTIC')
        code=code.replace("len(index) == 584","len(index) == 586").replace('len(cases) == 18','len(cases) == 12')
        code=code.replace('official_fixture_regression_passed','candidate_column_regression_passed')
        if name=='run_component_pb.py':
            code=code.replace("str(source / 'src') + ':' + str(root / 'preparation')","str(source / 'src') + ':' + str(source / 'tests') + ':' + str(source / 'benchmarks') + ':' + str(root / 'preparation')")
            place="        receipt['source_and_controls_unchanged'] = True"
            extra="""        original=json.loads((root/'preparation/ORIGINAL_NM_SOURCE_SHA256.json').read_bytes())
        assert len(original)==584
        changed=binding['changed'];added=binding['added']
        assert set(index)==set(original)|set(added)
        assert all(index[n]==h for n,h in original.items() if n not in changed)
        assert all(index[n]==v['new_sha256'] and original[n]==v['old_sha256'] for n,v in changed.items())
        calls=json.loads((root/'component-call-counts.json').read_bytes())
        receipt.update(actual_call_counts=calls,coupled_column_runs=calls['completed_coupled_column_steps'],
            original_NM_source_files=584,unchanged_original_source_files=583,candidate_source_files=586)
"""
            assert code.count(place)==1;code=code.replace(place,extra+place)
            start=code.index("    receipt['scope'] = ")
            end=code.index('\n',start)
            code=code[:start]+"    receipt['scope'] = 'New isolated586-source NumPy column candidate derived from NM584;12 actual coupling/disabled cases and13 intended diagnostics, original M/H/C/N and tracer bounds. Actual coupled-step and independent-operator replay counts are separate. No station, annual, official coupled or device acceptance; GPU unexecuted.'"+code[end:]
        if name=='dispatch_component_pb.py':
            code=code.replace('PB-k nine NumPy64 and nine explicit NumPy32 isolated perched cases; no coupled column, annual, new official call or GPU execution.',
                'PB-l12 isolated NumPy actual column/disabled cases, new586-source candidate; no site, annual, official call or GPU execution.')
        (EXEC/name).write_text(code,encoding='utf8',newline='\n')
    with tarfile.open(ROOT/'climatology-final-candidate-nm-source.tar.gz') as t:
        old=t.extractfile('SOURCE_SHA256.json').read()
    assert sha(old)=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
    (PREP/'ORIGINAL_NM_SOURCE_SHA256.json').write_bytes(old)
    for folder in (PREP,EXEC):
        for p in folder.glob('*.py'):ast.parse(p.read_bytes())
        save(folder/'CONTROLS_SHA256.json',{p.name:sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='CONTROLS_SHA256.json'})
    binding=json.loads((PREP/'BINDINGS.json').read_bytes());source=ROOT/binding['source_archive']
    assert sha(source.read_bytes())==binding['source_archive_sha256']
    raw={'source.tar.gz':source.read_bytes()}
    for folder,name in [(PREP,'preparation'),(EXEC,'execution')]:
        raw.update({name+'/'+p.name:p.read_bytes() for p in sorted(folder.iterdir()) if p.is_file()})
    raw['stage-inventory.json']=(json.dumps({n:sha(b) for n,b in sorted(raw.items())},indent=2)+'\n').encode()
    archive=ROOT/'clm-drainage-column-pb-l-stage.tar.gz'
    with tarfile.open(archive,'w:gz') as t:
        for n,b in sorted(raw.items()):ti=tarfile.TarInfo(n);ti.size=len(b);t.addfile(ti,io.BytesIO(b))
    report=dict(actual_static_exit=0,stage_sha256=sha(archive.read_bytes()),members=len(raw),
        preparation_manifest_sha256=sha((PREP/'CONTROLS_SHA256.json').read_bytes()),
        execution_manifest_sha256=sha((EXEC/'CONTROLS_SHA256.json').read_bytes()),
        source_archive_sha256=binding['source_archive_sha256'],numerical_execution=False,PBS_submitted=False)
    save(ROOT/'clm-drainage-column-pb-l-stage-preparation.json',report)
    print(json.dumps(report))


if __name__=='__main__':main()

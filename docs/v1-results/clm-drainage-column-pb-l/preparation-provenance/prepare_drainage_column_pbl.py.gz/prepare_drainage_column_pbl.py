"""Build an isolated exact-NM-derived candidate, without importing physics."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import tarfile

ROOT=Path(__file__).resolve().parent
PREP=ROOT/'clm-drainage-column-pb-l-preparation'
BASE=ROOT/'climatology-final-candidate-nm-source.tar.gz'
BASE_SHA='39fd30dd20d7715d35c171788680b2f76897e6f21672dfa543ef2dc634d33a7d'
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf8',newline='\n')


def main():
    assert sha(BASE.read_bytes())==BASE_SHA
    with tarfile.open(BASE) as t:
        items=t.getmembers();assert len({v.name for v in items})==len(items) and all(v.isfile() for v in items)
        raw={m.name:t.extractfile(m).read() for m in items}
    old_index=json.loads(raw.pop('SOURCE_SHA256.json'))
    assert len(old_index)==584 and set(old_index)==set(raw) and all(sha(raw[n])==h for n,h in old_index.items())
    path='src/noahmp_clm/clm_enthalpy_driver.py';original_driver=raw[path]
    old=original_driver.decode().replace('\r\n','\n');text=old
    old_type="        if not isinstance(soil_hydrology,RichardsHydrology):raise TypeError('Expected RichardsHydrology')"
    new_type="""        from .physics.clm_hydrology import CLMVerticalHydrology
        if not isinstance(soil_hydrology,(RichardsHydrology,CLMVerticalHydrology)):
            raise TypeError('Expected RichardsHydrology or CLMVerticalHydrology')
        if isinstance(soil_hydrology,CLMVerticalHydrology):soil_hydrology.validate_ground(state.ground)"""
    assert text.count(old_type)==1;text=text.replace(old_type,new_type)
    text=text.replace('    redistribution=None\n','    redistribution=None;clm_drainage=None\n',1)
    old_block="""    else:
        from .physics.richards import redistribute_soil_enthalpy
        before_water=ground.water.copy();before_heat=ground.enthalpy.copy()"""
    new_block="""    elif isinstance(soil_hydrology,CLMVerticalHydrology):
        from .physics.clm_hydrology import advance_clm_hydrology
        ground,redistribution,clm_drainage=advance_clm_hydrology(ground,f.dt,soil_hydrology)
        # These are real distributed soil outlets, not bottom-boundary flux.
        runoff+=clm_drainage['drained_kg_m2'];runoff_heat+=clm_drainage['drained_enthalpy_j_m2']
        drain=dict(bottom_mass_kgm2=0.,bottom_enthalpy_jm2=0.)
    else:
        from .physics.richards import redistribute_soil_enthalpy
        before_water=ground.water.copy();before_heat=ground.enthalpy.copy()"""
    assert text.count(old_block)==1;text=text.replace(old_block,new_block)
    old_route="""    if soil_hydrology is not None:
        # All pre-tile outlets in this mode are surface admission overflow"""
    new_route="""    if clm_drainage is not None:
        # No legacy diagnostic repartition: both outlets were really removed.
        deep=clm_drainage['drained_kg_m2']/1000.
        surface=(runoff-clm_drainage['drained_kg_m2'])/1000.
    elif soil_hydrology is not None:
        # All pre-tile outlets in this mode are surface admission overflow"""
    assert text.count(old_route)==1;text=text.replace(old_route,new_route)
    end="    if redistribution is not None:d['soil_hydrology']=redistribution\n"
    addition="""    if clm_drainage is not None:
        from .physics.clm_saturated_drainage import diagnose_water_tables
        clm_drainage['diagnosis_final_after_tile']=diagnose_water_tables(final.ground,soil_hydrology.drainage)
        d.update(clm_drainage=clm_drainage,
            saturated_outflow_kgm2=clm_drainage['saturated_mass_kg_m2'],
            saturated_outflow_enthalpy_jm2=clm_drainage['saturated_enthalpy_j_m2'],
            perched_outflow_kgm2=clm_drainage['perched_mass_kg_m2'],
            perched_outflow_enthalpy_jm2=clm_drainage['perched_enthalpy_j_m2'])
"""
    assert text.count(end)==1;text=text.replace(end,end+addition)
    ast.parse(text)
    raw[path]=text.encode()
    (PREP/'clm_enthalpy_driver.py').write_bytes(raw[path])
    (PREP/'nm_original_clm_enthalpy_driver.py').write_bytes(original_driver)
    pb=ROOT/'clm-drainage-perched-pb-k-preparation/saturated_drainage_pb.py'
    assert sha(pb.read_bytes())=='d2742cfc98aa65b31fe4fa918cbf6f514b4583f47e8fe60a64b7f316339808b8'
    new_files={'src/noahmp_clm/physics/clm_saturated_drainage.py':pb.read_bytes(),
        'src/noahmp_clm/physics/clm_hydrology.py':(PREP/'clm_hydrology.py').read_bytes()}
    for name,b in new_files.items():assert name not in raw;ast.parse(b.decode());raw[name]=b
    (PREP/'clm_saturated_drainage.py').write_bytes(pb.read_bytes())
    index={n:sha(b) for n,b in sorted(raw.items())};assert len(index)==586
    raw['SOURCE_SHA256.json']=(json.dumps(index,indent=2)+'\n').encode()
    archive=ROOT/'clm-drainage-column-pb-l-source.tar.gz'
    with tarfile.open(archive,'w:gz') as t:
        for name,b in sorted(raw.items()):
            info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b))
    patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
    for name,b in new_files.items():
        patch+=''.join(difflib.unified_diff([],b.decode().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))
    (PREP/'candidate.patch').write_text(patch,encoding='utf8',newline='\n')
    changed={path:dict(old_sha256=old_index[path],new_sha256=index[path])}
    additions={n:index[n] for n in new_files}
    assert sum(index[n]==h for n,h in old_index.items())==583
    binding=dict(base_archive=BASE.name,base_archive_sha256=BASE_SHA,base_source_files=584,
        source_archive=archive.name,source_archive_sha256=sha(archive.read_bytes()),source_files=586,
        source_manifest_sha256=sha(raw['SOURCE_SHA256.json']),changed=changed,added=additions,unchanged_base_files=583,
        patch_sha256=sha((PREP/'candidate.patch').read_bytes()),patch_line_endings='Driver diff normalized CRLF to LF; original driver bytes retained separately',prepared_only=True,physical_execution=False,
        production_files_changed=0,active_model_source_changed=False,scope='New NumPy column candidate derived from exact NM; not NM584 identity. Old None/Richards and all GPU source files unchanged except the stated NumPy driver.')
    save(PREP/'BINDINGS.json',binding)
    print(json.dumps(binding))


if __name__=='__main__':main()

"""Twelve true NumPy column/disabled cases; execute only on EHPC PBS."""
import os
import socket
if os.name=='nt' or socket.gethostname()!='compute002' or not os.environ.get('PBS_JOBID'):
    raise RuntimeError('PB-l numerical cases require EHPC compute002 PBS')

from dataclasses import fields,is_dataclass,replace
from pathlib import Path
import importlib.util
import json
import numpy as np
import pytest
from noahmp_clm.column import ColumnState,Forcing
from noahmp_clm.clm_state import CLMColumnState
from noahmp_clm.clm_driver import step_clm_column
from noahmp_clm import clm_enthalpy_driver as driver
from noahmp_clm.physics import clm_hydrology as hydrology
from noahmp_clm.physics.richards import RichardsHydrology,redistribute_soil_enthalpy
from noahmp_clm.physics.clm_hydrology import CLMVerticalHydrology
from noahmp_clm.physics.clm_saturated_drainage import DrainageParameters,IntegrationControls,drain_saturated_soil
from noahmp_clm.physics.snowpack import Snowpack,TF
from noahmp_clm.physics.soil_enthalpy import SoilEnthalpyState
from noahmp_clm.physics.tile_drainage import TileDrainageParameters,step_tile_drainage

HERE=Path(__file__).resolve().parent
CALLS=dict(completed_coupled_column_steps=0,candidate_column_steps=0,original_NM_column_steps=0,
    BGC_coupled_steps=0,new_CLM_physical_steps=0,independent_transport_replays=0,
    independent_drainage_replays=0,independent_tile_replays=0,expected_invalid_calls=0)


@pytest.fixture(scope='session',autouse=True)
def preserve_actual_call_counts():
    yield
    (Path.cwd()/'component-call-counts.json').write_text(json.dumps(CALLS,indent=2)+'\n')
    print('PB_L_CALL_COUNTS '+json.dumps(CALLS),flush=True)


def column_step(function,state,f,*,original_nm=False,**kwargs):
    result=function(state,f,**kwargs)
    CALLS['completed_coupled_column_steps']+=1
    CALLS['original_NM_column_steps' if original_nm else 'candidate_column_steps']+=1
    if state.bgc_state is not None:CALLS['BGC_coupled_steps']+=1
    return result


def same(a,b):
    if isinstance(a,np.ndarray):assert isinstance(b,np.ndarray) and a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()
    elif is_dataclass(a):
        assert type(a)==type(b)
        for f in fields(a):same(getattr(a,f.name),getattr(b,f.name))
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:same(a[k],b[k])
    elif isinstance(a,(tuple,list)):
        assert type(a)==type(b) and len(a)==len(b)
        for x,y in zip(a,b):same(x,y)
    else:assert a==b


def state_case(kind='warm',layers=4):
    dz=np.full(layers,2./layers);temperature=np.full(layers,290.);theta=np.full(layers,.43)
    forcing=Forcing(1800.,295.,.008,3.,101325.,500.,350.,0.)
    snow=Snowpack.empty()
    if kind=='frost':
        assert layers==4;temperature=np.array([280.,280.,270.,280.]);theta=np.array([.2,.43,.4,.2])
        forcing=Forcing(1800.,280.,.004,3.,101325.,50.,300.,0.)
    elif kind=='storm':forcing=replace(forcing,prcp=1e-4)
    elif kind=='melt':
        snow=Snowpack.from_ice([.1],TF)
        snow=Snowpack(snow.mass,snow.enthalpy,snow.thickness,snow.radius_um,np.array([[1.,2.,3.,4.,5.]])*1e-9)
    old=ColumnState(dz=dz,tsoil=temperature,smc=theta,ts=float(temperature[0]),fveg=0.,lai=0.,canw=0.)
    return CLMColumnState.from_column(old,snow=snow),forcing


def config(state,slope=.2):
    return CLMVerticalHydrology(DrainageParameters(float(state.ground.dz.sum()),slope))


def budgets(old,new,f,d,deposition=None):
    eps=np.finfo(float).eps
    rm=new.water_kgm2-old.water_kgm2-f.prcp*f.dt*1000.+d['et_mm']+d['runoff_mm']
    rh=new.enthalpy_jm2-old.enthalpy_jm2-d['precipitation_enthalpy_jm2']
    rh-=(f.swdown+f.lwdown-d['outgoing_shortwave']-d['outgoing_longwave']-d['h']-d['le'])*f.dt
    rh+=d['advected_enthalpy_jm2']+d['runoff_enthalpy_jm2']
    mb=32*eps*max(old.water_kgm2+new.water_kgm2+f.prcp*f.dt*1000.+abs(d['et_mm'])+d['runoff_mm'],1.)
    storage=sum(float(abs(a).sum()) for s in (old,new) for a in (s.ground.enthalpy,s.snow.enthalpy))
    storage+=sum(float(abs(s.canopy_condensate.enthalpy).sum()) if s.canopy_condensate is not None else abs(s.canopy_enthalpy_jm2) for s in (old,new))
    hb=float(np.sum(d['thermal']['convergence_tolerance_jm2']))+f.dt*float(np.sum(abs(d['layer_residual'])))
    hb+=32*eps*max(storage+abs(d['precipitation_enthalpy_jm2'])+abs(d['atmospheric_energy_jm2'])+abs(d['advected_enthalpy_jm2'])+abs(d['runoff_enthalpy_jm2']),1.)+1e-5
    assert abs(rm)<=mb and abs(rh)<=hb
    assert abs(d['water_residual_kgm2'])<3e-10 and abs(d['energy_residual_jm2'])<.02
    rates=np.zeros(5) if deposition is None else deposition
    impurity=new.snow.impurities.sum(axis=0)-old.snow.impurities.sum(axis=0)+d['impurity_output_kgm2']-rates*f.dt
    ib=64*eps*np.maximum(new.snow.impurities.sum(axis=0)+old.snow.impurities.sum(axis=0)+d['impurity_output_kgm2']+rates*f.dt,1.)
    assert np.all(abs(impurity)<=ib)
    return dict(water_residual=rm,water_bound=mb,heat_residual=rh,heat_bound=hb,impurity_residual=impurity.tolist(),impurity_bound=ib.tolist())


def run_connected(monkeypatch,state,f,parameters=None,**kwargs):
    configuration=config(state) if parameters is None else parameters
    captured=[];original=hydrology.advance_clm_hydrology
    def observe(ground,dt,options):
        result=original(ground,dt,options);captured.append((ground,dt,options,result))
        CALLS['new_CLM_physical_steps']+=1
        return result
    def forbidden(*args,**kwargs):raise AssertionError('Legacy drainage/ARNO/routing must not run in explicit CLM mode')
    with monkeypatch.context() as m:
        m.setattr(hydrology,'advance_clm_hydrology',observe)
        m.setattr(driver,'drain_soil',forbidden);m.setattr(driver,'route_runoff',forbidden)
        before=(state.ground.water.tobytes(),state.ground.enthalpy.tobytes(),state.snow.mass.tobytes())
        after,d=column_step(driver.step_clm_enthalpy_column,state,f,soil_hydrology=configuration,**kwargs)
    assert before==(state.ground.water.tobytes(),state.ground.enthalpy.tobytes(),state.snow.mass.tobytes())
    assert len(captured)==1
    ground,dt,options,_=captured[0]
    transported,tr=redistribute_soil_enthalpy(ground,dt,**options.transport.controls())
    CALLS['independent_transport_replays']+=1
    expected,dr=drain_saturated_soil(transported,dt,options.drainage,options.integration)
    CALLS['independent_drainage_replays']+=1
    if state.tile_drainage_parameters is not None:
        expected,_=step_tile_drainage(expected,dt,state.tile_drainage_parameters)
        CALLS['independent_tile_replays']+=1
    same(after.ground.water,expected.water);same(after.ground.enthalpy,expected.enthalpy)
    cd=d['clm_drainage'];same(cd['layer_mass_kg_m2'],dr['layer_mass_kg_m2']);same(cd['layer_enthalpy_j_m2'],dr['layer_enthalpy_j_m2'])
    same(d['soil_hydrology']['interface_transfer_kg_m2'],tr['interface_transfer_kg_m2'])
    assert np.all(abs(tr['residual_mass_heat'])<=tr['bound_mass_heat'])
    for prefix in ('','combined_'):
        assert abs(cd[prefix+'water_residual_kg_m2'])<=cd[prefix+'water_bound_kg_m2']
        assert abs(cd[prefix+'energy_residual_j_m2'])<=cd[prefix+'energy_bound_j_m2']
    assert d['bottom_outflow_kgm2']==d['bottom_outflow_enthalpy_jm2']==0.
    tile=d.get('tile_drainage_mm',0.)
    assert d['runoff_deep_mm']==pytest.approx(cd['drained_kg_m2']+tile,abs=1e-12,rel=0.)
    assert d['runoff_mm']==pytest.approx(d['runoff_surface_mm']+d['runoff_deep_mm'],abs=1e-12,rel=0.)
    assert after.surface_temperature==float(after.snow.temperature[0] if len(after.snow.mass) else after.ground.temperature[0])
    b=budgets(state,after,f,d,kwargs.get('deposition_rates'))
    return after,d,b,captured[0]


def emit(name,after,d,b,**more):
    cd=d.get('clm_drainage',{})
    print('PB_L_DIAGNOSTIC '+json.dumps(dict(test=name,soil_layers=len(after.ground.water),
        water=after.ground.water.tolist(),temperature=after.ground.temperature.tolist(),ice=after.ground.ice.tolist(),
        surface_temperature=after.surface_temperature,surface_runoff=d['runoff_surface_mm'],deep_runoff=d['runoff_deep_mm'],
        total_runoff=d['runoff_mm'],runoff_enthalpy=d['runoff_enthalpy_jm2'],
        saturated_mass=d.get('saturated_outflow_kgm2'),perched_mass=d.get('perched_outflow_kgm2'),
        saturated_layer_mass=cd.get('saturated_layer_mass_kg_m2',np.zeros(0)).tolist(),
        perched_layer_mass=cd.get('perched_layer_mass_kg_m2',np.zeros(0)).tolist(),
        saturated_layer_heat=cd.get('saturated_layer_enthalpy_j_m2',np.zeros(0)).tolist(),
        perched_layer_heat=cd.get('perched_layer_enthalpy_j_m2',np.zeros(0)).tolist(),
        combined_water_residual=cd.get('combined_water_residual_kg_m2'),combined_water_bound=cd.get('combined_water_bound_kg_m2'),
        combined_heat_residual=cd.get('combined_energy_residual_j_m2'),combined_heat_bound=cd.get('combined_energy_bound_j_m2'),
        **b,**more),allow_nan=False),flush=True)


@pytest.mark.parametrize('mode',['none','richards'])
def test_disabled_modes_are_byte_exact_original_nm(mode):
    spec=importlib.util.spec_from_file_location('noahmp_clm._nm_original_enthalpy_driver',HERE/'nm_original_clm_enthalpy_driver.py')
    reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
    state,f=state_case();args={} if mode=='none' else dict(soil_hydrology=RichardsHydrology())
    actual,d=column_step(driver.step_clm_enthalpy_column,state,f,**args)
    expected,rd=column_step(reference.step_clm_enthalpy_column,state,f,original_nm=True,**args)
    same(actual,expected);same(d,rd)
    emit('disabled_'+mode,actual,d,budgets(state,actual,f,d),all_state_and_diagnostics_exact_original_NM=True)


def test_zero_slope_exact_closed_transport_and_no_outlet(monkeypatch):
    state,f=state_case();expected,rd=column_step(driver.step_clm_enthalpy_column,state,f,soil_hydrology=RichardsHydrology())
    after,d,b,_=run_connected(monkeypatch,state,f,config(state,slope=0.))
    same(after,expected)
    for key in ('h','le','et_mm','runoff_mm','runoff_enthalpy_jm2'):assert d[key]==rd[key]
    assert d['saturated_outflow_kgm2']==d['perched_outflow_kgm2']==d['runoff_deep_mm']==0.
    emit('zero_slope',after,d,b)


@pytest.mark.parametrize('kind',['warm','frost','storm','melt'])
def test_real_column_outlets_surface_snow_and_no_double_withdrawal(monkeypatch,kind):
    state,f=state_case(kind);kwargs={}
    if kind=='storm':
        state=replace(state,options=replace(state.options,OptRunoffSurface=6))
        from noahmp_clm.physics.vic import VICParameters
        kwargs['vic_parameters']=VICParameters()
    if kind=='melt':kwargs['deposition_rates']=np.array([1.,2.,3.,4.,5.])*1e-13
    after,d,b,_=run_connected(monkeypatch,state,f,**kwargs)
    if kind=='frost':assert d['perched_outflow_kgm2']>0 and np.any(after.ground.ice>0)
    else:assert d['saturated_outflow_kgm2']>0
    if kind=='storm':assert d['runoff_surface_mm']>0 and d['runoff_deep_mm']>0
    if kind=='melt':assert after.swe==0 and np.any(d['impurity_output_kgm2']>0)
    emit(kind,after,d,b)


def test_tile_follows_actual_drainage_state_and_is_separate(monkeypatch):
    state,f=state_case();state=state.with_tile_drainage(TileDrainageParameters(tube_depth_m=1.,field_capacity=.28))
    after,d,b,_=run_connected(monkeypatch,state,f)
    assert d['tile_drainage_mm']>0 and d['saturated_outflow_kgm2']>0
    emit('tile',after,d,b,tile_mass=d['tile_drainage_mm'],tile_heat=d['tile_drainage_enthalpy_jm2'])


def test_bgc_two_steps_use_actual_root_phase_and_nitrogen_feedback(monkeypatch):
    from test_clm_bgc_column import case
    from noahmp_clm.physics.biogeochemistry import soil_environment
    from noahmp_clm.physics.plant_cn import leaf_nitrogen_factor,turnover_plant
    from run_fluxnet_column import audit_step
    state,f,_=case(None,285.,False)
    g=state.ground;state=replace(state,ground=SoilEnthalpyState.from_column(ColumnState(dz=g.dz,tsoil=g.temperature,smc=np.full(len(g.dz),.43),soil=g.params)))
    for step in range(2):
        after,d,b,_=run_connected(monkeypatch,state,f,nitrogen_deposition_gn_m2=1e-5)
        environment=soil_environment(after.ground,state.root_frac,state.bgc_parameters)
        same(d['biogeochemistry']['environment'],environment)
        turned,_=turnover_plant(state.bgc_state.plant,f.dt,parameters=state.bgc_parameters.plant)
        assert d['biogeochemistry']['nitrogen_factor_used']==leaf_nitrogen_factor(turned,state.bgc_parameters.plant)
        _,res,bound=audit_step(state,after,f,d,1e-5)
        assert np.all(abs(res)<=bound) and d['saturated_outflow_kgm2']>0
        emit('bgc_'+str(step),after,d,b,MHCN_residual=res.tolist(),MHCN_bound=bound.tolist(),
            environment=environment,plant_n_demand=d['biogeochemistry']['allocation']['soil_n_demand_gn_m2'],
            plant_n_uptake=d['biogeochemistry']['decomposition']['plant_uptake_gn_m2'])
        state=after


@pytest.mark.parametrize('layers',[3,6])
def test_numpy_column_retains_arbitrary_soil_layers(monkeypatch,layers):
    state,f=state_case(layers=layers);after,d,b,_=run_connected(monkeypatch,state,f)
    assert len(after.ground.water)==layers and len(d['clm_drainage']['layer_mass_kg_m2'])==layers
    assert d['saturated_outflow_kgm2']>0
    emit('layers_'+str(layers),after,d,b)


def test_explicit_config_conflicts_and_unimplemented_native_are_rejected():
    state,f=state_case();cfg=config(state)
    assert set(cfg.transport.controls())==set(RichardsHydrology.__dataclass_fields__) and not hasattr(cfg,'controls')
    with pytest.raises(TypeError):CLMVerticalHydrology({})
    with pytest.raises(TypeError):CLMVerticalHydrology(cfg.drainage,transport={})
    with pytest.raises(TypeError):CLMVerticalHydrology(cfg.drainage,integration={})
    with pytest.raises(ValueError,match='full soil-column depth'):
        driver.step_clm_enthalpy_column(state,f,soil_hydrology=replace(cfg,drainage=replace(cfg.drainage,bedrock_depth_m=1.)))
    with pytest.raises(ValueError,match='bottom outlets'):
        driver.step_clm_enthalpy_column(replace(state,options=replace(state.options,OptRunoffSubsurface=6)),f,soil_hydrology=cfg)
    with pytest.raises(NotImplementedError,match='CLMColumnState'):
        step_clm_column(ColumnState(),f,soil_hydrology=cfg)
    from noahmp_clm.gpu.clm_richards_column import resolve_column_richards
    with pytest.raises(TypeError,match='RichardsHydrology'):resolve_column_richards(cfg,np.zeros((1,8),np.int32),np)
    CALLS['expected_invalid_calls']+=7
    print('PB_L_DIAGNOSTIC '+json.dumps(dict(test='invalid_boundaries',actual_rejected=7,
        native_candidate_supported=False,numpy_layer_count_restricted_to_four=False)),flush=True)

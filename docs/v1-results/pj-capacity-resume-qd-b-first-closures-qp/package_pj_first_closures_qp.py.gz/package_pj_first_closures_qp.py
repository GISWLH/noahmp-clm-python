"""Seal read-only first8 closures and2 stopped failures; no large downloads."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path(__file__).resolve().parent
LABEL='pj-capacity-resume-qd-b-first-closures-qp'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()


def main():
    status=json.loads((BASE/'pj-capacity-resume-qd-b-status-qp.json').read_bytes())
    failures=json.loads((BASE/'pj-capacity-resume-qd-b-failures-1864-1865-qp.json').read_bytes())
    guards=json.loads((BASE/'pj-failed-source-guards-1864-1865-qp.json').read_bytes())
    assert failures['compute_ssh_exit']==0 and guards['stage36_exact'] and guards['source584_archive_members_exact']
    closed=[];references=[]
    for row in status['rows']:
        assert len(row['new_closed_windows'])==1
        item=row['new_closed_windows'][0];history=item['history'];receipt=item['receipt']
        assert receipt['passed'] and receipt['source_unchanged'] and receipt['original_steps_started']==receipt['original_steps_completed']==480
        assert item['worker_exit']=='0' and history['stop']==row['closed_steps']
        closed.append(dict(case=row['case_index'],job=history['job'],closed_steps=row['closed_steps'],
            original_window_started=480,original_window_completed=480,worker_exit=0,PBS_exit=0,Stageout_status=0,
            residual_m_h_c_n=history['residual_m_h_c_n'],bounds_m_h_c_n=history['bounds_m_h_c_n'],
            original_result_sha256=history['original_result_archive_sha256'],closed_archive_sha256=history['closed_archive_sha256'],
            spinup_accepted=False,score_eligible=False))
        references.append(dict(case=row['case_index'],job=history['job'],
            manager_original_result_path='/tmp/noahmp-numpy-baseline-resume-pj/actual/case-'+str(row['case_index'])+'/start-'+str(history['start']).zfill(7)+'/result.tar.gz',
            original_result_sha256=history['original_result_archive_sha256'],
            manager_closed_path='/tmp/noahmp-numpy-baseline-resume-pj/closed/case-'+str(row['case_index'])+'/stop-'+str(history['stop']).zfill(7)+'.tar.gz',
            closed_archive_sha256=history['closed_archive_sha256'],closed_archive_bytes=history['closed_archive_bytes'],included=False))
    stopped=[]
    for item,guard in zip(failures['compute'],guards['rows']):
        assert item['job']==guard['job'] and guard['outer_summary_source_unchanged'] is False and guard['original_inner_run_receipt_source_unchanged'] is True
        stopped.append(dict(case=item['case_index'],job=item['job'],closed_steps=7248,
            window_started=28,window_completed=27,failing_absolute_step=7275,PBS_exit=1,Stageout_status=0,worker_exit=1,
            original_error='Canopy phase Newton stalled at iteration 30: residual=13.757259 W/m2',
            original_error_unit_scope='Original bytes retained verbatim; scalar component/unit is not inferred without its original frame.',
            source_unchanged_outer_default=False,source_unchanged_inner_original_before_after_guard=True,
            source_directory_retained_after_PBS=False,score_eligible=False,spinup_accepted=False,retried=False))
        references.append(dict(case=item['case_index'],job=item['job'],compute_original_result_path=item['original_archive_path'],
            original_result_sha256=item['archive_sha256'],original_result_bytes=item['archive_bytes'],included=False,
            source='Raw original archive retained on compute002; only existing selected members and inventory were read, no282MB archive downloaded.'))
    readout=dict(observed_closure_snapshot_utc=status['observed_utc'],observed_failure_snapshot_utc=failures['observed_utc'],
        closed_windows=closed,stopped_physical_failures=stopped,
        running_job_handles_at_closure_snapshot=[r['current_job'] for r in status['rows'] if r['status']=='running'],
        other_partial_steps_not_credited=True,closed_years=0,accepted_spinups=0,scientific_scores=0,
        original_controller_unchanged=True,failed_years_not_restarted=True,large_failure_archives_downloaded=0,
        model_calls_by_this_collection=0,remote_mutations=0,
        source_guard_explanation='Original run_window verifies all584 bytes before model and again after caught model failure, recorded True in run/receipt. Outer worker initializes False and updates only after a successful full window; failure leaves default. Original job source dirs no longer exist, so no independent historical snapshot is invented.')
    readout_path=BASE/(LABEL+'-readout.json');assert not readout_path.exists();readout_path.write_bytes(encode(readout))
    names=['read_pj_closed_qp.py','read_capacity_resume_pj_qd_b.py','collect_pj_qd_b_failure_qp.py','read_pj_failed_source_guards_qp.py',
        'pj-capacity-resume-qd-b-status-qp.json','pj-capacity-resume-qd-b-status-qp.stderr','pj-capacity-resume-qd-b-status-qp-exit.json',
        'pj-capacity-resume-qd-b-status-qp-full.json','pj-capacity-resume-qd-b-status-qp-full.stderr','pj-capacity-resume-qd-b-status-qp-full-exit.json',
        'pj-capacity-resume-qd-b-failures-1864-1865-qp.json','pj-capacity-resume-qd-b-failures-1864-1865-qp.stderr','pj-capacity-resume-qd-b-failures-1864-1865-qp-exit.json',
        'pj-failed-source-guards-1864-1865-qp.json','pj-failed-source-guards-1864-1865-qp.stderr','pj-failed-source-guards-1864-1865-qp-exit.json',
        LABEL+'-readout.json','package_pj_first_closures_qp.py']
    items={name:(BASE/name).read_bytes() for name in names}
    items['HEAVY-ORIGINAL-REFERENCES.json']=encode(references)
    items['PRIOR-EVIDENCE-REFERENCES.json']=encode({
        'pj-capacity-resume-qd-b':dict(sha256='cd2821e16e6a510b4cda0d5aa3af3a46e47c6eb630a3497702746cbbaadcbfe7'),
        'pj-dependency-repair-qd-b':dict(sha256='a1e9241ed5a20ba9a55285432288b13323bf3585ca3115910d64374c6203733c'),
        'unchanged_wrapper':dict(sha256='62694b3eae242b33f1ac097b4e6705e57974579c8a2dcca749fd6f6b707e0d53'),
        'original_parent_PROGRESS':dict(sha256='159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6')})
    items['README.md']=b'Read-only closure snapshot. All8 original resumed windows1846-1853 achieved actualF0/Stageout0 and480/480; their manager raw and closed archive bytes were independently hashed. Closed steps13968,13968,13488,13488,7248,7248,7248,7248. Later1864/65 actualF1/Stageout0 stopped at7275 (27 completed/28 started after7248), never retried; no partial-window/year/spinup/score credit. Full282MB failure archives remain on compute002 and are hash-referenced, not downloaded. Selected original failure bytes/base64, full member inventories, raw query/command exits, original code guard bytes and current source584/stage36 checks included. Top outer source_unchanged=False is retained and explained by original inner successful source guard, not overwritten; temporary job source dirs have already been removed by PBS, so no independent historical external snapshot is claimed. No model/import/evaluate, numerical NPZ/pickle decode or remote changes by this collection.\n'
    items['artifact-inventory.json']=encode({name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(items.items())})
    target=BASE/(LABEL+'-evidence.tar.gz');assert not target.exists()
    with target.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            for name,raw in sorted(items.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;t.addfile(entry,io.BytesIO(raw))
    with tarfile.open(target) as t:assert {m.name:t.extractfile(m).read() for m in t}==items
    package=dict(label=LABEL,artifacts=len(items),bytes=target.stat().st_size,sha256=sha(target.read_bytes()),
        actual_closed_windows=8,stopped_physical_failures=2,new_model_calls=0,remote_mutations=0,large_archive_downloads=0)
    (BASE/(LABEL+'-package.json')).write_bytes(encode(package));print(json.dumps(package))


if __name__=='__main__':main()

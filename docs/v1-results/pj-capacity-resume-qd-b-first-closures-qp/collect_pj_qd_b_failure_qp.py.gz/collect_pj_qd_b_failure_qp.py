"""Collect two original terminal failures read-only; no retry or model imports."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
REMOTE=r'''
from pathlib import Path
import base64,hashlib,json,subprocess,time
root=Path('/tmp/noahmp-numpy-baseline-resume-pj')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def packed(raw):return dict(bytes=len(raw),sha256=sha(raw),base64=base64.b64encode(raw).decode())
rows=[]
for i,job in [(6,'1864.manager'),(7,'1865.manager')]:
    folder=root/'actual'/('case-'+str(i))/'start-0007248'
    q=subprocess.run(['qstat','-fx',job],capture_output=True,timeout=20)
    originals={str(p):packed(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='result.tar.gz'}
    rows.append(dict(case_index=i,job=job,qstat_exit=q.returncode,qstat_stdout=packed(q.stdout),qstat_stderr=packed(q.stderr),manager_originals=originals))
compute_script=r"""
from pathlib import Path
import base64,hashlib,json,tarfile
def packed(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode())
rows=[]
for i,job in [(6,'1864.manager'),(7,'1865.manager')]:
    root=Path('/tmp/noahmp-numpy-baseline-resume-pj/raw')/('case-'+str(i))/'start-7248'
    path=root/'result.tar.gz';digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):digest.update(chunk)
    selected={};inventory=[]
    with tarfile.open(path) as t:
        for m in t:
            if not m.isfile():continue
            n=m.name.removeprefix('./');inventory.append(dict(path=n,bytes=m.size))
            if n in ('receipt.json','worker-exit.txt','pbs-command-exit.txt','worker.stdout','worker.stderr','run/receipt.json','run/trajectory/report.json'):
                selected[n]=packed(t.extractfile(m).read())
    rows.append(dict(case_index=i,job=job,original_archive_path=str(path),archive_bytes=path.stat().st_size,
        archive_sha256=digest.hexdigest(),members=inventory,selected_original_members=selected,
        external_exit=packed((root/'pbs-exit.txt').read_bytes())))
print(json.dumps(rows))
"""
compute=subprocess.run(['ssh','compute002','/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'],input=compute_script.encode(),capture_output=True,timeout=120)
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),manager=rows,
    compute_ssh_exit=compute.returncode,compute_stdout=packed(compute.stdout),compute_stderr=packed(compute.stderr),
    compute=json.loads(compute.stdout) if compute.returncode==0 else None,model_calls=0,remote_mutations=0),indent=2))
'''


def main():
    output=BASE/'pj-capacity-resume-qd-b-failures-1864-1865-qp.json';assert not output.exists()
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','ehpc','/home/zhangyq/venvs/noahmp-closeout/bin/python -B -'],
        input=REMOTE.encode(),capture_output=True,timeout=150)
    output.write_bytes(result.stdout);output.with_suffix('.stderr').write_bytes(result.stderr)
    meta=dict(actual_exit=result.returncode,reader_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    output.with_name(output.stem+'-exit.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta))
    assert result.returncode==0


if __name__=='__main__':main()

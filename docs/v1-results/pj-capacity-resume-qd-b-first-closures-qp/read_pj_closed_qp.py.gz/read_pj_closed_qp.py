"""One manager metadata snapshot of existing resumed windows; no model import."""
from pathlib import Path
import hashlib
import json
import re
import socket
import subprocess
import tarfile
import time

assert socket.gethostname()=='manager'
root=Path('/tmp/noahmp-pj-capacity-resume-qd-b')
old=Path('/tmp/noahmp-numpy-baseline-resume-pj')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def file_sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()
assert sha((old/'PROGRESS.json').read_bytes())=='159ecced631b9dca30cf0e5539aa1eddcc4da0e7bd3a219eaa291666ccec53d6'
progress_raw=(root/'PROGRESS.json').read_bytes();progress=json.loads(progress_raw)
pid=99446;base=Path('/proc')/str(pid);process=dict(pid=pid,present=base.exists())
if base.exists():
    stat=(base/'stat').read_text().rsplit(')',1)[1].split()
    process.update(start_ticks=int(stat[19]),state=stat[0],cmdline=(base/'cmdline').read_bytes().replace(b'\0',b' ').decode())
    assert process['start_ticks']==279549118 and str(root/'resume_capacity_pj_qd.py') in process['cmdline']
rows=[]
for case in progress['cases']:
    i=case['case_index'];history=[]
    for entry in case['history']:
        if int(entry['job'].split('.')[0])<1846:continue
        folder=old/'actual'/('case-'+str(i))/('start-'+str(entry['start']).zfill(7))
        archive=folder/'result.tar.gz';archive_sha=file_sha(archive)
        assert archive_sha==entry['original_result_archive_sha256']
        with tarfile.open(archive) as t:
            files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile() and m.name.removeprefix('./') in ('receipt.json','worker-exit.txt')}
        receipt=json.loads(files['receipt.json'])
        qstat=(folder/'qstat.stdout').read_bytes()
        assert re.search(rb'^\s*job_state = F\s*$',qstat,re.M)
        assert all(re.search(rb'^\s*'+field+rb' = 0\s*$',qstat,re.M) for field in (b'Exit_status',b'Stageout_status'))
        assert receipt['passed'] and receipt['error'] is None and receipt['source_unchanged']
        assert receipt['pbs_job']==entry['job'] and receipt['start']==entry['start'] and receipt['stop']==entry['stop']
        assert receipt['original_steps_started']==receipt['original_steps_completed']==entry['stop']-entry['start']
        closed=old/'closed'/('case-'+str(i))/('stop-'+str(entry['stop']).zfill(7)+'.tar.gz')
        assert file_sha(closed)==entry['closed_archive_sha256']
        history.append(dict(history=entry,receipt=receipt,qstat=qstat.decode(),receipt_sha256=sha(files['receipt.json']),
            qstat_sha256=sha(qstat),original_archive_sha256=archive_sha,closed_archive_sha256=entry['closed_archive_sha256'],
            worker_exit=files['worker-exit.txt'].decode().strip()))
    running=None
    if case['status']=='running':
        q=subprocess.run(['qstat','-fx',case['job']],capture_output=True,timeout=20)
        running=dict(job=case['job'],actual_exit=q.returncode,stdout=q.stdout.decode(),stderr=q.stderr.decode())
    rows.append(dict(case_index=i,site=case['identity']['site'],closed_steps=case['steps'],status=case['status'],
        current_job=case.get('job'),new_closed_windows=history,running_qstat=running,
        spinup_accepted=case['identity']['spinup_accepted'],score_eligible=case['identity']['score_eligible']))
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),process=process,
    progress_sha256=sha(progress_raw),rows=rows,read_only=True,model_calls=0),indent=2))

"""Read-only original source/manifest guards after1864/65; no model import."""
from pathlib import Path
import base64
import hashlib
import json
import socket
import tarfile
import time

assert socket.gethostname()=='compute002'
root=Path('/tmp/noahmp-numpy-baseline-resume-pj')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
stage_raw=(root/'STAGE_SHA256.json').read_bytes();stage=json.loads(stage_raw)
stage_actual={name:sha((root/name).read_bytes()) for name in stage}
assert len(stage)==36 and stage_actual==stage
archive=root/'inputs/climatology-final-candidate-nm-source.tar.gz'
with tarfile.open(archive) as t:
    files={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()}
manifest_raw=files['SOURCE_SHA256.json'];manifest=json.loads(manifest_raw)
assert sha(manifest_raw)=='a39f48772a6751c4ec12f9a2034c6015105a26d81f17480d654ffb21ee7ced5f'
assert len(manifest)==584 and all(sha(files[name])==expected for name,expected in manifest.items())
original_controls={}
for name in ('preparation/run_window_job_pj.py','preparation/run_window_pj.py','pf/pb/numpy_chain_pb.py'):
    raw=(root/name).read_bytes();original_controls[name]=dict(sha256=sha(raw),base64=base64.b64encode(raw).decode())
rows=[]
for i,job in [(6,'1864.manager'),(7,'1865.manager')]:
    raw_root=root/'raw'/('case-'+str(i))/'start-7248'
    with tarfile.open(raw_root/'result.tar.gz') as t:
        selected={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile() and m.name.removeprefix('./') in ('receipt.json','run/receipt.json','PJ-traceback.txt')}
    source=Path('/var/tmp')/('pbs.'+job)/'source-nm584'
    retained=dict(path=str(source),exists=source.exists())
    if source.exists():
        retained.update(manifest_sha256=sha((source/'SOURCE_SHA256.json').read_bytes()),
            all584_files_exact=all(sha((source/name).read_bytes())==expected for name,expected in manifest.items()))
    top=json.loads(selected['receipt.json']);inner=json.loads(selected['run/receipt.json'])
    assert top['pbs_job']==inner['pbs_job']==job and top['source_unchanged'] is False and inner['source_unchanged'] is True
    rows.append(dict(case_index=i,job=job,outer_summary_source_unchanged=top['source_unchanged'],
        original_inner_run_receipt_source_unchanged=inner['source_unchanged'],inner_failure=inner['failure'],
        original_receipt_sha256={name:sha(raw) for name,raw in selected.items()},
        retained_original_job_source_posthoc=retained,
        interpretation='Outer False is its initialized default left on exception. Original inner run_window verifies source before the run and after caught model failure, then sets True. Posthoc stage/archive checks are separate from those original guards.'))
print(json.dumps(dict(observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),stage36_exact=True,
    stage_index_sha256=sha(stage_raw),stage_actual=stage_actual,source_archive_sha256=sha(archive.read_bytes()),
    source_manifest_sha256=sha(manifest_raw),source584_archive_members_exact=True,original_controls=original_controls,
    rows=rows,model_calls=0,remote_mutations=0),indent=2))

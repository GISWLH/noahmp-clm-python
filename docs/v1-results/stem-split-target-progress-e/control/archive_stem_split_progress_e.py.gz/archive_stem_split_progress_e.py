from pathlib import Path
import datetime,hashlib,io,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'p6-stem-split-e';r=s/'target-a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();raw=(r/'progress.json').read_bytes();d=json.loads(raw);a=b/'stem-split-target-progress-e-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in [s/'SOURCE_SHA256.json',r/'launch.json',r/'collection.json']:
  t.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
 for row in d['results']:
  name=Path(row['file']).stem
  for suffix in ['-expected.json','-receipt.json','.log','.xml']:t.add(r/(name+suffix),arcname='target-a/'+name+suffix,recursive=False)
 for n in ['tests/test_gpu_stem_column_precision.py','src/noahmp_clm/gpu/clm_layered_column.py','src/noahmp_clm/gpu/cuda/clm_layered_column.py','src/noahmp_clm/gpu/cuda/clm_layered_column_kernel.cu']:t.add(s/n,arcname='source/'+n,recursive=False)
 for n in ['run_stem_split_target_e.py','launch_stem_split_target_e.py','archive_stem_split_progress_e.py']:t.add(b/n,arcname='control/'+n,recursive=False)
 for name,value in [('captured-progress.json',raw),('snapshot.json',(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Immutable exact506E partial target22 snapshot, only completed canonical files preserved. Original float64 fixture-promotion failure retained; production float32 all380 passed. Active file not credited, no full GPU/science pass.',active=d.get('active'),results=[dict(file=x['file'],passed=x['passed'],counts=x['receipt']['counts']) for x in d['results']]),indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(name);info.size=len(value);t.addfile(info,io.BytesIO(value))
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size)))

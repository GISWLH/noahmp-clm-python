from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/lhwang/work/noahmp-v1');s=b/'pft-optics-final-c';r=s/'targets-c';d=json.loads((r/'exit.json').read_text());assert not d['passed'] and d['source_unchanged'] and len(d['results'])==3;a=b/'pft-optics-gpu20-failed-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
    t.add(s/'SOURCE_SHA256.json',arcname='SOURCE_SHA256.json',recursive=False)
    for p in sorted(r.rglob('*')):
        if p.is_file():t.add(p,arcname='targets-c/'+p.relative_to(r).as_posix(),recursive=False)
    for n in ['pft-optics-final-c-source.tar.gz','pft-optics-cpu-final-b-evidence.tar.gz']:t.add(b/n,arcname='prerequisites/'+n,recursive=False)
    for n in ['launch_pft_optics_gpu_b.py','control_pft_optics_gpu_b.py','collect_pft_optics_gpu_b.py','archive_pft_optics_gpu_failed_c.py','gpu-worker-lifecycle-a/run_pytest_worker_a.py']:t.add(b/n,arcname='control/'+n,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size)))

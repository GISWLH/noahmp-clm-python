from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-station-full-c';a=b/'p6-stem-station-c-source.tar.gz';s=Path(os.environ['TMPDIR'])/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(a)=='b227a67b8a685e760bba5f0f16ef154b71a9162955a11e3206cc17ce8e15bdac'
# Reuse only the real successful target receipt, not the export-helper status.
target=b/'stem-station-c/targets-receipt.json'
for _ in range(80):
 if target.exists():break
 time.sleep(10.)
assert target.exists();d=json.loads(target.read_text());assert d['returncode']==0 and d['source_unchanged'] and d['source_archive_sha256']==sha(a) and d['counts']==dict(tests=45,failures=0,errors=0,skipped=0)
s.mkdir(exist_ok=False)
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==504 and all(sha(s/n)==v for n,v in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None);files=sorted(v.relative_to(s).as_posix() for v in (s/'tests').glob('test_*.py') if not v.name.startswith(('test_gpu','test_jax','test_cuda')));xml=r/'cpu-full.xml';start=time.monotonic()
with (r/'cpu-full.log').open('w') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
counts={key:sum(int(v.attrib[key]) for v in ET.parse(xml).getroot().iter('testsuite')) for key in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==v for n,v in m.items());receipt=dict(scope='Fresh fullCPU879 on exact504C after actual target45. Separate control avoids original target export matching pytest-current symlink twice. Actual physics and original tests/gates unchanged; no native/scientific claim.',returncode=code,counts=counts,source_files=len(m),source_unchanged=unchanged,source_archive_sha256=sha(a),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start);(r/'cpu-full-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert code==0 and unchanged and counts==dict(tests=879,failures=0,errors=0,skipped=0)
reference=r/'numpy-reference';reference.mkdir(exist_ok=False)
dirs={v.resolve() for v in Path(os.environ['TMPDIR']).glob('pytest-of-*/pytest-*/test_actual_numpy_station_spli*') if v.is_dir() and not v.is_symlink() and re.fullmatch(r'pytest-\d+',v.parent.name) and v.name[-1].isdigit()};assert len(dirs)==2
for source_case in sorted(dirs):shutil.copytree(source_case,reference/source_case.name)
manifest={v.relative_to(reference).as_posix():sha(v) for v in reference.rglob('*') if v.is_file()};(r/'reference-export.json').write_text(json.dumps(dict(scope='Actual fullCPU879 NumPy complete and split/resumed physical trajectories, synthetic forcing only, preserved before PBS cleanup.',files=manifest),indent=2)+'\n')

from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
assert os.environ.get('PBS_JOBID')
b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-station-c';s=Path(os.environ['TMPDIR']).resolve()/'source';s.mkdir(exist_ok=False);a=b/'p6-stem-station-c-source.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(a)=='b227a67b8a685e760bba5f0f16ef154b71a9162955a11e3206cc17ce8e15bdac'
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==504 and all(sha(s/n)==v for n,v in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());env=os.environ.copy();env.update(PYTHONPATH=':'.join(map(str,[b/'test-deps',s,s/'src',s/'tests',s/'benchmarks'])),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('NOAHMP_REQUIRE_GPU',None)
def run(label,files,expected):
 start=time.monotonic();xml=r/(label+'.xml')
 with (r/(label+'.log')).open('w') as log:code=subprocess.run([sys.executable,'-m','pytest','-q','-s',*files,'--junitxml='+str(xml)],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 counts={key:sum(int(v.attrib[key]) for v in ET.parse(xml).getroot().iter('testsuite')) for key in ['tests','failures','errors','skipped']};unchanged=all(sha(s/n)==v for n,v in m.items());record=dict(scope='Actual station structure/checkpoint target45 and fullCPU879 on504. Native runner device execution pending, prior502 coupling and493 full regression remain frozen/separate. No annual/spinup/scientific claim.',returncode=code,counts=counts,source_files=len(m),source_unchanged=unchanged,source_archive_sha256=sha(a),pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,seconds=time.monotonic()-start)
 (r/(label+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n');print(label,json.dumps(record),flush=True)
 return code==0 and unchanged and counts==dict(tests=expected,failures=0,errors=0,skipped=0)
passed=run('targets',['tests/test_fluxnet_native_runner.py','tests/test_fluxnet_stem_runner.py'],45)
if not passed:raise SystemExit(1)
import shutil
reference=r/'numpy-reference';reference.mkdir(exist_ok=False)
dirs=[v for v in Path(os.environ['TMPDIR']).glob('pytest-of-*/pytest-*/test_actual_numpy_station_spli*') if v.is_dir() and not v.is_symlink() and v.name[-1].isdigit()]
assert len(dirs)==2
for source_case in dirs:shutil.copytree(source_case,reference/source_case.name)
manifest={v.relative_to(reference).as_posix():sha(v) for v in reference.rglob('*') if v.is_file()}
(r/'reference-export.json').write_text(json.dumps(dict(scope='Actual complete target NumPy physics/config/forcing/state/trace plus split/resume pair retained before PBS temporary directory cleanup. Synthetic forcing only, no observation/science acceptance.',files=manifest),indent=2)+'\n')
files=sorted(p.relative_to(s).as_posix() for p in (s/'tests').glob('test_*.py') if not p.name.startswith(('test_gpu','test_jax','test_cuda')))
raise SystemExit(0 if run('cpu-full',files,879) else 1)

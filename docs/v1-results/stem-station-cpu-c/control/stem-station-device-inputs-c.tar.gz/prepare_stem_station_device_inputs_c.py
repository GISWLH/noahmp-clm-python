from pathlib import Path
import hashlib,json,os,sys,tarfile
import numpy as np
assert os.environ.get('PBS_JOBID');b=Path('/home/zhangyq/noahmp-v1');r=b/'stem-station-device-inputs-c';a=b/'p6-stem-station-c-source.tar.gz';s=Path(os.environ['TMPDIR'])/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(a)=='b227a67b8a685e760bba5f0f16ef154b71a9162955a11e3206cc17ce8e15bdac';d=json.loads((b/'stem-station-c/targets-receipt.json').read_text());assert d['returncode']==0 and d['counts']==dict(tests=45,failures=0,errors=0,skipped=0)
s.mkdir(exist_ok=False)
with tarfile.open(a) as t:t.extractall(s,filter='data')
m=json.loads((s/'SOURCE_SHA256.json').read_text());assert len(m)==504 and all(sha(s/n)==v for n,v in m.items());sys.path[:0]=[str(b/'test-deps'),str(s),str(s/'src'),str(s/'tests'),str(s/'benchmarks')]
from test_fluxnet_stem_runner import configuration
from run_fluxnet_column import atomic_json
rows=[]
for name,scheme in [('prescribed','PRESCRIBED'),('cn-noncrop','CN_NONCROP')]:
 config,f=configuration(scheme);folder=r/name;folder.mkdir(exist_ok=False);atomic_json(folder/'config.json',config)
 np.savez_compressed(folder/'forcing.npz',time_start=np.asarray(['200301010000','200301010030','200301010100','200301010130']),time_end=np.asarray(['200301010030','200301010100','200301010130','200301010200']),forcing=np.asarray([list(vars(f).values())]*4),environment=np.asarray([[380.,.5,.5]]*4))
 atomic_json(folder/'meta.json',dict(site=config['site'],prepared_npz_sha256=sha(folder/'forcing.npz'),latitude=config['latitude'],longitude=config['longitude'],utc_offset_hours=config['utc_offset_hours']))
 rows.append(dict(case=name,input=name+'/forcing.npz',input_manifest=name+'/meta.json',configuration=name+'/config.json'))
atomic_json(r/'batch.json',dict(cases=rows));assert all(sha(s/n)==v for n,v in m.items());(r/'SOURCE_SHA256.json').write_bytes((s/'SOURCE_SHA256.json').read_bytes());manifest={v.relative_to(r).as_posix():sha(v) for v in r.rglob('*') if v.is_file()};atomic_json(r/'receipt.json',dict(scope='Actual EHPC compute-node synthesis of exactly the two passed NumPy target fixtures; synthetic4-step forcing only, no FLUXNET/annual/science claim. Full879 and original502 native validation remain separate.',pbs_job=os.environ['PBS_JOBID'],node=os.uname().nodename,source_unchanged=True,files=manifest))
archive=b/'stem-station-device-inputs-c.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(r.rglob('*')):
  if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
print(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size)),flush=True)

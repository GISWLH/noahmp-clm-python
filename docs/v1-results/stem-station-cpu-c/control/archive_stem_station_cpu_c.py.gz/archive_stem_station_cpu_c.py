from pathlib import Path
import hashlib,json,tarfile
b=Path('/home/zhangyq/noahmp-v1');target=b/'stem-station-c';full=b/'stem-station-full-c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((target/'targets-receipt.json').read_text());f=json.loads((full/'cpu-full-receipt.json').read_text());assert d['returncode']==f['returncode']==0 and d['source_unchanged'] and f['source_unchanged'] and d['counts']==dict(tests=45,failures=0,errors=0,skipped=0) and f['counts']==dict(tests=879,failures=0,errors=0,skipped=0) and (full/'pbs-exit.txt').read_text().strip()=='0'
refs=json.loads((full/'reference-export.json').read_text())['files'];assert all(sha(full/'numpy-reference'/n)==v for n,v in refs.items());rows=[]
with tarfile.open(b/'stem-station-device-inputs-c.tar.gz') as inputs:
 for case in sorted((full/'numpy-reference').iterdir()):
  config=json.loads((case/'config.json').read_text());scheme=config['canopy_structure']['parameters']['scheme'];name='prescribed' if scheme=='PRESCRIBED' else 'cn-noncrop'
  hashes={n:sha(case/n) for n in ['config.json','forcing.npz','meta.json']};equal={n:hashlib.sha256(inputs.extractfile(name+'/'+n).read()).hexdigest()==v for n,v in hashes.items()};assert all(equal.values())
  reports={}
  for label in ['continuous','split']:
   folder=case/label;p=folder/'report.json';report=json.loads(p.read_text());assert report['status']=='complete' and report['steps_completed']==4 and report['source_unchanged'] and sha(folder/report['model_npz'])==report['model_npz_sha256'] and sha(folder/report['checkpoint_file'])==report['checkpoint_sha256'];reports[label]=sha(p)
  rows.append(dict(scheme=scheme,input_hashes=hashes,device_inputs_bytes_equal=equal,reports=reports))
record=dict(scope='Actual EHPC504C target45 and fullCPU879, complete NumPy full/split/resume trajectories and exact byte equality to device fixture inputs. PBS154 target pytest0 followed by metadata-export failure; separate PBS155 full879/control/reference export all0. No native or observational acceptance.',cases=rows,target_pbs_exit=(target/'pbs-exit.txt').read_text().strip(),full_pbs_exit=0);(full/'binding.json').write_text(json.dumps(record,indent=2)+'\n');a=b/'stem-station-cpu-c-evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for root in [target,full]:
  for p in sorted(root.rglob('*')):
   if p.is_file():t.add(p,arcname=root.name+'/'+p.relative_to(root).as_posix(),recursive=False)
 for p in [b/'stem-station-device-inputs-c.tar.gz',Path(__file__)]:t.add(p,arcname='control/'+p.name,recursive=False)
print(json.dumps(dict(archive=a.name,sha256=sha(a),bytes=a.stat().st_size,cases=rows)))

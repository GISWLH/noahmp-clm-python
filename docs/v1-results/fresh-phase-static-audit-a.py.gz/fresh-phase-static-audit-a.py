from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
groups = {
    'leafweb-crop-ambient-a': 'fed04262a2c560b0601186595151d821bf34d79d2f0003c2fd6b6315bbcc7f91',
    'qia-physical-numpy-week-c': 'a749be08a19360f2957104f7824bf9281fbfcda9c6e2a3ec3d0d06e44ad11022',
    'qia-numpy182-abc': '6b9bc8dd4b74f5d2825961527c3e650401ce6ff76b573a6502631ec011026a58',
    'fresh-phase-edge-cpu-b': 'e623d1aaac00aedf2f8f2dd0f8b761c4ab1824fab2f5b88fb41cfb9b6f977c25',
    'fresh-phase-edge-gpu-b': '315d548602aac759dcc684346ae7fa75f3ea493585c5d83048a86be4d9e7a2df',
    'fresh-phase-full-deferred-a': '2e275583a332c7504028097bf4b30727b71ffd5f8af2c3d38734a1804e34b78b',
    'qia-fresh-phase-numpy-launch-a': '2dcf09440b7906163bce620f75f430022f7eb69223a517076f4e1153b4b9446b',
}

def read(group, name):
    p = root / 'docs/v1-results' / group / name
    data = p.read_bytes()
    return gzip.decompress(data) if name.endswith('.gz') else data

counts = {}
python_files = 0
for group, expected in groups.items():
    archive = root / 'outputs/v1' / (group + '-evidence.tar.gz')
    assert sha(archive.read_bytes()) == expected
    manifest = json.loads(read(group, 'manifest.json'))
    assert manifest['archive_sha256'] == expected
    for item in manifest['artifacts']:
        p = root / 'docs/v1-results' / group / item['path']
        stored = p.read_bytes()
        assert sha(stored) == item['stored_sha256'], p
        raw = gzip.decompress(stored) if item['path'] == item['source'] + '.gz' else stored
        assert sha(raw) == item['source_sha256'], p
        if item['source'].endswith('.py'):
            ast.parse(raw.decode('utf-8-sig'))
            python_files += 1
    counts[group] = len(manifest['artifacts'])

manifest_raw = read('fresh-phase-edge-cpu-b', 'SOURCE_SHA256.json.gz')
assert sha(manifest_raw) == '23dbd1e41080af5f2742e574aca7899163061bab68ea325b001a984473c23714'
manifest = json.loads(manifest_raw)
assert len(manifest) == 510
checked = []
for name, expected in manifest.items():
    if not name.startswith(('src/', 'tests/', 'benchmarks/')):
        continue
    p = root / name
    raw = p.read_bytes()
    assert expected in {sha(raw), sha(raw.replace(b'\r\n', b'\n'))}, name
    checked.append(name)

phase = 'src/noahmp_clm/physics/canopy_phase_energy.py'
current = ast.parse((root / phase).read_text())
old = ast.parse(subprocess.check_output(['git', 'show', 'HEAD:' + phase], cwd=root).decode())
get_solver = lambda tree: next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'solve_canopy_phase_energy')
new_solver, old_solver = get_solver(current), get_solver(old)
assert ast.dump(new_solver.args) == ast.dump(old_solver.args)
nested = lambda node: {n.name: ast.dump(n) for n in node.body if isinstance(n, ast.FunctionDef)}
assert nested(new_solver) == nested(old_solver)

cpu = ET.fromstring(read('fresh-phase-edge-cpu-b', 'cpu-full.xml.gz'))
suite = list(cpu)[0]
assert [int(suite.attrib[n]) for n in ['tests', 'failures', 'errors', 'skipped']] == [910, 0, 0, 0]
gpu = json.loads(read('fresh-phase-edge-gpu-b', 'target-a/receipt.json.gz'))
assert gpu['passed'] and gpu['counts'] == dict(tests=8, failures=0, errors=0, skipped=0)
device = json.loads(read('fresh-phase-edge-gpu-b', 'fresh182-device-a/receipt.json.gz'))
assert device['failure'] is None and device['source_unchanged'] and device['device_barriers_complete']
assert device['results']['same_precision']['maximum_absolute_difference'] == 0.
launch = json.loads(read('fresh-phase-full-deferred-a', 'controller/launch.json.gz'))
assert launch['source_manifest_sha256'] == sha(manifest_raw) and launch['pid'] == 2750196
for name, expected in launch['controls_sha256'].items():
    assert sha(read('fresh-phase-full-deferred-a', 'control/' + name + '.gz')) == expected

result = dict(scope='Local metadata/hash/XML/AST audit only; no model, pytest, scientific arrays, or data calibration executed locally. CPU numerical work on EHPC PBS and GPU on xuanze. Older packaged documentation is not the current repository documentation. Runtime comparison permits only CRLF-to-LF normalization.',
              groups=counts, artifacts=sum(counts.values()), python_artifacts_ast_checked=python_files,
              runtime_files_matching_frozen_source=len(checked), source_files=510,
              source_manifest_sha256=sha(manifest_raw), physical_nested_functions_and_original_signature_unchanged=True,
              cpu_tests=910, gpu_phase_tests=8, original182_raw32_max_absolute_difference=0.,
              current_full_queue_pid=2750196, audit_control_sha256=sha(Path(__file__).read_bytes()))
(root / 'docs/v1-results/fresh-phase-static-audit-a.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(root / 'docs/v1-results/fresh-phase-static-audit-a.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
